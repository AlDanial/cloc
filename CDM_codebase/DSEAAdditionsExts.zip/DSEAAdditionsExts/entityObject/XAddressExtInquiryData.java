/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[913b5073583ec2fbecfec060b8fe8261]
 */
package com.ibm.daimler.dsea.entityObject;


import com.ibm.mdm.base.db.EntityMapping;
import com.ibm.pdq.annotation.Select;


import com.dwl.tcrm.coreParty.entityObject.EObjAddress;

import com.ibm.mdm.base.db.ResultQueue2;

import java.util.Iterator;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * 
 * @generated
 */
public interface XAddressExtInquiryData {

  /**
   * MDM_TODO: CDKWB0050I The generated parameter and result lists in this file should be checked to ensure that each matches its
   * associated SQL query. Each list entry must be comma separated and identify a field within an entity object class.
   */ 
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */ 
   public final static String tableAliasString1 = "tableAlias (" + 
     "ADDRESS => com.dwl.tcrm.coreParty.entityObject.EObjAddress, " + 
     "H_ADDRESS => com.dwl.tcrm.coreParty.entityObject.EObjAddress, " + 
     "addressgroup => com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup, " + 
     "locationgroup => com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup, " + 
     "contmacrorole => com.dwl.tcrm.coreParty.entityObject.EObjContMacroRole, " + 
     "macroroleassoc => com.dwl.tcrm.coreParty.entityObject.EObjMacroRoleAssoc , " + 
     "ADDRESS => com.ibm.daimler.dsea.entityObject.EObjXAddressExt , " + 
     "H_ADDRESS => com.ibm.daimler.dsea.entityObject.EObjXAddressExt" + 
     ")";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension XAddress.
   *
   * @generated
   */ 
   public final static String getAddressHistorySQL = "SELECT DISTINCT A.H_ADDRESS_ID AS HIST_ID_PK, A.H_ACTION_CODE, A.H_CREATED_BY, A.H_CREATE_DT, A.H_END_DT, A.ADDRESS_ID, A.RESIDENCE_TP_CD, A.ADDR_LINE_ONE, A.ADDR_LINE_TWO, A.ADDR_LINE_THREE, A.P_ADDR_LINE_ONE, A.P_ADDR_LINE_TWO, A.P_ADDR_LINE_THREE, A.CITY_NAME, A.POSTAL_CODE,A.POSTAL_BARCODE, A.RESIDENCE_NUM, A.PROV_STATE_TP_CD, A.COUNTY_CODE, A.COUNTRY_TP_CD, A.ADDR_STANDARD_IND, A.OVERRIDE_IND, A.LATITUDE_DEGREES, A.LONGITUDE_DEGREES, A.LAST_UPDATE_DT, A.LAST_UPDATE_USER, A.LAST_UPDATE_TX_ID, A.BUILDING_NAME, A.STREET_NUMBER, A.STREET_NAME, A.STREET_SUFFIX, A.STREET_PREFIX, A.PRE_DIRECTIONAL, A.POST_DIRECTIONAL, A.BOX_DESIGNATOR, A.BOX_ID, A.STN_INFO, A.STN_ID, A.REGION, A.DEL_DESIGNATOR, A.DEL_ID, A.DEL_INFO, A.XADDR_VERIFICATION_DT, A.XSUBCITY_TP_CD, A.XDISTRICT_TP_CD, A.XBUILDING_NAME, A.XSTREET_NUMBER, A.XSTREET_NAME, A.XSuburb" + 
     " FROM H_ADDRESS A" + 
     " WHERE A.H_ADDRESS_ID = ? AND (( ? BETWEEN A.H_CREATE_DT AND A.H_END_DT ) OR ( ? >= A.H_CREATE_DT AND A.H_END_DT IS NULL ))";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getAddressHistoryParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.historyIdPK=H_ADDRESS_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.histCreateDt=H_CREATE_DT"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getAddressHistoryResults =
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.historyIdPK=HIST_ID_PK," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.histActionCode=H_ACTION_CODE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.histCreatedBy=H_CREATED_BY," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.histEndDt=H_END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.addressIdPK=ADDRESS_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.residenceTpCd=RESIDENCE_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.addrLineOne=ADDR_LINE_ONE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.addrLineTwo=ADDR_LINE_TWO," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.addrLineThree=ADDR_LINE_THREE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.pAddrLineOne=P_ADDR_LINE_ONE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.pAddrLineTwo=P_ADDR_LINE_TWO," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.pAddrLineThree=P_ADDR_LINE_THREE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.cityName=CITY_NAME," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.postalCode=POSTAL_CODE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.postalBarCode=POSTAL_BARCODE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.residenceNum=RESIDENCE_NUM," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.provStateTpCd=PROV_STATE_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.countyCode=COUNTY_CODE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.countryTpCd=COUNTRY_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.addrStandardInd=ADDR_STANDARD_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.overrideInd=OVERRIDE_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.latitudeDegrees=LATITUDE_DEGREES," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.longtitudeDegrees=LONGITUDE_DEGREES," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.buildingName=BUILDING_NAME," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.streetNumber=STREET_NUMBER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.streetName=STREET_NAME," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.streetSuffix=STREET_SUFFIX," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.streetPrefix=STREET_PREFIX," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.preDirectional=PRE_DIRECTIONAL," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.postDirectional=POST_DIRECTIONAL," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.boxDesignator=BOX_DESIGNATOR," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.boxId=BOX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.stnInfo=STN_INFO," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.stnId=STN_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.region=REGION," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.delDesignator=DEL_DESIGNATOR," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.delId=DEL_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.delInfo=DEL_INFO," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressExt.XAddressVerificationDate=XADDR_VERIFICATION_DT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressExt.XSubcity=XSUBCITY_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressExt.XDistrict=XDISTRICT_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressExt.XBuildingName=XBUILDING_NAME," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressExt.XStreetNumber=XSTREET_NUMBER," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressExt.XStreetName=XSTREET_NAME," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressExt.XSuburb=XSuburb"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension XAddress.
   *
   * @generated
   */ 
   public final static String getAddressSQL = "SELECT ADDRESS.ADDRESS_ID, ADDRESS.RESIDENCE_TP_CD, ADDRESS.ADDR_LINE_ONE, ADDRESS.ADDR_LINE_TWO, ADDRESS.ADDR_LINE_THREE, ADDRESS.P_ADDR_LINE_ONE, ADDRESS.P_ADDR_LINE_TWO, ADDRESS.P_ADDR_LINE_THREE, ADDRESS.CITY_NAME, ADDRESS.POSTAL_CODE, ADDRESS.POSTAL_BARCODE ,ADDRESS.RESIDENCE_NUM, ADDRESS.PROV_STATE_TP_CD, ADDRESS.COUNTY_CODE, ADDRESS.COUNTRY_TP_CD, ADDRESS.ADDR_STANDARD_IND, ADDRESS.OVERRIDE_IND , ADDRESS.LATITUDE_DEGREES, ADDRESS.LONGITUDE_DEGREES, ADDRESS.LAST_UPDATE_DT, ADDRESS.LAST_UPDATE_USER, ADDRESS.LAST_UPDATE_TX_ID, ADDRESS.BUILDING_NAME, ADDRESS.STREET_NUMBER, ADDRESS.STREET_NAME, ADDRESS.STREET_SUFFIX, ADDRESS.STREET_PREFIX, ADDRESS.PRE_DIRECTIONAL, ADDRESS.POST_DIRECTIONAL, ADDRESS.BOX_DESIGNATOR, ADDRESS.BOX_ID, ADDRESS.STN_INFO, ADDRESS.STN_ID, ADDRESS.REGION, ADDRESS.DEL_DESIGNATOR, ADDRESS.DEL_ID, ADDRESS.DEL_INFO, ADDRESS.P_CITY, ADDRESS.P_STREET_NAME, ADDRESS.XADDR_VERIFICATION_DT, ADDRESS.XSUBCITY_TP_CD, ADDRESS.XDISTRICT_TP_CD, ADDRESS.XBUILDING_NAME, ADDRESS.XSTREET_NUMBER, ADDRESS.XSTREET_NAME, ADDRESS.XSuburb" + 
     " FROM ADDRESS" + 
     " WHERE (ADDRESS.ADDRESS_ID = ?)";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getAddressParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.addressIdPK=ADDRESS_ID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getAddressResults =
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.addressIdPK=ADDRESS_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.residenceTpCd=RESIDENCE_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.addrLineOne=ADDR_LINE_ONE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.addrLineTwo=ADDR_LINE_TWO," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.addrLineThree=ADDR_LINE_THREE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.pAddrLineOne=P_ADDR_LINE_ONE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.pAddrLineTwo=P_ADDR_LINE_TWO," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.pAddrLineThree=P_ADDR_LINE_THREE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.cityName=CITY_NAME," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.postalCode=POSTAL_CODE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.postalBarCode=POSTAL_BARCODE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.residenceNum=RESIDENCE_NUM," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.provStateTpCd=PROV_STATE_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.countyCode=COUNTY_CODE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.countryTpCd=COUNTRY_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.addrStandardInd=ADDR_STANDARD_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.overrideInd=OVERRIDE_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.latitudeDegrees=LATITUDE_DEGREES," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.longtitudeDegrees=LONGITUDE_DEGREES," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.buildingName=BUILDING_NAME," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.streetNumber=STREET_NUMBER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.streetName=STREET_NAME," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.streetSuffix=STREET_SUFFIX," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.streetPrefix=STREET_PREFIX," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.preDirectional=PRE_DIRECTIONAL," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.postDirectional=POST_DIRECTIONAL," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.boxDesignator=BOX_DESIGNATOR," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.boxId=BOX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.stnInfo=STN_INFO," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.stnId=STN_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.region=REGION," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.delDesignator=DEL_DESIGNATOR," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.delId=DEL_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.delInfo=DEL_INFO," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.pCityName=P_CITY," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.pStreetName=P_STREET_NAME," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressExt.XAddressVerificationDate=XADDR_VERIFICATION_DT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressExt.XSubcity=XSUBCITY_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressExt.XDistrict=XDISTRICT_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressExt.XBuildingName=XBUILDING_NAME," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressExt.XStreetNumber=XSTREET_NUMBER," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressExt.XStreetName=XSTREET_NAME," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressExt.XSuburb=XSuburb"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension XAddress.
   *
   * @generated
   */ 
   public final static String getAddressGroupMicroSQL = "SELECT ADDRESS.ADDRESS_ID, ADDRESS.RESIDENCE_TP_CD, ADDRESS.ADDR_LINE_ONE, ADDRESS.ADDR_LINE_TWO, ADDRESS.ADDR_LINE_THREE, ADDRESS.P_ADDR_LINE_ONE, ADDRESS.P_ADDR_LINE_TWO, ADDRESS.P_ADDR_LINE_THREE, ADDRESS.CITY_NAME, ADDRESS.POSTAL_CODE, ADDRESS.POSTAL_BARCODE ,ADDRESS.RESIDENCE_NUM, ADDRESS.PROV_STATE_TP_CD, ADDRESS.COUNTY_CODE, ADDRESS.COUNTRY_TP_CD, ADDRESS.ADDR_STANDARD_IND, ADDRESS.OVERRIDE_IND , ADDRESS.LATITUDE_DEGREES, ADDRESS.LONGITUDE_DEGREES, ADDRESS.LAST_UPDATE_DT, ADDRESS.LAST_UPDATE_USER, ADDRESS.LAST_UPDATE_TX_ID, ADDRESS.BUILDING_NAME, ADDRESS.STREET_NUMBER, ADDRESS.STREET_NAME, ADDRESS.STREET_SUFFIX, ADDRESS.STREET_PREFIX, ADDRESS.PRE_DIRECTIONAL, ADDRESS.POST_DIRECTIONAL, ADDRESS.BOX_DESIGNATOR, ADDRESS.BOX_ID, ADDRESS.STN_INFO, ADDRESS.STN_ID, ADDRESS.REGION, ADDRESS.DEL_DESIGNATOR, ADDRESS.DEL_ID, ADDRESS.DEL_INFO, ADDRESS.XADDR_VERIFICATION_DT, ADDRESS.XSUBCITY_TP_CD, ADDRESS.XDISTRICT_TP_CD, ADDRESS.XBUILDING_NAME, ADDRESS.XSTREET_NUMBER, ADDRESS.XSTREET_NAME, ADDRESS.XSuburb" + 
     " FROM ADDRESS, ADDRESSGROUP A, LOCATIONGROUP B, CONTMACROROLE C, MACROROLEASSOC D" + 
     " WHERE ADDRESS.ADDRESS_ID = A.ADDRESS_ID AND A.LOCATION_GROUP_ID = B.LOCATION_GROUP_ID AND B.CONT_ID = C.CONT_ID AND C.CONT_MACRO_ROLE_ID = D.CONT_MACRO_ROLE_ID AND UPPER(D.ENTITY_NAME) = 'ADDRESSGROUP' AND A.LOCATION_GROUP_ID = D.INSTANCE_PK AND B.CONT_ID = ? AND A.ADDR_USAGE_TP_CD = ? AND C.ROLE_TP_CD = ? AND (B.END_DT IS NULL OR B.END_DT > ?)";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getAddressGroupMicroParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.addrUsageTpCd=ADDR_USAGE_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContMacroRole.roleType=ROLE_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.endDt=END_DT"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getAddressGroupMicroResults =
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.addressIdPK=ADDRESS_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.residenceTpCd=RESIDENCE_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.addrLineOne=ADDR_LINE_ONE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.addrLineTwo=ADDR_LINE_TWO," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.addrLineThree=ADDR_LINE_THREE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.pAddrLineOne=P_ADDR_LINE_ONE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.pAddrLineTwo=P_ADDR_LINE_TWO," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.pAddrLineThree=P_ADDR_LINE_THREE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.cityName=CITY_NAME," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.postalCode=POSTAL_CODE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.postalBarCode=POSTAL_BARCODE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.residenceNum=RESIDENCE_NUM," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.provStateTpCd=PROV_STATE_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.countyCode=COUNTY_CODE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.countryTpCd=COUNTRY_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.addrStandardInd=ADDR_STANDARD_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.overrideInd=OVERRIDE_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.latitudeDegrees=LATITUDE_DEGREES," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.longtitudeDegrees=LONGITUDE_DEGREES," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.buildingName=BUILDING_NAME," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.streetNumber=STREET_NUMBER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.streetName=STREET_NAME," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.streetSuffix=STREET_SUFFIX," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.streetPrefix=STREET_PREFIX," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.preDirectional=PRE_DIRECTIONAL," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.postDirectional=POST_DIRECTIONAL," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.boxDesignator=BOX_DESIGNATOR," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.boxId=BOX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.stnInfo=STN_INFO," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.stnId=STN_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.region=REGION," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.delDesignator=DEL_DESIGNATOR," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.delId=DEL_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.delInfo=DEL_INFO," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressExt.XAddressVerificationDate=XADDR_VERIFICATION_DT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressExt.XSubcity=XSUBCITY_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressExt.XDistrict=XDISTRICT_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressExt.XBuildingName=XBUILDING_NAME," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressExt.XStreetNumber=XSTREET_NUMBER," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressExt.XStreetName=XSTREET_NAME," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressExt.XSuburb=XSuburb"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension XAddress.
   *
   * @generated
   */ 
   public final static String getAddressLightImagesSQL = "SELECT DISTINCT A.ADDRESS_ID, A.LAST_UPDATE_DT, A.XADDR_VERIFICATION_DT, A.XSUBCITY_TP_CD, A.XDISTRICT_TP_CD, A.XBUILDING_NAME, A.XSTREET_NUMBER, A.XSTREET_NAME, A.XSuburb" + 
     " FROM H_ADDRESS A" + 
     " WHERE A.ADDRESS_ID = ? AND ( A.H_CREATE_DT BETWEEN ? AND ? )";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getAddressLightImagesParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.addressIdPK=ADDRESS_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.histCreateDt=H_CREATE_DT"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getAddressLightImagesResults =
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.addressIdPK=ADDRESS_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressExt.XAddressVerificationDate=XADDR_VERIFICATION_DT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressExt.XSubcity=XSUBCITY_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressExt.XDistrict=XDISTRICT_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressExt.XBuildingName=XBUILDING_NAME," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressExt.XStreetNumber=XSTREET_NUMBER," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressExt.XStreetName=XSTREET_NAME," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressExt.XSuburb=XSuburb"; 


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getAddressHistorySQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getAddressHistoryParameters, results=getAddressHistoryResults)
  		Iterator<ResultQueue2<EObjAddress, EObjXAddressExt>> getAddressHistory(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getAddressSQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getAddressParameters, results=getAddressResults)
  		Iterator<ResultQueue2<EObjAddress, EObjXAddressExt>> getAddress(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getAddressGroupMicroSQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getAddressGroupMicroParameters, results=getAddressGroupMicroResults)
  		Iterator<ResultQueue2<EObjAddress, EObjXAddressExt>> getAddressGroupMicro(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getAddressLightImagesSQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getAddressLightImagesParameters, results=getAddressLightImagesResults)
  		Iterator<ResultQueue2<EObjAddress, EObjXAddressExt>> getAddressLightImages(Object[] parameters);
 
}


