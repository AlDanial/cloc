/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[9283f917d4095094e1847f0f0b3c0e74]
 */

package com.ibm.daimler.dsea.entityObject;


import com.ibm.mdm.base.db.ResultQueue1;
import java.util.Iterator;
import com.ibm.mdm.base.db.EntityMapping;
import com.ibm.pdq.annotation.Select;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * @generated
 */
public interface XVehicleJPNInquiryData {
  
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String tableAliasString = "tableAlias (" + 
                                            "XVEHICLEJPN => com.ibm.daimler.dsea.entityObject.EObjXVehicleJPN, " +
                                            "H_XVEHICLEJPN => com.ibm.daimler.dsea.entityObject.EObjXVehicleJPN" +
                                            ")";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getXVehicleJPNSql = "SELECT r.XVehicle_JPNPK_ID XVehicle_JPNPK_ID, r.GLOBAL_VIN GLOBAL_VIN, r.BAU_MUSTER BAU_MUSTER, r.TYPE_ClASS TYPE_ClASS, r.SUB_MUSTER SUB_MUSTER, r.COLOR COLOR, r.TRIM TRIM, r.BATCH_IND BATCH_IND, r.MARKET_NAME MARKET_NAME, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.CREATE_DT CREATE_DT, r.CHANGED_DT CHANGED_DT, r.LAST_SERVICE_DT LAST_SERVICE_DT, r.SFDC_ID SFDC_ID, r.VEHICLE_ADDRESS_TYPE VEHICLE_ADDRESS_TYPE, r.VEHICLE_TYPE VEHICLE_TYPE, r.DELETE_FLAG DELETE_FLAG, r.END_DT END_DT, r.ENGINE_NUM ENGINE_NUM, r.MYCAR_ID MYCAR_ID, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XVEHICLEJPN r WHERE r.XVehicle_JPNPK_ID = ? ";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXVehicleJPNParameters =
    "EObjXVehicleJPN.XVehicleJPNpkId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXVehicleJPNResults =
    "EObjXVehicleJPN.XVehicleJPNpkId," +
    "EObjXVehicleJPN.GlobalVIN," +
    "EObjXVehicleJPN.BauMuster," +
    "EObjXVehicleJPN.TypeClass," +
    "EObjXVehicleJPN.SubMuster," +
    "EObjXVehicleJPN.Color," +
    "EObjXVehicleJPN.Trim," +
    "EObjXVehicleJPN.BatchInd," +
    "EObjXVehicleJPN.MarketName," +
    "EObjXVehicleJPN.SourceIdentifier," +
    "EObjXVehicleJPN.LastModifiedSystemDate," +
    "EObjXVehicleJPN.CreateDate," +
    "EObjXVehicleJPN.ChangedDate," +
    "EObjXVehicleJPN.LastServiceDate," +
    "EObjXVehicleJPN.SFDCId," +
    "EObjXVehicleJPN.VehicleAddressType," +
    "EObjXVehicleJPN.VehicleType," +
    "EObjXVehicleJPN.DeleteFlag," +
    "EObjXVehicleJPN.EndDate," +
    "EObjXVehicleJPN.EngineNumber," +
    "EObjXVehicleJPN.MyCarId," +
    "EObjXVehicleJPN.lastUpdateDt," +
    "EObjXVehicleJPN.lastUpdateUser," +
    "EObjXVehicleJPN.lastUpdateTxId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getXVehicleJPNHistorySql = "SELECT r.H_XVehicle_JPNPK_ID hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.XVehicle_JPNPK_ID XVehicle_JPNPK_ID, r.GLOBAL_VIN GLOBAL_VIN, r.BAU_MUSTER BAU_MUSTER, r.TYPE_ClASS TYPE_ClASS, r.SUB_MUSTER SUB_MUSTER, r.COLOR COLOR, r.TRIM TRIM, r.BATCH_IND BATCH_IND, r.MARKET_NAME MARKET_NAME, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.CREATE_DT CREATE_DT, r.CHANGED_DT CHANGED_DT, r.LAST_SERVICE_DT LAST_SERVICE_DT, r.SFDC_ID SFDC_ID, r.VEHICLE_ADDRESS_TYPE VEHICLE_ADDRESS_TYPE, r.VEHICLE_TYPE VEHICLE_TYPE, r.DELETE_FLAG DELETE_FLAG, r.END_DT END_DT, r.ENGINE_NUM ENGINE_NUM, r.MYCAR_ID MYCAR_ID, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XVEHICLEJPN r WHERE r.H_XVehicle_JPNPK_ID = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXVehicleJPNHistoryParameters =
    "EObjXVehicleJPN.XVehicleJPNpkId," +
    "EObjXVehicleJPN.lastUpdateDt," +
    "EObjXVehicleJPN.lastUpdateDt";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXVehicleJPNHistoryResults =
    "EObjXVehicleJPN.historyIdPK," +
    "EObjXVehicleJPN.histActionCode," +
    "EObjXVehicleJPN.histCreatedBy," +
    "EObjXVehicleJPN.histCreateDt," +
    "EObjXVehicleJPN.histEndDt," +
    "EObjXVehicleJPN.XVehicleJPNpkId," +
    "EObjXVehicleJPN.GlobalVIN," +
    "EObjXVehicleJPN.BauMuster," +
    "EObjXVehicleJPN.TypeClass," +
    "EObjXVehicleJPN.SubMuster," +
    "EObjXVehicleJPN.Color," +
    "EObjXVehicleJPN.Trim," +
    "EObjXVehicleJPN.BatchInd," +
    "EObjXVehicleJPN.MarketName," +
    "EObjXVehicleJPN.SourceIdentifier," +
    "EObjXVehicleJPN.LastModifiedSystemDate," +
    "EObjXVehicleJPN.CreateDate," +
    "EObjXVehicleJPN.ChangedDate," +
    "EObjXVehicleJPN.LastServiceDate," +
    "EObjXVehicleJPN.SFDCId," +
    "EObjXVehicleJPN.VehicleAddressType," +
    "EObjXVehicleJPN.VehicleType," +
    "EObjXVehicleJPN.DeleteFlag," +
    "EObjXVehicleJPN.EndDate," +
    "EObjXVehicleJPN.EngineNumber," +
    "EObjXVehicleJPN.MyCarId," +
    "EObjXVehicleJPN.lastUpdateDt," +
    "EObjXVehicleJPN.lastUpdateUser," +
    "EObjXVehicleJPN.lastUpdateTxId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getXVehicleJPNByGlobalVINSql = "SELECT r.XVehicle_JPNPK_ID XVehicle_JPNPK_ID, r.GLOBAL_VIN GLOBAL_VIN, r.BAU_MUSTER BAU_MUSTER, r.TYPE_ClASS TYPE_ClASS, r.SUB_MUSTER SUB_MUSTER, r.COLOR COLOR, r.TRIM TRIM, r.BATCH_IND BATCH_IND, r.MARKET_NAME MARKET_NAME, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.CREATE_DT CREATE_DT, r.CHANGED_DT CHANGED_DT, r.LAST_SERVICE_DT LAST_SERVICE_DT, r.SFDC_ID SFDC_ID, r.VEHICLE_ADDRESS_TYPE VEHICLE_ADDRESS_TYPE, r.VEHICLE_TYPE VEHICLE_TYPE, r.DELETE_FLAG DELETE_FLAG, r.END_DT END_DT, r.ENGINE_NUM ENGINE_NUM, r.MYCAR_ID MYCAR_ID, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XVEHICLEJPN r WHERE r.GLOBAL_VIN = ? ";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXVehicleJPNByGlobalVINParameters =
    "EObjXVehicleJPN.GlobalVIN";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXVehicleJPNByGlobalVINResults =
    "EObjXVehicleJPN.XVehicleJPNpkId," +
    "EObjXVehicleJPN.GlobalVIN," +
    "EObjXVehicleJPN.BauMuster," +
    "EObjXVehicleJPN.TypeClass," +
    "EObjXVehicleJPN.SubMuster," +
    "EObjXVehicleJPN.Color," +
    "EObjXVehicleJPN.Trim," +
    "EObjXVehicleJPN.BatchInd," +
    "EObjXVehicleJPN.MarketName," +
    "EObjXVehicleJPN.SourceIdentifier," +
    "EObjXVehicleJPN.LastModifiedSystemDate," +
    "EObjXVehicleJPN.CreateDate," +
    "EObjXVehicleJPN.ChangedDate," +
    "EObjXVehicleJPN.LastServiceDate," +
    "EObjXVehicleJPN.SFDCId," +
    "EObjXVehicleJPN.VehicleAddressType," +
    "EObjXVehicleJPN.VehicleType," +
    "EObjXVehicleJPN.DeleteFlag," +
    "EObjXVehicleJPN.EndDate," +
    "EObjXVehicleJPN.EngineNumber," +
    "EObjXVehicleJPN.MyCarId," +
    "EObjXVehicleJPN.lastUpdateDt," +
    "EObjXVehicleJPN.lastUpdateUser," +
    "EObjXVehicleJPN.lastUpdateTxId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getXVehicleJPNByGlobalVINHistorySql = "SELECT r.H_XVehicle_JPNPK_ID hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.XVehicle_JPNPK_ID XVehicle_JPNPK_ID, r.GLOBAL_VIN GLOBAL_VIN, r.BAU_MUSTER BAU_MUSTER, r.TYPE_ClASS TYPE_ClASS, r.SUB_MUSTER SUB_MUSTER, r.COLOR COLOR, r.TRIM TRIM, r.BATCH_IND BATCH_IND, r.MARKET_NAME MARKET_NAME, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.CREATE_DT CREATE_DT, r.CHANGED_DT CHANGED_DT, r.LAST_SERVICE_DT LAST_SERVICE_DT, r.SFDC_ID SFDC_ID, r.VEHICLE_ADDRESS_TYPE VEHICLE_ADDRESS_TYPE, r.VEHICLE_TYPE VEHICLE_TYPE, r.DELETE_FLAG DELETE_FLAG, r.END_DT END_DT, r.ENGINE_NUM ENGINE_NUM, r.MYCAR_ID MYCAR_ID, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XVEHICLEJPN r WHERE r.GLOBAL_VIN = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXVehicleJPNByGlobalVINHistoryParameters =
    "EObjXVehicleJPN.GlobalVIN," +
    "EObjXVehicleJPN.lastUpdateDt," +
    "EObjXVehicleJPN.lastUpdateDt";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXVehicleJPNByGlobalVINHistoryResults =
    "EObjXVehicleJPN.historyIdPK," +
    "EObjXVehicleJPN.histActionCode," +
    "EObjXVehicleJPN.histCreatedBy," +
    "EObjXVehicleJPN.histCreateDt," +
    "EObjXVehicleJPN.histEndDt," +
    "EObjXVehicleJPN.XVehicleJPNpkId," +
    "EObjXVehicleJPN.GlobalVIN," +
    "EObjXVehicleJPN.BauMuster," +
    "EObjXVehicleJPN.TypeClass," +
    "EObjXVehicleJPN.SubMuster," +
    "EObjXVehicleJPN.Color," +
    "EObjXVehicleJPN.Trim," +
    "EObjXVehicleJPN.BatchInd," +
    "EObjXVehicleJPN.MarketName," +
    "EObjXVehicleJPN.SourceIdentifier," +
    "EObjXVehicleJPN.LastModifiedSystemDate," +
    "EObjXVehicleJPN.CreateDate," +
    "EObjXVehicleJPN.ChangedDate," +
    "EObjXVehicleJPN.LastServiceDate," +
    "EObjXVehicleJPN.SFDCId," +
    "EObjXVehicleJPN.VehicleAddressType," +
    "EObjXVehicleJPN.VehicleType," +
    "EObjXVehicleJPN.DeleteFlag," +
    "EObjXVehicleJPN.EndDate," +
    "EObjXVehicleJPN.EngineNumber," +
    "EObjXVehicleJPN.MyCarId," +
    "EObjXVehicleJPN.lastUpdateDt," +
    "EObjXVehicleJPN.lastUpdateUser," +
    "EObjXVehicleJPN.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getXVehicleJPNSql, pattern=tableAliasString)
  @EntityMapping(parameters=getXVehicleJPNParameters, results=getXVehicleJPNResults)
  Iterator<ResultQueue1<EObjXVehicleJPN>> getXVehicleJPN(Object[] parameters);  


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getXVehicleJPNHistorySql, pattern=tableAliasString)
  @EntityMapping(parameters=getXVehicleJPNHistoryParameters, results=getXVehicleJPNHistoryResults)
  Iterator<ResultQueue1<EObjXVehicleJPN>> getXVehicleJPNHistory(Object[] parameters);  


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getXVehicleJPNByGlobalVINSql, pattern=tableAliasString)
  @EntityMapping(parameters=getXVehicleJPNByGlobalVINParameters, results=getXVehicleJPNByGlobalVINResults)
  Iterator<ResultQueue1<EObjXVehicleJPN>> getXVehicleJPNByGlobalVIN(Object[] parameters);  


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getXVehicleJPNByGlobalVINHistorySql, pattern=tableAliasString)
  @EntityMapping(parameters=getXVehicleJPNByGlobalVINHistoryParameters, results=getXVehicleJPNByGlobalVINHistoryResults)
  Iterator<ResultQueue1<EObjXVehicleJPN>> getXVehicleJPNByGlobalVINHistory(Object[] parameters);  


}


