/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[728ef6e06fc1f1a5cc74ff2669fc184d]
 */


package com.ibm.daimler.dsea.entityObject;

import java.util.Iterator;
import com.ibm.mdm.base.db.EntityMapping;
import com.ibm.pdq.annotation.Select;
import com.ibm.pdq.annotation.Update;

import com.dwl.tcrm.coreParty.entityObject.EObjAddress;

import com.ibm.daimler.dsea.entityObject.EObjXAddressExt;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * @generated
 */
public interface EObjXAddressExtData {


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjXAddressExtSql = "select XADDR_VERIFICATION_DT, XSUBCITY_TP_CD, XDISTRICT_TP_CD, XBUILDING_NAME, XSTREET_NUMBER, XSTREET_NAME, XSuburb, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from ADDRESS where ADDRESS_ID = ? ";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String createEObjXAddressExtSql = "insert into ADDRESS (POSTAL_BARCODE, ADDR_LINE_ONE, ADDR_LINE_THREE, ADDR_LINE_TWO, CITY_NAME, COUNTY_CODE, LATITUDE_DEGREES, LONGITUDE_DEGREES, RESIDENCE_NUM, ADDR_STANDARD_IND, OVERRIDE_IND, POSTAL_CODE, ADDRESS_ID, BOX_ID, BUILDING_NAME, STREET_NUMBER, STREET_NAME, STREET_SUFFIX, PRE_DIRECTIONAL, POST_DIRECTIONAL, BOX_DESIGNATOR, STN_INFO, STN_ID, REGION, DEL_DESIGNATOR, DEL_ID, DEL_INFO, COUNTRY_TP_CD, PROV_STATE_TP_CD, RESIDENCE_TP_CD, P_CITY, P_STREET_NAME, STREET_PREFIX, P_ADDR_LINE_ONE, P_ADDR_LINE_THREE, P_ADDR_LINE_TWO, XADDR_VERIFICATION_DT, XSUBCITY_TP_CD, XDISTRICT_TP_CD, XBUILDING_NAME, XSTREET_NUMBER, XSTREET_NAME, XSuburb, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( ?1.postalBarCode, ?1.addrLineOne, ?1.addrLineThree, ?1.addrLineTwo, ?1.cityName, ?1.countyCode, ?1.latitudeDegrees, ?1.longtitudeDegrees, ?1.residenceNum, ?1.addrStandardInd, ?1.overrideInd, ?1.postalCode, ?1.addressIdPK, ?1.boxId, ?1.buildingName, ?1.streetNumber, ?1.streetName, ?1.streetSuffix, ?1.preDirectional, ?1.postDirectional, ?1.boxDesignator, ?1.stnInfo, ?1.stnId, ?1.region, ?1.delDesignator, ?1.delId, ?1.delInfo, ?1.countryTpCd, ?1.provStateTpCd, ?1.residenceTpCd, ?1.pCityName, ?1.pStreetName, ?1.streetPrefix, ?1.pAddrLineOne, ?1.pAddrLineThree, ?1.pAddrLineTwo, ?2.xAddressVerificationDate, ?2.xSubcity, ?2.xDistrict, ?2.xBuildingName, ?2.xStreetNumber, ?2.xStreetName, ?2.xSuburb, ?1.lastUpdateDt, ?1.lastUpdateUser, ?1.lastUpdateTxId)";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String updateEObjXAddressExtSql = "update ADDRESS set POSTAL_BARCODE = ?1.postalBarCode, ADDR_LINE_ONE = ?1.addrLineOne, ADDR_LINE_THREE = ?1.addrLineThree, ADDR_LINE_TWO = ?1.addrLineTwo, CITY_NAME = ?1.cityName, COUNTY_CODE = ?1.countyCode, LATITUDE_DEGREES = ?1.latitudeDegrees, LONGITUDE_DEGREES = ?1.longtitudeDegrees, RESIDENCE_NUM = ?1.residenceNum, ADDR_STANDARD_IND = ?1.addrStandardInd, OVERRIDE_IND = ?1.overrideInd, POSTAL_CODE = ?1.postalCode, BOX_ID = ?1.boxId, BUILDING_NAME = ?1.buildingName, STREET_NUMBER = ?1.streetNumber, STREET_NAME = ?1.streetName, STREET_SUFFIX = ?1.streetSuffix, PRE_DIRECTIONAL = ?1.preDirectional, POST_DIRECTIONAL = ?1.postDirectional, BOX_DESIGNATOR = ?1.boxDesignator, STN_INFO = ?1.stnInfo, STN_ID = ?1.stnId, REGION = ?1.region, DEL_DESIGNATOR = ?1.delDesignator, DEL_ID = ?1.delId, DEL_INFO = ?1.delInfo, COUNTRY_TP_CD = ?1.countryTpCd, PROV_STATE_TP_CD = ?1.provStateTpCd, RESIDENCE_TP_CD = ?1.residenceTpCd, P_CITY = ?1.pCityName, P_STREET_NAME = ?1.pStreetName, STREET_PREFIX = ?1.streetPrefix, P_ADDR_LINE_ONE = ?1.pAddrLineOne, P_ADDR_LINE_THREE = ?1.pAddrLineThree, P_ADDR_LINE_TWO = ?1.pAddrLineTwo, XADDR_VERIFICATION_DT = ?2.xAddressVerificationDate, XSUBCITY_TP_CD = ?2.xSubcity, XDISTRICT_TP_CD = ?2.xDistrict, XBUILDING_NAME = ?2.xBuildingName, XSTREET_NUMBER = ?2.xStreetNumber, XSTREET_NAME = ?2.xStreetName, XSuburb = ?2.xSuburb, LAST_UPDATE_DT = ?1.lastUpdateDt, LAST_UPDATE_USER = ?1.lastUpdateUser, LAST_UPDATE_TX_ID = ?1.lastUpdateTxId where ADDRESS_ID = ?1.addressIdPK and LAST_UPDATE_DT = ?1.oldLastUpdateDt";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String deleteEObjXAddressExtSql = "delete from ADDRESS where ADDRESS_ID = ?";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXAddressExtKeyField = "EObjXAddressExt.addressIdPK";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXAddressExtGetFields =
    "EObjXAddressExt.xAddressVerificationDate," +
    "EObjXAddressExt.xSubcity," +
    "EObjXAddressExt.xDistrict," +
    "EObjXAddressExt.xBuildingName," +
    "EObjXAddressExt.xStreetNumber," +
    "EObjXAddressExt.xStreetName," +
    "EObjXAddressExt.xSuburb," +
    "EObjXAddressExt.lastUpdateDt," +
    "EObjXAddressExt.lastUpdateUser," +
    "EObjXAddressExt.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXAddressExtAllFields =
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.postalBarCode," +
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.addrLineOne," +
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.addrLineThree," +
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.addrLineTwo," +
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.cityName," +
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.countyCode," +
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.latitudeDegrees," +
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.longtitudeDegrees," +
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.residenceNum," +
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.addrStandardInd," +
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.overrideInd," +
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.postalCode," +
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.addressIdPK," +
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.boxId," +
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.buildingName," +
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.streetNumber," +
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.streetName," +
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.streetSuffix," +
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.preDirectional," +
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.postDirectional," +
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.boxDesignator," +
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.stnInfo," +
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.stnId," +
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.region," +
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.delDesignator," +
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.delId," +
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.delInfo," +
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.countryTpCd," +
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.provStateTpCd," +
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.residenceTpCd," +
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.pCityName," +
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.pStreetName," +
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.streetPrefix," +
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.pAddrLineOne," +
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.pAddrLineThree," +
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.pAddrLineTwo," +
    "com.ibm.daimler.dsea.entityObject.EObjXAddressExt.xAddressVerificationDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXAddressExt.xSubcity," +
    "com.ibm.daimler.dsea.entityObject.EObjXAddressExt.xDistrict," +
    "com.ibm.daimler.dsea.entityObject.EObjXAddressExt.xBuildingName," +
    "com.ibm.daimler.dsea.entityObject.EObjXAddressExt.xStreetNumber," +
    "com.ibm.daimler.dsea.entityObject.EObjXAddressExt.xStreetName," +
    "com.ibm.daimler.dsea.entityObject.EObjXAddressExt.xSuburb," +
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.lastUpdateDt," +
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.lastUpdateUser," +
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXAddressExtUpdateFields =
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.postalBarCode," +
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.addrLineOne," +
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.addrLineThree," +
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.addrLineTwo," +
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.cityName," +
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.countyCode," +
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.latitudeDegrees," +
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.longtitudeDegrees," +
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.residenceNum," +
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.addrStandardInd," +
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.overrideInd," +
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.postalCode," +
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.boxId," +
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.buildingName," +
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.streetNumber," +
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.streetName," +
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.streetSuffix," +
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.preDirectional," +
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.postDirectional," +
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.boxDesignator," +
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.stnInfo," +
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.stnId," +
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.region," +
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.delDesignator," +
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.delId," +
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.delInfo," +
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.countryTpCd," +
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.provStateTpCd," +
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.residenceTpCd," +
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.pCityName," +
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.pStreetName," +
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.streetPrefix," +
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.pAddrLineOne," +
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.pAddrLineThree," +
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.pAddrLineTwo," +
    "com.ibm.daimler.dsea.entityObject.EObjXAddressExt.xAddressVerificationDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXAddressExt.xSubcity," +
    "com.ibm.daimler.dsea.entityObject.EObjXAddressExt.xDistrict," +
    "com.ibm.daimler.dsea.entityObject.EObjXAddressExt.xBuildingName," +
    "com.ibm.daimler.dsea.entityObject.EObjXAddressExt.xStreetNumber," +
    "com.ibm.daimler.dsea.entityObject.EObjXAddressExt.xStreetName," +
    "com.ibm.daimler.dsea.entityObject.EObjXAddressExt.xSuburb," +
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.lastUpdateDt," +
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.lastUpdateUser," +
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.lastUpdateTxId," +
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.addressIdPK," +
    "com.dwl.tcrm.coreParty.entityObject.EObjAddress.oldLastUpdateDt";   

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Select XAddress by parameters.
   * @generated
   */
  @Select(sql=getEObjXAddressExtSql)
  @EntityMapping(parameters=EObjXAddressExtKeyField, results=EObjXAddressExtGetFields)
  Iterator<EObjXAddressExt> getEObjXAddressExt(Long addressIdPK);  
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Create XAddress by EObjXAddressExt Object.
   * @generated
   */
  @Update(sql=createEObjXAddressExtSql)
  @EntityMapping(parameters=EObjXAddressExtAllFields)
    int createEObjXAddressExt(EObjAddress e1, EObjXAddressExt e2); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Update one XAddress by EObjXAddressExt object.
   * @generated
   */
  @Update(sql=updateEObjXAddressExtSql)
  @EntityMapping(parameters=EObjXAddressExtUpdateFields)
    int updateEObjXAddressExt(EObjAddress e1, EObjXAddressExt e2); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Delete XAddress by parameters.
   * @generated
   */
  @Update(sql=deleteEObjXAddressExtSql)
  @EntityMapping(parameters=EObjXAddressExtKeyField)
  int deleteEObjXAddressExt(Long addressIdPK);

}

