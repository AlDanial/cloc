package com.ibm.daimler.dsea.entityObject;

import com.ibm.pdq.runtime.generator.BaseParameterHandler;
import java.util.Iterator;
import com.ibm.mdm.base.db.ResultQueue1;
import java.sql.PreparedStatement;
import com.ibm.pdq.runtime.statement.StatementDescriptor;
import com.ibm.pdq.runtime.generator.BaseData;
import java.sql.SQLException;
import com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleJPN;
import com.ibm.pdq.annotation.Metadata;
import com.ibm.pdq.runtime.generator.BaseRowHandler;
import com.ibm.pdq.runtime.statement.SqlStatementType;
import java.sql.Types;


@SuppressWarnings("unchecked")

/**
 * <!-- begin-user-doc -->
 * 
 * <!-- end-user-doc -->
 * 
 * @generated
 */
public class XCustomerVehicleJPNInquiryDataImpl  extends BaseData implements XCustomerVehicleJPNInquiryData
{

  /**
   * @generated
   */
  public static final String generatorVersion = "3.200.75";

  /**
   * @generated
   */
  public static final String identifier = "XCustomerVehicleJPNInquiryData";

  /**
   * @generated
   */
  public static final long generationTime = 0x00000164c6aca646L;

  /**
   * @generated
   */
  public static final String collection = "NULLID";

  /**
   * @generated
   */
  public static final String packageVersion = null;

  /**
   * @generated
   */
  public static final boolean forceSingleBindIsolation = false;

  /**
   * @generated
   */
  public XCustomerVehicleJPNInquiryDataImpl()
  {
    super();
  } 

  /**
   * @generated
   */
  public String getGeneratorVersion()
  {
    return generatorVersion;
  }

  /**
   * @Select( sql="SELECT r.XCustomer_Vehicle_JPNPK_ID XCustomer_Vehicle_JPNPK_ID, r.CONT_ID CONT_ID, r.VEHICLE_ID VEHICLE_ID, r.RETAILER_ID RETAILER_ID, r.CONNECTME_USAGE_TP_CD CONNECTME_USAGE_TP_CD, r.LICENSE_PLATE LICENSE_PLATE, r.VEHICLE_SALES_TP_CD VEHICLE_SALES_TP_CD, r.VEHICLE_USAGE_TP_CD VEHICLE_USAGE_TP_CD, r.VEHICLE_OWNERSHIP VEHICLE_OWNERSHIP, r.START_DT START_DT, r.END_DT END_DT, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.CUSTVEHRET_FLAG CUSTVEHRET_FLAG, r.DELETE_FLAG DELETE_FLAG, r.SFDC_ID SFDC_ID, r.SERVICE_NAME SERVICE_NAME, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XCUSTOMERVEHICLEJPN r WHERE r.XCustomer_Vehicle_JPNPK_ID = ? ", pattern="tableAlias (XCUSTOMERVEHICLEJPN => com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleJPN, H_XCUSTOMERVEHICLEJPN => com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleJPN)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue1<EObjXCustomerVehicleJPN>> getXCustomerVehicleJPN (Object[] parameters)
  {
    return queryIterator (getXCustomerVehicleJPNStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getXCustomerVehicleJPNStatementDescriptor = createStatementDescriptor (
    "getXCustomerVehicleJPN(Object[])",
    "SELECT r.XCustomer_Vehicle_JPNPK_ID XCustomer_Vehicle_JPNPK_ID, r.CONT_ID CONT_ID, r.VEHICLE_ID VEHICLE_ID, r.RETAILER_ID RETAILER_ID, r.CONNECTME_USAGE_TP_CD CONNECTME_USAGE_TP_CD, r.LICENSE_PLATE LICENSE_PLATE, r.VEHICLE_SALES_TP_CD VEHICLE_SALES_TP_CD, r.VEHICLE_USAGE_TP_CD VEHICLE_USAGE_TP_CD, r.VEHICLE_OWNERSHIP VEHICLE_OWNERSHIP, r.START_DT START_DT, r.END_DT END_DT, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.CUSTVEHRET_FLAG CUSTVEHRET_FLAG, r.DELETE_FLAG DELETE_FLAG, r.SFDC_ID SFDC_ID, r.SERVICE_NAME SERVICE_NAME, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XCUSTOMERVEHICLEJPN r WHERE r.XCustomer_Vehicle_JPNPK_ID = ? ",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"xcustomer_vehicle_jpnpk_id", "cont_id", "vehicle_id", "retailer_id", "connectme_usage_tp_cd", "license_plate", "vehicle_sales_tp_cd", "vehicle_usage_tp_cd", "vehicle_ownership", "start_dt", "end_dt", "source_ident_tp_cd", "custvehret_flag", "delete_flag", "sfdc_id", "service_name", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetXCustomerVehicleJPNParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetXCustomerVehicleJPNRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 19, 19, 19, 19, 20, 19, 19, 250, 0, 0, 19, 5, 10, 50, 120, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    1);

  /**
   * @generated
   */
  public static class GetXCustomerVehicleJPNParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetXCustomerVehicleJPNRowHandler extends BaseRowHandler<ResultQueue1<EObjXCustomerVehicleJPN>>
  {
    /**
     * @generated
     */
    public ResultQueue1<EObjXCustomerVehicleJPN> handle (java.sql.ResultSet rs, ResultQueue1<EObjXCustomerVehicleJPN> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue1<EObjXCustomerVehicleJPN> ();

      EObjXCustomerVehicleJPN returnObject1 = new EObjXCustomerVehicleJPN ();
      returnObject1.setXCustomerVehicleJPNpkId(getLongObject (rs, 1)); 
      returnObject1.setContId(getLongObject (rs, 2)); 
      returnObject1.setVehicleId(getLongObject (rs, 3)); 
      returnObject1.setRetailerId(getLongObject (rs, 4)); 
      returnObject1.setConnectMeUsage(getLongObject (rs, 5)); 
      returnObject1.setLicensePlate(getString (rs, 6)); 
      returnObject1.setVehicleSales(getLongObject (rs, 7)); 
      returnObject1.setVehicleUsage(getLongObject (rs, 8)); 
      returnObject1.setVehicleOwnerShip(getString (rs, 9)); 
      returnObject1.setStartDate(getTimestamp (rs, 10)); 
      returnObject1.setEndDate(getTimestamp (rs, 11)); 
      returnObject1.setSourceIdentifier(getLongObject (rs, 12)); 
      returnObject1.setCustVehRetFlag(getString (rs, 13)); 
      returnObject1.setDeleteFlag(getString (rs, 14)); 
      returnObject1.setSFDCId(getString (rs, 15)); 
      returnObject1.setServiceName(getString (rs, 16)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 17)); 
      returnObject1.setLastUpdateUser(getString (rs, 18)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 19)); 
      returnObject.add (returnObject1);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT r.H_XCustomer_Vehicle_JPNPK_ID hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.XCustomer_Vehicle_JPNPK_ID XCustomer_Vehicle_JPNPK_ID, r.CONT_ID CONT_ID, r.VEHICLE_ID VEHICLE_ID, r.RETAILER_ID RETAILER_ID, r.CONNECTME_USAGE_TP_CD CONNECTME_USAGE_TP_CD, r.LICENSE_PLATE LICENSE_PLATE, r.VEHICLE_SALES_TP_CD VEHICLE_SALES_TP_CD, r.VEHICLE_USAGE_TP_CD VEHICLE_USAGE_TP_CD, r.VEHICLE_OWNERSHIP VEHICLE_OWNERSHIP, r.START_DT START_DT, r.END_DT END_DT, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.CUSTVEHRET_FLAG CUSTVEHRET_FLAG, r.DELETE_FLAG DELETE_FLAG, r.SFDC_ID SFDC_ID, r.SERVICE_NAME SERVICE_NAME, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XCUSTOMERVEHICLEJPN r WHERE r.H_XCustomer_Vehicle_JPNPK_ID = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))", pattern="tableAlias (XCUSTOMERVEHICLEJPN => com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleJPN, H_XCUSTOMERVEHICLEJPN => com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleJPN)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue1<EObjXCustomerVehicleJPN>> getXCustomerVehicleJPNHistory (Object[] parameters)
  {
    return queryIterator (getXCustomerVehicleJPNHistoryStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getXCustomerVehicleJPNHistoryStatementDescriptor = createStatementDescriptor (
    "getXCustomerVehicleJPNHistory(Object[])",
    "SELECT r.H_XCustomer_Vehicle_JPNPK_ID hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.XCustomer_Vehicle_JPNPK_ID XCustomer_Vehicle_JPNPK_ID, r.CONT_ID CONT_ID, r.VEHICLE_ID VEHICLE_ID, r.RETAILER_ID RETAILER_ID, r.CONNECTME_USAGE_TP_CD CONNECTME_USAGE_TP_CD, r.LICENSE_PLATE LICENSE_PLATE, r.VEHICLE_SALES_TP_CD VEHICLE_SALES_TP_CD, r.VEHICLE_USAGE_TP_CD VEHICLE_USAGE_TP_CD, r.VEHICLE_OWNERSHIP VEHICLE_OWNERSHIP, r.START_DT START_DT, r.END_DT END_DT, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.CUSTVEHRET_FLAG CUSTVEHRET_FLAG, r.DELETE_FLAG DELETE_FLAG, r.SFDC_ID SFDC_ID, r.SERVICE_NAME SERVICE_NAME, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XCUSTOMERVEHICLEJPN r WHERE r.H_XCustomer_Vehicle_JPNPK_ID = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"historyidpk", "h_action_code", "h_created_by", "h_create_dt", "h_end_dt", "xcustomer_vehicle_jpnpk_id", "cont_id", "vehicle_id", "retailer_id", "connectme_usage_tp_cd", "license_plate", "vehicle_sales_tp_cd", "vehicle_usage_tp_cd", "vehicle_ownership", "start_dt", "end_dt", "source_ident_tp_cd", "custvehret_flag", "delete_flag", "sfdc_id", "service_name", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetXCustomerVehicleJPNHistoryParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP}, {19, 0, 0}, {0, 0, 0}, {1, 1, 1}},
    null,
    new GetXCustomerVehicleJPNHistoryRowHandler (),
    new int[][]{ {Types.BIGINT, Types.CHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 1, 20, 0, 0, 19, 19, 19, 19, 19, 20, 19, 19, 250, 0, 0, 19, 5, 10, 50, 120, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    2);

  /**
   * @generated
   */
  public static class GetXCustomerVehicleJPNHistoryParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetXCustomerVehicleJPNHistoryRowHandler extends BaseRowHandler<ResultQueue1<EObjXCustomerVehicleJPN>>
  {
    /**
     * @generated
     */
    public ResultQueue1<EObjXCustomerVehicleJPN> handle (java.sql.ResultSet rs, ResultQueue1<EObjXCustomerVehicleJPN> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue1<EObjXCustomerVehicleJPN> ();

      EObjXCustomerVehicleJPN returnObject1 = new EObjXCustomerVehicleJPN ();
      returnObject1.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject1.setHistActionCode(getString (rs, 2)); 
      returnObject1.setHistCreatedBy(getString (rs, 3)); 
      returnObject1.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject1.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject1.setXCustomerVehicleJPNpkId(getLongObject (rs, 6)); 
      returnObject1.setContId(getLongObject (rs, 7)); 
      returnObject1.setVehicleId(getLongObject (rs, 8)); 
      returnObject1.setRetailerId(getLongObject (rs, 9)); 
      returnObject1.setConnectMeUsage(getLongObject (rs, 10)); 
      returnObject1.setLicensePlate(getString (rs, 11)); 
      returnObject1.setVehicleSales(getLongObject (rs, 12)); 
      returnObject1.setVehicleUsage(getLongObject (rs, 13)); 
      returnObject1.setVehicleOwnerShip(getString (rs, 14)); 
      returnObject1.setStartDate(getTimestamp (rs, 15)); 
      returnObject1.setEndDate(getTimestamp (rs, 16)); 
      returnObject1.setSourceIdentifier(getLongObject (rs, 17)); 
      returnObject1.setCustVehRetFlag(getString (rs, 18)); 
      returnObject1.setDeleteFlag(getString (rs, 19)); 
      returnObject1.setSFDCId(getString (rs, 20)); 
      returnObject1.setServiceName(getString (rs, 21)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 22)); 
      returnObject1.setLastUpdateUser(getString (rs, 23)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 24)); 
      returnObject.add (returnObject1);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT r.XCustomer_Vehicle_JPNPK_ID XCustomer_Vehicle_JPNPK_ID, r.CONT_ID CONT_ID, r.VEHICLE_ID VEHICLE_ID, r.RETAILER_ID RETAILER_ID, r.CONNECTME_USAGE_TP_CD CONNECTME_USAGE_TP_CD, r.LICENSE_PLATE LICENSE_PLATE, r.VEHICLE_SALES_TP_CD VEHICLE_SALES_TP_CD, r.VEHICLE_USAGE_TP_CD VEHICLE_USAGE_TP_CD, r.VEHICLE_OWNERSHIP VEHICLE_OWNERSHIP, r.START_DT START_DT, r.END_DT END_DT, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.CUSTVEHRET_FLAG CUSTVEHRET_FLAG, r.DELETE_FLAG DELETE_FLAG, r.SFDC_ID SFDC_ID, r.SERVICE_NAME SERVICE_NAME, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XCUSTOMERVEHICLEJPN r WHERE r.CONT_ID = ? ", pattern="tableAlias (XCUSTOMERVEHICLEJPN => com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleJPN, H_XCUSTOMERVEHICLEJPN => com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleJPN)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue1<EObjXCustomerVehicleJPN>> getAllXCustomerVehicleJPNByPartyId (Object[] parameters)
  {
    return queryIterator (getAllXCustomerVehicleJPNByPartyIdStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getAllXCustomerVehicleJPNByPartyIdStatementDescriptor = createStatementDescriptor (
    "getAllXCustomerVehicleJPNByPartyId(Object[])",
    "SELECT r.XCustomer_Vehicle_JPNPK_ID XCustomer_Vehicle_JPNPK_ID, r.CONT_ID CONT_ID, r.VEHICLE_ID VEHICLE_ID, r.RETAILER_ID RETAILER_ID, r.CONNECTME_USAGE_TP_CD CONNECTME_USAGE_TP_CD, r.LICENSE_PLATE LICENSE_PLATE, r.VEHICLE_SALES_TP_CD VEHICLE_SALES_TP_CD, r.VEHICLE_USAGE_TP_CD VEHICLE_USAGE_TP_CD, r.VEHICLE_OWNERSHIP VEHICLE_OWNERSHIP, r.START_DT START_DT, r.END_DT END_DT, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.CUSTVEHRET_FLAG CUSTVEHRET_FLAG, r.DELETE_FLAG DELETE_FLAG, r.SFDC_ID SFDC_ID, r.SERVICE_NAME SERVICE_NAME, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XCUSTOMERVEHICLEJPN r WHERE r.CONT_ID = ? ",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"xcustomer_vehicle_jpnpk_id", "cont_id", "vehicle_id", "retailer_id", "connectme_usage_tp_cd", "license_plate", "vehicle_sales_tp_cd", "vehicle_usage_tp_cd", "vehicle_ownership", "start_dt", "end_dt", "source_ident_tp_cd", "custvehret_flag", "delete_flag", "sfdc_id", "service_name", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetAllXCustomerVehicleJPNByPartyIdParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetAllXCustomerVehicleJPNByPartyIdRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 19, 19, 19, 19, 20, 19, 19, 250, 0, 0, 19, 5, 10, 50, 120, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    3);

  /**
   * @generated
   */
  public static class GetAllXCustomerVehicleJPNByPartyIdParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetAllXCustomerVehicleJPNByPartyIdRowHandler extends BaseRowHandler<ResultQueue1<EObjXCustomerVehicleJPN>>
  {
    /**
     * @generated
     */
    public ResultQueue1<EObjXCustomerVehicleJPN> handle (java.sql.ResultSet rs, ResultQueue1<EObjXCustomerVehicleJPN> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue1<EObjXCustomerVehicleJPN> ();

      EObjXCustomerVehicleJPN returnObject1 = new EObjXCustomerVehicleJPN ();
      returnObject1.setXCustomerVehicleJPNpkId(getLongObject (rs, 1)); 
      returnObject1.setContId(getLongObject (rs, 2)); 
      returnObject1.setVehicleId(getLongObject (rs, 3)); 
      returnObject1.setRetailerId(getLongObject (rs, 4)); 
      returnObject1.setConnectMeUsage(getLongObject (rs, 5)); 
      returnObject1.setLicensePlate(getString (rs, 6)); 
      returnObject1.setVehicleSales(getLongObject (rs, 7)); 
      returnObject1.setVehicleUsage(getLongObject (rs, 8)); 
      returnObject1.setVehicleOwnerShip(getString (rs, 9)); 
      returnObject1.setStartDate(getTimestamp (rs, 10)); 
      returnObject1.setEndDate(getTimestamp (rs, 11)); 
      returnObject1.setSourceIdentifier(getLongObject (rs, 12)); 
      returnObject1.setCustVehRetFlag(getString (rs, 13)); 
      returnObject1.setDeleteFlag(getString (rs, 14)); 
      returnObject1.setSFDCId(getString (rs, 15)); 
      returnObject1.setServiceName(getString (rs, 16)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 17)); 
      returnObject1.setLastUpdateUser(getString (rs, 18)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 19)); 
      returnObject.add (returnObject1);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT r.H_XCustomer_Vehicle_JPNPK_ID hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.XCustomer_Vehicle_JPNPK_ID XCustomer_Vehicle_JPNPK_ID, r.CONT_ID CONT_ID, r.VEHICLE_ID VEHICLE_ID, r.RETAILER_ID RETAILER_ID, r.CONNECTME_USAGE_TP_CD CONNECTME_USAGE_TP_CD, r.LICENSE_PLATE LICENSE_PLATE, r.VEHICLE_SALES_TP_CD VEHICLE_SALES_TP_CD, r.VEHICLE_USAGE_TP_CD VEHICLE_USAGE_TP_CD, r.VEHICLE_OWNERSHIP VEHICLE_OWNERSHIP, r.START_DT START_DT, r.END_DT END_DT, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.CUSTVEHRET_FLAG CUSTVEHRET_FLAG, r.DELETE_FLAG DELETE_FLAG, r.SFDC_ID SFDC_ID, r.SERVICE_NAME SERVICE_NAME, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XCUSTOMERVEHICLEJPN r WHERE r.CONT_ID = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))", pattern="tableAlias (XCUSTOMERVEHICLEJPN => com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleJPN, H_XCUSTOMERVEHICLEJPN => com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleJPN)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue1<EObjXCustomerVehicleJPN>> getAllXCustomerVehicleJPNByPartyIdHistory (Object[] parameters)
  {
    return queryIterator (getAllXCustomerVehicleJPNByPartyIdHistoryStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getAllXCustomerVehicleJPNByPartyIdHistoryStatementDescriptor = createStatementDescriptor (
    "getAllXCustomerVehicleJPNByPartyIdHistory(Object[])",
    "SELECT r.H_XCustomer_Vehicle_JPNPK_ID hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.XCustomer_Vehicle_JPNPK_ID XCustomer_Vehicle_JPNPK_ID, r.CONT_ID CONT_ID, r.VEHICLE_ID VEHICLE_ID, r.RETAILER_ID RETAILER_ID, r.CONNECTME_USAGE_TP_CD CONNECTME_USAGE_TP_CD, r.LICENSE_PLATE LICENSE_PLATE, r.VEHICLE_SALES_TP_CD VEHICLE_SALES_TP_CD, r.VEHICLE_USAGE_TP_CD VEHICLE_USAGE_TP_CD, r.VEHICLE_OWNERSHIP VEHICLE_OWNERSHIP, r.START_DT START_DT, r.END_DT END_DT, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.CUSTVEHRET_FLAG CUSTVEHRET_FLAG, r.DELETE_FLAG DELETE_FLAG, r.SFDC_ID SFDC_ID, r.SERVICE_NAME SERVICE_NAME, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XCUSTOMERVEHICLEJPN r WHERE r.CONT_ID = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"historyidpk", "h_action_code", "h_created_by", "h_create_dt", "h_end_dt", "xcustomer_vehicle_jpnpk_id", "cont_id", "vehicle_id", "retailer_id", "connectme_usage_tp_cd", "license_plate", "vehicle_sales_tp_cd", "vehicle_usage_tp_cd", "vehicle_ownership", "start_dt", "end_dt", "source_ident_tp_cd", "custvehret_flag", "delete_flag", "sfdc_id", "service_name", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetAllXCustomerVehicleJPNByPartyIdHistoryParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP}, {19, 0, 0}, {0, 0, 0}, {1, 1, 1}},
    null,
    new GetAllXCustomerVehicleJPNByPartyIdHistoryRowHandler (),
    new int[][]{ {Types.BIGINT, Types.CHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 1, 20, 0, 0, 19, 19, 19, 19, 19, 20, 19, 19, 250, 0, 0, 19, 5, 10, 50, 120, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    4);

  /**
   * @generated
   */
  public static class GetAllXCustomerVehicleJPNByPartyIdHistoryParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetAllXCustomerVehicleJPNByPartyIdHistoryRowHandler extends BaseRowHandler<ResultQueue1<EObjXCustomerVehicleJPN>>
  {
    /**
     * @generated
     */
    public ResultQueue1<EObjXCustomerVehicleJPN> handle (java.sql.ResultSet rs, ResultQueue1<EObjXCustomerVehicleJPN> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue1<EObjXCustomerVehicleJPN> ();

      EObjXCustomerVehicleJPN returnObject1 = new EObjXCustomerVehicleJPN ();
      returnObject1.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject1.setHistActionCode(getString (rs, 2)); 
      returnObject1.setHistCreatedBy(getString (rs, 3)); 
      returnObject1.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject1.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject1.setXCustomerVehicleJPNpkId(getLongObject (rs, 6)); 
      returnObject1.setContId(getLongObject (rs, 7)); 
      returnObject1.setVehicleId(getLongObject (rs, 8)); 
      returnObject1.setRetailerId(getLongObject (rs, 9)); 
      returnObject1.setConnectMeUsage(getLongObject (rs, 10)); 
      returnObject1.setLicensePlate(getString (rs, 11)); 
      returnObject1.setVehicleSales(getLongObject (rs, 12)); 
      returnObject1.setVehicleUsage(getLongObject (rs, 13)); 
      returnObject1.setVehicleOwnerShip(getString (rs, 14)); 
      returnObject1.setStartDate(getTimestamp (rs, 15)); 
      returnObject1.setEndDate(getTimestamp (rs, 16)); 
      returnObject1.setSourceIdentifier(getLongObject (rs, 17)); 
      returnObject1.setCustVehRetFlag(getString (rs, 18)); 
      returnObject1.setDeleteFlag(getString (rs, 19)); 
      returnObject1.setSFDCId(getString (rs, 20)); 
      returnObject1.setServiceName(getString (rs, 21)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 22)); 
      returnObject1.setLastUpdateUser(getString (rs, 23)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 24)); 
      returnObject.add (returnObject1);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT r.XCustomer_Vehicle_JPNPK_ID XCustomer_Vehicle_JPNPK_ID, r.CONT_ID CONT_ID, r.VEHICLE_ID VEHICLE_ID, r.RETAILER_ID RETAILER_ID, r.CONNECTME_USAGE_TP_CD CONNECTME_USAGE_TP_CD, r.LICENSE_PLATE LICENSE_PLATE, r.VEHICLE_SALES_TP_CD VEHICLE_SALES_TP_CD, r.VEHICLE_USAGE_TP_CD VEHICLE_USAGE_TP_CD, r.VEHICLE_OWNERSHIP VEHICLE_OWNERSHIP, r.START_DT START_DT, r.END_DT END_DT, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.CUSTVEHRET_FLAG CUSTVEHRET_FLAG, r.DELETE_FLAG DELETE_FLAG, r.SFDC_ID SFDC_ID, r.SERVICE_NAME SERVICE_NAME, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XCUSTOMERVEHICLEJPN r WHERE r.VEHICLE_ID = ? ", pattern="tableAlias (XCUSTOMERVEHICLEJPN => com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleJPN, H_XCUSTOMERVEHICLEJPN => com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleJPN)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue1<EObjXCustomerVehicleJPN>> getAllCVRByVehicleId (Object[] parameters)
  {
    return queryIterator (getAllCVRByVehicleIdStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getAllCVRByVehicleIdStatementDescriptor = createStatementDescriptor (
    "getAllCVRByVehicleId(Object[])",
    "SELECT r.XCustomer_Vehicle_JPNPK_ID XCustomer_Vehicle_JPNPK_ID, r.CONT_ID CONT_ID, r.VEHICLE_ID VEHICLE_ID, r.RETAILER_ID RETAILER_ID, r.CONNECTME_USAGE_TP_CD CONNECTME_USAGE_TP_CD, r.LICENSE_PLATE LICENSE_PLATE, r.VEHICLE_SALES_TP_CD VEHICLE_SALES_TP_CD, r.VEHICLE_USAGE_TP_CD VEHICLE_USAGE_TP_CD, r.VEHICLE_OWNERSHIP VEHICLE_OWNERSHIP, r.START_DT START_DT, r.END_DT END_DT, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.CUSTVEHRET_FLAG CUSTVEHRET_FLAG, r.DELETE_FLAG DELETE_FLAG, r.SFDC_ID SFDC_ID, r.SERVICE_NAME SERVICE_NAME, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XCUSTOMERVEHICLEJPN r WHERE r.VEHICLE_ID = ? ",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"xcustomer_vehicle_jpnpk_id", "cont_id", "vehicle_id", "retailer_id", "connectme_usage_tp_cd", "license_plate", "vehicle_sales_tp_cd", "vehicle_usage_tp_cd", "vehicle_ownership", "start_dt", "end_dt", "source_ident_tp_cd", "custvehret_flag", "delete_flag", "sfdc_id", "service_name", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetAllCVRByVehicleIdParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetAllCVRByVehicleIdRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 19, 19, 19, 19, 20, 19, 19, 250, 0, 0, 19, 5, 10, 50, 120, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    5);

  /**
   * @generated
   */
  public static class GetAllCVRByVehicleIdParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetAllCVRByVehicleIdRowHandler extends BaseRowHandler<ResultQueue1<EObjXCustomerVehicleJPN>>
  {
    /**
     * @generated
     */
    public ResultQueue1<EObjXCustomerVehicleJPN> handle (java.sql.ResultSet rs, ResultQueue1<EObjXCustomerVehicleJPN> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue1<EObjXCustomerVehicleJPN> ();

      EObjXCustomerVehicleJPN returnObject1 = new EObjXCustomerVehicleJPN ();
      returnObject1.setXCustomerVehicleJPNpkId(getLongObject (rs, 1)); 
      returnObject1.setContId(getLongObject (rs, 2)); 
      returnObject1.setVehicleId(getLongObject (rs, 3)); 
      returnObject1.setRetailerId(getLongObject (rs, 4)); 
      returnObject1.setConnectMeUsage(getLongObject (rs, 5)); 
      returnObject1.setLicensePlate(getString (rs, 6)); 
      returnObject1.setVehicleSales(getLongObject (rs, 7)); 
      returnObject1.setVehicleUsage(getLongObject (rs, 8)); 
      returnObject1.setVehicleOwnerShip(getString (rs, 9)); 
      returnObject1.setStartDate(getTimestamp (rs, 10)); 
      returnObject1.setEndDate(getTimestamp (rs, 11)); 
      returnObject1.setSourceIdentifier(getLongObject (rs, 12)); 
      returnObject1.setCustVehRetFlag(getString (rs, 13)); 
      returnObject1.setDeleteFlag(getString (rs, 14)); 
      returnObject1.setSFDCId(getString (rs, 15)); 
      returnObject1.setServiceName(getString (rs, 16)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 17)); 
      returnObject1.setLastUpdateUser(getString (rs, 18)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 19)); 
      returnObject.add (returnObject1);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT r.H_XCustomer_Vehicle_JPNPK_ID hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.XCustomer_Vehicle_JPNPK_ID XCustomer_Vehicle_JPNPK_ID, r.CONT_ID CONT_ID, r.VEHICLE_ID VEHICLE_ID, r.RETAILER_ID RETAILER_ID, r.CONNECTME_USAGE_TP_CD CONNECTME_USAGE_TP_CD, r.LICENSE_PLATE LICENSE_PLATE, r.VEHICLE_SALES_TP_CD VEHICLE_SALES_TP_CD, r.VEHICLE_USAGE_TP_CD VEHICLE_USAGE_TP_CD, r.VEHICLE_OWNERSHIP VEHICLE_OWNERSHIP, r.START_DT START_DT, r.END_DT END_DT, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.CUSTVEHRET_FLAG CUSTVEHRET_FLAG, r.DELETE_FLAG DELETE_FLAG, r.SFDC_ID SFDC_ID, r.SERVICE_NAME SERVICE_NAME, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XCUSTOMERVEHICLEJPN r WHERE r.VEHICLE_ID = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))", pattern="tableAlias (XCUSTOMERVEHICLEJPN => com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleJPN, H_XCUSTOMERVEHICLEJPN => com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleJPN)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue1<EObjXCustomerVehicleJPN>> getAllCVRByVehicleIdHistory (Object[] parameters)
  {
    return queryIterator (getAllCVRByVehicleIdHistoryStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getAllCVRByVehicleIdHistoryStatementDescriptor = createStatementDescriptor (
    "getAllCVRByVehicleIdHistory(Object[])",
    "SELECT r.H_XCustomer_Vehicle_JPNPK_ID hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.XCustomer_Vehicle_JPNPK_ID XCustomer_Vehicle_JPNPK_ID, r.CONT_ID CONT_ID, r.VEHICLE_ID VEHICLE_ID, r.RETAILER_ID RETAILER_ID, r.CONNECTME_USAGE_TP_CD CONNECTME_USAGE_TP_CD, r.LICENSE_PLATE LICENSE_PLATE, r.VEHICLE_SALES_TP_CD VEHICLE_SALES_TP_CD, r.VEHICLE_USAGE_TP_CD VEHICLE_USAGE_TP_CD, r.VEHICLE_OWNERSHIP VEHICLE_OWNERSHIP, r.START_DT START_DT, r.END_DT END_DT, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.CUSTVEHRET_FLAG CUSTVEHRET_FLAG, r.DELETE_FLAG DELETE_FLAG, r.SFDC_ID SFDC_ID, r.SERVICE_NAME SERVICE_NAME, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XCUSTOMERVEHICLEJPN r WHERE r.VEHICLE_ID = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"historyidpk", "h_action_code", "h_created_by", "h_create_dt", "h_end_dt", "xcustomer_vehicle_jpnpk_id", "cont_id", "vehicle_id", "retailer_id", "connectme_usage_tp_cd", "license_plate", "vehicle_sales_tp_cd", "vehicle_usage_tp_cd", "vehicle_ownership", "start_dt", "end_dt", "source_ident_tp_cd", "custvehret_flag", "delete_flag", "sfdc_id", "service_name", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetAllCVRByVehicleIdHistoryParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP}, {19, 0, 0}, {0, 0, 0}, {1, 1, 1}},
    null,
    new GetAllCVRByVehicleIdHistoryRowHandler (),
    new int[][]{ {Types.BIGINT, Types.CHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 1, 20, 0, 0, 19, 19, 19, 19, 19, 20, 19, 19, 250, 0, 0, 19, 5, 10, 50, 120, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    6);

  /**
   * @generated
   */
  public static class GetAllCVRByVehicleIdHistoryParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetAllCVRByVehicleIdHistoryRowHandler extends BaseRowHandler<ResultQueue1<EObjXCustomerVehicleJPN>>
  {
    /**
     * @generated
     */
    public ResultQueue1<EObjXCustomerVehicleJPN> handle (java.sql.ResultSet rs, ResultQueue1<EObjXCustomerVehicleJPN> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue1<EObjXCustomerVehicleJPN> ();

      EObjXCustomerVehicleJPN returnObject1 = new EObjXCustomerVehicleJPN ();
      returnObject1.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject1.setHistActionCode(getString (rs, 2)); 
      returnObject1.setHistCreatedBy(getString (rs, 3)); 
      returnObject1.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject1.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject1.setXCustomerVehicleJPNpkId(getLongObject (rs, 6)); 
      returnObject1.setContId(getLongObject (rs, 7)); 
      returnObject1.setVehicleId(getLongObject (rs, 8)); 
      returnObject1.setRetailerId(getLongObject (rs, 9)); 
      returnObject1.setConnectMeUsage(getLongObject (rs, 10)); 
      returnObject1.setLicensePlate(getString (rs, 11)); 
      returnObject1.setVehicleSales(getLongObject (rs, 12)); 
      returnObject1.setVehicleUsage(getLongObject (rs, 13)); 
      returnObject1.setVehicleOwnerShip(getString (rs, 14)); 
      returnObject1.setStartDate(getTimestamp (rs, 15)); 
      returnObject1.setEndDate(getTimestamp (rs, 16)); 
      returnObject1.setSourceIdentifier(getLongObject (rs, 17)); 
      returnObject1.setCustVehRetFlag(getString (rs, 18)); 
      returnObject1.setDeleteFlag(getString (rs, 19)); 
      returnObject1.setSFDCId(getString (rs, 20)); 
      returnObject1.setServiceName(getString (rs, 21)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 22)); 
      returnObject1.setLastUpdateUser(getString (rs, 23)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 24)); 
      returnObject.add (returnObject1);

    
      return returnObject;
    }
  }

}
