/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[9a20c891d1a7c1e8f4eb78583580b7e0]
 */

package com.ibm.daimler.dsea.entityObject;


import com.ibm.mdm.base.db.ResultQueue1;
import java.util.Iterator;
import com.ibm.mdm.base.db.EntityMapping;
import com.ibm.pdq.annotation.Select;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * @generated
 */
public interface XCustomerRetailerRoleInquiryData {
  
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String tableAliasString = "tableAlias (" + 
                                            "XCUSTOMERRETAILERROLE => com.ibm.daimler.dsea.entityObject.EObjXCustomerRetailerRole, " +
                                            "H_XCUSTOMERRETAILERROLE => com.ibm.daimler.dsea.entityObject.EObjXCustomerRetailerRole" +
                                            ")";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getXCustomerRetailerRoleSql = "SELECT r.CUSTOMERRETAILERROLEPK_ID CUSTOMERRETAILERROLEPK_ID, r.CUSTOMER_RETAILER_ID CUSTOMER_RETAILER_ID, r.RETAILER_ROLE_TP_CD RETAILER_ROLE_TP_CD, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.START_DT START_DT, r.END_DT END_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XCUSTOMERRETAILERROLE r WHERE r.CUSTOMERRETAILERROLEPK_ID = ? ";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXCustomerRetailerRoleParameters =
    "EObjXCustomerRetailerRole.CustomerRetailerRolepkId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXCustomerRetailerRoleResults =
    "EObjXCustomerRetailerRole.CustomerRetailerRolepkId," +
    "EObjXCustomerRetailerRole.CustomerRetailerId," +
    "EObjXCustomerRetailerRole.RetailerRole," +
    "EObjXCustomerRetailerRole.SourceIdentifier," +
    "EObjXCustomerRetailerRole.StartDate," +
    "EObjXCustomerRetailerRole.EndDate," +
    "EObjXCustomerRetailerRole.lastUpdateDt," +
    "EObjXCustomerRetailerRole.lastUpdateUser," +
    "EObjXCustomerRetailerRole.lastUpdateTxId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getXCustomerRetailerRoleHistorySql = "SELECT r.H_CUSTOMERRETAILERROLEPK_ID hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.CUSTOMERRETAILERROLEPK_ID CUSTOMERRETAILERROLEPK_ID, r.CUSTOMER_RETAILER_ID CUSTOMER_RETAILER_ID, r.RETAILER_ROLE_TP_CD RETAILER_ROLE_TP_CD, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.START_DT START_DT, r.END_DT END_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XCUSTOMERRETAILERROLE r WHERE r.H_CUSTOMERRETAILERROLEPK_ID = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXCustomerRetailerRoleHistoryParameters =
    "EObjXCustomerRetailerRole.CustomerRetailerRolepkId," +
    "EObjXCustomerRetailerRole.lastUpdateDt," +
    "EObjXCustomerRetailerRole.lastUpdateDt";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXCustomerRetailerRoleHistoryResults =
    "EObjXCustomerRetailerRole.historyIdPK," +
    "EObjXCustomerRetailerRole.histActionCode," +
    "EObjXCustomerRetailerRole.histCreatedBy," +
    "EObjXCustomerRetailerRole.histCreateDt," +
    "EObjXCustomerRetailerRole.histEndDt," +
    "EObjXCustomerRetailerRole.CustomerRetailerRolepkId," +
    "EObjXCustomerRetailerRole.CustomerRetailerId," +
    "EObjXCustomerRetailerRole.RetailerRole," +
    "EObjXCustomerRetailerRole.SourceIdentifier," +
    "EObjXCustomerRetailerRole.StartDate," +
    "EObjXCustomerRetailerRole.EndDate," +
    "EObjXCustomerRetailerRole.lastUpdateDt," +
    "EObjXCustomerRetailerRole.lastUpdateUser," +
    "EObjXCustomerRetailerRole.lastUpdateTxId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getAllRetailerRoleByCustomerRetailerIdSql = "SELECT r.CUSTOMERRETAILERROLEPK_ID CUSTOMERRETAILERROLEPK_ID, r.CUSTOMER_RETAILER_ID CUSTOMER_RETAILER_ID, r.RETAILER_ROLE_TP_CD RETAILER_ROLE_TP_CD, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.START_DT START_DT, r.END_DT END_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XCUSTOMERRETAILERROLE r WHERE r.CUSTOMER_RETAILER_ID = ? ";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getAllRetailerRoleByCustomerRetailerIdParameters =
    "EObjXCustomerRetailerRole.CustomerRetailerId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getAllRetailerRoleByCustomerRetailerIdResults =
    "EObjXCustomerRetailerRole.CustomerRetailerRolepkId," +
    "EObjXCustomerRetailerRole.CustomerRetailerId," +
    "EObjXCustomerRetailerRole.RetailerRole," +
    "EObjXCustomerRetailerRole.SourceIdentifier," +
    "EObjXCustomerRetailerRole.StartDate," +
    "EObjXCustomerRetailerRole.EndDate," +
    "EObjXCustomerRetailerRole.lastUpdateDt," +
    "EObjXCustomerRetailerRole.lastUpdateUser," +
    "EObjXCustomerRetailerRole.lastUpdateTxId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getAllRetailerRoleByCustomerRetailerIdHistorySql = "SELECT r.H_CUSTOMERRETAILERROLEPK_ID hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.CUSTOMERRETAILERROLEPK_ID CUSTOMERRETAILERROLEPK_ID, r.CUSTOMER_RETAILER_ID CUSTOMER_RETAILER_ID, r.RETAILER_ROLE_TP_CD RETAILER_ROLE_TP_CD, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.START_DT START_DT, r.END_DT END_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XCUSTOMERRETAILERROLE r WHERE r.CUSTOMER_RETAILER_ID = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getAllRetailerRoleByCustomerRetailerIdHistoryParameters =
    "EObjXCustomerRetailerRole.CustomerRetailerId," +
    "EObjXCustomerRetailerRole.lastUpdateDt," +
    "EObjXCustomerRetailerRole.lastUpdateDt";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getAllRetailerRoleByCustomerRetailerIdHistoryResults =
    "EObjXCustomerRetailerRole.historyIdPK," +
    "EObjXCustomerRetailerRole.histActionCode," +
    "EObjXCustomerRetailerRole.histCreatedBy," +
    "EObjXCustomerRetailerRole.histCreateDt," +
    "EObjXCustomerRetailerRole.histEndDt," +
    "EObjXCustomerRetailerRole.CustomerRetailerRolepkId," +
    "EObjXCustomerRetailerRole.CustomerRetailerId," +
    "EObjXCustomerRetailerRole.RetailerRole," +
    "EObjXCustomerRetailerRole.SourceIdentifier," +
    "EObjXCustomerRetailerRole.StartDate," +
    "EObjXCustomerRetailerRole.EndDate," +
    "EObjXCustomerRetailerRole.lastUpdateDt," +
    "EObjXCustomerRetailerRole.lastUpdateUser," +
    "EObjXCustomerRetailerRole.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getXCustomerRetailerRoleSql, pattern=tableAliasString)
  @EntityMapping(parameters=getXCustomerRetailerRoleParameters, results=getXCustomerRetailerRoleResults)
  Iterator<ResultQueue1<EObjXCustomerRetailerRole>> getXCustomerRetailerRole(Object[] parameters);  


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getXCustomerRetailerRoleHistorySql, pattern=tableAliasString)
  @EntityMapping(parameters=getXCustomerRetailerRoleHistoryParameters, results=getXCustomerRetailerRoleHistoryResults)
  Iterator<ResultQueue1<EObjXCustomerRetailerRole>> getXCustomerRetailerRoleHistory(Object[] parameters);  


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getAllRetailerRoleByCustomerRetailerIdSql, pattern=tableAliasString)
  @EntityMapping(parameters=getAllRetailerRoleByCustomerRetailerIdParameters, results=getAllRetailerRoleByCustomerRetailerIdResults)
  Iterator<ResultQueue1<EObjXCustomerRetailerRole>> getAllRetailerRoleByCustomerRetailerId(Object[] parameters);  


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getAllRetailerRoleByCustomerRetailerIdHistorySql, pattern=tableAliasString)
  @EntityMapping(parameters=getAllRetailerRoleByCustomerRetailerIdHistoryParameters, results=getAllRetailerRoleByCustomerRetailerIdHistoryResults)
  Iterator<ResultQueue1<EObjXCustomerRetailerRole>> getAllRetailerRoleByCustomerRetailerIdHistory(Object[] parameters);  


}


