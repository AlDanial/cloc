/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[8350295c023c68f2fa3e8364cd07cb81]
 */


package com.ibm.daimler.dsea.entityObject;

import java.util.Iterator;
import com.ibm.mdm.base.db.EntityMapping;
import com.ibm.pdq.annotation.Select;
import com.ibm.pdq.annotation.Update;

import com.ibm.daimler.dsea.entityObject.EObjXDealerRetailer;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * @generated
 */
public interface EObjXDealerRetailerData {


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjXDealerRetailerSql = "select XDealer_Retailerpk_Id, Dealer_Code, Retailer_Code, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from XDEALERRETAILER where XDealer_Retailerpk_Id = ? ";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String createEObjXDealerRetailerSql = "insert into XDEALERRETAILER (XDealer_Retailerpk_Id, Dealer_Code, Retailer_Code, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( :xDealerRetailerpkId, :dealerCode, :retailerCode, :lastUpdateDt, :lastUpdateUser, :lastUpdateTxId)";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String updateEObjXDealerRetailerSql = "update XDEALERRETAILER set Dealer_Code = :dealerCode, Retailer_Code = :retailerCode, LAST_UPDATE_DT = :lastUpdateDt, LAST_UPDATE_USER = :lastUpdateUser, LAST_UPDATE_TX_ID = :lastUpdateTxId where XDealer_Retailerpk_Id = :xDealerRetailerpkId and LAST_UPDATE_DT = :oldLastUpdateDt";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String deleteEObjXDealerRetailerSql = "delete from XDEALERRETAILER where XDealer_Retailerpk_Id = ?";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXDealerRetailerKeyField = "EObjXDealerRetailer.xDealerRetailerpkId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXDealerRetailerGetFields =
    "EObjXDealerRetailer.xDealerRetailerpkId," +
    "EObjXDealerRetailer.dealerCode," +
    "EObjXDealerRetailer.retailerCode," +
    "EObjXDealerRetailer.lastUpdateDt," +
    "EObjXDealerRetailer.lastUpdateUser," +
    "EObjXDealerRetailer.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXDealerRetailerAllFields =
    "com.ibm.daimler.dsea.entityObject.EObjXDealerRetailer.xDealerRetailerpkId," +
    "com.ibm.daimler.dsea.entityObject.EObjXDealerRetailer.dealerCode," +
    "com.ibm.daimler.dsea.entityObject.EObjXDealerRetailer.retailerCode," +
    "com.ibm.daimler.dsea.entityObject.EObjXDealerRetailer.lastUpdateDt," +
    "com.ibm.daimler.dsea.entityObject.EObjXDealerRetailer.lastUpdateUser," +
    "com.ibm.daimler.dsea.entityObject.EObjXDealerRetailer.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXDealerRetailerUpdateFields =
    "com.ibm.daimler.dsea.entityObject.EObjXDealerRetailer.dealerCode," +
    "com.ibm.daimler.dsea.entityObject.EObjXDealerRetailer.retailerCode," +
    "com.ibm.daimler.dsea.entityObject.EObjXDealerRetailer.lastUpdateDt," +
    "com.ibm.daimler.dsea.entityObject.EObjXDealerRetailer.lastUpdateUser," +
    "com.ibm.daimler.dsea.entityObject.EObjXDealerRetailer.lastUpdateTxId," +
    "com.ibm.daimler.dsea.entityObject.EObjXDealerRetailer.xDealerRetailerpkId," +
    "com.ibm.daimler.dsea.entityObject.EObjXDealerRetailer.oldLastUpdateDt";   

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Select XDealerRetailer by parameters.
   * @generated
   */
  @Select(sql=getEObjXDealerRetailerSql)
  @EntityMapping(parameters=EObjXDealerRetailerKeyField, results=EObjXDealerRetailerGetFields)
  Iterator<EObjXDealerRetailer> getEObjXDealerRetailer(Long xDealerRetailerpkId);  
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Create XDealerRetailer by EObjXDealerRetailer Object.
   * @generated
   */
  @Update(sql=createEObjXDealerRetailerSql)
  @EntityMapping(parameters=EObjXDealerRetailerAllFields)
    int createEObjXDealerRetailer(EObjXDealerRetailer e); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Update one XDealerRetailer by EObjXDealerRetailer object.
   * @generated
   */
  @Update(sql=updateEObjXDealerRetailerSql)
  @EntityMapping(parameters=EObjXDealerRetailerUpdateFields)
    int updateEObjXDealerRetailer(EObjXDealerRetailer e); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Delete XDealerRetailer by parameters.
   * @generated
   */
  @Update(sql=deleteEObjXDealerRetailerSql)
  @EntityMapping(parameters=EObjXDealerRetailerKeyField)
  int deleteEObjXDealerRetailer(Long xDealerRetailerpkId);

}

