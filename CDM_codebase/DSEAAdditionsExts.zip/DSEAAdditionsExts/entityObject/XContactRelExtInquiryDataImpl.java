package com.ibm.daimler.dsea.entityObject;

import com.ibm.pdq.runtime.generator.BaseParameterHandler;
import java.util.Iterator;
import com.dwl.tcrm.coreParty.entityObject.EObjContact;
import com.ibm.daimler.dsea.entityObject.EObjXContactRelExt;
import java.sql.PreparedStatement;
import com.ibm.pdq.runtime.statement.StatementDescriptor;
import com.ibm.pdq.runtime.generator.BaseData;
import java.sql.SQLException;
import com.ibm.pdq.annotation.Metadata;
import com.ibm.mdm.base.db.ResultQueue3;
import com.ibm.mdm.base.db.ResultQueue2;
import com.dwl.tcrm.coreParty.entityObject.EObjContactRel;
import com.ibm.pdq.runtime.generator.BaseRowHandler;
import com.ibm.pdq.runtime.statement.SqlStatementType;
import java.sql.Types;


@SuppressWarnings("unchecked")

/**
 * <!-- begin-user-doc -->
 * 
 * <!-- end-user-doc -->
 * 
 * @generated
 */
public class XContactRelExtInquiryDataImpl  extends BaseData implements XContactRelExtInquiryData
{

  /**
   * @generated
   */
  public static final String generatorVersion = "3.200.75";

  /**
   * @generated
   */
  public static final String identifier = "XContactRelExtInquiryData";

  /**
   * @generated
   */
  public static final long generationTime = 0x00000164228403e9L;

  /**
   * @generated
   */
  public static final String collection = "NULLID";

  /**
   * @generated
   */
  public static final String packageVersion = null;

  /**
   * @generated
   */
  public static final boolean forceSingleBindIsolation = false;

  /**
   * @generated
   */
  public XContactRelExtInquiryDataImpl()
  {
    super();
  } 

  /**
   * @generated
   */
  public String getGeneratorVersion()
  {
    return generatorVersion;
  }

  /**
   * @Select( sql="SELECT DISTINCT A.H_CONT_REL_ID AS HIST_ID_PK, A.H_ACTION_CODE, A.H_CREATED_BY, A.H_CREATE_DT, A.H_END_DT, A.CONT_REL_ID, A.REL_TP_CD, A.REL_DESC, A.START_DT, A.END_DT, A.TO_CONT_ID, A.FROM_CONT_ID, A.LAST_UPDATE_DT, A.LAST_UPDATE_USER, A.LAST_UPDATE_TX_ID, A.REL_ASSIGN_TP_CD, A.END_REASON_TP_CD, B.CONTACT_NAME, A.XRETAILER_CODE, A.XCONTACT_ROLE, A.XCONTACT_POSITION, A.XCONTACTREL_RETAILER_FLAG, A.XSOURCE_IDENT_TP_CD, A.XMODIFY_SYS_DT, A.DELETE_FLAG FROM H_CONTACTREL A, H_CONTACT B WHERE (B.H_CONT_ID = A.FROM_CONT_ID) AND (A.FROM_CONT_ID = ? AND A.TO_CONT_ID = ? OR (A.TO_CONT_ID = ? AND A.FROM_CONT_ID = ?)) AND (? BETWEEN A.H_CREATE_DT AND A.H_END_DT OR (? >= A.H_CREATE_DT AND A.H_END_DT IS NULL)) AND (( ? BETWEEN B.H_CREATE_DT AND B.H_END_DT ) OR ( ? >= B.H_CREATE_DT AND B.H_END_DT IS NULL ))", pattern="tableAlias (CONTACTREL => com.dwl.tcrm.coreParty.entityObject.EObjContactRel, H_CONTACTREL => com.dwl.tcrm.coreParty.entityObject.EObjContactRel, CONTACT => com.dwl.tcrm.coreParty.entityObject.EObjContact, H_CONTACT => com.dwl.tcrm.coreParty.entityObject.EObjContact , CONTACTREL => com.ibm.daimler.dsea.entityObject.EObjXContactRelExt , H_CONTACTREL => com.ibm.daimler.dsea.entityObject.EObjXContactRelExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue3<EObjContactRel,EObjContact,EObjXContactRelExt>> getPartyRelationshipHistory (Object[] parameters)
  {
    return queryIterator (getPartyRelationshipHistoryStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getPartyRelationshipHistoryStatementDescriptor = createStatementDescriptor (
    "getPartyRelationshipHistory(Object[])",
    "SELECT DISTINCT A.H_CONT_REL_ID AS HIST_ID_PK, A.H_ACTION_CODE, A.H_CREATED_BY, A.H_CREATE_DT, A.H_END_DT, A.CONT_REL_ID, A.REL_TP_CD, A.REL_DESC, A.START_DT, A.END_DT, A.TO_CONT_ID, A.FROM_CONT_ID, A.LAST_UPDATE_DT, A.LAST_UPDATE_USER, A.LAST_UPDATE_TX_ID, A.REL_ASSIGN_TP_CD, A.END_REASON_TP_CD, B.CONTACT_NAME, A.XRETAILER_CODE, A.XCONTACT_ROLE, A.XCONTACT_POSITION, A.XCONTACTREL_RETAILER_FLAG, A.XSOURCE_IDENT_TP_CD, A.XMODIFY_SYS_DT, A.DELETE_FLAG FROM H_CONTACTREL A, H_CONTACT B WHERE (B.H_CONT_ID = A.FROM_CONT_ID) AND (A.FROM_CONT_ID = ? AND A.TO_CONT_ID = ? OR (A.TO_CONT_ID = ? AND A.FROM_CONT_ID = ?)) AND (? BETWEEN A.H_CREATE_DT AND A.H_END_DT OR (? >= A.H_CREATE_DT AND A.H_END_DT IS NULL)) AND (( ? BETWEEN B.H_CREATE_DT AND B.H_END_DT ) OR ( ? >= B.H_CREATE_DT AND B.H_END_DT IS NULL ))",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"hist_id_pk", "h_action_code", "h_created_by", "h_create_dt", "h_end_dt", "cont_rel_id", "rel_tp_cd", "rel_desc", "start_dt", "end_dt", "to_cont_id", "from_cont_id", "last_update_dt", "last_update_user", "last_update_tx_id", "rel_assign_tp_cd", "end_reason_tp_cd", "contact_name", "xretailer_code", "xcontact_role", "xcontact_position", "xcontactrel_retailer_flag", "xsource_ident_tp_cd", "xmodify_sys_dt", "delete_flag"},
    new GetPartyRelationshipHistoryParameterHandler (),
    new int[][]{{Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP}, {19, 19, 19, 19, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1, 1}},
    null,
    new GetPartyRelationshipHistoryRowHandler (),
    new int[][]{ {Types.BIGINT, Types.CHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR}, {19, 1, 20, 0, 0, 19, 19, 255, 0, 0, 19, 19, 0, 20, 19, 19, 19, 255, 255, 255, 255, 5, 19, 0, 10}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    1);

  /**
   * @generated
   */
  public static class GetPartyRelationshipHistoryParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.BIGINT, parameters[1], 0);
      setObject (stmt, 3, Types.BIGINT, parameters[2], 0);
      setObject (stmt, 4, Types.BIGINT, parameters[3], 0);
      setObject (stmt, 5, Types.TIMESTAMP, parameters[4], 0);
      setObject (stmt, 6, Types.TIMESTAMP, parameters[5], 0);
      setObject (stmt, 7, Types.TIMESTAMP, parameters[6], 0);
      setObject (stmt, 8, Types.TIMESTAMP, parameters[7], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetPartyRelationshipHistoryRowHandler extends BaseRowHandler<ResultQueue3<EObjContactRel,EObjContact,EObjXContactRelExt>>
  {
    /**
     * @generated
     */
    public ResultQueue3<EObjContactRel,EObjContact,EObjXContactRelExt> handle (java.sql.ResultSet rs, ResultQueue3<EObjContactRel,EObjContact,EObjXContactRelExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue3<EObjContactRel,EObjContact,EObjXContactRelExt> ();

      EObjContactRel returnObject1 = new EObjContactRel ();
      returnObject1.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject1.setHistActionCode(getString (rs, 2)); 
      returnObject1.setHistCreatedBy(getString (rs, 3)); 
      returnObject1.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject1.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject1.setContRelIdPK(getLongObject (rs, 6)); 
      returnObject1.setRelTpCd(getLongObject (rs, 7)); 
      returnObject1.setRelDesc(getString (rs, 8)); 
      returnObject1.setStartDt(getTimestamp (rs, 9)); 
      returnObject1.setEndDt(getTimestamp (rs, 10)); 
      returnObject1.setToContId(getLongObject (rs, 11)); 
      returnObject1.setFromContId(getLongObject (rs, 12)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 13)); 
      returnObject1.setLastUpdateUser(getString (rs, 14)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 15)); 
      returnObject1.setRelAssignTpCd(getLongObject (rs, 16)); 
      returnObject1.setEndReasonTpCd(getLongObject (rs, 17)); 
      returnObject.add (returnObject1);

      EObjContact returnObject2 = new EObjContact ();
      returnObject2.setContactName(getString (rs, 18)); 
      returnObject.add (returnObject2);

      EObjXContactRelExt returnObject3 = new EObjXContactRelExt ();
      returnObject3.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject3.setHistActionCode(getString (rs, 2)); 
      returnObject3.setHistCreatedBy(getString (rs, 3)); 
      returnObject3.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject3.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject3.setLastUpdateDt(getTimestamp (rs, 13)); 
      returnObject3.setLastUpdateUser(getString (rs, 14)); 
      returnObject3.setLastUpdateTxId(getLongObject (rs, 15)); 
      returnObject3.setXRetailerCode(getString (rs, 19)); 
      returnObject3.setXContactRole(getString (rs, 20)); 
      returnObject3.setXContactPosition(getString (rs, 21)); 
      returnObject3.setXContactRelRetailerFlag(getString (rs, 22)); 
      returnObject3.setXSourceIdentifier(getLongObject (rs, 23)); 
      returnObject3.setXLastModifiedSystemDate(getTimestamp (rs, 24)); 
      returnObject3.setDeleteFlag(getString (rs, 25)); 
      returnObject.add (returnObject3);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT CONTACTREL.CONT_REL_ID, CONTACTREL.REL_TP_CD, CONTACTREL.REL_DESC, CONTACTREL.START_DT, CONTACTREL.END_DT, CONTACTREL.TO_CONT_ID, CONTACTREL.FROM_CONT_ID, CONTACTREL.LAST_UPDATE_DT, CONTACTREL.LAST_UPDATE_USER, CONTACTREL.LAST_UPDATE_TX_ID, CONTACTREL.REL_ASSIGN_TP_CD, CONTACT.CONTACT_NAME, CONTACT.LAST_UPDATE_TX_ID, CONTACTREL.END_REASON_TP_CD, CONTACTREL.XRETAILER_CODE, CONTACTREL.XCONTACT_ROLE, CONTACTREL.XCONTACT_POSITION, CONTACTREL.XCONTACTREL_RETAILER_FLAG, CONTACTREL.XSOURCE_IDENT_TP_CD, CONTACTREL.XMODIFY_SYS_DT, CONTACTREL.DELETE_FLAG FROM CONTACTREL, CONTACT WHERE (CONTACT.CONT_ID = CONTACTREL.TO_CONT_ID) AND (CONTACTREL.FROM_CONT_ID = ? ) AND ( CONTACTREL.TO_CONT_ID = ? ) AND (CONTACTREL.END_DT IS NULL OR CONTACTREL.END_DT > ?) UNION SELECT CONTACTREL.CONT_REL_ID, CONTACTREL.REL_TP_CD, CONTACTREL.REL_DESC, CONTACTREL.START_DT , CONTACTREL.END_DT, CONTACTREL.TO_CONT_ID, CONTACTREL.FROM_CONT_ID, CONTACTREL.LAST_UPDATE_DT, CONTACTREL.LAST_UPDATE_USER, CONTACTREL.LAST_UPDATE_TX_ID, CONTACTREL.REL_ASSIGN_TP_CD, CONTACT.CONTACT_NAME, CONTACT.LAST_UPDATE_TX_ID, CONTACTREL.END_REASON_TP_CD, CONTACTREL.XRETAILER_CODE, CONTACTREL.XCONTACT_ROLE, CONTACTREL.XCONTACT_POSITION, CONTACTREL.XCONTACTREL_RETAILER_FLAG, CONTACTREL.XSOURCE_IDENT_TP_CD, CONTACTREL.XMODIFY_SYS_DT, CONTACTREL.DELETE_FLAG FROM CONTACTREL, CONTACT WHERE (CONTACT.CONT_ID = CONTACTREL.FROM_CONT_ID) AND ( CONTACTREL.TO_CONT_ID = ? ) AND ( CONTACTREL.FROM_CONT_ID = ? ) AND (CONTACTREL.END_DT IS NULL OR CONTACTREL.END_DT > ?)", pattern="<rsm><col number='1' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactRel' property='contRelIdPK'></col><col number='2' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactRel' property='relTpCd'></col><col number='3' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactRel' property='relDesc'></col><col number='4' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactRel' property='startDt'></col><col number='5' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactRel' property='endDt'></col><col number='6' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactRel' property='toContId'></col><col number='7' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactRel' property='fromContId'></col><col number='8' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactRel' property='lastUpdateDt'></col><col number='9' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactRel' property='lastUpdateUser'></col><col number='10' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactRel' property='lastUpdateTxId'></col><col number='11' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactRel' property='relAssignTpCd'></col><col number='12' bean='com.dwl.tcrm.coreParty.entityObject.EObjContact' property='contactName'></col><col number='13' bean='com.dwl.tcrm.coreParty.entityObject.EObjContact' property='lastUpdateTxId'></col><col number='14' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactRel' property='endReasonTpCd'></col><col number='15' bean='com.ibm.daimler.dsea.entityObject.EObjXContactRelExt' property='XRetailerCode'></col><col number='16' bean='com.ibm.daimler.dsea.entityObject.EObjXContactRelExt' property='XContactRole'></col><col number='17' bean='com.ibm.daimler.dsea.entityObject.EObjXContactRelExt' property='XContactPosition'></col><col number='18' bean='com.ibm.daimler.dsea.entityObject.EObjXContactRelExt' property='XContactRelRetailerFlag'></col><col number='19' bean='com.ibm.daimler.dsea.entityObject.EObjXContactRelExt' property='XSourceIdentifier'></col><col number='20' bean='com.ibm.daimler.dsea.entityObject.EObjXContactRelExt' property='XLastModifiedSystemDate'></col><col number='21' bean='com.ibm.daimler.dsea.entityObject.EObjXContactRelExt' property='DeleteFlag'></col></rsm>" )
   * 
   * @generated
   */
  public Iterator<ResultQueue3<EObjContactRel,EObjContact,EObjXContactRelExt>> getPartyRelationship (Object[] parameters)
  {
    return queryIterator (getPartyRelationshipStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getPartyRelationshipStatementDescriptor = createStatementDescriptor (
    "getPartyRelationship(Object[])",
    "SELECT CONTACTREL.CONT_REL_ID, CONTACTREL.REL_TP_CD, CONTACTREL.REL_DESC, CONTACTREL.START_DT, CONTACTREL.END_DT, CONTACTREL.TO_CONT_ID, CONTACTREL.FROM_CONT_ID, CONTACTREL.LAST_UPDATE_DT, CONTACTREL.LAST_UPDATE_USER, CONTACTREL.LAST_UPDATE_TX_ID, CONTACTREL.REL_ASSIGN_TP_CD, CONTACT.CONTACT_NAME, CONTACT.LAST_UPDATE_TX_ID, CONTACTREL.END_REASON_TP_CD, CONTACTREL.XRETAILER_CODE, CONTACTREL.XCONTACT_ROLE, CONTACTREL.XCONTACT_POSITION, CONTACTREL.XCONTACTREL_RETAILER_FLAG, CONTACTREL.XSOURCE_IDENT_TP_CD, CONTACTREL.XMODIFY_SYS_DT, CONTACTREL.DELETE_FLAG FROM CONTACTREL, CONTACT WHERE (CONTACT.CONT_ID = CONTACTREL.TO_CONT_ID) AND (CONTACTREL.FROM_CONT_ID = ? ) AND ( CONTACTREL.TO_CONT_ID = ? ) AND (CONTACTREL.END_DT IS NULL OR CONTACTREL.END_DT > ?) UNION SELECT CONTACTREL.CONT_REL_ID, CONTACTREL.REL_TP_CD, CONTACTREL.REL_DESC, CONTACTREL.START_DT , CONTACTREL.END_DT, CONTACTREL.TO_CONT_ID, CONTACTREL.FROM_CONT_ID, CONTACTREL.LAST_UPDATE_DT, CONTACTREL.LAST_UPDATE_USER, CONTACTREL.LAST_UPDATE_TX_ID, CONTACTREL.REL_ASSIGN_TP_CD, CONTACT.CONTACT_NAME, CONTACT.LAST_UPDATE_TX_ID, CONTACTREL.END_REASON_TP_CD, CONTACTREL.XRETAILER_CODE, CONTACTREL.XCONTACT_ROLE, CONTACTREL.XCONTACT_POSITION, CONTACTREL.XCONTACTREL_RETAILER_FLAG, CONTACTREL.XSOURCE_IDENT_TP_CD, CONTACTREL.XMODIFY_SYS_DT, CONTACTREL.DELETE_FLAG FROM CONTACTREL, CONTACT WHERE (CONTACT.CONT_ID = CONTACTREL.FROM_CONT_ID) AND ( CONTACTREL.TO_CONT_ID = ? ) AND ( CONTACTREL.FROM_CONT_ID = ? ) AND (CONTACTREL.END_DT IS NULL OR CONTACTREL.END_DT > ?)",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"cont_rel_id", "rel_tp_cd", "rel_desc", "start_dt", "end_dt", "to_cont_id", "from_cont_id", "last_update_dt", "last_update_user", "last_update_tx_id", "rel_assign_tp_cd", "contact_name", "last_update_tx_id", "end_reason_tp_cd", "xretailer_code", "xcontact_role", "xcontact_position", "xcontactrel_retailer_flag", "xsource_ident_tp_cd", "xmodify_sys_dt", "delete_flag"},
    new GetPartyRelationshipParameterHandler (),
    new int[][]{{Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP}, {19, 19, 0, 19, 19, 0}, {0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1}},
    null,
    new GetPartyRelationshipRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR}, {19, 19, 255, 0, 0, 19, 19, 0, 20, 19, 19, 255, 19, 19, 255, 255, 255, 5, 19, 0, 10}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    2);

  /**
   * @generated
   */
  public static class GetPartyRelationshipParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.BIGINT, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
      setObject (stmt, 4, Types.BIGINT, parameters[3], 0);
      setObject (stmt, 5, Types.BIGINT, parameters[4], 0);
      setObject (stmt, 6, Types.TIMESTAMP, parameters[5], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetPartyRelationshipRowHandler extends BaseRowHandler<ResultQueue3<EObjContactRel,EObjContact,EObjXContactRelExt>>
  {
    /**
     * @generated
     */
    public ResultQueue3<EObjContactRel,EObjContact,EObjXContactRelExt> handle (java.sql.ResultSet rs, ResultQueue3<EObjContactRel,EObjContact,EObjXContactRelExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue3<EObjContactRel,EObjContact,EObjXContactRelExt> ();

      EObjContactRel returnObject1 = new EObjContactRel ();
      returnObject1.setContRelIdPK(getLongObject (rs, 1)); 
      returnObject1.setRelTpCd(getLongObject (rs, 2)); 
      returnObject1.setRelDesc(getString (rs, 3)); 
      returnObject1.setStartDt(getTimestamp (rs, 4)); 
      returnObject1.setEndDt(getTimestamp (rs, 5)); 
      returnObject1.setToContId(getLongObject (rs, 6)); 
      returnObject1.setFromContId(getLongObject (rs, 7)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 8)); 
      returnObject1.setLastUpdateUser(getString (rs, 9)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 10)); 
      returnObject1.setRelAssignTpCd(getLongObject (rs, 11)); 
      returnObject1.setEndReasonTpCd(getLongObject (rs, 14)); 
      returnObject.add (returnObject1);

      EObjContact returnObject2 = new EObjContact ();
      returnObject2.setContactName(getString (rs, 12)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 13)); 
      returnObject.add (returnObject2);

      EObjXContactRelExt returnObject3 = new EObjXContactRelExt ();
      returnObject3.setXRetailerCode(getString (rs, 15)); 
      returnObject3.setXContactRole(getString (rs, 16)); 
      returnObject3.setXContactPosition(getString (rs, 17)); 
      returnObject3.setXContactRelRetailerFlag(getString (rs, 18)); 
      returnObject3.setXSourceIdentifier(getLongObject (rs, 19)); 
      returnObject3.setXLastModifiedSystemDate(getTimestamp (rs, 20)); 
      returnObject3.setDeleteFlag(getString (rs, 21)); 
      returnObject.add (returnObject3);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT CONTACTREL.CONT_REL_ID, CONTACTREL.REL_TP_CD, CONTACTREL.REL_DESC, CONTACTREL.START_DT, CONTACTREL.END_DT, CONTACTREL.TO_CONT_ID, CONTACTREL.FROM_CONT_ID, CONTACTREL.LAST_UPDATE_DT, CONTACTREL.LAST_UPDATE_USER,CONTACTREL.REL_ASSIGN_TP_CD, CONTACTREL.END_REASON_TP_CD, CONTACTREL.LAST_UPDATE_TX_ID, CONTACT.CONTACT_NAME, CONTACTREL.XRETAILER_CODE, CONTACTREL.XCONTACT_ROLE, CONTACTREL.XCONTACT_POSITION, CONTACTREL.XCONTACTREL_RETAILER_FLAG, CONTACTREL.XSOURCE_IDENT_TP_CD, CONTACTREL.XMODIFY_SYS_DT, CONTACTREL.DELETE_FLAG FROM CONTACTREL,CONTACT WHERE CONTACTREL.CONT_REL_ID = ? AND CONTACT.CONT_ID = CONTACTREL.TO_CONT_ID", pattern="tableAlias (CONTACTREL => com.dwl.tcrm.coreParty.entityObject.EObjContactRel, H_CONTACTREL => com.dwl.tcrm.coreParty.entityObject.EObjContactRel, CONTACT => com.dwl.tcrm.coreParty.entityObject.EObjContact, H_CONTACT => com.dwl.tcrm.coreParty.entityObject.EObjContact , CONTACTREL => com.ibm.daimler.dsea.entityObject.EObjXContactRelExt , H_CONTACTREL => com.ibm.daimler.dsea.entityObject.EObjXContactRelExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue3<EObjContactRel,EObjContact,EObjXContactRelExt>> getPartyRelationshipByID (Object[] parameters)
  {
    return queryIterator (getPartyRelationshipByIDStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getPartyRelationshipByIDStatementDescriptor = createStatementDescriptor (
    "getPartyRelationshipByID(Object[])",
    "SELECT CONTACTREL.CONT_REL_ID, CONTACTREL.REL_TP_CD, CONTACTREL.REL_DESC, CONTACTREL.START_DT, CONTACTREL.END_DT, CONTACTREL.TO_CONT_ID, CONTACTREL.FROM_CONT_ID, CONTACTREL.LAST_UPDATE_DT, CONTACTREL.LAST_UPDATE_USER,CONTACTREL.REL_ASSIGN_TP_CD, CONTACTREL.END_REASON_TP_CD, CONTACTREL.LAST_UPDATE_TX_ID, CONTACT.CONTACT_NAME, CONTACTREL.XRETAILER_CODE, CONTACTREL.XCONTACT_ROLE, CONTACTREL.XCONTACT_POSITION, CONTACTREL.XCONTACTREL_RETAILER_FLAG, CONTACTREL.XSOURCE_IDENT_TP_CD, CONTACTREL.XMODIFY_SYS_DT, CONTACTREL.DELETE_FLAG FROM CONTACTREL,CONTACT WHERE CONTACTREL.CONT_REL_ID = ? AND CONTACT.CONT_ID = CONTACTREL.TO_CONT_ID",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"cont_rel_id", "rel_tp_cd", "rel_desc", "start_dt", "end_dt", "to_cont_id", "from_cont_id", "last_update_dt", "last_update_user", "rel_assign_tp_cd", "end_reason_tp_cd", "last_update_tx_id", "contact_name", "xretailer_code", "xcontact_role", "xcontact_position", "xcontactrel_retailer_flag", "xsource_ident_tp_cd", "xmodify_sys_dt", "delete_flag"},
    new GetPartyRelationshipByIDParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetPartyRelationshipByIDRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR}, {19, 19, 255, 0, 0, 19, 19, 0, 20, 19, 19, 19, 255, 255, 255, 255, 5, 19, 0, 10}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    3);

  /**
   * @generated
   */
  public static class GetPartyRelationshipByIDParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetPartyRelationshipByIDRowHandler extends BaseRowHandler<ResultQueue3<EObjContactRel,EObjContact,EObjXContactRelExt>>
  {
    /**
     * @generated
     */
    public ResultQueue3<EObjContactRel,EObjContact,EObjXContactRelExt> handle (java.sql.ResultSet rs, ResultQueue3<EObjContactRel,EObjContact,EObjXContactRelExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue3<EObjContactRel,EObjContact,EObjXContactRelExt> ();

      EObjContactRel returnObject1 = new EObjContactRel ();
      returnObject1.setContRelIdPK(getLongObject (rs, 1)); 
      returnObject1.setRelTpCd(getLongObject (rs, 2)); 
      returnObject1.setRelDesc(getString (rs, 3)); 
      returnObject1.setStartDt(getTimestamp (rs, 4)); 
      returnObject1.setEndDt(getTimestamp (rs, 5)); 
      returnObject1.setToContId(getLongObject (rs, 6)); 
      returnObject1.setFromContId(getLongObject (rs, 7)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 8)); 
      returnObject1.setLastUpdateUser(getString (rs, 9)); 
      returnObject1.setRelAssignTpCd(getLongObject (rs, 10)); 
      returnObject1.setEndReasonTpCd(getLongObject (rs, 11)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 12)); 
      returnObject.add (returnObject1);

      EObjContact returnObject2 = new EObjContact ();
      returnObject2.setContactName(getString (rs, 13)); 
      returnObject.add (returnObject2);

      EObjXContactRelExt returnObject3 = new EObjXContactRelExt ();
      returnObject3.setLastUpdateDt(getTimestamp (rs, 8)); 
      returnObject3.setLastUpdateUser(getString (rs, 9)); 
      returnObject3.setLastUpdateTxId(getLongObject (rs, 12)); 
      returnObject3.setXRetailerCode(getString (rs, 14)); 
      returnObject3.setXContactRole(getString (rs, 15)); 
      returnObject3.setXContactPosition(getString (rs, 16)); 
      returnObject3.setXContactRelRetailerFlag(getString (rs, 17)); 
      returnObject3.setXSourceIdentifier(getLongObject (rs, 18)); 
      returnObject3.setXLastModifiedSystemDate(getTimestamp (rs, 19)); 
      returnObject3.setDeleteFlag(getString (rs, 20)); 
      returnObject.add (returnObject3);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT H_CONTACTREL.H_CONT_REL_ID AS HIST_ID_PK, H_CONTACTREL.REL_TP_CD, H_CONTACTREL.REL_DESC, H_CONTACTREL.START_DT, H_CONTACTREL.END_DT, H_CONTACTREL.TO_CONT_ID,H_CONTACTREL.FROM_CONT_ID, H_CONTACTREL.LAST_UPDATE_DT, H_CONTACTREL.LAST_UPDATE_USER,H_CONTACTREL.REL_ASSIGN_TP_CD, H_CONTACTREL.END_REASON_TP_CD, H_CONTACTREL.LAST_UPDATE_TX_ID, H_CONTACT.CONTACT_NAME, H_CONTACTREL.XRETAILER_CODE, H_CONTACTREL.XCONTACT_ROLE, H_CONTACTREL.XCONTACT_POSITION, H_CONTACTREL.XCONTACTREL_RETAILER_FLAG, H_CONTACTREL.XSOURCE_IDENT_TP_CD, H_CONTACTREL.XMODIFY_SYS_DT, H_CONTACTREL.DELETE_FLAG FROM H_CONTACTREL,H_CONTACT WHERE H_CONTACTREL.H_CONT_REL_ID = ? AND H_CONTACT.H_CONT_ID = H_CONTACTREL.TO_CONT_ID AND (? BETWEEN H_CONTACTREL.H_CREATE_DT AND H_CONTACTREL.H_END_DT OR (? >= H_CONTACTREL.H_CREATE_DT AND H_CONTACTREL.H_END_DT IS NULL )) AND (( ? BETWEEN H_CONTACT.H_CREATE_DT AND H_CONTACT.H_END_DT ) OR ( ? >= H_CONTACT.H_CREATE_DT AND H_CONTACT.H_END_DT IS NULL ))", pattern="tableAlias (CONTACTREL => com.dwl.tcrm.coreParty.entityObject.EObjContactRel, H_CONTACTREL => com.dwl.tcrm.coreParty.entityObject.EObjContactRel, CONTACT => com.dwl.tcrm.coreParty.entityObject.EObjContact, H_CONTACT => com.dwl.tcrm.coreParty.entityObject.EObjContact , CONTACTREL => com.ibm.daimler.dsea.entityObject.EObjXContactRelExt , H_CONTACTREL => com.ibm.daimler.dsea.entityObject.EObjXContactRelExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue3<EObjContactRel,EObjContact,EObjXContactRelExt>> getPartyRelationshipHistoryByID (Object[] parameters)
  {
    return queryIterator (getPartyRelationshipHistoryByIDStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getPartyRelationshipHistoryByIDStatementDescriptor = createStatementDescriptor (
    "getPartyRelationshipHistoryByID(Object[])",
    "SELECT H_CONTACTREL.H_CONT_REL_ID AS HIST_ID_PK, H_CONTACTREL.REL_TP_CD, H_CONTACTREL.REL_DESC, H_CONTACTREL.START_DT, H_CONTACTREL.END_DT, H_CONTACTREL.TO_CONT_ID,H_CONTACTREL.FROM_CONT_ID, H_CONTACTREL.LAST_UPDATE_DT, H_CONTACTREL.LAST_UPDATE_USER,H_CONTACTREL.REL_ASSIGN_TP_CD, H_CONTACTREL.END_REASON_TP_CD, H_CONTACTREL.LAST_UPDATE_TX_ID, H_CONTACT.CONTACT_NAME, H_CONTACTREL.XRETAILER_CODE, H_CONTACTREL.XCONTACT_ROLE, H_CONTACTREL.XCONTACT_POSITION, H_CONTACTREL.XCONTACTREL_RETAILER_FLAG, H_CONTACTREL.XSOURCE_IDENT_TP_CD, H_CONTACTREL.XMODIFY_SYS_DT, H_CONTACTREL.DELETE_FLAG FROM H_CONTACTREL,H_CONTACT WHERE H_CONTACTREL.H_CONT_REL_ID = ? AND H_CONTACT.H_CONT_ID = H_CONTACTREL.TO_CONT_ID AND (? BETWEEN H_CONTACTREL.H_CREATE_DT AND H_CONTACTREL.H_END_DT OR (? >= H_CONTACTREL.H_CREATE_DT AND H_CONTACTREL.H_END_DT IS NULL )) AND (( ? BETWEEN H_CONTACT.H_CREATE_DT AND H_CONTACT.H_END_DT ) OR ( ? >= H_CONTACT.H_CREATE_DT AND H_CONTACT.H_END_DT IS NULL ))",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"hist_id_pk", "rel_tp_cd", "rel_desc", "start_dt", "end_dt", "to_cont_id", "from_cont_id", "last_update_dt", "last_update_user", "rel_assign_tp_cd", "end_reason_tp_cd", "last_update_tx_id", "contact_name", "xretailer_code", "xcontact_role", "xcontact_position", "xcontactrel_retailer_flag", "xsource_ident_tp_cd", "xmodify_sys_dt", "delete_flag"},
    new GetPartyRelationshipHistoryByIDParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP}, {19, 0, 0, 0, 0}, {0, 0, 0, 0, 0}, {1, 1, 1, 1, 1}},
    null,
    new GetPartyRelationshipHistoryByIDRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR}, {19, 19, 255, 0, 0, 19, 19, 0, 20, 19, 19, 19, 255, 255, 255, 255, 5, 19, 0, 10}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    4);

  /**
   * @generated
   */
  public static class GetPartyRelationshipHistoryByIDParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
      setObject (stmt, 4, Types.TIMESTAMP, parameters[3], 0);
      setObject (stmt, 5, Types.TIMESTAMP, parameters[4], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetPartyRelationshipHistoryByIDRowHandler extends BaseRowHandler<ResultQueue3<EObjContactRel,EObjContact,EObjXContactRelExt>>
  {
    /**
     * @generated
     */
    public ResultQueue3<EObjContactRel,EObjContact,EObjXContactRelExt> handle (java.sql.ResultSet rs, ResultQueue3<EObjContactRel,EObjContact,EObjXContactRelExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue3<EObjContactRel,EObjContact,EObjXContactRelExt> ();

      EObjContactRel returnObject1 = new EObjContactRel ();
      returnObject1.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject1.setRelTpCd(getLongObject (rs, 2)); 
      returnObject1.setRelDesc(getString (rs, 3)); 
      returnObject1.setStartDt(getTimestamp (rs, 4)); 
      returnObject1.setEndDt(getTimestamp (rs, 5)); 
      returnObject1.setToContId(getLongObject (rs, 6)); 
      returnObject1.setFromContId(getLongObject (rs, 7)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 8)); 
      returnObject1.setLastUpdateUser(getString (rs, 9)); 
      returnObject1.setRelAssignTpCd(getLongObject (rs, 10)); 
      returnObject1.setEndReasonTpCd(getLongObject (rs, 11)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 12)); 
      returnObject.add (returnObject1);

      EObjContact returnObject2 = new EObjContact ();
      returnObject2.setContactName(getString (rs, 13)); 
      returnObject.add (returnObject2);

      EObjXContactRelExt returnObject3 = new EObjXContactRelExt ();
      returnObject3.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject3.setLastUpdateDt(getTimestamp (rs, 8)); 
      returnObject3.setLastUpdateUser(getString (rs, 9)); 
      returnObject3.setLastUpdateTxId(getLongObject (rs, 12)); 
      returnObject3.setXRetailerCode(getString (rs, 14)); 
      returnObject3.setXContactRole(getString (rs, 15)); 
      returnObject3.setXContactPosition(getString (rs, 16)); 
      returnObject3.setXContactRelRetailerFlag(getString (rs, 17)); 
      returnObject3.setXSourceIdentifier(getLongObject (rs, 18)); 
      returnObject3.setXLastModifiedSystemDate(getTimestamp (rs, 19)); 
      returnObject3.setDeleteFlag(getString (rs, 20)); 
      returnObject.add (returnObject3);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT DISTINCT A.H_CONT_REL_ID AS HIST_ID_PK, A.H_ACTION_CODE , A.H_CREATED_BY , A.H_CREATE_DT, A.H_END_DT , A.CONT_REL_ID , A.REL_TP_CD , A.REL_DESC , A.START_DT , A.END_DT , A.TO_CONT_ID , A.FROM_CONT_ID , A.LAST_UPDATE_DT , A.LAST_UPDATE_USER , A.LAST_UPDATE_TX_ID , A.REL_ASSIGN_TP_CD , A.END_REASON_TP_CD , B.CONTACT_NAME, A.XRETAILER_CODE, A.XCONTACT_ROLE, A.XCONTACT_POSITION, A.XCONTACTREL_RETAILER_FLAG, A.XSOURCE_IDENT_TP_CD, A.XMODIFY_SYS_DT, A.DELETE_FLAG FROM H_CONTACTREL A, H_CONTACT B WHERE (A.TO_CONT_ID = ? AND (B.CONT_ID = A.FROM_CONT_ID) AND (( ? BETWEEN A.H_CREATE_DT AND A.H_END_DT ) OR ( ? >= A.H_CREATE_DT AND A.H_END_DT IS NULL )) AND (( ? BETWEEN B.H_CREATE_DT AND B.H_END_DT ) OR ( ? >= B.H_CREATE_DT AND B.H_END_DT IS NULL ))) UNION ALL SELECT DISTINCT A.H_CONT_REL_ID AS HIST_ID_PK, A.H_ACTION_CODE , A.H_CREATED_BY , A.H_CREATE_DT , A.H_END_DT , A.CONT_REL_ID , A.REL_TP_CD , A.REL_DESC , A.START_DT , A.END_DT , A.TO_CONT_ID , A.FROM_CONT_ID, A.LAST_UPDATE_DT , A.LAST_UPDATE_USER, A.LAST_UPDATE_TX_ID , A.REL_ASSIGN_TP_CD , A.END_REASON_TP_CD, B.CONTACT_NAME, A.XRETAILER_CODE, A.XCONTACT_ROLE, A.XCONTACT_POSITION, A.XCONTACTREL_RETAILER_FLAG, A.XSOURCE_IDENT_TP_CD, A.XMODIFY_SYS_DT, A.DELETE_FLAG FROM H_CONTACTREL A, H_CONTACT B WHERE (A.FROM_CONT_ID = ? AND (B.H_CONT_ID = A.TO_CONT_ID) AND (( ? BETWEEN A.H_CREATE_DT AND A.H_END_DT ) OR ( ? >= A.H_CREATE_DT AND A.H_END_DT IS NULL )) AND (( ? BETWEEN B.H_CREATE_DT AND B.H_END_DT ) OR ( ? >= B.H_CREATE_DT AND B.H_END_DT IS NULL )))", pattern="<rsm><col number='1' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactRel' property='historyIdPK'></col><col number='2' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactRel' property='histActionCode'></col><col number='3' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactRel' property='histCreatedBy'></col><col number='4' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactRel' property='histCreateDt'></col><col number='5' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactRel' property='histEndDt'></col><col number='6' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactRel' property='contRelIdPK'></col><col number='7' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactRel' property='relTpCd'></col><col number='8' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactRel' property='relDesc'></col><col number='9' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactRel' property='startDt'></col><col number='10' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactRel' property='endDt'></col><col number='11' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactRel' property='toContId'></col><col number='12' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactRel' property='fromContId'></col><col number='13' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactRel' property='lastUpdateDt'></col><col number='14' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactRel' property='lastUpdateUser'></col><col number='15' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactRel' property='lastUpdateTxId'></col><col number='16' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactRel' property='relAssignTpCd'></col><col number='17' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactRel' property='endReasonTpCd'></col><col number='18' bean='com.dwl.tcrm.coreParty.entityObject.EObjContact' property='contactName'></col><col number='19' bean='com.ibm.daimler.dsea.entityObject.EObjXContactRelExt' property='XRetailerCode'></col><col number='20' bean='com.ibm.daimler.dsea.entityObject.EObjXContactRelExt' property='XContactRole'></col><col number='21' bean='com.ibm.daimler.dsea.entityObject.EObjXContactRelExt' property='XContactPosition'></col><col number='22' bean='com.ibm.daimler.dsea.entityObject.EObjXContactRelExt' property='XContactRelRetailerFlag'></col><col number='23' bean='com.ibm.daimler.dsea.entityObject.EObjXContactRelExt' property='XSourceIdentifier'></col><col number='24' bean='com.ibm.daimler.dsea.entityObject.EObjXContactRelExt' property='XLastModifiedSystemDate'></col><col number='25' bean='com.ibm.daimler.dsea.entityObject.EObjXContactRelExt' property='DeleteFlag'></col></rsm>" )
   * 
   * @generated
   */
  public Iterator<ResultQueue3<EObjContactRel,EObjContact,EObjXContactRelExt>> getPartyRelationshipsHistory (Object[] parameters)
  {
    return queryIterator (getPartyRelationshipsHistoryStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getPartyRelationshipsHistoryStatementDescriptor = createStatementDescriptor (
    "getPartyRelationshipsHistory(Object[])",
    "SELECT DISTINCT A.H_CONT_REL_ID AS HIST_ID_PK, A.H_ACTION_CODE , A.H_CREATED_BY , A.H_CREATE_DT, A.H_END_DT , A.CONT_REL_ID , A.REL_TP_CD , A.REL_DESC , A.START_DT , A.END_DT , A.TO_CONT_ID , A.FROM_CONT_ID , A.LAST_UPDATE_DT , A.LAST_UPDATE_USER , A.LAST_UPDATE_TX_ID , A.REL_ASSIGN_TP_CD , A.END_REASON_TP_CD , B.CONTACT_NAME, A.XRETAILER_CODE, A.XCONTACT_ROLE, A.XCONTACT_POSITION, A.XCONTACTREL_RETAILER_FLAG, A.XSOURCE_IDENT_TP_CD, A.XMODIFY_SYS_DT, A.DELETE_FLAG FROM H_CONTACTREL A, H_CONTACT B WHERE (A.TO_CONT_ID = ? AND (B.CONT_ID = A.FROM_CONT_ID) AND (( ? BETWEEN A.H_CREATE_DT AND A.H_END_DT ) OR ( ? >= A.H_CREATE_DT AND A.H_END_DT IS NULL )) AND (( ? BETWEEN B.H_CREATE_DT AND B.H_END_DT ) OR ( ? >= B.H_CREATE_DT AND B.H_END_DT IS NULL ))) UNION ALL SELECT DISTINCT A.H_CONT_REL_ID AS HIST_ID_PK, A.H_ACTION_CODE , A.H_CREATED_BY , A.H_CREATE_DT , A.H_END_DT , A.CONT_REL_ID , A.REL_TP_CD , A.REL_DESC , A.START_DT , A.END_DT , A.TO_CONT_ID , A.FROM_CONT_ID, A.LAST_UPDATE_DT , A.LAST_UPDATE_USER, A.LAST_UPDATE_TX_ID , A.REL_ASSIGN_TP_CD , A.END_REASON_TP_CD, B.CONTACT_NAME, A.XRETAILER_CODE, A.XCONTACT_ROLE, A.XCONTACT_POSITION, A.XCONTACTREL_RETAILER_FLAG, A.XSOURCE_IDENT_TP_CD, A.XMODIFY_SYS_DT, A.DELETE_FLAG FROM H_CONTACTREL A, H_CONTACT B WHERE (A.FROM_CONT_ID = ? AND (B.H_CONT_ID = A.TO_CONT_ID) AND (( ? BETWEEN A.H_CREATE_DT AND A.H_END_DT ) OR ( ? >= A.H_CREATE_DT AND A.H_END_DT IS NULL )) AND (( ? BETWEEN B.H_CREATE_DT AND B.H_END_DT ) OR ( ? >= B.H_CREATE_DT AND B.H_END_DT IS NULL )))",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"hist_id_pk", "h_action_code", "h_created_by", "h_create_dt", "h_end_dt", "cont_rel_id", "rel_tp_cd", "rel_desc", "start_dt", "end_dt", "to_cont_id", "from_cont_id", "last_update_dt", "last_update_user", "last_update_tx_id", "rel_assign_tp_cd", "end_reason_tp_cd", "contact_name", "xretailer_code", "xcontact_role", "xcontact_position", "xcontactrel_retailer_flag", "xsource_ident_tp_cd", "xmodify_sys_dt", "delete_flag"},
    new GetPartyRelationshipsHistoryParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP}, {19, 0, 0, 0, 0, 19, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1, 1, 1, 1}},
    null,
    new GetPartyRelationshipsHistoryRowHandler (),
    new int[][]{ {Types.BIGINT, Types.CHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR}, {19, 1, 20, 0, 0, 19, 19, 255, 0, 0, 19, 19, 0, 20, 19, 19, 19, 255, 255, 255, 255, 5, 19, 0, 10}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    5);

  /**
   * @generated
   */
  public static class GetPartyRelationshipsHistoryParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
      setObject (stmt, 4, Types.TIMESTAMP, parameters[3], 0);
      setObject (stmt, 5, Types.TIMESTAMP, parameters[4], 0);
      setObject (stmt, 6, Types.BIGINT, parameters[5], 0);
      setObject (stmt, 7, Types.TIMESTAMP, parameters[6], 0);
      setObject (stmt, 8, Types.TIMESTAMP, parameters[7], 0);
      setObject (stmt, 9, Types.TIMESTAMP, parameters[8], 0);
      setObject (stmt, 10, Types.TIMESTAMP, parameters[9], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetPartyRelationshipsHistoryRowHandler extends BaseRowHandler<ResultQueue3<EObjContactRel,EObjContact,EObjXContactRelExt>>
  {
    /**
     * @generated
     */
    public ResultQueue3<EObjContactRel,EObjContact,EObjXContactRelExt> handle (java.sql.ResultSet rs, ResultQueue3<EObjContactRel,EObjContact,EObjXContactRelExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue3<EObjContactRel,EObjContact,EObjXContactRelExt> ();

      EObjContactRel returnObject1 = new EObjContactRel ();
      returnObject1.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject1.setHistActionCode(getString (rs, 2)); 
      returnObject1.setHistCreatedBy(getString (rs, 3)); 
      returnObject1.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject1.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject1.setContRelIdPK(getLongObject (rs, 6)); 
      returnObject1.setRelTpCd(getLongObject (rs, 7)); 
      returnObject1.setRelDesc(getString (rs, 8)); 
      returnObject1.setStartDt(getTimestamp (rs, 9)); 
      returnObject1.setEndDt(getTimestamp (rs, 10)); 
      returnObject1.setToContId(getLongObject (rs, 11)); 
      returnObject1.setFromContId(getLongObject (rs, 12)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 13)); 
      returnObject1.setLastUpdateUser(getString (rs, 14)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 15)); 
      returnObject1.setRelAssignTpCd(getLongObject (rs, 16)); 
      returnObject1.setEndReasonTpCd(getLongObject (rs, 17)); 
      returnObject.add (returnObject1);

      EObjContact returnObject2 = new EObjContact ();
      returnObject2.setContactName(getString (rs, 18)); 
      returnObject.add (returnObject2);

      EObjXContactRelExt returnObject3 = new EObjXContactRelExt ();
      returnObject3.setXRetailerCode(getString (rs, 19)); 
      returnObject3.setXContactRole(getString (rs, 20)); 
      returnObject3.setXContactPosition(getString (rs, 21)); 
      returnObject3.setXContactRelRetailerFlag(getString (rs, 22)); 
      returnObject3.setXSourceIdentifier(getLongObject (rs, 23)); 
      returnObject3.setXLastModifiedSystemDate(getTimestamp (rs, 24)); 
      returnObject3.setDeleteFlag(getString (rs, 25)); 
      returnObject.add (returnObject3);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT CONTACTREL.CONT_REL_ID, CONTACTREL.REL_TP_CD, CONTACTREL.REL_DESC, CONTACTREL.START_DT, CONTACTREL.END_DT, CONTACTREL.TO_CONT_ID, CONTACTREL.FROM_CONT_ID, CONTACTREL.LAST_UPDATE_DT, CONTACTREL.LAST_UPDATE_USER, CONTACTREL.LAST_UPDATE_TX_ID, CONTACTREL.REL_ASSIGN_TP_CD, CONTACT.CONTACT_NAME, CONTACT.LAST_UPDATE_TX_ID, CONTACTREL.END_REASON_TP_CD, CONTACTREL.XRETAILER_CODE, CONTACTREL.XCONTACT_ROLE, CONTACTREL.XCONTACT_POSITION, CONTACTREL.XCONTACTREL_RETAILER_FLAG, CONTACTREL.XSOURCE_IDENT_TP_CD, CONTACTREL.XMODIFY_SYS_DT, CONTACTREL.DELETE_FLAG FROM CONTACTREL, CONTACT WHERE ((CONTACTREL.FROM_CONT_ID = ? AND CONTACT.CONT_ID = CONTACTREL.TO_CONT_ID AND (CONTACTREL.END_DT IS NULL OR CONTACTREL.END_DT > ?)) OR (CONTACTREL.TO_CONT_ID = ? AND CONTACT.CONT_ID = CONTACTREL.FROM_CONT_ID AND (CONTACTREL.END_DT IS NULL OR CONTACTREL.END_DT > ?)))", pattern="tableAlias (CONTACTREL => com.dwl.tcrm.coreParty.entityObject.EObjContactRel, H_CONTACTREL => com.dwl.tcrm.coreParty.entityObject.EObjContactRel, CONTACT => com.dwl.tcrm.coreParty.entityObject.EObjContact, H_CONTACT => com.dwl.tcrm.coreParty.entityObject.EObjContact , CONTACTREL => com.ibm.daimler.dsea.entityObject.EObjXContactRelExt , H_CONTACTREL => com.ibm.daimler.dsea.entityObject.EObjXContactRelExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue3<EObjContactRel,EObjContact,EObjXContactRelExt>> getActivePartyRelationships (Object[] parameters)
  {
    return queryIterator (getActivePartyRelationshipsStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getActivePartyRelationshipsStatementDescriptor = createStatementDescriptor (
    "getActivePartyRelationships(Object[])",
    "SELECT CONTACTREL.CONT_REL_ID, CONTACTREL.REL_TP_CD, CONTACTREL.REL_DESC, CONTACTREL.START_DT, CONTACTREL.END_DT, CONTACTREL.TO_CONT_ID, CONTACTREL.FROM_CONT_ID, CONTACTREL.LAST_UPDATE_DT, CONTACTREL.LAST_UPDATE_USER, CONTACTREL.LAST_UPDATE_TX_ID, CONTACTREL.REL_ASSIGN_TP_CD, CONTACT.CONTACT_NAME, CONTACT.LAST_UPDATE_TX_ID, CONTACTREL.END_REASON_TP_CD, CONTACTREL.XRETAILER_CODE, CONTACTREL.XCONTACT_ROLE, CONTACTREL.XCONTACT_POSITION, CONTACTREL.XCONTACTREL_RETAILER_FLAG, CONTACTREL.XSOURCE_IDENT_TP_CD, CONTACTREL.XMODIFY_SYS_DT, CONTACTREL.DELETE_FLAG FROM CONTACTREL, CONTACT WHERE ((CONTACTREL.FROM_CONT_ID = ? AND CONTACT.CONT_ID = CONTACTREL.TO_CONT_ID AND (CONTACTREL.END_DT IS NULL OR CONTACTREL.END_DT > ?)) OR (CONTACTREL.TO_CONT_ID = ? AND CONTACT.CONT_ID = CONTACTREL.FROM_CONT_ID AND (CONTACTREL.END_DT IS NULL OR CONTACTREL.END_DT > ?)))",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"cont_rel_id", "rel_tp_cd", "rel_desc", "start_dt", "end_dt", "to_cont_id", "from_cont_id", "last_update_dt", "last_update_user", "last_update_tx_id", "rel_assign_tp_cd", "contact_name", "last_update_tx_id", "end_reason_tp_cd", "xretailer_code", "xcontact_role", "xcontact_position", "xcontactrel_retailer_flag", "xsource_ident_tp_cd", "xmodify_sys_dt", "delete_flag"},
    new GetActivePartyRelationshipsParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP, Types.BIGINT, Types.TIMESTAMP}, {19, 0, 19, 0}, {0, 0, 0, 0}, {1, 1, 1, 1}},
    null,
    new GetActivePartyRelationshipsRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR}, {19, 19, 255, 0, 0, 19, 19, 0, 20, 19, 19, 255, 19, 19, 255, 255, 255, 5, 19, 0, 10}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    6);

  /**
   * @generated
   */
  public static class GetActivePartyRelationshipsParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
      setObject (stmt, 3, Types.BIGINT, parameters[2], 0);
      setObject (stmt, 4, Types.TIMESTAMP, parameters[3], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetActivePartyRelationshipsRowHandler extends BaseRowHandler<ResultQueue3<EObjContactRel,EObjContact,EObjXContactRelExt>>
  {
    /**
     * @generated
     */
    public ResultQueue3<EObjContactRel,EObjContact,EObjXContactRelExt> handle (java.sql.ResultSet rs, ResultQueue3<EObjContactRel,EObjContact,EObjXContactRelExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue3<EObjContactRel,EObjContact,EObjXContactRelExt> ();

      EObjContactRel returnObject1 = new EObjContactRel ();
      returnObject1.setContRelIdPK(getLongObject (rs, 1)); 
      returnObject1.setRelTpCd(getLongObject (rs, 2)); 
      returnObject1.setRelDesc(getString (rs, 3)); 
      returnObject1.setStartDt(getTimestamp (rs, 4)); 
      returnObject1.setEndDt(getTimestamp (rs, 5)); 
      returnObject1.setToContId(getLongObject (rs, 6)); 
      returnObject1.setFromContId(getLongObject (rs, 7)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 8)); 
      returnObject1.setLastUpdateUser(getString (rs, 9)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 10)); 
      returnObject1.setRelAssignTpCd(getLongObject (rs, 11)); 
      returnObject1.setEndReasonTpCd(getLongObject (rs, 14)); 
      returnObject.add (returnObject1);

      EObjContact returnObject2 = new EObjContact ();
      returnObject2.setContactName(getString (rs, 12)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 13)); 
      returnObject.add (returnObject2);

      EObjXContactRelExt returnObject3 = new EObjXContactRelExt ();
      returnObject3.setLastUpdateDt(getTimestamp (rs, 8)); 
      returnObject3.setLastUpdateUser(getString (rs, 9)); 
      returnObject3.setLastUpdateTxId(getLongObject (rs, 10)); 
      returnObject3.setXRetailerCode(getString (rs, 15)); 
      returnObject3.setXContactRole(getString (rs, 16)); 
      returnObject3.setXContactPosition(getString (rs, 17)); 
      returnObject3.setXContactRelRetailerFlag(getString (rs, 18)); 
      returnObject3.setXSourceIdentifier(getLongObject (rs, 19)); 
      returnObject3.setXLastModifiedSystemDate(getTimestamp (rs, 20)); 
      returnObject3.setDeleteFlag(getString (rs, 21)); 
      returnObject.add (returnObject3);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT CONTACTREL.CONT_REL_ID, CONTACTREL.REL_TP_CD,CONTACTREL.REL_DESC, CONTACTREL.START_DT, CONTACTREL.END_DT, CONTACTREL.TO_CONT_ID,CONTACTREL.FROM_CONT_ID, CONTACTREL.LAST_UPDATE_DT, CONTACTREL.LAST_UPDATE_USER,CONTACTREL.LAST_UPDATE_TX_ID,CONTACTREL.REL_ASSIGN_TP_CD, CONTACT.CONTACT_NAME,CONTACT.LAST_UPDATE_TX_ID,CONTACTREL.END_REASON_TP_CD, CONTACTREL.XRETAILER_CODE, CONTACTREL.XCONTACT_ROLE, CONTACTREL.XCONTACT_POSITION, CONTACTREL.XCONTACTREL_RETAILER_FLAG, CONTACTREL.XSOURCE_IDENT_TP_CD, CONTACTREL.XMODIFY_SYS_DT, CONTACTREL.DELETE_FLAG FROM CONTACTREL,CONTACT WHERE ((CONTACTREL.FROM_CONT_ID =? AND CONTACT.CONT_ID = CONTACTREL.TO_CONT_ID ) OR (CONTACTREL.TO_CONT_ID = ? AND CONTACT.CONT_ID = CONTACTREL.FROM_CONT_ID)) AND (CONTACTREL.END_DT < ? )", pattern="tableAlias (CONTACTREL => com.dwl.tcrm.coreParty.entityObject.EObjContactRel, H_CONTACTREL => com.dwl.tcrm.coreParty.entityObject.EObjContactRel, CONTACT => com.dwl.tcrm.coreParty.entityObject.EObjContact, H_CONTACT => com.dwl.tcrm.coreParty.entityObject.EObjContact , CONTACTREL => com.ibm.daimler.dsea.entityObject.EObjXContactRelExt , H_CONTACTREL => com.ibm.daimler.dsea.entityObject.EObjXContactRelExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue3<EObjContactRel,EObjContact,EObjXContactRelExt>> getInactivePartyRelationships (Object[] parameters)
  {
    return queryIterator (getInactivePartyRelationshipsStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getInactivePartyRelationshipsStatementDescriptor = createStatementDescriptor (
    "getInactivePartyRelationships(Object[])",
    "SELECT CONTACTREL.CONT_REL_ID, CONTACTREL.REL_TP_CD,CONTACTREL.REL_DESC, CONTACTREL.START_DT, CONTACTREL.END_DT, CONTACTREL.TO_CONT_ID,CONTACTREL.FROM_CONT_ID, CONTACTREL.LAST_UPDATE_DT, CONTACTREL.LAST_UPDATE_USER,CONTACTREL.LAST_UPDATE_TX_ID,CONTACTREL.REL_ASSIGN_TP_CD, CONTACT.CONTACT_NAME,CONTACT.LAST_UPDATE_TX_ID,CONTACTREL.END_REASON_TP_CD, CONTACTREL.XRETAILER_CODE, CONTACTREL.XCONTACT_ROLE, CONTACTREL.XCONTACT_POSITION, CONTACTREL.XCONTACTREL_RETAILER_FLAG, CONTACTREL.XSOURCE_IDENT_TP_CD, CONTACTREL.XMODIFY_SYS_DT, CONTACTREL.DELETE_FLAG FROM CONTACTREL,CONTACT WHERE ((CONTACTREL.FROM_CONT_ID =? AND CONTACT.CONT_ID = CONTACTREL.TO_CONT_ID ) OR (CONTACTREL.TO_CONT_ID = ? AND CONTACT.CONT_ID = CONTACTREL.FROM_CONT_ID)) AND (CONTACTREL.END_DT < ? )",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"cont_rel_id", "rel_tp_cd", "rel_desc", "start_dt", "end_dt", "to_cont_id", "from_cont_id", "last_update_dt", "last_update_user", "last_update_tx_id", "rel_assign_tp_cd", "contact_name", "last_update_tx_id", "end_reason_tp_cd", "xretailer_code", "xcontact_role", "xcontact_position", "xcontactrel_retailer_flag", "xsource_ident_tp_cd", "xmodify_sys_dt", "delete_flag"},
    new GetInactivePartyRelationshipsParameterHandler (),
    new int[][]{{Types.BIGINT, Types.BIGINT, Types.TIMESTAMP}, {19, 19, 0}, {0, 0, 0}, {1, 1, 1}},
    null,
    new GetInactivePartyRelationshipsRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR}, {19, 19, 255, 0, 0, 19, 19, 0, 20, 19, 19, 255, 19, 19, 255, 255, 255, 5, 19, 0, 10}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    7);

  /**
   * @generated
   */
  public static class GetInactivePartyRelationshipsParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.BIGINT, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetInactivePartyRelationshipsRowHandler extends BaseRowHandler<ResultQueue3<EObjContactRel,EObjContact,EObjXContactRelExt>>
  {
    /**
     * @generated
     */
    public ResultQueue3<EObjContactRel,EObjContact,EObjXContactRelExt> handle (java.sql.ResultSet rs, ResultQueue3<EObjContactRel,EObjContact,EObjXContactRelExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue3<EObjContactRel,EObjContact,EObjXContactRelExt> ();

      EObjContactRel returnObject1 = new EObjContactRel ();
      returnObject1.setContRelIdPK(getLongObject (rs, 1)); 
      returnObject1.setRelTpCd(getLongObject (rs, 2)); 
      returnObject1.setRelDesc(getString (rs, 3)); 
      returnObject1.setStartDt(getTimestamp (rs, 4)); 
      returnObject1.setEndDt(getTimestamp (rs, 5)); 
      returnObject1.setToContId(getLongObject (rs, 6)); 
      returnObject1.setFromContId(getLongObject (rs, 7)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 8)); 
      returnObject1.setLastUpdateUser(getString (rs, 9)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 10)); 
      returnObject1.setRelAssignTpCd(getLongObject (rs, 11)); 
      returnObject1.setEndReasonTpCd(getLongObject (rs, 14)); 
      returnObject.add (returnObject1);

      EObjContact returnObject2 = new EObjContact ();
      returnObject2.setContactName(getString (rs, 12)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 13)); 
      returnObject.add (returnObject2);

      EObjXContactRelExt returnObject3 = new EObjXContactRelExt ();
      returnObject3.setLastUpdateDt(getTimestamp (rs, 8)); 
      returnObject3.setLastUpdateUser(getString (rs, 9)); 
      returnObject3.setLastUpdateTxId(getLongObject (rs, 10)); 
      returnObject3.setXRetailerCode(getString (rs, 15)); 
      returnObject3.setXContactRole(getString (rs, 16)); 
      returnObject3.setXContactPosition(getString (rs, 17)); 
      returnObject3.setXContactRelRetailerFlag(getString (rs, 18)); 
      returnObject3.setXSourceIdentifier(getLongObject (rs, 19)); 
      returnObject3.setXLastModifiedSystemDate(getTimestamp (rs, 20)); 
      returnObject3.setDeleteFlag(getString (rs, 21)); 
      returnObject.add (returnObject3);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT CONTACTREL.CONT_REL_ID,CONTACTREL.REL_TP_CD,CONTACTREL.REL_DESC, CONTACTREL.START_DT, CONTACTREL.END_DT, CONTACTREL.TO_CONT_ID, CONTACTREL.FROM_CONT_ID, CONTACTREL.LAST_UPDATE_DT,CONTACTREL.LAST_UPDATE_USER, CONTACTREL.LAST_UPDATE_TX_ID,CONTACTREL.REL_ASSIGN_TP_CD, CONTACT.CONTACT_NAME, CONTACT.LAST_UPDATE_TX_ID, CONTACTREL.END_REASON_TP_CD, CONTACTREL.XRETAILER_CODE, CONTACTREL.XCONTACT_ROLE, CONTACTREL.XCONTACT_POSITION, CONTACTREL.XCONTACTREL_RETAILER_FLAG, CONTACTREL.XSOURCE_IDENT_TP_CD, CONTACTREL.XMODIFY_SYS_DT, CONTACTREL.DELETE_FLAG FROM CONTACTREL, CONTACT WHERE (( CONTACTREL.TO_CONT_ID = ? AND CONTACT.CONT_ID = CONTACTREL.FROM_CONT_ID) OR (CONTACTREL.FROM_CONT_ID =? AND CONTACT.CONT_ID = CONTACTREL.TO_CONT_ID))", pattern="tableAlias (CONTACTREL => com.dwl.tcrm.coreParty.entityObject.EObjContactRel, H_CONTACTREL => com.dwl.tcrm.coreParty.entityObject.EObjContactRel, CONTACT => com.dwl.tcrm.coreParty.entityObject.EObjContact, H_CONTACT => com.dwl.tcrm.coreParty.entityObject.EObjContact , CONTACTREL => com.ibm.daimler.dsea.entityObject.EObjXContactRelExt , H_CONTACTREL => com.ibm.daimler.dsea.entityObject.EObjXContactRelExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue3<EObjContactRel,EObjContact,EObjXContactRelExt>> getPartyRelationships (Object[] parameters)
  {
    return queryIterator (getPartyRelationshipsStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getPartyRelationshipsStatementDescriptor = createStatementDescriptor (
    "getPartyRelationships(Object[])",
    "SELECT CONTACTREL.CONT_REL_ID,CONTACTREL.REL_TP_CD,CONTACTREL.REL_DESC, CONTACTREL.START_DT, CONTACTREL.END_DT, CONTACTREL.TO_CONT_ID, CONTACTREL.FROM_CONT_ID, CONTACTREL.LAST_UPDATE_DT,CONTACTREL.LAST_UPDATE_USER, CONTACTREL.LAST_UPDATE_TX_ID,CONTACTREL.REL_ASSIGN_TP_CD, CONTACT.CONTACT_NAME, CONTACT.LAST_UPDATE_TX_ID, CONTACTREL.END_REASON_TP_CD, CONTACTREL.XRETAILER_CODE, CONTACTREL.XCONTACT_ROLE, CONTACTREL.XCONTACT_POSITION, CONTACTREL.XCONTACTREL_RETAILER_FLAG, CONTACTREL.XSOURCE_IDENT_TP_CD, CONTACTREL.XMODIFY_SYS_DT, CONTACTREL.DELETE_FLAG FROM CONTACTREL, CONTACT WHERE (( CONTACTREL.TO_CONT_ID = ? AND CONTACT.CONT_ID = CONTACTREL.FROM_CONT_ID) OR (CONTACTREL.FROM_CONT_ID =? AND CONTACT.CONT_ID = CONTACTREL.TO_CONT_ID))",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"cont_rel_id", "rel_tp_cd", "rel_desc", "start_dt", "end_dt", "to_cont_id", "from_cont_id", "last_update_dt", "last_update_user", "last_update_tx_id", "rel_assign_tp_cd", "contact_name", "last_update_tx_id", "end_reason_tp_cd", "xretailer_code", "xcontact_role", "xcontact_position", "xcontactrel_retailer_flag", "xsource_ident_tp_cd", "xmodify_sys_dt", "delete_flag"},
    new GetPartyRelationshipsParameterHandler (),
    new int[][]{{Types.BIGINT, Types.BIGINT}, {19, 19}, {0, 0}, {1, 1}},
    null,
    new GetPartyRelationshipsRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR}, {19, 19, 255, 0, 0, 19, 19, 0, 20, 19, 19, 255, 19, 19, 255, 255, 255, 5, 19, 0, 10}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    8);

  /**
   * @generated
   */
  public static class GetPartyRelationshipsParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.BIGINT, parameters[1], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetPartyRelationshipsRowHandler extends BaseRowHandler<ResultQueue3<EObjContactRel,EObjContact,EObjXContactRelExt>>
  {
    /**
     * @generated
     */
    public ResultQueue3<EObjContactRel,EObjContact,EObjXContactRelExt> handle (java.sql.ResultSet rs, ResultQueue3<EObjContactRel,EObjContact,EObjXContactRelExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue3<EObjContactRel,EObjContact,EObjXContactRelExt> ();

      EObjContactRel returnObject1 = new EObjContactRel ();
      returnObject1.setContRelIdPK(getLongObject (rs, 1)); 
      returnObject1.setRelTpCd(getLongObject (rs, 2)); 
      returnObject1.setRelDesc(getString (rs, 3)); 
      returnObject1.setStartDt(getTimestamp (rs, 4)); 
      returnObject1.setEndDt(getTimestamp (rs, 5)); 
      returnObject1.setToContId(getLongObject (rs, 6)); 
      returnObject1.setFromContId(getLongObject (rs, 7)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 8)); 
      returnObject1.setLastUpdateUser(getString (rs, 9)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 10)); 
      returnObject1.setRelAssignTpCd(getLongObject (rs, 11)); 
      returnObject1.setEndReasonTpCd(getLongObject (rs, 14)); 
      returnObject.add (returnObject1);

      EObjContact returnObject2 = new EObjContact ();
      returnObject2.setContactName(getString (rs, 12)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 13)); 
      returnObject.add (returnObject2);

      EObjXContactRelExt returnObject3 = new EObjXContactRelExt ();
      returnObject3.setLastUpdateDt(getTimestamp (rs, 8)); 
      returnObject3.setLastUpdateUser(getString (rs, 9)); 
      returnObject3.setLastUpdateTxId(getLongObject (rs, 10)); 
      returnObject3.setXRetailerCode(getString (rs, 15)); 
      returnObject3.setXContactRole(getString (rs, 16)); 
      returnObject3.setXContactPosition(getString (rs, 17)); 
      returnObject3.setXContactRelRetailerFlag(getString (rs, 18)); 
      returnObject3.setXSourceIdentifier(getLongObject (rs, 19)); 
      returnObject3.setXLastModifiedSystemDate(getTimestamp (rs, 20)); 
      returnObject3.setDeleteFlag(getString (rs, 21)); 
      returnObject.add (returnObject3);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT DISTINCT A.H_CONT_REL_ID AS HIST_ID_PK, A.H_ACTION_CODE, A.H_CREATED_BY, A.H_CREATE_DT, A.H_END_DT, A.CONT_REL_ID, A.REL_TP_CD, A.REL_DESC, A.START_DT, A.END_DT, A.TO_CONT_ID, A.FROM_CONT_ID, A.LAST_UPDATE_DT, A.LAST_UPDATE_USER, A.LAST_UPDATE_TX_ID, A.REL_ASSIGN_TP_CD, A.END_REASON_TP_CD, B.CONTACT_NAME, A.XRETAILER_CODE, A.XCONTACT_ROLE, A.XCONTACT_POSITION, A.XCONTACTREL_RETAILER_FLAG, A.XSOURCE_IDENT_TP_CD, A.XMODIFY_SYS_DT, A.DELETE_FLAG FROM H_CONTACTREL A, H_CONTACT B WHERE ((A.TO_CONT_ID = ? AND B.CONT_ID = A.FROM_CONT_ID) OR (A.FROM_CONT_ID = ? AND B.CONT_ID = A.TO_CONT_ID)) AND ( A.H_CREATE_DT BETWEEN ? AND ? ) AND ( B.H_CREATE_DT BETWEEN ? AND ? )", pattern="tableAlias (CONTACTREL => com.dwl.tcrm.coreParty.entityObject.EObjContactRel, H_CONTACTREL => com.dwl.tcrm.coreParty.entityObject.EObjContactRel, CONTACT => com.dwl.tcrm.coreParty.entityObject.EObjContact, H_CONTACT => com.dwl.tcrm.coreParty.entityObject.EObjContact , CONTACTREL => com.ibm.daimler.dsea.entityObject.EObjXContactRelExt , H_CONTACTREL => com.ibm.daimler.dsea.entityObject.EObjXContactRelExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue3<EObjContactRel,EObjContact,EObjXContactRelExt>> getPartyRelationshipsImage (Object[] parameters)
  {
    return queryIterator (getPartyRelationshipsImageStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getPartyRelationshipsImageStatementDescriptor = createStatementDescriptor (
    "getPartyRelationshipsImage(Object[])",
    "SELECT DISTINCT A.H_CONT_REL_ID AS HIST_ID_PK, A.H_ACTION_CODE, A.H_CREATED_BY, A.H_CREATE_DT, A.H_END_DT, A.CONT_REL_ID, A.REL_TP_CD, A.REL_DESC, A.START_DT, A.END_DT, A.TO_CONT_ID, A.FROM_CONT_ID, A.LAST_UPDATE_DT, A.LAST_UPDATE_USER, A.LAST_UPDATE_TX_ID, A.REL_ASSIGN_TP_CD, A.END_REASON_TP_CD, B.CONTACT_NAME, A.XRETAILER_CODE, A.XCONTACT_ROLE, A.XCONTACT_POSITION, A.XCONTACTREL_RETAILER_FLAG, A.XSOURCE_IDENT_TP_CD, A.XMODIFY_SYS_DT, A.DELETE_FLAG FROM H_CONTACTREL A, H_CONTACT B WHERE ((A.TO_CONT_ID = ? AND B.CONT_ID = A.FROM_CONT_ID) OR (A.FROM_CONT_ID = ? AND B.CONT_ID = A.TO_CONT_ID)) AND ( A.H_CREATE_DT BETWEEN ? AND ? ) AND ( B.H_CREATE_DT BETWEEN ? AND ? )",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"hist_id_pk", "h_action_code", "h_created_by", "h_create_dt", "h_end_dt", "cont_rel_id", "rel_tp_cd", "rel_desc", "start_dt", "end_dt", "to_cont_id", "from_cont_id", "last_update_dt", "last_update_user", "last_update_tx_id", "rel_assign_tp_cd", "end_reason_tp_cd", "contact_name", "xretailer_code", "xcontact_role", "xcontact_position", "xcontactrel_retailer_flag", "xsource_ident_tp_cd", "xmodify_sys_dt", "delete_flag"},
    new GetPartyRelationshipsImageParameterHandler (),
    new int[][]{{Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP}, {19, 19, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1}},
    null,
    new GetPartyRelationshipsImageRowHandler (),
    new int[][]{ {Types.BIGINT, Types.CHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR}, {19, 1, 20, 0, 0, 19, 19, 255, 0, 0, 19, 19, 0, 20, 19, 19, 19, 255, 255, 255, 255, 5, 19, 0, 10}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    9);

  /**
   * @generated
   */
  public static class GetPartyRelationshipsImageParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.BIGINT, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
      setObject (stmt, 4, Types.TIMESTAMP, parameters[3], 0);
      setObject (stmt, 5, Types.TIMESTAMP, parameters[4], 0);
      setObject (stmt, 6, Types.TIMESTAMP, parameters[5], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetPartyRelationshipsImageRowHandler extends BaseRowHandler<ResultQueue3<EObjContactRel,EObjContact,EObjXContactRelExt>>
  {
    /**
     * @generated
     */
    public ResultQueue3<EObjContactRel,EObjContact,EObjXContactRelExt> handle (java.sql.ResultSet rs, ResultQueue3<EObjContactRel,EObjContact,EObjXContactRelExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue3<EObjContactRel,EObjContact,EObjXContactRelExt> ();

      EObjContactRel returnObject1 = new EObjContactRel ();
      returnObject1.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject1.setHistActionCode(getString (rs, 2)); 
      returnObject1.setHistCreatedBy(getString (rs, 3)); 
      returnObject1.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject1.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject1.setContRelIdPK(getLongObject (rs, 6)); 
      returnObject1.setRelTpCd(getLongObject (rs, 7)); 
      returnObject1.setRelDesc(getString (rs, 8)); 
      returnObject1.setStartDt(getTimestamp (rs, 9)); 
      returnObject1.setEndDt(getTimestamp (rs, 10)); 
      returnObject1.setToContId(getLongObject (rs, 11)); 
      returnObject1.setFromContId(getLongObject (rs, 12)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 13)); 
      returnObject1.setLastUpdateUser(getString (rs, 14)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 15)); 
      returnObject1.setRelAssignTpCd(getLongObject (rs, 16)); 
      returnObject1.setEndReasonTpCd(getLongObject (rs, 17)); 
      returnObject.add (returnObject1);

      EObjContact returnObject2 = new EObjContact ();
      returnObject2.setContactName(getString (rs, 18)); 
      returnObject.add (returnObject2);

      EObjXContactRelExt returnObject3 = new EObjXContactRelExt ();
      returnObject3.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject3.setHistActionCode(getString (rs, 2)); 
      returnObject3.setHistCreatedBy(getString (rs, 3)); 
      returnObject3.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject3.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject3.setLastUpdateDt(getTimestamp (rs, 13)); 
      returnObject3.setLastUpdateUser(getString (rs, 14)); 
      returnObject3.setLastUpdateTxId(getLongObject (rs, 15)); 
      returnObject3.setXRetailerCode(getString (rs, 19)); 
      returnObject3.setXContactRole(getString (rs, 20)); 
      returnObject3.setXContactPosition(getString (rs, 21)); 
      returnObject3.setXContactRelRetailerFlag(getString (rs, 22)); 
      returnObject3.setXSourceIdentifier(getLongObject (rs, 23)); 
      returnObject3.setXLastModifiedSystemDate(getTimestamp (rs, 24)); 
      returnObject3.setDeleteFlag(getString (rs, 25)); 
      returnObject.add (returnObject3);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT DISTINCT A.CONT_REL_ID, A.LAST_UPDATE_DT, A.XRETAILER_CODE, A.XCONTACT_ROLE, A.XCONTACT_POSITION, A.XCONTACTREL_RETAILER_FLAG, A.XSOURCE_IDENT_TP_CD, A.XMODIFY_SYS_DT, A.DELETE_FLAG FROM H_CONTACTREL A, H_CONTACT B WHERE ((A.TO_CONT_ID = ? AND B.CONT_ID = A.FROM_CONT_ID) OR (A.FROM_CONT_ID = ? AND B.CONT_ID = A.TO_CONT_ID)) AND ( A.H_CREATE_DT BETWEEN ? AND ? )", pattern="tableAlias (CONTACTREL => com.dwl.tcrm.coreParty.entityObject.EObjContactRel, H_CONTACTREL => com.dwl.tcrm.coreParty.entityObject.EObjContactRel, CONTACT => com.dwl.tcrm.coreParty.entityObject.EObjContact, H_CONTACT => com.dwl.tcrm.coreParty.entityObject.EObjContact , CONTACTREL => com.ibm.daimler.dsea.entityObject.EObjXContactRelExt , H_CONTACTREL => com.ibm.daimler.dsea.entityObject.EObjXContactRelExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue2<EObjContactRel,EObjXContactRelExt>> getPartyRelationshipsLightImage (Object[] parameters)
  {
    return queryIterator (getPartyRelationshipsLightImageStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getPartyRelationshipsLightImageStatementDescriptor = createStatementDescriptor (
    "getPartyRelationshipsLightImage(Object[])",
    "SELECT DISTINCT A.CONT_REL_ID, A.LAST_UPDATE_DT, A.XRETAILER_CODE, A.XCONTACT_ROLE, A.XCONTACT_POSITION, A.XCONTACTREL_RETAILER_FLAG, A.XSOURCE_IDENT_TP_CD, A.XMODIFY_SYS_DT, A.DELETE_FLAG FROM H_CONTACTREL A, H_CONTACT B WHERE ((A.TO_CONT_ID = ? AND B.CONT_ID = A.FROM_CONT_ID) OR (A.FROM_CONT_ID = ? AND B.CONT_ID = A.TO_CONT_ID)) AND ( A.H_CREATE_DT BETWEEN ? AND ? )",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"cont_rel_id", "last_update_dt", "xretailer_code", "xcontact_role", "xcontact_position", "xcontactrel_retailer_flag", "xsource_ident_tp_cd", "xmodify_sys_dt", "delete_flag"},
    new GetPartyRelationshipsLightImageParameterHandler (),
    new int[][]{{Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP}, {19, 19, 0, 0}, {0, 0, 0, 0}, {1, 1, 1, 1}},
    null,
    new GetPartyRelationshipsLightImageRowHandler (),
    new int[][]{ {Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR}, {19, 0, 255, 255, 255, 5, 19, 0, 10}, {0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    10);

  /**
   * @generated
   */
  public static class GetPartyRelationshipsLightImageParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.BIGINT, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
      setObject (stmt, 4, Types.TIMESTAMP, parameters[3], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetPartyRelationshipsLightImageRowHandler extends BaseRowHandler<ResultQueue2<EObjContactRel,EObjXContactRelExt>>
  {
    /**
     * @generated
     */
    public ResultQueue2<EObjContactRel,EObjXContactRelExt> handle (java.sql.ResultSet rs, ResultQueue2<EObjContactRel,EObjXContactRelExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue2<EObjContactRel,EObjXContactRelExt> ();

      EObjContactRel returnObject1 = new EObjContactRel ();
      returnObject1.setContRelIdPK(getLongObject (rs, 1)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 2)); 
      returnObject.add (returnObject1);

      EObjXContactRelExt returnObject2 = new EObjXContactRelExt ();
      returnObject2.setLastUpdateDt(getTimestamp (rs, 2)); 
      returnObject2.setXRetailerCode(getString (rs, 3)); 
      returnObject2.setXContactRole(getString (rs, 4)); 
      returnObject2.setXContactPosition(getString (rs, 5)); 
      returnObject2.setXContactRelRetailerFlag(getString (rs, 6)); 
      returnObject2.setXSourceIdentifier(getLongObject (rs, 7)); 
      returnObject2.setXLastModifiedSystemDate(getTimestamp (rs, 8)); 
      returnObject2.setDeleteFlag(getString (rs, 9)); 
      returnObject.add (returnObject2);

    
      return returnObject;
    }
  }

}
