package com.ibm.daimler.dsea.entityObject;

import com.ibm.pdq.runtime.generator.BaseParameterHandler;
import java.util.Iterator;
import com.ibm.daimler.dsea.entityObject.EObjXCompanyIdentification;
import java.sql.PreparedStatement;
import com.ibm.pdq.runtime.statement.StatementDescriptor;
import com.ibm.pdq.runtime.generator.BaseData;
import java.sql.SQLException;
import com.ibm.pdq.annotation.Metadata;
import com.ibm.pdq.runtime.generator.BaseRowHandler;
import com.ibm.pdq.runtime.statement.SqlStatementType;
import java.sql.Types;


/**
 * <!-- begin-user-doc -->
 * 
 * <!-- end-user-doc -->
 * 
 * @generated
 */
public class EObjXCompanyIdentificationDataImpl  extends BaseData implements EObjXCompanyIdentificationData
{

  /**
   * @generated
   */
  public static final String generatorVersion = "3.200.75";

  /**
   * @generated
   */
  public static final String identifier = "EObjXCompanyIdentificationData";

  /**
   * @generated
   */
  public static final long generationTime = 0x000001635e65f62dL;

  /**
   * @generated
   */
  public static final String collection = "NULLID";

  /**
   * @generated
   */
  public static final String packageVersion = null;

  /**
   * @generated
   */
  public static final boolean forceSingleBindIsolation = false;

  /**
   * @generated
   */
  public EObjXCompanyIdentificationDataImpl()
  {
    super();
  } 

  /**
   * @generated
   */
  public String getGeneratorVersion()
  {
    return generatorVersion;
  }

  /**
   * @Select( sql="select COMPANYIDENTIFICATIONPK_ID, COMPANYMAGIC_NUMBER, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from XCOMPANYIDENTIFICATION where COMPANYIDENTIFICATIONPK_ID = ? " )
   * 
   * @generated
   */
  public Iterator<EObjXCompanyIdentification> getEObjXCompanyIdentification (Long companyIdentificationpkId)
  {
    return queryIterator (getEObjXCompanyIdentificationStatementDescriptor, companyIdentificationpkId);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getEObjXCompanyIdentificationStatementDescriptor = createStatementDescriptor (
    "getEObjXCompanyIdentification(Long)",
    "select COMPANYIDENTIFICATIONPK_ID, COMPANYMAGIC_NUMBER, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from XCOMPANYIDENTIFICATION where COMPANYIDENTIFICATIONPK_ID = ? ",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"companyidentificationpk_id", "companymagic_number", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetEObjXCompanyIdentificationParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetEObjXCompanyIdentificationRowHandler (),
    new int[][]{ {Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 250, 0, 20, 19}, {0, 0, 0, 0, 0}, {0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    1);

  /**
   * @generated
   */
  public static class GetEObjXCompanyIdentificationParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setLong (stmt, 1, Types.BIGINT, (Long)parameters[0]);
    }
  }

  /**
   * @generated
   */
  public static class GetEObjXCompanyIdentificationRowHandler extends BaseRowHandler<EObjXCompanyIdentification>
  {
    /**
     * @generated
     */
    public EObjXCompanyIdentification handle (java.sql.ResultSet rs, EObjXCompanyIdentification returnObject) throws java.sql.SQLException
    {
      returnObject = new EObjXCompanyIdentification ();
      returnObject.setCompanyIdentificationpkId(getLongObject (rs, 1)); 
      returnObject.setCompanyMagicNumber(getString (rs, 2)); 
      returnObject.setLastUpdateDt(getTimestamp (rs, 3)); 
      returnObject.setLastUpdateUser(getString (rs, 4)); 
      returnObject.setLastUpdateTxId(getLongObject (rs, 5)); 
    
      return returnObject;
    }
  }

  /**
   * @Update( sql="insert into XCOMPANYIDENTIFICATION (COMPANYIDENTIFICATIONPK_ID, COMPANYMAGIC_NUMBER, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( :companyIdentificationpkId, :companyMagicNumber, :lastUpdateDt, :lastUpdateUser, :lastUpdateTxId)" )
   * 
   * @generated
   */
  public int createEObjXCompanyIdentification (EObjXCompanyIdentification e)
  {
    return update (createEObjXCompanyIdentificationStatementDescriptor, e);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor createEObjXCompanyIdentificationStatementDescriptor = createStatementDescriptor (
    "createEObjXCompanyIdentification(com.ibm.daimler.dsea.entityObject.EObjXCompanyIdentification)",
    "insert into XCOMPANYIDENTIFICATION (COMPANYIDENTIFICATIONPK_ID, COMPANYMAGIC_NUMBER, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values(  ? ,  ? ,  ? ,  ? ,  ? )",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.INSERT,
    null,
    new CreateEObjXCompanyIdentificationParameterHandler (),
    new int[][]{{Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 250, 0, 0, 19}, {0, 0, 0, 0, 0}, {1, 1, 1, 1, 1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    2);

  /**
   * @generated
   */
  public static class CreateEObjXCompanyIdentificationParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      EObjXCompanyIdentification bean0 = (EObjXCompanyIdentification) parameters[0];
      setLong (stmt, 1, Types.BIGINT, (Long)bean0.getCompanyIdentificationpkId());
      setString (stmt, 2, Types.VARCHAR, (String)bean0.getCompanyMagicNumber());
      setTimestamp (stmt, 3, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUpdateDt());
      setString (stmt, 4, Types.VARCHAR, (String)bean0.getLastUpdateUser());
      setLong (stmt, 5, Types.BIGINT, (Long)bean0.getLastUpdateTxId());
    }
  }

  /**
   * @Update( sql="update XCOMPANYIDENTIFICATION set COMPANYMAGIC_NUMBER = :companyMagicNumber, LAST_UPDATE_DT = :lastUpdateDt, LAST_UPDATE_USER = :lastUpdateUser, LAST_UPDATE_TX_ID = :lastUpdateTxId where COMPANYIDENTIFICATIONPK_ID = :companyIdentificationpkId and LAST_UPDATE_DT = :oldLastUpdateDt" )
   * 
   * @generated
   */
  public int updateEObjXCompanyIdentification (EObjXCompanyIdentification e)
  {
    return update (updateEObjXCompanyIdentificationStatementDescriptor, e);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor updateEObjXCompanyIdentificationStatementDescriptor = createStatementDescriptor (
    "updateEObjXCompanyIdentification(com.ibm.daimler.dsea.entityObject.EObjXCompanyIdentification)",
    "update XCOMPANYIDENTIFICATION set COMPANYMAGIC_NUMBER =  ? , LAST_UPDATE_DT =  ? , LAST_UPDATE_USER =  ? , LAST_UPDATE_TX_ID =  ?  where COMPANYIDENTIFICATIONPK_ID =  ?  and LAST_UPDATE_DT =  ? ",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.UPDATE,
    null,
    new UpdateEObjXCompanyIdentificationParameterHandler (),
    new int[][]{{Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP}, {250, 0, 0, 19, 19, 0}, {0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    3);

  /**
   * @generated
   */
  public static class UpdateEObjXCompanyIdentificationParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      EObjXCompanyIdentification bean0 = (EObjXCompanyIdentification) parameters[0];
      setString (stmt, 1, Types.VARCHAR, (String)bean0.getCompanyMagicNumber());
      setTimestamp (stmt, 2, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUpdateDt());
      setString (stmt, 3, Types.VARCHAR, (String)bean0.getLastUpdateUser());
      setLong (stmt, 4, Types.BIGINT, (Long)bean0.getLastUpdateTxId());
      setLong (stmt, 5, Types.BIGINT, (Long)bean0.getCompanyIdentificationpkId());
      setTimestamp (stmt, 6, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getOldLastUpdateDt());
    }
  }

  /**
   * @Update( sql="delete from XCOMPANYIDENTIFICATION where COMPANYIDENTIFICATIONPK_ID = ?" )
   * 
   * @generated
   */
  public int deleteEObjXCompanyIdentification (Long companyIdentificationpkId)
  {
    return update (deleteEObjXCompanyIdentificationStatementDescriptor, companyIdentificationpkId);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor deleteEObjXCompanyIdentificationStatementDescriptor = createStatementDescriptor (
    "deleteEObjXCompanyIdentification(Long)",
    "delete from XCOMPANYIDENTIFICATION where COMPANYIDENTIFICATIONPK_ID = ?",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.DELETE,
    null,
    new DeleteEObjXCompanyIdentificationParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    4);

  /**
   * @generated
   */
  public static class DeleteEObjXCompanyIdentificationParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setLong (stmt, 1, Types.BIGINT, (Long)parameters[0]);
    }
  }

}
