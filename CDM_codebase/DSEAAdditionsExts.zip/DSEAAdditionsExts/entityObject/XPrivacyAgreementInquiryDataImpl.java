package com.ibm.daimler.dsea.entityObject;

import com.ibm.pdq.runtime.generator.BaseParameterHandler;
import java.util.Iterator;
import com.ibm.mdm.base.db.ResultQueue1;
import java.sql.PreparedStatement;
import com.ibm.pdq.runtime.statement.StatementDescriptor;
import com.ibm.daimler.dsea.entityObject.EObjXPrivacyAgreement;
import com.ibm.pdq.runtime.generator.BaseData;
import java.sql.SQLException;
import com.ibm.pdq.annotation.Metadata;
import com.ibm.pdq.runtime.generator.BaseRowHandler;
import com.ibm.pdq.runtime.statement.SqlStatementType;
import java.sql.Types;


@SuppressWarnings("unchecked")

/**
 * <!-- begin-user-doc -->
 * 
 * <!-- end-user-doc -->
 * 
 * @generated
 */
public class XPrivacyAgreementInquiryDataImpl  extends BaseData implements XPrivacyAgreementInquiryData
{

  /**
   * @generated
   */
  public static final String generatorVersion = "3.200.75";

  /**
   * @generated
   */
  public static final String identifier = "XPrivacyAgreementInquiryData";

  /**
   * @generated
   */
  public static final long generationTime = 0x0000015e13f84c08L;

  /**
   * @generated
   */
  public static final String collection = "NULLID";

  /**
   * @generated
   */
  public static final String packageVersion = null;

  /**
   * @generated
   */
  public static final boolean forceSingleBindIsolation = false;

  /**
   * @generated
   */
  public XPrivacyAgreementInquiryDataImpl()
  {
    super();
  } 

  /**
   * @generated
   */
  public String getGeneratorVersion()
  {
    return generatorVersion;
  }

  /**
   * @Select( sql="SELECT r.PRIVAGREEMENTPK_ID PRIVAGREEMENTPK_ID, r.LOCATION_GROUP_ID LOCATION_GROUP_ID, r.ACTION_TP_CD ACTION_TP_CD, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.START_DT START_DT, r.END_DT END_DT, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XPRIVAGREEMENT r WHERE r.PRIVAGREEMENTPK_ID = ? ", pattern="tableAlias (XPRIVAGREEMENT => com.ibm.daimler.dsea.entityObject.EObjXPrivacyAgreement, H_XPRIVAGREEMENT => com.ibm.daimler.dsea.entityObject.EObjXPrivacyAgreement)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue1<EObjXPrivacyAgreement>> getXPrivacyAgreement (Object[] parameters)
  {
    return queryIterator (getXPrivacyAgreementStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getXPrivacyAgreementStatementDescriptor = createStatementDescriptor (
    "getXPrivacyAgreement(Object[])",
    "SELECT r.PRIVAGREEMENTPK_ID PRIVAGREEMENTPK_ID, r.LOCATION_GROUP_ID LOCATION_GROUP_ID, r.ACTION_TP_CD ACTION_TP_CD, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.START_DT START_DT, r.END_DT END_DT, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XPRIVAGREEMENT r WHERE r.PRIVAGREEMENTPK_ID = ? ",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"privagreementpk_id", "location_group_id", "action_tp_cd", "source_ident_tp_cd", "start_dt", "end_dt", "modify_sys_dt", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetXPrivacyAgreementParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetXPrivacyAgreementRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 19, 19, 19, 0, 0, 0, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    1);

  /**
   * @generated
   */
  public static class GetXPrivacyAgreementParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetXPrivacyAgreementRowHandler extends BaseRowHandler<ResultQueue1<EObjXPrivacyAgreement>>
  {
    /**
     * @generated
     */
    public ResultQueue1<EObjXPrivacyAgreement> handle (java.sql.ResultSet rs, ResultQueue1<EObjXPrivacyAgreement> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue1<EObjXPrivacyAgreement> ();

      EObjXPrivacyAgreement returnObject1 = new EObjXPrivacyAgreement ();
      returnObject1.setPrivacyAgreementpkId(getLongObject (rs, 1)); 
      returnObject1.setLocationGroupId(getLongObject (rs, 2)); 
      returnObject1.setAction(getLongObject (rs, 3)); 
      returnObject1.setSourceIdentifier(getLongObject (rs, 4)); 
      returnObject1.setStartDate(getTimestamp (rs, 5)); 
      returnObject1.setEndDate(getTimestamp (rs, 6)); 
      returnObject1.setLastModifiedSystemDate(getTimestamp (rs, 7)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 8)); 
      returnObject1.setLastUpdateUser(getString (rs, 9)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 10)); 
      returnObject.add (returnObject1);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT r.H_PRIVAGREEMENTPK_ID hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.PRIVAGREEMENTPK_ID PRIVAGREEMENTPK_ID, r.LOCATION_GROUP_ID LOCATION_GROUP_ID, r.ACTION_TP_CD ACTION_TP_CD, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.START_DT START_DT, r.END_DT END_DT, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XPRIVAGREEMENT r WHERE r.H_PRIVAGREEMENTPK_ID = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))", pattern="tableAlias (XPRIVAGREEMENT => com.ibm.daimler.dsea.entityObject.EObjXPrivacyAgreement, H_XPRIVAGREEMENT => com.ibm.daimler.dsea.entityObject.EObjXPrivacyAgreement)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue1<EObjXPrivacyAgreement>> getXPrivacyAgreementHistory (Object[] parameters)
  {
    return queryIterator (getXPrivacyAgreementHistoryStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getXPrivacyAgreementHistoryStatementDescriptor = createStatementDescriptor (
    "getXPrivacyAgreementHistory(Object[])",
    "SELECT r.H_PRIVAGREEMENTPK_ID hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.PRIVAGREEMENTPK_ID PRIVAGREEMENTPK_ID, r.LOCATION_GROUP_ID LOCATION_GROUP_ID, r.ACTION_TP_CD ACTION_TP_CD, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.START_DT START_DT, r.END_DT END_DT, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XPRIVAGREEMENT r WHERE r.H_PRIVAGREEMENTPK_ID = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"historyidpk", "h_action_code", "h_created_by", "h_create_dt", "h_end_dt", "privagreementpk_id", "location_group_id", "action_tp_cd", "source_ident_tp_cd", "start_dt", "end_dt", "modify_sys_dt", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetXPrivacyAgreementHistoryParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP}, {19, 0, 0}, {0, 0, 0}, {1, 1, 1}},
    null,
    new GetXPrivacyAgreementHistoryRowHandler (),
    new int[][]{ {Types.BIGINT, Types.CHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 1, 20, 0, 0, 19, 19, 19, 19, 0, 0, 0, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    2);

  /**
   * @generated
   */
  public static class GetXPrivacyAgreementHistoryParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetXPrivacyAgreementHistoryRowHandler extends BaseRowHandler<ResultQueue1<EObjXPrivacyAgreement>>
  {
    /**
     * @generated
     */
    public ResultQueue1<EObjXPrivacyAgreement> handle (java.sql.ResultSet rs, ResultQueue1<EObjXPrivacyAgreement> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue1<EObjXPrivacyAgreement> ();

      EObjXPrivacyAgreement returnObject1 = new EObjXPrivacyAgreement ();
      returnObject1.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject1.setHistActionCode(getString (rs, 2)); 
      returnObject1.setHistCreatedBy(getString (rs, 3)); 
      returnObject1.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject1.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject1.setPrivacyAgreementpkId(getLongObject (rs, 6)); 
      returnObject1.setLocationGroupId(getLongObject (rs, 7)); 
      returnObject1.setAction(getLongObject (rs, 8)); 
      returnObject1.setSourceIdentifier(getLongObject (rs, 9)); 
      returnObject1.setStartDate(getTimestamp (rs, 10)); 
      returnObject1.setEndDate(getTimestamp (rs, 11)); 
      returnObject1.setLastModifiedSystemDate(getTimestamp (rs, 12)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 13)); 
      returnObject1.setLastUpdateUser(getString (rs, 14)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 15)); 
      returnObject.add (returnObject1);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT r.PRIVAGREEMENTPK_ID PRIVAGREEMENTPK_ID, r.LOCATION_GROUP_ID LOCATION_GROUP_ID, r.ACTION_TP_CD ACTION_TP_CD, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.START_DT START_DT, r.END_DT END_DT, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XPRIVAGREEMENT r WHERE r.LOCATION_GROUP_ID = ? ", pattern="tableAlias (XPRIVAGREEMENT => com.ibm.daimler.dsea.entityObject.EObjXPrivacyAgreement, H_XPRIVAGREEMENT => com.ibm.daimler.dsea.entityObject.EObjXPrivacyAgreement)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue1<EObjXPrivacyAgreement>> getXPrivAgreementByLocationGroupId (Object[] parameters)
  {
    return queryIterator (getXPrivAgreementByLocationGroupIdStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getXPrivAgreementByLocationGroupIdStatementDescriptor = createStatementDescriptor (
    "getXPrivAgreementByLocationGroupId(Object[])",
    "SELECT r.PRIVAGREEMENTPK_ID PRIVAGREEMENTPK_ID, r.LOCATION_GROUP_ID LOCATION_GROUP_ID, r.ACTION_TP_CD ACTION_TP_CD, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.START_DT START_DT, r.END_DT END_DT, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XPRIVAGREEMENT r WHERE r.LOCATION_GROUP_ID = ? ",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"privagreementpk_id", "location_group_id", "action_tp_cd", "source_ident_tp_cd", "start_dt", "end_dt", "modify_sys_dt", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetXPrivAgreementByLocationGroupIdParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetXPrivAgreementByLocationGroupIdRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 19, 19, 19, 0, 0, 0, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    3);

  /**
   * @generated
   */
  public static class GetXPrivAgreementByLocationGroupIdParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetXPrivAgreementByLocationGroupIdRowHandler extends BaseRowHandler<ResultQueue1<EObjXPrivacyAgreement>>
  {
    /**
     * @generated
     */
    public ResultQueue1<EObjXPrivacyAgreement> handle (java.sql.ResultSet rs, ResultQueue1<EObjXPrivacyAgreement> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue1<EObjXPrivacyAgreement> ();

      EObjXPrivacyAgreement returnObject1 = new EObjXPrivacyAgreement ();
      returnObject1.setPrivacyAgreementpkId(getLongObject (rs, 1)); 
      returnObject1.setLocationGroupId(getLongObject (rs, 2)); 
      returnObject1.setAction(getLongObject (rs, 3)); 
      returnObject1.setSourceIdentifier(getLongObject (rs, 4)); 
      returnObject1.setStartDate(getTimestamp (rs, 5)); 
      returnObject1.setEndDate(getTimestamp (rs, 6)); 
      returnObject1.setLastModifiedSystemDate(getTimestamp (rs, 7)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 8)); 
      returnObject1.setLastUpdateUser(getString (rs, 9)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 10)); 
      returnObject.add (returnObject1);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT r.H_PRIVAGREEMENTPK_ID hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.PRIVAGREEMENTPK_ID PRIVAGREEMENTPK_ID, r.LOCATION_GROUP_ID LOCATION_GROUP_ID, r.ACTION_TP_CD ACTION_TP_CD, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.START_DT START_DT, r.END_DT END_DT, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XPRIVAGREEMENT r WHERE r.LOCATION_GROUP_ID = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))", pattern="tableAlias (XPRIVAGREEMENT => com.ibm.daimler.dsea.entityObject.EObjXPrivacyAgreement, H_XPRIVAGREEMENT => com.ibm.daimler.dsea.entityObject.EObjXPrivacyAgreement)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue1<EObjXPrivacyAgreement>> getXPrivAgreementByLocationGroupIdHistory (Object[] parameters)
  {
    return queryIterator (getXPrivAgreementByLocationGroupIdHistoryStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getXPrivAgreementByLocationGroupIdHistoryStatementDescriptor = createStatementDescriptor (
    "getXPrivAgreementByLocationGroupIdHistory(Object[])",
    "SELECT r.H_PRIVAGREEMENTPK_ID hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.PRIVAGREEMENTPK_ID PRIVAGREEMENTPK_ID, r.LOCATION_GROUP_ID LOCATION_GROUP_ID, r.ACTION_TP_CD ACTION_TP_CD, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.START_DT START_DT, r.END_DT END_DT, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XPRIVAGREEMENT r WHERE r.LOCATION_GROUP_ID = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"historyidpk", "h_action_code", "h_created_by", "h_create_dt", "h_end_dt", "privagreementpk_id", "location_group_id", "action_tp_cd", "source_ident_tp_cd", "start_dt", "end_dt", "modify_sys_dt", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetXPrivAgreementByLocationGroupIdHistoryParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP}, {19, 0, 0}, {0, 0, 0}, {1, 1, 1}},
    null,
    new GetXPrivAgreementByLocationGroupIdHistoryRowHandler (),
    new int[][]{ {Types.BIGINT, Types.CHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 1, 20, 0, 0, 19, 19, 19, 19, 0, 0, 0, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    4);

  /**
   * @generated
   */
  public static class GetXPrivAgreementByLocationGroupIdHistoryParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetXPrivAgreementByLocationGroupIdHistoryRowHandler extends BaseRowHandler<ResultQueue1<EObjXPrivacyAgreement>>
  {
    /**
     * @generated
     */
    public ResultQueue1<EObjXPrivacyAgreement> handle (java.sql.ResultSet rs, ResultQueue1<EObjXPrivacyAgreement> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue1<EObjXPrivacyAgreement> ();

      EObjXPrivacyAgreement returnObject1 = new EObjXPrivacyAgreement ();
      returnObject1.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject1.setHistActionCode(getString (rs, 2)); 
      returnObject1.setHistCreatedBy(getString (rs, 3)); 
      returnObject1.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject1.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject1.setPrivacyAgreementpkId(getLongObject (rs, 6)); 
      returnObject1.setLocationGroupId(getLongObject (rs, 7)); 
      returnObject1.setAction(getLongObject (rs, 8)); 
      returnObject1.setSourceIdentifier(getLongObject (rs, 9)); 
      returnObject1.setStartDate(getTimestamp (rs, 10)); 
      returnObject1.setEndDate(getTimestamp (rs, 11)); 
      returnObject1.setLastModifiedSystemDate(getTimestamp (rs, 12)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 13)); 
      returnObject1.setLastUpdateUser(getString (rs, 14)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 15)); 
      returnObject.add (returnObject1);

    
      return returnObject;
    }
  }

}
