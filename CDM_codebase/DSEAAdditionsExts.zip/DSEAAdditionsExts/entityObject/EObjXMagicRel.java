/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[1a75e23e03105334f239af09b25e7d1d]
 */

package com.ibm.daimler.dsea.entityObject;

import com.dwl.base.EObjCommon;
import com.ibm.mdm.base.db.DataType;
import com.ibm.pdq.annotation.Column;
import com.ibm.pdq.annotation.Table;


import com.ibm.pdq.annotation.Id;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * The entity object corresponding to the XMagicRel business object. This entity
 * object should include all the attributes as defined by the business object.
 * 
 * @generated
 */
@SuppressWarnings("serial")
@Table(name=EObjXMagicRel.tableName)
public class EObjXMagicRel extends EObjCommon {

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public static final String tableName = "XMAGICREL";
    
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String xMagicRelpkIdColumn = "XMAGIC_RELPK_ID";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String xMagicRelpkIdJdbcType = "BIGINT";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    xMagicRelpkIdPrecision = 19;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String uCIDColumn = "UCID";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String uCIDJdbcType = "VARCHAR";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    uCIDPrecision = 250;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String goldenMagicColumn = "GOLDEN_MAGIC";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String goldenMagicJdbcType = "VARCHAR";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    goldenMagicPrecision = 250;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String oldMagicColumn = "OLD_MAGIC";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String oldMagicJdbcType = "VARCHAR";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    oldMagicPrecision = 250;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String oldMagicRetailerColumn = "OLD_MAGIC_RETAILER";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String oldMagicRetailerJdbcType = "VARCHAR";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    oldMagicRetailerPrecision = 250;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected Long xMagicRelpkId;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String uCID;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String goldenMagic;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String oldMagic;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String oldMagicRetailer;



    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Default constructor.     
     *
     * @generated
     */
    public EObjXMagicRel() {
        super();
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xMagicRelpkId attribute. 
     *
     * @generated
     */
    @Id
    @Column(name=xMagicRelpkIdColumn)
    @DataType(jdbcType=xMagicRelpkIdJdbcType, precision=xMagicRelpkIdPrecision)
    public Long getXMagicRelpkId (){
        return xMagicRelpkId;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xMagicRelpkId attribute. 
     *
     * @param xMagicRelpkId
     *     The new value of XMagicRelpkId. 
     * @generated
     */
    public void setXMagicRelpkId( Long xMagicRelpkId ){
        this.xMagicRelpkId = xMagicRelpkId;
    
        super.setIdPK(xMagicRelpkId);
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the uCID attribute. 
     *
     * @generated
     */
    @Column(name=uCIDColumn)
    @DataType(jdbcType=uCIDJdbcType, precision=uCIDPrecision)
    public String getUCID (){
        return uCID;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the uCID attribute. 
     *
     * @param uCID
     *     The new value of UCID. 
     * @generated
     */
    public void setUCID( String uCID ){
        this.uCID = uCID;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the goldenMagic attribute. 
     *
     * @generated
     */
    @Column(name=goldenMagicColumn)
    @DataType(jdbcType=goldenMagicJdbcType, precision=goldenMagicPrecision)
    public String getGoldenMagic (){
        return goldenMagic;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the goldenMagic attribute. 
     *
     * @param goldenMagic
     *     The new value of GoldenMagic. 
     * @generated
     */
    public void setGoldenMagic( String goldenMagic ){
        this.goldenMagic = goldenMagic;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the oldMagic attribute. 
     *
     * @generated
     */
    @Column(name=oldMagicColumn)
    @DataType(jdbcType=oldMagicJdbcType, precision=oldMagicPrecision)
    public String getOldMagic (){
        return oldMagic;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the oldMagic attribute. 
     *
     * @param oldMagic
     *     The new value of OldMagic. 
     * @generated
     */
    public void setOldMagic( String oldMagic ){
        this.oldMagic = oldMagic;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the oldMagicRetailer attribute. 
     *
     * @generated
     */
    @Column(name=oldMagicRetailerColumn)
    @DataType(jdbcType=oldMagicRetailerJdbcType, precision=oldMagicRetailerPrecision)
    public String getOldMagicRetailer (){
        return oldMagicRetailer;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the oldMagicRetailer attribute. 
     *
     * @param oldMagicRetailer
     *     The new value of OldMagicRetailer. 
     * @generated
     */
    public void setOldMagicRetailer( String oldMagicRetailer ){
        this.oldMagicRetailer = oldMagicRetailer;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the primary key. 
     *
     * @param aUniqueId
     *     The new value of the primary key. 
     * @generated
   */
	public void setPrimaryKey(Object aUniqueId) {
    this.setXMagicRelpkId((Long)aUniqueId);
  }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the primary key.
     *
     * @generated
     */
	public Object getPrimaryKey() {
    return this.getXMagicRelpkId();
  }
	 
}


