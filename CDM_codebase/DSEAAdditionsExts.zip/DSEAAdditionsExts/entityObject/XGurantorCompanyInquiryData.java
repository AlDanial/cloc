/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[eb87269544390dbcc5de2fabe747b799]
 */

package com.ibm.daimler.dsea.entityObject;


import com.ibm.mdm.base.db.ResultQueue1;
import java.util.Iterator;
import com.ibm.mdm.base.db.EntityMapping;
import com.ibm.pdq.annotation.Select;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * @generated
 */
public interface XGurantorCompanyInquiryData {
  
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String tableAliasString = "tableAlias (" + 
                                            "XGURANTORCOMPANY => com.ibm.daimler.dsea.entityObject.EObjXGurantorCompany, " +
                                            "H_XGURANTORCOMPANY => com.ibm.daimler.dsea.entityObject.EObjXGurantorCompany" +
                                            ")";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getXGurantorCompanySql = "SELECT r.XGurantor_Companypk_Id XGurantor_Companypk_Id, r.CONTRACT_DETAILS_ID CONTRACT_DETAILS_ID, r.BPID BPID, r.CAN_NUMBER CAN_NUMBER, r.INDUSTRY_TP_CD INDUSTRY_TP_CD, r.COMPANY_NAME COMPANY_NAME, r.COMPANY_NAME_LOCAL COMPANY_NAME_LOCAL, r.ADDR_USAGE_TP_CD ADDR_USAGE_TP_CD, r.ADDR_LINE_ONE ADDR_LINE_ONE, r.ADDR_LINE_TWO ADDR_LINE_TWO, r.ADDR_LINE_THREE ADDR_LINE_THREE, r.POSTAL_CODE POSTAL_CODE, r.CITY_NAME CITY_NAME, r.RESIDENCE_NUMBER RESIDENCE_NUMBER, r.COUNTRY_TP_CD COUNTRY_TP_CD, r.BUILDING_NAME BUILDING_NAME, r.STREET_NAME STREET_NAME, r.STREET_NUMBER STREET_NUMBER, r.MOBILE_NUMBER MOBILE_NUMBER, r.HOME_PHONE_NUMBER HOME_PHONE_NUMBER, r.WORK_PHONE_NUMBER WORK_PHONE_NUMBER, r.WORK_PHONE_NUMBER_EXT WORK_PHONE_NUMBER_EXT, r.FAX FAX, r.EMAIL EMAIL, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.START_DT START_DT, r.END_DT END_DT, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XGURANTORCOMPANY r WHERE r.XGurantor_Companypk_Id = ? ";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXGurantorCompanyParameters =
    "EObjXGurantorCompany.XGurantorCompanypkId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXGurantorCompanyResults =
    "EObjXGurantorCompany.XGurantorCompanypkId," +
    "EObjXGurantorCompany.ContractDetailsId," +
    "EObjXGurantorCompany.BPID," +
    "EObjXGurantorCompany.CANNumber," +
    "EObjXGurantorCompany.Industry," +
    "EObjXGurantorCompany.CompanyName," +
    "EObjXGurantorCompany.CompanyNameLocal," +
    "EObjXGurantorCompany.AddressUsage," +
    "EObjXGurantorCompany.AddressLineOne," +
    "EObjXGurantorCompany.AddressLineTwo," +
    "EObjXGurantorCompany.AddressLineThree," +
    "EObjXGurantorCompany.PostalCode," +
    "EObjXGurantorCompany.CityName," +
    "EObjXGurantorCompany.ResidenceNumber," +
    "EObjXGurantorCompany.Country," +
    "EObjXGurantorCompany.BuildingName," +
    "EObjXGurantorCompany.StreetName," +
    "EObjXGurantorCompany.StreetNumber," +
    "EObjXGurantorCompany.MobileNumber," +
    "EObjXGurantorCompany.HomePhoneNumber," +
    "EObjXGurantorCompany.WorkPhoneNumber," +
    "EObjXGurantorCompany.WorkPhoneNumberExtension," +
    "EObjXGurantorCompany.Fax," +
    "EObjXGurantorCompany.Email," +
    "EObjXGurantorCompany.SourceIdentifier," +
    "EObjXGurantorCompany.StartDate," +
    "EObjXGurantorCompany.EndDate," +
    "EObjXGurantorCompany.LastModifiedSystemDate," +
    "EObjXGurantorCompany.lastUpdateDt," +
    "EObjXGurantorCompany.lastUpdateUser," +
    "EObjXGurantorCompany.lastUpdateTxId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getXGurantorCompanyHistorySql = "SELECT r.H_XGurantor_Companypk_Id hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.XGurantor_Companypk_Id XGurantor_Companypk_Id, r.CONTRACT_DETAILS_ID CONTRACT_DETAILS_ID, r.BPID BPID, r.CAN_NUMBER CAN_NUMBER, r.INDUSTRY_TP_CD INDUSTRY_TP_CD, r.COMPANY_NAME COMPANY_NAME, r.COMPANY_NAME_LOCAL COMPANY_NAME_LOCAL, r.ADDR_USAGE_TP_CD ADDR_USAGE_TP_CD, r.ADDR_LINE_ONE ADDR_LINE_ONE, r.ADDR_LINE_TWO ADDR_LINE_TWO, r.ADDR_LINE_THREE ADDR_LINE_THREE, r.POSTAL_CODE POSTAL_CODE, r.CITY_NAME CITY_NAME, r.RESIDENCE_NUMBER RESIDENCE_NUMBER, r.COUNTRY_TP_CD COUNTRY_TP_CD, r.BUILDING_NAME BUILDING_NAME, r.STREET_NAME STREET_NAME, r.STREET_NUMBER STREET_NUMBER, r.MOBILE_NUMBER MOBILE_NUMBER, r.HOME_PHONE_NUMBER HOME_PHONE_NUMBER, r.WORK_PHONE_NUMBER WORK_PHONE_NUMBER, r.WORK_PHONE_NUMBER_EXT WORK_PHONE_NUMBER_EXT, r.FAX FAX, r.EMAIL EMAIL, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.START_DT START_DT, r.END_DT END_DT, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XGURANTORCOMPANY r WHERE r.H_XGurantor_Companypk_Id = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXGurantorCompanyHistoryParameters =
    "EObjXGurantorCompany.XGurantorCompanypkId," +
    "EObjXGurantorCompany.lastUpdateDt," +
    "EObjXGurantorCompany.lastUpdateDt";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXGurantorCompanyHistoryResults =
    "EObjXGurantorCompany.historyIdPK," +
    "EObjXGurantorCompany.histActionCode," +
    "EObjXGurantorCompany.histCreatedBy," +
    "EObjXGurantorCompany.histCreateDt," +
    "EObjXGurantorCompany.histEndDt," +
    "EObjXGurantorCompany.XGurantorCompanypkId," +
    "EObjXGurantorCompany.ContractDetailsId," +
    "EObjXGurantorCompany.BPID," +
    "EObjXGurantorCompany.CANNumber," +
    "EObjXGurantorCompany.Industry," +
    "EObjXGurantorCompany.CompanyName," +
    "EObjXGurantorCompany.CompanyNameLocal," +
    "EObjXGurantorCompany.AddressUsage," +
    "EObjXGurantorCompany.AddressLineOne," +
    "EObjXGurantorCompany.AddressLineTwo," +
    "EObjXGurantorCompany.AddressLineThree," +
    "EObjXGurantorCompany.PostalCode," +
    "EObjXGurantorCompany.CityName," +
    "EObjXGurantorCompany.ResidenceNumber," +
    "EObjXGurantorCompany.Country," +
    "EObjXGurantorCompany.BuildingName," +
    "EObjXGurantorCompany.StreetName," +
    "EObjXGurantorCompany.StreetNumber," +
    "EObjXGurantorCompany.MobileNumber," +
    "EObjXGurantorCompany.HomePhoneNumber," +
    "EObjXGurantorCompany.WorkPhoneNumber," +
    "EObjXGurantorCompany.WorkPhoneNumberExtension," +
    "EObjXGurantorCompany.Fax," +
    "EObjXGurantorCompany.Email," +
    "EObjXGurantorCompany.SourceIdentifier," +
    "EObjXGurantorCompany.StartDate," +
    "EObjXGurantorCompany.EndDate," +
    "EObjXGurantorCompany.LastModifiedSystemDate," +
    "EObjXGurantorCompany.lastUpdateDt," +
    "EObjXGurantorCompany.lastUpdateUser," +
    "EObjXGurantorCompany.lastUpdateTxId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getAllXGurantorCompanyByContractDetailsIdSql = "SELECT r.XGurantor_Companypk_Id XGurantor_Companypk_Id, r.CONTRACT_DETAILS_ID CONTRACT_DETAILS_ID, r.BPID BPID, r.CAN_NUMBER CAN_NUMBER, r.INDUSTRY_TP_CD INDUSTRY_TP_CD, r.COMPANY_NAME COMPANY_NAME, r.COMPANY_NAME_LOCAL COMPANY_NAME_LOCAL, r.ADDR_USAGE_TP_CD ADDR_USAGE_TP_CD, r.ADDR_LINE_ONE ADDR_LINE_ONE, r.ADDR_LINE_TWO ADDR_LINE_TWO, r.ADDR_LINE_THREE ADDR_LINE_THREE, r.POSTAL_CODE POSTAL_CODE, r.CITY_NAME CITY_NAME, r.RESIDENCE_NUMBER RESIDENCE_NUMBER, r.COUNTRY_TP_CD COUNTRY_TP_CD, r.BUILDING_NAME BUILDING_NAME, r.STREET_NAME STREET_NAME, r.STREET_NUMBER STREET_NUMBER, r.MOBILE_NUMBER MOBILE_NUMBER, r.HOME_PHONE_NUMBER HOME_PHONE_NUMBER, r.WORK_PHONE_NUMBER WORK_PHONE_NUMBER, r.WORK_PHONE_NUMBER_EXT WORK_PHONE_NUMBER_EXT, r.FAX FAX, r.EMAIL EMAIL, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.START_DT START_DT, r.END_DT END_DT, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XGURANTORCOMPANY r WHERE r.CONTRACT_DETAILS_ID = ? ";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getAllXGurantorCompanyByContractDetailsIdParameters =
    "EObjXGurantorCompany.ContractDetailsId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getAllXGurantorCompanyByContractDetailsIdResults =
    "EObjXGurantorCompany.XGurantorCompanypkId," +
    "EObjXGurantorCompany.ContractDetailsId," +
    "EObjXGurantorCompany.BPID," +
    "EObjXGurantorCompany.CANNumber," +
    "EObjXGurantorCompany.Industry," +
    "EObjXGurantorCompany.CompanyName," +
    "EObjXGurantorCompany.CompanyNameLocal," +
    "EObjXGurantorCompany.AddressUsage," +
    "EObjXGurantorCompany.AddressLineOne," +
    "EObjXGurantorCompany.AddressLineTwo," +
    "EObjXGurantorCompany.AddressLineThree," +
    "EObjXGurantorCompany.PostalCode," +
    "EObjXGurantorCompany.CityName," +
    "EObjXGurantorCompany.ResidenceNumber," +
    "EObjXGurantorCompany.Country," +
    "EObjXGurantorCompany.BuildingName," +
    "EObjXGurantorCompany.StreetName," +
    "EObjXGurantorCompany.StreetNumber," +
    "EObjXGurantorCompany.MobileNumber," +
    "EObjXGurantorCompany.HomePhoneNumber," +
    "EObjXGurantorCompany.WorkPhoneNumber," +
    "EObjXGurantorCompany.WorkPhoneNumberExtension," +
    "EObjXGurantorCompany.Fax," +
    "EObjXGurantorCompany.Email," +
    "EObjXGurantorCompany.SourceIdentifier," +
    "EObjXGurantorCompany.StartDate," +
    "EObjXGurantorCompany.EndDate," +
    "EObjXGurantorCompany.LastModifiedSystemDate," +
    "EObjXGurantorCompany.lastUpdateDt," +
    "EObjXGurantorCompany.lastUpdateUser," +
    "EObjXGurantorCompany.lastUpdateTxId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getAllXGurantorCompanyByContractDetailsIdHistorySql = "SELECT r.H_XGurantor_Companypk_Id hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.XGurantor_Companypk_Id XGurantor_Companypk_Id, r.CONTRACT_DETAILS_ID CONTRACT_DETAILS_ID, r.BPID BPID, r.CAN_NUMBER CAN_NUMBER, r.INDUSTRY_TP_CD INDUSTRY_TP_CD, r.COMPANY_NAME COMPANY_NAME, r.COMPANY_NAME_LOCAL COMPANY_NAME_LOCAL, r.ADDR_USAGE_TP_CD ADDR_USAGE_TP_CD, r.ADDR_LINE_ONE ADDR_LINE_ONE, r.ADDR_LINE_TWO ADDR_LINE_TWO, r.ADDR_LINE_THREE ADDR_LINE_THREE, r.POSTAL_CODE POSTAL_CODE, r.CITY_NAME CITY_NAME, r.RESIDENCE_NUMBER RESIDENCE_NUMBER, r.COUNTRY_TP_CD COUNTRY_TP_CD, r.BUILDING_NAME BUILDING_NAME, r.STREET_NAME STREET_NAME, r.STREET_NUMBER STREET_NUMBER, r.MOBILE_NUMBER MOBILE_NUMBER, r.HOME_PHONE_NUMBER HOME_PHONE_NUMBER, r.WORK_PHONE_NUMBER WORK_PHONE_NUMBER, r.WORK_PHONE_NUMBER_EXT WORK_PHONE_NUMBER_EXT, r.FAX FAX, r.EMAIL EMAIL, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.START_DT START_DT, r.END_DT END_DT, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XGURANTORCOMPANY r WHERE r.CONTRACT_DETAILS_ID = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getAllXGurantorCompanyByContractDetailsIdHistoryParameters =
    "EObjXGurantorCompany.ContractDetailsId," +
    "EObjXGurantorCompany.lastUpdateDt," +
    "EObjXGurantorCompany.lastUpdateDt";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getAllXGurantorCompanyByContractDetailsIdHistoryResults =
    "EObjXGurantorCompany.historyIdPK," +
    "EObjXGurantorCompany.histActionCode," +
    "EObjXGurantorCompany.histCreatedBy," +
    "EObjXGurantorCompany.histCreateDt," +
    "EObjXGurantorCompany.histEndDt," +
    "EObjXGurantorCompany.XGurantorCompanypkId," +
    "EObjXGurantorCompany.ContractDetailsId," +
    "EObjXGurantorCompany.BPID," +
    "EObjXGurantorCompany.CANNumber," +
    "EObjXGurantorCompany.Industry," +
    "EObjXGurantorCompany.CompanyName," +
    "EObjXGurantorCompany.CompanyNameLocal," +
    "EObjXGurantorCompany.AddressUsage," +
    "EObjXGurantorCompany.AddressLineOne," +
    "EObjXGurantorCompany.AddressLineTwo," +
    "EObjXGurantorCompany.AddressLineThree," +
    "EObjXGurantorCompany.PostalCode," +
    "EObjXGurantorCompany.CityName," +
    "EObjXGurantorCompany.ResidenceNumber," +
    "EObjXGurantorCompany.Country," +
    "EObjXGurantorCompany.BuildingName," +
    "EObjXGurantorCompany.StreetName," +
    "EObjXGurantorCompany.StreetNumber," +
    "EObjXGurantorCompany.MobileNumber," +
    "EObjXGurantorCompany.HomePhoneNumber," +
    "EObjXGurantorCompany.WorkPhoneNumber," +
    "EObjXGurantorCompany.WorkPhoneNumberExtension," +
    "EObjXGurantorCompany.Fax," +
    "EObjXGurantorCompany.Email," +
    "EObjXGurantorCompany.SourceIdentifier," +
    "EObjXGurantorCompany.StartDate," +
    "EObjXGurantorCompany.EndDate," +
    "EObjXGurantorCompany.LastModifiedSystemDate," +
    "EObjXGurantorCompany.lastUpdateDt," +
    "EObjXGurantorCompany.lastUpdateUser," +
    "EObjXGurantorCompany.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getXGurantorCompanySql, pattern=tableAliasString)
  @EntityMapping(parameters=getXGurantorCompanyParameters, results=getXGurantorCompanyResults)
  Iterator<ResultQueue1<EObjXGurantorCompany>> getXGurantorCompany(Object[] parameters);  


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getXGurantorCompanyHistorySql, pattern=tableAliasString)
  @EntityMapping(parameters=getXGurantorCompanyHistoryParameters, results=getXGurantorCompanyHistoryResults)
  Iterator<ResultQueue1<EObjXGurantorCompany>> getXGurantorCompanyHistory(Object[] parameters);  


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getAllXGurantorCompanyByContractDetailsIdSql, pattern=tableAliasString)
  @EntityMapping(parameters=getAllXGurantorCompanyByContractDetailsIdParameters, results=getAllXGurantorCompanyByContractDetailsIdResults)
  Iterator<ResultQueue1<EObjXGurantorCompany>> getAllXGurantorCompanyByContractDetailsId(Object[] parameters);  


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getAllXGurantorCompanyByContractDetailsIdHistorySql, pattern=tableAliasString)
  @EntityMapping(parameters=getAllXGurantorCompanyByContractDetailsIdHistoryParameters, results=getAllXGurantorCompanyByContractDetailsIdHistoryResults)
  Iterator<ResultQueue1<EObjXGurantorCompany>> getAllXGurantorCompanyByContractDetailsIdHistory(Object[] parameters);  


}


