package com.ibm.daimler.dsea.entityObject;

import com.ibm.pdq.runtime.generator.BaseParameterHandler;
import java.util.Iterator;
import java.sql.PreparedStatement;
import com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleKOR;
import com.ibm.pdq.runtime.statement.StatementDescriptor;
import com.ibm.pdq.runtime.generator.BaseData;
import java.sql.SQLException;
import com.ibm.pdq.annotation.Metadata;
import com.ibm.pdq.runtime.generator.BaseRowHandler;
import com.ibm.pdq.runtime.statement.SqlStatementType;
import java.sql.Types;


/**
 * <!-- begin-user-doc -->
 * 
 * <!-- end-user-doc -->
 * 
 * @generated
 */
public class EObjXCustomerVehicleKORDataImpl  extends BaseData implements EObjXCustomerVehicleKORData
{

  /**
   * @generated
   */
  public static final String generatorVersion = "3.200.75";

  /**
   * @generated
   */
  public static final String identifier = "EObjXCustomerVehicleKORData";

  /**
   * @generated
   */
  public static final long generationTime = 0x00000166f7ce1938L;

  /**
   * @generated
   */
  public static final String collection = "NULLID";

  /**
   * @generated
   */
  public static final String packageVersion = null;

  /**
   * @generated
   */
  public static final boolean forceSingleBindIsolation = false;

  /**
   * @generated
   */
  public EObjXCustomerVehicleKORDataImpl()
  {
    super();
  } 

  /**
   * @generated
   */
  public String getGeneratorVersion()
  {
    return generatorVersion;
  }

  /**
   * @Select( sql="select XCustomer_Vehicle_KORpk_Id, Cont_Id, VEHICLE_ID, RETAILER_ID, CONNECTME_USAGE_TP_CD, LICENSE_PLATE, VEHICLE_SALES_TP_CD, VEHICLE_USAGE_TP_CD, VEHICLE_OWNERSHIP, START_DT, END_DT, SOURCE_IDENT_TP_CD, CUSTVEHRET_FLAG, DELETE_FLAG, SFDC_ID, SERVICE_NAME, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from XCUSTOMERVEHICLEKOR where XCustomer_Vehicle_KORpk_Id = ? " )
   * 
   * @generated
   */
  public Iterator<EObjXCustomerVehicleKOR> getEObjXCustomerVehicleKOR (Long xCustomerVehicleKORpkId)
  {
    return queryIterator (getEObjXCustomerVehicleKORStatementDescriptor, xCustomerVehicleKORpkId);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getEObjXCustomerVehicleKORStatementDescriptor = createStatementDescriptor (
    "getEObjXCustomerVehicleKOR(Long)",
    "select XCustomer_Vehicle_KORpk_Id, Cont_Id, VEHICLE_ID, RETAILER_ID, CONNECTME_USAGE_TP_CD, LICENSE_PLATE, VEHICLE_SALES_TP_CD, VEHICLE_USAGE_TP_CD, VEHICLE_OWNERSHIP, START_DT, END_DT, SOURCE_IDENT_TP_CD, CUSTVEHRET_FLAG, DELETE_FLAG, SFDC_ID, SERVICE_NAME, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from XCUSTOMERVEHICLEKOR where XCustomer_Vehicle_KORpk_Id = ? ",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"xcustomer_vehicle_korpk_id", "cont_id", "vehicle_id", "retailer_id", "connectme_usage_tp_cd", "license_plate", "vehicle_sales_tp_cd", "vehicle_usage_tp_cd", "vehicle_ownership", "start_dt", "end_dt", "source_ident_tp_cd", "custvehret_flag", "delete_flag", "sfdc_id", "service_name", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetEObjXCustomerVehicleKORParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetEObjXCustomerVehicleKORRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 19, 19, 19, 19, 20, 19, 19, 250, 0, 0, 19, 5, 10, 50, 120, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    1);

  /**
   * @generated
   */
  public static class GetEObjXCustomerVehicleKORParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setLong (stmt, 1, Types.BIGINT, (Long)parameters[0]);
    }
  }

  /**
   * @generated
   */
  public static class GetEObjXCustomerVehicleKORRowHandler extends BaseRowHandler<EObjXCustomerVehicleKOR>
  {
    /**
     * @generated
     */
    public EObjXCustomerVehicleKOR handle (java.sql.ResultSet rs, EObjXCustomerVehicleKOR returnObject) throws java.sql.SQLException
    {
      returnObject = new EObjXCustomerVehicleKOR ();
      returnObject.setXCustomerVehicleKORpkId(getLongObject (rs, 1)); 
      returnObject.setContId(getLongObject (rs, 2)); 
      returnObject.setVehicleId(getLongObject (rs, 3)); 
      returnObject.setRetailerId(getLongObject (rs, 4)); 
      returnObject.setConnectMeUsage(getLongObject (rs, 5)); 
      returnObject.setLicensePlate(getString (rs, 6)); 
      returnObject.setVehicleSales(getLongObject (rs, 7)); 
      returnObject.setVehicleUsage(getLongObject (rs, 8)); 
      returnObject.setVehicleOwnerShip(getString (rs, 9)); 
      returnObject.setStartDate(getTimestamp (rs, 10)); 
      returnObject.setEndDate(getTimestamp (rs, 11)); 
      returnObject.setSourceIdentifier(getLongObject (rs, 12)); 
      returnObject.setCustVehRetFlag(getString (rs, 13)); 
      returnObject.setDeleteFlag(getString (rs, 14)); 
      returnObject.setSFDCId(getString (rs, 15)); 
      returnObject.setServiceName(getString (rs, 16)); 
      returnObject.setLastUpdateDt(getTimestamp (rs, 17)); 
      returnObject.setLastUpdateUser(getString (rs, 18)); 
      returnObject.setLastUpdateTxId(getLongObject (rs, 19)); 
    
      return returnObject;
    }
  }

  /**
   * @Update( sql="insert into XCUSTOMERVEHICLEKOR (XCustomer_Vehicle_KORpk_Id, Cont_Id, VEHICLE_ID, RETAILER_ID, CONNECTME_USAGE_TP_CD, LICENSE_PLATE, VEHICLE_SALES_TP_CD, VEHICLE_USAGE_TP_CD, VEHICLE_OWNERSHIP, START_DT, END_DT, SOURCE_IDENT_TP_CD, CUSTVEHRET_FLAG, DELETE_FLAG, SFDC_ID, SERVICE_NAME, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( :xCustomerVehicleKORpkId, :contId, :vehicleId, :retailerId, :connectMeUsage, :licensePlate, :vehicleSales, :vehicleUsage, :vehicleOwnerShip, :startDate, :endDate, :sourceIdentifier, :custVehRetFlag, :deleteFlag, :sFDCId, :serviceName, :lastUpdateDt, :lastUpdateUser, :lastUpdateTxId)" )
   * 
   * @generated
   */
  public int createEObjXCustomerVehicleKOR (EObjXCustomerVehicleKOR e)
  {
    return update (createEObjXCustomerVehicleKORStatementDescriptor, e);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor createEObjXCustomerVehicleKORStatementDescriptor = createStatementDescriptor (
    "createEObjXCustomerVehicleKOR(com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleKOR)",
    "insert into XCUSTOMERVEHICLEKOR (XCustomer_Vehicle_KORpk_Id, Cont_Id, VEHICLE_ID, RETAILER_ID, CONNECTME_USAGE_TP_CD, LICENSE_PLATE, VEHICLE_SALES_TP_CD, VEHICLE_USAGE_TP_CD, VEHICLE_OWNERSHIP, START_DT, END_DT, SOURCE_IDENT_TP_CD, CUSTVEHRET_FLAG, DELETE_FLAG, SFDC_ID, SERVICE_NAME, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values(  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? )",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.INSERT,
    null,
    new CreateEObjXCustomerVehicleKORParameterHandler (),
    new int[][]{{Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 19, 19, 19, 19, 20, 19, 19, 250, 0, 0, 19, 5, 10, 50, 120, 0, 0, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    2);

  /**
   * @generated
   */
  public static class CreateEObjXCustomerVehicleKORParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      EObjXCustomerVehicleKOR bean0 = (EObjXCustomerVehicleKOR) parameters[0];
      setLong (stmt, 1, Types.BIGINT, (Long)bean0.getXCustomerVehicleKORpkId());
      setLong (stmt, 2, Types.BIGINT, (Long)bean0.getContId());
      setLong (stmt, 3, Types.BIGINT, (Long)bean0.getVehicleId());
      setLong (stmt, 4, Types.BIGINT, (Long)bean0.getRetailerId());
      setLong (stmt, 5, Types.BIGINT, (Long)bean0.getConnectMeUsage());
      setString (stmt, 6, Types.VARCHAR, (String)bean0.getLicensePlate());
      setLong (stmt, 7, Types.BIGINT, (Long)bean0.getVehicleSales());
      setLong (stmt, 8, Types.BIGINT, (Long)bean0.getVehicleUsage());
      setString (stmt, 9, Types.VARCHAR, (String)bean0.getVehicleOwnerShip());
      setTimestamp (stmt, 10, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getStartDate());
      setTimestamp (stmt, 11, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getEndDate());
      setLong (stmt, 12, Types.BIGINT, (Long)bean0.getSourceIdentifier());
      setString (stmt, 13, Types.VARCHAR, (String)bean0.getCustVehRetFlag());
      setString (stmt, 14, Types.VARCHAR, (String)bean0.getDeleteFlag());
      setString (stmt, 15, Types.VARCHAR, (String)bean0.getSFDCId());
      setString (stmt, 16, Types.VARCHAR, (String)bean0.getServiceName());
      setTimestamp (stmt, 17, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUpdateDt());
      setString (stmt, 18, Types.VARCHAR, (String)bean0.getLastUpdateUser());
      setLong (stmt, 19, Types.BIGINT, (Long)bean0.getLastUpdateTxId());
    }
  }

  /**
   * @Update( sql="update XCUSTOMERVEHICLEKOR set Cont_Id = :contId, VEHICLE_ID = :vehicleId, RETAILER_ID = :retailerId, CONNECTME_USAGE_TP_CD = :connectMeUsage, LICENSE_PLATE = :licensePlate, VEHICLE_SALES_TP_CD = :vehicleSales, VEHICLE_USAGE_TP_CD = :vehicleUsage, VEHICLE_OWNERSHIP = :vehicleOwnerShip, START_DT = :startDate, END_DT = :endDate, SOURCE_IDENT_TP_CD = :sourceIdentifier, CUSTVEHRET_FLAG = :custVehRetFlag, DELETE_FLAG = :deleteFlag, SFDC_ID = :sFDCId, SERVICE_NAME = :serviceName, LAST_UPDATE_DT = :lastUpdateDt, LAST_UPDATE_USER = :lastUpdateUser, LAST_UPDATE_TX_ID = :lastUpdateTxId where XCustomer_Vehicle_KORpk_Id = :xCustomerVehicleKORpkId and LAST_UPDATE_DT = :oldLastUpdateDt" )
   * 
   * @generated
   */
  public int updateEObjXCustomerVehicleKOR (EObjXCustomerVehicleKOR e)
  {
    return update (updateEObjXCustomerVehicleKORStatementDescriptor, e);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor updateEObjXCustomerVehicleKORStatementDescriptor = createStatementDescriptor (
    "updateEObjXCustomerVehicleKOR(com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleKOR)",
    "update XCUSTOMERVEHICLEKOR set Cont_Id =  ? , VEHICLE_ID =  ? , RETAILER_ID =  ? , CONNECTME_USAGE_TP_CD =  ? , LICENSE_PLATE =  ? , VEHICLE_SALES_TP_CD =  ? , VEHICLE_USAGE_TP_CD =  ? , VEHICLE_OWNERSHIP =  ? , START_DT =  ? , END_DT =  ? , SOURCE_IDENT_TP_CD =  ? , CUSTVEHRET_FLAG =  ? , DELETE_FLAG =  ? , SFDC_ID =  ? , SERVICE_NAME =  ? , LAST_UPDATE_DT =  ? , LAST_UPDATE_USER =  ? , LAST_UPDATE_TX_ID =  ?  where XCustomer_Vehicle_KORpk_Id =  ?  and LAST_UPDATE_DT =  ? ",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.UPDATE,
    null,
    new UpdateEObjXCustomerVehicleKORParameterHandler (),
    new int[][]{{Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP}, {19, 19, 19, 19, 20, 19, 19, 250, 0, 0, 19, 5, 10, 50, 120, 0, 0, 19, 19, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    3);

  /**
   * @generated
   */
  public static class UpdateEObjXCustomerVehicleKORParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      EObjXCustomerVehicleKOR bean0 = (EObjXCustomerVehicleKOR) parameters[0];
      setLong (stmt, 1, Types.BIGINT, (Long)bean0.getContId());
      setLong (stmt, 2, Types.BIGINT, (Long)bean0.getVehicleId());
      setLong (stmt, 3, Types.BIGINT, (Long)bean0.getRetailerId());
      setLong (stmt, 4, Types.BIGINT, (Long)bean0.getConnectMeUsage());
      setString (stmt, 5, Types.VARCHAR, (String)bean0.getLicensePlate());
      setLong (stmt, 6, Types.BIGINT, (Long)bean0.getVehicleSales());
      setLong (stmt, 7, Types.BIGINT, (Long)bean0.getVehicleUsage());
      setString (stmt, 8, Types.VARCHAR, (String)bean0.getVehicleOwnerShip());
      setTimestamp (stmt, 9, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getStartDate());
      setTimestamp (stmt, 10, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getEndDate());
      setLong (stmt, 11, Types.BIGINT, (Long)bean0.getSourceIdentifier());
      setString (stmt, 12, Types.VARCHAR, (String)bean0.getCustVehRetFlag());
      setString (stmt, 13, Types.VARCHAR, (String)bean0.getDeleteFlag());
      setString (stmt, 14, Types.VARCHAR, (String)bean0.getSFDCId());
      setString (stmt, 15, Types.VARCHAR, (String)bean0.getServiceName());
      setTimestamp (stmt, 16, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUpdateDt());
      setString (stmt, 17, Types.VARCHAR, (String)bean0.getLastUpdateUser());
      setLong (stmt, 18, Types.BIGINT, (Long)bean0.getLastUpdateTxId());
      setLong (stmt, 19, Types.BIGINT, (Long)bean0.getXCustomerVehicleKORpkId());
      setTimestamp (stmt, 20, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getOldLastUpdateDt());
    }
  }

  /**
   * @Update( sql="delete from XCUSTOMERVEHICLEKOR where XCustomer_Vehicle_KORpk_Id = ?" )
   * 
   * @generated
   */
  public int deleteEObjXCustomerVehicleKOR (Long xCustomerVehicleKORpkId)
  {
    return update (deleteEObjXCustomerVehicleKORStatementDescriptor, xCustomerVehicleKORpkId);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor deleteEObjXCustomerVehicleKORStatementDescriptor = createStatementDescriptor (
    "deleteEObjXCustomerVehicleKOR(Long)",
    "delete from XCUSTOMERVEHICLEKOR where XCustomer_Vehicle_KORpk_Id = ?",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.DELETE,
    null,
    new DeleteEObjXCustomerVehicleKORParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    4);

  /**
   * @generated
   */
  public static class DeleteEObjXCustomerVehicleKORParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setLong (stmt, 1, Types.BIGINT, (Long)parameters[0]);
    }
  }

}
