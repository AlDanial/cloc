package com.ibm.daimler.dsea.entityObject;

import com.ibm.pdq.runtime.generator.BaseParameterHandler;
import java.util.Iterator;
import java.sql.PreparedStatement;
import com.ibm.pdq.runtime.statement.StatementDescriptor;
import com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt;
import com.ibm.pdq.runtime.generator.BaseData;
import java.sql.SQLException;
import com.ibm.pdq.annotation.Metadata;
import com.dwl.tcrm.coreParty.entityObject.EObjIdentifier;
import com.ibm.pdq.runtime.generator.BaseRowHandler;
import com.ibm.pdq.runtime.statement.SqlStatementType;
import java.sql.Types;


/**
 * <!-- begin-user-doc -->
 * 
 * <!-- end-user-doc -->
 * 
 * @generated
 */
public class EObjXIdentifierExtDataImpl  extends BaseData implements EObjXIdentifierExtData
{

  /**
   * @generated
   */
  public static final String generatorVersion = "3.200.75";

  /**
   * @generated
   */
  public static final String identifier = "EObjXIdentifierExtData";

  /**
   * @generated
   */
  public static final long generationTime = 0x0000016069b1d5c8L;

  /**
   * @generated
   */
  public static final String collection = "NULLID";

  /**
   * @generated
   */
  public static final String packageVersion = null;

  /**
   * @generated
   */
  public static final boolean forceSingleBindIsolation = false;

  /**
   * @generated
   */
  public EObjXIdentifierExtDataImpl()
  {
    super();
  } 

  /**
   * @generated
   */
  public String getGeneratorVersion()
  {
    return generatorVersion;
  }

  /**
   * @Select( sql="select XMODIFY_SYS_DT, XRETAILER_ID, XIDEN_RETAILER_FLAG, X_BPID, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from IDENTIFIER where IDENTIFIER_ID = ? " )
   * 
   * @generated
   */
  public Iterator<EObjXIdentifierExt> getEObjXIdentifierExt (Long identifierIdPK)
  {
    return queryIterator (getEObjXIdentifierExtStatementDescriptor, identifierIdPK);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getEObjXIdentifierExtStatementDescriptor = createStatementDescriptor (
    "getEObjXIdentifierExt(Long)",
    "select XMODIFY_SYS_DT, XRETAILER_ID, XIDEN_RETAILER_FLAG, X_BPID, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from IDENTIFIER where IDENTIFIER_ID = ? ",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"xmodify_sys_dt", "xretailer_id", "xiden_retailer_flag", "x_bpid", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetEObjXIdentifierExtParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetEObjXIdentifierExtRowHandler (),
    new int[][]{ {Types.TIMESTAMP, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {0, 19, 5, 50, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    1);

  /**
   * @generated
   */
  public static class GetEObjXIdentifierExtParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setLong (stmt, 1, Types.BIGINT, (Long)parameters[0]);
    }
  }

  /**
   * @generated
   */
  public static class GetEObjXIdentifierExtRowHandler extends BaseRowHandler<EObjXIdentifierExt>
  {
    /**
     * @generated
     */
    public EObjXIdentifierExt handle (java.sql.ResultSet rs, EObjXIdentifierExt returnObject) throws java.sql.SQLException
    {
      returnObject = new EObjXIdentifierExt ();
      returnObject.setXLastModifiedSystemDate(getTimestamp (rs, 1)); 
      returnObject.setXRetailerId(getLongObject (rs, 2)); 
      returnObject.setXIdentifierRetailerFlag(getString (rs, 3)); 
      returnObject.setX_BPID(getString (rs, 4)); 
      returnObject.setLastUpdateDt(getTimestamp (rs, 5)); 
      returnObject.setLastUpdateUser(getString (rs, 6)); 
      returnObject.setLastUpdateTxId(getLongObject (rs, 7)); 
    
      return returnObject;
    }
  }

  /**
   * @Update( sql="insert into IDENTIFIER (REF_NUM, LAST_VERIFIED_DT, IDENTIFIER_ID, CONT_ID, START_DT, END_DT, EXPIRY_DT, IDENTIFIER_DESC, ASSIGNED_BY, ISSUE_LOCATION, LAST_USED_DT, ID_STATUS_TP_CD, ID_TP_CD, SOURCE_IDENT_TP_CD, XMODIFY_SYS_DT, XRETAILER_ID, XIDEN_RETAILER_FLAG, X_BPID, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( ?1.refNum, ?1.lastVerifiedDt, ?1.identifierIdPK, ?1.contId, ?1.startDt, ?1.endDt, ?1.expiryDt, ?1.identifierDesc, ?1.assignedBy, ?1.issueLocation, ?1.lastUsedDt, ?1.idStatusTpCd, ?1.idTpCd, ?1.sourceIdentTpCd, ?2.xLastModifiedSystemDate, ?2.xRetailerId, ?2.xIdentifierRetailerFlag, ?2.x_BPID, ?1.lastUpdateDt, ?1.lastUpdateUser, ?1.lastUpdateTxId)" )
   * 
   * @generated
   */
  public int createEObjXIdentifierExt (EObjIdentifier e1, EObjXIdentifierExt e2)
  {
    return update (createEObjXIdentifierExtStatementDescriptor, e1, e2);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor createEObjXIdentifierExtStatementDescriptor = createStatementDescriptor (
    "createEObjXIdentifierExt(com.dwl.tcrm.coreParty.entityObject.EObjIdentifier, com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt)",
    "insert into IDENTIFIER (REF_NUM, LAST_VERIFIED_DT, IDENTIFIER_ID, CONT_ID, START_DT, END_DT, EXPIRY_DT, IDENTIFIER_DESC, ASSIGNED_BY, ISSUE_LOCATION, LAST_USED_DT, ID_STATUS_TP_CD, ID_TP_CD, SOURCE_IDENT_TP_CD, XMODIFY_SYS_DT, XRETAILER_ID, XIDEN_RETAILER_FLAG, X_BPID, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values(  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? )",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.INSERT,
    null,
    new CreateEObjXIdentifierExtParameterHandler (),
    new int[][]{{Types.VARCHAR, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {50, 0, 19, 19, 0, 0, 0, 255, 19, 30, 0, 19, 19, 19, 0, 19, 5, 50, 0, 0, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    2);

  /**
   * @generated
   */
  public static class CreateEObjXIdentifierExtParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      EObjIdentifier bean0 = (EObjIdentifier) parameters[0];
      setString (stmt, 1, Types.VARCHAR, (String)bean0.getRefNum());
      setTimestamp (stmt, 2, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastVerifiedDt());
      setLong (stmt, 3, Types.BIGINT, (Long)bean0.getIdentifierIdPK());
      setLong (stmt, 4, Types.BIGINT, (Long)bean0.getContId());
      setTimestamp (stmt, 5, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getStartDt());
      setTimestamp (stmt, 6, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getEndDt());
      setTimestamp (stmt, 7, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getExpiryDt());
      setString (stmt, 8, Types.VARCHAR, (String)bean0.getIdentifierDesc());
      setLong (stmt, 9, Types.BIGINT, (Long)bean0.getAssignedBy());
      setString (stmt, 10, Types.VARCHAR, (String)bean0.getIssueLocation());
      setTimestamp (stmt, 11, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUsedDt());
      setLong (stmt, 12, Types.BIGINT, (Long)bean0.getIdStatusTpCd());
      setLong (stmt, 13, Types.BIGINT, (Long)bean0.getIdTpCd());
      setLong (stmt, 14, Types.BIGINT, (Long)bean0.getSourceIdentTpCd());
      EObjXIdentifierExt bean1 = (EObjXIdentifierExt) parameters[1];
      setTimestamp (stmt, 15, Types.TIMESTAMP, (java.sql.Timestamp)bean1.getXLastModifiedSystemDate());
      setLong (stmt, 16, Types.BIGINT, (Long)bean1.getXRetailerId());
      setString (stmt, 17, Types.VARCHAR, (String)bean1.getXIdentifierRetailerFlag());
      setString (stmt, 18, Types.VARCHAR, (String)bean1.getX_BPID());
      setTimestamp (stmt, 19, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUpdateDt());
      setString (stmt, 20, Types.VARCHAR, (String)bean0.getLastUpdateUser());
      setLong (stmt, 21, Types.BIGINT, (Long)bean0.getLastUpdateTxId());
    }
  }

  /**
   * @Update( sql="update IDENTIFIER set REF_NUM = ?1.refNum, LAST_VERIFIED_DT = ?1.lastVerifiedDt, CONT_ID = ?1.contId, START_DT = ?1.startDt, END_DT = ?1.endDt, EXPIRY_DT = ?1.expiryDt, IDENTIFIER_DESC = ?1.identifierDesc, ASSIGNED_BY = ?1.assignedBy, ISSUE_LOCATION = ?1.issueLocation, LAST_USED_DT = ?1.lastUsedDt, ID_STATUS_TP_CD = ?1.idStatusTpCd, ID_TP_CD = ?1.idTpCd, SOURCE_IDENT_TP_CD = ?1.sourceIdentTpCd, XMODIFY_SYS_DT = ?2.xLastModifiedSystemDate, XRETAILER_ID = ?2.xRetailerId, XIDEN_RETAILER_FLAG = ?2.xIdentifierRetailerFlag, X_BPID = ?2.x_BPID, LAST_UPDATE_DT = ?1.lastUpdateDt, LAST_UPDATE_USER = ?1.lastUpdateUser, LAST_UPDATE_TX_ID = ?1.lastUpdateTxId where IDENTIFIER_ID = ?1.identifierIdPK and LAST_UPDATE_DT = ?1.oldLastUpdateDt" )
   * 
   * @generated
   */
  public int updateEObjXIdentifierExt (EObjIdentifier e1, EObjXIdentifierExt e2)
  {
    return update (updateEObjXIdentifierExtStatementDescriptor, e1, e2);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor updateEObjXIdentifierExtStatementDescriptor = createStatementDescriptor (
    "updateEObjXIdentifierExt(com.dwl.tcrm.coreParty.entityObject.EObjIdentifier, com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt)",
    "update IDENTIFIER set REF_NUM =  ? , LAST_VERIFIED_DT =  ? , CONT_ID =  ? , START_DT =  ? , END_DT =  ? , EXPIRY_DT =  ? , IDENTIFIER_DESC =  ? , ASSIGNED_BY =  ? , ISSUE_LOCATION =  ? , LAST_USED_DT =  ? , ID_STATUS_TP_CD =  ? , ID_TP_CD =  ? , SOURCE_IDENT_TP_CD =  ? , XMODIFY_SYS_DT =  ? , XRETAILER_ID =  ? , XIDEN_RETAILER_FLAG =  ? , X_BPID =  ? , LAST_UPDATE_DT =  ? , LAST_UPDATE_USER =  ? , LAST_UPDATE_TX_ID =  ?  where IDENTIFIER_ID =  ?  and LAST_UPDATE_DT =  ? ",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.UPDATE,
    null,
    new UpdateEObjXIdentifierExtParameterHandler (),
    new int[][]{{Types.VARCHAR, Types.TIMESTAMP, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP}, {50, 0, 19, 0, 0, 0, 255, 19, 30, 0, 19, 19, 19, 0, 19, 5, 50, 0, 0, 19, 19, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    3);

  /**
   * @generated
   */
  public static class UpdateEObjXIdentifierExtParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      EObjIdentifier bean0 = (EObjIdentifier) parameters[0];
      setString (stmt, 1, Types.VARCHAR, (String)bean0.getRefNum());
      setTimestamp (stmt, 2, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastVerifiedDt());
      setLong (stmt, 3, Types.BIGINT, (Long)bean0.getContId());
      setTimestamp (stmt, 4, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getStartDt());
      setTimestamp (stmt, 5, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getEndDt());
      setTimestamp (stmt, 6, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getExpiryDt());
      setString (stmt, 7, Types.VARCHAR, (String)bean0.getIdentifierDesc());
      setLong (stmt, 8, Types.BIGINT, (Long)bean0.getAssignedBy());
      setString (stmt, 9, Types.VARCHAR, (String)bean0.getIssueLocation());
      setTimestamp (stmt, 10, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUsedDt());
      setLong (stmt, 11, Types.BIGINT, (Long)bean0.getIdStatusTpCd());
      setLong (stmt, 12, Types.BIGINT, (Long)bean0.getIdTpCd());
      setLong (stmt, 13, Types.BIGINT, (Long)bean0.getSourceIdentTpCd());
      EObjXIdentifierExt bean1 = (EObjXIdentifierExt) parameters[1];
      setTimestamp (stmt, 14, Types.TIMESTAMP, (java.sql.Timestamp)bean1.getXLastModifiedSystemDate());
      setLong (stmt, 15, Types.BIGINT, (Long)bean1.getXRetailerId());
      setString (stmt, 16, Types.VARCHAR, (String)bean1.getXIdentifierRetailerFlag());
      setString (stmt, 17, Types.VARCHAR, (String)bean1.getX_BPID());
      setTimestamp (stmt, 18, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUpdateDt());
      setString (stmt, 19, Types.VARCHAR, (String)bean0.getLastUpdateUser());
      setLong (stmt, 20, Types.BIGINT, (Long)bean0.getLastUpdateTxId());
      setLong (stmt, 21, Types.BIGINT, (Long)bean0.getIdentifierIdPK());
      setTimestamp (stmt, 22, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getOldLastUpdateDt());
    }
  }

  /**
   * @Update( sql="delete from IDENTIFIER where IDENTIFIER_ID = ?" )
   * 
   * @generated
   */
  public int deleteEObjXIdentifierExt (Long identifierIdPK)
  {
    return update (deleteEObjXIdentifierExtStatementDescriptor, identifierIdPK);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor deleteEObjXIdentifierExtStatementDescriptor = createStatementDescriptor (
    "deleteEObjXIdentifierExt(Long)",
    "delete from IDENTIFIER where IDENTIFIER_ID = ?",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.DELETE,
    null,
    new DeleteEObjXIdentifierExtParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    4);

  /**
   * @generated
   */
  public static class DeleteEObjXIdentifierExtParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setLong (stmt, 1, Types.BIGINT, (Long)parameters[0]);
    }
  }

}
