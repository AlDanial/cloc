package com.ibm.daimler.dsea.entityObject;

import com.ibm.pdq.runtime.generator.BaseParameterHandler;
import java.util.Iterator;
import java.sql.PreparedStatement;
import com.ibm.pdq.runtime.statement.StatementDescriptor;
import com.dwl.tcrm.coreParty.entityObject.EObjContEquiv;
import com.ibm.pdq.runtime.generator.BaseData;
import java.sql.SQLException;
import com.ibm.pdq.annotation.Metadata;
import com.ibm.daimler.dsea.entityObject.EObjXContEquivExt;
import com.ibm.pdq.runtime.generator.BaseRowHandler;
import com.ibm.pdq.runtime.statement.SqlStatementType;
import java.sql.Types;


/**
 * <!-- begin-user-doc -->
 * 
 * <!-- end-user-doc -->
 * 
 * @generated
 */
public class EObjXContEquivExtDataImpl  extends BaseData implements EObjXContEquivExtData
{

  /**
   * @generated
   */
  public static final String generatorVersion = "3.200.75";

  /**
   * @generated
   */
  public static final String identifier = "EObjXContEquivExtData";

  /**
   * @generated
   */
  public static final long generationTime = 0x00000164c354c400L;

  /**
   * @generated
   */
  public static final String collection = "NULLID";

  /**
   * @generated
   */
  public static final String packageVersion = null;

  /**
   * @generated
   */
  public static final boolean forceSingleBindIsolation = false;

  /**
   * @generated
   */
  public EObjXContEquivExtDataImpl()
  {
    super();
  } 

  /**
   * @generated
   */
  public String getGeneratorVersion()
  {
    return generatorVersion;
  }

  /**
   * @Select( sql="select XRETAILER_ID, XSOURCE_RETAILER_FLAG, XMODIFY_SYS_DT, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from CONTEQUIV where CONT_EQUIV_ID = ? " )
   * 
   * @generated
   */
  public Iterator<EObjXContEquivExt> getEObjXContEquivExt (Long contEquivIdPK)
  {
    return queryIterator (getEObjXContEquivExtStatementDescriptor, contEquivIdPK);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getEObjXContEquivExtStatementDescriptor = createStatementDescriptor (
    "getEObjXContEquivExt(Long)",
    "select XRETAILER_ID, XSOURCE_RETAILER_FLAG, XMODIFY_SYS_DT, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from CONTEQUIV where CONT_EQUIV_ID = ? ",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"xretailer_id", "xsource_retailer_flag", "xmodify_sys_dt", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetEObjXContEquivExtParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetEObjXContEquivExtRowHandler (),
    new int[][]{ {Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 5, 0, 0, 20, 19}, {0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    1);

  /**
   * @generated
   */
  public static class GetEObjXContEquivExtParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setLong (stmt, 1, Types.BIGINT, (Long)parameters[0]);
    }
  }

  /**
   * @generated
   */
  public static class GetEObjXContEquivExtRowHandler extends BaseRowHandler<EObjXContEquivExt>
  {
    /**
     * @generated
     */
    public EObjXContEquivExt handle (java.sql.ResultSet rs, EObjXContEquivExt returnObject) throws java.sql.SQLException
    {
      returnObject = new EObjXContEquivExt ();
      returnObject.setXRetailerId(getLongObject (rs, 1)); 
      returnObject.setXSourceRetailerFlag(getString (rs, 2)); 
      returnObject.setXLastModifiedSystemDate(getTimestamp (rs, 3)); 
      returnObject.setLastUpdateDt(getTimestamp (rs, 4)); 
      returnObject.setLastUpdateUser(getString (rs, 5)); 
      returnObject.setLastUpdateTxId(getLongObject (rs, 6)); 
    
      return returnObject;
    }
  }

  /**
   * @Update( sql="insert into CONTEQUIV (DESCRIPTION, CONT_ID, CONT_EQUIV_ID, ADMIN_CLIENT_ID, ADMIN_SYS_TP_CD, XRETAILER_ID, XSOURCE_RETAILER_FLAG, XMODIFY_SYS_DT, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( ?1.description, ?1.contId, ?1.contEquivIdPK, ?1.adminClientId, ?1.adminSysTpCd, ?2.xRetailerId, ?2.xSourceRetailerFlag, ?2.xLastModifiedSystemDate, ?1.lastUpdateDt, ?1.lastUpdateUser, ?1.lastUpdateTxId)" )
   * 
   * @generated
   */
  public int createEObjXContEquivExt (EObjContEquiv e1, EObjXContEquivExt e2)
  {
    return update (createEObjXContEquivExtStatementDescriptor, e1, e2);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor createEObjXContEquivExtStatementDescriptor = createStatementDescriptor (
    "createEObjXContEquivExt(com.dwl.tcrm.coreParty.entityObject.EObjContEquiv, com.ibm.daimler.dsea.entityObject.EObjXContEquivExt)",
    "insert into CONTEQUIV (DESCRIPTION, CONT_ID, CONT_EQUIV_ID, ADMIN_CLIENT_ID, ADMIN_SYS_TP_CD, XRETAILER_ID, XSOURCE_RETAILER_FLAG, XMODIFY_SYS_DT, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values(  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? )",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.INSERT,
    null,
    new CreateEObjXContEquivExtParameterHandler (),
    new int[][]{{Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {255, 19, 19, 20, 19, 19, 5, 0, 0, 0, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    2);

  /**
   * @generated
   */
  public static class CreateEObjXContEquivExtParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      EObjContEquiv bean0 = (EObjContEquiv) parameters[0];
      setString (stmt, 1, Types.VARCHAR, (String)bean0.getDescription());
      setLong (stmt, 2, Types.BIGINT, (Long)bean0.getContId());
      setLong (stmt, 3, Types.BIGINT, (Long)bean0.getContEquivIdPK());
      setString (stmt, 4, Types.VARCHAR, (String)bean0.getAdminClientId());
      setLong (stmt, 5, Types.BIGINT, (Long)bean0.getAdminSysTpCd());
      EObjXContEquivExt bean1 = (EObjXContEquivExt) parameters[1];
      setLong (stmt, 6, Types.BIGINT, (Long)bean1.getXRetailerId());
      setString (stmt, 7, Types.VARCHAR, (String)bean1.getXSourceRetailerFlag());
      setTimestamp (stmt, 8, Types.TIMESTAMP, (java.sql.Timestamp)bean1.getXLastModifiedSystemDate());
      setTimestamp (stmt, 9, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUpdateDt());
      setString (stmt, 10, Types.VARCHAR, (String)bean0.getLastUpdateUser());
      setLong (stmt, 11, Types.BIGINT, (Long)bean0.getLastUpdateTxId());
    }
  }

  /**
   * @Update( sql="update CONTEQUIV set DESCRIPTION = ?1.description, CONT_ID = ?1.contId, ADMIN_CLIENT_ID = ?1.adminClientId, ADMIN_SYS_TP_CD = ?1.adminSysTpCd, XRETAILER_ID = ?2.xRetailerId, XSOURCE_RETAILER_FLAG = ?2.xSourceRetailerFlag, XMODIFY_SYS_DT = ?2.xLastModifiedSystemDate, LAST_UPDATE_DT = ?1.lastUpdateDt, LAST_UPDATE_USER = ?1.lastUpdateUser, LAST_UPDATE_TX_ID = ?1.lastUpdateTxId where CONT_EQUIV_ID = ?1.contEquivIdPK and LAST_UPDATE_DT = ?1.oldLastUpdateDt" )
   * 
   * @generated
   */
  public int updateEObjXContEquivExt (EObjContEquiv e1, EObjXContEquivExt e2)
  {
    return update (updateEObjXContEquivExtStatementDescriptor, e1, e2);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor updateEObjXContEquivExtStatementDescriptor = createStatementDescriptor (
    "updateEObjXContEquivExt(com.dwl.tcrm.coreParty.entityObject.EObjContEquiv, com.ibm.daimler.dsea.entityObject.EObjXContEquivExt)",
    "update CONTEQUIV set DESCRIPTION =  ? , CONT_ID =  ? , ADMIN_CLIENT_ID =  ? , ADMIN_SYS_TP_CD =  ? , XRETAILER_ID =  ? , XSOURCE_RETAILER_FLAG =  ? , XMODIFY_SYS_DT =  ? , LAST_UPDATE_DT =  ? , LAST_UPDATE_USER =  ? , LAST_UPDATE_TX_ID =  ?  where CONT_EQUIV_ID =  ?  and LAST_UPDATE_DT =  ? ",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.UPDATE,
    null,
    new UpdateEObjXContEquivExtParameterHandler (),
    new int[][]{{Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP}, {255, 19, 20, 19, 19, 5, 0, 0, 0, 19, 19, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    3);

  /**
   * @generated
   */
  public static class UpdateEObjXContEquivExtParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      EObjContEquiv bean0 = (EObjContEquiv) parameters[0];
      setString (stmt, 1, Types.VARCHAR, (String)bean0.getDescription());
      setLong (stmt, 2, Types.BIGINT, (Long)bean0.getContId());
      setString (stmt, 3, Types.VARCHAR, (String)bean0.getAdminClientId());
      setLong (stmt, 4, Types.BIGINT, (Long)bean0.getAdminSysTpCd());
      EObjXContEquivExt bean1 = (EObjXContEquivExt) parameters[1];
      setLong (stmt, 5, Types.BIGINT, (Long)bean1.getXRetailerId());
      setString (stmt, 6, Types.VARCHAR, (String)bean1.getXSourceRetailerFlag());
      setTimestamp (stmt, 7, Types.TIMESTAMP, (java.sql.Timestamp)bean1.getXLastModifiedSystemDate());
      setTimestamp (stmt, 8, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUpdateDt());
      setString (stmt, 9, Types.VARCHAR, (String)bean0.getLastUpdateUser());
      setLong (stmt, 10, Types.BIGINT, (Long)bean0.getLastUpdateTxId());
      setLong (stmt, 11, Types.BIGINT, (Long)bean0.getContEquivIdPK());
      setTimestamp (stmt, 12, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getOldLastUpdateDt());
    }
  }

  /**
   * @Update( sql="delete from CONTEQUIV where CONT_EQUIV_ID = ?" )
   * 
   * @generated
   */
  public int deleteEObjXContEquivExt (Long contEquivIdPK)
  {
    return update (deleteEObjXContEquivExtStatementDescriptor, contEquivIdPK);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor deleteEObjXContEquivExtStatementDescriptor = createStatementDescriptor (
    "deleteEObjXContEquivExt(Long)",
    "delete from CONTEQUIV where CONT_EQUIV_ID = ?",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.DELETE,
    null,
    new DeleteEObjXContEquivExtParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    4);

  /**
   * @generated
   */
  public static class DeleteEObjXContEquivExtParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setLong (stmt, 1, Types.BIGINT, (Long)parameters[0]);
    }
  }

}
