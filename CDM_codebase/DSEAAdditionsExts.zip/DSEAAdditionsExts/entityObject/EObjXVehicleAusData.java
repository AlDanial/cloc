/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[0e910c3ef8735bf75bbdd16864ef5950]
 */


package com.ibm.daimler.dsea.entityObject;

import java.util.Iterator;
import com.ibm.mdm.base.db.EntityMapping;
import com.ibm.pdq.annotation.Select;
import com.ibm.pdq.annotation.Update;

import com.ibm.daimler.dsea.entityObject.EObjXVehicleAus;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * @generated
 */
public interface EObjXVehicleAusData {


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjXVehicleAusSql = "select XVehicle_Auspk_Id, GLOBAL_VIN, AMG_VEH, VEHICLE_TYPE, CLASS_SUMMARY, ODOMETER, ENGINE_NUM, VEHICLE_YEAR, MODEL, REG_NO, VEHICLE_CLASS, COMM_NO, MARKET_NAME, CIRCLE_OF_EXCELLENCE, SOURCE_IDENT_TP_CD, MODIFY_SYS_DT, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from XVEHICLEAUS where XVehicle_Auspk_Id = ? ";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String createEObjXVehicleAusSql = "insert into XVEHICLEAUS (XVehicle_Auspk_Id, GLOBAL_VIN, AMG_VEH, VEHICLE_TYPE, CLASS_SUMMARY, ODOMETER, ENGINE_NUM, VEHICLE_YEAR, MODEL, REG_NO, VEHICLE_CLASS, COMM_NO, MARKET_NAME, CIRCLE_OF_EXCELLENCE, SOURCE_IDENT_TP_CD, MODIFY_SYS_DT, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( :xVehicleAuspkId, :globalVIN, :amgVehicle, :vehicleType, :classSummary, :odoMeter, :engineNum, :vehicleYear, :model, :regNum, :vehicleClass, :commNo, :marketName, :circleOfExcellence, :sourceIdentifier, :lastModifiedSystemDate, :lastUpdateDt, :lastUpdateUser, :lastUpdateTxId)";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String updateEObjXVehicleAusSql = "update XVEHICLEAUS set GLOBAL_VIN = :globalVIN, AMG_VEH = :amgVehicle, VEHICLE_TYPE = :vehicleType, CLASS_SUMMARY = :classSummary, ODOMETER = :odoMeter, ENGINE_NUM = :engineNum, VEHICLE_YEAR = :vehicleYear, MODEL = :model, REG_NO = :regNum, VEHICLE_CLASS = :vehicleClass, COMM_NO = :commNo, MARKET_NAME = :marketName, CIRCLE_OF_EXCELLENCE = :circleOfExcellence, SOURCE_IDENT_TP_CD = :sourceIdentifier, MODIFY_SYS_DT = :lastModifiedSystemDate, LAST_UPDATE_DT = :lastUpdateDt, LAST_UPDATE_USER = :lastUpdateUser, LAST_UPDATE_TX_ID = :lastUpdateTxId where XVehicle_Auspk_Id = :xVehicleAuspkId and LAST_UPDATE_DT = :oldLastUpdateDt";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String deleteEObjXVehicleAusSql = "delete from XVEHICLEAUS where XVehicle_Auspk_Id = ?";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXVehicleAusKeyField = "EObjXVehicleAus.xVehicleAuspkId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXVehicleAusGetFields =
    "EObjXVehicleAus.xVehicleAuspkId," +
    "EObjXVehicleAus.globalVIN," +
    "EObjXVehicleAus.amgVehicle," +
    "EObjXVehicleAus.vehicleType," +
    "EObjXVehicleAus.classSummary," +
    "EObjXVehicleAus.odoMeter," +
    "EObjXVehicleAus.engineNum," +
    "EObjXVehicleAus.vehicleYear," +
    "EObjXVehicleAus.model," +
    "EObjXVehicleAus.regNum," +
    "EObjXVehicleAus.vehicleClass," +
    "EObjXVehicleAus.commNo," +
    "EObjXVehicleAus.marketName," +
    "EObjXVehicleAus.circleOfExcellence," +
    "EObjXVehicleAus.sourceIdentifier," +
    "EObjXVehicleAus.lastModifiedSystemDate," +
    "EObjXVehicleAus.lastUpdateDt," +
    "EObjXVehicleAus.lastUpdateUser," +
    "EObjXVehicleAus.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXVehicleAusAllFields =
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleAus.xVehicleAuspkId," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleAus.globalVIN," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleAus.amgVehicle," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleAus.vehicleType," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleAus.classSummary," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleAus.odoMeter," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleAus.engineNum," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleAus.vehicleYear," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleAus.model," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleAus.regNum," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleAus.vehicleClass," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleAus.commNo," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleAus.marketName," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleAus.circleOfExcellence," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleAus.sourceIdentifier," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleAus.lastModifiedSystemDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleAus.lastUpdateDt," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleAus.lastUpdateUser," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleAus.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXVehicleAusUpdateFields =
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleAus.globalVIN," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleAus.amgVehicle," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleAus.vehicleType," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleAus.classSummary," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleAus.odoMeter," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleAus.engineNum," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleAus.vehicleYear," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleAus.model," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleAus.regNum," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleAus.vehicleClass," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleAus.commNo," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleAus.marketName," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleAus.circleOfExcellence," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleAus.sourceIdentifier," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleAus.lastModifiedSystemDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleAus.lastUpdateDt," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleAus.lastUpdateUser," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleAus.lastUpdateTxId," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleAus.xVehicleAuspkId," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleAus.oldLastUpdateDt";   

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Select XVehicleAus by parameters.
   * @generated
   */
  @Select(sql=getEObjXVehicleAusSql)
  @EntityMapping(parameters=EObjXVehicleAusKeyField, results=EObjXVehicleAusGetFields)
  Iterator<EObjXVehicleAus> getEObjXVehicleAus(Long xVehicleAuspkId);  
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Create XVehicleAus by EObjXVehicleAus Object.
   * @generated
   */
  @Update(sql=createEObjXVehicleAusSql)
  @EntityMapping(parameters=EObjXVehicleAusAllFields)
    int createEObjXVehicleAus(EObjXVehicleAus e); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Update one XVehicleAus by EObjXVehicleAus object.
   * @generated
   */
  @Update(sql=updateEObjXVehicleAusSql)
  @EntityMapping(parameters=EObjXVehicleAusUpdateFields)
    int updateEObjXVehicleAus(EObjXVehicleAus e); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Delete XVehicleAus by parameters.
   * @generated
   */
  @Update(sql=deleteEObjXVehicleAusSql)
  @EntityMapping(parameters=EObjXVehicleAusKeyField)
  int deleteEObjXVehicleAus(Long xVehicleAuspkId);

}

