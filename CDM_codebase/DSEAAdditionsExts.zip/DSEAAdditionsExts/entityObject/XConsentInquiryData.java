/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[b47512ae48150c2b6f828ba6e1f963a1]
 */

package com.ibm.daimler.dsea.entityObject;


import com.ibm.mdm.base.db.ResultQueue1;
import java.util.Iterator;
import com.ibm.mdm.base.db.EntityMapping;
import com.ibm.pdq.annotation.Select;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * @generated
 */
public interface XConsentInquiryData {
  
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String tableAliasString = "tableAlias (" + 
                                            "XCONSENT => com.ibm.daimler.dsea.entityObject.EObjXConsent, " +
                                            "H_XCONSENT => com.ibm.daimler.dsea.entityObject.EObjXConsent" +
                                            ")";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getXConsentSql = "SELECT r.XConsentpk_Id XConsentpk_Id, r.CONT_ID CONT_ID, r.COMM_CHANNNEL COMM_CHANNNEL, r.CONSENT_ACTION_TP_CD CONSENT_ACTION_TP_CD, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.RETAILER_ID RETAILER_ID, r.Retailer_Flag Retailer_Flag, r.LAST_MODIFIED_SYSTEM_DT LAST_MODIFIED_SYSTEM_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XCONSENT r WHERE r.XConsentpk_Id = ? ";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXConsentParameters =
    "EObjXConsent.XConsentpkId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXConsentResults =
    "EObjXConsent.XConsentpkId," +
    "EObjXConsent.ContId," +
    "EObjXConsent.CommunicationChannel," +
    "EObjXConsent.ConsentAction," +
    "EObjXConsent.SourceIdentifier," +
    "EObjXConsent.RetailerId," +
    "EObjXConsent.RetailerFlag," +
    "EObjXConsent.LastModifiedSystemDate," +
    "EObjXConsent.lastUpdateDt," +
    "EObjXConsent.lastUpdateUser," +
    "EObjXConsent.lastUpdateTxId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getXConsentHistorySql = "SELECT r.H_XConsentpk_Id hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.XConsentpk_Id XConsentpk_Id, r.CONT_ID CONT_ID, r.COMM_CHANNNEL COMM_CHANNNEL, r.CONSENT_ACTION_TP_CD CONSENT_ACTION_TP_CD, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.RETAILER_ID RETAILER_ID, r.Retailer_Flag Retailer_Flag, r.LAST_MODIFIED_SYSTEM_DT LAST_MODIFIED_SYSTEM_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XCONSENT r WHERE r.H_XConsentpk_Id = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXConsentHistoryParameters =
    "EObjXConsent.XConsentpkId," +
    "EObjXConsent.lastUpdateDt," +
    "EObjXConsent.lastUpdateDt";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXConsentHistoryResults =
    "EObjXConsent.historyIdPK," +
    "EObjXConsent.histActionCode," +
    "EObjXConsent.histCreatedBy," +
    "EObjXConsent.histCreateDt," +
    "EObjXConsent.histEndDt," +
    "EObjXConsent.XConsentpkId," +
    "EObjXConsent.ContId," +
    "EObjXConsent.CommunicationChannel," +
    "EObjXConsent.ConsentAction," +
    "EObjXConsent.SourceIdentifier," +
    "EObjXConsent.RetailerId," +
    "EObjXConsent.RetailerFlag," +
    "EObjXConsent.LastModifiedSystemDate," +
    "EObjXConsent.lastUpdateDt," +
    "EObjXConsent.lastUpdateUser," +
    "EObjXConsent.lastUpdateTxId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getXConsentByContIdSql = "SELECT r.XConsentpk_Id XConsentpk_Id, r.CONT_ID CONT_ID, r.COMM_CHANNNEL COMM_CHANNNEL, r.CONSENT_ACTION_TP_CD CONSENT_ACTION_TP_CD, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.RETAILER_ID RETAILER_ID, r.Retailer_Flag Retailer_Flag, r.LAST_MODIFIED_SYSTEM_DT LAST_MODIFIED_SYSTEM_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XCONSENT r WHERE r.CONT_ID = ? ";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXConsentByContIdParameters =
    "EObjXConsent.ContId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXConsentByContIdResults =
    "EObjXConsent.XConsentpkId," +
    "EObjXConsent.ContId," +
    "EObjXConsent.CommunicationChannel," +
    "EObjXConsent.ConsentAction," +
    "EObjXConsent.SourceIdentifier," +
    "EObjXConsent.RetailerId," +
    "EObjXConsent.RetailerFlag," +
    "EObjXConsent.LastModifiedSystemDate," +
    "EObjXConsent.lastUpdateDt," +
    "EObjXConsent.lastUpdateUser," +
    "EObjXConsent.lastUpdateTxId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getXConsentByContIdHistorySql = "SELECT r.H_XConsentpk_Id hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.XConsentpk_Id XConsentpk_Id, r.CONT_ID CONT_ID, r.COMM_CHANNNEL COMM_CHANNNEL, r.CONSENT_ACTION_TP_CD CONSENT_ACTION_TP_CD, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.RETAILER_ID RETAILER_ID, r.Retailer_Flag Retailer_Flag, r.LAST_MODIFIED_SYSTEM_DT LAST_MODIFIED_SYSTEM_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XCONSENT r WHERE r.CONT_ID = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXConsentByContIdHistoryParameters =
    "EObjXConsent.ContId," +
    "EObjXConsent.lastUpdateDt," +
    "EObjXConsent.lastUpdateDt";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXConsentByContIdHistoryResults =
    "EObjXConsent.historyIdPK," +
    "EObjXConsent.histActionCode," +
    "EObjXConsent.histCreatedBy," +
    "EObjXConsent.histCreateDt," +
    "EObjXConsent.histEndDt," +
    "EObjXConsent.XConsentpkId," +
    "EObjXConsent.ContId," +
    "EObjXConsent.CommunicationChannel," +
    "EObjXConsent.ConsentAction," +
    "EObjXConsent.SourceIdentifier," +
    "EObjXConsent.RetailerId," +
    "EObjXConsent.RetailerFlag," +
    "EObjXConsent.LastModifiedSystemDate," +
    "EObjXConsent.lastUpdateDt," +
    "EObjXConsent.lastUpdateUser," +
    "EObjXConsent.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getXConsentSql, pattern=tableAliasString)
  @EntityMapping(parameters=getXConsentParameters, results=getXConsentResults)
  Iterator<ResultQueue1<EObjXConsent>> getXConsent(Object[] parameters);  


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getXConsentHistorySql, pattern=tableAliasString)
  @EntityMapping(parameters=getXConsentHistoryParameters, results=getXConsentHistoryResults)
  Iterator<ResultQueue1<EObjXConsent>> getXConsentHistory(Object[] parameters);  


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getXConsentByContIdSql, pattern=tableAliasString)
  @EntityMapping(parameters=getXConsentByContIdParameters, results=getXConsentByContIdResults)
  Iterator<ResultQueue1<EObjXConsent>> getXConsentByContId(Object[] parameters);  


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getXConsentByContIdHistorySql, pattern=tableAliasString)
  @EntityMapping(parameters=getXConsentByContIdHistoryParameters, results=getXConsentByContIdHistoryResults)
  Iterator<ResultQueue1<EObjXConsent>> getXConsentByContIdHistory(Object[] parameters);  


}


