/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[11a02d02e0b8346df8d0ed393ab155ca]
 */


package com.ibm.daimler.dsea.entityObject;

import java.util.Iterator;
import com.ibm.mdm.base.db.EntityMapping;
import com.ibm.pdq.annotation.Select;
import com.ibm.pdq.annotation.Update;

import com.ibm.daimler.dsea.entityObject.EObjXCustomerRetailerRole;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * @generated
 */
public interface EObjXCustomerRetailerRoleData {


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjXCustomerRetailerRoleSql = "select CUSTOMERRETAILERROLEPK_ID, CUSTOMER_RETAILER_ID, RETAILER_ROLE_TP_CD, SOURCE_IDENT_TP_CD, START_DT, END_DT, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from XCUSTOMERRETAILERROLE where CUSTOMERRETAILERROLEPK_ID = ? ";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String createEObjXCustomerRetailerRoleSql = "insert into XCUSTOMERRETAILERROLE (CUSTOMERRETAILERROLEPK_ID, CUSTOMER_RETAILER_ID, RETAILER_ROLE_TP_CD, SOURCE_IDENT_TP_CD, START_DT, END_DT, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( :customerRetailerRolepkId, :customerRetailerId, :retailerRole, :sourceIdentifier, :startDate, :endDate, :lastUpdateDt, :lastUpdateUser, :lastUpdateTxId)";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String updateEObjXCustomerRetailerRoleSql = "update XCUSTOMERRETAILERROLE set CUSTOMER_RETAILER_ID = :customerRetailerId, RETAILER_ROLE_TP_CD = :retailerRole, SOURCE_IDENT_TP_CD = :sourceIdentifier, START_DT = :startDate, END_DT = :endDate, LAST_UPDATE_DT = :lastUpdateDt, LAST_UPDATE_USER = :lastUpdateUser, LAST_UPDATE_TX_ID = :lastUpdateTxId where CUSTOMERRETAILERROLEPK_ID = :customerRetailerRolepkId and LAST_UPDATE_DT = :oldLastUpdateDt";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String deleteEObjXCustomerRetailerRoleSql = "delete from XCUSTOMERRETAILERROLE where CUSTOMERRETAILERROLEPK_ID = ?";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXCustomerRetailerRoleKeyField = "EObjXCustomerRetailerRole.customerRetailerRolepkId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXCustomerRetailerRoleGetFields =
    "EObjXCustomerRetailerRole.customerRetailerRolepkId," +
    "EObjXCustomerRetailerRole.customerRetailerId," +
    "EObjXCustomerRetailerRole.retailerRole," +
    "EObjXCustomerRetailerRole.sourceIdentifier," +
    "EObjXCustomerRetailerRole.startDate," +
    "EObjXCustomerRetailerRole.endDate," +
    "EObjXCustomerRetailerRole.lastUpdateDt," +
    "EObjXCustomerRetailerRole.lastUpdateUser," +
    "EObjXCustomerRetailerRole.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXCustomerRetailerRoleAllFields =
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerRetailerRole.customerRetailerRolepkId," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerRetailerRole.customerRetailerId," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerRetailerRole.retailerRole," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerRetailerRole.sourceIdentifier," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerRetailerRole.startDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerRetailerRole.endDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerRetailerRole.lastUpdateDt," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerRetailerRole.lastUpdateUser," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerRetailerRole.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXCustomerRetailerRoleUpdateFields =
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerRetailerRole.customerRetailerId," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerRetailerRole.retailerRole," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerRetailerRole.sourceIdentifier," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerRetailerRole.startDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerRetailerRole.endDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerRetailerRole.lastUpdateDt," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerRetailerRole.lastUpdateUser," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerRetailerRole.lastUpdateTxId," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerRetailerRole.customerRetailerRolepkId," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerRetailerRole.oldLastUpdateDt";   

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Select XCustomerRetailerRole by parameters.
   * @generated
   */
  @Select(sql=getEObjXCustomerRetailerRoleSql)
  @EntityMapping(parameters=EObjXCustomerRetailerRoleKeyField, results=EObjXCustomerRetailerRoleGetFields)
  Iterator<EObjXCustomerRetailerRole> getEObjXCustomerRetailerRole(Long customerRetailerRolepkId);  
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Create XCustomerRetailerRole by EObjXCustomerRetailerRole Object.
   * @generated
   */
  @Update(sql=createEObjXCustomerRetailerRoleSql)
  @EntityMapping(parameters=EObjXCustomerRetailerRoleAllFields)
    int createEObjXCustomerRetailerRole(EObjXCustomerRetailerRole e); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Update one XCustomerRetailerRole by EObjXCustomerRetailerRole object.
   * @generated
   */
  @Update(sql=updateEObjXCustomerRetailerRoleSql)
  @EntityMapping(parameters=EObjXCustomerRetailerRoleUpdateFields)
    int updateEObjXCustomerRetailerRole(EObjXCustomerRetailerRole e); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Delete XCustomerRetailerRole by parameters.
   * @generated
   */
  @Update(sql=deleteEObjXCustomerRetailerRoleSql)
  @EntityMapping(parameters=EObjXCustomerRetailerRoleKeyField)
  int deleteEObjXCustomerRetailerRole(Long customerRetailerRolepkId);

}

