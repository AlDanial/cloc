package com.ibm.daimler.dsea.entityObject;

import com.ibm.pdq.runtime.generator.BaseParameterHandler;
import java.util.Iterator;
import com.ibm.daimler.dsea.entityObject.EObjXCustomerRetailerRole;
import java.sql.PreparedStatement;
import com.ibm.pdq.runtime.statement.StatementDescriptor;
import com.ibm.pdq.runtime.generator.BaseData;
import java.sql.SQLException;
import com.ibm.pdq.annotation.Metadata;
import com.ibm.pdq.runtime.generator.BaseRowHandler;
import com.ibm.pdq.runtime.statement.SqlStatementType;
import java.sql.Types;


/**
 * <!-- begin-user-doc -->
 * 
 * <!-- end-user-doc -->
 * 
 * @generated
 */
public class EObjXCustomerRetailerRoleDataImpl  extends BaseData implements EObjXCustomerRetailerRoleData
{

  /**
   * @generated
   */
  public static final String generatorVersion = "3.200.75";

  /**
   * @generated
   */
  public static final String identifier = "EObjXCustomerRetailerRoleData";

  /**
   * @generated
   */
  public static final long generationTime = 0x0000015e13f839d0L;

  /**
   * @generated
   */
  public static final String collection = "NULLID";

  /**
   * @generated
   */
  public static final String packageVersion = null;

  /**
   * @generated
   */
  public static final boolean forceSingleBindIsolation = false;

  /**
   * @generated
   */
  public EObjXCustomerRetailerRoleDataImpl()
  {
    super();
  } 

  /**
   * @generated
   */
  public String getGeneratorVersion()
  {
    return generatorVersion;
  }

  /**
   * @Select( sql="select CUSTOMERRETAILERROLEPK_ID, CUSTOMER_RETAILER_ID, RETAILER_ROLE_TP_CD, SOURCE_IDENT_TP_CD, START_DT, END_DT, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from XCUSTOMERRETAILERROLE where CUSTOMERRETAILERROLEPK_ID = ? " )
   * 
   * @generated
   */
  public Iterator<EObjXCustomerRetailerRole> getEObjXCustomerRetailerRole (Long customerRetailerRolepkId)
  {
    return queryIterator (getEObjXCustomerRetailerRoleStatementDescriptor, customerRetailerRolepkId);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getEObjXCustomerRetailerRoleStatementDescriptor = createStatementDescriptor (
    "getEObjXCustomerRetailerRole(Long)",
    "select CUSTOMERRETAILERROLEPK_ID, CUSTOMER_RETAILER_ID, RETAILER_ROLE_TP_CD, SOURCE_IDENT_TP_CD, START_DT, END_DT, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from XCUSTOMERRETAILERROLE where CUSTOMERRETAILERROLEPK_ID = ? ",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"customerretailerrolepk_id", "customer_retailer_id", "retailer_role_tp_cd", "source_ident_tp_cd", "start_dt", "end_dt", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetEObjXCustomerRetailerRoleParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetEObjXCustomerRetailerRoleRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 19, 19, 19, 0, 0, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    1);

  /**
   * @generated
   */
  public static class GetEObjXCustomerRetailerRoleParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setLong (stmt, 1, Types.BIGINT, (Long)parameters[0]);
    }
  }

  /**
   * @generated
   */
  public static class GetEObjXCustomerRetailerRoleRowHandler extends BaseRowHandler<EObjXCustomerRetailerRole>
  {
    /**
     * @generated
     */
    public EObjXCustomerRetailerRole handle (java.sql.ResultSet rs, EObjXCustomerRetailerRole returnObject) throws java.sql.SQLException
    {
      returnObject = new EObjXCustomerRetailerRole ();
      returnObject.setCustomerRetailerRolepkId(getLongObject (rs, 1)); 
      returnObject.setCustomerRetailerId(getLongObject (rs, 2)); 
      returnObject.setRetailerRole(getLongObject (rs, 3)); 
      returnObject.setSourceIdentifier(getLongObject (rs, 4)); 
      returnObject.setStartDate(getTimestamp (rs, 5)); 
      returnObject.setEndDate(getTimestamp (rs, 6)); 
      returnObject.setLastUpdateDt(getTimestamp (rs, 7)); 
      returnObject.setLastUpdateUser(getString (rs, 8)); 
      returnObject.setLastUpdateTxId(getLongObject (rs, 9)); 
    
      return returnObject;
    }
  }

  /**
   * @Update( sql="insert into XCUSTOMERRETAILERROLE (CUSTOMERRETAILERROLEPK_ID, CUSTOMER_RETAILER_ID, RETAILER_ROLE_TP_CD, SOURCE_IDENT_TP_CD, START_DT, END_DT, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( :customerRetailerRolepkId, :customerRetailerId, :retailerRole, :sourceIdentifier, :startDate, :endDate, :lastUpdateDt, :lastUpdateUser, :lastUpdateTxId)" )
   * 
   * @generated
   */
  public int createEObjXCustomerRetailerRole (EObjXCustomerRetailerRole e)
  {
    return update (createEObjXCustomerRetailerRoleStatementDescriptor, e);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor createEObjXCustomerRetailerRoleStatementDescriptor = createStatementDescriptor (
    "createEObjXCustomerRetailerRole(com.ibm.daimler.dsea.entityObject.EObjXCustomerRetailerRole)",
    "insert into XCUSTOMERRETAILERROLE (CUSTOMERRETAILERROLEPK_ID, CUSTOMER_RETAILER_ID, RETAILER_ROLE_TP_CD, SOURCE_IDENT_TP_CD, START_DT, END_DT, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values(  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? )",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.INSERT,
    null,
    new CreateEObjXCustomerRetailerRoleParameterHandler (),
    new int[][]{{Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 19, 19, 19, 0, 0, 0, 0, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1, 1, 1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    2);

  /**
   * @generated
   */
  public static class CreateEObjXCustomerRetailerRoleParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      EObjXCustomerRetailerRole bean0 = (EObjXCustomerRetailerRole) parameters[0];
      setLong (stmt, 1, Types.BIGINT, (Long)bean0.getCustomerRetailerRolepkId());
      setLong (stmt, 2, Types.BIGINT, (Long)bean0.getCustomerRetailerId());
      setLong (stmt, 3, Types.BIGINT, (Long)bean0.getRetailerRole());
      setLong (stmt, 4, Types.BIGINT, (Long)bean0.getSourceIdentifier());
      setTimestamp (stmt, 5, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getStartDate());
      setTimestamp (stmt, 6, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getEndDate());
      setTimestamp (stmt, 7, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUpdateDt());
      setString (stmt, 8, Types.VARCHAR, (String)bean0.getLastUpdateUser());
      setLong (stmt, 9, Types.BIGINT, (Long)bean0.getLastUpdateTxId());
    }
  }

  /**
   * @Update( sql="update XCUSTOMERRETAILERROLE set CUSTOMER_RETAILER_ID = :customerRetailerId, RETAILER_ROLE_TP_CD = :retailerRole, SOURCE_IDENT_TP_CD = :sourceIdentifier, START_DT = :startDate, END_DT = :endDate, LAST_UPDATE_DT = :lastUpdateDt, LAST_UPDATE_USER = :lastUpdateUser, LAST_UPDATE_TX_ID = :lastUpdateTxId where CUSTOMERRETAILERROLEPK_ID = :customerRetailerRolepkId and LAST_UPDATE_DT = :oldLastUpdateDt" )
   * 
   * @generated
   */
  public int updateEObjXCustomerRetailerRole (EObjXCustomerRetailerRole e)
  {
    return update (updateEObjXCustomerRetailerRoleStatementDescriptor, e);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor updateEObjXCustomerRetailerRoleStatementDescriptor = createStatementDescriptor (
    "updateEObjXCustomerRetailerRole(com.ibm.daimler.dsea.entityObject.EObjXCustomerRetailerRole)",
    "update XCUSTOMERRETAILERROLE set CUSTOMER_RETAILER_ID =  ? , RETAILER_ROLE_TP_CD =  ? , SOURCE_IDENT_TP_CD =  ? , START_DT =  ? , END_DT =  ? , LAST_UPDATE_DT =  ? , LAST_UPDATE_USER =  ? , LAST_UPDATE_TX_ID =  ?  where CUSTOMERRETAILERROLEPK_ID =  ?  and LAST_UPDATE_DT =  ? ",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.UPDATE,
    null,
    new UpdateEObjXCustomerRetailerRoleParameterHandler (),
    new int[][]{{Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP}, {19, 19, 19, 0, 0, 0, 0, 19, 19, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1, 1, 1, 1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    3);

  /**
   * @generated
   */
  public static class UpdateEObjXCustomerRetailerRoleParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      EObjXCustomerRetailerRole bean0 = (EObjXCustomerRetailerRole) parameters[0];
      setLong (stmt, 1, Types.BIGINT, (Long)bean0.getCustomerRetailerId());
      setLong (stmt, 2, Types.BIGINT, (Long)bean0.getRetailerRole());
      setLong (stmt, 3, Types.BIGINT, (Long)bean0.getSourceIdentifier());
      setTimestamp (stmt, 4, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getStartDate());
      setTimestamp (stmt, 5, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getEndDate());
      setTimestamp (stmt, 6, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUpdateDt());
      setString (stmt, 7, Types.VARCHAR, (String)bean0.getLastUpdateUser());
      setLong (stmt, 8, Types.BIGINT, (Long)bean0.getLastUpdateTxId());
      setLong (stmt, 9, Types.BIGINT, (Long)bean0.getCustomerRetailerRolepkId());
      setTimestamp (stmt, 10, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getOldLastUpdateDt());
    }
  }

  /**
   * @Update( sql="delete from XCUSTOMERRETAILERROLE where CUSTOMERRETAILERROLEPK_ID = ?" )
   * 
   * @generated
   */
  public int deleteEObjXCustomerRetailerRole (Long customerRetailerRolepkId)
  {
    return update (deleteEObjXCustomerRetailerRoleStatementDescriptor, customerRetailerRolepkId);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor deleteEObjXCustomerRetailerRoleStatementDescriptor = createStatementDescriptor (
    "deleteEObjXCustomerRetailerRole(Long)",
    "delete from XCUSTOMERRETAILERROLE where CUSTOMERRETAILERROLEPK_ID = ?",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.DELETE,
    null,
    new DeleteEObjXCustomerRetailerRoleParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    4);

  /**
   * @generated
   */
  public static class DeleteEObjXCustomerRetailerRoleParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setLong (stmt, 1, Types.BIGINT, (Long)parameters[0]);
    }
  }

}
