package com.ibm.daimler.dsea.entityObject;

import com.ibm.pdq.runtime.generator.BaseParameterHandler;
import java.util.Iterator;
import com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt;
import java.sql.PreparedStatement;
import com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup;
import com.ibm.pdq.runtime.statement.StatementDescriptor;
import com.ibm.pdq.runtime.generator.BaseData;
import java.sql.SQLException;
import com.ibm.pdq.annotation.Metadata;
import com.ibm.pdq.runtime.generator.BaseRowHandler;
import com.ibm.pdq.runtime.statement.SqlStatementType;
import java.sql.Types;


/**
 * <!-- begin-user-doc -->
 * 
 * <!-- end-user-doc -->
 * 
 * @generated
 */
public class EObjXAddressGroupExtDataImpl  extends BaseData implements EObjXAddressGroupExtData
{

  /**
   * @generated
   */
  public static final String generatorVersion = "3.200.75";

  /**
   * @generated
   */
  public static final String identifier = "EObjXAddressGroupExtData";

  /**
   * @generated
   */
  public static final long generationTime = 0x00000164c354c381L;

  /**
   * @generated
   */
  public static final String collection = "NULLID";

  /**
   * @generated
   */
  public static final String packageVersion = null;

  /**
   * @generated
   */
  public static final boolean forceSingleBindIsolation = false;

  /**
   * @generated
   */
  public EObjXAddressGroupExtDataImpl()
  {
    super();
  } 

  /**
   * @generated
   */
  public String getGeneratorVersion()
  {
    return generatorVersion;
  }

  /**
   * @Select( sql="select XVERIFIED_TP_CD, XRETAILER_ID, XMODIFY_SYS_DT, XADDR_RETAILER_FLAG, TITLE_OF_HONOR, COMPANY_NAME, SFAddress_Id, X_BPID, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from ADDRESSGROUP where LOCATION_GROUP_ID = ? " )
   * 
   * @generated
   */
  public Iterator<EObjXAddressGroupExt> getEObjXAddressGroupExt (Long locationGroupIdPK)
  {
    return queryIterator (getEObjXAddressGroupExtStatementDescriptor, locationGroupIdPK);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getEObjXAddressGroupExtStatementDescriptor = createStatementDescriptor (
    "getEObjXAddressGroupExt(Long)",
    "select XVERIFIED_TP_CD, XRETAILER_ID, XMODIFY_SYS_DT, XADDR_RETAILER_FLAG, TITLE_OF_HONOR, COMPANY_NAME, SFAddress_Id, X_BPID, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from ADDRESSGROUP where LOCATION_GROUP_ID = ? ",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"xverified_tp_cd", "xretailer_id", "xmodify_sys_dt", "xaddr_retailer_flag", "title_of_honor", "company_name", "sfaddress_id", "x_bpid", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetEObjXAddressGroupExtParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetEObjXAddressGroupExtRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 19, 0, 5, 255, 255, 250, 50, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    1);

  /**
   * @generated
   */
  public static class GetEObjXAddressGroupExtParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setLong (stmt, 1, Types.BIGINT, (Long)parameters[0]);
    }
  }

  /**
   * @generated
   */
  public static class GetEObjXAddressGroupExtRowHandler extends BaseRowHandler<EObjXAddressGroupExt>
  {
    /**
     * @generated
     */
    public EObjXAddressGroupExt handle (java.sql.ResultSet rs, EObjXAddressGroupExt returnObject) throws java.sql.SQLException
    {
      returnObject = new EObjXAddressGroupExt ();
      returnObject.setXVerified(getLongObject (rs, 1)); 
      returnObject.setXRetailerId(getLongObject (rs, 2)); 
      returnObject.setXLastModifiedSystemDate(getTimestamp (rs, 3)); 
      returnObject.setXAddressRetailerFlag(getString (rs, 4)); 
      returnObject.setTitleOfHonor(getString (rs, 5)); 
      returnObject.setCompanyName(getString (rs, 6)); 
      returnObject.setSFAddressId(getString (rs, 7)); 
      returnObject.setX_BPID(getString (rs, 8)); 
      returnObject.setLastUpdateDt(getTimestamp (rs, 9)); 
      returnObject.setLastUpdateUser(getString (rs, 10)); 
      returnObject.setLastUpdateTxId(getLongObject (rs, 11)); 
    
      return returnObject;
    }
  }

  /**
   * @Update( sql="insert into ADDRESSGROUP (ADDRESS_ID, CARE_OF_DESC, LOCATION_GROUP_ID, ADDR_USAGE_TP_CD, XVERIFIED_TP_CD, XRETAILER_ID, XMODIFY_SYS_DT, XADDR_RETAILER_FLAG, TITLE_OF_HONOR, COMPANY_NAME, SFAddress_Id, X_BPID, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( ?1.addressId, ?1.careOfDesc, ?1.locationGroupIdPK, ?1.addrUsageTpCd, ?2.xVerified, ?2.xRetailerId, ?2.xLastModifiedSystemDate, ?2.xAddressRetailerFlag, ?2.titleOfHonor, ?2.companyName, ?2.sFAddressId, ?2.x_BPID, ?1.lastUpdateDt, ?1.lastUpdateUser, ?1.lastUpdateTxId)" )
   * 
   * @generated
   */
  public int createEObjXAddressGroupExt (EObjAddressGroup e1, EObjXAddressGroupExt e2)
  {
    return update (createEObjXAddressGroupExtStatementDescriptor, e1, e2);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor createEObjXAddressGroupExtStatementDescriptor = createStatementDescriptor (
    "createEObjXAddressGroupExt(com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup, com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt)",
    "insert into ADDRESSGROUP (ADDRESS_ID, CARE_OF_DESC, LOCATION_GROUP_ID, ADDR_USAGE_TP_CD, XVERIFIED_TP_CD, XRETAILER_ID, XMODIFY_SYS_DT, XADDR_RETAILER_FLAG, TITLE_OF_HONOR, COMPANY_NAME, SFAddress_Id, X_BPID, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values(  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? )",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.INSERT,
    null,
    new CreateEObjXAddressGroupExtParameterHandler (),
    new int[][]{{Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 50, 19, 19, 19, 19, 0, 5, 255, 255, 250, 50, 0, 0, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    2);

  /**
   * @generated
   */
  public static class CreateEObjXAddressGroupExtParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      EObjAddressGroup bean0 = (EObjAddressGroup) parameters[0];
      setLong (stmt, 1, Types.BIGINT, (Long)bean0.getAddressId());
      setString (stmt, 2, Types.VARCHAR, (String)bean0.getCareOfDesc());
      setLong (stmt, 3, Types.BIGINT, (Long)bean0.getLocationGroupIdPK());
      setLong (stmt, 4, Types.BIGINT, (Long)bean0.getAddrUsageTpCd());
      EObjXAddressGroupExt bean1 = (EObjXAddressGroupExt) parameters[1];
      setLong (stmt, 5, Types.BIGINT, (Long)bean1.getXVerified());
      setLong (stmt, 6, Types.BIGINT, (Long)bean1.getXRetailerId());
      setTimestamp (stmt, 7, Types.TIMESTAMP, (java.sql.Timestamp)bean1.getXLastModifiedSystemDate());
      setString (stmt, 8, Types.VARCHAR, (String)bean1.getXAddressRetailerFlag());
      setString (stmt, 9, Types.VARCHAR, (String)bean1.getTitleOfHonor());
      setString (stmt, 10, Types.VARCHAR, (String)bean1.getCompanyName());
      setString (stmt, 11, Types.VARCHAR, (String)bean1.getSFAddressId());
      setString (stmt, 12, Types.VARCHAR, (String)bean1.getX_BPID());
      setTimestamp (stmt, 13, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUpdateDt());
      setString (stmt, 14, Types.VARCHAR, (String)bean0.getLastUpdateUser());
      setLong (stmt, 15, Types.BIGINT, (Long)bean0.getLastUpdateTxId());
    }
  }

  /**
   * @Update( sql="update ADDRESSGROUP set ADDRESS_ID = ?1.addressId, CARE_OF_DESC = ?1.careOfDesc, ADDR_USAGE_TP_CD = ?1.addrUsageTpCd, XVERIFIED_TP_CD = ?2.xVerified, XRETAILER_ID = ?2.xRetailerId, XMODIFY_SYS_DT = ?2.xLastModifiedSystemDate, XADDR_RETAILER_FLAG = ?2.xAddressRetailerFlag, TITLE_OF_HONOR = ?2.titleOfHonor, COMPANY_NAME = ?2.companyName, SFAddress_Id = ?2.sFAddressId, X_BPID = ?2.x_BPID, LAST_UPDATE_DT = ?1.lastUpdateDt, LAST_UPDATE_USER = ?1.lastUpdateUser, LAST_UPDATE_TX_ID = ?1.lastUpdateTxId where LOCATION_GROUP_ID = ?1.locationGroupIdPK and LAST_UPDATE_DT = ?1.oldLastUpdateDt" )
   * 
   * @generated
   */
  public int updateEObjXAddressGroupExt (EObjAddressGroup e1, EObjXAddressGroupExt e2)
  {
    return update (updateEObjXAddressGroupExtStatementDescriptor, e1, e2);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor updateEObjXAddressGroupExtStatementDescriptor = createStatementDescriptor (
    "updateEObjXAddressGroupExt(com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup, com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt)",
    "update ADDRESSGROUP set ADDRESS_ID =  ? , CARE_OF_DESC =  ? , ADDR_USAGE_TP_CD =  ? , XVERIFIED_TP_CD =  ? , XRETAILER_ID =  ? , XMODIFY_SYS_DT =  ? , XADDR_RETAILER_FLAG =  ? , TITLE_OF_HONOR =  ? , COMPANY_NAME =  ? , SFAddress_Id =  ? , X_BPID =  ? , LAST_UPDATE_DT =  ? , LAST_UPDATE_USER =  ? , LAST_UPDATE_TX_ID =  ?  where LOCATION_GROUP_ID =  ?  and LAST_UPDATE_DT =  ? ",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.UPDATE,
    null,
    new UpdateEObjXAddressGroupExtParameterHandler (),
    new int[][]{{Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP}, {19, 50, 19, 19, 19, 0, 5, 255, 255, 250, 50, 0, 0, 19, 19, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    3);

  /**
   * @generated
   */
  public static class UpdateEObjXAddressGroupExtParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      EObjAddressGroup bean0 = (EObjAddressGroup) parameters[0];
      setLong (stmt, 1, Types.BIGINT, (Long)bean0.getAddressId());
      setString (stmt, 2, Types.VARCHAR, (String)bean0.getCareOfDesc());
      setLong (stmt, 3, Types.BIGINT, (Long)bean0.getAddrUsageTpCd());
      EObjXAddressGroupExt bean1 = (EObjXAddressGroupExt) parameters[1];
      setLong (stmt, 4, Types.BIGINT, (Long)bean1.getXVerified());
      setLong (stmt, 5, Types.BIGINT, (Long)bean1.getXRetailerId());
      setTimestamp (stmt, 6, Types.TIMESTAMP, (java.sql.Timestamp)bean1.getXLastModifiedSystemDate());
      setString (stmt, 7, Types.VARCHAR, (String)bean1.getXAddressRetailerFlag());
      setString (stmt, 8, Types.VARCHAR, (String)bean1.getTitleOfHonor());
      setString (stmt, 9, Types.VARCHAR, (String)bean1.getCompanyName());
      setString (stmt, 10, Types.VARCHAR, (String)bean1.getSFAddressId());
      setString (stmt, 11, Types.VARCHAR, (String)bean1.getX_BPID());
      setTimestamp (stmt, 12, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUpdateDt());
      setString (stmt, 13, Types.VARCHAR, (String)bean0.getLastUpdateUser());
      setLong (stmt, 14, Types.BIGINT, (Long)bean0.getLastUpdateTxId());
      setLong (stmt, 15, Types.BIGINT, (Long)bean0.getLocationGroupIdPK());
      setTimestamp (stmt, 16, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getOldLastUpdateDt());
    }
  }

  /**
   * @Update( sql="delete from ADDRESSGROUP where LOCATION_GROUP_ID = ?" )
   * 
   * @generated
   */
  public int deleteEObjXAddressGroupExt (Long locationGroupIdPK)
  {
    return update (deleteEObjXAddressGroupExtStatementDescriptor, locationGroupIdPK);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor deleteEObjXAddressGroupExtStatementDescriptor = createStatementDescriptor (
    "deleteEObjXAddressGroupExt(Long)",
    "delete from ADDRESSGROUP where LOCATION_GROUP_ID = ?",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.DELETE,
    null,
    new DeleteEObjXAddressGroupExtParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    4);

  /**
   * @generated
   */
  public static class DeleteEObjXAddressGroupExtParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setLong (stmt, 1, Types.BIGINT, (Long)parameters[0]);
    }
  }

}
