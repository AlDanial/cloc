/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[dbf6671b997b2cbe6fa14d00dccd3eb4]
 */
package com.ibm.daimler.dsea.entityObject;


import com.ibm.mdm.base.db.EntityMapping;
import com.ibm.pdq.annotation.Select;


import com.dwl.tcrm.financial.entityObject.EObjContract;

import com.ibm.mdm.base.db.ResultQueue2;

import java.util.Iterator;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * 
 * @generated
 */
public interface XContractExtInquiryData {

  /**
   * MDM_TODO: CDKWB0050I The generated parameter and result lists in this file should be checked to ensure that each matches its
   * associated SQL query. Each list entry must be comma separated and identify a field within an entity object class.
   */ 
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */ 
   public final static String tableAliasString1 = "tableAlias (" + 
     "CONTRACT => com.dwl.tcrm.financial.entityObject.EObjContract, " + 
     "H_CONTRACT => com.dwl.tcrm.financial.entityObject.EObjContract , " + 
     "CONTRACT => com.ibm.daimler.dsea.entityObject.EObjXContractExt , " + 
     "H_CONTRACT => com.ibm.daimler.dsea.entityObject.EObjXContractExt" + 
     ")";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension XContract.
   *
   * @generated
   */ 
   public final static String getEObjCONTRACT_HISTORYSQL = "SELECT DISTINCT A.H_CONTRACT_ID AS HIST_ID_PK , A.H_ACTION_CODE , A.H_CREATED_BY , A.H_CREATE_DT , A.H_END_DT , A.CONTRACT_ID , A.CURRENCY_TP_CD , A.FREQ_MODE_TP_CD , A.CONTR_LANG_TP_CD , A.LINE_OF_BUSINESS , A.BILL_TP_CD , A.REPL_BY_CONTRACT , A.PREMIUM_AMT , A.PREMAMT_CUR_TP , A.NEXT_BILL_DT , A.CURR_CASH_VAL_AMT , A.CASHVAL_CUR_TP , A.BRAND_NAME , A.SERVICE_ORG_NAME , A.BUS_ORGUNIT_ID , A.LAST_UPDATE_DT , A.LAST_UPDATE_USER , A.SERVICE_PROV_ID , A.LAST_UPDATE_TX_ID , A.ISSUE_LOCATION , A.MANAGED_ACCOUNT_IND , A.AGREEMENT_NAME , A.AGREEMENT_NICKNAME , A.SIGNED_DT , A.EXECUTED_DT , A.END_DT , A.REPLACES_CONTRACT , A.ACCOUNT_LAST_TRANSACTION_DT , A.TERMINATION_DT , A.TERMINATION_REASON_TP_CD , A.AGREEMENT_DESCRIPTION , A.AGREEMENT_ST_TP_CD , A.AGREEMENT_TP_CD , A.SERVICE_LEVEL_TP_CD , A.LAST_VERIFIED_DT , A.LAST_REVIEWED_DT , A.PRODUCT_ID , A.ADMIN_CONTRACT_ID , A.ADMIN_SYS_TP_CD , A.ACCESS_TOKEN_VALUE , A.CLUSTER_KEY, A.XCONTRACT_NUM" + 
     " FROM H_CONTRACT A" + 
     " WHERE A.H_CONTRACT_ID = ? AND (( ? BETWEEN A.H_CREATE_DT AND A.H_END_DT ) OR ( ? >= A.H_CREATE_DT AND A.H_END_DT IS NULL ))";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjCONTRACT_HISTORYParameters =
    "com.dwl.tcrm.financial.entityObject.EObjContract.historyIdPK=H_CONTRACT_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContract.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContract.histCreateDt=H_CREATE_DT"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjCONTRACT_HISTORYResults =
    "com.dwl.tcrm.financial.entityObject.EObjContract.historyIdPK=HIST_ID_PK," + 
    "com.dwl.tcrm.financial.entityObject.EObjContract.histActionCode=H_ACTION_CODE," + 
    "com.dwl.tcrm.financial.entityObject.EObjContract.histCreatedBy=H_CREATED_BY," + 
    "com.dwl.tcrm.financial.entityObject.EObjContract.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContract.histEndDt=H_END_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContract.contractIdPK=CONTRACT_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContract.currencyTpCd=CURRENCY_TP_CD," + 
    "com.dwl.tcrm.financial.entityObject.EObjContract.freqModeTpCd=FREQ_MODE_TP_CD," + 
    "com.dwl.tcrm.financial.entityObject.EObjContract.contrLangTpCd=CONTR_LANG_TP_CD," + 
    "com.dwl.tcrm.financial.entityObject.EObjContract.lineOfBusiness=LINE_OF_BUSINESS," + 
    "com.dwl.tcrm.financial.entityObject.EObjContract.billTpCd=BILL_TP_CD," + 
    "com.dwl.tcrm.financial.entityObject.EObjContract.replByContract=REPL_BY_CONTRACT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContract.premiumAmt=PREMIUM_AMT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContract.premiumAmtCurTpCd=PREMAMT_CUR_TP," + 
    "com.dwl.tcrm.financial.entityObject.EObjContract.nextBillDt=NEXT_BILL_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContract.currCashValAmt=CURR_CASH_VAL_AMT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContract.currCashValAmtCurTpCd=CASHVAL_CUR_TP," + 
    "com.dwl.tcrm.financial.entityObject.EObjContract.brandName=BRAND_NAME," + 
    "com.dwl.tcrm.financial.entityObject.EObjContract.serviceOrgName=SERVICE_ORG_NAME," + 
    "com.dwl.tcrm.financial.entityObject.EObjContract.busOrgunitId=BUS_ORGUNIT_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContract.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContract.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.financial.entityObject.EObjContract.serviceProvId=SERVICE_PROV_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContract.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContract.issueLocation=ISSUE_LOCATION," + 
    "com.dwl.tcrm.financial.entityObject.EObjContract.managedAccountIndicator=MANAGED_ACCOUNT_IND," + 
    "com.dwl.tcrm.financial.entityObject.EObjContract.agreementName=AGREEMENT_NAME," + 
    "com.dwl.tcrm.financial.entityObject.EObjContract.agreementNickName=AGREEMENT_NICKNAME," + 
    "com.dwl.tcrm.financial.entityObject.EObjContract.signedDate=SIGNED_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContract.executedDate=EXECUTED_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContract.endDate=END_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContract.replacesContract=REPLACES_CONTRACT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContract.accountLastTransactionDate=ACCOUNT_LAST_TRANSACTION_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContract.terminationDate=TERMINATION_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContract.terminationReasonType=TERMINATION_REASON_TP_CD," + 
    "com.dwl.tcrm.financial.entityObject.EObjContract.agreementDescription=AGREEMENT_DESCRIPTION," + 
    "com.dwl.tcrm.financial.entityObject.EObjContract.agreementStatusType=AGREEMENT_ST_TP_CD," + 
    "com.dwl.tcrm.financial.entityObject.EObjContract.agreementType=AGREEMENT_TP_CD," + 
    "com.dwl.tcrm.financial.entityObject.EObjContract.serviceLevelType=SERVICE_LEVEL_TP_CD," + 
    "com.dwl.tcrm.financial.entityObject.EObjContract.lastVerifiedDate=LAST_VERIFIED_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContract.lastReviewedDate=LAST_REVIEWED_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContract.productId=PRODUCT_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContract.adminContractId=ADMIN_CONTRACT_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContract.adminSysTpCd=ADMIN_SYS_TP_CD," + 
    "com.dwl.tcrm.financial.entityObject.EObjContract.accessTokenValue=ACCESS_TOKEN_VALUE," + 
    "com.dwl.tcrm.financial.entityObject.EObjContract.clusterKey=CLUSTER_KEY," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContractExt.XContractNum=XCONTRACT_NUM"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension XContract.
   *
   * @generated
   */ 
   public final static String getEObjCONTRACTSQL = "SELECT CONTRACT.CONTRACT_ID , CONTRACT.CURRENCY_TP_CD , CONTRACT.FREQ_MODE_TP_CD , CONTRACT.CONTR_LANG_TP_CD , CONTRACT.LINE_OF_BUSINESS , CONTRACT.BILL_TP_CD , CONTRACT.REPL_BY_CONTRACT , CONTRACT.PREMIUM_AMT , CONTRACT.PREMAMT_CUR_TP , CONTRACT.NEXT_BILL_DT , CONTRACT.CURR_CASH_VAL_AMT , CONTRACT.CASHVAL_CUR_TP , CONTRACT.BRAND_NAME , CONTRACT.SERVICE_ORG_NAME , CONTRACT.BUS_ORGUNIT_ID , CONTRACT.LAST_UPDATE_DT , CONTRACT.LAST_UPDATE_USER , CONTRACT.SERVICE_PROV_ID , CONTRACT.LAST_UPDATE_TX_ID , CONTRACT.ISSUE_LOCATION , CONTRACT.MANAGED_ACCOUNT_IND , CONTRACT.AGREEMENT_NAME , CONTRACT.AGREEMENT_NICKNAME , CONTRACT.SIGNED_DT , CONTRACT.EXECUTED_DT , CONTRACT.END_DT , CONTRACT.REPLACES_CONTRACT , CONTRACT.ACCOUNT_LAST_TRANSACTION_DT , CONTRACT.TERMINATION_DT , CONTRACT.TERMINATION_REASON_TP_CD , CONTRACT.AGREEMENT_DESCRIPTION , CONTRACT.AGREEMENT_ST_TP_CD , CONTRACT.AGREEMENT_TP_CD , CONTRACT.SERVICE_LEVEL_TP_CD , CONTRACT.LAST_VERIFIED_DT , CONTRACT.LAST_REVIEWED_DT , CONTRACT.PRODUCT_ID , CONTRACT.ADMIN_CONTRACT_ID , CONTRACT.ADMIN_SYS_TP_CD , CONTRACT.ACCESS_TOKEN_VALUE , CONTRACT.CLUSTER_KEY, CONTRACT.XCONTRACT_NUM" + 
     " FROM CONTRACT" + 
     " WHERE CONTRACT.CONTRACT_ID = ?";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjCONTRACTParameters =
    "com.dwl.tcrm.financial.entityObject.EObjContract.contractIdPK=CONTRACT_ID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjCONTRACTResults =
    "com.dwl.tcrm.financial.entityObject.EObjContract.contractIdPK=CONTRACT_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContract.currencyTpCd=CURRENCY_TP_CD," + 
    "com.dwl.tcrm.financial.entityObject.EObjContract.freqModeTpCd=FREQ_MODE_TP_CD," + 
    "com.dwl.tcrm.financial.entityObject.EObjContract.contrLangTpCd=CONTR_LANG_TP_CD," + 
    "com.dwl.tcrm.financial.entityObject.EObjContract.lineOfBusiness=LINE_OF_BUSINESS," + 
    "com.dwl.tcrm.financial.entityObject.EObjContract.billTpCd=BILL_TP_CD," + 
    "com.dwl.tcrm.financial.entityObject.EObjContract.replByContract=REPL_BY_CONTRACT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContract.premiumAmt=PREMIUM_AMT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContract.premiumAmtCurTpCd=PREMAMT_CUR_TP," + 
    "com.dwl.tcrm.financial.entityObject.EObjContract.nextBillDt=NEXT_BILL_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContract.currCashValAmt=CURR_CASH_VAL_AMT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContract.currCashValAmtCurTpCd=CASHVAL_CUR_TP," + 
    "com.dwl.tcrm.financial.entityObject.EObjContract.brandName=BRAND_NAME," + 
    "com.dwl.tcrm.financial.entityObject.EObjContract.serviceOrgName=SERVICE_ORG_NAME," + 
    "com.dwl.tcrm.financial.entityObject.EObjContract.busOrgunitId=BUS_ORGUNIT_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContract.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContract.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.financial.entityObject.EObjContract.serviceProvId=SERVICE_PROV_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContract.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContract.issueLocation=ISSUE_LOCATION," + 
    "com.dwl.tcrm.financial.entityObject.EObjContract.managedAccountIndicator=MANAGED_ACCOUNT_IND," + 
    "com.dwl.tcrm.financial.entityObject.EObjContract.agreementName=AGREEMENT_NAME," + 
    "com.dwl.tcrm.financial.entityObject.EObjContract.agreementNickName=AGREEMENT_NICKNAME," + 
    "com.dwl.tcrm.financial.entityObject.EObjContract.signedDate=SIGNED_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContract.executedDate=EXECUTED_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContract.endDate=END_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContract.replacesContract=REPLACES_CONTRACT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContract.accountLastTransactionDate=ACCOUNT_LAST_TRANSACTION_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContract.terminationDate=TERMINATION_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContract.terminationReasonType=TERMINATION_REASON_TP_CD," + 
    "com.dwl.tcrm.financial.entityObject.EObjContract.agreementDescription=AGREEMENT_DESCRIPTION," + 
    "com.dwl.tcrm.financial.entityObject.EObjContract.agreementStatusType=AGREEMENT_ST_TP_CD," + 
    "com.dwl.tcrm.financial.entityObject.EObjContract.agreementType=AGREEMENT_TP_CD," + 
    "com.dwl.tcrm.financial.entityObject.EObjContract.serviceLevelType=SERVICE_LEVEL_TP_CD," + 
    "com.dwl.tcrm.financial.entityObject.EObjContract.lastVerifiedDate=LAST_VERIFIED_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContract.lastReviewedDate=LAST_REVIEWED_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContract.productId=PRODUCT_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContract.adminContractId=ADMIN_CONTRACT_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContract.adminSysTpCd=ADMIN_SYS_TP_CD," + 
    "com.dwl.tcrm.financial.entityObject.EObjContract.accessTokenValue=ACCESS_TOKEN_VALUE," + 
    "com.dwl.tcrm.financial.entityObject.EObjContract.clusterKey=CLUSTER_KEY," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContractExt.XContractNum=XCONTRACT_NUM"; 
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */ 
   public final static String tableAliasString2 = "tableAlias (" + 
     "CONTRACTCOMPONENT => com.dwl.tcrm.financial.entityObject.EObjContractComponent, " + 
     "H_CONTRACTCOMPONEN => com.dwl.tcrm.financial.entityObject.EObjContractComponent, " + 
     "ADDRESSGROUP => com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup, " + 
     "H_ADDRESSGROUP => com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup, " + 
     "LOCATIONGROUP => com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup, " + 
     "H_LOCATIONGROUP => com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup, " + 
     "ROLELOCATION => com.dwl.tcrm.financial.entityObject.EObjRoleLocation, " + 
     "H_ROLELOCATION => com.dwl.tcrm.financial.entityObject.EObjRoleLocation, " + 
     "CONTRACTROLE => com.dwl.tcrm.financial.entityObject.EObjContractRole, " + 
     "H_CONTRACTROLE => com.dwl.tcrm.financial.entityObject.EObjContractRole, " + 
     "CONTACTMETHODGROUP => com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup, " + 
     "H_CONTACTMETHODGRO => com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup" + 
     ")";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0061I This SQL query does not return additional fields defined by entity type extension XContract because the
   * base query only returns the primary key.
   *
   * @generated
   */ 
   public final static String getEObjCONTRACT_IDS_ALLSQL = "SELECT DISTINCT CC.CONTRACT_ID" + 
     " FROM CONTRACTROLE CR, CONTRACTCOMPONENT CC" + 
     " WHERE CC.CONTR_COMPONENT_ID = CR.CONTR_COMPONENT_ID AND CR.CONT_ID = ?";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjCONTRACT_IDS_ALLParameters =
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.contId=CONT_ID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjCONTRACT_IDS_ALLResults =
    "com.dwl.tcrm.financial.entityObject.EObjContractComponent.contractId=CONTRACT_ID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0061I This SQL query does not return additional fields defined by entity type extension XContract because the
   * base query only returns the primary key.
   *
   * @generated
   */ 
   public final static String getEObjCONTRACT_IDS_ACTIVESQL = "SELECT DISTINCT CC.CONTRACT_ID" + 
     " FROM CONTRACTROLE CR, CONTRACTCOMPONENT CC" + 
     " WHERE CC.CONTR_COMPONENT_ID = CR.CONTR_COMPONENT_ID AND CR.CONT_ID = ? AND (CR.END_DT IS NULL OR CR.END_DT > ? )";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjCONTRACT_IDS_ACTIVEParameters =
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.contId=CONT_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.endDt=END_DT"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjCONTRACT_IDS_ACTIVEResults =
    "com.dwl.tcrm.financial.entityObject.EObjContractComponent.contractId=CONTRACT_ID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0061I This SQL query does not return additional fields defined by entity type extension XContract because the
   * base query only returns the primary key.
   *
   * @generated
   */ 
   public final static String getEObjCONTRACT_IDS_INACTIVESQL = "SELECT DISTINCT CC.CONTRACT_ID" + 
     " FROM CONTRACTROLE CR, CONTRACTCOMPONENT CC" + 
     " WHERE CC.CONTR_COMPONENT_ID = CR.CONTR_COMPONENT_ID AND CR.CONT_ID = ? AND (CR.END_DT < ? )";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjCONTRACT_IDS_INACTIVEParameters =
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.contId=CONT_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.endDt=END_DT"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjCONTRACT_IDS_INACTIVEResults =
    "com.dwl.tcrm.financial.entityObject.EObjContractComponent.contractId=CONTRACT_ID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0061I This SQL query does not return additional fields defined by entity type extension XContract because the
   * base query only returns the primary key.
   *
   * @generated
   */ 
   public final static String getEObjCONTRACT_IDS_HISTORYSQL = "SELECT DISTINCT CC.CONTRACT_ID" + 
     " FROM H_CONTRACTROLE CR, H_CONTRACTCOMPONEN CC" + 
     " WHERE CC.H_CONTR_COMPONENT_ = CR.CONTR_COMPONENT_ID AND CR.CONT_ID = ? AND (? BETWEEN CR.H_CREATE_DT AND CR.H_END_DT OR ? >= CR.H_CREATE_DT AND CR.H_END_DT IS NULL )";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjCONTRACT_IDS_HISTORYParameters =
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.contId=CONT_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.histCreateDt=H_CREATE_DT"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjCONTRACT_IDS_HISTORYResults =
    "com.dwl.tcrm.financial.entityObject.EObjContractComponent.contractId=CONTRACT_ID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0061I This SQL query does not return additional fields defined by entity type extension XContract because the
   * base query only returns the primary key.
   *
   * @generated
   */ 
   public final static String getEObjCONTRACT_IDS_BY_ADDRESS_ID_HISTORYSQL = "SELECT DISTINCT H_CONTRACTCOMPONEN.CONTRACT_ID" + 
     " FROM H_ADDRESSGROUP, H_LOCATIONGROUP ,H_ROLELOCATION, H_CONTRACTROLE, H_CONTRACTCOMPONEN" + 
     " WHERE H_ADDRESSGROUP.H_LOCATION_GROUP_I=H_LOCATIONGROUP.H_LOCATION_GROUP_I AND H_LOCATIONGROUP.H_LOCATION_GROUP_I=H_ROLELOCATION.LOCATION_GROUP_ID AND H_LOCATIONGROUP.CONT_ID=H_CONTRACTROLE.CONT_ID AND H_CONTRACTROLE.CONTR_COMPONENT_ID=H_CONTRACTCOMPONEN.H_CONTR_COMPONENT_ AND H_ROLELOCATION.CONTRACT_ROLE_ID = H_CONTRACTROLE.H_CONTRACT_ROLE_ID AND H_ADDRESSGROUP.ADDRESS_ID = ? AND (? BETWEEN H_ADDRESSGROUP.H_CREATE_DT AND H_ADDRESSGROUP.H_END_DT OR ? >= H_ADDRESSGROUP.H_CREATE_DT AND H_ADDRESSGROUP.H_END_DT IS NULL )";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjCONTRACT_IDS_BY_ADDRESS_ID_HISTORYParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.addressId=ADDRESS_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.histCreateDt=H_CREATE_DT"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjCONTRACT_IDS_BY_ADDRESS_ID_HISTORYResults =
    "com.dwl.tcrm.financial.entityObject.EObjContractComponent.contractId=CONTRACT_ID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0061I This SQL query does not return additional fields defined by entity type extension XContract because the
   * base query only returns the primary key.
   *
   * @generated
   */ 
   public final static String getEObjCONTRACT_IDS_BY_ADDRESS_ID_ALLSQL = "SELECT DISTINCT CONTRACTCOMPONENT.CONTRACT_ID" + 
     " FROM ADDRESSGROUP, LOCATIONGROUP, ROLELOCATION, CONTRACTROLE, CONTRACTCOMPONENT" + 
     " WHERE ADDRESSGROUP.ADDRESS_ID=? AND ADDRESSGROUP.LOCATION_GROUP_ID=LOCATIONGROUP.LOCATION_GROUP_ID AND LOCATIONGROUP.LOCATION_GROUP_ID=ROLELOCATION.LOCATION_GROUP_ID AND LOCATIONGROUP.CONT_ID=CONTRACTROLE.CONT_ID AND CONTRACTROLE.CONTR_COMPONENT_ID=CONTRACTCOMPONENT.CONTR_COMPONENT_ID AND ROLELOCATION.CONTRACT_ROLE_ID=CONTRACTROLE.CONTRACT_ROLE_ID";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjCONTRACT_IDS_BY_ADDRESS_ID_ALLParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.addressId=ADDRESS_ID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjCONTRACT_IDS_BY_ADDRESS_ID_ALLResults =
    "com.dwl.tcrm.financial.entityObject.EObjContractComponent.contractId=CONTRACT_ID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0061I This SQL query does not return additional fields defined by entity type extension XContract because the
   * base query only returns the primary key.
   *
   * @generated
   */ 
   public final static String getEObjCONTRACT_IDS_BY_CONTACT_METHOD_ID_HISTORYSQL = "SELECT DISTINCT H_CONTRACTCOMPONEN.CONTRACT_ID" + 
     " FROM H_CONTACTMETHODGRO, H_LOCATIONGROUP ,H_ROLELOCATION, H_CONTRACTROLE, H_CONTRACTCOMPONEN" + 
     " WHERE H_CONTACTMETHODGRO.H_LOCATION_GROUP_I=H_LOCATIONGROUP.H_LOCATION_GROUP_I AND H_LOCATIONGROUP.H_LOCATION_GROUP_I=H_ROLELOCATION.LOCATION_GROUP_ID AND H_LOCATIONGROUP.CONT_ID=H_CONTRACTROLE.CONT_ID AND H_CONTRACTROLE.CONTR_COMPONENT_ID=H_CONTRACTCOMPONEN.H_CONTR_COMPONENT_ AND H_ROLELOCATION.CONTRACT_ROLE_ID = H_CONTRACTROLE.H_CONTRACT_ROLE_ID AND H_CONTACTMETHODGRO.CONTACT_METHOD_ID = ? AND (? BETWEEN H_CONTACTMETHODGRO.H_CREATE_DT AND H_CONTACTMETHODGRO.H_END_DT OR ? >= H_CONTACTMETHODGRO.H_CREATE_DT AND H_CONTACTMETHODGRO.H_END_DT IS NULL )";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjCONTRACT_IDS_BY_CONTACT_METHOD_ID_HISTORYParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.contactMethodId=CONTACT_METHOD_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.histCreateDt=H_CREATE_DT"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjCONTRACT_IDS_BY_CONTACT_METHOD_ID_HISTORYResults =
    "com.dwl.tcrm.financial.entityObject.EObjContractComponent.contractId=CONTRACT_ID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0061I This SQL query does not return additional fields defined by entity type extension XContract because the
   * base query only returns the primary key.
   *
   * @generated
   */ 
   public final static String getEObjCONTRACT_IDS_BY_CONTACT_METHOD_ID_ALLSQL = "SELECT DISTINCT CONTRACTCOMPONENT.CONTRACT_ID" + 
     " FROM CONTACTMETHODGROUP, LOCATIONGROUP, ROLELOCATION, CONTRACTROLE, CONTRACTCOMPONENT" + 
     " WHERE CONTACTMETHODGROUP.CONTACT_METHOD_ID=? AND CONTACTMETHODGROUP.LOCATION_GROUP_ID=LOCATIONGROUP.LOCATION_GROUP_ID AND LOCATIONGROUP.LOCATION_GROUP_ID=ROLELOCATION.LOCATION_GROUP_ID AND LOCATIONGROUP.CONT_ID=CONTRACTROLE.CONT_ID AND CONTRACTROLE.CONTR_COMPONENT_ID=CONTRACTCOMPONENT.CONTR_COMPONENT_ID AND ROLELOCATION.CONTRACT_ROLE_ID = CONTRACTROLE.CONTRACT_ROLE_ID";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjCONTRACT_IDS_BY_CONTACT_METHOD_ID_ALLParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.contactMethodId=CONTACT_METHOD_ID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjCONTRACT_IDS_BY_CONTACT_METHOD_ID_ALLResults =
    "com.dwl.tcrm.financial.entityObject.EObjContractComponent.contractId=CONTRACT_ID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension XContract.
   *
   * @generated
   */ 
   public final static String getEObjCONTRACTS_LIGHT_IMAGESSQL = "SELECT CONTRACT_ID , LAST_UPDATE_DT , H_CONTRACT.ACCESS_TOKEN_VALUE, H_CONTRACT.XCONTRACT_NUM" + 
     " FROM H_CONTRACT" + 
     " WHERE CONTRACT_ID = ? AND (H_CREATE_DT BETWEEN ? AND ?)";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjCONTRACTS_LIGHT_IMAGESParameters =
    "com.dwl.tcrm.financial.entityObject.EObjContract.contractIdPK=CONTRACT_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContract.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContract.histCreateDt=H_CREATE_DT"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjCONTRACTS_LIGHT_IMAGESResults =
    "com.dwl.tcrm.financial.entityObject.EObjContract.contractIdPK=CONTRACT_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContract.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContract.accessTokenValue=ACCESS_TOKEN_VALUE," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContractExt.XContractNum=XCONTRACT_NUM"; 


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getEObjCONTRACT_HISTORYSQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getEObjCONTRACT_HISTORYParameters, results=getEObjCONTRACT_HISTORYResults)
  		Iterator<ResultQueue2<EObjContract, EObjXContractExt>> getEObjCONTRACT_HISTORY(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getEObjCONTRACTSQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getEObjCONTRACTParameters, results=getEObjCONTRACTResults)
  		Iterator<ResultQueue2<EObjContract, EObjXContractExt>> getEObjCONTRACT(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getEObjCONTRACT_IDS_ALLSQL , pattern=tableAliasString2)
  @EntityMapping(parameters=getEObjCONTRACT_IDS_ALLParameters, results=getEObjCONTRACT_IDS_ALLResults)
  		java.util.Iterator<com.ibm.mdm.base.db.ResultQueue1<com.dwl.tcrm.financial.entityObject.EObjContract>> getEObjCONTRACT_IDS_ALL(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getEObjCONTRACT_IDS_ACTIVESQL , pattern=tableAliasString2)
  @EntityMapping(parameters=getEObjCONTRACT_IDS_ACTIVEParameters, results=getEObjCONTRACT_IDS_ACTIVEResults)
  		java.util.Iterator<com.ibm.mdm.base.db.ResultQueue1<com.dwl.tcrm.financial.entityObject.EObjContract>> getEObjCONTRACT_IDS_ACTIVE(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getEObjCONTRACT_IDS_INACTIVESQL , pattern=tableAliasString2)
  @EntityMapping(parameters=getEObjCONTRACT_IDS_INACTIVEParameters, results=getEObjCONTRACT_IDS_INACTIVEResults)
  		java.util.Iterator<com.ibm.mdm.base.db.ResultQueue1<com.dwl.tcrm.financial.entityObject.EObjContract>> getEObjCONTRACT_IDS_INACTIVE(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getEObjCONTRACT_IDS_HISTORYSQL , pattern=tableAliasString2)
  @EntityMapping(parameters=getEObjCONTRACT_IDS_HISTORYParameters, results=getEObjCONTRACT_IDS_HISTORYResults)
  		java.util.Iterator<com.ibm.mdm.base.db.ResultQueue1<com.dwl.tcrm.financial.entityObject.EObjContract>> getEObjCONTRACT_IDS_HISTORY(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getEObjCONTRACT_IDS_BY_ADDRESS_ID_HISTORYSQL , pattern=tableAliasString2)
  @EntityMapping(parameters=getEObjCONTRACT_IDS_BY_ADDRESS_ID_HISTORYParameters, results=getEObjCONTRACT_IDS_BY_ADDRESS_ID_HISTORYResults)
  		java.util.Iterator<com.ibm.mdm.base.db.ResultQueue1<com.dwl.tcrm.financial.entityObject.EObjContract>> getEObjCONTRACT_IDS_BY_ADDRESS_ID_HISTORY(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getEObjCONTRACT_IDS_BY_ADDRESS_ID_ALLSQL , pattern=tableAliasString2)
  @EntityMapping(parameters=getEObjCONTRACT_IDS_BY_ADDRESS_ID_ALLParameters, results=getEObjCONTRACT_IDS_BY_ADDRESS_ID_ALLResults)
  		java.util.Iterator<com.ibm.mdm.base.db.ResultQueue1<com.dwl.tcrm.financial.entityObject.EObjContract>> getEObjCONTRACT_IDS_BY_ADDRESS_ID_ALL(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getEObjCONTRACT_IDS_BY_CONTACT_METHOD_ID_HISTORYSQL , pattern=tableAliasString2)
  @EntityMapping(parameters=getEObjCONTRACT_IDS_BY_CONTACT_METHOD_ID_HISTORYParameters, results=getEObjCONTRACT_IDS_BY_CONTACT_METHOD_ID_HISTORYResults)
  		java.util.Iterator<com.ibm.mdm.base.db.ResultQueue1<com.dwl.tcrm.financial.entityObject.EObjContract>> getEObjCONTRACT_IDS_BY_CONTACT_METHOD_ID_HISTORY(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getEObjCONTRACT_IDS_BY_CONTACT_METHOD_ID_ALLSQL , pattern=tableAliasString2)
  @EntityMapping(parameters=getEObjCONTRACT_IDS_BY_CONTACT_METHOD_ID_ALLParameters, results=getEObjCONTRACT_IDS_BY_CONTACT_METHOD_ID_ALLResults)
  		java.util.Iterator<com.ibm.mdm.base.db.ResultQueue1<com.dwl.tcrm.financial.entityObject.EObjContract>> getEObjCONTRACT_IDS_BY_CONTACT_METHOD_ID_ALL(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getEObjCONTRACTS_LIGHT_IMAGESSQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getEObjCONTRACTS_LIGHT_IMAGESParameters, results=getEObjCONTRACTS_LIGHT_IMAGESResults)
  		Iterator<ResultQueue2<EObjContract, EObjXContractExt>> getEObjCONTRACTS_LIGHT_IMAGES(Object[] parameters);
 
}


