package com.ibm.daimler.dsea.entityObject;

import com.ibm.pdq.runtime.generator.BaseParameterHandler;
import java.util.Iterator;
import com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicle;
import java.sql.PreparedStatement;
import com.ibm.pdq.runtime.statement.StatementDescriptor;
import com.ibm.pdq.runtime.generator.BaseData;
import java.sql.SQLException;
import com.ibm.pdq.annotation.Metadata;
import com.ibm.pdq.runtime.generator.BaseRowHandler;
import com.ibm.pdq.runtime.statement.SqlStatementType;
import java.sql.Types;


/**
 * <!-- begin-user-doc -->
 * 
 * <!-- end-user-doc -->
 * 
 * @generated
 */
public class EObjXCustomerVehicleDataImpl  extends BaseData implements EObjXCustomerVehicleData
{

  /**
   * @generated
   */
  public static final String generatorVersion = "3.200.75";

  /**
   * @generated
   */
  public static final String identifier = "EObjXCustomerVehicleData";

  /**
   * @generated
   */
  public static final long generationTime = 0x0000016069b1d521L;

  /**
   * @generated
   */
  public static final String collection = "NULLID";

  /**
   * @generated
   */
  public static final String packageVersion = null;

  /**
   * @generated
   */
  public static final boolean forceSingleBindIsolation = false;

  /**
   * @generated
   */
  public EObjXCustomerVehicleDataImpl()
  {
    super();
  } 

  /**
   * @generated
   */
  public String getGeneratorVersion()
  {
    return generatorVersion;
  }

  /**
   * @Select( sql="select CUSTOMERVEHICLEPK_ID, CONT_ID, VEHICLE_ID, RETAILER_ID, CONNECTME_USAGE_TP_CD, LICENSE_PLATE, VEHICLE_SALES_TP_CD, VEHICLE_USAGE_TP_CD, VEHICLE_OWNERSHIP, START_DT, END_DT, SOURCE_IDENT_TP_CD, X_BPID, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from XCUSTOMERVEHICLE where CUSTOMERVEHICLEPK_ID = ? " )
   * 
   * @generated
   */
  public Iterator<EObjXCustomerVehicle> getEObjXCustomerVehicle (Long customerVehiclepkId)
  {
    return queryIterator (getEObjXCustomerVehicleStatementDescriptor, customerVehiclepkId);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getEObjXCustomerVehicleStatementDescriptor = createStatementDescriptor (
    "getEObjXCustomerVehicle(Long)",
    "select CUSTOMERVEHICLEPK_ID, CONT_ID, VEHICLE_ID, RETAILER_ID, CONNECTME_USAGE_TP_CD, LICENSE_PLATE, VEHICLE_SALES_TP_CD, VEHICLE_USAGE_TP_CD, VEHICLE_OWNERSHIP, START_DT, END_DT, SOURCE_IDENT_TP_CD, X_BPID, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from XCUSTOMERVEHICLE where CUSTOMERVEHICLEPK_ID = ? ",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"customervehiclepk_id", "cont_id", "vehicle_id", "retailer_id", "connectme_usage_tp_cd", "license_plate", "vehicle_sales_tp_cd", "vehicle_usage_tp_cd", "vehicle_ownership", "start_dt", "end_dt", "source_ident_tp_cd", "x_bpid", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetEObjXCustomerVehicleParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetEObjXCustomerVehicleRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 19, 19, 19, 19, 20, 19, 19, 250, 0, 0, 19, 50, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    1);

  /**
   * @generated
   */
  public static class GetEObjXCustomerVehicleParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setLong (stmt, 1, Types.BIGINT, (Long)parameters[0]);
    }
  }

  /**
   * @generated
   */
  public static class GetEObjXCustomerVehicleRowHandler extends BaseRowHandler<EObjXCustomerVehicle>
  {
    /**
     * @generated
     */
    public EObjXCustomerVehicle handle (java.sql.ResultSet rs, EObjXCustomerVehicle returnObject) throws java.sql.SQLException
    {
      returnObject = new EObjXCustomerVehicle ();
      returnObject.setCustomerVehiclepkId(getLongObject (rs, 1)); 
      returnObject.setContId(getLongObject (rs, 2)); 
      returnObject.setVehicleId(getLongObject (rs, 3)); 
      returnObject.setRetailerId(getLongObject (rs, 4)); 
      returnObject.setConnectMeUsage(getLongObject (rs, 5)); 
      returnObject.setLicensePlate(getString (rs, 6)); 
      returnObject.setVehicleSales(getLongObject (rs, 7)); 
      returnObject.setVehicleUsage(getLongObject (rs, 8)); 
      returnObject.setVehicleOwnerShip(getString (rs, 9)); 
      returnObject.setStartDate(getTimestamp (rs, 10)); 
      returnObject.setEndDate(getTimestamp (rs, 11)); 
      returnObject.setSourceIdentifier(getLongObject (rs, 12)); 
      returnObject.setX_BPID(getString (rs, 13)); 
      returnObject.setLastUpdateDt(getTimestamp (rs, 14)); 
      returnObject.setLastUpdateUser(getString (rs, 15)); 
      returnObject.setLastUpdateTxId(getLongObject (rs, 16)); 
    
      return returnObject;
    }
  }

  /**
   * @Update( sql="insert into XCUSTOMERVEHICLE (CUSTOMERVEHICLEPK_ID, CONT_ID, VEHICLE_ID, RETAILER_ID, CONNECTME_USAGE_TP_CD, LICENSE_PLATE, VEHICLE_SALES_TP_CD, VEHICLE_USAGE_TP_CD, VEHICLE_OWNERSHIP, START_DT, END_DT, SOURCE_IDENT_TP_CD, X_BPID, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( :customerVehiclepkId, :contId, :vehicleId, :retailerId, :connectMeUsage, :licensePlate, :vehicleSales, :vehicleUsage, :vehicleOwnerShip, :startDate, :endDate, :sourceIdentifier, :x_BPID, :lastUpdateDt, :lastUpdateUser, :lastUpdateTxId)" )
   * 
   * @generated
   */
  public int createEObjXCustomerVehicle (EObjXCustomerVehicle e)
  {
    return update (createEObjXCustomerVehicleStatementDescriptor, e);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor createEObjXCustomerVehicleStatementDescriptor = createStatementDescriptor (
    "createEObjXCustomerVehicle(com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicle)",
    "insert into XCUSTOMERVEHICLE (CUSTOMERVEHICLEPK_ID, CONT_ID, VEHICLE_ID, RETAILER_ID, CONNECTME_USAGE_TP_CD, LICENSE_PLATE, VEHICLE_SALES_TP_CD, VEHICLE_USAGE_TP_CD, VEHICLE_OWNERSHIP, START_DT, END_DT, SOURCE_IDENT_TP_CD, X_BPID, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values(  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? )",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.INSERT,
    null,
    new CreateEObjXCustomerVehicleParameterHandler (),
    new int[][]{{Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 19, 19, 19, 19, 20, 19, 19, 250, 0, 0, 19, 50, 0, 0, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    2);

  /**
   * @generated
   */
  public static class CreateEObjXCustomerVehicleParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      EObjXCustomerVehicle bean0 = (EObjXCustomerVehicle) parameters[0];
      setLong (stmt, 1, Types.BIGINT, (Long)bean0.getCustomerVehiclepkId());
      setLong (stmt, 2, Types.BIGINT, (Long)bean0.getContId());
      setLong (stmt, 3, Types.BIGINT, (Long)bean0.getVehicleId());
      setLong (stmt, 4, Types.BIGINT, (Long)bean0.getRetailerId());
      setLong (stmt, 5, Types.BIGINT, (Long)bean0.getConnectMeUsage());
      setString (stmt, 6, Types.VARCHAR, (String)bean0.getLicensePlate());
      setLong (stmt, 7, Types.BIGINT, (Long)bean0.getVehicleSales());
      setLong (stmt, 8, Types.BIGINT, (Long)bean0.getVehicleUsage());
      setString (stmt, 9, Types.VARCHAR, (String)bean0.getVehicleOwnerShip());
      setTimestamp (stmt, 10, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getStartDate());
      setTimestamp (stmt, 11, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getEndDate());
      setLong (stmt, 12, Types.BIGINT, (Long)bean0.getSourceIdentifier());
      setString (stmt, 13, Types.VARCHAR, (String)bean0.getX_BPID());
      setTimestamp (stmt, 14, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUpdateDt());
      setString (stmt, 15, Types.VARCHAR, (String)bean0.getLastUpdateUser());
      setLong (stmt, 16, Types.BIGINT, (Long)bean0.getLastUpdateTxId());
    }
  }

  /**
   * @Update( sql="update XCUSTOMERVEHICLE set CONT_ID = :contId, VEHICLE_ID = :vehicleId, RETAILER_ID = :retailerId, CONNECTME_USAGE_TP_CD = :connectMeUsage, LICENSE_PLATE = :licensePlate, VEHICLE_SALES_TP_CD = :vehicleSales, VEHICLE_USAGE_TP_CD = :vehicleUsage, VEHICLE_OWNERSHIP = :vehicleOwnerShip, START_DT = :startDate, END_DT = :endDate, SOURCE_IDENT_TP_CD = :sourceIdentifier, X_BPID = :x_BPID, LAST_UPDATE_DT = :lastUpdateDt, LAST_UPDATE_USER = :lastUpdateUser, LAST_UPDATE_TX_ID = :lastUpdateTxId where CUSTOMERVEHICLEPK_ID = :customerVehiclepkId and LAST_UPDATE_DT = :oldLastUpdateDt" )
   * 
   * @generated
   */
  public int updateEObjXCustomerVehicle (EObjXCustomerVehicle e)
  {
    return update (updateEObjXCustomerVehicleStatementDescriptor, e);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor updateEObjXCustomerVehicleStatementDescriptor = createStatementDescriptor (
    "updateEObjXCustomerVehicle(com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicle)",
    "update XCUSTOMERVEHICLE set CONT_ID =  ? , VEHICLE_ID =  ? , RETAILER_ID =  ? , CONNECTME_USAGE_TP_CD =  ? , LICENSE_PLATE =  ? , VEHICLE_SALES_TP_CD =  ? , VEHICLE_USAGE_TP_CD =  ? , VEHICLE_OWNERSHIP =  ? , START_DT =  ? , END_DT =  ? , SOURCE_IDENT_TP_CD =  ? , X_BPID =  ? , LAST_UPDATE_DT =  ? , LAST_UPDATE_USER =  ? , LAST_UPDATE_TX_ID =  ?  where CUSTOMERVEHICLEPK_ID =  ?  and LAST_UPDATE_DT =  ? ",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.UPDATE,
    null,
    new UpdateEObjXCustomerVehicleParameterHandler (),
    new int[][]{{Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP}, {19, 19, 19, 19, 20, 19, 19, 250, 0, 0, 19, 50, 0, 0, 19, 19, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    3);

  /**
   * @generated
   */
  public static class UpdateEObjXCustomerVehicleParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      EObjXCustomerVehicle bean0 = (EObjXCustomerVehicle) parameters[0];
      setLong (stmt, 1, Types.BIGINT, (Long)bean0.getContId());
      setLong (stmt, 2, Types.BIGINT, (Long)bean0.getVehicleId());
      setLong (stmt, 3, Types.BIGINT, (Long)bean0.getRetailerId());
      setLong (stmt, 4, Types.BIGINT, (Long)bean0.getConnectMeUsage());
      setString (stmt, 5, Types.VARCHAR, (String)bean0.getLicensePlate());
      setLong (stmt, 6, Types.BIGINT, (Long)bean0.getVehicleSales());
      setLong (stmt, 7, Types.BIGINT, (Long)bean0.getVehicleUsage());
      setString (stmt, 8, Types.VARCHAR, (String)bean0.getVehicleOwnerShip());
      setTimestamp (stmt, 9, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getStartDate());
      setTimestamp (stmt, 10, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getEndDate());
      setLong (stmt, 11, Types.BIGINT, (Long)bean0.getSourceIdentifier());
      setString (stmt, 12, Types.VARCHAR, (String)bean0.getX_BPID());
      setTimestamp (stmt, 13, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUpdateDt());
      setString (stmt, 14, Types.VARCHAR, (String)bean0.getLastUpdateUser());
      setLong (stmt, 15, Types.BIGINT, (Long)bean0.getLastUpdateTxId());
      setLong (stmt, 16, Types.BIGINT, (Long)bean0.getCustomerVehiclepkId());
      setTimestamp (stmt, 17, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getOldLastUpdateDt());
    }
  }

  /**
   * @Update( sql="delete from XCUSTOMERVEHICLE where CUSTOMERVEHICLEPK_ID = ?" )
   * 
   * @generated
   */
  public int deleteEObjXCustomerVehicle (Long customerVehiclepkId)
  {
    return update (deleteEObjXCustomerVehicleStatementDescriptor, customerVehiclepkId);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor deleteEObjXCustomerVehicleStatementDescriptor = createStatementDescriptor (
    "deleteEObjXCustomerVehicle(Long)",
    "delete from XCUSTOMERVEHICLE where CUSTOMERVEHICLEPK_ID = ?",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.DELETE,
    null,
    new DeleteEObjXCustomerVehicleParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    4);

  /**
   * @generated
   */
  public static class DeleteEObjXCustomerVehicleParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setLong (stmt, 1, Types.BIGINT, (Long)parameters[0]);
    }
  }

}
