package com.ibm.daimler.dsea.entityObject;

import com.ibm.pdq.runtime.generator.BaseParameterHandler;
import com.dwl.tcrm.coreParty.entityObject.EObjOrg;
import java.util.Iterator;
import com.dwl.tcrm.coreParty.entityObject.EObjContact;
import java.sql.PreparedStatement;
import com.ibm.pdq.runtime.statement.StatementDescriptor;
import com.ibm.pdq.runtime.generator.BaseData;
import java.sql.SQLException;
import com.ibm.pdq.annotation.Metadata;
import com.ibm.mdm.base.db.ResultQueue4;
import com.dwl.tcrm.coreParty.entityObject.EObjContSummary;
import com.ibm.mdm.base.db.ResultQueue3;
import com.ibm.daimler.dsea.entityObject.EObjXOrgExt;
import com.ibm.pdq.runtime.generator.BaseRowHandler;
import com.ibm.pdq.runtime.statement.SqlStatementType;
import java.sql.Types;


@SuppressWarnings("unchecked")

/**
 * <!-- begin-user-doc -->
 * 
 * <!-- end-user-doc -->
 * 
 * @generated
 */
public class XOrgExtInquiryDataImpl  extends BaseData implements XOrgExtInquiryData
{

  /**
   * @generated
   */
  public static final String generatorVersion = "3.200.75";

  /**
   * @generated
   */
  public static final String identifier = "XOrgExtInquiryData";

  /**
   * @generated
   */
  public static final long generationTime = 0x00000170aed92f50L;

  /**
   * @generated
   */
  public static final String collection = "NULLID";

  /**
   * @generated
   */
  public static final String packageVersion = null;

  /**
   * @generated
   */
  public static final boolean forceSingleBindIsolation = false;

  /**
   * @generated
   */
  public XOrgExtInquiryDataImpl()
  {
    super();
  } 

  /**
   * @generated
   */
  public String getGeneratorVersion()
  {
    return generatorVersion;
  }

  /**
   * @Select( sql="SELECT DISTINCT A.H_CONT_ID AS H_CONT_ID_ORG, A.H_ACTION_CODE, A.H_CREATED_BY, A.H_CREATE_DT, A.H_END_DT, A.CONT_ID, A.ORG_TP_CD, A.INDUSTRY_TP_CD, A.ESTABLISHED_DT, A.BUY_SELL_AGR_TP_CD, A.PROFIT_IND, A.LAST_UPDATE_DT, A.LAST_UPDATE_USER,A.LAST_UPDATE_TX_ID, B.H_CONT_ID AS H_CONT_ID, B.H_ACTION_CODE, B.H_CREATED_BY, B.H_CREATE_DT, B.H_END_DT, B.CONT_ID, B.ACCE_COMP_TP_CD, B.PREF_LANG_TP_CD, B.CREATED_DT, B.SINCE_DT, B.LEFT_DT, B.INACTIVATED_DT, B.CONTACT_NAME, B.PERSON_ORG_CODE, B.SOLICIT_IND, B.CONFIDENTIAL_IND, B.CLIENT_IMP_TP_CD, B.CLIENT_ST_TP_CD, B.CLIENT_POTEN_TP_CD, B.RPTING_FREQ_TP_CD, B.LAST_STATEMENT_DT, B.PROVIDED_BY_CONT, B.LAST_UPDATE_DT, B.LAST_UPDATE_USER, B.LAST_UPDATE_TX_ID, B.LAST_USED_DT, B.LAST_VERIFIED_DT, B.SOURCE_IDENT_TP_CD, B.DO_NOT_DELETE_IND, B.ALERT_IND, B.ACCESS_TOKEN_VALUE, B.PENDING_CDC_IND, B.ENTITYLINK_ST_TP_CD, B.ENTITY_ID, B.ENTITY_TYPE, B.ENTITY_STATUS_TP_CD, A.XDEFUNCT_IND, A.XWEBSITE, A.XMARKET_NAME, A.XBATCH_IND, A.XNUMOFEMP_TP_CD, A.XMODIFY_SYS_DT, A.XSOURCE_TYPE_FLAG, A.XGENERATED_BY, A.XCORP_CAT_TP_CD, A.XCORP_GROUP_TP_CD, A.XPERSONAL_AGREEMENT, A.XDo_Not_Merge_Flag, A.DELETE_FLAG, A.INFO_REMOVE_FLAG, A.DEDUP_HIDDEN_FLAG, A.PREF_COMMUNICATION_CHANNEL, A.YANASE_FLAG, A.FINANCE_PARTY_TYPE, A.CONTRACT_NUMBER, A.XPrivacy_Act, A.XFleet, A.XPC_Ind, A.XVANS_Ind, A.Last_Activity_Date, A.X_CUST_TYPE FROM H_ORG A, H_CONTACT B WHERE A.H_CONT_ID = ? AND A.H_CONT_ID = B.H_CONT_ID AND (( ? BETWEEN A.H_CREATE_DT AND A.H_END_DT ) OR ( ? >= A.H_CREATE_DT AND A.H_END_DT IS NULL )) AND (( ? BETWEEN B.H_CREATE_DT AND B.H_END_DT ) OR ( ? >= B.H_CREATE_DT AND B.H_END_DT IS NULL ))", pattern="tableAlias (CONTSUMMARY => com.dwl.tcrm.coreParty.entityObject.EObjContSummary, ORG => com.dwl.tcrm.coreParty.entityObject.EObjOrg, H_ORG => com.dwl.tcrm.coreParty.entityObject.EObjOrg, CONTACT => com.dwl.tcrm.coreParty.entityObject.EObjContact, H_CONTACT => com.dwl.tcrm.coreParty.entityObject.EObjContact , ORG => com.ibm.daimler.dsea.entityObject.EObjXOrgExt , H_ORG => com.ibm.daimler.dsea.entityObject.EObjXOrgExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue3<EObjContact,EObjOrg,EObjXOrgExt>> getOrganizationHistory (Object[] parameters)
  {
    return queryIterator (getOrganizationHistoryStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getOrganizationHistoryStatementDescriptor = createStatementDescriptor (
    "getOrganizationHistory(Object[])",
    "SELECT DISTINCT A.H_CONT_ID AS H_CONT_ID_ORG, A.H_ACTION_CODE, A.H_CREATED_BY, A.H_CREATE_DT, A.H_END_DT, A.CONT_ID, A.ORG_TP_CD, A.INDUSTRY_TP_CD, A.ESTABLISHED_DT, A.BUY_SELL_AGR_TP_CD, A.PROFIT_IND, A.LAST_UPDATE_DT, A.LAST_UPDATE_USER,A.LAST_UPDATE_TX_ID, B.H_CONT_ID AS H_CONT_ID, B.H_ACTION_CODE, B.H_CREATED_BY, B.H_CREATE_DT, B.H_END_DT, B.CONT_ID, B.ACCE_COMP_TP_CD, B.PREF_LANG_TP_CD, B.CREATED_DT, B.SINCE_DT, B.LEFT_DT, B.INACTIVATED_DT, B.CONTACT_NAME, B.PERSON_ORG_CODE, B.SOLICIT_IND, B.CONFIDENTIAL_IND, B.CLIENT_IMP_TP_CD, B.CLIENT_ST_TP_CD, B.CLIENT_POTEN_TP_CD, B.RPTING_FREQ_TP_CD, B.LAST_STATEMENT_DT, B.PROVIDED_BY_CONT, B.LAST_UPDATE_DT, B.LAST_UPDATE_USER, B.LAST_UPDATE_TX_ID, B.LAST_USED_DT, B.LAST_VERIFIED_DT, B.SOURCE_IDENT_TP_CD, B.DO_NOT_DELETE_IND, B.ALERT_IND, B.ACCESS_TOKEN_VALUE, B.PENDING_CDC_IND, B.ENTITYLINK_ST_TP_CD, B.ENTITY_ID, B.ENTITY_TYPE, B.ENTITY_STATUS_TP_CD, A.XDEFUNCT_IND, A.XWEBSITE, A.XMARKET_NAME, A.XBATCH_IND, A.XNUMOFEMP_TP_CD, A.XMODIFY_SYS_DT, A.XSOURCE_TYPE_FLAG, A.XGENERATED_BY, A.XCORP_CAT_TP_CD, A.XCORP_GROUP_TP_CD, A.XPERSONAL_AGREEMENT, A.XDo_Not_Merge_Flag, A.DELETE_FLAG, A.INFO_REMOVE_FLAG, A.DEDUP_HIDDEN_FLAG, A.PREF_COMMUNICATION_CHANNEL, A.YANASE_FLAG, A.FINANCE_PARTY_TYPE, A.CONTRACT_NUMBER, A.XPrivacy_Act, A.XFleet, A.XPC_Ind, A.XVANS_Ind, A.Last_Activity_Date, A.X_CUST_TYPE FROM H_ORG A, H_CONTACT B WHERE A.H_CONT_ID = ? AND A.H_CONT_ID = B.H_CONT_ID AND (( ? BETWEEN A.H_CREATE_DT AND A.H_END_DT ) OR ( ? >= A.H_CREATE_DT AND A.H_END_DT IS NULL )) AND (( ? BETWEEN B.H_CREATE_DT AND B.H_END_DT ) OR ( ? >= B.H_CREATE_DT AND B.H_END_DT IS NULL ))",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"h_cont_id_org", "h_action_code", "h_created_by", "h_create_dt", "h_end_dt", "cont_id", "org_tp_cd", "industry_tp_cd", "established_dt", "buy_sell_agr_tp_cd", "profit_ind", "last_update_dt", "last_update_user", "last_update_tx_id", "h_cont_id", "h_action_code", "h_created_by", "h_create_dt", "h_end_dt", "cont_id", "acce_comp_tp_cd", "pref_lang_tp_cd", "created_dt", "since_dt", "left_dt", "inactivated_dt", "contact_name", "person_org_code", "solicit_ind", "confidential_ind", "client_imp_tp_cd", "client_st_tp_cd", "client_poten_tp_cd", "rpting_freq_tp_cd", "last_statement_dt", "provided_by_cont", "last_update_dt", "last_update_user", "last_update_tx_id", "last_used_dt", "last_verified_dt", "source_ident_tp_cd", "do_not_delete_ind", "alert_ind", "access_token_value", "pending_cdc_ind", "entitylink_st_tp_cd", "entity_id", "entity_type", "entity_status_tp_cd", "xdefunct_ind", "xwebsite", "xmarket_name", "xbatch_ind", "xnumofemp_tp_cd", "xmodify_sys_dt", "xsource_type_flag", "xgenerated_by", "xcorp_cat_tp_cd", "xcorp_group_tp_cd", "xpersonal_agreement", "xdo_not_merge_flag", "delete_flag", "info_remove_flag", "dedup_hidden_flag", "pref_communication_channel", "yanase_flag", "finance_party_type", "contract_number", "xprivacy_act", "xfleet", "xpc_ind", "xvans_ind", "last_activity_date", "x_cust_type"},
    new GetOrganizationHistoryParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP}, {19, 0, 0, 0, 0}, {0, 0, 0, 0, 0}, {1, 1, 1, 1, 1}},
    null,
    new GetOrganizationHistoryRowHandler (),
    new int[][]{ {Types.BIGINT, Types.CHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.BIGINT, Types.CHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.CHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.CHAR, Types.CHAR, Types.CHAR, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.CHAR, Types.CHAR, Types.VARCHAR, Types.CHAR, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR}, {19, 1, 20, 0, 0, 19, 19, 19, 0, 19, 1, 0, 20, 19, 19, 1, 20, 0, 0, 19, 19, 19, 0, 0, 0, 0, 255, 1, 1, 1, 19, 19, 19, 19, 0, 19, 0, 20, 19, 0, 0, 19, 1, 1, 50, 1, 19, 19, 25, 19, 5, 255, 50, 5, 19, 0, 50, 50, 19, 19, 20, 5, 10, 10, 10, 255, 10, 10, 250, 250, 5, 10, 10, 0, 10}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    1);

  /**
   * @generated
   */
  public static class GetOrganizationHistoryParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
      setObject (stmt, 4, Types.TIMESTAMP, parameters[3], 0);
      setObject (stmt, 5, Types.TIMESTAMP, parameters[4], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetOrganizationHistoryRowHandler extends BaseRowHandler<ResultQueue3<EObjContact,EObjOrg,EObjXOrgExt>>
  {
    /**
     * @generated
     */
    public ResultQueue3<EObjContact,EObjOrg,EObjXOrgExt> handle (java.sql.ResultSet rs, ResultQueue3<EObjContact,EObjOrg,EObjXOrgExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue3<EObjContact,EObjOrg,EObjXOrgExt> ();

      EObjContact returnObject1 = new EObjContact ();
      returnObject1.setHistoryIdPK(getLongObject (rs, 15)); 
      returnObject1.setHistActionCode(getString (rs, 16)); 
      returnObject1.setHistCreatedBy(getString (rs, 17)); 
      returnObject1.setHistCreateDt(getTimestamp (rs, 18)); 
      returnObject1.setHistEndDt(getTimestamp (rs, 19)); 
      returnObject1.setContIdPK(getLongObject (rs, 20)); 
      returnObject1.setAcceCompTpCd(getLongObject (rs, 21)); 
      returnObject1.setPrefLangTpCd(getLongObject (rs, 22)); 
      returnObject1.setCreatedDt(getTimestamp (rs, 23)); 
      returnObject1.setSinceDt(getTimestamp (rs, 24)); 
      returnObject1.setLeftDt(getTimestamp (rs, 25)); 
      returnObject1.setInactivatedDt(getTimestamp (rs, 26)); 
      returnObject1.setContactName(getString (rs, 27)); 
      returnObject1.setPersonOrgCode(getString (rs, 28)); 
      returnObject1.setSolicitInd(getString (rs, 29)); 
      returnObject1.setConfidentialInd(getString (rs, 30)); 
      returnObject1.setClientImpTpCd(getLongObject (rs, 31)); 
      returnObject1.setClientStTpCd(getLongObject (rs, 32)); 
      returnObject1.setClientPotenTpCd(getLongObject (rs, 33)); 
      returnObject1.setRptingFreqTpCd(getLongObject (rs, 34)); 
      returnObject1.setLastStatementDt(getTimestamp (rs, 35)); 
      returnObject1.setProvidedByCont(getLongObject (rs, 36)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 37)); 
      returnObject1.setLastUpdateUser(getString (rs, 38)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 39)); 
      returnObject1.setLastUsedDt(getTimestamp (rs, 40)); 
      returnObject1.setLastVerifiedDt(getTimestamp (rs, 41)); 
      returnObject1.setSourceIdentTpCd(getLongObject (rs, 42)); 
      returnObject1.setDoNotDelInd(getString (rs, 43)); 
      returnObject1.setAlertInd(getString (rs, 44)); 
      returnObject1.setAccessTokenValue(getString (rs, 45)); 
      returnObject1.setPendingCDCInd(getString (rs, 46)); 
      returnObject1.setEntitylink_st_tp_cd(getLongObject (rs, 47)); 
      returnObject1.setEntity_id(getLongObject (rs, 48)); 
      returnObject1.setEntity_type(getString (rs, 49)); 
      returnObject1.setEntityStatusTpCd(getLongObject (rs, 50)); 
      returnObject.add (returnObject1);

      EObjOrg returnObject2 = new EObjOrg ();
      returnObject2.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject2.setHistActionCode(getString (rs, 2)); 
      returnObject2.setHistCreatedBy(getString (rs, 3)); 
      returnObject2.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject2.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject2.setContIdPK(getLongObject (rs, 6)); 
      returnObject2.setOrgTpCd(getLongObject (rs, 7)); 
      returnObject2.setIndustryTpCd(getLongObject (rs, 8)); 
      returnObject2.setEstablishedDt(getTimestamp (rs, 9)); 
      returnObject2.setBuySellAgrTpCd(getLongObject (rs, 10)); 
      returnObject2.setProfitInd(getString (rs, 11)); 
      returnObject2.setLastUpdateDt(getTimestamp (rs, 12)); 
      returnObject2.setLastUpdateUser(getString (rs, 13)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 14)); 
      returnObject.add (returnObject2);

      EObjXOrgExt returnObject3 = new EObjXOrgExt ();
      returnObject3.setHistActionCode(getString (rs, 2)); 
      returnObject3.setHistCreatedBy(getString (rs, 3)); 
      returnObject3.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject3.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject3.setLastUpdateDt(getTimestamp (rs, 12)); 
      returnObject3.setLastUpdateUser(getString (rs, 13)); 
      returnObject3.setLastUpdateTxId(getLongObject (rs, 14)); 
      returnObject3.setXDefunctInd(getString (rs, 51)); 
      returnObject3.setXWebsite(getString (rs, 52)); 
      returnObject3.setXMarketName(getString (rs, 53)); 
      returnObject3.setXBatchInd(getString (rs, 54)); 
      returnObject3.setXNumberOfEmployees(getLongObject (rs, 55)); 
      returnObject3.setXLastModifiedSystemDate(getTimestamp (rs, 56)); 
      returnObject3.setXSourceTypeFlag(getString (rs, 57)); 
      returnObject3.setXGenerated_by(getString (rs, 58)); 
      returnObject3.setXCorporateCategory(getLongObject (rs, 59)); 
      returnObject3.setXCorporateGroup(getLongObject (rs, 60)); 
      returnObject3.setXPersonalAgreement(getString (rs, 61)); 
      returnObject3.setXDoNotMergeFlag(getString (rs, 62)); 
      returnObject3.setDeleteFlag(getString (rs, 63)); 
      returnObject3.setInfoRemoveFlag(getString (rs, 64)); 
      returnObject3.setDedupHiddenFlag(getString (rs, 65)); 
      returnObject3.setPrefCommunicationChannel(getString (rs, 66)); 
      returnObject3.setYanaseFlag(getString (rs, 67)); 
      returnObject3.setFinancePartyType(getString (rs, 68)); 
      returnObject3.setContractNumber(getString (rs, 69)); 
      returnObject3.setXPrivacyAct(getString (rs, 70)); 
      returnObject3.setXFleet(getString (rs, 71)); 
      returnObject3.setXPC_Ind(getString (rs, 72)); 
      returnObject3.setXVANS_Ind(getString (rs, 73)); 
      returnObject3.setLastActivityDate(getTimestamp (rs, 74)); 
      returnObject3.setX_CUST_TYPE(getString (rs, 75)); 
      returnObject.add (returnObject3);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT ORG.CONT_ID, ORG.ORG_TP_CD, ORG.INDUSTRY_TP_CD, ORG.ESTABLISHED_DT, ORG.BUY_SELL_AGR_TP_CD, ORG.PROFIT_IND, ORG.LAST_UPDATE_DT, ORG.LAST_UPDATE_USER, ORG.LAST_UPDATE_TX_ID, CONTACT.CONT_ID, CONTACT.ACCE_COMP_TP_CD, CONTACT.PREF_LANG_TP_CD, CONTACT.CREATED_DT, CONTACT.SINCE_DT, CONTACT.LEFT_DT, CONTACT.INACTIVATED_DT, CONTACT.CONTACT_NAME, CONTACT.PERSON_ORG_CODE, CONTACT.SOLICIT_IND, CONTACT.CONFIDENTIAL_IND, CONTACT.CLIENT_IMP_TP_CD, CONTACT.CLIENT_ST_TP_CD, CONTACT.CLIENT_POTEN_TP_CD, CONTACT.RPTING_FREQ_TP_CD, CONTACT.LAST_STATEMENT_DT, CONTACT.PROVIDED_BY_CONT, CONTACT.LAST_UPDATE_DT, CONTACT.LAST_UPDATE_USER, CONTACT.ALERT_IND, CONTACT.LAST_UPDATE_TX_ID, CONTACT.LAST_USED_DT, CONTACT.LAST_VERIFIED_DT, CONTACT.SOURCE_IDENT_TP_CD, CONTACT.DO_NOT_DELETE_IND, CS.CONT_ID, CS.PRIVPREF_IND, CS.MISCVALUE_IND, CS.CONTACTREL_IND, CS.BANKACCOUNT_IND, CS.CHARGECARD_IND, CS.INCOMESOURCE_IND, CS.PAYROLLDEDUCT_IND, CS.IDENTIFIER_IND, CS.ALERT_IND, CS.CONTEQUIV_IND, CS.INTERACTION_IND, CS.ADDRESSGROUP_IND, CS.CONTMETHGROUP_IND, CS.LOBREL_IND, CS.LAST_UPDATE_DT, CS.LAST_UPDATE_USER, CS.LAST_UPDATE_TX_ID, CONTACT.ACCESS_TOKEN_VALUE, CONTACT.PENDING_CDC_IND, CONTACT.ENTITYLINK_ST_TP_CD, CONTACT.ENTITY_ID, CONTACT.ENTITY_TYPE, CONTACT.ENTITY_STATUS_TP_CD, ORG.XDEFUNCT_IND, ORG.XWEBSITE, ORG.XMARKET_NAME, ORG.XBATCH_IND, ORG.XNUMOFEMP_TP_CD, ORG.XMODIFY_SYS_DT, ORG.XSOURCE_TYPE_FLAG, ORG.XGENERATED_BY, ORG.XCORP_CAT_TP_CD, ORG.XCORP_GROUP_TP_CD, ORG.XPERSONAL_AGREEMENT, ORG.XDo_Not_Merge_Flag, ORG.DELETE_FLAG, ORG.INFO_REMOVE_FLAG, ORG.DEDUP_HIDDEN_FLAG, ORG.PREF_COMMUNICATION_CHANNEL, ORG.YANASE_FLAG, ORG.FINANCE_PARTY_TYPE, ORG.CONTRACT_NUMBER, ORG.XPrivacy_Act, ORG.XFleet, ORG.XPC_Ind, ORG.XVANS_Ind, ORG.Last_Activity_Date, ORG.X_CUST_TYPE FROM ORG, CONTACT LEFT OUTER JOIN CONTSUMMARY CS ON CONTACT.CONT_ID = CS.CONT_ID WHERE ORG.CONT_ID = CONTACT.CONT_ID AND ORG.CONT_ID = ?", pattern="tableAlias (CONTSUMMARY => com.dwl.tcrm.coreParty.entityObject.EObjContSummary, ORG => com.dwl.tcrm.coreParty.entityObject.EObjOrg, H_ORG => com.dwl.tcrm.coreParty.entityObject.EObjOrg, CONTACT => com.dwl.tcrm.coreParty.entityObject.EObjContact, H_CONTACT => com.dwl.tcrm.coreParty.entityObject.EObjContact , ORG => com.ibm.daimler.dsea.entityObject.EObjXOrgExt , H_ORG => com.ibm.daimler.dsea.entityObject.EObjXOrgExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue4<EObjContact,EObjOrg,EObjContSummary,EObjXOrgExt>> getOrganizationIndicators (Object[] parameters)
  {
    return queryIterator (getOrganizationIndicatorsStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getOrganizationIndicatorsStatementDescriptor = createStatementDescriptor (
    "getOrganizationIndicators(Object[])",
    "SELECT ORG.CONT_ID, ORG.ORG_TP_CD, ORG.INDUSTRY_TP_CD, ORG.ESTABLISHED_DT, ORG.BUY_SELL_AGR_TP_CD, ORG.PROFIT_IND, ORG.LAST_UPDATE_DT, ORG.LAST_UPDATE_USER, ORG.LAST_UPDATE_TX_ID, CONTACT.CONT_ID, CONTACT.ACCE_COMP_TP_CD, CONTACT.PREF_LANG_TP_CD, CONTACT.CREATED_DT, CONTACT.SINCE_DT, CONTACT.LEFT_DT, CONTACT.INACTIVATED_DT, CONTACT.CONTACT_NAME, CONTACT.PERSON_ORG_CODE, CONTACT.SOLICIT_IND, CONTACT.CONFIDENTIAL_IND, CONTACT.CLIENT_IMP_TP_CD, CONTACT.CLIENT_ST_TP_CD, CONTACT.CLIENT_POTEN_TP_CD, CONTACT.RPTING_FREQ_TP_CD, CONTACT.LAST_STATEMENT_DT, CONTACT.PROVIDED_BY_CONT, CONTACT.LAST_UPDATE_DT, CONTACT.LAST_UPDATE_USER, CONTACT.ALERT_IND, CONTACT.LAST_UPDATE_TX_ID, CONTACT.LAST_USED_DT, CONTACT.LAST_VERIFIED_DT, CONTACT.SOURCE_IDENT_TP_CD, CONTACT.DO_NOT_DELETE_IND, CS.CONT_ID, CS.PRIVPREF_IND, CS.MISCVALUE_IND, CS.CONTACTREL_IND, CS.BANKACCOUNT_IND, CS.CHARGECARD_IND, CS.INCOMESOURCE_IND, CS.PAYROLLDEDUCT_IND, CS.IDENTIFIER_IND, CS.ALERT_IND, CS.CONTEQUIV_IND, CS.INTERACTION_IND, CS.ADDRESSGROUP_IND, CS.CONTMETHGROUP_IND, CS.LOBREL_IND, CS.LAST_UPDATE_DT, CS.LAST_UPDATE_USER, CS.LAST_UPDATE_TX_ID, CONTACT.ACCESS_TOKEN_VALUE, CONTACT.PENDING_CDC_IND, CONTACT.ENTITYLINK_ST_TP_CD, CONTACT.ENTITY_ID, CONTACT.ENTITY_TYPE, CONTACT.ENTITY_STATUS_TP_CD, ORG.XDEFUNCT_IND, ORG.XWEBSITE, ORG.XMARKET_NAME, ORG.XBATCH_IND, ORG.XNUMOFEMP_TP_CD, ORG.XMODIFY_SYS_DT, ORG.XSOURCE_TYPE_FLAG, ORG.XGENERATED_BY, ORG.XCORP_CAT_TP_CD, ORG.XCORP_GROUP_TP_CD, ORG.XPERSONAL_AGREEMENT, ORG.XDo_Not_Merge_Flag, ORG.DELETE_FLAG, ORG.INFO_REMOVE_FLAG, ORG.DEDUP_HIDDEN_FLAG, ORG.PREF_COMMUNICATION_CHANNEL, ORG.YANASE_FLAG, ORG.FINANCE_PARTY_TYPE, ORG.CONTRACT_NUMBER, ORG.XPrivacy_Act, ORG.XFleet, ORG.XPC_Ind, ORG.XVANS_Ind, ORG.Last_Activity_Date, ORG.X_CUST_TYPE FROM ORG, CONTACT LEFT OUTER JOIN CONTSUMMARY CS ON CONTACT.CONT_ID = CS.CONT_ID WHERE ORG.CONT_ID = CONTACT.CONT_ID AND ORG.CONT_ID = ?",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"cont_id", "org_tp_cd", "industry_tp_cd", "established_dt", "buy_sell_agr_tp_cd", "profit_ind", "last_update_dt", "last_update_user", "last_update_tx_id", "cont_id", "acce_comp_tp_cd", "pref_lang_tp_cd", "created_dt", "since_dt", "left_dt", "inactivated_dt", "contact_name", "person_org_code", "solicit_ind", "confidential_ind", "client_imp_tp_cd", "client_st_tp_cd", "client_poten_tp_cd", "rpting_freq_tp_cd", "last_statement_dt", "provided_by_cont", "last_update_dt", "last_update_user", "alert_ind", "last_update_tx_id", "last_used_dt", "last_verified_dt", "source_ident_tp_cd", "do_not_delete_ind", "cont_id", "privpref_ind", "miscvalue_ind", "contactrel_ind", "bankaccount_ind", "chargecard_ind", "incomesource_ind", "payrolldeduct_ind", "identifier_ind", "alert_ind", "contequiv_ind", "interaction_ind", "addressgroup_ind", "contmethgroup_ind", "lobrel_ind", "last_update_dt", "last_update_user", "last_update_tx_id", "access_token_value", "pending_cdc_ind", "entitylink_st_tp_cd", "entity_id", "entity_type", "entity_status_tp_cd", "xdefunct_ind", "xwebsite", "xmarket_name", "xbatch_ind", "xnumofemp_tp_cd", "xmodify_sys_dt", "xsource_type_flag", "xgenerated_by", "xcorp_cat_tp_cd", "xcorp_group_tp_cd", "xpersonal_agreement", "xdo_not_merge_flag", "delete_flag", "info_remove_flag", "dedup_hidden_flag", "pref_communication_channel", "yanase_flag", "finance_party_type", "contract_number", "xprivacy_act", "xfleet", "xpc_ind", "xvans_ind", "last_activity_date", "x_cust_type"},
    new GetOrganizationIndicatorsParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetOrganizationIndicatorsRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.BIGINT, Types.CHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.CHAR, Types.CHAR, Types.CHAR, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR, Types.CHAR, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.CHAR, Types.BIGINT, Types.SMALLINT, Types.SMALLINT, Types.SMALLINT, Types.SMALLINT, Types.SMALLINT, Types.SMALLINT, Types.SMALLINT, Types.SMALLINT, Types.SMALLINT, Types.SMALLINT, Types.SMALLINT, Types.SMALLINT, Types.SMALLINT, Types.SMALLINT, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.CHAR, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR}, {19, 19, 19, 0, 19, 1, 0, 20, 19, 19, 19, 19, 0, 0, 0, 0, 255, 1, 1, 1, 19, 19, 19, 19, 0, 19, 0, 20, 1, 19, 0, 0, 19, 1, 19, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 0, 20, 19, 50, 1, 19, 19, 25, 19, 5, 255, 50, 5, 19, 0, 50, 50, 19, 19, 20, 5, 10, 10, 10, 255, 10, 10, 250, 250, 5, 10, 10, 0, 10}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    2);

  /**
   * @generated
   */
  public static class GetOrganizationIndicatorsParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetOrganizationIndicatorsRowHandler extends BaseRowHandler<ResultQueue4<EObjContact,EObjOrg,EObjContSummary,EObjXOrgExt>>
  {
    /**
     * @generated
     */
    public ResultQueue4<EObjContact,EObjOrg,EObjContSummary,EObjXOrgExt> handle (java.sql.ResultSet rs, ResultQueue4<EObjContact,EObjOrg,EObjContSummary,EObjXOrgExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue4<EObjContact,EObjOrg,EObjContSummary,EObjXOrgExt> ();

      EObjContact returnObject1 = new EObjContact ();
      returnObject1.setContIdPK(getLongObject (rs, 10)); 
      returnObject1.setAcceCompTpCd(getLongObject (rs, 11)); 
      returnObject1.setPrefLangTpCd(getLongObject (rs, 12)); 
      returnObject1.setCreatedDt(getTimestamp (rs, 13)); 
      returnObject1.setSinceDt(getTimestamp (rs, 14)); 
      returnObject1.setLeftDt(getTimestamp (rs, 15)); 
      returnObject1.setInactivatedDt(getTimestamp (rs, 16)); 
      returnObject1.setContactName(getString (rs, 17)); 
      returnObject1.setPersonOrgCode(getString (rs, 18)); 
      returnObject1.setSolicitInd(getString (rs, 19)); 
      returnObject1.setConfidentialInd(getString (rs, 20)); 
      returnObject1.setClientImpTpCd(getLongObject (rs, 21)); 
      returnObject1.setClientStTpCd(getLongObject (rs, 22)); 
      returnObject1.setClientPotenTpCd(getLongObject (rs, 23)); 
      returnObject1.setRptingFreqTpCd(getLongObject (rs, 24)); 
      returnObject1.setLastStatementDt(getTimestamp (rs, 25)); 
      returnObject1.setProvidedByCont(getLongObject (rs, 26)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 27)); 
      returnObject1.setLastUpdateUser(getString (rs, 28)); 
      returnObject1.setAlertInd(getString (rs, 29)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 30)); 
      returnObject1.setLastUsedDt(getTimestamp (rs, 31)); 
      returnObject1.setLastVerifiedDt(getTimestamp (rs, 32)); 
      returnObject1.setSourceIdentTpCd(getLongObject (rs, 33)); 
      returnObject1.setDoNotDelInd(getString (rs, 34)); 
      returnObject1.setAccessTokenValue(getString (rs, 53)); 
      returnObject1.setPendingCDCInd(getString (rs, 54)); 
      returnObject1.setEntitylink_st_tp_cd(getLongObject (rs, 55)); 
      returnObject1.setEntity_id(getLongObject (rs, 56)); 
      returnObject1.setEntity_type(getString (rs, 57)); 
      returnObject1.setEntityStatusTpCd(getLongObject (rs, 58)); 
      returnObject.add (returnObject1);

      EObjOrg returnObject2 = new EObjOrg ();
      returnObject2.setContIdPK(getLongObject (rs, 1)); 
      returnObject2.setOrgTpCd(getLongObject (rs, 2)); 
      returnObject2.setIndustryTpCd(getLongObject (rs, 3)); 
      returnObject2.setEstablishedDt(getTimestamp (rs, 4)); 
      returnObject2.setBuySellAgrTpCd(getLongObject (rs, 5)); 
      returnObject2.setProfitInd(getString (rs, 6)); 
      returnObject2.setLastUpdateDt(getTimestamp (rs, 7)); 
      returnObject2.setLastUpdateUser(getString (rs, 8)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 9)); 
      returnObject.add (returnObject2);

      EObjContSummary returnObject3 = new EObjContSummary ();
      returnObject3.setContId(getLongObject (rs, 35)); 
      returnObject3.setPrivPrefInd(getShortObject (rs,36)); 
      returnObject3.setMiscValueInd(getShortObject (rs,37)); 
      returnObject3.setBankAccountInd(getShortObject (rs,39)); 
      returnObject3.setChargeCardInd(getShortObject (rs,40)); 
      returnObject3.setIncomeSourceInd(getShortObject (rs,41)); 
      returnObject3.setPayrollDeductInd(getShortObject (rs,42)); 
      returnObject3.setIdentifierInd(getShortObject (rs,43)); 
      returnObject3.setAlertInd(getShortObject (rs,44)); 
      returnObject3.setContEquivInd(getShortObject (rs,45)); 
      returnObject3.setInteractionInd(getShortObject (rs,46)); 
      returnObject3.setAddressGroupInd(getShortObject (rs,47)); 
      returnObject3.setContMethGroupInd(getShortObject (rs,48)); 
      returnObject3.setLobRelInd(getShortObject (rs,49)); 
      returnObject3.setLastUpdateDt(getTimestamp (rs, 50)); 
      returnObject3.setLastUpdateUser(getString (rs, 51)); 
      returnObject3.setLastUpdateTxId(getLongObject (rs, 52)); 
      returnObject.add (returnObject3);

      EObjXOrgExt returnObject4 = new EObjXOrgExt ();
      returnObject4.setLastUpdateDt(getTimestamp (rs, 7)); 
      returnObject4.setLastUpdateUser(getString (rs, 8)); 
      returnObject4.setLastUpdateTxId(getLongObject (rs, 9)); 
      returnObject4.setXDefunctInd(getString (rs, 59)); 
      returnObject4.setXWebsite(getString (rs, 60)); 
      returnObject4.setXMarketName(getString (rs, 61)); 
      returnObject4.setXBatchInd(getString (rs, 62)); 
      returnObject4.setXNumberOfEmployees(getLongObject (rs, 63)); 
      returnObject4.setXLastModifiedSystemDate(getTimestamp (rs, 64)); 
      returnObject4.setXSourceTypeFlag(getString (rs, 65)); 
      returnObject4.setXGenerated_by(getString (rs, 66)); 
      returnObject4.setXCorporateCategory(getLongObject (rs, 67)); 
      returnObject4.setXCorporateGroup(getLongObject (rs, 68)); 
      returnObject4.setXPersonalAgreement(getString (rs, 69)); 
      returnObject4.setXDoNotMergeFlag(getString (rs, 70)); 
      returnObject4.setDeleteFlag(getString (rs, 71)); 
      returnObject4.setInfoRemoveFlag(getString (rs, 72)); 
      returnObject4.setDedupHiddenFlag(getString (rs, 73)); 
      returnObject4.setPrefCommunicationChannel(getString (rs, 74)); 
      returnObject4.setYanaseFlag(getString (rs, 75)); 
      returnObject4.setFinancePartyType(getString (rs, 76)); 
      returnObject4.setContractNumber(getString (rs, 77)); 
      returnObject4.setXPrivacyAct(getString (rs, 78)); 
      returnObject4.setXFleet(getString (rs, 79)); 
      returnObject4.setXPC_Ind(getString (rs, 80)); 
      returnObject4.setXVANS_Ind(getString (rs, 81)); 
      returnObject4.setLastActivityDate(getTimestamp (rs, 82)); 
      returnObject4.setX_CUST_TYPE(getString (rs, 83)); 
      returnObject.add (returnObject4);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT ORG.CONT_ID, ORG.ORG_TP_CD, ORG.INDUSTRY_TP_CD, ORG.ESTABLISHED_DT, ORG.BUY_SELL_AGR_TP_CD, ORG.PROFIT_IND, ORG.LAST_UPDATE_DT, ORG.LAST_UPDATE_USER, ORG.LAST_UPDATE_TX_ID, CONTACT.CONT_ID, CONTACT.ACCE_COMP_TP_CD, CONTACT.PREF_LANG_TP_CD, CONTACT.CREATED_DT, CONTACT.SINCE_DT, CONTACT.LEFT_DT, CONTACT.INACTIVATED_DT, CONTACT.CONTACT_NAME, CONTACT.PERSON_ORG_CODE, CONTACT.SOLICIT_IND, CONTACT.CONFIDENTIAL_IND, CONTACT.CLIENT_IMP_TP_CD, CONTACT.CLIENT_ST_TP_CD, CONTACT.CLIENT_POTEN_TP_CD, CONTACT.RPTING_FREQ_TP_CD, CONTACT.LAST_STATEMENT_DT, CONTACT.PROVIDED_BY_CONT, CONTACT.LAST_UPDATE_DT, CONTACT.LAST_UPDATE_USER, CONTACT.ALERT_IND, CONTACT.LAST_UPDATE_TX_ID, CONTACT.LAST_USED_DT, CONTACT.LAST_VERIFIED_DT, CONTACT.SOURCE_IDENT_TP_CD, CONTACT.DO_NOT_DELETE_IND, CONTACT.ACCESS_TOKEN_VALUE, CONTACT.PENDING_CDC_IND, CONTACT.ENTITYLINK_ST_TP_CD, CONTACT.ENTITY_ID, CONTACT.ENTITY_TYPE, CONTACT.ENTITY_STATUS_TP_CD, ORG.XDEFUNCT_IND, ORG.XWEBSITE, ORG.XMARKET_NAME, ORG.XBATCH_IND, ORG.XNUMOFEMP_TP_CD, ORG.XMODIFY_SYS_DT, ORG.XSOURCE_TYPE_FLAG, ORG.XGENERATED_BY, ORG.XCORP_CAT_TP_CD, ORG.XCORP_GROUP_TP_CD, ORG.XPERSONAL_AGREEMENT, ORG.XDo_Not_Merge_Flag, ORG.DELETE_FLAG, ORG.INFO_REMOVE_FLAG, ORG.DEDUP_HIDDEN_FLAG, ORG.PREF_COMMUNICATION_CHANNEL, ORG.YANASE_FLAG, ORG.FINANCE_PARTY_TYPE, ORG.CONTRACT_NUMBER, ORG.XPrivacy_Act, ORG.XFleet, ORG.XPC_Ind, ORG.XVANS_Ind, ORG.Last_Activity_Date, ORG.X_CUST_TYPE FROM ORG, CONTACT WHERE ORG.CONT_ID = CONTACT.CONT_ID AND ORG.CONT_ID = ?", pattern="tableAlias (CONTSUMMARY => com.dwl.tcrm.coreParty.entityObject.EObjContSummary, ORG => com.dwl.tcrm.coreParty.entityObject.EObjOrg, H_ORG => com.dwl.tcrm.coreParty.entityObject.EObjOrg, CONTACT => com.dwl.tcrm.coreParty.entityObject.EObjContact, H_CONTACT => com.dwl.tcrm.coreParty.entityObject.EObjContact , ORG => com.ibm.daimler.dsea.entityObject.EObjXOrgExt , H_ORG => com.ibm.daimler.dsea.entityObject.EObjXOrgExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue3<EObjContact,EObjOrg,EObjXOrgExt>> getOrganization (Object[] parameters)
  {
    return queryIterator (getOrganizationStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getOrganizationStatementDescriptor = createStatementDescriptor (
    "getOrganization(Object[])",
    "SELECT ORG.CONT_ID, ORG.ORG_TP_CD, ORG.INDUSTRY_TP_CD, ORG.ESTABLISHED_DT, ORG.BUY_SELL_AGR_TP_CD, ORG.PROFIT_IND, ORG.LAST_UPDATE_DT, ORG.LAST_UPDATE_USER, ORG.LAST_UPDATE_TX_ID, CONTACT.CONT_ID, CONTACT.ACCE_COMP_TP_CD, CONTACT.PREF_LANG_TP_CD, CONTACT.CREATED_DT, CONTACT.SINCE_DT, CONTACT.LEFT_DT, CONTACT.INACTIVATED_DT, CONTACT.CONTACT_NAME, CONTACT.PERSON_ORG_CODE, CONTACT.SOLICIT_IND, CONTACT.CONFIDENTIAL_IND, CONTACT.CLIENT_IMP_TP_CD, CONTACT.CLIENT_ST_TP_CD, CONTACT.CLIENT_POTEN_TP_CD, CONTACT.RPTING_FREQ_TP_CD, CONTACT.LAST_STATEMENT_DT, CONTACT.PROVIDED_BY_CONT, CONTACT.LAST_UPDATE_DT, CONTACT.LAST_UPDATE_USER, CONTACT.ALERT_IND, CONTACT.LAST_UPDATE_TX_ID, CONTACT.LAST_USED_DT, CONTACT.LAST_VERIFIED_DT, CONTACT.SOURCE_IDENT_TP_CD, CONTACT.DO_NOT_DELETE_IND, CONTACT.ACCESS_TOKEN_VALUE, CONTACT.PENDING_CDC_IND, CONTACT.ENTITYLINK_ST_TP_CD, CONTACT.ENTITY_ID, CONTACT.ENTITY_TYPE, CONTACT.ENTITY_STATUS_TP_CD, ORG.XDEFUNCT_IND, ORG.XWEBSITE, ORG.XMARKET_NAME, ORG.XBATCH_IND, ORG.XNUMOFEMP_TP_CD, ORG.XMODIFY_SYS_DT, ORG.XSOURCE_TYPE_FLAG, ORG.XGENERATED_BY, ORG.XCORP_CAT_TP_CD, ORG.XCORP_GROUP_TP_CD, ORG.XPERSONAL_AGREEMENT, ORG.XDo_Not_Merge_Flag, ORG.DELETE_FLAG, ORG.INFO_REMOVE_FLAG, ORG.DEDUP_HIDDEN_FLAG, ORG.PREF_COMMUNICATION_CHANNEL, ORG.YANASE_FLAG, ORG.FINANCE_PARTY_TYPE, ORG.CONTRACT_NUMBER, ORG.XPrivacy_Act, ORG.XFleet, ORG.XPC_Ind, ORG.XVANS_Ind, ORG.Last_Activity_Date, ORG.X_CUST_TYPE FROM ORG, CONTACT WHERE ORG.CONT_ID = CONTACT.CONT_ID AND ORG.CONT_ID = ?",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"cont_id", "org_tp_cd", "industry_tp_cd", "established_dt", "buy_sell_agr_tp_cd", "profit_ind", "last_update_dt", "last_update_user", "last_update_tx_id", "cont_id", "acce_comp_tp_cd", "pref_lang_tp_cd", "created_dt", "since_dt", "left_dt", "inactivated_dt", "contact_name", "person_org_code", "solicit_ind", "confidential_ind", "client_imp_tp_cd", "client_st_tp_cd", "client_poten_tp_cd", "rpting_freq_tp_cd", "last_statement_dt", "provided_by_cont", "last_update_dt", "last_update_user", "alert_ind", "last_update_tx_id", "last_used_dt", "last_verified_dt", "source_ident_tp_cd", "do_not_delete_ind", "access_token_value", "pending_cdc_ind", "entitylink_st_tp_cd", "entity_id", "entity_type", "entity_status_tp_cd", "xdefunct_ind", "xwebsite", "xmarket_name", "xbatch_ind", "xnumofemp_tp_cd", "xmodify_sys_dt", "xsource_type_flag", "xgenerated_by", "xcorp_cat_tp_cd", "xcorp_group_tp_cd", "xpersonal_agreement", "xdo_not_merge_flag", "delete_flag", "info_remove_flag", "dedup_hidden_flag", "pref_communication_channel", "yanase_flag", "finance_party_type", "contract_number", "xprivacy_act", "xfleet", "xpc_ind", "xvans_ind", "last_activity_date", "x_cust_type"},
    new GetOrganizationParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetOrganizationRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.BIGINT, Types.CHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.CHAR, Types.CHAR, Types.CHAR, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR, Types.CHAR, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.CHAR, Types.VARCHAR, Types.CHAR, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR}, {19, 19, 19, 0, 19, 1, 0, 20, 19, 19, 19, 19, 0, 0, 0, 0, 255, 1, 1, 1, 19, 19, 19, 19, 0, 19, 0, 20, 1, 19, 0, 0, 19, 1, 50, 1, 19, 19, 25, 19, 5, 255, 50, 5, 19, 0, 50, 50, 19, 19, 20, 5, 10, 10, 10, 255, 10, 10, 250, 250, 5, 10, 10, 0, 10}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    3);

  /**
   * @generated
   */
  public static class GetOrganizationParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetOrganizationRowHandler extends BaseRowHandler<ResultQueue3<EObjContact,EObjOrg,EObjXOrgExt>>
  {
    /**
     * @generated
     */
    public ResultQueue3<EObjContact,EObjOrg,EObjXOrgExt> handle (java.sql.ResultSet rs, ResultQueue3<EObjContact,EObjOrg,EObjXOrgExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue3<EObjContact,EObjOrg,EObjXOrgExt> ();

      EObjContact returnObject1 = new EObjContact ();
      returnObject1.setContIdPK(getLongObject (rs, 10)); 
      returnObject1.setAcceCompTpCd(getLongObject (rs, 11)); 
      returnObject1.setPrefLangTpCd(getLongObject (rs, 12)); 
      returnObject1.setCreatedDt(getTimestamp (rs, 13)); 
      returnObject1.setSinceDt(getTimestamp (rs, 14)); 
      returnObject1.setLeftDt(getTimestamp (rs, 15)); 
      returnObject1.setInactivatedDt(getTimestamp (rs, 16)); 
      returnObject1.setContactName(getString (rs, 17)); 
      returnObject1.setPersonOrgCode(getString (rs, 18)); 
      returnObject1.setSolicitInd(getString (rs, 19)); 
      returnObject1.setConfidentialInd(getString (rs, 20)); 
      returnObject1.setClientImpTpCd(getLongObject (rs, 21)); 
      returnObject1.setClientStTpCd(getLongObject (rs, 22)); 
      returnObject1.setClientPotenTpCd(getLongObject (rs, 23)); 
      returnObject1.setRptingFreqTpCd(getLongObject (rs, 24)); 
      returnObject1.setLastStatementDt(getTimestamp (rs, 25)); 
      returnObject1.setProvidedByCont(getLongObject (rs, 26)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 27)); 
      returnObject1.setLastUpdateUser(getString (rs, 28)); 
      returnObject1.setAlertInd(getString (rs, 29)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 30)); 
      returnObject1.setLastUsedDt(getTimestamp (rs, 31)); 
      returnObject1.setLastVerifiedDt(getTimestamp (rs, 32)); 
      returnObject1.setSourceIdentTpCd(getLongObject (rs, 33)); 
      returnObject1.setDoNotDelInd(getString (rs, 34)); 
      returnObject1.setAccessTokenValue(getString (rs, 35)); 
      returnObject1.setPendingCDCInd(getString (rs, 36)); 
      returnObject1.setEntitylink_st_tp_cd(getLongObject (rs, 37)); 
      returnObject1.setEntity_id(getLongObject (rs, 38)); 
      returnObject1.setEntity_type(getString (rs, 39)); 
      returnObject1.setEntityStatusTpCd(getLongObject (rs, 40)); 
      returnObject.add (returnObject1);

      EObjOrg returnObject2 = new EObjOrg ();
      returnObject2.setContIdPK(getLongObject (rs, 1)); 
      returnObject2.setOrgTpCd(getLongObject (rs, 2)); 
      returnObject2.setIndustryTpCd(getLongObject (rs, 3)); 
      returnObject2.setEstablishedDt(getTimestamp (rs, 4)); 
      returnObject2.setBuySellAgrTpCd(getLongObject (rs, 5)); 
      returnObject2.setProfitInd(getString (rs, 6)); 
      returnObject2.setLastUpdateDt(getTimestamp (rs, 7)); 
      returnObject2.setLastUpdateUser(getString (rs, 8)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 9)); 
      returnObject.add (returnObject2);

      EObjXOrgExt returnObject3 = new EObjXOrgExt ();
      returnObject3.setLastUpdateDt(getTimestamp (rs, 7)); 
      returnObject3.setLastUpdateUser(getString (rs, 8)); 
      returnObject3.setLastUpdateTxId(getLongObject (rs, 9)); 
      returnObject3.setXDefunctInd(getString (rs, 41)); 
      returnObject3.setXWebsite(getString (rs, 42)); 
      returnObject3.setXMarketName(getString (rs, 43)); 
      returnObject3.setXBatchInd(getString (rs, 44)); 
      returnObject3.setXNumberOfEmployees(getLongObject (rs, 45)); 
      returnObject3.setXLastModifiedSystemDate(getTimestamp (rs, 46)); 
      returnObject3.setXSourceTypeFlag(getString (rs, 47)); 
      returnObject3.setXGenerated_by(getString (rs, 48)); 
      returnObject3.setXCorporateCategory(getLongObject (rs, 49)); 
      returnObject3.setXCorporateGroup(getLongObject (rs, 50)); 
      returnObject3.setXPersonalAgreement(getString (rs, 51)); 
      returnObject3.setXDoNotMergeFlag(getString (rs, 52)); 
      returnObject3.setDeleteFlag(getString (rs, 53)); 
      returnObject3.setInfoRemoveFlag(getString (rs, 54)); 
      returnObject3.setDedupHiddenFlag(getString (rs, 55)); 
      returnObject3.setPrefCommunicationChannel(getString (rs, 56)); 
      returnObject3.setYanaseFlag(getString (rs, 57)); 
      returnObject3.setFinancePartyType(getString (rs, 58)); 
      returnObject3.setContractNumber(getString (rs, 59)); 
      returnObject3.setXPrivacyAct(getString (rs, 60)); 
      returnObject3.setXFleet(getString (rs, 61)); 
      returnObject3.setXPC_Ind(getString (rs, 62)); 
      returnObject3.setXVANS_Ind(getString (rs, 63)); 
      returnObject3.setLastActivityDate(getTimestamp (rs, 64)); 
      returnObject3.setX_CUST_TYPE(getString (rs, 65)); 
      returnObject.add (returnObject3);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT DISTINCT A.H_CONT_ID AS H_CONT_ID_ORG, A.H_ACTION_CODE,A.H_CREATED_BY,A.H_CREATE_DT,A.H_END_DT, A.CONT_ID,A.ORG_TP_CD,A.INDUSTRY_TP_CD,A.ESTABLISHED_DT, A.BUY_SELL_AGR_TP_CD,A.PROFIT_IND,A.LAST_UPDATE_DT, A.LAST_UPDATE_USER, A.LAST_UPDATE_TX_ID, B.H_CONT_ID AS H_CONT_ID,B.H_ACTION_CODE,B.H_CREATED_BY,B.H_CREATE_DT,B.H_END_DT,B.CONT_ID,B.ACCE_COMP_TP_CD, B.PREF_LANG_TP_CD,B.CREATED_DT, B.SINCE_DT, B.LEFT_DT, B.INACTIVATED_DT,B.CONTACT_NAME,B.PERSON_ORG_CODE,B.SOLICIT_IND,B.CONFIDENTIAL_IND,B.CLIENT_IMP_TP_CD,B.CLIENT_ST_TP_CD,B.CLIENT_POTEN_TP_CD,B.RPTING_FREQ_TP_CD,B.LAST_STATEMENT_DT,B.PROVIDED_BY_CONT,B.LAST_UPDATE_DT,B.LAST_UPDATE_USER,B.LAST_UPDATE_TX_ID, B.LAST_USED_DT, B.LAST_VERIFIED_DT, B.SOURCE_IDENT_TP_CD, B.DO_NOT_DELETE_IND ,B.ALERT_IND, B.ACCESS_TOKEN_VALUE, B.PENDING_CDC_IND, B.ENTITYLINK_ST_TP_CD, B.ENTITY_ID, B.ENTITY_TYPE, B.ENTITY_STATUS_TP_CD, A.XDEFUNCT_IND, A.XWEBSITE, A.XMARKET_NAME, A.XBATCH_IND, A.XNUMOFEMP_TP_CD, A.XMODIFY_SYS_DT, A.XSOURCE_TYPE_FLAG, A.XGENERATED_BY, A.XCORP_CAT_TP_CD, A.XCORP_GROUP_TP_CD, A.XPERSONAL_AGREEMENT, A.XDo_Not_Merge_Flag, A.DELETE_FLAG, A.INFO_REMOVE_FLAG, A.DEDUP_HIDDEN_FLAG, A.PREF_COMMUNICATION_CHANNEL, A.YANASE_FLAG, A.FINANCE_PARTY_TYPE, A.CONTRACT_NUMBER, A.XPrivacy_Act, A.XFleet, A.XPC_Ind, A.XVANS_Ind, A.Last_Activity_Date, A.X_CUST_TYPE FROM H_CONTACT B LEFT JOIN H_ORG A ON A.CONT_ID = B.CONT_ID AND A.LAST_UPDATE_TX_ID = B.LAST_UPDATE_TX_ID WHERE B.CONT_ID = ? AND (A.H_CREATE_DT BETWEEN ? AND ?) UNION SELECT DISTINCT A.H_CONT_ID AS H_CONT_ID_ORG,A.H_ACTION_CODE,A.H_CREATED_BY, A.H_CREATE_DT, A.H_END_DT,A.CONT_ID,A.ORG_TP_CD, A.INDUSTRY_TP_CD,A.ESTABLISHED_DT,A.BUY_SELL_AGR_TP_CD,A.PROFIT_IND,A.LAST_UPDATE_DT, A.LAST_UPDATE_USER,A.LAST_UPDATE_TX_ID,B.H_CONT_ID AS H_CONT_ID,B.H_ACTION_CODE,B.H_CREATED_BY, B.H_CREATE_DT,B.H_END_DT,B.CONT_ID,B.ACCE_COMP_TP_CD,B.PREF_LANG_TP_CD,B.CREATED_DT,B.SINCE_DT,B.LEFT_DT,B.INACTIVATED_DT,B.CONTACT_NAME,B.PERSON_ORG_CODE,B.SOLICIT_IND,B.CONFIDENTIAL_IND,B.CLIENT_IMP_TP_CD,B.CLIENT_ST_TP_CD,B.CLIENT_POTEN_TP_CD,B.RPTING_FREQ_TP_CD,B.LAST_STATEMENT_DT,B.PROVIDED_BY_CONT,B.LAST_UPDATE_DT,B.LAST_UPDATE_USER, B.LAST_UPDATE_TX_ID, B.LAST_USED_DT, B.LAST_VERIFIED_DT, B.SOURCE_IDENT_TP_CD, B.DO_NOT_DELETE_IND, B.ALERT_IND, B.ACCESS_TOKEN_VALUE, B.PENDING_CDC_IND,B.ENTITYLINK_ST_TP_CD, B.ENTITY_ID, B.ENTITY_TYPE, B.ENTITY_STATUS_TP_CD, A.XDEFUNCT_IND, A.XWEBSITE, A.XMARKET_NAME, A.XBATCH_IND, A.XNUMOFEMP_TP_CD, A.XMODIFY_SYS_DT, A.XSOURCE_TYPE_FLAG, A.XGENERATED_BY, A.XCORP_CAT_TP_CD, A.XCORP_GROUP_TP_CD, A.XPERSONAL_AGREEMENT, A.XDo_Not_Merge_Flag, A.DELETE_FLAG, A.INFO_REMOVE_FLAG, A.DEDUP_HIDDEN_FLAG, A.PREF_COMMUNICATION_CHANNEL, A.YANASE_FLAG, A.FINANCE_PARTY_TYPE, A.CONTRACT_NUMBER, A.XPrivacy_Act, A.XFleet, A.XPC_Ind, A.XVANS_Ind, A.Last_Activity_Date, A.X_CUST_TYPE FROM H_ORG A LEFT JOIN H_CONTACT B ON A.CONT_ID = B.CONT_ID AND A.LAST_UPDATE_TX_ID = B.LAST_UPDATE_TX_ID WHERE A.CONT_ID = ? AND ( A.H_CREATE_DT BETWEEN ? AND ?)", pattern="<rsm><col number='1' bean='com.dwl.tcrm.coreParty.entityObject.EObjOrg' property='historyIdPK'></col><col number='2' bean='com.dwl.tcrm.coreParty.entityObject.EObjOrg' property='histActionCode'></col><col number='3' bean='com.dwl.tcrm.coreParty.entityObject.EObjOrg' property='histCreatedBy'></col><col number='4' bean='com.dwl.tcrm.coreParty.entityObject.EObjOrg' property='histCreateDt'></col><col number='5' bean='com.dwl.tcrm.coreParty.entityObject.EObjOrg' property='histEndDt'></col><col number='6' bean='com.dwl.tcrm.coreParty.entityObject.EObjOrg' property='contIdPK'></col><col number='7' bean='com.dwl.tcrm.coreParty.entityObject.EObjOrg' property='orgTpCd'></col><col number='8' bean='com.dwl.tcrm.coreParty.entityObject.EObjOrg' property='industryTpCd'></col><col number='9' bean='com.dwl.tcrm.coreParty.entityObject.EObjOrg' property='establishedDt'></col><col number='10' bean='com.dwl.tcrm.coreParty.entityObject.EObjOrg' property='buySellAgrTpCd'></col><col number='11' bean='com.dwl.tcrm.coreParty.entityObject.EObjOrg' property='profitInd'></col><col number='12' bean='com.dwl.tcrm.coreParty.entityObject.EObjOrg' property='lastUpdateDt'></col><col number='13' bean='com.dwl.tcrm.coreParty.entityObject.EObjOrg' property='lastUpdateUser'></col><col number='14' bean='com.dwl.tcrm.coreParty.entityObject.EObjOrg' property='lastUpdateTxId'></col><col number='15' bean='com.dwl.tcrm.coreParty.entityObject.EObjContact' property='historyIdPK'></col><col number='16' bean='com.dwl.tcrm.coreParty.entityObject.EObjContact' property='histActionCode'></col><col number='17' bean='com.dwl.tcrm.coreParty.entityObject.EObjContact' property='histCreatedBy'></col><col number='18' bean='com.dwl.tcrm.coreParty.entityObject.EObjContact' property='histCreateDt'></col><col number='19' bean='com.dwl.tcrm.coreParty.entityObject.EObjContact' property='histEndDt'></col><col number='20' bean='com.dwl.tcrm.coreParty.entityObject.EObjContact' property='contIdPK'></col><col number='21' bean='com.dwl.tcrm.coreParty.entityObject.EObjContact' property='acceCompTpCd'></col><col number='22' bean='com.dwl.tcrm.coreParty.entityObject.EObjContact' property='prefLangTpCd'></col><col number='23' bean='com.dwl.tcrm.coreParty.entityObject.EObjContact' property='createdDt'></col><col number='24' bean='com.dwl.tcrm.coreParty.entityObject.EObjContact' property='sinceDt'></col><col number='25' bean='com.dwl.tcrm.coreParty.entityObject.EObjContact' property='leftDt'></col><col number='26' bean='com.dwl.tcrm.coreParty.entityObject.EObjContact' property='inactivatedDt'></col><col number='27' bean='com.dwl.tcrm.coreParty.entityObject.EObjContact' property='contactName'></col><col number='28' bean='com.dwl.tcrm.coreParty.entityObject.EObjContact' property='personOrgCode'></col><col number='29' bean='com.dwl.tcrm.coreParty.entityObject.EObjContact' property='solicitInd'></col><col number='30' bean='com.dwl.tcrm.coreParty.entityObject.EObjContact' property='confidentialInd'></col><col number='31' bean='com.dwl.tcrm.coreParty.entityObject.EObjContact' property='clientImpTpCd'></col><col number='32' bean='com.dwl.tcrm.coreParty.entityObject.EObjContact' property='clientStTpCd'></col><col number='33' bean='com.dwl.tcrm.coreParty.entityObject.EObjContact' property='clientPotenTpCd'></col><col number='34' bean='com.dwl.tcrm.coreParty.entityObject.EObjContact' property='rptingFreqTpCd'></col><col number='35' bean='com.dwl.tcrm.coreParty.entityObject.EObjContact' property='lastStatementDt'></col><col number='36' bean='com.dwl.tcrm.coreParty.entityObject.EObjContact' property='providedByCont'></col><col number='37' bean='com.dwl.tcrm.coreParty.entityObject.EObjContact' property='lastUpdateDt'></col><col number='38' bean='com.dwl.tcrm.coreParty.entityObject.EObjContact' property='lastUpdateUser'></col><col number='39' bean='com.dwl.tcrm.coreParty.entityObject.EObjContact' property='lastUpdateTxId'></col><col number='40' bean='com.dwl.tcrm.coreParty.entityObject.EObjContact' property='lastUsedDt'></col><col number='41' bean='com.dwl.tcrm.coreParty.entityObject.EObjContact' property='lastVerifiedDt'></col><col number='42' bean='com.dwl.tcrm.coreParty.entityObject.EObjContact' property='sourceIdentTpCd'></col><col number='43' bean='com.dwl.tcrm.coreParty.entityObject.EObjContact' property='doNotDelInd'></col><col number='44' bean='com.dwl.tcrm.coreParty.entityObject.EObjContact' property='alertInd'></col><col number='45' bean='com.dwl.tcrm.coreParty.entityObject.EObjContact' property='accessTokenValue'></col><col number='46' bean='com.dwl.tcrm.coreParty.entityObject.EObjContact' property='pendingCDCInd'></col><col number='47' bean='com.dwl.tcrm.coreParty.entityObject.EObjContact' property='entitylink_st_tp_cd'></col><col number='48' bean='com.dwl.tcrm.coreParty.entityObject.EObjContact' property='entity_id'></col><col number='49' bean='com.dwl.tcrm.coreParty.entityObject.EObjContact' property='entity_type'></col><col number='50' bean='com.dwl.tcrm.coreParty.entityObject.EObjContact' property='entityStatusTpCd'></col><col number='51' bean='com.ibm.daimler.dsea.entityObject.EObjXOrgExt' property='XDefunctInd'></col><col number='52' bean='com.ibm.daimler.dsea.entityObject.EObjXOrgExt' property='XWebsite'></col><col number='53' bean='com.ibm.daimler.dsea.entityObject.EObjXOrgExt' property='XMarketName'></col><col number='54' bean='com.ibm.daimler.dsea.entityObject.EObjXOrgExt' property='XBatchInd'></col><col number='55' bean='com.ibm.daimler.dsea.entityObject.EObjXOrgExt' property='XNumberOfEmployees'></col><col number='56' bean='com.ibm.daimler.dsea.entityObject.EObjXOrgExt' property='XLastModifiedSystemDate'></col><col number='57' bean='com.ibm.daimler.dsea.entityObject.EObjXOrgExt' property='XSourceTypeFlag'></col><col number='58' bean='com.ibm.daimler.dsea.entityObject.EObjXOrgExt' property='XGenerated_by'></col><col number='59' bean='com.ibm.daimler.dsea.entityObject.EObjXOrgExt' property='XCorporateCategory'></col><col number='60' bean='com.ibm.daimler.dsea.entityObject.EObjXOrgExt' property='XCorporateGroup'></col><col number='61' bean='com.ibm.daimler.dsea.entityObject.EObjXOrgExt' property='XPersonalAgreement'></col><col number='62' bean='com.ibm.daimler.dsea.entityObject.EObjXOrgExt' property='XDoNotMergeFlag'></col><col number='63' bean='com.ibm.daimler.dsea.entityObject.EObjXOrgExt' property='DeleteFlag'></col><col number='64' bean='com.ibm.daimler.dsea.entityObject.EObjXOrgExt' property='InfoRemoveFlag'></col><col number='65' bean='com.ibm.daimler.dsea.entityObject.EObjXOrgExt' property='DedupHiddenFlag'></col><col number='66' bean='com.ibm.daimler.dsea.entityObject.EObjXOrgExt' property='PrefCommunicationChannel'></col><col number='67' bean='com.ibm.daimler.dsea.entityObject.EObjXOrgExt' property='YanaseFlag'></col><col number='68' bean='com.ibm.daimler.dsea.entityObject.EObjXOrgExt' property='FinancePartyType'></col><col number='69' bean='com.ibm.daimler.dsea.entityObject.EObjXOrgExt' property='ContractNumber'></col><col number='70' bean='com.ibm.daimler.dsea.entityObject.EObjXOrgExt' property='XPrivacyAct'></col><col number='71' bean='com.ibm.daimler.dsea.entityObject.EObjXOrgExt' property='XFleet'></col><col number='72' bean='com.ibm.daimler.dsea.entityObject.EObjXOrgExt' property='XPC_Ind'></col><col number='73' bean='com.ibm.daimler.dsea.entityObject.EObjXOrgExt' property='XVANS_Ind'></col><col number='74' bean='com.ibm.daimler.dsea.entityObject.EObjXOrgExt' property='LastActivityDate'></col><col number='75' bean='com.ibm.daimler.dsea.entityObject.EObjXOrgExt' property='X_CUST_TYPE'></col></rsm>" )
   * 
   * @generated
   */
  public Iterator<ResultQueue3<EObjContact,EObjOrg,EObjXOrgExt>> getOrganizationImages (Object[] parameters)
  {
    return queryIterator (getOrganizationImagesStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getOrganizationImagesStatementDescriptor = createStatementDescriptor (
    "getOrganizationImages(Object[])",
    "SELECT DISTINCT A.H_CONT_ID AS H_CONT_ID_ORG, A.H_ACTION_CODE,A.H_CREATED_BY,A.H_CREATE_DT,A.H_END_DT, A.CONT_ID,A.ORG_TP_CD,A.INDUSTRY_TP_CD,A.ESTABLISHED_DT, A.BUY_SELL_AGR_TP_CD,A.PROFIT_IND,A.LAST_UPDATE_DT, A.LAST_UPDATE_USER, A.LAST_UPDATE_TX_ID, B.H_CONT_ID AS H_CONT_ID,B.H_ACTION_CODE,B.H_CREATED_BY,B.H_CREATE_DT,B.H_END_DT,B.CONT_ID,B.ACCE_COMP_TP_CD, B.PREF_LANG_TP_CD,B.CREATED_DT, B.SINCE_DT, B.LEFT_DT, B.INACTIVATED_DT,B.CONTACT_NAME,B.PERSON_ORG_CODE,B.SOLICIT_IND,B.CONFIDENTIAL_IND,B.CLIENT_IMP_TP_CD,B.CLIENT_ST_TP_CD,B.CLIENT_POTEN_TP_CD,B.RPTING_FREQ_TP_CD,B.LAST_STATEMENT_DT,B.PROVIDED_BY_CONT,B.LAST_UPDATE_DT,B.LAST_UPDATE_USER,B.LAST_UPDATE_TX_ID, B.LAST_USED_DT, B.LAST_VERIFIED_DT, B.SOURCE_IDENT_TP_CD, B.DO_NOT_DELETE_IND ,B.ALERT_IND, B.ACCESS_TOKEN_VALUE, B.PENDING_CDC_IND, B.ENTITYLINK_ST_TP_CD, B.ENTITY_ID, B.ENTITY_TYPE, B.ENTITY_STATUS_TP_CD, A.XDEFUNCT_IND, A.XWEBSITE, A.XMARKET_NAME, A.XBATCH_IND, A.XNUMOFEMP_TP_CD, A.XMODIFY_SYS_DT, A.XSOURCE_TYPE_FLAG, A.XGENERATED_BY, A.XCORP_CAT_TP_CD, A.XCORP_GROUP_TP_CD, A.XPERSONAL_AGREEMENT, A.XDo_Not_Merge_Flag, A.DELETE_FLAG, A.INFO_REMOVE_FLAG, A.DEDUP_HIDDEN_FLAG, A.PREF_COMMUNICATION_CHANNEL, A.YANASE_FLAG, A.FINANCE_PARTY_TYPE, A.CONTRACT_NUMBER, A.XPrivacy_Act, A.XFleet, A.XPC_Ind, A.XVANS_Ind, A.Last_Activity_Date, A.X_CUST_TYPE FROM H_CONTACT B LEFT JOIN H_ORG A ON A.CONT_ID = B.CONT_ID AND A.LAST_UPDATE_TX_ID = B.LAST_UPDATE_TX_ID WHERE B.CONT_ID = ? AND (A.H_CREATE_DT BETWEEN ? AND ?) UNION SELECT DISTINCT A.H_CONT_ID AS H_CONT_ID_ORG,A.H_ACTION_CODE,A.H_CREATED_BY, A.H_CREATE_DT, A.H_END_DT,A.CONT_ID,A.ORG_TP_CD, A.INDUSTRY_TP_CD,A.ESTABLISHED_DT,A.BUY_SELL_AGR_TP_CD,A.PROFIT_IND,A.LAST_UPDATE_DT, A.LAST_UPDATE_USER,A.LAST_UPDATE_TX_ID,B.H_CONT_ID AS H_CONT_ID,B.H_ACTION_CODE,B.H_CREATED_BY, B.H_CREATE_DT,B.H_END_DT,B.CONT_ID,B.ACCE_COMP_TP_CD,B.PREF_LANG_TP_CD,B.CREATED_DT,B.SINCE_DT,B.LEFT_DT,B.INACTIVATED_DT,B.CONTACT_NAME,B.PERSON_ORG_CODE,B.SOLICIT_IND,B.CONFIDENTIAL_IND,B.CLIENT_IMP_TP_CD,B.CLIENT_ST_TP_CD,B.CLIENT_POTEN_TP_CD,B.RPTING_FREQ_TP_CD,B.LAST_STATEMENT_DT,B.PROVIDED_BY_CONT,B.LAST_UPDATE_DT,B.LAST_UPDATE_USER, B.LAST_UPDATE_TX_ID, B.LAST_USED_DT, B.LAST_VERIFIED_DT, B.SOURCE_IDENT_TP_CD, B.DO_NOT_DELETE_IND, B.ALERT_IND, B.ACCESS_TOKEN_VALUE, B.PENDING_CDC_IND,B.ENTITYLINK_ST_TP_CD, B.ENTITY_ID, B.ENTITY_TYPE, B.ENTITY_STATUS_TP_CD, A.XDEFUNCT_IND, A.XWEBSITE, A.XMARKET_NAME, A.XBATCH_IND, A.XNUMOFEMP_TP_CD, A.XMODIFY_SYS_DT, A.XSOURCE_TYPE_FLAG, A.XGENERATED_BY, A.XCORP_CAT_TP_CD, A.XCORP_GROUP_TP_CD, A.XPERSONAL_AGREEMENT, A.XDo_Not_Merge_Flag, A.DELETE_FLAG, A.INFO_REMOVE_FLAG, A.DEDUP_HIDDEN_FLAG, A.PREF_COMMUNICATION_CHANNEL, A.YANASE_FLAG, A.FINANCE_PARTY_TYPE, A.CONTRACT_NUMBER, A.XPrivacy_Act, A.XFleet, A.XPC_Ind, A.XVANS_Ind, A.Last_Activity_Date, A.X_CUST_TYPE FROM H_ORG A LEFT JOIN H_CONTACT B ON A.CONT_ID = B.CONT_ID AND A.LAST_UPDATE_TX_ID = B.LAST_UPDATE_TX_ID WHERE A.CONT_ID = ? AND ( A.H_CREATE_DT BETWEEN ? AND ?)",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"h_cont_id_org", "h_action_code", "h_created_by", "h_create_dt", "h_end_dt", "cont_id", "org_tp_cd", "industry_tp_cd", "established_dt", "buy_sell_agr_tp_cd", "profit_ind", "last_update_dt", "last_update_user", "last_update_tx_id", "h_cont_id", "h_action_code", "h_created_by", "h_create_dt", "h_end_dt", "cont_id", "acce_comp_tp_cd", "pref_lang_tp_cd", "created_dt", "since_dt", "left_dt", "inactivated_dt", "contact_name", "person_org_code", "solicit_ind", "confidential_ind", "client_imp_tp_cd", "client_st_tp_cd", "client_poten_tp_cd", "rpting_freq_tp_cd", "last_statement_dt", "provided_by_cont", "last_update_dt", "last_update_user", "last_update_tx_id", "last_used_dt", "last_verified_dt", "source_ident_tp_cd", "do_not_delete_ind", "alert_ind", "access_token_value", "pending_cdc_ind", "entitylink_st_tp_cd", "entity_id", "entity_type", "entity_status_tp_cd", "xdefunct_ind", "xwebsite", "xmarket_name", "xbatch_ind", "xnumofemp_tp_cd", "xmodify_sys_dt", "xsource_type_flag", "xgenerated_by", "xcorp_cat_tp_cd", "xcorp_group_tp_cd", "xpersonal_agreement", "xdo_not_merge_flag", "delete_flag", "info_remove_flag", "dedup_hidden_flag", "pref_communication_channel", "yanase_flag", "finance_party_type", "contract_number", "xprivacy_act", "xfleet", "xpc_ind", "xvans_ind", "last_activity_date", "x_cust_type"},
    new GetOrganizationImagesParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP}, {19, 0, 0, 19, 0, 0}, {0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1}},
    null,
    new GetOrganizationImagesRowHandler (),
    new int[][]{ {Types.BIGINT, Types.CHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.BIGINT, Types.CHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.CHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.CHAR, Types.CHAR, Types.CHAR, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.CHAR, Types.CHAR, Types.VARCHAR, Types.CHAR, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR}, {19, 1, 20, 0, 0, 19, 19, 19, 0, 19, 1, 0, 20, 19, 19, 1, 20, 0, 0, 19, 19, 19, 0, 0, 0, 0, 255, 1, 1, 1, 19, 19, 19, 19, 0, 19, 0, 20, 19, 0, 0, 19, 1, 1, 50, 1, 19, 19, 25, 19, 5, 255, 50, 5, 19, 0, 50, 50, 19, 19, 20, 5, 10, 10, 10, 255, 10, 10, 250, 250, 5, 10, 10, 0, 10}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    4);

  /**
   * @generated
   */
  public static class GetOrganizationImagesParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
      setObject (stmt, 4, Types.BIGINT, parameters[3], 0);
      setObject (stmt, 5, Types.TIMESTAMP, parameters[4], 0);
      setObject (stmt, 6, Types.TIMESTAMP, parameters[5], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetOrganizationImagesRowHandler extends BaseRowHandler<ResultQueue3<EObjContact,EObjOrg,EObjXOrgExt>>
  {
    /**
     * @generated
     */
    public ResultQueue3<EObjContact,EObjOrg,EObjXOrgExt> handle (java.sql.ResultSet rs, ResultQueue3<EObjContact,EObjOrg,EObjXOrgExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue3<EObjContact,EObjOrg,EObjXOrgExt> ();

      EObjContact returnObject1 = new EObjContact ();
      returnObject1.setHistoryIdPK(getLongObject (rs, 15)); 
      returnObject1.setHistActionCode(getString (rs, 16)); 
      returnObject1.setHistCreatedBy(getString (rs, 17)); 
      returnObject1.setHistCreateDt(getTimestamp (rs, 18)); 
      returnObject1.setHistEndDt(getTimestamp (rs, 19)); 
      returnObject1.setContIdPK(getLongObject (rs, 20)); 
      returnObject1.setAcceCompTpCd(getLongObject (rs, 21)); 
      returnObject1.setPrefLangTpCd(getLongObject (rs, 22)); 
      returnObject1.setCreatedDt(getTimestamp (rs, 23)); 
      returnObject1.setSinceDt(getTimestamp (rs, 24)); 
      returnObject1.setLeftDt(getTimestamp (rs, 25)); 
      returnObject1.setInactivatedDt(getTimestamp (rs, 26)); 
      returnObject1.setContactName(getString (rs, 27)); 
      returnObject1.setPersonOrgCode(getString (rs, 28)); 
      returnObject1.setSolicitInd(getString (rs, 29)); 
      returnObject1.setConfidentialInd(getString (rs, 30)); 
      returnObject1.setClientImpTpCd(getLongObject (rs, 31)); 
      returnObject1.setClientStTpCd(getLongObject (rs, 32)); 
      returnObject1.setClientPotenTpCd(getLongObject (rs, 33)); 
      returnObject1.setRptingFreqTpCd(getLongObject (rs, 34)); 
      returnObject1.setLastStatementDt(getTimestamp (rs, 35)); 
      returnObject1.setProvidedByCont(getLongObject (rs, 36)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 37)); 
      returnObject1.setLastUpdateUser(getString (rs, 38)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 39)); 
      returnObject1.setLastUsedDt(getTimestamp (rs, 40)); 
      returnObject1.setLastVerifiedDt(getTimestamp (rs, 41)); 
      returnObject1.setSourceIdentTpCd(getLongObject (rs, 42)); 
      returnObject1.setDoNotDelInd(getString (rs, 43)); 
      returnObject1.setAlertInd(getString (rs, 44)); 
      returnObject1.setAccessTokenValue(getString (rs, 45)); 
      returnObject1.setPendingCDCInd(getString (rs, 46)); 
      returnObject1.setEntitylink_st_tp_cd(getLongObject (rs, 47)); 
      returnObject1.setEntity_id(getLongObject (rs, 48)); 
      returnObject1.setEntity_type(getString (rs, 49)); 
      returnObject1.setEntityStatusTpCd(getLongObject (rs, 50)); 
      returnObject.add (returnObject1);

      EObjOrg returnObject2 = new EObjOrg ();
      returnObject2.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject2.setHistActionCode(getString (rs, 2)); 
      returnObject2.setHistCreatedBy(getString (rs, 3)); 
      returnObject2.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject2.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject2.setContIdPK(getLongObject (rs, 6)); 
      returnObject2.setOrgTpCd(getLongObject (rs, 7)); 
      returnObject2.setIndustryTpCd(getLongObject (rs, 8)); 
      returnObject2.setEstablishedDt(getTimestamp (rs, 9)); 
      returnObject2.setBuySellAgrTpCd(getLongObject (rs, 10)); 
      returnObject2.setProfitInd(getString (rs, 11)); 
      returnObject2.setLastUpdateDt(getTimestamp (rs, 12)); 
      returnObject2.setLastUpdateUser(getString (rs, 13)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 14)); 
      returnObject.add (returnObject2);

      EObjXOrgExt returnObject3 = new EObjXOrgExt ();
      returnObject3.setXDefunctInd(getString (rs, 51)); 
      returnObject3.setXWebsite(getString (rs, 52)); 
      returnObject3.setXMarketName(getString (rs, 53)); 
      returnObject3.setXBatchInd(getString (rs, 54)); 
      returnObject3.setXNumberOfEmployees(getLongObject (rs, 55)); 
      returnObject3.setXLastModifiedSystemDate(getTimestamp (rs, 56)); 
      returnObject3.setXSourceTypeFlag(getString (rs, 57)); 
      returnObject3.setXGenerated_by(getString (rs, 58)); 
      returnObject3.setXCorporateCategory(getLongObject (rs, 59)); 
      returnObject3.setXCorporateGroup(getLongObject (rs, 60)); 
      returnObject3.setXPersonalAgreement(getString (rs, 61)); 
      returnObject3.setXDoNotMergeFlag(getString (rs, 62)); 
      returnObject3.setDeleteFlag(getString (rs, 63)); 
      returnObject3.setInfoRemoveFlag(getString (rs, 64)); 
      returnObject3.setDedupHiddenFlag(getString (rs, 65)); 
      returnObject3.setPrefCommunicationChannel(getString (rs, 66)); 
      returnObject3.setYanaseFlag(getString (rs, 67)); 
      returnObject3.setFinancePartyType(getString (rs, 68)); 
      returnObject3.setContractNumber(getString (rs, 69)); 
      returnObject3.setXPrivacyAct(getString (rs, 70)); 
      returnObject3.setXFleet(getString (rs, 71)); 
      returnObject3.setXPC_Ind(getString (rs, 72)); 
      returnObject3.setXVANS_Ind(getString (rs, 73)); 
      returnObject3.setLastActivityDate(getTimestamp (rs, 74)); 
      returnObject3.setX_CUST_TYPE(getString (rs, 75)); 
      returnObject.add (returnObject3);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT DISTINCT A.CONT_ID, A.LAST_UPDATE_DT, B.ACCESS_TOKEN_VALUE, B.PENDING_CDC_IND, A.XDEFUNCT_IND, A.XWEBSITE, A.XMARKET_NAME, A.XBATCH_IND, A.XNUMOFEMP_TP_CD, A.XMODIFY_SYS_DT, A.XSOURCE_TYPE_FLAG, A.XGENERATED_BY, A.XCORP_CAT_TP_CD, A.XCORP_GROUP_TP_CD, A.XPERSONAL_AGREEMENT, A.XDo_Not_Merge_Flag, A.DELETE_FLAG, A.INFO_REMOVE_FLAG, A.DEDUP_HIDDEN_FLAG, A.PREF_COMMUNICATION_CHANNEL, A.YANASE_FLAG, A.FINANCE_PARTY_TYPE, A.CONTRACT_NUMBER, A.XPrivacy_Act, A.XFleet, A.XPC_Ind, A.XVANS_Ind, A.Last_Activity_Date, A.X_CUST_TYPE FROM H_CONTACT B LEFT JOIN H_ORG A ON A.CONT_ID = B.CONT_ID AND A.LAST_UPDATE_TX_ID = B.LAST_UPDATE_TX_ID WHERE B.CONT_ID = ? AND (A.H_CREATE_DT BETWEEN ? AND ?) UNION SELECT DISTINCT A.CONT_ID, A.LAST_UPDATE_DT, B.ACCESS_TOKEN_VALUE, B.PENDING_CDC_IND, A.XDEFUNCT_IND, A.XWEBSITE, A.XMARKET_NAME, A.XBATCH_IND, A.XNUMOFEMP_TP_CD, A.XMODIFY_SYS_DT, A.XSOURCE_TYPE_FLAG, A.XGENERATED_BY, A.XCORP_CAT_TP_CD, A.XCORP_GROUP_TP_CD, A.XPERSONAL_AGREEMENT, A.XDo_Not_Merge_Flag, A.DELETE_FLAG, A.INFO_REMOVE_FLAG, A.DEDUP_HIDDEN_FLAG, A.PREF_COMMUNICATION_CHANNEL, A.YANASE_FLAG, A.FINANCE_PARTY_TYPE, A.CONTRACT_NUMBER, A.XPrivacy_Act, A.XFleet, A.XPC_Ind, A.XVANS_Ind, A.Last_Activity_Date, A.X_CUST_TYPE FROM H_ORG A LEFT JOIN H_CONTACT B ON A.CONT_ID = B.CONT_ID AND A.LAST_UPDATE_TX_ID = B.LAST_UPDATE_TX_ID WHERE A.CONT_ID = ? AND ( A.H_CREATE_DT BETWEEN ? AND ?)", pattern="<rsm><col number='1' bean='com.dwl.tcrm.coreParty.entityObject.EObjOrg' property='contIdPK'></col><col number='2' bean='com.dwl.tcrm.coreParty.entityObject.EObjOrg' property='lastUpdateDt'></col><col number='3' bean='com.dwl.tcrm.coreParty.entityObject.EObjContact' property='accessTokenValue'></col><col number='4' bean='com.dwl.tcrm.coreParty.entityObject.EObjContact' property='pendingCDCInd'></col><col number='5' bean='com.ibm.daimler.dsea.entityObject.EObjXOrgExt' property='XDefunctInd'></col><col number='6' bean='com.ibm.daimler.dsea.entityObject.EObjXOrgExt' property='XWebsite'></col><col number='7' bean='com.ibm.daimler.dsea.entityObject.EObjXOrgExt' property='XMarketName'></col><col number='8' bean='com.ibm.daimler.dsea.entityObject.EObjXOrgExt' property='XBatchInd'></col><col number='9' bean='com.ibm.daimler.dsea.entityObject.EObjXOrgExt' property='XNumberOfEmployees'></col><col number='10' bean='com.ibm.daimler.dsea.entityObject.EObjXOrgExt' property='XLastModifiedSystemDate'></col><col number='11' bean='com.ibm.daimler.dsea.entityObject.EObjXOrgExt' property='XSourceTypeFlag'></col><col number='12' bean='com.ibm.daimler.dsea.entityObject.EObjXOrgExt' property='XGenerated_by'></col><col number='13' bean='com.ibm.daimler.dsea.entityObject.EObjXOrgExt' property='XCorporateCategory'></col><col number='14' bean='com.ibm.daimler.dsea.entityObject.EObjXOrgExt' property='XCorporateGroup'></col><col number='15' bean='com.ibm.daimler.dsea.entityObject.EObjXOrgExt' property='XPersonalAgreement'></col><col number='16' bean='com.ibm.daimler.dsea.entityObject.EObjXOrgExt' property='XDoNotMergeFlag'></col><col number='17' bean='com.ibm.daimler.dsea.entityObject.EObjXOrgExt' property='DeleteFlag'></col><col number='18' bean='com.ibm.daimler.dsea.entityObject.EObjXOrgExt' property='InfoRemoveFlag'></col><col number='19' bean='com.ibm.daimler.dsea.entityObject.EObjXOrgExt' property='DedupHiddenFlag'></col><col number='20' bean='com.ibm.daimler.dsea.entityObject.EObjXOrgExt' property='PrefCommunicationChannel'></col><col number='21' bean='com.ibm.daimler.dsea.entityObject.EObjXOrgExt' property='YanaseFlag'></col><col number='22' bean='com.ibm.daimler.dsea.entityObject.EObjXOrgExt' property='FinancePartyType'></col><col number='23' bean='com.ibm.daimler.dsea.entityObject.EObjXOrgExt' property='ContractNumber'></col><col number='24' bean='com.ibm.daimler.dsea.entityObject.EObjXOrgExt' property='XPrivacyAct'></col><col number='25' bean='com.ibm.daimler.dsea.entityObject.EObjXOrgExt' property='XFleet'></col><col number='26' bean='com.ibm.daimler.dsea.entityObject.EObjXOrgExt' property='XPC_Ind'></col><col number='27' bean='com.ibm.daimler.dsea.entityObject.EObjXOrgExt' property='XVANS_Ind'></col><col number='28' bean='com.ibm.daimler.dsea.entityObject.EObjXOrgExt' property='LastActivityDate'></col><col number='29' bean='com.ibm.daimler.dsea.entityObject.EObjXOrgExt' property='X_CUST_TYPE'></col></rsm>" )
   * 
   * @generated
   */
  public Iterator<ResultQueue3<EObjContact,EObjOrg,EObjXOrgExt>> getOrganizationsLightImages (Object[] parameters)
  {
    return queryIterator (getOrganizationsLightImagesStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getOrganizationsLightImagesStatementDescriptor = createStatementDescriptor (
    "getOrganizationsLightImages(Object[])",
    "SELECT DISTINCT A.CONT_ID, A.LAST_UPDATE_DT, B.ACCESS_TOKEN_VALUE, B.PENDING_CDC_IND, A.XDEFUNCT_IND, A.XWEBSITE, A.XMARKET_NAME, A.XBATCH_IND, A.XNUMOFEMP_TP_CD, A.XMODIFY_SYS_DT, A.XSOURCE_TYPE_FLAG, A.XGENERATED_BY, A.XCORP_CAT_TP_CD, A.XCORP_GROUP_TP_CD, A.XPERSONAL_AGREEMENT, A.XDo_Not_Merge_Flag, A.DELETE_FLAG, A.INFO_REMOVE_FLAG, A.DEDUP_HIDDEN_FLAG, A.PREF_COMMUNICATION_CHANNEL, A.YANASE_FLAG, A.FINANCE_PARTY_TYPE, A.CONTRACT_NUMBER, A.XPrivacy_Act, A.XFleet, A.XPC_Ind, A.XVANS_Ind, A.Last_Activity_Date, A.X_CUST_TYPE FROM H_CONTACT B LEFT JOIN H_ORG A ON A.CONT_ID = B.CONT_ID AND A.LAST_UPDATE_TX_ID = B.LAST_UPDATE_TX_ID WHERE B.CONT_ID = ? AND (A.H_CREATE_DT BETWEEN ? AND ?) UNION SELECT DISTINCT A.CONT_ID, A.LAST_UPDATE_DT, B.ACCESS_TOKEN_VALUE, B.PENDING_CDC_IND, A.XDEFUNCT_IND, A.XWEBSITE, A.XMARKET_NAME, A.XBATCH_IND, A.XNUMOFEMP_TP_CD, A.XMODIFY_SYS_DT, A.XSOURCE_TYPE_FLAG, A.XGENERATED_BY, A.XCORP_CAT_TP_CD, A.XCORP_GROUP_TP_CD, A.XPERSONAL_AGREEMENT, A.XDo_Not_Merge_Flag, A.DELETE_FLAG, A.INFO_REMOVE_FLAG, A.DEDUP_HIDDEN_FLAG, A.PREF_COMMUNICATION_CHANNEL, A.YANASE_FLAG, A.FINANCE_PARTY_TYPE, A.CONTRACT_NUMBER, A.XPrivacy_Act, A.XFleet, A.XPC_Ind, A.XVANS_Ind, A.Last_Activity_Date, A.X_CUST_TYPE FROM H_ORG A LEFT JOIN H_CONTACT B ON A.CONT_ID = B.CONT_ID AND A.LAST_UPDATE_TX_ID = B.LAST_UPDATE_TX_ID WHERE A.CONT_ID = ? AND ( A.H_CREATE_DT BETWEEN ? AND ?)",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"cont_id", "last_update_dt", "access_token_value", "pending_cdc_ind", "xdefunct_ind", "xwebsite", "xmarket_name", "xbatch_ind", "xnumofemp_tp_cd", "xmodify_sys_dt", "xsource_type_flag", "xgenerated_by", "xcorp_cat_tp_cd", "xcorp_group_tp_cd", "xpersonal_agreement", "xdo_not_merge_flag", "delete_flag", "info_remove_flag", "dedup_hidden_flag", "pref_communication_channel", "yanase_flag", "finance_party_type", "contract_number", "xprivacy_act", "xfleet", "xpc_ind", "xvans_ind", "last_activity_date", "x_cust_type"},
    new GetOrganizationsLightImagesParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP}, {19, 0, 0, 19, 0, 0}, {0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1}},
    null,
    new GetOrganizationsLightImagesRowHandler (),
    new int[][]{ {Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR, Types.CHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR}, {19, 0, 50, 1, 5, 255, 50, 5, 19, 0, 50, 50, 19, 19, 20, 5, 10, 10, 10, 255, 10, 10, 250, 250, 5, 10, 10, 0, 10}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    5);

  /**
   * @generated
   */
  public static class GetOrganizationsLightImagesParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
      setObject (stmt, 4, Types.BIGINT, parameters[3], 0);
      setObject (stmt, 5, Types.TIMESTAMP, parameters[4], 0);
      setObject (stmt, 6, Types.TIMESTAMP, parameters[5], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetOrganizationsLightImagesRowHandler extends BaseRowHandler<ResultQueue3<EObjContact,EObjOrg,EObjXOrgExt>>
  {
    /**
     * @generated
     */
    public ResultQueue3<EObjContact,EObjOrg,EObjXOrgExt> handle (java.sql.ResultSet rs, ResultQueue3<EObjContact,EObjOrg,EObjXOrgExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue3<EObjContact,EObjOrg,EObjXOrgExt> ();

      EObjContact returnObject1 = new EObjContact ();
      returnObject1.setAccessTokenValue(getString (rs, 3)); 
      returnObject1.setPendingCDCInd(getString (rs, 4)); 
      returnObject.add (returnObject1);

      EObjOrg returnObject2 = new EObjOrg ();
      returnObject2.setContIdPK(getLongObject (rs, 1)); 
      returnObject2.setLastUpdateDt(getTimestamp (rs, 2)); 
      returnObject.add (returnObject2);

      EObjXOrgExt returnObject3 = new EObjXOrgExt ();
      returnObject3.setXDefunctInd(getString (rs, 5)); 
      returnObject3.setXWebsite(getString (rs, 6)); 
      returnObject3.setXMarketName(getString (rs, 7)); 
      returnObject3.setXBatchInd(getString (rs, 8)); 
      returnObject3.setXNumberOfEmployees(getLongObject (rs, 9)); 
      returnObject3.setXLastModifiedSystemDate(getTimestamp (rs, 10)); 
      returnObject3.setXSourceTypeFlag(getString (rs, 11)); 
      returnObject3.setXGenerated_by(getString (rs, 12)); 
      returnObject3.setXCorporateCategory(getLongObject (rs, 13)); 
      returnObject3.setXCorporateGroup(getLongObject (rs, 14)); 
      returnObject3.setXPersonalAgreement(getString (rs, 15)); 
      returnObject3.setXDoNotMergeFlag(getString (rs, 16)); 
      returnObject3.setDeleteFlag(getString (rs, 17)); 
      returnObject3.setInfoRemoveFlag(getString (rs, 18)); 
      returnObject3.setDedupHiddenFlag(getString (rs, 19)); 
      returnObject3.setPrefCommunicationChannel(getString (rs, 20)); 
      returnObject3.setYanaseFlag(getString (rs, 21)); 
      returnObject3.setFinancePartyType(getString (rs, 22)); 
      returnObject3.setContractNumber(getString (rs, 23)); 
      returnObject3.setXPrivacyAct(getString (rs, 24)); 
      returnObject3.setXFleet(getString (rs, 25)); 
      returnObject3.setXPC_Ind(getString (rs, 26)); 
      returnObject3.setXVANS_Ind(getString (rs, 27)); 
      returnObject3.setLastActivityDate(getTimestamp (rs, 28)); 
      returnObject3.setX_CUST_TYPE(getString (rs, 29)); 
      returnObject.add (returnObject3);

    
      return returnObject;
    }
  }

}
