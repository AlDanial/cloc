/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[ddda488539e2e8c0fa143fed3506ad59]
 */


package com.ibm.daimler.dsea.entityObject;

import java.util.Iterator;
import com.ibm.mdm.base.db.EntityMapping;
import com.ibm.pdq.annotation.Select;
import com.ibm.pdq.annotation.Update;

import com.ibm.daimler.dsea.entityObject.EObjXPrivacyAgreement;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * @generated
 */
public interface EObjXPrivacyAgreementData {


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjXPrivacyAgreementSql = "select PRIVAGREEMENTPK_ID, LOCATION_GROUP_ID, ACTION_TP_CD, SOURCE_IDENT_TP_CD, START_DT, END_DT, MODIFY_SYS_DT, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from XPRIVAGREEMENT where PRIVAGREEMENTPK_ID = ? ";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String createEObjXPrivacyAgreementSql = "insert into XPRIVAGREEMENT (PRIVAGREEMENTPK_ID, LOCATION_GROUP_ID, ACTION_TP_CD, SOURCE_IDENT_TP_CD, START_DT, END_DT, MODIFY_SYS_DT, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( :privacyAgreementpkId, :locationGroupId, :action, :sourceIdentifier, :startDate, :endDate, :lastModifiedSystemDate, :lastUpdateDt, :lastUpdateUser, :lastUpdateTxId)";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String updateEObjXPrivacyAgreementSql = "update XPRIVAGREEMENT set LOCATION_GROUP_ID = :locationGroupId, ACTION_TP_CD = :action, SOURCE_IDENT_TP_CD = :sourceIdentifier, START_DT = :startDate, END_DT = :endDate, MODIFY_SYS_DT = :lastModifiedSystemDate, LAST_UPDATE_DT = :lastUpdateDt, LAST_UPDATE_USER = :lastUpdateUser, LAST_UPDATE_TX_ID = :lastUpdateTxId where PRIVAGREEMENTPK_ID = :privacyAgreementpkId and LAST_UPDATE_DT = :oldLastUpdateDt";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String deleteEObjXPrivacyAgreementSql = "delete from XPRIVAGREEMENT where PRIVAGREEMENTPK_ID = ?";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXPrivacyAgreementKeyField = "EObjXPrivacyAgreement.privacyAgreementpkId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXPrivacyAgreementGetFields =
    "EObjXPrivacyAgreement.privacyAgreementpkId," +
    "EObjXPrivacyAgreement.locationGroupId," +
    "EObjXPrivacyAgreement.action," +
    "EObjXPrivacyAgreement.sourceIdentifier," +
    "EObjXPrivacyAgreement.startDate," +
    "EObjXPrivacyAgreement.endDate," +
    "EObjXPrivacyAgreement.lastModifiedSystemDate," +
    "EObjXPrivacyAgreement.lastUpdateDt," +
    "EObjXPrivacyAgreement.lastUpdateUser," +
    "EObjXPrivacyAgreement.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXPrivacyAgreementAllFields =
    "com.ibm.daimler.dsea.entityObject.EObjXPrivacyAgreement.privacyAgreementpkId," +
    "com.ibm.daimler.dsea.entityObject.EObjXPrivacyAgreement.locationGroupId," +
    "com.ibm.daimler.dsea.entityObject.EObjXPrivacyAgreement.action," +
    "com.ibm.daimler.dsea.entityObject.EObjXPrivacyAgreement.sourceIdentifier," +
    "com.ibm.daimler.dsea.entityObject.EObjXPrivacyAgreement.startDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXPrivacyAgreement.endDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXPrivacyAgreement.lastModifiedSystemDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXPrivacyAgreement.lastUpdateDt," +
    "com.ibm.daimler.dsea.entityObject.EObjXPrivacyAgreement.lastUpdateUser," +
    "com.ibm.daimler.dsea.entityObject.EObjXPrivacyAgreement.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXPrivacyAgreementUpdateFields =
    "com.ibm.daimler.dsea.entityObject.EObjXPrivacyAgreement.locationGroupId," +
    "com.ibm.daimler.dsea.entityObject.EObjXPrivacyAgreement.action," +
    "com.ibm.daimler.dsea.entityObject.EObjXPrivacyAgreement.sourceIdentifier," +
    "com.ibm.daimler.dsea.entityObject.EObjXPrivacyAgreement.startDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXPrivacyAgreement.endDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXPrivacyAgreement.lastModifiedSystemDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXPrivacyAgreement.lastUpdateDt," +
    "com.ibm.daimler.dsea.entityObject.EObjXPrivacyAgreement.lastUpdateUser," +
    "com.ibm.daimler.dsea.entityObject.EObjXPrivacyAgreement.lastUpdateTxId," +
    "com.ibm.daimler.dsea.entityObject.EObjXPrivacyAgreement.privacyAgreementpkId," +
    "com.ibm.daimler.dsea.entityObject.EObjXPrivacyAgreement.oldLastUpdateDt";   

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Select XPrivacyAgreement by parameters.
   * @generated
   */
  @Select(sql=getEObjXPrivacyAgreementSql)
  @EntityMapping(parameters=EObjXPrivacyAgreementKeyField, results=EObjXPrivacyAgreementGetFields)
  Iterator<EObjXPrivacyAgreement> getEObjXPrivacyAgreement(Long privacyAgreementpkId);  
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Create XPrivacyAgreement by EObjXPrivacyAgreement Object.
   * @generated
   */
  @Update(sql=createEObjXPrivacyAgreementSql)
  @EntityMapping(parameters=EObjXPrivacyAgreementAllFields)
    int createEObjXPrivacyAgreement(EObjXPrivacyAgreement e); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Update one XPrivacyAgreement by EObjXPrivacyAgreement object.
   * @generated
   */
  @Update(sql=updateEObjXPrivacyAgreementSql)
  @EntityMapping(parameters=EObjXPrivacyAgreementUpdateFields)
    int updateEObjXPrivacyAgreement(EObjXPrivacyAgreement e); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Delete XPrivacyAgreement by parameters.
   * @generated
   */
  @Update(sql=deleteEObjXPrivacyAgreementSql)
  @EntityMapping(parameters=EObjXPrivacyAgreementKeyField)
  int deleteEObjXPrivacyAgreement(Long privacyAgreementpkId);

}

