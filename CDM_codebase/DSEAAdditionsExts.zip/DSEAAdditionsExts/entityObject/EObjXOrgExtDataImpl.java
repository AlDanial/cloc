package com.ibm.daimler.dsea.entityObject;

import com.ibm.pdq.runtime.generator.BaseParameterHandler;
import com.dwl.tcrm.coreParty.entityObject.EObjOrg;
import java.util.Iterator;
import java.sql.PreparedStatement;
import com.ibm.pdq.runtime.statement.StatementDescriptor;
import com.ibm.pdq.runtime.generator.BaseData;
import java.sql.SQLException;
import com.ibm.pdq.annotation.Metadata;
import com.ibm.daimler.dsea.entityObject.EObjXOrgExt;
import com.ibm.pdq.runtime.generator.BaseRowHandler;
import com.ibm.pdq.runtime.statement.SqlStatementType;
import java.sql.Types;


/**
 * <!-- begin-user-doc -->
 * 
 * <!-- end-user-doc -->
 * 
 * @generated
 */
public class EObjXOrgExtDataImpl  extends BaseData implements EObjXOrgExtData
{

  /**
   * @generated
   */
  public static final String generatorVersion = "3.200.75";

  /**
   * @generated
   */
  public static final String identifier = "EObjXOrgExtData";

  /**
   * @generated
   */
  public static final long generationTime = 0x00000170aed92d76L;

  /**
   * @generated
   */
  public static final String collection = "NULLID";

  /**
   * @generated
   */
  public static final String packageVersion = null;

  /**
   * @generated
   */
  public static final boolean forceSingleBindIsolation = false;

  /**
   * @generated
   */
  public EObjXOrgExtDataImpl()
  {
    super();
  } 

  /**
   * @generated
   */
  public String getGeneratorVersion()
  {
    return generatorVersion;
  }

  /**
   * @Select( sql="select XDEFUNCT_IND, XWEBSITE, XMARKET_NAME, XBATCH_IND, XNUMOFEMP_TP_CD, XMODIFY_SYS_DT, XSOURCE_TYPE_FLAG, XGENERATED_BY, XCORP_CAT_TP_CD, XCORP_GROUP_TP_CD, XPERSONAL_AGREEMENT, XDo_Not_Merge_Flag, DELETE_FLAG, INFO_REMOVE_FLAG, DEDUP_HIDDEN_FLAG, PREF_COMMUNICATION_CHANNEL, YANASE_FLAG, FINANCE_PARTY_TYPE, CONTRACT_NUMBER, XPrivacy_Act, XFleet, XPC_Ind, XVANS_Ind, Last_Activity_Date, X_CUST_TYPE, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from ORG where CONT_ID = ? " )
   * 
   * @generated
   */
  public Iterator<EObjXOrgExt> getEObjXOrgExt (Long contIdPK)
  {
    return queryIterator (getEObjXOrgExtStatementDescriptor, contIdPK);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getEObjXOrgExtStatementDescriptor = createStatementDescriptor (
    "getEObjXOrgExt(Long)",
    "select XDEFUNCT_IND, XWEBSITE, XMARKET_NAME, XBATCH_IND, XNUMOFEMP_TP_CD, XMODIFY_SYS_DT, XSOURCE_TYPE_FLAG, XGENERATED_BY, XCORP_CAT_TP_CD, XCORP_GROUP_TP_CD, XPERSONAL_AGREEMENT, XDo_Not_Merge_Flag, DELETE_FLAG, INFO_REMOVE_FLAG, DEDUP_HIDDEN_FLAG, PREF_COMMUNICATION_CHANNEL, YANASE_FLAG, FINANCE_PARTY_TYPE, CONTRACT_NUMBER, XPrivacy_Act, XFleet, XPC_Ind, XVANS_Ind, Last_Activity_Date, X_CUST_TYPE, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from ORG where CONT_ID = ? ",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"xdefunct_ind", "xwebsite", "xmarket_name", "xbatch_ind", "xnumofemp_tp_cd", "xmodify_sys_dt", "xsource_type_flag", "xgenerated_by", "xcorp_cat_tp_cd", "xcorp_group_tp_cd", "xpersonal_agreement", "xdo_not_merge_flag", "delete_flag", "info_remove_flag", "dedup_hidden_flag", "pref_communication_channel", "yanase_flag", "finance_party_type", "contract_number", "xprivacy_act", "xfleet", "xpc_ind", "xvans_ind", "last_activity_date", "x_cust_type", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetEObjXOrgExtParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetEObjXOrgExtRowHandler (),
    new int[][]{ {Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {5, 255, 50, 5, 19, 0, 50, 50, 19, 19, 20, 5, 10, 10, 10, 255, 10, 10, 250, 250, 5, 10, 10, 0, 10, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    1);

  /**
   * @generated
   */
  public static class GetEObjXOrgExtParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setLong (stmt, 1, Types.BIGINT, (Long)parameters[0]);
    }
  }

  /**
   * @generated
   */
  public static class GetEObjXOrgExtRowHandler extends BaseRowHandler<EObjXOrgExt>
  {
    /**
     * @generated
     */
    public EObjXOrgExt handle (java.sql.ResultSet rs, EObjXOrgExt returnObject) throws java.sql.SQLException
    {
      returnObject = new EObjXOrgExt ();
      returnObject.setXDefunctInd(getString (rs, 1)); 
      returnObject.setXWebsite(getString (rs, 2)); 
      returnObject.setXMarketName(getString (rs, 3)); 
      returnObject.setXBatchInd(getString (rs, 4)); 
      returnObject.setXNumberOfEmployees(getLongObject (rs, 5)); 
      returnObject.setXLastModifiedSystemDate(getTimestamp (rs, 6)); 
      returnObject.setXSourceTypeFlag(getString (rs, 7)); 
      returnObject.setXGenerated_by(getString (rs, 8)); 
      returnObject.setXCorporateCategory(getLongObject (rs, 9)); 
      returnObject.setXCorporateGroup(getLongObject (rs, 10)); 
      returnObject.setXPersonalAgreement(getString (rs, 11)); 
      returnObject.setXDoNotMergeFlag(getString (rs, 12)); 
      returnObject.setDeleteFlag(getString (rs, 13)); 
      returnObject.setInfoRemoveFlag(getString (rs, 14)); 
      returnObject.setDedupHiddenFlag(getString (rs, 15)); 
      returnObject.setPrefCommunicationChannel(getString (rs, 16)); 
      returnObject.setYanaseFlag(getString (rs, 17)); 
      returnObject.setFinancePartyType(getString (rs, 18)); 
      returnObject.setContractNumber(getString (rs, 19)); 
      returnObject.setXPrivacyAct(getString (rs, 20)); 
      returnObject.setXFleet(getString (rs, 21)); 
      returnObject.setXPC_Ind(getString (rs, 22)); 
      returnObject.setXVANS_Ind(getString (rs, 23)); 
      returnObject.setLastActivityDate(getTimestamp (rs, 24)); 
      returnObject.setX_CUST_TYPE(getString (rs, 25)); 
      returnObject.setLastUpdateDt(getTimestamp (rs, 26)); 
      returnObject.setLastUpdateUser(getString (rs, 27)); 
      returnObject.setLastUpdateTxId(getLongObject (rs, 28)); 
    
      return returnObject;
    }
  }

  /**
   * @Update( sql="insert into ORG (ESTABLISHED_DT, CONT_ID, PROFIT_IND, BUY_SELL_AGR_TP_CD, INDUSTRY_TP_CD, ORG_TP_CD, XDEFUNCT_IND, XWEBSITE, XMARKET_NAME, XBATCH_IND, XNUMOFEMP_TP_CD, XMODIFY_SYS_DT, XSOURCE_TYPE_FLAG, XGENERATED_BY, XCORP_CAT_TP_CD, XCORP_GROUP_TP_CD, XPERSONAL_AGREEMENT, XDo_Not_Merge_Flag, DELETE_FLAG, INFO_REMOVE_FLAG, DEDUP_HIDDEN_FLAG, PREF_COMMUNICATION_CHANNEL, YANASE_FLAG, FINANCE_PARTY_TYPE, CONTRACT_NUMBER, XPrivacy_Act, XFleet, XPC_Ind, XVANS_Ind, Last_Activity_Date, X_CUST_TYPE, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( ?1.establishedDt, ?1.contIdPK, ?1.profitInd, ?1.buySellAgrTpCd, ?1.industryTpCd, ?1.orgTpCd, ?2.xDefunctInd, ?2.xWebsite, ?2.xMarketName, ?2.xBatchInd, ?2.xNumberOfEmployees, ?2.xLastModifiedSystemDate, ?2.xSourceTypeFlag, ?2.xGenerated_by, ?2.xCorporateCategory, ?2.xCorporateGroup, ?2.xPersonalAgreement, ?2.xDoNotMergeFlag, ?2.deleteFlag, ?2.infoRemoveFlag, ?2.dedupHiddenFlag, ?2.prefCommunicationChannel, ?2.yanaseFlag, ?2.financePartyType, ?2.contractNumber, ?2.xPrivacyAct, ?2.xFleet, ?2.xPC_Ind, ?2.xVANS_Ind, ?2.lastActivityDate, ?2.x_CUST_TYPE, ?1.lastUpdateDt, ?1.lastUpdateUser, ?1.lastUpdateTxId)" )
   * 
   * @generated
   */
  public int createEObjXOrgExt (EObjOrg e1, EObjXOrgExt e2)
  {
    return update (createEObjXOrgExtStatementDescriptor, e1, e2);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor createEObjXOrgExtStatementDescriptor = createStatementDescriptor (
    "createEObjXOrgExt(com.dwl.tcrm.coreParty.entityObject.EObjOrg, com.ibm.daimler.dsea.entityObject.EObjXOrgExt)",
    "insert into ORG (ESTABLISHED_DT, CONT_ID, PROFIT_IND, BUY_SELL_AGR_TP_CD, INDUSTRY_TP_CD, ORG_TP_CD, XDEFUNCT_IND, XWEBSITE, XMARKET_NAME, XBATCH_IND, XNUMOFEMP_TP_CD, XMODIFY_SYS_DT, XSOURCE_TYPE_FLAG, XGENERATED_BY, XCORP_CAT_TP_CD, XCORP_GROUP_TP_CD, XPERSONAL_AGREEMENT, XDo_Not_Merge_Flag, DELETE_FLAG, INFO_REMOVE_FLAG, DEDUP_HIDDEN_FLAG, PREF_COMMUNICATION_CHANNEL, YANASE_FLAG, FINANCE_PARTY_TYPE, CONTRACT_NUMBER, XPrivacy_Act, XFleet, XPC_Ind, XVANS_Ind, Last_Activity_Date, X_CUST_TYPE, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values(  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? )",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.INSERT,
    null,
    new CreateEObjXOrgExtParameterHandler (),
    new int[][]{{Types.TIMESTAMP, Types.BIGINT, Types.CHAR, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {0, 19, 1, 19, 19, 19, 5, 255, 50, 5, 19, 0, 50, 50, 19, 19, 20, 5, 10, 10, 10, 255, 10, 10, 250, 250, 5, 10, 10, 0, 10, 0, 0, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    2);

  /**
   * @generated
   */
  public static class CreateEObjXOrgExtParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      EObjOrg bean0 = (EObjOrg) parameters[0];
      setTimestamp (stmt, 1, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getEstablishedDt());
      setLong (stmt, 2, Types.BIGINT, (Long)bean0.getContIdPK());
      setString (stmt, 3, Types.CHAR, (String)bean0.getProfitInd());
      setLong (stmt, 4, Types.BIGINT, (Long)bean0.getBuySellAgrTpCd());
      setLong (stmt, 5, Types.BIGINT, (Long)bean0.getIndustryTpCd());
      setLong (stmt, 6, Types.BIGINT, (Long)bean0.getOrgTpCd());
      EObjXOrgExt bean1 = (EObjXOrgExt) parameters[1];
      setString (stmt, 7, Types.VARCHAR, (String)bean1.getXDefunctInd());
      setString (stmt, 8, Types.VARCHAR, (String)bean1.getXWebsite());
      setString (stmt, 9, Types.VARCHAR, (String)bean1.getXMarketName());
      setString (stmt, 10, Types.VARCHAR, (String)bean1.getXBatchInd());
      setLong (stmt, 11, Types.BIGINT, (Long)bean1.getXNumberOfEmployees());
      setTimestamp (stmt, 12, Types.TIMESTAMP, (java.sql.Timestamp)bean1.getXLastModifiedSystemDate());
      setString (stmt, 13, Types.VARCHAR, (String)bean1.getXSourceTypeFlag());
      setString (stmt, 14, Types.VARCHAR, (String)bean1.getXGenerated_by());
      setLong (stmt, 15, Types.BIGINT, (Long)bean1.getXCorporateCategory());
      setLong (stmt, 16, Types.BIGINT, (Long)bean1.getXCorporateGroup());
      setString (stmt, 17, Types.VARCHAR, (String)bean1.getXPersonalAgreement());
      setString (stmt, 18, Types.VARCHAR, (String)bean1.getXDoNotMergeFlag());
      setString (stmt, 19, Types.VARCHAR, (String)bean1.getDeleteFlag());
      setString (stmt, 20, Types.VARCHAR, (String)bean1.getInfoRemoveFlag());
      setString (stmt, 21, Types.VARCHAR, (String)bean1.getDedupHiddenFlag());
      setString (stmt, 22, Types.VARCHAR, (String)bean1.getPrefCommunicationChannel());
      setString (stmt, 23, Types.VARCHAR, (String)bean1.getYanaseFlag());
      setString (stmt, 24, Types.VARCHAR, (String)bean1.getFinancePartyType());
      setString (stmt, 25, Types.VARCHAR, (String)bean1.getContractNumber());
      setString (stmt, 26, Types.VARCHAR, (String)bean1.getXPrivacyAct());
      setString (stmt, 27, Types.VARCHAR, (String)bean1.getXFleet());
      setString (stmt, 28, Types.VARCHAR, (String)bean1.getXPC_Ind());
      setString (stmt, 29, Types.VARCHAR, (String)bean1.getXVANS_Ind());
      setTimestamp (stmt, 30, Types.TIMESTAMP, (java.sql.Timestamp)bean1.getLastActivityDate());
      setString (stmt, 31, Types.VARCHAR, (String)bean1.getX_CUST_TYPE());
      setTimestamp (stmt, 32, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUpdateDt());
      setString (stmt, 33, Types.VARCHAR, (String)bean0.getLastUpdateUser());
      setLong (stmt, 34, Types.BIGINT, (Long)bean0.getLastUpdateTxId());
    }
  }

  /**
   * @Update( sql="update ORG set ESTABLISHED_DT = ?1.establishedDt, PROFIT_IND = ?1.profitInd, BUY_SELL_AGR_TP_CD = ?1.buySellAgrTpCd, INDUSTRY_TP_CD = ?1.industryTpCd, ORG_TP_CD = ?1.orgTpCd, XDEFUNCT_IND = ?2.xDefunctInd, XWEBSITE = ?2.xWebsite, XMARKET_NAME = ?2.xMarketName, XBATCH_IND = ?2.xBatchInd, XNUMOFEMP_TP_CD = ?2.xNumberOfEmployees, XMODIFY_SYS_DT = ?2.xLastModifiedSystemDate, XSOURCE_TYPE_FLAG = ?2.xSourceTypeFlag, XGENERATED_BY = ?2.xGenerated_by, XCORP_CAT_TP_CD = ?2.xCorporateCategory, XCORP_GROUP_TP_CD = ?2.xCorporateGroup, XPERSONAL_AGREEMENT = ?2.xPersonalAgreement, XDo_Not_Merge_Flag = ?2.xDoNotMergeFlag, DELETE_FLAG = ?2.deleteFlag, INFO_REMOVE_FLAG = ?2.infoRemoveFlag, DEDUP_HIDDEN_FLAG = ?2.dedupHiddenFlag, PREF_COMMUNICATION_CHANNEL = ?2.prefCommunicationChannel, YANASE_FLAG = ?2.yanaseFlag, FINANCE_PARTY_TYPE = ?2.financePartyType, CONTRACT_NUMBER = ?2.contractNumber, XPrivacy_Act = ?2.xPrivacyAct, XFleet = ?2.xFleet, XPC_Ind = ?2.xPC_Ind, XVANS_Ind = ?2.xVANS_Ind, Last_Activity_Date = ?2.lastActivityDate, X_CUST_TYPE = ?2.x_CUST_TYPE, LAST_UPDATE_DT = ?1.lastUpdateDt, LAST_UPDATE_USER = ?1.lastUpdateUser, LAST_UPDATE_TX_ID = ?1.lastUpdateTxId where CONT_ID = ?1.contIdPK and LAST_UPDATE_DT = ?1.oldLastUpdateDt" )
   * 
   * @generated
   */
  public int updateEObjXOrgExt (EObjOrg e1, EObjXOrgExt e2)
  {
    return update (updateEObjXOrgExtStatementDescriptor, e1, e2);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor updateEObjXOrgExtStatementDescriptor = createStatementDescriptor (
    "updateEObjXOrgExt(com.dwl.tcrm.coreParty.entityObject.EObjOrg, com.ibm.daimler.dsea.entityObject.EObjXOrgExt)",
    "update ORG set ESTABLISHED_DT =  ? , PROFIT_IND =  ? , BUY_SELL_AGR_TP_CD =  ? , INDUSTRY_TP_CD =  ? , ORG_TP_CD =  ? , XDEFUNCT_IND =  ? , XWEBSITE =  ? , XMARKET_NAME =  ? , XBATCH_IND =  ? , XNUMOFEMP_TP_CD =  ? , XMODIFY_SYS_DT =  ? , XSOURCE_TYPE_FLAG =  ? , XGENERATED_BY =  ? , XCORP_CAT_TP_CD =  ? , XCORP_GROUP_TP_CD =  ? , XPERSONAL_AGREEMENT =  ? , XDo_Not_Merge_Flag =  ? , DELETE_FLAG =  ? , INFO_REMOVE_FLAG =  ? , DEDUP_HIDDEN_FLAG =  ? , PREF_COMMUNICATION_CHANNEL =  ? , YANASE_FLAG =  ? , FINANCE_PARTY_TYPE =  ? , CONTRACT_NUMBER =  ? , XPrivacy_Act =  ? , XFleet =  ? , XPC_Ind =  ? , XVANS_Ind =  ? , Last_Activity_Date =  ? , X_CUST_TYPE =  ? , LAST_UPDATE_DT =  ? , LAST_UPDATE_USER =  ? , LAST_UPDATE_TX_ID =  ?  where CONT_ID =  ?  and LAST_UPDATE_DT =  ? ",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.UPDATE,
    null,
    new UpdateEObjXOrgExtParameterHandler (),
    new int[][]{{Types.TIMESTAMP, Types.CHAR, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP}, {0, 1, 19, 19, 19, 5, 255, 50, 5, 19, 0, 50, 50, 19, 19, 20, 5, 10, 10, 10, 255, 10, 10, 250, 250, 5, 10, 10, 0, 10, 0, 0, 19, 19, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    3);

  /**
   * @generated
   */
  public static class UpdateEObjXOrgExtParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      EObjOrg bean0 = (EObjOrg) parameters[0];
      setTimestamp (stmt, 1, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getEstablishedDt());
      setString (stmt, 2, Types.CHAR, (String)bean0.getProfitInd());
      setLong (stmt, 3, Types.BIGINT, (Long)bean0.getBuySellAgrTpCd());
      setLong (stmt, 4, Types.BIGINT, (Long)bean0.getIndustryTpCd());
      setLong (stmt, 5, Types.BIGINT, (Long)bean0.getOrgTpCd());
      EObjXOrgExt bean1 = (EObjXOrgExt) parameters[1];
      setString (stmt, 6, Types.VARCHAR, (String)bean1.getXDefunctInd());
      setString (stmt, 7, Types.VARCHAR, (String)bean1.getXWebsite());
      setString (stmt, 8, Types.VARCHAR, (String)bean1.getXMarketName());
      setString (stmt, 9, Types.VARCHAR, (String)bean1.getXBatchInd());
      setLong (stmt, 10, Types.BIGINT, (Long)bean1.getXNumberOfEmployees());
      setTimestamp (stmt, 11, Types.TIMESTAMP, (java.sql.Timestamp)bean1.getXLastModifiedSystemDate());
      setString (stmt, 12, Types.VARCHAR, (String)bean1.getXSourceTypeFlag());
      setString (stmt, 13, Types.VARCHAR, (String)bean1.getXGenerated_by());
      setLong (stmt, 14, Types.BIGINT, (Long)bean1.getXCorporateCategory());
      setLong (stmt, 15, Types.BIGINT, (Long)bean1.getXCorporateGroup());
      setString (stmt, 16, Types.VARCHAR, (String)bean1.getXPersonalAgreement());
      setString (stmt, 17, Types.VARCHAR, (String)bean1.getXDoNotMergeFlag());
      setString (stmt, 18, Types.VARCHAR, (String)bean1.getDeleteFlag());
      setString (stmt, 19, Types.VARCHAR, (String)bean1.getInfoRemoveFlag());
      setString (stmt, 20, Types.VARCHAR, (String)bean1.getDedupHiddenFlag());
      setString (stmt, 21, Types.VARCHAR, (String)bean1.getPrefCommunicationChannel());
      setString (stmt, 22, Types.VARCHAR, (String)bean1.getYanaseFlag());
      setString (stmt, 23, Types.VARCHAR, (String)bean1.getFinancePartyType());
      setString (stmt, 24, Types.VARCHAR, (String)bean1.getContractNumber());
      setString (stmt, 25, Types.VARCHAR, (String)bean1.getXPrivacyAct());
      setString (stmt, 26, Types.VARCHAR, (String)bean1.getXFleet());
      setString (stmt, 27, Types.VARCHAR, (String)bean1.getXPC_Ind());
      setString (stmt, 28, Types.VARCHAR, (String)bean1.getXVANS_Ind());
      setTimestamp (stmt, 29, Types.TIMESTAMP, (java.sql.Timestamp)bean1.getLastActivityDate());
      setString (stmt, 30, Types.VARCHAR, (String)bean1.getX_CUST_TYPE());
      setTimestamp (stmt, 31, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUpdateDt());
      setString (stmt, 32, Types.VARCHAR, (String)bean0.getLastUpdateUser());
      setLong (stmt, 33, Types.BIGINT, (Long)bean0.getLastUpdateTxId());
      setLong (stmt, 34, Types.BIGINT, (Long)bean0.getContIdPK());
      setTimestamp (stmt, 35, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getOldLastUpdateDt());
    }
  }

  /**
   * @Update( sql="delete from ORG where CONT_ID = ?" )
   * 
   * @generated
   */
  public int deleteEObjXOrgExt (Long contIdPK)
  {
    return update (deleteEObjXOrgExtStatementDescriptor, contIdPK);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor deleteEObjXOrgExtStatementDescriptor = createStatementDescriptor (
    "deleteEObjXOrgExt(Long)",
    "delete from ORG where CONT_ID = ?",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.DELETE,
    null,
    new DeleteEObjXOrgExtParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    4);

  /**
   * @generated
   */
  public static class DeleteEObjXOrgExtParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setLong (stmt, 1, Types.BIGINT, (Long)parameters[0]);
    }
  }

}
