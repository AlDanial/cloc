/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[4533313f8e164c5058e9dc788cd27f60]
 */


package com.ibm.daimler.dsea.entityObject;

import java.util.Iterator;
import com.ibm.mdm.base.db.EntityMapping;
import com.ibm.pdq.annotation.Select;
import com.ibm.pdq.annotation.Update;

import com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleJPN;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * @generated
 */
public interface EObjXCustomerVehicleJPNData {


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjXCustomerVehicleJPNSql = "select XCustomer_Vehicle_JPNPK_ID, CONT_ID, VEHICLE_ID, RETAILER_ID, CONNECTME_USAGE_TP_CD, LICENSE_PLATE, VEHICLE_SALES_TP_CD, VEHICLE_USAGE_TP_CD, VEHICLE_OWNERSHIP, START_DT, END_DT, SOURCE_IDENT_TP_CD, CUSTVEHRET_FLAG, DELETE_FLAG, SFDC_ID, SERVICE_NAME, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from XCUSTOMERVEHICLEJPN where XCustomer_Vehicle_JPNPK_ID = ? ";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String createEObjXCustomerVehicleJPNSql = "insert into XCUSTOMERVEHICLEJPN (XCustomer_Vehicle_JPNPK_ID, CONT_ID, VEHICLE_ID, RETAILER_ID, CONNECTME_USAGE_TP_CD, LICENSE_PLATE, VEHICLE_SALES_TP_CD, VEHICLE_USAGE_TP_CD, VEHICLE_OWNERSHIP, START_DT, END_DT, SOURCE_IDENT_TP_CD, CUSTVEHRET_FLAG, DELETE_FLAG, SFDC_ID, SERVICE_NAME, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( :xCustomerVehicleJPNpkId, :contId, :vehicleId, :retailerId, :connectMeUsage, :licensePlate, :vehicleSales, :vehicleUsage, :vehicleOwnerShip, :startDate, :endDate, :sourceIdentifier, :custVehRetFlag, :deleteFlag, :sFDCId, :serviceName, :lastUpdateDt, :lastUpdateUser, :lastUpdateTxId)";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String updateEObjXCustomerVehicleJPNSql = "update XCUSTOMERVEHICLEJPN set CONT_ID = :contId, VEHICLE_ID = :vehicleId, RETAILER_ID = :retailerId, CONNECTME_USAGE_TP_CD = :connectMeUsage, LICENSE_PLATE = :licensePlate, VEHICLE_SALES_TP_CD = :vehicleSales, VEHICLE_USAGE_TP_CD = :vehicleUsage, VEHICLE_OWNERSHIP = :vehicleOwnerShip, START_DT = :startDate, END_DT = :endDate, SOURCE_IDENT_TP_CD = :sourceIdentifier, CUSTVEHRET_FLAG = :custVehRetFlag, DELETE_FLAG = :deleteFlag, SFDC_ID = :sFDCId, SERVICE_NAME = :serviceName, LAST_UPDATE_DT = :lastUpdateDt, LAST_UPDATE_USER = :lastUpdateUser, LAST_UPDATE_TX_ID = :lastUpdateTxId where XCustomer_Vehicle_JPNPK_ID = :xCustomerVehicleJPNpkId and LAST_UPDATE_DT = :oldLastUpdateDt";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String deleteEObjXCustomerVehicleJPNSql = "delete from XCUSTOMERVEHICLEJPN where XCustomer_Vehicle_JPNPK_ID = ?";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXCustomerVehicleJPNKeyField = "EObjXCustomerVehicleJPN.xCustomerVehicleJPNpkId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXCustomerVehicleJPNGetFields =
    "EObjXCustomerVehicleJPN.xCustomerVehicleJPNpkId," +
    "EObjXCustomerVehicleJPN.contId," +
    "EObjXCustomerVehicleJPN.vehicleId," +
    "EObjXCustomerVehicleJPN.retailerId," +
    "EObjXCustomerVehicleJPN.connectMeUsage," +
    "EObjXCustomerVehicleJPN.licensePlate," +
    "EObjXCustomerVehicleJPN.vehicleSales," +
    "EObjXCustomerVehicleJPN.vehicleUsage," +
    "EObjXCustomerVehicleJPN.vehicleOwnerShip," +
    "EObjXCustomerVehicleJPN.startDate," +
    "EObjXCustomerVehicleJPN.endDate," +
    "EObjXCustomerVehicleJPN.sourceIdentifier," +
    "EObjXCustomerVehicleJPN.custVehRetFlag," +
    "EObjXCustomerVehicleJPN.deleteFlag," +
    "EObjXCustomerVehicleJPN.sFDCId," +
    "EObjXCustomerVehicleJPN.serviceName," +
    "EObjXCustomerVehicleJPN.lastUpdateDt," +
    "EObjXCustomerVehicleJPN.lastUpdateUser," +
    "EObjXCustomerVehicleJPN.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXCustomerVehicleJPNAllFields =
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleJPN.xCustomerVehicleJPNpkId," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleJPN.contId," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleJPN.vehicleId," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleJPN.retailerId," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleJPN.connectMeUsage," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleJPN.licensePlate," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleJPN.vehicleSales," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleJPN.vehicleUsage," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleJPN.vehicleOwnerShip," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleJPN.startDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleJPN.endDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleJPN.sourceIdentifier," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleJPN.custVehRetFlag," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleJPN.deleteFlag," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleJPN.sFDCId," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleJPN.serviceName," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleJPN.lastUpdateDt," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleJPN.lastUpdateUser," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleJPN.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXCustomerVehicleJPNUpdateFields =
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleJPN.contId," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleJPN.vehicleId," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleJPN.retailerId," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleJPN.connectMeUsage," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleJPN.licensePlate," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleJPN.vehicleSales," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleJPN.vehicleUsage," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleJPN.vehicleOwnerShip," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleJPN.startDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleJPN.endDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleJPN.sourceIdentifier," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleJPN.custVehRetFlag," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleJPN.deleteFlag," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleJPN.sFDCId," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleJPN.serviceName," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleJPN.lastUpdateDt," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleJPN.lastUpdateUser," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleJPN.lastUpdateTxId," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleJPN.xCustomerVehicleJPNpkId," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleJPN.oldLastUpdateDt";   

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Select XCustomerVehicleJPN by parameters.
   * @generated
   */
  @Select(sql=getEObjXCustomerVehicleJPNSql)
  @EntityMapping(parameters=EObjXCustomerVehicleJPNKeyField, results=EObjXCustomerVehicleJPNGetFields)
  Iterator<EObjXCustomerVehicleJPN> getEObjXCustomerVehicleJPN(Long xCustomerVehicleJPNpkId);  
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Create XCustomerVehicleJPN by EObjXCustomerVehicleJPN Object.
   * @generated
   */
  @Update(sql=createEObjXCustomerVehicleJPNSql)
  @EntityMapping(parameters=EObjXCustomerVehicleJPNAllFields)
    int createEObjXCustomerVehicleJPN(EObjXCustomerVehicleJPN e); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Update one XCustomerVehicleJPN by EObjXCustomerVehicleJPN object.
   * @generated
   */
  @Update(sql=updateEObjXCustomerVehicleJPNSql)
  @EntityMapping(parameters=EObjXCustomerVehicleJPNUpdateFields)
    int updateEObjXCustomerVehicleJPN(EObjXCustomerVehicleJPN e); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Delete XCustomerVehicleJPN by parameters.
   * @generated
   */
  @Update(sql=deleteEObjXCustomerVehicleJPNSql)
  @EntityMapping(parameters=EObjXCustomerVehicleJPNKeyField)
  int deleteEObjXCustomerVehicleJPN(Long xCustomerVehicleJPNpkId);

}

