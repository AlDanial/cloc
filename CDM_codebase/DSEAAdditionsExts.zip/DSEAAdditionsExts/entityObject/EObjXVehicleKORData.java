/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[7caa5b870736b704b00cbc6ff9a309c3]
 */


package com.ibm.daimler.dsea.entityObject;

import java.util.Iterator;
import com.ibm.mdm.base.db.EntityMapping;
import com.ibm.pdq.annotation.Select;
import com.ibm.pdq.annotation.Update;

import com.ibm.daimler.dsea.entityObject.EObjXVehicleKOR;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * @generated
 */
public interface EObjXVehicleKORData {


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjXVehicleKORSql = "select XVehicle_KORpk_Id, Global_VIN, BAU_MUSTER, TYPE_CLASS, SUB_MUSTER, COLOR, TRIM, BATCH_IND, MARKET_NAME, MODIFY_SYS_DT, CREATE_DT, CHANGED_DT, LAST_SERVICE_DT, SFDC_ID, VEHICLE_ADDRESS_TYPE, VEHICLE_TYPE, DELETE_FLAG, END_DT, ENGINE_NUM, SOURCE_IDENT_TP_CD, Local_VIN, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from XVEHICLEKOR where XVehicle_KORpk_Id = ? ";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String createEObjXVehicleKORSql = "insert into XVEHICLEKOR (XVehicle_KORpk_Id, Global_VIN, BAU_MUSTER, TYPE_CLASS, SUB_MUSTER, COLOR, TRIM, BATCH_IND, MARKET_NAME, MODIFY_SYS_DT, CREATE_DT, CHANGED_DT, LAST_SERVICE_DT, SFDC_ID, VEHICLE_ADDRESS_TYPE, VEHICLE_TYPE, DELETE_FLAG, END_DT, ENGINE_NUM, SOURCE_IDENT_TP_CD, Local_VIN, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( :xVehicleKORpkId, :globalVIN, :bauMuster, :typeClass, :subMuster, :color, :trim, :batchInd, :marketName, :lastModifiedSystemDate, :createDate, :changedDate, :lastServiceDate, :sFDCId, :vehicleAddressType, :vehicleType, :deleteFlag, :endDate, :engineNumber, :sourceIdentifier, :localVIN, :lastUpdateDt, :lastUpdateUser, :lastUpdateTxId)";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String updateEObjXVehicleKORSql = "update XVEHICLEKOR set Global_VIN = :globalVIN, BAU_MUSTER = :bauMuster, TYPE_CLASS = :typeClass, SUB_MUSTER = :subMuster, COLOR = :color, TRIM = :trim, BATCH_IND = :batchInd, MARKET_NAME = :marketName, MODIFY_SYS_DT = :lastModifiedSystemDate, CREATE_DT = :createDate, CHANGED_DT = :changedDate, LAST_SERVICE_DT = :lastServiceDate, SFDC_ID = :sFDCId, VEHICLE_ADDRESS_TYPE = :vehicleAddressType, VEHICLE_TYPE = :vehicleType, DELETE_FLAG = :deleteFlag, END_DT = :endDate, ENGINE_NUM = :engineNumber, SOURCE_IDENT_TP_CD = :sourceIdentifier, Local_VIN = :localVIN, LAST_UPDATE_DT = :lastUpdateDt, LAST_UPDATE_USER = :lastUpdateUser, LAST_UPDATE_TX_ID = :lastUpdateTxId where XVehicle_KORpk_Id = :xVehicleKORpkId and LAST_UPDATE_DT = :oldLastUpdateDt";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String deleteEObjXVehicleKORSql = "delete from XVEHICLEKOR where XVehicle_KORpk_Id = ?";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXVehicleKORKeyField = "EObjXVehicleKOR.xVehicleKORpkId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXVehicleKORGetFields =
    "EObjXVehicleKOR.xVehicleKORpkId," +
    "EObjXVehicleKOR.globalVIN," +
    "EObjXVehicleKOR.bauMuster," +
    "EObjXVehicleKOR.typeClass," +
    "EObjXVehicleKOR.subMuster," +
    "EObjXVehicleKOR.color," +
    "EObjXVehicleKOR.trim," +
    "EObjXVehicleKOR.batchInd," +
    "EObjXVehicleKOR.marketName," +
    "EObjXVehicleKOR.lastModifiedSystemDate," +
    "EObjXVehicleKOR.createDate," +
    "EObjXVehicleKOR.changedDate," +
    "EObjXVehicleKOR.lastServiceDate," +
    "EObjXVehicleKOR.sFDCId," +
    "EObjXVehicleKOR.vehicleAddressType," +
    "EObjXVehicleKOR.vehicleType," +
    "EObjXVehicleKOR.deleteFlag," +
    "EObjXVehicleKOR.endDate," +
    "EObjXVehicleKOR.engineNumber," +
    "EObjXVehicleKOR.sourceIdentifier," +
    "EObjXVehicleKOR.localVIN," +
    "EObjXVehicleKOR.lastUpdateDt," +
    "EObjXVehicleKOR.lastUpdateUser," +
    "EObjXVehicleKOR.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXVehicleKORAllFields =
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleKOR.xVehicleKORpkId," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleKOR.globalVIN," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleKOR.bauMuster," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleKOR.typeClass," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleKOR.subMuster," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleKOR.color," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleKOR.trim," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleKOR.batchInd," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleKOR.marketName," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleKOR.lastModifiedSystemDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleKOR.createDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleKOR.changedDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleKOR.lastServiceDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleKOR.sFDCId," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleKOR.vehicleAddressType," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleKOR.vehicleType," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleKOR.deleteFlag," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleKOR.endDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleKOR.engineNumber," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleKOR.sourceIdentifier," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleKOR.localVIN," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleKOR.lastUpdateDt," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleKOR.lastUpdateUser," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleKOR.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXVehicleKORUpdateFields =
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleKOR.globalVIN," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleKOR.bauMuster," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleKOR.typeClass," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleKOR.subMuster," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleKOR.color," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleKOR.trim," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleKOR.batchInd," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleKOR.marketName," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleKOR.lastModifiedSystemDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleKOR.createDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleKOR.changedDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleKOR.lastServiceDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleKOR.sFDCId," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleKOR.vehicleAddressType," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleKOR.vehicleType," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleKOR.deleteFlag," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleKOR.endDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleKOR.engineNumber," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleKOR.sourceIdentifier," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleKOR.localVIN," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleKOR.lastUpdateDt," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleKOR.lastUpdateUser," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleKOR.lastUpdateTxId," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleKOR.xVehicleKORpkId," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleKOR.oldLastUpdateDt";   

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Select XVehicleKOR by parameters.
   * @generated
   */
  @Select(sql=getEObjXVehicleKORSql)
  @EntityMapping(parameters=EObjXVehicleKORKeyField, results=EObjXVehicleKORGetFields)
  Iterator<EObjXVehicleKOR> getEObjXVehicleKOR(Long xVehicleKORpkId);  
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Create XVehicleKOR by EObjXVehicleKOR Object.
   * @generated
   */
  @Update(sql=createEObjXVehicleKORSql)
  @EntityMapping(parameters=EObjXVehicleKORAllFields)
    int createEObjXVehicleKOR(EObjXVehicleKOR e); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Update one XVehicleKOR by EObjXVehicleKOR object.
   * @generated
   */
  @Update(sql=updateEObjXVehicleKORSql)
  @EntityMapping(parameters=EObjXVehicleKORUpdateFields)
    int updateEObjXVehicleKOR(EObjXVehicleKOR e); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Delete XVehicleKOR by parameters.
   * @generated
   */
  @Update(sql=deleteEObjXVehicleKORSql)
  @EntityMapping(parameters=EObjXVehicleKORKeyField)
  int deleteEObjXVehicleKOR(Long xVehicleKORpkId);

}

