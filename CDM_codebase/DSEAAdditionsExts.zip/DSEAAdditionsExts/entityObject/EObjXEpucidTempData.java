/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[1d62decdb7c395fe585fc1223499703b]
 */


package com.ibm.daimler.dsea.entityObject;

import java.util.Iterator;
import com.ibm.mdm.base.db.EntityMapping;
import com.ibm.pdq.annotation.Select;
import com.ibm.pdq.annotation.Update;

import com.ibm.daimler.dsea.entityObject.EObjXEpucidTemp;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * @generated
 */
public interface EObjXEpucidTempData {


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjXEpucidTempSql = "select XEpucid_Temppk_Id, EPUCID, UCID, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from XEPUCIDTEMP where XEpucid_Temppk_Id = ? ";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String createEObjXEpucidTempSql = "insert into XEPUCIDTEMP (XEpucid_Temppk_Id, EPUCID, UCID, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( :xEpucidTemppkId, :ePUCID, :uCID, :lastUpdateDt, :lastUpdateUser, :lastUpdateTxId)";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String updateEObjXEpucidTempSql = "update XEPUCIDTEMP set EPUCID = :ePUCID, UCID = :uCID, LAST_UPDATE_DT = :lastUpdateDt, LAST_UPDATE_USER = :lastUpdateUser, LAST_UPDATE_TX_ID = :lastUpdateTxId where XEpucid_Temppk_Id = :xEpucidTemppkId and LAST_UPDATE_DT = :oldLastUpdateDt";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String deleteEObjXEpucidTempSql = "delete from XEPUCIDTEMP where XEpucid_Temppk_Id = ?";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXEpucidTempKeyField = "EObjXEpucidTemp.xEpucidTemppkId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXEpucidTempGetFields =
    "EObjXEpucidTemp.xEpucidTemppkId," +
    "EObjXEpucidTemp.ePUCID," +
    "EObjXEpucidTemp.uCID," +
    "EObjXEpucidTemp.lastUpdateDt," +
    "EObjXEpucidTemp.lastUpdateUser," +
    "EObjXEpucidTemp.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXEpucidTempAllFields =
    "com.ibm.daimler.dsea.entityObject.EObjXEpucidTemp.xEpucidTemppkId," +
    "com.ibm.daimler.dsea.entityObject.EObjXEpucidTemp.ePUCID," +
    "com.ibm.daimler.dsea.entityObject.EObjXEpucidTemp.uCID," +
    "com.ibm.daimler.dsea.entityObject.EObjXEpucidTemp.lastUpdateDt," +
    "com.ibm.daimler.dsea.entityObject.EObjXEpucidTemp.lastUpdateUser," +
    "com.ibm.daimler.dsea.entityObject.EObjXEpucidTemp.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXEpucidTempUpdateFields =
    "com.ibm.daimler.dsea.entityObject.EObjXEpucidTemp.ePUCID," +
    "com.ibm.daimler.dsea.entityObject.EObjXEpucidTemp.uCID," +
    "com.ibm.daimler.dsea.entityObject.EObjXEpucidTemp.lastUpdateDt," +
    "com.ibm.daimler.dsea.entityObject.EObjXEpucidTemp.lastUpdateUser," +
    "com.ibm.daimler.dsea.entityObject.EObjXEpucidTemp.lastUpdateTxId," +
    "com.ibm.daimler.dsea.entityObject.EObjXEpucidTemp.xEpucidTemppkId," +
    "com.ibm.daimler.dsea.entityObject.EObjXEpucidTemp.oldLastUpdateDt";   

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Select XEpucidTemp by parameters.
   * @generated
   */
  @Select(sql=getEObjXEpucidTempSql)
  @EntityMapping(parameters=EObjXEpucidTempKeyField, results=EObjXEpucidTempGetFields)
  Iterator<EObjXEpucidTemp> getEObjXEpucidTemp(Long xEpucidTemppkId);  
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Create XEpucidTemp by EObjXEpucidTemp Object.
   * @generated
   */
  @Update(sql=createEObjXEpucidTempSql)
  @EntityMapping(parameters=EObjXEpucidTempAllFields)
    int createEObjXEpucidTemp(EObjXEpucidTemp e); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Update one XEpucidTemp by EObjXEpucidTemp object.
   * @generated
   */
  @Update(sql=updateEObjXEpucidTempSql)
  @EntityMapping(parameters=EObjXEpucidTempUpdateFields)
    int updateEObjXEpucidTemp(EObjXEpucidTemp e); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Delete XEpucidTemp by parameters.
   * @generated
   */
  @Update(sql=deleteEObjXEpucidTempSql)
  @EntityMapping(parameters=EObjXEpucidTempKeyField)
  int deleteEObjXEpucidTemp(Long xEpucidTemppkId);

}

