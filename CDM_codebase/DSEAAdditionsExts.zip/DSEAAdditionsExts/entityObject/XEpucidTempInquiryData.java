/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[f724ca5f5cb513c8071f6330e0a983e7]
 */

package com.ibm.daimler.dsea.entityObject;


import com.ibm.mdm.base.db.ResultQueue1;
import java.util.Iterator;
import com.ibm.mdm.base.db.EntityMapping;
import com.ibm.pdq.annotation.Select;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * @generated
 */
public interface XEpucidTempInquiryData {
  
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String tableAliasString = "tableAlias (" + 
                                            "XEPUCIDTEMP => com.ibm.daimler.dsea.entityObject.EObjXEpucidTemp, " +
                                            "H_XEPUCIDTEMP => com.ibm.daimler.dsea.entityObject.EObjXEpucidTemp" +
                                            ")";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getXEpucidTempSql = "SELECT r.XEpucid_Temppk_Id XEpucid_Temppk_Id, r.EPUCID EPUCID, r.UCID UCID, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XEPUCIDTEMP r WHERE r.XEpucid_Temppk_Id = ? ";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXEpucidTempParameters =
    "EObjXEpucidTemp.XEpucidTemppkId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXEpucidTempResults =
    "EObjXEpucidTemp.XEpucidTemppkId," +
    "EObjXEpucidTemp.EPUCID," +
    "EObjXEpucidTemp.UCID," +
    "EObjXEpucidTemp.lastUpdateDt," +
    "EObjXEpucidTemp.lastUpdateUser," +
    "EObjXEpucidTemp.lastUpdateTxId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getXEpucidTempHistorySql = "SELECT r.H_XEpucid_Temppk_Id hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.XEpucid_Temppk_Id XEpucid_Temppk_Id, r.EPUCID EPUCID, r.UCID UCID, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XEPUCIDTEMP r WHERE r.H_XEpucid_Temppk_Id = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXEpucidTempHistoryParameters =
    "EObjXEpucidTemp.XEpucidTemppkId," +
    "EObjXEpucidTemp.lastUpdateDt," +
    "EObjXEpucidTemp.lastUpdateDt";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXEpucidTempHistoryResults =
    "EObjXEpucidTemp.historyIdPK," +
    "EObjXEpucidTemp.histActionCode," +
    "EObjXEpucidTemp.histCreatedBy," +
    "EObjXEpucidTemp.histCreateDt," +
    "EObjXEpucidTemp.histEndDt," +
    "EObjXEpucidTemp.XEpucidTemppkId," +
    "EObjXEpucidTemp.EPUCID," +
    "EObjXEpucidTemp.UCID," +
    "EObjXEpucidTemp.lastUpdateDt," +
    "EObjXEpucidTemp.lastUpdateUser," +
    "EObjXEpucidTemp.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getXEpucidTempSql, pattern=tableAliasString)
  @EntityMapping(parameters=getXEpucidTempParameters, results=getXEpucidTempResults)
  Iterator<ResultQueue1<EObjXEpucidTemp>> getXEpucidTemp(Object[] parameters);  


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getXEpucidTempHistorySql, pattern=tableAliasString)
  @EntityMapping(parameters=getXEpucidTempHistoryParameters, results=getXEpucidTempHistoryResults)
  Iterator<ResultQueue1<EObjXEpucidTemp>> getXEpucidTempHistory(Object[] parameters);  


}


