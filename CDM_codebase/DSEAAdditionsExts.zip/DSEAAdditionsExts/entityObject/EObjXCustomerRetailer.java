/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[7a88e6e6728c4171c814a33ee327971d]
 */

package com.ibm.daimler.dsea.entityObject;

import com.dwl.base.EObjCommon;
import com.ibm.mdm.base.db.DataType;
import com.ibm.pdq.annotation.Column;
import com.ibm.pdq.annotation.Table;


import com.ibm.pdq.annotation.Id;

import java.sql.Timestamp;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * The entity object corresponding to the XCustomerRetailer business object.
 * This entity object should include all the attributes as defined by the
 * business object.
 * 
 * @generated
 */
@SuppressWarnings("serial")
@Table(name=EObjXCustomerRetailer.tableName)
public class EObjXCustomerRetailer extends EObjCommon {

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public static final String tableName = "XCUSTOMERRETAILER";
    
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String customerRetailerpkIdColumn = "CUSTOMERRETAILERPK_ID";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String customerRetailerpkIdJdbcType = "BIGINT";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    customerRetailerpkIdPrecision = 19;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String contIdColumn = "CONT_ID";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String contIdJdbcType = "BIGINT";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    contIdPrecision = 19;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String retailerIdColumn = "RETAILER_ID";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String retailerIdJdbcType = "BIGINT";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    retailerIdPrecision = 19;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String sourceIdentifierColumn = "SOURCE_IDENT_TP_CD";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String sourceIdentifierJdbcType = "BIGINT";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    sourceIdentifierPrecision = 19;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String startDateColumn = "START_DT";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String startDateJdbcType = "TIMESTAMP";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String endDateColumn = "END_DT";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String endDateJdbcType = "TIMESTAMP";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected Long customerRetailerpkId;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected Long contId;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected Long retailerId;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected Long sourceIdentifier;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected  Timestamp startDate;
    //inside if 

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected  Timestamp endDate;
    //inside if 



    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Default constructor.     
     *
     * @generated
     */
    public EObjXCustomerRetailer() {
        super();
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the customerRetailerpkId attribute. 
     *
     * @generated
     */
    @Id
    @Column(name=customerRetailerpkIdColumn)
    @DataType(jdbcType=customerRetailerpkIdJdbcType, precision=customerRetailerpkIdPrecision)
    public Long getCustomerRetailerpkId (){
        return customerRetailerpkId;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the customerRetailerpkId attribute. 
     *
     * @param customerRetailerpkId
     *     The new value of CustomerRetailerpkId. 
     * @generated
     */
    public void setCustomerRetailerpkId( Long customerRetailerpkId ){
        this.customerRetailerpkId = customerRetailerpkId;
    
        super.setIdPK(customerRetailerpkId);
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the contId attribute. 
     *
     * @generated
     */
    @Column(name=contIdColumn)
    @DataType(jdbcType=contIdJdbcType, precision=contIdPrecision)
    public Long getContId (){
        return contId;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the contId attribute. 
     *
     * @param contId
     *     The new value of ContId. 
     * @generated
     */
    public void setContId( Long contId ){
        this.contId = contId;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the retailerId attribute. 
     *
     * @generated
     */
    @Column(name=retailerIdColumn)
    @DataType(jdbcType=retailerIdJdbcType, precision=retailerIdPrecision)
    public Long getRetailerId (){
        return retailerId;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the retailerId attribute. 
     *
     * @param retailerId
     *     The new value of RetailerId. 
     * @generated
     */
    public void setRetailerId( Long retailerId ){
        this.retailerId = retailerId;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the sourceIdentifier attribute. 
     *
     * @generated
     */
    @Column(name=sourceIdentifierColumn)
    @DataType(jdbcType=sourceIdentifierJdbcType, precision=sourceIdentifierPrecision)
    public Long getSourceIdentifier (){
        return sourceIdentifier;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the sourceIdentifier attribute. 
     *
     * @param sourceIdentifier
     *     The new value of SourceIdentifier. 
     * @generated
     */
    public void setSourceIdentifier( Long sourceIdentifier ){
        this.sourceIdentifier = sourceIdentifier;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the startDate attribute. 
     *
     * @generated
     */
    @Column(name=startDateColumn)
    @DataType(jdbcType=startDateJdbcType)
    public Timestamp getStartDate (){
        return startDate;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the startDate attribute. 
     *
     * @param startDate
     *     The new value of StartDate. 
     * @generated
     */
    public void setStartDate( Timestamp startDate ){
        this.startDate = startDate;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the endDate attribute. 
     *
     * @generated
     */
    @Column(name=endDateColumn)
    @DataType(jdbcType=endDateJdbcType)
    public Timestamp getEndDate (){
        return endDate;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the endDate attribute. 
     *
     * @param endDate
     *     The new value of EndDate. 
     * @generated
     */
    public void setEndDate( Timestamp endDate ){
        this.endDate = endDate;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the primary key. 
     *
     * @param aUniqueId
     *     The new value of the primary key. 
     * @generated
   */
	public void setPrimaryKey(Object aUniqueId) {
    this.setCustomerRetailerpkId((Long)aUniqueId);
  }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the primary key.
     *
     * @generated
     */
	public Object getPrimaryKey() {
    return this.getCustomerRetailerpkId();
  }
	 
}


