package com.ibm.daimler.dsea.entityObject;

import com.ibm.pdq.runtime.generator.BaseParameterHandler;
import java.util.Iterator;
import com.dwl.tcrm.coreParty.entityObject.EObjPersonName;
import com.dwl.tcrm.coreParty.entityObject.EObjPersonSearch;
import com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt;
import java.sql.PreparedStatement;
import com.ibm.pdq.runtime.statement.StatementDescriptor;
import com.ibm.pdq.runtime.generator.BaseData;
import java.sql.SQLException;
import com.ibm.pdq.annotation.Metadata;
import com.ibm.mdm.base.db.ResultQueue3;
import com.ibm.mdm.base.db.ResultQueue2;
import com.ibm.pdq.runtime.generator.BaseRowHandler;
import com.ibm.pdq.runtime.statement.SqlStatementType;
import java.sql.Types;


@SuppressWarnings("unchecked")

/**
 * <!-- begin-user-doc -->
 * 
 * <!-- end-user-doc -->
 * 
 * @generated
 */
public class XPersonNameExtInquiryDataImpl  extends BaseData implements XPersonNameExtInquiryData
{

  /**
   * @generated
   */
  public static final String generatorVersion = "3.200.75";

  /**
   * @generated
   */
  public static final String identifier = "XPersonNameExtInquiryData";

  /**
   * @generated
   */
  public static final long generationTime = 0x00000161e03e43b8L;

  /**
   * @generated
   */
  public static final String collection = "NULLID";

  /**
   * @generated
   */
  public static final String packageVersion = null;

  /**
   * @generated
   */
  public static final boolean forceSingleBindIsolation = false;

  /**
   * @generated
   */
  public XPersonNameExtInquiryDataImpl()
  {
    super();
  } 

  /**
   * @generated
   */
  public String getGeneratorVersion()
  {
    return generatorVersion;
  }

  /**
   * @Select( sql="SELECT DISTINCT A.H_PERSON_NAME_ID AS HIST_ID_PK , A.H_ACTION_CODE , A.H_CREATED_BY , A.H_CREATE_DT , A.H_END_DT , A.PERSON_NAME_ID , A.PREFIX_NAME_TP_CD , A.PREFIX_DESC , A.NAME_USAGE_TP_CD , A.GIVEN_NAME_ONE , A.GIVEN_NAME_TWO , A.GIVEN_NAME_THREE , A.GIVEN_NAME_FOUR , A.LAST_NAME , A.GENERATION_TP_CD , A.SUFFIX_DESC , A.START_DT , A.END_DT , A.CONT_ID , A.USE_STANDARD_IND , A.LAST_UPDATE_DT , A.LAST_UPDATE_USER , A.LAST_UPDATE_TX_ID , A.LAST_USED_DT , A.LAST_VERIFIED_DT , A.SOURCE_IDENT_TP_CD , B.GIVEN_NAME_ONE , B.GIVEN_NAME_TWO , B.GIVEN_NAME_THREE , B.GIVEN_NAME_FOUR , B.LAST_NAME , B.LAST_UPDATE_TX_ID, B.STANDARD_IND, A.XMODIFY_SYS_DT, A.XGIVEN_NAME_ONE_LOCAL, A.XGIVEN_NAME_TWO_LOCAL, A.XLAST_NAME_LOCAL, A.XPERSONNAME_RETAILER_FLAG, A.X_BPID FROM H_PERSONNAME A,H_PERSONSEARCH B WHERE A.CONT_ID = ? AND A.H_PERSON_NAME_ID = B.PERSON_NAME_ID AND (( ? BETWEEN A.H_CREATE_DT AND A.H_END_DT ) OR ( ? >= A.H_CREATE_DT AND A.H_END_DT IS NULL )) AND (( ? BETWEEN B.H_CREATE_DT AND B.H_END_DT ) OR ( ? >= B.H_CREATE_DT AND B.H_END_DT IS NULL ))", pattern="tableAlias (PERSONNAME => com.dwl.tcrm.coreParty.entityObject.EObjPersonName, H_PERSONNAME => com.dwl.tcrm.coreParty.entityObject.EObjPersonName, PERSONSEARCH => com.dwl.tcrm.coreParty.entityObject.EObjPersonSearch, H_PERSONSEARCH => com.dwl.tcrm.coreParty.entityObject.EObjPersonSearch , PERSONNAME => com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt , H_PERSONNAME => com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue3<EObjPersonName,EObjPersonSearch,EObjXPersonNameExt>> getPersonNamesHistory (Object[] parameters)
  {
    return queryIterator (getPersonNamesHistoryStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getPersonNamesHistoryStatementDescriptor = createStatementDescriptor (
    "getPersonNamesHistory(Object[])",
    "SELECT DISTINCT A.H_PERSON_NAME_ID AS HIST_ID_PK , A.H_ACTION_CODE , A.H_CREATED_BY , A.H_CREATE_DT , A.H_END_DT , A.PERSON_NAME_ID , A.PREFIX_NAME_TP_CD , A.PREFIX_DESC , A.NAME_USAGE_TP_CD , A.GIVEN_NAME_ONE , A.GIVEN_NAME_TWO , A.GIVEN_NAME_THREE , A.GIVEN_NAME_FOUR , A.LAST_NAME , A.GENERATION_TP_CD , A.SUFFIX_DESC , A.START_DT , A.END_DT , A.CONT_ID , A.USE_STANDARD_IND , A.LAST_UPDATE_DT , A.LAST_UPDATE_USER , A.LAST_UPDATE_TX_ID , A.LAST_USED_DT , A.LAST_VERIFIED_DT , A.SOURCE_IDENT_TP_CD , B.GIVEN_NAME_ONE , B.GIVEN_NAME_TWO , B.GIVEN_NAME_THREE , B.GIVEN_NAME_FOUR , B.LAST_NAME , B.LAST_UPDATE_TX_ID, B.STANDARD_IND, A.XMODIFY_SYS_DT, A.XGIVEN_NAME_ONE_LOCAL, A.XGIVEN_NAME_TWO_LOCAL, A.XLAST_NAME_LOCAL, A.XPERSONNAME_RETAILER_FLAG, A.X_BPID FROM H_PERSONNAME A,H_PERSONSEARCH B WHERE A.CONT_ID = ? AND A.H_PERSON_NAME_ID = B.PERSON_NAME_ID AND (( ? BETWEEN A.H_CREATE_DT AND A.H_END_DT ) OR ( ? >= A.H_CREATE_DT AND A.H_END_DT IS NULL )) AND (( ? BETWEEN B.H_CREATE_DT AND B.H_END_DT ) OR ( ? >= B.H_CREATE_DT AND B.H_END_DT IS NULL ))",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"hist_id_pk", "h_action_code", "h_created_by", "h_create_dt", "h_end_dt", "person_name_id", "prefix_name_tp_cd", "prefix_desc", "name_usage_tp_cd", "given_name_one", "given_name_two", "given_name_three", "given_name_four", "last_name", "generation_tp_cd", "suffix_desc", "start_dt", "end_dt", "cont_id", "use_standard_ind", "last_update_dt", "last_update_user", "last_update_tx_id", "last_used_dt", "last_verified_dt", "source_ident_tp_cd", "given_name_one", "given_name_two", "given_name_three", "given_name_four", "last_name", "last_update_tx_id", "standard_ind", "xmodify_sys_dt", "xgiven_name_one_local", "xgiven_name_two_local", "xlast_name_local", "xpersonname_retailer_flag", "x_bpid"},
    new GetPersonNamesHistoryParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP}, {19, 0, 0, 0, 0}, {0, 0, 0, 0, 0}, {1, 1, 1, 1, 1}},
    null,
    new GetPersonNamesHistoryRowHandler (),
    new int[][]{ {Types.BIGINT, Types.CHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.CHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.CHAR, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR}, {19, 1, 20, 0, 0, 19, 19, 20, 19, 25, 25, 25, 25, 30, 19, 20, 0, 0, 19, 1, 0, 20, 19, 0, 0, 19, 25, 25, 25, 25, 30, 19, 1, 0, 500, 500, 500, 10, 50}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    1);

  /**
   * @generated
   */
  public static class GetPersonNamesHistoryParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
      setObject (stmt, 4, Types.TIMESTAMP, parameters[3], 0);
      setObject (stmt, 5, Types.TIMESTAMP, parameters[4], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetPersonNamesHistoryRowHandler extends BaseRowHandler<ResultQueue3<EObjPersonName,EObjPersonSearch,EObjXPersonNameExt>>
  {
    /**
     * @generated
     */
    public ResultQueue3<EObjPersonName,EObjPersonSearch,EObjXPersonNameExt> handle (java.sql.ResultSet rs, ResultQueue3<EObjPersonName,EObjPersonSearch,EObjXPersonNameExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue3<EObjPersonName,EObjPersonSearch,EObjXPersonNameExt> ();

      EObjPersonName returnObject1 = new EObjPersonName ();
      returnObject1.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject1.setHistActionCode(getString (rs, 2)); 
      returnObject1.setHistCreatedBy(getString (rs, 3)); 
      returnObject1.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject1.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject1.setPersonNameIdPK(getLongObject (rs, 6)); 
      returnObject1.setPrefixNameTpCd(getLongObject (rs, 7)); 
      returnObject1.setPrefixDesc(getString (rs, 8)); 
      returnObject1.setNameUsageTpCd(getLongObject (rs, 9)); 
      returnObject1.setGivenNameOne(getString (rs, 10)); 
      returnObject1.setGivenNameTwo(getString (rs, 11)); 
      returnObject1.setGivenNameThree(getString (rs, 12)); 
      returnObject1.setGivenNameFour(getString (rs, 13)); 
      returnObject1.setLastName(getString (rs, 14)); 
      returnObject1.setGenerationTpCd(getLongObject (rs, 15)); 
      returnObject1.setSuffixDesc(getString (rs, 16)); 
      returnObject1.setStartDt(getTimestamp (rs, 17)); 
      returnObject1.setEndDt(getTimestamp (rs, 18)); 
      returnObject1.setContId(getLongObject (rs, 19)); 
      returnObject1.setUseStandardInd(getString (rs, 20)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 21)); 
      returnObject1.setLastUpdateUser(getString (rs, 22)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 23)); 
      returnObject1.setLastUsedDt(getTimestamp (rs, 24)); 
      returnObject1.setLastVerifiedDt(getTimestamp (rs, 25)); 
      returnObject1.setSourceIdentTpCd(getLongObject (rs, 26)); 
      returnObject.add (returnObject1);

      EObjPersonSearch returnObject2 = new EObjPersonSearch ();
      returnObject2.setGivenNameOne(getString (rs, 27)); 
      returnObject2.setGivenNameTwo(getString (rs, 28)); 
      returnObject2.setGivenNameThree(getString (rs, 29)); 
      returnObject2.setGivenNameFour(getString (rs, 30)); 
      returnObject2.setLastName(getString (rs, 31)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 32)); 
      returnObject2.setPersonNameStandardInd(getString (rs, 33)); 
      returnObject.add (returnObject2);

      EObjXPersonNameExt returnObject3 = new EObjXPersonNameExt ();
      returnObject3.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject3.setHistActionCode(getString (rs, 2)); 
      returnObject3.setHistCreatedBy(getString (rs, 3)); 
      returnObject3.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject3.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject3.setLastUpdateDt(getTimestamp (rs, 21)); 
      returnObject3.setLastUpdateUser(getString (rs, 22)); 
      returnObject3.setLastUpdateTxId(getLongObject (rs, 23)); 
      returnObject3.setXLastModifiedSystemDate(getTimestamp (rs, 34)); 
      returnObject3.setXGivenNameOneLocal(getString (rs, 35)); 
      returnObject3.setXGivenNameTwoLocal(getString (rs, 36)); 
      returnObject3.setXLastNameLocal(getString (rs, 37)); 
      returnObject3.setXPersonNameRetailerFlag(getString (rs, 38)); 
      returnObject3.setX_BPID(getString (rs, 39)); 
      returnObject.add (returnObject3);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT PERSONNAME.PERSON_NAME_ID , PERSONNAME.PREFIX_NAME_TP_CD , PERSONNAME.PREFIX_DESC , PERSONNAME.NAME_USAGE_TP_CD , PERSONNAME.GIVEN_NAME_ONE , PERSONNAME.GIVEN_NAME_TWO , PERSONNAME.GIVEN_NAME_THREE , PERSONNAME.GIVEN_NAME_FOUR , PERSONNAME.LAST_NAME , PERSONNAME.GENERATION_TP_CD , PERSONNAME.SUFFIX_DESC , PERSONNAME.START_DT , PERSONNAME.END_DT , PERSONNAME.CONT_ID , PERSONNAME.USE_STANDARD_IND , PERSONNAME.LAST_UPDATE_DT , PERSONNAME.LAST_UPDATE_USER , PERSONNAME.LAST_UPDATE_TX_ID , PERSONNAME.LAST_USED_DT , PERSONNAME.LAST_VERIFIED_DT , PERSONNAME.SOURCE_IDENT_TP_CD , PERSONNAME.P_LAST_NAME, PERSONNAME.P_GIVEN_NAME_ONE, PERSONNAME.P_GIVEN_NAME_TWO, PERSONSEARCH.GIVEN_NAME_ONE , PERSONSEARCH.GIVEN_NAME_TWO , PERSONSEARCH.GIVEN_NAME_THREE , PERSONSEARCH.GIVEN_NAME_FOUR , PERSONSEARCH.LAST_NAME , PERSONSEARCH.LAST_UPDATE_TX_ID, PERSONSEARCH.STANDARD_IND, PERSONNAME.XMODIFY_SYS_DT, PERSONNAME.XGIVEN_NAME_ONE_LOCAL, PERSONNAME.XGIVEN_NAME_TWO_LOCAL, PERSONNAME.XLAST_NAME_LOCAL, PERSONNAME.XPERSONNAME_RETAILER_FLAG, PERSONNAME.X_BPID FROM PERSONNAME, PERSONSEARCH WHERE PERSONNAME.CONT_ID = ? AND (PERSONNAME.END_DT IS NULL OR PERSONNAME.END_DT> ? ) AND PERSONNAME.PERSON_NAME_ID = PERSONSEARCH.PERSON_NAME_ID", pattern="tableAlias (PERSONNAME => com.dwl.tcrm.coreParty.entityObject.EObjPersonName, H_PERSONNAME => com.dwl.tcrm.coreParty.entityObject.EObjPersonName, PERSONSEARCH => com.dwl.tcrm.coreParty.entityObject.EObjPersonSearch, H_PERSONSEARCH => com.dwl.tcrm.coreParty.entityObject.EObjPersonSearch , PERSONNAME => com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt , H_PERSONNAME => com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue3<EObjPersonName,EObjPersonSearch,EObjXPersonNameExt>> getPersonNamesActive (Object[] parameters)
  {
    return queryIterator (getPersonNamesActiveStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getPersonNamesActiveStatementDescriptor = createStatementDescriptor (
    "getPersonNamesActive(Object[])",
    "SELECT PERSONNAME.PERSON_NAME_ID , PERSONNAME.PREFIX_NAME_TP_CD , PERSONNAME.PREFIX_DESC , PERSONNAME.NAME_USAGE_TP_CD , PERSONNAME.GIVEN_NAME_ONE , PERSONNAME.GIVEN_NAME_TWO , PERSONNAME.GIVEN_NAME_THREE , PERSONNAME.GIVEN_NAME_FOUR , PERSONNAME.LAST_NAME , PERSONNAME.GENERATION_TP_CD , PERSONNAME.SUFFIX_DESC , PERSONNAME.START_DT , PERSONNAME.END_DT , PERSONNAME.CONT_ID , PERSONNAME.USE_STANDARD_IND , PERSONNAME.LAST_UPDATE_DT , PERSONNAME.LAST_UPDATE_USER , PERSONNAME.LAST_UPDATE_TX_ID , PERSONNAME.LAST_USED_DT , PERSONNAME.LAST_VERIFIED_DT , PERSONNAME.SOURCE_IDENT_TP_CD , PERSONNAME.P_LAST_NAME, PERSONNAME.P_GIVEN_NAME_ONE, PERSONNAME.P_GIVEN_NAME_TWO, PERSONSEARCH.GIVEN_NAME_ONE , PERSONSEARCH.GIVEN_NAME_TWO , PERSONSEARCH.GIVEN_NAME_THREE , PERSONSEARCH.GIVEN_NAME_FOUR , PERSONSEARCH.LAST_NAME , PERSONSEARCH.LAST_UPDATE_TX_ID, PERSONSEARCH.STANDARD_IND, PERSONNAME.XMODIFY_SYS_DT, PERSONNAME.XGIVEN_NAME_ONE_LOCAL, PERSONNAME.XGIVEN_NAME_TWO_LOCAL, PERSONNAME.XLAST_NAME_LOCAL, PERSONNAME.XPERSONNAME_RETAILER_FLAG, PERSONNAME.X_BPID FROM PERSONNAME, PERSONSEARCH WHERE PERSONNAME.CONT_ID = ? AND (PERSONNAME.END_DT IS NULL OR PERSONNAME.END_DT> ? ) AND PERSONNAME.PERSON_NAME_ID = PERSONSEARCH.PERSON_NAME_ID",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"person_name_id", "prefix_name_tp_cd", "prefix_desc", "name_usage_tp_cd", "given_name_one", "given_name_two", "given_name_three", "given_name_four", "last_name", "generation_tp_cd", "suffix_desc", "start_dt", "end_dt", "cont_id", "use_standard_ind", "last_update_dt", "last_update_user", "last_update_tx_id", "last_used_dt", "last_verified_dt", "source_ident_tp_cd", "p_last_name", "p_given_name_one", "p_given_name_two", "given_name_one", "given_name_two", "given_name_three", "given_name_four", "last_name", "last_update_tx_id", "standard_ind", "xmodify_sys_dt", "xgiven_name_one_local", "xgiven_name_two_local", "xlast_name_local", "xpersonname_retailer_flag", "x_bpid"},
    new GetPersonNamesActiveParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP}, {19, 0}, {0, 0}, {1, 1}},
    null,
    new GetPersonNamesActiveRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.CHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.CHAR, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR}, {19, 19, 20, 19, 25, 25, 25, 25, 30, 19, 20, 0, 0, 19, 1, 0, 20, 19, 0, 0, 19, 20, 20, 20, 25, 25, 25, 25, 30, 19, 1, 0, 500, 500, 500, 10, 50}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    2);

  /**
   * @generated
   */
  public static class GetPersonNamesActiveParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetPersonNamesActiveRowHandler extends BaseRowHandler<ResultQueue3<EObjPersonName,EObjPersonSearch,EObjXPersonNameExt>>
  {
    /**
     * @generated
     */
    public ResultQueue3<EObjPersonName,EObjPersonSearch,EObjXPersonNameExt> handle (java.sql.ResultSet rs, ResultQueue3<EObjPersonName,EObjPersonSearch,EObjXPersonNameExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue3<EObjPersonName,EObjPersonSearch,EObjXPersonNameExt> ();

      EObjPersonName returnObject1 = new EObjPersonName ();
      returnObject1.setPersonNameIdPK(getLongObject (rs, 1)); 
      returnObject1.setPrefixNameTpCd(getLongObject (rs, 2)); 
      returnObject1.setPrefixDesc(getString (rs, 3)); 
      returnObject1.setNameUsageTpCd(getLongObject (rs, 4)); 
      returnObject1.setGivenNameOne(getString (rs, 5)); 
      returnObject1.setGivenNameTwo(getString (rs, 6)); 
      returnObject1.setGivenNameThree(getString (rs, 7)); 
      returnObject1.setGivenNameFour(getString (rs, 8)); 
      returnObject1.setLastName(getString (rs, 9)); 
      returnObject1.setGenerationTpCd(getLongObject (rs, 10)); 
      returnObject1.setSuffixDesc(getString (rs, 11)); 
      returnObject1.setStartDt(getTimestamp (rs, 12)); 
      returnObject1.setEndDt(getTimestamp (rs, 13)); 
      returnObject1.setContId(getLongObject (rs, 14)); 
      returnObject1.setUseStandardInd(getString (rs, 15)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 16)); 
      returnObject1.setLastUpdateUser(getString (rs, 17)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 18)); 
      returnObject1.setLastUsedDt(getTimestamp (rs, 19)); 
      returnObject1.setLastVerifiedDt(getTimestamp (rs, 20)); 
      returnObject1.setSourceIdentTpCd(getLongObject (rs, 21)); 
      returnObject1.setPLastName(getString (rs, 22)); 
      returnObject1.setPGivenNameOne(getString (rs, 23)); 
      returnObject1.setPGivenNameTwo(getString (rs, 24)); 
      returnObject.add (returnObject1);

      EObjPersonSearch returnObject2 = new EObjPersonSearch ();
      returnObject2.setGivenNameOne(getString (rs, 25)); 
      returnObject2.setGivenNameTwo(getString (rs, 26)); 
      returnObject2.setGivenNameThree(getString (rs, 27)); 
      returnObject2.setGivenNameFour(getString (rs, 28)); 
      returnObject2.setLastName(getString (rs, 29)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 30)); 
      returnObject2.setPersonNameStandardInd(getString (rs, 31)); 
      returnObject.add (returnObject2);

      EObjXPersonNameExt returnObject3 = new EObjXPersonNameExt ();
      returnObject3.setLastUpdateDt(getTimestamp (rs, 16)); 
      returnObject3.setLastUpdateUser(getString (rs, 17)); 
      returnObject3.setLastUpdateTxId(getLongObject (rs, 18)); 
      returnObject3.setXLastModifiedSystemDate(getTimestamp (rs, 32)); 
      returnObject3.setXGivenNameOneLocal(getString (rs, 33)); 
      returnObject3.setXGivenNameTwoLocal(getString (rs, 34)); 
      returnObject3.setXLastNameLocal(getString (rs, 35)); 
      returnObject3.setXPersonNameRetailerFlag(getString (rs, 36)); 
      returnObject3.setX_BPID(getString (rs, 37)); 
      returnObject.add (returnObject3);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT PERSONNAME.PERSON_NAME_ID , PERSONNAME.PREFIX_NAME_TP_CD , PERSONNAME.PREFIX_DESC , PERSONNAME.NAME_USAGE_TP_CD , PERSONNAME.GIVEN_NAME_ONE , PERSONNAME.GIVEN_NAME_TWO , PERSONNAME.GIVEN_NAME_THREE , PERSONNAME.GIVEN_NAME_FOUR , PERSONNAME.LAST_NAME , PERSONNAME.GENERATION_TP_CD , PERSONNAME.SUFFIX_DESC , PERSONNAME.START_DT , PERSONNAME.END_DT , PERSONNAME.CONT_ID , PERSONNAME.USE_STANDARD_IND , PERSONNAME.LAST_UPDATE_DT , PERSONNAME.LAST_UPDATE_USER , PERSONNAME.LAST_UPDATE_TX_ID , PERSONNAME.LAST_USED_DT , PERSONNAME.LAST_VERIFIED_DT , PERSONNAME.SOURCE_IDENT_TP_CD , PERSONSEARCH.GIVEN_NAME_ONE , PERSONSEARCH.GIVEN_NAME_TWO , PERSONSEARCH.GIVEN_NAME_THREE , PERSONSEARCH.GIVEN_NAME_FOUR , PERSONSEARCH.LAST_NAME , PERSONSEARCH.LAST_UPDATE_TX_ID, PERSONSEARCH.STANDARD_IND, PERSONNAME.XMODIFY_SYS_DT, PERSONNAME.XGIVEN_NAME_ONE_LOCAL, PERSONNAME.XGIVEN_NAME_TWO_LOCAL, PERSONNAME.XLAST_NAME_LOCAL, PERSONNAME.XPERSONNAME_RETAILER_FLAG, PERSONNAME.X_BPID FROM PERSONNAME,PERSONSEARCH WHERE PERSONNAME.CONT_ID = ? AND (PERSONNAME.END_DT< ? ) AND PERSONNAME.PERSON_NAME_ID = PERSONSEARCH.PERSON_NAME_ID", pattern="tableAlias (PERSONNAME => com.dwl.tcrm.coreParty.entityObject.EObjPersonName, H_PERSONNAME => com.dwl.tcrm.coreParty.entityObject.EObjPersonName, PERSONSEARCH => com.dwl.tcrm.coreParty.entityObject.EObjPersonSearch, H_PERSONSEARCH => com.dwl.tcrm.coreParty.entityObject.EObjPersonSearch , PERSONNAME => com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt , H_PERSONNAME => com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue3<EObjPersonName,EObjPersonSearch,EObjXPersonNameExt>> getPersonNamesInActive (Object[] parameters)
  {
    return queryIterator (getPersonNamesInActiveStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getPersonNamesInActiveStatementDescriptor = createStatementDescriptor (
    "getPersonNamesInActive(Object[])",
    "SELECT PERSONNAME.PERSON_NAME_ID , PERSONNAME.PREFIX_NAME_TP_CD , PERSONNAME.PREFIX_DESC , PERSONNAME.NAME_USAGE_TP_CD , PERSONNAME.GIVEN_NAME_ONE , PERSONNAME.GIVEN_NAME_TWO , PERSONNAME.GIVEN_NAME_THREE , PERSONNAME.GIVEN_NAME_FOUR , PERSONNAME.LAST_NAME , PERSONNAME.GENERATION_TP_CD , PERSONNAME.SUFFIX_DESC , PERSONNAME.START_DT , PERSONNAME.END_DT , PERSONNAME.CONT_ID , PERSONNAME.USE_STANDARD_IND , PERSONNAME.LAST_UPDATE_DT , PERSONNAME.LAST_UPDATE_USER , PERSONNAME.LAST_UPDATE_TX_ID , PERSONNAME.LAST_USED_DT , PERSONNAME.LAST_VERIFIED_DT , PERSONNAME.SOURCE_IDENT_TP_CD , PERSONSEARCH.GIVEN_NAME_ONE , PERSONSEARCH.GIVEN_NAME_TWO , PERSONSEARCH.GIVEN_NAME_THREE , PERSONSEARCH.GIVEN_NAME_FOUR , PERSONSEARCH.LAST_NAME , PERSONSEARCH.LAST_UPDATE_TX_ID, PERSONSEARCH.STANDARD_IND, PERSONNAME.XMODIFY_SYS_DT, PERSONNAME.XGIVEN_NAME_ONE_LOCAL, PERSONNAME.XGIVEN_NAME_TWO_LOCAL, PERSONNAME.XLAST_NAME_LOCAL, PERSONNAME.XPERSONNAME_RETAILER_FLAG, PERSONNAME.X_BPID FROM PERSONNAME,PERSONSEARCH WHERE PERSONNAME.CONT_ID = ? AND (PERSONNAME.END_DT< ? ) AND PERSONNAME.PERSON_NAME_ID = PERSONSEARCH.PERSON_NAME_ID",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"person_name_id", "prefix_name_tp_cd", "prefix_desc", "name_usage_tp_cd", "given_name_one", "given_name_two", "given_name_three", "given_name_four", "last_name", "generation_tp_cd", "suffix_desc", "start_dt", "end_dt", "cont_id", "use_standard_ind", "last_update_dt", "last_update_user", "last_update_tx_id", "last_used_dt", "last_verified_dt", "source_ident_tp_cd", "given_name_one", "given_name_two", "given_name_three", "given_name_four", "last_name", "last_update_tx_id", "standard_ind", "xmodify_sys_dt", "xgiven_name_one_local", "xgiven_name_two_local", "xlast_name_local", "xpersonname_retailer_flag", "x_bpid"},
    new GetPersonNamesInActiveParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP}, {19, 0}, {0, 0}, {1, 1}},
    null,
    new GetPersonNamesInActiveRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.CHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.CHAR, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR}, {19, 19, 20, 19, 25, 25, 25, 25, 30, 19, 20, 0, 0, 19, 1, 0, 20, 19, 0, 0, 19, 25, 25, 25, 25, 30, 19, 1, 0, 500, 500, 500, 10, 50}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    3);

  /**
   * @generated
   */
  public static class GetPersonNamesInActiveParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetPersonNamesInActiveRowHandler extends BaseRowHandler<ResultQueue3<EObjPersonName,EObjPersonSearch,EObjXPersonNameExt>>
  {
    /**
     * @generated
     */
    public ResultQueue3<EObjPersonName,EObjPersonSearch,EObjXPersonNameExt> handle (java.sql.ResultSet rs, ResultQueue3<EObjPersonName,EObjPersonSearch,EObjXPersonNameExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue3<EObjPersonName,EObjPersonSearch,EObjXPersonNameExt> ();

      EObjPersonName returnObject1 = new EObjPersonName ();
      returnObject1.setPersonNameIdPK(getLongObject (rs, 1)); 
      returnObject1.setPrefixNameTpCd(getLongObject (rs, 2)); 
      returnObject1.setPrefixDesc(getString (rs, 3)); 
      returnObject1.setNameUsageTpCd(getLongObject (rs, 4)); 
      returnObject1.setGivenNameOne(getString (rs, 5)); 
      returnObject1.setGivenNameTwo(getString (rs, 6)); 
      returnObject1.setGivenNameThree(getString (rs, 7)); 
      returnObject1.setGivenNameFour(getString (rs, 8)); 
      returnObject1.setLastName(getString (rs, 9)); 
      returnObject1.setGenerationTpCd(getLongObject (rs, 10)); 
      returnObject1.setSuffixDesc(getString (rs, 11)); 
      returnObject1.setStartDt(getTimestamp (rs, 12)); 
      returnObject1.setEndDt(getTimestamp (rs, 13)); 
      returnObject1.setContId(getLongObject (rs, 14)); 
      returnObject1.setUseStandardInd(getString (rs, 15)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 16)); 
      returnObject1.setLastUpdateUser(getString (rs, 17)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 18)); 
      returnObject1.setLastUsedDt(getTimestamp (rs, 19)); 
      returnObject1.setLastVerifiedDt(getTimestamp (rs, 20)); 
      returnObject1.setSourceIdentTpCd(getLongObject (rs, 21)); 
      returnObject.add (returnObject1);

      EObjPersonSearch returnObject2 = new EObjPersonSearch ();
      returnObject2.setGivenNameOne(getString (rs, 22)); 
      returnObject2.setGivenNameTwo(getString (rs, 23)); 
      returnObject2.setGivenNameThree(getString (rs, 24)); 
      returnObject2.setGivenNameFour(getString (rs, 25)); 
      returnObject2.setLastName(getString (rs, 26)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 27)); 
      returnObject2.setPersonNameStandardInd(getString (rs, 28)); 
      returnObject.add (returnObject2);

      EObjXPersonNameExt returnObject3 = new EObjXPersonNameExt ();
      returnObject3.setLastUpdateDt(getTimestamp (rs, 16)); 
      returnObject3.setLastUpdateUser(getString (rs, 17)); 
      returnObject3.setLastUpdateTxId(getLongObject (rs, 18)); 
      returnObject3.setXLastModifiedSystemDate(getTimestamp (rs, 29)); 
      returnObject3.setXGivenNameOneLocal(getString (rs, 30)); 
      returnObject3.setXGivenNameTwoLocal(getString (rs, 31)); 
      returnObject3.setXLastNameLocal(getString (rs, 32)); 
      returnObject3.setXPersonNameRetailerFlag(getString (rs, 33)); 
      returnObject3.setX_BPID(getString (rs, 34)); 
      returnObject.add (returnObject3);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT PERSONNAME.PERSON_NAME_ID , PERSONNAME.PREFIX_NAME_TP_CD , PERSONNAME.PREFIX_DESC , PERSONNAME.NAME_USAGE_TP_CD , PERSONNAME.GIVEN_NAME_ONE , PERSONNAME.GIVEN_NAME_TWO , PERSONNAME.GIVEN_NAME_THREE , PERSONNAME.GIVEN_NAME_FOUR , PERSONNAME.LAST_NAME , PERSONNAME.GENERATION_TP_CD , PERSONNAME.SUFFIX_DESC , PERSONNAME.START_DT , PERSONNAME.END_DT , PERSONNAME.CONT_ID , PERSONNAME.USE_STANDARD_IND , PERSONNAME.LAST_UPDATE_DT , PERSONNAME.LAST_UPDATE_USER , PERSONNAME.LAST_UPDATE_TX_ID , PERSONNAME.LAST_USED_DT , PERSONNAME.LAST_VERIFIED_DT , PERSONNAME.SOURCE_IDENT_TP_CD , PERSONSEARCH.GIVEN_NAME_ONE , PERSONSEARCH.GIVEN_NAME_TWO , PERSONSEARCH.GIVEN_NAME_THREE , PERSONSEARCH.GIVEN_NAME_FOUR , PERSONSEARCH.LAST_NAME , PERSONSEARCH.LAST_UPDATE_TX_ID, PERSONSEARCH.STANDARD_IND, PERSONNAME.XMODIFY_SYS_DT, PERSONNAME.XGIVEN_NAME_ONE_LOCAL, PERSONNAME.XGIVEN_NAME_TWO_LOCAL, PERSONNAME.XLAST_NAME_LOCAL, PERSONNAME.XPERSONNAME_RETAILER_FLAG, PERSONNAME.X_BPID FROM PERSONNAME,PERSONSEARCH WHERE PERSONNAME.CONT_ID = ? AND PERSONNAME.PERSON_NAME_ID = PERSONSEARCH.PERSON_NAME_ID", pattern="tableAlias (PERSONNAME => com.dwl.tcrm.coreParty.entityObject.EObjPersonName, H_PERSONNAME => com.dwl.tcrm.coreParty.entityObject.EObjPersonName, PERSONSEARCH => com.dwl.tcrm.coreParty.entityObject.EObjPersonSearch, H_PERSONSEARCH => com.dwl.tcrm.coreParty.entityObject.EObjPersonSearch , PERSONNAME => com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt , H_PERSONNAME => com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue3<EObjPersonName,EObjPersonSearch,EObjXPersonNameExt>> getPersonNamesAll (Object[] parameters)
  {
    return queryIterator (getPersonNamesAllStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getPersonNamesAllStatementDescriptor = createStatementDescriptor (
    "getPersonNamesAll(Object[])",
    "SELECT PERSONNAME.PERSON_NAME_ID , PERSONNAME.PREFIX_NAME_TP_CD , PERSONNAME.PREFIX_DESC , PERSONNAME.NAME_USAGE_TP_CD , PERSONNAME.GIVEN_NAME_ONE , PERSONNAME.GIVEN_NAME_TWO , PERSONNAME.GIVEN_NAME_THREE , PERSONNAME.GIVEN_NAME_FOUR , PERSONNAME.LAST_NAME , PERSONNAME.GENERATION_TP_CD , PERSONNAME.SUFFIX_DESC , PERSONNAME.START_DT , PERSONNAME.END_DT , PERSONNAME.CONT_ID , PERSONNAME.USE_STANDARD_IND , PERSONNAME.LAST_UPDATE_DT , PERSONNAME.LAST_UPDATE_USER , PERSONNAME.LAST_UPDATE_TX_ID , PERSONNAME.LAST_USED_DT , PERSONNAME.LAST_VERIFIED_DT , PERSONNAME.SOURCE_IDENT_TP_CD , PERSONSEARCH.GIVEN_NAME_ONE , PERSONSEARCH.GIVEN_NAME_TWO , PERSONSEARCH.GIVEN_NAME_THREE , PERSONSEARCH.GIVEN_NAME_FOUR , PERSONSEARCH.LAST_NAME , PERSONSEARCH.LAST_UPDATE_TX_ID, PERSONSEARCH.STANDARD_IND, PERSONNAME.XMODIFY_SYS_DT, PERSONNAME.XGIVEN_NAME_ONE_LOCAL, PERSONNAME.XGIVEN_NAME_TWO_LOCAL, PERSONNAME.XLAST_NAME_LOCAL, PERSONNAME.XPERSONNAME_RETAILER_FLAG, PERSONNAME.X_BPID FROM PERSONNAME,PERSONSEARCH WHERE PERSONNAME.CONT_ID = ? AND PERSONNAME.PERSON_NAME_ID = PERSONSEARCH.PERSON_NAME_ID",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"person_name_id", "prefix_name_tp_cd", "prefix_desc", "name_usage_tp_cd", "given_name_one", "given_name_two", "given_name_three", "given_name_four", "last_name", "generation_tp_cd", "suffix_desc", "start_dt", "end_dt", "cont_id", "use_standard_ind", "last_update_dt", "last_update_user", "last_update_tx_id", "last_used_dt", "last_verified_dt", "source_ident_tp_cd", "given_name_one", "given_name_two", "given_name_three", "given_name_four", "last_name", "last_update_tx_id", "standard_ind", "xmodify_sys_dt", "xgiven_name_one_local", "xgiven_name_two_local", "xlast_name_local", "xpersonname_retailer_flag", "x_bpid"},
    new GetPersonNamesAllParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetPersonNamesAllRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.CHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.CHAR, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR}, {19, 19, 20, 19, 25, 25, 25, 25, 30, 19, 20, 0, 0, 19, 1, 0, 20, 19, 0, 0, 19, 25, 25, 25, 25, 30, 19, 1, 0, 500, 500, 500, 10, 50}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    4);

  /**
   * @generated
   */
  public static class GetPersonNamesAllParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetPersonNamesAllRowHandler extends BaseRowHandler<ResultQueue3<EObjPersonName,EObjPersonSearch,EObjXPersonNameExt>>
  {
    /**
     * @generated
     */
    public ResultQueue3<EObjPersonName,EObjPersonSearch,EObjXPersonNameExt> handle (java.sql.ResultSet rs, ResultQueue3<EObjPersonName,EObjPersonSearch,EObjXPersonNameExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue3<EObjPersonName,EObjPersonSearch,EObjXPersonNameExt> ();

      EObjPersonName returnObject1 = new EObjPersonName ();
      returnObject1.setPersonNameIdPK(getLongObject (rs, 1)); 
      returnObject1.setPrefixNameTpCd(getLongObject (rs, 2)); 
      returnObject1.setPrefixDesc(getString (rs, 3)); 
      returnObject1.setNameUsageTpCd(getLongObject (rs, 4)); 
      returnObject1.setGivenNameOne(getString (rs, 5)); 
      returnObject1.setGivenNameTwo(getString (rs, 6)); 
      returnObject1.setGivenNameThree(getString (rs, 7)); 
      returnObject1.setGivenNameFour(getString (rs, 8)); 
      returnObject1.setLastName(getString (rs, 9)); 
      returnObject1.setGenerationTpCd(getLongObject (rs, 10)); 
      returnObject1.setSuffixDesc(getString (rs, 11)); 
      returnObject1.setStartDt(getTimestamp (rs, 12)); 
      returnObject1.setEndDt(getTimestamp (rs, 13)); 
      returnObject1.setContId(getLongObject (rs, 14)); 
      returnObject1.setUseStandardInd(getString (rs, 15)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 16)); 
      returnObject1.setLastUpdateUser(getString (rs, 17)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 18)); 
      returnObject1.setLastUsedDt(getTimestamp (rs, 19)); 
      returnObject1.setLastVerifiedDt(getTimestamp (rs, 20)); 
      returnObject1.setSourceIdentTpCd(getLongObject (rs, 21)); 
      returnObject.add (returnObject1);

      EObjPersonSearch returnObject2 = new EObjPersonSearch ();
      returnObject2.setGivenNameOne(getString (rs, 22)); 
      returnObject2.setGivenNameTwo(getString (rs, 23)); 
      returnObject2.setGivenNameThree(getString (rs, 24)); 
      returnObject2.setGivenNameFour(getString (rs, 25)); 
      returnObject2.setLastName(getString (rs, 26)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 27)); 
      returnObject2.setPersonNameStandardInd(getString (rs, 28)); 
      returnObject.add (returnObject2);

      EObjXPersonNameExt returnObject3 = new EObjXPersonNameExt ();
      returnObject3.setLastUpdateDt(getTimestamp (rs, 16)); 
      returnObject3.setLastUpdateUser(getString (rs, 17)); 
      returnObject3.setLastUpdateTxId(getLongObject (rs, 18)); 
      returnObject3.setXLastModifiedSystemDate(getTimestamp (rs, 29)); 
      returnObject3.setXGivenNameOneLocal(getString (rs, 30)); 
      returnObject3.setXGivenNameTwoLocal(getString (rs, 31)); 
      returnObject3.setXLastNameLocal(getString (rs, 32)); 
      returnObject3.setXPersonNameRetailerFlag(getString (rs, 33)); 
      returnObject3.setX_BPID(getString (rs, 34)); 
      returnObject.add (returnObject3);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT DISTINCT A.H_PERSON_NAME_ID AS HIST_ID_PK ,A.H_ACTION_CODE ,A.H_CREATED_BY ,A.H_CREATE_DT ,A.H_END_DT ,A.PERSON_NAME_ID ,A.PREFIX_NAME_TP_CD ,A.PREFIX_DESC ,A.NAME_USAGE_TP_CD ,A.GIVEN_NAME_ONE ,A.GIVEN_NAME_TWO ,A.GIVEN_NAME_THREE ,A.GIVEN_NAME_FOUR ,A.LAST_NAME , A.GENERATION_TP_CD , A.SUFFIX_DESC ,A.START_DT ,A.END_DT ,A.CONT_ID ,A.USE_STANDARD_IND ,A.LAST_UPDATE_DT ,A.LAST_UPDATE_USER , A.LAST_UPDATE_TX_ID , A.LAST_USED_DT , A.LAST_VERIFIED_DT , A.SOURCE_IDENT_TP_CD , B.GIVEN_NAME_ONE ,B.GIVEN_NAME_TWO ,B.GIVEN_NAME_THREE ,B.GIVEN_NAME_FOUR ,B.LAST_NAME , B.LAST_UPDATE_TX_ID, B.STANDARD_IND, A.XMODIFY_SYS_DT, A.XGIVEN_NAME_ONE_LOCAL, A.XGIVEN_NAME_TWO_LOCAL, A.XLAST_NAME_LOCAL, A.XPERSONNAME_RETAILER_FLAG, A.X_BPID FROM H_PERSONNAME A, H_PERSONSEARCH B WHERE A.H_PERSON_NAME_ID = B.PERSON_NAME_ID AND A.CONT_ID = ? AND A.NAME_USAGE_TP_CD = ? AND (? BETWEEN A.H_CREATE_DT AND A.H_END_DT OR (? >= A.H_CREATE_DT AND A.H_END_DT IS NULL )) AND (( ? BETWEEN B.H_CREATE_DT AND B.H_END_DT ) OR ( ? >= B.H_CREATE_DT AND B.H_END_DT IS NULL ))", pattern="tableAlias (PERSONNAME => com.dwl.tcrm.coreParty.entityObject.EObjPersonName, H_PERSONNAME => com.dwl.tcrm.coreParty.entityObject.EObjPersonName, PERSONSEARCH => com.dwl.tcrm.coreParty.entityObject.EObjPersonSearch, H_PERSONSEARCH => com.dwl.tcrm.coreParty.entityObject.EObjPersonSearch , PERSONNAME => com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt , H_PERSONNAME => com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue3<EObjPersonName,EObjPersonSearch,EObjXPersonNameExt>> getPersonNameWithTypeHistory (Object[] parameters)
  {
    return queryIterator (getPersonNameWithTypeHistoryStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getPersonNameWithTypeHistoryStatementDescriptor = createStatementDescriptor (
    "getPersonNameWithTypeHistory(Object[])",
    "SELECT DISTINCT A.H_PERSON_NAME_ID AS HIST_ID_PK ,A.H_ACTION_CODE ,A.H_CREATED_BY ,A.H_CREATE_DT ,A.H_END_DT ,A.PERSON_NAME_ID ,A.PREFIX_NAME_TP_CD ,A.PREFIX_DESC ,A.NAME_USAGE_TP_CD ,A.GIVEN_NAME_ONE ,A.GIVEN_NAME_TWO ,A.GIVEN_NAME_THREE ,A.GIVEN_NAME_FOUR ,A.LAST_NAME , A.GENERATION_TP_CD , A.SUFFIX_DESC ,A.START_DT ,A.END_DT ,A.CONT_ID ,A.USE_STANDARD_IND ,A.LAST_UPDATE_DT ,A.LAST_UPDATE_USER , A.LAST_UPDATE_TX_ID , A.LAST_USED_DT , A.LAST_VERIFIED_DT , A.SOURCE_IDENT_TP_CD , B.GIVEN_NAME_ONE ,B.GIVEN_NAME_TWO ,B.GIVEN_NAME_THREE ,B.GIVEN_NAME_FOUR ,B.LAST_NAME , B.LAST_UPDATE_TX_ID, B.STANDARD_IND, A.XMODIFY_SYS_DT, A.XGIVEN_NAME_ONE_LOCAL, A.XGIVEN_NAME_TWO_LOCAL, A.XLAST_NAME_LOCAL, A.XPERSONNAME_RETAILER_FLAG, A.X_BPID FROM H_PERSONNAME A, H_PERSONSEARCH B WHERE A.H_PERSON_NAME_ID = B.PERSON_NAME_ID AND A.CONT_ID = ? AND A.NAME_USAGE_TP_CD = ? AND (? BETWEEN A.H_CREATE_DT AND A.H_END_DT OR (? >= A.H_CREATE_DT AND A.H_END_DT IS NULL )) AND (( ? BETWEEN B.H_CREATE_DT AND B.H_END_DT ) OR ( ? >= B.H_CREATE_DT AND B.H_END_DT IS NULL ))",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"hist_id_pk", "h_action_code", "h_created_by", "h_create_dt", "h_end_dt", "person_name_id", "prefix_name_tp_cd", "prefix_desc", "name_usage_tp_cd", "given_name_one", "given_name_two", "given_name_three", "given_name_four", "last_name", "generation_tp_cd", "suffix_desc", "start_dt", "end_dt", "cont_id", "use_standard_ind", "last_update_dt", "last_update_user", "last_update_tx_id", "last_used_dt", "last_verified_dt", "source_ident_tp_cd", "given_name_one", "given_name_two", "given_name_three", "given_name_four", "last_name", "last_update_tx_id", "standard_ind", "xmodify_sys_dt", "xgiven_name_one_local", "xgiven_name_two_local", "xlast_name_local", "xpersonname_retailer_flag", "x_bpid"},
    new GetPersonNameWithTypeHistoryParameterHandler (),
    new int[][]{{Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP}, {19, 19, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1}},
    null,
    new GetPersonNameWithTypeHistoryRowHandler (),
    new int[][]{ {Types.BIGINT, Types.CHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.CHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.CHAR, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR}, {19, 1, 20, 0, 0, 19, 19, 20, 19, 25, 25, 25, 25, 30, 19, 20, 0, 0, 19, 1, 0, 20, 19, 0, 0, 19, 25, 25, 25, 25, 30, 19, 1, 0, 500, 500, 500, 10, 50}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    5);

  /**
   * @generated
   */
  public static class GetPersonNameWithTypeHistoryParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.BIGINT, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
      setObject (stmt, 4, Types.TIMESTAMP, parameters[3], 0);
      setObject (stmt, 5, Types.TIMESTAMP, parameters[4], 0);
      setObject (stmt, 6, Types.TIMESTAMP, parameters[5], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetPersonNameWithTypeHistoryRowHandler extends BaseRowHandler<ResultQueue3<EObjPersonName,EObjPersonSearch,EObjXPersonNameExt>>
  {
    /**
     * @generated
     */
    public ResultQueue3<EObjPersonName,EObjPersonSearch,EObjXPersonNameExt> handle (java.sql.ResultSet rs, ResultQueue3<EObjPersonName,EObjPersonSearch,EObjXPersonNameExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue3<EObjPersonName,EObjPersonSearch,EObjXPersonNameExt> ();

      EObjPersonName returnObject1 = new EObjPersonName ();
      returnObject1.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject1.setHistActionCode(getString (rs, 2)); 
      returnObject1.setHistCreatedBy(getString (rs, 3)); 
      returnObject1.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject1.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject1.setPersonNameIdPK(getLongObject (rs, 6)); 
      returnObject1.setPrefixNameTpCd(getLongObject (rs, 7)); 
      returnObject1.setPrefixDesc(getString (rs, 8)); 
      returnObject1.setNameUsageTpCd(getLongObject (rs, 9)); 
      returnObject1.setGivenNameOne(getString (rs, 10)); 
      returnObject1.setGivenNameTwo(getString (rs, 11)); 
      returnObject1.setGivenNameThree(getString (rs, 12)); 
      returnObject1.setGivenNameFour(getString (rs, 13)); 
      returnObject1.setLastName(getString (rs, 14)); 
      returnObject1.setGenerationTpCd(getLongObject (rs, 15)); 
      returnObject1.setSuffixDesc(getString (rs, 16)); 
      returnObject1.setStartDt(getTimestamp (rs, 17)); 
      returnObject1.setEndDt(getTimestamp (rs, 18)); 
      returnObject1.setContId(getLongObject (rs, 19)); 
      returnObject1.setUseStandardInd(getString (rs, 20)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 21)); 
      returnObject1.setLastUpdateUser(getString (rs, 22)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 23)); 
      returnObject1.setLastUsedDt(getTimestamp (rs, 24)); 
      returnObject1.setLastVerifiedDt(getTimestamp (rs, 25)); 
      returnObject1.setSourceIdentTpCd(getLongObject (rs, 26)); 
      returnObject.add (returnObject1);

      EObjPersonSearch returnObject2 = new EObjPersonSearch ();
      returnObject2.setGivenNameOne(getString (rs, 27)); 
      returnObject2.setGivenNameTwo(getString (rs, 28)); 
      returnObject2.setGivenNameThree(getString (rs, 29)); 
      returnObject2.setGivenNameFour(getString (rs, 30)); 
      returnObject2.setLastName(getString (rs, 31)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 32)); 
      returnObject2.setPersonNameStandardInd(getString (rs, 33)); 
      returnObject.add (returnObject2);

      EObjXPersonNameExt returnObject3 = new EObjXPersonNameExt ();
      returnObject3.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject3.setHistActionCode(getString (rs, 2)); 
      returnObject3.setHistCreatedBy(getString (rs, 3)); 
      returnObject3.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject3.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject3.setLastUpdateDt(getTimestamp (rs, 21)); 
      returnObject3.setLastUpdateUser(getString (rs, 22)); 
      returnObject3.setLastUpdateTxId(getLongObject (rs, 23)); 
      returnObject3.setXLastModifiedSystemDate(getTimestamp (rs, 34)); 
      returnObject3.setXGivenNameOneLocal(getString (rs, 35)); 
      returnObject3.setXGivenNameTwoLocal(getString (rs, 36)); 
      returnObject3.setXLastNameLocal(getString (rs, 37)); 
      returnObject3.setXPersonNameRetailerFlag(getString (rs, 38)); 
      returnObject3.setX_BPID(getString (rs, 39)); 
      returnObject.add (returnObject3);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT PERSONNAME.PERSON_NAME_ID ,PERSONNAME.PREFIX_NAME_TP_CD ,PERSONNAME.PREFIX_DESC ,PERSONNAME.NAME_USAGE_TP_CD ,PERSONNAME.GIVEN_NAME_ONE ,PERSONNAME.GIVEN_NAME_TWO ,PERSONNAME.GIVEN_NAME_THREE ,PERSONNAME.GIVEN_NAME_FOUR ,PERSONNAME.LAST_NAME , PERSONNAME.GENERATION_TP_CD , PERSONNAME.SUFFIX_DESC ,PERSONNAME.START_DT ,PERSONNAME.END_DT ,PERSONNAME.CONT_ID ,PERSONNAME.USE_STANDARD_IND ,PERSONNAME.LAST_UPDATE_DT ,PERSONNAME.LAST_UPDATE_USER , PERSONNAME.LAST_UPDATE_TX_ID , PERSONNAME.LAST_USED_DT , PERSONNAME.LAST_VERIFIED_DT , PERSONNAME.SOURCE_IDENT_TP_CD , PERSONSEARCH.GIVEN_NAME_ONE ,PERSONSEARCH.GIVEN_NAME_TWO ,PERSONSEARCH.GIVEN_NAME_THREE ,PERSONSEARCH.GIVEN_NAME_FOUR ,PERSONSEARCH.LAST_NAME , PERSONSEARCH.LAST_UPDATE_TX_ID, PERSONSEARCH.STANDARD_IND, PERSONNAME.XMODIFY_SYS_DT, PERSONNAME.XGIVEN_NAME_ONE_LOCAL, PERSONNAME.XGIVEN_NAME_TWO_LOCAL, PERSONNAME.XLAST_NAME_LOCAL, PERSONNAME.XPERSONNAME_RETAILER_FLAG, PERSONNAME.X_BPID FROM PERSONNAME , PERSONSEARCH WHERE PERSONNAME.CONT_ID = ? AND (PERSONNAME.NAME_USAGE_TP_CD = ?) AND (PERSONNAME.END_DT IS NULL OR PERSONNAME.END_DT> ? ) AND PERSONNAME.PERSON_NAME_ID = PERSONSEARCH.PERSON_NAME_ID", pattern="tableAlias (PERSONNAME => com.dwl.tcrm.coreParty.entityObject.EObjPersonName, H_PERSONNAME => com.dwl.tcrm.coreParty.entityObject.EObjPersonName, PERSONSEARCH => com.dwl.tcrm.coreParty.entityObject.EObjPersonSearch, H_PERSONSEARCH => com.dwl.tcrm.coreParty.entityObject.EObjPersonSearch , PERSONNAME => com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt , H_PERSONNAME => com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue3<EObjPersonName,EObjPersonSearch,EObjXPersonNameExt>> getPersonNameWithType (Object[] parameters)
  {
    return queryIterator (getPersonNameWithTypeStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getPersonNameWithTypeStatementDescriptor = createStatementDescriptor (
    "getPersonNameWithType(Object[])",
    "SELECT PERSONNAME.PERSON_NAME_ID ,PERSONNAME.PREFIX_NAME_TP_CD ,PERSONNAME.PREFIX_DESC ,PERSONNAME.NAME_USAGE_TP_CD ,PERSONNAME.GIVEN_NAME_ONE ,PERSONNAME.GIVEN_NAME_TWO ,PERSONNAME.GIVEN_NAME_THREE ,PERSONNAME.GIVEN_NAME_FOUR ,PERSONNAME.LAST_NAME , PERSONNAME.GENERATION_TP_CD , PERSONNAME.SUFFIX_DESC ,PERSONNAME.START_DT ,PERSONNAME.END_DT ,PERSONNAME.CONT_ID ,PERSONNAME.USE_STANDARD_IND ,PERSONNAME.LAST_UPDATE_DT ,PERSONNAME.LAST_UPDATE_USER , PERSONNAME.LAST_UPDATE_TX_ID , PERSONNAME.LAST_USED_DT , PERSONNAME.LAST_VERIFIED_DT , PERSONNAME.SOURCE_IDENT_TP_CD , PERSONSEARCH.GIVEN_NAME_ONE ,PERSONSEARCH.GIVEN_NAME_TWO ,PERSONSEARCH.GIVEN_NAME_THREE ,PERSONSEARCH.GIVEN_NAME_FOUR ,PERSONSEARCH.LAST_NAME , PERSONSEARCH.LAST_UPDATE_TX_ID, PERSONSEARCH.STANDARD_IND, PERSONNAME.XMODIFY_SYS_DT, PERSONNAME.XGIVEN_NAME_ONE_LOCAL, PERSONNAME.XGIVEN_NAME_TWO_LOCAL, PERSONNAME.XLAST_NAME_LOCAL, PERSONNAME.XPERSONNAME_RETAILER_FLAG, PERSONNAME.X_BPID FROM PERSONNAME , PERSONSEARCH WHERE PERSONNAME.CONT_ID = ? AND (PERSONNAME.NAME_USAGE_TP_CD = ?) AND (PERSONNAME.END_DT IS NULL OR PERSONNAME.END_DT> ? ) AND PERSONNAME.PERSON_NAME_ID = PERSONSEARCH.PERSON_NAME_ID",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"person_name_id", "prefix_name_tp_cd", "prefix_desc", "name_usage_tp_cd", "given_name_one", "given_name_two", "given_name_three", "given_name_four", "last_name", "generation_tp_cd", "suffix_desc", "start_dt", "end_dt", "cont_id", "use_standard_ind", "last_update_dt", "last_update_user", "last_update_tx_id", "last_used_dt", "last_verified_dt", "source_ident_tp_cd", "given_name_one", "given_name_two", "given_name_three", "given_name_four", "last_name", "last_update_tx_id", "standard_ind", "xmodify_sys_dt", "xgiven_name_one_local", "xgiven_name_two_local", "xlast_name_local", "xpersonname_retailer_flag", "x_bpid"},
    new GetPersonNameWithTypeParameterHandler (),
    new int[][]{{Types.BIGINT, Types.BIGINT, Types.TIMESTAMP}, {19, 19, 0}, {0, 0, 0}, {1, 1, 1}},
    null,
    new GetPersonNameWithTypeRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.CHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.CHAR, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR}, {19, 19, 20, 19, 25, 25, 25, 25, 30, 19, 20, 0, 0, 19, 1, 0, 20, 19, 0, 0, 19, 25, 25, 25, 25, 30, 19, 1, 0, 500, 500, 500, 10, 50}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    6);

  /**
   * @generated
   */
  public static class GetPersonNameWithTypeParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.BIGINT, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetPersonNameWithTypeRowHandler extends BaseRowHandler<ResultQueue3<EObjPersonName,EObjPersonSearch,EObjXPersonNameExt>>
  {
    /**
     * @generated
     */
    public ResultQueue3<EObjPersonName,EObjPersonSearch,EObjXPersonNameExt> handle (java.sql.ResultSet rs, ResultQueue3<EObjPersonName,EObjPersonSearch,EObjXPersonNameExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue3<EObjPersonName,EObjPersonSearch,EObjXPersonNameExt> ();

      EObjPersonName returnObject1 = new EObjPersonName ();
      returnObject1.setPersonNameIdPK(getLongObject (rs, 1)); 
      returnObject1.setPrefixNameTpCd(getLongObject (rs, 2)); 
      returnObject1.setPrefixDesc(getString (rs, 3)); 
      returnObject1.setNameUsageTpCd(getLongObject (rs, 4)); 
      returnObject1.setGivenNameOne(getString (rs, 5)); 
      returnObject1.setGivenNameTwo(getString (rs, 6)); 
      returnObject1.setGivenNameThree(getString (rs, 7)); 
      returnObject1.setGivenNameFour(getString (rs, 8)); 
      returnObject1.setLastName(getString (rs, 9)); 
      returnObject1.setGenerationTpCd(getLongObject (rs, 10)); 
      returnObject1.setSuffixDesc(getString (rs, 11)); 
      returnObject1.setStartDt(getTimestamp (rs, 12)); 
      returnObject1.setEndDt(getTimestamp (rs, 13)); 
      returnObject1.setContId(getLongObject (rs, 14)); 
      returnObject1.setUseStandardInd(getString (rs, 15)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 16)); 
      returnObject1.setLastUpdateUser(getString (rs, 17)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 18)); 
      returnObject1.setLastUsedDt(getTimestamp (rs, 19)); 
      returnObject1.setLastVerifiedDt(getTimestamp (rs, 20)); 
      returnObject1.setSourceIdentTpCd(getLongObject (rs, 21)); 
      returnObject.add (returnObject1);

      EObjPersonSearch returnObject2 = new EObjPersonSearch ();
      returnObject2.setGivenNameOne(getString (rs, 22)); 
      returnObject2.setGivenNameTwo(getString (rs, 23)); 
      returnObject2.setGivenNameThree(getString (rs, 24)); 
      returnObject2.setGivenNameFour(getString (rs, 25)); 
      returnObject2.setLastName(getString (rs, 26)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 27)); 
      returnObject2.setPersonNameStandardInd(getString (rs, 28)); 
      returnObject.add (returnObject2);

      EObjXPersonNameExt returnObject3 = new EObjXPersonNameExt ();
      returnObject3.setLastUpdateDt(getTimestamp (rs, 16)); 
      returnObject3.setLastUpdateUser(getString (rs, 17)); 
      returnObject3.setLastUpdateTxId(getLongObject (rs, 18)); 
      returnObject3.setXLastModifiedSystemDate(getTimestamp (rs, 29)); 
      returnObject3.setXGivenNameOneLocal(getString (rs, 30)); 
      returnObject3.setXGivenNameTwoLocal(getString (rs, 31)); 
      returnObject3.setXLastNameLocal(getString (rs, 32)); 
      returnObject3.setXPersonNameRetailerFlag(getString (rs, 33)); 
      returnObject3.setX_BPID(getString (rs, 34)); 
      returnObject.add (returnObject3);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT PERSONNAME.PERSON_NAME_ID , PERSONNAME.PREFIX_NAME_TP_CD , PERSONNAME.PREFIX_DESC , PERSONNAME.NAME_USAGE_TP_CD , PERSONNAME.GIVEN_NAME_ONE , PERSONNAME.GIVEN_NAME_TWO , PERSONNAME.GIVEN_NAME_THREE , PERSONNAME.GIVEN_NAME_FOUR , PERSONNAME.LAST_NAME , PERSONNAME.GENERATION_TP_CD , PERSONNAME.SUFFIX_DESC , PERSONNAME.START_DT , PERSONNAME.END_DT , PERSONNAME.CONT_ID , PERSONNAME.USE_STANDARD_IND , PERSONNAME.LAST_UPDATE_DT , PERSONNAME.LAST_UPDATE_USER , PERSONNAME.LAST_USED_DT , PERSONNAME.LAST_VERIFIED_DT , PERSONNAME.SOURCE_IDENT_TP_CD , PERSONNAME.LAST_USED_DT , PERSONNAME.LAST_VERIFIED_DT , PERSONNAME.SOURCE_IDENT_TP_CD , PERSONSEARCH.GIVEN_NAME_ONE , PERSONSEARCH.GIVEN_NAME_TWO , PERSONSEARCH.GIVEN_NAME_THREE , PERSONSEARCH.GIVEN_NAME_FOUR , PERSONSEARCH.LAST_NAME , PERSONNAME.LAST_UPDATE_TX_ID, PERSONSEARCH.STANDARD_IND, PERSONNAME.XMODIFY_SYS_DT, PERSONNAME.XGIVEN_NAME_ONE_LOCAL, PERSONNAME.XGIVEN_NAME_TWO_LOCAL, PERSONNAME.XLAST_NAME_LOCAL, PERSONNAME.XPERSONNAME_RETAILER_FLAG, PERSONNAME.X_BPID FROM PERSONNAME , PERSONSEARCH WHERE PERSONNAME.PERSON_NAME_ID = ? AND PERSONNAME.PERSON_NAME_ID = PERSONSEARCH.PERSON_NAME_ID", pattern="tableAlias (PERSONNAME => com.dwl.tcrm.coreParty.entityObject.EObjPersonName, H_PERSONNAME => com.dwl.tcrm.coreParty.entityObject.EObjPersonName, PERSONSEARCH => com.dwl.tcrm.coreParty.entityObject.EObjPersonSearch, H_PERSONSEARCH => com.dwl.tcrm.coreParty.entityObject.EObjPersonSearch , PERSONNAME => com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt , H_PERSONNAME => com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue3<EObjPersonName,EObjPersonSearch,EObjXPersonNameExt>> getPersonNameByID (Object[] parameters)
  {
    return queryIterator (getPersonNameByIDStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getPersonNameByIDStatementDescriptor = createStatementDescriptor (
    "getPersonNameByID(Object[])",
    "SELECT PERSONNAME.PERSON_NAME_ID , PERSONNAME.PREFIX_NAME_TP_CD , PERSONNAME.PREFIX_DESC , PERSONNAME.NAME_USAGE_TP_CD , PERSONNAME.GIVEN_NAME_ONE , PERSONNAME.GIVEN_NAME_TWO , PERSONNAME.GIVEN_NAME_THREE , PERSONNAME.GIVEN_NAME_FOUR , PERSONNAME.LAST_NAME , PERSONNAME.GENERATION_TP_CD , PERSONNAME.SUFFIX_DESC , PERSONNAME.START_DT , PERSONNAME.END_DT , PERSONNAME.CONT_ID , PERSONNAME.USE_STANDARD_IND , PERSONNAME.LAST_UPDATE_DT , PERSONNAME.LAST_UPDATE_USER , PERSONNAME.LAST_USED_DT , PERSONNAME.LAST_VERIFIED_DT , PERSONNAME.SOURCE_IDENT_TP_CD , PERSONNAME.LAST_USED_DT , PERSONNAME.LAST_VERIFIED_DT , PERSONNAME.SOURCE_IDENT_TP_CD , PERSONSEARCH.GIVEN_NAME_ONE , PERSONSEARCH.GIVEN_NAME_TWO , PERSONSEARCH.GIVEN_NAME_THREE , PERSONSEARCH.GIVEN_NAME_FOUR , PERSONSEARCH.LAST_NAME , PERSONNAME.LAST_UPDATE_TX_ID, PERSONSEARCH.STANDARD_IND, PERSONNAME.XMODIFY_SYS_DT, PERSONNAME.XGIVEN_NAME_ONE_LOCAL, PERSONNAME.XGIVEN_NAME_TWO_LOCAL, PERSONNAME.XLAST_NAME_LOCAL, PERSONNAME.XPERSONNAME_RETAILER_FLAG, PERSONNAME.X_BPID FROM PERSONNAME , PERSONSEARCH WHERE PERSONNAME.PERSON_NAME_ID = ? AND PERSONNAME.PERSON_NAME_ID = PERSONSEARCH.PERSON_NAME_ID",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"person_name_id", "prefix_name_tp_cd", "prefix_desc", "name_usage_tp_cd", "given_name_one", "given_name_two", "given_name_three", "given_name_four", "last_name", "generation_tp_cd", "suffix_desc", "start_dt", "end_dt", "cont_id", "use_standard_ind", "last_update_dt", "last_update_user", "last_used_dt", "last_verified_dt", "source_ident_tp_cd", "last_used_dt", "last_verified_dt", "source_ident_tp_cd", "given_name_one", "given_name_two", "given_name_three", "given_name_four", "last_name", "last_update_tx_id", "standard_ind", "xmodify_sys_dt", "xgiven_name_one_local", "xgiven_name_two_local", "xlast_name_local", "xpersonname_retailer_flag", "x_bpid"},
    new GetPersonNameByIDParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetPersonNameByIDRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.CHAR, Types.TIMESTAMP, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.CHAR, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR}, {19, 19, 20, 19, 25, 25, 25, 25, 30, 19, 20, 0, 0, 19, 1, 0, 20, 0, 0, 19, 0, 0, 19, 25, 25, 25, 25, 30, 19, 1, 0, 500, 500, 500, 10, 50}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    7);

  /**
   * @generated
   */
  public static class GetPersonNameByIDParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetPersonNameByIDRowHandler extends BaseRowHandler<ResultQueue3<EObjPersonName,EObjPersonSearch,EObjXPersonNameExt>>
  {
    /**
     * @generated
     */
    public ResultQueue3<EObjPersonName,EObjPersonSearch,EObjXPersonNameExt> handle (java.sql.ResultSet rs, ResultQueue3<EObjPersonName,EObjPersonSearch,EObjXPersonNameExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue3<EObjPersonName,EObjPersonSearch,EObjXPersonNameExt> ();

      EObjPersonName returnObject1 = new EObjPersonName ();
      returnObject1.setPersonNameIdPK(getLongObject (rs, 1)); 
      returnObject1.setPrefixNameTpCd(getLongObject (rs, 2)); 
      returnObject1.setPrefixDesc(getString (rs, 3)); 
      returnObject1.setNameUsageTpCd(getLongObject (rs, 4)); 
      returnObject1.setGivenNameOne(getString (rs, 5)); 
      returnObject1.setGivenNameTwo(getString (rs, 6)); 
      returnObject1.setGivenNameThree(getString (rs, 7)); 
      returnObject1.setGivenNameFour(getString (rs, 8)); 
      returnObject1.setLastName(getString (rs, 9)); 
      returnObject1.setGenerationTpCd(getLongObject (rs, 10)); 
      returnObject1.setSuffixDesc(getString (rs, 11)); 
      returnObject1.setStartDt(getTimestamp (rs, 12)); 
      returnObject1.setEndDt(getTimestamp (rs, 13)); 
      returnObject1.setContId(getLongObject (rs, 14)); 
      returnObject1.setUseStandardInd(getString (rs, 15)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 16)); 
      returnObject1.setLastUpdateUser(getString (rs, 17)); 
      returnObject1.setLastUsedDt(getTimestamp (rs, 18)); 
      returnObject1.setLastVerifiedDt(getTimestamp (rs, 19)); 
      returnObject1.setSourceIdentTpCd(getLongObject (rs, 20)); 
      returnObject1.setLastUsedDt(getTimestamp (rs, 21)); 
      returnObject1.setLastVerifiedDt(getTimestamp (rs, 22)); 
      returnObject1.setSourceIdentTpCd(getLongObject (rs, 23)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 29)); 
      returnObject.add (returnObject1);

      EObjPersonSearch returnObject2 = new EObjPersonSearch ();
      returnObject2.setGivenNameOne(getString (rs, 24)); 
      returnObject2.setGivenNameTwo(getString (rs, 25)); 
      returnObject2.setGivenNameThree(getString (rs, 26)); 
      returnObject2.setGivenNameFour(getString (rs, 27)); 
      returnObject2.setLastName(getString (rs, 28)); 
      returnObject2.setPersonNameStandardInd(getString (rs, 30)); 
      returnObject.add (returnObject2);

      EObjXPersonNameExt returnObject3 = new EObjXPersonNameExt ();
      returnObject3.setLastUpdateDt(getTimestamp (rs, 16)); 
      returnObject3.setLastUpdateUser(getString (rs, 17)); 
      returnObject3.setLastUpdateTxId(getLongObject (rs, 29)); 
      returnObject3.setXLastModifiedSystemDate(getTimestamp (rs, 31)); 
      returnObject3.setXGivenNameOneLocal(getString (rs, 32)); 
      returnObject3.setXGivenNameTwoLocal(getString (rs, 33)); 
      returnObject3.setXLastNameLocal(getString (rs, 34)); 
      returnObject3.setXPersonNameRetailerFlag(getString (rs, 35)); 
      returnObject3.setX_BPID(getString (rs, 36)); 
      returnObject.add (returnObject3);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT H_PERSONNAME.H_PERSON_NAME_ID AS HIST_ID_PK, H_PERSONNAME.H_ACTION_CODE, H_PERSONNAME.H_CREATED_BY, H_PERSONNAME.H_CREATE_DT, H_PERSONNAME.PREFIX_NAME_TP_CD , H_PERSONNAME.PREFIX_DESC , H_PERSONNAME.NAME_USAGE_TP_CD , H_PERSONNAME.GIVEN_NAME_ONE , H_PERSONNAME.GIVEN_NAME_TWO , H_PERSONNAME.GIVEN_NAME_THREE , H_PERSONNAME.GIVEN_NAME_FOUR , H_PERSONNAME.LAST_NAME , H_PERSONNAME.GENERATION_TP_CD , H_PERSONNAME.SUFFIX_DESC , H_PERSONNAME.START_DT , H_PERSONNAME.END_DT , H_PERSONNAME.CONT_ID , H_PERSONNAME.USE_STANDARD_IND , H_PERSONNAME.LAST_UPDATE_DT , H_PERSONNAME.LAST_UPDATE_USER , H_PERSONNAME.LAST_USED_DT , H_PERSONNAME.LAST_VERIFIED_DT , H_PERSONNAME.SOURCE_IDENT_TP_CD , H_PERSONNAME.LAST_USED_DT , H_PERSONNAME.LAST_VERIFIED_DT , H_PERSONNAME.SOURCE_IDENT_TP_CD , H_PERSONSEARCH.GIVEN_NAME_ONE , H_PERSONSEARCH.GIVEN_NAME_TWO , H_PERSONSEARCH.GIVEN_NAME_THREE , H_PERSONSEARCH.GIVEN_NAME_FOUR , H_PERSONSEARCH.LAST_NAME , H_PERSONNAME.LAST_UPDATE_TX_ID, H_PERSONSEARCH.STANDARD_IND,H_PERSONNAME.PERSON_NAME_ID,H_PERSONNAME.H_END_DT, H_PERSONNAME.XMODIFY_SYS_DT, H_PERSONNAME.XGIVEN_NAME_ONE_LOCAL, H_PERSONNAME.XGIVEN_NAME_TWO_LOCAL, H_PERSONNAME.XLAST_NAME_LOCAL, H_PERSONNAME.XPERSONNAME_RETAILER_FLAG, H_PERSONNAME.X_BPID FROM H_PERSONNAME , H_PERSONSEARCH WHERE H_PERSONNAME.H_PERSON_NAME_ID = ? AND H_PERSONNAME.H_PERSON_NAME_ID = H_PERSONSEARCH.PERSON_NAME_ID AND (( ? BETWEEN H_PERSONNAME.H_CREATE_DT AND H_PERSONNAME.H_END_DT ) OR ( ? >= H_PERSONNAME.H_CREATE_DT AND H_PERSONNAME.H_END_DT IS NULL )) AND (( ? BETWEEN H_PERSONSEARCH.H_CREATE_DT AND H_PERSONSEARCH.H_END_DT ) OR ( ? >= H_PERSONSEARCH.H_CREATE_DT AND H_PERSONSEARCH.H_END_DT IS NULL ))", pattern="tableAlias (PERSONNAME => com.dwl.tcrm.coreParty.entityObject.EObjPersonName, H_PERSONNAME => com.dwl.tcrm.coreParty.entityObject.EObjPersonName, PERSONSEARCH => com.dwl.tcrm.coreParty.entityObject.EObjPersonSearch, H_PERSONSEARCH => com.dwl.tcrm.coreParty.entityObject.EObjPersonSearch , PERSONNAME => com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt , H_PERSONNAME => com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue3<EObjPersonName,EObjPersonSearch,EObjXPersonNameExt>> getPersonNameByIDHistory (Object[] parameters)
  {
    return queryIterator (getPersonNameByIDHistoryStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getPersonNameByIDHistoryStatementDescriptor = createStatementDescriptor (
    "getPersonNameByIDHistory(Object[])",
    "SELECT H_PERSONNAME.H_PERSON_NAME_ID AS HIST_ID_PK, H_PERSONNAME.H_ACTION_CODE, H_PERSONNAME.H_CREATED_BY, H_PERSONNAME.H_CREATE_DT, H_PERSONNAME.PREFIX_NAME_TP_CD , H_PERSONNAME.PREFIX_DESC , H_PERSONNAME.NAME_USAGE_TP_CD , H_PERSONNAME.GIVEN_NAME_ONE , H_PERSONNAME.GIVEN_NAME_TWO , H_PERSONNAME.GIVEN_NAME_THREE , H_PERSONNAME.GIVEN_NAME_FOUR , H_PERSONNAME.LAST_NAME , H_PERSONNAME.GENERATION_TP_CD , H_PERSONNAME.SUFFIX_DESC , H_PERSONNAME.START_DT , H_PERSONNAME.END_DT , H_PERSONNAME.CONT_ID , H_PERSONNAME.USE_STANDARD_IND , H_PERSONNAME.LAST_UPDATE_DT , H_PERSONNAME.LAST_UPDATE_USER , H_PERSONNAME.LAST_USED_DT , H_PERSONNAME.LAST_VERIFIED_DT , H_PERSONNAME.SOURCE_IDENT_TP_CD , H_PERSONNAME.LAST_USED_DT , H_PERSONNAME.LAST_VERIFIED_DT , H_PERSONNAME.SOURCE_IDENT_TP_CD , H_PERSONSEARCH.GIVEN_NAME_ONE , H_PERSONSEARCH.GIVEN_NAME_TWO , H_PERSONSEARCH.GIVEN_NAME_THREE , H_PERSONSEARCH.GIVEN_NAME_FOUR , H_PERSONSEARCH.LAST_NAME , H_PERSONNAME.LAST_UPDATE_TX_ID, H_PERSONSEARCH.STANDARD_IND,H_PERSONNAME.PERSON_NAME_ID,H_PERSONNAME.H_END_DT, H_PERSONNAME.XMODIFY_SYS_DT, H_PERSONNAME.XGIVEN_NAME_ONE_LOCAL, H_PERSONNAME.XGIVEN_NAME_TWO_LOCAL, H_PERSONNAME.XLAST_NAME_LOCAL, H_PERSONNAME.XPERSONNAME_RETAILER_FLAG, H_PERSONNAME.X_BPID FROM H_PERSONNAME , H_PERSONSEARCH WHERE H_PERSONNAME.H_PERSON_NAME_ID = ? AND H_PERSONNAME.H_PERSON_NAME_ID = H_PERSONSEARCH.PERSON_NAME_ID AND (( ? BETWEEN H_PERSONNAME.H_CREATE_DT AND H_PERSONNAME.H_END_DT ) OR ( ? >= H_PERSONNAME.H_CREATE_DT AND H_PERSONNAME.H_END_DT IS NULL )) AND (( ? BETWEEN H_PERSONSEARCH.H_CREATE_DT AND H_PERSONSEARCH.H_END_DT ) OR ( ? >= H_PERSONSEARCH.H_CREATE_DT AND H_PERSONSEARCH.H_END_DT IS NULL ))",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"hist_id_pk", "h_action_code", "h_created_by", "h_create_dt", "prefix_name_tp_cd", "prefix_desc", "name_usage_tp_cd", "given_name_one", "given_name_two", "given_name_three", "given_name_four", "last_name", "generation_tp_cd", "suffix_desc", "start_dt", "end_dt", "cont_id", "use_standard_ind", "last_update_dt", "last_update_user", "last_used_dt", "last_verified_dt", "source_ident_tp_cd", "last_used_dt", "last_verified_dt", "source_ident_tp_cd", "given_name_one", "given_name_two", "given_name_three", "given_name_four", "last_name", "last_update_tx_id", "standard_ind", "person_name_id", "h_end_dt", "xmodify_sys_dt", "xgiven_name_one_local", "xgiven_name_two_local", "xlast_name_local", "xpersonname_retailer_flag", "x_bpid"},
    new GetPersonNameByIDHistoryParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP}, {19, 0, 0, 0, 0}, {0, 0, 0, 0, 0}, {1, 1, 1, 1, 1}},
    null,
    new GetPersonNameByIDHistoryRowHandler (),
    new int[][]{ {Types.BIGINT, Types.CHAR, Types.VARCHAR, Types.TIMESTAMP, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.CHAR, Types.TIMESTAMP, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.CHAR, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR}, {19, 1, 20, 0, 19, 20, 19, 25, 25, 25, 25, 30, 19, 20, 0, 0, 19, 1, 0, 20, 0, 0, 19, 0, 0, 19, 25, 25, 25, 25, 30, 19, 1, 19, 0, 0, 500, 500, 500, 10, 50}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    8);

  /**
   * @generated
   */
  public static class GetPersonNameByIDHistoryParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
      setObject (stmt, 4, Types.TIMESTAMP, parameters[3], 0);
      setObject (stmt, 5, Types.TIMESTAMP, parameters[4], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetPersonNameByIDHistoryRowHandler extends BaseRowHandler<ResultQueue3<EObjPersonName,EObjPersonSearch,EObjXPersonNameExt>>
  {
    /**
     * @generated
     */
    public ResultQueue3<EObjPersonName,EObjPersonSearch,EObjXPersonNameExt> handle (java.sql.ResultSet rs, ResultQueue3<EObjPersonName,EObjPersonSearch,EObjXPersonNameExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue3<EObjPersonName,EObjPersonSearch,EObjXPersonNameExt> ();

      EObjPersonName returnObject1 = new EObjPersonName ();
      returnObject1.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject1.setHistActionCode(getString (rs, 2)); 
      returnObject1.setHistCreatedBy(getString (rs, 3)); 
      returnObject1.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject1.setPrefixNameTpCd(getLongObject (rs, 5)); 
      returnObject1.setPrefixDesc(getString (rs, 6)); 
      returnObject1.setNameUsageTpCd(getLongObject (rs, 7)); 
      returnObject1.setGivenNameOne(getString (rs, 8)); 
      returnObject1.setGivenNameTwo(getString (rs, 9)); 
      returnObject1.setGivenNameThree(getString (rs, 10)); 
      returnObject1.setGivenNameFour(getString (rs, 11)); 
      returnObject1.setLastName(getString (rs, 12)); 
      returnObject1.setGenerationTpCd(getLongObject (rs, 13)); 
      returnObject1.setSuffixDesc(getString (rs, 14)); 
      returnObject1.setStartDt(getTimestamp (rs, 15)); 
      returnObject1.setEndDt(getTimestamp (rs, 16)); 
      returnObject1.setContId(getLongObject (rs, 17)); 
      returnObject1.setUseStandardInd(getString (rs, 18)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 19)); 
      returnObject1.setLastUpdateUser(getString (rs, 20)); 
      returnObject1.setLastUsedDt(getTimestamp (rs, 21)); 
      returnObject1.setLastVerifiedDt(getTimestamp (rs, 22)); 
      returnObject1.setSourceIdentTpCd(getLongObject (rs, 23)); 
      returnObject1.setLastUsedDt(getTimestamp (rs, 24)); 
      returnObject1.setLastVerifiedDt(getTimestamp (rs, 25)); 
      returnObject1.setSourceIdentTpCd(getLongObject (rs, 26)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 32)); 
      returnObject1.setPersonNameIdPK(getLongObject (rs, 34)); 
      returnObject1.setHistEndDt(getTimestamp (rs, 35)); 
      returnObject.add (returnObject1);

      EObjPersonSearch returnObject2 = new EObjPersonSearch ();
      returnObject2.setGivenNameOne(getString (rs, 27)); 
      returnObject2.setGivenNameTwo(getString (rs, 28)); 
      returnObject2.setGivenNameThree(getString (rs, 29)); 
      returnObject2.setGivenNameFour(getString (rs, 30)); 
      returnObject2.setLastName(getString (rs, 31)); 
      returnObject2.setPersonNameStandardInd(getString (rs, 33)); 
      returnObject.add (returnObject2);

      EObjXPersonNameExt returnObject3 = new EObjXPersonNameExt ();
      returnObject3.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject3.setHistActionCode(getString (rs, 2)); 
      returnObject3.setHistCreatedBy(getString (rs, 3)); 
      returnObject3.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject3.setLastUpdateDt(getTimestamp (rs, 19)); 
      returnObject3.setLastUpdateUser(getString (rs, 20)); 
      returnObject3.setLastUpdateTxId(getLongObject (rs, 32)); 
      returnObject3.setHistEndDt(getTimestamp (rs, 35)); 
      returnObject3.setXLastModifiedSystemDate(getTimestamp (rs, 36)); 
      returnObject3.setXGivenNameOneLocal(getString (rs, 37)); 
      returnObject3.setXGivenNameTwoLocal(getString (rs, 38)); 
      returnObject3.setXLastNameLocal(getString (rs, 39)); 
      returnObject3.setXPersonNameRetailerFlag(getString (rs, 40)); 
      returnObject3.setX_BPID(getString (rs, 41)); 
      returnObject.add (returnObject3);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT DISTINCT A.H_PERSON_NAME_ID AS HIST_ID_PK , A.H_ACTION_CODE , A.H_CREATED_BY , A.H_CREATE_DT , A.H_END_DT , A.PERSON_NAME_ID , A.PREFIX_NAME_TP_CD , A.PREFIX_DESC , A.NAME_USAGE_TP_CD , A.GIVEN_NAME_ONE , A.GIVEN_NAME_TWO , A.GIVEN_NAME_THREE , A.GIVEN_NAME_FOUR , A.LAST_NAME , A.GENERATION_TP_CD , A.SUFFIX_DESC , A.START_DT , A.END_DT , A.CONT_ID , A.USE_STANDARD_IND , A.LAST_UPDATE_DT , A.LAST_UPDATE_USER , A.LAST_UPDATE_TX_ID , A.LAST_USED_DT , A.LAST_VERIFIED_DT , A.SOURCE_IDENT_TP_CD, A.XMODIFY_SYS_DT, A.XGIVEN_NAME_ONE_LOCAL, A.XGIVEN_NAME_TWO_LOCAL, A.XLAST_NAME_LOCAL, A.XPERSONNAME_RETAILER_FLAG, A.X_BPID FROM H_PERSONNAME A WHERE A.CONT_ID = ? AND ( A.H_CREATE_DT BETWEEN ? AND ?)", pattern="tableAlias (PERSONNAME => com.dwl.tcrm.coreParty.entityObject.EObjPersonName, H_PERSONNAME => com.dwl.tcrm.coreParty.entityObject.EObjPersonName, PERSONSEARCH => com.dwl.tcrm.coreParty.entityObject.EObjPersonSearch, H_PERSONSEARCH => com.dwl.tcrm.coreParty.entityObject.EObjPersonSearch , PERSONNAME => com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt , H_PERSONNAME => com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue2<EObjPersonName,EObjXPersonNameExt>> getPersonNameImages (Object[] parameters)
  {
    return queryIterator (getPersonNameImagesStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getPersonNameImagesStatementDescriptor = createStatementDescriptor (
    "getPersonNameImages(Object[])",
    "SELECT DISTINCT A.H_PERSON_NAME_ID AS HIST_ID_PK , A.H_ACTION_CODE , A.H_CREATED_BY , A.H_CREATE_DT , A.H_END_DT , A.PERSON_NAME_ID , A.PREFIX_NAME_TP_CD , A.PREFIX_DESC , A.NAME_USAGE_TP_CD , A.GIVEN_NAME_ONE , A.GIVEN_NAME_TWO , A.GIVEN_NAME_THREE , A.GIVEN_NAME_FOUR , A.LAST_NAME , A.GENERATION_TP_CD , A.SUFFIX_DESC , A.START_DT , A.END_DT , A.CONT_ID , A.USE_STANDARD_IND , A.LAST_UPDATE_DT , A.LAST_UPDATE_USER , A.LAST_UPDATE_TX_ID , A.LAST_USED_DT , A.LAST_VERIFIED_DT , A.SOURCE_IDENT_TP_CD, A.XMODIFY_SYS_DT, A.XGIVEN_NAME_ONE_LOCAL, A.XGIVEN_NAME_TWO_LOCAL, A.XLAST_NAME_LOCAL, A.XPERSONNAME_RETAILER_FLAG, A.X_BPID FROM H_PERSONNAME A WHERE A.CONT_ID = ? AND ( A.H_CREATE_DT BETWEEN ? AND ?)",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"hist_id_pk", "h_action_code", "h_created_by", "h_create_dt", "h_end_dt", "person_name_id", "prefix_name_tp_cd", "prefix_desc", "name_usage_tp_cd", "given_name_one", "given_name_two", "given_name_three", "given_name_four", "last_name", "generation_tp_cd", "suffix_desc", "start_dt", "end_dt", "cont_id", "use_standard_ind", "last_update_dt", "last_update_user", "last_update_tx_id", "last_used_dt", "last_verified_dt", "source_ident_tp_cd", "xmodify_sys_dt", "xgiven_name_one_local", "xgiven_name_two_local", "xlast_name_local", "xpersonname_retailer_flag", "x_bpid"},
    new GetPersonNameImagesParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP}, {19, 0, 0}, {0, 0, 0}, {1, 1, 1}},
    null,
    new GetPersonNameImagesRowHandler (),
    new int[][]{ {Types.BIGINT, Types.CHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.CHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR}, {19, 1, 20, 0, 0, 19, 19, 20, 19, 25, 25, 25, 25, 30, 19, 20, 0, 0, 19, 1, 0, 20, 19, 0, 0, 19, 0, 500, 500, 500, 10, 50}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    9);

  /**
   * @generated
   */
  public static class GetPersonNameImagesParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetPersonNameImagesRowHandler extends BaseRowHandler<ResultQueue2<EObjPersonName,EObjXPersonNameExt>>
  {
    /**
     * @generated
     */
    public ResultQueue2<EObjPersonName,EObjXPersonNameExt> handle (java.sql.ResultSet rs, ResultQueue2<EObjPersonName,EObjXPersonNameExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue2<EObjPersonName,EObjXPersonNameExt> ();

      EObjPersonName returnObject1 = new EObjPersonName ();
      returnObject1.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject1.setHistActionCode(getString (rs, 2)); 
      returnObject1.setHistCreatedBy(getString (rs, 3)); 
      returnObject1.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject1.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject1.setPersonNameIdPK(getLongObject (rs, 6)); 
      returnObject1.setPrefixNameTpCd(getLongObject (rs, 7)); 
      returnObject1.setPrefixDesc(getString (rs, 8)); 
      returnObject1.setNameUsageTpCd(getLongObject (rs, 9)); 
      returnObject1.setGivenNameOne(getString (rs, 10)); 
      returnObject1.setGivenNameTwo(getString (rs, 11)); 
      returnObject1.setGivenNameThree(getString (rs, 12)); 
      returnObject1.setGivenNameFour(getString (rs, 13)); 
      returnObject1.setLastName(getString (rs, 14)); 
      returnObject1.setGenerationTpCd(getLongObject (rs, 15)); 
      returnObject1.setSuffixDesc(getString (rs, 16)); 
      returnObject1.setStartDt(getTimestamp (rs, 17)); 
      returnObject1.setEndDt(getTimestamp (rs, 18)); 
      returnObject1.setContId(getLongObject (rs, 19)); 
      returnObject1.setUseStandardInd(getString (rs, 20)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 21)); 
      returnObject1.setLastUpdateUser(getString (rs, 22)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 23)); 
      returnObject1.setLastUsedDt(getTimestamp (rs, 24)); 
      returnObject1.setLastVerifiedDt(getTimestamp (rs, 25)); 
      returnObject1.setSourceIdentTpCd(getLongObject (rs, 26)); 
      returnObject.add (returnObject1);

      EObjXPersonNameExt returnObject2 = new EObjXPersonNameExt ();
      returnObject2.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject2.setHistActionCode(getString (rs, 2)); 
      returnObject2.setHistCreatedBy(getString (rs, 3)); 
      returnObject2.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject2.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject2.setLastUpdateDt(getTimestamp (rs, 21)); 
      returnObject2.setLastUpdateUser(getString (rs, 22)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 23)); 
      returnObject2.setXLastModifiedSystemDate(getTimestamp (rs, 27)); 
      returnObject2.setXGivenNameOneLocal(getString (rs, 28)); 
      returnObject2.setXGivenNameTwoLocal(getString (rs, 29)); 
      returnObject2.setXLastNameLocal(getString (rs, 30)); 
      returnObject2.setXPersonNameRetailerFlag(getString (rs, 31)); 
      returnObject2.setX_BPID(getString (rs, 32)); 
      returnObject.add (returnObject2);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT DISTINCT A.PERSON_NAME_ID , A.LAST_UPDATE_DT, A.XMODIFY_SYS_DT, A.XGIVEN_NAME_ONE_LOCAL, A.XGIVEN_NAME_TWO_LOCAL, A.XLAST_NAME_LOCAL, A.XPERSONNAME_RETAILER_FLAG, A.X_BPID FROM H_PERSONNAME A WHERE A.CONT_ID = ? AND ( A.H_CREATE_DT BETWEEN ? AND ?)", pattern="tableAlias (PERSONNAME => com.dwl.tcrm.coreParty.entityObject.EObjPersonName, H_PERSONNAME => com.dwl.tcrm.coreParty.entityObject.EObjPersonName, PERSONSEARCH => com.dwl.tcrm.coreParty.entityObject.EObjPersonSearch, H_PERSONSEARCH => com.dwl.tcrm.coreParty.entityObject.EObjPersonSearch , PERSONNAME => com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt , H_PERSONNAME => com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue2<EObjPersonName,EObjXPersonNameExt>> getPersonNameLightImages (Object[] parameters)
  {
    return queryIterator (getPersonNameLightImagesStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getPersonNameLightImagesStatementDescriptor = createStatementDescriptor (
    "getPersonNameLightImages(Object[])",
    "SELECT DISTINCT A.PERSON_NAME_ID , A.LAST_UPDATE_DT, A.XMODIFY_SYS_DT, A.XGIVEN_NAME_ONE_LOCAL, A.XGIVEN_NAME_TWO_LOCAL, A.XLAST_NAME_LOCAL, A.XPERSONNAME_RETAILER_FLAG, A.X_BPID FROM H_PERSONNAME A WHERE A.CONT_ID = ? AND ( A.H_CREATE_DT BETWEEN ? AND ?)",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"person_name_id", "last_update_dt", "xmodify_sys_dt", "xgiven_name_one_local", "xgiven_name_two_local", "xlast_name_local", "xpersonname_retailer_flag", "x_bpid"},
    new GetPersonNameLightImagesParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP}, {19, 0, 0}, {0, 0, 0}, {1, 1, 1}},
    null,
    new GetPersonNameLightImagesRowHandler (),
    new int[][]{ {Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR}, {19, 0, 0, 500, 500, 500, 10, 50}, {0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    10);

  /**
   * @generated
   */
  public static class GetPersonNameLightImagesParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetPersonNameLightImagesRowHandler extends BaseRowHandler<ResultQueue2<EObjPersonName,EObjXPersonNameExt>>
  {
    /**
     * @generated
     */
    public ResultQueue2<EObjPersonName,EObjXPersonNameExt> handle (java.sql.ResultSet rs, ResultQueue2<EObjPersonName,EObjXPersonNameExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue2<EObjPersonName,EObjXPersonNameExt> ();

      EObjPersonName returnObject1 = new EObjPersonName ();
      returnObject1.setPersonNameIdPK(getLongObject (rs, 1)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 2)); 
      returnObject.add (returnObject1);

      EObjXPersonNameExt returnObject2 = new EObjXPersonNameExt ();
      returnObject2.setLastUpdateDt(getTimestamp (rs, 2)); 
      returnObject2.setXLastModifiedSystemDate(getTimestamp (rs, 3)); 
      returnObject2.setXGivenNameOneLocal(getString (rs, 4)); 
      returnObject2.setXGivenNameTwoLocal(getString (rs, 5)); 
      returnObject2.setXLastNameLocal(getString (rs, 6)); 
      returnObject2.setXPersonNameRetailerFlag(getString (rs, 7)); 
      returnObject2.setX_BPID(getString (rs, 8)); 
      returnObject.add (returnObject2);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT DISTINCT A.H_PERSON_NAME_ID AS HIST_ID_PK , A.H_ACTION_CODE , A.H_CREATED_BY , A.H_CREATE_DT , A.H_END_DT , A.PERSON_NAME_ID , A.PREFIX_NAME_TP_CD , A.PREFIX_DESC , A.NAME_USAGE_TP_CD , A.GIVEN_NAME_ONE , A.GIVEN_NAME_TWO , A.GIVEN_NAME_THREE , A.GIVEN_NAME_FOUR , A.LAST_NAME , A.GENERATION_TP_CD , A.SUFFIX_DESC , A.START_DT , A.END_DT , A.CONT_ID , A.USE_STANDARD_IND , A.LAST_UPDATE_DT , A.LAST_UPDATE_USER , A.LAST_UPDATE_TX_ID , A.LAST_USED_DT , A.LAST_VERIFIED_DT , A.SOURCE_IDENT_TP_CD, A.XMODIFY_SYS_DT, A.XGIVEN_NAME_ONE_LOCAL, A.XGIVEN_NAME_TWO_LOCAL, A.XLAST_NAME_LOCAL, A.XPERSONNAME_RETAILER_FLAG, A.X_BPID FROM H_PERSONNAME A WHERE A.CONT_ID = ? AND (( ? BETWEEN A.H_CREATE_DT AND A.H_END_DT ) OR ( ? >= A.H_CREATE_DT AND A.H_END_DT IS NULL ))", pattern="tableAlias (PERSONNAME => com.dwl.tcrm.coreParty.entityObject.EObjPersonName, H_PERSONNAME => com.dwl.tcrm.coreParty.entityObject.EObjPersonName, PERSONSEARCH => com.dwl.tcrm.coreParty.entityObject.EObjPersonSearch, H_PERSONSEARCH => com.dwl.tcrm.coreParty.entityObject.EObjPersonSearch , PERSONNAME => com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt , H_PERSONNAME => com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue2<EObjPersonName,EObjXPersonNameExt>> getPersonNamesNotStandardizedHistory (Object[] parameters)
  {
    return queryIterator (getPersonNamesNotStandardizedHistoryStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getPersonNamesNotStandardizedHistoryStatementDescriptor = createStatementDescriptor (
    "getPersonNamesNotStandardizedHistory(Object[])",
    "SELECT DISTINCT A.H_PERSON_NAME_ID AS HIST_ID_PK , A.H_ACTION_CODE , A.H_CREATED_BY , A.H_CREATE_DT , A.H_END_DT , A.PERSON_NAME_ID , A.PREFIX_NAME_TP_CD , A.PREFIX_DESC , A.NAME_USAGE_TP_CD , A.GIVEN_NAME_ONE , A.GIVEN_NAME_TWO , A.GIVEN_NAME_THREE , A.GIVEN_NAME_FOUR , A.LAST_NAME , A.GENERATION_TP_CD , A.SUFFIX_DESC , A.START_DT , A.END_DT , A.CONT_ID , A.USE_STANDARD_IND , A.LAST_UPDATE_DT , A.LAST_UPDATE_USER , A.LAST_UPDATE_TX_ID , A.LAST_USED_DT , A.LAST_VERIFIED_DT , A.SOURCE_IDENT_TP_CD, A.XMODIFY_SYS_DT, A.XGIVEN_NAME_ONE_LOCAL, A.XGIVEN_NAME_TWO_LOCAL, A.XLAST_NAME_LOCAL, A.XPERSONNAME_RETAILER_FLAG, A.X_BPID FROM H_PERSONNAME A WHERE A.CONT_ID = ? AND (( ? BETWEEN A.H_CREATE_DT AND A.H_END_DT ) OR ( ? >= A.H_CREATE_DT AND A.H_END_DT IS NULL ))",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"hist_id_pk", "h_action_code", "h_created_by", "h_create_dt", "h_end_dt", "person_name_id", "prefix_name_tp_cd", "prefix_desc", "name_usage_tp_cd", "given_name_one", "given_name_two", "given_name_three", "given_name_four", "last_name", "generation_tp_cd", "suffix_desc", "start_dt", "end_dt", "cont_id", "use_standard_ind", "last_update_dt", "last_update_user", "last_update_tx_id", "last_used_dt", "last_verified_dt", "source_ident_tp_cd", "xmodify_sys_dt", "xgiven_name_one_local", "xgiven_name_two_local", "xlast_name_local", "xpersonname_retailer_flag", "x_bpid"},
    new GetPersonNamesNotStandardizedHistoryParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP}, {19, 0, 0}, {0, 0, 0}, {1, 1, 1}},
    null,
    new GetPersonNamesNotStandardizedHistoryRowHandler (),
    new int[][]{ {Types.BIGINT, Types.CHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.CHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR}, {19, 1, 20, 0, 0, 19, 19, 20, 19, 25, 25, 25, 25, 30, 19, 20, 0, 0, 19, 1, 0, 20, 19, 0, 0, 19, 0, 500, 500, 500, 10, 50}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    11);

  /**
   * @generated
   */
  public static class GetPersonNamesNotStandardizedHistoryParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetPersonNamesNotStandardizedHistoryRowHandler extends BaseRowHandler<ResultQueue2<EObjPersonName,EObjXPersonNameExt>>
  {
    /**
     * @generated
     */
    public ResultQueue2<EObjPersonName,EObjXPersonNameExt> handle (java.sql.ResultSet rs, ResultQueue2<EObjPersonName,EObjXPersonNameExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue2<EObjPersonName,EObjXPersonNameExt> ();

      EObjPersonName returnObject1 = new EObjPersonName ();
      returnObject1.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject1.setHistActionCode(getString (rs, 2)); 
      returnObject1.setHistCreatedBy(getString (rs, 3)); 
      returnObject1.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject1.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject1.setPersonNameIdPK(getLongObject (rs, 6)); 
      returnObject1.setPrefixNameTpCd(getLongObject (rs, 7)); 
      returnObject1.setPrefixDesc(getString (rs, 8)); 
      returnObject1.setNameUsageTpCd(getLongObject (rs, 9)); 
      returnObject1.setGivenNameOne(getString (rs, 10)); 
      returnObject1.setGivenNameTwo(getString (rs, 11)); 
      returnObject1.setGivenNameThree(getString (rs, 12)); 
      returnObject1.setGivenNameFour(getString (rs, 13)); 
      returnObject1.setLastName(getString (rs, 14)); 
      returnObject1.setGenerationTpCd(getLongObject (rs, 15)); 
      returnObject1.setSuffixDesc(getString (rs, 16)); 
      returnObject1.setStartDt(getTimestamp (rs, 17)); 
      returnObject1.setEndDt(getTimestamp (rs, 18)); 
      returnObject1.setContId(getLongObject (rs, 19)); 
      returnObject1.setUseStandardInd(getString (rs, 20)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 21)); 
      returnObject1.setLastUpdateUser(getString (rs, 22)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 23)); 
      returnObject1.setLastUsedDt(getTimestamp (rs, 24)); 
      returnObject1.setLastVerifiedDt(getTimestamp (rs, 25)); 
      returnObject1.setSourceIdentTpCd(getLongObject (rs, 26)); 
      returnObject.add (returnObject1);

      EObjXPersonNameExt returnObject2 = new EObjXPersonNameExt ();
      returnObject2.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject2.setHistActionCode(getString (rs, 2)); 
      returnObject2.setHistCreatedBy(getString (rs, 3)); 
      returnObject2.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject2.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject2.setLastUpdateDt(getTimestamp (rs, 21)); 
      returnObject2.setLastUpdateUser(getString (rs, 22)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 23)); 
      returnObject2.setXLastModifiedSystemDate(getTimestamp (rs, 27)); 
      returnObject2.setXGivenNameOneLocal(getString (rs, 28)); 
      returnObject2.setXGivenNameTwoLocal(getString (rs, 29)); 
      returnObject2.setXLastNameLocal(getString (rs, 30)); 
      returnObject2.setXPersonNameRetailerFlag(getString (rs, 31)); 
      returnObject2.setX_BPID(getString (rs, 32)); 
      returnObject.add (returnObject2);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT PERSONNAME.PERSON_NAME_ID , PERSONNAME.PREFIX_NAME_TP_CD , PERSONNAME.PREFIX_DESC , PERSONNAME.NAME_USAGE_TP_CD , PERSONNAME.GIVEN_NAME_ONE , PERSONNAME.GIVEN_NAME_TWO , PERSONNAME.GIVEN_NAME_THREE , PERSONNAME.GIVEN_NAME_FOUR , PERSONNAME.LAST_NAME , PERSONNAME.GENERATION_TP_CD , PERSONNAME.SUFFIX_DESC , PERSONNAME.START_DT , PERSONNAME.END_DT , PERSONNAME.CONT_ID , PERSONNAME.USE_STANDARD_IND , PERSONNAME.LAST_UPDATE_DT , PERSONNAME.LAST_UPDATE_USER , PERSONNAME.LAST_UPDATE_TX_ID , PERSONNAME.LAST_USED_DT , PERSONNAME.LAST_VERIFIED_DT , PERSONNAME.SOURCE_IDENT_TP_CD, PERSONNAME.XMODIFY_SYS_DT, PERSONNAME.XGIVEN_NAME_ONE_LOCAL, PERSONNAME.XGIVEN_NAME_TWO_LOCAL, PERSONNAME.XLAST_NAME_LOCAL, PERSONNAME.XPERSONNAME_RETAILER_FLAG, PERSONNAME.X_BPID FROM PERSONNAME WHERE PERSONNAME.CONT_ID = ? AND (PERSONNAME.END_DT IS NULL OR PERSONNAME.END_DT> ? )", pattern="tableAlias (PERSONNAME => com.dwl.tcrm.coreParty.entityObject.EObjPersonName, H_PERSONNAME => com.dwl.tcrm.coreParty.entityObject.EObjPersonName, PERSONSEARCH => com.dwl.tcrm.coreParty.entityObject.EObjPersonSearch, H_PERSONSEARCH => com.dwl.tcrm.coreParty.entityObject.EObjPersonSearch , PERSONNAME => com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt , H_PERSONNAME => com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue2<EObjPersonName,EObjXPersonNameExt>> getPersonNamesNotStandardizedActive (Object[] parameters)
  {
    return queryIterator (getPersonNamesNotStandardizedActiveStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getPersonNamesNotStandardizedActiveStatementDescriptor = createStatementDescriptor (
    "getPersonNamesNotStandardizedActive(Object[])",
    "SELECT PERSONNAME.PERSON_NAME_ID , PERSONNAME.PREFIX_NAME_TP_CD , PERSONNAME.PREFIX_DESC , PERSONNAME.NAME_USAGE_TP_CD , PERSONNAME.GIVEN_NAME_ONE , PERSONNAME.GIVEN_NAME_TWO , PERSONNAME.GIVEN_NAME_THREE , PERSONNAME.GIVEN_NAME_FOUR , PERSONNAME.LAST_NAME , PERSONNAME.GENERATION_TP_CD , PERSONNAME.SUFFIX_DESC , PERSONNAME.START_DT , PERSONNAME.END_DT , PERSONNAME.CONT_ID , PERSONNAME.USE_STANDARD_IND , PERSONNAME.LAST_UPDATE_DT , PERSONNAME.LAST_UPDATE_USER , PERSONNAME.LAST_UPDATE_TX_ID , PERSONNAME.LAST_USED_DT , PERSONNAME.LAST_VERIFIED_DT , PERSONNAME.SOURCE_IDENT_TP_CD, PERSONNAME.XMODIFY_SYS_DT, PERSONNAME.XGIVEN_NAME_ONE_LOCAL, PERSONNAME.XGIVEN_NAME_TWO_LOCAL, PERSONNAME.XLAST_NAME_LOCAL, PERSONNAME.XPERSONNAME_RETAILER_FLAG, PERSONNAME.X_BPID FROM PERSONNAME WHERE PERSONNAME.CONT_ID = ? AND (PERSONNAME.END_DT IS NULL OR PERSONNAME.END_DT> ? )",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"person_name_id", "prefix_name_tp_cd", "prefix_desc", "name_usage_tp_cd", "given_name_one", "given_name_two", "given_name_three", "given_name_four", "last_name", "generation_tp_cd", "suffix_desc", "start_dt", "end_dt", "cont_id", "use_standard_ind", "last_update_dt", "last_update_user", "last_update_tx_id", "last_used_dt", "last_verified_dt", "source_ident_tp_cd", "xmodify_sys_dt", "xgiven_name_one_local", "xgiven_name_two_local", "xlast_name_local", "xpersonname_retailer_flag", "x_bpid"},
    new GetPersonNamesNotStandardizedActiveParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP}, {19, 0}, {0, 0}, {1, 1}},
    null,
    new GetPersonNamesNotStandardizedActiveRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.CHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR}, {19, 19, 20, 19, 25, 25, 25, 25, 30, 19, 20, 0, 0, 19, 1, 0, 20, 19, 0, 0, 19, 0, 500, 500, 500, 10, 50}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    12);

  /**
   * @generated
   */
  public static class GetPersonNamesNotStandardizedActiveParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetPersonNamesNotStandardizedActiveRowHandler extends BaseRowHandler<ResultQueue2<EObjPersonName,EObjXPersonNameExt>>
  {
    /**
     * @generated
     */
    public ResultQueue2<EObjPersonName,EObjXPersonNameExt> handle (java.sql.ResultSet rs, ResultQueue2<EObjPersonName,EObjXPersonNameExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue2<EObjPersonName,EObjXPersonNameExt> ();

      EObjPersonName returnObject1 = new EObjPersonName ();
      returnObject1.setPersonNameIdPK(getLongObject (rs, 1)); 
      returnObject1.setPrefixNameTpCd(getLongObject (rs, 2)); 
      returnObject1.setPrefixDesc(getString (rs, 3)); 
      returnObject1.setNameUsageTpCd(getLongObject (rs, 4)); 
      returnObject1.setGivenNameOne(getString (rs, 5)); 
      returnObject1.setGivenNameTwo(getString (rs, 6)); 
      returnObject1.setGivenNameThree(getString (rs, 7)); 
      returnObject1.setGivenNameFour(getString (rs, 8)); 
      returnObject1.setLastName(getString (rs, 9)); 
      returnObject1.setGenerationTpCd(getLongObject (rs, 10)); 
      returnObject1.setSuffixDesc(getString (rs, 11)); 
      returnObject1.setStartDt(getTimestamp (rs, 12)); 
      returnObject1.setEndDt(getTimestamp (rs, 13)); 
      returnObject1.setContId(getLongObject (rs, 14)); 
      returnObject1.setUseStandardInd(getString (rs, 15)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 16)); 
      returnObject1.setLastUpdateUser(getString (rs, 17)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 18)); 
      returnObject1.setLastUsedDt(getTimestamp (rs, 19)); 
      returnObject1.setLastVerifiedDt(getTimestamp (rs, 20)); 
      returnObject1.setSourceIdentTpCd(getLongObject (rs, 21)); 
      returnObject.add (returnObject1);

      EObjXPersonNameExt returnObject2 = new EObjXPersonNameExt ();
      returnObject2.setLastUpdateDt(getTimestamp (rs, 16)); 
      returnObject2.setLastUpdateUser(getString (rs, 17)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 18)); 
      returnObject2.setXLastModifiedSystemDate(getTimestamp (rs, 22)); 
      returnObject2.setXGivenNameOneLocal(getString (rs, 23)); 
      returnObject2.setXGivenNameTwoLocal(getString (rs, 24)); 
      returnObject2.setXLastNameLocal(getString (rs, 25)); 
      returnObject2.setXPersonNameRetailerFlag(getString (rs, 26)); 
      returnObject2.setX_BPID(getString (rs, 27)); 
      returnObject.add (returnObject2);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT PERSONNAME.PERSON_NAME_ID , PERSONNAME.PREFIX_NAME_TP_CD , PERSONNAME.PREFIX_DESC , PERSONNAME.NAME_USAGE_TP_CD , PERSONNAME.GIVEN_NAME_ONE , PERSONNAME.GIVEN_NAME_TWO , PERSONNAME.GIVEN_NAME_THREE , PERSONNAME.GIVEN_NAME_FOUR , PERSONNAME.LAST_NAME , PERSONNAME.GENERATION_TP_CD , PERSONNAME.SUFFIX_DESC , PERSONNAME.START_DT , PERSONNAME.END_DT , PERSONNAME.CONT_ID , PERSONNAME.USE_STANDARD_IND , PERSONNAME.LAST_UPDATE_DT , PERSONNAME.LAST_UPDATE_USER , PERSONNAME.LAST_UPDATE_TX_ID , PERSONNAME.LAST_USED_DT , PERSONNAME.LAST_VERIFIED_DT , PERSONNAME.SOURCE_IDENT_TP_CD, PERSONNAME.XMODIFY_SYS_DT, PERSONNAME.XGIVEN_NAME_ONE_LOCAL, PERSONNAME.XGIVEN_NAME_TWO_LOCAL, PERSONNAME.XLAST_NAME_LOCAL, PERSONNAME.XPERSONNAME_RETAILER_FLAG, PERSONNAME.X_BPID FROM PERSONNAME WHERE PERSONNAME.CONT_ID = ? AND PERSONNAME.END_DT< ?", pattern="tableAlias (PERSONNAME => com.dwl.tcrm.coreParty.entityObject.EObjPersonName, H_PERSONNAME => com.dwl.tcrm.coreParty.entityObject.EObjPersonName, PERSONSEARCH => com.dwl.tcrm.coreParty.entityObject.EObjPersonSearch, H_PERSONSEARCH => com.dwl.tcrm.coreParty.entityObject.EObjPersonSearch , PERSONNAME => com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt , H_PERSONNAME => com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue2<EObjPersonName,EObjXPersonNameExt>> getPersonNamesNotStandardizedInActive (Object[] parameters)
  {
    return queryIterator (getPersonNamesNotStandardizedInActiveStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getPersonNamesNotStandardizedInActiveStatementDescriptor = createStatementDescriptor (
    "getPersonNamesNotStandardizedInActive(Object[])",
    "SELECT PERSONNAME.PERSON_NAME_ID , PERSONNAME.PREFIX_NAME_TP_CD , PERSONNAME.PREFIX_DESC , PERSONNAME.NAME_USAGE_TP_CD , PERSONNAME.GIVEN_NAME_ONE , PERSONNAME.GIVEN_NAME_TWO , PERSONNAME.GIVEN_NAME_THREE , PERSONNAME.GIVEN_NAME_FOUR , PERSONNAME.LAST_NAME , PERSONNAME.GENERATION_TP_CD , PERSONNAME.SUFFIX_DESC , PERSONNAME.START_DT , PERSONNAME.END_DT , PERSONNAME.CONT_ID , PERSONNAME.USE_STANDARD_IND , PERSONNAME.LAST_UPDATE_DT , PERSONNAME.LAST_UPDATE_USER , PERSONNAME.LAST_UPDATE_TX_ID , PERSONNAME.LAST_USED_DT , PERSONNAME.LAST_VERIFIED_DT , PERSONNAME.SOURCE_IDENT_TP_CD, PERSONNAME.XMODIFY_SYS_DT, PERSONNAME.XGIVEN_NAME_ONE_LOCAL, PERSONNAME.XGIVEN_NAME_TWO_LOCAL, PERSONNAME.XLAST_NAME_LOCAL, PERSONNAME.XPERSONNAME_RETAILER_FLAG, PERSONNAME.X_BPID FROM PERSONNAME WHERE PERSONNAME.CONT_ID = ? AND PERSONNAME.END_DT< ?",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"person_name_id", "prefix_name_tp_cd", "prefix_desc", "name_usage_tp_cd", "given_name_one", "given_name_two", "given_name_three", "given_name_four", "last_name", "generation_tp_cd", "suffix_desc", "start_dt", "end_dt", "cont_id", "use_standard_ind", "last_update_dt", "last_update_user", "last_update_tx_id", "last_used_dt", "last_verified_dt", "source_ident_tp_cd", "xmodify_sys_dt", "xgiven_name_one_local", "xgiven_name_two_local", "xlast_name_local", "xpersonname_retailer_flag", "x_bpid"},
    new GetPersonNamesNotStandardizedInActiveParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP}, {19, 0}, {0, 0}, {1, 1}},
    null,
    new GetPersonNamesNotStandardizedInActiveRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.CHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR}, {19, 19, 20, 19, 25, 25, 25, 25, 30, 19, 20, 0, 0, 19, 1, 0, 20, 19, 0, 0, 19, 0, 500, 500, 500, 10, 50}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    13);

  /**
   * @generated
   */
  public static class GetPersonNamesNotStandardizedInActiveParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetPersonNamesNotStandardizedInActiveRowHandler extends BaseRowHandler<ResultQueue2<EObjPersonName,EObjXPersonNameExt>>
  {
    /**
     * @generated
     */
    public ResultQueue2<EObjPersonName,EObjXPersonNameExt> handle (java.sql.ResultSet rs, ResultQueue2<EObjPersonName,EObjXPersonNameExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue2<EObjPersonName,EObjXPersonNameExt> ();

      EObjPersonName returnObject1 = new EObjPersonName ();
      returnObject1.setPersonNameIdPK(getLongObject (rs, 1)); 
      returnObject1.setPrefixNameTpCd(getLongObject (rs, 2)); 
      returnObject1.setPrefixDesc(getString (rs, 3)); 
      returnObject1.setNameUsageTpCd(getLongObject (rs, 4)); 
      returnObject1.setGivenNameOne(getString (rs, 5)); 
      returnObject1.setGivenNameTwo(getString (rs, 6)); 
      returnObject1.setGivenNameThree(getString (rs, 7)); 
      returnObject1.setGivenNameFour(getString (rs, 8)); 
      returnObject1.setLastName(getString (rs, 9)); 
      returnObject1.setGenerationTpCd(getLongObject (rs, 10)); 
      returnObject1.setSuffixDesc(getString (rs, 11)); 
      returnObject1.setStartDt(getTimestamp (rs, 12)); 
      returnObject1.setEndDt(getTimestamp (rs, 13)); 
      returnObject1.setContId(getLongObject (rs, 14)); 
      returnObject1.setUseStandardInd(getString (rs, 15)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 16)); 
      returnObject1.setLastUpdateUser(getString (rs, 17)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 18)); 
      returnObject1.setLastUsedDt(getTimestamp (rs, 19)); 
      returnObject1.setLastVerifiedDt(getTimestamp (rs, 20)); 
      returnObject1.setSourceIdentTpCd(getLongObject (rs, 21)); 
      returnObject.add (returnObject1);

      EObjXPersonNameExt returnObject2 = new EObjXPersonNameExt ();
      returnObject2.setLastUpdateDt(getTimestamp (rs, 16)); 
      returnObject2.setLastUpdateUser(getString (rs, 17)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 18)); 
      returnObject2.setXLastModifiedSystemDate(getTimestamp (rs, 22)); 
      returnObject2.setXGivenNameOneLocal(getString (rs, 23)); 
      returnObject2.setXGivenNameTwoLocal(getString (rs, 24)); 
      returnObject2.setXLastNameLocal(getString (rs, 25)); 
      returnObject2.setXPersonNameRetailerFlag(getString (rs, 26)); 
      returnObject2.setX_BPID(getString (rs, 27)); 
      returnObject.add (returnObject2);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT PERSONNAME.PERSON_NAME_ID , PERSONNAME.PREFIX_NAME_TP_CD , PERSONNAME.PREFIX_DESC , PERSONNAME.NAME_USAGE_TP_CD , PERSONNAME.GIVEN_NAME_ONE , PERSONNAME.GIVEN_NAME_TWO , PERSONNAME.GIVEN_NAME_THREE , PERSONNAME.GIVEN_NAME_FOUR , PERSONNAME.LAST_NAME , PERSONNAME.GENERATION_TP_CD , PERSONNAME.SUFFIX_DESC , PERSONNAME.START_DT , PERSONNAME.END_DT , PERSONNAME.CONT_ID , PERSONNAME.USE_STANDARD_IND , PERSONNAME.LAST_UPDATE_DT , PERSONNAME.LAST_UPDATE_USER , PERSONNAME.LAST_UPDATE_TX_ID , PERSONNAME.LAST_USED_DT , PERSONNAME.LAST_VERIFIED_DT , PERSONNAME.SOURCE_IDENT_TP_CD, PERSONNAME.XMODIFY_SYS_DT, PERSONNAME.XGIVEN_NAME_ONE_LOCAL, PERSONNAME.XGIVEN_NAME_TWO_LOCAL, PERSONNAME.XLAST_NAME_LOCAL, PERSONNAME.XPERSONNAME_RETAILER_FLAG, PERSONNAME.X_BPID FROM PERSONNAME WHERE PERSONNAME.CONT_ID = ?", pattern="tableAlias (PERSONNAME => com.dwl.tcrm.coreParty.entityObject.EObjPersonName, H_PERSONNAME => com.dwl.tcrm.coreParty.entityObject.EObjPersonName, PERSONSEARCH => com.dwl.tcrm.coreParty.entityObject.EObjPersonSearch, H_PERSONSEARCH => com.dwl.tcrm.coreParty.entityObject.EObjPersonSearch , PERSONNAME => com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt , H_PERSONNAME => com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue2<EObjPersonName,EObjXPersonNameExt>> getPersonNamesNotStandardizedAll (Object[] parameters)
  {
    return queryIterator (getPersonNamesNotStandardizedAllStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getPersonNamesNotStandardizedAllStatementDescriptor = createStatementDescriptor (
    "getPersonNamesNotStandardizedAll(Object[])",
    "SELECT PERSONNAME.PERSON_NAME_ID , PERSONNAME.PREFIX_NAME_TP_CD , PERSONNAME.PREFIX_DESC , PERSONNAME.NAME_USAGE_TP_CD , PERSONNAME.GIVEN_NAME_ONE , PERSONNAME.GIVEN_NAME_TWO , PERSONNAME.GIVEN_NAME_THREE , PERSONNAME.GIVEN_NAME_FOUR , PERSONNAME.LAST_NAME , PERSONNAME.GENERATION_TP_CD , PERSONNAME.SUFFIX_DESC , PERSONNAME.START_DT , PERSONNAME.END_DT , PERSONNAME.CONT_ID , PERSONNAME.USE_STANDARD_IND , PERSONNAME.LAST_UPDATE_DT , PERSONNAME.LAST_UPDATE_USER , PERSONNAME.LAST_UPDATE_TX_ID , PERSONNAME.LAST_USED_DT , PERSONNAME.LAST_VERIFIED_DT , PERSONNAME.SOURCE_IDENT_TP_CD, PERSONNAME.XMODIFY_SYS_DT, PERSONNAME.XGIVEN_NAME_ONE_LOCAL, PERSONNAME.XGIVEN_NAME_TWO_LOCAL, PERSONNAME.XLAST_NAME_LOCAL, PERSONNAME.XPERSONNAME_RETAILER_FLAG, PERSONNAME.X_BPID FROM PERSONNAME WHERE PERSONNAME.CONT_ID = ?",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"person_name_id", "prefix_name_tp_cd", "prefix_desc", "name_usage_tp_cd", "given_name_one", "given_name_two", "given_name_three", "given_name_four", "last_name", "generation_tp_cd", "suffix_desc", "start_dt", "end_dt", "cont_id", "use_standard_ind", "last_update_dt", "last_update_user", "last_update_tx_id", "last_used_dt", "last_verified_dt", "source_ident_tp_cd", "xmodify_sys_dt", "xgiven_name_one_local", "xgiven_name_two_local", "xlast_name_local", "xpersonname_retailer_flag", "x_bpid"},
    new GetPersonNamesNotStandardizedAllParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetPersonNamesNotStandardizedAllRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.CHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR}, {19, 19, 20, 19, 25, 25, 25, 25, 30, 19, 20, 0, 0, 19, 1, 0, 20, 19, 0, 0, 19, 0, 500, 500, 500, 10, 50}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    14);

  /**
   * @generated
   */
  public static class GetPersonNamesNotStandardizedAllParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetPersonNamesNotStandardizedAllRowHandler extends BaseRowHandler<ResultQueue2<EObjPersonName,EObjXPersonNameExt>>
  {
    /**
     * @generated
     */
    public ResultQueue2<EObjPersonName,EObjXPersonNameExt> handle (java.sql.ResultSet rs, ResultQueue2<EObjPersonName,EObjXPersonNameExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue2<EObjPersonName,EObjXPersonNameExt> ();

      EObjPersonName returnObject1 = new EObjPersonName ();
      returnObject1.setPersonNameIdPK(getLongObject (rs, 1)); 
      returnObject1.setPrefixNameTpCd(getLongObject (rs, 2)); 
      returnObject1.setPrefixDesc(getString (rs, 3)); 
      returnObject1.setNameUsageTpCd(getLongObject (rs, 4)); 
      returnObject1.setGivenNameOne(getString (rs, 5)); 
      returnObject1.setGivenNameTwo(getString (rs, 6)); 
      returnObject1.setGivenNameThree(getString (rs, 7)); 
      returnObject1.setGivenNameFour(getString (rs, 8)); 
      returnObject1.setLastName(getString (rs, 9)); 
      returnObject1.setGenerationTpCd(getLongObject (rs, 10)); 
      returnObject1.setSuffixDesc(getString (rs, 11)); 
      returnObject1.setStartDt(getTimestamp (rs, 12)); 
      returnObject1.setEndDt(getTimestamp (rs, 13)); 
      returnObject1.setContId(getLongObject (rs, 14)); 
      returnObject1.setUseStandardInd(getString (rs, 15)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 16)); 
      returnObject1.setLastUpdateUser(getString (rs, 17)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 18)); 
      returnObject1.setLastUsedDt(getTimestamp (rs, 19)); 
      returnObject1.setLastVerifiedDt(getTimestamp (rs, 20)); 
      returnObject1.setSourceIdentTpCd(getLongObject (rs, 21)); 
      returnObject.add (returnObject1);

      EObjXPersonNameExt returnObject2 = new EObjXPersonNameExt ();
      returnObject2.setLastUpdateDt(getTimestamp (rs, 16)); 
      returnObject2.setLastUpdateUser(getString (rs, 17)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 18)); 
      returnObject2.setXLastModifiedSystemDate(getTimestamp (rs, 22)); 
      returnObject2.setXGivenNameOneLocal(getString (rs, 23)); 
      returnObject2.setXGivenNameTwoLocal(getString (rs, 24)); 
      returnObject2.setXLastNameLocal(getString (rs, 25)); 
      returnObject2.setXPersonNameRetailerFlag(getString (rs, 26)); 
      returnObject2.setX_BPID(getString (rs, 27)); 
      returnObject.add (returnObject2);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT DISTINCT A.H_PERSON_NAME_ID AS HIST_ID_PK ,A.H_ACTION_CODE ,A.H_CREATED_BY ,A.H_CREATE_DT ,A.H_END_DT ,A.PERSON_NAME_ID ,A.PREFIX_NAME_TP_CD ,A.PREFIX_DESC ,A.NAME_USAGE_TP_CD ,A.GIVEN_NAME_ONE ,A.GIVEN_NAME_TWO ,A.GIVEN_NAME_THREE ,A.GIVEN_NAME_FOUR ,A.LAST_NAME , A.GENERATION_TP_CD , A.SUFFIX_DESC ,A.START_DT ,A.END_DT ,A.CONT_ID ,A.USE_STANDARD_IND ,A.LAST_UPDATE_DT ,A.LAST_UPDATE_USER , A.LAST_UPDATE_TX_ID , A.LAST_USED_DT , A.LAST_VERIFIED_DT , A.SOURCE_IDENT_TP_CD, A.XMODIFY_SYS_DT, A.XGIVEN_NAME_ONE_LOCAL, A.XGIVEN_NAME_TWO_LOCAL, A.XLAST_NAME_LOCAL, A.XPERSONNAME_RETAILER_FLAG, A.X_BPID FROM H_PERSONNAME A WHERE A.CONT_ID = ? AND A.NAME_USAGE_TP_CD = ? AND (? BETWEEN A.H_CREATE_DT AND A.H_END_DT OR (? >= A.H_CREATE_DT AND A.H_END_DT IS NULL ))", pattern="tableAlias (PERSONNAME => com.dwl.tcrm.coreParty.entityObject.EObjPersonName, H_PERSONNAME => com.dwl.tcrm.coreParty.entityObject.EObjPersonName, PERSONSEARCH => com.dwl.tcrm.coreParty.entityObject.EObjPersonSearch, H_PERSONSEARCH => com.dwl.tcrm.coreParty.entityObject.EObjPersonSearch , PERSONNAME => com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt , H_PERSONNAME => com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue2<EObjPersonName,EObjXPersonNameExt>> getPersonNameNotStandardizedWithTypeHistory (Object[] parameters)
  {
    return queryIterator (getPersonNameNotStandardizedWithTypeHistoryStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getPersonNameNotStandardizedWithTypeHistoryStatementDescriptor = createStatementDescriptor (
    "getPersonNameNotStandardizedWithTypeHistory(Object[])",
    "SELECT DISTINCT A.H_PERSON_NAME_ID AS HIST_ID_PK ,A.H_ACTION_CODE ,A.H_CREATED_BY ,A.H_CREATE_DT ,A.H_END_DT ,A.PERSON_NAME_ID ,A.PREFIX_NAME_TP_CD ,A.PREFIX_DESC ,A.NAME_USAGE_TP_CD ,A.GIVEN_NAME_ONE ,A.GIVEN_NAME_TWO ,A.GIVEN_NAME_THREE ,A.GIVEN_NAME_FOUR ,A.LAST_NAME , A.GENERATION_TP_CD , A.SUFFIX_DESC ,A.START_DT ,A.END_DT ,A.CONT_ID ,A.USE_STANDARD_IND ,A.LAST_UPDATE_DT ,A.LAST_UPDATE_USER , A.LAST_UPDATE_TX_ID , A.LAST_USED_DT , A.LAST_VERIFIED_DT , A.SOURCE_IDENT_TP_CD, A.XMODIFY_SYS_DT, A.XGIVEN_NAME_ONE_LOCAL, A.XGIVEN_NAME_TWO_LOCAL, A.XLAST_NAME_LOCAL, A.XPERSONNAME_RETAILER_FLAG, A.X_BPID FROM H_PERSONNAME A WHERE A.CONT_ID = ? AND A.NAME_USAGE_TP_CD = ? AND (? BETWEEN A.H_CREATE_DT AND A.H_END_DT OR (? >= A.H_CREATE_DT AND A.H_END_DT IS NULL ))",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"hist_id_pk", "h_action_code", "h_created_by", "h_create_dt", "h_end_dt", "person_name_id", "prefix_name_tp_cd", "prefix_desc", "name_usage_tp_cd", "given_name_one", "given_name_two", "given_name_three", "given_name_four", "last_name", "generation_tp_cd", "suffix_desc", "start_dt", "end_dt", "cont_id", "use_standard_ind", "last_update_dt", "last_update_user", "last_update_tx_id", "last_used_dt", "last_verified_dt", "source_ident_tp_cd", "xmodify_sys_dt", "xgiven_name_one_local", "xgiven_name_two_local", "xlast_name_local", "xpersonname_retailer_flag", "x_bpid"},
    new GetPersonNameNotStandardizedWithTypeHistoryParameterHandler (),
    new int[][]{{Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP}, {19, 19, 0, 0}, {0, 0, 0, 0}, {1, 1, 1, 1}},
    null,
    new GetPersonNameNotStandardizedWithTypeHistoryRowHandler (),
    new int[][]{ {Types.BIGINT, Types.CHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.CHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR}, {19, 1, 20, 0, 0, 19, 19, 20, 19, 25, 25, 25, 25, 30, 19, 20, 0, 0, 19, 1, 0, 20, 19, 0, 0, 19, 0, 500, 500, 500, 10, 50}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    15);

  /**
   * @generated
   */
  public static class GetPersonNameNotStandardizedWithTypeHistoryParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.BIGINT, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
      setObject (stmt, 4, Types.TIMESTAMP, parameters[3], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetPersonNameNotStandardizedWithTypeHistoryRowHandler extends BaseRowHandler<ResultQueue2<EObjPersonName,EObjXPersonNameExt>>
  {
    /**
     * @generated
     */
    public ResultQueue2<EObjPersonName,EObjXPersonNameExt> handle (java.sql.ResultSet rs, ResultQueue2<EObjPersonName,EObjXPersonNameExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue2<EObjPersonName,EObjXPersonNameExt> ();

      EObjPersonName returnObject1 = new EObjPersonName ();
      returnObject1.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject1.setHistActionCode(getString (rs, 2)); 
      returnObject1.setHistCreatedBy(getString (rs, 3)); 
      returnObject1.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject1.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject1.setPersonNameIdPK(getLongObject (rs, 6)); 
      returnObject1.setPrefixNameTpCd(getLongObject (rs, 7)); 
      returnObject1.setPrefixDesc(getString (rs, 8)); 
      returnObject1.setNameUsageTpCd(getLongObject (rs, 9)); 
      returnObject1.setGivenNameOne(getString (rs, 10)); 
      returnObject1.setGivenNameTwo(getString (rs, 11)); 
      returnObject1.setGivenNameThree(getString (rs, 12)); 
      returnObject1.setGivenNameFour(getString (rs, 13)); 
      returnObject1.setLastName(getString (rs, 14)); 
      returnObject1.setGenerationTpCd(getLongObject (rs, 15)); 
      returnObject1.setSuffixDesc(getString (rs, 16)); 
      returnObject1.setStartDt(getTimestamp (rs, 17)); 
      returnObject1.setEndDt(getTimestamp (rs, 18)); 
      returnObject1.setContId(getLongObject (rs, 19)); 
      returnObject1.setUseStandardInd(getString (rs, 20)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 21)); 
      returnObject1.setLastUpdateUser(getString (rs, 22)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 23)); 
      returnObject1.setLastUsedDt(getTimestamp (rs, 24)); 
      returnObject1.setLastVerifiedDt(getTimestamp (rs, 25)); 
      returnObject1.setSourceIdentTpCd(getLongObject (rs, 26)); 
      returnObject.add (returnObject1);

      EObjXPersonNameExt returnObject2 = new EObjXPersonNameExt ();
      returnObject2.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject2.setHistActionCode(getString (rs, 2)); 
      returnObject2.setHistCreatedBy(getString (rs, 3)); 
      returnObject2.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject2.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject2.setLastUpdateDt(getTimestamp (rs, 21)); 
      returnObject2.setLastUpdateUser(getString (rs, 22)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 23)); 
      returnObject2.setXLastModifiedSystemDate(getTimestamp (rs, 27)); 
      returnObject2.setXGivenNameOneLocal(getString (rs, 28)); 
      returnObject2.setXGivenNameTwoLocal(getString (rs, 29)); 
      returnObject2.setXLastNameLocal(getString (rs, 30)); 
      returnObject2.setXPersonNameRetailerFlag(getString (rs, 31)); 
      returnObject2.setX_BPID(getString (rs, 32)); 
      returnObject.add (returnObject2);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT PERSONNAME.PERSON_NAME_ID ,PERSONNAME.PREFIX_NAME_TP_CD ,PERSONNAME.PREFIX_DESC ,PERSONNAME.NAME_USAGE_TP_CD ,PERSONNAME.GIVEN_NAME_ONE ,PERSONNAME.GIVEN_NAME_TWO ,PERSONNAME.GIVEN_NAME_THREE ,PERSONNAME.GIVEN_NAME_FOUR ,PERSONNAME.LAST_NAME , PERSONNAME.GENERATION_TP_CD , PERSONNAME.SUFFIX_DESC ,PERSONNAME.START_DT ,PERSONNAME.END_DT ,PERSONNAME.CONT_ID ,PERSONNAME.USE_STANDARD_IND ,PERSONNAME.LAST_UPDATE_DT ,PERSONNAME.LAST_UPDATE_USER , PERSONNAME.LAST_UPDATE_TX_ID , PERSONNAME.LAST_USED_DT , PERSONNAME.LAST_VERIFIED_DT , PERSONNAME.SOURCE_IDENT_TP_CD, PERSONNAME.XMODIFY_SYS_DT, PERSONNAME.XGIVEN_NAME_ONE_LOCAL, PERSONNAME.XGIVEN_NAME_TWO_LOCAL, PERSONNAME.XLAST_NAME_LOCAL, PERSONNAME.XPERSONNAME_RETAILER_FLAG, PERSONNAME.X_BPID FROM PERSONNAME WHERE PERSONNAME.CONT_ID = ? AND (PERSONNAME.NAME_USAGE_TP_CD = ?) AND (PERSONNAME.END_DT IS NULL OR PERSONNAME.END_DT> ? )", pattern="tableAlias (PERSONNAME => com.dwl.tcrm.coreParty.entityObject.EObjPersonName, H_PERSONNAME => com.dwl.tcrm.coreParty.entityObject.EObjPersonName, PERSONSEARCH => com.dwl.tcrm.coreParty.entityObject.EObjPersonSearch, H_PERSONSEARCH => com.dwl.tcrm.coreParty.entityObject.EObjPersonSearch , PERSONNAME => com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt , H_PERSONNAME => com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue2<EObjPersonName,EObjXPersonNameExt>> getPersonNameNotStandardizedWithType (Object[] parameters)
  {
    return queryIterator (getPersonNameNotStandardizedWithTypeStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getPersonNameNotStandardizedWithTypeStatementDescriptor = createStatementDescriptor (
    "getPersonNameNotStandardizedWithType(Object[])",
    "SELECT PERSONNAME.PERSON_NAME_ID ,PERSONNAME.PREFIX_NAME_TP_CD ,PERSONNAME.PREFIX_DESC ,PERSONNAME.NAME_USAGE_TP_CD ,PERSONNAME.GIVEN_NAME_ONE ,PERSONNAME.GIVEN_NAME_TWO ,PERSONNAME.GIVEN_NAME_THREE ,PERSONNAME.GIVEN_NAME_FOUR ,PERSONNAME.LAST_NAME , PERSONNAME.GENERATION_TP_CD , PERSONNAME.SUFFIX_DESC ,PERSONNAME.START_DT ,PERSONNAME.END_DT ,PERSONNAME.CONT_ID ,PERSONNAME.USE_STANDARD_IND ,PERSONNAME.LAST_UPDATE_DT ,PERSONNAME.LAST_UPDATE_USER , PERSONNAME.LAST_UPDATE_TX_ID , PERSONNAME.LAST_USED_DT , PERSONNAME.LAST_VERIFIED_DT , PERSONNAME.SOURCE_IDENT_TP_CD, PERSONNAME.XMODIFY_SYS_DT, PERSONNAME.XGIVEN_NAME_ONE_LOCAL, PERSONNAME.XGIVEN_NAME_TWO_LOCAL, PERSONNAME.XLAST_NAME_LOCAL, PERSONNAME.XPERSONNAME_RETAILER_FLAG, PERSONNAME.X_BPID FROM PERSONNAME WHERE PERSONNAME.CONT_ID = ? AND (PERSONNAME.NAME_USAGE_TP_CD = ?) AND (PERSONNAME.END_DT IS NULL OR PERSONNAME.END_DT> ? )",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"person_name_id", "prefix_name_tp_cd", "prefix_desc", "name_usage_tp_cd", "given_name_one", "given_name_two", "given_name_three", "given_name_four", "last_name", "generation_tp_cd", "suffix_desc", "start_dt", "end_dt", "cont_id", "use_standard_ind", "last_update_dt", "last_update_user", "last_update_tx_id", "last_used_dt", "last_verified_dt", "source_ident_tp_cd", "xmodify_sys_dt", "xgiven_name_one_local", "xgiven_name_two_local", "xlast_name_local", "xpersonname_retailer_flag", "x_bpid"},
    new GetPersonNameNotStandardizedWithTypeParameterHandler (),
    new int[][]{{Types.BIGINT, Types.BIGINT, Types.TIMESTAMP}, {19, 19, 0}, {0, 0, 0}, {1, 1, 1}},
    null,
    new GetPersonNameNotStandardizedWithTypeRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.CHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR}, {19, 19, 20, 19, 25, 25, 25, 25, 30, 19, 20, 0, 0, 19, 1, 0, 20, 19, 0, 0, 19, 0, 500, 500, 500, 10, 50}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    16);

  /**
   * @generated
   */
  public static class GetPersonNameNotStandardizedWithTypeParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.BIGINT, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetPersonNameNotStandardizedWithTypeRowHandler extends BaseRowHandler<ResultQueue2<EObjPersonName,EObjXPersonNameExt>>
  {
    /**
     * @generated
     */
    public ResultQueue2<EObjPersonName,EObjXPersonNameExt> handle (java.sql.ResultSet rs, ResultQueue2<EObjPersonName,EObjXPersonNameExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue2<EObjPersonName,EObjXPersonNameExt> ();

      EObjPersonName returnObject1 = new EObjPersonName ();
      returnObject1.setPersonNameIdPK(getLongObject (rs, 1)); 
      returnObject1.setPrefixNameTpCd(getLongObject (rs, 2)); 
      returnObject1.setPrefixDesc(getString (rs, 3)); 
      returnObject1.setNameUsageTpCd(getLongObject (rs, 4)); 
      returnObject1.setGivenNameOne(getString (rs, 5)); 
      returnObject1.setGivenNameTwo(getString (rs, 6)); 
      returnObject1.setGivenNameThree(getString (rs, 7)); 
      returnObject1.setGivenNameFour(getString (rs, 8)); 
      returnObject1.setLastName(getString (rs, 9)); 
      returnObject1.setGenerationTpCd(getLongObject (rs, 10)); 
      returnObject1.setSuffixDesc(getString (rs, 11)); 
      returnObject1.setStartDt(getTimestamp (rs, 12)); 
      returnObject1.setEndDt(getTimestamp (rs, 13)); 
      returnObject1.setContId(getLongObject (rs, 14)); 
      returnObject1.setUseStandardInd(getString (rs, 15)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 16)); 
      returnObject1.setLastUpdateUser(getString (rs, 17)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 18)); 
      returnObject1.setLastUsedDt(getTimestamp (rs, 19)); 
      returnObject1.setLastVerifiedDt(getTimestamp (rs, 20)); 
      returnObject1.setSourceIdentTpCd(getLongObject (rs, 21)); 
      returnObject.add (returnObject1);

      EObjXPersonNameExt returnObject2 = new EObjXPersonNameExt ();
      returnObject2.setLastUpdateDt(getTimestamp (rs, 16)); 
      returnObject2.setLastUpdateUser(getString (rs, 17)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 18)); 
      returnObject2.setXLastModifiedSystemDate(getTimestamp (rs, 22)); 
      returnObject2.setXGivenNameOneLocal(getString (rs, 23)); 
      returnObject2.setXGivenNameTwoLocal(getString (rs, 24)); 
      returnObject2.setXLastNameLocal(getString (rs, 25)); 
      returnObject2.setXPersonNameRetailerFlag(getString (rs, 26)); 
      returnObject2.setX_BPID(getString (rs, 27)); 
      returnObject.add (returnObject2);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT PERSONNAME.PERSON_NAME_ID , PERSONNAME.PREFIX_NAME_TP_CD , PERSONNAME.PREFIX_DESC , PERSONNAME.NAME_USAGE_TP_CD , PERSONNAME.GIVEN_NAME_ONE , PERSONNAME.GIVEN_NAME_TWO , PERSONNAME.GIVEN_NAME_THREE , PERSONNAME.GIVEN_NAME_FOUR , PERSONNAME.LAST_NAME , PERSONNAME.GENERATION_TP_CD , PERSONNAME.SUFFIX_DESC , PERSONNAME.START_DT , PERSONNAME.END_DT , PERSONNAME.CONT_ID , PERSONNAME.USE_STANDARD_IND , PERSONNAME.LAST_UPDATE_DT , PERSONNAME.LAST_UPDATE_USER , PERSONNAME.LAST_UPDATE_TX_ID , PERSONNAME.LAST_USED_DT , PERSONNAME.LAST_VERIFIED_DT , PERSONNAME.SOURCE_IDENT_TP_CD, PERSONNAME.XMODIFY_SYS_DT, PERSONNAME.XGIVEN_NAME_ONE_LOCAL, PERSONNAME.XGIVEN_NAME_TWO_LOCAL, PERSONNAME.XLAST_NAME_LOCAL, PERSONNAME.XPERSONNAME_RETAILER_FLAG, PERSONNAME.X_BPID FROM PERSONNAME WHERE PERSONNAME.PERSON_NAME_ID = ?", pattern="tableAlias (PERSONNAME => com.dwl.tcrm.coreParty.entityObject.EObjPersonName, H_PERSONNAME => com.dwl.tcrm.coreParty.entityObject.EObjPersonName, PERSONSEARCH => com.dwl.tcrm.coreParty.entityObject.EObjPersonSearch, H_PERSONSEARCH => com.dwl.tcrm.coreParty.entityObject.EObjPersonSearch , PERSONNAME => com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt , H_PERSONNAME => com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue2<EObjPersonName,EObjXPersonNameExt>> getPersonNameNotStandardizedByID (Object[] parameters)
  {
    return queryIterator (getPersonNameNotStandardizedByIDStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getPersonNameNotStandardizedByIDStatementDescriptor = createStatementDescriptor (
    "getPersonNameNotStandardizedByID(Object[])",
    "SELECT PERSONNAME.PERSON_NAME_ID , PERSONNAME.PREFIX_NAME_TP_CD , PERSONNAME.PREFIX_DESC , PERSONNAME.NAME_USAGE_TP_CD , PERSONNAME.GIVEN_NAME_ONE , PERSONNAME.GIVEN_NAME_TWO , PERSONNAME.GIVEN_NAME_THREE , PERSONNAME.GIVEN_NAME_FOUR , PERSONNAME.LAST_NAME , PERSONNAME.GENERATION_TP_CD , PERSONNAME.SUFFIX_DESC , PERSONNAME.START_DT , PERSONNAME.END_DT , PERSONNAME.CONT_ID , PERSONNAME.USE_STANDARD_IND , PERSONNAME.LAST_UPDATE_DT , PERSONNAME.LAST_UPDATE_USER , PERSONNAME.LAST_UPDATE_TX_ID , PERSONNAME.LAST_USED_DT , PERSONNAME.LAST_VERIFIED_DT , PERSONNAME.SOURCE_IDENT_TP_CD, PERSONNAME.XMODIFY_SYS_DT, PERSONNAME.XGIVEN_NAME_ONE_LOCAL, PERSONNAME.XGIVEN_NAME_TWO_LOCAL, PERSONNAME.XLAST_NAME_LOCAL, PERSONNAME.XPERSONNAME_RETAILER_FLAG, PERSONNAME.X_BPID FROM PERSONNAME WHERE PERSONNAME.PERSON_NAME_ID = ?",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"person_name_id", "prefix_name_tp_cd", "prefix_desc", "name_usage_tp_cd", "given_name_one", "given_name_two", "given_name_three", "given_name_four", "last_name", "generation_tp_cd", "suffix_desc", "start_dt", "end_dt", "cont_id", "use_standard_ind", "last_update_dt", "last_update_user", "last_update_tx_id", "last_used_dt", "last_verified_dt", "source_ident_tp_cd", "xmodify_sys_dt", "xgiven_name_one_local", "xgiven_name_two_local", "xlast_name_local", "xpersonname_retailer_flag", "x_bpid"},
    new GetPersonNameNotStandardizedByIDParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetPersonNameNotStandardizedByIDRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.CHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR}, {19, 19, 20, 19, 25, 25, 25, 25, 30, 19, 20, 0, 0, 19, 1, 0, 20, 19, 0, 0, 19, 0, 500, 500, 500, 10, 50}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    17);

  /**
   * @generated
   */
  public static class GetPersonNameNotStandardizedByIDParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetPersonNameNotStandardizedByIDRowHandler extends BaseRowHandler<ResultQueue2<EObjPersonName,EObjXPersonNameExt>>
  {
    /**
     * @generated
     */
    public ResultQueue2<EObjPersonName,EObjXPersonNameExt> handle (java.sql.ResultSet rs, ResultQueue2<EObjPersonName,EObjXPersonNameExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue2<EObjPersonName,EObjXPersonNameExt> ();

      EObjPersonName returnObject1 = new EObjPersonName ();
      returnObject1.setPersonNameIdPK(getLongObject (rs, 1)); 
      returnObject1.setPrefixNameTpCd(getLongObject (rs, 2)); 
      returnObject1.setPrefixDesc(getString (rs, 3)); 
      returnObject1.setNameUsageTpCd(getLongObject (rs, 4)); 
      returnObject1.setGivenNameOne(getString (rs, 5)); 
      returnObject1.setGivenNameTwo(getString (rs, 6)); 
      returnObject1.setGivenNameThree(getString (rs, 7)); 
      returnObject1.setGivenNameFour(getString (rs, 8)); 
      returnObject1.setLastName(getString (rs, 9)); 
      returnObject1.setGenerationTpCd(getLongObject (rs, 10)); 
      returnObject1.setSuffixDesc(getString (rs, 11)); 
      returnObject1.setStartDt(getTimestamp (rs, 12)); 
      returnObject1.setEndDt(getTimestamp (rs, 13)); 
      returnObject1.setContId(getLongObject (rs, 14)); 
      returnObject1.setUseStandardInd(getString (rs, 15)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 16)); 
      returnObject1.setLastUpdateUser(getString (rs, 17)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 18)); 
      returnObject1.setLastUsedDt(getTimestamp (rs, 19)); 
      returnObject1.setLastVerifiedDt(getTimestamp (rs, 20)); 
      returnObject1.setSourceIdentTpCd(getLongObject (rs, 21)); 
      returnObject.add (returnObject1);

      EObjXPersonNameExt returnObject2 = new EObjXPersonNameExt ();
      returnObject2.setLastUpdateDt(getTimestamp (rs, 16)); 
      returnObject2.setLastUpdateUser(getString (rs, 17)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 18)); 
      returnObject2.setXLastModifiedSystemDate(getTimestamp (rs, 22)); 
      returnObject2.setXGivenNameOneLocal(getString (rs, 23)); 
      returnObject2.setXGivenNameTwoLocal(getString (rs, 24)); 
      returnObject2.setXLastNameLocal(getString (rs, 25)); 
      returnObject2.setXPersonNameRetailerFlag(getString (rs, 26)); 
      returnObject2.setX_BPID(getString (rs, 27)); 
      returnObject.add (returnObject2);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT H_PERSONNAME.H_PERSON_NAME_ID AS HIST_ID_PK , H_PERSONNAME.H_ACTION_CODE, H_PERSONNAME.H_CREATED_BY, H_PERSONNAME.H_CREATE_DT, H_PERSONNAME.PREFIX_NAME_TP_CD , H_PERSONNAME.PREFIX_DESC , H_PERSONNAME.NAME_USAGE_TP_CD , H_PERSONNAME.GIVEN_NAME_ONE , H_PERSONNAME.GIVEN_NAME_TWO , H_PERSONNAME.GIVEN_NAME_THREE , H_PERSONNAME.GIVEN_NAME_FOUR , H_PERSONNAME.LAST_NAME , H_PERSONNAME.GENERATION_TP_CD , H_PERSONNAME.SUFFIX_DESC , H_PERSONNAME.START_DT , H_PERSONNAME.END_DT , H_PERSONNAME.CONT_ID , H_PERSONNAME.USE_STANDARD_IND , H_PERSONNAME.LAST_UPDATE_DT , H_PERSONNAME.LAST_UPDATE_USER , H_PERSONNAME.LAST_UPDATE_TX_ID , H_PERSONNAME.LAST_USED_DT , H_PERSONNAME.LAST_VERIFIED_DT , H_PERSONNAME.SOURCE_IDENT_TP_CD, H_PERSONNAME.XMODIFY_SYS_DT, H_PERSONNAME.XGIVEN_NAME_ONE_LOCAL, H_PERSONNAME.XGIVEN_NAME_TWO_LOCAL, H_PERSONNAME.XLAST_NAME_LOCAL, H_PERSONNAME.XPERSONNAME_RETAILER_FLAG, H_PERSONNAME.X_BPID FROM H_PERSONNAME WHERE H_PERSONNAME.H_PERSON_NAME_ID = ? AND (( ? BETWEEN H_PERSONNAME.H_CREATE_DT AND H_PERSONNAME.H_END_DT ) OR ( ? >= H_PERSONNAME.H_CREATE_DT AND H_PERSONNAME.H_END_DT IS NULL ))", pattern="tableAlias (PERSONNAME => com.dwl.tcrm.coreParty.entityObject.EObjPersonName, H_PERSONNAME => com.dwl.tcrm.coreParty.entityObject.EObjPersonName, PERSONSEARCH => com.dwl.tcrm.coreParty.entityObject.EObjPersonSearch, H_PERSONSEARCH => com.dwl.tcrm.coreParty.entityObject.EObjPersonSearch , PERSONNAME => com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt , H_PERSONNAME => com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue2<EObjPersonName,EObjXPersonNameExt>> getPersonNameNotStandardizedHistoryById (Object[] parameters)
  {
    return queryIterator (getPersonNameNotStandardizedHistoryByIdStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getPersonNameNotStandardizedHistoryByIdStatementDescriptor = createStatementDescriptor (
    "getPersonNameNotStandardizedHistoryById(Object[])",
    "SELECT H_PERSONNAME.H_PERSON_NAME_ID AS HIST_ID_PK , H_PERSONNAME.H_ACTION_CODE, H_PERSONNAME.H_CREATED_BY, H_PERSONNAME.H_CREATE_DT, H_PERSONNAME.PREFIX_NAME_TP_CD , H_PERSONNAME.PREFIX_DESC , H_PERSONNAME.NAME_USAGE_TP_CD , H_PERSONNAME.GIVEN_NAME_ONE , H_PERSONNAME.GIVEN_NAME_TWO , H_PERSONNAME.GIVEN_NAME_THREE , H_PERSONNAME.GIVEN_NAME_FOUR , H_PERSONNAME.LAST_NAME , H_PERSONNAME.GENERATION_TP_CD , H_PERSONNAME.SUFFIX_DESC , H_PERSONNAME.START_DT , H_PERSONNAME.END_DT , H_PERSONNAME.CONT_ID , H_PERSONNAME.USE_STANDARD_IND , H_PERSONNAME.LAST_UPDATE_DT , H_PERSONNAME.LAST_UPDATE_USER , H_PERSONNAME.LAST_UPDATE_TX_ID , H_PERSONNAME.LAST_USED_DT , H_PERSONNAME.LAST_VERIFIED_DT , H_PERSONNAME.SOURCE_IDENT_TP_CD, H_PERSONNAME.XMODIFY_SYS_DT, H_PERSONNAME.XGIVEN_NAME_ONE_LOCAL, H_PERSONNAME.XGIVEN_NAME_TWO_LOCAL, H_PERSONNAME.XLAST_NAME_LOCAL, H_PERSONNAME.XPERSONNAME_RETAILER_FLAG, H_PERSONNAME.X_BPID FROM H_PERSONNAME WHERE H_PERSONNAME.H_PERSON_NAME_ID = ? AND (( ? BETWEEN H_PERSONNAME.H_CREATE_DT AND H_PERSONNAME.H_END_DT ) OR ( ? >= H_PERSONNAME.H_CREATE_DT AND H_PERSONNAME.H_END_DT IS NULL ))",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"hist_id_pk", "h_action_code", "h_created_by", "h_create_dt", "prefix_name_tp_cd", "prefix_desc", "name_usage_tp_cd", "given_name_one", "given_name_two", "given_name_three", "given_name_four", "last_name", "generation_tp_cd", "suffix_desc", "start_dt", "end_dt", "cont_id", "use_standard_ind", "last_update_dt", "last_update_user", "last_update_tx_id", "last_used_dt", "last_verified_dt", "source_ident_tp_cd", "xmodify_sys_dt", "xgiven_name_one_local", "xgiven_name_two_local", "xlast_name_local", "xpersonname_retailer_flag", "x_bpid"},
    new GetPersonNameNotStandardizedHistoryByIdParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP}, {19, 0, 0}, {0, 0, 0}, {1, 1, 1}},
    null,
    new GetPersonNameNotStandardizedHistoryByIdRowHandler (),
    new int[][]{ {Types.BIGINT, Types.CHAR, Types.VARCHAR, Types.TIMESTAMP, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.CHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR}, {19, 1, 20, 0, 19, 20, 19, 25, 25, 25, 25, 30, 19, 20, 0, 0, 19, 1, 0, 20, 19, 0, 0, 19, 0, 500, 500, 500, 10, 50}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    18);

  /**
   * @generated
   */
  public static class GetPersonNameNotStandardizedHistoryByIdParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetPersonNameNotStandardizedHistoryByIdRowHandler extends BaseRowHandler<ResultQueue2<EObjPersonName,EObjXPersonNameExt>>
  {
    /**
     * @generated
     */
    public ResultQueue2<EObjPersonName,EObjXPersonNameExt> handle (java.sql.ResultSet rs, ResultQueue2<EObjPersonName,EObjXPersonNameExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue2<EObjPersonName,EObjXPersonNameExt> ();

      EObjPersonName returnObject1 = new EObjPersonName ();
      returnObject1.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject1.setHistActionCode(getString (rs, 2)); 
      returnObject1.setHistCreatedBy(getString (rs, 3)); 
      returnObject1.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject1.setPrefixNameTpCd(getLongObject (rs, 5)); 
      returnObject1.setPrefixDesc(getString (rs, 6)); 
      returnObject1.setNameUsageTpCd(getLongObject (rs, 7)); 
      returnObject1.setGivenNameOne(getString (rs, 8)); 
      returnObject1.setGivenNameTwo(getString (rs, 9)); 
      returnObject1.setGivenNameThree(getString (rs, 10)); 
      returnObject1.setGivenNameFour(getString (rs, 11)); 
      returnObject1.setLastName(getString (rs, 12)); 
      returnObject1.setGenerationTpCd(getLongObject (rs, 13)); 
      returnObject1.setSuffixDesc(getString (rs, 14)); 
      returnObject1.setStartDt(getTimestamp (rs, 15)); 
      returnObject1.setEndDt(getTimestamp (rs, 16)); 
      returnObject1.setContId(getLongObject (rs, 17)); 
      returnObject1.setUseStandardInd(getString (rs, 18)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 19)); 
      returnObject1.setLastUpdateUser(getString (rs, 20)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 21)); 
      returnObject1.setLastUsedDt(getTimestamp (rs, 22)); 
      returnObject1.setLastVerifiedDt(getTimestamp (rs, 23)); 
      returnObject1.setSourceIdentTpCd(getLongObject (rs, 24)); 
      returnObject.add (returnObject1);

      EObjXPersonNameExt returnObject2 = new EObjXPersonNameExt ();
      returnObject2.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject2.setHistActionCode(getString (rs, 2)); 
      returnObject2.setHistCreatedBy(getString (rs, 3)); 
      returnObject2.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject2.setLastUpdateDt(getTimestamp (rs, 19)); 
      returnObject2.setLastUpdateUser(getString (rs, 20)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 21)); 
      returnObject2.setXLastModifiedSystemDate(getTimestamp (rs, 25)); 
      returnObject2.setXGivenNameOneLocal(getString (rs, 26)); 
      returnObject2.setXGivenNameTwoLocal(getString (rs, 27)); 
      returnObject2.setXLastNameLocal(getString (rs, 28)); 
      returnObject2.setXPersonNameRetailerFlag(getString (rs, 29)); 
      returnObject2.setX_BPID(getString (rs, 30)); 
      returnObject.add (returnObject2);

    
      return returnObject;
    }
  }

}
