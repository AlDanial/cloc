package com.ibm.daimler.dsea.entityObject;

import com.ibm.pdq.runtime.generator.BaseParameterHandler;
import java.util.Iterator;
import java.sql.PreparedStatement;
import com.ibm.pdq.runtime.statement.StatementDescriptor;
import com.ibm.pdq.runtime.generator.BaseData;
import java.sql.SQLException;
import com.ibm.pdq.annotation.Metadata;
import com.ibm.daimler.dsea.entityObject.EObjXCustomerRetailer;
import com.ibm.pdq.runtime.generator.BaseRowHandler;
import com.ibm.pdq.runtime.statement.SqlStatementType;
import java.sql.Types;


/**
 * <!-- begin-user-doc -->
 * 
 * <!-- end-user-doc -->
 * 
 * @generated
 */
public class EObjXCustomerRetailerDataImpl  extends BaseData implements EObjXCustomerRetailerData
{

  /**
   * @generated
   */
  public static final String generatorVersion = "3.200.75";

  /**
   * @generated
   */
  public static final String identifier = "EObjXCustomerRetailerData";

  /**
   * @generated
   */
  public static final long generationTime = 0x0000015e13f83991L;

  /**
   * @generated
   */
  public static final String collection = "NULLID";

  /**
   * @generated
   */
  public static final String packageVersion = null;

  /**
   * @generated
   */
  public static final boolean forceSingleBindIsolation = false;

  /**
   * @generated
   */
  public EObjXCustomerRetailerDataImpl()
  {
    super();
  } 

  /**
   * @generated
   */
  public String getGeneratorVersion()
  {
    return generatorVersion;
  }

  /**
   * @Select( sql="select CUSTOMERRETAILERPK_ID, CONT_ID, RETAILER_ID, SOURCE_IDENT_TP_CD, START_DT, END_DT, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from XCUSTOMERRETAILER where CUSTOMERRETAILERPK_ID = ? " )
   * 
   * @generated
   */
  public Iterator<EObjXCustomerRetailer> getEObjXCustomerRetailer (Long customerRetailerpkId)
  {
    return queryIterator (getEObjXCustomerRetailerStatementDescriptor, customerRetailerpkId);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getEObjXCustomerRetailerStatementDescriptor = createStatementDescriptor (
    "getEObjXCustomerRetailer(Long)",
    "select CUSTOMERRETAILERPK_ID, CONT_ID, RETAILER_ID, SOURCE_IDENT_TP_CD, START_DT, END_DT, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from XCUSTOMERRETAILER where CUSTOMERRETAILERPK_ID = ? ",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"customerretailerpk_id", "cont_id", "retailer_id", "source_ident_tp_cd", "start_dt", "end_dt", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetEObjXCustomerRetailerParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetEObjXCustomerRetailerRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 19, 19, 19, 0, 0, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    1);

  /**
   * @generated
   */
  public static class GetEObjXCustomerRetailerParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setLong (stmt, 1, Types.BIGINT, (Long)parameters[0]);
    }
  }

  /**
   * @generated
   */
  public static class GetEObjXCustomerRetailerRowHandler extends BaseRowHandler<EObjXCustomerRetailer>
  {
    /**
     * @generated
     */
    public EObjXCustomerRetailer handle (java.sql.ResultSet rs, EObjXCustomerRetailer returnObject) throws java.sql.SQLException
    {
      returnObject = new EObjXCustomerRetailer ();
      returnObject.setCustomerRetailerpkId(getLongObject (rs, 1)); 
      returnObject.setContId(getLongObject (rs, 2)); 
      returnObject.setRetailerId(getLongObject (rs, 3)); 
      returnObject.setSourceIdentifier(getLongObject (rs, 4)); 
      returnObject.setStartDate(getTimestamp (rs, 5)); 
      returnObject.setEndDate(getTimestamp (rs, 6)); 
      returnObject.setLastUpdateDt(getTimestamp (rs, 7)); 
      returnObject.setLastUpdateUser(getString (rs, 8)); 
      returnObject.setLastUpdateTxId(getLongObject (rs, 9)); 
    
      return returnObject;
    }
  }

  /**
   * @Update( sql="insert into XCUSTOMERRETAILER (CUSTOMERRETAILERPK_ID, CONT_ID, RETAILER_ID, SOURCE_IDENT_TP_CD, START_DT, END_DT, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( :customerRetailerpkId, :contId, :retailerId, :sourceIdentifier, :startDate, :endDate, :lastUpdateDt, :lastUpdateUser, :lastUpdateTxId)" )
   * 
   * @generated
   */
  public int createEObjXCustomerRetailer (EObjXCustomerRetailer e)
  {
    return update (createEObjXCustomerRetailerStatementDescriptor, e);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor createEObjXCustomerRetailerStatementDescriptor = createStatementDescriptor (
    "createEObjXCustomerRetailer(com.ibm.daimler.dsea.entityObject.EObjXCustomerRetailer)",
    "insert into XCUSTOMERRETAILER (CUSTOMERRETAILERPK_ID, CONT_ID, RETAILER_ID, SOURCE_IDENT_TP_CD, START_DT, END_DT, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values(  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? )",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.INSERT,
    null,
    new CreateEObjXCustomerRetailerParameterHandler (),
    new int[][]{{Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 19, 19, 19, 0, 0, 0, 0, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1, 1, 1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    2);

  /**
   * @generated
   */
  public static class CreateEObjXCustomerRetailerParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      EObjXCustomerRetailer bean0 = (EObjXCustomerRetailer) parameters[0];
      setLong (stmt, 1, Types.BIGINT, (Long)bean0.getCustomerRetailerpkId());
      setLong (stmt, 2, Types.BIGINT, (Long)bean0.getContId());
      setLong (stmt, 3, Types.BIGINT, (Long)bean0.getRetailerId());
      setLong (stmt, 4, Types.BIGINT, (Long)bean0.getSourceIdentifier());
      setTimestamp (stmt, 5, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getStartDate());
      setTimestamp (stmt, 6, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getEndDate());
      setTimestamp (stmt, 7, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUpdateDt());
      setString (stmt, 8, Types.VARCHAR, (String)bean0.getLastUpdateUser());
      setLong (stmt, 9, Types.BIGINT, (Long)bean0.getLastUpdateTxId());
    }
  }

  /**
   * @Update( sql="update XCUSTOMERRETAILER set CONT_ID = :contId, RETAILER_ID = :retailerId, SOURCE_IDENT_TP_CD = :sourceIdentifier, START_DT = :startDate, END_DT = :endDate, LAST_UPDATE_DT = :lastUpdateDt, LAST_UPDATE_USER = :lastUpdateUser, LAST_UPDATE_TX_ID = :lastUpdateTxId where CUSTOMERRETAILERPK_ID = :customerRetailerpkId and LAST_UPDATE_DT = :oldLastUpdateDt" )
   * 
   * @generated
   */
  public int updateEObjXCustomerRetailer (EObjXCustomerRetailer e)
  {
    return update (updateEObjXCustomerRetailerStatementDescriptor, e);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor updateEObjXCustomerRetailerStatementDescriptor = createStatementDescriptor (
    "updateEObjXCustomerRetailer(com.ibm.daimler.dsea.entityObject.EObjXCustomerRetailer)",
    "update XCUSTOMERRETAILER set CONT_ID =  ? , RETAILER_ID =  ? , SOURCE_IDENT_TP_CD =  ? , START_DT =  ? , END_DT =  ? , LAST_UPDATE_DT =  ? , LAST_UPDATE_USER =  ? , LAST_UPDATE_TX_ID =  ?  where CUSTOMERRETAILERPK_ID =  ?  and LAST_UPDATE_DT =  ? ",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.UPDATE,
    null,
    new UpdateEObjXCustomerRetailerParameterHandler (),
    new int[][]{{Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP}, {19, 19, 19, 0, 0, 0, 0, 19, 19, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1, 1, 1, 1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    3);

  /**
   * @generated
   */
  public static class UpdateEObjXCustomerRetailerParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      EObjXCustomerRetailer bean0 = (EObjXCustomerRetailer) parameters[0];
      setLong (stmt, 1, Types.BIGINT, (Long)bean0.getContId());
      setLong (stmt, 2, Types.BIGINT, (Long)bean0.getRetailerId());
      setLong (stmt, 3, Types.BIGINT, (Long)bean0.getSourceIdentifier());
      setTimestamp (stmt, 4, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getStartDate());
      setTimestamp (stmt, 5, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getEndDate());
      setTimestamp (stmt, 6, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUpdateDt());
      setString (stmt, 7, Types.VARCHAR, (String)bean0.getLastUpdateUser());
      setLong (stmt, 8, Types.BIGINT, (Long)bean0.getLastUpdateTxId());
      setLong (stmt, 9, Types.BIGINT, (Long)bean0.getCustomerRetailerpkId());
      setTimestamp (stmt, 10, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getOldLastUpdateDt());
    }
  }

  /**
   * @Update( sql="delete from XCUSTOMERRETAILER where CUSTOMERRETAILERPK_ID = ?" )
   * 
   * @generated
   */
  public int deleteEObjXCustomerRetailer (Long customerRetailerpkId)
  {
    return update (deleteEObjXCustomerRetailerStatementDescriptor, customerRetailerpkId);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor deleteEObjXCustomerRetailerStatementDescriptor = createStatementDescriptor (
    "deleteEObjXCustomerRetailer(Long)",
    "delete from XCUSTOMERRETAILER where CUSTOMERRETAILERPK_ID = ?",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.DELETE,
    null,
    new DeleteEObjXCustomerRetailerParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    4);

  /**
   * @generated
   */
  public static class DeleteEObjXCustomerRetailerParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setLong (stmt, 1, Types.BIGINT, (Long)parameters[0]);
    }
  }

}
