/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[6aba816bdb0366af83bfc0777a63ff49]
 */


package com.ibm.daimler.dsea.entityObject;

import java.util.Iterator;
import com.ibm.mdm.base.db.EntityMapping;
import com.ibm.pdq.annotation.Select;
import com.ibm.pdq.annotation.Update;

import com.dwl.tcrm.financial.entityObject.EObjContractRole;

import com.ibm.daimler.dsea.entityObject.EObjXContractRoleExt;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * @generated
 */
public interface EObjXContractRoleExtData {


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjXContractRoleExtSql = "select XSOURCE_IDENT_TP_CD, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from CONTRACTROLE where CONTRACT_ROLE_ID = ? ";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String createEObjXContractRoleExtSql = "insert into CONTRACTROLE (CONTR_COMPONENT_ID, CONTRACT_ROLE_ID, DISTRIB_PCT, END_DT, IRREVOC_IND, CONT_ID, START_DT, REGISTERED_NAME, RECORDED_START_DT, ARRANGEMENT_DESC, RECORDED_END_DT, SHARE_DIST_TP_CD, END_REASON_TP_CD, ARRANGEMENT_TP_CD, CONTR_ROLE_TP_CD, XSOURCE_IDENT_TP_CD, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( ?1.contrComponentId, ?1.contractRoleIdPK, ?1.distribPct, ?1.endDt, ?1.irrevocInd, ?1.contId, ?1.startDt, ?1.registeredName, ?1.recordedStartDt, ?1.arrangementDesc, ?1.recordedEndDt, ?1.shareDistTpCd, ?1.endReasonTpCd, ?1.arrangementTpCd, ?1.contractRoleTpCd, ?2.xSourceIdentifier, ?1.lastUpdateDt, ?1.lastUpdateUser, ?1.lastUpdateTxId)";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String updateEObjXContractRoleExtSql = "update CONTRACTROLE set CONTR_COMPONENT_ID = ?1.contrComponentId, DISTRIB_PCT = ?1.distribPct, END_DT = ?1.endDt, IRREVOC_IND = ?1.irrevocInd, CONT_ID = ?1.contId, START_DT = ?1.startDt, REGISTERED_NAME = ?1.registeredName, RECORDED_START_DT = ?1.recordedStartDt, ARRANGEMENT_DESC = ?1.arrangementDesc, RECORDED_END_DT = ?1.recordedEndDt, SHARE_DIST_TP_CD = ?1.shareDistTpCd, END_REASON_TP_CD = ?1.endReasonTpCd, ARRANGEMENT_TP_CD = ?1.arrangementTpCd, CONTR_ROLE_TP_CD = ?1.contractRoleTpCd, XSOURCE_IDENT_TP_CD = ?2.xSourceIdentifier, LAST_UPDATE_DT = ?1.lastUpdateDt, LAST_UPDATE_USER = ?1.lastUpdateUser, LAST_UPDATE_TX_ID = ?1.lastUpdateTxId where CONTRACT_ROLE_ID = ?1.contractRoleIdPK and LAST_UPDATE_DT = ?1.oldLastUpdateDt";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String deleteEObjXContractRoleExtSql = "delete from CONTRACTROLE where CONTRACT_ROLE_ID = ?";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXContractRoleExtKeyField = "EObjXContractRoleExt.contractRoleIdPK";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXContractRoleExtGetFields =
    "EObjXContractRoleExt.xSourceIdentifier," +
    "EObjXContractRoleExt.lastUpdateDt," +
    "EObjXContractRoleExt.lastUpdateUser," +
    "EObjXContractRoleExt.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXContractRoleExtAllFields =
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.contrComponentId," +
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.contractRoleIdPK," +
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.distribPct," +
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.endDt," +
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.irrevocInd," +
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.contId," +
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.startDt," +
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.registeredName," +
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.recordedStartDt," +
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.arrangementDesc," +
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.recordedEndDt," +
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.shareDistTpCd," +
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.endReasonTpCd," +
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.arrangementTpCd," +
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.contractRoleTpCd," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractRoleExt.xSourceIdentifier," +
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.lastUpdateDt," +
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.lastUpdateUser," +
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXContractRoleExtUpdateFields =
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.contrComponentId," +
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.distribPct," +
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.endDt," +
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.irrevocInd," +
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.contId," +
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.startDt," +
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.registeredName," +
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.recordedStartDt," +
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.arrangementDesc," +
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.recordedEndDt," +
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.shareDistTpCd," +
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.endReasonTpCd," +
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.arrangementTpCd," +
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.contractRoleTpCd," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractRoleExt.xSourceIdentifier," +
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.lastUpdateDt," +
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.lastUpdateUser," +
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.lastUpdateTxId," +
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.contractRoleIdPK," +
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.oldLastUpdateDt";   

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Select XContractRole by parameters.
   * @generated
   */
  @Select(sql=getEObjXContractRoleExtSql)
  @EntityMapping(parameters=EObjXContractRoleExtKeyField, results=EObjXContractRoleExtGetFields)
  Iterator<EObjXContractRoleExt> getEObjXContractRoleExt(Long contractRoleIdPK);  
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Create XContractRole by EObjXContractRoleExt Object.
   * @generated
   */
  @Update(sql=createEObjXContractRoleExtSql)
  @EntityMapping(parameters=EObjXContractRoleExtAllFields)
    int createEObjXContractRoleExt(EObjContractRole e1, EObjXContractRoleExt e2); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Update one XContractRole by EObjXContractRoleExt object.
   * @generated
   */
  @Update(sql=updateEObjXContractRoleExtSql)
  @EntityMapping(parameters=EObjXContractRoleExtUpdateFields)
    int updateEObjXContractRoleExt(EObjContractRole e1, EObjXContractRoleExt e2); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Delete XContractRole by parameters.
   * @generated
   */
  @Update(sql=deleteEObjXContractRoleExtSql)
  @EntityMapping(parameters=EObjXContractRoleExtKeyField)
  int deleteEObjXContractRoleExt(Long contractRoleIdPK);

}

