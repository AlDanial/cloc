package com.ibm.daimler.dsea.entityObject;

import com.ibm.pdq.runtime.generator.BaseParameterHandler;
import com.dwl.tcrm.coreParty.entityObject.EObjOrgName;
import java.util.Iterator;
import com.ibm.daimler.dsea.entityObject.EObjXOrgNameExt;
import java.sql.PreparedStatement;
import com.ibm.pdq.runtime.statement.StatementDescriptor;
import com.ibm.pdq.runtime.generator.BaseData;
import java.sql.SQLException;
import com.ibm.pdq.annotation.Metadata;
import com.ibm.pdq.runtime.generator.BaseRowHandler;
import com.ibm.pdq.runtime.statement.SqlStatementType;
import java.sql.Types;


/**
 * <!-- begin-user-doc -->
 * 
 * <!-- end-user-doc -->
 * 
 * @generated
 */
public class EObjXOrgNameExtDataImpl  extends BaseData implements EObjXOrgNameExtData
{

  /**
   * @generated
   */
  public static final String generatorVersion = "3.200.75";

  /**
   * @generated
   */
  public static final String identifier = "EObjXOrgNameExtData";

  /**
   * @generated
   */
  public static final long generationTime = 0x0000015e13ff8178L;

  /**
   * @generated
   */
  public static final String collection = "NULLID";

  /**
   * @generated
   */
  public static final String packageVersion = null;

  /**
   * @generated
   */
  public static final boolean forceSingleBindIsolation = false;

  /**
   * @generated
   */
  public EObjXOrgNameExtDataImpl()
  {
    super();
  } 

  /**
   * @generated
   */
  public String getGeneratorVersion()
  {
    return generatorVersion;
  }

  /**
   * @Select( sql="select XMODIFY_SYS_DT, XORG_NAME_LOCAL, XORGNAME_RETAILER_FLAG, X_BPID, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from ORGNAME where ORG_NAME_ID = ? " )
   * 
   * @generated
   */
  public Iterator<EObjXOrgNameExt> getEObjXOrgNameExt (Long orgNameIdPK)
  {
    return queryIterator (getEObjXOrgNameExtStatementDescriptor, orgNameIdPK);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getEObjXOrgNameExtStatementDescriptor = createStatementDescriptor (
    "getEObjXOrgNameExt(Long)",
    "select XMODIFY_SYS_DT, XORG_NAME_LOCAL, XORGNAME_RETAILER_FLAG, X_BPID, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from ORGNAME where ORG_NAME_ID = ? ",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"xmodify_sys_dt", "xorg_name_local", "xorgname_retailer_flag", "x_bpid", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetEObjXOrgNameExtParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetEObjXOrgNameExtRowHandler (),
    new int[][]{ {Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {0, 500, 10, 50, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    1);

  /**
   * @generated
   */
  public static class GetEObjXOrgNameExtParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setLong (stmt, 1, Types.BIGINT, (Long)parameters[0]);
    }
  }

  /**
   * @generated
   */
  public static class GetEObjXOrgNameExtRowHandler extends BaseRowHandler<EObjXOrgNameExt>
  {
    /**
     * @generated
     */
    public EObjXOrgNameExt handle (java.sql.ResultSet rs, EObjXOrgNameExt returnObject) throws java.sql.SQLException
    {
      returnObject = new EObjXOrgNameExt ();
      returnObject.setXLastModifiedSystemDate(getTimestamp (rs, 1)); 
      returnObject.setXOrganizationNameLocal(getString (rs, 2)); 
      returnObject.setXOrgNameRetailerFlag(getString (rs, 3)); 
      returnObject.setX_BPID(getString (rs, 4)); 
      returnObject.setLastUpdateDt(getTimestamp (rs, 5)); 
      returnObject.setLastUpdateUser(getString (rs, 6)); 
      returnObject.setLastUpdateTxId(getLongObject (rs, 7)); 
    
      return returnObject;
    }
  }

  /**
   * @Update( sql="insert into ORGNAME (LAST_USED_DT, LAST_VERIFIED_DT, END_DT, ORG_NAME, ORG_NAME_ID, CONT_ID, START_DT, S_ORG_NAME, SOURCE_IDENT_TP_CD, ORG_NAME_TP_CD, P_ORG_NAME, STANDARD_IND, NAME_SEARCH_KEY, XMODIFY_SYS_DT, XORG_NAME_LOCAL, XORGNAME_RETAILER_FLAG, X_BPID, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( ?1.lastUsedDt, ?1.lastVerifiedDt, ?1.endDt, ?1.orgName, ?1.orgNameIdPK, ?1.contId, ?1.startDt, ?1.sOrgName, ?1.sourceIdentTpCd, ?1.orgNameTpCd, ?1.pOrgName, ?1.orgNameStandardInd, ?1.nameSearchKey, ?2.xLastModifiedSystemDate, ?2.xOrganizationNameLocal, ?2.xOrgNameRetailerFlag, ?2.x_BPID, ?1.lastUpdateDt, ?1.lastUpdateUser, ?1.lastUpdateTxId)" )
   * 
   * @generated
   */
  public int createEObjXOrgNameExt (EObjOrgName e1, EObjXOrgNameExt e2)
  {
    return update (createEObjXOrgNameExtStatementDescriptor, e1, e2);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor createEObjXOrgNameExtStatementDescriptor = createStatementDescriptor (
    "createEObjXOrgNameExt(com.dwl.tcrm.coreParty.entityObject.EObjOrgName, com.ibm.daimler.dsea.entityObject.EObjXOrgNameExt)",
    "insert into ORGNAME (LAST_USED_DT, LAST_VERIFIED_DT, END_DT, ORG_NAME, ORG_NAME_ID, CONT_ID, START_DT, S_ORG_NAME, SOURCE_IDENT_TP_CD, ORG_NAME_TP_CD, P_ORG_NAME, STANDARD_IND, NAME_SEARCH_KEY, XMODIFY_SYS_DT, XORG_NAME_LOCAL, XORGNAME_RETAILER_FLAG, X_BPID, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values(  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? )",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.INSERT,
    null,
    new CreateEObjXOrgNameExtParameterHandler (),
    new int[][]{{Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.CHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {0, 0, 0, 255, 19, 19, 0, 255, 19, 19, 20, 1, 30, 0, 500, 10, 50, 0, 0, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    2);

  /**
   * @generated
   */
  public static class CreateEObjXOrgNameExtParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      EObjOrgName bean0 = (EObjOrgName) parameters[0];
      setTimestamp (stmt, 1, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUsedDt());
      setTimestamp (stmt, 2, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastVerifiedDt());
      setTimestamp (stmt, 3, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getEndDt());
      setString (stmt, 4, Types.VARCHAR, (String)bean0.getOrgName());
      setLong (stmt, 5, Types.BIGINT, (Long)bean0.getOrgNameIdPK());
      setLong (stmt, 6, Types.BIGINT, (Long)bean0.getContId());
      setTimestamp (stmt, 7, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getStartDt());
      setString (stmt, 8, Types.VARCHAR, (String)bean0.getSOrgName());
      setLong (stmt, 9, Types.BIGINT, (Long)bean0.getSourceIdentTpCd());
      setLong (stmt, 10, Types.BIGINT, (Long)bean0.getOrgNameTpCd());
      setString (stmt, 11, Types.VARCHAR, (String)bean0.getPOrgName());
      setString (stmt, 12, Types.CHAR, (String)bean0.getOrgNameStandardInd());
      setString (stmt, 13, Types.VARCHAR, (String)bean0.getNameSearchKey());
      EObjXOrgNameExt bean1 = (EObjXOrgNameExt) parameters[1];
      setTimestamp (stmt, 14, Types.TIMESTAMP, (java.sql.Timestamp)bean1.getXLastModifiedSystemDate());
      setString (stmt, 15, Types.VARCHAR, (String)bean1.getXOrganizationNameLocal());
      setString (stmt, 16, Types.VARCHAR, (String)bean1.getXOrgNameRetailerFlag());
      setString (stmt, 17, Types.VARCHAR, (String)bean1.getX_BPID());
      setTimestamp (stmt, 18, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUpdateDt());
      setString (stmt, 19, Types.VARCHAR, (String)bean0.getLastUpdateUser());
      setLong (stmt, 20, Types.BIGINT, (Long)bean0.getLastUpdateTxId());
    }
  }

  /**
   * @Update( sql="update ORGNAME set LAST_USED_DT = ?1.lastUsedDt, LAST_VERIFIED_DT = ?1.lastVerifiedDt, END_DT = ?1.endDt, ORG_NAME = ?1.orgName, CONT_ID = ?1.contId, START_DT = ?1.startDt, S_ORG_NAME = ?1.sOrgName, SOURCE_IDENT_TP_CD = ?1.sourceIdentTpCd, ORG_NAME_TP_CD = ?1.orgNameTpCd, P_ORG_NAME = ?1.pOrgName, STANDARD_IND = ?1.orgNameStandardInd, NAME_SEARCH_KEY = ?1.nameSearchKey, XMODIFY_SYS_DT = ?2.xLastModifiedSystemDate, XORG_NAME_LOCAL = ?2.xOrganizationNameLocal, XORGNAME_RETAILER_FLAG = ?2.xOrgNameRetailerFlag, X_BPID = ?2.x_BPID, LAST_UPDATE_DT = ?1.lastUpdateDt, LAST_UPDATE_USER = ?1.lastUpdateUser, LAST_UPDATE_TX_ID = ?1.lastUpdateTxId where ORG_NAME_ID = ?1.orgNameIdPK and LAST_UPDATE_DT = ?1.oldLastUpdateDt" )
   * 
   * @generated
   */
  public int updateEObjXOrgNameExt (EObjOrgName e1, EObjXOrgNameExt e2)
  {
    return update (updateEObjXOrgNameExtStatementDescriptor, e1, e2);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor updateEObjXOrgNameExtStatementDescriptor = createStatementDescriptor (
    "updateEObjXOrgNameExt(com.dwl.tcrm.coreParty.entityObject.EObjOrgName, com.ibm.daimler.dsea.entityObject.EObjXOrgNameExt)",
    "update ORGNAME set LAST_USED_DT =  ? , LAST_VERIFIED_DT =  ? , END_DT =  ? , ORG_NAME =  ? , CONT_ID =  ? , START_DT =  ? , S_ORG_NAME =  ? , SOURCE_IDENT_TP_CD =  ? , ORG_NAME_TP_CD =  ? , P_ORG_NAME =  ? , STANDARD_IND =  ? , NAME_SEARCH_KEY =  ? , XMODIFY_SYS_DT =  ? , XORG_NAME_LOCAL =  ? , XORGNAME_RETAILER_FLAG =  ? , X_BPID =  ? , LAST_UPDATE_DT =  ? , LAST_UPDATE_USER =  ? , LAST_UPDATE_TX_ID =  ?  where ORG_NAME_ID =  ?  and LAST_UPDATE_DT =  ? ",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.UPDATE,
    null,
    new UpdateEObjXOrgNameExtParameterHandler (),
    new int[][]{{Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.CHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP}, {0, 0, 0, 255, 19, 0, 255, 19, 19, 20, 1, 30, 0, 500, 10, 50, 0, 0, 19, 19, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    3);

  /**
   * @generated
   */
  public static class UpdateEObjXOrgNameExtParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      EObjOrgName bean0 = (EObjOrgName) parameters[0];
      setTimestamp (stmt, 1, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUsedDt());
      setTimestamp (stmt, 2, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastVerifiedDt());
      setTimestamp (stmt, 3, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getEndDt());
      setString (stmt, 4, Types.VARCHAR, (String)bean0.getOrgName());
      setLong (stmt, 5, Types.BIGINT, (Long)bean0.getContId());
      setTimestamp (stmt, 6, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getStartDt());
      setString (stmt, 7, Types.VARCHAR, (String)bean0.getSOrgName());
      setLong (stmt, 8, Types.BIGINT, (Long)bean0.getSourceIdentTpCd());
      setLong (stmt, 9, Types.BIGINT, (Long)bean0.getOrgNameTpCd());
      setString (stmt, 10, Types.VARCHAR, (String)bean0.getPOrgName());
      setString (stmt, 11, Types.CHAR, (String)bean0.getOrgNameStandardInd());
      setString (stmt, 12, Types.VARCHAR, (String)bean0.getNameSearchKey());
      EObjXOrgNameExt bean1 = (EObjXOrgNameExt) parameters[1];
      setTimestamp (stmt, 13, Types.TIMESTAMP, (java.sql.Timestamp)bean1.getXLastModifiedSystemDate());
      setString (stmt, 14, Types.VARCHAR, (String)bean1.getXOrganizationNameLocal());
      setString (stmt, 15, Types.VARCHAR, (String)bean1.getXOrgNameRetailerFlag());
      setString (stmt, 16, Types.VARCHAR, (String)bean1.getX_BPID());
      setTimestamp (stmt, 17, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUpdateDt());
      setString (stmt, 18, Types.VARCHAR, (String)bean0.getLastUpdateUser());
      setLong (stmt, 19, Types.BIGINT, (Long)bean0.getLastUpdateTxId());
      setLong (stmt, 20, Types.BIGINT, (Long)bean0.getOrgNameIdPK());
      setTimestamp (stmt, 21, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getOldLastUpdateDt());
    }
  }

  /**
   * @Update( sql="delete from ORGNAME where ORG_NAME_ID = ?" )
   * 
   * @generated
   */
  public int deleteEObjXOrgNameExt (Long orgNameIdPK)
  {
    return update (deleteEObjXOrgNameExtStatementDescriptor, orgNameIdPK);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor deleteEObjXOrgNameExtStatementDescriptor = createStatementDescriptor (
    "deleteEObjXOrgNameExt(Long)",
    "delete from ORGNAME where ORG_NAME_ID = ?",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.DELETE,
    null,
    new DeleteEObjXOrgNameExtParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    4);

  /**
   * @generated
   */
  public static class DeleteEObjXOrgNameExtParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setLong (stmt, 1, Types.BIGINT, (Long)parameters[0]);
    }
  }

}
