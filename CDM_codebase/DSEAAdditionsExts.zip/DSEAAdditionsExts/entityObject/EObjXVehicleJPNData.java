/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[8485e911fb084cd681a7fa6caa6d5598]
 */


package com.ibm.daimler.dsea.entityObject;

import java.util.Iterator;
import com.ibm.mdm.base.db.EntityMapping;
import com.ibm.pdq.annotation.Select;
import com.ibm.pdq.annotation.Update;

import com.ibm.daimler.dsea.entityObject.EObjXVehicleJPN;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * @generated
 */
public interface EObjXVehicleJPNData {


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjXVehicleJPNSql = "select XVehicle_JPNPK_ID, GLOBAL_VIN, BAU_MUSTER, TYPE_ClASS, SUB_MUSTER, COLOR, TRIM, BATCH_IND, MARKET_NAME, SOURCE_IDENT_TP_CD, MODIFY_SYS_DT, CREATE_DT, CHANGED_DT, LAST_SERVICE_DT, SFDC_ID, VEHICLE_ADDRESS_TYPE, VEHICLE_TYPE, DELETE_FLAG, END_DT, ENGINE_NUM, MYCAR_ID, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from XVEHICLEJPN where XVehicle_JPNPK_ID = ? ";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String createEObjXVehicleJPNSql = "insert into XVEHICLEJPN (XVehicle_JPNPK_ID, GLOBAL_VIN, BAU_MUSTER, TYPE_ClASS, SUB_MUSTER, COLOR, TRIM, BATCH_IND, MARKET_NAME, SOURCE_IDENT_TP_CD, MODIFY_SYS_DT, CREATE_DT, CHANGED_DT, LAST_SERVICE_DT, SFDC_ID, VEHICLE_ADDRESS_TYPE, VEHICLE_TYPE, DELETE_FLAG, END_DT, ENGINE_NUM, MYCAR_ID, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( :xVehicleJPNpkId, :globalVIN, :bauMuster, :typeClass, :subMuster, :color, :trim, :batchInd, :marketName, :sourceIdentifier, :lastModifiedSystemDate, :createDate, :changedDate, :lastServiceDate, :sFDCId, :vehicleAddressType, :vehicleType, :deleteFlag, :endDate, :engineNumber, :myCarId, :lastUpdateDt, :lastUpdateUser, :lastUpdateTxId)";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String updateEObjXVehicleJPNSql = "update XVEHICLEJPN set GLOBAL_VIN = :globalVIN, BAU_MUSTER = :bauMuster, TYPE_ClASS = :typeClass, SUB_MUSTER = :subMuster, COLOR = :color, TRIM = :trim, BATCH_IND = :batchInd, MARKET_NAME = :marketName, SOURCE_IDENT_TP_CD = :sourceIdentifier, MODIFY_SYS_DT = :lastModifiedSystemDate, CREATE_DT = :createDate, CHANGED_DT = :changedDate, LAST_SERVICE_DT = :lastServiceDate, SFDC_ID = :sFDCId, VEHICLE_ADDRESS_TYPE = :vehicleAddressType, VEHICLE_TYPE = :vehicleType, DELETE_FLAG = :deleteFlag, END_DT = :endDate, ENGINE_NUM = :engineNumber, MYCAR_ID = :myCarId, LAST_UPDATE_DT = :lastUpdateDt, LAST_UPDATE_USER = :lastUpdateUser, LAST_UPDATE_TX_ID = :lastUpdateTxId where XVehicle_JPNPK_ID = :xVehicleJPNpkId and LAST_UPDATE_DT = :oldLastUpdateDt";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String deleteEObjXVehicleJPNSql = "delete from XVEHICLEJPN where XVehicle_JPNPK_ID = ?";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXVehicleJPNKeyField = "EObjXVehicleJPN.xVehicleJPNpkId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXVehicleJPNGetFields =
    "EObjXVehicleJPN.xVehicleJPNpkId," +
    "EObjXVehicleJPN.globalVIN," +
    "EObjXVehicleJPN.bauMuster," +
    "EObjXVehicleJPN.typeClass," +
    "EObjXVehicleJPN.subMuster," +
    "EObjXVehicleJPN.color," +
    "EObjXVehicleJPN.trim," +
    "EObjXVehicleJPN.batchInd," +
    "EObjXVehicleJPN.marketName," +
    "EObjXVehicleJPN.sourceIdentifier," +
    "EObjXVehicleJPN.lastModifiedSystemDate," +
    "EObjXVehicleJPN.createDate," +
    "EObjXVehicleJPN.changedDate," +
    "EObjXVehicleJPN.lastServiceDate," +
    "EObjXVehicleJPN.sFDCId," +
    "EObjXVehicleJPN.vehicleAddressType," +
    "EObjXVehicleJPN.vehicleType," +
    "EObjXVehicleJPN.deleteFlag," +
    "EObjXVehicleJPN.endDate," +
    "EObjXVehicleJPN.engineNumber," +
    "EObjXVehicleJPN.myCarId," +
    "EObjXVehicleJPN.lastUpdateDt," +
    "EObjXVehicleJPN.lastUpdateUser," +
    "EObjXVehicleJPN.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXVehicleJPNAllFields =
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleJPN.xVehicleJPNpkId," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleJPN.globalVIN," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleJPN.bauMuster," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleJPN.typeClass," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleJPN.subMuster," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleJPN.color," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleJPN.trim," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleJPN.batchInd," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleJPN.marketName," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleJPN.sourceIdentifier," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleJPN.lastModifiedSystemDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleJPN.createDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleJPN.changedDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleJPN.lastServiceDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleJPN.sFDCId," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleJPN.vehicleAddressType," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleJPN.vehicleType," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleJPN.deleteFlag," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleJPN.endDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleJPN.engineNumber," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleJPN.myCarId," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleJPN.lastUpdateDt," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleJPN.lastUpdateUser," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleJPN.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXVehicleJPNUpdateFields =
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleJPN.globalVIN," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleJPN.bauMuster," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleJPN.typeClass," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleJPN.subMuster," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleJPN.color," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleJPN.trim," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleJPN.batchInd," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleJPN.marketName," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleJPN.sourceIdentifier," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleJPN.lastModifiedSystemDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleJPN.createDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleJPN.changedDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleJPN.lastServiceDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleJPN.sFDCId," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleJPN.vehicleAddressType," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleJPN.vehicleType," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleJPN.deleteFlag," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleJPN.endDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleJPN.engineNumber," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleJPN.myCarId," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleJPN.lastUpdateDt," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleJPN.lastUpdateUser," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleJPN.lastUpdateTxId," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleJPN.xVehicleJPNpkId," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleJPN.oldLastUpdateDt";   

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Select XVehicleJPN by parameters.
   * @generated
   */
  @Select(sql=getEObjXVehicleJPNSql)
  @EntityMapping(parameters=EObjXVehicleJPNKeyField, results=EObjXVehicleJPNGetFields)
  Iterator<EObjXVehicleJPN> getEObjXVehicleJPN(Long xVehicleJPNpkId);  
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Create XVehicleJPN by EObjXVehicleJPN Object.
   * @generated
   */
  @Update(sql=createEObjXVehicleJPNSql)
  @EntityMapping(parameters=EObjXVehicleJPNAllFields)
    int createEObjXVehicleJPN(EObjXVehicleJPN e); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Update one XVehicleJPN by EObjXVehicleJPN object.
   * @generated
   */
  @Update(sql=updateEObjXVehicleJPNSql)
  @EntityMapping(parameters=EObjXVehicleJPNUpdateFields)
    int updateEObjXVehicleJPN(EObjXVehicleJPN e); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Delete XVehicleJPN by parameters.
   * @generated
   */
  @Update(sql=deleteEObjXVehicleJPNSql)
  @EntityMapping(parameters=EObjXVehicleJPNKeyField)
  int deleteEObjXVehicleJPN(Long xVehicleJPNpkId);

}

