/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[a48d0dc3d52686c712cb9c094c6f4c2a]
 */

package com.ibm.daimler.dsea.entityObject;


import com.ibm.mdm.base.db.ResultQueue1;
import java.util.Iterator;
import com.ibm.mdm.base.db.EntityMapping;
import com.ibm.pdq.annotation.Select;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * @generated
 */
public interface XContractRelJPNInquiryData {
  
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String tableAliasString = "tableAlias (" + 
                                            "XCONTRACTRELJPN => com.ibm.daimler.dsea.entityObject.EObjXContractRelJPN, " +
                                            "H_XCONTRACTRELJPN => com.ibm.daimler.dsea.entityObject.EObjXContractRelJPN" +
                                            ")";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getXContractRelJPNSql = "SELECT r.XCONTRACT_RELJPNPK_ID XCONTRACT_RELJPNPK_ID, r.CONTRACT_ID CONTRACT_ID, r.CONT_ID CONT_ID, r.MARKET_NAME MARKET_NAME, r.PERSON_ORG_CODE PERSON_ORG_CODE, r.CONTRACT_ROLE CONTRACT_ROLE, r.START_DT START_DT, r.END_DT END_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XCONTRACTRELJPN r WHERE r.XCONTRACT_RELJPNPK_ID = ? ";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXContractRelJPNParameters =
    "EObjXContractRelJPN.XContractRelJPNpkId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXContractRelJPNResults =
    "EObjXContractRelJPN.XContractRelJPNpkId," +
    "EObjXContractRelJPN.ContractId," +
    "EObjXContractRelJPN.ContId," +
    "EObjXContractRelJPN.MarketName," +
    "EObjXContractRelJPN.PersonOrgCode," +
    "EObjXContractRelJPN.ContractRole," +
    "EObjXContractRelJPN.StartDate," +
    "EObjXContractRelJPN.EndDate," +
    "EObjXContractRelJPN.lastUpdateDt," +
    "EObjXContractRelJPN.lastUpdateUser," +
    "EObjXContractRelJPN.lastUpdateTxId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getXContractRelJPNHistorySql = "SELECT r.H_XCONTRACT_RELJPNPK_ID hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.XCONTRACT_RELJPNPK_ID XCONTRACT_RELJPNPK_ID, r.CONTRACT_ID CONTRACT_ID, r.CONT_ID CONT_ID, r.MARKET_NAME MARKET_NAME, r.PERSON_ORG_CODE PERSON_ORG_CODE, r.CONTRACT_ROLE CONTRACT_ROLE, r.START_DT START_DT, r.END_DT END_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XCONTRACTRELJPN r WHERE r.H_XCONTRACT_RELJPNPK_ID = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXContractRelJPNHistoryParameters =
    "EObjXContractRelJPN.XContractRelJPNpkId," +
    "EObjXContractRelJPN.lastUpdateDt," +
    "EObjXContractRelJPN.lastUpdateDt";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXContractRelJPNHistoryResults =
    "EObjXContractRelJPN.historyIdPK," +
    "EObjXContractRelJPN.histActionCode," +
    "EObjXContractRelJPN.histCreatedBy," +
    "EObjXContractRelJPN.histCreateDt," +
    "EObjXContractRelJPN.histEndDt," +
    "EObjXContractRelJPN.XContractRelJPNpkId," +
    "EObjXContractRelJPN.ContractId," +
    "EObjXContractRelJPN.ContId," +
    "EObjXContractRelJPN.MarketName," +
    "EObjXContractRelJPN.PersonOrgCode," +
    "EObjXContractRelJPN.ContractRole," +
    "EObjXContractRelJPN.StartDate," +
    "EObjXContractRelJPN.EndDate," +
    "EObjXContractRelJPN.lastUpdateDt," +
    "EObjXContractRelJPN.lastUpdateUser," +
    "EObjXContractRelJPN.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getXContractRelJPNSql, pattern=tableAliasString)
  @EntityMapping(parameters=getXContractRelJPNParameters, results=getXContractRelJPNResults)
  Iterator<ResultQueue1<EObjXContractRelJPN>> getXContractRelJPN(Object[] parameters);  


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getXContractRelJPNHistorySql, pattern=tableAliasString)
  @EntityMapping(parameters=getXContractRelJPNHistoryParameters, results=getXContractRelJPNHistoryResults)
  Iterator<ResultQueue1<EObjXContractRelJPN>> getXContractRelJPNHistory(Object[] parameters);  


}


