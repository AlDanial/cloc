/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[df3ffb697234cdb1dde4240cbba6b723]
 */
package com.ibm.daimler.dsea.entityObject;


import com.ibm.mdm.base.db.EntityMapping;
import com.ibm.pdq.annotation.Select;


import com.dwl.tcrm.coreParty.entityObject.EObjContact;
import com.dwl.tcrm.coreParty.entityObject.EObjContactRel;

import com.ibm.mdm.base.db.ResultQueue2;
import com.ibm.mdm.base.db.ResultQueue3;

import java.util.Iterator;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * 
 * @generated
 */
public interface XContactRelExtInquiryData {

  /**
   * MDM_TODO: CDKWB0050I The generated parameter and result lists in this file should be checked to ensure that each matches its
   * associated SQL query. Each list entry must be comma separated and identify a field within an entity object class.
   */ 
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */ 
   public final static String tableAliasString1 = "tableAlias (" + 
     "CONTACTREL => com.dwl.tcrm.coreParty.entityObject.EObjContactRel, " + 
     "H_CONTACTREL => com.dwl.tcrm.coreParty.entityObject.EObjContactRel, " + 
     "CONTACT => com.dwl.tcrm.coreParty.entityObject.EObjContact, " + 
     "H_CONTACT => com.dwl.tcrm.coreParty.entityObject.EObjContact , " + 
     "CONTACTREL => com.ibm.daimler.dsea.entityObject.EObjXContactRelExt , " + 
     "H_CONTACTREL => com.ibm.daimler.dsea.entityObject.EObjXContactRelExt" + 
     ")";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension
   * XContactRel.
   *
   * @generated
   */ 
   public final static String getPartyRelationshipHistorySQL = "SELECT DISTINCT A.H_CONT_REL_ID AS HIST_ID_PK, A.H_ACTION_CODE, A.H_CREATED_BY, A.H_CREATE_DT, A.H_END_DT, A.CONT_REL_ID, A.REL_TP_CD, A.REL_DESC, A.START_DT, A.END_DT, A.TO_CONT_ID, A.FROM_CONT_ID, A.LAST_UPDATE_DT, A.LAST_UPDATE_USER, A.LAST_UPDATE_TX_ID, A.REL_ASSIGN_TP_CD, A.END_REASON_TP_CD, B.CONTACT_NAME, A.XRETAILER_CODE, A.XCONTACT_ROLE, A.XCONTACT_POSITION, A.XCONTACTREL_RETAILER_FLAG, A.XSOURCE_IDENT_TP_CD, A.XMODIFY_SYS_DT, A.DELETE_FLAG" + 
     " FROM H_CONTACTREL A, H_CONTACT B" + 
     " WHERE (B.H_CONT_ID = A.FROM_CONT_ID) AND (A.FROM_CONT_ID = ? AND A.TO_CONT_ID = ? OR (A.TO_CONT_ID = ? AND A.FROM_CONT_ID = ?)) AND (? BETWEEN A.H_CREATE_DT AND A.H_END_DT OR (? >= A.H_CREATE_DT AND A.H_END_DT IS NULL)) AND (( ? BETWEEN B.H_CREATE_DT AND B.H_END_DT ) OR ( ? >= B.H_CREATE_DT AND B.H_END_DT IS NULL ))";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyRelationshipHistoryParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.fromContId=FROM_CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.toContId=TO_CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.toContId=TO_CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.fromContId=FROM_CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.histCreateDt=H_CREATE_DT"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyRelationshipHistoryResults =
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.historyIdPK=HIST_ID_PK," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.histActionCode=H_ACTION_CODE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.histCreatedBy=H_CREATED_BY," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.histEndDt=H_END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.contRelIdPK=CONT_REL_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.relTpCd=REL_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.relDesc=REL_DESC," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.startDt=START_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.endDt=END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.toContId=TO_CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.fromContId=FROM_CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.relAssignTpCd=REL_ASSIGN_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.endReasonTpCd=END_REASON_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.contactName=CONTACT_NAME," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactRelExt.XRetailerCode=XRETAILER_CODE," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactRelExt.XContactRole=XCONTACT_ROLE," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactRelExt.XContactPosition=XCONTACT_POSITION," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactRelExt.XContactRelRetailerFlag=XCONTACTREL_RETAILER_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactRelExt.XSourceIdentifier=XSOURCE_IDENT_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactRelExt.XLastModifiedSystemDate=XMODIFY_SYS_DT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactRelExt.DeleteFlag=DELETE_FLAG"; 
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */ 
   public final static String resultSetMapping1 = "<rsm>" + 
     "<col number='1' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactRel' property='contRelIdPK'></col>" + 
     "<col number='2' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactRel' property='relTpCd'></col>" + 
     "<col number='3' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactRel' property='relDesc'></col>" + 
     "<col number='4' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactRel' property='startDt'></col>" + 
     "<col number='5' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactRel' property='endDt'></col>" + 
     "<col number='6' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactRel' property='toContId'></col>" + 
     "<col number='7' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactRel' property='fromContId'></col>" + 
     "<col number='8' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactRel' property='lastUpdateDt'></col>" + 
     "<col number='9' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactRel' property='lastUpdateUser'></col>" + 
     "<col number='10' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactRel' property='lastUpdateTxId'></col>" + 
     "<col number='11' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactRel' property='relAssignTpCd'></col>" + 
     "<col number='12' bean='com.dwl.tcrm.coreParty.entityObject.EObjContact' property='contactName'></col>" + 
     "<col number='13' bean='com.dwl.tcrm.coreParty.entityObject.EObjContact' property='lastUpdateTxId'></col>" + 
     "<col number='14' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactRel' property='endReasonTpCd'></col>" + 
     "<col number='15' bean='com.ibm.daimler.dsea.entityObject.EObjXContactRelExt' property='XRetailerCode'></col>" + 
     "<col number='16' bean='com.ibm.daimler.dsea.entityObject.EObjXContactRelExt' property='XContactRole'></col>" + 
     "<col number='17' bean='com.ibm.daimler.dsea.entityObject.EObjXContactRelExt' property='XContactPosition'></col>" + 
     "<col number='18' bean='com.ibm.daimler.dsea.entityObject.EObjXContactRelExt' property='XContactRelRetailerFlag'></col>" + 
     "<col number='19' bean='com.ibm.daimler.dsea.entityObject.EObjXContactRelExt' property='XSourceIdentifier'></col>" + 
     "<col number='20' bean='com.ibm.daimler.dsea.entityObject.EObjXContactRelExt' property='XLastModifiedSystemDate'></col>" + 
     "<col number='21' bean='com.ibm.daimler.dsea.entityObject.EObjXContactRelExt' property='DeleteFlag'></col>" + 
     "</rsm>";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension
   * XContactRel.
   *
   * @generated
   */ 
   public final static String getPartyRelationshipSQL = "SELECT CONTACTREL.CONT_REL_ID, CONTACTREL.REL_TP_CD, CONTACTREL.REL_DESC, CONTACTREL.START_DT, CONTACTREL.END_DT, CONTACTREL.TO_CONT_ID, CONTACTREL.FROM_CONT_ID, CONTACTREL.LAST_UPDATE_DT, CONTACTREL.LAST_UPDATE_USER, CONTACTREL.LAST_UPDATE_TX_ID, CONTACTREL.REL_ASSIGN_TP_CD, CONTACT.CONTACT_NAME, CONTACT.LAST_UPDATE_TX_ID, CONTACTREL.END_REASON_TP_CD, CONTACTREL.XRETAILER_CODE, CONTACTREL.XCONTACT_ROLE, CONTACTREL.XCONTACT_POSITION, CONTACTREL.XCONTACTREL_RETAILER_FLAG, CONTACTREL.XSOURCE_IDENT_TP_CD, CONTACTREL.XMODIFY_SYS_DT, CONTACTREL.DELETE_FLAG" + 
     " FROM CONTACTREL, CONTACT" + 
     " WHERE (CONTACT.CONT_ID = CONTACTREL.TO_CONT_ID) AND (CONTACTREL.FROM_CONT_ID = ? ) AND ( CONTACTREL.TO_CONT_ID = ? ) AND (CONTACTREL.END_DT IS NULL OR CONTACTREL.END_DT > ?)" + 
     " UNION SELECT CONTACTREL.CONT_REL_ID, CONTACTREL.REL_TP_CD, CONTACTREL.REL_DESC, CONTACTREL.START_DT , CONTACTREL.END_DT, CONTACTREL.TO_CONT_ID, CONTACTREL.FROM_CONT_ID, CONTACTREL.LAST_UPDATE_DT, CONTACTREL.LAST_UPDATE_USER, CONTACTREL.LAST_UPDATE_TX_ID, CONTACTREL.REL_ASSIGN_TP_CD, CONTACT.CONTACT_NAME, CONTACT.LAST_UPDATE_TX_ID, CONTACTREL.END_REASON_TP_CD, CONTACTREL.XRETAILER_CODE, CONTACTREL.XCONTACT_ROLE, CONTACTREL.XCONTACT_POSITION, CONTACTREL.XCONTACTREL_RETAILER_FLAG, CONTACTREL.XSOURCE_IDENT_TP_CD, CONTACTREL.XMODIFY_SYS_DT, CONTACTREL.DELETE_FLAG" + 
     " FROM CONTACTREL, CONTACT" + 
     " WHERE (CONTACT.CONT_ID = CONTACTREL.FROM_CONT_ID) AND ( CONTACTREL.TO_CONT_ID = ? ) AND ( CONTACTREL.FROM_CONT_ID = ? ) AND (CONTACTREL.END_DT IS NULL OR CONTACTREL.END_DT > ?)";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyRelationshipParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.fromContId=FROM_CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.toContId=TO_CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.endDt=END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.toContId=TO_CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.fromContId=FROM_CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.endDt=END_DT"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyRelationshipResults =
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.contRelIdPK=CONT_REL_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.relTpCd=REL_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.relDesc=REL_DESC," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.startDt=START_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.endDt=END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.toContId=TO_CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.fromContId=FROM_CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.relAssignTpCd=REL_ASSIGN_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.contactName=CONTACT_NAME," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.endReasonTpCd=END_REASON_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactRelExt.XRetailerCode=XRETAILER_CODE," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactRelExt.XContactRole=XCONTACT_ROLE," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactRelExt.XContactPosition=XCONTACT_POSITION," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactRelExt.XContactRelRetailerFlag=XCONTACTREL_RETAILER_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactRelExt.XSourceIdentifier=XSOURCE_IDENT_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactRelExt.XLastModifiedSystemDate=XMODIFY_SYS_DT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactRelExt.DeleteFlag=DELETE_FLAG"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension
   * XContactRel.
   *
   * @generated
   */ 
   public final static String getPartyRelationshipByIDSQL = "SELECT CONTACTREL.CONT_REL_ID, CONTACTREL.REL_TP_CD, CONTACTREL.REL_DESC, CONTACTREL.START_DT, CONTACTREL.END_DT, CONTACTREL.TO_CONT_ID, CONTACTREL.FROM_CONT_ID, CONTACTREL.LAST_UPDATE_DT, CONTACTREL.LAST_UPDATE_USER,CONTACTREL.REL_ASSIGN_TP_CD, CONTACTREL.END_REASON_TP_CD, CONTACTREL.LAST_UPDATE_TX_ID, CONTACT.CONTACT_NAME, CONTACTREL.XRETAILER_CODE, CONTACTREL.XCONTACT_ROLE, CONTACTREL.XCONTACT_POSITION, CONTACTREL.XCONTACTREL_RETAILER_FLAG, CONTACTREL.XSOURCE_IDENT_TP_CD, CONTACTREL.XMODIFY_SYS_DT, CONTACTREL.DELETE_FLAG" + 
     " FROM CONTACTREL,CONTACT" + 
     " WHERE CONTACTREL.CONT_REL_ID = ? AND CONTACT.CONT_ID = CONTACTREL.TO_CONT_ID";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyRelationshipByIDParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.contRelIdPK=CONT_REL_ID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyRelationshipByIDResults =
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.contRelIdPK=CONT_REL_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.relTpCd=REL_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.relDesc=REL_DESC," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.startDt=START_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.endDt=END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.toContId=TO_CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.fromContId=FROM_CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.relAssignTpCd=REL_ASSIGN_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.endReasonTpCd=END_REASON_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.contactName=CONTACT_NAME," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactRelExt.XRetailerCode=XRETAILER_CODE," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactRelExt.XContactRole=XCONTACT_ROLE," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactRelExt.XContactPosition=XCONTACT_POSITION," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactRelExt.XContactRelRetailerFlag=XCONTACTREL_RETAILER_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactRelExt.XSourceIdentifier=XSOURCE_IDENT_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactRelExt.XLastModifiedSystemDate=XMODIFY_SYS_DT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactRelExt.DeleteFlag=DELETE_FLAG"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension
   * XContactRel.
   *
   * @generated
   */ 
   public final static String getPartyRelationshipHistoryByIDSQL = "SELECT H_CONTACTREL.H_CONT_REL_ID AS HIST_ID_PK, H_CONTACTREL.REL_TP_CD, H_CONTACTREL.REL_DESC, H_CONTACTREL.START_DT, H_CONTACTREL.END_DT, H_CONTACTREL.TO_CONT_ID,H_CONTACTREL.FROM_CONT_ID, H_CONTACTREL.LAST_UPDATE_DT, H_CONTACTREL.LAST_UPDATE_USER,H_CONTACTREL.REL_ASSIGN_TP_CD, H_CONTACTREL.END_REASON_TP_CD, H_CONTACTREL.LAST_UPDATE_TX_ID, H_CONTACT.CONTACT_NAME, H_CONTACTREL.XRETAILER_CODE, H_CONTACTREL.XCONTACT_ROLE, H_CONTACTREL.XCONTACT_POSITION, H_CONTACTREL.XCONTACTREL_RETAILER_FLAG, H_CONTACTREL.XSOURCE_IDENT_TP_CD, H_CONTACTREL.XMODIFY_SYS_DT, H_CONTACTREL.DELETE_FLAG" + 
     " FROM H_CONTACTREL,H_CONTACT" + 
     " WHERE H_CONTACTREL.H_CONT_REL_ID = ? AND H_CONTACT.H_CONT_ID = H_CONTACTREL.TO_CONT_ID AND (? BETWEEN H_CONTACTREL.H_CREATE_DT AND H_CONTACTREL.H_END_DT OR (? >= H_CONTACTREL.H_CREATE_DT AND H_CONTACTREL.H_END_DT IS NULL )) AND (( ? BETWEEN H_CONTACT.H_CREATE_DT AND H_CONTACT.H_END_DT ) OR ( ? >= H_CONTACT.H_CREATE_DT AND H_CONTACT.H_END_DT IS NULL ))";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyRelationshipHistoryByIDParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.historyIdPK=H_CONT_REL_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.histCreateDt=H_CREATE_DT"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyRelationshipHistoryByIDResults =
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.historyIdPK=HIST_ID_PK," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.relTpCd=REL_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.relDesc=REL_DESC," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.startDt=START_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.endDt=END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.toContId=TO_CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.fromContId=FROM_CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.relAssignTpCd=REL_ASSIGN_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.endReasonTpCd=END_REASON_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.contactName=CONTACT_NAME," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactRelExt.XRetailerCode=XRETAILER_CODE," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactRelExt.XContactRole=XCONTACT_ROLE," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactRelExt.XContactPosition=XCONTACT_POSITION," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactRelExt.XContactRelRetailerFlag=XCONTACTREL_RETAILER_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactRelExt.XSourceIdentifier=XSOURCE_IDENT_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactRelExt.XLastModifiedSystemDate=XMODIFY_SYS_DT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactRelExt.DeleteFlag=DELETE_FLAG"; 
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */ 
   public final static String resultSetMapping2 = "<rsm>" + 
     "<col number='1' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactRel' property='historyIdPK'></col>" + 
     "<col number='2' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactRel' property='histActionCode'></col>" + 
     "<col number='3' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactRel' property='histCreatedBy'></col>" + 
     "<col number='4' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactRel' property='histCreateDt'></col>" + 
     "<col number='5' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactRel' property='histEndDt'></col>" + 
     "<col number='6' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactRel' property='contRelIdPK'></col>" + 
     "<col number='7' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactRel' property='relTpCd'></col>" + 
     "<col number='8' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactRel' property='relDesc'></col>" + 
     "<col number='9' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactRel' property='startDt'></col>" + 
     "<col number='10' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactRel' property='endDt'></col>" + 
     "<col number='11' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactRel' property='toContId'></col>" + 
     "<col number='12' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactRel' property='fromContId'></col>" + 
     "<col number='13' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactRel' property='lastUpdateDt'></col>" + 
     "<col number='14' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactRel' property='lastUpdateUser'></col>" + 
     "<col number='15' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactRel' property='lastUpdateTxId'></col>" + 
     "<col number='16' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactRel' property='relAssignTpCd'></col>" + 
     "<col number='17' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactRel' property='endReasonTpCd'></col>" + 
     "<col number='18' bean='com.dwl.tcrm.coreParty.entityObject.EObjContact' property='contactName'></col>" + 
     "<col number='19' bean='com.ibm.daimler.dsea.entityObject.EObjXContactRelExt' property='XRetailerCode'></col>" + 
     "<col number='20' bean='com.ibm.daimler.dsea.entityObject.EObjXContactRelExt' property='XContactRole'></col>" + 
     "<col number='21' bean='com.ibm.daimler.dsea.entityObject.EObjXContactRelExt' property='XContactPosition'></col>" + 
     "<col number='22' bean='com.ibm.daimler.dsea.entityObject.EObjXContactRelExt' property='XContactRelRetailerFlag'></col>" + 
     "<col number='23' bean='com.ibm.daimler.dsea.entityObject.EObjXContactRelExt' property='XSourceIdentifier'></col>" + 
     "<col number='24' bean='com.ibm.daimler.dsea.entityObject.EObjXContactRelExt' property='XLastModifiedSystemDate'></col>" + 
     "<col number='25' bean='com.ibm.daimler.dsea.entityObject.EObjXContactRelExt' property='DeleteFlag'></col>" + 
     "</rsm>";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension
   * XContactRel.
   *
   * @generated
   */ 
   public final static String getPartyRelationshipsHistorySQL = "SELECT DISTINCT A.H_CONT_REL_ID AS HIST_ID_PK, A.H_ACTION_CODE , A.H_CREATED_BY , A.H_CREATE_DT, A.H_END_DT , A.CONT_REL_ID , A.REL_TP_CD , A.REL_DESC , A.START_DT , A.END_DT , A.TO_CONT_ID , A.FROM_CONT_ID , A.LAST_UPDATE_DT , A.LAST_UPDATE_USER , A.LAST_UPDATE_TX_ID , A.REL_ASSIGN_TP_CD , A.END_REASON_TP_CD , B.CONTACT_NAME, A.XRETAILER_CODE, A.XCONTACT_ROLE, A.XCONTACT_POSITION, A.XCONTACTREL_RETAILER_FLAG, A.XSOURCE_IDENT_TP_CD, A.XMODIFY_SYS_DT, A.DELETE_FLAG" + 
     " FROM H_CONTACTREL A, H_CONTACT B" + 
     " WHERE (A.TO_CONT_ID = ? AND (B.CONT_ID = A.FROM_CONT_ID) AND (( ? BETWEEN A.H_CREATE_DT AND A.H_END_DT ) OR ( ? >= A.H_CREATE_DT AND A.H_END_DT IS NULL )) AND (( ? BETWEEN B.H_CREATE_DT AND B.H_END_DT ) OR ( ? >= B.H_CREATE_DT AND B.H_END_DT IS NULL )))" + 
     " UNION ALL SELECT DISTINCT A.H_CONT_REL_ID AS HIST_ID_PK, A.H_ACTION_CODE , A.H_CREATED_BY , A.H_CREATE_DT , A.H_END_DT , A.CONT_REL_ID , A.REL_TP_CD , A.REL_DESC , A.START_DT , A.END_DT , A.TO_CONT_ID , A.FROM_CONT_ID, A.LAST_UPDATE_DT , A.LAST_UPDATE_USER, A.LAST_UPDATE_TX_ID , A.REL_ASSIGN_TP_CD , A.END_REASON_TP_CD, B.CONTACT_NAME, A.XRETAILER_CODE, A.XCONTACT_ROLE, A.XCONTACT_POSITION, A.XCONTACTREL_RETAILER_FLAG, A.XSOURCE_IDENT_TP_CD, A.XMODIFY_SYS_DT, A.DELETE_FLAG" + 
     " FROM H_CONTACTREL A, H_CONTACT B" + 
     " WHERE (A.FROM_CONT_ID = ? AND (B.H_CONT_ID = A.TO_CONT_ID) AND (( ? BETWEEN A.H_CREATE_DT AND A.H_END_DT ) OR ( ? >= A.H_CREATE_DT AND A.H_END_DT IS NULL )) AND (( ? BETWEEN B.H_CREATE_DT AND B.H_END_DT ) OR ( ? >= B.H_CREATE_DT AND B.H_END_DT IS NULL )))";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyRelationshipsHistoryParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.toContId=TO_CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.fromContId=FROM_CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.histCreateDt=H_CREATE_DT"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyRelationshipsHistoryResults =
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.historyIdPK=HIST_ID_PK," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.histActionCode=H_ACTION_CODE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.histCreatedBy=H_CREATED_BY," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.histEndDt=H_END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.contRelIdPK=CONT_REL_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.relTpCd=REL_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.relDesc=REL_DESC," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.startDt=START_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.endDt=END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.toContId=TO_CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.fromContId=FROM_CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.relAssignTpCd=REL_ASSIGN_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.endReasonTpCd=END_REASON_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.contactName=CONTACT_NAME," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactRelExt.XRetailerCode=XRETAILER_CODE," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactRelExt.XContactRole=XCONTACT_ROLE," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactRelExt.XContactPosition=XCONTACT_POSITION," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactRelExt.XContactRelRetailerFlag=XCONTACTREL_RETAILER_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactRelExt.XSourceIdentifier=XSOURCE_IDENT_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactRelExt.XLastModifiedSystemDate=XMODIFY_SYS_DT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactRelExt.DeleteFlag=DELETE_FLAG"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension
   * XContactRel.
   *
   * @generated
   */ 
   public final static String getActivePartyRelationshipsSQL = "SELECT CONTACTREL.CONT_REL_ID, CONTACTREL.REL_TP_CD, CONTACTREL.REL_DESC, CONTACTREL.START_DT, CONTACTREL.END_DT, CONTACTREL.TO_CONT_ID, CONTACTREL.FROM_CONT_ID, CONTACTREL.LAST_UPDATE_DT, CONTACTREL.LAST_UPDATE_USER, CONTACTREL.LAST_UPDATE_TX_ID, CONTACTREL.REL_ASSIGN_TP_CD, CONTACT.CONTACT_NAME, CONTACT.LAST_UPDATE_TX_ID, CONTACTREL.END_REASON_TP_CD, CONTACTREL.XRETAILER_CODE, CONTACTREL.XCONTACT_ROLE, CONTACTREL.XCONTACT_POSITION, CONTACTREL.XCONTACTREL_RETAILER_FLAG, CONTACTREL.XSOURCE_IDENT_TP_CD, CONTACTREL.XMODIFY_SYS_DT, CONTACTREL.DELETE_FLAG" + 
     " FROM CONTACTREL, CONTACT" + 
     " WHERE ((CONTACTREL.FROM_CONT_ID = ? AND CONTACT.CONT_ID = CONTACTREL.TO_CONT_ID AND (CONTACTREL.END_DT IS NULL OR CONTACTREL.END_DT > ?)) OR (CONTACTREL.TO_CONT_ID = ? AND CONTACT.CONT_ID = CONTACTREL.FROM_CONT_ID AND (CONTACTREL.END_DT IS NULL OR CONTACTREL.END_DT > ?)))";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getActivePartyRelationshipsParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.fromContId=FROM_CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.endDt=END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.toContId=TO_CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.endDt=END_DT"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getActivePartyRelationshipsResults =
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.contRelIdPK=CONT_REL_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.relTpCd=REL_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.relDesc=REL_DESC," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.startDt=START_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.endDt=END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.toContId=TO_CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.fromContId=FROM_CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.relAssignTpCd=REL_ASSIGN_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.contactName=CONTACT_NAME," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.endReasonTpCd=END_REASON_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactRelExt.XRetailerCode=XRETAILER_CODE," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactRelExt.XContactRole=XCONTACT_ROLE," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactRelExt.XContactPosition=XCONTACT_POSITION," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactRelExt.XContactRelRetailerFlag=XCONTACTREL_RETAILER_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactRelExt.XSourceIdentifier=XSOURCE_IDENT_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactRelExt.XLastModifiedSystemDate=XMODIFY_SYS_DT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactRelExt.DeleteFlag=DELETE_FLAG"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension
   * XContactRel.
   *
   * @generated
   */ 
   public final static String getInactivePartyRelationshipsSQL = "SELECT CONTACTREL.CONT_REL_ID, CONTACTREL.REL_TP_CD,CONTACTREL.REL_DESC, CONTACTREL.START_DT, CONTACTREL.END_DT, CONTACTREL.TO_CONT_ID,CONTACTREL.FROM_CONT_ID, CONTACTREL.LAST_UPDATE_DT, CONTACTREL.LAST_UPDATE_USER,CONTACTREL.LAST_UPDATE_TX_ID,CONTACTREL.REL_ASSIGN_TP_CD, CONTACT.CONTACT_NAME,CONTACT.LAST_UPDATE_TX_ID,CONTACTREL.END_REASON_TP_CD, CONTACTREL.XRETAILER_CODE, CONTACTREL.XCONTACT_ROLE, CONTACTREL.XCONTACT_POSITION, CONTACTREL.XCONTACTREL_RETAILER_FLAG, CONTACTREL.XSOURCE_IDENT_TP_CD, CONTACTREL.XMODIFY_SYS_DT, CONTACTREL.DELETE_FLAG" + 
     " FROM CONTACTREL,CONTACT" + 
     " WHERE ((CONTACTREL.FROM_CONT_ID =? AND CONTACT.CONT_ID = CONTACTREL.TO_CONT_ID ) OR (CONTACTREL.TO_CONT_ID = ? AND CONTACT.CONT_ID = CONTACTREL.FROM_CONT_ID)) AND (CONTACTREL.END_DT < ? )";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getInactivePartyRelationshipsParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.fromContId=FROM_CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.toContId=TO_CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.endDt=END_DT"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getInactivePartyRelationshipsResults =
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.contRelIdPK=CONT_REL_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.relTpCd=REL_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.relDesc=REL_DESC," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.startDt=START_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.endDt=END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.toContId=TO_CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.fromContId=FROM_CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.relAssignTpCd=REL_ASSIGN_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.contactName=CONTACT_NAME," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.endReasonTpCd=END_REASON_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactRelExt.XRetailerCode=XRETAILER_CODE," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactRelExt.XContactRole=XCONTACT_ROLE," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactRelExt.XContactPosition=XCONTACT_POSITION," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactRelExt.XContactRelRetailerFlag=XCONTACTREL_RETAILER_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactRelExt.XSourceIdentifier=XSOURCE_IDENT_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactRelExt.XLastModifiedSystemDate=XMODIFY_SYS_DT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactRelExt.DeleteFlag=DELETE_FLAG"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension
   * XContactRel.
   *
   * @generated
   */ 
   public final static String getPartyRelationshipsSQL = "SELECT CONTACTREL.CONT_REL_ID,CONTACTREL.REL_TP_CD,CONTACTREL.REL_DESC, CONTACTREL.START_DT, CONTACTREL.END_DT, CONTACTREL.TO_CONT_ID, CONTACTREL.FROM_CONT_ID, CONTACTREL.LAST_UPDATE_DT,CONTACTREL.LAST_UPDATE_USER, CONTACTREL.LAST_UPDATE_TX_ID,CONTACTREL.REL_ASSIGN_TP_CD, CONTACT.CONTACT_NAME, CONTACT.LAST_UPDATE_TX_ID, CONTACTREL.END_REASON_TP_CD, CONTACTREL.XRETAILER_CODE, CONTACTREL.XCONTACT_ROLE, CONTACTREL.XCONTACT_POSITION, CONTACTREL.XCONTACTREL_RETAILER_FLAG, CONTACTREL.XSOURCE_IDENT_TP_CD, CONTACTREL.XMODIFY_SYS_DT, CONTACTREL.DELETE_FLAG" + 
     " FROM CONTACTREL, CONTACT" + 
     " WHERE (( CONTACTREL.TO_CONT_ID = ? AND CONTACT.CONT_ID = CONTACTREL.FROM_CONT_ID) OR (CONTACTREL.FROM_CONT_ID =? AND CONTACT.CONT_ID = CONTACTREL.TO_CONT_ID))";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyRelationshipsParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.toContId=TO_CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.fromContId=FROM_CONT_ID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyRelationshipsResults =
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.contRelIdPK=CONT_REL_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.relTpCd=REL_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.relDesc=REL_DESC," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.startDt=START_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.endDt=END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.toContId=TO_CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.fromContId=FROM_CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.relAssignTpCd=REL_ASSIGN_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.contactName=CONTACT_NAME," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.endReasonTpCd=END_REASON_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactRelExt.XRetailerCode=XRETAILER_CODE," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactRelExt.XContactRole=XCONTACT_ROLE," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactRelExt.XContactPosition=XCONTACT_POSITION," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactRelExt.XContactRelRetailerFlag=XCONTACTREL_RETAILER_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactRelExt.XSourceIdentifier=XSOURCE_IDENT_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactRelExt.XLastModifiedSystemDate=XMODIFY_SYS_DT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactRelExt.DeleteFlag=DELETE_FLAG"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension
   * XContactRel.
   *
   * @generated
   */ 
   public final static String getPartyRelationshipsImageSQL = "SELECT DISTINCT A.H_CONT_REL_ID AS HIST_ID_PK, A.H_ACTION_CODE, A.H_CREATED_BY, A.H_CREATE_DT, A.H_END_DT, A.CONT_REL_ID, A.REL_TP_CD, A.REL_DESC, A.START_DT, A.END_DT, A.TO_CONT_ID, A.FROM_CONT_ID, A.LAST_UPDATE_DT, A.LAST_UPDATE_USER, A.LAST_UPDATE_TX_ID, A.REL_ASSIGN_TP_CD, A.END_REASON_TP_CD, B.CONTACT_NAME, A.XRETAILER_CODE, A.XCONTACT_ROLE, A.XCONTACT_POSITION, A.XCONTACTREL_RETAILER_FLAG, A.XSOURCE_IDENT_TP_CD, A.XMODIFY_SYS_DT, A.DELETE_FLAG" + 
     " FROM H_CONTACTREL A, H_CONTACT B" + 
     " WHERE ((A.TO_CONT_ID = ? AND B.CONT_ID = A.FROM_CONT_ID) OR (A.FROM_CONT_ID = ? AND B.CONT_ID = A.TO_CONT_ID)) AND ( A.H_CREATE_DT BETWEEN ? AND ? ) AND ( B.H_CREATE_DT BETWEEN ? AND ? )";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyRelationshipsImageParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.toContId=TO_CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.fromContId=FROM_CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.histCreateDt=H_CREATE_DT"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyRelationshipsImageResults =
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.historyIdPK=HIST_ID_PK," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.histActionCode=H_ACTION_CODE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.histCreatedBy=H_CREATED_BY," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.histEndDt=H_END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.contRelIdPK=CONT_REL_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.relTpCd=REL_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.relDesc=REL_DESC," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.startDt=START_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.endDt=END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.toContId=TO_CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.fromContId=FROM_CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.relAssignTpCd=REL_ASSIGN_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.endReasonTpCd=END_REASON_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.contactName=CONTACT_NAME," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactRelExt.XRetailerCode=XRETAILER_CODE," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactRelExt.XContactRole=XCONTACT_ROLE," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactRelExt.XContactPosition=XCONTACT_POSITION," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactRelExt.XContactRelRetailerFlag=XCONTACTREL_RETAILER_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactRelExt.XSourceIdentifier=XSOURCE_IDENT_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactRelExt.XLastModifiedSystemDate=XMODIFY_SYS_DT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactRelExt.DeleteFlag=DELETE_FLAG"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension
   * XContactRel.
   *
   * @generated
   */ 
   public final static String getPartyRelationshipsLightImageSQL = "SELECT DISTINCT A.CONT_REL_ID, A.LAST_UPDATE_DT, A.XRETAILER_CODE, A.XCONTACT_ROLE, A.XCONTACT_POSITION, A.XCONTACTREL_RETAILER_FLAG, A.XSOURCE_IDENT_TP_CD, A.XMODIFY_SYS_DT, A.DELETE_FLAG" + 
     " FROM H_CONTACTREL A, H_CONTACT B" + 
     " WHERE ((A.TO_CONT_ID = ? AND B.CONT_ID = A.FROM_CONT_ID) OR (A.FROM_CONT_ID = ? AND B.CONT_ID = A.TO_CONT_ID)) AND ( A.H_CREATE_DT BETWEEN ? AND ? )";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyRelationshipsLightImageParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.toContId=TO_CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.fromContId=FROM_CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.histCreateDt=H_CREATE_DT"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyRelationshipsLightImageResults =
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.contRelIdPK=CONT_REL_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactRelExt.XRetailerCode=XRETAILER_CODE," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactRelExt.XContactRole=XCONTACT_ROLE," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactRelExt.XContactPosition=XCONTACT_POSITION," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactRelExt.XContactRelRetailerFlag=XCONTACTREL_RETAILER_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactRelExt.XSourceIdentifier=XSOURCE_IDENT_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactRelExt.XLastModifiedSystemDate=XMODIFY_SYS_DT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactRelExt.DeleteFlag=DELETE_FLAG"; 


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getPartyRelationshipHistorySQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getPartyRelationshipHistoryParameters, results=getPartyRelationshipHistoryResults)
  		Iterator<ResultQueue3<EObjContactRel, EObjContact, EObjXContactRelExt>> getPartyRelationshipHistory(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getPartyRelationshipSQL , pattern=resultSetMapping1)
  @EntityMapping(parameters=getPartyRelationshipParameters, results=getPartyRelationshipResults)
  		Iterator<ResultQueue3<EObjContactRel, EObjContact, EObjXContactRelExt>> getPartyRelationship(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getPartyRelationshipByIDSQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getPartyRelationshipByIDParameters, results=getPartyRelationshipByIDResults)
  		Iterator<ResultQueue3<EObjContactRel, EObjContact, EObjXContactRelExt>> getPartyRelationshipByID(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getPartyRelationshipHistoryByIDSQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getPartyRelationshipHistoryByIDParameters, results=getPartyRelationshipHistoryByIDResults)
  		Iterator<ResultQueue3<EObjContactRel, EObjContact, EObjXContactRelExt>> getPartyRelationshipHistoryByID(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getPartyRelationshipsHistorySQL , pattern=resultSetMapping2)
  @EntityMapping(parameters=getPartyRelationshipsHistoryParameters, results=getPartyRelationshipsHistoryResults)
  		Iterator<ResultQueue3<EObjContactRel, EObjContact, EObjXContactRelExt>> getPartyRelationshipsHistory(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getActivePartyRelationshipsSQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getActivePartyRelationshipsParameters, results=getActivePartyRelationshipsResults)
  		Iterator<ResultQueue3<EObjContactRel, EObjContact, EObjXContactRelExt>> getActivePartyRelationships(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getInactivePartyRelationshipsSQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getInactivePartyRelationshipsParameters, results=getInactivePartyRelationshipsResults)
  		Iterator<ResultQueue3<EObjContactRel, EObjContact, EObjXContactRelExt>> getInactivePartyRelationships(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getPartyRelationshipsSQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getPartyRelationshipsParameters, results=getPartyRelationshipsResults)
  		Iterator<ResultQueue3<EObjContactRel, EObjContact, EObjXContactRelExt>> getPartyRelationships(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getPartyRelationshipsImageSQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getPartyRelationshipsImageParameters, results=getPartyRelationshipsImageResults)
  		Iterator<ResultQueue3<EObjContactRel, EObjContact, EObjXContactRelExt>> getPartyRelationshipsImage(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getPartyRelationshipsLightImageSQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getPartyRelationshipsLightImageParameters, results=getPartyRelationshipsLightImageResults)
  		Iterator<ResultQueue2<EObjContactRel, EObjXContactRelExt>> getPartyRelationshipsLightImage(Object[] parameters);
 
}


