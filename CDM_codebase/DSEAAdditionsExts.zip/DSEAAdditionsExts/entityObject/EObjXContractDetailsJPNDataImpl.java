package com.ibm.daimler.dsea.entityObject;

import com.ibm.pdq.runtime.generator.BaseParameterHandler;
import java.util.Iterator;
import java.sql.PreparedStatement;
import com.ibm.pdq.runtime.statement.StatementDescriptor;
import com.ibm.pdq.runtime.generator.BaseData;
import com.ibm.daimler.dsea.entityObject.EObjXContractDetailsJPN;
import java.sql.SQLException;
import com.ibm.pdq.annotation.Metadata;
import com.ibm.pdq.runtime.generator.BaseRowHandler;
import com.ibm.pdq.runtime.statement.SqlStatementType;
import java.sql.Types;


/**
 * <!-- begin-user-doc -->
 * 
 * <!-- end-user-doc -->
 * 
 * @generated
 */
public class EObjXContractDetailsJPNDataImpl  extends BaseData implements EObjXContractDetailsJPNData
{

  /**
   * @generated
   */
  public static final String generatorVersion = "3.200.75";

  /**
   * @generated
   */
  public static final String identifier = "EObjXContractDetailsJPNData";

  /**
   * @generated
   */
  public static final long generationTime = 0x0000016676bfed0bL;

  /**
   * @generated
   */
  public static final String collection = "NULLID";

  /**
   * @generated
   */
  public static final String packageVersion = null;

  /**
   * @generated
   */
  public static final boolean forceSingleBindIsolation = false;

  /**
   * @generated
   */
  public EObjXContractDetailsJPNDataImpl()
  {
    super();
  } 

  /**
   * @generated
   */
  public String getGeneratorVersion()
  {
    return generatorVersion;
  }

  /**
   * @Select( sql="select XContract_JPNPK_ID, CONT_ID, FINANCE_PRODUCT, CONTRACT_NUMBER, CONTRACT_ST_TP_CD, MARKET_NAME, GLOBAL_VIN, SOURCE_IDENT_TP_CD, START_DT, END_DT, MODIFY_SYS_DT, SFDC_ID, BATCH_IND, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from XCONTRACTDETAILSJPN where XContract_JPNPK_ID = ? " )
   * 
   * @generated
   */
  public Iterator<EObjXContractDetailsJPN> getEObjXContractDetailsJPN (Long xContractJPNpkId)
  {
    return queryIterator (getEObjXContractDetailsJPNStatementDescriptor, xContractJPNpkId);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getEObjXContractDetailsJPNStatementDescriptor = createStatementDescriptor (
    "getEObjXContractDetailsJPN(Long)",
    "select XContract_JPNPK_ID, CONT_ID, FINANCE_PRODUCT, CONTRACT_NUMBER, CONTRACT_ST_TP_CD, MARKET_NAME, GLOBAL_VIN, SOURCE_IDENT_TP_CD, START_DT, END_DT, MODIFY_SYS_DT, SFDC_ID, BATCH_IND, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from XCONTRACTDETAILSJPN where XContract_JPNPK_ID = ? ",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"xcontract_jpnpk_id", "cont_id", "finance_product", "contract_number", "contract_st_tp_cd", "market_name", "global_vin", "source_ident_tp_cd", "start_dt", "end_dt", "modify_sys_dt", "sfdc_id", "batch_ind", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetEObjXContractDetailsJPNParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetEObjXContractDetailsJPNRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 19, 255, 250, 19, 50, 50, 19, 0, 0, 0, 50, 5, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    1);

  /**
   * @generated
   */
  public static class GetEObjXContractDetailsJPNParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setLong (stmt, 1, Types.BIGINT, (Long)parameters[0]);
    }
  }

  /**
   * @generated
   */
  public static class GetEObjXContractDetailsJPNRowHandler extends BaseRowHandler<EObjXContractDetailsJPN>
  {
    /**
     * @generated
     */
    public EObjXContractDetailsJPN handle (java.sql.ResultSet rs, EObjXContractDetailsJPN returnObject) throws java.sql.SQLException
    {
      returnObject = new EObjXContractDetailsJPN ();
      returnObject.setXContractJPNpkId(getLongObject (rs, 1)); 
      returnObject.setContId(getLongObject (rs, 2)); 
      returnObject.setFinanceProduct(getString (rs, 3)); 
      returnObject.setContractNumber(getString (rs, 4)); 
      returnObject.setContractStatus(getLongObject (rs, 5)); 
      returnObject.setMarketName(getString (rs, 6)); 
      returnObject.setGlobalVIN(getString (rs, 7)); 
      returnObject.setSourceIdentifier(getLongObject (rs, 8)); 
      returnObject.setStartDate(getTimestamp (rs, 9)); 
      returnObject.setEndDate(getTimestamp (rs, 10)); 
      returnObject.setLastModifiedSystemDate(getTimestamp (rs, 11)); 
      returnObject.setSFDCId(getString (rs, 12)); 
      returnObject.setBatchInd(getString (rs, 13)); 
      returnObject.setLastUpdateDt(getTimestamp (rs, 14)); 
      returnObject.setLastUpdateUser(getString (rs, 15)); 
      returnObject.setLastUpdateTxId(getLongObject (rs, 16)); 
    
      return returnObject;
    }
  }

  /**
   * @Update( sql="insert into XCONTRACTDETAILSJPN (XContract_JPNPK_ID, CONT_ID, FINANCE_PRODUCT, CONTRACT_NUMBER, CONTRACT_ST_TP_CD, MARKET_NAME, GLOBAL_VIN, SOURCE_IDENT_TP_CD, START_DT, END_DT, MODIFY_SYS_DT, SFDC_ID, BATCH_IND, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( :xContractJPNpkId, :contId, :financeProduct, :contractNumber, :contractStatus, :marketName, :globalVIN, :sourceIdentifier, :startDate, :endDate, :lastModifiedSystemDate, :sFDCId, :batchInd, :lastUpdateDt, :lastUpdateUser, :lastUpdateTxId)" )
   * 
   * @generated
   */
  public int createEObjXContractDetailsJPN (EObjXContractDetailsJPN e)
  {
    return update (createEObjXContractDetailsJPNStatementDescriptor, e);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor createEObjXContractDetailsJPNStatementDescriptor = createStatementDescriptor (
    "createEObjXContractDetailsJPN(com.ibm.daimler.dsea.entityObject.EObjXContractDetailsJPN)",
    "insert into XCONTRACTDETAILSJPN (XContract_JPNPK_ID, CONT_ID, FINANCE_PRODUCT, CONTRACT_NUMBER, CONTRACT_ST_TP_CD, MARKET_NAME, GLOBAL_VIN, SOURCE_IDENT_TP_CD, START_DT, END_DT, MODIFY_SYS_DT, SFDC_ID, BATCH_IND, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values(  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? )",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.INSERT,
    null,
    new CreateEObjXContractDetailsJPNParameterHandler (),
    new int[][]{{Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 19, 255, 250, 19, 50, 50, 19, 0, 0, 0, 50, 5, 0, 0, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    2);

  /**
   * @generated
   */
  public static class CreateEObjXContractDetailsJPNParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      EObjXContractDetailsJPN bean0 = (EObjXContractDetailsJPN) parameters[0];
      setLong (stmt, 1, Types.BIGINT, (Long)bean0.getXContractJPNpkId());
      setLong (stmt, 2, Types.BIGINT, (Long)bean0.getContId());
      setString (stmt, 3, Types.VARCHAR, (String)bean0.getFinanceProduct());
      setString (stmt, 4, Types.VARCHAR, (String)bean0.getContractNumber());
      setLong (stmt, 5, Types.BIGINT, (Long)bean0.getContractStatus());
      setString (stmt, 6, Types.VARCHAR, (String)bean0.getMarketName());
      setString (stmt, 7, Types.VARCHAR, (String)bean0.getGlobalVIN());
      setLong (stmt, 8, Types.BIGINT, (Long)bean0.getSourceIdentifier());
      setTimestamp (stmt, 9, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getStartDate());
      setTimestamp (stmt, 10, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getEndDate());
      setTimestamp (stmt, 11, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastModifiedSystemDate());
      setString (stmt, 12, Types.VARCHAR, (String)bean0.getSFDCId());
      setString (stmt, 13, Types.VARCHAR, (String)bean0.getBatchInd());
      setTimestamp (stmt, 14, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUpdateDt());
      setString (stmt, 15, Types.VARCHAR, (String)bean0.getLastUpdateUser());
      setLong (stmt, 16, Types.BIGINT, (Long)bean0.getLastUpdateTxId());
    }
  }

  /**
   * @Update( sql="update XCONTRACTDETAILSJPN set CONT_ID = :contId, FINANCE_PRODUCT = :financeProduct, CONTRACT_NUMBER = :contractNumber, CONTRACT_ST_TP_CD = :contractStatus, MARKET_NAME = :marketName, GLOBAL_VIN = :globalVIN, SOURCE_IDENT_TP_CD = :sourceIdentifier, START_DT = :startDate, END_DT = :endDate, MODIFY_SYS_DT = :lastModifiedSystemDate, SFDC_ID = :sFDCId, BATCH_IND = :batchInd, LAST_UPDATE_DT = :lastUpdateDt, LAST_UPDATE_USER = :lastUpdateUser, LAST_UPDATE_TX_ID = :lastUpdateTxId where XContract_JPNPK_ID = :xContractJPNpkId and LAST_UPDATE_DT = :oldLastUpdateDt" )
   * 
   * @generated
   */
  public int updateEObjXContractDetailsJPN (EObjXContractDetailsJPN e)
  {
    return update (updateEObjXContractDetailsJPNStatementDescriptor, e);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor updateEObjXContractDetailsJPNStatementDescriptor = createStatementDescriptor (
    "updateEObjXContractDetailsJPN(com.ibm.daimler.dsea.entityObject.EObjXContractDetailsJPN)",
    "update XCONTRACTDETAILSJPN set CONT_ID =  ? , FINANCE_PRODUCT =  ? , CONTRACT_NUMBER =  ? , CONTRACT_ST_TP_CD =  ? , MARKET_NAME =  ? , GLOBAL_VIN =  ? , SOURCE_IDENT_TP_CD =  ? , START_DT =  ? , END_DT =  ? , MODIFY_SYS_DT =  ? , SFDC_ID =  ? , BATCH_IND =  ? , LAST_UPDATE_DT =  ? , LAST_UPDATE_USER =  ? , LAST_UPDATE_TX_ID =  ?  where XContract_JPNPK_ID =  ?  and LAST_UPDATE_DT =  ? ",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.UPDATE,
    null,
    new UpdateEObjXContractDetailsJPNParameterHandler (),
    new int[][]{{Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP}, {19, 255, 250, 19, 50, 50, 19, 0, 0, 0, 50, 5, 0, 0, 19, 19, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    3);

  /**
   * @generated
   */
  public static class UpdateEObjXContractDetailsJPNParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      EObjXContractDetailsJPN bean0 = (EObjXContractDetailsJPN) parameters[0];
      setLong (stmt, 1, Types.BIGINT, (Long)bean0.getContId());
      setString (stmt, 2, Types.VARCHAR, (String)bean0.getFinanceProduct());
      setString (stmt, 3, Types.VARCHAR, (String)bean0.getContractNumber());
      setLong (stmt, 4, Types.BIGINT, (Long)bean0.getContractStatus());
      setString (stmt, 5, Types.VARCHAR, (String)bean0.getMarketName());
      setString (stmt, 6, Types.VARCHAR, (String)bean0.getGlobalVIN());
      setLong (stmt, 7, Types.BIGINT, (Long)bean0.getSourceIdentifier());
      setTimestamp (stmt, 8, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getStartDate());
      setTimestamp (stmt, 9, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getEndDate());
      setTimestamp (stmt, 10, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastModifiedSystemDate());
      setString (stmt, 11, Types.VARCHAR, (String)bean0.getSFDCId());
      setString (stmt, 12, Types.VARCHAR, (String)bean0.getBatchInd());
      setTimestamp (stmt, 13, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUpdateDt());
      setString (stmt, 14, Types.VARCHAR, (String)bean0.getLastUpdateUser());
      setLong (stmt, 15, Types.BIGINT, (Long)bean0.getLastUpdateTxId());
      setLong (stmt, 16, Types.BIGINT, (Long)bean0.getXContractJPNpkId());
      setTimestamp (stmt, 17, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getOldLastUpdateDt());
    }
  }

  /**
   * @Update( sql="delete from XCONTRACTDETAILSJPN where XContract_JPNPK_ID = ?" )
   * 
   * @generated
   */
  public int deleteEObjXContractDetailsJPN (Long xContractJPNpkId)
  {
    return update (deleteEObjXContractDetailsJPNStatementDescriptor, xContractJPNpkId);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor deleteEObjXContractDetailsJPNStatementDescriptor = createStatementDescriptor (
    "deleteEObjXContractDetailsJPN(Long)",
    "delete from XCONTRACTDETAILSJPN where XContract_JPNPK_ID = ?",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.DELETE,
    null,
    new DeleteEObjXContractDetailsJPNParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    4);

  /**
   * @generated
   */
  public static class DeleteEObjXContractDetailsJPNParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setLong (stmt, 1, Types.BIGINT, (Long)parameters[0]);
    }
  }

}
