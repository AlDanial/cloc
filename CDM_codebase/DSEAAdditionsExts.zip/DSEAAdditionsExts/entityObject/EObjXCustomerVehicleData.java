/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[9acace02b118b6cc2c1c8d0b15a931ef]
 */


package com.ibm.daimler.dsea.entityObject;

import java.util.Iterator;
import com.ibm.mdm.base.db.EntityMapping;
import com.ibm.pdq.annotation.Select;
import com.ibm.pdq.annotation.Update;

import com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicle;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * @generated
 */
public interface EObjXCustomerVehicleData {


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjXCustomerVehicleSql = "select CUSTOMERVEHICLEPK_ID, CONT_ID, VEHICLE_ID, RETAILER_ID, CONNECTME_USAGE_TP_CD, LICENSE_PLATE, VEHICLE_SALES_TP_CD, VEHICLE_USAGE_TP_CD, VEHICLE_OWNERSHIP, START_DT, END_DT, SOURCE_IDENT_TP_CD, X_BPID, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from XCUSTOMERVEHICLE where CUSTOMERVEHICLEPK_ID = ? ";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String createEObjXCustomerVehicleSql = "insert into XCUSTOMERVEHICLE (CUSTOMERVEHICLEPK_ID, CONT_ID, VEHICLE_ID, RETAILER_ID, CONNECTME_USAGE_TP_CD, LICENSE_PLATE, VEHICLE_SALES_TP_CD, VEHICLE_USAGE_TP_CD, VEHICLE_OWNERSHIP, START_DT, END_DT, SOURCE_IDENT_TP_CD, X_BPID, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( :customerVehiclepkId, :contId, :vehicleId, :retailerId, :connectMeUsage, :licensePlate, :vehicleSales, :vehicleUsage, :vehicleOwnerShip, :startDate, :endDate, :sourceIdentifier, :x_BPID, :lastUpdateDt, :lastUpdateUser, :lastUpdateTxId)";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String updateEObjXCustomerVehicleSql = "update XCUSTOMERVEHICLE set CONT_ID = :contId, VEHICLE_ID = :vehicleId, RETAILER_ID = :retailerId, CONNECTME_USAGE_TP_CD = :connectMeUsage, LICENSE_PLATE = :licensePlate, VEHICLE_SALES_TP_CD = :vehicleSales, VEHICLE_USAGE_TP_CD = :vehicleUsage, VEHICLE_OWNERSHIP = :vehicleOwnerShip, START_DT = :startDate, END_DT = :endDate, SOURCE_IDENT_TP_CD = :sourceIdentifier, X_BPID = :x_BPID, LAST_UPDATE_DT = :lastUpdateDt, LAST_UPDATE_USER = :lastUpdateUser, LAST_UPDATE_TX_ID = :lastUpdateTxId where CUSTOMERVEHICLEPK_ID = :customerVehiclepkId and LAST_UPDATE_DT = :oldLastUpdateDt";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String deleteEObjXCustomerVehicleSql = "delete from XCUSTOMERVEHICLE where CUSTOMERVEHICLEPK_ID = ?";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXCustomerVehicleKeyField = "EObjXCustomerVehicle.customerVehiclepkId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXCustomerVehicleGetFields =
    "EObjXCustomerVehicle.customerVehiclepkId," +
    "EObjXCustomerVehicle.contId," +
    "EObjXCustomerVehicle.vehicleId," +
    "EObjXCustomerVehicle.retailerId," +
    "EObjXCustomerVehicle.connectMeUsage," +
    "EObjXCustomerVehicle.licensePlate," +
    "EObjXCustomerVehicle.vehicleSales," +
    "EObjXCustomerVehicle.vehicleUsage," +
    "EObjXCustomerVehicle.vehicleOwnerShip," +
    "EObjXCustomerVehicle.startDate," +
    "EObjXCustomerVehicle.endDate," +
    "EObjXCustomerVehicle.sourceIdentifier," +
    "EObjXCustomerVehicle.x_BPID," +
    "EObjXCustomerVehicle.lastUpdateDt," +
    "EObjXCustomerVehicle.lastUpdateUser," +
    "EObjXCustomerVehicle.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXCustomerVehicleAllFields =
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicle.customerVehiclepkId," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicle.contId," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicle.vehicleId," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicle.retailerId," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicle.connectMeUsage," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicle.licensePlate," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicle.vehicleSales," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicle.vehicleUsage," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicle.vehicleOwnerShip," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicle.startDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicle.endDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicle.sourceIdentifier," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicle.x_BPID," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicle.lastUpdateDt," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicle.lastUpdateUser," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicle.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXCustomerVehicleUpdateFields =
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicle.contId," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicle.vehicleId," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicle.retailerId," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicle.connectMeUsage," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicle.licensePlate," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicle.vehicleSales," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicle.vehicleUsage," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicle.vehicleOwnerShip," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicle.startDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicle.endDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicle.sourceIdentifier," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicle.x_BPID," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicle.lastUpdateDt," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicle.lastUpdateUser," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicle.lastUpdateTxId," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicle.customerVehiclepkId," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicle.oldLastUpdateDt";   

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Select XCustomerVehicle by parameters.
   * @generated
   */
  @Select(sql=getEObjXCustomerVehicleSql)
  @EntityMapping(parameters=EObjXCustomerVehicleKeyField, results=EObjXCustomerVehicleGetFields)
  Iterator<EObjXCustomerVehicle> getEObjXCustomerVehicle(Long customerVehiclepkId);  
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Create XCustomerVehicle by EObjXCustomerVehicle Object.
   * @generated
   */
  @Update(sql=createEObjXCustomerVehicleSql)
  @EntityMapping(parameters=EObjXCustomerVehicleAllFields)
    int createEObjXCustomerVehicle(EObjXCustomerVehicle e); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Update one XCustomerVehicle by EObjXCustomerVehicle object.
   * @generated
   */
  @Update(sql=updateEObjXCustomerVehicleSql)
  @EntityMapping(parameters=EObjXCustomerVehicleUpdateFields)
    int updateEObjXCustomerVehicle(EObjXCustomerVehicle e); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Delete XCustomerVehicle by parameters.
   * @generated
   */
  @Update(sql=deleteEObjXCustomerVehicleSql)
  @EntityMapping(parameters=EObjXCustomerVehicleKeyField)
  int deleteEObjXCustomerVehicle(Long customerVehiclepkId);

}

