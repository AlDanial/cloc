/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[7940ae3db2f9930242b3214e52879f07]
 */


package com.ibm.daimler.dsea.entityObject;

import java.util.Iterator;
import com.ibm.mdm.base.db.EntityMapping;
import com.ibm.pdq.annotation.Select;
import com.ibm.pdq.annotation.Update;

import com.ibm.daimler.dsea.entityObject.EObjXGurantorCompany;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * @generated
 */
public interface EObjXGurantorCompanyData {


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjXGurantorCompanySql = "select XGurantor_Companypk_Id, CONTRACT_DETAILS_ID, BPID, CAN_NUMBER, INDUSTRY_TP_CD, COMPANY_NAME, COMPANY_NAME_LOCAL, ADDR_USAGE_TP_CD, ADDR_LINE_ONE, ADDR_LINE_TWO, ADDR_LINE_THREE, POSTAL_CODE, CITY_NAME, RESIDENCE_NUMBER, COUNTRY_TP_CD, BUILDING_NAME, STREET_NAME, STREET_NUMBER, MOBILE_NUMBER, HOME_PHONE_NUMBER, WORK_PHONE_NUMBER, WORK_PHONE_NUMBER_EXT, FAX, EMAIL, SOURCE_IDENT_TP_CD, START_DT, END_DT, MODIFY_SYS_DT, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from XGURANTORCOMPANY where XGurantor_Companypk_Id = ? ";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String createEObjXGurantorCompanySql = "insert into XGURANTORCOMPANY (XGurantor_Companypk_Id, CONTRACT_DETAILS_ID, BPID, CAN_NUMBER, INDUSTRY_TP_CD, COMPANY_NAME, COMPANY_NAME_LOCAL, ADDR_USAGE_TP_CD, ADDR_LINE_ONE, ADDR_LINE_TWO, ADDR_LINE_THREE, POSTAL_CODE, CITY_NAME, RESIDENCE_NUMBER, COUNTRY_TP_CD, BUILDING_NAME, STREET_NAME, STREET_NUMBER, MOBILE_NUMBER, HOME_PHONE_NUMBER, WORK_PHONE_NUMBER, WORK_PHONE_NUMBER_EXT, FAX, EMAIL, SOURCE_IDENT_TP_CD, START_DT, END_DT, MODIFY_SYS_DT, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( :xGurantorCompanypkId, :contractDetailsId, :bPID, :cANNumber, :industry, :companyName, :companyNameLocal, :addressUsage, :addressLineOne, :addressLineTwo, :addressLineThree, :postalCode, :cityName, :residenceNumber, :country, :buildingName, :streetName, :streetNumber, :mobileNumber, :homePhoneNumber, :workPhoneNumber, :workPhoneNumberExtension, :fax, :email, :sourceIdentifier, :startDate, :endDate, :lastModifiedSystemDate, :lastUpdateDt, :lastUpdateUser, :lastUpdateTxId)";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String updateEObjXGurantorCompanySql = "update XGURANTORCOMPANY set CONTRACT_DETAILS_ID = :contractDetailsId, BPID = :bPID, CAN_NUMBER = :cANNumber, INDUSTRY_TP_CD = :industry, COMPANY_NAME = :companyName, COMPANY_NAME_LOCAL = :companyNameLocal, ADDR_USAGE_TP_CD = :addressUsage, ADDR_LINE_ONE = :addressLineOne, ADDR_LINE_TWO = :addressLineTwo, ADDR_LINE_THREE = :addressLineThree, POSTAL_CODE = :postalCode, CITY_NAME = :cityName, RESIDENCE_NUMBER = :residenceNumber, COUNTRY_TP_CD = :country, BUILDING_NAME = :buildingName, STREET_NAME = :streetName, STREET_NUMBER = :streetNumber, MOBILE_NUMBER = :mobileNumber, HOME_PHONE_NUMBER = :homePhoneNumber, WORK_PHONE_NUMBER = :workPhoneNumber, WORK_PHONE_NUMBER_EXT = :workPhoneNumberExtension, FAX = :fax, EMAIL = :email, SOURCE_IDENT_TP_CD = :sourceIdentifier, START_DT = :startDate, END_DT = :endDate, MODIFY_SYS_DT = :lastModifiedSystemDate, LAST_UPDATE_DT = :lastUpdateDt, LAST_UPDATE_USER = :lastUpdateUser, LAST_UPDATE_TX_ID = :lastUpdateTxId where XGurantor_Companypk_Id = :xGurantorCompanypkId and LAST_UPDATE_DT = :oldLastUpdateDt";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String deleteEObjXGurantorCompanySql = "delete from XGURANTORCOMPANY where XGurantor_Companypk_Id = ?";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXGurantorCompanyKeyField = "EObjXGurantorCompany.xGurantorCompanypkId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXGurantorCompanyGetFields =
    "EObjXGurantorCompany.xGurantorCompanypkId," +
    "EObjXGurantorCompany.contractDetailsId," +
    "EObjXGurantorCompany.bPID," +
    "EObjXGurantorCompany.cANNumber," +
    "EObjXGurantorCompany.industry," +
    "EObjXGurantorCompany.companyName," +
    "EObjXGurantorCompany.companyNameLocal," +
    "EObjXGurantorCompany.addressUsage," +
    "EObjXGurantorCompany.addressLineOne," +
    "EObjXGurantorCompany.addressLineTwo," +
    "EObjXGurantorCompany.addressLineThree," +
    "EObjXGurantorCompany.postalCode," +
    "EObjXGurantorCompany.cityName," +
    "EObjXGurantorCompany.residenceNumber," +
    "EObjXGurantorCompany.country," +
    "EObjXGurantorCompany.buildingName," +
    "EObjXGurantorCompany.streetName," +
    "EObjXGurantorCompany.streetNumber," +
    "EObjXGurantorCompany.mobileNumber," +
    "EObjXGurantorCompany.homePhoneNumber," +
    "EObjXGurantorCompany.workPhoneNumber," +
    "EObjXGurantorCompany.workPhoneNumberExtension," +
    "EObjXGurantorCompany.fax," +
    "EObjXGurantorCompany.email," +
    "EObjXGurantorCompany.sourceIdentifier," +
    "EObjXGurantorCompany.startDate," +
    "EObjXGurantorCompany.endDate," +
    "EObjXGurantorCompany.lastModifiedSystemDate," +
    "EObjXGurantorCompany.lastUpdateDt," +
    "EObjXGurantorCompany.lastUpdateUser," +
    "EObjXGurantorCompany.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXGurantorCompanyAllFields =
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorCompany.xGurantorCompanypkId," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorCompany.contractDetailsId," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorCompany.bPID," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorCompany.cANNumber," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorCompany.industry," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorCompany.companyName," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorCompany.companyNameLocal," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorCompany.addressUsage," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorCompany.addressLineOne," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorCompany.addressLineTwo," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorCompany.addressLineThree," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorCompany.postalCode," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorCompany.cityName," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorCompany.residenceNumber," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorCompany.country," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorCompany.buildingName," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorCompany.streetName," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorCompany.streetNumber," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorCompany.mobileNumber," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorCompany.homePhoneNumber," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorCompany.workPhoneNumber," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorCompany.workPhoneNumberExtension," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorCompany.fax," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorCompany.email," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorCompany.sourceIdentifier," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorCompany.startDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorCompany.endDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorCompany.lastModifiedSystemDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorCompany.lastUpdateDt," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorCompany.lastUpdateUser," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorCompany.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXGurantorCompanyUpdateFields =
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorCompany.contractDetailsId," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorCompany.bPID," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorCompany.cANNumber," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorCompany.industry," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorCompany.companyName," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorCompany.companyNameLocal," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorCompany.addressUsage," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorCompany.addressLineOne," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorCompany.addressLineTwo," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorCompany.addressLineThree," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorCompany.postalCode," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorCompany.cityName," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorCompany.residenceNumber," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorCompany.country," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorCompany.buildingName," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorCompany.streetName," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorCompany.streetNumber," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorCompany.mobileNumber," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorCompany.homePhoneNumber," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorCompany.workPhoneNumber," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorCompany.workPhoneNumberExtension," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorCompany.fax," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorCompany.email," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorCompany.sourceIdentifier," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorCompany.startDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorCompany.endDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorCompany.lastModifiedSystemDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorCompany.lastUpdateDt," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorCompany.lastUpdateUser," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorCompany.lastUpdateTxId," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorCompany.xGurantorCompanypkId," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorCompany.oldLastUpdateDt";   

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Select XGurantorCompany by parameters.
   * @generated
   */
  @Select(sql=getEObjXGurantorCompanySql)
  @EntityMapping(parameters=EObjXGurantorCompanyKeyField, results=EObjXGurantorCompanyGetFields)
  Iterator<EObjXGurantorCompany> getEObjXGurantorCompany(Long xGurantorCompanypkId);  
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Create XGurantorCompany by EObjXGurantorCompany Object.
   * @generated
   */
  @Update(sql=createEObjXGurantorCompanySql)
  @EntityMapping(parameters=EObjXGurantorCompanyAllFields)
    int createEObjXGurantorCompany(EObjXGurantorCompany e); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Update one XGurantorCompany by EObjXGurantorCompany object.
   * @generated
   */
  @Update(sql=updateEObjXGurantorCompanySql)
  @EntityMapping(parameters=EObjXGurantorCompanyUpdateFields)
    int updateEObjXGurantorCompany(EObjXGurantorCompany e); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Delete XGurantorCompany by parameters.
   * @generated
   */
  @Update(sql=deleteEObjXGurantorCompanySql)
  @EntityMapping(parameters=EObjXGurantorCompanyKeyField)
  int deleteEObjXGurantorCompany(Long xGurantorCompanypkId);

}

