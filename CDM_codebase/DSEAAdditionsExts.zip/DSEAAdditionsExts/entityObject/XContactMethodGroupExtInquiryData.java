/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[aafda45a5501a4023f3b178f8c3db1f8]
 */
package com.ibm.daimler.dsea.entityObject;


import com.ibm.mdm.base.db.EntityMapping;
import com.ibm.pdq.annotation.Select;


import com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup;
import com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup;

import com.ibm.mdm.base.db.ResultQueue3;

import java.util.Iterator;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * 
 * @generated
 */
public interface XContactMethodGroupExtInquiryData {

  /**
   * MDM_TODO: CDKWB0050I The generated parameter and result lists in this file should be checked to ensure that each matches its
   * associated SQL query. Each list entry must be comma separated and identify a field within an entity object class.
   */ 
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */ 
   public final static String tableAliasString1 = "tableAlias (" + 
     "CONTACTMETHODGROUP => com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup, " + 
     "H_CONTACTMETHODGRO => com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup, " + 
     "LOCATIONGROUP => com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup, " + 
     "H_LOCATIONGROUP => com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup , " + 
     "CONTACTMETHODGROUP => com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt , " + 
     "H_CONTACTMETHODGRO => com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt" + 
     ")";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension
   * XContactMethodGroup.
   *
   * @generated
   */ 
   public final static String getPartyContactMethodsHistorySQL = "SELECT DISTINCT A.H_LOCATION_GROUP_I AS H_CONT_METHOD_GRP_ID, A.H_ACTION_CODE, A.H_CREATED_BY, A.H_CREATE_DT, A.H_END_DT, A.LOCATION_GROUP_ID, A.CONTACT_METHOD_ID, A.CONT_METH_TP_CD, A.METHOD_ST_TP_CD, A.ATTACH_ALLOW_IND, A.TEXT_ONLY_IND, A.MESSAGE_SIZE, A.COMMENT_DESC, A.LAST_UPDATE_DT, A.LAST_UPDATE_USER, A.LAST_UPDATE_TX_ID, B.H_LOCATION_GROUP_I AS H_LOCATION_GROUP_I, B.H_ACTION_CODE, B.H_CREATED_BY, B.H_CREATE_DT, B.H_END_DT, B.LOCATION_GROUP_ID, B.UNDEL_REASON_TP_CD, B.CONT_ID, B.MEMBER_IND, B.PREFERRED_IND, B.SOLICIT_IND, B.LOC_GROUP_TP_CODE, B.EFFECT_START_MMDD, B.EFFECT_END_MMDD, B.EFFECT_START_TM, B.EFFECT_END_TM, B.START_DT, B.END_DT, B.LAST_UPDATE_DT, B.LAST_UPDATE_USER, B.LAST_UPDATE_TX_ID, B.LAST_USED_DT, B.LAST_VERIFIED_DT, B.SOURCE_IDENT_TP_CD, A.XVERIFIED_TP_CD, A.XRETAILER_ID, A.XMODIFY_SYS_DT, A.XCONTACT_RETAILER_FLAG, A.X_BPID" + 
     " FROM H_CONTACTMETHODGRO A,H_LOCATIONGROUP B" + 
     " WHERE B.CONT_ID = ? AND A.H_LOCATION_GROUP_I = B.H_LOCATION_GROUP_I AND (( ? BETWEEN A.H_CREATE_DT AND A.H_END_DT ) OR ( ? >= A.H_CREATE_DT AND A.H_END_DT IS NULL )) AND (( ? BETWEEN B.H_CREATE_DT AND B.H_END_DT ) OR ( ? >= B.H_CREATE_DT AND B.H_END_DT IS NULL ))";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyContactMethodsHistoryParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.histCreateDt=H_CREATE_DT"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyContactMethodsHistoryResults =
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.locationGroupIdPK=H_CONT_METHOD_GRP_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.histActionCode=H_ACTION_CODE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.histCreatedBy=H_CREATED_BY," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.histEndDt=H_END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.locationGroupIdPK=LOCATION_GROUP_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.contactMethodId=CONTACT_METHOD_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.contMethTpCd=CONT_METH_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.methodStTpCd=METHOD_ST_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.attachAllowInd=ATTACH_ALLOW_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.textOnlyInd=TEXT_ONLY_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.messageSize=MESSAGE_SIZE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.commentDesc=COMMENT_DESC," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.locationGroupIdPK=H_LOCATION_GROUP_I," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.histActionCode=H_ACTION_CODE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.histCreatedBy=H_CREATED_BY," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.histEndDt=H_END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.locationGroupIdPK=LOCATION_GROUP_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.undelReasonTpCd=UNDEL_REASON_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.memberInd=MEMBER_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.preferredInd=PREFERRED_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.solicitInd=SOLICIT_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.locGroupTpCode=LOC_GROUP_TP_CODE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.effectStartMMDD=EFFECT_START_MMDD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.effectEndMMDD=EFFECT_END_MMDD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.effectStartTm=EFFECT_START_TM," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.effectEndTm=EFFECT_END_TM," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.startDt=START_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.endDt=END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastUsedDt=LAST_USED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastVerifiedDt=LAST_VERIFIED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.sourceIdentTpCd=SOURCE_IDENT_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt.XVerified=XVERIFIED_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt.XRetailerId=XRETAILER_ID," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt.XLastModifiedSystemDate=XMODIFY_SYS_DT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt.XContactRetailerFlag=XCONTACT_RETAILER_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt.X_BPID=X_BPID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension
   * XContactMethodGroup.
   *
   * @generated
   */ 
   public final static String getActivePartyContactMethodsSQL = "SELECT CONTACTMETHODGROUP.LOCATION_GROUP_ID, CONTACTMETHODGROUP.CONTACT_METHOD_ID, CONTACTMETHODGROUP.CONT_METH_TP_CD, CONTACTMETHODGROUP.METHOD_ST_TP_CD, CONTACTMETHODGROUP.ATTACH_ALLOW_IND, CONTACTMETHODGROUP.TEXT_ONLY_IND, CONTACTMETHODGROUP.MESSAGE_SIZE, CONTACTMETHODGROUP.COMMENT_DESC, CONTACTMETHODGROUP.LAST_UPDATE_DT, CONTACTMETHODGROUP.LAST_UPDATE_USER, CONTACTMETHODGROUP.LAST_UPDATE_TX_ID, LOCATIONGROUP.LOCATION_GROUP_ID, LOCATIONGROUP.UNDEL_REASON_TP_CD, LOCATIONGROUP.CONT_ID, LOCATIONGROUP.MEMBER_IND, LOCATIONGROUP.PREFERRED_IND, LOCATIONGROUP.SOLICIT_IND, LOCATIONGROUP.LOC_GROUP_TP_CODE, LOCATIONGROUP.EFFECT_START_MMDD, LOCATIONGROUP.EFFECT_END_MMDD, LOCATIONGROUP.EFFECT_START_TM, LOCATIONGROUP.EFFECT_END_TM, LOCATIONGROUP.START_DT, LOCATIONGROUP.END_DT, LOCATIONGROUP.LAST_UPDATE_DT, LOCATIONGROUP.LAST_UPDATE_USER, LOCATIONGROUP.LAST_UPDATE_TX_ID, LOCATIONGROUP.LAST_USED_DT, LOCATIONGROUP.LAST_VERIFIED_DT, LOCATIONGROUP.SOURCE_IDENT_TP_CD, CONTACTMETHODGROUP.XVERIFIED_TP_CD, CONTACTMETHODGROUP.XRETAILER_ID, CONTACTMETHODGROUP.XMODIFY_SYS_DT, CONTACTMETHODGROUP.XCONTACT_RETAILER_FLAG, CONTACTMETHODGROUP.X_BPID" + 
     " FROM CONTACTMETHODGROUP, LOCATIONGROUP" + 
     " WHERE CONTACTMETHODGROUP.LOCATION_GROUP_ID = LOCATIONGROUP.LOCATION_GROUP_ID AND LOCATIONGROUP.CONT_ID = ? AND ((LOCATIONGROUP.END_DT IS NULL) OR (LOCATIONGROUP.END_DT > ? ))";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getActivePartyContactMethodsParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.endDt=END_DT"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getActivePartyContactMethodsResults =
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.locationGroupIdPK=LOCATION_GROUP_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.contactMethodId=CONTACT_METHOD_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.contMethTpCd=CONT_METH_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.methodStTpCd=METHOD_ST_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.attachAllowInd=ATTACH_ALLOW_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.textOnlyInd=TEXT_ONLY_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.messageSize=MESSAGE_SIZE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.commentDesc=COMMENT_DESC," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.locationGroupIdPK=LOCATION_GROUP_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.undelReasonTpCd=UNDEL_REASON_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.memberInd=MEMBER_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.preferredInd=PREFERRED_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.solicitInd=SOLICIT_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.locGroupTpCode=LOC_GROUP_TP_CODE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.effectStartMMDD=EFFECT_START_MMDD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.effectEndMMDD=EFFECT_END_MMDD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.effectStartTm=EFFECT_START_TM," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.effectEndTm=EFFECT_END_TM," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.startDt=START_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.endDt=END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastUsedDt=LAST_USED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastVerifiedDt=LAST_VERIFIED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.sourceIdentTpCd=SOURCE_IDENT_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt.XVerified=XVERIFIED_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt.XRetailerId=XRETAILER_ID," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt.XLastModifiedSystemDate=XMODIFY_SYS_DT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt.XContactRetailerFlag=XCONTACT_RETAILER_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt.X_BPID=X_BPID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension
   * XContactMethodGroup.
   *
   * @generated
   */ 
   public final static String getInactivePartyContactMethodsSQL = "SELECT CONTACTMETHODGROUP.LOCATION_GROUP_ID, CONTACTMETHODGROUP.CONTACT_METHOD_ID, CONTACTMETHODGROUP.CONT_METH_TP_CD, CONTACTMETHODGROUP.METHOD_ST_TP_CD, CONTACTMETHODGROUP.ATTACH_ALLOW_IND, CONTACTMETHODGROUP.TEXT_ONLY_IND, CONTACTMETHODGROUP.MESSAGE_SIZE , CONTACTMETHODGROUP.COMMENT_DESC, CONTACTMETHODGROUP.LAST_UPDATE_DT, CONTACTMETHODGROUP.LAST_UPDATE_USER, CONTACTMETHODGROUP.LAST_UPDATE_TX_ID, LOCATIONGROUP.LOCATION_GROUP_ID, LOCATIONGROUP.UNDEL_REASON_TP_CD, LOCATIONGROUP.CONT_ID, LOCATIONGROUP.MEMBER_IND, LOCATIONGROUP.PREFERRED_IND, LOCATIONGROUP.SOLICIT_IND, LOCATIONGROUP.LOC_GROUP_TP_CODE, LOCATIONGROUP.EFFECT_START_MMDD, LOCATIONGROUP.EFFECT_END_MMDD, LOCATIONGROUP.EFFECT_START_TM, LOCATIONGROUP.EFFECT_END_TM, LOCATIONGROUP.START_DT, LOCATIONGROUP.END_DT, LOCATIONGROUP.LAST_UPDATE_DT, LOCATIONGROUP.LAST_UPDATE_USER, LOCATIONGROUP.LAST_UPDATE_TX_ID, LOCATIONGROUP.LAST_USED_DT, LOCATIONGROUP.LAST_VERIFIED_DT, LOCATIONGROUP.SOURCE_IDENT_TP_CD, CONTACTMETHODGROUP.XVERIFIED_TP_CD, CONTACTMETHODGROUP.XRETAILER_ID, CONTACTMETHODGROUP.XMODIFY_SYS_DT, CONTACTMETHODGROUP.XCONTACT_RETAILER_FLAG, CONTACTMETHODGROUP.X_BPID" + 
     " FROM CONTACTMETHODGROUP,LOCATIONGROUP" + 
     " WHERE CONTACTMETHODGROUP.LOCATION_GROUP_ID = LOCATIONGROUP.LOCATION_GROUP_ID AND LOCATIONGROUP.CONT_ID = ? AND (LOCATIONGROUP.END_DT < ? )";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getInactivePartyContactMethodsParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.endDt=END_DT"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getInactivePartyContactMethodsResults =
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.locationGroupIdPK=LOCATION_GROUP_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.contactMethodId=CONTACT_METHOD_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.contMethTpCd=CONT_METH_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.methodStTpCd=METHOD_ST_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.attachAllowInd=ATTACH_ALLOW_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.textOnlyInd=TEXT_ONLY_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.messageSize=MESSAGE_SIZE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.commentDesc=COMMENT_DESC," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.locationGroupIdPK=LOCATION_GROUP_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.undelReasonTpCd=UNDEL_REASON_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.memberInd=MEMBER_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.preferredInd=PREFERRED_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.solicitInd=SOLICIT_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.locGroupTpCode=LOC_GROUP_TP_CODE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.effectStartMMDD=EFFECT_START_MMDD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.effectEndMMDD=EFFECT_END_MMDD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.effectStartTm=EFFECT_START_TM," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.effectEndTm=EFFECT_END_TM," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.startDt=START_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.endDt=END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastUsedDt=LAST_USED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastVerifiedDt=LAST_VERIFIED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.sourceIdentTpCd=SOURCE_IDENT_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt.XVerified=XVERIFIED_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt.XRetailerId=XRETAILER_ID," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt.XLastModifiedSystemDate=XMODIFY_SYS_DT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt.XContactRetailerFlag=XCONTACT_RETAILER_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt.X_BPID=X_BPID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension
   * XContactMethodGroup.
   *
   * @generated
   */ 
   public final static String getAllPartyContactMethodsSQL = "SELECT CONTACTMETHODGROUP.LOCATION_GROUP_ID, CONTACTMETHODGROUP.CONTACT_METHOD_ID, CONTACTMETHODGROUP.CONT_METH_TP_CD, CONTACTMETHODGROUP.METHOD_ST_TP_CD, CONTACTMETHODGROUP.ATTACH_ALLOW_IND, CONTACTMETHODGROUP.TEXT_ONLY_IND, CONTACTMETHODGROUP.MESSAGE_SIZE, CONTACTMETHODGROUP.COMMENT_DESC, CONTACTMETHODGROUP.LAST_UPDATE_DT, CONTACTMETHODGROUP.LAST_UPDATE_USER,CONTACTMETHODGROUP.LAST_UPDATE_TX_ID, LOCATIONGROUP.LOCATION_GROUP_ID, LOCATIONGROUP.UNDEL_REASON_TP_CD, LOCATIONGROUP.CONT_ID, LOCATIONGROUP.MEMBER_IND, LOCATIONGROUP.PREFERRED_IND, LOCATIONGROUP.SOLICIT_IND, LOCATIONGROUP.LOC_GROUP_TP_CODE, LOCATIONGROUP.EFFECT_START_MMDD, LOCATIONGROUP.EFFECT_END_MMDD, LOCATIONGROUP.EFFECT_START_TM, LOCATIONGROUP.EFFECT_END_TM, LOCATIONGROUP.START_DT, LOCATIONGROUP.END_DT, LOCATIONGROUP.LAST_UPDATE_DT, LOCATIONGROUP.LAST_UPDATE_USER, LOCATIONGROUP.LAST_UPDATE_TX_ID, LOCATIONGROUP.LAST_USED_DT, LOCATIONGROUP.LAST_VERIFIED_DT, LOCATIONGROUP.SOURCE_IDENT_TP_CD, CONTACTMETHODGROUP.XVERIFIED_TP_CD, CONTACTMETHODGROUP.XRETAILER_ID, CONTACTMETHODGROUP.XMODIFY_SYS_DT, CONTACTMETHODGROUP.XCONTACT_RETAILER_FLAG, CONTACTMETHODGROUP.X_BPID" + 
     " FROM CONTACTMETHODGROUP,LOCATIONGROUP" + 
     " WHERE CONTACTMETHODGROUP.LOCATION_GROUP_ID = LOCATIONGROUP.LOCATION_GROUP_ID AND LOCATIONGROUP.CONT_ID = ?";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getAllPartyContactMethodsParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.contId=CONT_ID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getAllPartyContactMethodsResults =
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.locationGroupIdPK=LOCATION_GROUP_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.contactMethodId=CONTACT_METHOD_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.contMethTpCd=CONT_METH_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.methodStTpCd=METHOD_ST_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.attachAllowInd=ATTACH_ALLOW_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.textOnlyInd=TEXT_ONLY_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.messageSize=MESSAGE_SIZE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.commentDesc=COMMENT_DESC," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.locationGroupIdPK=LOCATION_GROUP_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.undelReasonTpCd=UNDEL_REASON_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.memberInd=MEMBER_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.preferredInd=PREFERRED_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.solicitInd=SOLICIT_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.locGroupTpCode=LOC_GROUP_TP_CODE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.effectStartMMDD=EFFECT_START_MMDD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.effectEndMMDD=EFFECT_END_MMDD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.effectStartTm=EFFECT_START_TM," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.effectEndTm=EFFECT_END_TM," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.startDt=START_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.endDt=END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastUsedDt=LAST_USED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastVerifiedDt=LAST_VERIFIED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.sourceIdentTpCd=SOURCE_IDENT_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt.XVerified=XVERIFIED_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt.XRetailerId=XRETAILER_ID," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt.XLastModifiedSystemDate=XMODIFY_SYS_DT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt.XContactRetailerFlag=XCONTACT_RETAILER_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt.X_BPID=X_BPID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension
   * XContactMethodGroup.
   *
   * @generated
   */ 
   public final static String getPartyContactMethodHistorySQL = "SELECT DISTINCT B1.H_LOCATION_GROUP_I AS H_CONT_METHOD_GRP_ID,B1.H_ACTION_CODE,B1.H_CREATED_BY,B1.H_CREATE_DT, B1.H_END_DT,B1.LOCATION_GROUP_ID,B1.CONTACT_METHOD_ID,B1.CONT_METH_TP_CD,B1.METHOD_ST_TP_CD,B1.ATTACH_ALLOW_IND,B1.TEXT_ONLY_IND,B1.MESSAGE_SIZE,B1.COMMENT_DESC,B1.LAST_UPDATE_DT,B1.LAST_UPDATE_USER, B1.LAST_UPDATE_TX_ID,A1.H_LOCATION_GROUP_I AS H_LOCATION_GROUP_I,A1.H_ACTION_CODE,A1.H_CREATED_BY,A1.H_CREATE_DT,A1.H_END_DT,A1.LOCATION_GROUP_ID,A1.UNDEL_REASON_TP_CD,A1.CONT_ID, A1.MEMBER_IND, A1.PREFERRED_IND,A1.SOLICIT_IND,A1.LOC_GROUP_TP_CODE,A1.EFFECT_START_MMDD,A1.EFFECT_END_MMDD,A1.EFFECT_START_TM,A1.EFFECT_END_TM,A1.START_DT,A1.END_DT,A1.LAST_UPDATE_DT,A1.LAST_UPDATE_USER, A1.LAST_UPDATE_TX_ID, A1.LAST_USED_DT, A1.LAST_VERIFIED_DT, A1.SOURCE_IDENT_TP_CD, B1.XVERIFIED_TP_CD, B1.XRETAILER_ID, B1.XMODIFY_SYS_DT, B1.XCONTACT_RETAILER_FLAG, B1.X_BPID" + 
     " FROM H_CONTACTMETHODGRO B1, H_LOCATIONGROUP A1" + 
     " WHERE B1.H_LOCATION_GROUP_I = A1.H_LOCATION_GROUP_I AND A1.CONT_ID = ? AND ( ? BETWEEN A1.H_CREATE_DT AND A1.H_END_DT OR (? >= A1.H_CREATE_DT AND A1.H_END_DT IS NULL)) AND B1.CONT_METH_TP_CD = ? AND ( ? BETWEEN B1.H_CREATE_DT AND B1.H_END_DT OR (? >= B1.H_CREATE_DT AND B1.H_END_DT IS NULL))";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyContactMethodHistoryParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.contMethTpCd=CONT_METH_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.histCreateDt=H_CREATE_DT"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyContactMethodHistoryResults =
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.locationGroupIdPK=H_CONT_METHOD_GRP_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.histActionCode=H_ACTION_CODE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.histCreatedBy=H_CREATED_BY," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.histEndDt=H_END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.locationGroupIdPK=LOCATION_GROUP_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.contactMethodId=CONTACT_METHOD_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.contMethTpCd=CONT_METH_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.methodStTpCd=METHOD_ST_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.attachAllowInd=ATTACH_ALLOW_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.textOnlyInd=TEXT_ONLY_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.messageSize=MESSAGE_SIZE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.commentDesc=COMMENT_DESC," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.locationGroupIdPK=H_LOCATION_GROUP_I," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.histActionCode=H_ACTION_CODE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.histCreatedBy=H_CREATED_BY," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.histEndDt=H_END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.locationGroupIdPK=LOCATION_GROUP_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.undelReasonTpCd=UNDEL_REASON_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.memberInd=MEMBER_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.preferredInd=PREFERRED_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.solicitInd=SOLICIT_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.locGroupTpCode=LOC_GROUP_TP_CODE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.effectStartMMDD=EFFECT_START_MMDD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.effectEndMMDD=EFFECT_END_MMDD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.effectStartTm=EFFECT_START_TM," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.effectEndTm=EFFECT_END_TM," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.startDt=START_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.endDt=END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastUsedDt=LAST_USED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastVerifiedDt=LAST_VERIFIED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.sourceIdentTpCd=SOURCE_IDENT_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt.XVerified=XVERIFIED_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt.XRetailerId=XRETAILER_ID," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt.XLastModifiedSystemDate=XMODIFY_SYS_DT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt.XContactRetailerFlag=XCONTACT_RETAILER_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt.X_BPID=X_BPID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension
   * XContactMethodGroup.
   *
   * @generated
   */ 
   public final static String getPartyContactMethodByIDSQL = "SELECT CONTACTMETHODGROUP.LOCATION_GROUP_ID, CONTACTMETHODGROUP.CONTACT_METHOD_ID, CONTACTMETHODGROUP.CONT_METH_TP_CD, CONTACTMETHODGROUP.METHOD_ST_TP_CD, CONTACTMETHODGROUP.ATTACH_ALLOW_IND, CONTACTMETHODGROUP.TEXT_ONLY_IND, CONTACTMETHODGROUP.MESSAGE_SIZE, CONTACTMETHODGROUP.COMMENT_DESC, CONTACTMETHODGROUP.LAST_UPDATE_DT, CONTACTMETHODGROUP.LAST_UPDATE_USER, CONTACTMETHODGROUP.LAST_UPDATE_TX_ID, LOCATIONGROUP.LOCATION_GROUP_ID, LOCATIONGROUP.UNDEL_REASON_TP_CD, LOCATIONGROUP.CONT_ID, LOCATIONGROUP.MEMBER_IND, LOCATIONGROUP.PREFERRED_IND, LOCATIONGROUP.SOLICIT_IND, LOCATIONGROUP.LOC_GROUP_TP_CODE, LOCATIONGROUP.EFFECT_START_MMDD, LOCATIONGROUP.EFFECT_END_MMDD, LOCATIONGROUP.EFFECT_START_TM, LOCATIONGROUP.EFFECT_END_TM, LOCATIONGROUP.START_DT, LOCATIONGROUP.END_DT, LOCATIONGROUP.LAST_UPDATE_DT, LOCATIONGROUP.LAST_UPDATE_USER, LOCATIONGROUP.LAST_UPDATE_TX_ID, LOCATIONGROUP.LAST_USED_DT, LOCATIONGROUP.LAST_VERIFIED_DT, LOCATIONGROUP.SOURCE_IDENT_TP_CD, CONTACTMETHODGROUP.XVERIFIED_TP_CD, CONTACTMETHODGROUP.XRETAILER_ID, CONTACTMETHODGROUP.XMODIFY_SYS_DT, CONTACTMETHODGROUP.XCONTACT_RETAILER_FLAG, CONTACTMETHODGROUP.X_BPID" + 
     " FROM CONTACTMETHODGROUP,LOCATIONGROUP" + 
     " WHERE CONTACTMETHODGROUP.LOCATION_GROUP_ID = LOCATIONGROUP.LOCATION_GROUP_ID AND LOCATIONGROUP.LOCATION_GROUP_ID = ?";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyContactMethodByIDParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.locationGroupIdPK=LOCATION_GROUP_ID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyContactMethodByIDResults =
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.locationGroupIdPK=LOCATION_GROUP_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.contactMethodId=CONTACT_METHOD_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.contMethTpCd=CONT_METH_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.methodStTpCd=METHOD_ST_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.attachAllowInd=ATTACH_ALLOW_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.textOnlyInd=TEXT_ONLY_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.messageSize=MESSAGE_SIZE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.commentDesc=COMMENT_DESC," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.locationGroupIdPK=LOCATION_GROUP_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.undelReasonTpCd=UNDEL_REASON_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.memberInd=MEMBER_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.preferredInd=PREFERRED_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.solicitInd=SOLICIT_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.locGroupTpCode=LOC_GROUP_TP_CODE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.effectStartMMDD=EFFECT_START_MMDD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.effectEndMMDD=EFFECT_END_MMDD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.effectStartTm=EFFECT_START_TM," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.effectEndTm=EFFECT_END_TM," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.startDt=START_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.endDt=END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastUsedDt=LAST_USED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastVerifiedDt=LAST_VERIFIED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.sourceIdentTpCd=SOURCE_IDENT_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt.XVerified=XVERIFIED_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt.XRetailerId=XRETAILER_ID," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt.XLastModifiedSystemDate=XMODIFY_SYS_DT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt.XContactRetailerFlag=XCONTACT_RETAILER_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt.X_BPID=X_BPID"; 
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */ 
   public final static String resultSetMapping1 = "<rsm>" + 
     "<col number='1' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup' property='historyIdPK'></col>" + 
     "<col number='2' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup' property='histActionCode'></col>" + 
     "<col number='3' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup' property='histCreatedBy'></col>" + 
     "<col number='4' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup' property='histCreateDt'></col>" + 
     "<col number='5' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup' property='histEndDt'></col>" + 
     "<col number='6' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup' property='locationGroupIdPK'></col>" + 
     "<col number='7' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup' property='contactMethodId'></col>" + 
     "<col number='8' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup' property='contMethTpCd'></col>" + 
     "<col number='9' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup' property='methodStTpCd'></col>" + 
     "<col number='10' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup' property='attachAllowInd'></col>" + 
     "<col number='11' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup' property='textOnlyInd'></col>" + 
     "<col number='12' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup' property='messageSize'></col>" + 
     "<col number='13' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup' property='commentDesc'></col>" + 
     "<col number='14' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup' property='lastUpdateDt'></col>" + 
     "<col number='15' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup' property='lastUpdateUser'></col>" + 
     "<col number='16' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup' property='lastUpdateTxId'></col>" + 
     "<col number='17' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='historyIdPK'></col>" + 
     "<col number='18' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='histActionCode'></col>" + 
     "<col number='19' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='histCreatedBy'></col>" + 
     "<col number='20' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='histCreateDt'></col>" + 
     "<col number='21' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='histEndDt'></col>" + 
     "<col number='22' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='locationGroupIdPK'></col>" + 
     "<col number='23' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='undelReasonTpCd'></col>" + 
     "<col number='24' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='contId'></col>" + 
     "<col number='25' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='memberInd'></col>" + 
     "<col number='26' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='preferredInd'></col>" + 
     "<col number='27' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='solicitInd'></col>" + 
     "<col number='28' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='locGroupTpCode'></col>" + 
     "<col number='29' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='effectStartMMDD'></col>" + 
     "<col number='30' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='effectEndMMDD'></col>" + 
     "<col number='31' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='effectStartTm'></col>" + 
     "<col number='32' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='effectEndTm'></col>" + 
     "<col number='33' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='startDt'></col>" + 
     "<col number='34' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='endDt'></col>" + 
     "<col number='35' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='lastUpdateDt'></col>" + 
     "<col number='36' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='lastUpdateUser'></col>" + 
     "<col number='37' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='lastUpdateTxId'></col>" + 
     "<col number='38' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='lastUsedDt'></col>" + 
     "<col number='39' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='lastVerifiedDt'></col>" + 
     "<col number='40' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='sourceIdentTpCd'></col>" + 
     "<col number='41' bean='com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt' property='XVerified'></col>" + 
     "<col number='42' bean='com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt' property='XRetailerId'></col>" + 
     "<col number='43' bean='com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt' property='XLastModifiedSystemDate'></col>" + 
     "<col number='44' bean='com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt' property='XContactRetailerFlag'></col>" + 
     "<col number='45' bean='com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt' property='X_BPID'></col>" + 
     "</rsm>";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension
   * XContactMethodGroup.
   *
   * @generated
   */ 
   public final static String getPartyContactMethodImagesSQL = "SELECT DISTINCT A.H_LOCATION_GROUP_I AS H_CONT_METHOD_GRP_ID, A.H_ACTION_CODE, A.H_CREATED_BY, A.H_CREATE_DT, A.H_END_DT, A.LOCATION_GROUP_ID, A.CONTACT_METHOD_ID, A.CONT_METH_TP_CD, A.METHOD_ST_TP_CD, A.ATTACH_ALLOW_IND, A.TEXT_ONLY_IND, A.MESSAGE_SIZE, A.COMMENT_DESC, A.LAST_UPDATE_DT, A.LAST_UPDATE_USER, A.LAST_UPDATE_TX_ID, B.H_LOCATION_GROUP_I AS H_LOCATION_GROUP_I, B.H_ACTION_CODE, B.H_CREATED_BY, B.H_CREATE_DT, B.H_END_DT, B.LOCATION_GROUP_ID, B.UNDEL_REASON_TP_CD, B.CONT_ID, B.MEMBER_IND, B.PREFERRED_IND, B.SOLICIT_IND, B.LOC_GROUP_TP_CODE, B.EFFECT_START_MMDD, B.EFFECT_END_MMDD, B.EFFECT_START_TM, B.EFFECT_END_TM, B.START_DT, B.END_DT, B.LAST_UPDATE_DT, B.LAST_UPDATE_USER, B.LAST_UPDATE_TX_ID, B.LAST_USED_DT, B.LAST_VERIFIED_DT, B.SOURCE_IDENT_TP_CD, A.XVERIFIED_TP_CD, A.XRETAILER_ID, A.XMODIFY_SYS_DT, A.XCONTACT_RETAILER_FLAG, A.X_BPID" + 
     " FROM H_CONTACTMETHODGRO A, H_LOCATIONGROUP B" + 
     " WHERE B.CONT_ID = ? AND A.LOCATION_GROUP_ID = B.LOCATION_GROUP_ID AND A.LAST_UPDATE_TX_ID = B.LAST_UPDATE_TX_ID AND ( A.H_CREATE_DT BETWEEN ? AND ?)" + 
     " UNION SELECT DISTINCT A.H_LOCATION_GROUP_I AS H_CONT_METHOD_GRP_ID, A.H_ACTION_CODE, A.H_CREATED_BY, A.H_CREATE_DT, A.H_END_DT, A.LOCATION_GROUP_ID, A.CONTACT_METHOD_ID, A.CONT_METH_TP_CD, A.METHOD_ST_TP_CD, A.ATTACH_ALLOW_IND, A.TEXT_ONLY_IND, A.MESSAGE_SIZE, A.COMMENT_DESC, A.LAST_UPDATE_DT, A.LAST_UPDATE_USER, A.LAST_UPDATE_TX_ID, B.H_LOCATION_GROUP_I AS H_LOCATION_GROUP_I, B.H_ACTION_CODE, B.H_CREATED_BY, B.H_CREATE_DT, B.H_END_DT, B.LOCATION_GROUP_ID, B.UNDEL_REASON_TP_CD, B.CONT_ID, B.MEMBER_IND, B.PREFERRED_IND, B.SOLICIT_IND, B.LOC_GROUP_TP_CODE, B.EFFECT_START_MMDD , B.EFFECT_END_MMDD, B.EFFECT_START_TM, B.EFFECT_END_TM, B.START_DT, B.END_DT, B.LAST_UPDATE_DT, B.LAST_UPDATE_USER, B.LAST_UPDATE_TX_ID, B.LAST_USED_DT, B.LAST_VERIFIED_DT, B.SOURCE_IDENT_TP_CD, A.XVERIFIED_TP_CD, A.XRETAILER_ID, A.XMODIFY_SYS_DT, A.XCONTACT_RETAILER_FLAG, A.X_BPID" + 
     " FROM H_LOCATIONGROUP B LEFT JOIN H_CONTACTMETHODGRO A ON A.LOCATION_GROUP_ID = B.LOCATION_GROUP_ID AND A.LAST_UPDATE_TX_ID = B.LAST_UPDATE_TX_ID" + 
     " WHERE B.CONT_ID = ? AND ( B.H_CREATE_DT BETWEEN ? AND ?)";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyContactMethodImagesParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.histCreateDt=H_CREATE_DT"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyContactMethodImagesResults =
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.locationGroupIdPK=H_CONT_METHOD_GRP_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.histActionCode=H_ACTION_CODE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.histCreatedBy=H_CREATED_BY," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.histEndDt=H_END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.locationGroupIdPK=LOCATION_GROUP_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.contactMethodId=CONTACT_METHOD_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.contMethTpCd=CONT_METH_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.methodStTpCd=METHOD_ST_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.attachAllowInd=ATTACH_ALLOW_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.textOnlyInd=TEXT_ONLY_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.messageSize=MESSAGE_SIZE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.commentDesc=COMMENT_DESC," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.locationGroupIdPK=H_LOCATION_GROUP_I," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.histActionCode=H_ACTION_CODE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.histCreatedBy=H_CREATED_BY," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.histEndDt=H_END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.locationGroupIdPK=LOCATION_GROUP_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.undelReasonTpCd=UNDEL_REASON_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.memberInd=MEMBER_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.preferredInd=PREFERRED_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.solicitInd=SOLICIT_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.locGroupTpCode=LOC_GROUP_TP_CODE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.effectStartMMDD=EFFECT_START_MMDD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.effectEndMMDD=EFFECT_END_MMDD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.effectStartTm=EFFECT_START_TM," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.effectEndTm=EFFECT_END_TM," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.startDt=START_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.endDt=END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastUsedDt=LAST_USED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastVerifiedDt=LAST_VERIFIED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.sourceIdentTpCd=SOURCE_IDENT_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt.XVerified=XVERIFIED_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt.XRetailerId=XRETAILER_ID," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt.XLastModifiedSystemDate=XMODIFY_SYS_DT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt.XContactRetailerFlag=XCONTACT_RETAILER_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt.X_BPID=X_BPID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension
   * XContactMethodGroup.
   *
   * @generated
   */ 
   public final static String getPartyContactMethodsLightImagesSQL = "SELECT DISTINCT A.LOCATION_GROUP_ID, A.CONTACT_METHOD_ID, A.LAST_UPDATE_DT, B.LOCATION_GROUP_ID, B.LAST_UPDATE_DT, A.XVERIFIED_TP_CD, A.XRETAILER_ID, A.XMODIFY_SYS_DT, A.XCONTACT_RETAILER_FLAG, A.X_BPID" + 
     " FROM H_CONTACTMETHODGRO A, H_LOCATIONGROUP B" + 
     " WHERE B.CONT_ID = ? AND A.LOCATION_GROUP_ID = B.LOCATION_GROUP_ID AND A.LAST_UPDATE_TX_ID = B.LAST_UPDATE_TX_ID AND (( A.LAST_UPDATE_DT BETWEEN ? AND ? ) OR ( B.H_CREATE_DT BETWEEN ? AND ?))";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyContactMethodsLightImagesParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.histCreateDt=H_CREATE_DT"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyContactMethodsLightImagesResults =
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.locationGroupIdPK=LOCATION_GROUP_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.contactMethodId=CONTACT_METHOD_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.locationGroupIdPK=LOCATION_GROUP_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt.XVerified=XVERIFIED_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt.XRetailerId=XRETAILER_ID," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt.XLastModifiedSystemDate=XMODIFY_SYS_DT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt.XContactRetailerFlag=XCONTACT_RETAILER_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt.X_BPID=X_BPID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension
   * XContactMethodGroup.
   *
   * @generated
   */ 
   public final static String getPartyContactMethodHistoryByIDSQL = "SELECT DISTINCT A.H_LOCATION_GROUP_I AS H_CONT_METHOD_GRP_ID, A.H_ACTION_CODE, A.H_CREATED_BY, A.H_CREATE_DT, A.H_END_DT, A.LOCATION_GROUP_ID, A.CONTACT_METHOD_ID, A.CONT_METH_TP_CD, A.METHOD_ST_TP_CD, A.ATTACH_ALLOW_IND, A.TEXT_ONLY_IND, A.MESSAGE_SIZE, A.COMMENT_DESC, A.LAST_UPDATE_DT, A.LAST_UPDATE_USER, A.LAST_UPDATE_TX_ID, B.H_LOCATION_GROUP_I AS H_LOCATION_GROUP_I, B.H_ACTION_CODE, B.H_CREATED_BY, B.H_CREATE_DT, B.H_END_DT, B.LOCATION_GROUP_ID, B.UNDEL_REASON_TP_CD, B.CONT_ID, B.MEMBER_IND, B.PREFERRED_IND, B.SOLICIT_IND, B.LOC_GROUP_TP_CODE, B.EFFECT_START_MMDD, B.EFFECT_END_MMDD, B.EFFECT_START_TM, B.EFFECT_END_TM, B.START_DT, B.END_DT, B.LAST_UPDATE_DT, B.LAST_UPDATE_USER, B.LAST_UPDATE_TX_ID, B.LAST_USED_DT, B.LAST_VERIFIED_DT, B.SOURCE_IDENT_TP_CD, A.XVERIFIED_TP_CD, A.XRETAILER_ID, A.XMODIFY_SYS_DT, A.XCONTACT_RETAILER_FLAG, A.X_BPID" + 
     " FROM H_CONTACTMETHODGRO A,H_LOCATIONGROUP B" + 
     " WHERE A.H_LOCATION_GROUP_I = ? AND A.H_LOCATION_GROUP_I = B.H_LOCATION_GROUP_I AND (( ? BETWEEN A.H_CREATE_DT AND A.H_END_DT ) OR ( ? >= A.H_CREATE_DT AND A.H_END_DT IS NULL )) AND (( ? BETWEEN B.H_CREATE_DT AND B.H_END_DT ) OR ( ? >= B.H_CREATE_DT AND B.H_END_DT IS NULL ))";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyContactMethodHistoryByIDParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.locationGroupIdPK=H_LOCATION_GROUP_I," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.histCreateDt=H_CREATE_DT"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyContactMethodHistoryByIDResults =
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.locationGroupIdPK=H_CONT_METHOD_GRP_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.histActionCode=H_ACTION_CODE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.histCreatedBy=H_CREATED_BY," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.histEndDt=H_END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.locationGroupIdPK=LOCATION_GROUP_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.contactMethodId=CONTACT_METHOD_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.contMethTpCd=CONT_METH_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.methodStTpCd=METHOD_ST_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.attachAllowInd=ATTACH_ALLOW_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.textOnlyInd=TEXT_ONLY_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.messageSize=MESSAGE_SIZE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.commentDesc=COMMENT_DESC," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.locationGroupIdPK=H_LOCATION_GROUP_I," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.histActionCode=H_ACTION_CODE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.histCreatedBy=H_CREATED_BY," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.histEndDt=H_END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.locationGroupIdPK=LOCATION_GROUP_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.undelReasonTpCd=UNDEL_REASON_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.memberInd=MEMBER_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.preferredInd=PREFERRED_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.solicitInd=SOLICIT_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.locGroupTpCode=LOC_GROUP_TP_CODE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.effectStartMMDD=EFFECT_START_MMDD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.effectEndMMDD=EFFECT_END_MMDD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.effectStartTm=EFFECT_START_TM," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.effectEndTm=EFFECT_END_TM," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.startDt=START_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.endDt=END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastUsedDt=LAST_USED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastVerifiedDt=LAST_VERIFIED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.sourceIdentTpCd=SOURCE_IDENT_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt.XVerified=XVERIFIED_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt.XRetailerId=XRETAILER_ID," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt.XLastModifiedSystemDate=XMODIFY_SYS_DT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt.XContactRetailerFlag=XCONTACT_RETAILER_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt.X_BPID=X_BPID"; 
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */ 
   public final static String resultSetMapping2 = "<rsm>" + 
     "<col number='1' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup' property='locationGroupIdPK'></col>" + 
     "<col number='2' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup' property='contactMethodId'></col>" + 
     "<col number='3' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup' property='contMethTpCd'></col>" + 
     "<col number='4' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup' property='methodStTpCd'></col>" + 
     "<col number='5' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup' property='attachAllowInd'></col>" + 
     "<col number='6' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup' property='textOnlyInd'></col>" + 
     "<col number='7' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup' property='messageSize'></col>" + 
     "<col number='8' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup' property='commentDesc'></col>" + 
     "<col number='9' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup' property='lastUpdateDt'></col>" + 
     "<col number='10' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup' property='lastUpdateUser'></col>" + 
     "<col number='11' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup' property='lastUpdateTxId'></col>" + 
     "<col number='12' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='locationGroupIdPK'></col>" + 
     "<col number='13' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='undelReasonTpCd'></col>" + 
     "<col number='14' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='contId'></col>" + 
     "<col number='15' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='memberInd'></col>" + 
     "<col number='16' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='preferredInd'></col>" + 
     "<col number='17' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='solicitInd'></col>" + 
     "<col number='18' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='locGroupTpCode'></col>" + 
     "<col number='19' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='effectStartMMDD'></col>" + 
     "<col number='20' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='effectEndMMDD'></col>" + 
     "<col number='21' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='effectStartTm'></col>" + 
     "<col number='22' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='effectEndTm'></col>" + 
     "<col number='23' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='startDt'></col>" + 
     "<col number='24' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='endDt'></col>" + 
     "<col number='25' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='lastUpdateDt'></col>" + 
     "<col number='26' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='lastUpdateUser'></col>" + 
     "<col number='27' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='lastUpdateTxId'></col>" + 
     "<col number='28' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='lastUsedDt'></col>" + 
     "<col number='29' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='lastVerifiedDt'></col>" + 
     "<col number='30' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='sourceIdentTpCd'></col>" + 
     "<col number='31' bean='com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt' property='XVerified'></col>" + 
     "<col number='32' bean='com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt' property='XRetailerId'></col>" + 
     "<col number='33' bean='com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt' property='XLastModifiedSystemDate'></col>" + 
     "<col number='34' bean='com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt' property='XContactRetailerFlag'></col>" + 
     "<col number='35' bean='com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt' property='X_BPID'></col>" + 
     "</rsm>";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension
   * XContactMethodGroup.
   *
   * @generated
   */ 
   public final static String getPartyContactMethodSQL = "SELECT CONTACTMETHODGROUP.LOCATION_GROUP_ID, CONTACTMETHODGROUP.CONTACT_METHOD_ID, CONTACTMETHODGROUP.CONT_METH_TP_CD, CONTACTMETHODGROUP.METHOD_ST_TP_CD, CONTACTMETHODGROUP.ATTACH_ALLOW_IND, CONTACTMETHODGROUP.TEXT_ONLY_IND, CONTACTMETHODGROUP.MESSAGE_SIZE, CONTACTMETHODGROUP.COMMENT_DESC, CONTACTMETHODGROUP.LAST_UPDATE_DT, CONTACTMETHODGROUP.LAST_UPDATE_USER, CONTACTMETHODGROUP.LAST_UPDATE_TX_ID, LOCATIONGROUP.LOCATION_GROUP_ID, LOCATIONGROUP.UNDEL_REASON_TP_CD, LOCATIONGROUP.CONT_ID, LOCATIONGROUP.MEMBER_IND, LOCATIONGROUP.PREFERRED_IND, LOCATIONGROUP.SOLICIT_IND, LOCATIONGROUP.LOC_GROUP_TP_CODE, LOCATIONGROUP.EFFECT_START_MMDD, LOCATIONGROUP.EFFECT_END_MMDD, LOCATIONGROUP.EFFECT_START_TM, LOCATIONGROUP.EFFECT_END_TM, LOCATIONGROUP.START_DT, LOCATIONGROUP.END_DT, LOCATIONGROUP.LAST_UPDATE_DT, LOCATIONGROUP.LAST_UPDATE_USER, LOCATIONGROUP.LAST_UPDATE_TX_ID, LOCATIONGROUP.LAST_USED_DT, LOCATIONGROUP.LAST_VERIFIED_DT, LOCATIONGROUP.SOURCE_IDENT_TP_CD, CONTACTMETHODGROUP.XVERIFIED_TP_CD, CONTACTMETHODGROUP.XRETAILER_ID, CONTACTMETHODGROUP.XMODIFY_SYS_DT, CONTACTMETHODGROUP.XCONTACT_RETAILER_FLAG, CONTACTMETHODGROUP.X_BPID" + 
     " FROM CONTACTMETHODGROUP,LOCATIONGROUP" + 
     " WHERE CONTACTMETHODGROUP.LOCATION_GROUP_ID = LOCATIONGROUP.LOCATION_GROUP_ID AND LOCATIONGROUP.CONT_ID = ? AND CONTACTMETHODGROUP.CONT_METH_TP_CD = ? AND ((LOCATIONGROUP.END_DT IS NULL) OR (LOCATIONGROUP.END_DT > ? ))" + 
     " UNION ALL SELECT CONTACTMETHODGROUP.LOCATION_GROUP_ID, CONTACTMETHODGROUP.CONTACT_METHOD_ID, CONTACTMETHODGROUP.CONT_METH_TP_CD, CONTACTMETHODGROUP.METHOD_ST_TP_CD, CONTACTMETHODGROUP.ATTACH_ALLOW_IND, CONTACTMETHODGROUP.TEXT_ONLY_IND, CONTACTMETHODGROUP.MESSAGE_SIZE, CONTACTMETHODGROUP.COMMENT_DESC, CONTACTMETHODGROUP.LAST_UPDATE_DT, CONTACTMETHODGROUP.LAST_UPDATE_USER,CONTACTMETHODGROUP.LAST_UPDATE_TX_ID, LOCATIONGROUP.LOCATION_GROUP_ID, LOCATIONGROUP.UNDEL_REASON_TP_CD, LOCATIONGROUP.CONT_ID, LOCATIONGROUP.MEMBER_IND, LOCATIONGROUP.PREFERRED_IND, LOCATIONGROUP.SOLICIT_IND, LOCATIONGROUP.LOC_GROUP_TP_CODE, LOCATIONGROUP.EFFECT_START_MMDD, LOCATIONGROUP.EFFECT_END_MMDD, LOCATIONGROUP.EFFECT_START_TM, LOCATIONGROUP.EFFECT_END_TM, LOCATIONGROUP.START_DT, LOCATIONGROUP.END_DT, LOCATIONGROUP.LAST_UPDATE_DT, LOCATIONGROUP.LAST_UPDATE_USER, LOCATIONGROUP.LAST_UPDATE_TX_ID, LOCATIONGROUP.LAST_USED_DT, LOCATIONGROUP.LAST_VERIFIED_DT, LOCATIONGROUP.SOURCE_IDENT_TP_CD, CONTACTMETHODGROUP.XVERIFIED_TP_CD, CONTACTMETHODGROUP.XRETAILER_ID, CONTACTMETHODGROUP.XMODIFY_SYS_DT, CONTACTMETHODGROUP.XCONTACT_RETAILER_FLAG, CONTACTMETHODGROUP.X_BPID" + 
     " FROM CONTACTMETHODGROUP, LOCATIONGROUP" + 
     " WHERE CONTACTMETHODGROUP.LOCATION_GROUP_ID = LOCATIONGROUP.LOCATION_GROUP_ID AND LOCATIONGROUP.CONT_ID = ? AND CONTACTMETHODGROUP.CONT_METH_TP_CD = ? AND ((LOCATIONGROUP.END_DT IS NULL) OR (LOCATIONGROUP.END_DT > ?))";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyContactMethodParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.contMethTpCd=CONT_METH_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.endDt=END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.contMethTpCd=CONT_METH_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.endDt=END_DT"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyContactMethodResults =
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.locationGroupIdPK=LOCATION_GROUP_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.contactMethodId=CONTACT_METHOD_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.contMethTpCd=CONT_METH_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.methodStTpCd=METHOD_ST_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.attachAllowInd=ATTACH_ALLOW_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.textOnlyInd=TEXT_ONLY_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.messageSize=MESSAGE_SIZE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.commentDesc=COMMENT_DESC," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.locationGroupIdPK=LOCATION_GROUP_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.undelReasonTpCd=UNDEL_REASON_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.memberInd=MEMBER_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.preferredInd=PREFERRED_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.solicitInd=SOLICIT_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.locGroupTpCode=LOC_GROUP_TP_CODE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.effectStartMMDD=EFFECT_START_MMDD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.effectEndMMDD=EFFECT_END_MMDD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.effectStartTm=EFFECT_START_TM," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.effectEndTm=EFFECT_END_TM," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.startDt=START_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.endDt=END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastUsedDt=LAST_USED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastVerifiedDt=LAST_VERIFIED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.sourceIdentTpCd=SOURCE_IDENT_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt.XVerified=XVERIFIED_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt.XRetailerId=XRETAILER_ID," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt.XLastModifiedSystemDate=XMODIFY_SYS_DT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt.XContactRetailerFlag=XCONTACT_RETAILER_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt.X_BPID=X_BPID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension
   * XContactMethodGroup.
   *
   * @generated
   */ 
   public final static String getAllPartyContactMethodByContMethodIDSQL = "SELECT CONTACTMETHODGROUP.LOCATION_GROUP_ID, CONTACTMETHODGROUP.CONTACT_METHOD_ID, CONTACTMETHODGROUP.CONT_METH_TP_CD, CONTACTMETHODGROUP.METHOD_ST_TP_CD, CONTACTMETHODGROUP.ATTACH_ALLOW_IND, CONTACTMETHODGROUP.TEXT_ONLY_IND, CONTACTMETHODGROUP.MESSAGE_SIZE, CONTACTMETHODGROUP.COMMENT_DESC, CONTACTMETHODGROUP.LAST_UPDATE_DT, CONTACTMETHODGROUP.LAST_UPDATE_USER, CONTACTMETHODGROUP.LAST_UPDATE_TX_ID, LOCATIONGROUP.LOCATION_GROUP_ID, LOCATIONGROUP.UNDEL_REASON_TP_CD, LOCATIONGROUP.CONT_ID, LOCATIONGROUP.MEMBER_IND, LOCATIONGROUP.PREFERRED_IND, LOCATIONGROUP.SOLICIT_IND, LOCATIONGROUP.LOC_GROUP_TP_CODE, LOCATIONGROUP.EFFECT_START_MMDD, LOCATIONGROUP.EFFECT_END_MMDD, LOCATIONGROUP.EFFECT_START_TM, LOCATIONGROUP.EFFECT_END_TM, LOCATIONGROUP.START_DT, LOCATIONGROUP.END_DT, LOCATIONGROUP.LAST_UPDATE_DT, LOCATIONGROUP.LAST_UPDATE_USER, LOCATIONGROUP.LAST_UPDATE_TX_ID, CONTACTMETHODGROUP.XVERIFIED_TP_CD, CONTACTMETHODGROUP.XRETAILER_ID, CONTACTMETHODGROUP.XMODIFY_SYS_DT, CONTACTMETHODGROUP.XCONTACT_RETAILER_FLAG, CONTACTMETHODGROUP.X_BPID" + 
     " FROM CONTACT, LOCATIONGROUP, CONTACTMETHODGROUP, CONTACTMETHOD" + 
     " WHERE CONTACT.CONT_ID = LOCATIONGROUP.CONT_ID AND LOCATIONGROUP.LOCATION_GROUP_ID=CONTACTMETHODGROUP.LOCATION_GROUP_ID AND CONTACTMETHODGROUP.CONTACT_METHOD_ID = CONTACTMETHOD.CONTACT_METHOD_ID AND CONTACTMETHOD.CONTACT_METHOD_ID = ?";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getAllPartyContactMethodByContMethodIDParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethod.contactMethodIdPK=CONTACT_METHOD_ID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getAllPartyContactMethodByContMethodIDResults =
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.locationGroupIdPK=LOCATION_GROUP_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.contactMethodId=CONTACT_METHOD_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.contMethTpCd=CONT_METH_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.methodStTpCd=METHOD_ST_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.attachAllowInd=ATTACH_ALLOW_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.textOnlyInd=TEXT_ONLY_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.messageSize=MESSAGE_SIZE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.commentDesc=COMMENT_DESC," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.locationGroupIdPK=LOCATION_GROUP_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.undelReasonTpCd=UNDEL_REASON_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.memberInd=MEMBER_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.preferredInd=PREFERRED_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.solicitInd=SOLICIT_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.locGroupTpCode=LOC_GROUP_TP_CODE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.effectStartMMDD=EFFECT_START_MMDD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.effectEndMMDD=EFFECT_END_MMDD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.effectStartTm=EFFECT_START_TM," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.effectEndTm=EFFECT_END_TM," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.startDt=START_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.endDt=END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt.XVerified=XVERIFIED_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt.XRetailerId=XRETAILER_ID," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt.XLastModifiedSystemDate=XMODIFY_SYS_DT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt.XContactRetailerFlag=XCONTACT_RETAILER_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt.X_BPID=X_BPID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension
   * XContactMethodGroup.
   *
   * @generated
   */ 
   public final static String getAllPartyContactMethodByAddressdIDSQL = "SELECT CONTACTMETHODGROUP.LOCATION_GROUP_ID, CONTACTMETHODGROUP.CONTACT_METHOD_ID, CONTACTMETHODGROUP.CONT_METH_TP_CD, CONTACTMETHODGROUP.METHOD_ST_TP_CD, CONTACTMETHODGROUP.ATTACH_ALLOW_IND, CONTACTMETHODGROUP.TEXT_ONLY_IND, CONTACTMETHODGROUP.MESSAGE_SIZE, CONTACTMETHODGROUP.COMMENT_DESC, CONTACTMETHODGROUP.LAST_UPDATE_DT, CONTACTMETHODGROUP.LAST_UPDATE_USER,CONTACTMETHODGROUP.LAST_UPDATE_TX_ID, LOCATIONGROUP.LOCATION_GROUP_ID, LOCATIONGROUP.UNDEL_REASON_TP_CD, LOCATIONGROUP.CONT_ID, LOCATIONGROUP.MEMBER_IND, LOCATIONGROUP.PREFERRED_IND, LOCATIONGROUP.SOLICIT_IND, LOCATIONGROUP.LOC_GROUP_TP_CODE, LOCATIONGROUP.EFFECT_START_MMDD, LOCATIONGROUP.EFFECT_END_MMDD, LOCATIONGROUP.EFFECT_START_TM, LOCATIONGROUP.EFFECT_END_TM, LOCATIONGROUP.START_DT, LOCATIONGROUP.END_DT, LOCATIONGROUP.LAST_UPDATE_DT, LOCATIONGROUP.LAST_UPDATE_USER, LOCATIONGROUP.LAST_UPDATE_TX_ID, CONTACTMETHODGROUP.XVERIFIED_TP_CD, CONTACTMETHODGROUP.XRETAILER_ID, CONTACTMETHODGROUP.XMODIFY_SYS_DT, CONTACTMETHODGROUP.XCONTACT_RETAILER_FLAG, CONTACTMETHODGROUP.X_BPID" + 
     " FROM CONTACT, LOCATIONGROUP, CONTACTMETHODGROUP, CONTACTMETHOD" + 
     " WHERE CONTACT.CONT_ID = LOCATIONGROUP.CONT_ID AND LOCATIONGROUP.LOCATION_GROUP_ID=CONTACTMETHODGROUP.LOCATION_GROUP_ID AND CONTACTMETHODGROUP.CONTACT_METHOD_ID = CONTACTMETHOD.CONTACT_METHOD_ID AND CONTACTMETHOD.ADDRESS_ID = ?";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getAllPartyContactMethodByAddressdIDParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethod.addressId=ADDRESS_ID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getAllPartyContactMethodByAddressdIDResults =
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.locationGroupIdPK=LOCATION_GROUP_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.contactMethodId=CONTACT_METHOD_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.contMethTpCd=CONT_METH_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.methodStTpCd=METHOD_ST_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.attachAllowInd=ATTACH_ALLOW_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.textOnlyInd=TEXT_ONLY_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.messageSize=MESSAGE_SIZE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.commentDesc=COMMENT_DESC," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.locationGroupIdPK=LOCATION_GROUP_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.undelReasonTpCd=UNDEL_REASON_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.memberInd=MEMBER_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.preferredInd=PREFERRED_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.solicitInd=SOLICIT_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.locGroupTpCode=LOC_GROUP_TP_CODE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.effectStartMMDD=EFFECT_START_MMDD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.effectEndMMDD=EFFECT_END_MMDD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.effectStartTm=EFFECT_START_TM," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.effectEndTm=EFFECT_END_TM," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.startDt=START_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.endDt=END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt.XVerified=XVERIFIED_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt.XRetailerId=XRETAILER_ID," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt.XLastModifiedSystemDate=XMODIFY_SYS_DT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt.XContactRetailerFlag=XCONTACT_RETAILER_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt.X_BPID=X_BPID"; 


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getPartyContactMethodsHistorySQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getPartyContactMethodsHistoryParameters, results=getPartyContactMethodsHistoryResults)
  		Iterator<ResultQueue3<EObjContactMethodGroup, EObjLocationGroup, EObjXContactMethodGroupExt>> getPartyContactMethodsHistory(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getActivePartyContactMethodsSQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getActivePartyContactMethodsParameters, results=getActivePartyContactMethodsResults)
  		Iterator<ResultQueue3<EObjContactMethodGroup, EObjLocationGroup, EObjXContactMethodGroupExt>> getActivePartyContactMethods(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getInactivePartyContactMethodsSQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getInactivePartyContactMethodsParameters, results=getInactivePartyContactMethodsResults)
  		Iterator<ResultQueue3<EObjContactMethodGroup, EObjLocationGroup, EObjXContactMethodGroupExt>> getInactivePartyContactMethods(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getAllPartyContactMethodsSQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getAllPartyContactMethodsParameters, results=getAllPartyContactMethodsResults)
  		Iterator<ResultQueue3<EObjContactMethodGroup, EObjLocationGroup, EObjXContactMethodGroupExt>> getAllPartyContactMethods(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getPartyContactMethodHistorySQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getPartyContactMethodHistoryParameters, results=getPartyContactMethodHistoryResults)
  		Iterator<ResultQueue3<EObjContactMethodGroup, EObjLocationGroup, EObjXContactMethodGroupExt>> getPartyContactMethodHistory(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getPartyContactMethodByIDSQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getPartyContactMethodByIDParameters, results=getPartyContactMethodByIDResults)
  		Iterator<ResultQueue3<EObjContactMethodGroup, EObjLocationGroup, EObjXContactMethodGroupExt>> getPartyContactMethodByID(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getPartyContactMethodImagesSQL , pattern=resultSetMapping1)
  @EntityMapping(parameters=getPartyContactMethodImagesParameters, results=getPartyContactMethodImagesResults)
  		Iterator<ResultQueue3<EObjContactMethodGroup, EObjLocationGroup, EObjXContactMethodGroupExt>> getPartyContactMethodImages(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getPartyContactMethodsLightImagesSQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getPartyContactMethodsLightImagesParameters, results=getPartyContactMethodsLightImagesResults)
  		Iterator<ResultQueue3<EObjContactMethodGroup, EObjLocationGroup, EObjXContactMethodGroupExt>> getPartyContactMethodsLightImages(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getPartyContactMethodHistoryByIDSQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getPartyContactMethodHistoryByIDParameters, results=getPartyContactMethodHistoryByIDResults)
  		Iterator<ResultQueue3<EObjContactMethodGroup, EObjLocationGroup, EObjXContactMethodGroupExt>> getPartyContactMethodHistoryByID(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getPartyContactMethodSQL , pattern=resultSetMapping2)
  @EntityMapping(parameters=getPartyContactMethodParameters, results=getPartyContactMethodResults)
  		Iterator<ResultQueue3<EObjContactMethodGroup, EObjLocationGroup, EObjXContactMethodGroupExt>> getPartyContactMethod(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getAllPartyContactMethodByContMethodIDSQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getAllPartyContactMethodByContMethodIDParameters, results=getAllPartyContactMethodByContMethodIDResults)
  		Iterator<ResultQueue3<EObjContactMethodGroup, EObjLocationGroup, EObjXContactMethodGroupExt>> getAllPartyContactMethodByContMethodID(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getAllPartyContactMethodByAddressdIDSQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getAllPartyContactMethodByAddressdIDParameters, results=getAllPartyContactMethodByAddressdIDResults)
  		Iterator<ResultQueue3<EObjContactMethodGroup, EObjLocationGroup, EObjXContactMethodGroupExt>> getAllPartyContactMethodByAddressdID(Object[] parameters);
 
}


