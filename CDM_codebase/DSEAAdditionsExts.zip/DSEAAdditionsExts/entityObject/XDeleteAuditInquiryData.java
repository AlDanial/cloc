/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[f78d29a063c66d281654a1f112514bb8]
 */

package com.ibm.daimler.dsea.entityObject;


import com.ibm.mdm.base.db.ResultQueue1;
import java.util.Iterator;
import com.ibm.mdm.base.db.EntityMapping;
import com.ibm.pdq.annotation.Select;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * @generated
 */
public interface XDeleteAuditInquiryData {
  
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String tableAliasString = "tableAlias (" + 
                                            "XDELETEAUDIT => com.ibm.daimler.dsea.entityObject.EObjXDeleteAudit, " +
                                            "H_XDELETEAUDIT => com.ibm.daimler.dsea.entityObject.EObjXDeleteAudit" +
                                            ")";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getXDeleteAuditSql = "SELECT r.XDelete_Auditpk_Id XDelete_Auditpk_Id, r.CONT_ID CONT_ID, r.ADMIN_CLIENT_ID ADMIN_CLIENT_ID, r.ADMIN_SYSTEM_VALUE ADMIN_SYSTEM_VALUE, r.DESCRIPTION DESCRIPTION, r.DELETE_DATE DELETE_DATE, r.MARKET_NAME MARKET_NAME, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XDELETEAUDIT r WHERE r.XDelete_Auditpk_Id = ? ";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXDeleteAuditParameters =
    "EObjXDeleteAudit.XDeleteAuditpkId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXDeleteAuditResults =
    "EObjXDeleteAudit.XDeleteAuditpkId," +
    "EObjXDeleteAudit.CONT_ID," +
    "EObjXDeleteAudit.ADMIN_CLIENT_ID," +
    "EObjXDeleteAudit.ADMIN_SYSTEM_VALUE," +
    "EObjXDeleteAudit.DESCRIPTION," +
    "EObjXDeleteAudit.DELETE_DATE," +
    "EObjXDeleteAudit.MARKET_NAME," +
    "EObjXDeleteAudit.lastUpdateDt," +
    "EObjXDeleteAudit.lastUpdateUser," +
    "EObjXDeleteAudit.lastUpdateTxId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getXDeleteAuditHistorySql = "SELECT r.H_XDelete_Auditpk_Id hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.XDelete_Auditpk_Id XDelete_Auditpk_Id, r.CONT_ID CONT_ID, r.ADMIN_CLIENT_ID ADMIN_CLIENT_ID, r.ADMIN_SYSTEM_VALUE ADMIN_SYSTEM_VALUE, r.DESCRIPTION DESCRIPTION, r.DELETE_DATE DELETE_DATE, r.MARKET_NAME MARKET_NAME, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XDELETEAUDIT r WHERE r.H_XDelete_Auditpk_Id = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXDeleteAuditHistoryParameters =
    "EObjXDeleteAudit.XDeleteAuditpkId," +
    "EObjXDeleteAudit.lastUpdateDt," +
    "EObjXDeleteAudit.lastUpdateDt";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXDeleteAuditHistoryResults =
    "EObjXDeleteAudit.historyIdPK," +
    "EObjXDeleteAudit.histActionCode," +
    "EObjXDeleteAudit.histCreatedBy," +
    "EObjXDeleteAudit.histCreateDt," +
    "EObjXDeleteAudit.histEndDt," +
    "EObjXDeleteAudit.XDeleteAuditpkId," +
    "EObjXDeleteAudit.CONT_ID," +
    "EObjXDeleteAudit.ADMIN_CLIENT_ID," +
    "EObjXDeleteAudit.ADMIN_SYSTEM_VALUE," +
    "EObjXDeleteAudit.DESCRIPTION," +
    "EObjXDeleteAudit.DELETE_DATE," +
    "EObjXDeleteAudit.MARKET_NAME," +
    "EObjXDeleteAudit.lastUpdateDt," +
    "EObjXDeleteAudit.lastUpdateUser," +
    "EObjXDeleteAudit.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getXDeleteAuditSql, pattern=tableAliasString)
  @EntityMapping(parameters=getXDeleteAuditParameters, results=getXDeleteAuditResults)
  Iterator<ResultQueue1<EObjXDeleteAudit>> getXDeleteAudit(Object[] parameters);  


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getXDeleteAuditHistorySql, pattern=tableAliasString)
  @EntityMapping(parameters=getXDeleteAuditHistoryParameters, results=getXDeleteAuditHistoryResults)
  Iterator<ResultQueue1<EObjXDeleteAudit>> getXDeleteAuditHistory(Object[] parameters);  


}


