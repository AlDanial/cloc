/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[a0149ba77eda1a4c1d96ff75bffc008b]
 */


package com.ibm.daimler.dsea.entityObject;

import java.util.Iterator;
import com.ibm.mdm.base.db.EntityMapping;
import com.ibm.pdq.annotation.Select;
import com.ibm.pdq.annotation.Update;

import com.dwl.tcrm.coreParty.entityObject.EObjPersonName;

import com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * @generated
 */
public interface EObjXPersonNameExtData {


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjXPersonNameExtSql = "select XMODIFY_SYS_DT, XGIVEN_NAME_ONE_LOCAL, XGIVEN_NAME_TWO_LOCAL, XLAST_NAME_LOCAL, XPERSONNAME_RETAILER_FLAG, X_BPID, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from PERSONNAME where PERSON_NAME_ID = ? ";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String createEObjXPersonNameExtSql = "insert into PERSONNAME (LAST_USED_DT, LAST_VERIFIED_DT, END_DT, GIVEN_NAME_FOUR, GIVEN_NAME_ONE, GIVEN_NAME_THREE, GIVEN_NAME_TWO, LAST_NAME, PREFIX_DESC, PERSON_NAME_ID, CONT_ID, START_DT, SUFFIX_DESC, USE_STANDARD_IND, NAME_USAGE_TP_CD, PREFIX_NAME_TP_CD, GENERATION_TP_CD, SOURCE_IDENT_TP_CD, P_LAST_NAME, P_GIVEN_NAME_ONE, P_GIVEN_NAME_TWO, P_GIVEN_NAME_THREE, P_GIVEN_NAME_FOUR, XMODIFY_SYS_DT, XGIVEN_NAME_ONE_LOCAL, XGIVEN_NAME_TWO_LOCAL, XLAST_NAME_LOCAL, XPERSONNAME_RETAILER_FLAG, X_BPID, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( ?1.lastUsedDt, ?1.lastVerifiedDt, ?1.endDt, ?1.givenNameFour, ?1.givenNameOne, ?1.givenNameThree, ?1.givenNameTwo, ?1.lastName, ?1.prefixDesc, ?1.personNameIdPK, ?1.contId, ?1.startDt, ?1.suffixDesc, ?1.useStandardInd, ?1.nameUsageTpCd, ?1.prefixNameTpCd, ?1.generationTpCd, ?1.sourceIdentTpCd, ?1.pLastName, ?1.pGivenNameOne, ?1.pGivenNameTwo, ?1.pGivenNameThree, ?1.pGivenNameFour, ?2.xLastModifiedSystemDate, ?2.xGivenNameOneLocal, ?2.xGivenNameTwoLocal, ?2.xLastNameLocal, ?2.xPersonNameRetailerFlag, ?2.x_BPID, ?1.lastUpdateDt, ?1.lastUpdateUser, ?1.lastUpdateTxId)";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String updateEObjXPersonNameExtSql = "update PERSONNAME set LAST_USED_DT = ?1.lastUsedDt, LAST_VERIFIED_DT = ?1.lastVerifiedDt, END_DT = ?1.endDt, GIVEN_NAME_FOUR = ?1.givenNameFour, GIVEN_NAME_ONE = ?1.givenNameOne, GIVEN_NAME_THREE = ?1.givenNameThree, GIVEN_NAME_TWO = ?1.givenNameTwo, LAST_NAME = ?1.lastName, PREFIX_DESC = ?1.prefixDesc, CONT_ID = ?1.contId, START_DT = ?1.startDt, SUFFIX_DESC = ?1.suffixDesc, USE_STANDARD_IND = ?1.useStandardInd, NAME_USAGE_TP_CD = ?1.nameUsageTpCd, PREFIX_NAME_TP_CD = ?1.prefixNameTpCd, GENERATION_TP_CD = ?1.generationTpCd, SOURCE_IDENT_TP_CD = ?1.sourceIdentTpCd, P_LAST_NAME = ?1.pLastName, P_GIVEN_NAME_ONE = ?1.pGivenNameOne, P_GIVEN_NAME_TWO = ?1.pGivenNameTwo, P_GIVEN_NAME_THREE = ?1.pGivenNameThree, P_GIVEN_NAME_FOUR = ?1.pGivenNameFour, XMODIFY_SYS_DT = ?2.xLastModifiedSystemDate, XGIVEN_NAME_ONE_LOCAL = ?2.xGivenNameOneLocal, XGIVEN_NAME_TWO_LOCAL = ?2.xGivenNameTwoLocal, XLAST_NAME_LOCAL = ?2.xLastNameLocal, XPERSONNAME_RETAILER_FLAG = ?2.xPersonNameRetailerFlag, X_BPID = ?2.x_BPID, LAST_UPDATE_DT = ?1.lastUpdateDt, LAST_UPDATE_USER = ?1.lastUpdateUser, LAST_UPDATE_TX_ID = ?1.lastUpdateTxId where PERSON_NAME_ID = ?1.personNameIdPK and LAST_UPDATE_DT = ?1.oldLastUpdateDt";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String deleteEObjXPersonNameExtSql = "delete from PERSONNAME where PERSON_NAME_ID = ?";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXPersonNameExtKeyField = "EObjXPersonNameExt.personNameIdPK";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXPersonNameExtGetFields =
    "EObjXPersonNameExt.xLastModifiedSystemDate," +
    "EObjXPersonNameExt.xGivenNameOneLocal," +
    "EObjXPersonNameExt.xGivenNameTwoLocal," +
    "EObjXPersonNameExt.xLastNameLocal," +
    "EObjXPersonNameExt.xPersonNameRetailerFlag," +
    "EObjXPersonNameExt.x_BPID," +
    "EObjXPersonNameExt.lastUpdateDt," +
    "EObjXPersonNameExt.lastUpdateUser," +
    "EObjXPersonNameExt.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXPersonNameExtAllFields =
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastUsedDt," +
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastVerifiedDt," +
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.endDt," +
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.givenNameFour," +
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.givenNameOne," +
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.givenNameThree," +
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.givenNameTwo," +
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastName," +
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.prefixDesc," +
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.personNameIdPK," +
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.contId," +
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.startDt," +
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.suffixDesc," +
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.useStandardInd," +
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.nameUsageTpCd," +
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.prefixNameTpCd," +
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.generationTpCd," +
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.sourceIdentTpCd," +
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.pLastName," +
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.pGivenNameOne," +
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.pGivenNameTwo," +
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.pGivenNameThree," +
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.pGivenNameFour," +
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.xLastModifiedSystemDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.xGivenNameOneLocal," +
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.xGivenNameTwoLocal," +
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.xLastNameLocal," +
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.xPersonNameRetailerFlag," +
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.x_BPID," +
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastUpdateDt," +
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastUpdateUser," +
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXPersonNameExtUpdateFields =
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastUsedDt," +
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastVerifiedDt," +
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.endDt," +
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.givenNameFour," +
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.givenNameOne," +
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.givenNameThree," +
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.givenNameTwo," +
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastName," +
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.prefixDesc," +
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.contId," +
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.startDt," +
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.suffixDesc," +
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.useStandardInd," +
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.nameUsageTpCd," +
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.prefixNameTpCd," +
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.generationTpCd," +
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.sourceIdentTpCd," +
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.pLastName," +
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.pGivenNameOne," +
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.pGivenNameTwo," +
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.pGivenNameThree," +
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.pGivenNameFour," +
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.xLastModifiedSystemDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.xGivenNameOneLocal," +
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.xGivenNameTwoLocal," +
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.xLastNameLocal," +
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.xPersonNameRetailerFlag," +
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.x_BPID," +
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastUpdateDt," +
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastUpdateUser," +
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastUpdateTxId," +
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.personNameIdPK," +
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.oldLastUpdateDt";   

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Select XPersonName by parameters.
   * @generated
   */
  @Select(sql=getEObjXPersonNameExtSql)
  @EntityMapping(parameters=EObjXPersonNameExtKeyField, results=EObjXPersonNameExtGetFields)
  Iterator<EObjXPersonNameExt> getEObjXPersonNameExt(Long personNameIdPK);  
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Create XPersonName by EObjXPersonNameExt Object.
   * @generated
   */
  @Update(sql=createEObjXPersonNameExtSql)
  @EntityMapping(parameters=EObjXPersonNameExtAllFields)
    int createEObjXPersonNameExt(EObjPersonName e1, EObjXPersonNameExt e2); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Update one XPersonName by EObjXPersonNameExt object.
   * @generated
   */
  @Update(sql=updateEObjXPersonNameExtSql)
  @EntityMapping(parameters=EObjXPersonNameExtUpdateFields)
    int updateEObjXPersonNameExt(EObjPersonName e1, EObjXPersonNameExt e2); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Delete XPersonName by parameters.
   * @generated
   */
  @Update(sql=deleteEObjXPersonNameExtSql)
  @EntityMapping(parameters=EObjXPersonNameExtKeyField)
  int deleteEObjXPersonNameExt(Long personNameIdPK);

}

