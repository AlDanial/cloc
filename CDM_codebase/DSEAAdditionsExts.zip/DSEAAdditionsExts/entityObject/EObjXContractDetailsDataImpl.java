package com.ibm.daimler.dsea.entityObject;

import com.ibm.daimler.dsea.entityObject.EObjXContractDetails;
import com.ibm.pdq.runtime.generator.BaseParameterHandler;
import java.util.Iterator;
import java.sql.PreparedStatement;
import com.ibm.pdq.runtime.statement.StatementDescriptor;
import com.ibm.pdq.runtime.generator.BaseData;
import java.sql.SQLException;
import com.ibm.pdq.annotation.Metadata;
import com.ibm.pdq.runtime.generator.BaseRowHandler;
import com.ibm.pdq.runtime.statement.SqlStatementType;
import java.sql.Types;


/**
 * <!-- begin-user-doc -->
 * 
 * <!-- end-user-doc -->
 * 
 * @generated
 */
public class EObjXContractDetailsDataImpl  extends BaseData implements EObjXContractDetailsData
{

  /**
   * @generated
   */
  public static final String generatorVersion = "3.200.75";

  /**
   * @generated
   */
  public static final String identifier = "EObjXContractDetailsData";

  /**
   * @generated
   */
  public static final long generationTime = 0x000001635e65fd3fL;

  /**
   * @generated
   */
  public static final String collection = "NULLID";

  /**
   * @generated
   */
  public static final String packageVersion = null;

  /**
   * @generated
   */
  public static final boolean forceSingleBindIsolation = false;

  /**
   * @generated
   */
  public EObjXContractDetailsDataImpl()
  {
    super();
  } 

  /**
   * @generated
   */
  public String getGeneratorVersion()
  {
    return generatorVersion;
  }

  /**
   * @Select( sql="select CONTRACTPK_ID, CONT_ID, FINANCE_PRODUCT, CONTRACT_NUMBER, CONTRACT_ST_TP_CD, MARKET_NAME, Financial_Product_Group, ADDR_LINE_ONE, ADDR_LINE_TWO, ADDR_LINE_THREE, POSTAL_CODE, CITY_NAME, RESIDENCE_NUMBER, COUNTRY_TP_CD, BUILDING_NAME, STREET_NAME, STREET_NUMBER, SOURCE_IDENT_TP_CD, START_DT, END_DT, MODIFY_SYS_DT, ODDays, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from XCONTRACT where CONTRACTPK_ID = ? " )
   * 
   * @generated
   */
  public Iterator<EObjXContractDetails> getEObjXContractDetails (Long contractpkId)
  {
    return queryIterator (getEObjXContractDetailsStatementDescriptor, contractpkId);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getEObjXContractDetailsStatementDescriptor = createStatementDescriptor (
    "getEObjXContractDetails(Long)",
    "select CONTRACTPK_ID, CONT_ID, FINANCE_PRODUCT, CONTRACT_NUMBER, CONTRACT_ST_TP_CD, MARKET_NAME, Financial_Product_Group, ADDR_LINE_ONE, ADDR_LINE_TWO, ADDR_LINE_THREE, POSTAL_CODE, CITY_NAME, RESIDENCE_NUMBER, COUNTRY_TP_CD, BUILDING_NAME, STREET_NAME, STREET_NUMBER, SOURCE_IDENT_TP_CD, START_DT, END_DT, MODIFY_SYS_DT, ODDays, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from XCONTRACT where CONTRACTPK_ID = ? ",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"contractpk_id", "cont_id", "finance_product", "contract_number", "contract_st_tp_cd", "market_name", "financial_product_group", "addr_line_one", "addr_line_two", "addr_line_three", "postal_code", "city_name", "residence_number", "country_tp_cd", "building_name", "street_name", "street_number", "source_ident_tp_cd", "start_dt", "end_dt", "modify_sys_dt", "oddays", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetEObjXContractDetailsParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetEObjXContractDetailsRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.INTEGER, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 19, 500, 250, 19, 50, 250, 500, 500, 500, 250, 250, 250, 19, 250, 250, 250, 19, 0, 0, 0, 10, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    1);

  /**
   * @generated
   */
  public static class GetEObjXContractDetailsParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setLong (stmt, 1, Types.BIGINT, (Long)parameters[0]);
    }
  }

  /**
   * @generated
   */
  public static class GetEObjXContractDetailsRowHandler extends BaseRowHandler<EObjXContractDetails>
  {
    /**
     * @generated
     */
    public EObjXContractDetails handle (java.sql.ResultSet rs, EObjXContractDetails returnObject) throws java.sql.SQLException
    {
      returnObject = new EObjXContractDetails ();
      returnObject.setContractpkId(getLongObject (rs, 1)); 
      returnObject.setContId(getLongObject (rs, 2)); 
      returnObject.setFinanceProduct(getString (rs, 3)); 
      returnObject.setContractNumber(getString (rs, 4)); 
      returnObject.setContractStatus(getLongObject (rs, 5)); 
      returnObject.setMarketName(getString (rs, 6)); 
      returnObject.setFinancialProductGroup(getString (rs, 7)); 
      returnObject.setAddressLineOne(getString (rs, 8)); 
      returnObject.setAddressLineTwo(getString (rs, 9)); 
      returnObject.setAddressLineThree(getString (rs, 10)); 
      returnObject.setPostalCode(getString (rs, 11)); 
      returnObject.setCityName(getString (rs, 12)); 
      returnObject.setResidenceNumber(getString (rs, 13)); 
      returnObject.setCountry(getLongObject (rs, 14)); 
      returnObject.setBuildingName(getString (rs, 15)); 
      returnObject.setStreetName(getString (rs, 16)); 
      returnObject.setStreetNumber(getString (rs, 17)); 
      returnObject.setSourceIdentifier(getLongObject (rs, 18)); 
      returnObject.setStartDate(getTimestamp (rs, 19)); 
      returnObject.setEndDate(getTimestamp (rs, 20)); 
      returnObject.setLastModifiedSystemDate(getTimestamp (rs, 21)); 
      returnObject.setODDays(getIntObject (rs, 22)); 
      returnObject.setLastUpdateDt(getTimestamp (rs, 23)); 
      returnObject.setLastUpdateUser(getString (rs, 24)); 
      returnObject.setLastUpdateTxId(getLongObject (rs, 25)); 
    
      return returnObject;
    }
  }

  /**
   * @Update( sql="insert into XCONTRACT (CONTRACTPK_ID, CONT_ID, FINANCE_PRODUCT, CONTRACT_NUMBER, CONTRACT_ST_TP_CD, MARKET_NAME, Financial_Product_Group, ADDR_LINE_ONE, ADDR_LINE_TWO, ADDR_LINE_THREE, POSTAL_CODE, CITY_NAME, RESIDENCE_NUMBER, COUNTRY_TP_CD, BUILDING_NAME, STREET_NAME, STREET_NUMBER, SOURCE_IDENT_TP_CD, START_DT, END_DT, MODIFY_SYS_DT, ODDays, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( :contractpkId, :contId, :financeProduct, :contractNumber, :contractStatus, :marketName, :financialProductGroup, :addressLineOne, :addressLineTwo, :addressLineThree, :postalCode, :cityName, :residenceNumber, :country, :buildingName, :streetName, :streetNumber, :sourceIdentifier, :startDate, :endDate, :lastModifiedSystemDate, :oDDays, :lastUpdateDt, :lastUpdateUser, :lastUpdateTxId)" )
   * 
   * @generated
   */
  public int createEObjXContractDetails (EObjXContractDetails e)
  {
    return update (createEObjXContractDetailsStatementDescriptor, e);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor createEObjXContractDetailsStatementDescriptor = createStatementDescriptor (
    "createEObjXContractDetails(com.ibm.daimler.dsea.entityObject.EObjXContractDetails)",
    "insert into XCONTRACT (CONTRACTPK_ID, CONT_ID, FINANCE_PRODUCT, CONTRACT_NUMBER, CONTRACT_ST_TP_CD, MARKET_NAME, Financial_Product_Group, ADDR_LINE_ONE, ADDR_LINE_TWO, ADDR_LINE_THREE, POSTAL_CODE, CITY_NAME, RESIDENCE_NUMBER, COUNTRY_TP_CD, BUILDING_NAME, STREET_NAME, STREET_NUMBER, SOURCE_IDENT_TP_CD, START_DT, END_DT, MODIFY_SYS_DT, ODDays, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values(  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? )",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.INSERT,
    null,
    new CreateEObjXContractDetailsParameterHandler (),
    new int[][]{{Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.INTEGER, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 19, 500, 250, 19, 50, 250, 500, 500, 500, 250, 250, 250, 19, 250, 250, 250, 19, 0, 0, 0, 10, 0, 0, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    2);

  /**
   * @generated
   */
  public static class CreateEObjXContractDetailsParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      EObjXContractDetails bean0 = (EObjXContractDetails) parameters[0];
      setLong (stmt, 1, Types.BIGINT, (Long)bean0.getContractpkId());
      setLong (stmt, 2, Types.BIGINT, (Long)bean0.getContId());
      setString (stmt, 3, Types.VARCHAR, (String)bean0.getFinanceProduct());
      setString (stmt, 4, Types.VARCHAR, (String)bean0.getContractNumber());
      setLong (stmt, 5, Types.BIGINT, (Long)bean0.getContractStatus());
      setString (stmt, 6, Types.VARCHAR, (String)bean0.getMarketName());
      setString (stmt, 7, Types.VARCHAR, (String)bean0.getFinancialProductGroup());
      setString (stmt, 8, Types.VARCHAR, (String)bean0.getAddressLineOne());
      setString (stmt, 9, Types.VARCHAR, (String)bean0.getAddressLineTwo());
      setString (stmt, 10, Types.VARCHAR, (String)bean0.getAddressLineThree());
      setString (stmt, 11, Types.VARCHAR, (String)bean0.getPostalCode());
      setString (stmt, 12, Types.VARCHAR, (String)bean0.getCityName());
      setString (stmt, 13, Types.VARCHAR, (String)bean0.getResidenceNumber());
      setLong (stmt, 14, Types.BIGINT, (Long)bean0.getCountry());
      setString (stmt, 15, Types.VARCHAR, (String)bean0.getBuildingName());
      setString (stmt, 16, Types.VARCHAR, (String)bean0.getStreetName());
      setString (stmt, 17, Types.VARCHAR, (String)bean0.getStreetNumber());
      setLong (stmt, 18, Types.BIGINT, (Long)bean0.getSourceIdentifier());
      setTimestamp (stmt, 19, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getStartDate());
      setTimestamp (stmt, 20, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getEndDate());
      setTimestamp (stmt, 21, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastModifiedSystemDate());
      setInteger (stmt, 22, Types.INTEGER, (Integer)bean0.getODDays());
      setTimestamp (stmt, 23, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUpdateDt());
      setString (stmt, 24, Types.VARCHAR, (String)bean0.getLastUpdateUser());
      setLong (stmt, 25, Types.BIGINT, (Long)bean0.getLastUpdateTxId());
    }
  }

  /**
   * @Update( sql="update XCONTRACT set CONT_ID = :contId, FINANCE_PRODUCT = :financeProduct, CONTRACT_NUMBER = :contractNumber, CONTRACT_ST_TP_CD = :contractStatus, MARKET_NAME = :marketName, Financial_Product_Group = :financialProductGroup, ADDR_LINE_ONE = :addressLineOne, ADDR_LINE_TWO = :addressLineTwo, ADDR_LINE_THREE = :addressLineThree, POSTAL_CODE = :postalCode, CITY_NAME = :cityName, RESIDENCE_NUMBER = :residenceNumber, COUNTRY_TP_CD = :country, BUILDING_NAME = :buildingName, STREET_NAME = :streetName, STREET_NUMBER = :streetNumber, SOURCE_IDENT_TP_CD = :sourceIdentifier, START_DT = :startDate, END_DT = :endDate, MODIFY_SYS_DT = :lastModifiedSystemDate, ODDays = :oDDays, LAST_UPDATE_DT = :lastUpdateDt, LAST_UPDATE_USER = :lastUpdateUser, LAST_UPDATE_TX_ID = :lastUpdateTxId where CONTRACTPK_ID = :contractpkId and LAST_UPDATE_DT = :oldLastUpdateDt" )
   * 
   * @generated
   */
  public int updateEObjXContractDetails (EObjXContractDetails e)
  {
    return update (updateEObjXContractDetailsStatementDescriptor, e);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor updateEObjXContractDetailsStatementDescriptor = createStatementDescriptor (
    "updateEObjXContractDetails(com.ibm.daimler.dsea.entityObject.EObjXContractDetails)",
    "update XCONTRACT set CONT_ID =  ? , FINANCE_PRODUCT =  ? , CONTRACT_NUMBER =  ? , CONTRACT_ST_TP_CD =  ? , MARKET_NAME =  ? , Financial_Product_Group =  ? , ADDR_LINE_ONE =  ? , ADDR_LINE_TWO =  ? , ADDR_LINE_THREE =  ? , POSTAL_CODE =  ? , CITY_NAME =  ? , RESIDENCE_NUMBER =  ? , COUNTRY_TP_CD =  ? , BUILDING_NAME =  ? , STREET_NAME =  ? , STREET_NUMBER =  ? , SOURCE_IDENT_TP_CD =  ? , START_DT =  ? , END_DT =  ? , MODIFY_SYS_DT =  ? , ODDays =  ? , LAST_UPDATE_DT =  ? , LAST_UPDATE_USER =  ? , LAST_UPDATE_TX_ID =  ?  where CONTRACTPK_ID =  ?  and LAST_UPDATE_DT =  ? ",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.UPDATE,
    null,
    new UpdateEObjXContractDetailsParameterHandler (),
    new int[][]{{Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.INTEGER, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP}, {19, 500, 250, 19, 50, 250, 500, 500, 500, 250, 250, 250, 19, 250, 250, 250, 19, 0, 0, 0, 10, 0, 0, 19, 19, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    3);

  /**
   * @generated
   */
  public static class UpdateEObjXContractDetailsParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      EObjXContractDetails bean0 = (EObjXContractDetails) parameters[0];
      setLong (stmt, 1, Types.BIGINT, (Long)bean0.getContId());
      setString (stmt, 2, Types.VARCHAR, (String)bean0.getFinanceProduct());
      setString (stmt, 3, Types.VARCHAR, (String)bean0.getContractNumber());
      setLong (stmt, 4, Types.BIGINT, (Long)bean0.getContractStatus());
      setString (stmt, 5, Types.VARCHAR, (String)bean0.getMarketName());
      setString (stmt, 6, Types.VARCHAR, (String)bean0.getFinancialProductGroup());
      setString (stmt, 7, Types.VARCHAR, (String)bean0.getAddressLineOne());
      setString (stmt, 8, Types.VARCHAR, (String)bean0.getAddressLineTwo());
      setString (stmt, 9, Types.VARCHAR, (String)bean0.getAddressLineThree());
      setString (stmt, 10, Types.VARCHAR, (String)bean0.getPostalCode());
      setString (stmt, 11, Types.VARCHAR, (String)bean0.getCityName());
      setString (stmt, 12, Types.VARCHAR, (String)bean0.getResidenceNumber());
      setLong (stmt, 13, Types.BIGINT, (Long)bean0.getCountry());
      setString (stmt, 14, Types.VARCHAR, (String)bean0.getBuildingName());
      setString (stmt, 15, Types.VARCHAR, (String)bean0.getStreetName());
      setString (stmt, 16, Types.VARCHAR, (String)bean0.getStreetNumber());
      setLong (stmt, 17, Types.BIGINT, (Long)bean0.getSourceIdentifier());
      setTimestamp (stmt, 18, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getStartDate());
      setTimestamp (stmt, 19, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getEndDate());
      setTimestamp (stmt, 20, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastModifiedSystemDate());
      setInteger (stmt, 21, Types.INTEGER, (Integer)bean0.getODDays());
      setTimestamp (stmt, 22, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUpdateDt());
      setString (stmt, 23, Types.VARCHAR, (String)bean0.getLastUpdateUser());
      setLong (stmt, 24, Types.BIGINT, (Long)bean0.getLastUpdateTxId());
      setLong (stmt, 25, Types.BIGINT, (Long)bean0.getContractpkId());
      setTimestamp (stmt, 26, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getOldLastUpdateDt());
    }
  }

  /**
   * @Update( sql="delete from XCONTRACT where CONTRACTPK_ID = ?" )
   * 
   * @generated
   */
  public int deleteEObjXContractDetails (Long contractpkId)
  {
    return update (deleteEObjXContractDetailsStatementDescriptor, contractpkId);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor deleteEObjXContractDetailsStatementDescriptor = createStatementDescriptor (
    "deleteEObjXContractDetails(Long)",
    "delete from XCONTRACT where CONTRACTPK_ID = ?",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.DELETE,
    null,
    new DeleteEObjXContractDetailsParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    4);

  /**
   * @generated
   */
  public static class DeleteEObjXContractDetailsParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setLong (stmt, 1, Types.BIGINT, (Long)parameters[0]);
    }
  }

}
