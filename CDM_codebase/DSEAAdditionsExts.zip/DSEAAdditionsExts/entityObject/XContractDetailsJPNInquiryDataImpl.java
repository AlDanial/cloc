package com.ibm.daimler.dsea.entityObject;

import com.ibm.pdq.runtime.generator.BaseParameterHandler;
import java.util.Iterator;
import com.ibm.mdm.base.db.ResultQueue1;
import java.sql.PreparedStatement;
import com.ibm.pdq.runtime.statement.StatementDescriptor;
import com.ibm.pdq.runtime.generator.BaseData;
import com.ibm.daimler.dsea.entityObject.EObjXContractDetailsJPN;
import java.sql.SQLException;
import com.ibm.pdq.annotation.Metadata;
import com.ibm.pdq.runtime.generator.BaseRowHandler;
import com.ibm.pdq.runtime.statement.SqlStatementType;
import java.sql.Types;


@SuppressWarnings("unchecked")

/**
 * <!-- begin-user-doc -->
 * 
 * <!-- end-user-doc -->
 * 
 * @generated
 */
public class XContractDetailsJPNInquiryDataImpl  extends BaseData implements XContractDetailsJPNInquiryData
{

  /**
   * @generated
   */
  public static final String generatorVersion = "3.200.75";

  /**
   * @generated
   */
  public static final String identifier = "XContractDetailsJPNInquiryData";

  /**
   * @generated
   */
  public static final long generationTime = 0x0000016676bff205L;

  /**
   * @generated
   */
  public static final String collection = "NULLID";

  /**
   * @generated
   */
  public static final String packageVersion = null;

  /**
   * @generated
   */
  public static final boolean forceSingleBindIsolation = false;

  /**
   * @generated
   */
  public XContractDetailsJPNInquiryDataImpl()
  {
    super();
  } 

  /**
   * @generated
   */
  public String getGeneratorVersion()
  {
    return generatorVersion;
  }

  /**
   * @Select( sql="SELECT r.XContract_JPNPK_ID XContract_JPNPK_ID, r.CONT_ID CONT_ID, r.FINANCE_PRODUCT FINANCE_PRODUCT, r.CONTRACT_NUMBER CONTRACT_NUMBER, r.CONTRACT_ST_TP_CD CONTRACT_ST_TP_CD, r.MARKET_NAME MARKET_NAME, r.GLOBAL_VIN GLOBAL_VIN, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.START_DT START_DT, r.END_DT END_DT, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.SFDC_ID SFDC_ID, r.BATCH_IND BATCH_IND, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XCONTRACTDETAILSJPN r WHERE r.XContract_JPNPK_ID = ? ", pattern="tableAlias (XCONTRACTDETAILSJPN => com.ibm.daimler.dsea.entityObject.EObjXContractDetailsJPN, H_XCONTRACTDETAILSJPN => com.ibm.daimler.dsea.entityObject.EObjXContractDetailsJPN)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue1<EObjXContractDetailsJPN>> getXContractDetailsJPN (Object[] parameters)
  {
    return queryIterator (getXContractDetailsJPNStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getXContractDetailsJPNStatementDescriptor = createStatementDescriptor (
    "getXContractDetailsJPN(Object[])",
    "SELECT r.XContract_JPNPK_ID XContract_JPNPK_ID, r.CONT_ID CONT_ID, r.FINANCE_PRODUCT FINANCE_PRODUCT, r.CONTRACT_NUMBER CONTRACT_NUMBER, r.CONTRACT_ST_TP_CD CONTRACT_ST_TP_CD, r.MARKET_NAME MARKET_NAME, r.GLOBAL_VIN GLOBAL_VIN, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.START_DT START_DT, r.END_DT END_DT, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.SFDC_ID SFDC_ID, r.BATCH_IND BATCH_IND, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XCONTRACTDETAILSJPN r WHERE r.XContract_JPNPK_ID = ? ",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"xcontract_jpnpk_id", "cont_id", "finance_product", "contract_number", "contract_st_tp_cd", "market_name", "global_vin", "source_ident_tp_cd", "start_dt", "end_dt", "modify_sys_dt", "sfdc_id", "batch_ind", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetXContractDetailsJPNParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetXContractDetailsJPNRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 19, 255, 250, 19, 50, 50, 19, 0, 0, 0, 50, 5, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    1);

  /**
   * @generated
   */
  public static class GetXContractDetailsJPNParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetXContractDetailsJPNRowHandler extends BaseRowHandler<ResultQueue1<EObjXContractDetailsJPN>>
  {
    /**
     * @generated
     */
    public ResultQueue1<EObjXContractDetailsJPN> handle (java.sql.ResultSet rs, ResultQueue1<EObjXContractDetailsJPN> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue1<EObjXContractDetailsJPN> ();

      EObjXContractDetailsJPN returnObject1 = new EObjXContractDetailsJPN ();
      returnObject1.setXContractJPNpkId(getLongObject (rs, 1)); 
      returnObject1.setContId(getLongObject (rs, 2)); 
      returnObject1.setFinanceProduct(getString (rs, 3)); 
      returnObject1.setContractNumber(getString (rs, 4)); 
      returnObject1.setContractStatus(getLongObject (rs, 5)); 
      returnObject1.setMarketName(getString (rs, 6)); 
      returnObject1.setGlobalVIN(getString (rs, 7)); 
      returnObject1.setSourceIdentifier(getLongObject (rs, 8)); 
      returnObject1.setStartDate(getTimestamp (rs, 9)); 
      returnObject1.setEndDate(getTimestamp (rs, 10)); 
      returnObject1.setLastModifiedSystemDate(getTimestamp (rs, 11)); 
      returnObject1.setSFDCId(getString (rs, 12)); 
      returnObject1.setBatchInd(getString (rs, 13)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 14)); 
      returnObject1.setLastUpdateUser(getString (rs, 15)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 16)); 
      returnObject.add (returnObject1);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT r.H_XContract_JPNPK_ID hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.XContract_JPNPK_ID XContract_JPNPK_ID, r.CONT_ID CONT_ID, r.FINANCE_PRODUCT FINANCE_PRODUCT, r.CONTRACT_NUMBER CONTRACT_NUMBER, r.CONTRACT_ST_TP_CD CONTRACT_ST_TP_CD, r.MARKET_NAME MARKET_NAME, r.GLOBAL_VIN GLOBAL_VIN, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.START_DT START_DT, r.END_DT END_DT, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.SFDC_ID SFDC_ID, r.BATCH_IND BATCH_IND, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XCONTRACTDETAILSJPN r WHERE r.H_XContract_JPNPK_ID = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))", pattern="tableAlias (XCONTRACTDETAILSJPN => com.ibm.daimler.dsea.entityObject.EObjXContractDetailsJPN, H_XCONTRACTDETAILSJPN => com.ibm.daimler.dsea.entityObject.EObjXContractDetailsJPN)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue1<EObjXContractDetailsJPN>> getXContractDetailsJPNHistory (Object[] parameters)
  {
    return queryIterator (getXContractDetailsJPNHistoryStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getXContractDetailsJPNHistoryStatementDescriptor = createStatementDescriptor (
    "getXContractDetailsJPNHistory(Object[])",
    "SELECT r.H_XContract_JPNPK_ID hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.XContract_JPNPK_ID XContract_JPNPK_ID, r.CONT_ID CONT_ID, r.FINANCE_PRODUCT FINANCE_PRODUCT, r.CONTRACT_NUMBER CONTRACT_NUMBER, r.CONTRACT_ST_TP_CD CONTRACT_ST_TP_CD, r.MARKET_NAME MARKET_NAME, r.GLOBAL_VIN GLOBAL_VIN, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.START_DT START_DT, r.END_DT END_DT, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.SFDC_ID SFDC_ID, r.BATCH_IND BATCH_IND, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XCONTRACTDETAILSJPN r WHERE r.H_XContract_JPNPK_ID = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"historyidpk", "h_action_code", "h_created_by", "h_create_dt", "h_end_dt", "xcontract_jpnpk_id", "cont_id", "finance_product", "contract_number", "contract_st_tp_cd", "market_name", "global_vin", "source_ident_tp_cd", "start_dt", "end_dt", "modify_sys_dt", "sfdc_id", "batch_ind", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetXContractDetailsJPNHistoryParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP}, {19, 0, 0}, {0, 0, 0}, {1, 1, 1}},
    null,
    new GetXContractDetailsJPNHistoryRowHandler (),
    new int[][]{ {Types.BIGINT, Types.CHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 1, 20, 0, 0, 19, 19, 255, 250, 19, 50, 50, 19, 0, 0, 0, 50, 5, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    2);

  /**
   * @generated
   */
  public static class GetXContractDetailsJPNHistoryParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetXContractDetailsJPNHistoryRowHandler extends BaseRowHandler<ResultQueue1<EObjXContractDetailsJPN>>
  {
    /**
     * @generated
     */
    public ResultQueue1<EObjXContractDetailsJPN> handle (java.sql.ResultSet rs, ResultQueue1<EObjXContractDetailsJPN> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue1<EObjXContractDetailsJPN> ();

      EObjXContractDetailsJPN returnObject1 = new EObjXContractDetailsJPN ();
      returnObject1.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject1.setHistActionCode(getString (rs, 2)); 
      returnObject1.setHistCreatedBy(getString (rs, 3)); 
      returnObject1.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject1.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject1.setXContractJPNpkId(getLongObject (rs, 6)); 
      returnObject1.setContId(getLongObject (rs, 7)); 
      returnObject1.setFinanceProduct(getString (rs, 8)); 
      returnObject1.setContractNumber(getString (rs, 9)); 
      returnObject1.setContractStatus(getLongObject (rs, 10)); 
      returnObject1.setMarketName(getString (rs, 11)); 
      returnObject1.setGlobalVIN(getString (rs, 12)); 
      returnObject1.setSourceIdentifier(getLongObject (rs, 13)); 
      returnObject1.setStartDate(getTimestamp (rs, 14)); 
      returnObject1.setEndDate(getTimestamp (rs, 15)); 
      returnObject1.setLastModifiedSystemDate(getTimestamp (rs, 16)); 
      returnObject1.setSFDCId(getString (rs, 17)); 
      returnObject1.setBatchInd(getString (rs, 18)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 19)); 
      returnObject1.setLastUpdateUser(getString (rs, 20)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 21)); 
      returnObject.add (returnObject1);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT r.XContract_JPNPK_ID XContract_JPNPK_ID, r.CONT_ID CONT_ID, r.FINANCE_PRODUCT FINANCE_PRODUCT, r.CONTRACT_NUMBER CONTRACT_NUMBER, r.CONTRACT_ST_TP_CD CONTRACT_ST_TP_CD, r.MARKET_NAME MARKET_NAME, r.GLOBAL_VIN GLOBAL_VIN, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.START_DT START_DT, r.END_DT END_DT, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.SFDC_ID SFDC_ID, r.BATCH_IND BATCH_IND, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XCONTRACTDETAILSJPN r WHERE r.CONT_ID = ? ", pattern="tableAlias (XCONTRACTDETAILSJPN => com.ibm.daimler.dsea.entityObject.EObjXContractDetailsJPN, H_XCONTRACTDETAILSJPN => com.ibm.daimler.dsea.entityObject.EObjXContractDetailsJPN)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue1<EObjXContractDetailsJPN>> getAllXContractDetailsJPNByPartyId (Object[] parameters)
  {
    return queryIterator (getAllXContractDetailsJPNByPartyIdStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getAllXContractDetailsJPNByPartyIdStatementDescriptor = createStatementDescriptor (
    "getAllXContractDetailsJPNByPartyId(Object[])",
    "SELECT r.XContract_JPNPK_ID XContract_JPNPK_ID, r.CONT_ID CONT_ID, r.FINANCE_PRODUCT FINANCE_PRODUCT, r.CONTRACT_NUMBER CONTRACT_NUMBER, r.CONTRACT_ST_TP_CD CONTRACT_ST_TP_CD, r.MARKET_NAME MARKET_NAME, r.GLOBAL_VIN GLOBAL_VIN, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.START_DT START_DT, r.END_DT END_DT, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.SFDC_ID SFDC_ID, r.BATCH_IND BATCH_IND, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XCONTRACTDETAILSJPN r WHERE r.CONT_ID = ? ",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"xcontract_jpnpk_id", "cont_id", "finance_product", "contract_number", "contract_st_tp_cd", "market_name", "global_vin", "source_ident_tp_cd", "start_dt", "end_dt", "modify_sys_dt", "sfdc_id", "batch_ind", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetAllXContractDetailsJPNByPartyIdParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetAllXContractDetailsJPNByPartyIdRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 19, 255, 250, 19, 50, 50, 19, 0, 0, 0, 50, 5, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    3);

  /**
   * @generated
   */
  public static class GetAllXContractDetailsJPNByPartyIdParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetAllXContractDetailsJPNByPartyIdRowHandler extends BaseRowHandler<ResultQueue1<EObjXContractDetailsJPN>>
  {
    /**
     * @generated
     */
    public ResultQueue1<EObjXContractDetailsJPN> handle (java.sql.ResultSet rs, ResultQueue1<EObjXContractDetailsJPN> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue1<EObjXContractDetailsJPN> ();

      EObjXContractDetailsJPN returnObject1 = new EObjXContractDetailsJPN ();
      returnObject1.setXContractJPNpkId(getLongObject (rs, 1)); 
      returnObject1.setContId(getLongObject (rs, 2)); 
      returnObject1.setFinanceProduct(getString (rs, 3)); 
      returnObject1.setContractNumber(getString (rs, 4)); 
      returnObject1.setContractStatus(getLongObject (rs, 5)); 
      returnObject1.setMarketName(getString (rs, 6)); 
      returnObject1.setGlobalVIN(getString (rs, 7)); 
      returnObject1.setSourceIdentifier(getLongObject (rs, 8)); 
      returnObject1.setStartDate(getTimestamp (rs, 9)); 
      returnObject1.setEndDate(getTimestamp (rs, 10)); 
      returnObject1.setLastModifiedSystemDate(getTimestamp (rs, 11)); 
      returnObject1.setSFDCId(getString (rs, 12)); 
      returnObject1.setBatchInd(getString (rs, 13)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 14)); 
      returnObject1.setLastUpdateUser(getString (rs, 15)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 16)); 
      returnObject.add (returnObject1);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT r.H_XContract_JPNPK_ID hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.XContract_JPNPK_ID XContract_JPNPK_ID, r.CONT_ID CONT_ID, r.FINANCE_PRODUCT FINANCE_PRODUCT, r.CONTRACT_NUMBER CONTRACT_NUMBER, r.CONTRACT_ST_TP_CD CONTRACT_ST_TP_CD, r.MARKET_NAME MARKET_NAME, r.GLOBAL_VIN GLOBAL_VIN, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.START_DT START_DT, r.END_DT END_DT, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.SFDC_ID SFDC_ID, r.BATCH_IND BATCH_IND, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XCONTRACTDETAILSJPN r WHERE r.CONT_ID = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))", pattern="tableAlias (XCONTRACTDETAILSJPN => com.ibm.daimler.dsea.entityObject.EObjXContractDetailsJPN, H_XCONTRACTDETAILSJPN => com.ibm.daimler.dsea.entityObject.EObjXContractDetailsJPN)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue1<EObjXContractDetailsJPN>> getAllXContractDetailsJPNByPartyIdHistory (Object[] parameters)
  {
    return queryIterator (getAllXContractDetailsJPNByPartyIdHistoryStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getAllXContractDetailsJPNByPartyIdHistoryStatementDescriptor = createStatementDescriptor (
    "getAllXContractDetailsJPNByPartyIdHistory(Object[])",
    "SELECT r.H_XContract_JPNPK_ID hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.XContract_JPNPK_ID XContract_JPNPK_ID, r.CONT_ID CONT_ID, r.FINANCE_PRODUCT FINANCE_PRODUCT, r.CONTRACT_NUMBER CONTRACT_NUMBER, r.CONTRACT_ST_TP_CD CONTRACT_ST_TP_CD, r.MARKET_NAME MARKET_NAME, r.GLOBAL_VIN GLOBAL_VIN, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.START_DT START_DT, r.END_DT END_DT, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.SFDC_ID SFDC_ID, r.BATCH_IND BATCH_IND, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XCONTRACTDETAILSJPN r WHERE r.CONT_ID = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"historyidpk", "h_action_code", "h_created_by", "h_create_dt", "h_end_dt", "xcontract_jpnpk_id", "cont_id", "finance_product", "contract_number", "contract_st_tp_cd", "market_name", "global_vin", "source_ident_tp_cd", "start_dt", "end_dt", "modify_sys_dt", "sfdc_id", "batch_ind", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetAllXContractDetailsJPNByPartyIdHistoryParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP}, {19, 0, 0}, {0, 0, 0}, {1, 1, 1}},
    null,
    new GetAllXContractDetailsJPNByPartyIdHistoryRowHandler (),
    new int[][]{ {Types.BIGINT, Types.CHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 1, 20, 0, 0, 19, 19, 255, 250, 19, 50, 50, 19, 0, 0, 0, 50, 5, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    4);

  /**
   * @generated
   */
  public static class GetAllXContractDetailsJPNByPartyIdHistoryParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetAllXContractDetailsJPNByPartyIdHistoryRowHandler extends BaseRowHandler<ResultQueue1<EObjXContractDetailsJPN>>
  {
    /**
     * @generated
     */
    public ResultQueue1<EObjXContractDetailsJPN> handle (java.sql.ResultSet rs, ResultQueue1<EObjXContractDetailsJPN> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue1<EObjXContractDetailsJPN> ();

      EObjXContractDetailsJPN returnObject1 = new EObjXContractDetailsJPN ();
      returnObject1.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject1.setHistActionCode(getString (rs, 2)); 
      returnObject1.setHistCreatedBy(getString (rs, 3)); 
      returnObject1.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject1.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject1.setXContractJPNpkId(getLongObject (rs, 6)); 
      returnObject1.setContId(getLongObject (rs, 7)); 
      returnObject1.setFinanceProduct(getString (rs, 8)); 
      returnObject1.setContractNumber(getString (rs, 9)); 
      returnObject1.setContractStatus(getLongObject (rs, 10)); 
      returnObject1.setMarketName(getString (rs, 11)); 
      returnObject1.setGlobalVIN(getString (rs, 12)); 
      returnObject1.setSourceIdentifier(getLongObject (rs, 13)); 
      returnObject1.setStartDate(getTimestamp (rs, 14)); 
      returnObject1.setEndDate(getTimestamp (rs, 15)); 
      returnObject1.setLastModifiedSystemDate(getTimestamp (rs, 16)); 
      returnObject1.setSFDCId(getString (rs, 17)); 
      returnObject1.setBatchInd(getString (rs, 18)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 19)); 
      returnObject1.setLastUpdateUser(getString (rs, 20)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 21)); 
      returnObject.add (returnObject1);

    
      return returnObject;
    }
  }

}
