package com.ibm.daimler.dsea.entityObject;

import com.ibm.pdq.runtime.generator.BaseParameterHandler;
import java.util.Iterator;
import java.sql.PreparedStatement;
import com.ibm.pdq.runtime.statement.StatementDescriptor;
import com.dwl.tcrm.coreParty.entityObject.EObjContactMethod;
import com.ibm.pdq.runtime.generator.BaseData;
import java.sql.SQLException;
import com.ibm.pdq.annotation.Metadata;
import com.ibm.pdq.runtime.generator.BaseRowHandler;
import com.ibm.pdq.runtime.statement.SqlStatementType;
import com.ibm.daimler.dsea.entityObject.EObjXContactMethodExt;
import java.sql.Types;


/**
 * <!-- begin-user-doc -->
 * 
 * <!-- end-user-doc -->
 * 
 * @generated
 */
public class EObjXContactMethodExtDataImpl  extends BaseData implements EObjXContactMethodExtData
{

  /**
   * @generated
   */
  public static final String generatorVersion = "3.200.75";

  /**
   * @generated
   */
  public static final String identifier = "EObjXContactMethodExtData";

  /**
   * @generated
   */
  public static final long generationTime = 0x00000161c413c2f6L;

  /**
   * @generated
   */
  public static final String collection = "NULLID";

  /**
   * @generated
   */
  public static final String packageVersion = null;

  /**
   * @generated
   */
  public static final boolean forceSingleBindIsolation = false;

  /**
   * @generated
   */
  public EObjXContactMethodExtDataImpl()
  {
    super();
  } 

  /**
   * @generated
   */
  public String getGeneratorVersion()
  {
    return generatorVersion;
  }

  /**
   * @Select( sql="select PHONE_EXTENSION, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from CONTACTMETHOD where CONTACT_METHOD_ID = ? " )
   * 
   * @generated
   */
  public Iterator<EObjXContactMethodExt> getEObjXContactMethodExt (Long contactMethodIdPK)
  {
    return queryIterator (getEObjXContactMethodExtStatementDescriptor, contactMethodIdPK);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getEObjXContactMethodExtStatementDescriptor = createStatementDescriptor (
    "getEObjXContactMethodExt(Long)",
    "select PHONE_EXTENSION, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from CONTACTMETHOD where CONTACT_METHOD_ID = ? ",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"phone_extension", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetEObjXContactMethodExtParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetEObjXContactMethodExtRowHandler (),
    new int[][]{ {Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {250, 0, 20, 19}, {0, 0, 0, 0}, {0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    1);

  /**
   * @generated
   */
  public static class GetEObjXContactMethodExtParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setLong (stmt, 1, Types.BIGINT, (Long)parameters[0]);
    }
  }

  /**
   * @generated
   */
  public static class GetEObjXContactMethodExtRowHandler extends BaseRowHandler<EObjXContactMethodExt>
  {
    /**
     * @generated
     */
    public EObjXContactMethodExt handle (java.sql.ResultSet rs, EObjXContactMethodExt returnObject) throws java.sql.SQLException
    {
      returnObject = new EObjXContactMethodExt ();
      returnObject.setPhoneExtension(getString (rs, 1)); 
      returnObject.setLastUpdateDt(getTimestamp (rs, 2)); 
      returnObject.setLastUpdateUser(getString (rs, 3)); 
      returnObject.setLastUpdateTxId(getLongObject (rs, 4)); 
    
      return returnObject;
    }
  }

  /**
   * @Update( sql="insert into CONTACTMETHOD (ADDRESS_ID, CONTACT_METHOD_ID, REF_NUM, CONT_METH_STD_IND, CONT_METH_CAT_CD, PHONE_EXTENSION, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( ?1.addressId, ?1.contactMethodIdPK, ?1.refNum, ?1.contMethStandardInd, ?1.contMethCatCd, ?2.phoneExtension, ?1.lastUpdateDt, ?1.lastUpdateUser, ?1.lastUpdateTxId)" )
   * 
   * @generated
   */
  public int createEObjXContactMethodExt (EObjContactMethod e1, EObjXContactMethodExt e2)
  {
    return update (createEObjXContactMethodExtStatementDescriptor, e1, e2);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor createEObjXContactMethodExtStatementDescriptor = createStatementDescriptor (
    "createEObjXContactMethodExt(com.dwl.tcrm.coreParty.entityObject.EObjContactMethod, com.ibm.daimler.dsea.entityObject.EObjXContactMethodExt)",
    "insert into CONTACTMETHOD (ADDRESS_ID, CONTACT_METHOD_ID, REF_NUM, CONT_METH_STD_IND, CONT_METH_CAT_CD, PHONE_EXTENSION, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values(  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? )",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.INSERT,
    null,
    new CreateEObjXContactMethodExtParameterHandler (),
    new int[][]{{Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.CHAR, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 19, 255, 1, 19, 250, 0, 0, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1, 1, 1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    2);

  /**
   * @generated
   */
  public static class CreateEObjXContactMethodExtParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      EObjContactMethod bean0 = (EObjContactMethod) parameters[0];
      setLong (stmt, 1, Types.BIGINT, (Long)bean0.getAddressId());
      setLong (stmt, 2, Types.BIGINT, (Long)bean0.getContactMethodIdPK());
      setString (stmt, 3, Types.VARCHAR, (String)bean0.getRefNum());
      setString (stmt, 4, Types.CHAR, (String)bean0.getContMethStandardInd());
      setLong (stmt, 5, Types.BIGINT, (Long)bean0.getContMethCatCd());
      EObjXContactMethodExt bean1 = (EObjXContactMethodExt) parameters[1];
      setString (stmt, 6, Types.VARCHAR, (String)bean1.getPhoneExtension());
      setTimestamp (stmt, 7, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUpdateDt());
      setString (stmt, 8, Types.VARCHAR, (String)bean0.getLastUpdateUser());
      setLong (stmt, 9, Types.BIGINT, (Long)bean0.getLastUpdateTxId());
    }
  }

  /**
   * @Update( sql="update CONTACTMETHOD set ADDRESS_ID = ?1.addressId, REF_NUM = ?1.refNum, CONT_METH_STD_IND = ?1.contMethStandardInd, CONT_METH_CAT_CD = ?1.contMethCatCd, PHONE_EXTENSION = ?2.phoneExtension, LAST_UPDATE_DT = ?1.lastUpdateDt, LAST_UPDATE_USER = ?1.lastUpdateUser, LAST_UPDATE_TX_ID = ?1.lastUpdateTxId where CONTACT_METHOD_ID = ?1.contactMethodIdPK and LAST_UPDATE_DT = ?1.oldLastUpdateDt" )
   * 
   * @generated
   */
  public int updateEObjXContactMethodExt (EObjContactMethod e1, EObjXContactMethodExt e2)
  {
    return update (updateEObjXContactMethodExtStatementDescriptor, e1, e2);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor updateEObjXContactMethodExtStatementDescriptor = createStatementDescriptor (
    "updateEObjXContactMethodExt(com.dwl.tcrm.coreParty.entityObject.EObjContactMethod, com.ibm.daimler.dsea.entityObject.EObjXContactMethodExt)",
    "update CONTACTMETHOD set ADDRESS_ID =  ? , REF_NUM =  ? , CONT_METH_STD_IND =  ? , CONT_METH_CAT_CD =  ? , PHONE_EXTENSION =  ? , LAST_UPDATE_DT =  ? , LAST_UPDATE_USER =  ? , LAST_UPDATE_TX_ID =  ?  where CONTACT_METHOD_ID =  ?  and LAST_UPDATE_DT =  ? ",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.UPDATE,
    null,
    new UpdateEObjXContactMethodExtParameterHandler (),
    new int[][]{{Types.BIGINT, Types.VARCHAR, Types.CHAR, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP}, {19, 255, 1, 19, 250, 0, 0, 19, 19, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1, 1, 1, 1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    3);

  /**
   * @generated
   */
  public static class UpdateEObjXContactMethodExtParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      EObjContactMethod bean0 = (EObjContactMethod) parameters[0];
      setLong (stmt, 1, Types.BIGINT, (Long)bean0.getAddressId());
      setString (stmt, 2, Types.VARCHAR, (String)bean0.getRefNum());
      setString (stmt, 3, Types.CHAR, (String)bean0.getContMethStandardInd());
      setLong (stmt, 4, Types.BIGINT, (Long)bean0.getContMethCatCd());
      EObjXContactMethodExt bean1 = (EObjXContactMethodExt) parameters[1];
      setString (stmt, 5, Types.VARCHAR, (String)bean1.getPhoneExtension());
      setTimestamp (stmt, 6, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUpdateDt());
      setString (stmt, 7, Types.VARCHAR, (String)bean0.getLastUpdateUser());
      setLong (stmt, 8, Types.BIGINT, (Long)bean0.getLastUpdateTxId());
      setLong (stmt, 9, Types.BIGINT, (Long)bean0.getContactMethodIdPK());
      setTimestamp (stmt, 10, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getOldLastUpdateDt());
    }
  }

  /**
   * @Update( sql="delete from CONTACTMETHOD where CONTACT_METHOD_ID = ?" )
   * 
   * @generated
   */
  public int deleteEObjXContactMethodExt (Long contactMethodIdPK)
  {
    return update (deleteEObjXContactMethodExtStatementDescriptor, contactMethodIdPK);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor deleteEObjXContactMethodExtStatementDescriptor = createStatementDescriptor (
    "deleteEObjXContactMethodExt(Long)",
    "delete from CONTACTMETHOD where CONTACT_METHOD_ID = ?",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.DELETE,
    null,
    new DeleteEObjXContactMethodExtParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    4);

  /**
   * @generated
   */
  public static class DeleteEObjXContactMethodExtParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setLong (stmt, 1, Types.BIGINT, (Long)parameters[0]);
    }
  }

}
