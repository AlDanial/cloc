/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[ffce166151009cb33afb49818b4105f7]
 */

package com.ibm.daimler.dsea.entityObject;


import com.ibm.mdm.base.db.ResultQueue1;
import java.util.Iterator;
import com.ibm.mdm.base.db.EntityMapping;
import com.ibm.pdq.annotation.Select;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * @generated
 */
public interface XVehicleAddressInquiryData {
  
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String tableAliasString = "tableAlias (" + 
                                            "XVEHICLEADDRESS => com.ibm.daimler.dsea.entityObject.EObjXVehicleAddress, " +
                                            "H_XVEHICLEADDRESS => com.ibm.daimler.dsea.entityObject.EObjXVehicleAddress" +
                                            ")";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getXVehicleAddressSql = "SELECT r.VEHICLE_ADDRESSPK_ID VEHICLE_ADDRESSPK_ID, r.ADDRESS_USAGE_TYPE ADDRESS_USAGE_TYPE, r.PREFERRED_IND PREFERRED_IND, r.ADDRESS_LINE_ONE ADDRESS_LINE_ONE, r.ADDRESS_LINE_TWO ADDRESS_LINE_TWO, r.ADDRESS_LINE_THREE ADDRESS_LINE_THREE, r.CITY_NAME CITY_NAME, r.POSTAL_CODE POSTAL_CODE, r.RESIDENCE_NUM RESIDENCE_NUM, r.COUNTRY COUNTRY, r.PROVINCE_STATE PROVINCE_STATE, r.VEHICLE_ID VEHICLE_ID, r.CONT_ID CONT_ID, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.START_DT START_DT, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XVEHICLEADDRESS r WHERE r.VEHICLE_ADDRESSPK_ID = ? ";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXVehicleAddressParameters =
    "EObjXVehicleAddress.VehicleAddresspkId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXVehicleAddressResults =
    "EObjXVehicleAddress.VehicleAddresspkId," +
    "EObjXVehicleAddress.AddressUsageType," +
    "EObjXVehicleAddress.PreferredInd," +
    "EObjXVehicleAddress.AddressLineOne," +
    "EObjXVehicleAddress.AddressLineTwo," +
    "EObjXVehicleAddress.AddressLineThree," +
    "EObjXVehicleAddress.City," +
    "EObjXVehicleAddress.ZipPostalCode," +
    "EObjXVehicleAddress.ResidenceNumber," +
    "EObjXVehicleAddress.Country," +
    "EObjXVehicleAddress.ProvinceState," +
    "EObjXVehicleAddress.VehicleId," +
    "EObjXVehicleAddress.ContId," +
    "EObjXVehicleAddress.SourceIdentifier," +
    "EObjXVehicleAddress.StartDate," +
    "EObjXVehicleAddress.LastModifiedSystemDate," +
    "EObjXVehicleAddress.lastUpdateDt," +
    "EObjXVehicleAddress.lastUpdateUser," +
    "EObjXVehicleAddress.lastUpdateTxId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getXVehicleAddressHistorySql = "SELECT r.H_VEHICLE_ADDRESSPK_ID hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.VEHICLE_ADDRESSPK_ID VEHICLE_ADDRESSPK_ID, r.ADDRESS_USAGE_TYPE ADDRESS_USAGE_TYPE, r.PREFERRED_IND PREFERRED_IND, r.ADDRESS_LINE_ONE ADDRESS_LINE_ONE, r.ADDRESS_LINE_TWO ADDRESS_LINE_TWO, r.ADDRESS_LINE_THREE ADDRESS_LINE_THREE, r.CITY_NAME CITY_NAME, r.POSTAL_CODE POSTAL_CODE, r.RESIDENCE_NUM RESIDENCE_NUM, r.COUNTRY COUNTRY, r.PROVINCE_STATE PROVINCE_STATE, r.VEHICLE_ID VEHICLE_ID, r.CONT_ID CONT_ID, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.START_DT START_DT, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XVEHICLEADDRESS r WHERE r.H_VEHICLE_ADDRESSPK_ID = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXVehicleAddressHistoryParameters =
    "EObjXVehicleAddress.VehicleAddresspkId," +
    "EObjXVehicleAddress.lastUpdateDt," +
    "EObjXVehicleAddress.lastUpdateDt";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXVehicleAddressHistoryResults =
    "EObjXVehicleAddress.historyIdPK," +
    "EObjXVehicleAddress.histActionCode," +
    "EObjXVehicleAddress.histCreatedBy," +
    "EObjXVehicleAddress.histCreateDt," +
    "EObjXVehicleAddress.histEndDt," +
    "EObjXVehicleAddress.VehicleAddresspkId," +
    "EObjXVehicleAddress.AddressUsageType," +
    "EObjXVehicleAddress.PreferredInd," +
    "EObjXVehicleAddress.AddressLineOne," +
    "EObjXVehicleAddress.AddressLineTwo," +
    "EObjXVehicleAddress.AddressLineThree," +
    "EObjXVehicleAddress.City," +
    "EObjXVehicleAddress.ZipPostalCode," +
    "EObjXVehicleAddress.ResidenceNumber," +
    "EObjXVehicleAddress.Country," +
    "EObjXVehicleAddress.ProvinceState," +
    "EObjXVehicleAddress.VehicleId," +
    "EObjXVehicleAddress.ContId," +
    "EObjXVehicleAddress.SourceIdentifier," +
    "EObjXVehicleAddress.StartDate," +
    "EObjXVehicleAddress.LastModifiedSystemDate," +
    "EObjXVehicleAddress.lastUpdateDt," +
    "EObjXVehicleAddress.lastUpdateUser," +
    "EObjXVehicleAddress.lastUpdateTxId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getVehicleAddressByVehicleIdSql = "SELECT r.VEHICLE_ADDRESSPK_ID VEHICLE_ADDRESSPK_ID, r.ADDRESS_USAGE_TYPE ADDRESS_USAGE_TYPE, r.PREFERRED_IND PREFERRED_IND, r.ADDRESS_LINE_ONE ADDRESS_LINE_ONE, r.ADDRESS_LINE_TWO ADDRESS_LINE_TWO, r.ADDRESS_LINE_THREE ADDRESS_LINE_THREE, r.CITY_NAME CITY_NAME, r.POSTAL_CODE POSTAL_CODE, r.RESIDENCE_NUM RESIDENCE_NUM, r.COUNTRY COUNTRY, r.PROVINCE_STATE PROVINCE_STATE, r.VEHICLE_ID VEHICLE_ID, r.CONT_ID CONT_ID, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.START_DT START_DT, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XVEHICLEADDRESS r WHERE r.VEHICLE_ID = ? ";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getVehicleAddressByVehicleIdParameters =
    "EObjXVehicleAddress.VehicleId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getVehicleAddressByVehicleIdResults =
    "EObjXVehicleAddress.VehicleAddresspkId," +
    "EObjXVehicleAddress.AddressUsageType," +
    "EObjXVehicleAddress.PreferredInd," +
    "EObjXVehicleAddress.AddressLineOne," +
    "EObjXVehicleAddress.AddressLineTwo," +
    "EObjXVehicleAddress.AddressLineThree," +
    "EObjXVehicleAddress.City," +
    "EObjXVehicleAddress.ZipPostalCode," +
    "EObjXVehicleAddress.ResidenceNumber," +
    "EObjXVehicleAddress.Country," +
    "EObjXVehicleAddress.ProvinceState," +
    "EObjXVehicleAddress.VehicleId," +
    "EObjXVehicleAddress.ContId," +
    "EObjXVehicleAddress.SourceIdentifier," +
    "EObjXVehicleAddress.StartDate," +
    "EObjXVehicleAddress.LastModifiedSystemDate," +
    "EObjXVehicleAddress.lastUpdateDt," +
    "EObjXVehicleAddress.lastUpdateUser," +
    "EObjXVehicleAddress.lastUpdateTxId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getVehicleAddressByVehicleIdHistorySql = "SELECT r.H_VEHICLE_ADDRESSPK_ID hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.VEHICLE_ADDRESSPK_ID VEHICLE_ADDRESSPK_ID, r.ADDRESS_USAGE_TYPE ADDRESS_USAGE_TYPE, r.PREFERRED_IND PREFERRED_IND, r.ADDRESS_LINE_ONE ADDRESS_LINE_ONE, r.ADDRESS_LINE_TWO ADDRESS_LINE_TWO, r.ADDRESS_LINE_THREE ADDRESS_LINE_THREE, r.CITY_NAME CITY_NAME, r.POSTAL_CODE POSTAL_CODE, r.RESIDENCE_NUM RESIDENCE_NUM, r.COUNTRY COUNTRY, r.PROVINCE_STATE PROVINCE_STATE, r.VEHICLE_ID VEHICLE_ID, r.CONT_ID CONT_ID, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.START_DT START_DT, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XVEHICLEADDRESS r WHERE r.VEHICLE_ID = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getVehicleAddressByVehicleIdHistoryParameters =
    "EObjXVehicleAddress.VehicleId," +
    "EObjXVehicleAddress.lastUpdateDt," +
    "EObjXVehicleAddress.lastUpdateDt";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getVehicleAddressByVehicleIdHistoryResults =
    "EObjXVehicleAddress.historyIdPK," +
    "EObjXVehicleAddress.histActionCode," +
    "EObjXVehicleAddress.histCreatedBy," +
    "EObjXVehicleAddress.histCreateDt," +
    "EObjXVehicleAddress.histEndDt," +
    "EObjXVehicleAddress.VehicleAddresspkId," +
    "EObjXVehicleAddress.AddressUsageType," +
    "EObjXVehicleAddress.PreferredInd," +
    "EObjXVehicleAddress.AddressLineOne," +
    "EObjXVehicleAddress.AddressLineTwo," +
    "EObjXVehicleAddress.AddressLineThree," +
    "EObjXVehicleAddress.City," +
    "EObjXVehicleAddress.ZipPostalCode," +
    "EObjXVehicleAddress.ResidenceNumber," +
    "EObjXVehicleAddress.Country," +
    "EObjXVehicleAddress.ProvinceState," +
    "EObjXVehicleAddress.VehicleId," +
    "EObjXVehicleAddress.ContId," +
    "EObjXVehicleAddress.SourceIdentifier," +
    "EObjXVehicleAddress.StartDate," +
    "EObjXVehicleAddress.LastModifiedSystemDate," +
    "EObjXVehicleAddress.lastUpdateDt," +
    "EObjXVehicleAddress.lastUpdateUser," +
    "EObjXVehicleAddress.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getXVehicleAddressSql, pattern=tableAliasString)
  @EntityMapping(parameters=getXVehicleAddressParameters, results=getXVehicleAddressResults)
  Iterator<ResultQueue1<EObjXVehicleAddress>> getXVehicleAddress(Object[] parameters);  


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getXVehicleAddressHistorySql, pattern=tableAliasString)
  @EntityMapping(parameters=getXVehicleAddressHistoryParameters, results=getXVehicleAddressHistoryResults)
  Iterator<ResultQueue1<EObjXVehicleAddress>> getXVehicleAddressHistory(Object[] parameters);  


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getVehicleAddressByVehicleIdSql, pattern=tableAliasString)
  @EntityMapping(parameters=getVehicleAddressByVehicleIdParameters, results=getVehicleAddressByVehicleIdResults)
  Iterator<ResultQueue1<EObjXVehicleAddress>> getVehicleAddressByVehicleId(Object[] parameters);  


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getVehicleAddressByVehicleIdHistorySql, pattern=tableAliasString)
  @EntityMapping(parameters=getVehicleAddressByVehicleIdHistoryParameters, results=getVehicleAddressByVehicleIdHistoryResults)
  Iterator<ResultQueue1<EObjXVehicleAddress>> getVehicleAddressByVehicleIdHistory(Object[] parameters);  


}


