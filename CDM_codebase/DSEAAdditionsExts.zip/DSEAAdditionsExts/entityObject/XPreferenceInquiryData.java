/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[a8835e75bd9a0a921b19be7eca98cc71]
 */

package com.ibm.daimler.dsea.entityObject;


import com.ibm.mdm.base.db.ResultQueue1;
import java.util.Iterator;
import com.ibm.mdm.base.db.EntityMapping;
import com.ibm.pdq.annotation.Select;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * @generated
 */
public interface XPreferenceInquiryData {
  
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String tableAliasString = "tableAlias (" + 
                                            "XPREFERENCE => com.ibm.daimler.dsea.entityObject.EObjXPreference, " +
                                            "H_XPREFERENCE => com.ibm.daimler.dsea.entityObject.EObjXPreference" +
                                            ")";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getXPreferenceSql = "SELECT r.PREFERENCEPK_ID PREFERENCEPK_ID, r.LOCATION_GROUP_ID LOCATION_GROUP_ID, r.PREFERENCE_TP_CD PREFERENCE_TP_CD, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.START_DT START_DT, r.END_DT END_DT, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XPREFERENCE r WHERE r.PREFERENCEPK_ID = ? ";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXPreferenceParameters =
    "EObjXPreference.PreferencepkId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXPreferenceResults =
    "EObjXPreference.PreferencepkId," +
    "EObjXPreference.LocationGroupId," +
    "EObjXPreference.Preferred," +
    "EObjXPreference.SourceIdentifier," +
    "EObjXPreference.StartDate," +
    "EObjXPreference.EndDate," +
    "EObjXPreference.LastModifiedSystemDate," +
    "EObjXPreference.lastUpdateDt," +
    "EObjXPreference.lastUpdateUser," +
    "EObjXPreference.lastUpdateTxId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getXPreferenceHistorySql = "SELECT r.H_PREFERENCEPK_ID hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.PREFERENCEPK_ID PREFERENCEPK_ID, r.LOCATION_GROUP_ID LOCATION_GROUP_ID, r.PREFERENCE_TP_CD PREFERENCE_TP_CD, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.START_DT START_DT, r.END_DT END_DT, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XPREFERENCE r WHERE r.H_PREFERENCEPK_ID = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXPreferenceHistoryParameters =
    "EObjXPreference.PreferencepkId," +
    "EObjXPreference.lastUpdateDt," +
    "EObjXPreference.lastUpdateDt";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXPreferenceHistoryResults =
    "EObjXPreference.historyIdPK," +
    "EObjXPreference.histActionCode," +
    "EObjXPreference.histCreatedBy," +
    "EObjXPreference.histCreateDt," +
    "EObjXPreference.histEndDt," +
    "EObjXPreference.PreferencepkId," +
    "EObjXPreference.LocationGroupId," +
    "EObjXPreference.Preferred," +
    "EObjXPreference.SourceIdentifier," +
    "EObjXPreference.StartDate," +
    "EObjXPreference.EndDate," +
    "EObjXPreference.LastModifiedSystemDate," +
    "EObjXPreference.lastUpdateDt," +
    "EObjXPreference.lastUpdateUser," +
    "EObjXPreference.lastUpdateTxId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getXPreferenceByLocationGroupIdSql = "SELECT r.PREFERENCEPK_ID PREFERENCEPK_ID, r.LOCATION_GROUP_ID LOCATION_GROUP_ID, r.PREFERENCE_TP_CD PREFERENCE_TP_CD, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.START_DT START_DT, r.END_DT END_DT, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XPREFERENCE r WHERE r.LOCATION_GROUP_ID = ? ";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXPreferenceByLocationGroupIdParameters =
    "EObjXPreference.LocationGroupId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXPreferenceByLocationGroupIdResults =
    "EObjXPreference.PreferencepkId," +
    "EObjXPreference.LocationGroupId," +
    "EObjXPreference.Preferred," +
    "EObjXPreference.SourceIdentifier," +
    "EObjXPreference.StartDate," +
    "EObjXPreference.EndDate," +
    "EObjXPreference.LastModifiedSystemDate," +
    "EObjXPreference.lastUpdateDt," +
    "EObjXPreference.lastUpdateUser," +
    "EObjXPreference.lastUpdateTxId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getXPreferenceByLocationGroupIdHistorySql = "SELECT r.H_PREFERENCEPK_ID hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.PREFERENCEPK_ID PREFERENCEPK_ID, r.LOCATION_GROUP_ID LOCATION_GROUP_ID, r.PREFERENCE_TP_CD PREFERENCE_TP_CD, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.START_DT START_DT, r.END_DT END_DT, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XPREFERENCE r WHERE r.LOCATION_GROUP_ID = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXPreferenceByLocationGroupIdHistoryParameters =
    "EObjXPreference.LocationGroupId," +
    "EObjXPreference.lastUpdateDt," +
    "EObjXPreference.lastUpdateDt";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXPreferenceByLocationGroupIdHistoryResults =
    "EObjXPreference.historyIdPK," +
    "EObjXPreference.histActionCode," +
    "EObjXPreference.histCreatedBy," +
    "EObjXPreference.histCreateDt," +
    "EObjXPreference.histEndDt," +
    "EObjXPreference.PreferencepkId," +
    "EObjXPreference.LocationGroupId," +
    "EObjXPreference.Preferred," +
    "EObjXPreference.SourceIdentifier," +
    "EObjXPreference.StartDate," +
    "EObjXPreference.EndDate," +
    "EObjXPreference.LastModifiedSystemDate," +
    "EObjXPreference.lastUpdateDt," +
    "EObjXPreference.lastUpdateUser," +
    "EObjXPreference.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getXPreferenceSql, pattern=tableAliasString)
  @EntityMapping(parameters=getXPreferenceParameters, results=getXPreferenceResults)
  Iterator<ResultQueue1<EObjXPreference>> getXPreference(Object[] parameters);  


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getXPreferenceHistorySql, pattern=tableAliasString)
  @EntityMapping(parameters=getXPreferenceHistoryParameters, results=getXPreferenceHistoryResults)
  Iterator<ResultQueue1<EObjXPreference>> getXPreferenceHistory(Object[] parameters);  


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getXPreferenceByLocationGroupIdSql, pattern=tableAliasString)
  @EntityMapping(parameters=getXPreferenceByLocationGroupIdParameters, results=getXPreferenceByLocationGroupIdResults)
  Iterator<ResultQueue1<EObjXPreference>> getXPreferenceByLocationGroupId(Object[] parameters);  


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getXPreferenceByLocationGroupIdHistorySql, pattern=tableAliasString)
  @EntityMapping(parameters=getXPreferenceByLocationGroupIdHistoryParameters, results=getXPreferenceByLocationGroupIdHistoryResults)
  Iterator<ResultQueue1<EObjXPreference>> getXPreferenceByLocationGroupIdHistory(Object[] parameters);  


}


