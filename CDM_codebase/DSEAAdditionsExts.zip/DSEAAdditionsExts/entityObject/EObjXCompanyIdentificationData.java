/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[d509a6fa0dfb59a25b29edba2ece3804]
 */


package com.ibm.daimler.dsea.entityObject;

import java.util.Iterator;
import com.ibm.mdm.base.db.EntityMapping;
import com.ibm.pdq.annotation.Select;
import com.ibm.pdq.annotation.Update;

import com.ibm.daimler.dsea.entityObject.EObjXCompanyIdentification;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * @generated
 */
public interface EObjXCompanyIdentificationData {


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjXCompanyIdentificationSql = "select COMPANYIDENTIFICATIONPK_ID, COMPANYMAGIC_NUMBER, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from XCOMPANYIDENTIFICATION where COMPANYIDENTIFICATIONPK_ID = ? ";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String createEObjXCompanyIdentificationSql = "insert into XCOMPANYIDENTIFICATION (COMPANYIDENTIFICATIONPK_ID, COMPANYMAGIC_NUMBER, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( :companyIdentificationpkId, :companyMagicNumber, :lastUpdateDt, :lastUpdateUser, :lastUpdateTxId)";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String updateEObjXCompanyIdentificationSql = "update XCOMPANYIDENTIFICATION set COMPANYMAGIC_NUMBER = :companyMagicNumber, LAST_UPDATE_DT = :lastUpdateDt, LAST_UPDATE_USER = :lastUpdateUser, LAST_UPDATE_TX_ID = :lastUpdateTxId where COMPANYIDENTIFICATIONPK_ID = :companyIdentificationpkId and LAST_UPDATE_DT = :oldLastUpdateDt";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String deleteEObjXCompanyIdentificationSql = "delete from XCOMPANYIDENTIFICATION where COMPANYIDENTIFICATIONPK_ID = ?";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXCompanyIdentificationKeyField = "EObjXCompanyIdentification.companyIdentificationpkId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXCompanyIdentificationGetFields =
    "EObjXCompanyIdentification.companyIdentificationpkId," +
    "EObjXCompanyIdentification.companyMagicNumber," +
    "EObjXCompanyIdentification.lastUpdateDt," +
    "EObjXCompanyIdentification.lastUpdateUser," +
    "EObjXCompanyIdentification.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXCompanyIdentificationAllFields =
    "com.ibm.daimler.dsea.entityObject.EObjXCompanyIdentification.companyIdentificationpkId," +
    "com.ibm.daimler.dsea.entityObject.EObjXCompanyIdentification.companyMagicNumber," +
    "com.ibm.daimler.dsea.entityObject.EObjXCompanyIdentification.lastUpdateDt," +
    "com.ibm.daimler.dsea.entityObject.EObjXCompanyIdentification.lastUpdateUser," +
    "com.ibm.daimler.dsea.entityObject.EObjXCompanyIdentification.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXCompanyIdentificationUpdateFields =
    "com.ibm.daimler.dsea.entityObject.EObjXCompanyIdentification.companyMagicNumber," +
    "com.ibm.daimler.dsea.entityObject.EObjXCompanyIdentification.lastUpdateDt," +
    "com.ibm.daimler.dsea.entityObject.EObjXCompanyIdentification.lastUpdateUser," +
    "com.ibm.daimler.dsea.entityObject.EObjXCompanyIdentification.lastUpdateTxId," +
    "com.ibm.daimler.dsea.entityObject.EObjXCompanyIdentification.companyIdentificationpkId," +
    "com.ibm.daimler.dsea.entityObject.EObjXCompanyIdentification.oldLastUpdateDt";   

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Select XCompanyIdentification by parameters.
   * @generated
   */
  @Select(sql=getEObjXCompanyIdentificationSql)
  @EntityMapping(parameters=EObjXCompanyIdentificationKeyField, results=EObjXCompanyIdentificationGetFields)
  Iterator<EObjXCompanyIdentification> getEObjXCompanyIdentification(Long companyIdentificationpkId);  
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Create XCompanyIdentification by EObjXCompanyIdentification Object.
   * @generated
   */
  @Update(sql=createEObjXCompanyIdentificationSql)
  @EntityMapping(parameters=EObjXCompanyIdentificationAllFields)
    int createEObjXCompanyIdentification(EObjXCompanyIdentification e); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Update one XCompanyIdentification by EObjXCompanyIdentification object.
   * @generated
   */
  @Update(sql=updateEObjXCompanyIdentificationSql)
  @EntityMapping(parameters=EObjXCompanyIdentificationUpdateFields)
    int updateEObjXCompanyIdentification(EObjXCompanyIdentification e); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Delete XCompanyIdentification by parameters.
   * @generated
   */
  @Update(sql=deleteEObjXCompanyIdentificationSql)
  @EntityMapping(parameters=EObjXCompanyIdentificationKeyField)
  int deleteEObjXCompanyIdentification(Long companyIdentificationpkId);

}

