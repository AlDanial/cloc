/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[54991e5e83c73fd37a86b77d7095a216]
 */


package com.ibm.daimler.dsea.entityObject;

import java.util.Iterator;
import com.ibm.mdm.base.db.EntityMapping;
import com.ibm.pdq.annotation.Select;
import com.ibm.pdq.annotation.Update;

import com.ibm.daimler.dsea.entityObject.EObjXRetailerJPN;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * @generated
 */
public interface EObjXRetailerJPNData {


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjXRetailerJPNSql = "select XRETAILERJPNPK_ID, RETAILER_CODE, RETAILER_NAME, BRANCH_NAME, SOURCE_IDENT_TP_CD, GS_CODE, GC_CODE, MODIFY_SYS_DT, ND_CODE, MARKET_NAME, DEALER_ACTIVE_FLAG, Dealer_Group, DEALER_ROLLOUT_FLAG, BATCH_IND, CREATE_DT, CHANGED_DT, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from XRETAILERJPN where XRETAILERJPNPK_ID = ? ";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String createEObjXRetailerJPNSql = "insert into XRETAILERJPN (XRETAILERJPNPK_ID, RETAILER_CODE, RETAILER_NAME, BRANCH_NAME, SOURCE_IDENT_TP_CD, GS_CODE, GC_CODE, MODIFY_SYS_DT, ND_CODE, MARKET_NAME, DEALER_ACTIVE_FLAG, Dealer_Group, DEALER_ROLLOUT_FLAG, BATCH_IND, CREATE_DT, CHANGED_DT, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( :xRetailerJPNpkId, :retailerCode, :retailerName, :branchName, :sourceIdentifier, :gSCode, :gCCode, :lastModifiedSystemDate, :nDCode, :marketName, :dealerActiveFlag, :dealerGroup, :dealerRolloutFlag, :batchInd, :createDate, :changedDate, :lastUpdateDt, :lastUpdateUser, :lastUpdateTxId)";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String updateEObjXRetailerJPNSql = "update XRETAILERJPN set RETAILER_CODE = :retailerCode, RETAILER_NAME = :retailerName, BRANCH_NAME = :branchName, SOURCE_IDENT_TP_CD = :sourceIdentifier, GS_CODE = :gSCode, GC_CODE = :gCCode, MODIFY_SYS_DT = :lastModifiedSystemDate, ND_CODE = :nDCode, MARKET_NAME = :marketName, DEALER_ACTIVE_FLAG = :dealerActiveFlag, Dealer_Group = :dealerGroup, DEALER_ROLLOUT_FLAG = :dealerRolloutFlag, BATCH_IND = :batchInd, CREATE_DT = :createDate, CHANGED_DT = :changedDate, LAST_UPDATE_DT = :lastUpdateDt, LAST_UPDATE_USER = :lastUpdateUser, LAST_UPDATE_TX_ID = :lastUpdateTxId where XRETAILERJPNPK_ID = :xRetailerJPNpkId and LAST_UPDATE_DT = :oldLastUpdateDt";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String deleteEObjXRetailerJPNSql = "delete from XRETAILERJPN where XRETAILERJPNPK_ID = ?";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXRetailerJPNKeyField = "EObjXRetailerJPN.xRetailerJPNpkId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXRetailerJPNGetFields =
    "EObjXRetailerJPN.xRetailerJPNpkId," +
    "EObjXRetailerJPN.retailerCode," +
    "EObjXRetailerJPN.retailerName," +
    "EObjXRetailerJPN.branchName," +
    "EObjXRetailerJPN.sourceIdentifier," +
    "EObjXRetailerJPN.gSCode," +
    "EObjXRetailerJPN.gCCode," +
    "EObjXRetailerJPN.lastModifiedSystemDate," +
    "EObjXRetailerJPN.nDCode," +
    "EObjXRetailerJPN.marketName," +
    "EObjXRetailerJPN.dealerActiveFlag," +
    "EObjXRetailerJPN.dealerGroup," +
    "EObjXRetailerJPN.dealerRolloutFlag," +
    "EObjXRetailerJPN.batchInd," +
    "EObjXRetailerJPN.createDate," +
    "EObjXRetailerJPN.changedDate," +
    "EObjXRetailerJPN.lastUpdateDt," +
    "EObjXRetailerJPN.lastUpdateUser," +
    "EObjXRetailerJPN.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXRetailerJPNAllFields =
    "com.ibm.daimler.dsea.entityObject.EObjXRetailerJPN.xRetailerJPNpkId," +
    "com.ibm.daimler.dsea.entityObject.EObjXRetailerJPN.retailerCode," +
    "com.ibm.daimler.dsea.entityObject.EObjXRetailerJPN.retailerName," +
    "com.ibm.daimler.dsea.entityObject.EObjXRetailerJPN.branchName," +
    "com.ibm.daimler.dsea.entityObject.EObjXRetailerJPN.sourceIdentifier," +
    "com.ibm.daimler.dsea.entityObject.EObjXRetailerJPN.gSCode," +
    "com.ibm.daimler.dsea.entityObject.EObjXRetailerJPN.gCCode," +
    "com.ibm.daimler.dsea.entityObject.EObjXRetailerJPN.lastModifiedSystemDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXRetailerJPN.nDCode," +
    "com.ibm.daimler.dsea.entityObject.EObjXRetailerJPN.marketName," +
    "com.ibm.daimler.dsea.entityObject.EObjXRetailerJPN.dealerActiveFlag," +
    "com.ibm.daimler.dsea.entityObject.EObjXRetailerJPN.dealerGroup," +
    "com.ibm.daimler.dsea.entityObject.EObjXRetailerJPN.dealerRolloutFlag," +
    "com.ibm.daimler.dsea.entityObject.EObjXRetailerJPN.batchInd," +
    "com.ibm.daimler.dsea.entityObject.EObjXRetailerJPN.createDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXRetailerJPN.changedDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXRetailerJPN.lastUpdateDt," +
    "com.ibm.daimler.dsea.entityObject.EObjXRetailerJPN.lastUpdateUser," +
    "com.ibm.daimler.dsea.entityObject.EObjXRetailerJPN.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXRetailerJPNUpdateFields =
    "com.ibm.daimler.dsea.entityObject.EObjXRetailerJPN.retailerCode," +
    "com.ibm.daimler.dsea.entityObject.EObjXRetailerJPN.retailerName," +
    "com.ibm.daimler.dsea.entityObject.EObjXRetailerJPN.branchName," +
    "com.ibm.daimler.dsea.entityObject.EObjXRetailerJPN.sourceIdentifier," +
    "com.ibm.daimler.dsea.entityObject.EObjXRetailerJPN.gSCode," +
    "com.ibm.daimler.dsea.entityObject.EObjXRetailerJPN.gCCode," +
    "com.ibm.daimler.dsea.entityObject.EObjXRetailerJPN.lastModifiedSystemDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXRetailerJPN.nDCode," +
    "com.ibm.daimler.dsea.entityObject.EObjXRetailerJPN.marketName," +
    "com.ibm.daimler.dsea.entityObject.EObjXRetailerJPN.dealerActiveFlag," +
    "com.ibm.daimler.dsea.entityObject.EObjXRetailerJPN.dealerGroup," +
    "com.ibm.daimler.dsea.entityObject.EObjXRetailerJPN.dealerRolloutFlag," +
    "com.ibm.daimler.dsea.entityObject.EObjXRetailerJPN.batchInd," +
    "com.ibm.daimler.dsea.entityObject.EObjXRetailerJPN.createDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXRetailerJPN.changedDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXRetailerJPN.lastUpdateDt," +
    "com.ibm.daimler.dsea.entityObject.EObjXRetailerJPN.lastUpdateUser," +
    "com.ibm.daimler.dsea.entityObject.EObjXRetailerJPN.lastUpdateTxId," +
    "com.ibm.daimler.dsea.entityObject.EObjXRetailerJPN.xRetailerJPNpkId," +
    "com.ibm.daimler.dsea.entityObject.EObjXRetailerJPN.oldLastUpdateDt";   

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Select XRetailerJPN by parameters.
   * @generated
   */
  @Select(sql=getEObjXRetailerJPNSql)
  @EntityMapping(parameters=EObjXRetailerJPNKeyField, results=EObjXRetailerJPNGetFields)
  Iterator<EObjXRetailerJPN> getEObjXRetailerJPN(Long xRetailerJPNpkId);  
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Create XRetailerJPN by EObjXRetailerJPN Object.
   * @generated
   */
  @Update(sql=createEObjXRetailerJPNSql)
  @EntityMapping(parameters=EObjXRetailerJPNAllFields)
    int createEObjXRetailerJPN(EObjXRetailerJPN e); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Update one XRetailerJPN by EObjXRetailerJPN object.
   * @generated
   */
  @Update(sql=updateEObjXRetailerJPNSql)
  @EntityMapping(parameters=EObjXRetailerJPNUpdateFields)
    int updateEObjXRetailerJPN(EObjXRetailerJPN e); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Delete XRetailerJPN by parameters.
   * @generated
   */
  @Update(sql=deleteEObjXRetailerJPNSql)
  @EntityMapping(parameters=EObjXRetailerJPNKeyField)
  int deleteEObjXRetailerJPN(Long xRetailerJPNpkId);

}

