/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[61c1ef7a44c392c2dbc9f8d2647d8116]
 */

package com.ibm.daimler.dsea.entityObject;

import com.dwl.base.EObjCommon;
import com.ibm.mdm.base.db.DataType;
import com.ibm.pdq.annotation.Column;
import com.ibm.pdq.annotation.Table;


import com.ibm.pdq.annotation.Id;

import java.sql.Timestamp;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * The entity object corresponding to the XGurantorCompany business object. This
 * entity object should include all the attributes as defined by the business
 * object.
 * 
 * @generated
 */
@SuppressWarnings("serial")
@Table(name=EObjXGurantorCompany.tableName)
public class EObjXGurantorCompany extends EObjCommon {

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public static final String tableName = "XGURANTORCOMPANY";
    
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String xGurantorCompanypkIdColumn = "XGURANTOR_COMPANYPK_ID";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String xGurantorCompanypkIdJdbcType = "BIGINT";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    xGurantorCompanypkIdPrecision = 19;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String contractDetailsIdColumn = "CONTRACT_DETAILS_ID";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String contractDetailsIdJdbcType = "BIGINT";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    contractDetailsIdPrecision = 19;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String bPIDColumn = "BPID";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String bPIDJdbcType = "VARCHAR";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    bPIDPrecision = 500;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String cANNumberColumn = "CAN_NUMBER";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String cANNumberJdbcType = "VARCHAR";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    cANNumberPrecision = 500;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String industryColumn = "INDUSTRY_TP_CD";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String industryJdbcType = "BIGINT";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    industryPrecision = 19;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String companyNameColumn = "COMPANY_NAME";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String companyNameJdbcType = "VARCHAR";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    companyNamePrecision = 500;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String companyNameLocalColumn = "COMPANY_NAME_LOCAL";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String companyNameLocalJdbcType = "VARCHAR";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    companyNameLocalPrecision = 500;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String addressUsageColumn = "ADDR_USAGE_TP_CD";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String addressUsageJdbcType = "BIGINT";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    addressUsagePrecision = 19;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String addressLineOneColumn = "ADDR_LINE_ONE";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String addressLineOneJdbcType = "VARCHAR";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    addressLineOnePrecision = 500;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String addressLineTwoColumn = "ADDR_LINE_TWO";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String addressLineTwoJdbcType = "VARCHAR";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    addressLineTwoPrecision = 500;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String addressLineThreeColumn = "ADDR_LINE_THREE";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String addressLineThreeJdbcType = "VARCHAR";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    addressLineThreePrecision = 500;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String postalCodeColumn = "POSTAL_CODE";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String postalCodeJdbcType = "VARCHAR";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    postalCodePrecision = 250;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String cityNameColumn = "CITY_NAME";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String cityNameJdbcType = "VARCHAR";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    cityNamePrecision = 250;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String residenceNumberColumn = "RESIDENCE_NUMBER";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String residenceNumberJdbcType = "VARCHAR";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    residenceNumberPrecision = 250;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String countryColumn = "COUNTRY_TP_CD";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String countryJdbcType = "BIGINT";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    countryPrecision = 19;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String buildingNameColumn = "BUILDING_NAME";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String buildingNameJdbcType = "VARCHAR";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    buildingNamePrecision = 250;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String streetNameColumn = "STREET_NAME";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String streetNameJdbcType = "VARCHAR";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    streetNamePrecision = 250;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String streetNumberColumn = "STREET_NUMBER";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String streetNumberJdbcType = "VARCHAR";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    streetNumberPrecision = 250;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String mobileNumberColumn = "MOBILE_NUMBER";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String mobileNumberJdbcType = "VARCHAR";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    mobileNumberPrecision = 250;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String homePhoneNumberColumn = "HOME_PHONE_NUMBER";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String homePhoneNumberJdbcType = "VARCHAR";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    homePhoneNumberPrecision = 250;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String workPhoneNumberColumn = "WORK_PHONE_NUMBER";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String workPhoneNumberJdbcType = "VARCHAR";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    workPhoneNumberPrecision = 250;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String workPhoneNumberExtensionColumn = "WORK_PHONE_NUMBER_EXT";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String workPhoneNumberExtensionJdbcType = "VARCHAR";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    workPhoneNumberExtensionPrecision = 250;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String faxColumn = "FAX";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String faxJdbcType = "VARCHAR";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    faxPrecision = 250;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String emailColumn = "EMAIL";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String emailJdbcType = "VARCHAR";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    emailPrecision = 250;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String sourceIdentifierColumn = "SOURCE_IDENT_TP_CD";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String sourceIdentifierJdbcType = "BIGINT";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    sourceIdentifierPrecision = 19;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String startDateColumn = "START_DT";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String startDateJdbcType = "TIMESTAMP";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String endDateColumn = "END_DT";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String endDateJdbcType = "TIMESTAMP";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String lastModifiedSystemDateColumn = "MODIFY_SYS_DT";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String lastModifiedSystemDateJdbcType = "TIMESTAMP";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected Long xGurantorCompanypkId;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected Long contractDetailsId;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String bPID;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String cANNumber;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected Long industry;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String companyName;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String companyNameLocal;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected Long addressUsage;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String addressLineOne;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String addressLineTwo;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String addressLineThree;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String postalCode;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String cityName;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String residenceNumber;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected Long country;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String buildingName;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String streetName;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String streetNumber;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String mobileNumber;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String homePhoneNumber;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String workPhoneNumber;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String workPhoneNumberExtension;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String fax;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String email;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected Long sourceIdentifier;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected  Timestamp startDate;
    //inside if 

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected  Timestamp endDate;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected  Timestamp lastModifiedSystemDate;
    //inside if 



    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Default constructor.     
     *
     * @generated
     */
    public EObjXGurantorCompany() {
        super();
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xGurantorCompanypkId attribute. 
     *
     * @generated
     */
    @Id
    @Column(name=xGurantorCompanypkIdColumn)
    @DataType(jdbcType=xGurantorCompanypkIdJdbcType, precision=xGurantorCompanypkIdPrecision)
    public Long getXGurantorCompanypkId (){
        return xGurantorCompanypkId;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xGurantorCompanypkId attribute. 
     *
     * @param xGurantorCompanypkId
     *     The new value of XGurantorCompanypkId. 
     * @generated
     */
    public void setXGurantorCompanypkId( Long xGurantorCompanypkId ){
        this.xGurantorCompanypkId = xGurantorCompanypkId;
    
        super.setIdPK(xGurantorCompanypkId);
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the contractDetailsId attribute. 
     *
     * @generated
     */
    @Column(name=contractDetailsIdColumn)
    @DataType(jdbcType=contractDetailsIdJdbcType, precision=contractDetailsIdPrecision)
    public Long getContractDetailsId (){
        return contractDetailsId;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the contractDetailsId attribute. 
     *
     * @param contractDetailsId
     *     The new value of ContractDetailsId. 
     * @generated
     */
    public void setContractDetailsId( Long contractDetailsId ){
        this.contractDetailsId = contractDetailsId;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the bPID attribute. 
     *
     * @generated
     */
    @Column(name=bPIDColumn)
    @DataType(jdbcType=bPIDJdbcType, precision=bPIDPrecision)
    public String getBPID (){
        return bPID;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the bPID attribute. 
     *
     * @param bPID
     *     The new value of BPID. 
     * @generated
     */
    public void setBPID( String bPID ){
        this.bPID = bPID;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the cANNumber attribute. 
     *
     * @generated
     */
    @Column(name=cANNumberColumn)
    @DataType(jdbcType=cANNumberJdbcType, precision=cANNumberPrecision)
    public String getCANNumber (){
        return cANNumber;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the cANNumber attribute. 
     *
     * @param cANNumber
     *     The new value of CANNumber. 
     * @generated
     */
    public void setCANNumber( String cANNumber ){
        this.cANNumber = cANNumber;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the industry attribute. 
     *
     * @generated
     */
    @Column(name=industryColumn)
    @DataType(jdbcType=industryJdbcType, precision=industryPrecision)
    public Long getIndustry (){
        return industry;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the industry attribute. 
     *
     * @param industry
     *     The new value of Industry. 
     * @generated
     */
    public void setIndustry( Long industry ){
        this.industry = industry;
    
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the companyName attribute. 
     *
     * @generated
     */
    @Column(name=companyNameColumn)
    @DataType(jdbcType=companyNameJdbcType, precision=companyNamePrecision)
    public String getCompanyName (){
        return companyName;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the companyName attribute. 
     *
     * @param companyName
     *     The new value of CompanyName. 
     * @generated
     */
    public void setCompanyName( String companyName ){
        this.companyName = companyName;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the companyNameLocal attribute. 
     *
     * @generated
     */
    @Column(name=companyNameLocalColumn)
    @DataType(jdbcType=companyNameLocalJdbcType, precision=companyNameLocalPrecision)
    public String getCompanyNameLocal (){
        return companyNameLocal;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the companyNameLocal attribute. 
     *
     * @param companyNameLocal
     *     The new value of CompanyNameLocal. 
     * @generated
     */
    public void setCompanyNameLocal( String companyNameLocal ){
        this.companyNameLocal = companyNameLocal;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the addressUsage attribute. 
     *
     * @generated
     */
    @Column(name=addressUsageColumn)
    @DataType(jdbcType=addressUsageJdbcType, precision=addressUsagePrecision)
    public Long getAddressUsage (){
        return addressUsage;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the addressUsage attribute. 
     *
     * @param addressUsage
     *     The new value of AddressUsage. 
     * @generated
     */
    public void setAddressUsage( Long addressUsage ){
        this.addressUsage = addressUsage;
    
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the addressLineOne attribute. 
     *
     * @generated
     */
    @Column(name=addressLineOneColumn)
    @DataType(jdbcType=addressLineOneJdbcType, precision=addressLineOnePrecision)
    public String getAddressLineOne (){
        return addressLineOne;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the addressLineOne attribute. 
     *
     * @param addressLineOne
     *     The new value of AddressLineOne. 
     * @generated
     */
    public void setAddressLineOne( String addressLineOne ){
        this.addressLineOne = addressLineOne;
    
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the addressLineTwo attribute. 
     *
     * @generated
     */
    @Column(name=addressLineTwoColumn)
    @DataType(jdbcType=addressLineTwoJdbcType, precision=addressLineTwoPrecision)
    public String getAddressLineTwo (){
        return addressLineTwo;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the addressLineTwo attribute. 
     *
     * @param addressLineTwo
     *     The new value of AddressLineTwo. 
     * @generated
     */
    public void setAddressLineTwo( String addressLineTwo ){
        this.addressLineTwo = addressLineTwo;
    
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the addressLineThree attribute. 
     *
     * @generated
     */
    @Column(name=addressLineThreeColumn)
    @DataType(jdbcType=addressLineThreeJdbcType, precision=addressLineThreePrecision)
    public String getAddressLineThree (){
        return addressLineThree;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the addressLineThree attribute. 
     *
     * @param addressLineThree
     *     The new value of AddressLineThree. 
     * @generated
     */
    public void setAddressLineThree( String addressLineThree ){
        this.addressLineThree = addressLineThree;
    
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the postalCode attribute. 
     *
     * @generated
     */
    @Column(name=postalCodeColumn)
    @DataType(jdbcType=postalCodeJdbcType, precision=postalCodePrecision)
    public String getPostalCode (){
        return postalCode;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the postalCode attribute. 
     *
     * @param postalCode
     *     The new value of PostalCode. 
     * @generated
     */
    public void setPostalCode( String postalCode ){
        this.postalCode = postalCode;
    
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the cityName attribute. 
     *
     * @generated
     */
    @Column(name=cityNameColumn)
    @DataType(jdbcType=cityNameJdbcType, precision=cityNamePrecision)
    public String getCityName (){
        return cityName;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the cityName attribute. 
     *
     * @param cityName
     *     The new value of CityName. 
     * @generated
     */
    public void setCityName( String cityName ){
        this.cityName = cityName;
    
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the residenceNumber attribute. 
     *
     * @generated
     */
    @Column(name=residenceNumberColumn)
    @DataType(jdbcType=residenceNumberJdbcType, precision=residenceNumberPrecision)
    public String getResidenceNumber (){
        return residenceNumber;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the residenceNumber attribute. 
     *
     * @param residenceNumber
     *     The new value of ResidenceNumber. 
     * @generated
     */
    public void setResidenceNumber( String residenceNumber ){
        this.residenceNumber = residenceNumber;
    
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the country attribute. 
     *
     * @generated
     */
    @Column(name=countryColumn)
    @DataType(jdbcType=countryJdbcType, precision=countryPrecision)
    public Long getCountry (){
        return country;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the country attribute. 
     *
     * @param country
     *     The new value of Country. 
     * @generated
     */
    public void setCountry( Long country ){
        this.country = country;
    
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the buildingName attribute. 
     *
     * @generated
     */
    @Column(name=buildingNameColumn)
    @DataType(jdbcType=buildingNameJdbcType, precision=buildingNamePrecision)
    public String getBuildingName (){
        return buildingName;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the buildingName attribute. 
     *
     * @param buildingName
     *     The new value of BuildingName. 
     * @generated
     */
    public void setBuildingName( String buildingName ){
        this.buildingName = buildingName;
    
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the streetName attribute. 
     *
     * @generated
     */
    @Column(name=streetNameColumn)
    @DataType(jdbcType=streetNameJdbcType, precision=streetNamePrecision)
    public String getStreetName (){
        return streetName;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the streetName attribute. 
     *
     * @param streetName
     *     The new value of StreetName. 
     * @generated
     */
    public void setStreetName( String streetName ){
        this.streetName = streetName;
    
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the streetNumber attribute. 
     *
     * @generated
     */
    @Column(name=streetNumberColumn)
    @DataType(jdbcType=streetNumberJdbcType, precision=streetNumberPrecision)
    public String getStreetNumber (){
        return streetNumber;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the streetNumber attribute. 
     *
     * @param streetNumber
     *     The new value of StreetNumber. 
     * @generated
     */
    public void setStreetNumber( String streetNumber ){
        this.streetNumber = streetNumber;
    
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the mobileNumber attribute. 
     *
     * @generated
     */
    @Column(name=mobileNumberColumn)
    @DataType(jdbcType=mobileNumberJdbcType, precision=mobileNumberPrecision)
    public String getMobileNumber (){
        return mobileNumber;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the mobileNumber attribute. 
     *
     * @param mobileNumber
     *     The new value of MobileNumber. 
     * @generated
     */
    public void setMobileNumber( String mobileNumber ){
        this.mobileNumber = mobileNumber;
    
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the homePhoneNumber attribute. 
     *
     * @generated
     */
    @Column(name=homePhoneNumberColumn)
    @DataType(jdbcType=homePhoneNumberJdbcType, precision=homePhoneNumberPrecision)
    public String getHomePhoneNumber (){
        return homePhoneNumber;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the homePhoneNumber attribute. 
     *
     * @param homePhoneNumber
     *     The new value of HomePhoneNumber. 
     * @generated
     */
    public void setHomePhoneNumber( String homePhoneNumber ){
        this.homePhoneNumber = homePhoneNumber;
    
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the workPhoneNumber attribute. 
     *
     * @generated
     */
    @Column(name=workPhoneNumberColumn)
    @DataType(jdbcType=workPhoneNumberJdbcType, precision=workPhoneNumberPrecision)
    public String getWorkPhoneNumber (){
        return workPhoneNumber;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the workPhoneNumber attribute. 
     *
     * @param workPhoneNumber
     *     The new value of WorkPhoneNumber. 
     * @generated
     */
    public void setWorkPhoneNumber( String workPhoneNumber ){
        this.workPhoneNumber = workPhoneNumber;
    
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the workPhoneNumberExtension attribute. 
     *
     * @generated
     */
    @Column(name=workPhoneNumberExtensionColumn)
    @DataType(jdbcType=workPhoneNumberExtensionJdbcType, precision=workPhoneNumberExtensionPrecision)
    public String getWorkPhoneNumberExtension (){
        return workPhoneNumberExtension;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the workPhoneNumberExtension attribute. 
     *
     * @param workPhoneNumberExtension
     *     The new value of WorkPhoneNumberExtension. 
     * @generated
     */
    public void setWorkPhoneNumberExtension( String workPhoneNumberExtension ){
        this.workPhoneNumberExtension = workPhoneNumberExtension;
    
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the fax attribute. 
     *
     * @generated
     */
    @Column(name=faxColumn)
    @DataType(jdbcType=faxJdbcType, precision=faxPrecision)
    public String getFax (){
        return fax;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the fax attribute. 
     *
     * @param fax
     *     The new value of Fax. 
     * @generated
     */
    public void setFax( String fax ){
        this.fax = fax;
    
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the email attribute. 
     *
     * @generated
     */
    @Column(name=emailColumn)
    @DataType(jdbcType=emailJdbcType, precision=emailPrecision)
    public String getEmail (){
        return email;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the email attribute. 
     *
     * @param email
     *     The new value of Email. 
     * @generated
     */
    public void setEmail( String email ){
        this.email = email;
    
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the sourceIdentifier attribute. 
     *
     * @generated
     */
    @Column(name=sourceIdentifierColumn)
    @DataType(jdbcType=sourceIdentifierJdbcType, precision=sourceIdentifierPrecision)
    public Long getSourceIdentifier (){
        return sourceIdentifier;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the sourceIdentifier attribute. 
     *
     * @param sourceIdentifier
     *     The new value of SourceIdentifier. 
     * @generated
     */
    public void setSourceIdentifier( Long sourceIdentifier ){
        this.sourceIdentifier = sourceIdentifier;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the startDate attribute. 
     *
     * @generated
     */
    @Column(name=startDateColumn)
    @DataType(jdbcType=startDateJdbcType)
    public Timestamp getStartDate (){
        return startDate;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the startDate attribute. 
     *
     * @param startDate
     *     The new value of StartDate. 
     * @generated
     */
    public void setStartDate( Timestamp startDate ){
        this.startDate = startDate;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the endDate attribute. 
     *
     * @generated
     */
    @Column(name=endDateColumn)
    @DataType(jdbcType=endDateJdbcType)
    public Timestamp getEndDate (){
        return endDate;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the endDate attribute. 
     *
     * @param endDate
     *     The new value of EndDate. 
     * @generated
     */
    public void setEndDate( Timestamp endDate ){
        this.endDate = endDate;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the lastModifiedSystemDate attribute. 
     *
     * @generated
     */
    @Column(name=lastModifiedSystemDateColumn)
    @DataType(jdbcType=lastModifiedSystemDateJdbcType)
    public Timestamp getLastModifiedSystemDate (){
        return lastModifiedSystemDate;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the lastModifiedSystemDate attribute. 
     *
     * @param lastModifiedSystemDate
     *     The new value of LastModifiedSystemDate. 
     * @generated
     */
    public void setLastModifiedSystemDate( Timestamp lastModifiedSystemDate ){
        this.lastModifiedSystemDate = lastModifiedSystemDate;
    
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the primary key. 
     *
     * @param aUniqueId
     *     The new value of the primary key. 
     * @generated
   */
	public void setPrimaryKey(Object aUniqueId) {
    this.setXGurantorCompanypkId((Long)aUniqueId);
  }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the primary key.
     *
     * @generated
     */
	public Object getPrimaryKey() {
    return this.getXGurantorCompanypkId();
  }
	 
}


