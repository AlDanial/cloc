/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[2f5ec5841a29d65bce627176e25384ef]
 */

package com.ibm.daimler.dsea.entityObject;

import com.dwl.base.EObjCommon;
import com.ibm.mdm.base.db.DataType;
import com.ibm.pdq.annotation.Column;
import com.ibm.pdq.annotation.Table;


import com.ibm.pdq.annotation.Id;
import java.sql.Timestamp;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * The entity object corresponding to the XVehicle business object. This entity
 * object should include all the attributes as defined by the business object.
 * 
 * @generated
 */
@SuppressWarnings("serial")
@Table(name=EObjXVehicle.tableName)
public class EObjXVehicle extends EObjCommon {

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public static final String tableName = "XVEHICLE";
    
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String vehiclepkIdColumn = "VEHICLEPK_ID";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String vehiclepkIdJdbcType = "BIGINT";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    vehiclepkIdPrecision = 19;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String divisionColumn = "DIVISION";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String divisionJdbcType = "VARCHAR";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    divisionPrecision = 20;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String businessUnitColumn = "BUSINESS_UNIT";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String businessUnitJdbcType = "VARCHAR";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    businessUnitPrecision = 20;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String activityColumn = "ACTIVITY";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String activityJdbcType = "VARCHAR";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    activityPrecision = 20;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String typeClassColumn = "TYPE_CLASS";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String typeClassJdbcType = "VARCHAR";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    typeClassPrecision = 20;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String bauRelheColumn = "BAU_RELHE";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String bauRelheJdbcType = "VARCHAR";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    bauRelhePrecision = 20;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String bauMusterColumn = "BAU_MUSTER";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String bauMusterJdbcType = "VARCHAR";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    bauMusterPrecision = 20;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String subMusterColumn = "SUB_MUSTER";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String subMusterJdbcType = "VARCHAR";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    subMusterPrecision = 10;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String engineNumberColumn = "ENGINE_NUM";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String engineNumberJdbcType = "VARCHAR";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    engineNumberPrecision = 20;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String countryColumn = "COUNTRY_TP_CD";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String countryJdbcType = "BIGINT";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    countryPrecision = 19;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String colorColumn = "COLOR";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String colorJdbcType = "VARCHAR";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    colorPrecision = 50;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String trimColumn = "TRIM";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String trimJdbcType = "VARCHAR";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    trimPrecision = 50;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String globalVINColumn = "GLOBAL_VIN";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String globalVINJdbcType = "VARCHAR";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    globalVINPrecision = 20;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String localVINColumn = "LOCAL_VIN";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String localVINJdbcType = "VARCHAR";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    localVINPrecision = 20;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String licensePlateColumn = "LICENSE_PLATE";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String licensePlateJdbcType = "VARCHAR";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    licensePlatePrecision = 20;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String sourceIdentifierColumn = "SOURCE_IDENT_TP_CD";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String sourceIdentifierJdbcType = "BIGINT";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    sourceIdentifierPrecision = 19;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String lastModifiedSystemDateColumn = "MODIFY_SYS_DT";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String lastModifiedSystemDateJdbcType = "TIMESTAMP";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String createDateColumn = "CREATE_DT";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String createDateJdbcType = "TIMESTAMP";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String changedDateColumn = "CHANGED_DT";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String changedDateJdbcType = "TIMESTAMP";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String lastServiceDateColumn = "LAST_SERVICE_DT";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String lastServiceDateJdbcType = "TIMESTAMP";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String marketNameColumn = "MARKET_NAME";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String marketNameJdbcType = "VARCHAR";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    marketNamePrecision = 250;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected Long vehiclepkId;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String division;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String businessUnit;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String activity;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String typeClass;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String bauRelhe;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String bauMuster;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String subMuster;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String engineNumber;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected Long country;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String color;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String trim;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String globalVIN;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String localVIN;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String licensePlate;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected Long sourceIdentifier;



    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected  Timestamp lastModifiedSystemDate;



    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected  Timestamp createDate;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected  Timestamp changedDate;



    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected  Timestamp lastServiceDate;



    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String marketName;



    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Default constructor.     
     *
     * @generated
     */
    public EObjXVehicle() {
        super();
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the vehiclepkId attribute. 
     *
     * @generated
     */
    @Id
    @Column(name=vehiclepkIdColumn)
    @DataType(jdbcType=vehiclepkIdJdbcType, precision=vehiclepkIdPrecision)
    public Long getVehiclepkId (){
        return vehiclepkId;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the vehiclepkId attribute. 
     *
     * @param vehiclepkId
     *     The new value of VehiclepkId. 
     * @generated
     */
    public void setVehiclepkId( Long vehiclepkId ){
        this.vehiclepkId = vehiclepkId;
    
        super.setIdPK(vehiclepkId);
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the division attribute. 
     *
     * @generated
     */
    @Column(name=divisionColumn)
    @DataType(jdbcType=divisionJdbcType, precision=divisionPrecision)
    public String getDivision (){
        return division;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the division attribute. 
     *
     * @param division
     *     The new value of Division. 
     * @generated
     */
    public void setDivision( String division ){
        this.division = division;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the businessUnit attribute. 
     *
     * @generated
     */
    @Column(name=businessUnitColumn)
    @DataType(jdbcType=businessUnitJdbcType, precision=businessUnitPrecision)
    public String getBusinessUnit (){
        return businessUnit;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the businessUnit attribute. 
     *
     * @param businessUnit
     *     The new value of BusinessUnit. 
     * @generated
     */
    public void setBusinessUnit( String businessUnit ){
        this.businessUnit = businessUnit;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the activity attribute. 
     *
     * @generated
     */
    @Column(name=activityColumn)
    @DataType(jdbcType=activityJdbcType, precision=activityPrecision)
    public String getActivity (){
        return activity;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the activity attribute. 
     *
     * @param activity
     *     The new value of Activity. 
     * @generated
     */
    public void setActivity( String activity ){
        this.activity = activity;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the typeClass attribute. 
     *
     * @generated
     */
    @Column(name=typeClassColumn)
    @DataType(jdbcType=typeClassJdbcType, precision=typeClassPrecision)
    public String getTypeClass (){
        return typeClass;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the typeClass attribute. 
     *
     * @param typeClass
     *     The new value of TypeClass. 
     * @generated
     */
    public void setTypeClass( String typeClass ){
        this.typeClass = typeClass;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the bauRelhe attribute. 
     *
     * @generated
     */
    @Column(name=bauRelheColumn)
    @DataType(jdbcType=bauRelheJdbcType, precision=bauRelhePrecision)
    public String getBauRelhe (){
        return bauRelhe;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the bauRelhe attribute. 
     *
     * @param bauRelhe
     *     The new value of BauRelhe. 
     * @generated
     */
    public void setBauRelhe( String bauRelhe ){
        this.bauRelhe = bauRelhe;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the bauMuster attribute. 
     *
     * @generated
     */
    @Column(name=bauMusterColumn)
    @DataType(jdbcType=bauMusterJdbcType, precision=bauMusterPrecision)
    public String getBauMuster (){
        return bauMuster;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the bauMuster attribute. 
     *
     * @param bauMuster
     *     The new value of BauMuster. 
     * @generated
     */
    public void setBauMuster( String bauMuster ){
        this.bauMuster = bauMuster;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the subMuster attribute. 
     *
     * @generated
     */
    @Column(name=subMusterColumn)
    @DataType(jdbcType=subMusterJdbcType, precision=subMusterPrecision)
    public String getSubMuster (){
        return subMuster;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the subMuster attribute. 
     *
     * @param subMuster
     *     The new value of SubMuster. 
     * @generated
     */
    public void setSubMuster( String subMuster ){
        this.subMuster = subMuster;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the engineNumber attribute. 
     *
     * @generated
     */
    @Column(name=engineNumberColumn)
    @DataType(jdbcType=engineNumberJdbcType, precision=engineNumberPrecision)
    public String getEngineNumber (){
        return engineNumber;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the engineNumber attribute. 
     *
     * @param engineNumber
     *     The new value of EngineNumber. 
     * @generated
     */
    public void setEngineNumber( String engineNumber ){
        this.engineNumber = engineNumber;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the country attribute. 
     *
     * @generated
     */
    @Column(name=countryColumn)
    @DataType(jdbcType=countryJdbcType, precision=countryPrecision)
    public Long getCountry (){
        return country;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the country attribute. 
     *
     * @param country
     *     The new value of Country. 
     * @generated
     */
    public void setCountry( Long country ){
        this.country = country;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the color attribute. 
     *
     * @generated
     */
    @Column(name=colorColumn)
    @DataType(jdbcType=colorJdbcType, precision=colorPrecision)
    public String getColor (){
        return color;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the color attribute. 
     *
     * @param color
     *     The new value of Color. 
     * @generated
     */
    public void setColor( String color ){
        this.color = color;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the trim attribute. 
     *
     * @generated
     */
    @Column(name=trimColumn)
    @DataType(jdbcType=trimJdbcType, precision=trimPrecision)
    public String getTrim (){
        return trim;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the trim attribute. 
     *
     * @param trim
     *     The new value of Trim. 
     * @generated
     */
    public void setTrim( String trim ){
        this.trim = trim;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the globalVIN attribute. 
     *
     * @generated
     */
    @Column(name=globalVINColumn)
    @DataType(jdbcType=globalVINJdbcType, precision=globalVINPrecision)
    public String getGlobalVIN (){
        return globalVIN;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the globalVIN attribute. 
     *
     * @param globalVIN
     *     The new value of GlobalVIN. 
     * @generated
     */
    public void setGlobalVIN( String globalVIN ){
        this.globalVIN = globalVIN;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the localVIN attribute. 
     *
     * @generated
     */
    @Column(name=localVINColumn)
    @DataType(jdbcType=localVINJdbcType, precision=localVINPrecision)
    public String getLocalVIN (){
        return localVIN;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the localVIN attribute. 
     *
     * @param localVIN
     *     The new value of LocalVIN. 
     * @generated
     */
    public void setLocalVIN( String localVIN ){
        this.localVIN = localVIN;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the licensePlate attribute. 
     *
     * @generated
     */
    @Column(name=licensePlateColumn)
    @DataType(jdbcType=licensePlateJdbcType, precision=licensePlatePrecision)
    public String getLicensePlate (){
        return licensePlate;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the licensePlate attribute. 
     *
     * @param licensePlate
     *     The new value of LicensePlate. 
     * @generated
     */
    public void setLicensePlate( String licensePlate ){
        this.licensePlate = licensePlate;
    
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the sourceIdentifier attribute. 
     *
     * @generated
     */
    @Column(name=sourceIdentifierColumn)
    @DataType(jdbcType=sourceIdentifierJdbcType, precision=sourceIdentifierPrecision)
    public Long getSourceIdentifier (){
        return sourceIdentifier;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the sourceIdentifier attribute. 
     *
     * @param sourceIdentifier
     *     The new value of SourceIdentifier. 
     * @generated
     */
    public void setSourceIdentifier( Long sourceIdentifier ){
        this.sourceIdentifier = sourceIdentifier;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the lastModifiedSystemDate attribute. 
     *
     * @generated
     */
    @Column(name=lastModifiedSystemDateColumn)
    @DataType(jdbcType=lastModifiedSystemDateJdbcType)
    public Timestamp getLastModifiedSystemDate (){
        return lastModifiedSystemDate;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the lastModifiedSystemDate attribute. 
     *
     * @param lastModifiedSystemDate
     *     The new value of LastModifiedSystemDate. 
     * @generated
     */
    public void setLastModifiedSystemDate( Timestamp lastModifiedSystemDate ){
        this.lastModifiedSystemDate = lastModifiedSystemDate;
    
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the createDate attribute. 
     *
     * @generated
     */
    @Column(name=createDateColumn)
    @DataType(jdbcType=createDateJdbcType)
    public Timestamp getCreateDate (){
        return createDate;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the createDate attribute. 
     *
     * @param createDate
     *     The new value of CreateDate. 
     * @generated
     */
    public void setCreateDate( Timestamp createDate ){
        this.createDate = createDate;
    
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the changedDate attribute. 
     *
     * @generated
     */
    @Column(name=changedDateColumn)
    @DataType(jdbcType=changedDateJdbcType)
    public Timestamp getChangedDate (){
        return changedDate;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the changedDate attribute. 
     *
     * @param changedDate
     *     The new value of ChangedDate. 
     * @generated
     */
    public void setChangedDate( Timestamp changedDate ){
        this.changedDate = changedDate;
    
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the lastServiceDate attribute. 
     *
     * @generated
     */
    @Column(name=lastServiceDateColumn)
    @DataType(jdbcType=lastServiceDateJdbcType)
    public Timestamp getLastServiceDate (){
        return lastServiceDate;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the lastServiceDate attribute. 
     *
     * @param lastServiceDate
     *     The new value of LastServiceDate. 
     * @generated
     */
    public void setLastServiceDate( Timestamp lastServiceDate ){
        this.lastServiceDate = lastServiceDate;
    
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the marketName attribute. 
     *
     * @generated
     */
    @Column(name=marketNameColumn)
    @DataType(jdbcType=marketNameJdbcType, precision=marketNamePrecision)
    public String getMarketName (){
        return marketName;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the marketName attribute. 
     *
     * @param marketName
     *     The new value of MarketName. 
     * @generated
     */
    public void setMarketName( String marketName ){
        this.marketName = marketName;
    
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the primary key. 
     *
     * @param aUniqueId
     *     The new value of the primary key. 
     * @generated
   */
	public void setPrimaryKey(Object aUniqueId) {
    this.setVehiclepkId((Long)aUniqueId);
  }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the primary key.
     *
     * @generated
     */
	public Object getPrimaryKey() {
    return this.getVehiclepkId();
  }
	 
}


