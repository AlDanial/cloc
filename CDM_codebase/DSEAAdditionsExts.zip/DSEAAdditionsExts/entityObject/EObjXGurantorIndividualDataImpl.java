package com.ibm.daimler.dsea.entityObject;

import com.ibm.pdq.runtime.generator.BaseParameterHandler;
import java.util.Iterator;
import java.sql.PreparedStatement;
import com.ibm.pdq.runtime.statement.StatementDescriptor;
import com.ibm.pdq.runtime.generator.BaseData;
import com.ibm.daimler.dsea.entityObject.EObjXGurantorIndividual;
import java.sql.SQLException;
import com.ibm.pdq.annotation.Metadata;
import com.ibm.pdq.runtime.generator.BaseRowHandler;
import com.ibm.pdq.runtime.statement.SqlStatementType;
import java.sql.Types;


/**
 * <!-- begin-user-doc -->
 * 
 * <!-- end-user-doc -->
 * 
 * @generated
 */
public class EObjXGurantorIndividualDataImpl  extends BaseData implements EObjXGurantorIndividualData
{

  /**
   * @generated
   */
  public static final String generatorVersion = "3.200.75";

  /**
   * @generated
   */
  public static final String identifier = "EObjXGurantorIndividualData";

  /**
   * @generated
   */
  public static final long generationTime = 0x00000161d1eb309fL;

  /**
   * @generated
   */
  public static final String collection = "NULLID";

  /**
   * @generated
   */
  public static final String packageVersion = null;

  /**
   * @generated
   */
  public static final boolean forceSingleBindIsolation = false;

  /**
   * @generated
   */
  public EObjXGurantorIndividualDataImpl()
  {
    super();
  } 

  /**
   * @generated
   */
  public String getGeneratorVersion()
  {
    return generatorVersion;
  }

  /**
   * @Select( sql="select XGurantor_Individualpk_Id, CONTRACT_DETAILS_ID, BPID, ABN_NUMBER, PREFIX_NAME_TP_CD, GIVEN_NAME_ONE, LAST_NAME, GIVEN_NAME_ONE_LOCAL, LAST_NAME_LOCAL, BIRTH_DT, ADDR_USAGE_TP_CD, ADDR_LINE_ONE, ADDR_LINE_TWO, ADDR_LINE_THREE, POSTAL_CODE, CITY_NAME, RESIDENCE_NUMBER, COUNTRY_TP_CD, BUILDING_NAME, STREET_NAME, STREET_NUMBER, MOBILE_NUMBER, HOME_PHONE_NUMBER, WORK_PHONE_NUMBER, WORK_PHONE_NUMBER_EXT, FAX, EMAIL, SOURCE_IDENT_TP_CD, START_DT, END_DT, MODIFY_SYS_DT, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from XGURANTORINDIVIDUAL where XGurantor_Individualpk_Id = ? " )
   * 
   * @generated
   */
  public Iterator<EObjXGurantorIndividual> getEObjXGurantorIndividual (Long xGurantorIndividualpkId)
  {
    return queryIterator (getEObjXGurantorIndividualStatementDescriptor, xGurantorIndividualpkId);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getEObjXGurantorIndividualStatementDescriptor = createStatementDescriptor (
    "getEObjXGurantorIndividual(Long)",
    "select XGurantor_Individualpk_Id, CONTRACT_DETAILS_ID, BPID, ABN_NUMBER, PREFIX_NAME_TP_CD, GIVEN_NAME_ONE, LAST_NAME, GIVEN_NAME_ONE_LOCAL, LAST_NAME_LOCAL, BIRTH_DT, ADDR_USAGE_TP_CD, ADDR_LINE_ONE, ADDR_LINE_TWO, ADDR_LINE_THREE, POSTAL_CODE, CITY_NAME, RESIDENCE_NUMBER, COUNTRY_TP_CD, BUILDING_NAME, STREET_NAME, STREET_NUMBER, MOBILE_NUMBER, HOME_PHONE_NUMBER, WORK_PHONE_NUMBER, WORK_PHONE_NUMBER_EXT, FAX, EMAIL, SOURCE_IDENT_TP_CD, START_DT, END_DT, MODIFY_SYS_DT, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from XGURANTORINDIVIDUAL where XGurantor_Individualpk_Id = ? ",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"xgurantor_individualpk_id", "contract_details_id", "bpid", "abn_number", "prefix_name_tp_cd", "given_name_one", "last_name", "given_name_one_local", "last_name_local", "birth_dt", "addr_usage_tp_cd", "addr_line_one", "addr_line_two", "addr_line_three", "postal_code", "city_name", "residence_number", "country_tp_cd", "building_name", "street_name", "street_number", "mobile_number", "home_phone_number", "work_phone_number", "work_phone_number_ext", "fax", "email", "source_ident_tp_cd", "start_dt", "end_dt", "modify_sys_dt", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetEObjXGurantorIndividualParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetEObjXGurantorIndividualRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 19, 500, 500, 19, 500, 500, 500, 500, 0, 19, 500, 500, 500, 250, 250, 250, 19, 250, 250, 250, 250, 250, 250, 250, 250, 250, 19, 0, 0, 0, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    1);

  /**
   * @generated
   */
  public static class GetEObjXGurantorIndividualParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setLong (stmt, 1, Types.BIGINT, (Long)parameters[0]);
    }
  }

  /**
   * @generated
   */
  public static class GetEObjXGurantorIndividualRowHandler extends BaseRowHandler<EObjXGurantorIndividual>
  {
    /**
     * @generated
     */
    public EObjXGurantorIndividual handle (java.sql.ResultSet rs, EObjXGurantorIndividual returnObject) throws java.sql.SQLException
    {
      returnObject = new EObjXGurantorIndividual ();
      returnObject.setXGurantorIndividualpkId(getLongObject (rs, 1)); 
      returnObject.setContractDetailsId(getLongObject (rs, 2)); 
      returnObject.setBPID(getString (rs, 3)); 
      returnObject.setABNNumber(getString (rs, 4)); 
      returnObject.setTitle(getLongObject (rs, 5)); 
      returnObject.setGivenNameOne(getString (rs, 6)); 
      returnObject.setLastName(getString (rs, 7)); 
      returnObject.setGivenNameOneLocal(getString (rs, 8)); 
      returnObject.setLastNameLocal(getString (rs, 9)); 
      returnObject.setBirthDate(getTimestamp (rs, 10)); 
      returnObject.setAddressUsage(getLongObject (rs, 11)); 
      returnObject.setAddressLineOne(getString (rs, 12)); 
      returnObject.setAddressLineTwo(getString (rs, 13)); 
      returnObject.setAddressLineThree(getString (rs, 14)); 
      returnObject.setPostalCode(getString (rs, 15)); 
      returnObject.setCityName(getString (rs, 16)); 
      returnObject.setResidenceNumber(getString (rs, 17)); 
      returnObject.setCountry(getLongObject (rs, 18)); 
      returnObject.setBuildingName(getString (rs, 19)); 
      returnObject.setStreetName(getString (rs, 20)); 
      returnObject.setStreetNumber(getString (rs, 21)); 
      returnObject.setMobileNumber(getString (rs, 22)); 
      returnObject.setHomePhoneNumber(getString (rs, 23)); 
      returnObject.setWorkPhoneNumber(getString (rs, 24)); 
      returnObject.setWorkPhoneNumberExtension(getString (rs, 25)); 
      returnObject.setFax(getString (rs, 26)); 
      returnObject.setEmail(getString (rs, 27)); 
      returnObject.setSourceIdentifier(getLongObject (rs, 28)); 
      returnObject.setStartDate(getTimestamp (rs, 29)); 
      returnObject.setEndDate(getTimestamp (rs, 30)); 
      returnObject.setLastModifiedSystemDate(getTimestamp (rs, 31)); 
      returnObject.setLastUpdateDt(getTimestamp (rs, 32)); 
      returnObject.setLastUpdateUser(getString (rs, 33)); 
      returnObject.setLastUpdateTxId(getLongObject (rs, 34)); 
    
      return returnObject;
    }
  }

  /**
   * @Update( sql="insert into XGURANTORINDIVIDUAL (XGurantor_Individualpk_Id, CONTRACT_DETAILS_ID, BPID, ABN_NUMBER, PREFIX_NAME_TP_CD, GIVEN_NAME_ONE, LAST_NAME, GIVEN_NAME_ONE_LOCAL, LAST_NAME_LOCAL, BIRTH_DT, ADDR_USAGE_TP_CD, ADDR_LINE_ONE, ADDR_LINE_TWO, ADDR_LINE_THREE, POSTAL_CODE, CITY_NAME, RESIDENCE_NUMBER, COUNTRY_TP_CD, BUILDING_NAME, STREET_NAME, STREET_NUMBER, MOBILE_NUMBER, HOME_PHONE_NUMBER, WORK_PHONE_NUMBER, WORK_PHONE_NUMBER_EXT, FAX, EMAIL, SOURCE_IDENT_TP_CD, START_DT, END_DT, MODIFY_SYS_DT, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( :xGurantorIndividualpkId, :contractDetailsId, :bPID, :aBNNumber, :title, :givenNameOne, :lastName, :givenNameOneLocal, :lastNameLocal, :birthDate, :addressUsage, :addressLineOne, :addressLineTwo, :addressLineThree, :postalCode, :cityName, :residenceNumber, :country, :buildingName, :streetName, :streetNumber, :mobileNumber, :homePhoneNumber, :workPhoneNumber, :workPhoneNumberExtension, :fax, :email, :sourceIdentifier, :startDate, :endDate, :lastModifiedSystemDate, :lastUpdateDt, :lastUpdateUser, :lastUpdateTxId)" )
   * 
   * @generated
   */
  public int createEObjXGurantorIndividual (EObjXGurantorIndividual e)
  {
    return update (createEObjXGurantorIndividualStatementDescriptor, e);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor createEObjXGurantorIndividualStatementDescriptor = createStatementDescriptor (
    "createEObjXGurantorIndividual(com.ibm.daimler.dsea.entityObject.EObjXGurantorIndividual)",
    "insert into XGURANTORINDIVIDUAL (XGurantor_Individualpk_Id, CONTRACT_DETAILS_ID, BPID, ABN_NUMBER, PREFIX_NAME_TP_CD, GIVEN_NAME_ONE, LAST_NAME, GIVEN_NAME_ONE_LOCAL, LAST_NAME_LOCAL, BIRTH_DT, ADDR_USAGE_TP_CD, ADDR_LINE_ONE, ADDR_LINE_TWO, ADDR_LINE_THREE, POSTAL_CODE, CITY_NAME, RESIDENCE_NUMBER, COUNTRY_TP_CD, BUILDING_NAME, STREET_NAME, STREET_NUMBER, MOBILE_NUMBER, HOME_PHONE_NUMBER, WORK_PHONE_NUMBER, WORK_PHONE_NUMBER_EXT, FAX, EMAIL, SOURCE_IDENT_TP_CD, START_DT, END_DT, MODIFY_SYS_DT, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values(  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? )",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.INSERT,
    null,
    new CreateEObjXGurantorIndividualParameterHandler (),
    new int[][]{{Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 19, 500, 500, 19, 500, 500, 500, 500, 0, 19, 500, 500, 500, 250, 250, 250, 19, 250, 250, 250, 250, 250, 250, 250, 250, 250, 19, 0, 0, 0, 0, 0, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    2);

  /**
   * @generated
   */
  public static class CreateEObjXGurantorIndividualParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      EObjXGurantorIndividual bean0 = (EObjXGurantorIndividual) parameters[0];
      setLong (stmt, 1, Types.BIGINT, (Long)bean0.getXGurantorIndividualpkId());
      setLong (stmt, 2, Types.BIGINT, (Long)bean0.getContractDetailsId());
      setString (stmt, 3, Types.VARCHAR, (String)bean0.getBPID());
      setString (stmt, 4, Types.VARCHAR, (String)bean0.getABNNumber());
      setLong (stmt, 5, Types.BIGINT, (Long)bean0.getTitle());
      setString (stmt, 6, Types.VARCHAR, (String)bean0.getGivenNameOne());
      setString (stmt, 7, Types.VARCHAR, (String)bean0.getLastName());
      setString (stmt, 8, Types.VARCHAR, (String)bean0.getGivenNameOneLocal());
      setString (stmt, 9, Types.VARCHAR, (String)bean0.getLastNameLocal());
      setTimestamp (stmt, 10, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getBirthDate());
      setLong (stmt, 11, Types.BIGINT, (Long)bean0.getAddressUsage());
      setString (stmt, 12, Types.VARCHAR, (String)bean0.getAddressLineOne());
      setString (stmt, 13, Types.VARCHAR, (String)bean0.getAddressLineTwo());
      setString (stmt, 14, Types.VARCHAR, (String)bean0.getAddressLineThree());
      setString (stmt, 15, Types.VARCHAR, (String)bean0.getPostalCode());
      setString (stmt, 16, Types.VARCHAR, (String)bean0.getCityName());
      setString (stmt, 17, Types.VARCHAR, (String)bean0.getResidenceNumber());
      setLong (stmt, 18, Types.BIGINT, (Long)bean0.getCountry());
      setString (stmt, 19, Types.VARCHAR, (String)bean0.getBuildingName());
      setString (stmt, 20, Types.VARCHAR, (String)bean0.getStreetName());
      setString (stmt, 21, Types.VARCHAR, (String)bean0.getStreetNumber());
      setString (stmt, 22, Types.VARCHAR, (String)bean0.getMobileNumber());
      setString (stmt, 23, Types.VARCHAR, (String)bean0.getHomePhoneNumber());
      setString (stmt, 24, Types.VARCHAR, (String)bean0.getWorkPhoneNumber());
      setString (stmt, 25, Types.VARCHAR, (String)bean0.getWorkPhoneNumberExtension());
      setString (stmt, 26, Types.VARCHAR, (String)bean0.getFax());
      setString (stmt, 27, Types.VARCHAR, (String)bean0.getEmail());
      setLong (stmt, 28, Types.BIGINT, (Long)bean0.getSourceIdentifier());
      setTimestamp (stmt, 29, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getStartDate());
      setTimestamp (stmt, 30, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getEndDate());
      setTimestamp (stmt, 31, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastModifiedSystemDate());
      setTimestamp (stmt, 32, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUpdateDt());
      setString (stmt, 33, Types.VARCHAR, (String)bean0.getLastUpdateUser());
      setLong (stmt, 34, Types.BIGINT, (Long)bean0.getLastUpdateTxId());
    }
  }

  /**
   * @Update( sql="update XGURANTORINDIVIDUAL set CONTRACT_DETAILS_ID = :contractDetailsId, BPID = :bPID, ABN_NUMBER = :aBNNumber, PREFIX_NAME_TP_CD = :title, GIVEN_NAME_ONE = :givenNameOne, LAST_NAME = :lastName, GIVEN_NAME_ONE_LOCAL = :givenNameOneLocal, LAST_NAME_LOCAL = :lastNameLocal, BIRTH_DT = :birthDate, ADDR_USAGE_TP_CD = :addressUsage, ADDR_LINE_ONE = :addressLineOne, ADDR_LINE_TWO = :addressLineTwo, ADDR_LINE_THREE = :addressLineThree, POSTAL_CODE = :postalCode, CITY_NAME = :cityName, RESIDENCE_NUMBER = :residenceNumber, COUNTRY_TP_CD = :country, BUILDING_NAME = :buildingName, STREET_NAME = :streetName, STREET_NUMBER = :streetNumber, MOBILE_NUMBER = :mobileNumber, HOME_PHONE_NUMBER = :homePhoneNumber, WORK_PHONE_NUMBER = :workPhoneNumber, WORK_PHONE_NUMBER_EXT = :workPhoneNumberExtension, FAX = :fax, EMAIL = :email, SOURCE_IDENT_TP_CD = :sourceIdentifier, START_DT = :startDate, END_DT = :endDate, MODIFY_SYS_DT = :lastModifiedSystemDate, LAST_UPDATE_DT = :lastUpdateDt, LAST_UPDATE_USER = :lastUpdateUser, LAST_UPDATE_TX_ID = :lastUpdateTxId where XGurantor_Individualpk_Id = :xGurantorIndividualpkId and LAST_UPDATE_DT = :oldLastUpdateDt" )
   * 
   * @generated
   */
  public int updateEObjXGurantorIndividual (EObjXGurantorIndividual e)
  {
    return update (updateEObjXGurantorIndividualStatementDescriptor, e);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor updateEObjXGurantorIndividualStatementDescriptor = createStatementDescriptor (
    "updateEObjXGurantorIndividual(com.ibm.daimler.dsea.entityObject.EObjXGurantorIndividual)",
    "update XGURANTORINDIVIDUAL set CONTRACT_DETAILS_ID =  ? , BPID =  ? , ABN_NUMBER =  ? , PREFIX_NAME_TP_CD =  ? , GIVEN_NAME_ONE =  ? , LAST_NAME =  ? , GIVEN_NAME_ONE_LOCAL =  ? , LAST_NAME_LOCAL =  ? , BIRTH_DT =  ? , ADDR_USAGE_TP_CD =  ? , ADDR_LINE_ONE =  ? , ADDR_LINE_TWO =  ? , ADDR_LINE_THREE =  ? , POSTAL_CODE =  ? , CITY_NAME =  ? , RESIDENCE_NUMBER =  ? , COUNTRY_TP_CD =  ? , BUILDING_NAME =  ? , STREET_NAME =  ? , STREET_NUMBER =  ? , MOBILE_NUMBER =  ? , HOME_PHONE_NUMBER =  ? , WORK_PHONE_NUMBER =  ? , WORK_PHONE_NUMBER_EXT =  ? , FAX =  ? , EMAIL =  ? , SOURCE_IDENT_TP_CD =  ? , START_DT =  ? , END_DT =  ? , MODIFY_SYS_DT =  ? , LAST_UPDATE_DT =  ? , LAST_UPDATE_USER =  ? , LAST_UPDATE_TX_ID =  ?  where XGurantor_Individualpk_Id =  ?  and LAST_UPDATE_DT =  ? ",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.UPDATE,
    null,
    new UpdateEObjXGurantorIndividualParameterHandler (),
    new int[][]{{Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP}, {19, 500, 500, 19, 500, 500, 500, 500, 0, 19, 500, 500, 500, 250, 250, 250, 19, 250, 250, 250, 250, 250, 250, 250, 250, 250, 19, 0, 0, 0, 0, 0, 19, 19, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    3);

  /**
   * @generated
   */
  public static class UpdateEObjXGurantorIndividualParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      EObjXGurantorIndividual bean0 = (EObjXGurantorIndividual) parameters[0];
      setLong (stmt, 1, Types.BIGINT, (Long)bean0.getContractDetailsId());
      setString (stmt, 2, Types.VARCHAR, (String)bean0.getBPID());
      setString (stmt, 3, Types.VARCHAR, (String)bean0.getABNNumber());
      setLong (stmt, 4, Types.BIGINT, (Long)bean0.getTitle());
      setString (stmt, 5, Types.VARCHAR, (String)bean0.getGivenNameOne());
      setString (stmt, 6, Types.VARCHAR, (String)bean0.getLastName());
      setString (stmt, 7, Types.VARCHAR, (String)bean0.getGivenNameOneLocal());
      setString (stmt, 8, Types.VARCHAR, (String)bean0.getLastNameLocal());
      setTimestamp (stmt, 9, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getBirthDate());
      setLong (stmt, 10, Types.BIGINT, (Long)bean0.getAddressUsage());
      setString (stmt, 11, Types.VARCHAR, (String)bean0.getAddressLineOne());
      setString (stmt, 12, Types.VARCHAR, (String)bean0.getAddressLineTwo());
      setString (stmt, 13, Types.VARCHAR, (String)bean0.getAddressLineThree());
      setString (stmt, 14, Types.VARCHAR, (String)bean0.getPostalCode());
      setString (stmt, 15, Types.VARCHAR, (String)bean0.getCityName());
      setString (stmt, 16, Types.VARCHAR, (String)bean0.getResidenceNumber());
      setLong (stmt, 17, Types.BIGINT, (Long)bean0.getCountry());
      setString (stmt, 18, Types.VARCHAR, (String)bean0.getBuildingName());
      setString (stmt, 19, Types.VARCHAR, (String)bean0.getStreetName());
      setString (stmt, 20, Types.VARCHAR, (String)bean0.getStreetNumber());
      setString (stmt, 21, Types.VARCHAR, (String)bean0.getMobileNumber());
      setString (stmt, 22, Types.VARCHAR, (String)bean0.getHomePhoneNumber());
      setString (stmt, 23, Types.VARCHAR, (String)bean0.getWorkPhoneNumber());
      setString (stmt, 24, Types.VARCHAR, (String)bean0.getWorkPhoneNumberExtension());
      setString (stmt, 25, Types.VARCHAR, (String)bean0.getFax());
      setString (stmt, 26, Types.VARCHAR, (String)bean0.getEmail());
      setLong (stmt, 27, Types.BIGINT, (Long)bean0.getSourceIdentifier());
      setTimestamp (stmt, 28, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getStartDate());
      setTimestamp (stmt, 29, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getEndDate());
      setTimestamp (stmt, 30, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastModifiedSystemDate());
      setTimestamp (stmt, 31, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUpdateDt());
      setString (stmt, 32, Types.VARCHAR, (String)bean0.getLastUpdateUser());
      setLong (stmt, 33, Types.BIGINT, (Long)bean0.getLastUpdateTxId());
      setLong (stmt, 34, Types.BIGINT, (Long)bean0.getXGurantorIndividualpkId());
      setTimestamp (stmt, 35, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getOldLastUpdateDt());
    }
  }

  /**
   * @Update( sql="delete from XGURANTORINDIVIDUAL where XGurantor_Individualpk_Id = ?" )
   * 
   * @generated
   */
  public int deleteEObjXGurantorIndividual (Long xGurantorIndividualpkId)
  {
    return update (deleteEObjXGurantorIndividualStatementDescriptor, xGurantorIndividualpkId);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor deleteEObjXGurantorIndividualStatementDescriptor = createStatementDescriptor (
    "deleteEObjXGurantorIndividual(Long)",
    "delete from XGURANTORINDIVIDUAL where XGurantor_Individualpk_Id = ?",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.DELETE,
    null,
    new DeleteEObjXGurantorIndividualParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    4);

  /**
   * @generated
   */
  public static class DeleteEObjXGurantorIndividualParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setLong (stmt, 1, Types.BIGINT, (Long)parameters[0]);
    }
  }

}
