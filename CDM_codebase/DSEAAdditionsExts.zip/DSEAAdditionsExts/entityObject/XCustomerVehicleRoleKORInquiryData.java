/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[c014e774bb750c321f6ec217fe82b4d4]
 */

package com.ibm.daimler.dsea.entityObject;


import com.ibm.mdm.base.db.ResultQueue1;
import java.util.Iterator;
import com.ibm.mdm.base.db.EntityMapping;
import com.ibm.pdq.annotation.Select;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * @generated
 */
public interface XCustomerVehicleRoleKORInquiryData {
  
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String tableAliasString = "tableAlias (" + 
                                            "XCUSTOMERVEHICLEROLEKOR => com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRoleKOR, " +
                                            "H_XCUSTOMERVEHICLEROLEKOR => com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRoleKOR" +
                                            ")";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getXCustomerVehicleRoleKORSql = "SELECT r.XCUSTOMERVEHICLEROLEKORPK_ID XCUSTOMERVEHICLEROLEKORPK_ID, r.CUSTOMER_VEHICLE_ID CUSTOMER_VEHICLE_ID, r.VEHICLE_ROLE_TP_CD VEHICLE_ROLE_TP_CD, r.START_DT START_DT, r.END_DT END_DT, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.CHANGED_DT CHANGED_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XCUSTOMERVEHICLEROLEKOR r WHERE r.XCUSTOMERVEHICLEROLEKORPK_ID = ? ";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXCustomerVehicleRoleKORParameters =
    "EObjXCustomerVehicleRoleKOR.XCustomerVehicleRoleKORpkId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXCustomerVehicleRoleKORResults =
    "EObjXCustomerVehicleRoleKOR.XCustomerVehicleRoleKORpkId," +
    "EObjXCustomerVehicleRoleKOR.CustomerVehicleId," +
    "EObjXCustomerVehicleRoleKOR.VehicleRole," +
    "EObjXCustomerVehicleRoleKOR.StartDate," +
    "EObjXCustomerVehicleRoleKOR.EndDate," +
    "EObjXCustomerVehicleRoleKOR.SourceIdentifier," +
    "EObjXCustomerVehicleRoleKOR.ChangedDate," +
    "EObjXCustomerVehicleRoleKOR.lastUpdateDt," +
    "EObjXCustomerVehicleRoleKOR.lastUpdateUser," +
    "EObjXCustomerVehicleRoleKOR.lastUpdateTxId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getXCustomerVehicleRoleKORHistorySql = "SELECT r.H_XCUSTOMERVEHICLEROLEKORPK_ID hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.XCUSTOMERVEHICLEROLEKORPK_ID XCUSTOMERVEHICLEROLEKORPK_ID, r.CUSTOMER_VEHICLE_ID CUSTOMER_VEHICLE_ID, r.VEHICLE_ROLE_TP_CD VEHICLE_ROLE_TP_CD, r.START_DT START_DT, r.END_DT END_DT, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.CHANGED_DT CHANGED_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XCUSTOMERVEHICLEROLEKOR r WHERE r.H_XCUSTOMERVEHICLEROLEKORPK_ID = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXCustomerVehicleRoleKORHistoryParameters =
    "EObjXCustomerVehicleRoleKOR.XCustomerVehicleRoleKORpkId," +
    "EObjXCustomerVehicleRoleKOR.lastUpdateDt," +
    "EObjXCustomerVehicleRoleKOR.lastUpdateDt";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXCustomerVehicleRoleKORHistoryResults =
    "EObjXCustomerVehicleRoleKOR.historyIdPK," +
    "EObjXCustomerVehicleRoleKOR.histActionCode," +
    "EObjXCustomerVehicleRoleKOR.histCreatedBy," +
    "EObjXCustomerVehicleRoleKOR.histCreateDt," +
    "EObjXCustomerVehicleRoleKOR.histEndDt," +
    "EObjXCustomerVehicleRoleKOR.XCustomerVehicleRoleKORpkId," +
    "EObjXCustomerVehicleRoleKOR.CustomerVehicleId," +
    "EObjXCustomerVehicleRoleKOR.VehicleRole," +
    "EObjXCustomerVehicleRoleKOR.StartDate," +
    "EObjXCustomerVehicleRoleKOR.EndDate," +
    "EObjXCustomerVehicleRoleKOR.SourceIdentifier," +
    "EObjXCustomerVehicleRoleKOR.ChangedDate," +
    "EObjXCustomerVehicleRoleKOR.lastUpdateDt," +
    "EObjXCustomerVehicleRoleKOR.lastUpdateUser," +
    "EObjXCustomerVehicleRoleKOR.lastUpdateTxId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getAllVehicleRoleByCustomerVehicleKORIdSql = "SELECT r.XCUSTOMERVEHICLEROLEKORPK_ID XCUSTOMERVEHICLEROLEKORPK_ID, r.CUSTOMER_VEHICLE_ID CUSTOMER_VEHICLE_ID, r.VEHICLE_ROLE_TP_CD VEHICLE_ROLE_TP_CD, r.START_DT START_DT, r.END_DT END_DT, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.CHANGED_DT CHANGED_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XCUSTOMERVEHICLEROLEKOR r WHERE r.CUSTOMER_VEHICLE_ID = ? ";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getAllVehicleRoleByCustomerVehicleKORIdParameters =
    "EObjXCustomerVehicleRoleKOR.CustomerVehicleId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getAllVehicleRoleByCustomerVehicleKORIdResults =
    "EObjXCustomerVehicleRoleKOR.XCustomerVehicleRoleKORpkId," +
    "EObjXCustomerVehicleRoleKOR.CustomerVehicleId," +
    "EObjXCustomerVehicleRoleKOR.VehicleRole," +
    "EObjXCustomerVehicleRoleKOR.StartDate," +
    "EObjXCustomerVehicleRoleKOR.EndDate," +
    "EObjXCustomerVehicleRoleKOR.SourceIdentifier," +
    "EObjXCustomerVehicleRoleKOR.ChangedDate," +
    "EObjXCustomerVehicleRoleKOR.lastUpdateDt," +
    "EObjXCustomerVehicleRoleKOR.lastUpdateUser," +
    "EObjXCustomerVehicleRoleKOR.lastUpdateTxId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getAllVehicleRoleByCustomerVehicleKORIdHistorySql = "SELECT r.H_XCUSTOMERVEHICLEROLEKORPK_ID hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.XCUSTOMERVEHICLEROLEKORPK_ID XCUSTOMERVEHICLEROLEKORPK_ID, r.CUSTOMER_VEHICLE_ID CUSTOMER_VEHICLE_ID, r.VEHICLE_ROLE_TP_CD VEHICLE_ROLE_TP_CD, r.START_DT START_DT, r.END_DT END_DT, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.CHANGED_DT CHANGED_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XCUSTOMERVEHICLEROLEKOR r WHERE r.CUSTOMER_VEHICLE_ID = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getAllVehicleRoleByCustomerVehicleKORIdHistoryParameters =
    "EObjXCustomerVehicleRoleKOR.CustomerVehicleId," +
    "EObjXCustomerVehicleRoleKOR.lastUpdateDt," +
    "EObjXCustomerVehicleRoleKOR.lastUpdateDt";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getAllVehicleRoleByCustomerVehicleKORIdHistoryResults =
    "EObjXCustomerVehicleRoleKOR.historyIdPK," +
    "EObjXCustomerVehicleRoleKOR.histActionCode," +
    "EObjXCustomerVehicleRoleKOR.histCreatedBy," +
    "EObjXCustomerVehicleRoleKOR.histCreateDt," +
    "EObjXCustomerVehicleRoleKOR.histEndDt," +
    "EObjXCustomerVehicleRoleKOR.XCustomerVehicleRoleKORpkId," +
    "EObjXCustomerVehicleRoleKOR.CustomerVehicleId," +
    "EObjXCustomerVehicleRoleKOR.VehicleRole," +
    "EObjXCustomerVehicleRoleKOR.StartDate," +
    "EObjXCustomerVehicleRoleKOR.EndDate," +
    "EObjXCustomerVehicleRoleKOR.SourceIdentifier," +
    "EObjXCustomerVehicleRoleKOR.ChangedDate," +
    "EObjXCustomerVehicleRoleKOR.lastUpdateDt," +
    "EObjXCustomerVehicleRoleKOR.lastUpdateUser," +
    "EObjXCustomerVehicleRoleKOR.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getXCustomerVehicleRoleKORSql, pattern=tableAliasString)
  @EntityMapping(parameters=getXCustomerVehicleRoleKORParameters, results=getXCustomerVehicleRoleKORResults)
  Iterator<ResultQueue1<EObjXCustomerVehicleRoleKOR>> getXCustomerVehicleRoleKOR(Object[] parameters);  


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getXCustomerVehicleRoleKORHistorySql, pattern=tableAliasString)
  @EntityMapping(parameters=getXCustomerVehicleRoleKORHistoryParameters, results=getXCustomerVehicleRoleKORHistoryResults)
  Iterator<ResultQueue1<EObjXCustomerVehicleRoleKOR>> getXCustomerVehicleRoleKORHistory(Object[] parameters);  


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getAllVehicleRoleByCustomerVehicleKORIdSql, pattern=tableAliasString)
  @EntityMapping(parameters=getAllVehicleRoleByCustomerVehicleKORIdParameters, results=getAllVehicleRoleByCustomerVehicleKORIdResults)
  Iterator<ResultQueue1<EObjXCustomerVehicleRoleKOR>> getAllVehicleRoleByCustomerVehicleKORId(Object[] parameters);  


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getAllVehicleRoleByCustomerVehicleKORIdHistorySql, pattern=tableAliasString)
  @EntityMapping(parameters=getAllVehicleRoleByCustomerVehicleKORIdHistoryParameters, results=getAllVehicleRoleByCustomerVehicleKORIdHistoryResults)
  Iterator<ResultQueue1<EObjXCustomerVehicleRoleKOR>> getAllVehicleRoleByCustomerVehicleKORIdHistory(Object[] parameters);  


}


