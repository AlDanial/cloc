/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[b30a193b559eb15253574642561435c1]
 */


package com.ibm.daimler.dsea.entityObject;

import java.util.Iterator;
import com.ibm.mdm.base.db.EntityMapping;
import com.ibm.pdq.annotation.Select;
import com.ibm.pdq.annotation.Update;

import com.ibm.daimler.dsea.entityObject.EObjXCustomerRetailerJPN;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * @generated
 */
public interface EObjXCustomerRetailerJPNData {


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjXCustomerRetailerJPNSql = "select XCUSTOMERRETAILERJPNPK_ID, CONT_ID, RETAILER_ID, SOURCE_IDENT_TP_CD, START_DT, END_DT, DELETE_FLAG, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from XCUSTOMERRETAILERJPN where XCUSTOMERRETAILERJPNPK_ID = ? ";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String createEObjXCustomerRetailerJPNSql = "insert into XCUSTOMERRETAILERJPN (XCUSTOMERRETAILERJPNPK_ID, CONT_ID, RETAILER_ID, SOURCE_IDENT_TP_CD, START_DT, END_DT, DELETE_FLAG, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( :xCustomerRetailerJPNpkId, :contId, :retailerId, :sourceIdentifier, :startDate, :endDate, :deleteFlag, :lastUpdateDt, :lastUpdateUser, :lastUpdateTxId)";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String updateEObjXCustomerRetailerJPNSql = "update XCUSTOMERRETAILERJPN set CONT_ID = :contId, RETAILER_ID = :retailerId, SOURCE_IDENT_TP_CD = :sourceIdentifier, START_DT = :startDate, END_DT = :endDate, DELETE_FLAG = :deleteFlag, LAST_UPDATE_DT = :lastUpdateDt, LAST_UPDATE_USER = :lastUpdateUser, LAST_UPDATE_TX_ID = :lastUpdateTxId where XCUSTOMERRETAILERJPNPK_ID = :xCustomerRetailerJPNpkId and LAST_UPDATE_DT = :oldLastUpdateDt";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String deleteEObjXCustomerRetailerJPNSql = "delete from XCUSTOMERRETAILERJPN where XCUSTOMERRETAILERJPNPK_ID = ?";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXCustomerRetailerJPNKeyField = "EObjXCustomerRetailerJPN.xCustomerRetailerJPNpkId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXCustomerRetailerJPNGetFields =
    "EObjXCustomerRetailerJPN.xCustomerRetailerJPNpkId," +
    "EObjXCustomerRetailerJPN.contId," +
    "EObjXCustomerRetailerJPN.retailerId," +
    "EObjXCustomerRetailerJPN.sourceIdentifier," +
    "EObjXCustomerRetailerJPN.startDate," +
    "EObjXCustomerRetailerJPN.endDate," +
    "EObjXCustomerRetailerJPN.deleteFlag," +
    "EObjXCustomerRetailerJPN.lastUpdateDt," +
    "EObjXCustomerRetailerJPN.lastUpdateUser," +
    "EObjXCustomerRetailerJPN.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXCustomerRetailerJPNAllFields =
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerRetailerJPN.xCustomerRetailerJPNpkId," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerRetailerJPN.contId," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerRetailerJPN.retailerId," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerRetailerJPN.sourceIdentifier," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerRetailerJPN.startDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerRetailerJPN.endDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerRetailerJPN.deleteFlag," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerRetailerJPN.lastUpdateDt," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerRetailerJPN.lastUpdateUser," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerRetailerJPN.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXCustomerRetailerJPNUpdateFields =
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerRetailerJPN.contId," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerRetailerJPN.retailerId," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerRetailerJPN.sourceIdentifier," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerRetailerJPN.startDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerRetailerJPN.endDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerRetailerJPN.deleteFlag," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerRetailerJPN.lastUpdateDt," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerRetailerJPN.lastUpdateUser," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerRetailerJPN.lastUpdateTxId," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerRetailerJPN.xCustomerRetailerJPNpkId," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerRetailerJPN.oldLastUpdateDt";   

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Select XCustomerRetailerJPN by parameters.
   * @generated
   */
  @Select(sql=getEObjXCustomerRetailerJPNSql)
  @EntityMapping(parameters=EObjXCustomerRetailerJPNKeyField, results=EObjXCustomerRetailerJPNGetFields)
  Iterator<EObjXCustomerRetailerJPN> getEObjXCustomerRetailerJPN(Long xCustomerRetailerJPNpkId);  
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Create XCustomerRetailerJPN by EObjXCustomerRetailerJPN Object.
   * @generated
   */
  @Update(sql=createEObjXCustomerRetailerJPNSql)
  @EntityMapping(parameters=EObjXCustomerRetailerJPNAllFields)
    int createEObjXCustomerRetailerJPN(EObjXCustomerRetailerJPN e); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Update one XCustomerRetailerJPN by EObjXCustomerRetailerJPN object.
   * @generated
   */
  @Update(sql=updateEObjXCustomerRetailerJPNSql)
  @EntityMapping(parameters=EObjXCustomerRetailerJPNUpdateFields)
    int updateEObjXCustomerRetailerJPN(EObjXCustomerRetailerJPN e); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Delete XCustomerRetailerJPN by parameters.
   * @generated
   */
  @Update(sql=deleteEObjXCustomerRetailerJPNSql)
  @EntityMapping(parameters=EObjXCustomerRetailerJPNKeyField)
  int deleteEObjXCustomerRetailerJPN(Long xCustomerRetailerJPNpkId);

}

