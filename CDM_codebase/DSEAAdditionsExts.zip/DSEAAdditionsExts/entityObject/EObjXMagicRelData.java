/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[ae957ab5cc70bf03c7537236dfc12426]
 */


package com.ibm.daimler.dsea.entityObject;

import java.util.Iterator;
import com.ibm.mdm.base.db.EntityMapping;
import com.ibm.pdq.annotation.Select;
import com.ibm.pdq.annotation.Update;

import com.ibm.daimler.dsea.entityObject.EObjXMagicRel;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * @generated
 */
public interface EObjXMagicRelData {


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjXMagicRelSql = "select XMagic_Relpk_Id, UCID, Golden_Magic, Old_Magic, Old_Magic_Retailer, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from XMAGICREL where XMagic_Relpk_Id = ? ";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String createEObjXMagicRelSql = "insert into XMAGICREL (XMagic_Relpk_Id, UCID, Golden_Magic, Old_Magic, Old_Magic_Retailer, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( :xMagicRelpkId, :uCID, :goldenMagic, :oldMagic, :oldMagicRetailer, :lastUpdateDt, :lastUpdateUser, :lastUpdateTxId)";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String updateEObjXMagicRelSql = "update XMAGICREL set UCID = :uCID, Golden_Magic = :goldenMagic, Old_Magic = :oldMagic, Old_Magic_Retailer = :oldMagicRetailer, LAST_UPDATE_DT = :lastUpdateDt, LAST_UPDATE_USER = :lastUpdateUser, LAST_UPDATE_TX_ID = :lastUpdateTxId where XMagic_Relpk_Id = :xMagicRelpkId and LAST_UPDATE_DT = :oldLastUpdateDt";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String deleteEObjXMagicRelSql = "delete from XMAGICREL where XMagic_Relpk_Id = ?";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXMagicRelKeyField = "EObjXMagicRel.xMagicRelpkId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXMagicRelGetFields =
    "EObjXMagicRel.xMagicRelpkId," +
    "EObjXMagicRel.uCID," +
    "EObjXMagicRel.goldenMagic," +
    "EObjXMagicRel.oldMagic," +
    "EObjXMagicRel.oldMagicRetailer," +
    "EObjXMagicRel.lastUpdateDt," +
    "EObjXMagicRel.lastUpdateUser," +
    "EObjXMagicRel.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXMagicRelAllFields =
    "com.ibm.daimler.dsea.entityObject.EObjXMagicRel.xMagicRelpkId," +
    "com.ibm.daimler.dsea.entityObject.EObjXMagicRel.uCID," +
    "com.ibm.daimler.dsea.entityObject.EObjXMagicRel.goldenMagic," +
    "com.ibm.daimler.dsea.entityObject.EObjXMagicRel.oldMagic," +
    "com.ibm.daimler.dsea.entityObject.EObjXMagicRel.oldMagicRetailer," +
    "com.ibm.daimler.dsea.entityObject.EObjXMagicRel.lastUpdateDt," +
    "com.ibm.daimler.dsea.entityObject.EObjXMagicRel.lastUpdateUser," +
    "com.ibm.daimler.dsea.entityObject.EObjXMagicRel.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXMagicRelUpdateFields =
    "com.ibm.daimler.dsea.entityObject.EObjXMagicRel.uCID," +
    "com.ibm.daimler.dsea.entityObject.EObjXMagicRel.goldenMagic," +
    "com.ibm.daimler.dsea.entityObject.EObjXMagicRel.oldMagic," +
    "com.ibm.daimler.dsea.entityObject.EObjXMagicRel.oldMagicRetailer," +
    "com.ibm.daimler.dsea.entityObject.EObjXMagicRel.lastUpdateDt," +
    "com.ibm.daimler.dsea.entityObject.EObjXMagicRel.lastUpdateUser," +
    "com.ibm.daimler.dsea.entityObject.EObjXMagicRel.lastUpdateTxId," +
    "com.ibm.daimler.dsea.entityObject.EObjXMagicRel.xMagicRelpkId," +
    "com.ibm.daimler.dsea.entityObject.EObjXMagicRel.oldLastUpdateDt";   

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Select XMagicRel by parameters.
   * @generated
   */
  @Select(sql=getEObjXMagicRelSql)
  @EntityMapping(parameters=EObjXMagicRelKeyField, results=EObjXMagicRelGetFields)
  Iterator<EObjXMagicRel> getEObjXMagicRel(Long xMagicRelpkId);  
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Create XMagicRel by EObjXMagicRel Object.
   * @generated
   */
  @Update(sql=createEObjXMagicRelSql)
  @EntityMapping(parameters=EObjXMagicRelAllFields)
    int createEObjXMagicRel(EObjXMagicRel e); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Update one XMagicRel by EObjXMagicRel object.
   * @generated
   */
  @Update(sql=updateEObjXMagicRelSql)
  @EntityMapping(parameters=EObjXMagicRelUpdateFields)
    int updateEObjXMagicRel(EObjXMagicRel e); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Delete XMagicRel by parameters.
   * @generated
   */
  @Update(sql=deleteEObjXMagicRelSql)
  @EntityMapping(parameters=EObjXMagicRelKeyField)
  int deleteEObjXMagicRel(Long xMagicRelpkId);

}

