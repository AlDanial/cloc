/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[75814a8563485b542ed41a9f4001536f]
 */


package com.ibm.daimler.dsea.entityObject;

import java.util.Iterator;
import com.ibm.mdm.base.db.EntityMapping;
import com.ibm.pdq.annotation.Select;
import com.ibm.pdq.annotation.Update;

import com.dwl.tcrm.coreParty.entityObject.EObjIdentifier;

import com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * @generated
 */
public interface EObjXIdentifierExtData {


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjXIdentifierExtSql = "select XMODIFY_SYS_DT, XRETAILER_ID, XIDEN_RETAILER_FLAG, X_BPID, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from IDENTIFIER where IDENTIFIER_ID = ? ";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String createEObjXIdentifierExtSql = "insert into IDENTIFIER (REF_NUM, LAST_VERIFIED_DT, IDENTIFIER_ID, CONT_ID, START_DT, END_DT, EXPIRY_DT, IDENTIFIER_DESC, ASSIGNED_BY, ISSUE_LOCATION, LAST_USED_DT, ID_STATUS_TP_CD, ID_TP_CD, SOURCE_IDENT_TP_CD, XMODIFY_SYS_DT, XRETAILER_ID, XIDEN_RETAILER_FLAG, X_BPID, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( ?1.refNum, ?1.lastVerifiedDt, ?1.identifierIdPK, ?1.contId, ?1.startDt, ?1.endDt, ?1.expiryDt, ?1.identifierDesc, ?1.assignedBy, ?1.issueLocation, ?1.lastUsedDt, ?1.idStatusTpCd, ?1.idTpCd, ?1.sourceIdentTpCd, ?2.xLastModifiedSystemDate, ?2.xRetailerId, ?2.xIdentifierRetailerFlag, ?2.x_BPID, ?1.lastUpdateDt, ?1.lastUpdateUser, ?1.lastUpdateTxId)";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String updateEObjXIdentifierExtSql = "update IDENTIFIER set REF_NUM = ?1.refNum, LAST_VERIFIED_DT = ?1.lastVerifiedDt, CONT_ID = ?1.contId, START_DT = ?1.startDt, END_DT = ?1.endDt, EXPIRY_DT = ?1.expiryDt, IDENTIFIER_DESC = ?1.identifierDesc, ASSIGNED_BY = ?1.assignedBy, ISSUE_LOCATION = ?1.issueLocation, LAST_USED_DT = ?1.lastUsedDt, ID_STATUS_TP_CD = ?1.idStatusTpCd, ID_TP_CD = ?1.idTpCd, SOURCE_IDENT_TP_CD = ?1.sourceIdentTpCd, XMODIFY_SYS_DT = ?2.xLastModifiedSystemDate, XRETAILER_ID = ?2.xRetailerId, XIDEN_RETAILER_FLAG = ?2.xIdentifierRetailerFlag, X_BPID = ?2.x_BPID, LAST_UPDATE_DT = ?1.lastUpdateDt, LAST_UPDATE_USER = ?1.lastUpdateUser, LAST_UPDATE_TX_ID = ?1.lastUpdateTxId where IDENTIFIER_ID = ?1.identifierIdPK and LAST_UPDATE_DT = ?1.oldLastUpdateDt";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String deleteEObjXIdentifierExtSql = "delete from IDENTIFIER where IDENTIFIER_ID = ?";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXIdentifierExtKeyField = "EObjXIdentifierExt.identifierIdPK";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXIdentifierExtGetFields =
    "EObjXIdentifierExt.xLastModifiedSystemDate," +
    "EObjXIdentifierExt.xRetailerId," +
    "EObjXIdentifierExt.xIdentifierRetailerFlag," +
    "EObjXIdentifierExt.x_BPID," +
    "EObjXIdentifierExt.lastUpdateDt," +
    "EObjXIdentifierExt.lastUpdateUser," +
    "EObjXIdentifierExt.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXIdentifierExtAllFields =
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.refNum," +
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.lastVerifiedDt," +
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.identifierIdPK," +
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.contId," +
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.startDt," +
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.endDt," +
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.expiryDt," +
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.identifierDesc," +
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.assignedBy," +
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.issueLocation," +
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.lastUsedDt," +
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.idStatusTpCd," +
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.idTpCd," +
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.sourceIdentTpCd," +
    "com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt.xLastModifiedSystemDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt.xRetailerId," +
    "com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt.xIdentifierRetailerFlag," +
    "com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt.x_BPID," +
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.lastUpdateDt," +
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.lastUpdateUser," +
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXIdentifierExtUpdateFields =
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.refNum," +
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.lastVerifiedDt," +
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.contId," +
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.startDt," +
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.endDt," +
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.expiryDt," +
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.identifierDesc," +
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.assignedBy," +
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.issueLocation," +
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.lastUsedDt," +
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.idStatusTpCd," +
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.idTpCd," +
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.sourceIdentTpCd," +
    "com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt.xLastModifiedSystemDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt.xRetailerId," +
    "com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt.xIdentifierRetailerFlag," +
    "com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt.x_BPID," +
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.lastUpdateDt," +
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.lastUpdateUser," +
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.lastUpdateTxId," +
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.identifierIdPK," +
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.oldLastUpdateDt";   

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Select XIdentifier by parameters.
   * @generated
   */
  @Select(sql=getEObjXIdentifierExtSql)
  @EntityMapping(parameters=EObjXIdentifierExtKeyField, results=EObjXIdentifierExtGetFields)
  Iterator<EObjXIdentifierExt> getEObjXIdentifierExt(Long identifierIdPK);  
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Create XIdentifier by EObjXIdentifierExt Object.
   * @generated
   */
  @Update(sql=createEObjXIdentifierExtSql)
  @EntityMapping(parameters=EObjXIdentifierExtAllFields)
    int createEObjXIdentifierExt(EObjIdentifier e1, EObjXIdentifierExt e2); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Update one XIdentifier by EObjXIdentifierExt object.
   * @generated
   */
  @Update(sql=updateEObjXIdentifierExtSql)
  @EntityMapping(parameters=EObjXIdentifierExtUpdateFields)
    int updateEObjXIdentifierExt(EObjIdentifier e1, EObjXIdentifierExt e2); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Delete XIdentifier by parameters.
   * @generated
   */
  @Update(sql=deleteEObjXIdentifierExtSql)
  @EntityMapping(parameters=EObjXIdentifierExtKeyField)
  int deleteEObjXIdentifierExt(Long identifierIdPK);

}

