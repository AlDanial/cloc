package com.ibm.daimler.dsea.entityObject;

import com.ibm.pdq.runtime.generator.BaseParameterHandler;
import java.util.Iterator;
import java.sql.PreparedStatement;
import com.ibm.pdq.runtime.statement.StatementDescriptor;
import com.ibm.pdq.runtime.generator.BaseData;
import java.sql.SQLException;
import com.ibm.pdq.annotation.Metadata;
import com.ibm.daimler.dsea.entityObject.EObjXConsent;
import com.ibm.pdq.runtime.generator.BaseRowHandler;
import com.ibm.pdq.runtime.statement.SqlStatementType;
import java.sql.Types;


/**
 * <!-- begin-user-doc -->
 * 
 * <!-- end-user-doc -->
 * 
 * @generated
 */
public class EObjXConsentDataImpl  extends BaseData implements EObjXConsentData
{

  /**
   * @generated
   */
  public static final String generatorVersion = "3.200.75";

  /**
   * @generated
   */
  public static final String identifier = "EObjXConsentData";

  /**
   * @generated
   */
  public static final long generationTime = 0x000001635e65f8adL;

  /**
   * @generated
   */
  public static final String collection = "NULLID";

  /**
   * @generated
   */
  public static final String packageVersion = null;

  /**
   * @generated
   */
  public static final boolean forceSingleBindIsolation = false;

  /**
   * @generated
   */
  public EObjXConsentDataImpl()
  {
    super();
  } 

  /**
   * @generated
   */
  public String getGeneratorVersion()
  {
    return generatorVersion;
  }

  /**
   * @Select( sql="select XConsentpk_Id, CONT_ID, COMM_CHANNNEL, CONSENT_ACTION_TP_CD, SOURCE_IDENT_TP_CD, RETAILER_ID, Retailer_Flag, LAST_MODIFIED_SYSTEM_DT, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from XCONSENT where XConsentpk_Id = ? " )
   * 
   * @generated
   */
  public Iterator<EObjXConsent> getEObjXConsent (Long xConsentpkId)
  {
    return queryIterator (getEObjXConsentStatementDescriptor, xConsentpkId);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getEObjXConsentStatementDescriptor = createStatementDescriptor (
    "getEObjXConsent(Long)",
    "select XConsentpk_Id, CONT_ID, COMM_CHANNNEL, CONSENT_ACTION_TP_CD, SOURCE_IDENT_TP_CD, RETAILER_ID, Retailer_Flag, LAST_MODIFIED_SYSTEM_DT, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from XCONSENT where XConsentpk_Id = ? ",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"xconsentpk_id", "cont_id", "comm_channnel", "consent_action_tp_cd", "source_ident_tp_cd", "retailer_id", "retailer_flag", "last_modified_system_dt", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetEObjXConsentParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetEObjXConsentRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 19, 50, 19, 19, 19, 5, 0, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    1);

  /**
   * @generated
   */
  public static class GetEObjXConsentParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setLong (stmt, 1, Types.BIGINT, (Long)parameters[0]);
    }
  }

  /**
   * @generated
   */
  public static class GetEObjXConsentRowHandler extends BaseRowHandler<EObjXConsent>
  {
    /**
     * @generated
     */
    public EObjXConsent handle (java.sql.ResultSet rs, EObjXConsent returnObject) throws java.sql.SQLException
    {
      returnObject = new EObjXConsent ();
      returnObject.setXConsentpkId(getLongObject (rs, 1)); 
      returnObject.setContId(getLongObject (rs, 2)); 
      returnObject.setCommunicationChannel(getString (rs, 3)); 
      returnObject.setConsentAction(getLongObject (rs, 4)); 
      returnObject.setSourceIdentifier(getLongObject (rs, 5)); 
      returnObject.setRetailerId(getLongObject (rs, 6)); 
      returnObject.setRetailerFlag(getString (rs, 7)); 
      returnObject.setLastModifiedSystemDate(getTimestamp (rs, 8)); 
      returnObject.setLastUpdateDt(getTimestamp (rs, 9)); 
      returnObject.setLastUpdateUser(getString (rs, 10)); 
      returnObject.setLastUpdateTxId(getLongObject (rs, 11)); 
    
      return returnObject;
    }
  }

  /**
   * @Update( sql="insert into XCONSENT (XConsentpk_Id, CONT_ID, COMM_CHANNNEL, CONSENT_ACTION_TP_CD, SOURCE_IDENT_TP_CD, RETAILER_ID, Retailer_Flag, LAST_MODIFIED_SYSTEM_DT, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( :xConsentpkId, :contId, :communicationChannel, :consentAction, :sourceIdentifier, :retailerId, :retailerFlag, :lastModifiedSystemDate, :lastUpdateDt, :lastUpdateUser, :lastUpdateTxId)" )
   * 
   * @generated
   */
  public int createEObjXConsent (EObjXConsent e)
  {
    return update (createEObjXConsentStatementDescriptor, e);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor createEObjXConsentStatementDescriptor = createStatementDescriptor (
    "createEObjXConsent(com.ibm.daimler.dsea.entityObject.EObjXConsent)",
    "insert into XCONSENT (XConsentpk_Id, CONT_ID, COMM_CHANNNEL, CONSENT_ACTION_TP_CD, SOURCE_IDENT_TP_CD, RETAILER_ID, Retailer_Flag, LAST_MODIFIED_SYSTEM_DT, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values(  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? )",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.INSERT,
    null,
    new CreateEObjXConsentParameterHandler (),
    new int[][]{{Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 19, 50, 19, 19, 19, 5, 0, 0, 0, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    2);

  /**
   * @generated
   */
  public static class CreateEObjXConsentParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      EObjXConsent bean0 = (EObjXConsent) parameters[0];
      setLong (stmt, 1, Types.BIGINT, (Long)bean0.getXConsentpkId());
      setLong (stmt, 2, Types.BIGINT, (Long)bean0.getContId());
      setString (stmt, 3, Types.VARCHAR, (String)bean0.getCommunicationChannel());
      setLong (stmt, 4, Types.BIGINT, (Long)bean0.getConsentAction());
      setLong (stmt, 5, Types.BIGINT, (Long)bean0.getSourceIdentifier());
      setLong (stmt, 6, Types.BIGINT, (Long)bean0.getRetailerId());
      setString (stmt, 7, Types.VARCHAR, (String)bean0.getRetailerFlag());
      setTimestamp (stmt, 8, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastModifiedSystemDate());
      setTimestamp (stmt, 9, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUpdateDt());
      setString (stmt, 10, Types.VARCHAR, (String)bean0.getLastUpdateUser());
      setLong (stmt, 11, Types.BIGINT, (Long)bean0.getLastUpdateTxId());
    }
  }

  /**
   * @Update( sql="update XCONSENT set CONT_ID = :contId, COMM_CHANNNEL = :communicationChannel, CONSENT_ACTION_TP_CD = :consentAction, SOURCE_IDENT_TP_CD = :sourceIdentifier, RETAILER_ID = :retailerId, Retailer_Flag = :retailerFlag, LAST_MODIFIED_SYSTEM_DT = :lastModifiedSystemDate, LAST_UPDATE_DT = :lastUpdateDt, LAST_UPDATE_USER = :lastUpdateUser, LAST_UPDATE_TX_ID = :lastUpdateTxId where XConsentpk_Id = :xConsentpkId and LAST_UPDATE_DT = :oldLastUpdateDt" )
   * 
   * @generated
   */
  public int updateEObjXConsent (EObjXConsent e)
  {
    return update (updateEObjXConsentStatementDescriptor, e);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor updateEObjXConsentStatementDescriptor = createStatementDescriptor (
    "updateEObjXConsent(com.ibm.daimler.dsea.entityObject.EObjXConsent)",
    "update XCONSENT set CONT_ID =  ? , COMM_CHANNNEL =  ? , CONSENT_ACTION_TP_CD =  ? , SOURCE_IDENT_TP_CD =  ? , RETAILER_ID =  ? , Retailer_Flag =  ? , LAST_MODIFIED_SYSTEM_DT =  ? , LAST_UPDATE_DT =  ? , LAST_UPDATE_USER =  ? , LAST_UPDATE_TX_ID =  ?  where XConsentpk_Id =  ?  and LAST_UPDATE_DT =  ? ",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.UPDATE,
    null,
    new UpdateEObjXConsentParameterHandler (),
    new int[][]{{Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP}, {19, 50, 19, 19, 19, 5, 0, 0, 0, 19, 19, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    3);

  /**
   * @generated
   */
  public static class UpdateEObjXConsentParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      EObjXConsent bean0 = (EObjXConsent) parameters[0];
      setLong (stmt, 1, Types.BIGINT, (Long)bean0.getContId());
      setString (stmt, 2, Types.VARCHAR, (String)bean0.getCommunicationChannel());
      setLong (stmt, 3, Types.BIGINT, (Long)bean0.getConsentAction());
      setLong (stmt, 4, Types.BIGINT, (Long)bean0.getSourceIdentifier());
      setLong (stmt, 5, Types.BIGINT, (Long)bean0.getRetailerId());
      setString (stmt, 6, Types.VARCHAR, (String)bean0.getRetailerFlag());
      setTimestamp (stmt, 7, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastModifiedSystemDate());
      setTimestamp (stmt, 8, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUpdateDt());
      setString (stmt, 9, Types.VARCHAR, (String)bean0.getLastUpdateUser());
      setLong (stmt, 10, Types.BIGINT, (Long)bean0.getLastUpdateTxId());
      setLong (stmt, 11, Types.BIGINT, (Long)bean0.getXConsentpkId());
      setTimestamp (stmt, 12, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getOldLastUpdateDt());
    }
  }

  /**
   * @Update( sql="delete from XCONSENT where XConsentpk_Id = ?" )
   * 
   * @generated
   */
  public int deleteEObjXConsent (Long xConsentpkId)
  {
    return update (deleteEObjXConsentStatementDescriptor, xConsentpkId);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor deleteEObjXConsentStatementDescriptor = createStatementDescriptor (
    "deleteEObjXConsent(Long)",
    "delete from XCONSENT where XConsentpk_Id = ?",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.DELETE,
    null,
    new DeleteEObjXConsentParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    4);

  /**
   * @generated
   */
  public static class DeleteEObjXConsentParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setLong (stmt, 1, Types.BIGINT, (Long)parameters[0]);
    }
  }

}
