package com.ibm.daimler.dsea.entityObject;

import com.ibm.pdq.runtime.generator.BaseParameterHandler;
import java.util.Iterator;
import java.sql.PreparedStatement;
import com.ibm.pdq.runtime.statement.StatementDescriptor;
import com.ibm.pdq.runtime.generator.BaseData;
import java.sql.SQLException;
import com.ibm.pdq.annotation.Metadata;
import com.ibm.daimler.dsea.entityObject.EObjXGurantorCompany;
import com.ibm.pdq.runtime.generator.BaseRowHandler;
import com.ibm.pdq.runtime.statement.SqlStatementType;
import java.sql.Types;


/**
 * <!-- begin-user-doc -->
 * 
 * <!-- end-user-doc -->
 * 
 * @generated
 */
public class EObjXGurantorCompanyDataImpl  extends BaseData implements EObjXGurantorCompanyData
{

  /**
   * @generated
   */
  public static final String generatorVersion = "3.200.75";

  /**
   * @generated
   */
  public static final String identifier = "EObjXGurantorCompanyData";

  /**
   * @generated
   */
  public static final long generationTime = 0x00000161d1eb2f86L;

  /**
   * @generated
   */
  public static final String collection = "NULLID";

  /**
   * @generated
   */
  public static final String packageVersion = null;

  /**
   * @generated
   */
  public static final boolean forceSingleBindIsolation = false;

  /**
   * @generated
   */
  public EObjXGurantorCompanyDataImpl()
  {
    super();
  } 

  /**
   * @generated
   */
  public String getGeneratorVersion()
  {
    return generatorVersion;
  }

  /**
   * @Select( sql="select XGurantor_Companypk_Id, CONTRACT_DETAILS_ID, BPID, CAN_NUMBER, INDUSTRY_TP_CD, COMPANY_NAME, COMPANY_NAME_LOCAL, ADDR_USAGE_TP_CD, ADDR_LINE_ONE, ADDR_LINE_TWO, ADDR_LINE_THREE, POSTAL_CODE, CITY_NAME, RESIDENCE_NUMBER, COUNTRY_TP_CD, BUILDING_NAME, STREET_NAME, STREET_NUMBER, MOBILE_NUMBER, HOME_PHONE_NUMBER, WORK_PHONE_NUMBER, WORK_PHONE_NUMBER_EXT, FAX, EMAIL, SOURCE_IDENT_TP_CD, START_DT, END_DT, MODIFY_SYS_DT, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from XGURANTORCOMPANY where XGurantor_Companypk_Id = ? " )
   * 
   * @generated
   */
  public Iterator<EObjXGurantorCompany> getEObjXGurantorCompany (Long xGurantorCompanypkId)
  {
    return queryIterator (getEObjXGurantorCompanyStatementDescriptor, xGurantorCompanypkId);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getEObjXGurantorCompanyStatementDescriptor = createStatementDescriptor (
    "getEObjXGurantorCompany(Long)",
    "select XGurantor_Companypk_Id, CONTRACT_DETAILS_ID, BPID, CAN_NUMBER, INDUSTRY_TP_CD, COMPANY_NAME, COMPANY_NAME_LOCAL, ADDR_USAGE_TP_CD, ADDR_LINE_ONE, ADDR_LINE_TWO, ADDR_LINE_THREE, POSTAL_CODE, CITY_NAME, RESIDENCE_NUMBER, COUNTRY_TP_CD, BUILDING_NAME, STREET_NAME, STREET_NUMBER, MOBILE_NUMBER, HOME_PHONE_NUMBER, WORK_PHONE_NUMBER, WORK_PHONE_NUMBER_EXT, FAX, EMAIL, SOURCE_IDENT_TP_CD, START_DT, END_DT, MODIFY_SYS_DT, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from XGURANTORCOMPANY where XGurantor_Companypk_Id = ? ",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"xgurantor_companypk_id", "contract_details_id", "bpid", "can_number", "industry_tp_cd", "company_name", "company_name_local", "addr_usage_tp_cd", "addr_line_one", "addr_line_two", "addr_line_three", "postal_code", "city_name", "residence_number", "country_tp_cd", "building_name", "street_name", "street_number", "mobile_number", "home_phone_number", "work_phone_number", "work_phone_number_ext", "fax", "email", "source_ident_tp_cd", "start_dt", "end_dt", "modify_sys_dt", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetEObjXGurantorCompanyParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetEObjXGurantorCompanyRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 19, 500, 500, 19, 500, 500, 19, 500, 500, 500, 250, 250, 250, 19, 250, 250, 250, 250, 250, 250, 250, 250, 250, 19, 0, 0, 0, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    1);

  /**
   * @generated
   */
  public static class GetEObjXGurantorCompanyParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setLong (stmt, 1, Types.BIGINT, (Long)parameters[0]);
    }
  }

  /**
   * @generated
   */
  public static class GetEObjXGurantorCompanyRowHandler extends BaseRowHandler<EObjXGurantorCompany>
  {
    /**
     * @generated
     */
    public EObjXGurantorCompany handle (java.sql.ResultSet rs, EObjXGurantorCompany returnObject) throws java.sql.SQLException
    {
      returnObject = new EObjXGurantorCompany ();
      returnObject.setXGurantorCompanypkId(getLongObject (rs, 1)); 
      returnObject.setContractDetailsId(getLongObject (rs, 2)); 
      returnObject.setBPID(getString (rs, 3)); 
      returnObject.setCANNumber(getString (rs, 4)); 
      returnObject.setIndustry(getLongObject (rs, 5)); 
      returnObject.setCompanyName(getString (rs, 6)); 
      returnObject.setCompanyNameLocal(getString (rs, 7)); 
      returnObject.setAddressUsage(getLongObject (rs, 8)); 
      returnObject.setAddressLineOne(getString (rs, 9)); 
      returnObject.setAddressLineTwo(getString (rs, 10)); 
      returnObject.setAddressLineThree(getString (rs, 11)); 
      returnObject.setPostalCode(getString (rs, 12)); 
      returnObject.setCityName(getString (rs, 13)); 
      returnObject.setResidenceNumber(getString (rs, 14)); 
      returnObject.setCountry(getLongObject (rs, 15)); 
      returnObject.setBuildingName(getString (rs, 16)); 
      returnObject.setStreetName(getString (rs, 17)); 
      returnObject.setStreetNumber(getString (rs, 18)); 
      returnObject.setMobileNumber(getString (rs, 19)); 
      returnObject.setHomePhoneNumber(getString (rs, 20)); 
      returnObject.setWorkPhoneNumber(getString (rs, 21)); 
      returnObject.setWorkPhoneNumberExtension(getString (rs, 22)); 
      returnObject.setFax(getString (rs, 23)); 
      returnObject.setEmail(getString (rs, 24)); 
      returnObject.setSourceIdentifier(getLongObject (rs, 25)); 
      returnObject.setStartDate(getTimestamp (rs, 26)); 
      returnObject.setEndDate(getTimestamp (rs, 27)); 
      returnObject.setLastModifiedSystemDate(getTimestamp (rs, 28)); 
      returnObject.setLastUpdateDt(getTimestamp (rs, 29)); 
      returnObject.setLastUpdateUser(getString (rs, 30)); 
      returnObject.setLastUpdateTxId(getLongObject (rs, 31)); 
    
      return returnObject;
    }
  }

  /**
   * @Update( sql="insert into XGURANTORCOMPANY (XGurantor_Companypk_Id, CONTRACT_DETAILS_ID, BPID, CAN_NUMBER, INDUSTRY_TP_CD, COMPANY_NAME, COMPANY_NAME_LOCAL, ADDR_USAGE_TP_CD, ADDR_LINE_ONE, ADDR_LINE_TWO, ADDR_LINE_THREE, POSTAL_CODE, CITY_NAME, RESIDENCE_NUMBER, COUNTRY_TP_CD, BUILDING_NAME, STREET_NAME, STREET_NUMBER, MOBILE_NUMBER, HOME_PHONE_NUMBER, WORK_PHONE_NUMBER, WORK_PHONE_NUMBER_EXT, FAX, EMAIL, SOURCE_IDENT_TP_CD, START_DT, END_DT, MODIFY_SYS_DT, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( :xGurantorCompanypkId, :contractDetailsId, :bPID, :cANNumber, :industry, :companyName, :companyNameLocal, :addressUsage, :addressLineOne, :addressLineTwo, :addressLineThree, :postalCode, :cityName, :residenceNumber, :country, :buildingName, :streetName, :streetNumber, :mobileNumber, :homePhoneNumber, :workPhoneNumber, :workPhoneNumberExtension, :fax, :email, :sourceIdentifier, :startDate, :endDate, :lastModifiedSystemDate, :lastUpdateDt, :lastUpdateUser, :lastUpdateTxId)" )
   * 
   * @generated
   */
  public int createEObjXGurantorCompany (EObjXGurantorCompany e)
  {
    return update (createEObjXGurantorCompanyStatementDescriptor, e);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor createEObjXGurantorCompanyStatementDescriptor = createStatementDescriptor (
    "createEObjXGurantorCompany(com.ibm.daimler.dsea.entityObject.EObjXGurantorCompany)",
    "insert into XGURANTORCOMPANY (XGurantor_Companypk_Id, CONTRACT_DETAILS_ID, BPID, CAN_NUMBER, INDUSTRY_TP_CD, COMPANY_NAME, COMPANY_NAME_LOCAL, ADDR_USAGE_TP_CD, ADDR_LINE_ONE, ADDR_LINE_TWO, ADDR_LINE_THREE, POSTAL_CODE, CITY_NAME, RESIDENCE_NUMBER, COUNTRY_TP_CD, BUILDING_NAME, STREET_NAME, STREET_NUMBER, MOBILE_NUMBER, HOME_PHONE_NUMBER, WORK_PHONE_NUMBER, WORK_PHONE_NUMBER_EXT, FAX, EMAIL, SOURCE_IDENT_TP_CD, START_DT, END_DT, MODIFY_SYS_DT, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values(  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? )",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.INSERT,
    null,
    new CreateEObjXGurantorCompanyParameterHandler (),
    new int[][]{{Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 19, 500, 500, 19, 500, 500, 19, 500, 500, 500, 250, 250, 250, 19, 250, 250, 250, 250, 250, 250, 250, 250, 250, 19, 0, 0, 0, 0, 0, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    2);

  /**
   * @generated
   */
  public static class CreateEObjXGurantorCompanyParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      EObjXGurantorCompany bean0 = (EObjXGurantorCompany) parameters[0];
      setLong (stmt, 1, Types.BIGINT, (Long)bean0.getXGurantorCompanypkId());
      setLong (stmt, 2, Types.BIGINT, (Long)bean0.getContractDetailsId());
      setString (stmt, 3, Types.VARCHAR, (String)bean0.getBPID());
      setString (stmt, 4, Types.VARCHAR, (String)bean0.getCANNumber());
      setLong (stmt, 5, Types.BIGINT, (Long)bean0.getIndustry());
      setString (stmt, 6, Types.VARCHAR, (String)bean0.getCompanyName());
      setString (stmt, 7, Types.VARCHAR, (String)bean0.getCompanyNameLocal());
      setLong (stmt, 8, Types.BIGINT, (Long)bean0.getAddressUsage());
      setString (stmt, 9, Types.VARCHAR, (String)bean0.getAddressLineOne());
      setString (stmt, 10, Types.VARCHAR, (String)bean0.getAddressLineTwo());
      setString (stmt, 11, Types.VARCHAR, (String)bean0.getAddressLineThree());
      setString (stmt, 12, Types.VARCHAR, (String)bean0.getPostalCode());
      setString (stmt, 13, Types.VARCHAR, (String)bean0.getCityName());
      setString (stmt, 14, Types.VARCHAR, (String)bean0.getResidenceNumber());
      setLong (stmt, 15, Types.BIGINT, (Long)bean0.getCountry());
      setString (stmt, 16, Types.VARCHAR, (String)bean0.getBuildingName());
      setString (stmt, 17, Types.VARCHAR, (String)bean0.getStreetName());
      setString (stmt, 18, Types.VARCHAR, (String)bean0.getStreetNumber());
      setString (stmt, 19, Types.VARCHAR, (String)bean0.getMobileNumber());
      setString (stmt, 20, Types.VARCHAR, (String)bean0.getHomePhoneNumber());
      setString (stmt, 21, Types.VARCHAR, (String)bean0.getWorkPhoneNumber());
      setString (stmt, 22, Types.VARCHAR, (String)bean0.getWorkPhoneNumberExtension());
      setString (stmt, 23, Types.VARCHAR, (String)bean0.getFax());
      setString (stmt, 24, Types.VARCHAR, (String)bean0.getEmail());
      setLong (stmt, 25, Types.BIGINT, (Long)bean0.getSourceIdentifier());
      setTimestamp (stmt, 26, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getStartDate());
      setTimestamp (stmt, 27, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getEndDate());
      setTimestamp (stmt, 28, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastModifiedSystemDate());
      setTimestamp (stmt, 29, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUpdateDt());
      setString (stmt, 30, Types.VARCHAR, (String)bean0.getLastUpdateUser());
      setLong (stmt, 31, Types.BIGINT, (Long)bean0.getLastUpdateTxId());
    }
  }

  /**
   * @Update( sql="update XGURANTORCOMPANY set CONTRACT_DETAILS_ID = :contractDetailsId, BPID = :bPID, CAN_NUMBER = :cANNumber, INDUSTRY_TP_CD = :industry, COMPANY_NAME = :companyName, COMPANY_NAME_LOCAL = :companyNameLocal, ADDR_USAGE_TP_CD = :addressUsage, ADDR_LINE_ONE = :addressLineOne, ADDR_LINE_TWO = :addressLineTwo, ADDR_LINE_THREE = :addressLineThree, POSTAL_CODE = :postalCode, CITY_NAME = :cityName, RESIDENCE_NUMBER = :residenceNumber, COUNTRY_TP_CD = :country, BUILDING_NAME = :buildingName, STREET_NAME = :streetName, STREET_NUMBER = :streetNumber, MOBILE_NUMBER = :mobileNumber, HOME_PHONE_NUMBER = :homePhoneNumber, WORK_PHONE_NUMBER = :workPhoneNumber, WORK_PHONE_NUMBER_EXT = :workPhoneNumberExtension, FAX = :fax, EMAIL = :email, SOURCE_IDENT_TP_CD = :sourceIdentifier, START_DT = :startDate, END_DT = :endDate, MODIFY_SYS_DT = :lastModifiedSystemDate, LAST_UPDATE_DT = :lastUpdateDt, LAST_UPDATE_USER = :lastUpdateUser, LAST_UPDATE_TX_ID = :lastUpdateTxId where XGurantor_Companypk_Id = :xGurantorCompanypkId and LAST_UPDATE_DT = :oldLastUpdateDt" )
   * 
   * @generated
   */
  public int updateEObjXGurantorCompany (EObjXGurantorCompany e)
  {
    return update (updateEObjXGurantorCompanyStatementDescriptor, e);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor updateEObjXGurantorCompanyStatementDescriptor = createStatementDescriptor (
    "updateEObjXGurantorCompany(com.ibm.daimler.dsea.entityObject.EObjXGurantorCompany)",
    "update XGURANTORCOMPANY set CONTRACT_DETAILS_ID =  ? , BPID =  ? , CAN_NUMBER =  ? , INDUSTRY_TP_CD =  ? , COMPANY_NAME =  ? , COMPANY_NAME_LOCAL =  ? , ADDR_USAGE_TP_CD =  ? , ADDR_LINE_ONE =  ? , ADDR_LINE_TWO =  ? , ADDR_LINE_THREE =  ? , POSTAL_CODE =  ? , CITY_NAME =  ? , RESIDENCE_NUMBER =  ? , COUNTRY_TP_CD =  ? , BUILDING_NAME =  ? , STREET_NAME =  ? , STREET_NUMBER =  ? , MOBILE_NUMBER =  ? , HOME_PHONE_NUMBER =  ? , WORK_PHONE_NUMBER =  ? , WORK_PHONE_NUMBER_EXT =  ? , FAX =  ? , EMAIL =  ? , SOURCE_IDENT_TP_CD =  ? , START_DT =  ? , END_DT =  ? , MODIFY_SYS_DT =  ? , LAST_UPDATE_DT =  ? , LAST_UPDATE_USER =  ? , LAST_UPDATE_TX_ID =  ?  where XGurantor_Companypk_Id =  ?  and LAST_UPDATE_DT =  ? ",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.UPDATE,
    null,
    new UpdateEObjXGurantorCompanyParameterHandler (),
    new int[][]{{Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP}, {19, 500, 500, 19, 500, 500, 19, 500, 500, 500, 250, 250, 250, 19, 250, 250, 250, 250, 250, 250, 250, 250, 250, 19, 0, 0, 0, 0, 0, 19, 19, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    3);

  /**
   * @generated
   */
  public static class UpdateEObjXGurantorCompanyParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      EObjXGurantorCompany bean0 = (EObjXGurantorCompany) parameters[0];
      setLong (stmt, 1, Types.BIGINT, (Long)bean0.getContractDetailsId());
      setString (stmt, 2, Types.VARCHAR, (String)bean0.getBPID());
      setString (stmt, 3, Types.VARCHAR, (String)bean0.getCANNumber());
      setLong (stmt, 4, Types.BIGINT, (Long)bean0.getIndustry());
      setString (stmt, 5, Types.VARCHAR, (String)bean0.getCompanyName());
      setString (stmt, 6, Types.VARCHAR, (String)bean0.getCompanyNameLocal());
      setLong (stmt, 7, Types.BIGINT, (Long)bean0.getAddressUsage());
      setString (stmt, 8, Types.VARCHAR, (String)bean0.getAddressLineOne());
      setString (stmt, 9, Types.VARCHAR, (String)bean0.getAddressLineTwo());
      setString (stmt, 10, Types.VARCHAR, (String)bean0.getAddressLineThree());
      setString (stmt, 11, Types.VARCHAR, (String)bean0.getPostalCode());
      setString (stmt, 12, Types.VARCHAR, (String)bean0.getCityName());
      setString (stmt, 13, Types.VARCHAR, (String)bean0.getResidenceNumber());
      setLong (stmt, 14, Types.BIGINT, (Long)bean0.getCountry());
      setString (stmt, 15, Types.VARCHAR, (String)bean0.getBuildingName());
      setString (stmt, 16, Types.VARCHAR, (String)bean0.getStreetName());
      setString (stmt, 17, Types.VARCHAR, (String)bean0.getStreetNumber());
      setString (stmt, 18, Types.VARCHAR, (String)bean0.getMobileNumber());
      setString (stmt, 19, Types.VARCHAR, (String)bean0.getHomePhoneNumber());
      setString (stmt, 20, Types.VARCHAR, (String)bean0.getWorkPhoneNumber());
      setString (stmt, 21, Types.VARCHAR, (String)bean0.getWorkPhoneNumberExtension());
      setString (stmt, 22, Types.VARCHAR, (String)bean0.getFax());
      setString (stmt, 23, Types.VARCHAR, (String)bean0.getEmail());
      setLong (stmt, 24, Types.BIGINT, (Long)bean0.getSourceIdentifier());
      setTimestamp (stmt, 25, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getStartDate());
      setTimestamp (stmt, 26, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getEndDate());
      setTimestamp (stmt, 27, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastModifiedSystemDate());
      setTimestamp (stmt, 28, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUpdateDt());
      setString (stmt, 29, Types.VARCHAR, (String)bean0.getLastUpdateUser());
      setLong (stmt, 30, Types.BIGINT, (Long)bean0.getLastUpdateTxId());
      setLong (stmt, 31, Types.BIGINT, (Long)bean0.getXGurantorCompanypkId());
      setTimestamp (stmt, 32, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getOldLastUpdateDt());
    }
  }

  /**
   * @Update( sql="delete from XGURANTORCOMPANY where XGurantor_Companypk_Id = ?" )
   * 
   * @generated
   */
  public int deleteEObjXGurantorCompany (Long xGurantorCompanypkId)
  {
    return update (deleteEObjXGurantorCompanyStatementDescriptor, xGurantorCompanypkId);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor deleteEObjXGurantorCompanyStatementDescriptor = createStatementDescriptor (
    "deleteEObjXGurantorCompany(Long)",
    "delete from XGURANTORCOMPANY where XGurantor_Companypk_Id = ?",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.DELETE,
    null,
    new DeleteEObjXGurantorCompanyParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    4);

  /**
   * @generated
   */
  public static class DeleteEObjXGurantorCompanyParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setLong (stmt, 1, Types.BIGINT, (Long)parameters[0]);
    }
  }

}
