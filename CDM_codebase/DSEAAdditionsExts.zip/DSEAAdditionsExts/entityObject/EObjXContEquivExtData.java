/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[30ab7dc823f2b2ae7f68164b6ed58e1a]
 */


package com.ibm.daimler.dsea.entityObject;

import java.util.Iterator;
import com.ibm.mdm.base.db.EntityMapping;
import com.ibm.pdq.annotation.Select;
import com.ibm.pdq.annotation.Update;

import com.dwl.tcrm.coreParty.entityObject.EObjContEquiv;

import com.ibm.daimler.dsea.entityObject.EObjXContEquivExt;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * @generated
 */
public interface EObjXContEquivExtData {


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjXContEquivExtSql = "select XRETAILER_ID, XSOURCE_RETAILER_FLAG, XMODIFY_SYS_DT, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from CONTEQUIV where CONT_EQUIV_ID = ? ";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String createEObjXContEquivExtSql = "insert into CONTEQUIV (DESCRIPTION, CONT_ID, CONT_EQUIV_ID, ADMIN_CLIENT_ID, ADMIN_SYS_TP_CD, XRETAILER_ID, XSOURCE_RETAILER_FLAG, XMODIFY_SYS_DT, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( ?1.description, ?1.contId, ?1.contEquivIdPK, ?1.adminClientId, ?1.adminSysTpCd, ?2.xRetailerId, ?2.xSourceRetailerFlag, ?2.xLastModifiedSystemDate, ?1.lastUpdateDt, ?1.lastUpdateUser, ?1.lastUpdateTxId)";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String updateEObjXContEquivExtSql = "update CONTEQUIV set DESCRIPTION = ?1.description, CONT_ID = ?1.contId, ADMIN_CLIENT_ID = ?1.adminClientId, ADMIN_SYS_TP_CD = ?1.adminSysTpCd, XRETAILER_ID = ?2.xRetailerId, XSOURCE_RETAILER_FLAG = ?2.xSourceRetailerFlag, XMODIFY_SYS_DT = ?2.xLastModifiedSystemDate, LAST_UPDATE_DT = ?1.lastUpdateDt, LAST_UPDATE_USER = ?1.lastUpdateUser, LAST_UPDATE_TX_ID = ?1.lastUpdateTxId where CONT_EQUIV_ID = ?1.contEquivIdPK and LAST_UPDATE_DT = ?1.oldLastUpdateDt";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String deleteEObjXContEquivExtSql = "delete from CONTEQUIV where CONT_EQUIV_ID = ?";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXContEquivExtKeyField = "EObjXContEquivExt.contEquivIdPK";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXContEquivExtGetFields =
    "EObjXContEquivExt.xRetailerId," +
    "EObjXContEquivExt.xSourceRetailerFlag," +
    "EObjXContEquivExt.xLastModifiedSystemDate," +
    "EObjXContEquivExt.lastUpdateDt," +
    "EObjXContEquivExt.lastUpdateUser," +
    "EObjXContEquivExt.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXContEquivExtAllFields =
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.description," +
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.contId," +
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.contEquivIdPK," +
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.adminClientId," +
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.adminSysTpCd," +
    "com.ibm.daimler.dsea.entityObject.EObjXContEquivExt.xRetailerId," +
    "com.ibm.daimler.dsea.entityObject.EObjXContEquivExt.xSourceRetailerFlag," +
    "com.ibm.daimler.dsea.entityObject.EObjXContEquivExt.xLastModifiedSystemDate," +
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.lastUpdateDt," +
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.lastUpdateUser," +
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXContEquivExtUpdateFields =
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.description," +
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.contId," +
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.adminClientId," +
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.adminSysTpCd," +
    "com.ibm.daimler.dsea.entityObject.EObjXContEquivExt.xRetailerId," +
    "com.ibm.daimler.dsea.entityObject.EObjXContEquivExt.xSourceRetailerFlag," +
    "com.ibm.daimler.dsea.entityObject.EObjXContEquivExt.xLastModifiedSystemDate," +
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.lastUpdateDt," +
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.lastUpdateUser," +
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.lastUpdateTxId," +
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.contEquivIdPK," +
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.oldLastUpdateDt";   

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Select XContEquiv by parameters.
   * @generated
   */
  @Select(sql=getEObjXContEquivExtSql)
  @EntityMapping(parameters=EObjXContEquivExtKeyField, results=EObjXContEquivExtGetFields)
  Iterator<EObjXContEquivExt> getEObjXContEquivExt(Long contEquivIdPK);  
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Create XContEquiv by EObjXContEquivExt Object.
   * @generated
   */
  @Update(sql=createEObjXContEquivExtSql)
  @EntityMapping(parameters=EObjXContEquivExtAllFields)
    int createEObjXContEquivExt(EObjContEquiv e1, EObjXContEquivExt e2); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Update one XContEquiv by EObjXContEquivExt object.
   * @generated
   */
  @Update(sql=updateEObjXContEquivExtSql)
  @EntityMapping(parameters=EObjXContEquivExtUpdateFields)
    int updateEObjXContEquivExt(EObjContEquiv e1, EObjXContEquivExt e2); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Delete XContEquiv by parameters.
   * @generated
   */
  @Update(sql=deleteEObjXContEquivExtSql)
  @EntityMapping(parameters=EObjXContEquivExtKeyField)
  int deleteEObjXContEquivExt(Long contEquivIdPK);

}

