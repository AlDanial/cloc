/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[4be9bf323ca333465d7a075cff06c8b7]
 */


package com.ibm.daimler.dsea.entityObject;

import java.util.Iterator;
import com.ibm.mdm.base.db.EntityMapping;
import com.ibm.pdq.annotation.Select;
import com.ibm.pdq.annotation.Update;

import com.ibm.daimler.dsea.entityObject.EObjXDataSharing;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * @generated
 */
public interface EObjXDataSharingData {


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjXDataSharingSql = "select DATASHARINGPK_ID, DATA_SHARING_FLAG, CONT_ID, Customer_Merge_Ind, GCUpdate_Date, Data_Sharing_Wholesale, WSData_Sharing_Update_Date, RETAILER_ID, RETAILER_FLAG, SOURCE_IDENT_TP_CD, START_DT, MODIFY_SYS_DT, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from XDATASHARING where DATASHARINGPK_ID = ? ";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String createEObjXDataSharingSql = "insert into XDATASHARING (DATASHARINGPK_ID, DATA_SHARING_FLAG, CONT_ID, Customer_Merge_Ind, GCUpdate_Date, Data_Sharing_Wholesale, WSData_Sharing_Update_Date, RETAILER_ID, RETAILER_FLAG, SOURCE_IDENT_TP_CD, START_DT, MODIFY_SYS_DT, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( :dataSharingpkId, :dataSharingFlag, :contId, :customerMergeInd, :gCUpdateDate, :dataSharingWholesale, :wSDataSharingUpdateDate, :retailerId, :retailerFlag, :sourceIdentifier, :startDate, :lastModifiedSystemDate, :lastUpdateDt, :lastUpdateUser, :lastUpdateTxId)";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String updateEObjXDataSharingSql = "update XDATASHARING set DATA_SHARING_FLAG = :dataSharingFlag, CONT_ID = :contId, Customer_Merge_Ind = :customerMergeInd, GCUpdate_Date = :gCUpdateDate, Data_Sharing_Wholesale = :dataSharingWholesale, WSData_Sharing_Update_Date = :wSDataSharingUpdateDate, RETAILER_ID = :retailerId, RETAILER_FLAG = :retailerFlag, SOURCE_IDENT_TP_CD = :sourceIdentifier, START_DT = :startDate, MODIFY_SYS_DT = :lastModifiedSystemDate, LAST_UPDATE_DT = :lastUpdateDt, LAST_UPDATE_USER = :lastUpdateUser, LAST_UPDATE_TX_ID = :lastUpdateTxId where DATASHARINGPK_ID = :dataSharingpkId and LAST_UPDATE_DT = :oldLastUpdateDt";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String deleteEObjXDataSharingSql = "delete from XDATASHARING where DATASHARINGPK_ID = ?";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXDataSharingKeyField = "EObjXDataSharing.dataSharingpkId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXDataSharingGetFields =
    "EObjXDataSharing.dataSharingpkId," +
    "EObjXDataSharing.dataSharingFlag," +
    "EObjXDataSharing.contId," +
    "EObjXDataSharing.customerMergeInd," +
    "EObjXDataSharing.gCUpdateDate," +
    "EObjXDataSharing.dataSharingWholesale," +
    "EObjXDataSharing.wSDataSharingUpdateDate," +
    "EObjXDataSharing.retailerId," +
    "EObjXDataSharing.retailerFlag," +
    "EObjXDataSharing.sourceIdentifier," +
    "EObjXDataSharing.startDate," +
    "EObjXDataSharing.lastModifiedSystemDate," +
    "EObjXDataSharing.lastUpdateDt," +
    "EObjXDataSharing.lastUpdateUser," +
    "EObjXDataSharing.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXDataSharingAllFields =
    "com.ibm.daimler.dsea.entityObject.EObjXDataSharing.dataSharingpkId," +
    "com.ibm.daimler.dsea.entityObject.EObjXDataSharing.dataSharingFlag," +
    "com.ibm.daimler.dsea.entityObject.EObjXDataSharing.contId," +
    "com.ibm.daimler.dsea.entityObject.EObjXDataSharing.customerMergeInd," +
    "com.ibm.daimler.dsea.entityObject.EObjXDataSharing.gCUpdateDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXDataSharing.dataSharingWholesale," +
    "com.ibm.daimler.dsea.entityObject.EObjXDataSharing.wSDataSharingUpdateDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXDataSharing.retailerId," +
    "com.ibm.daimler.dsea.entityObject.EObjXDataSharing.retailerFlag," +
    "com.ibm.daimler.dsea.entityObject.EObjXDataSharing.sourceIdentifier," +
    "com.ibm.daimler.dsea.entityObject.EObjXDataSharing.startDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXDataSharing.lastModifiedSystemDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXDataSharing.lastUpdateDt," +
    "com.ibm.daimler.dsea.entityObject.EObjXDataSharing.lastUpdateUser," +
    "com.ibm.daimler.dsea.entityObject.EObjXDataSharing.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXDataSharingUpdateFields =
    "com.ibm.daimler.dsea.entityObject.EObjXDataSharing.dataSharingFlag," +
    "com.ibm.daimler.dsea.entityObject.EObjXDataSharing.contId," +
    "com.ibm.daimler.dsea.entityObject.EObjXDataSharing.customerMergeInd," +
    "com.ibm.daimler.dsea.entityObject.EObjXDataSharing.gCUpdateDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXDataSharing.dataSharingWholesale," +
    "com.ibm.daimler.dsea.entityObject.EObjXDataSharing.wSDataSharingUpdateDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXDataSharing.retailerId," +
    "com.ibm.daimler.dsea.entityObject.EObjXDataSharing.retailerFlag," +
    "com.ibm.daimler.dsea.entityObject.EObjXDataSharing.sourceIdentifier," +
    "com.ibm.daimler.dsea.entityObject.EObjXDataSharing.startDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXDataSharing.lastModifiedSystemDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXDataSharing.lastUpdateDt," +
    "com.ibm.daimler.dsea.entityObject.EObjXDataSharing.lastUpdateUser," +
    "com.ibm.daimler.dsea.entityObject.EObjXDataSharing.lastUpdateTxId," +
    "com.ibm.daimler.dsea.entityObject.EObjXDataSharing.dataSharingpkId," +
    "com.ibm.daimler.dsea.entityObject.EObjXDataSharing.oldLastUpdateDt";   

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Select XDataSharing by parameters.
   * @generated
   */
  @Select(sql=getEObjXDataSharingSql)
  @EntityMapping(parameters=EObjXDataSharingKeyField, results=EObjXDataSharingGetFields)
  Iterator<EObjXDataSharing> getEObjXDataSharing(Long dataSharingpkId);  
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Create XDataSharing by EObjXDataSharing Object.
   * @generated
   */
  @Update(sql=createEObjXDataSharingSql)
  @EntityMapping(parameters=EObjXDataSharingAllFields)
    int createEObjXDataSharing(EObjXDataSharing e); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Update one XDataSharing by EObjXDataSharing object.
   * @generated
   */
  @Update(sql=updateEObjXDataSharingSql)
  @EntityMapping(parameters=EObjXDataSharingUpdateFields)
    int updateEObjXDataSharing(EObjXDataSharing e); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Delete XDataSharing by parameters.
   * @generated
   */
  @Update(sql=deleteEObjXDataSharingSql)
  @EntityMapping(parameters=EObjXDataSharingKeyField)
  int deleteEObjXDataSharing(Long dataSharingpkId);

}

