/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[78ac485f3a884af819d565ebfb0f20c7]
 */


package com.ibm.daimler.dsea.entityObject;

import java.util.Iterator;
import com.ibm.mdm.base.db.EntityMapping;
import com.ibm.pdq.annotation.Select;
import com.ibm.pdq.annotation.Update;

import com.dwl.tcrm.coreParty.entityObject.EObjOrg;

import com.ibm.daimler.dsea.entityObject.EObjXOrgExt;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * @generated
 */
public interface EObjXOrgExtData {


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjXOrgExtSql = "select XDEFUNCT_IND, XWEBSITE, XMARKET_NAME, XBATCH_IND, XNUMOFEMP_TP_CD, XMODIFY_SYS_DT, XSOURCE_TYPE_FLAG, XGENERATED_BY, XCORP_CAT_TP_CD, XCORP_GROUP_TP_CD, XPERSONAL_AGREEMENT, XDo_Not_Merge_Flag, DELETE_FLAG, INFO_REMOVE_FLAG, DEDUP_HIDDEN_FLAG, PREF_COMMUNICATION_CHANNEL, YANASE_FLAG, FINANCE_PARTY_TYPE, CONTRACT_NUMBER, XPrivacy_Act, XFleet, XPC_Ind, XVANS_Ind, Last_Activity_Date, X_CUST_TYPE, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from ORG where CONT_ID = ? ";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String createEObjXOrgExtSql = "insert into ORG (ESTABLISHED_DT, CONT_ID, PROFIT_IND, BUY_SELL_AGR_TP_CD, INDUSTRY_TP_CD, ORG_TP_CD, XDEFUNCT_IND, XWEBSITE, XMARKET_NAME, XBATCH_IND, XNUMOFEMP_TP_CD, XMODIFY_SYS_DT, XSOURCE_TYPE_FLAG, XGENERATED_BY, XCORP_CAT_TP_CD, XCORP_GROUP_TP_CD, XPERSONAL_AGREEMENT, XDo_Not_Merge_Flag, DELETE_FLAG, INFO_REMOVE_FLAG, DEDUP_HIDDEN_FLAG, PREF_COMMUNICATION_CHANNEL, YANASE_FLAG, FINANCE_PARTY_TYPE, CONTRACT_NUMBER, XPrivacy_Act, XFleet, XPC_Ind, XVANS_Ind, Last_Activity_Date, X_CUST_TYPE, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( ?1.establishedDt, ?1.contIdPK, ?1.profitInd, ?1.buySellAgrTpCd, ?1.industryTpCd, ?1.orgTpCd, ?2.xDefunctInd, ?2.xWebsite, ?2.xMarketName, ?2.xBatchInd, ?2.xNumberOfEmployees, ?2.xLastModifiedSystemDate, ?2.xSourceTypeFlag, ?2.xGenerated_by, ?2.xCorporateCategory, ?2.xCorporateGroup, ?2.xPersonalAgreement, ?2.xDoNotMergeFlag, ?2.deleteFlag, ?2.infoRemoveFlag, ?2.dedupHiddenFlag, ?2.prefCommunicationChannel, ?2.yanaseFlag, ?2.financePartyType, ?2.contractNumber, ?2.xPrivacyAct, ?2.xFleet, ?2.xPC_Ind, ?2.xVANS_Ind, ?2.lastActivityDate, ?2.x_CUST_TYPE, ?1.lastUpdateDt, ?1.lastUpdateUser, ?1.lastUpdateTxId)";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String updateEObjXOrgExtSql = "update ORG set ESTABLISHED_DT = ?1.establishedDt, PROFIT_IND = ?1.profitInd, BUY_SELL_AGR_TP_CD = ?1.buySellAgrTpCd, INDUSTRY_TP_CD = ?1.industryTpCd, ORG_TP_CD = ?1.orgTpCd, XDEFUNCT_IND = ?2.xDefunctInd, XWEBSITE = ?2.xWebsite, XMARKET_NAME = ?2.xMarketName, XBATCH_IND = ?2.xBatchInd, XNUMOFEMP_TP_CD = ?2.xNumberOfEmployees, XMODIFY_SYS_DT = ?2.xLastModifiedSystemDate, XSOURCE_TYPE_FLAG = ?2.xSourceTypeFlag, XGENERATED_BY = ?2.xGenerated_by, XCORP_CAT_TP_CD = ?2.xCorporateCategory, XCORP_GROUP_TP_CD = ?2.xCorporateGroup, XPERSONAL_AGREEMENT = ?2.xPersonalAgreement, XDo_Not_Merge_Flag = ?2.xDoNotMergeFlag, DELETE_FLAG = ?2.deleteFlag, INFO_REMOVE_FLAG = ?2.infoRemoveFlag, DEDUP_HIDDEN_FLAG = ?2.dedupHiddenFlag, PREF_COMMUNICATION_CHANNEL = ?2.prefCommunicationChannel, YANASE_FLAG = ?2.yanaseFlag, FINANCE_PARTY_TYPE = ?2.financePartyType, CONTRACT_NUMBER = ?2.contractNumber, XPrivacy_Act = ?2.xPrivacyAct, XFleet = ?2.xFleet, XPC_Ind = ?2.xPC_Ind, XVANS_Ind = ?2.xVANS_Ind, Last_Activity_Date = ?2.lastActivityDate, X_CUST_TYPE = ?2.x_CUST_TYPE, LAST_UPDATE_DT = ?1.lastUpdateDt, LAST_UPDATE_USER = ?1.lastUpdateUser, LAST_UPDATE_TX_ID = ?1.lastUpdateTxId where CONT_ID = ?1.contIdPK and LAST_UPDATE_DT = ?1.oldLastUpdateDt";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String deleteEObjXOrgExtSql = "delete from ORG where CONT_ID = ?";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXOrgExtKeyField = "EObjXOrgExt.contIdPK";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXOrgExtGetFields =
    "EObjXOrgExt.xDefunctInd," +
    "EObjXOrgExt.xWebsite," +
    "EObjXOrgExt.xMarketName," +
    "EObjXOrgExt.xBatchInd," +
    "EObjXOrgExt.xNumberOfEmployees," +
    "EObjXOrgExt.xLastModifiedSystemDate," +
    "EObjXOrgExt.xSourceTypeFlag," +
    "EObjXOrgExt.xGenerated_by," +
    "EObjXOrgExt.xCorporateCategory," +
    "EObjXOrgExt.xCorporateGroup," +
    "EObjXOrgExt.xPersonalAgreement," +
    "EObjXOrgExt.xDoNotMergeFlag," +
    "EObjXOrgExt.deleteFlag," +
    "EObjXOrgExt.infoRemoveFlag," +
    "EObjXOrgExt.dedupHiddenFlag," +
    "EObjXOrgExt.prefCommunicationChannel," +
    "EObjXOrgExt.yanaseFlag," +
    "EObjXOrgExt.financePartyType," +
    "EObjXOrgExt.contractNumber," +
    "EObjXOrgExt.xPrivacyAct," +
    "EObjXOrgExt.xFleet," +
    "EObjXOrgExt.xPC_Ind," +
    "EObjXOrgExt.xVANS_Ind," +
    "EObjXOrgExt.lastActivityDate," +
    "EObjXOrgExt.x_CUST_TYPE," +
    "EObjXOrgExt.lastUpdateDt," +
    "EObjXOrgExt.lastUpdateUser," +
    "EObjXOrgExt.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXOrgExtAllFields =
    "com.dwl.tcrm.coreParty.entityObject.EObjOrg.establishedDt," +
    "com.dwl.tcrm.coreParty.entityObject.EObjOrg.contIdPK," +
    "com.dwl.tcrm.coreParty.entityObject.EObjOrg.profitInd," +
    "com.dwl.tcrm.coreParty.entityObject.EObjOrg.buySellAgrTpCd," +
    "com.dwl.tcrm.coreParty.entityObject.EObjOrg.industryTpCd," +
    "com.dwl.tcrm.coreParty.entityObject.EObjOrg.orgTpCd," +
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.xDefunctInd," +
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.xWebsite," +
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.xMarketName," +
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.xBatchInd," +
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.xNumberOfEmployees," +
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.xLastModifiedSystemDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.xSourceTypeFlag," +
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.xGenerated_by," +
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.xCorporateCategory," +
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.xCorporateGroup," +
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.xPersonalAgreement," +
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.xDoNotMergeFlag," +
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.deleteFlag," +
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.infoRemoveFlag," +
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.dedupHiddenFlag," +
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.prefCommunicationChannel," +
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.yanaseFlag," +
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.financePartyType," +
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.contractNumber," +
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.xPrivacyAct," +
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.xFleet," +
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.xPC_Ind," +
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.xVANS_Ind," +
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.lastActivityDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.x_CUST_TYPE," +
    "com.dwl.tcrm.coreParty.entityObject.EObjOrg.lastUpdateDt," +
    "com.dwl.tcrm.coreParty.entityObject.EObjOrg.lastUpdateUser," +
    "com.dwl.tcrm.coreParty.entityObject.EObjOrg.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXOrgExtUpdateFields =
    "com.dwl.tcrm.coreParty.entityObject.EObjOrg.establishedDt," +
    "com.dwl.tcrm.coreParty.entityObject.EObjOrg.profitInd," +
    "com.dwl.tcrm.coreParty.entityObject.EObjOrg.buySellAgrTpCd," +
    "com.dwl.tcrm.coreParty.entityObject.EObjOrg.industryTpCd," +
    "com.dwl.tcrm.coreParty.entityObject.EObjOrg.orgTpCd," +
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.xDefunctInd," +
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.xWebsite," +
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.xMarketName," +
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.xBatchInd," +
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.xNumberOfEmployees," +
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.xLastModifiedSystemDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.xSourceTypeFlag," +
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.xGenerated_by," +
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.xCorporateCategory," +
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.xCorporateGroup," +
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.xPersonalAgreement," +
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.xDoNotMergeFlag," +
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.deleteFlag," +
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.infoRemoveFlag," +
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.dedupHiddenFlag," +
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.prefCommunicationChannel," +
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.yanaseFlag," +
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.financePartyType," +
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.contractNumber," +
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.xPrivacyAct," +
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.xFleet," +
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.xPC_Ind," +
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.xVANS_Ind," +
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.lastActivityDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.x_CUST_TYPE," +
    "com.dwl.tcrm.coreParty.entityObject.EObjOrg.lastUpdateDt," +
    "com.dwl.tcrm.coreParty.entityObject.EObjOrg.lastUpdateUser," +
    "com.dwl.tcrm.coreParty.entityObject.EObjOrg.lastUpdateTxId," +
    "com.dwl.tcrm.coreParty.entityObject.EObjOrg.contIdPK," +
    "com.dwl.tcrm.coreParty.entityObject.EObjOrg.oldLastUpdateDt";   

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Select XOrg by parameters.
   * @generated
   */
  @Select(sql=getEObjXOrgExtSql)
  @EntityMapping(parameters=EObjXOrgExtKeyField, results=EObjXOrgExtGetFields)
  Iterator<EObjXOrgExt> getEObjXOrgExt(Long contIdPK);  
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Create XOrg by EObjXOrgExt Object.
   * @generated
   */
  @Update(sql=createEObjXOrgExtSql)
  @EntityMapping(parameters=EObjXOrgExtAllFields)
    int createEObjXOrgExt(EObjOrg e1, EObjXOrgExt e2); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Update one XOrg by EObjXOrgExt object.
   * @generated
   */
  @Update(sql=updateEObjXOrgExtSql)
  @EntityMapping(parameters=EObjXOrgExtUpdateFields)
    int updateEObjXOrgExt(EObjOrg e1, EObjXOrgExt e2); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Delete XOrg by parameters.
   * @generated
   */
  @Update(sql=deleteEObjXOrgExtSql)
  @EntityMapping(parameters=EObjXOrgExtKeyField)
  int deleteEObjXOrgExt(Long contIdPK);

}

