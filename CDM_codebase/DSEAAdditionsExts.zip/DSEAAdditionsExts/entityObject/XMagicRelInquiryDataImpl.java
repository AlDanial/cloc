package com.ibm.daimler.dsea.entityObject;

import com.ibm.pdq.runtime.generator.BaseParameterHandler;
import java.util.Iterator;
import com.ibm.mdm.base.db.ResultQueue1;
import java.sql.PreparedStatement;
import com.ibm.pdq.runtime.statement.StatementDescriptor;
import com.ibm.pdq.runtime.generator.BaseData;
import java.sql.SQLException;
import com.ibm.pdq.annotation.Metadata;
import com.ibm.daimler.dsea.entityObject.EObjXMagicRel;
import com.ibm.pdq.runtime.generator.BaseRowHandler;
import com.ibm.pdq.runtime.statement.SqlStatementType;
import java.sql.Types;


@SuppressWarnings("unchecked")

/**
 * <!-- begin-user-doc -->
 * 
 * <!-- end-user-doc -->
 * 
 * @generated
 */
public class XMagicRelInquiryDataImpl  extends BaseData implements XMagicRelInquiryData
{

  /**
   * @generated
   */
  public static final String generatorVersion = "3.200.75";

  /**
   * @generated
   */
  public static final String identifier = "XMagicRelInquiryData";

  /**
   * @generated
   */
  public static final long generationTime = 0x000001635e663022L;

  /**
   * @generated
   */
  public static final String collection = "NULLID";

  /**
   * @generated
   */
  public static final String packageVersion = null;

  /**
   * @generated
   */
  public static final boolean forceSingleBindIsolation = false;

  /**
   * @generated
   */
  public XMagicRelInquiryDataImpl()
  {
    super();
  } 

  /**
   * @generated
   */
  public String getGeneratorVersion()
  {
    return generatorVersion;
  }

  /**
   * @Select( sql="SELECT r.XMagic_Relpk_Id XMagic_Relpk_Id, r.UCID UCID, r.Golden_Magic Golden_Magic, r.Old_Magic Old_Magic, r.Old_Magic_Retailer Old_Magic_Retailer, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XMAGICREL r WHERE r.XMagic_Relpk_Id = ? ", pattern="tableAlias (XMAGICREL => com.ibm.daimler.dsea.entityObject.EObjXMagicRel, H_XMAGICREL => com.ibm.daimler.dsea.entityObject.EObjXMagicRel)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue1<EObjXMagicRel>> getXMagicRel (Object[] parameters)
  {
    return queryIterator (getXMagicRelStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getXMagicRelStatementDescriptor = createStatementDescriptor (
    "getXMagicRel(Object[])",
    "SELECT r.XMagic_Relpk_Id XMagic_Relpk_Id, r.UCID UCID, r.Golden_Magic Golden_Magic, r.Old_Magic Old_Magic, r.Old_Magic_Retailer Old_Magic_Retailer, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XMAGICREL r WHERE r.XMagic_Relpk_Id = ? ",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"xmagic_relpk_id", "ucid", "golden_magic", "old_magic", "old_magic_retailer", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetXMagicRelParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetXMagicRelRowHandler (),
    new int[][]{ {Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 250, 250, 250, 250, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    1);

  /**
   * @generated
   */
  public static class GetXMagicRelParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetXMagicRelRowHandler extends BaseRowHandler<ResultQueue1<EObjXMagicRel>>
  {
    /**
     * @generated
     */
    public ResultQueue1<EObjXMagicRel> handle (java.sql.ResultSet rs, ResultQueue1<EObjXMagicRel> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue1<EObjXMagicRel> ();

      EObjXMagicRel returnObject1 = new EObjXMagicRel ();
      returnObject1.setXMagicRelpkId(getLongObject (rs, 1)); 
      returnObject1.setUCID(getString (rs, 2)); 
      returnObject1.setGoldenMagic(getString (rs, 3)); 
      returnObject1.setOldMagic(getString (rs, 4)); 
      returnObject1.setOldMagicRetailer(getString (rs, 5)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 6)); 
      returnObject1.setLastUpdateUser(getString (rs, 7)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 8)); 
      returnObject.add (returnObject1);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT r.H_XMagic_Relpk_Id hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.XMagic_Relpk_Id XMagic_Relpk_Id, r.UCID UCID, r.Golden_Magic Golden_Magic, r.Old_Magic Old_Magic, r.Old_Magic_Retailer Old_Magic_Retailer, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XMAGICREL r WHERE r.H_XMagic_Relpk_Id = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))", pattern="tableAlias (XMAGICREL => com.ibm.daimler.dsea.entityObject.EObjXMagicRel, H_XMAGICREL => com.ibm.daimler.dsea.entityObject.EObjXMagicRel)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue1<EObjXMagicRel>> getXMagicRelHistory (Object[] parameters)
  {
    return queryIterator (getXMagicRelHistoryStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getXMagicRelHistoryStatementDescriptor = createStatementDescriptor (
    "getXMagicRelHistory(Object[])",
    "SELECT r.H_XMagic_Relpk_Id hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.XMagic_Relpk_Id XMagic_Relpk_Id, r.UCID UCID, r.Golden_Magic Golden_Magic, r.Old_Magic Old_Magic, r.Old_Magic_Retailer Old_Magic_Retailer, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XMAGICREL r WHERE r.H_XMagic_Relpk_Id = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"historyidpk", "h_action_code", "h_created_by", "h_create_dt", "h_end_dt", "xmagic_relpk_id", "ucid", "golden_magic", "old_magic", "old_magic_retailer", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetXMagicRelHistoryParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP}, {19, 0, 0}, {0, 0, 0}, {1, 1, 1}},
    null,
    new GetXMagicRelHistoryRowHandler (),
    new int[][]{ {Types.BIGINT, Types.CHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 1, 20, 0, 0, 19, 250, 250, 250, 250, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    2);

  /**
   * @generated
   */
  public static class GetXMagicRelHistoryParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetXMagicRelHistoryRowHandler extends BaseRowHandler<ResultQueue1<EObjXMagicRel>>
  {
    /**
     * @generated
     */
    public ResultQueue1<EObjXMagicRel> handle (java.sql.ResultSet rs, ResultQueue1<EObjXMagicRel> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue1<EObjXMagicRel> ();

      EObjXMagicRel returnObject1 = new EObjXMagicRel ();
      returnObject1.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject1.setHistActionCode(getString (rs, 2)); 
      returnObject1.setHistCreatedBy(getString (rs, 3)); 
      returnObject1.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject1.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject1.setXMagicRelpkId(getLongObject (rs, 6)); 
      returnObject1.setUCID(getString (rs, 7)); 
      returnObject1.setGoldenMagic(getString (rs, 8)); 
      returnObject1.setOldMagic(getString (rs, 9)); 
      returnObject1.setOldMagicRetailer(getString (rs, 10)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 11)); 
      returnObject1.setLastUpdateUser(getString (rs, 12)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 13)); 
      returnObject.add (returnObject1);

    
      return returnObject;
    }
  }

}
