package com.ibm.daimler.dsea.entityObject;

import com.ibm.pdq.runtime.generator.BaseParameterHandler;
import com.ibm.daimler.dsea.entityObject.EObjXVehicleKOR;
import java.util.Iterator;
import com.ibm.mdm.base.db.ResultQueue1;
import java.sql.PreparedStatement;
import com.ibm.pdq.runtime.statement.StatementDescriptor;
import com.ibm.pdq.runtime.generator.BaseData;
import java.sql.SQLException;
import com.ibm.pdq.annotation.Metadata;
import com.ibm.pdq.runtime.generator.BaseRowHandler;
import com.ibm.pdq.runtime.statement.SqlStatementType;
import java.sql.Types;


@SuppressWarnings("unchecked")

/**
 * <!-- begin-user-doc -->
 * 
 * <!-- end-user-doc -->
 * 
 * @generated
 */
public class XVehicleKORInquiryDataImpl  extends BaseData implements XVehicleKORInquiryData
{

  /**
   * @generated
   */
  public static final String generatorVersion = "3.200.75";

  /**
   * @generated
   */
  public static final String identifier = "XVehicleKORInquiryData";

  /**
   * @generated
   */
  public static final long generationTime = 0x00000166f7ce1ca0L;

  /**
   * @generated
   */
  public static final String collection = "NULLID";

  /**
   * @generated
   */
  public static final String packageVersion = null;

  /**
   * @generated
   */
  public static final boolean forceSingleBindIsolation = false;

  /**
   * @generated
   */
  public XVehicleKORInquiryDataImpl()
  {
    super();
  } 

  /**
   * @generated
   */
  public String getGeneratorVersion()
  {
    return generatorVersion;
  }

  /**
   * @Select( sql="SELECT r.XVehicle_KORpk_Id XVehicle_KORpk_Id, r.Global_VIN Global_VIN, r.BAU_MUSTER BAU_MUSTER, r.TYPE_CLASS TYPE_CLASS, r.SUB_MUSTER SUB_MUSTER, r.COLOR COLOR, r.TRIM TRIM, r.BATCH_IND BATCH_IND, r.MARKET_NAME MARKET_NAME, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.CREATE_DT CREATE_DT, r.CHANGED_DT CHANGED_DT, r.LAST_SERVICE_DT LAST_SERVICE_DT, r.SFDC_ID SFDC_ID, r.VEHICLE_ADDRESS_TYPE VEHICLE_ADDRESS_TYPE, r.VEHICLE_TYPE VEHICLE_TYPE, r.DELETE_FLAG DELETE_FLAG, r.END_DT END_DT, r.ENGINE_NUM ENGINE_NUM, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.Local_VIN Local_VIN, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XVEHICLEKOR r WHERE r.XVehicle_KORpk_Id = ? ", pattern="tableAlias (XVEHICLEKOR => com.ibm.daimler.dsea.entityObject.EObjXVehicleKOR, H_XVEHICLEKOR => com.ibm.daimler.dsea.entityObject.EObjXVehicleKOR)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue1<EObjXVehicleKOR>> getXVehicleKOR (Object[] parameters)
  {
    return queryIterator (getXVehicleKORStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getXVehicleKORStatementDescriptor = createStatementDescriptor (
    "getXVehicleKOR(Object[])",
    "SELECT r.XVehicle_KORpk_Id XVehicle_KORpk_Id, r.Global_VIN Global_VIN, r.BAU_MUSTER BAU_MUSTER, r.TYPE_CLASS TYPE_CLASS, r.SUB_MUSTER SUB_MUSTER, r.COLOR COLOR, r.TRIM TRIM, r.BATCH_IND BATCH_IND, r.MARKET_NAME MARKET_NAME, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.CREATE_DT CREATE_DT, r.CHANGED_DT CHANGED_DT, r.LAST_SERVICE_DT LAST_SERVICE_DT, r.SFDC_ID SFDC_ID, r.VEHICLE_ADDRESS_TYPE VEHICLE_ADDRESS_TYPE, r.VEHICLE_TYPE VEHICLE_TYPE, r.DELETE_FLAG DELETE_FLAG, r.END_DT END_DT, r.ENGINE_NUM ENGINE_NUM, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.Local_VIN Local_VIN, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XVEHICLEKOR r WHERE r.XVehicle_KORpk_Id = ? ",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"xvehicle_korpk_id", "global_vin", "bau_muster", "type_class", "sub_muster", "color", "trim", "batch_ind", "market_name", "modify_sys_dt", "create_dt", "changed_dt", "last_service_dt", "sfdc_id", "vehicle_address_type", "vehicle_type", "delete_flag", "end_dt", "engine_num", "source_ident_tp_cd", "local_vin", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetXVehicleKORParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetXVehicleKORRowHandler (),
    new int[][]{ {Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 50, 20, 255, 255, 255, 255, 5, 50, 0, 0, 0, 0, 50, 255, 50, 10, 0, 20, 19, 50, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    1);

  /**
   * @generated
   */
  public static class GetXVehicleKORParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetXVehicleKORRowHandler extends BaseRowHandler<ResultQueue1<EObjXVehicleKOR>>
  {
    /**
     * @generated
     */
    public ResultQueue1<EObjXVehicleKOR> handle (java.sql.ResultSet rs, ResultQueue1<EObjXVehicleKOR> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue1<EObjXVehicleKOR> ();

      EObjXVehicleKOR returnObject1 = new EObjXVehicleKOR ();
      returnObject1.setXVehicleKORpkId(getLongObject (rs, 1)); 
      returnObject1.setGlobalVIN(getString (rs, 2)); 
      returnObject1.setBauMuster(getString (rs, 3)); 
      returnObject1.setTypeClass(getString (rs, 4)); 
      returnObject1.setSubMuster(getString (rs, 5)); 
      returnObject1.setColor(getString (rs, 6)); 
      returnObject1.setTrim(getString (rs, 7)); 
      returnObject1.setBatchInd(getString (rs, 8)); 
      returnObject1.setMarketName(getString (rs, 9)); 
      returnObject1.setLastModifiedSystemDate(getTimestamp (rs, 10)); 
      returnObject1.setCreateDate(getTimestamp (rs, 11)); 
      returnObject1.setChangedDate(getTimestamp (rs, 12)); 
      returnObject1.setLastServiceDate(getTimestamp (rs, 13)); 
      returnObject1.setSFDCId(getString (rs, 14)); 
      returnObject1.setVehicleAddressType(getString (rs, 15)); 
      returnObject1.setVehicleType(getString (rs, 16)); 
      returnObject1.setDeleteFlag(getString (rs, 17)); 
      returnObject1.setEndDate(getTimestamp (rs, 18)); 
      returnObject1.setEngineNumber(getString (rs, 19)); 
      returnObject1.setSourceIdentifier(getLongObject (rs, 20)); 
      returnObject1.setLocalVIN(getString (rs, 21)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 22)); 
      returnObject1.setLastUpdateUser(getString (rs, 23)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 24)); 
      returnObject.add (returnObject1);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT r.H_XVehicle_KORpk_Id hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.XVehicle_KORpk_Id XVehicle_KORpk_Id, r.Global_VIN Global_VIN, r.BAU_MUSTER BAU_MUSTER, r.TYPE_CLASS TYPE_CLASS, r.SUB_MUSTER SUB_MUSTER, r.COLOR COLOR, r.TRIM TRIM, r.BATCH_IND BATCH_IND, r.MARKET_NAME MARKET_NAME, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.CREATE_DT CREATE_DT, r.CHANGED_DT CHANGED_DT, r.LAST_SERVICE_DT LAST_SERVICE_DT, r.SFDC_ID SFDC_ID, r.VEHICLE_ADDRESS_TYPE VEHICLE_ADDRESS_TYPE, r.VEHICLE_TYPE VEHICLE_TYPE, r.DELETE_FLAG DELETE_FLAG, r.END_DT END_DT, r.ENGINE_NUM ENGINE_NUM, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.Local_VIN Local_VIN, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XVEHICLEKOR r WHERE r.H_XVehicle_KORpk_Id = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))", pattern="tableAlias (XVEHICLEKOR => com.ibm.daimler.dsea.entityObject.EObjXVehicleKOR, H_XVEHICLEKOR => com.ibm.daimler.dsea.entityObject.EObjXVehicleKOR)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue1<EObjXVehicleKOR>> getXVehicleKORHistory (Object[] parameters)
  {
    return queryIterator (getXVehicleKORHistoryStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getXVehicleKORHistoryStatementDescriptor = createStatementDescriptor (
    "getXVehicleKORHistory(Object[])",
    "SELECT r.H_XVehicle_KORpk_Id hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.XVehicle_KORpk_Id XVehicle_KORpk_Id, r.Global_VIN Global_VIN, r.BAU_MUSTER BAU_MUSTER, r.TYPE_CLASS TYPE_CLASS, r.SUB_MUSTER SUB_MUSTER, r.COLOR COLOR, r.TRIM TRIM, r.BATCH_IND BATCH_IND, r.MARKET_NAME MARKET_NAME, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.CREATE_DT CREATE_DT, r.CHANGED_DT CHANGED_DT, r.LAST_SERVICE_DT LAST_SERVICE_DT, r.SFDC_ID SFDC_ID, r.VEHICLE_ADDRESS_TYPE VEHICLE_ADDRESS_TYPE, r.VEHICLE_TYPE VEHICLE_TYPE, r.DELETE_FLAG DELETE_FLAG, r.END_DT END_DT, r.ENGINE_NUM ENGINE_NUM, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.Local_VIN Local_VIN, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XVEHICLEKOR r WHERE r.H_XVehicle_KORpk_Id = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"historyidpk", "h_action_code", "h_created_by", "h_create_dt", "h_end_dt", "xvehicle_korpk_id", "global_vin", "bau_muster", "type_class", "sub_muster", "color", "trim", "batch_ind", "market_name", "modify_sys_dt", "create_dt", "changed_dt", "last_service_dt", "sfdc_id", "vehicle_address_type", "vehicle_type", "delete_flag", "end_dt", "engine_num", "source_ident_tp_cd", "local_vin", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetXVehicleKORHistoryParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP}, {19, 0, 0}, {0, 0, 0}, {1, 1, 1}},
    null,
    new GetXVehicleKORHistoryRowHandler (),
    new int[][]{ {Types.BIGINT, Types.CHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 1, 20, 0, 0, 19, 50, 20, 255, 255, 255, 255, 5, 50, 0, 0, 0, 0, 50, 255, 50, 10, 0, 20, 19, 50, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    2);

  /**
   * @generated
   */
  public static class GetXVehicleKORHistoryParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetXVehicleKORHistoryRowHandler extends BaseRowHandler<ResultQueue1<EObjXVehicleKOR>>
  {
    /**
     * @generated
     */
    public ResultQueue1<EObjXVehicleKOR> handle (java.sql.ResultSet rs, ResultQueue1<EObjXVehicleKOR> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue1<EObjXVehicleKOR> ();

      EObjXVehicleKOR returnObject1 = new EObjXVehicleKOR ();
      returnObject1.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject1.setHistActionCode(getString (rs, 2)); 
      returnObject1.setHistCreatedBy(getString (rs, 3)); 
      returnObject1.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject1.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject1.setXVehicleKORpkId(getLongObject (rs, 6)); 
      returnObject1.setGlobalVIN(getString (rs, 7)); 
      returnObject1.setBauMuster(getString (rs, 8)); 
      returnObject1.setTypeClass(getString (rs, 9)); 
      returnObject1.setSubMuster(getString (rs, 10)); 
      returnObject1.setColor(getString (rs, 11)); 
      returnObject1.setTrim(getString (rs, 12)); 
      returnObject1.setBatchInd(getString (rs, 13)); 
      returnObject1.setMarketName(getString (rs, 14)); 
      returnObject1.setLastModifiedSystemDate(getTimestamp (rs, 15)); 
      returnObject1.setCreateDate(getTimestamp (rs, 16)); 
      returnObject1.setChangedDate(getTimestamp (rs, 17)); 
      returnObject1.setLastServiceDate(getTimestamp (rs, 18)); 
      returnObject1.setSFDCId(getString (rs, 19)); 
      returnObject1.setVehicleAddressType(getString (rs, 20)); 
      returnObject1.setVehicleType(getString (rs, 21)); 
      returnObject1.setDeleteFlag(getString (rs, 22)); 
      returnObject1.setEndDate(getTimestamp (rs, 23)); 
      returnObject1.setEngineNumber(getString (rs, 24)); 
      returnObject1.setSourceIdentifier(getLongObject (rs, 25)); 
      returnObject1.setLocalVIN(getString (rs, 26)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 27)); 
      returnObject1.setLastUpdateUser(getString (rs, 28)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 29)); 
      returnObject.add (returnObject1);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT r.XVehicle_KORpk_Id XVehicle_KORpk_Id, r.Global_VIN Global_VIN, r.BAU_MUSTER BAU_MUSTER, r.TYPE_CLASS TYPE_CLASS, r.SUB_MUSTER SUB_MUSTER, r.COLOR COLOR, r.TRIM TRIM, r.BATCH_IND BATCH_IND, r.MARKET_NAME MARKET_NAME, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.CREATE_DT CREATE_DT, r.CHANGED_DT CHANGED_DT, r.LAST_SERVICE_DT LAST_SERVICE_DT, r.SFDC_ID SFDC_ID, r.VEHICLE_ADDRESS_TYPE VEHICLE_ADDRESS_TYPE, r.VEHICLE_TYPE VEHICLE_TYPE, r.DELETE_FLAG DELETE_FLAG, r.END_DT END_DT, r.ENGINE_NUM ENGINE_NUM, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.Local_VIN Local_VIN, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XVEHICLEKOR r WHERE r.Global_VIN = ? ", pattern="tableAlias (XVEHICLEKOR => com.ibm.daimler.dsea.entityObject.EObjXVehicleKOR, H_XVEHICLEKOR => com.ibm.daimler.dsea.entityObject.EObjXVehicleKOR)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue1<EObjXVehicleKOR>> getXVehicleKORByGlobalVIN (Object[] parameters)
  {
    return queryIterator (getXVehicleKORByGlobalVINStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getXVehicleKORByGlobalVINStatementDescriptor = createStatementDescriptor (
    "getXVehicleKORByGlobalVIN(Object[])",
    "SELECT r.XVehicle_KORpk_Id XVehicle_KORpk_Id, r.Global_VIN Global_VIN, r.BAU_MUSTER BAU_MUSTER, r.TYPE_CLASS TYPE_CLASS, r.SUB_MUSTER SUB_MUSTER, r.COLOR COLOR, r.TRIM TRIM, r.BATCH_IND BATCH_IND, r.MARKET_NAME MARKET_NAME, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.CREATE_DT CREATE_DT, r.CHANGED_DT CHANGED_DT, r.LAST_SERVICE_DT LAST_SERVICE_DT, r.SFDC_ID SFDC_ID, r.VEHICLE_ADDRESS_TYPE VEHICLE_ADDRESS_TYPE, r.VEHICLE_TYPE VEHICLE_TYPE, r.DELETE_FLAG DELETE_FLAG, r.END_DT END_DT, r.ENGINE_NUM ENGINE_NUM, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.Local_VIN Local_VIN, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XVEHICLEKOR r WHERE r.Global_VIN = ? ",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"xvehicle_korpk_id", "global_vin", "bau_muster", "type_class", "sub_muster", "color", "trim", "batch_ind", "market_name", "modify_sys_dt", "create_dt", "changed_dt", "last_service_dt", "sfdc_id", "vehicle_address_type", "vehicle_type", "delete_flag", "end_dt", "engine_num", "source_ident_tp_cd", "local_vin", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetXVehicleKORByGlobalVINParameterHandler (),
    new int[][]{{Types.VARCHAR}, {50}, {0}, {1}},
    null,
    new GetXVehicleKORByGlobalVINRowHandler (),
    new int[][]{ {Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 50, 20, 255, 255, 255, 255, 5, 50, 0, 0, 0, 0, 50, 255, 50, 10, 0, 20, 19, 50, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    3);

  /**
   * @generated
   */
  public static class GetXVehicleKORByGlobalVINParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.VARCHAR, parameters[0], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetXVehicleKORByGlobalVINRowHandler extends BaseRowHandler<ResultQueue1<EObjXVehicleKOR>>
  {
    /**
     * @generated
     */
    public ResultQueue1<EObjXVehicleKOR> handle (java.sql.ResultSet rs, ResultQueue1<EObjXVehicleKOR> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue1<EObjXVehicleKOR> ();

      EObjXVehicleKOR returnObject1 = new EObjXVehicleKOR ();
      returnObject1.setXVehicleKORpkId(getLongObject (rs, 1)); 
      returnObject1.setGlobalVIN(getString (rs, 2)); 
      returnObject1.setBauMuster(getString (rs, 3)); 
      returnObject1.setTypeClass(getString (rs, 4)); 
      returnObject1.setSubMuster(getString (rs, 5)); 
      returnObject1.setColor(getString (rs, 6)); 
      returnObject1.setTrim(getString (rs, 7)); 
      returnObject1.setBatchInd(getString (rs, 8)); 
      returnObject1.setMarketName(getString (rs, 9)); 
      returnObject1.setLastModifiedSystemDate(getTimestamp (rs, 10)); 
      returnObject1.setCreateDate(getTimestamp (rs, 11)); 
      returnObject1.setChangedDate(getTimestamp (rs, 12)); 
      returnObject1.setLastServiceDate(getTimestamp (rs, 13)); 
      returnObject1.setSFDCId(getString (rs, 14)); 
      returnObject1.setVehicleAddressType(getString (rs, 15)); 
      returnObject1.setVehicleType(getString (rs, 16)); 
      returnObject1.setDeleteFlag(getString (rs, 17)); 
      returnObject1.setEndDate(getTimestamp (rs, 18)); 
      returnObject1.setEngineNumber(getString (rs, 19)); 
      returnObject1.setSourceIdentifier(getLongObject (rs, 20)); 
      returnObject1.setLocalVIN(getString (rs, 21)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 22)); 
      returnObject1.setLastUpdateUser(getString (rs, 23)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 24)); 
      returnObject.add (returnObject1);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT r.H_XVehicle_KORpk_Id hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.XVehicle_KORpk_Id XVehicle_KORpk_Id, r.Global_VIN Global_VIN, r.BAU_MUSTER BAU_MUSTER, r.TYPE_CLASS TYPE_CLASS, r.SUB_MUSTER SUB_MUSTER, r.COLOR COLOR, r.TRIM TRIM, r.BATCH_IND BATCH_IND, r.MARKET_NAME MARKET_NAME, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.CREATE_DT CREATE_DT, r.CHANGED_DT CHANGED_DT, r.LAST_SERVICE_DT LAST_SERVICE_DT, r.SFDC_ID SFDC_ID, r.VEHICLE_ADDRESS_TYPE VEHICLE_ADDRESS_TYPE, r.VEHICLE_TYPE VEHICLE_TYPE, r.DELETE_FLAG DELETE_FLAG, r.END_DT END_DT, r.ENGINE_NUM ENGINE_NUM, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.Local_VIN Local_VIN, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XVEHICLEKOR r WHERE r.Global_VIN = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))", pattern="tableAlias (XVEHICLEKOR => com.ibm.daimler.dsea.entityObject.EObjXVehicleKOR, H_XVEHICLEKOR => com.ibm.daimler.dsea.entityObject.EObjXVehicleKOR)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue1<EObjXVehicleKOR>> getXVehicleKORByGlobalVINHistory (Object[] parameters)
  {
    return queryIterator (getXVehicleKORByGlobalVINHistoryStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getXVehicleKORByGlobalVINHistoryStatementDescriptor = createStatementDescriptor (
    "getXVehicleKORByGlobalVINHistory(Object[])",
    "SELECT r.H_XVehicle_KORpk_Id hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.XVehicle_KORpk_Id XVehicle_KORpk_Id, r.Global_VIN Global_VIN, r.BAU_MUSTER BAU_MUSTER, r.TYPE_CLASS TYPE_CLASS, r.SUB_MUSTER SUB_MUSTER, r.COLOR COLOR, r.TRIM TRIM, r.BATCH_IND BATCH_IND, r.MARKET_NAME MARKET_NAME, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.CREATE_DT CREATE_DT, r.CHANGED_DT CHANGED_DT, r.LAST_SERVICE_DT LAST_SERVICE_DT, r.SFDC_ID SFDC_ID, r.VEHICLE_ADDRESS_TYPE VEHICLE_ADDRESS_TYPE, r.VEHICLE_TYPE VEHICLE_TYPE, r.DELETE_FLAG DELETE_FLAG, r.END_DT END_DT, r.ENGINE_NUM ENGINE_NUM, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.Local_VIN Local_VIN, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XVEHICLEKOR r WHERE r.Global_VIN = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"historyidpk", "h_action_code", "h_created_by", "h_create_dt", "h_end_dt", "xvehicle_korpk_id", "global_vin", "bau_muster", "type_class", "sub_muster", "color", "trim", "batch_ind", "market_name", "modify_sys_dt", "create_dt", "changed_dt", "last_service_dt", "sfdc_id", "vehicle_address_type", "vehicle_type", "delete_flag", "end_dt", "engine_num", "source_ident_tp_cd", "local_vin", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetXVehicleKORByGlobalVINHistoryParameterHandler (),
    new int[][]{{Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP}, {50, 0, 0}, {0, 0, 0}, {1, 1, 1}},
    null,
    new GetXVehicleKORByGlobalVINHistoryRowHandler (),
    new int[][]{ {Types.BIGINT, Types.CHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 1, 20, 0, 0, 19, 50, 20, 255, 255, 255, 255, 5, 50, 0, 0, 0, 0, 50, 255, 50, 10, 0, 20, 19, 50, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    4);

  /**
   * @generated
   */
  public static class GetXVehicleKORByGlobalVINHistoryParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.VARCHAR, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetXVehicleKORByGlobalVINHistoryRowHandler extends BaseRowHandler<ResultQueue1<EObjXVehicleKOR>>
  {
    /**
     * @generated
     */
    public ResultQueue1<EObjXVehicleKOR> handle (java.sql.ResultSet rs, ResultQueue1<EObjXVehicleKOR> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue1<EObjXVehicleKOR> ();

      EObjXVehicleKOR returnObject1 = new EObjXVehicleKOR ();
      returnObject1.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject1.setHistActionCode(getString (rs, 2)); 
      returnObject1.setHistCreatedBy(getString (rs, 3)); 
      returnObject1.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject1.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject1.setXVehicleKORpkId(getLongObject (rs, 6)); 
      returnObject1.setGlobalVIN(getString (rs, 7)); 
      returnObject1.setBauMuster(getString (rs, 8)); 
      returnObject1.setTypeClass(getString (rs, 9)); 
      returnObject1.setSubMuster(getString (rs, 10)); 
      returnObject1.setColor(getString (rs, 11)); 
      returnObject1.setTrim(getString (rs, 12)); 
      returnObject1.setBatchInd(getString (rs, 13)); 
      returnObject1.setMarketName(getString (rs, 14)); 
      returnObject1.setLastModifiedSystemDate(getTimestamp (rs, 15)); 
      returnObject1.setCreateDate(getTimestamp (rs, 16)); 
      returnObject1.setChangedDate(getTimestamp (rs, 17)); 
      returnObject1.setLastServiceDate(getTimestamp (rs, 18)); 
      returnObject1.setSFDCId(getString (rs, 19)); 
      returnObject1.setVehicleAddressType(getString (rs, 20)); 
      returnObject1.setVehicleType(getString (rs, 21)); 
      returnObject1.setDeleteFlag(getString (rs, 22)); 
      returnObject1.setEndDate(getTimestamp (rs, 23)); 
      returnObject1.setEngineNumber(getString (rs, 24)); 
      returnObject1.setSourceIdentifier(getLongObject (rs, 25)); 
      returnObject1.setLocalVIN(getString (rs, 26)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 27)); 
      returnObject1.setLastUpdateUser(getString (rs, 28)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 29)); 
      returnObject.add (returnObject1);

    
      return returnObject;
    }
  }

}
