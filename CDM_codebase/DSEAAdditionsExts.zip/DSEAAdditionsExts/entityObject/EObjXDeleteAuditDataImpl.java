package com.ibm.daimler.dsea.entityObject;

import com.ibm.pdq.runtime.generator.BaseParameterHandler;
import com.ibm.daimler.dsea.entityObject.EObjXDeleteAudit;
import java.util.Iterator;
import java.sql.PreparedStatement;
import com.ibm.pdq.runtime.statement.StatementDescriptor;
import com.ibm.pdq.runtime.generator.BaseData;
import java.sql.SQLException;
import com.ibm.pdq.annotation.Metadata;
import com.ibm.pdq.runtime.generator.BaseRowHandler;
import com.ibm.pdq.runtime.statement.SqlStatementType;
import java.sql.Types;


/**
 * <!-- begin-user-doc -->
 * 
 * <!-- end-user-doc -->
 * 
 * @generated
 */
public class EObjXDeleteAuditDataImpl  extends BaseData implements EObjXDeleteAuditData
{

  /**
   * @generated
   */
  public static final String generatorVersion = "3.200.75";

  /**
   * @generated
   */
  public static final String identifier = "EObjXDeleteAuditData";

  /**
   * @generated
   */
  public static final long generationTime = 0x0000017182cdbf9cL;

  /**
   * @generated
   */
  public static final String collection = "NULLID";

  /**
   * @generated
   */
  public static final String packageVersion = null;

  /**
   * @generated
   */
  public static final boolean forceSingleBindIsolation = false;

  /**
   * @generated
   */
  public EObjXDeleteAuditDataImpl()
  {
    super();
  } 

  /**
   * @generated
   */
  public String getGeneratorVersion()
  {
    return generatorVersion;
  }

  /**
   * @Select( sql="select XDelete_Auditpk_Id, CONT_ID, ADMIN_CLIENT_ID, ADMIN_SYSTEM_VALUE, DESCRIPTION, DELETE_DATE, MARKET_NAME, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from XDELETEAUDIT where XDelete_Auditpk_Id = ? " )
   * 
   * @generated
   */
  public Iterator<EObjXDeleteAudit> getEObjXDeleteAudit (Long xDeleteAuditpkId)
  {
    return queryIterator (getEObjXDeleteAuditStatementDescriptor, xDeleteAuditpkId);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getEObjXDeleteAuditStatementDescriptor = createStatementDescriptor (
    "getEObjXDeleteAudit(Long)",
    "select XDelete_Auditpk_Id, CONT_ID, ADMIN_CLIENT_ID, ADMIN_SYSTEM_VALUE, DESCRIPTION, DELETE_DATE, MARKET_NAME, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from XDELETEAUDIT where XDelete_Auditpk_Id = ? ",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"xdelete_auditpk_id", "cont_id", "admin_client_id", "admin_system_value", "description", "delete_date", "market_name", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetEObjXDeleteAuditParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetEObjXDeleteAuditRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 19, 50, 50, 250, 0, 50, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    1);

  /**
   * @generated
   */
  public static class GetEObjXDeleteAuditParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setLong (stmt, 1, Types.BIGINT, (Long)parameters[0]);
    }
  }

  /**
   * @generated
   */
  public static class GetEObjXDeleteAuditRowHandler extends BaseRowHandler<EObjXDeleteAudit>
  {
    /**
     * @generated
     */
    public EObjXDeleteAudit handle (java.sql.ResultSet rs, EObjXDeleteAudit returnObject) throws java.sql.SQLException
    {
      returnObject = new EObjXDeleteAudit ();
      returnObject.setXDeleteAuditpkId(getLongObject (rs, 1)); 
      returnObject.setCONT_ID(getLongObject (rs, 2)); 
      returnObject.setADMIN_CLIENT_ID(getString (rs, 3)); 
      returnObject.setADMIN_SYSTEM_VALUE(getString (rs, 4)); 
      returnObject.setDESCRIPTION(getString (rs, 5)); 
      returnObject.setDELETE_DATE(getTimestamp (rs, 6)); 
      returnObject.setMARKET_NAME(getString (rs, 7)); 
      returnObject.setLastUpdateDt(getTimestamp (rs, 8)); 
      returnObject.setLastUpdateUser(getString (rs, 9)); 
      returnObject.setLastUpdateTxId(getLongObject (rs, 10)); 
    
      return returnObject;
    }
  }

  /**
   * @Update( sql="insert into XDELETEAUDIT (XDelete_Auditpk_Id, CONT_ID, ADMIN_CLIENT_ID, ADMIN_SYSTEM_VALUE, DESCRIPTION, DELETE_DATE, MARKET_NAME, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( :xDeleteAuditpkId, :cONT_ID, :aDMIN_CLIENT_ID, :aDMIN_SYSTEM_VALUE, :dESCRIPTION, :dELETE_DATE, :mARKET_NAME, :lastUpdateDt, :lastUpdateUser, :lastUpdateTxId)" )
   * 
   * @generated
   */
  public int createEObjXDeleteAudit (EObjXDeleteAudit e)
  {
    return update (createEObjXDeleteAuditStatementDescriptor, e);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor createEObjXDeleteAuditStatementDescriptor = createStatementDescriptor (
    "createEObjXDeleteAudit(com.ibm.daimler.dsea.entityObject.EObjXDeleteAudit)",
    "insert into XDELETEAUDIT (XDelete_Auditpk_Id, CONT_ID, ADMIN_CLIENT_ID, ADMIN_SYSTEM_VALUE, DESCRIPTION, DELETE_DATE, MARKET_NAME, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values(  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? )",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.INSERT,
    null,
    new CreateEObjXDeleteAuditParameterHandler (),
    new int[][]{{Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 19, 50, 50, 250, 0, 50, 0, 0, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1, 1, 1, 1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    2);

  /**
   * @generated
   */
  public static class CreateEObjXDeleteAuditParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      EObjXDeleteAudit bean0 = (EObjXDeleteAudit) parameters[0];
      setLong (stmt, 1, Types.BIGINT, (Long)bean0.getXDeleteAuditpkId());
      setLong (stmt, 2, Types.BIGINT, (Long)bean0.getCONT_ID());
      setString (stmt, 3, Types.VARCHAR, (String)bean0.getADMIN_CLIENT_ID());
      setString (stmt, 4, Types.VARCHAR, (String)bean0.getADMIN_SYSTEM_VALUE());
      setString (stmt, 5, Types.VARCHAR, (String)bean0.getDESCRIPTION());
      setTimestamp (stmt, 6, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getDELETE_DATE());
      setString (stmt, 7, Types.VARCHAR, (String)bean0.getMARKET_NAME());
      setTimestamp (stmt, 8, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUpdateDt());
      setString (stmt, 9, Types.VARCHAR, (String)bean0.getLastUpdateUser());
      setLong (stmt, 10, Types.BIGINT, (Long)bean0.getLastUpdateTxId());
    }
  }

  /**
   * @Update( sql="update XDELETEAUDIT set CONT_ID = :cONT_ID, ADMIN_CLIENT_ID = :aDMIN_CLIENT_ID, ADMIN_SYSTEM_VALUE = :aDMIN_SYSTEM_VALUE, DESCRIPTION = :dESCRIPTION, DELETE_DATE = :dELETE_DATE, MARKET_NAME = :mARKET_NAME, LAST_UPDATE_DT = :lastUpdateDt, LAST_UPDATE_USER = :lastUpdateUser, LAST_UPDATE_TX_ID = :lastUpdateTxId where XDelete_Auditpk_Id = :xDeleteAuditpkId and LAST_UPDATE_DT = :oldLastUpdateDt" )
   * 
   * @generated
   */
  public int updateEObjXDeleteAudit (EObjXDeleteAudit e)
  {
    return update (updateEObjXDeleteAuditStatementDescriptor, e);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor updateEObjXDeleteAuditStatementDescriptor = createStatementDescriptor (
    "updateEObjXDeleteAudit(com.ibm.daimler.dsea.entityObject.EObjXDeleteAudit)",
    "update XDELETEAUDIT set CONT_ID =  ? , ADMIN_CLIENT_ID =  ? , ADMIN_SYSTEM_VALUE =  ? , DESCRIPTION =  ? , DELETE_DATE =  ? , MARKET_NAME =  ? , LAST_UPDATE_DT =  ? , LAST_UPDATE_USER =  ? , LAST_UPDATE_TX_ID =  ?  where XDelete_Auditpk_Id =  ?  and LAST_UPDATE_DT =  ? ",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.UPDATE,
    null,
    new UpdateEObjXDeleteAuditParameterHandler (),
    new int[][]{{Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP}, {19, 50, 50, 250, 0, 50, 0, 0, 19, 19, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    3);

  /**
   * @generated
   */
  public static class UpdateEObjXDeleteAuditParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      EObjXDeleteAudit bean0 = (EObjXDeleteAudit) parameters[0];
      setLong (stmt, 1, Types.BIGINT, (Long)bean0.getCONT_ID());
      setString (stmt, 2, Types.VARCHAR, (String)bean0.getADMIN_CLIENT_ID());
      setString (stmt, 3, Types.VARCHAR, (String)bean0.getADMIN_SYSTEM_VALUE());
      setString (stmt, 4, Types.VARCHAR, (String)bean0.getDESCRIPTION());
      setTimestamp (stmt, 5, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getDELETE_DATE());
      setString (stmt, 6, Types.VARCHAR, (String)bean0.getMARKET_NAME());
      setTimestamp (stmt, 7, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUpdateDt());
      setString (stmt, 8, Types.VARCHAR, (String)bean0.getLastUpdateUser());
      setLong (stmt, 9, Types.BIGINT, (Long)bean0.getLastUpdateTxId());
      setLong (stmt, 10, Types.BIGINT, (Long)bean0.getXDeleteAuditpkId());
      setTimestamp (stmt, 11, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getOldLastUpdateDt());
    }
  }

  /**
   * @Update( sql="delete from XDELETEAUDIT where XDelete_Auditpk_Id = ?" )
   * 
   * @generated
   */
  public int deleteEObjXDeleteAudit (Long xDeleteAuditpkId)
  {
    return update (deleteEObjXDeleteAuditStatementDescriptor, xDeleteAuditpkId);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor deleteEObjXDeleteAuditStatementDescriptor = createStatementDescriptor (
    "deleteEObjXDeleteAudit(Long)",
    "delete from XDELETEAUDIT where XDelete_Auditpk_Id = ?",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.DELETE,
    null,
    new DeleteEObjXDeleteAuditParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    4);

  /**
   * @generated
   */
  public static class DeleteEObjXDeleteAuditParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setLong (stmt, 1, Types.BIGINT, (Long)parameters[0]);
    }
  }

}
