package com.ibm.daimler.dsea.entityObject;

import com.ibm.pdq.runtime.generator.BaseParameterHandler;
import java.util.Iterator;
import com.ibm.daimler.dsea.entityObject.EObjXVRCollapse;
import java.sql.PreparedStatement;
import com.ibm.pdq.runtime.statement.StatementDescriptor;
import com.ibm.pdq.runtime.generator.BaseData;
import java.sql.SQLException;
import com.ibm.pdq.annotation.Metadata;
import com.ibm.pdq.runtime.generator.BaseRowHandler;
import com.ibm.pdq.runtime.statement.SqlStatementType;
import java.sql.Types;


/**
 * <!-- begin-user-doc -->
 * 
 * <!-- end-user-doc -->
 * 
 * @generated
 */
public class EObjXVRCollapseDataImpl  extends BaseData implements EObjXVRCollapseData
{

  /**
   * @generated
   */
  public static final String generatorVersion = "3.200.75";

  /**
   * @generated
   */
  public static final String identifier = "EObjXVRCollapseData";

  /**
   * @generated
   */
  public static final long generationTime = 0x0000016eac1308a6L;

  /**
   * @generated
   */
  public static final String collection = "NULLID";

  /**
   * @generated
   */
  public static final String packageVersion = null;

  /**
   * @generated
   */
  public static final boolean forceSingleBindIsolation = false;

  /**
   * @generated
   */
  public EObjXVRCollapseDataImpl()
  {
    super();
  } 

  /**
   * @generated
   */
  public String getGeneratorVersion()
  {
    return generatorVersion;
  }

  /**
   * @Select( sql="select XVRCollapsepk_Id, SUSPECT_IDS, GOLDEN_CONT_ID, ACTION, FLAG, Create_Date, MARKET_NAME, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from XVRCOLLAPSE where XVRCollapsepk_Id = ? " )
   * 
   * @generated
   */
  public Iterator<EObjXVRCollapse> getEObjXVRCollapse (Long xVRCollapsepkId)
  {
    return queryIterator (getEObjXVRCollapseStatementDescriptor, xVRCollapsepkId);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getEObjXVRCollapseStatementDescriptor = createStatementDescriptor (
    "getEObjXVRCollapse(Long)",
    "select XVRCollapsepk_Id, SUSPECT_IDS, GOLDEN_CONT_ID, ACTION, FLAG, Create_Date, MARKET_NAME, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from XVRCOLLAPSE where XVRCollapsepk_Id = ? ",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"xvrcollapsepk_id", "suspect_ids", "golden_cont_id", "action", "flag", "create_date", "market_name", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetEObjXVRCollapseParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetEObjXVRCollapseRowHandler (),
    new int[][]{ {Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 1000, 250, 20, 10, 0, 5, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    1);

  /**
   * @generated
   */
  public static class GetEObjXVRCollapseParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setLong (stmt, 1, Types.BIGINT, (Long)parameters[0]);
    }
  }

  /**
   * @generated
   */
  public static class GetEObjXVRCollapseRowHandler extends BaseRowHandler<EObjXVRCollapse>
  {
    /**
     * @generated
     */
    public EObjXVRCollapse handle (java.sql.ResultSet rs, EObjXVRCollapse returnObject) throws java.sql.SQLException
    {
      returnObject = new EObjXVRCollapse ();
      returnObject.setXVRCollapsepkId(getLongObject (rs, 1)); 
      returnObject.setSuspectIds(getString (rs, 2)); 
      returnObject.setGoldenContId(getString (rs, 3)); 
      returnObject.setAction(getString (rs, 4)); 
      returnObject.setFlag(getString (rs, 5)); 
      returnObject.setCreateDate(getTimestamp (rs, 6)); 
      returnObject.setMarketName(getString (rs, 7)); 
      returnObject.setLastUpdateDt(getTimestamp (rs, 8)); 
      returnObject.setLastUpdateUser(getString (rs, 9)); 
      returnObject.setLastUpdateTxId(getLongObject (rs, 10)); 
    
      return returnObject;
    }
  }

  /**
   * @Update( sql="insert into XVRCOLLAPSE (XVRCollapsepk_Id, SUSPECT_IDS, GOLDEN_CONT_ID, ACTION, FLAG, Create_Date, MARKET_NAME, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( :xVRCollapsepkId, :suspectIds, :goldenContId, :action, :flag, :createDate, :marketName, :lastUpdateDt, :lastUpdateUser, :lastUpdateTxId)" )
   * 
   * @generated
   */
  public int createEObjXVRCollapse (EObjXVRCollapse e)
  {
    return update (createEObjXVRCollapseStatementDescriptor, e);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor createEObjXVRCollapseStatementDescriptor = createStatementDescriptor (
    "createEObjXVRCollapse(com.ibm.daimler.dsea.entityObject.EObjXVRCollapse)",
    "insert into XVRCOLLAPSE (XVRCollapsepk_Id, SUSPECT_IDS, GOLDEN_CONT_ID, ACTION, FLAG, Create_Date, MARKET_NAME, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values(  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? )",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.INSERT,
    null,
    new CreateEObjXVRCollapseParameterHandler (),
    new int[][]{{Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 1000, 250, 20, 10, 0, 5, 0, 0, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1, 1, 1, 1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    2);

  /**
   * @generated
   */
  public static class CreateEObjXVRCollapseParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      EObjXVRCollapse bean0 = (EObjXVRCollapse) parameters[0];
      setLong (stmt, 1, Types.BIGINT, (Long)bean0.getXVRCollapsepkId());
      setString (stmt, 2, Types.VARCHAR, (String)bean0.getSuspectIds());
      setString (stmt, 3, Types.VARCHAR, (String)bean0.getGoldenContId());
      setString (stmt, 4, Types.VARCHAR, (String)bean0.getAction());
      setString (stmt, 5, Types.VARCHAR, (String)bean0.getFlag());
      setTimestamp (stmt, 6, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getCreateDate());
      setString (stmt, 7, Types.VARCHAR, (String)bean0.getMarketName());
      setTimestamp (stmt, 8, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUpdateDt());
      setString (stmt, 9, Types.VARCHAR, (String)bean0.getLastUpdateUser());
      setLong (stmt, 10, Types.BIGINT, (Long)bean0.getLastUpdateTxId());
    }
  }

  /**
   * @Update( sql="update XVRCOLLAPSE set SUSPECT_IDS = :suspectIds, GOLDEN_CONT_ID = :goldenContId, ACTION = :action, FLAG = :flag, Create_Date = :createDate, MARKET_NAME = :marketName, LAST_UPDATE_DT = :lastUpdateDt, LAST_UPDATE_USER = :lastUpdateUser, LAST_UPDATE_TX_ID = :lastUpdateTxId where XVRCollapsepk_Id = :xVRCollapsepkId and LAST_UPDATE_DT = :oldLastUpdateDt" )
   * 
   * @generated
   */
  public int updateEObjXVRCollapse (EObjXVRCollapse e)
  {
    return update (updateEObjXVRCollapseStatementDescriptor, e);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor updateEObjXVRCollapseStatementDescriptor = createStatementDescriptor (
    "updateEObjXVRCollapse(com.ibm.daimler.dsea.entityObject.EObjXVRCollapse)",
    "update XVRCOLLAPSE set SUSPECT_IDS =  ? , GOLDEN_CONT_ID =  ? , ACTION =  ? , FLAG =  ? , Create_Date =  ? , MARKET_NAME =  ? , LAST_UPDATE_DT =  ? , LAST_UPDATE_USER =  ? , LAST_UPDATE_TX_ID =  ?  where XVRCollapsepk_Id =  ?  and LAST_UPDATE_DT =  ? ",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.UPDATE,
    null,
    new UpdateEObjXVRCollapseParameterHandler (),
    new int[][]{{Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP}, {1000, 250, 20, 10, 0, 5, 0, 0, 19, 19, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    3);

  /**
   * @generated
   */
  public static class UpdateEObjXVRCollapseParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      EObjXVRCollapse bean0 = (EObjXVRCollapse) parameters[0];
      setString (stmt, 1, Types.VARCHAR, (String)bean0.getSuspectIds());
      setString (stmt, 2, Types.VARCHAR, (String)bean0.getGoldenContId());
      setString (stmt, 3, Types.VARCHAR, (String)bean0.getAction());
      setString (stmt, 4, Types.VARCHAR, (String)bean0.getFlag());
      setTimestamp (stmt, 5, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getCreateDate());
      setString (stmt, 6, Types.VARCHAR, (String)bean0.getMarketName());
      setTimestamp (stmt, 7, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUpdateDt());
      setString (stmt, 8, Types.VARCHAR, (String)bean0.getLastUpdateUser());
      setLong (stmt, 9, Types.BIGINT, (Long)bean0.getLastUpdateTxId());
      setLong (stmt, 10, Types.BIGINT, (Long)bean0.getXVRCollapsepkId());
      setTimestamp (stmt, 11, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getOldLastUpdateDt());
    }
  }

  /**
   * @Update( sql="delete from XVRCOLLAPSE where XVRCollapsepk_Id = ?" )
   * 
   * @generated
   */
  public int deleteEObjXVRCollapse (Long xVRCollapsepkId)
  {
    return update (deleteEObjXVRCollapseStatementDescriptor, xVRCollapsepkId);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor deleteEObjXVRCollapseStatementDescriptor = createStatementDescriptor (
    "deleteEObjXVRCollapse(Long)",
    "delete from XVRCOLLAPSE where XVRCollapsepk_Id = ?",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.DELETE,
    null,
    new DeleteEObjXVRCollapseParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    4);

  /**
   * @generated
   */
  public static class DeleteEObjXVRCollapseParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setLong (stmt, 1, Types.BIGINT, (Long)parameters[0]);
    }
  }

}
