package com.ibm.daimler.dsea.entityObject;

import com.ibm.pdq.runtime.generator.BaseParameterHandler;
import java.util.Iterator;
import com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRoleKOR;
import java.sql.PreparedStatement;
import com.ibm.pdq.runtime.statement.StatementDescriptor;
import com.ibm.pdq.runtime.generator.BaseData;
import java.sql.SQLException;
import com.ibm.pdq.annotation.Metadata;
import com.ibm.pdq.runtime.generator.BaseRowHandler;
import com.ibm.pdq.runtime.statement.SqlStatementType;
import java.sql.Types;


/**
 * <!-- begin-user-doc -->
 * 
 * <!-- end-user-doc -->
 * 
 * @generated
 */
public class EObjXCustomerVehicleRoleKORDataImpl  extends BaseData implements EObjXCustomerVehicleRoleKORData
{

  /**
   * @generated
   */
  public static final String generatorVersion = "3.200.75";

  /**
   * @generated
   */
  public static final String identifier = "EObjXCustomerVehicleRoleKORData";

  /**
   * @generated
   */
  public static final long generationTime = 0x00000166f7ce19deL;

  /**
   * @generated
   */
  public static final String collection = "NULLID";

  /**
   * @generated
   */
  public static final String packageVersion = null;

  /**
   * @generated
   */
  public static final boolean forceSingleBindIsolation = false;

  /**
   * @generated
   */
  public EObjXCustomerVehicleRoleKORDataImpl()
  {
    super();
  } 

  /**
   * @generated
   */
  public String getGeneratorVersion()
  {
    return generatorVersion;
  }

  /**
   * @Select( sql="select XCUSTOMERVEHICLEROLEKORPK_ID, CUSTOMER_VEHICLE_ID, VEHICLE_ROLE_TP_CD, START_DT, END_DT, SOURCE_IDENT_TP_CD, CHANGED_DT, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from XCUSTOMERVEHICLEROLEKOR where XCUSTOMERVEHICLEROLEKORPK_ID = ? " )
   * 
   * @generated
   */
  public Iterator<EObjXCustomerVehicleRoleKOR> getEObjXCustomerVehicleRoleKOR (Long xCustomerVehicleRoleKORpkId)
  {
    return queryIterator (getEObjXCustomerVehicleRoleKORStatementDescriptor, xCustomerVehicleRoleKORpkId);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getEObjXCustomerVehicleRoleKORStatementDescriptor = createStatementDescriptor (
    "getEObjXCustomerVehicleRoleKOR(Long)",
    "select XCUSTOMERVEHICLEROLEKORPK_ID, CUSTOMER_VEHICLE_ID, VEHICLE_ROLE_TP_CD, START_DT, END_DT, SOURCE_IDENT_TP_CD, CHANGED_DT, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from XCUSTOMERVEHICLEROLEKOR where XCUSTOMERVEHICLEROLEKORPK_ID = ? ",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"xcustomervehiclerolekorpk_id", "customer_vehicle_id", "vehicle_role_tp_cd", "start_dt", "end_dt", "source_ident_tp_cd", "changed_dt", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetEObjXCustomerVehicleRoleKORParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetEObjXCustomerVehicleRoleKORRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 19, 19, 0, 0, 19, 0, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    1);

  /**
   * @generated
   */
  public static class GetEObjXCustomerVehicleRoleKORParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setLong (stmt, 1, Types.BIGINT, (Long)parameters[0]);
    }
  }

  /**
   * @generated
   */
  public static class GetEObjXCustomerVehicleRoleKORRowHandler extends BaseRowHandler<EObjXCustomerVehicleRoleKOR>
  {
    /**
     * @generated
     */
    public EObjXCustomerVehicleRoleKOR handle (java.sql.ResultSet rs, EObjXCustomerVehicleRoleKOR returnObject) throws java.sql.SQLException
    {
      returnObject = new EObjXCustomerVehicleRoleKOR ();
      returnObject.setXCustomerVehicleRoleKORpkId(getLongObject (rs, 1)); 
      returnObject.setCustomerVehicleId(getLongObject (rs, 2)); 
      returnObject.setVehicleRole(getLongObject (rs, 3)); 
      returnObject.setStartDate(getTimestamp (rs, 4)); 
      returnObject.setEndDate(getTimestamp (rs, 5)); 
      returnObject.setSourceIdentifier(getLongObject (rs, 6)); 
      returnObject.setChangedDate(getTimestamp (rs, 7)); 
      returnObject.setLastUpdateDt(getTimestamp (rs, 8)); 
      returnObject.setLastUpdateUser(getString (rs, 9)); 
      returnObject.setLastUpdateTxId(getLongObject (rs, 10)); 
    
      return returnObject;
    }
  }

  /**
   * @Update( sql="insert into XCUSTOMERVEHICLEROLEKOR (XCUSTOMERVEHICLEROLEKORPK_ID, CUSTOMER_VEHICLE_ID, VEHICLE_ROLE_TP_CD, START_DT, END_DT, SOURCE_IDENT_TP_CD, CHANGED_DT, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( :xCustomerVehicleRoleKORpkId, :customerVehicleId, :vehicleRole, :startDate, :endDate, :sourceIdentifier, :changedDate, :lastUpdateDt, :lastUpdateUser, :lastUpdateTxId)" )
   * 
   * @generated
   */
  public int createEObjXCustomerVehicleRoleKOR (EObjXCustomerVehicleRoleKOR e)
  {
    return update (createEObjXCustomerVehicleRoleKORStatementDescriptor, e);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor createEObjXCustomerVehicleRoleKORStatementDescriptor = createStatementDescriptor (
    "createEObjXCustomerVehicleRoleKOR(com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRoleKOR)",
    "insert into XCUSTOMERVEHICLEROLEKOR (XCUSTOMERVEHICLEROLEKORPK_ID, CUSTOMER_VEHICLE_ID, VEHICLE_ROLE_TP_CD, START_DT, END_DT, SOURCE_IDENT_TP_CD, CHANGED_DT, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values(  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? )",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.INSERT,
    null,
    new CreateEObjXCustomerVehicleRoleKORParameterHandler (),
    new int[][]{{Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 19, 19, 0, 0, 19, 0, 0, 0, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1, 1, 1, 1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    2);

  /**
   * @generated
   */
  public static class CreateEObjXCustomerVehicleRoleKORParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      EObjXCustomerVehicleRoleKOR bean0 = (EObjXCustomerVehicleRoleKOR) parameters[0];
      setLong (stmt, 1, Types.BIGINT, (Long)bean0.getXCustomerVehicleRoleKORpkId());
      setLong (stmt, 2, Types.BIGINT, (Long)bean0.getCustomerVehicleId());
      setLong (stmt, 3, Types.BIGINT, (Long)bean0.getVehicleRole());
      setTimestamp (stmt, 4, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getStartDate());
      setTimestamp (stmt, 5, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getEndDate());
      setLong (stmt, 6, Types.BIGINT, (Long)bean0.getSourceIdentifier());
      setTimestamp (stmt, 7, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getChangedDate());
      setTimestamp (stmt, 8, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUpdateDt());
      setString (stmt, 9, Types.VARCHAR, (String)bean0.getLastUpdateUser());
      setLong (stmt, 10, Types.BIGINT, (Long)bean0.getLastUpdateTxId());
    }
  }

  /**
   * @Update( sql="update XCUSTOMERVEHICLEROLEKOR set CUSTOMER_VEHICLE_ID = :customerVehicleId, VEHICLE_ROLE_TP_CD = :vehicleRole, START_DT = :startDate, END_DT = :endDate, SOURCE_IDENT_TP_CD = :sourceIdentifier, CHANGED_DT = :changedDate, LAST_UPDATE_DT = :lastUpdateDt, LAST_UPDATE_USER = :lastUpdateUser, LAST_UPDATE_TX_ID = :lastUpdateTxId where XCUSTOMERVEHICLEROLEKORPK_ID = :xCustomerVehicleRoleKORpkId and LAST_UPDATE_DT = :oldLastUpdateDt" )
   * 
   * @generated
   */
  public int updateEObjXCustomerVehicleRoleKOR (EObjXCustomerVehicleRoleKOR e)
  {
    return update (updateEObjXCustomerVehicleRoleKORStatementDescriptor, e);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor updateEObjXCustomerVehicleRoleKORStatementDescriptor = createStatementDescriptor (
    "updateEObjXCustomerVehicleRoleKOR(com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRoleKOR)",
    "update XCUSTOMERVEHICLEROLEKOR set CUSTOMER_VEHICLE_ID =  ? , VEHICLE_ROLE_TP_CD =  ? , START_DT =  ? , END_DT =  ? , SOURCE_IDENT_TP_CD =  ? , CHANGED_DT =  ? , LAST_UPDATE_DT =  ? , LAST_UPDATE_USER =  ? , LAST_UPDATE_TX_ID =  ?  where XCUSTOMERVEHICLEROLEKORPK_ID =  ?  and LAST_UPDATE_DT =  ? ",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.UPDATE,
    null,
    new UpdateEObjXCustomerVehicleRoleKORParameterHandler (),
    new int[][]{{Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP}, {19, 19, 0, 0, 19, 0, 0, 0, 19, 19, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    3);

  /**
   * @generated
   */
  public static class UpdateEObjXCustomerVehicleRoleKORParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      EObjXCustomerVehicleRoleKOR bean0 = (EObjXCustomerVehicleRoleKOR) parameters[0];
      setLong (stmt, 1, Types.BIGINT, (Long)bean0.getCustomerVehicleId());
      setLong (stmt, 2, Types.BIGINT, (Long)bean0.getVehicleRole());
      setTimestamp (stmt, 3, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getStartDate());
      setTimestamp (stmt, 4, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getEndDate());
      setLong (stmt, 5, Types.BIGINT, (Long)bean0.getSourceIdentifier());
      setTimestamp (stmt, 6, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getChangedDate());
      setTimestamp (stmt, 7, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUpdateDt());
      setString (stmt, 8, Types.VARCHAR, (String)bean0.getLastUpdateUser());
      setLong (stmt, 9, Types.BIGINT, (Long)bean0.getLastUpdateTxId());
      setLong (stmt, 10, Types.BIGINT, (Long)bean0.getXCustomerVehicleRoleKORpkId());
      setTimestamp (stmt, 11, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getOldLastUpdateDt());
    }
  }

  /**
   * @Update( sql="delete from XCUSTOMERVEHICLEROLEKOR where XCUSTOMERVEHICLEROLEKORPK_ID = ?" )
   * 
   * @generated
   */
  public int deleteEObjXCustomerVehicleRoleKOR (Long xCustomerVehicleRoleKORpkId)
  {
    return update (deleteEObjXCustomerVehicleRoleKORStatementDescriptor, xCustomerVehicleRoleKORpkId);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor deleteEObjXCustomerVehicleRoleKORStatementDescriptor = createStatementDescriptor (
    "deleteEObjXCustomerVehicleRoleKOR(Long)",
    "delete from XCUSTOMERVEHICLEROLEKOR where XCUSTOMERVEHICLEROLEKORPK_ID = ?",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.DELETE,
    null,
    new DeleteEObjXCustomerVehicleRoleKORParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    4);

  /**
   * @generated
   */
  public static class DeleteEObjXCustomerVehicleRoleKORParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setLong (stmt, 1, Types.BIGINT, (Long)parameters[0]);
    }
  }

}
