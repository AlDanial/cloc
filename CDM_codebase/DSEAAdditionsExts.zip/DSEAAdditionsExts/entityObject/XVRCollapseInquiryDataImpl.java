package com.ibm.daimler.dsea.entityObject;

import com.ibm.pdq.runtime.generator.BaseParameterHandler;
import java.util.Iterator;
import com.ibm.mdm.base.db.ResultQueue1;
import com.ibm.daimler.dsea.entityObject.EObjXVRCollapse;
import java.sql.PreparedStatement;
import com.ibm.pdq.runtime.statement.StatementDescriptor;
import com.ibm.pdq.runtime.generator.BaseData;
import java.sql.SQLException;
import com.ibm.pdq.annotation.Metadata;
import com.ibm.pdq.runtime.generator.BaseRowHandler;
import com.ibm.pdq.runtime.statement.SqlStatementType;
import java.sql.Types;


@SuppressWarnings("unchecked")

/**
 * <!-- begin-user-doc -->
 * 
 * <!-- end-user-doc -->
 * 
 * @generated
 */
public class XVRCollapseInquiryDataImpl  extends BaseData implements XVRCollapseInquiryData
{

  /**
   * @generated
   */
  public static final String generatorVersion = "3.200.75";

  /**
   * @generated
   */
  public static final String identifier = "XVRCollapseInquiryData";

  /**
   * @generated
   */
  public static final long generationTime = 0x0000016eac130928L;

  /**
   * @generated
   */
  public static final String collection = "NULLID";

  /**
   * @generated
   */
  public static final String packageVersion = null;

  /**
   * @generated
   */
  public static final boolean forceSingleBindIsolation = false;

  /**
   * @generated
   */
  public XVRCollapseInquiryDataImpl()
  {
    super();
  } 

  /**
   * @generated
   */
  public String getGeneratorVersion()
  {
    return generatorVersion;
  }

  /**
   * @Select( sql="SELECT r.XVRCollapsepk_Id XVRCollapsepk_Id, r.SUSPECT_IDS SUSPECT_IDS, r.GOLDEN_CONT_ID GOLDEN_CONT_ID, r.ACTION ACTION, r.FLAG FLAG, r.Create_Date Create_Date, r.MARKET_NAME MARKET_NAME, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XVRCOLLAPSE r WHERE r.XVRCollapsepk_Id = ? ", pattern="tableAlias (XVRCOLLAPSE => com.ibm.daimler.dsea.entityObject.EObjXVRCollapse, H_XVRCOLLAPSE => com.ibm.daimler.dsea.entityObject.EObjXVRCollapse)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue1<EObjXVRCollapse>> getXVRCollapse (Object[] parameters)
  {
    return queryIterator (getXVRCollapseStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getXVRCollapseStatementDescriptor = createStatementDescriptor (
    "getXVRCollapse(Object[])",
    "SELECT r.XVRCollapsepk_Id XVRCollapsepk_Id, r.SUSPECT_IDS SUSPECT_IDS, r.GOLDEN_CONT_ID GOLDEN_CONT_ID, r.ACTION ACTION, r.FLAG FLAG, r.Create_Date Create_Date, r.MARKET_NAME MARKET_NAME, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XVRCOLLAPSE r WHERE r.XVRCollapsepk_Id = ? ",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"xvrcollapsepk_id", "suspect_ids", "golden_cont_id", "action", "flag", "create_date", "market_name", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetXVRCollapseParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetXVRCollapseRowHandler (),
    new int[][]{ {Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 1000, 250, 20, 10, 0, 5, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    1);

  /**
   * @generated
   */
  public static class GetXVRCollapseParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetXVRCollapseRowHandler extends BaseRowHandler<ResultQueue1<EObjXVRCollapse>>
  {
    /**
     * @generated
     */
    public ResultQueue1<EObjXVRCollapse> handle (java.sql.ResultSet rs, ResultQueue1<EObjXVRCollapse> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue1<EObjXVRCollapse> ();

      EObjXVRCollapse returnObject1 = new EObjXVRCollapse ();
      returnObject1.setXVRCollapsepkId(getLongObject (rs, 1)); 
      returnObject1.setSuspectIds(getString (rs, 2)); 
      returnObject1.setGoldenContId(getString (rs, 3)); 
      returnObject1.setAction(getString (rs, 4)); 
      returnObject1.setFlag(getString (rs, 5)); 
      returnObject1.setCreateDate(getTimestamp (rs, 6)); 
      returnObject1.setMarketName(getString (rs, 7)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 8)); 
      returnObject1.setLastUpdateUser(getString (rs, 9)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 10)); 
      returnObject.add (returnObject1);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT r.H_XVRCollapsepk_Id hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.XVRCollapsepk_Id XVRCollapsepk_Id, r.SUSPECT_IDS SUSPECT_IDS, r.GOLDEN_CONT_ID GOLDEN_CONT_ID, r.ACTION ACTION, r.FLAG FLAG, r.Create_Date Create_Date, r.MARKET_NAME MARKET_NAME, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XVRCOLLAPSE r WHERE r.H_XVRCollapsepk_Id = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))", pattern="tableAlias (XVRCOLLAPSE => com.ibm.daimler.dsea.entityObject.EObjXVRCollapse, H_XVRCOLLAPSE => com.ibm.daimler.dsea.entityObject.EObjXVRCollapse)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue1<EObjXVRCollapse>> getXVRCollapseHistory (Object[] parameters)
  {
    return queryIterator (getXVRCollapseHistoryStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getXVRCollapseHistoryStatementDescriptor = createStatementDescriptor (
    "getXVRCollapseHistory(Object[])",
    "SELECT r.H_XVRCollapsepk_Id hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.XVRCollapsepk_Id XVRCollapsepk_Id, r.SUSPECT_IDS SUSPECT_IDS, r.GOLDEN_CONT_ID GOLDEN_CONT_ID, r.ACTION ACTION, r.FLAG FLAG, r.Create_Date Create_Date, r.MARKET_NAME MARKET_NAME, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XVRCOLLAPSE r WHERE r.H_XVRCollapsepk_Id = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"historyidpk", "h_action_code", "h_created_by", "h_create_dt", "h_end_dt", "xvrcollapsepk_id", "suspect_ids", "golden_cont_id", "action", "flag", "create_date", "market_name", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetXVRCollapseHistoryParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP}, {19, 0, 0}, {0, 0, 0}, {1, 1, 1}},
    null,
    new GetXVRCollapseHistoryRowHandler (),
    new int[][]{ {Types.BIGINT, Types.CHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 1, 20, 0, 0, 19, 1000, 250, 20, 10, 0, 5, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    2);

  /**
   * @generated
   */
  public static class GetXVRCollapseHistoryParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetXVRCollapseHistoryRowHandler extends BaseRowHandler<ResultQueue1<EObjXVRCollapse>>
  {
    /**
     * @generated
     */
    public ResultQueue1<EObjXVRCollapse> handle (java.sql.ResultSet rs, ResultQueue1<EObjXVRCollapse> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue1<EObjXVRCollapse> ();

      EObjXVRCollapse returnObject1 = new EObjXVRCollapse ();
      returnObject1.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject1.setHistActionCode(getString (rs, 2)); 
      returnObject1.setHistCreatedBy(getString (rs, 3)); 
      returnObject1.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject1.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject1.setXVRCollapsepkId(getLongObject (rs, 6)); 
      returnObject1.setSuspectIds(getString (rs, 7)); 
      returnObject1.setGoldenContId(getString (rs, 8)); 
      returnObject1.setAction(getString (rs, 9)); 
      returnObject1.setFlag(getString (rs, 10)); 
      returnObject1.setCreateDate(getTimestamp (rs, 11)); 
      returnObject1.setMarketName(getString (rs, 12)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 13)); 
      returnObject1.setLastUpdateUser(getString (rs, 14)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 15)); 
      returnObject.add (returnObject1);

    
      return returnObject;
    }
  }

}
