/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[fa0db9a656947abc81d69cc3abe97c00]
 */

package com.ibm.daimler.dsea.entityObject;

import com.dwl.base.EObjCommon;
import com.ibm.mdm.base.db.DataType;
import com.ibm.pdq.annotation.Column;
import com.ibm.pdq.annotation.Table;


import com.ibm.pdq.annotation.Id;

import java.sql.Timestamp;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * The entity object corresponding to the XPreference business object. This
 * entity object should include all the attributes as defined by the business
 * object.
 * 
 * @generated
 */
@SuppressWarnings("serial")
@Table(name=EObjXPreference.tableName)
public class EObjXPreference extends EObjCommon {

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public static final String tableName = "XPREFERENCE";
    
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String preferencepkIdColumn = "PREFERENCEPK_ID";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String preferencepkIdJdbcType = "BIGINT";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    preferencepkIdPrecision = 19;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String locationGroupIdColumn = "LOCATION_GROUP_ID";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String locationGroupIdJdbcType = "BIGINT";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    locationGroupIdPrecision = 19;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String preferredColumn = "PREFERENCE_TP_CD";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String preferredJdbcType = "BIGINT";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    preferredPrecision = 19;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String sourceIdentifierColumn = "SOURCE_IDENT_TP_CD";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String sourceIdentifierJdbcType = "BIGINT";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    sourceIdentifierPrecision = 19;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String startDateColumn = "START_DT";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String startDateJdbcType = "TIMESTAMP";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String endDateColumn = "END_DT";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String endDateJdbcType = "TIMESTAMP";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String lastModifiedSystemDateColumn = "MODIFY_SYS_DT";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String lastModifiedSystemDateJdbcType = "TIMESTAMP";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected Long preferencepkId;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected Long locationGroupId;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected Long preferred;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected Long sourceIdentifier;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected  Timestamp startDate;
    //inside if 

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected  Timestamp endDate;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected  Timestamp lastModifiedSystemDate;
    //inside if 



    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Default constructor.     
     *
     * @generated
     */
    public EObjXPreference() {
        super();
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the preferencepkId attribute. 
     *
     * @generated
     */
    @Id
    @Column(name=preferencepkIdColumn)
    @DataType(jdbcType=preferencepkIdJdbcType, precision=preferencepkIdPrecision)
    public Long getPreferencepkId (){
        return preferencepkId;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the preferencepkId attribute. 
     *
     * @param preferencepkId
     *     The new value of PreferencepkId. 
     * @generated
     */
    public void setPreferencepkId( Long preferencepkId ){
        this.preferencepkId = preferencepkId;
    
        super.setIdPK(preferencepkId);
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the locationGroupId attribute. 
     *
     * @generated
     */
    @Column(name=locationGroupIdColumn)
    @DataType(jdbcType=locationGroupIdJdbcType, precision=locationGroupIdPrecision)
    public Long getLocationGroupId (){
        return locationGroupId;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the locationGroupId attribute. 
     *
     * @param locationGroupId
     *     The new value of LocationGroupId. 
     * @generated
     */
    public void setLocationGroupId( Long locationGroupId ){
        this.locationGroupId = locationGroupId;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the preferred attribute. 
     *
     * @generated
     */
    @Column(name=preferredColumn)
    @DataType(jdbcType=preferredJdbcType, precision=preferredPrecision)
    public Long getPreferred (){
        return preferred;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the preferred attribute. 
     *
     * @param preferred
     *     The new value of Preferred. 
     * @generated
     */
    public void setPreferred( Long preferred ){
        this.preferred = preferred;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the sourceIdentifier attribute. 
     *
     * @generated
     */
    @Column(name=sourceIdentifierColumn)
    @DataType(jdbcType=sourceIdentifierJdbcType, precision=sourceIdentifierPrecision)
    public Long getSourceIdentifier (){
        return sourceIdentifier;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the sourceIdentifier attribute. 
     *
     * @param sourceIdentifier
     *     The new value of SourceIdentifier. 
     * @generated
     */
    public void setSourceIdentifier( Long sourceIdentifier ){
        this.sourceIdentifier = sourceIdentifier;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the startDate attribute. 
     *
     * @generated
     */
    @Column(name=startDateColumn)
    @DataType(jdbcType=startDateJdbcType)
    public Timestamp getStartDate (){
        return startDate;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the startDate attribute. 
     *
     * @param startDate
     *     The new value of StartDate. 
     * @generated
     */
    public void setStartDate( Timestamp startDate ){
        this.startDate = startDate;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the endDate attribute. 
     *
     * @generated
     */
    @Column(name=endDateColumn)
    @DataType(jdbcType=endDateJdbcType)
    public Timestamp getEndDate (){
        return endDate;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the endDate attribute. 
     *
     * @param endDate
     *     The new value of EndDate. 
     * @generated
     */
    public void setEndDate( Timestamp endDate ){
        this.endDate = endDate;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the lastModifiedSystemDate attribute. 
     *
     * @generated
     */
    @Column(name=lastModifiedSystemDateColumn)
    @DataType(jdbcType=lastModifiedSystemDateJdbcType)
    public Timestamp getLastModifiedSystemDate (){
        return lastModifiedSystemDate;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the lastModifiedSystemDate attribute. 
     *
     * @param lastModifiedSystemDate
     *     The new value of LastModifiedSystemDate. 
     * @generated
     */
    public void setLastModifiedSystemDate( Timestamp lastModifiedSystemDate ){
        this.lastModifiedSystemDate = lastModifiedSystemDate;
    
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the primary key. 
     *
     * @param aUniqueId
     *     The new value of the primary key. 
     * @generated
   */
	public void setPrimaryKey(Object aUniqueId) {
    this.setPreferencepkId((Long)aUniqueId);
  }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the primary key.
     *
     * @generated
     */
	public Object getPrimaryKey() {
    return this.getPreferencepkId();
  }
	 
}


