package com.ibm.daimler.dsea.entityObject;

import com.ibm.pdq.runtime.generator.BaseParameterHandler;
import com.ibm.daimler.dsea.entityObject.EObjXRetailerJPN;
import java.util.Iterator;
import java.sql.PreparedStatement;
import com.ibm.pdq.runtime.statement.StatementDescriptor;
import com.ibm.pdq.runtime.generator.BaseData;
import java.sql.SQLException;
import com.ibm.pdq.annotation.Metadata;
import com.ibm.pdq.runtime.generator.BaseRowHandler;
import com.ibm.pdq.runtime.statement.SqlStatementType;
import java.sql.Types;


/**
 * <!-- begin-user-doc -->
 * 
 * <!-- end-user-doc -->
 * 
 * @generated
 */
public class EObjXRetailerJPNDataImpl  extends BaseData implements EObjXRetailerJPNData
{

  /**
   * @generated
   */
  public static final String generatorVersion = "3.200.75";

  /**
   * @generated
   */
  public static final String identifier = "EObjXRetailerJPNData";

  /**
   * @generated
   */
  public static final long generationTime = 0x00000164228400fbL;

  /**
   * @generated
   */
  public static final String collection = "NULLID";

  /**
   * @generated
   */
  public static final String packageVersion = null;

  /**
   * @generated
   */
  public static final boolean forceSingleBindIsolation = false;

  /**
   * @generated
   */
  public EObjXRetailerJPNDataImpl()
  {
    super();
  } 

  /**
   * @generated
   */
  public String getGeneratorVersion()
  {
    return generatorVersion;
  }

  /**
   * @Select( sql="select XRETAILERJPNPK_ID, RETAILER_CODE, RETAILER_NAME, BRANCH_NAME, SOURCE_IDENT_TP_CD, GS_CODE, GC_CODE, MODIFY_SYS_DT, ND_CODE, MARKET_NAME, DEALER_ACTIVE_FLAG, Dealer_Group, DEALER_ROLLOUT_FLAG, BATCH_IND, CREATE_DT, CHANGED_DT, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from XRETAILERJPN where XRETAILERJPNPK_ID = ? " )
   * 
   * @generated
   */
  public Iterator<EObjXRetailerJPN> getEObjXRetailerJPN (Long xRetailerJPNpkId)
  {
    return queryIterator (getEObjXRetailerJPNStatementDescriptor, xRetailerJPNpkId);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getEObjXRetailerJPNStatementDescriptor = createStatementDescriptor (
    "getEObjXRetailerJPN(Long)",
    "select XRETAILERJPNPK_ID, RETAILER_CODE, RETAILER_NAME, BRANCH_NAME, SOURCE_IDENT_TP_CD, GS_CODE, GC_CODE, MODIFY_SYS_DT, ND_CODE, MARKET_NAME, DEALER_ACTIVE_FLAG, Dealer_Group, DEALER_ROLLOUT_FLAG, BATCH_IND, CREATE_DT, CHANGED_DT, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from XRETAILERJPN where XRETAILERJPNPK_ID = ? ",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"xretailerjpnpk_id", "retailer_code", "retailer_name", "branch_name", "source_ident_tp_cd", "gs_code", "gc_code", "modify_sys_dt", "nd_code", "market_name", "dealer_active_flag", "dealer_group", "dealer_rollout_flag", "batch_ind", "create_dt", "changed_dt", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetEObjXRetailerJPNParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetEObjXRetailerJPNRowHandler (),
    new int[][]{ {Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 20, 255, 255, 19, 20, 20, 0, 20, 50, 5, 255, 5, 5, 0, 0, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    1);

  /**
   * @generated
   */
  public static class GetEObjXRetailerJPNParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setLong (stmt, 1, Types.BIGINT, (Long)parameters[0]);
    }
  }

  /**
   * @generated
   */
  public static class GetEObjXRetailerJPNRowHandler extends BaseRowHandler<EObjXRetailerJPN>
  {
    /**
     * @generated
     */
    public EObjXRetailerJPN handle (java.sql.ResultSet rs, EObjXRetailerJPN returnObject) throws java.sql.SQLException
    {
      returnObject = new EObjXRetailerJPN ();
      returnObject.setXRetailerJPNpkId(getLongObject (rs, 1)); 
      returnObject.setRetailerCode(getString (rs, 2)); 
      returnObject.setRetailerName(getString (rs, 3)); 
      returnObject.setBranchName(getString (rs, 4)); 
      returnObject.setSourceIdentifier(getLongObject (rs, 5)); 
      returnObject.setGSCode(getString (rs, 6)); 
      returnObject.setGCCode(getString (rs, 7)); 
      returnObject.setLastModifiedSystemDate(getTimestamp (rs, 8)); 
      returnObject.setNDCode(getString (rs, 9)); 
      returnObject.setMarketName(getString (rs, 10)); 
      returnObject.setDealerActiveFlag(getString (rs, 11)); 
      returnObject.setDealerGroup(getString (rs, 12)); 
      returnObject.setDealerRolloutFlag(getString (rs, 13)); 
      returnObject.setBatchInd(getString (rs, 14)); 
      returnObject.setCreateDate(getTimestamp (rs, 15)); 
      returnObject.setChangedDate(getTimestamp (rs, 16)); 
      returnObject.setLastUpdateDt(getTimestamp (rs, 17)); 
      returnObject.setLastUpdateUser(getString (rs, 18)); 
      returnObject.setLastUpdateTxId(getLongObject (rs, 19)); 
    
      return returnObject;
    }
  }

  /**
   * @Update( sql="insert into XRETAILERJPN (XRETAILERJPNPK_ID, RETAILER_CODE, RETAILER_NAME, BRANCH_NAME, SOURCE_IDENT_TP_CD, GS_CODE, GC_CODE, MODIFY_SYS_DT, ND_CODE, MARKET_NAME, DEALER_ACTIVE_FLAG, Dealer_Group, DEALER_ROLLOUT_FLAG, BATCH_IND, CREATE_DT, CHANGED_DT, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( :xRetailerJPNpkId, :retailerCode, :retailerName, :branchName, :sourceIdentifier, :gSCode, :gCCode, :lastModifiedSystemDate, :nDCode, :marketName, :dealerActiveFlag, :dealerGroup, :dealerRolloutFlag, :batchInd, :createDate, :changedDate, :lastUpdateDt, :lastUpdateUser, :lastUpdateTxId)" )
   * 
   * @generated
   */
  public int createEObjXRetailerJPN (EObjXRetailerJPN e)
  {
    return update (createEObjXRetailerJPNStatementDescriptor, e);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor createEObjXRetailerJPNStatementDescriptor = createStatementDescriptor (
    "createEObjXRetailerJPN(com.ibm.daimler.dsea.entityObject.EObjXRetailerJPN)",
    "insert into XRETAILERJPN (XRETAILERJPNPK_ID, RETAILER_CODE, RETAILER_NAME, BRANCH_NAME, SOURCE_IDENT_TP_CD, GS_CODE, GC_CODE, MODIFY_SYS_DT, ND_CODE, MARKET_NAME, DEALER_ACTIVE_FLAG, Dealer_Group, DEALER_ROLLOUT_FLAG, BATCH_IND, CREATE_DT, CHANGED_DT, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values(  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? )",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.INSERT,
    null,
    new CreateEObjXRetailerJPNParameterHandler (),
    new int[][]{{Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 20, 255, 255, 19, 20, 20, 0, 20, 50, 5, 255, 5, 5, 0, 0, 0, 0, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    2);

  /**
   * @generated
   */
  public static class CreateEObjXRetailerJPNParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      EObjXRetailerJPN bean0 = (EObjXRetailerJPN) parameters[0];
      setLong (stmt, 1, Types.BIGINT, (Long)bean0.getXRetailerJPNpkId());
      setString (stmt, 2, Types.VARCHAR, (String)bean0.getRetailerCode());
      setString (stmt, 3, Types.VARCHAR, (String)bean0.getRetailerName());
      setString (stmt, 4, Types.VARCHAR, (String)bean0.getBranchName());
      setLong (stmt, 5, Types.BIGINT, (Long)bean0.getSourceIdentifier());
      setString (stmt, 6, Types.VARCHAR, (String)bean0.getGSCode());
      setString (stmt, 7, Types.VARCHAR, (String)bean0.getGCCode());
      setTimestamp (stmt, 8, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastModifiedSystemDate());
      setString (stmt, 9, Types.VARCHAR, (String)bean0.getNDCode());
      setString (stmt, 10, Types.VARCHAR, (String)bean0.getMarketName());
      setString (stmt, 11, Types.VARCHAR, (String)bean0.getDealerActiveFlag());
      setString (stmt, 12, Types.VARCHAR, (String)bean0.getDealerGroup());
      setString (stmt, 13, Types.VARCHAR, (String)bean0.getDealerRolloutFlag());
      setString (stmt, 14, Types.VARCHAR, (String)bean0.getBatchInd());
      setTimestamp (stmt, 15, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getCreateDate());
      setTimestamp (stmt, 16, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getChangedDate());
      setTimestamp (stmt, 17, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUpdateDt());
      setString (stmt, 18, Types.VARCHAR, (String)bean0.getLastUpdateUser());
      setLong (stmt, 19, Types.BIGINT, (Long)bean0.getLastUpdateTxId());
    }
  }

  /**
   * @Update( sql="update XRETAILERJPN set RETAILER_CODE = :retailerCode, RETAILER_NAME = :retailerName, BRANCH_NAME = :branchName, SOURCE_IDENT_TP_CD = :sourceIdentifier, GS_CODE = :gSCode, GC_CODE = :gCCode, MODIFY_SYS_DT = :lastModifiedSystemDate, ND_CODE = :nDCode, MARKET_NAME = :marketName, DEALER_ACTIVE_FLAG = :dealerActiveFlag, Dealer_Group = :dealerGroup, DEALER_ROLLOUT_FLAG = :dealerRolloutFlag, BATCH_IND = :batchInd, CREATE_DT = :createDate, CHANGED_DT = :changedDate, LAST_UPDATE_DT = :lastUpdateDt, LAST_UPDATE_USER = :lastUpdateUser, LAST_UPDATE_TX_ID = :lastUpdateTxId where XRETAILERJPNPK_ID = :xRetailerJPNpkId and LAST_UPDATE_DT = :oldLastUpdateDt" )
   * 
   * @generated
   */
  public int updateEObjXRetailerJPN (EObjXRetailerJPN e)
  {
    return update (updateEObjXRetailerJPNStatementDescriptor, e);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor updateEObjXRetailerJPNStatementDescriptor = createStatementDescriptor (
    "updateEObjXRetailerJPN(com.ibm.daimler.dsea.entityObject.EObjXRetailerJPN)",
    "update XRETAILERJPN set RETAILER_CODE =  ? , RETAILER_NAME =  ? , BRANCH_NAME =  ? , SOURCE_IDENT_TP_CD =  ? , GS_CODE =  ? , GC_CODE =  ? , MODIFY_SYS_DT =  ? , ND_CODE =  ? , MARKET_NAME =  ? , DEALER_ACTIVE_FLAG =  ? , Dealer_Group =  ? , DEALER_ROLLOUT_FLAG =  ? , BATCH_IND =  ? , CREATE_DT =  ? , CHANGED_DT =  ? , LAST_UPDATE_DT =  ? , LAST_UPDATE_USER =  ? , LAST_UPDATE_TX_ID =  ?  where XRETAILERJPNPK_ID =  ?  and LAST_UPDATE_DT =  ? ",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.UPDATE,
    null,
    new UpdateEObjXRetailerJPNParameterHandler (),
    new int[][]{{Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP}, {20, 255, 255, 19, 20, 20, 0, 20, 50, 5, 255, 5, 5, 0, 0, 0, 0, 19, 19, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    3);

  /**
   * @generated
   */
  public static class UpdateEObjXRetailerJPNParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      EObjXRetailerJPN bean0 = (EObjXRetailerJPN) parameters[0];
      setString (stmt, 1, Types.VARCHAR, (String)bean0.getRetailerCode());
      setString (stmt, 2, Types.VARCHAR, (String)bean0.getRetailerName());
      setString (stmt, 3, Types.VARCHAR, (String)bean0.getBranchName());
      setLong (stmt, 4, Types.BIGINT, (Long)bean0.getSourceIdentifier());
      setString (stmt, 5, Types.VARCHAR, (String)bean0.getGSCode());
      setString (stmt, 6, Types.VARCHAR, (String)bean0.getGCCode());
      setTimestamp (stmt, 7, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastModifiedSystemDate());
      setString (stmt, 8, Types.VARCHAR, (String)bean0.getNDCode());
      setString (stmt, 9, Types.VARCHAR, (String)bean0.getMarketName());
      setString (stmt, 10, Types.VARCHAR, (String)bean0.getDealerActiveFlag());
      setString (stmt, 11, Types.VARCHAR, (String)bean0.getDealerGroup());
      setString (stmt, 12, Types.VARCHAR, (String)bean0.getDealerRolloutFlag());
      setString (stmt, 13, Types.VARCHAR, (String)bean0.getBatchInd());
      setTimestamp (stmt, 14, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getCreateDate());
      setTimestamp (stmt, 15, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getChangedDate());
      setTimestamp (stmt, 16, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUpdateDt());
      setString (stmt, 17, Types.VARCHAR, (String)bean0.getLastUpdateUser());
      setLong (stmt, 18, Types.BIGINT, (Long)bean0.getLastUpdateTxId());
      setLong (stmt, 19, Types.BIGINT, (Long)bean0.getXRetailerJPNpkId());
      setTimestamp (stmt, 20, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getOldLastUpdateDt());
    }
  }

  /**
   * @Update( sql="delete from XRETAILERJPN where XRETAILERJPNPK_ID = ?" )
   * 
   * @generated
   */
  public int deleteEObjXRetailerJPN (Long xRetailerJPNpkId)
  {
    return update (deleteEObjXRetailerJPNStatementDescriptor, xRetailerJPNpkId);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor deleteEObjXRetailerJPNStatementDescriptor = createStatementDescriptor (
    "deleteEObjXRetailerJPN(Long)",
    "delete from XRETAILERJPN where XRETAILERJPNPK_ID = ?",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.DELETE,
    null,
    new DeleteEObjXRetailerJPNParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    4);

  /**
   * @generated
   */
  public static class DeleteEObjXRetailerJPNParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setLong (stmt, 1, Types.BIGINT, (Long)parameters[0]);
    }
  }

}
