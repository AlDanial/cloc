/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[f730abfaea75574fc44d63d9e04a5e24]
 */

package com.ibm.daimler.dsea.entityObject;


import com.ibm.mdm.base.db.ResultQueue1;
import java.util.Iterator;
import com.ibm.mdm.base.db.EntityMapping;
import com.ibm.pdq.annotation.Select;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * @generated
 */
public interface XContractRelInquiryData {
  
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String tableAliasString = "tableAlias (" + 
                                            "XCONTRACTREL => com.ibm.daimler.dsea.entityObject.EObjXContractRel, " +
                                            "H_XCONTRACTREL => com.ibm.daimler.dsea.entityObject.EObjXContractRel" +
                                            ")";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getXContractRelSql = "SELECT r.XContract_Relpk_Id XContract_Relpk_Id, r.Contract_Id Contract_Id, r.Cont_Id Cont_Id, r.Market Market, r.Person_Org_Code Person_Org_Code, r.Contract_Role Contract_Role, r.Start_Date Start_Date, r.End_Date End_Date, r.X_BPID X_BPID, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XCONTRACTREL r WHERE r.XContract_Relpk_Id = ? ";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXContractRelParameters =
    "EObjXContractRel.XContractRelpkId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXContractRelResults =
    "EObjXContractRel.XContractRelpkId," +
    "EObjXContractRel.ContractId," +
    "EObjXContractRel.ContId," +
    "EObjXContractRel.Market," +
    "EObjXContractRel.PersonOrgCode," +
    "EObjXContractRel.ContractRole," +
    "EObjXContractRel.StartDate," +
    "EObjXContractRel.EndDate," +
    "EObjXContractRel.X_BPID," +
    "EObjXContractRel.lastUpdateDt," +
    "EObjXContractRel.lastUpdateUser," +
    "EObjXContractRel.lastUpdateTxId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getXContractRelHistorySql = "SELECT r.H_XContract_Relpk_Id hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.XContract_Relpk_Id XContract_Relpk_Id, r.Contract_Id Contract_Id, r.Cont_Id Cont_Id, r.Market Market, r.Person_Org_Code Person_Org_Code, r.Contract_Role Contract_Role, r.Start_Date Start_Date, r.End_Date End_Date, r.X_BPID X_BPID, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XCONTRACTREL r WHERE r.H_XContract_Relpk_Id = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXContractRelHistoryParameters =
    "EObjXContractRel.XContractRelpkId," +
    "EObjXContractRel.lastUpdateDt," +
    "EObjXContractRel.lastUpdateDt";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXContractRelHistoryResults =
    "EObjXContractRel.historyIdPK," +
    "EObjXContractRel.histActionCode," +
    "EObjXContractRel.histCreatedBy," +
    "EObjXContractRel.histCreateDt," +
    "EObjXContractRel.histEndDt," +
    "EObjXContractRel.XContractRelpkId," +
    "EObjXContractRel.ContractId," +
    "EObjXContractRel.ContId," +
    "EObjXContractRel.Market," +
    "EObjXContractRel.PersonOrgCode," +
    "EObjXContractRel.ContractRole," +
    "EObjXContractRel.StartDate," +
    "EObjXContractRel.EndDate," +
    "EObjXContractRel.X_BPID," +
    "EObjXContractRel.lastUpdateDt," +
    "EObjXContractRel.lastUpdateUser," +
    "EObjXContractRel.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getXContractRelSql, pattern=tableAliasString)
  @EntityMapping(parameters=getXContractRelParameters, results=getXContractRelResults)
  Iterator<ResultQueue1<EObjXContractRel>> getXContractRel(Object[] parameters);  


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getXContractRelHistorySql, pattern=tableAliasString)
  @EntityMapping(parameters=getXContractRelHistoryParameters, results=getXContractRelHistoryResults)
  Iterator<ResultQueue1<EObjXContractRel>> getXContractRelHistory(Object[] parameters);  


}


