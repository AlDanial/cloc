/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[b8d49cb4824df9a6785fa25ff4473310]
 */

package com.ibm.daimler.dsea.entityObject;

import com.dwl.base.EObjCommon;
import com.ibm.mdm.base.db.DataType;
import com.ibm.pdq.annotation.Column;
import com.ibm.pdq.annotation.Table;


import com.ibm.pdq.annotation.Id;
import java.sql.Timestamp;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * The entity object corresponding to the XRetailer business object. This entity
 * object should include all the attributes as defined by the business object.
 * 
 * @generated
 */
@SuppressWarnings("serial")
@Table(name=EObjXRetailer.tableName)
public class EObjXRetailer extends EObjCommon {

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public static final String tableName = "XRETAILER";
    
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String retailerpkIdColumn = "RETAILERPK_ID";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String retailerpkIdJdbcType = "BIGINT";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    retailerpkIdPrecision = 19;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String retailerCodeColumn = "RETAILER_CODE";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String retailerCodeJdbcType = "VARCHAR";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    retailerCodePrecision = 20;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String retailerNameColumn = "RETAILER_NAME";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String retailerNameJdbcType = "VARCHAR";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    retailerNamePrecision = 50;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String branchNameColumn = "BRANCH_NAME";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String branchNameJdbcType = "VARCHAR";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    branchNamePrecision = 50;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String sourceIdentifierColumn = "SOURCE_IDENT_TP_CD";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String sourceIdentifierJdbcType = "BIGINT";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    sourceIdentifierPrecision = 19;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String gSCodeColumn = "GS_CODE";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String gSCodeJdbcType = "VARCHAR";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    gSCodePrecision = 20;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String gCCodeColumn = "GC_CODE";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String gCCodeJdbcType = "VARCHAR";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    gCCodePrecision = 20;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String lastModifiedSystemDateColumn = "MODIFY_SYS_DT";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String lastModifiedSystemDateJdbcType = "TIMESTAMP";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String nDCodeColumn = "ND_CODE";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String nDCodeJdbcType = "VARCHAR";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    nDCodePrecision = 20;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String marketNameColumn = "MARKET_NAME";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String marketNameJdbcType = "VARCHAR";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    marketNamePrecision = 50;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String dealerActiveFlagColumn = "DEALER_ACTIVE_FLAG";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String dealerActiveFlagJdbcType = "VARCHAR";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    dealerActiveFlagPrecision = 5;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String dealerGroupColumn = "DEALER_GROUP";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String dealerGroupJdbcType = "VARCHAR";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    dealerGroupPrecision = 255;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String dealerRolloutFlagColumn = "DEALER_ROLLOUT_FLAG";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String dealerRolloutFlagJdbcType = "VARCHAR";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    dealerRolloutFlagPrecision = 5;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String batchIndColumn = "BATCH_IND";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String batchIndJdbcType = "VARCHAR";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    batchIndPrecision = 5;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String createDateColumn = "CREATE_DT";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String createDateJdbcType = "TIMESTAMP";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String changedDateColumn = "CHANGED_DT";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String changedDateJdbcType = "TIMESTAMP";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String cRMCompanyCodeColumn = "CRM_COMPANY_CODE";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String cRMCompanyCodeJdbcType = "VARCHAR";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    cRMCompanyCodePrecision = 250;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected Long retailerpkId;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String retailerCode;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String retailerName;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String branchName;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected Long sourceIdentifier;



    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String gSCode;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String gCCode;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected  Timestamp lastModifiedSystemDate;



    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String nDCode;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String marketName;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String dealerActiveFlag;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String dealerGroup;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String dealerRolloutFlag;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String batchInd;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected  Timestamp createDate;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected Timestamp changedDate;



    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String cRMCompanyCode;



    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Default constructor.     
     *
     * @generated
     */
    public EObjXRetailer() {
        super();
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the retailerpkId attribute. 
     *
     * @generated
     */
    @Id
    @Column(name=retailerpkIdColumn)
    @DataType(jdbcType=retailerpkIdJdbcType, precision=retailerpkIdPrecision)
    public Long getRetailerpkId (){
        return retailerpkId;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the retailerpkId attribute. 
     *
     * @param retailerpkId
     *     The new value of RetailerpkId. 
     * @generated
     */
    public void setRetailerpkId( Long retailerpkId ){
        this.retailerpkId = retailerpkId;
    
        super.setIdPK(retailerpkId);
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the retailerCode attribute. 
     *
     * @generated
     */
    @Column(name=retailerCodeColumn)
    @DataType(jdbcType=retailerCodeJdbcType, precision=retailerCodePrecision)
    public String getRetailerCode (){
        return retailerCode;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the retailerCode attribute. 
     *
     * @param retailerCode
     *     The new value of RetailerCode. 
     * @generated
     */
    public void setRetailerCode( String retailerCode ){
        this.retailerCode = retailerCode;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the retailerName attribute. 
     *
     * @generated
     */
    @Column(name=retailerNameColumn)
    @DataType(jdbcType=retailerNameJdbcType, precision=retailerNamePrecision)
    public String getRetailerName (){
        return retailerName;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the retailerName attribute. 
     *
     * @param retailerName
     *     The new value of RetailerName. 
     * @generated
     */
    public void setRetailerName( String retailerName ){
        this.retailerName = retailerName;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the branchName attribute. 
     *
     * @generated
     */
    @Column(name=branchNameColumn)
    @DataType(jdbcType=branchNameJdbcType, precision=branchNamePrecision)
    public String getBranchName (){
        return branchName;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the branchName attribute. 
     *
     * @param branchName
     *     The new value of BranchName. 
     * @generated
     */
    public void setBranchName( String branchName ){
        this.branchName = branchName;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the sourceIdentifier attribute. 
     *
     * @generated
     */
    @Column(name=sourceIdentifierColumn)
    @DataType(jdbcType=sourceIdentifierJdbcType, precision=sourceIdentifierPrecision)
    public Long getSourceIdentifier (){
        return sourceIdentifier;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the sourceIdentifier attribute. 
     *
     * @param sourceIdentifier
     *     The new value of SourceIdentifier. 
     * @generated
     */
    public void setSourceIdentifier( Long sourceIdentifier ){
        this.sourceIdentifier = sourceIdentifier;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the gSCode attribute. 
     *
     * @generated
     */
    @Column(name=gSCodeColumn)
    @DataType(jdbcType=gSCodeJdbcType, precision=gSCodePrecision)
    public String getGSCode (){
        return gSCode;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the gSCode attribute. 
     *
     * @param gSCode
     *     The new value of GSCode. 
     * @generated
     */
    public void setGSCode( String gSCode ){
        this.gSCode = gSCode;
    
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the gCCode attribute. 
     *
     * @generated
     */
    @Column(name=gCCodeColumn)
    @DataType(jdbcType=gCCodeJdbcType, precision=gCCodePrecision)
    public String getGCCode (){
        return gCCode;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the gCCode attribute. 
     *
     * @param gCCode
     *     The new value of GCCode. 
     * @generated
     */
    public void setGCCode( String gCCode ){
        this.gCCode = gCCode;
    
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the lastModifiedSystemDate attribute. 
     *
     * @generated
     */
    @Column(name=lastModifiedSystemDateColumn)
    @DataType(jdbcType=lastModifiedSystemDateJdbcType)
    public Timestamp getLastModifiedSystemDate (){
        return lastModifiedSystemDate;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the lastModifiedSystemDate attribute. 
     *
     * @param lastModifiedSystemDate
     *     The new value of LastModifiedSystemDate. 
     * @generated
     */
    public void setLastModifiedSystemDate( Timestamp lastModifiedSystemDate ){
        this.lastModifiedSystemDate = lastModifiedSystemDate;
    
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the nDCode attribute. 
     *
     * @generated
     */
    @Column(name=nDCodeColumn)
    @DataType(jdbcType=nDCodeJdbcType, precision=nDCodePrecision)
    public String getNDCode (){
        return nDCode;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the nDCode attribute. 
     *
     * @param nDCode
     *     The new value of NDCode. 
     * @generated
     */
    public void setNDCode( String nDCode ){
        this.nDCode = nDCode;
    
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the marketName attribute. 
     *
     * @generated
     */
    @Column(name=marketNameColumn)
    @DataType(jdbcType=marketNameJdbcType, precision=marketNamePrecision)
    public String getMarketName (){
        return marketName;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the marketName attribute. 
     *
     * @param marketName
     *     The new value of MarketName. 
     * @generated
     */
    public void setMarketName( String marketName ){
        this.marketName = marketName;
    
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the dealerActiveFlag attribute. 
     *
     * @generated
     */
    @Column(name=dealerActiveFlagColumn)
    @DataType(jdbcType=dealerActiveFlagJdbcType, precision=dealerActiveFlagPrecision)
    public String getDealerActiveFlag (){
        return dealerActiveFlag;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the dealerActiveFlag attribute. 
     *
     * @param dealerActiveFlag
     *     The new value of DealerActiveFlag. 
     * @generated
     */
    public void setDealerActiveFlag( String dealerActiveFlag ){
        this.dealerActiveFlag = dealerActiveFlag;
    
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the dealerGroup attribute. 
     *
     * @generated
     */
    @Column(name=dealerGroupColumn)
    @DataType(jdbcType=dealerGroupJdbcType, precision=dealerGroupPrecision)
    public String getDealerGroup (){
        return dealerGroup;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the dealerGroup attribute. 
     *
     * @param dealerGroup
     *     The new value of DealerGroup. 
     * @generated
     */
    public void setDealerGroup( String dealerGroup ){
        this.dealerGroup = dealerGroup;
    
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the dealerRolloutFlag attribute. 
     *
     * @generated
     */
    @Column(name=dealerRolloutFlagColumn)
    @DataType(jdbcType=dealerRolloutFlagJdbcType, precision=dealerRolloutFlagPrecision)
    public String getDealerRolloutFlag (){
        return dealerRolloutFlag;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the dealerRolloutFlag attribute. 
     *
     * @param dealerRolloutFlag
     *     The new value of DealerRolloutFlag. 
     * @generated
     */
    public void setDealerRolloutFlag( String dealerRolloutFlag ){
        this.dealerRolloutFlag = dealerRolloutFlag;
    
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the batchInd attribute. 
     *
     * @generated
     */
    @Column(name=batchIndColumn)
    @DataType(jdbcType=batchIndJdbcType, precision=batchIndPrecision)
    public String getBatchInd (){
        return batchInd;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the batchInd attribute. 
     *
     * @param batchInd
     *     The new value of BatchInd. 
     * @generated
     */
    public void setBatchInd( String batchInd ){
        this.batchInd = batchInd;
    
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the createDate attribute. 
     *
     * @generated
     */
    @Column(name=createDateColumn)
    @DataType(jdbcType=createDateJdbcType)
    public Timestamp getCreateDate (){
        return createDate;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the createDate attribute. 
     *
     * @param createDate
     *     The new value of CreateDate. 
     * @generated
     */
    public void setCreateDate( Timestamp createDate ){
        this.createDate = createDate;
    
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the changedDate attribute. 
     *
     * @generated
     */
    @Column(name=changedDateColumn)
    @DataType(jdbcType=changedDateJdbcType)
    public Timestamp getChangedDate (){
        return changedDate;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the changedDate attribute. 
     *
     * @param changedDate
     *     The new value of ChangedDate. 
     * @generated
     */
    public void setChangedDate( Timestamp changedDate ){
        this.changedDate = changedDate;
    
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the cRMCompanyCode attribute. 
     *
     * @generated
     */
    @Column(name=cRMCompanyCodeColumn)
    @DataType(jdbcType=cRMCompanyCodeJdbcType, precision=cRMCompanyCodePrecision)
    public String getCRMCompanyCode (){
        return cRMCompanyCode;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the cRMCompanyCode attribute. 
     *
     * @param cRMCompanyCode
     *     The new value of CRMCompanyCode. 
     * @generated
     */
    public void setCRMCompanyCode( String cRMCompanyCode ){
        this.cRMCompanyCode = cRMCompanyCode;
    
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the primary key. 
     *
     * @param aUniqueId
     *     The new value of the primary key. 
     * @generated
   */
	public void setPrimaryKey(Object aUniqueId) {
    this.setRetailerpkId((Long)aUniqueId);
  }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the primary key.
     *
     * @generated
     */
	public Object getPrimaryKey() {
    return this.getRetailerpkId();
  }
	 
}


