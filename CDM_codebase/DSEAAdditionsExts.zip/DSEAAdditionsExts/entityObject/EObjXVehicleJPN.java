/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[1a6ca5e541e78d1c8e9500e6806e88a6]
 */

package com.ibm.daimler.dsea.entityObject;

import com.dwl.base.EObjCommon;
import com.ibm.mdm.base.db.DataType;
import com.ibm.pdq.annotation.Column;
import com.ibm.pdq.annotation.Table;


import com.ibm.pdq.annotation.Id;

import java.sql.Timestamp;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * The entity object corresponding to the XVehicleJPN business object. This
 * entity object should include all the attributes as defined by the business
 * object.
 * 
 * @generated
 */
@SuppressWarnings("serial")
@Table(name=EObjXVehicleJPN.tableName)
public class EObjXVehicleJPN extends EObjCommon {

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public static final String tableName = "XVEHICLEJPN";
    
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String xVehicleJPNpkIdColumn = "XVEHICLE_JPNPK_ID";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String xVehicleJPNpkIdJdbcType = "BIGINT";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    xVehicleJPNpkIdPrecision = 19;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String globalVINColumn = "GLOBAL_VIN";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String globalVINJdbcType = "VARCHAR";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    globalVINPrecision = 50;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String bauMusterColumn = "BAU_MUSTER";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String bauMusterJdbcType = "VARCHAR";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    bauMusterPrecision = 20;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String typeClassColumn = "TYPE_CLASS";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String typeClassJdbcType = "VARCHAR";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    typeClassPrecision = 255;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String subMusterColumn = "SUB_MUSTER";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String subMusterJdbcType = "VARCHAR";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    subMusterPrecision = 255;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String colorColumn = "COLOR";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String colorJdbcType = "VARCHAR";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    colorPrecision = 255;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String trimColumn = "TRIM";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String trimJdbcType = "VARCHAR";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    trimPrecision = 255;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String batchIndColumn = "BATCH_IND";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String batchIndJdbcType = "VARCHAR";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    batchIndPrecision = 5;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String marketNameColumn = "MARKET_NAME";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String marketNameJdbcType = "VARCHAR";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    marketNamePrecision = 50;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String sourceIdentifierColumn = "SOURCE_IDENT_TP_CD";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String sourceIdentifierJdbcType = "BIGINT";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    sourceIdentifierPrecision = 19;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String lastModifiedSystemDateColumn = "MODIFY_SYS_DT";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String lastModifiedSystemDateJdbcType = "TIMESTAMP";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String createDateColumn = "CREATE_DT";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String createDateJdbcType = "TIMESTAMP";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String changedDateColumn = "CHANGED_DT";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String changedDateJdbcType = "TIMESTAMP";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String lastServiceDateColumn = "LAST_SERVICE_DT";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String lastServiceDateJdbcType = "TIMESTAMP";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String sFDCIdColumn = "SFDC_ID";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String sFDCIdJdbcType = "VARCHAR";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    sFDCIdPrecision = 50;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String vehicleAddressTypeColumn = "VEHICLE_ADDRESS_TYPE";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String vehicleAddressTypeJdbcType = "VARCHAR";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    vehicleAddressTypePrecision = 255;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String vehicleTypeColumn = "VEHICLE_TYPE";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String vehicleTypeJdbcType = "VARCHAR";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    vehicleTypePrecision = 50;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String deleteFlagColumn = "DELETE_FLAG";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String deleteFlagJdbcType = "VARCHAR";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    deleteFlagPrecision = 10;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String endDateColumn = "END_DT";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String endDateJdbcType = "TIMESTAMP";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String engineNumberColumn = "ENGINE_NUM";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String engineNumberJdbcType = "VARCHAR";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    engineNumberPrecision = 20;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String myCarIdColumn = "MYCAR_ID";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String myCarIdJdbcType = "VARCHAR";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    myCarIdPrecision = 50;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected Long xVehicleJPNpkId;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String globalVIN;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String bauMuster;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String typeClass;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String subMuster;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String color;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String trim;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String batchInd;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String marketName;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected Long sourceIdentifier;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected  Timestamp lastModifiedSystemDate;
    //inside if 

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected  Timestamp createDate;
    //inside if 

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected  Timestamp changedDate;
    //inside if 

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected  Timestamp lastServiceDate;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String sFDCId;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String vehicleAddressType;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String vehicleType;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String deleteFlag;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected  Timestamp endDate;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String engineNumber;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String myCarId;
    //inside if 



    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Default constructor.     
     *
     * @generated
     */
    public EObjXVehicleJPN() {
        super();
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xVehicleJPNpkId attribute. 
     *
     * @generated
     */
    @Id
    @Column(name=xVehicleJPNpkIdColumn)
    @DataType(jdbcType=xVehicleJPNpkIdJdbcType, precision=xVehicleJPNpkIdPrecision)
    public Long getXVehicleJPNpkId (){
        return xVehicleJPNpkId;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xVehicleJPNpkId attribute. 
     *
     * @param xVehicleJPNpkId
     *     The new value of XVehicleJPNpkId. 
     * @generated
     */
    public void setXVehicleJPNpkId( Long xVehicleJPNpkId ){
        this.xVehicleJPNpkId = xVehicleJPNpkId;
    
        super.setIdPK(xVehicleJPNpkId);
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the globalVIN attribute. 
     *
     * @generated
     */
    @Column(name=globalVINColumn)
    @DataType(jdbcType=globalVINJdbcType, precision=globalVINPrecision)
    public String getGlobalVIN (){
        return globalVIN;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the globalVIN attribute. 
     *
     * @param globalVIN
     *     The new value of GlobalVIN. 
     * @generated
     */
    public void setGlobalVIN( String globalVIN ){
        this.globalVIN = globalVIN;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the bauMuster attribute. 
     *
     * @generated
     */
    @Column(name=bauMusterColumn)
    @DataType(jdbcType=bauMusterJdbcType, precision=bauMusterPrecision)
    public String getBauMuster (){
        return bauMuster;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the bauMuster attribute. 
     *
     * @param bauMuster
     *     The new value of BauMuster. 
     * @generated
     */
    public void setBauMuster( String bauMuster ){
        this.bauMuster = bauMuster;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the typeClass attribute. 
     *
     * @generated
     */
    @Column(name=typeClassColumn)
    @DataType(jdbcType=typeClassJdbcType, precision=typeClassPrecision)
    public String getTypeClass (){
        return typeClass;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the typeClass attribute. 
     *
     * @param typeClass
     *     The new value of TypeClass. 
     * @generated
     */
    public void setTypeClass( String typeClass ){
        this.typeClass = typeClass;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the subMuster attribute. 
     *
     * @generated
     */
    @Column(name=subMusterColumn)
    @DataType(jdbcType=subMusterJdbcType, precision=subMusterPrecision)
    public String getSubMuster (){
        return subMuster;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the subMuster attribute. 
     *
     * @param subMuster
     *     The new value of SubMuster. 
     * @generated
     */
    public void setSubMuster( String subMuster ){
        this.subMuster = subMuster;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the color attribute. 
     *
     * @generated
     */
    @Column(name=colorColumn)
    @DataType(jdbcType=colorJdbcType, precision=colorPrecision)
    public String getColor (){
        return color;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the color attribute. 
     *
     * @param color
     *     The new value of Color. 
     * @generated
     */
    public void setColor( String color ){
        this.color = color;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the trim attribute. 
     *
     * @generated
     */
    @Column(name=trimColumn)
    @DataType(jdbcType=trimJdbcType, precision=trimPrecision)
    public String getTrim (){
        return trim;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the trim attribute. 
     *
     * @param trim
     *     The new value of Trim. 
     * @generated
     */
    public void setTrim( String trim ){
        this.trim = trim;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the batchInd attribute. 
     *
     * @generated
     */
    @Column(name=batchIndColumn)
    @DataType(jdbcType=batchIndJdbcType, precision=batchIndPrecision)
    public String getBatchInd (){
        return batchInd;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the batchInd attribute. 
     *
     * @param batchInd
     *     The new value of BatchInd. 
     * @generated
     */
    public void setBatchInd( String batchInd ){
        this.batchInd = batchInd;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the marketName attribute. 
     *
     * @generated
     */
    @Column(name=marketNameColumn)
    @DataType(jdbcType=marketNameJdbcType, precision=marketNamePrecision)
    public String getMarketName (){
        return marketName;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the marketName attribute. 
     *
     * @param marketName
     *     The new value of MarketName. 
     * @generated
     */
    public void setMarketName( String marketName ){
        this.marketName = marketName;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the sourceIdentifier attribute. 
     *
     * @generated
     */
    @Column(name=sourceIdentifierColumn)
    @DataType(jdbcType=sourceIdentifierJdbcType, precision=sourceIdentifierPrecision)
    public Long getSourceIdentifier (){
        return sourceIdentifier;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the sourceIdentifier attribute. 
     *
     * @param sourceIdentifier
     *     The new value of SourceIdentifier. 
     * @generated
     */
    public void setSourceIdentifier( Long sourceIdentifier ){
        this.sourceIdentifier = sourceIdentifier;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the lastModifiedSystemDate attribute. 
     *
     * @generated
     */
    @Column(name=lastModifiedSystemDateColumn)
    @DataType(jdbcType=lastModifiedSystemDateJdbcType)
    public Timestamp getLastModifiedSystemDate (){
        return lastModifiedSystemDate;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the lastModifiedSystemDate attribute. 
     *
     * @param lastModifiedSystemDate
     *     The new value of LastModifiedSystemDate. 
     * @generated
     */
    public void setLastModifiedSystemDate( Timestamp lastModifiedSystemDate ){
        this.lastModifiedSystemDate = lastModifiedSystemDate;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the createDate attribute. 
     *
     * @generated
     */
    @Column(name=createDateColumn)
    @DataType(jdbcType=createDateJdbcType)
    public Timestamp getCreateDate (){
        return createDate;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the createDate attribute. 
     *
     * @param createDate
     *     The new value of CreateDate. 
     * @generated
     */
    public void setCreateDate( Timestamp createDate ){
        this.createDate = createDate;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the changedDate attribute. 
     *
     * @generated
     */
    @Column(name=changedDateColumn)
    @DataType(jdbcType=changedDateJdbcType)
    public Timestamp getChangedDate (){
        return changedDate;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the changedDate attribute. 
     *
     * @param changedDate
     *     The new value of ChangedDate. 
     * @generated
     */
    public void setChangedDate( Timestamp changedDate ){
        this.changedDate = changedDate;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the lastServiceDate attribute. 
     *
     * @generated
     */
    @Column(name=lastServiceDateColumn)
    @DataType(jdbcType=lastServiceDateJdbcType)
    public Timestamp getLastServiceDate (){
        return lastServiceDate;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the lastServiceDate attribute. 
     *
     * @param lastServiceDate
     *     The new value of LastServiceDate. 
     * @generated
     */
    public void setLastServiceDate( Timestamp lastServiceDate ){
        this.lastServiceDate = lastServiceDate;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the sFDCId attribute. 
     *
     * @generated
     */
    @Column(name=sFDCIdColumn)
    @DataType(jdbcType=sFDCIdJdbcType, precision=sFDCIdPrecision)
    public String getSFDCId (){
        return sFDCId;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the sFDCId attribute. 
     *
     * @param sFDCId
     *     The new value of SFDCId. 
     * @generated
     */
    public void setSFDCId( String sFDCId ){
        this.sFDCId = sFDCId;
    
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the vehicleAddressType attribute. 
     *
     * @generated
     */
    @Column(name=vehicleAddressTypeColumn)
    @DataType(jdbcType=vehicleAddressTypeJdbcType, precision=vehicleAddressTypePrecision)
    public String getVehicleAddressType (){
        return vehicleAddressType;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the vehicleAddressType attribute. 
     *
     * @param vehicleAddressType
     *     The new value of VehicleAddressType. 
     * @generated
     */
    public void setVehicleAddressType( String vehicleAddressType ){
        this.vehicleAddressType = vehicleAddressType;
    
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the vehicleType attribute. 
     *
     * @generated
     */
    @Column(name=vehicleTypeColumn)
    @DataType(jdbcType=vehicleTypeJdbcType, precision=vehicleTypePrecision)
    public String getVehicleType (){
        return vehicleType;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the vehicleType attribute. 
     *
     * @param vehicleType
     *     The new value of VehicleType. 
     * @generated
     */
    public void setVehicleType( String vehicleType ){
        this.vehicleType = vehicleType;
    
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the deleteFlag attribute. 
     *
     * @generated
     */
    @Column(name=deleteFlagColumn)
    @DataType(jdbcType=deleteFlagJdbcType, precision=deleteFlagPrecision)
    public String getDeleteFlag (){
        return deleteFlag;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the deleteFlag attribute. 
     *
     * @param deleteFlag
     *     The new value of DeleteFlag. 
     * @generated
     */
    public void setDeleteFlag( String deleteFlag ){
        this.deleteFlag = deleteFlag;
    
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the endDate attribute. 
     *
     * @generated
     */
    @Column(name=endDateColumn)
    @DataType(jdbcType=endDateJdbcType)
    public Timestamp getEndDate (){
        return endDate;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the endDate attribute. 
     *
     * @param endDate
     *     The new value of EndDate. 
     * @generated
     */
    public void setEndDate( Timestamp endDate ){
        this.endDate = endDate;
    
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the engineNumber attribute. 
     *
     * @generated
     */
    @Column(name=engineNumberColumn)
    @DataType(jdbcType=engineNumberJdbcType, precision=engineNumberPrecision)
    public String getEngineNumber (){
        return engineNumber;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the engineNumber attribute. 
     *
     * @param engineNumber
     *     The new value of EngineNumber. 
     * @generated
     */
    public void setEngineNumber( String engineNumber ){
        this.engineNumber = engineNumber;
    
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the myCarId attribute. 
     *
     * @generated
     */
    @Column(name=myCarIdColumn)
    @DataType(jdbcType=myCarIdJdbcType, precision=myCarIdPrecision)
    public String getMyCarId (){
        return myCarId;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the myCarId attribute. 
     *
     * @param myCarId
     *     The new value of MyCarId. 
     * @generated
     */
    public void setMyCarId( String myCarId ){
        this.myCarId = myCarId;
    
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the primary key. 
     *
     * @param aUniqueId
     *     The new value of the primary key. 
     * @generated
   */
	public void setPrimaryKey(Object aUniqueId) {
    this.setXVehicleJPNpkId((Long)aUniqueId);
  }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the primary key.
     *
     * @generated
     */
	public Object getPrimaryKey() {
    return this.getXVehicleJPNpkId();
  }
	 
}


