/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[dbd99bc81fa17699360e98a03c3b4747]
 */

package com.ibm.daimler.dsea.entityObject;


import com.ibm.mdm.base.db.ResultQueue1;
import java.util.Iterator;
import com.ibm.mdm.base.db.EntityMapping;
import com.ibm.pdq.annotation.Select;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * @generated
 */
public interface XCustomerVehicleKORInquiryData {
  
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String tableAliasString = "tableAlias (" + 
                                            "XCUSTOMERVEHICLEKOR => com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleKOR, " +
                                            "H_XCUSTOMERVEHICLEKOR => com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleKOR" +
                                            ")";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getXCustomerVehicleKORSql = "SELECT r.XCustomer_Vehicle_KORpk_Id XCustomer_Vehicle_KORpk_Id, r.Cont_Id Cont_Id, r.VEHICLE_ID VEHICLE_ID, r.RETAILER_ID RETAILER_ID, r.CONNECTME_USAGE_TP_CD CONNECTME_USAGE_TP_CD, r.LICENSE_PLATE LICENSE_PLATE, r.VEHICLE_SALES_TP_CD VEHICLE_SALES_TP_CD, r.VEHICLE_USAGE_TP_CD VEHICLE_USAGE_TP_CD, r.VEHICLE_OWNERSHIP VEHICLE_OWNERSHIP, r.START_DT START_DT, r.END_DT END_DT, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.CUSTVEHRET_FLAG CUSTVEHRET_FLAG, r.DELETE_FLAG DELETE_FLAG, r.SFDC_ID SFDC_ID, r.SERVICE_NAME SERVICE_NAME, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XCUSTOMERVEHICLEKOR r WHERE r.XCustomer_Vehicle_KORpk_Id = ? ";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXCustomerVehicleKORParameters =
    "EObjXCustomerVehicleKOR.XCustomerVehicleKORpkId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXCustomerVehicleKORResults =
    "EObjXCustomerVehicleKOR.XCustomerVehicleKORpkId," +
    "EObjXCustomerVehicleKOR.ContId," +
    "EObjXCustomerVehicleKOR.VehicleId," +
    "EObjXCustomerVehicleKOR.RetailerId," +
    "EObjXCustomerVehicleKOR.ConnectMeUsage," +
    "EObjXCustomerVehicleKOR.LicensePlate," +
    "EObjXCustomerVehicleKOR.VehicleSales," +
    "EObjXCustomerVehicleKOR.VehicleUsage," +
    "EObjXCustomerVehicleKOR.VehicleOwnerShip," +
    "EObjXCustomerVehicleKOR.StartDate," +
    "EObjXCustomerVehicleKOR.EndDate," +
    "EObjXCustomerVehicleKOR.SourceIdentifier," +
    "EObjXCustomerVehicleKOR.CustVehRetFlag," +
    "EObjXCustomerVehicleKOR.DeleteFlag," +
    "EObjXCustomerVehicleKOR.SFDCId," +
    "EObjXCustomerVehicleKOR.ServiceName," +
    "EObjXCustomerVehicleKOR.lastUpdateDt," +
    "EObjXCustomerVehicleKOR.lastUpdateUser," +
    "EObjXCustomerVehicleKOR.lastUpdateTxId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getXCustomerVehicleKORHistorySql = "SELECT r.H_XCustomer_Vehicle_KORpk_Id hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.XCustomer_Vehicle_KORpk_Id XCustomer_Vehicle_KORpk_Id, r.Cont_Id Cont_Id, r.VEHICLE_ID VEHICLE_ID, r.RETAILER_ID RETAILER_ID, r.CONNECTME_USAGE_TP_CD CONNECTME_USAGE_TP_CD, r.LICENSE_PLATE LICENSE_PLATE, r.VEHICLE_SALES_TP_CD VEHICLE_SALES_TP_CD, r.VEHICLE_USAGE_TP_CD VEHICLE_USAGE_TP_CD, r.VEHICLE_OWNERSHIP VEHICLE_OWNERSHIP, r.START_DT START_DT, r.END_DT END_DT, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.CUSTVEHRET_FLAG CUSTVEHRET_FLAG, r.DELETE_FLAG DELETE_FLAG, r.SFDC_ID SFDC_ID, r.SERVICE_NAME SERVICE_NAME, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XCUSTOMERVEHICLEKOR r WHERE r.H_XCustomer_Vehicle_KORpk_Id = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXCustomerVehicleKORHistoryParameters =
    "EObjXCustomerVehicleKOR.XCustomerVehicleKORpkId," +
    "EObjXCustomerVehicleKOR.lastUpdateDt," +
    "EObjXCustomerVehicleKOR.lastUpdateDt";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXCustomerVehicleKORHistoryResults =
    "EObjXCustomerVehicleKOR.historyIdPK," +
    "EObjXCustomerVehicleKOR.histActionCode," +
    "EObjXCustomerVehicleKOR.histCreatedBy," +
    "EObjXCustomerVehicleKOR.histCreateDt," +
    "EObjXCustomerVehicleKOR.histEndDt," +
    "EObjXCustomerVehicleKOR.XCustomerVehicleKORpkId," +
    "EObjXCustomerVehicleKOR.ContId," +
    "EObjXCustomerVehicleKOR.VehicleId," +
    "EObjXCustomerVehicleKOR.RetailerId," +
    "EObjXCustomerVehicleKOR.ConnectMeUsage," +
    "EObjXCustomerVehicleKOR.LicensePlate," +
    "EObjXCustomerVehicleKOR.VehicleSales," +
    "EObjXCustomerVehicleKOR.VehicleUsage," +
    "EObjXCustomerVehicleKOR.VehicleOwnerShip," +
    "EObjXCustomerVehicleKOR.StartDate," +
    "EObjXCustomerVehicleKOR.EndDate," +
    "EObjXCustomerVehicleKOR.SourceIdentifier," +
    "EObjXCustomerVehicleKOR.CustVehRetFlag," +
    "EObjXCustomerVehicleKOR.DeleteFlag," +
    "EObjXCustomerVehicleKOR.SFDCId," +
    "EObjXCustomerVehicleKOR.ServiceName," +
    "EObjXCustomerVehicleKOR.lastUpdateDt," +
    "EObjXCustomerVehicleKOR.lastUpdateUser," +
    "EObjXCustomerVehicleKOR.lastUpdateTxId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getAllXCustomerVehicleKORByPartyIdSql = "SELECT r.XCustomer_Vehicle_KORpk_Id XCustomer_Vehicle_KORpk_Id, r.Cont_Id Cont_Id, r.VEHICLE_ID VEHICLE_ID, r.RETAILER_ID RETAILER_ID, r.CONNECTME_USAGE_TP_CD CONNECTME_USAGE_TP_CD, r.LICENSE_PLATE LICENSE_PLATE, r.VEHICLE_SALES_TP_CD VEHICLE_SALES_TP_CD, r.VEHICLE_USAGE_TP_CD VEHICLE_USAGE_TP_CD, r.VEHICLE_OWNERSHIP VEHICLE_OWNERSHIP, r.START_DT START_DT, r.END_DT END_DT, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.CUSTVEHRET_FLAG CUSTVEHRET_FLAG, r.DELETE_FLAG DELETE_FLAG, r.SFDC_ID SFDC_ID, r.SERVICE_NAME SERVICE_NAME, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XCUSTOMERVEHICLEKOR r WHERE r.Cont_Id = ? ";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getAllXCustomerVehicleKORByPartyIdParameters =
    "EObjXCustomerVehicleKOR.ContId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getAllXCustomerVehicleKORByPartyIdResults =
    "EObjXCustomerVehicleKOR.XCustomerVehicleKORpkId," +
    "EObjXCustomerVehicleKOR.ContId," +
    "EObjXCustomerVehicleKOR.VehicleId," +
    "EObjXCustomerVehicleKOR.RetailerId," +
    "EObjXCustomerVehicleKOR.ConnectMeUsage," +
    "EObjXCustomerVehicleKOR.LicensePlate," +
    "EObjXCustomerVehicleKOR.VehicleSales," +
    "EObjXCustomerVehicleKOR.VehicleUsage," +
    "EObjXCustomerVehicleKOR.VehicleOwnerShip," +
    "EObjXCustomerVehicleKOR.StartDate," +
    "EObjXCustomerVehicleKOR.EndDate," +
    "EObjXCustomerVehicleKOR.SourceIdentifier," +
    "EObjXCustomerVehicleKOR.CustVehRetFlag," +
    "EObjXCustomerVehicleKOR.DeleteFlag," +
    "EObjXCustomerVehicleKOR.SFDCId," +
    "EObjXCustomerVehicleKOR.ServiceName," +
    "EObjXCustomerVehicleKOR.lastUpdateDt," +
    "EObjXCustomerVehicleKOR.lastUpdateUser," +
    "EObjXCustomerVehicleKOR.lastUpdateTxId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getAllXCustomerVehicleKORByPartyIdHistorySql = "SELECT r.H_XCustomer_Vehicle_KORpk_Id hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.XCustomer_Vehicle_KORpk_Id XCustomer_Vehicle_KORpk_Id, r.Cont_Id Cont_Id, r.VEHICLE_ID VEHICLE_ID, r.RETAILER_ID RETAILER_ID, r.CONNECTME_USAGE_TP_CD CONNECTME_USAGE_TP_CD, r.LICENSE_PLATE LICENSE_PLATE, r.VEHICLE_SALES_TP_CD VEHICLE_SALES_TP_CD, r.VEHICLE_USAGE_TP_CD VEHICLE_USAGE_TP_CD, r.VEHICLE_OWNERSHIP VEHICLE_OWNERSHIP, r.START_DT START_DT, r.END_DT END_DT, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.CUSTVEHRET_FLAG CUSTVEHRET_FLAG, r.DELETE_FLAG DELETE_FLAG, r.SFDC_ID SFDC_ID, r.SERVICE_NAME SERVICE_NAME, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XCUSTOMERVEHICLEKOR r WHERE r.Cont_Id = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getAllXCustomerVehicleKORByPartyIdHistoryParameters =
    "EObjXCustomerVehicleKOR.ContId," +
    "EObjXCustomerVehicleKOR.lastUpdateDt," +
    "EObjXCustomerVehicleKOR.lastUpdateDt";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getAllXCustomerVehicleKORByPartyIdHistoryResults =
    "EObjXCustomerVehicleKOR.historyIdPK," +
    "EObjXCustomerVehicleKOR.histActionCode," +
    "EObjXCustomerVehicleKOR.histCreatedBy," +
    "EObjXCustomerVehicleKOR.histCreateDt," +
    "EObjXCustomerVehicleKOR.histEndDt," +
    "EObjXCustomerVehicleKOR.XCustomerVehicleKORpkId," +
    "EObjXCustomerVehicleKOR.ContId," +
    "EObjXCustomerVehicleKOR.VehicleId," +
    "EObjXCustomerVehicleKOR.RetailerId," +
    "EObjXCustomerVehicleKOR.ConnectMeUsage," +
    "EObjXCustomerVehicleKOR.LicensePlate," +
    "EObjXCustomerVehicleKOR.VehicleSales," +
    "EObjXCustomerVehicleKOR.VehicleUsage," +
    "EObjXCustomerVehicleKOR.VehicleOwnerShip," +
    "EObjXCustomerVehicleKOR.StartDate," +
    "EObjXCustomerVehicleKOR.EndDate," +
    "EObjXCustomerVehicleKOR.SourceIdentifier," +
    "EObjXCustomerVehicleKOR.CustVehRetFlag," +
    "EObjXCustomerVehicleKOR.DeleteFlag," +
    "EObjXCustomerVehicleKOR.SFDCId," +
    "EObjXCustomerVehicleKOR.ServiceName," +
    "EObjXCustomerVehicleKOR.lastUpdateDt," +
    "EObjXCustomerVehicleKOR.lastUpdateUser," +
    "EObjXCustomerVehicleKOR.lastUpdateTxId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getAllCVRByVehicle_IDSql = "SELECT r.XCustomer_Vehicle_KORpk_Id XCustomer_Vehicle_KORpk_Id, r.Cont_Id Cont_Id, r.VEHICLE_ID VEHICLE_ID, r.RETAILER_ID RETAILER_ID, r.CONNECTME_USAGE_TP_CD CONNECTME_USAGE_TP_CD, r.LICENSE_PLATE LICENSE_PLATE, r.VEHICLE_SALES_TP_CD VEHICLE_SALES_TP_CD, r.VEHICLE_USAGE_TP_CD VEHICLE_USAGE_TP_CD, r.VEHICLE_OWNERSHIP VEHICLE_OWNERSHIP, r.START_DT START_DT, r.END_DT END_DT, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.CUSTVEHRET_FLAG CUSTVEHRET_FLAG, r.DELETE_FLAG DELETE_FLAG, r.SFDC_ID SFDC_ID, r.SERVICE_NAME SERVICE_NAME, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XCUSTOMERVEHICLEKOR r WHERE r.VEHICLE_ID = ? ";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getAllCVRByVehicle_IDParameters =
    "EObjXCustomerVehicleKOR.VehicleId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getAllCVRByVehicle_IDResults =
    "EObjXCustomerVehicleKOR.XCustomerVehicleKORpkId," +
    "EObjXCustomerVehicleKOR.ContId," +
    "EObjXCustomerVehicleKOR.VehicleId," +
    "EObjXCustomerVehicleKOR.RetailerId," +
    "EObjXCustomerVehicleKOR.ConnectMeUsage," +
    "EObjXCustomerVehicleKOR.LicensePlate," +
    "EObjXCustomerVehicleKOR.VehicleSales," +
    "EObjXCustomerVehicleKOR.VehicleUsage," +
    "EObjXCustomerVehicleKOR.VehicleOwnerShip," +
    "EObjXCustomerVehicleKOR.StartDate," +
    "EObjXCustomerVehicleKOR.EndDate," +
    "EObjXCustomerVehicleKOR.SourceIdentifier," +
    "EObjXCustomerVehicleKOR.CustVehRetFlag," +
    "EObjXCustomerVehicleKOR.DeleteFlag," +
    "EObjXCustomerVehicleKOR.SFDCId," +
    "EObjXCustomerVehicleKOR.ServiceName," +
    "EObjXCustomerVehicleKOR.lastUpdateDt," +
    "EObjXCustomerVehicleKOR.lastUpdateUser," +
    "EObjXCustomerVehicleKOR.lastUpdateTxId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getAllCVRByVehicle_IDHistorySql = "SELECT r.H_XCustomer_Vehicle_KORpk_Id hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.XCustomer_Vehicle_KORpk_Id XCustomer_Vehicle_KORpk_Id, r.Cont_Id Cont_Id, r.VEHICLE_ID VEHICLE_ID, r.RETAILER_ID RETAILER_ID, r.CONNECTME_USAGE_TP_CD CONNECTME_USAGE_TP_CD, r.LICENSE_PLATE LICENSE_PLATE, r.VEHICLE_SALES_TP_CD VEHICLE_SALES_TP_CD, r.VEHICLE_USAGE_TP_CD VEHICLE_USAGE_TP_CD, r.VEHICLE_OWNERSHIP VEHICLE_OWNERSHIP, r.START_DT START_DT, r.END_DT END_DT, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.CUSTVEHRET_FLAG CUSTVEHRET_FLAG, r.DELETE_FLAG DELETE_FLAG, r.SFDC_ID SFDC_ID, r.SERVICE_NAME SERVICE_NAME, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XCUSTOMERVEHICLEKOR r WHERE r.VEHICLE_ID = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getAllCVRByVehicle_IDHistoryParameters =
    "EObjXCustomerVehicleKOR.VehicleId," +
    "EObjXCustomerVehicleKOR.lastUpdateDt," +
    "EObjXCustomerVehicleKOR.lastUpdateDt";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getAllCVRByVehicle_IDHistoryResults =
    "EObjXCustomerVehicleKOR.historyIdPK," +
    "EObjXCustomerVehicleKOR.histActionCode," +
    "EObjXCustomerVehicleKOR.histCreatedBy," +
    "EObjXCustomerVehicleKOR.histCreateDt," +
    "EObjXCustomerVehicleKOR.histEndDt," +
    "EObjXCustomerVehicleKOR.XCustomerVehicleKORpkId," +
    "EObjXCustomerVehicleKOR.ContId," +
    "EObjXCustomerVehicleKOR.VehicleId," +
    "EObjXCustomerVehicleKOR.RetailerId," +
    "EObjXCustomerVehicleKOR.ConnectMeUsage," +
    "EObjXCustomerVehicleKOR.LicensePlate," +
    "EObjXCustomerVehicleKOR.VehicleSales," +
    "EObjXCustomerVehicleKOR.VehicleUsage," +
    "EObjXCustomerVehicleKOR.VehicleOwnerShip," +
    "EObjXCustomerVehicleKOR.StartDate," +
    "EObjXCustomerVehicleKOR.EndDate," +
    "EObjXCustomerVehicleKOR.SourceIdentifier," +
    "EObjXCustomerVehicleKOR.CustVehRetFlag," +
    "EObjXCustomerVehicleKOR.DeleteFlag," +
    "EObjXCustomerVehicleKOR.SFDCId," +
    "EObjXCustomerVehicleKOR.ServiceName," +
    "EObjXCustomerVehicleKOR.lastUpdateDt," +
    "EObjXCustomerVehicleKOR.lastUpdateUser," +
    "EObjXCustomerVehicleKOR.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getXCustomerVehicleKORSql, pattern=tableAliasString)
  @EntityMapping(parameters=getXCustomerVehicleKORParameters, results=getXCustomerVehicleKORResults)
  Iterator<ResultQueue1<EObjXCustomerVehicleKOR>> getXCustomerVehicleKOR(Object[] parameters);  


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getXCustomerVehicleKORHistorySql, pattern=tableAliasString)
  @EntityMapping(parameters=getXCustomerVehicleKORHistoryParameters, results=getXCustomerVehicleKORHistoryResults)
  Iterator<ResultQueue1<EObjXCustomerVehicleKOR>> getXCustomerVehicleKORHistory(Object[] parameters);  


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getAllXCustomerVehicleKORByPartyIdSql, pattern=tableAliasString)
  @EntityMapping(parameters=getAllXCustomerVehicleKORByPartyIdParameters, results=getAllXCustomerVehicleKORByPartyIdResults)
  Iterator<ResultQueue1<EObjXCustomerVehicleKOR>> getAllXCustomerVehicleKORByPartyId(Object[] parameters);  


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getAllXCustomerVehicleKORByPartyIdHistorySql, pattern=tableAliasString)
  @EntityMapping(parameters=getAllXCustomerVehicleKORByPartyIdHistoryParameters, results=getAllXCustomerVehicleKORByPartyIdHistoryResults)
  Iterator<ResultQueue1<EObjXCustomerVehicleKOR>> getAllXCustomerVehicleKORByPartyIdHistory(Object[] parameters);  


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getAllCVRByVehicle_IDSql, pattern=tableAliasString)
  @EntityMapping(parameters=getAllCVRByVehicle_IDParameters, results=getAllCVRByVehicle_IDResults)
  Iterator<ResultQueue1<EObjXCustomerVehicleKOR>> getAllCVRByVehicle_ID(Object[] parameters);  


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getAllCVRByVehicle_IDHistorySql, pattern=tableAliasString)
  @EntityMapping(parameters=getAllCVRByVehicle_IDHistoryParameters, results=getAllCVRByVehicle_IDHistoryResults)
  Iterator<ResultQueue1<EObjXCustomerVehicleKOR>> getAllCVRByVehicle_IDHistory(Object[] parameters);  


}


