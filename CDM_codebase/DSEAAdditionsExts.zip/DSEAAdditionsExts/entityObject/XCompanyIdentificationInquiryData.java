/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[e024d7e93e7e3e7d5fd3dfe6e0529b8a]
 */

package com.ibm.daimler.dsea.entityObject;


import com.ibm.mdm.base.db.ResultQueue1;
import java.util.Iterator;
import com.ibm.mdm.base.db.EntityMapping;
import com.ibm.pdq.annotation.Select;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * @generated
 */
public interface XCompanyIdentificationInquiryData {
  
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String tableAliasString = "tableAlias (" + 
                                            "XCOMPANYIDENTIFICATION => com.ibm.daimler.dsea.entityObject.EObjXCompanyIdentification, " +
                                            "H_XCOMPANYIDENTIFICATION => com.ibm.daimler.dsea.entityObject.EObjXCompanyIdentification" +
                                            ")";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getXCompanyIdentificationSql = "SELECT r.COMPANYIDENTIFICATIONPK_ID COMPANYIDENTIFICATIONPK_ID, r.COMPANYMAGIC_NUMBER COMPANYMAGIC_NUMBER, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XCOMPANYIDENTIFICATION r WHERE r.COMPANYIDENTIFICATIONPK_ID = ? ";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXCompanyIdentificationParameters =
    "EObjXCompanyIdentification.CompanyIdentificationpkId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXCompanyIdentificationResults =
    "EObjXCompanyIdentification.CompanyIdentificationpkId," +
    "EObjXCompanyIdentification.CompanyMagicNumber," +
    "EObjXCompanyIdentification.lastUpdateDt," +
    "EObjXCompanyIdentification.lastUpdateUser," +
    "EObjXCompanyIdentification.lastUpdateTxId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getXCompanyIdentificationHistorySql = "SELECT r.H_COMPANYIDENTIFICATIONPK_ID hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.COMPANYIDENTIFICATIONPK_ID COMPANYIDENTIFICATIONPK_ID, r.COMPANYMAGIC_NUMBER COMPANYMAGIC_NUMBER, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XCOMPANYIDENTIFICATION r WHERE r.H_COMPANYIDENTIFICATIONPK_ID = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXCompanyIdentificationHistoryParameters =
    "EObjXCompanyIdentification.CompanyIdentificationpkId," +
    "EObjXCompanyIdentification.lastUpdateDt," +
    "EObjXCompanyIdentification.lastUpdateDt";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXCompanyIdentificationHistoryResults =
    "EObjXCompanyIdentification.historyIdPK," +
    "EObjXCompanyIdentification.histActionCode," +
    "EObjXCompanyIdentification.histCreatedBy," +
    "EObjXCompanyIdentification.histCreateDt," +
    "EObjXCompanyIdentification.histEndDt," +
    "EObjXCompanyIdentification.CompanyIdentificationpkId," +
    "EObjXCompanyIdentification.CompanyMagicNumber," +
    "EObjXCompanyIdentification.lastUpdateDt," +
    "EObjXCompanyIdentification.lastUpdateUser," +
    "EObjXCompanyIdentification.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getXCompanyIdentificationSql, pattern=tableAliasString)
  @EntityMapping(parameters=getXCompanyIdentificationParameters, results=getXCompanyIdentificationResults)
  Iterator<ResultQueue1<EObjXCompanyIdentification>> getXCompanyIdentification(Object[] parameters);  


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getXCompanyIdentificationHistorySql, pattern=tableAliasString)
  @EntityMapping(parameters=getXCompanyIdentificationHistoryParameters, results=getXCompanyIdentificationHistoryResults)
  Iterator<ResultQueue1<EObjXCompanyIdentification>> getXCompanyIdentificationHistory(Object[] parameters);  


}


