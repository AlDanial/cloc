package com.ibm.daimler.dsea.entityObject;

import com.ibm.pdq.runtime.generator.BaseParameterHandler;
import java.util.Iterator;
import com.ibm.daimler.dsea.entityObject.EObjXContractExt;
import java.sql.PreparedStatement;
import com.ibm.pdq.runtime.statement.StatementDescriptor;
import com.ibm.pdq.runtime.generator.BaseData;
import java.sql.SQLException;
import com.ibm.pdq.annotation.Metadata;
import com.dwl.tcrm.financial.entityObject.EObjContract;
import com.ibm.pdq.runtime.generator.BaseRowHandler;
import com.ibm.pdq.runtime.statement.SqlStatementType;
import java.sql.Types;


/**
 * <!-- begin-user-doc -->
 * 
 * <!-- end-user-doc -->
 * 
 * @generated
 */
public class EObjXContractExtDataImpl  extends BaseData implements EObjXContractExtData
{

  /**
   * @generated
   */
  public static final String generatorVersion = "3.200.75";

  /**
   * @generated
   */
  public static final String identifier = "EObjXContractExtData";

  /**
   * @generated
   */
  public static final long generationTime = 0x0000015de99d0c6aL;

  /**
   * @generated
   */
  public static final String collection = "NULLID";

  /**
   * @generated
   */
  public static final String packageVersion = null;

  /**
   * @generated
   */
  public static final boolean forceSingleBindIsolation = false;

  /**
   * @generated
   */
  public EObjXContractExtDataImpl()
  {
    super();
  } 

  /**
   * @generated
   */
  public String getGeneratorVersion()
  {
    return generatorVersion;
  }

  /**
   * @Select( sql="select XCONTRACT_NUM, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from CONTRACT where CONTRACT_ID = ? " )
   * 
   * @generated
   */
  public Iterator<EObjXContractExt> getEObjXContractExt (Long contractIdPK)
  {
    return queryIterator (getEObjXContractExtStatementDescriptor, contractIdPK);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getEObjXContractExtStatementDescriptor = createStatementDescriptor (
    "getEObjXContractExt(Long)",
    "select XCONTRACT_NUM, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from CONTRACT where CONTRACT_ID = ? ",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"xcontract_num", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetEObjXContractExtParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetEObjXContractExtRowHandler (),
    new int[][]{ {Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {50, 0, 20, 19}, {0, 0, 0, 0}, {0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    1);

  /**
   * @generated
   */
  public static class GetEObjXContractExtParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setLong (stmt, 1, Types.BIGINT, (Long)parameters[0]);
    }
  }

  /**
   * @generated
   */
  public static class GetEObjXContractExtRowHandler extends BaseRowHandler<EObjXContractExt>
  {
    /**
     * @generated
     */
    public EObjXContractExt handle (java.sql.ResultSet rs, EObjXContractExt returnObject) throws java.sql.SQLException
    {
      returnObject = new EObjXContractExt ();
      returnObject.setXContractNum(getString (rs, 1)); 
      returnObject.setLastUpdateDt(getTimestamp (rs, 2)); 
      returnObject.setLastUpdateUser(getString (rs, 3)); 
      returnObject.setLastUpdateTxId(getLongObject (rs, 4)); 
    
      return returnObject;
    }
  }

  /**
   * @Update( sql="insert into CONTRACT (ADMIN_CONTRACT_ID, CURR_CASH_VAL_AMT, PREMIUM_AMT, REPL_BY_CONTRACT, NEXT_BILL_DT, SERVICE_PROV_ID, SERVICE_ORG_NAME, BRAND_NAME, BUS_ORGUNIT_ID, LINE_OF_BUSINESS, ISSUE_LOCATION, CONTRACT_ID, MANAGED_ACCOUNT_IND, AGREEMENT_NAME, AGREEMENT_NICKNAME, SIGNED_DT, EXECUTED_DT, END_DT, REPLACES_CONTRACT, ACCOUNT_LAST_TRANSACTION_DT, TERMINATION_DT, AGREEMENT_DESCRIPTION, LAST_VERIFIED_DT, LAST_REVIEWED_DT, PRODUCT_ID, CLUSTER_KEY, ACCESS_TOKEN_VALUE, ADMIN_SYS_TP_CD, AGREEMENT_ST_TP_CD, AGREEMENT_TP_CD, BILL_TP_CD, PREMAMT_CUR_TP, CASHVAL_CUR_TP, CURRENCY_TP_CD, FREQ_MODE_TP_CD, CONTR_LANG_TP_CD, SERVICE_LEVEL_TP_CD, TERMINATION_REASON_TP_CD, XCONTRACT_NUM, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( ?1.adminContractId, ?1.currCashValAmt, ?1.premiumAmt, ?1.replByContract, ?1.nextBillDt, ?1.serviceProvId, ?1.serviceOrgName, ?1.brandName, ?1.busOrgunitId, ?1.lineOfBusiness, ?1.issueLocation, ?1.contractIdPK, ?1.managedAccountIndicator, ?1.agreementName, ?1.agreementNickName, ?1.signedDate, ?1.executedDate, ?1.endDate, ?1.replacesContract, ?1.accountLastTransactionDate, ?1.terminationDate, ?1.agreementDescription, ?1.lastVerifiedDate, ?1.lastReviewedDate, ?1.productId, ?1.clusterKey, ?1.accessTokenValue, ?1.adminSysTpCd, ?1.agreementStatusType, ?1.agreementType, ?1.billTpCd, ?1.premiumAmtCurTpCd, ?1.currCashValAmtCurTpCd, ?1.currencyTpCd, ?1.freqModeTpCd, ?1.contrLangTpCd, ?1.serviceLevelType, ?1.terminationReasonType, ?2.xContractNum, ?1.lastUpdateDt, ?1.lastUpdateUser, ?1.lastUpdateTxId)" )
   * 
   * @generated
   */
  public int createEObjXContractExt (EObjContract e1, EObjXContractExt e2)
  {
    return update (createEObjXContractExtStatementDescriptor, e1, e2);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor createEObjXContractExtStatementDescriptor = createStatementDescriptor (
    "createEObjXContractExt(com.dwl.tcrm.financial.entityObject.EObjContract, com.ibm.daimler.dsea.entityObject.EObjXContractExt)",
    "insert into CONTRACT (ADMIN_CONTRACT_ID, CURR_CASH_VAL_AMT, PREMIUM_AMT, REPL_BY_CONTRACT, NEXT_BILL_DT, SERVICE_PROV_ID, SERVICE_ORG_NAME, BRAND_NAME, BUS_ORGUNIT_ID, LINE_OF_BUSINESS, ISSUE_LOCATION, CONTRACT_ID, MANAGED_ACCOUNT_IND, AGREEMENT_NAME, AGREEMENT_NICKNAME, SIGNED_DT, EXECUTED_DT, END_DT, REPLACES_CONTRACT, ACCOUNT_LAST_TRANSACTION_DT, TERMINATION_DT, AGREEMENT_DESCRIPTION, LAST_VERIFIED_DT, LAST_REVIEWED_DT, PRODUCT_ID, CLUSTER_KEY, ACCESS_TOKEN_VALUE, ADMIN_SYS_TP_CD, AGREEMENT_ST_TP_CD, AGREEMENT_TP_CD, BILL_TP_CD, PREMAMT_CUR_TP, CASHVAL_CUR_TP, CURRENCY_TP_CD, FREQ_MODE_TP_CD, CONTR_LANG_TP_CD, SERVICE_LEVEL_TP_CD, TERMINATION_REASON_TP_CD, XCONTRACT_NUM, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values(  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? )",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.INSERT,
    null,
    new CreateEObjXContractExtParameterHandler (),
    new int[][]{{Types.VARCHAR, Types.DECIMAL, Types.DECIMAL, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.CHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {150, 17, 17, 19, 0, 30, 70, 30, 30, 30, 30, 19, 1, 120, 120, 0, 0, 0, 19, 0, 0, 250, 0, 0, 19, 19, 50, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 50, 0, 0, 19}, {0, 3, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    2);

  /**
   * @generated
   */
  public static class CreateEObjXContractExtParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      EObjContract bean0 = (EObjContract) parameters[0];
      setString (stmt, 1, Types.VARCHAR, (String)bean0.getAdminContractId());
      setBigDecimal (stmt, 2, Types.DECIMAL, (java.math.BigDecimal)bean0.getCurrCashValAmt());
      setBigDecimal (stmt, 3, Types.DECIMAL, (java.math.BigDecimal)bean0.getPremiumAmt());
      setLong (stmt, 4, Types.BIGINT, (Long)bean0.getReplByContract());
      setTimestamp (stmt, 5, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getNextBillDt());
      setString (stmt, 6, Types.VARCHAR, (String)bean0.getServiceProvId());
      setString (stmt, 7, Types.VARCHAR, (String)bean0.getServiceOrgName());
      setString (stmt, 8, Types.VARCHAR, (String)bean0.getBrandName());
      setString (stmt, 9, Types.VARCHAR, (String)bean0.getBusOrgunitId());
      setString (stmt, 10, Types.VARCHAR, (String)bean0.getLineOfBusiness());
      setString (stmt, 11, Types.VARCHAR, (String)bean0.getIssueLocation());
      setLong (stmt, 12, Types.BIGINT, (Long)bean0.getContractIdPK());
      setString (stmt, 13, Types.CHAR, (String)bean0.getManagedAccountIndicator());
      setString (stmt, 14, Types.VARCHAR, (String)bean0.getAgreementName());
      setString (stmt, 15, Types.VARCHAR, (String)bean0.getAgreementNickName());
      setTimestamp (stmt, 16, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getSignedDate());
      setTimestamp (stmt, 17, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getExecutedDate());
      setTimestamp (stmt, 18, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getEndDate());
      setLong (stmt, 19, Types.BIGINT, (Long)bean0.getReplacesContract());
      setTimestamp (stmt, 20, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getAccountLastTransactionDate());
      setTimestamp (stmt, 21, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getTerminationDate());
      setString (stmt, 22, Types.VARCHAR, (String)bean0.getAgreementDescription());
      setTimestamp (stmt, 23, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastVerifiedDate());
      setTimestamp (stmt, 24, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastReviewedDate());
      setLong (stmt, 25, Types.BIGINT, (Long)bean0.getProductId());
      setLong (stmt, 26, Types.BIGINT, (Long)bean0.getClusterKey());
      setString (stmt, 27, Types.VARCHAR, (String)bean0.getAccessTokenValue());
      setLong (stmt, 28, Types.BIGINT, (Long)bean0.getAdminSysTpCd());
      setLong (stmt, 29, Types.BIGINT, (Long)bean0.getAgreementStatusType());
      setLong (stmt, 30, Types.BIGINT, (Long)bean0.getAgreementType());
      setLong (stmt, 31, Types.BIGINT, (Long)bean0.getBillTpCd());
      setLong (stmt, 32, Types.BIGINT, (Long)bean0.getPremiumAmtCurTpCd());
      setLong (stmt, 33, Types.BIGINT, (Long)bean0.getCurrCashValAmtCurTpCd());
      setLong (stmt, 34, Types.BIGINT, (Long)bean0.getCurrencyTpCd());
      setLong (stmt, 35, Types.BIGINT, (Long)bean0.getFreqModeTpCd());
      setLong (stmt, 36, Types.BIGINT, (Long)bean0.getContrLangTpCd());
      setLong (stmt, 37, Types.BIGINT, (Long)bean0.getServiceLevelType());
      setLong (stmt, 38, Types.BIGINT, (Long)bean0.getTerminationReasonType());
      EObjXContractExt bean1 = (EObjXContractExt) parameters[1];
      setString (stmt, 39, Types.VARCHAR, (String)bean1.getXContractNum());
      setTimestamp (stmt, 40, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUpdateDt());
      setString (stmt, 41, Types.VARCHAR, (String)bean0.getLastUpdateUser());
      setLong (stmt, 42, Types.BIGINT, (Long)bean0.getLastUpdateTxId());
    }
  }

  /**
   * @Update( sql="update CONTRACT set ADMIN_CONTRACT_ID = ?1.adminContractId, CURR_CASH_VAL_AMT = ?1.currCashValAmt, PREMIUM_AMT = ?1.premiumAmt, REPL_BY_CONTRACT = ?1.replByContract, NEXT_BILL_DT = ?1.nextBillDt, SERVICE_PROV_ID = ?1.serviceProvId, SERVICE_ORG_NAME = ?1.serviceOrgName, BRAND_NAME = ?1.brandName, BUS_ORGUNIT_ID = ?1.busOrgunitId, LINE_OF_BUSINESS = ?1.lineOfBusiness, ISSUE_LOCATION = ?1.issueLocation, MANAGED_ACCOUNT_IND = ?1.managedAccountIndicator, AGREEMENT_NAME = ?1.agreementName, AGREEMENT_NICKNAME = ?1.agreementNickName, SIGNED_DT = ?1.signedDate, EXECUTED_DT = ?1.executedDate, END_DT = ?1.endDate, REPLACES_CONTRACT = ?1.replacesContract, ACCOUNT_LAST_TRANSACTION_DT = ?1.accountLastTransactionDate, TERMINATION_DT = ?1.terminationDate, AGREEMENT_DESCRIPTION = ?1.agreementDescription, LAST_VERIFIED_DT = ?1.lastVerifiedDate, LAST_REVIEWED_DT = ?1.lastReviewedDate, PRODUCT_ID = ?1.productId, CLUSTER_KEY = ?1.clusterKey, ACCESS_TOKEN_VALUE = ?1.accessTokenValue, ADMIN_SYS_TP_CD = ?1.adminSysTpCd, AGREEMENT_ST_TP_CD = ?1.agreementStatusType, AGREEMENT_TP_CD = ?1.agreementType, BILL_TP_CD = ?1.billTpCd, PREMAMT_CUR_TP = ?1.premiumAmtCurTpCd, CASHVAL_CUR_TP = ?1.currCashValAmtCurTpCd, CURRENCY_TP_CD = ?1.currencyTpCd, FREQ_MODE_TP_CD = ?1.freqModeTpCd, CONTR_LANG_TP_CD = ?1.contrLangTpCd, SERVICE_LEVEL_TP_CD = ?1.serviceLevelType, TERMINATION_REASON_TP_CD = ?1.terminationReasonType, XCONTRACT_NUM = ?2.xContractNum, LAST_UPDATE_DT = ?1.lastUpdateDt, LAST_UPDATE_USER = ?1.lastUpdateUser, LAST_UPDATE_TX_ID = ?1.lastUpdateTxId where CONTRACT_ID = ?1.contractIdPK and LAST_UPDATE_DT = ?1.oldLastUpdateDt" )
   * 
   * @generated
   */
  public int updateEObjXContractExt (EObjContract e1, EObjXContractExt e2)
  {
    return update (updateEObjXContractExtStatementDescriptor, e1, e2);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor updateEObjXContractExtStatementDescriptor = createStatementDescriptor (
    "updateEObjXContractExt(com.dwl.tcrm.financial.entityObject.EObjContract, com.ibm.daimler.dsea.entityObject.EObjXContractExt)",
    "update CONTRACT set ADMIN_CONTRACT_ID =  ? , CURR_CASH_VAL_AMT =  ? , PREMIUM_AMT =  ? , REPL_BY_CONTRACT =  ? , NEXT_BILL_DT =  ? , SERVICE_PROV_ID =  ? , SERVICE_ORG_NAME =  ? , BRAND_NAME =  ? , BUS_ORGUNIT_ID =  ? , LINE_OF_BUSINESS =  ? , ISSUE_LOCATION =  ? , MANAGED_ACCOUNT_IND =  ? , AGREEMENT_NAME =  ? , AGREEMENT_NICKNAME =  ? , SIGNED_DT =  ? , EXECUTED_DT =  ? , END_DT =  ? , REPLACES_CONTRACT =  ? , ACCOUNT_LAST_TRANSACTION_DT =  ? , TERMINATION_DT =  ? , AGREEMENT_DESCRIPTION =  ? , LAST_VERIFIED_DT =  ? , LAST_REVIEWED_DT =  ? , PRODUCT_ID =  ? , CLUSTER_KEY =  ? , ACCESS_TOKEN_VALUE =  ? , ADMIN_SYS_TP_CD =  ? , AGREEMENT_ST_TP_CD =  ? , AGREEMENT_TP_CD =  ? , BILL_TP_CD =  ? , PREMAMT_CUR_TP =  ? , CASHVAL_CUR_TP =  ? , CURRENCY_TP_CD =  ? , FREQ_MODE_TP_CD =  ? , CONTR_LANG_TP_CD =  ? , SERVICE_LEVEL_TP_CD =  ? , TERMINATION_REASON_TP_CD =  ? , XCONTRACT_NUM =  ? , LAST_UPDATE_DT =  ? , LAST_UPDATE_USER =  ? , LAST_UPDATE_TX_ID =  ?  where CONTRACT_ID =  ?  and LAST_UPDATE_DT =  ? ",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.UPDATE,
    null,
    new UpdateEObjXContractExtParameterHandler (),
    new int[][]{{Types.VARCHAR, Types.DECIMAL, Types.DECIMAL, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.CHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP}, {150, 17, 17, 19, 0, 30, 70, 30, 30, 30, 30, 1, 120, 120, 0, 0, 0, 19, 0, 0, 250, 0, 0, 19, 19, 50, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 50, 0, 0, 19, 19, 0}, {0, 3, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    3);

  /**
   * @generated
   */
  public static class UpdateEObjXContractExtParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      EObjContract bean0 = (EObjContract) parameters[0];
      setString (stmt, 1, Types.VARCHAR, (String)bean0.getAdminContractId());
      setBigDecimal (stmt, 2, Types.DECIMAL, (java.math.BigDecimal)bean0.getCurrCashValAmt());
      setBigDecimal (stmt, 3, Types.DECIMAL, (java.math.BigDecimal)bean0.getPremiumAmt());
      setLong (stmt, 4, Types.BIGINT, (Long)bean0.getReplByContract());
      setTimestamp (stmt, 5, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getNextBillDt());
      setString (stmt, 6, Types.VARCHAR, (String)bean0.getServiceProvId());
      setString (stmt, 7, Types.VARCHAR, (String)bean0.getServiceOrgName());
      setString (stmt, 8, Types.VARCHAR, (String)bean0.getBrandName());
      setString (stmt, 9, Types.VARCHAR, (String)bean0.getBusOrgunitId());
      setString (stmt, 10, Types.VARCHAR, (String)bean0.getLineOfBusiness());
      setString (stmt, 11, Types.VARCHAR, (String)bean0.getIssueLocation());
      setString (stmt, 12, Types.CHAR, (String)bean0.getManagedAccountIndicator());
      setString (stmt, 13, Types.VARCHAR, (String)bean0.getAgreementName());
      setString (stmt, 14, Types.VARCHAR, (String)bean0.getAgreementNickName());
      setTimestamp (stmt, 15, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getSignedDate());
      setTimestamp (stmt, 16, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getExecutedDate());
      setTimestamp (stmt, 17, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getEndDate());
      setLong (stmt, 18, Types.BIGINT, (Long)bean0.getReplacesContract());
      setTimestamp (stmt, 19, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getAccountLastTransactionDate());
      setTimestamp (stmt, 20, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getTerminationDate());
      setString (stmt, 21, Types.VARCHAR, (String)bean0.getAgreementDescription());
      setTimestamp (stmt, 22, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastVerifiedDate());
      setTimestamp (stmt, 23, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastReviewedDate());
      setLong (stmt, 24, Types.BIGINT, (Long)bean0.getProductId());
      setLong (stmt, 25, Types.BIGINT, (Long)bean0.getClusterKey());
      setString (stmt, 26, Types.VARCHAR, (String)bean0.getAccessTokenValue());
      setLong (stmt, 27, Types.BIGINT, (Long)bean0.getAdminSysTpCd());
      setLong (stmt, 28, Types.BIGINT, (Long)bean0.getAgreementStatusType());
      setLong (stmt, 29, Types.BIGINT, (Long)bean0.getAgreementType());
      setLong (stmt, 30, Types.BIGINT, (Long)bean0.getBillTpCd());
      setLong (stmt, 31, Types.BIGINT, (Long)bean0.getPremiumAmtCurTpCd());
      setLong (stmt, 32, Types.BIGINT, (Long)bean0.getCurrCashValAmtCurTpCd());
      setLong (stmt, 33, Types.BIGINT, (Long)bean0.getCurrencyTpCd());
      setLong (stmt, 34, Types.BIGINT, (Long)bean0.getFreqModeTpCd());
      setLong (stmt, 35, Types.BIGINT, (Long)bean0.getContrLangTpCd());
      setLong (stmt, 36, Types.BIGINT, (Long)bean0.getServiceLevelType());
      setLong (stmt, 37, Types.BIGINT, (Long)bean0.getTerminationReasonType());
      EObjXContractExt bean1 = (EObjXContractExt) parameters[1];
      setString (stmt, 38, Types.VARCHAR, (String)bean1.getXContractNum());
      setTimestamp (stmt, 39, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUpdateDt());
      setString (stmt, 40, Types.VARCHAR, (String)bean0.getLastUpdateUser());
      setLong (stmt, 41, Types.BIGINT, (Long)bean0.getLastUpdateTxId());
      setLong (stmt, 42, Types.BIGINT, (Long)bean0.getContractIdPK());
      setTimestamp (stmt, 43, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getOldLastUpdateDt());
    }
  }

  /**
   * @Update( sql="delete from CONTRACT where CONTRACT_ID = ?" )
   * 
   * @generated
   */
  public int deleteEObjXContractExt (Long contractIdPK)
  {
    return update (deleteEObjXContractExtStatementDescriptor, contractIdPK);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor deleteEObjXContractExtStatementDescriptor = createStatementDescriptor (
    "deleteEObjXContractExt(Long)",
    "delete from CONTRACT where CONTRACT_ID = ?",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.DELETE,
    null,
    new DeleteEObjXContractExtParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    4);

  /**
   * @generated
   */
  public static class DeleteEObjXContractExtParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setLong (stmt, 1, Types.BIGINT, (Long)parameters[0]);
    }
  }

}
