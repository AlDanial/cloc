package com.ibm.daimler.dsea.entityObject;

import com.ibm.pdq.runtime.generator.BaseParameterHandler;
import java.util.Iterator;
import java.sql.PreparedStatement;
import com.ibm.pdq.runtime.statement.StatementDescriptor;
import com.ibm.daimler.dsea.entityObject.EObjXContractRoleExt;
import com.ibm.pdq.runtime.generator.BaseData;
import java.sql.SQLException;
import com.ibm.pdq.annotation.Metadata;
import com.dwl.tcrm.financial.entityObject.EObjContractRole;
import com.ibm.mdm.base.db.ResultQueue2;
import com.ibm.pdq.runtime.generator.BaseRowHandler;
import com.ibm.pdq.runtime.statement.SqlStatementType;
import java.sql.Types;


@SuppressWarnings("unchecked")

/**
 * <!-- begin-user-doc -->
 * 
 * <!-- end-user-doc -->
 * 
 * @generated
 */
public class XContractRoleExtInquiryDataImpl  extends BaseData implements XContractRoleExtInquiryData
{

  /**
   * @generated
   */
  public static final String generatorVersion = "3.200.75";

  /**
   * @generated
   */
  public static final String identifier = "XContractRoleExtInquiryData";

  /**
   * @generated
   */
  public static final long generationTime = 0x0000015e13f844e7L;

  /**
   * @generated
   */
  public static final String collection = "NULLID";

  /**
   * @generated
   */
  public static final String packageVersion = null;

  /**
   * @generated
   */
  public static final boolean forceSingleBindIsolation = false;

  /**
   * @generated
   */
  public XContractRoleExtInquiryDataImpl()
  {
    super();
  } 

  /**
   * @generated
   */
  public String getGeneratorVersion()
  {
    return generatorVersion;
  }

  /**
   * @Select( sql="SELECT A.H_CONTRACT_ROLE_ID AS HIST_ID_PK , A.H_ACTION_CODE , A.H_CREATED_BY , A.H_CREATE_DT , A.H_END_DT , A.CONTRACT_ROLE_ID , A.CONT_ID , A.CONTR_COMPONENT_ID , A.CONTR_ROLE_TP_CD , A.DISTRIB_PCT , A.IRREVOC_IND , A.START_DT , A.END_DT , A.REGISTERED_NAME , A.RECORDED_START_DT , A.RECORDED_END_DT , A.LAST_UPDATE_DT , A.LAST_UPDATE_USER , A.ARRANGEMENT_TP_CD , A.SHARE_DIST_TP_CD , A.END_REASON_TP_CD , A.LAST_UPDATE_TX_ID , A.ARRANGEMENT_DESC, A.XSOURCE_IDENT_TP_CD FROM H_CONTRACTROLE A WHERE A.CONTR_COMPONENT_ID IN (SELECT H_CONTRACTCOMPONEN.CONTR_COMPONENT_ID FROM H_CONTRACTCOMPONEN WHERE CONTRACT_ID = ?) AND (H_CREATE_DT BETWEEN ? AND ?)", pattern="tableAlias (CONTRACTROLE => com.dwl.tcrm.financial.entityObject.EObjContractRole, H_CONTRACTROLE => com.dwl.tcrm.financial.entityObject.EObjContractRole , CONTRACTROLE => com.ibm.daimler.dsea.entityObject.EObjXContractRoleExt , H_CONTRACTROLE => com.ibm.daimler.dsea.entityObject.EObjXContractRoleExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue2<EObjContractRole,EObjXContractRoleExt>> getEObjCONTRACT_PARTY_ROLES_BY_CONTRACT_ID_HISTORY (Object[] parameters)
  {
    return queryIterator (getEObjCONTRACT_PARTY_ROLES_BY_CONTRACT_ID_HISTORYStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getEObjCONTRACT_PARTY_ROLES_BY_CONTRACT_ID_HISTORYStatementDescriptor = createStatementDescriptor (
    "getEObjCONTRACT_PARTY_ROLES_BY_CONTRACT_ID_HISTORY(Object[])",
    "SELECT A.H_CONTRACT_ROLE_ID AS HIST_ID_PK , A.H_ACTION_CODE , A.H_CREATED_BY , A.H_CREATE_DT , A.H_END_DT , A.CONTRACT_ROLE_ID , A.CONT_ID , A.CONTR_COMPONENT_ID , A.CONTR_ROLE_TP_CD , A.DISTRIB_PCT , A.IRREVOC_IND , A.START_DT , A.END_DT , A.REGISTERED_NAME , A.RECORDED_START_DT , A.RECORDED_END_DT , A.LAST_UPDATE_DT , A.LAST_UPDATE_USER , A.ARRANGEMENT_TP_CD , A.SHARE_DIST_TP_CD , A.END_REASON_TP_CD , A.LAST_UPDATE_TX_ID , A.ARRANGEMENT_DESC, A.XSOURCE_IDENT_TP_CD FROM H_CONTRACTROLE A WHERE A.CONTR_COMPONENT_ID IN (SELECT H_CONTRACTCOMPONEN.CONTR_COMPONENT_ID FROM H_CONTRACTCOMPONEN WHERE CONTRACT_ID = ?) AND (H_CREATE_DT BETWEEN ? AND ?)",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"hist_id_pk", "h_action_code", "h_created_by", "h_create_dt", "h_end_dt", "contract_role_id", "cont_id", "contr_component_id", "contr_role_tp_cd", "distrib_pct", "irrevoc_ind", "start_dt", "end_dt", "registered_name", "recorded_start_dt", "recorded_end_dt", "last_update_dt", "last_update_user", "arrangement_tp_cd", "share_dist_tp_cd", "end_reason_tp_cd", "last_update_tx_id", "arrangement_desc", "xsource_ident_tp_cd"},
    new GetEObjCONTRACT_PARTY_ROLES_BY_CONTRACT_ID_HISTORYParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP}, {19, 0, 0}, {0, 0, 0}, {1, 1, 1}},
    null,
    new GetEObjCONTRACT_PARTY_ROLES_BY_CONTRACT_ID_HISTORYRowHandler (),
    new int[][]{ {Types.BIGINT, Types.CHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.DECIMAL, Types.CHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.BIGINT}, {19, 1, 20, 0, 0, 19, 19, 19, 19, 5, 1, 0, 0, 255, 0, 0, 0, 20, 19, 19, 19, 19, 255, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    1);

  /**
   * @generated
   */
  public static class GetEObjCONTRACT_PARTY_ROLES_BY_CONTRACT_ID_HISTORYParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetEObjCONTRACT_PARTY_ROLES_BY_CONTRACT_ID_HISTORYRowHandler extends BaseRowHandler<ResultQueue2<EObjContractRole,EObjXContractRoleExt>>
  {
    /**
     * @generated
     */
    public ResultQueue2<EObjContractRole,EObjXContractRoleExt> handle (java.sql.ResultSet rs, ResultQueue2<EObjContractRole,EObjXContractRoleExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue2<EObjContractRole,EObjXContractRoleExt> ();

      EObjContractRole returnObject1 = new EObjContractRole ();
      returnObject1.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject1.setHistActionCode(getString (rs, 2)); 
      returnObject1.setHistCreatedBy(getString (rs, 3)); 
      returnObject1.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject1.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject1.setContractRoleIdPK(getLongObject (rs, 6)); 
      returnObject1.setContId(getLongObject (rs, 7)); 
      returnObject1.setContrComponentId(getLongObject (rs, 8)); 
      returnObject1.setContractRoleTpCd(getLongObject (rs, 9)); 
      returnObject1.setDistribPct(getBigDecimal (rs, 10)); 
      returnObject1.setIrrevocInd(getString (rs, 11)); 
      returnObject1.setStartDt(getTimestamp (rs, 12)); 
      returnObject1.setEndDt(getTimestamp (rs, 13)); 
      returnObject1.setRegisteredName(getString (rs, 14)); 
      returnObject1.setRecordedStartDt(getTimestamp (rs, 15)); 
      returnObject1.setRecordedEndDt(getTimestamp (rs, 16)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 17)); 
      returnObject1.setLastUpdateUser(getString (rs, 18)); 
      returnObject1.setArrangementTpCd(getLongObject (rs, 19)); 
      returnObject1.setShareDistTpCd(getLongObject (rs, 20)); 
      returnObject1.setEndReasonTpCd(getLongObject (rs, 21)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 22)); 
      returnObject1.setArrangementDesc(getString (rs, 23)); 
      returnObject.add (returnObject1);

      EObjXContractRoleExt returnObject2 = new EObjXContractRoleExt ();
      returnObject2.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject2.setHistActionCode(getString (rs, 2)); 
      returnObject2.setHistCreatedBy(getString (rs, 3)); 
      returnObject2.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject2.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject2.setLastUpdateDt(getTimestamp (rs, 17)); 
      returnObject2.setLastUpdateUser(getString (rs, 18)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 22)); 
      returnObject2.setXSourceIdentifier(getLongObject (rs, 24)); 
      returnObject.add (returnObject2);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT A.H_CONTRACT_ROLE_ID AS HIST_ID_PK , A.H_ACTION_CODE , A.H_CREATED_BY , A.H_CREATE_DT , A.H_END_DT , A.CONTRACT_ROLE_ID , A.CONT_ID , A.CONTR_COMPONENT_ID , A.CONTR_ROLE_TP_CD , A.DISTRIB_PCT , A.IRREVOC_IND , A.START_DT , A.END_DT , A.REGISTERED_NAME , A.RECORDED_START_DT , A.RECORDED_END_DT , A.LAST_UPDATE_DT , A.LAST_UPDATE_USER , A.ARRANGEMENT_TP_CD , A.SHARE_DIST_TP_CD , A.END_REASON_TP_CD , A.LAST_UPDATE_TX_ID , A.ARRANGEMENT_DESC, A.XSOURCE_IDENT_TP_CD FROM H_CONTRACTROLE A WHERE A.CONTR_COMPONENT_ID IN (SELECT H_CONTRACTCOMPONEN.CONTR_COMPONENT_ID FROM H_CONTRACTCOMPONEN WHERE CONTRACT_ID = ?)", pattern="tableAlias (CONTRACTROLE => com.dwl.tcrm.financial.entityObject.EObjContractRole, H_CONTRACTROLE => com.dwl.tcrm.financial.entityObject.EObjContractRole , CONTRACTROLE => com.ibm.daimler.dsea.entityObject.EObjXContractRoleExt , H_CONTRACTROLE => com.ibm.daimler.dsea.entityObject.EObjXContractRoleExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue2<EObjContractRole,EObjXContractRoleExt>> getEObjCONTRACT_PARTY_ROLE_BY_CONTRACT_WITHOUT_DATE_FILTER_HISTORY (Object[] parameters)
  {
    return queryIterator (getEObjCONTRACT_PARTY_ROLE_BY_CONTRACT_WITHOUT_DATE_FILTER_HISTORYStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getEObjCONTRACT_PARTY_ROLE_BY_CONTRACT_WITHOUT_DATE_FILTER_HISTORYStatementDescriptor = createStatementDescriptor (
    "getEObjCONTRACT_PARTY_ROLE_BY_CONTRACT_WITHOUT_DATE_FILTER_HISTORY(Object[])",
    "SELECT A.H_CONTRACT_ROLE_ID AS HIST_ID_PK , A.H_ACTION_CODE , A.H_CREATED_BY , A.H_CREATE_DT , A.H_END_DT , A.CONTRACT_ROLE_ID , A.CONT_ID , A.CONTR_COMPONENT_ID , A.CONTR_ROLE_TP_CD , A.DISTRIB_PCT , A.IRREVOC_IND , A.START_DT , A.END_DT , A.REGISTERED_NAME , A.RECORDED_START_DT , A.RECORDED_END_DT , A.LAST_UPDATE_DT , A.LAST_UPDATE_USER , A.ARRANGEMENT_TP_CD , A.SHARE_DIST_TP_CD , A.END_REASON_TP_CD , A.LAST_UPDATE_TX_ID , A.ARRANGEMENT_DESC, A.XSOURCE_IDENT_TP_CD FROM H_CONTRACTROLE A WHERE A.CONTR_COMPONENT_ID IN (SELECT H_CONTRACTCOMPONEN.CONTR_COMPONENT_ID FROM H_CONTRACTCOMPONEN WHERE CONTRACT_ID = ?)",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"hist_id_pk", "h_action_code", "h_created_by", "h_create_dt", "h_end_dt", "contract_role_id", "cont_id", "contr_component_id", "contr_role_tp_cd", "distrib_pct", "irrevoc_ind", "start_dt", "end_dt", "registered_name", "recorded_start_dt", "recorded_end_dt", "last_update_dt", "last_update_user", "arrangement_tp_cd", "share_dist_tp_cd", "end_reason_tp_cd", "last_update_tx_id", "arrangement_desc", "xsource_ident_tp_cd"},
    new GetEObjCONTRACT_PARTY_ROLE_BY_CONTRACT_WITHOUT_DATE_FILTER_HISTORYParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetEObjCONTRACT_PARTY_ROLE_BY_CONTRACT_WITHOUT_DATE_FILTER_HISTORYRowHandler (),
    new int[][]{ {Types.BIGINT, Types.CHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.DECIMAL, Types.CHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.BIGINT}, {19, 1, 20, 0, 0, 19, 19, 19, 19, 5, 1, 0, 0, 255, 0, 0, 0, 20, 19, 19, 19, 19, 255, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    2);

  /**
   * @generated
   */
  public static class GetEObjCONTRACT_PARTY_ROLE_BY_CONTRACT_WITHOUT_DATE_FILTER_HISTORYParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetEObjCONTRACT_PARTY_ROLE_BY_CONTRACT_WITHOUT_DATE_FILTER_HISTORYRowHandler extends BaseRowHandler<ResultQueue2<EObjContractRole,EObjXContractRoleExt>>
  {
    /**
     * @generated
     */
    public ResultQueue2<EObjContractRole,EObjXContractRoleExt> handle (java.sql.ResultSet rs, ResultQueue2<EObjContractRole,EObjXContractRoleExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue2<EObjContractRole,EObjXContractRoleExt> ();

      EObjContractRole returnObject1 = new EObjContractRole ();
      returnObject1.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject1.setHistActionCode(getString (rs, 2)); 
      returnObject1.setHistCreatedBy(getString (rs, 3)); 
      returnObject1.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject1.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject1.setContractRoleIdPK(getLongObject (rs, 6)); 
      returnObject1.setContId(getLongObject (rs, 7)); 
      returnObject1.setContrComponentId(getLongObject (rs, 8)); 
      returnObject1.setContractRoleTpCd(getLongObject (rs, 9)); 
      returnObject1.setDistribPct(getBigDecimal (rs, 10)); 
      returnObject1.setIrrevocInd(getString (rs, 11)); 
      returnObject1.setStartDt(getTimestamp (rs, 12)); 
      returnObject1.setEndDt(getTimestamp (rs, 13)); 
      returnObject1.setRegisteredName(getString (rs, 14)); 
      returnObject1.setRecordedStartDt(getTimestamp (rs, 15)); 
      returnObject1.setRecordedEndDt(getTimestamp (rs, 16)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 17)); 
      returnObject1.setLastUpdateUser(getString (rs, 18)); 
      returnObject1.setArrangementTpCd(getLongObject (rs, 19)); 
      returnObject1.setShareDistTpCd(getLongObject (rs, 20)); 
      returnObject1.setEndReasonTpCd(getLongObject (rs, 21)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 22)); 
      returnObject1.setArrangementDesc(getString (rs, 23)); 
      returnObject.add (returnObject1);

      EObjXContractRoleExt returnObject2 = new EObjXContractRoleExt ();
      returnObject2.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject2.setHistActionCode(getString (rs, 2)); 
      returnObject2.setHistCreatedBy(getString (rs, 3)); 
      returnObject2.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject2.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject2.setLastUpdateDt(getTimestamp (rs, 17)); 
      returnObject2.setLastUpdateUser(getString (rs, 18)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 22)); 
      returnObject2.setXSourceIdentifier(getLongObject (rs, 24)); 
      returnObject.add (returnObject2);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT A.H_CONTRACT_ROLE_ID AS HIST_ID_PK , A.H_ACTION_CODE , A.H_CREATED_BY , A.H_CREATE_DT , A.H_END_DT , A.CONTRACT_ROLE_ID , A.CONT_ID , A.CONTR_COMPONENT_ID , A.CONTR_ROLE_TP_CD , A.DISTRIB_PCT , A.IRREVOC_IND , A.START_DT , A.END_DT , A.REGISTERED_NAME , A.RECORDED_START_DT , A.RECORDED_END_DT , A.LAST_UPDATE_DT , A.LAST_UPDATE_USER , A.ARRANGEMENT_TP_CD , A.SHARE_DIST_TP_CD , A.END_REASON_TP_CD , A.LAST_UPDATE_TX_ID , A.ARRANGEMENT_DESC, A.XSOURCE_IDENT_TP_CD FROM H_CONTRACTROLE A WHERE A.CONT_ID = ? AND (A.H_CREATE_DT BETWEEN ? AND ? )", pattern="tableAlias (CONTRACTROLE => com.dwl.tcrm.financial.entityObject.EObjContractRole, H_CONTRACTROLE => com.dwl.tcrm.financial.entityObject.EObjContractRole , CONTRACTROLE => com.ibm.daimler.dsea.entityObject.EObjXContractRoleExt , H_CONTRACTROLE => com.ibm.daimler.dsea.entityObject.EObjXContractRoleExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue2<EObjContractRole,EObjXContractRoleExt>> getEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_HISTORY (Object[] parameters)
  {
    return queryIterator (getEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_HISTORYStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_HISTORYStatementDescriptor = createStatementDescriptor (
    "getEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_HISTORY(Object[])",
    "SELECT A.H_CONTRACT_ROLE_ID AS HIST_ID_PK , A.H_ACTION_CODE , A.H_CREATED_BY , A.H_CREATE_DT , A.H_END_DT , A.CONTRACT_ROLE_ID , A.CONT_ID , A.CONTR_COMPONENT_ID , A.CONTR_ROLE_TP_CD , A.DISTRIB_PCT , A.IRREVOC_IND , A.START_DT , A.END_DT , A.REGISTERED_NAME , A.RECORDED_START_DT , A.RECORDED_END_DT , A.LAST_UPDATE_DT , A.LAST_UPDATE_USER , A.ARRANGEMENT_TP_CD , A.SHARE_DIST_TP_CD , A.END_REASON_TP_CD , A.LAST_UPDATE_TX_ID , A.ARRANGEMENT_DESC, A.XSOURCE_IDENT_TP_CD FROM H_CONTRACTROLE A WHERE A.CONT_ID = ? AND (A.H_CREATE_DT BETWEEN ? AND ? )",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"hist_id_pk", "h_action_code", "h_created_by", "h_create_dt", "h_end_dt", "contract_role_id", "cont_id", "contr_component_id", "contr_role_tp_cd", "distrib_pct", "irrevoc_ind", "start_dt", "end_dt", "registered_name", "recorded_start_dt", "recorded_end_dt", "last_update_dt", "last_update_user", "arrangement_tp_cd", "share_dist_tp_cd", "end_reason_tp_cd", "last_update_tx_id", "arrangement_desc", "xsource_ident_tp_cd"},
    new GetEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_HISTORYParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP}, {19, 0, 0}, {0, 0, 0}, {1, 1, 1}},
    null,
    new GetEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_HISTORYRowHandler (),
    new int[][]{ {Types.BIGINT, Types.CHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.DECIMAL, Types.CHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.BIGINT}, {19, 1, 20, 0, 0, 19, 19, 19, 19, 5, 1, 0, 0, 255, 0, 0, 0, 20, 19, 19, 19, 19, 255, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    3);

  /**
   * @generated
   */
  public static class GetEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_HISTORYParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_HISTORYRowHandler extends BaseRowHandler<ResultQueue2<EObjContractRole,EObjXContractRoleExt>>
  {
    /**
     * @generated
     */
    public ResultQueue2<EObjContractRole,EObjXContractRoleExt> handle (java.sql.ResultSet rs, ResultQueue2<EObjContractRole,EObjXContractRoleExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue2<EObjContractRole,EObjXContractRoleExt> ();

      EObjContractRole returnObject1 = new EObjContractRole ();
      returnObject1.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject1.setHistActionCode(getString (rs, 2)); 
      returnObject1.setHistCreatedBy(getString (rs, 3)); 
      returnObject1.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject1.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject1.setContractRoleIdPK(getLongObject (rs, 6)); 
      returnObject1.setContId(getLongObject (rs, 7)); 
      returnObject1.setContrComponentId(getLongObject (rs, 8)); 
      returnObject1.setContractRoleTpCd(getLongObject (rs, 9)); 
      returnObject1.setDistribPct(getBigDecimal (rs, 10)); 
      returnObject1.setIrrevocInd(getString (rs, 11)); 
      returnObject1.setStartDt(getTimestamp (rs, 12)); 
      returnObject1.setEndDt(getTimestamp (rs, 13)); 
      returnObject1.setRegisteredName(getString (rs, 14)); 
      returnObject1.setRecordedStartDt(getTimestamp (rs, 15)); 
      returnObject1.setRecordedEndDt(getTimestamp (rs, 16)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 17)); 
      returnObject1.setLastUpdateUser(getString (rs, 18)); 
      returnObject1.setArrangementTpCd(getLongObject (rs, 19)); 
      returnObject1.setShareDistTpCd(getLongObject (rs, 20)); 
      returnObject1.setEndReasonTpCd(getLongObject (rs, 21)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 22)); 
      returnObject1.setArrangementDesc(getString (rs, 23)); 
      returnObject.add (returnObject1);

      EObjXContractRoleExt returnObject2 = new EObjXContractRoleExt ();
      returnObject2.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject2.setHistActionCode(getString (rs, 2)); 
      returnObject2.setHistCreatedBy(getString (rs, 3)); 
      returnObject2.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject2.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject2.setLastUpdateDt(getTimestamp (rs, 17)); 
      returnObject2.setLastUpdateUser(getString (rs, 18)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 22)); 
      returnObject2.setXSourceIdentifier(getLongObject (rs, 24)); 
      returnObject.add (returnObject2);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT DISTINCT A.H_CONTRACT_ROLE_ID AS HIST_ID_PK , A.H_ACTION_CODE , A.H_CREATED_BY , A.H_CREATE_DT , A.H_END_DT , A.CONTRACT_ROLE_ID , A.CONT_ID , A.CONTR_COMPONENT_ID , A.CONTR_ROLE_TP_CD , A.DISTRIB_PCT , A.IRREVOC_IND , A.START_DT , A.END_DT , A.REGISTERED_NAME , A.RECORDED_START_DT , A.RECORDED_END_DT , A.LAST_UPDATE_DT , A.LAST_UPDATE_USER , A.ARRANGEMENT_TP_CD , A.SHARE_DIST_TP_CD , A.END_REASON_TP_CD , A.LAST_UPDATE_TX_ID ,A.ARRANGEMENT_DESC, A.XSOURCE_IDENT_TP_CD FROM H_CONTRACTROLE A WHERE A.CONTR_COMPONENT_ID = ? AND (? BETWEEN A.H_CREATE_DT AND A.H_END_DT OR ? >= A.H_CREATE_DT AND A.H_END_DT IS NULL )", pattern="tableAlias (CONTRACTROLE => com.dwl.tcrm.financial.entityObject.EObjContractRole, H_CONTRACTROLE => com.dwl.tcrm.financial.entityObject.EObjContractRole , CONTRACTROLE => com.ibm.daimler.dsea.entityObject.EObjXContractRoleExt , H_CONTRACTROLE => com.ibm.daimler.dsea.entityObject.EObjXContractRoleExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue2<EObjContractRole,EObjXContractRoleExt>> getEObjCONTRACT_PARTY_ROLES_HISTORY (Object[] parameters)
  {
    return queryIterator (getEObjCONTRACT_PARTY_ROLES_HISTORYStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getEObjCONTRACT_PARTY_ROLES_HISTORYStatementDescriptor = createStatementDescriptor (
    "getEObjCONTRACT_PARTY_ROLES_HISTORY(Object[])",
    "SELECT DISTINCT A.H_CONTRACT_ROLE_ID AS HIST_ID_PK , A.H_ACTION_CODE , A.H_CREATED_BY , A.H_CREATE_DT , A.H_END_DT , A.CONTRACT_ROLE_ID , A.CONT_ID , A.CONTR_COMPONENT_ID , A.CONTR_ROLE_TP_CD , A.DISTRIB_PCT , A.IRREVOC_IND , A.START_DT , A.END_DT , A.REGISTERED_NAME , A.RECORDED_START_DT , A.RECORDED_END_DT , A.LAST_UPDATE_DT , A.LAST_UPDATE_USER , A.ARRANGEMENT_TP_CD , A.SHARE_DIST_TP_CD , A.END_REASON_TP_CD , A.LAST_UPDATE_TX_ID ,A.ARRANGEMENT_DESC, A.XSOURCE_IDENT_TP_CD FROM H_CONTRACTROLE A WHERE A.CONTR_COMPONENT_ID = ? AND (? BETWEEN A.H_CREATE_DT AND A.H_END_DT OR ? >= A.H_CREATE_DT AND A.H_END_DT IS NULL )",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"hist_id_pk", "h_action_code", "h_created_by", "h_create_dt", "h_end_dt", "contract_role_id", "cont_id", "contr_component_id", "contr_role_tp_cd", "distrib_pct", "irrevoc_ind", "start_dt", "end_dt", "registered_name", "recorded_start_dt", "recorded_end_dt", "last_update_dt", "last_update_user", "arrangement_tp_cd", "share_dist_tp_cd", "end_reason_tp_cd", "last_update_tx_id", "arrangement_desc", "xsource_ident_tp_cd"},
    new GetEObjCONTRACT_PARTY_ROLES_HISTORYParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP}, {19, 0, 0}, {0, 0, 0}, {1, 1, 1}},
    null,
    new GetEObjCONTRACT_PARTY_ROLES_HISTORYRowHandler (),
    new int[][]{ {Types.BIGINT, Types.CHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.DECIMAL, Types.CHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.BIGINT}, {19, 1, 20, 0, 0, 19, 19, 19, 19, 5, 1, 0, 0, 255, 0, 0, 0, 20, 19, 19, 19, 19, 255, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    4);

  /**
   * @generated
   */
  public static class GetEObjCONTRACT_PARTY_ROLES_HISTORYParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetEObjCONTRACT_PARTY_ROLES_HISTORYRowHandler extends BaseRowHandler<ResultQueue2<EObjContractRole,EObjXContractRoleExt>>
  {
    /**
     * @generated
     */
    public ResultQueue2<EObjContractRole,EObjXContractRoleExt> handle (java.sql.ResultSet rs, ResultQueue2<EObjContractRole,EObjXContractRoleExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue2<EObjContractRole,EObjXContractRoleExt> ();

      EObjContractRole returnObject1 = new EObjContractRole ();
      returnObject1.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject1.setHistActionCode(getString (rs, 2)); 
      returnObject1.setHistCreatedBy(getString (rs, 3)); 
      returnObject1.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject1.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject1.setContractRoleIdPK(getLongObject (rs, 6)); 
      returnObject1.setContId(getLongObject (rs, 7)); 
      returnObject1.setContrComponentId(getLongObject (rs, 8)); 
      returnObject1.setContractRoleTpCd(getLongObject (rs, 9)); 
      returnObject1.setDistribPct(getBigDecimal (rs, 10)); 
      returnObject1.setIrrevocInd(getString (rs, 11)); 
      returnObject1.setStartDt(getTimestamp (rs, 12)); 
      returnObject1.setEndDt(getTimestamp (rs, 13)); 
      returnObject1.setRegisteredName(getString (rs, 14)); 
      returnObject1.setRecordedStartDt(getTimestamp (rs, 15)); 
      returnObject1.setRecordedEndDt(getTimestamp (rs, 16)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 17)); 
      returnObject1.setLastUpdateUser(getString (rs, 18)); 
      returnObject1.setArrangementTpCd(getLongObject (rs, 19)); 
      returnObject1.setShareDistTpCd(getLongObject (rs, 20)); 
      returnObject1.setEndReasonTpCd(getLongObject (rs, 21)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 22)); 
      returnObject1.setArrangementDesc(getString (rs, 23)); 
      returnObject.add (returnObject1);

      EObjXContractRoleExt returnObject2 = new EObjXContractRoleExt ();
      returnObject2.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject2.setHistActionCode(getString (rs, 2)); 
      returnObject2.setHistCreatedBy(getString (rs, 3)); 
      returnObject2.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject2.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject2.setLastUpdateDt(getTimestamp (rs, 17)); 
      returnObject2.setLastUpdateUser(getString (rs, 18)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 22)); 
      returnObject2.setXSourceIdentifier(getLongObject (rs, 24)); 
      returnObject.add (returnObject2);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT CONTRACTROLE.CONTRACT_ROLE_ID , CONTRACTROLE.CONT_ID , CONTRACTROLE.CONTR_COMPONENT_ID , CONTRACTROLE.CONTR_ROLE_TP_CD , CONTRACTROLE.DISTRIB_PCT , CONTRACTROLE.IRREVOC_IND , CONTRACTROLE.START_DT , CONTRACTROLE.END_DT ,CONTRACTROLE.REGISTERED_NAME , CONTRACTROLE.RECORDED_START_DT , CONTRACTROLE.RECORDED_END_DT , CONTRACTROLE.LAST_UPDATE_DT , CONTRACTROLE.LAST_UPDATE_USER , CONTRACTROLE.ARRANGEMENT_TP_CD ,CONTRACTROLE.SHARE_DIST_TP_CD , CONTRACTROLE.END_REASON_TP_CD , CONTRACTROLE.LAST_UPDATE_TX_ID ,CONTRACTROLE.ARRANGEMENT_DESC, CONTRACTROLE.XSOURCE_IDENT_TP_CD FROM CONTRACTROLE WHERE (CONTRACTROLE.CONTR_COMPONENT_ID = ?) AND (CONTRACTROLE.END_DT IS NULL OR CONTRACTROLE.END_DT > ? )", pattern="tableAlias (CONTRACTROLE => com.dwl.tcrm.financial.entityObject.EObjContractRole, H_CONTRACTROLE => com.dwl.tcrm.financial.entityObject.EObjContractRole , CONTRACTROLE => com.ibm.daimler.dsea.entityObject.EObjXContractRoleExt , H_CONTRACTROLE => com.ibm.daimler.dsea.entityObject.EObjXContractRoleExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue2<EObjContractRole,EObjXContractRoleExt>> getEObjCONTRACT_PARTY_ROLES_ACTIVE (Object[] parameters)
  {
    return queryIterator (getEObjCONTRACT_PARTY_ROLES_ACTIVEStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getEObjCONTRACT_PARTY_ROLES_ACTIVEStatementDescriptor = createStatementDescriptor (
    "getEObjCONTRACT_PARTY_ROLES_ACTIVE(Object[])",
    "SELECT CONTRACTROLE.CONTRACT_ROLE_ID , CONTRACTROLE.CONT_ID , CONTRACTROLE.CONTR_COMPONENT_ID , CONTRACTROLE.CONTR_ROLE_TP_CD , CONTRACTROLE.DISTRIB_PCT , CONTRACTROLE.IRREVOC_IND , CONTRACTROLE.START_DT , CONTRACTROLE.END_DT ,CONTRACTROLE.REGISTERED_NAME , CONTRACTROLE.RECORDED_START_DT , CONTRACTROLE.RECORDED_END_DT , CONTRACTROLE.LAST_UPDATE_DT , CONTRACTROLE.LAST_UPDATE_USER , CONTRACTROLE.ARRANGEMENT_TP_CD ,CONTRACTROLE.SHARE_DIST_TP_CD , CONTRACTROLE.END_REASON_TP_CD , CONTRACTROLE.LAST_UPDATE_TX_ID ,CONTRACTROLE.ARRANGEMENT_DESC, CONTRACTROLE.XSOURCE_IDENT_TP_CD FROM CONTRACTROLE WHERE (CONTRACTROLE.CONTR_COMPONENT_ID = ?) AND (CONTRACTROLE.END_DT IS NULL OR CONTRACTROLE.END_DT > ? )",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"contract_role_id", "cont_id", "contr_component_id", "contr_role_tp_cd", "distrib_pct", "irrevoc_ind", "start_dt", "end_dt", "registered_name", "recorded_start_dt", "recorded_end_dt", "last_update_dt", "last_update_user", "arrangement_tp_cd", "share_dist_tp_cd", "end_reason_tp_cd", "last_update_tx_id", "arrangement_desc", "xsource_ident_tp_cd"},
    new GetEObjCONTRACT_PARTY_ROLES_ACTIVEParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP}, {19, 0}, {0, 0}, {1, 1}},
    null,
    new GetEObjCONTRACT_PARTY_ROLES_ACTIVERowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.DECIMAL, Types.CHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.BIGINT}, {19, 19, 19, 19, 5, 1, 0, 0, 255, 0, 0, 0, 20, 19, 19, 19, 19, 255, 19}, {0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    5);

  /**
   * @generated
   */
  public static class GetEObjCONTRACT_PARTY_ROLES_ACTIVEParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetEObjCONTRACT_PARTY_ROLES_ACTIVERowHandler extends BaseRowHandler<ResultQueue2<EObjContractRole,EObjXContractRoleExt>>
  {
    /**
     * @generated
     */
    public ResultQueue2<EObjContractRole,EObjXContractRoleExt> handle (java.sql.ResultSet rs, ResultQueue2<EObjContractRole,EObjXContractRoleExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue2<EObjContractRole,EObjXContractRoleExt> ();

      EObjContractRole returnObject1 = new EObjContractRole ();
      returnObject1.setContractRoleIdPK(getLongObject (rs, 1)); 
      returnObject1.setContId(getLongObject (rs, 2)); 
      returnObject1.setContrComponentId(getLongObject (rs, 3)); 
      returnObject1.setContractRoleTpCd(getLongObject (rs, 4)); 
      returnObject1.setDistribPct(getBigDecimal (rs, 5)); 
      returnObject1.setIrrevocInd(getString (rs, 6)); 
      returnObject1.setStartDt(getTimestamp (rs, 7)); 
      returnObject1.setEndDt(getTimestamp (rs, 8)); 
      returnObject1.setRegisteredName(getString (rs, 9)); 
      returnObject1.setRecordedStartDt(getTimestamp (rs, 10)); 
      returnObject1.setRecordedEndDt(getTimestamp (rs, 11)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 12)); 
      returnObject1.setLastUpdateUser(getString (rs, 13)); 
      returnObject1.setArrangementTpCd(getLongObject (rs, 14)); 
      returnObject1.setShareDistTpCd(getLongObject (rs, 15)); 
      returnObject1.setEndReasonTpCd(getLongObject (rs, 16)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 17)); 
      returnObject1.setArrangementDesc(getString (rs, 18)); 
      returnObject.add (returnObject1);

      EObjXContractRoleExt returnObject2 = new EObjXContractRoleExt ();
      returnObject2.setLastUpdateDt(getTimestamp (rs, 12)); 
      returnObject2.setLastUpdateUser(getString (rs, 13)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 17)); 
      returnObject2.setXSourceIdentifier(getLongObject (rs, 19)); 
      returnObject.add (returnObject2);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT CONTRACTROLE.CONTRACT_ROLE_ID , CONTRACTROLE.CONT_ID , CONTRACTROLE.CONTR_COMPONENT_ID , CONTRACTROLE.CONTR_ROLE_TP_CD , CONTRACTROLE.DISTRIB_PCT , CONTRACTROLE.IRREVOC_IND , CONTRACTROLE.START_DT , CONTRACTROLE.END_DT , CONTRACTROLE.REGISTERED_NAME , CONTRACTROLE.RECORDED_START_DT , CONTRACTROLE.RECORDED_END_DT ,CONTRACTROLE.LAST_UPDATE_DT , CONTRACTROLE.LAST_UPDATE_USER , CONTRACTROLE.ARRANGEMENT_TP_CD ,CONTRACTROLE.SHARE_DIST_TP_CD , CONTRACTROLE.END_REASON_TP_CD , CONTRACTROLE.LAST_UPDATE_TX_ID ,CONTRACTROLE.ARRANGEMENT_DESC, CONTRACTROLE.XSOURCE_IDENT_TP_CD FROM CONTRACTROLE WHERE CONTRACTROLE.CONTR_COMPONENT_ID = ? AND CONTRACTROLE.END_DT < ?", pattern="tableAlias (CONTRACTROLE => com.dwl.tcrm.financial.entityObject.EObjContractRole, H_CONTRACTROLE => com.dwl.tcrm.financial.entityObject.EObjContractRole , CONTRACTROLE => com.ibm.daimler.dsea.entityObject.EObjXContractRoleExt , H_CONTRACTROLE => com.ibm.daimler.dsea.entityObject.EObjXContractRoleExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue2<EObjContractRole,EObjXContractRoleExt>> getEObjCONTRACT_PARTY_ROLES_INACTIVE (Object[] parameters)
  {
    return queryIterator (getEObjCONTRACT_PARTY_ROLES_INACTIVEStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getEObjCONTRACT_PARTY_ROLES_INACTIVEStatementDescriptor = createStatementDescriptor (
    "getEObjCONTRACT_PARTY_ROLES_INACTIVE(Object[])",
    "SELECT CONTRACTROLE.CONTRACT_ROLE_ID , CONTRACTROLE.CONT_ID , CONTRACTROLE.CONTR_COMPONENT_ID , CONTRACTROLE.CONTR_ROLE_TP_CD , CONTRACTROLE.DISTRIB_PCT , CONTRACTROLE.IRREVOC_IND , CONTRACTROLE.START_DT , CONTRACTROLE.END_DT , CONTRACTROLE.REGISTERED_NAME , CONTRACTROLE.RECORDED_START_DT , CONTRACTROLE.RECORDED_END_DT ,CONTRACTROLE.LAST_UPDATE_DT , CONTRACTROLE.LAST_UPDATE_USER , CONTRACTROLE.ARRANGEMENT_TP_CD ,CONTRACTROLE.SHARE_DIST_TP_CD , CONTRACTROLE.END_REASON_TP_CD , CONTRACTROLE.LAST_UPDATE_TX_ID ,CONTRACTROLE.ARRANGEMENT_DESC, CONTRACTROLE.XSOURCE_IDENT_TP_CD FROM CONTRACTROLE WHERE CONTRACTROLE.CONTR_COMPONENT_ID = ? AND CONTRACTROLE.END_DT < ?",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"contract_role_id", "cont_id", "contr_component_id", "contr_role_tp_cd", "distrib_pct", "irrevoc_ind", "start_dt", "end_dt", "registered_name", "recorded_start_dt", "recorded_end_dt", "last_update_dt", "last_update_user", "arrangement_tp_cd", "share_dist_tp_cd", "end_reason_tp_cd", "last_update_tx_id", "arrangement_desc", "xsource_ident_tp_cd"},
    new GetEObjCONTRACT_PARTY_ROLES_INACTIVEParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP}, {19, 0}, {0, 0}, {1, 1}},
    null,
    new GetEObjCONTRACT_PARTY_ROLES_INACTIVERowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.DECIMAL, Types.CHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.BIGINT}, {19, 19, 19, 19, 5, 1, 0, 0, 255, 0, 0, 0, 20, 19, 19, 19, 19, 255, 19}, {0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    6);

  /**
   * @generated
   */
  public static class GetEObjCONTRACT_PARTY_ROLES_INACTIVEParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetEObjCONTRACT_PARTY_ROLES_INACTIVERowHandler extends BaseRowHandler<ResultQueue2<EObjContractRole,EObjXContractRoleExt>>
  {
    /**
     * @generated
     */
    public ResultQueue2<EObjContractRole,EObjXContractRoleExt> handle (java.sql.ResultSet rs, ResultQueue2<EObjContractRole,EObjXContractRoleExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue2<EObjContractRole,EObjXContractRoleExt> ();

      EObjContractRole returnObject1 = new EObjContractRole ();
      returnObject1.setContractRoleIdPK(getLongObject (rs, 1)); 
      returnObject1.setContId(getLongObject (rs, 2)); 
      returnObject1.setContrComponentId(getLongObject (rs, 3)); 
      returnObject1.setContractRoleTpCd(getLongObject (rs, 4)); 
      returnObject1.setDistribPct(getBigDecimal (rs, 5)); 
      returnObject1.setIrrevocInd(getString (rs, 6)); 
      returnObject1.setStartDt(getTimestamp (rs, 7)); 
      returnObject1.setEndDt(getTimestamp (rs, 8)); 
      returnObject1.setRegisteredName(getString (rs, 9)); 
      returnObject1.setRecordedStartDt(getTimestamp (rs, 10)); 
      returnObject1.setRecordedEndDt(getTimestamp (rs, 11)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 12)); 
      returnObject1.setLastUpdateUser(getString (rs, 13)); 
      returnObject1.setArrangementTpCd(getLongObject (rs, 14)); 
      returnObject1.setShareDistTpCd(getLongObject (rs, 15)); 
      returnObject1.setEndReasonTpCd(getLongObject (rs, 16)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 17)); 
      returnObject1.setArrangementDesc(getString (rs, 18)); 
      returnObject.add (returnObject1);

      EObjXContractRoleExt returnObject2 = new EObjXContractRoleExt ();
      returnObject2.setLastUpdateDt(getTimestamp (rs, 12)); 
      returnObject2.setLastUpdateUser(getString (rs, 13)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 17)); 
      returnObject2.setXSourceIdentifier(getLongObject (rs, 19)); 
      returnObject.add (returnObject2);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT CONTRACTROLE.CONTRACT_ROLE_ID , CONTRACTROLE.CONT_ID , CONTRACTROLE.CONTR_COMPONENT_ID , CONTRACTROLE.CONTR_ROLE_TP_CD , CONTRACTROLE.DISTRIB_PCT , CONTRACTROLE.IRREVOC_IND , CONTRACTROLE.START_DT , CONTRACTROLE.END_DT , CONTRACTROLE.REGISTERED_NAME , CONTRACTROLE.RECORDED_START_DT , CONTRACTROLE.RECORDED_END_DT , CONTRACTROLE.LAST_UPDATE_DT , CONTRACTROLE.LAST_UPDATE_USER , CONTRACTROLE.ARRANGEMENT_TP_CD , CONTRACTROLE.SHARE_DIST_TP_CD , CONTRACTROLE.END_REASON_TP_CD ,CONTRACTROLE.LAST_UPDATE_TX_ID ,CONTRACTROLE.ARRANGEMENT_DESC, CONTRACTROLE.XSOURCE_IDENT_TP_CD FROM CONTRACTROLE WHERE CONTRACTROLE.CONTR_COMPONENT_ID = ?", pattern="tableAlias (CONTRACTROLE => com.dwl.tcrm.financial.entityObject.EObjContractRole, H_CONTRACTROLE => com.dwl.tcrm.financial.entityObject.EObjContractRole , CONTRACTROLE => com.ibm.daimler.dsea.entityObject.EObjXContractRoleExt , H_CONTRACTROLE => com.ibm.daimler.dsea.entityObject.EObjXContractRoleExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue2<EObjContractRole,EObjXContractRoleExt>> getEObjCONTRACT_PARTY_ROLES_ALL (Object[] parameters)
  {
    return queryIterator (getEObjCONTRACT_PARTY_ROLES_ALLStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getEObjCONTRACT_PARTY_ROLES_ALLStatementDescriptor = createStatementDescriptor (
    "getEObjCONTRACT_PARTY_ROLES_ALL(Object[])",
    "SELECT CONTRACTROLE.CONTRACT_ROLE_ID , CONTRACTROLE.CONT_ID , CONTRACTROLE.CONTR_COMPONENT_ID , CONTRACTROLE.CONTR_ROLE_TP_CD , CONTRACTROLE.DISTRIB_PCT , CONTRACTROLE.IRREVOC_IND , CONTRACTROLE.START_DT , CONTRACTROLE.END_DT , CONTRACTROLE.REGISTERED_NAME , CONTRACTROLE.RECORDED_START_DT , CONTRACTROLE.RECORDED_END_DT , CONTRACTROLE.LAST_UPDATE_DT , CONTRACTROLE.LAST_UPDATE_USER , CONTRACTROLE.ARRANGEMENT_TP_CD , CONTRACTROLE.SHARE_DIST_TP_CD , CONTRACTROLE.END_REASON_TP_CD ,CONTRACTROLE.LAST_UPDATE_TX_ID ,CONTRACTROLE.ARRANGEMENT_DESC, CONTRACTROLE.XSOURCE_IDENT_TP_CD FROM CONTRACTROLE WHERE CONTRACTROLE.CONTR_COMPONENT_ID = ?",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"contract_role_id", "cont_id", "contr_component_id", "contr_role_tp_cd", "distrib_pct", "irrevoc_ind", "start_dt", "end_dt", "registered_name", "recorded_start_dt", "recorded_end_dt", "last_update_dt", "last_update_user", "arrangement_tp_cd", "share_dist_tp_cd", "end_reason_tp_cd", "last_update_tx_id", "arrangement_desc", "xsource_ident_tp_cd"},
    new GetEObjCONTRACT_PARTY_ROLES_ALLParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetEObjCONTRACT_PARTY_ROLES_ALLRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.DECIMAL, Types.CHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.BIGINT}, {19, 19, 19, 19, 5, 1, 0, 0, 255, 0, 0, 0, 20, 19, 19, 19, 19, 255, 19}, {0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    7);

  /**
   * @generated
   */
  public static class GetEObjCONTRACT_PARTY_ROLES_ALLParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetEObjCONTRACT_PARTY_ROLES_ALLRowHandler extends BaseRowHandler<ResultQueue2<EObjContractRole,EObjXContractRoleExt>>
  {
    /**
     * @generated
     */
    public ResultQueue2<EObjContractRole,EObjXContractRoleExt> handle (java.sql.ResultSet rs, ResultQueue2<EObjContractRole,EObjXContractRoleExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue2<EObjContractRole,EObjXContractRoleExt> ();

      EObjContractRole returnObject1 = new EObjContractRole ();
      returnObject1.setContractRoleIdPK(getLongObject (rs, 1)); 
      returnObject1.setContId(getLongObject (rs, 2)); 
      returnObject1.setContrComponentId(getLongObject (rs, 3)); 
      returnObject1.setContractRoleTpCd(getLongObject (rs, 4)); 
      returnObject1.setDistribPct(getBigDecimal (rs, 5)); 
      returnObject1.setIrrevocInd(getString (rs, 6)); 
      returnObject1.setStartDt(getTimestamp (rs, 7)); 
      returnObject1.setEndDt(getTimestamp (rs, 8)); 
      returnObject1.setRegisteredName(getString (rs, 9)); 
      returnObject1.setRecordedStartDt(getTimestamp (rs, 10)); 
      returnObject1.setRecordedEndDt(getTimestamp (rs, 11)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 12)); 
      returnObject1.setLastUpdateUser(getString (rs, 13)); 
      returnObject1.setArrangementTpCd(getLongObject (rs, 14)); 
      returnObject1.setShareDistTpCd(getLongObject (rs, 15)); 
      returnObject1.setEndReasonTpCd(getLongObject (rs, 16)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 17)); 
      returnObject1.setArrangementDesc(getString (rs, 18)); 
      returnObject.add (returnObject1);

      EObjXContractRoleExt returnObject2 = new EObjXContractRoleExt ();
      returnObject2.setLastUpdateDt(getTimestamp (rs, 12)); 
      returnObject2.setLastUpdateUser(getString (rs, 13)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 17)); 
      returnObject2.setXSourceIdentifier(getLongObject (rs, 19)); 
      returnObject.add (returnObject2);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT A.H_CONTRACT_ROLE_ID AS HIST_ID_PK , A.H_ACTION_CODE , A.H_CREATED_BY , A.H_CREATE_DT , A.H_END_DT , A.CONTRACT_ROLE_ID , A.CONT_ID , A.CONTR_COMPONENT_ID , A.CONTR_ROLE_TP_CD , A.DISTRIB_PCT , A.IRREVOC_IND , A.START_DT , A.END_DT , A.REGISTERED_NAME , A.RECORDED_START_DT , A.RECORDED_END_DT , A.LAST_UPDATE_DT , A.LAST_UPDATE_USER , A.ARRANGEMENT_TP_CD , A.SHARE_DIST_TP_CD , A.END_REASON_TP_CD , A.LAST_UPDATE_TX_ID , A.ARRANGEMENT_DESC, A.XSOURCE_IDENT_TP_CD FROM H_CONTRACTROLE A WHERE A.CONT_ID = ? AND (? BETWEEN A.H_CREATE_DT AND A.H_END_DT OR ? >= A.H_CREATE_DT AND A.H_END_DT IS NULL )", pattern="tableAlias (CONTRACTROLE => com.dwl.tcrm.financial.entityObject.EObjContractRole, H_CONTRACTROLE => com.dwl.tcrm.financial.entityObject.EObjContractRole , CONTRACTROLE => com.ibm.daimler.dsea.entityObject.EObjXContractRoleExt , H_CONTRACTROLE => com.ibm.daimler.dsea.entityObject.EObjXContractRoleExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue2<EObjContractRole,EObjXContractRoleExt>> getEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_AND_DATE_HISTORY (Object[] parameters)
  {
    return queryIterator (getEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_AND_DATE_HISTORYStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_AND_DATE_HISTORYStatementDescriptor = createStatementDescriptor (
    "getEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_AND_DATE_HISTORY(Object[])",
    "SELECT A.H_CONTRACT_ROLE_ID AS HIST_ID_PK , A.H_ACTION_CODE , A.H_CREATED_BY , A.H_CREATE_DT , A.H_END_DT , A.CONTRACT_ROLE_ID , A.CONT_ID , A.CONTR_COMPONENT_ID , A.CONTR_ROLE_TP_CD , A.DISTRIB_PCT , A.IRREVOC_IND , A.START_DT , A.END_DT , A.REGISTERED_NAME , A.RECORDED_START_DT , A.RECORDED_END_DT , A.LAST_UPDATE_DT , A.LAST_UPDATE_USER , A.ARRANGEMENT_TP_CD , A.SHARE_DIST_TP_CD , A.END_REASON_TP_CD , A.LAST_UPDATE_TX_ID , A.ARRANGEMENT_DESC, A.XSOURCE_IDENT_TP_CD FROM H_CONTRACTROLE A WHERE A.CONT_ID = ? AND (? BETWEEN A.H_CREATE_DT AND A.H_END_DT OR ? >= A.H_CREATE_DT AND A.H_END_DT IS NULL )",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"hist_id_pk", "h_action_code", "h_created_by", "h_create_dt", "h_end_dt", "contract_role_id", "cont_id", "contr_component_id", "contr_role_tp_cd", "distrib_pct", "irrevoc_ind", "start_dt", "end_dt", "registered_name", "recorded_start_dt", "recorded_end_dt", "last_update_dt", "last_update_user", "arrangement_tp_cd", "share_dist_tp_cd", "end_reason_tp_cd", "last_update_tx_id", "arrangement_desc", "xsource_ident_tp_cd"},
    new GetEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_AND_DATE_HISTORYParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP}, {19, 0, 0}, {0, 0, 0}, {1, 1, 1}},
    null,
    new GetEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_AND_DATE_HISTORYRowHandler (),
    new int[][]{ {Types.BIGINT, Types.CHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.DECIMAL, Types.CHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.BIGINT}, {19, 1, 20, 0, 0, 19, 19, 19, 19, 5, 1, 0, 0, 255, 0, 0, 0, 20, 19, 19, 19, 19, 255, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    8);

  /**
   * @generated
   */
  public static class GetEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_AND_DATE_HISTORYParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_AND_DATE_HISTORYRowHandler extends BaseRowHandler<ResultQueue2<EObjContractRole,EObjXContractRoleExt>>
  {
    /**
     * @generated
     */
    public ResultQueue2<EObjContractRole,EObjXContractRoleExt> handle (java.sql.ResultSet rs, ResultQueue2<EObjContractRole,EObjXContractRoleExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue2<EObjContractRole,EObjXContractRoleExt> ();

      EObjContractRole returnObject1 = new EObjContractRole ();
      returnObject1.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject1.setHistActionCode(getString (rs, 2)); 
      returnObject1.setHistCreatedBy(getString (rs, 3)); 
      returnObject1.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject1.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject1.setContractRoleIdPK(getLongObject (rs, 6)); 
      returnObject1.setContId(getLongObject (rs, 7)); 
      returnObject1.setContrComponentId(getLongObject (rs, 8)); 
      returnObject1.setContractRoleTpCd(getLongObject (rs, 9)); 
      returnObject1.setDistribPct(getBigDecimal (rs, 10)); 
      returnObject1.setIrrevocInd(getString (rs, 11)); 
      returnObject1.setStartDt(getTimestamp (rs, 12)); 
      returnObject1.setEndDt(getTimestamp (rs, 13)); 
      returnObject1.setRegisteredName(getString (rs, 14)); 
      returnObject1.setRecordedStartDt(getTimestamp (rs, 15)); 
      returnObject1.setRecordedEndDt(getTimestamp (rs, 16)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 17)); 
      returnObject1.setLastUpdateUser(getString (rs, 18)); 
      returnObject1.setArrangementTpCd(getLongObject (rs, 19)); 
      returnObject1.setShareDistTpCd(getLongObject (rs, 20)); 
      returnObject1.setEndReasonTpCd(getLongObject (rs, 21)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 22)); 
      returnObject1.setArrangementDesc(getString (rs, 23)); 
      returnObject.add (returnObject1);

      EObjXContractRoleExt returnObject2 = new EObjXContractRoleExt ();
      returnObject2.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject2.setHistActionCode(getString (rs, 2)); 
      returnObject2.setHistCreatedBy(getString (rs, 3)); 
      returnObject2.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject2.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject2.setLastUpdateDt(getTimestamp (rs, 17)); 
      returnObject2.setLastUpdateUser(getString (rs, 18)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 22)); 
      returnObject2.setXSourceIdentifier(getLongObject (rs, 24)); 
      returnObject.add (returnObject2);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT CONTRACTROLE.CONTRACT_ROLE_ID , CONTRACTROLE.CONT_ID , CONTRACTROLE.CONTR_COMPONENT_ID , CONTRACTROLE.CONTR_ROLE_TP_CD , CONTRACTROLE.DISTRIB_PCT , CONTRACTROLE.IRREVOC_IND , CONTRACTROLE.START_DT , CONTRACTROLE.END_DT , CONTRACTROLE.REGISTERED_NAME , CONTRACTROLE.RECORDED_START_DT , CONTRACTROLE.RECORDED_END_DT , CONTRACTROLE.LAST_UPDATE_DT , CONTRACTROLE.LAST_UPDATE_USER , CONTRACTROLE.ARRANGEMENT_TP_CD , CONTRACTROLE.SHARE_DIST_TP_CD , CONTRACTROLE.END_REASON_TP_CD , CONTRACTROLE.LAST_UPDATE_TX_ID ,CONTRACTROLE.ARRANGEMENT_DESC, CONTRACTROLE.XSOURCE_IDENT_TP_CD FROM CONTRACTROLE WHERE CONTRACTROLE.CONT_ID = ? AND (CONTRACTROLE.END_DT IS NULL OR CONTRACTROLE.END_DT > ? )", pattern="tableAlias (CONTRACTROLE => com.dwl.tcrm.financial.entityObject.EObjContractRole, H_CONTRACTROLE => com.dwl.tcrm.financial.entityObject.EObjContractRole , CONTRACTROLE => com.ibm.daimler.dsea.entityObject.EObjXContractRoleExt , H_CONTRACTROLE => com.ibm.daimler.dsea.entityObject.EObjXContractRoleExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue2<EObjContractRole,EObjXContractRoleExt>> getEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_ACTIVE (Object[] parameters)
  {
    return queryIterator (getEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_ACTIVEStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_ACTIVEStatementDescriptor = createStatementDescriptor (
    "getEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_ACTIVE(Object[])",
    "SELECT CONTRACTROLE.CONTRACT_ROLE_ID , CONTRACTROLE.CONT_ID , CONTRACTROLE.CONTR_COMPONENT_ID , CONTRACTROLE.CONTR_ROLE_TP_CD , CONTRACTROLE.DISTRIB_PCT , CONTRACTROLE.IRREVOC_IND , CONTRACTROLE.START_DT , CONTRACTROLE.END_DT , CONTRACTROLE.REGISTERED_NAME , CONTRACTROLE.RECORDED_START_DT , CONTRACTROLE.RECORDED_END_DT , CONTRACTROLE.LAST_UPDATE_DT , CONTRACTROLE.LAST_UPDATE_USER , CONTRACTROLE.ARRANGEMENT_TP_CD , CONTRACTROLE.SHARE_DIST_TP_CD , CONTRACTROLE.END_REASON_TP_CD , CONTRACTROLE.LAST_UPDATE_TX_ID ,CONTRACTROLE.ARRANGEMENT_DESC, CONTRACTROLE.XSOURCE_IDENT_TP_CD FROM CONTRACTROLE WHERE CONTRACTROLE.CONT_ID = ? AND (CONTRACTROLE.END_DT IS NULL OR CONTRACTROLE.END_DT > ? )",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"contract_role_id", "cont_id", "contr_component_id", "contr_role_tp_cd", "distrib_pct", "irrevoc_ind", "start_dt", "end_dt", "registered_name", "recorded_start_dt", "recorded_end_dt", "last_update_dt", "last_update_user", "arrangement_tp_cd", "share_dist_tp_cd", "end_reason_tp_cd", "last_update_tx_id", "arrangement_desc", "xsource_ident_tp_cd"},
    new GetEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_ACTIVEParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP}, {19, 0}, {0, 0}, {1, 1}},
    null,
    new GetEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_ACTIVERowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.DECIMAL, Types.CHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.BIGINT}, {19, 19, 19, 19, 5, 1, 0, 0, 255, 0, 0, 0, 20, 19, 19, 19, 19, 255, 19}, {0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    9);

  /**
   * @generated
   */
  public static class GetEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_ACTIVEParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_ACTIVERowHandler extends BaseRowHandler<ResultQueue2<EObjContractRole,EObjXContractRoleExt>>
  {
    /**
     * @generated
     */
    public ResultQueue2<EObjContractRole,EObjXContractRoleExt> handle (java.sql.ResultSet rs, ResultQueue2<EObjContractRole,EObjXContractRoleExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue2<EObjContractRole,EObjXContractRoleExt> ();

      EObjContractRole returnObject1 = new EObjContractRole ();
      returnObject1.setContractRoleIdPK(getLongObject (rs, 1)); 
      returnObject1.setContId(getLongObject (rs, 2)); 
      returnObject1.setContrComponentId(getLongObject (rs, 3)); 
      returnObject1.setContractRoleTpCd(getLongObject (rs, 4)); 
      returnObject1.setDistribPct(getBigDecimal (rs, 5)); 
      returnObject1.setIrrevocInd(getString (rs, 6)); 
      returnObject1.setStartDt(getTimestamp (rs, 7)); 
      returnObject1.setEndDt(getTimestamp (rs, 8)); 
      returnObject1.setRegisteredName(getString (rs, 9)); 
      returnObject1.setRecordedStartDt(getTimestamp (rs, 10)); 
      returnObject1.setRecordedEndDt(getTimestamp (rs, 11)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 12)); 
      returnObject1.setLastUpdateUser(getString (rs, 13)); 
      returnObject1.setArrangementTpCd(getLongObject (rs, 14)); 
      returnObject1.setShareDistTpCd(getLongObject (rs, 15)); 
      returnObject1.setEndReasonTpCd(getLongObject (rs, 16)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 17)); 
      returnObject1.setArrangementDesc(getString (rs, 18)); 
      returnObject.add (returnObject1);

      EObjXContractRoleExt returnObject2 = new EObjXContractRoleExt ();
      returnObject2.setLastUpdateDt(getTimestamp (rs, 12)); 
      returnObject2.setLastUpdateUser(getString (rs, 13)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 17)); 
      returnObject2.setXSourceIdentifier(getLongObject (rs, 19)); 
      returnObject.add (returnObject2);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT CONTRACTROLE.CONTRACT_ROLE_ID , CONTRACTROLE.CONT_ID , CONTRACTROLE.CONTR_COMPONENT_ID , CONTRACTROLE.CONTR_ROLE_TP_CD , CONTRACTROLE.DISTRIB_PCT , CONTRACTROLE.IRREVOC_IND , CONTRACTROLE.START_DT , CONTRACTROLE.END_DT , CONTRACTROLE.REGISTERED_NAME , CONTRACTROLE.RECORDED_START_DT , CONTRACTROLE.RECORDED_END_DT , CONTRACTROLE.LAST_UPDATE_DT , CONTRACTROLE.LAST_UPDATE_USER , CONTRACTROLE.ARRANGEMENT_TP_CD , CONTRACTROLE.SHARE_DIST_TP_CD , CONTRACTROLE.END_REASON_TP_CD ,CONTRACTROLE.LAST_UPDATE_TX_ID ,CONTRACTROLE.ARRANGEMENT_DESC, CONTRACTROLE.XSOURCE_IDENT_TP_CD FROM CONTRACTROLE WHERE CONTRACTROLE.CONT_ID = ? AND CONTRACTROLE.END_DT < ?", pattern="tableAlias (CONTRACTROLE => com.dwl.tcrm.financial.entityObject.EObjContractRole, H_CONTRACTROLE => com.dwl.tcrm.financial.entityObject.EObjContractRole , CONTRACTROLE => com.ibm.daimler.dsea.entityObject.EObjXContractRoleExt , H_CONTRACTROLE => com.ibm.daimler.dsea.entityObject.EObjXContractRoleExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue2<EObjContractRole,EObjXContractRoleExt>> getEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_INACTIVE (Object[] parameters)
  {
    return queryIterator (getEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_INACTIVEStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_INACTIVEStatementDescriptor = createStatementDescriptor (
    "getEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_INACTIVE(Object[])",
    "SELECT CONTRACTROLE.CONTRACT_ROLE_ID , CONTRACTROLE.CONT_ID , CONTRACTROLE.CONTR_COMPONENT_ID , CONTRACTROLE.CONTR_ROLE_TP_CD , CONTRACTROLE.DISTRIB_PCT , CONTRACTROLE.IRREVOC_IND , CONTRACTROLE.START_DT , CONTRACTROLE.END_DT , CONTRACTROLE.REGISTERED_NAME , CONTRACTROLE.RECORDED_START_DT , CONTRACTROLE.RECORDED_END_DT , CONTRACTROLE.LAST_UPDATE_DT , CONTRACTROLE.LAST_UPDATE_USER , CONTRACTROLE.ARRANGEMENT_TP_CD , CONTRACTROLE.SHARE_DIST_TP_CD , CONTRACTROLE.END_REASON_TP_CD ,CONTRACTROLE.LAST_UPDATE_TX_ID ,CONTRACTROLE.ARRANGEMENT_DESC, CONTRACTROLE.XSOURCE_IDENT_TP_CD FROM CONTRACTROLE WHERE CONTRACTROLE.CONT_ID = ? AND CONTRACTROLE.END_DT < ?",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"contract_role_id", "cont_id", "contr_component_id", "contr_role_tp_cd", "distrib_pct", "irrevoc_ind", "start_dt", "end_dt", "registered_name", "recorded_start_dt", "recorded_end_dt", "last_update_dt", "last_update_user", "arrangement_tp_cd", "share_dist_tp_cd", "end_reason_tp_cd", "last_update_tx_id", "arrangement_desc", "xsource_ident_tp_cd"},
    new GetEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_INACTIVEParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP}, {19, 0}, {0, 0}, {1, 1}},
    null,
    new GetEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_INACTIVERowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.DECIMAL, Types.CHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.BIGINT}, {19, 19, 19, 19, 5, 1, 0, 0, 255, 0, 0, 0, 20, 19, 19, 19, 19, 255, 19}, {0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    10);

  /**
   * @generated
   */
  public static class GetEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_INACTIVEParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_INACTIVERowHandler extends BaseRowHandler<ResultQueue2<EObjContractRole,EObjXContractRoleExt>>
  {
    /**
     * @generated
     */
    public ResultQueue2<EObjContractRole,EObjXContractRoleExt> handle (java.sql.ResultSet rs, ResultQueue2<EObjContractRole,EObjXContractRoleExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue2<EObjContractRole,EObjXContractRoleExt> ();

      EObjContractRole returnObject1 = new EObjContractRole ();
      returnObject1.setContractRoleIdPK(getLongObject (rs, 1)); 
      returnObject1.setContId(getLongObject (rs, 2)); 
      returnObject1.setContrComponentId(getLongObject (rs, 3)); 
      returnObject1.setContractRoleTpCd(getLongObject (rs, 4)); 
      returnObject1.setDistribPct(getBigDecimal (rs, 5)); 
      returnObject1.setIrrevocInd(getString (rs, 6)); 
      returnObject1.setStartDt(getTimestamp (rs, 7)); 
      returnObject1.setEndDt(getTimestamp (rs, 8)); 
      returnObject1.setRegisteredName(getString (rs, 9)); 
      returnObject1.setRecordedStartDt(getTimestamp (rs, 10)); 
      returnObject1.setRecordedEndDt(getTimestamp (rs, 11)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 12)); 
      returnObject1.setLastUpdateUser(getString (rs, 13)); 
      returnObject1.setArrangementTpCd(getLongObject (rs, 14)); 
      returnObject1.setShareDistTpCd(getLongObject (rs, 15)); 
      returnObject1.setEndReasonTpCd(getLongObject (rs, 16)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 17)); 
      returnObject1.setArrangementDesc(getString (rs, 18)); 
      returnObject.add (returnObject1);

      EObjXContractRoleExt returnObject2 = new EObjXContractRoleExt ();
      returnObject2.setLastUpdateDt(getTimestamp (rs, 12)); 
      returnObject2.setLastUpdateUser(getString (rs, 13)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 17)); 
      returnObject2.setXSourceIdentifier(getLongObject (rs, 19)); 
      returnObject.add (returnObject2);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT CONTRACTROLE.CONTRACT_ROLE_ID , CONTRACTROLE.CONT_ID , CONTRACTROLE.CONTR_COMPONENT_ID , CONTRACTROLE.CONTR_ROLE_TP_CD , CONTRACTROLE.DISTRIB_PCT , CONTRACTROLE.IRREVOC_IND , CONTRACTROLE.START_DT , CONTRACTROLE.END_DT , CONTRACTROLE.REGISTERED_NAME , CONTRACTROLE.RECORDED_START_DT , CONTRACTROLE.RECORDED_END_DT , CONTRACTROLE.LAST_UPDATE_DT , CONTRACTROLE.LAST_UPDATE_USER , CONTRACTROLE.ARRANGEMENT_TP_CD ,CONTRACTROLE.SHARE_DIST_TP_CD , CONTRACTROLE.END_REASON_TP_CD , CONTRACTROLE.LAST_UPDATE_TX_ID ,CONTRACTROLE.ARRANGEMENT_DESC, CONTRACTROLE.XSOURCE_IDENT_TP_CD FROM CONTRACTROLE WHERE CONTRACTROLE.CONT_ID = ?", pattern="tableAlias (CONTRACTROLE => com.dwl.tcrm.financial.entityObject.EObjContractRole, H_CONTRACTROLE => com.dwl.tcrm.financial.entityObject.EObjContractRole , CONTRACTROLE => com.ibm.daimler.dsea.entityObject.EObjXContractRoleExt , H_CONTRACTROLE => com.ibm.daimler.dsea.entityObject.EObjXContractRoleExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue2<EObjContractRole,EObjXContractRoleExt>> getEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_ALL (Object[] parameters)
  {
    return queryIterator (getEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_ALLStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_ALLStatementDescriptor = createStatementDescriptor (
    "getEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_ALL(Object[])",
    "SELECT CONTRACTROLE.CONTRACT_ROLE_ID , CONTRACTROLE.CONT_ID , CONTRACTROLE.CONTR_COMPONENT_ID , CONTRACTROLE.CONTR_ROLE_TP_CD , CONTRACTROLE.DISTRIB_PCT , CONTRACTROLE.IRREVOC_IND , CONTRACTROLE.START_DT , CONTRACTROLE.END_DT , CONTRACTROLE.REGISTERED_NAME , CONTRACTROLE.RECORDED_START_DT , CONTRACTROLE.RECORDED_END_DT , CONTRACTROLE.LAST_UPDATE_DT , CONTRACTROLE.LAST_UPDATE_USER , CONTRACTROLE.ARRANGEMENT_TP_CD ,CONTRACTROLE.SHARE_DIST_TP_CD , CONTRACTROLE.END_REASON_TP_CD , CONTRACTROLE.LAST_UPDATE_TX_ID ,CONTRACTROLE.ARRANGEMENT_DESC, CONTRACTROLE.XSOURCE_IDENT_TP_CD FROM CONTRACTROLE WHERE CONTRACTROLE.CONT_ID = ?",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"contract_role_id", "cont_id", "contr_component_id", "contr_role_tp_cd", "distrib_pct", "irrevoc_ind", "start_dt", "end_dt", "registered_name", "recorded_start_dt", "recorded_end_dt", "last_update_dt", "last_update_user", "arrangement_tp_cd", "share_dist_tp_cd", "end_reason_tp_cd", "last_update_tx_id", "arrangement_desc", "xsource_ident_tp_cd"},
    new GetEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_ALLParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_ALLRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.DECIMAL, Types.CHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.BIGINT}, {19, 19, 19, 19, 5, 1, 0, 0, 255, 0, 0, 0, 20, 19, 19, 19, 19, 255, 19}, {0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    11);

  /**
   * @generated
   */
  public static class GetEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_ALLParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_ALLRowHandler extends BaseRowHandler<ResultQueue2<EObjContractRole,EObjXContractRoleExt>>
  {
    /**
     * @generated
     */
    public ResultQueue2<EObjContractRole,EObjXContractRoleExt> handle (java.sql.ResultSet rs, ResultQueue2<EObjContractRole,EObjXContractRoleExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue2<EObjContractRole,EObjXContractRoleExt> ();

      EObjContractRole returnObject1 = new EObjContractRole ();
      returnObject1.setContractRoleIdPK(getLongObject (rs, 1)); 
      returnObject1.setContId(getLongObject (rs, 2)); 
      returnObject1.setContrComponentId(getLongObject (rs, 3)); 
      returnObject1.setContractRoleTpCd(getLongObject (rs, 4)); 
      returnObject1.setDistribPct(getBigDecimal (rs, 5)); 
      returnObject1.setIrrevocInd(getString (rs, 6)); 
      returnObject1.setStartDt(getTimestamp (rs, 7)); 
      returnObject1.setEndDt(getTimestamp (rs, 8)); 
      returnObject1.setRegisteredName(getString (rs, 9)); 
      returnObject1.setRecordedStartDt(getTimestamp (rs, 10)); 
      returnObject1.setRecordedEndDt(getTimestamp (rs, 11)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 12)); 
      returnObject1.setLastUpdateUser(getString (rs, 13)); 
      returnObject1.setArrangementTpCd(getLongObject (rs, 14)); 
      returnObject1.setShareDistTpCd(getLongObject (rs, 15)); 
      returnObject1.setEndReasonTpCd(getLongObject (rs, 16)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 17)); 
      returnObject1.setArrangementDesc(getString (rs, 18)); 
      returnObject.add (returnObject1);

      EObjXContractRoleExt returnObject2 = new EObjXContractRoleExt ();
      returnObject2.setLastUpdateDt(getTimestamp (rs, 12)); 
      returnObject2.setLastUpdateUser(getString (rs, 13)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 17)); 
      returnObject2.setXSourceIdentifier(getLongObject (rs, 19)); 
      returnObject.add (returnObject2);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT A.H_CONTRACT_ROLE_ID AS HIST_ID_PK , A.H_ACTION_CODE , A.H_CREATED_BY , A.H_CREATE_DT , A.H_END_DT , A.CONTRACT_ROLE_ID , A.CONT_ID , A.CONTR_COMPONENT_ID , A.CONTR_ROLE_TP_CD , A.DISTRIB_PCT , A.IRREVOC_IND , A.START_DT , A.END_DT , A.REGISTERED_NAME , A.RECORDED_START_DT , A.RECORDED_END_DT , A.LAST_UPDATE_DT , A.LAST_UPDATE_USER , A.ARRANGEMENT_TP_CD , A.SHARE_DIST_TP_CD , A.END_REASON_TP_CD , A.LAST_UPDATE_TX_ID, A.XSOURCE_IDENT_TP_CD FROM H_CONTRACTROLE A WHERE A.CONT_ID = ? AND A.CONTR_COMPONENT_ID = ? AND (? BETWEEN A.H_CREATE_DT AND A.H_END_DT OR ? >= A.H_CREATE_DT AND A.H_END_DT IS NULL)", pattern="tableAlias (CONTRACTROLE => com.dwl.tcrm.financial.entityObject.EObjContractRole, H_CONTRACTROLE => com.dwl.tcrm.financial.entityObject.EObjContractRole , CONTRACTROLE => com.ibm.daimler.dsea.entityObject.EObjXContractRoleExt , H_CONTRACTROLE => com.ibm.daimler.dsea.entityObject.EObjXContractRoleExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue2<EObjContractRole,EObjXContractRoleExt>> getEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_AND_COMPONENT_HISTORY (Object[] parameters)
  {
    return queryIterator (getEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_AND_COMPONENT_HISTORYStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_AND_COMPONENT_HISTORYStatementDescriptor = createStatementDescriptor (
    "getEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_AND_COMPONENT_HISTORY(Object[])",
    "SELECT A.H_CONTRACT_ROLE_ID AS HIST_ID_PK , A.H_ACTION_CODE , A.H_CREATED_BY , A.H_CREATE_DT , A.H_END_DT , A.CONTRACT_ROLE_ID , A.CONT_ID , A.CONTR_COMPONENT_ID , A.CONTR_ROLE_TP_CD , A.DISTRIB_PCT , A.IRREVOC_IND , A.START_DT , A.END_DT , A.REGISTERED_NAME , A.RECORDED_START_DT , A.RECORDED_END_DT , A.LAST_UPDATE_DT , A.LAST_UPDATE_USER , A.ARRANGEMENT_TP_CD , A.SHARE_DIST_TP_CD , A.END_REASON_TP_CD , A.LAST_UPDATE_TX_ID, A.XSOURCE_IDENT_TP_CD FROM H_CONTRACTROLE A WHERE A.CONT_ID = ? AND A.CONTR_COMPONENT_ID = ? AND (? BETWEEN A.H_CREATE_DT AND A.H_END_DT OR ? >= A.H_CREATE_DT AND A.H_END_DT IS NULL)",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"hist_id_pk", "h_action_code", "h_created_by", "h_create_dt", "h_end_dt", "contract_role_id", "cont_id", "contr_component_id", "contr_role_tp_cd", "distrib_pct", "irrevoc_ind", "start_dt", "end_dt", "registered_name", "recorded_start_dt", "recorded_end_dt", "last_update_dt", "last_update_user", "arrangement_tp_cd", "share_dist_tp_cd", "end_reason_tp_cd", "last_update_tx_id", "xsource_ident_tp_cd"},
    new GetEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_AND_COMPONENT_HISTORYParameterHandler (),
    new int[][]{{Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP}, {19, 19, 0, 0}, {0, 0, 0, 0}, {1, 1, 1, 1}},
    null,
    new GetEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_AND_COMPONENT_HISTORYRowHandler (),
    new int[][]{ {Types.BIGINT, Types.CHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.DECIMAL, Types.CHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT}, {19, 1, 20, 0, 0, 19, 19, 19, 19, 5, 1, 0, 0, 255, 0, 0, 0, 20, 19, 19, 19, 19, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    12);

  /**
   * @generated
   */
  public static class GetEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_AND_COMPONENT_HISTORYParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.BIGINT, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
      setObject (stmt, 4, Types.TIMESTAMP, parameters[3], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_AND_COMPONENT_HISTORYRowHandler extends BaseRowHandler<ResultQueue2<EObjContractRole,EObjXContractRoleExt>>
  {
    /**
     * @generated
     */
    public ResultQueue2<EObjContractRole,EObjXContractRoleExt> handle (java.sql.ResultSet rs, ResultQueue2<EObjContractRole,EObjXContractRoleExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue2<EObjContractRole,EObjXContractRoleExt> ();

      EObjContractRole returnObject1 = new EObjContractRole ();
      returnObject1.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject1.setHistActionCode(getString (rs, 2)); 
      returnObject1.setHistCreatedBy(getString (rs, 3)); 
      returnObject1.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject1.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject1.setContractRoleIdPK(getLongObject (rs, 6)); 
      returnObject1.setContId(getLongObject (rs, 7)); 
      returnObject1.setContrComponentId(getLongObject (rs, 8)); 
      returnObject1.setContractRoleTpCd(getLongObject (rs, 9)); 
      returnObject1.setDistribPct(getBigDecimal (rs, 10)); 
      returnObject1.setIrrevocInd(getString (rs, 11)); 
      returnObject1.setStartDt(getTimestamp (rs, 12)); 
      returnObject1.setEndDt(getTimestamp (rs, 13)); 
      returnObject1.setRegisteredName(getString (rs, 14)); 
      returnObject1.setRecordedStartDt(getTimestamp (rs, 15)); 
      returnObject1.setRecordedEndDt(getTimestamp (rs, 16)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 17)); 
      returnObject1.setLastUpdateUser(getString (rs, 18)); 
      returnObject1.setArrangementTpCd(getLongObject (rs, 19)); 
      returnObject1.setShareDistTpCd(getLongObject (rs, 20)); 
      returnObject1.setEndReasonTpCd(getLongObject (rs, 21)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 22)); 
      returnObject.add (returnObject1);

      EObjXContractRoleExt returnObject2 = new EObjXContractRoleExt ();
      returnObject2.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject2.setHistActionCode(getString (rs, 2)); 
      returnObject2.setHistCreatedBy(getString (rs, 3)); 
      returnObject2.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject2.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject2.setLastUpdateDt(getTimestamp (rs, 17)); 
      returnObject2.setLastUpdateUser(getString (rs, 18)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 22)); 
      returnObject2.setXSourceIdentifier(getLongObject (rs, 23)); 
      returnObject.add (returnObject2);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT CONTRACTROLE.CONTRACT_ROLE_ID , CONTRACTROLE.CONT_ID , CONTRACTROLE.CONTR_COMPONENT_ID , CONTRACTROLE.CONTR_ROLE_TP_CD , CONTRACTROLE.DISTRIB_PCT , CONTRACTROLE.IRREVOC_IND , CONTRACTROLE.START_DT , CONTRACTROLE.END_DT , CONTRACTROLE.REGISTERED_NAME , CONTRACTROLE.RECORDED_START_DT , CONTRACTROLE.RECORDED_END_DT , CONTRACTROLE.LAST_UPDATE_DT , CONTRACTROLE.LAST_UPDATE_USER , CONTRACTROLE.ARRANGEMENT_TP_CD ,CONTRACTROLE.SHARE_DIST_TP_CD , CONTRACTROLE.END_REASON_TP_CD , CONTRACTROLE.LAST_UPDATE_TX_ID ,CONTRACTROLE.ARRANGEMENT_DESC, CONTRACTROLE.XSOURCE_IDENT_TP_CD FROM CONTRACTROLE WHERE (CONTRACTROLE.CONT_ID = ?) AND (CONTRACTROLE.CONTR_COMPONENT_ID = ?) AND (CONTRACTROLE.END_DT IS NULL OR CONTRACTROLE.END_DT > ? )", pattern="tableAlias (CONTRACTROLE => com.dwl.tcrm.financial.entityObject.EObjContractRole, H_CONTRACTROLE => com.dwl.tcrm.financial.entityObject.EObjContractRole , CONTRACTROLE => com.ibm.daimler.dsea.entityObject.EObjXContractRoleExt , H_CONTRACTROLE => com.ibm.daimler.dsea.entityObject.EObjXContractRoleExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue2<EObjContractRole,EObjXContractRoleExt>> getEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_AND_COMPONENT_ACTIVE (Object[] parameters)
  {
    return queryIterator (getEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_AND_COMPONENT_ACTIVEStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_AND_COMPONENT_ACTIVEStatementDescriptor = createStatementDescriptor (
    "getEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_AND_COMPONENT_ACTIVE(Object[])",
    "SELECT CONTRACTROLE.CONTRACT_ROLE_ID , CONTRACTROLE.CONT_ID , CONTRACTROLE.CONTR_COMPONENT_ID , CONTRACTROLE.CONTR_ROLE_TP_CD , CONTRACTROLE.DISTRIB_PCT , CONTRACTROLE.IRREVOC_IND , CONTRACTROLE.START_DT , CONTRACTROLE.END_DT , CONTRACTROLE.REGISTERED_NAME , CONTRACTROLE.RECORDED_START_DT , CONTRACTROLE.RECORDED_END_DT , CONTRACTROLE.LAST_UPDATE_DT , CONTRACTROLE.LAST_UPDATE_USER , CONTRACTROLE.ARRANGEMENT_TP_CD ,CONTRACTROLE.SHARE_DIST_TP_CD , CONTRACTROLE.END_REASON_TP_CD , CONTRACTROLE.LAST_UPDATE_TX_ID ,CONTRACTROLE.ARRANGEMENT_DESC, CONTRACTROLE.XSOURCE_IDENT_TP_CD FROM CONTRACTROLE WHERE (CONTRACTROLE.CONT_ID = ?) AND (CONTRACTROLE.CONTR_COMPONENT_ID = ?) AND (CONTRACTROLE.END_DT IS NULL OR CONTRACTROLE.END_DT > ? )",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"contract_role_id", "cont_id", "contr_component_id", "contr_role_tp_cd", "distrib_pct", "irrevoc_ind", "start_dt", "end_dt", "registered_name", "recorded_start_dt", "recorded_end_dt", "last_update_dt", "last_update_user", "arrangement_tp_cd", "share_dist_tp_cd", "end_reason_tp_cd", "last_update_tx_id", "arrangement_desc", "xsource_ident_tp_cd"},
    new GetEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_AND_COMPONENT_ACTIVEParameterHandler (),
    new int[][]{{Types.BIGINT, Types.BIGINT, Types.TIMESTAMP}, {19, 19, 0}, {0, 0, 0}, {1, 1, 1}},
    null,
    new GetEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_AND_COMPONENT_ACTIVERowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.DECIMAL, Types.CHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.BIGINT}, {19, 19, 19, 19, 5, 1, 0, 0, 255, 0, 0, 0, 20, 19, 19, 19, 19, 255, 19}, {0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    13);

  /**
   * @generated
   */
  public static class GetEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_AND_COMPONENT_ACTIVEParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.BIGINT, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_AND_COMPONENT_ACTIVERowHandler extends BaseRowHandler<ResultQueue2<EObjContractRole,EObjXContractRoleExt>>
  {
    /**
     * @generated
     */
    public ResultQueue2<EObjContractRole,EObjXContractRoleExt> handle (java.sql.ResultSet rs, ResultQueue2<EObjContractRole,EObjXContractRoleExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue2<EObjContractRole,EObjXContractRoleExt> ();

      EObjContractRole returnObject1 = new EObjContractRole ();
      returnObject1.setContractRoleIdPK(getLongObject (rs, 1)); 
      returnObject1.setContId(getLongObject (rs, 2)); 
      returnObject1.setContrComponentId(getLongObject (rs, 3)); 
      returnObject1.setContractRoleTpCd(getLongObject (rs, 4)); 
      returnObject1.setDistribPct(getBigDecimal (rs, 5)); 
      returnObject1.setIrrevocInd(getString (rs, 6)); 
      returnObject1.setStartDt(getTimestamp (rs, 7)); 
      returnObject1.setEndDt(getTimestamp (rs, 8)); 
      returnObject1.setRegisteredName(getString (rs, 9)); 
      returnObject1.setRecordedStartDt(getTimestamp (rs, 10)); 
      returnObject1.setRecordedEndDt(getTimestamp (rs, 11)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 12)); 
      returnObject1.setLastUpdateUser(getString (rs, 13)); 
      returnObject1.setArrangementTpCd(getLongObject (rs, 14)); 
      returnObject1.setShareDistTpCd(getLongObject (rs, 15)); 
      returnObject1.setEndReasonTpCd(getLongObject (rs, 16)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 17)); 
      returnObject1.setArrangementDesc(getString (rs, 18)); 
      returnObject.add (returnObject1);

      EObjXContractRoleExt returnObject2 = new EObjXContractRoleExt ();
      returnObject2.setLastUpdateDt(getTimestamp (rs, 12)); 
      returnObject2.setLastUpdateUser(getString (rs, 13)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 17)); 
      returnObject2.setXSourceIdentifier(getLongObject (rs, 19)); 
      returnObject.add (returnObject2);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT CONTRACTROLE.CONTRACT_ROLE_ID , CONTRACTROLE.CONT_ID , CONTRACTROLE.CONTR_COMPONENT_ID , CONTRACTROLE.CONTR_ROLE_TP_CD , CONTRACTROLE.DISTRIB_PCT , CONTRACTROLE.IRREVOC_IND , CONTRACTROLE.START_DT , CONTRACTROLE.END_DT ,CONTRACTROLE.REGISTERED_NAME , CONTRACTROLE.RECORDED_START_DT , CONTRACTROLE.RECORDED_END_DT , CONTRACTROLE.LAST_UPDATE_DT , CONTRACTROLE.LAST_UPDATE_USER , CONTRACTROLE.ARRANGEMENT_TP_CD ,CONTRACTROLE.SHARE_DIST_TP_CD , CONTRACTROLE.END_REASON_TP_CD , CONTRACTROLE.LAST_UPDATE_TX_ID , CONTRACTROLE.ARRANGEMENT_DESC, CONTRACTROLE.XSOURCE_IDENT_TP_CD FROM CONTRACTROLE WHERE (CONTRACTROLE.CONT_ID = ?) AND (CONTRACTROLE.CONTR_COMPONENT_ID = ?) AND (CONTRACTROLE.END_DT < ? )", pattern="tableAlias (CONTRACTROLE => com.dwl.tcrm.financial.entityObject.EObjContractRole, H_CONTRACTROLE => com.dwl.tcrm.financial.entityObject.EObjContractRole , CONTRACTROLE => com.ibm.daimler.dsea.entityObject.EObjXContractRoleExt , H_CONTRACTROLE => com.ibm.daimler.dsea.entityObject.EObjXContractRoleExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue2<EObjContractRole,EObjXContractRoleExt>> getEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_AND_COMPONENT_ID_INACTIVE (Object[] parameters)
  {
    return queryIterator (getEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_AND_COMPONENT_ID_INACTIVEStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_AND_COMPONENT_ID_INACTIVEStatementDescriptor = createStatementDescriptor (
    "getEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_AND_COMPONENT_ID_INACTIVE(Object[])",
    "SELECT CONTRACTROLE.CONTRACT_ROLE_ID , CONTRACTROLE.CONT_ID , CONTRACTROLE.CONTR_COMPONENT_ID , CONTRACTROLE.CONTR_ROLE_TP_CD , CONTRACTROLE.DISTRIB_PCT , CONTRACTROLE.IRREVOC_IND , CONTRACTROLE.START_DT , CONTRACTROLE.END_DT ,CONTRACTROLE.REGISTERED_NAME , CONTRACTROLE.RECORDED_START_DT , CONTRACTROLE.RECORDED_END_DT , CONTRACTROLE.LAST_UPDATE_DT , CONTRACTROLE.LAST_UPDATE_USER , CONTRACTROLE.ARRANGEMENT_TP_CD ,CONTRACTROLE.SHARE_DIST_TP_CD , CONTRACTROLE.END_REASON_TP_CD , CONTRACTROLE.LAST_UPDATE_TX_ID , CONTRACTROLE.ARRANGEMENT_DESC, CONTRACTROLE.XSOURCE_IDENT_TP_CD FROM CONTRACTROLE WHERE (CONTRACTROLE.CONT_ID = ?) AND (CONTRACTROLE.CONTR_COMPONENT_ID = ?) AND (CONTRACTROLE.END_DT < ? )",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"contract_role_id", "cont_id", "contr_component_id", "contr_role_tp_cd", "distrib_pct", "irrevoc_ind", "start_dt", "end_dt", "registered_name", "recorded_start_dt", "recorded_end_dt", "last_update_dt", "last_update_user", "arrangement_tp_cd", "share_dist_tp_cd", "end_reason_tp_cd", "last_update_tx_id", "arrangement_desc", "xsource_ident_tp_cd"},
    new GetEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_AND_COMPONENT_ID_INACTIVEParameterHandler (),
    new int[][]{{Types.BIGINT, Types.BIGINT, Types.TIMESTAMP}, {19, 19, 0}, {0, 0, 0}, {1, 1, 1}},
    null,
    new GetEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_AND_COMPONENT_ID_INACTIVERowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.DECIMAL, Types.CHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.BIGINT}, {19, 19, 19, 19, 5, 1, 0, 0, 255, 0, 0, 0, 20, 19, 19, 19, 19, 255, 19}, {0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    14);

  /**
   * @generated
   */
  public static class GetEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_AND_COMPONENT_ID_INACTIVEParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.BIGINT, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_AND_COMPONENT_ID_INACTIVERowHandler extends BaseRowHandler<ResultQueue2<EObjContractRole,EObjXContractRoleExt>>
  {
    /**
     * @generated
     */
    public ResultQueue2<EObjContractRole,EObjXContractRoleExt> handle (java.sql.ResultSet rs, ResultQueue2<EObjContractRole,EObjXContractRoleExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue2<EObjContractRole,EObjXContractRoleExt> ();

      EObjContractRole returnObject1 = new EObjContractRole ();
      returnObject1.setContractRoleIdPK(getLongObject (rs, 1)); 
      returnObject1.setContId(getLongObject (rs, 2)); 
      returnObject1.setContrComponentId(getLongObject (rs, 3)); 
      returnObject1.setContractRoleTpCd(getLongObject (rs, 4)); 
      returnObject1.setDistribPct(getBigDecimal (rs, 5)); 
      returnObject1.setIrrevocInd(getString (rs, 6)); 
      returnObject1.setStartDt(getTimestamp (rs, 7)); 
      returnObject1.setEndDt(getTimestamp (rs, 8)); 
      returnObject1.setRegisteredName(getString (rs, 9)); 
      returnObject1.setRecordedStartDt(getTimestamp (rs, 10)); 
      returnObject1.setRecordedEndDt(getTimestamp (rs, 11)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 12)); 
      returnObject1.setLastUpdateUser(getString (rs, 13)); 
      returnObject1.setArrangementTpCd(getLongObject (rs, 14)); 
      returnObject1.setShareDistTpCd(getLongObject (rs, 15)); 
      returnObject1.setEndReasonTpCd(getLongObject (rs, 16)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 17)); 
      returnObject1.setArrangementDesc(getString (rs, 18)); 
      returnObject.add (returnObject1);

      EObjXContractRoleExt returnObject2 = new EObjXContractRoleExt ();
      returnObject2.setLastUpdateDt(getTimestamp (rs, 12)); 
      returnObject2.setLastUpdateUser(getString (rs, 13)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 17)); 
      returnObject2.setXSourceIdentifier(getLongObject (rs, 19)); 
      returnObject.add (returnObject2);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT CONTRACTROLE.CONTRACT_ROLE_ID , CONTRACTROLE.CONT_ID , CONTRACTROLE.CONTR_COMPONENT_ID , CONTRACTROLE.CONTR_ROLE_TP_CD , CONTRACTROLE.DISTRIB_PCT , CONTRACTROLE.IRREVOC_IND , CONTRACTROLE.START_DT , CONTRACTROLE.END_DT , CONTRACTROLE.REGISTERED_NAME , CONTRACTROLE.RECORDED_START_DT , CONTRACTROLE.RECORDED_END_DT , CONTRACTROLE.LAST_UPDATE_DT , CONTRACTROLE.LAST_UPDATE_USER , CONTRACTROLE.ARRANGEMENT_TP_CD , CONTRACTROLE.SHARE_DIST_TP_CD , CONTRACTROLE.END_REASON_TP_CD , CONTRACTROLE.LAST_UPDATE_TX_ID , CONTRACTROLE.ARRANGEMENT_DESC, CONTRACTROLE.XSOURCE_IDENT_TP_CD FROM CONTRACTROLE WHERE (CONTRACTROLE.CONT_ID = ?) AND (CONTRACTROLE.CONTR_COMPONENT_ID = ?)", pattern="tableAlias (CONTRACTROLE => com.dwl.tcrm.financial.entityObject.EObjContractRole, H_CONTRACTROLE => com.dwl.tcrm.financial.entityObject.EObjContractRole , CONTRACTROLE => com.ibm.daimler.dsea.entityObject.EObjXContractRoleExt , H_CONTRACTROLE => com.ibm.daimler.dsea.entityObject.EObjXContractRoleExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue2<EObjContractRole,EObjXContractRoleExt>> getEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_AND_COMPONENT_ID_ALL_QUERY_RECORDS (Object[] parameters)
  {
    return queryIterator (getEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_AND_COMPONENT_ID_ALL_QUERY_RECORDSStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_AND_COMPONENT_ID_ALL_QUERY_RECORDSStatementDescriptor = createStatementDescriptor (
    "getEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_AND_COMPONENT_ID_ALL_QUERY_RECORDS(Object[])",
    "SELECT CONTRACTROLE.CONTRACT_ROLE_ID , CONTRACTROLE.CONT_ID , CONTRACTROLE.CONTR_COMPONENT_ID , CONTRACTROLE.CONTR_ROLE_TP_CD , CONTRACTROLE.DISTRIB_PCT , CONTRACTROLE.IRREVOC_IND , CONTRACTROLE.START_DT , CONTRACTROLE.END_DT , CONTRACTROLE.REGISTERED_NAME , CONTRACTROLE.RECORDED_START_DT , CONTRACTROLE.RECORDED_END_DT , CONTRACTROLE.LAST_UPDATE_DT , CONTRACTROLE.LAST_UPDATE_USER , CONTRACTROLE.ARRANGEMENT_TP_CD , CONTRACTROLE.SHARE_DIST_TP_CD , CONTRACTROLE.END_REASON_TP_CD , CONTRACTROLE.LAST_UPDATE_TX_ID , CONTRACTROLE.ARRANGEMENT_DESC, CONTRACTROLE.XSOURCE_IDENT_TP_CD FROM CONTRACTROLE WHERE (CONTRACTROLE.CONT_ID = ?) AND (CONTRACTROLE.CONTR_COMPONENT_ID = ?)",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"contract_role_id", "cont_id", "contr_component_id", "contr_role_tp_cd", "distrib_pct", "irrevoc_ind", "start_dt", "end_dt", "registered_name", "recorded_start_dt", "recorded_end_dt", "last_update_dt", "last_update_user", "arrangement_tp_cd", "share_dist_tp_cd", "end_reason_tp_cd", "last_update_tx_id", "arrangement_desc", "xsource_ident_tp_cd"},
    new GetEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_AND_COMPONENT_ID_ALL_QUERY_RECORDSParameterHandler (),
    new int[][]{{Types.BIGINT, Types.BIGINT}, {19, 19}, {0, 0}, {1, 1}},
    null,
    new GetEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_AND_COMPONENT_ID_ALL_QUERY_RECORDSRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.DECIMAL, Types.CHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.BIGINT}, {19, 19, 19, 19, 5, 1, 0, 0, 255, 0, 0, 0, 20, 19, 19, 19, 19, 255, 19}, {0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    15);

  /**
   * @generated
   */
  public static class GetEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_AND_COMPONENT_ID_ALL_QUERY_RECORDSParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.BIGINT, parameters[1], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_AND_COMPONENT_ID_ALL_QUERY_RECORDSRowHandler extends BaseRowHandler<ResultQueue2<EObjContractRole,EObjXContractRoleExt>>
  {
    /**
     * @generated
     */
    public ResultQueue2<EObjContractRole,EObjXContractRoleExt> handle (java.sql.ResultSet rs, ResultQueue2<EObjContractRole,EObjXContractRoleExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue2<EObjContractRole,EObjXContractRoleExt> ();

      EObjContractRole returnObject1 = new EObjContractRole ();
      returnObject1.setContractRoleIdPK(getLongObject (rs, 1)); 
      returnObject1.setContId(getLongObject (rs, 2)); 
      returnObject1.setContrComponentId(getLongObject (rs, 3)); 
      returnObject1.setContractRoleTpCd(getLongObject (rs, 4)); 
      returnObject1.setDistribPct(getBigDecimal (rs, 5)); 
      returnObject1.setIrrevocInd(getString (rs, 6)); 
      returnObject1.setStartDt(getTimestamp (rs, 7)); 
      returnObject1.setEndDt(getTimestamp (rs, 8)); 
      returnObject1.setRegisteredName(getString (rs, 9)); 
      returnObject1.setRecordedStartDt(getTimestamp (rs, 10)); 
      returnObject1.setRecordedEndDt(getTimestamp (rs, 11)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 12)); 
      returnObject1.setLastUpdateUser(getString (rs, 13)); 
      returnObject1.setArrangementTpCd(getLongObject (rs, 14)); 
      returnObject1.setShareDistTpCd(getLongObject (rs, 15)); 
      returnObject1.setEndReasonTpCd(getLongObject (rs, 16)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 17)); 
      returnObject1.setArrangementDesc(getString (rs, 18)); 
      returnObject.add (returnObject1);

      EObjXContractRoleExt returnObject2 = new EObjXContractRoleExt ();
      returnObject2.setLastUpdateDt(getTimestamp (rs, 12)); 
      returnObject2.setLastUpdateUser(getString (rs, 13)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 17)); 
      returnObject2.setXSourceIdentifier(getLongObject (rs, 19)); 
      returnObject.add (returnObject2);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT A.H_CONTRACT_ROLE_ID AS HIST_ID_PK , A.H_ACTION_CODE , A.H_CREATED_BY , A.H_CREATE_DT , A.H_END_DT , A.CONTRACT_ROLE_ID , A.CONT_ID , A.CONTR_COMPONENT_ID , A.CONTR_ROLE_TP_CD , A.DISTRIB_PCT , A.IRREVOC_IND , A.START_DT , A.END_DT , A.REGISTERED_NAME , A.RECORDED_START_DT , A.RECORDED_END_DT , A.LAST_UPDATE_DT , A.LAST_UPDATE_USER , A.ARRANGEMENT_TP_CD , A.SHARE_DIST_TP_CD , A.END_REASON_TP_CD , A.LAST_UPDATE_TX_ID , A.ARRANGEMENT_DESC, A.XSOURCE_IDENT_TP_CD FROM H_CONTRACTROLE A WHERE A.H_CONTRACT_ROLE_ID = ? AND (? BETWEEN A.H_CREATE_DT AND A.H_END_DT OR ? >= A.H_CREATE_DT AND A.H_END_DT IS NULL )", pattern="tableAlias (CONTRACTROLE => com.dwl.tcrm.financial.entityObject.EObjContractRole, H_CONTRACTROLE => com.dwl.tcrm.financial.entityObject.EObjContractRole , CONTRACTROLE => com.ibm.daimler.dsea.entityObject.EObjXContractRoleExt , H_CONTRACTROLE => com.ibm.daimler.dsea.entityObject.EObjXContractRoleExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue2<EObjContractRole,EObjXContractRoleExt>> getEObjCONTRACT_PARTY_ROLE_HISTORY (Object[] parameters)
  {
    return queryIterator (getEObjCONTRACT_PARTY_ROLE_HISTORYStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getEObjCONTRACT_PARTY_ROLE_HISTORYStatementDescriptor = createStatementDescriptor (
    "getEObjCONTRACT_PARTY_ROLE_HISTORY(Object[])",
    "SELECT A.H_CONTRACT_ROLE_ID AS HIST_ID_PK , A.H_ACTION_CODE , A.H_CREATED_BY , A.H_CREATE_DT , A.H_END_DT , A.CONTRACT_ROLE_ID , A.CONT_ID , A.CONTR_COMPONENT_ID , A.CONTR_ROLE_TP_CD , A.DISTRIB_PCT , A.IRREVOC_IND , A.START_DT , A.END_DT , A.REGISTERED_NAME , A.RECORDED_START_DT , A.RECORDED_END_DT , A.LAST_UPDATE_DT , A.LAST_UPDATE_USER , A.ARRANGEMENT_TP_CD , A.SHARE_DIST_TP_CD , A.END_REASON_TP_CD , A.LAST_UPDATE_TX_ID , A.ARRANGEMENT_DESC, A.XSOURCE_IDENT_TP_CD FROM H_CONTRACTROLE A WHERE A.H_CONTRACT_ROLE_ID = ? AND (? BETWEEN A.H_CREATE_DT AND A.H_END_DT OR ? >= A.H_CREATE_DT AND A.H_END_DT IS NULL )",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"hist_id_pk", "h_action_code", "h_created_by", "h_create_dt", "h_end_dt", "contract_role_id", "cont_id", "contr_component_id", "contr_role_tp_cd", "distrib_pct", "irrevoc_ind", "start_dt", "end_dt", "registered_name", "recorded_start_dt", "recorded_end_dt", "last_update_dt", "last_update_user", "arrangement_tp_cd", "share_dist_tp_cd", "end_reason_tp_cd", "last_update_tx_id", "arrangement_desc", "xsource_ident_tp_cd"},
    new GetEObjCONTRACT_PARTY_ROLE_HISTORYParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP}, {19, 0, 0}, {0, 0, 0}, {1, 1, 1}},
    null,
    new GetEObjCONTRACT_PARTY_ROLE_HISTORYRowHandler (),
    new int[][]{ {Types.BIGINT, Types.CHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.DECIMAL, Types.CHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.BIGINT}, {19, 1, 20, 0, 0, 19, 19, 19, 19, 5, 1, 0, 0, 255, 0, 0, 0, 20, 19, 19, 19, 19, 255, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    16);

  /**
   * @generated
   */
  public static class GetEObjCONTRACT_PARTY_ROLE_HISTORYParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetEObjCONTRACT_PARTY_ROLE_HISTORYRowHandler extends BaseRowHandler<ResultQueue2<EObjContractRole,EObjXContractRoleExt>>
  {
    /**
     * @generated
     */
    public ResultQueue2<EObjContractRole,EObjXContractRoleExt> handle (java.sql.ResultSet rs, ResultQueue2<EObjContractRole,EObjXContractRoleExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue2<EObjContractRole,EObjXContractRoleExt> ();

      EObjContractRole returnObject1 = new EObjContractRole ();
      returnObject1.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject1.setHistActionCode(getString (rs, 2)); 
      returnObject1.setHistCreatedBy(getString (rs, 3)); 
      returnObject1.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject1.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject1.setContractRoleIdPK(getLongObject (rs, 6)); 
      returnObject1.setContId(getLongObject (rs, 7)); 
      returnObject1.setContrComponentId(getLongObject (rs, 8)); 
      returnObject1.setContractRoleTpCd(getLongObject (rs, 9)); 
      returnObject1.setDistribPct(getBigDecimal (rs, 10)); 
      returnObject1.setIrrevocInd(getString (rs, 11)); 
      returnObject1.setStartDt(getTimestamp (rs, 12)); 
      returnObject1.setEndDt(getTimestamp (rs, 13)); 
      returnObject1.setRegisteredName(getString (rs, 14)); 
      returnObject1.setRecordedStartDt(getTimestamp (rs, 15)); 
      returnObject1.setRecordedEndDt(getTimestamp (rs, 16)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 17)); 
      returnObject1.setLastUpdateUser(getString (rs, 18)); 
      returnObject1.setArrangementTpCd(getLongObject (rs, 19)); 
      returnObject1.setShareDistTpCd(getLongObject (rs, 20)); 
      returnObject1.setEndReasonTpCd(getLongObject (rs, 21)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 22)); 
      returnObject1.setArrangementDesc(getString (rs, 23)); 
      returnObject.add (returnObject1);

      EObjXContractRoleExt returnObject2 = new EObjXContractRoleExt ();
      returnObject2.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject2.setHistActionCode(getString (rs, 2)); 
      returnObject2.setHistCreatedBy(getString (rs, 3)); 
      returnObject2.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject2.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject2.setLastUpdateDt(getTimestamp (rs, 17)); 
      returnObject2.setLastUpdateUser(getString (rs, 18)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 22)); 
      returnObject2.setXSourceIdentifier(getLongObject (rs, 24)); 
      returnObject.add (returnObject2);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT CONTRACTROLE.CONTRACT_ROLE_ID , CONTRACTROLE.CONT_ID , CONTRACTROLE.CONTR_COMPONENT_ID , CONTRACTROLE.CONTR_ROLE_TP_CD , CONTRACTROLE.DISTRIB_PCT , CONTRACTROLE.IRREVOC_IND , CONTRACTROLE.START_DT , CONTRACTROLE.END_DT , CONTRACTROLE.REGISTERED_NAME , CONTRACTROLE.RECORDED_START_DT , CONTRACTROLE.RECORDED_END_DT , CONTRACTROLE.LAST_UPDATE_DT , CONTRACTROLE.LAST_UPDATE_USER ,CONTRACTROLE.ARRANGEMENT_TP_CD ,CONTRACTROLE.SHARE_DIST_TP_CD , CONTRACTROLE.END_REASON_TP_CD , CONTRACTROLE.LAST_UPDATE_TX_ID ,CONTRACTROLE.ARRANGEMENT_DESC, CONTRACTROLE.XSOURCE_IDENT_TP_CD FROM CONTRACTROLE WHERE CONTRACTROLE.CONTRACT_ROLE_ID = ?", pattern="tableAlias (CONTRACTROLE => com.dwl.tcrm.financial.entityObject.EObjContractRole, H_CONTRACTROLE => com.dwl.tcrm.financial.entityObject.EObjContractRole , CONTRACTROLE => com.ibm.daimler.dsea.entityObject.EObjXContractRoleExt , H_CONTRACTROLE => com.ibm.daimler.dsea.entityObject.EObjXContractRoleExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue2<EObjContractRole,EObjXContractRoleExt>> getEObjCONTRACT_PARTY_ROLE (Object[] parameters)
  {
    return queryIterator (getEObjCONTRACT_PARTY_ROLEStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getEObjCONTRACT_PARTY_ROLEStatementDescriptor = createStatementDescriptor (
    "getEObjCONTRACT_PARTY_ROLE(Object[])",
    "SELECT CONTRACTROLE.CONTRACT_ROLE_ID , CONTRACTROLE.CONT_ID , CONTRACTROLE.CONTR_COMPONENT_ID , CONTRACTROLE.CONTR_ROLE_TP_CD , CONTRACTROLE.DISTRIB_PCT , CONTRACTROLE.IRREVOC_IND , CONTRACTROLE.START_DT , CONTRACTROLE.END_DT , CONTRACTROLE.REGISTERED_NAME , CONTRACTROLE.RECORDED_START_DT , CONTRACTROLE.RECORDED_END_DT , CONTRACTROLE.LAST_UPDATE_DT , CONTRACTROLE.LAST_UPDATE_USER ,CONTRACTROLE.ARRANGEMENT_TP_CD ,CONTRACTROLE.SHARE_DIST_TP_CD , CONTRACTROLE.END_REASON_TP_CD , CONTRACTROLE.LAST_UPDATE_TX_ID ,CONTRACTROLE.ARRANGEMENT_DESC, CONTRACTROLE.XSOURCE_IDENT_TP_CD FROM CONTRACTROLE WHERE CONTRACTROLE.CONTRACT_ROLE_ID = ?",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"contract_role_id", "cont_id", "contr_component_id", "contr_role_tp_cd", "distrib_pct", "irrevoc_ind", "start_dt", "end_dt", "registered_name", "recorded_start_dt", "recorded_end_dt", "last_update_dt", "last_update_user", "arrangement_tp_cd", "share_dist_tp_cd", "end_reason_tp_cd", "last_update_tx_id", "arrangement_desc", "xsource_ident_tp_cd"},
    new GetEObjCONTRACT_PARTY_ROLEParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetEObjCONTRACT_PARTY_ROLERowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.DECIMAL, Types.CHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.BIGINT}, {19, 19, 19, 19, 5, 1, 0, 0, 255, 0, 0, 0, 20, 19, 19, 19, 19, 255, 19}, {0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    17);

  /**
   * @generated
   */
  public static class GetEObjCONTRACT_PARTY_ROLEParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetEObjCONTRACT_PARTY_ROLERowHandler extends BaseRowHandler<ResultQueue2<EObjContractRole,EObjXContractRoleExt>>
  {
    /**
     * @generated
     */
    public ResultQueue2<EObjContractRole,EObjXContractRoleExt> handle (java.sql.ResultSet rs, ResultQueue2<EObjContractRole,EObjXContractRoleExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue2<EObjContractRole,EObjXContractRoleExt> ();

      EObjContractRole returnObject1 = new EObjContractRole ();
      returnObject1.setContractRoleIdPK(getLongObject (rs, 1)); 
      returnObject1.setContId(getLongObject (rs, 2)); 
      returnObject1.setContrComponentId(getLongObject (rs, 3)); 
      returnObject1.setContractRoleTpCd(getLongObject (rs, 4)); 
      returnObject1.setDistribPct(getBigDecimal (rs, 5)); 
      returnObject1.setIrrevocInd(getString (rs, 6)); 
      returnObject1.setStartDt(getTimestamp (rs, 7)); 
      returnObject1.setEndDt(getTimestamp (rs, 8)); 
      returnObject1.setRegisteredName(getString (rs, 9)); 
      returnObject1.setRecordedStartDt(getTimestamp (rs, 10)); 
      returnObject1.setRecordedEndDt(getTimestamp (rs, 11)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 12)); 
      returnObject1.setLastUpdateUser(getString (rs, 13)); 
      returnObject1.setArrangementTpCd(getLongObject (rs, 14)); 
      returnObject1.setShareDistTpCd(getLongObject (rs, 15)); 
      returnObject1.setEndReasonTpCd(getLongObject (rs, 16)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 17)); 
      returnObject1.setArrangementDesc(getString (rs, 18)); 
      returnObject.add (returnObject1);

      EObjXContractRoleExt returnObject2 = new EObjXContractRoleExt ();
      returnObject2.setLastUpdateDt(getTimestamp (rs, 12)); 
      returnObject2.setLastUpdateUser(getString (rs, 13)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 17)); 
      returnObject2.setXSourceIdentifier(getLongObject (rs, 19)); 
      returnObject.add (returnObject2);

    
      return returnObject;
    }
  }

}
