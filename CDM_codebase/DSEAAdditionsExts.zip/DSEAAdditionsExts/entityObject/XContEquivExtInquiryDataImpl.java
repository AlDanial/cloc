package com.ibm.daimler.dsea.entityObject;

import com.ibm.pdq.runtime.generator.BaseParameterHandler;
import java.util.Iterator;
import java.sql.PreparedStatement;
import com.ibm.pdq.runtime.statement.StatementDescriptor;
import com.dwl.tcrm.coreParty.entityObject.EObjContEquiv;
import com.ibm.pdq.runtime.generator.BaseData;
import java.sql.SQLException;
import com.ibm.pdq.annotation.Metadata;
import com.ibm.mdm.base.db.ResultQueue2;
import com.ibm.daimler.dsea.entityObject.EObjXContEquivExt;
import com.ibm.pdq.runtime.generator.BaseRowHandler;
import com.ibm.pdq.runtime.statement.SqlStatementType;
import java.sql.Types;


@SuppressWarnings("unchecked")

/**
 * <!-- begin-user-doc -->
 * 
 * <!-- end-user-doc -->
 * 
 * @generated
 */
public class XContEquivExtInquiryDataImpl  extends BaseData implements XContEquivExtInquiryData
{

  /**
   * @generated
   */
  public static final String generatorVersion = "3.200.75";

  /**
   * @generated
   */
  public static final String identifier = "XContEquivExtInquiryData";

  /**
   * @generated
   */
  public static final long generationTime = 0x00000164c354ca5aL;

  /**
   * @generated
   */
  public static final String collection = "NULLID";

  /**
   * @generated
   */
  public static final String packageVersion = null;

  /**
   * @generated
   */
  public static final boolean forceSingleBindIsolation = false;

  /**
   * @generated
   */
  public XContEquivExtInquiryDataImpl()
  {
    super();
  } 

  /**
   * @generated
   */
  public String getGeneratorVersion()
  {
    return generatorVersion;
  }

  /**
   * @Select( sql="SELECT A.H_CONT_EQUIV_ID AS HIST_ID_PK, A.H_ACTION_CODE, A.H_CREATED_BY, A.H_CREATE_DT, A.H_END_DT, A.CONT_EQUIV_ID, A.CONT_ID, A.ADMIN_SYS_TP_CD, A.ADMIN_CLIENT_ID, A.DESCRIPTION, A.LAST_UPDATE_DT, A.LAST_UPDATE_USER, A.LAST_UPDATE_TX_ID, A.XRETAILER_ID, A.XSOURCE_RETAILER_FLAG, A.XMODIFY_SYS_DT FROM H_CONTEQUIV A WHERE A.H_CREATE_DT = (SELECT MAX(A1.H_CREATE_DT) FROM H_CONTEQUIV A1 WHERE A1.CONT_EQUIV_ID = A.CONT_EQUIV_ID AND CONT_EQUIV_ID = ? AND A1.LAST_UPDATE_DT <= ?)", pattern="tableAlias (CONTEQUIV => com.dwl.tcrm.coreParty.entityObject.EObjContEquiv, H_CONTEQUIV => com.dwl.tcrm.coreParty.entityObject.EObjContEquiv , CONTEQUIV => com.ibm.daimler.dsea.entityObject.EObjXContEquivExt , H_CONTEQUIV => com.ibm.daimler.dsea.entityObject.EObjXContEquivExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue2<EObjContEquiv,EObjXContEquivExt>> getPartyAdminSysKeyByIdHistory (Object[] parameters)
  {
    return queryIterator (getPartyAdminSysKeyByIdHistoryStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getPartyAdminSysKeyByIdHistoryStatementDescriptor = createStatementDescriptor (
    "getPartyAdminSysKeyByIdHistory(Object[])",
    "SELECT A.H_CONT_EQUIV_ID AS HIST_ID_PK, A.H_ACTION_CODE, A.H_CREATED_BY, A.H_CREATE_DT, A.H_END_DT, A.CONT_EQUIV_ID, A.CONT_ID, A.ADMIN_SYS_TP_CD, A.ADMIN_CLIENT_ID, A.DESCRIPTION, A.LAST_UPDATE_DT, A.LAST_UPDATE_USER, A.LAST_UPDATE_TX_ID, A.XRETAILER_ID, A.XSOURCE_RETAILER_FLAG, A.XMODIFY_SYS_DT FROM H_CONTEQUIV A WHERE A.H_CREATE_DT = (SELECT MAX(A1.H_CREATE_DT) FROM H_CONTEQUIV A1 WHERE A1.CONT_EQUIV_ID = A.CONT_EQUIV_ID AND CONT_EQUIV_ID = ? AND A1.LAST_UPDATE_DT <= ?)",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"hist_id_pk", "h_action_code", "h_created_by", "h_create_dt", "h_end_dt", "cont_equiv_id", "cont_id", "admin_sys_tp_cd", "admin_client_id", "description", "last_update_dt", "last_update_user", "last_update_tx_id", "xretailer_id", "xsource_retailer_flag", "xmodify_sys_dt"},
    new GetPartyAdminSysKeyByIdHistoryParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP}, {19, 0}, {0, 0}, {1, 1}},
    null,
    new GetPartyAdminSysKeyByIdHistoryRowHandler (),
    new int[][]{ {Types.BIGINT, Types.CHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP}, {19, 1, 20, 0, 0, 19, 19, 19, 20, 255, 0, 20, 19, 19, 5, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    1);

  /**
   * @generated
   */
  public static class GetPartyAdminSysKeyByIdHistoryParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetPartyAdminSysKeyByIdHistoryRowHandler extends BaseRowHandler<ResultQueue2<EObjContEquiv,EObjXContEquivExt>>
  {
    /**
     * @generated
     */
    public ResultQueue2<EObjContEquiv,EObjXContEquivExt> handle (java.sql.ResultSet rs, ResultQueue2<EObjContEquiv,EObjXContEquivExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue2<EObjContEquiv,EObjXContEquivExt> ();

      EObjContEquiv returnObject1 = new EObjContEquiv ();
      returnObject1.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject1.setHistActionCode(getString (rs, 2)); 
      returnObject1.setHistCreatedBy(getString (rs, 3)); 
      returnObject1.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject1.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject1.setContEquivIdPK(getLongObject (rs, 6)); 
      returnObject1.setContId(getLongObject (rs, 7)); 
      returnObject1.setAdminSysTpCd(getLongObject (rs, 8)); 
      returnObject1.setAdminClientId(getString (rs, 9)); 
      returnObject1.setDescription(getString (rs, 10)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 11)); 
      returnObject1.setLastUpdateUser(getString (rs, 12)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 13)); 
      returnObject.add (returnObject1);

      EObjXContEquivExt returnObject2 = new EObjXContEquivExt ();
      returnObject2.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject2.setHistActionCode(getString (rs, 2)); 
      returnObject2.setHistCreatedBy(getString (rs, 3)); 
      returnObject2.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject2.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject2.setLastUpdateDt(getTimestamp (rs, 11)); 
      returnObject2.setLastUpdateUser(getString (rs, 12)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 13)); 
      returnObject2.setXRetailerId(getLongObject (rs, 14)); 
      returnObject2.setXSourceRetailerFlag(getString (rs, 15)); 
      returnObject2.setXLastModifiedSystemDate(getTimestamp (rs, 16)); 
      returnObject.add (returnObject2);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT CONTEQUIV.CONT_EQUIV_ID, CONTEQUIV.CONT_ID , CONTEQUIV.ADMIN_SYS_TP_CD, CONTEQUIV.ADMIN_CLIENT_ID, CONTEQUIV.DESCRIPTION , CONTEQUIV.LAST_UPDATE_DT, CONTEQUIV.LAST_UPDATE_USER , CONTEQUIV.LAST_UPDATE_TX_ID, CONTEQUIV.XRETAILER_ID, CONTEQUIV.XSOURCE_RETAILER_FLAG, CONTEQUIV.XMODIFY_SYS_DT FROM CONTEQUIV WHERE CONTEQUIV.CONT_EQUIV_ID = ?", pattern="tableAlias (CONTEQUIV => com.dwl.tcrm.coreParty.entityObject.EObjContEquiv, H_CONTEQUIV => com.dwl.tcrm.coreParty.entityObject.EObjContEquiv , CONTEQUIV => com.ibm.daimler.dsea.entityObject.EObjXContEquivExt , H_CONTEQUIV => com.ibm.daimler.dsea.entityObject.EObjXContEquivExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue2<EObjContEquiv,EObjXContEquivExt>> getPartyAdminSysKeyById (Object[] parameters)
  {
    return queryIterator (getPartyAdminSysKeyByIdStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getPartyAdminSysKeyByIdStatementDescriptor = createStatementDescriptor (
    "getPartyAdminSysKeyById(Object[])",
    "SELECT CONTEQUIV.CONT_EQUIV_ID, CONTEQUIV.CONT_ID , CONTEQUIV.ADMIN_SYS_TP_CD, CONTEQUIV.ADMIN_CLIENT_ID, CONTEQUIV.DESCRIPTION , CONTEQUIV.LAST_UPDATE_DT, CONTEQUIV.LAST_UPDATE_USER , CONTEQUIV.LAST_UPDATE_TX_ID, CONTEQUIV.XRETAILER_ID, CONTEQUIV.XSOURCE_RETAILER_FLAG, CONTEQUIV.XMODIFY_SYS_DT FROM CONTEQUIV WHERE CONTEQUIV.CONT_EQUIV_ID = ?",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"cont_equiv_id", "cont_id", "admin_sys_tp_cd", "admin_client_id", "description", "last_update_dt", "last_update_user", "last_update_tx_id", "xretailer_id", "xsource_retailer_flag", "xmodify_sys_dt"},
    new GetPartyAdminSysKeyByIdParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetPartyAdminSysKeyByIdRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP}, {19, 19, 19, 20, 255, 0, 20, 19, 19, 5, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    2);

  /**
   * @generated
   */
  public static class GetPartyAdminSysKeyByIdParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetPartyAdminSysKeyByIdRowHandler extends BaseRowHandler<ResultQueue2<EObjContEquiv,EObjXContEquivExt>>
  {
    /**
     * @generated
     */
    public ResultQueue2<EObjContEquiv,EObjXContEquivExt> handle (java.sql.ResultSet rs, ResultQueue2<EObjContEquiv,EObjXContEquivExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue2<EObjContEquiv,EObjXContEquivExt> ();

      EObjContEquiv returnObject1 = new EObjContEquiv ();
      returnObject1.setContEquivIdPK(getLongObject (rs, 1)); 
      returnObject1.setContId(getLongObject (rs, 2)); 
      returnObject1.setAdminSysTpCd(getLongObject (rs, 3)); 
      returnObject1.setAdminClientId(getString (rs, 4)); 
      returnObject1.setDescription(getString (rs, 5)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 6)); 
      returnObject1.setLastUpdateUser(getString (rs, 7)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 8)); 
      returnObject.add (returnObject1);

      EObjXContEquivExt returnObject2 = new EObjXContEquivExt ();
      returnObject2.setLastUpdateDt(getTimestamp (rs, 6)); 
      returnObject2.setLastUpdateUser(getString (rs, 7)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 8)); 
      returnObject2.setXRetailerId(getLongObject (rs, 9)); 
      returnObject2.setXSourceRetailerFlag(getString (rs, 10)); 
      returnObject2.setXLastModifiedSystemDate(getTimestamp (rs, 11)); 
      returnObject.add (returnObject2);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT A.H_CONT_EQUIV_ID AS HIST_ID_PK, A.H_ACTION_CODE, A.H_CREATED_BY, A.H_CREATE_DT, A.H_END_DT, A.CONT_EQUIV_ID, A.CONT_ID, A.ADMIN_SYS_TP_CD, A.ADMIN_CLIENT_ID, A.DESCRIPTION, A.LAST_UPDATE_DT, A.LAST_UPDATE_USER, A.LAST_UPDATE_TX_ID, A.XRETAILER_ID, A.XSOURCE_RETAILER_FLAG, A.XMODIFY_SYS_DT FROM H_CONTEQUIV A WHERE A.ADMIN_SYS_TP_CD = ? AND A.ADMIN_CLIENT_ID = ? AND (? BETWEEN A.H_CREATE_DT AND A.H_END_DT OR (? >= A.H_CREATE_DT AND A.H_END_DT IS NULL ))", pattern="tableAlias (CONTEQUIV => com.dwl.tcrm.coreParty.entityObject.EObjContEquiv, H_CONTEQUIV => com.dwl.tcrm.coreParty.entityObject.EObjContEquiv , CONTEQUIV => com.ibm.daimler.dsea.entityObject.EObjXContEquivExt , H_CONTEQUIV => com.ibm.daimler.dsea.entityObject.EObjXContEquivExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue2<EObjContEquiv,EObjXContEquivExt>> getPartyAdminSysKeyHistory (Object[] parameters)
  {
    return queryIterator (getPartyAdminSysKeyHistoryStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getPartyAdminSysKeyHistoryStatementDescriptor = createStatementDescriptor (
    "getPartyAdminSysKeyHistory(Object[])",
    "SELECT A.H_CONT_EQUIV_ID AS HIST_ID_PK, A.H_ACTION_CODE, A.H_CREATED_BY, A.H_CREATE_DT, A.H_END_DT, A.CONT_EQUIV_ID, A.CONT_ID, A.ADMIN_SYS_TP_CD, A.ADMIN_CLIENT_ID, A.DESCRIPTION, A.LAST_UPDATE_DT, A.LAST_UPDATE_USER, A.LAST_UPDATE_TX_ID, A.XRETAILER_ID, A.XSOURCE_RETAILER_FLAG, A.XMODIFY_SYS_DT FROM H_CONTEQUIV A WHERE A.ADMIN_SYS_TP_CD = ? AND A.ADMIN_CLIENT_ID = ? AND (? BETWEEN A.H_CREATE_DT AND A.H_END_DT OR (? >= A.H_CREATE_DT AND A.H_END_DT IS NULL ))",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"hist_id_pk", "h_action_code", "h_created_by", "h_create_dt", "h_end_dt", "cont_equiv_id", "cont_id", "admin_sys_tp_cd", "admin_client_id", "description", "last_update_dt", "last_update_user", "last_update_tx_id", "xretailer_id", "xsource_retailer_flag", "xmodify_sys_dt"},
    new GetPartyAdminSysKeyHistoryParameterHandler (),
    new int[][]{{Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP}, {19, 20, 0, 0}, {0, 0, 0, 0}, {1, 1, 1, 1}},
    null,
    new GetPartyAdminSysKeyHistoryRowHandler (),
    new int[][]{ {Types.BIGINT, Types.CHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP}, {19, 1, 20, 0, 0, 19, 19, 19, 20, 255, 0, 20, 19, 19, 5, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    3);

  /**
   * @generated
   */
  public static class GetPartyAdminSysKeyHistoryParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.VARCHAR, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
      setObject (stmt, 4, Types.TIMESTAMP, parameters[3], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetPartyAdminSysKeyHistoryRowHandler extends BaseRowHandler<ResultQueue2<EObjContEquiv,EObjXContEquivExt>>
  {
    /**
     * @generated
     */
    public ResultQueue2<EObjContEquiv,EObjXContEquivExt> handle (java.sql.ResultSet rs, ResultQueue2<EObjContEquiv,EObjXContEquivExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue2<EObjContEquiv,EObjXContEquivExt> ();

      EObjContEquiv returnObject1 = new EObjContEquiv ();
      returnObject1.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject1.setHistActionCode(getString (rs, 2)); 
      returnObject1.setHistCreatedBy(getString (rs, 3)); 
      returnObject1.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject1.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject1.setContEquivIdPK(getLongObject (rs, 6)); 
      returnObject1.setContId(getLongObject (rs, 7)); 
      returnObject1.setAdminSysTpCd(getLongObject (rs, 8)); 
      returnObject1.setAdminClientId(getString (rs, 9)); 
      returnObject1.setDescription(getString (rs, 10)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 11)); 
      returnObject1.setLastUpdateUser(getString (rs, 12)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 13)); 
      returnObject.add (returnObject1);

      EObjXContEquivExt returnObject2 = new EObjXContEquivExt ();
      returnObject2.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject2.setHistActionCode(getString (rs, 2)); 
      returnObject2.setHistCreatedBy(getString (rs, 3)); 
      returnObject2.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject2.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject2.setLastUpdateDt(getTimestamp (rs, 11)); 
      returnObject2.setLastUpdateUser(getString (rs, 12)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 13)); 
      returnObject2.setXRetailerId(getLongObject (rs, 14)); 
      returnObject2.setXSourceRetailerFlag(getString (rs, 15)); 
      returnObject2.setXLastModifiedSystemDate(getTimestamp (rs, 16)); 
      returnObject.add (returnObject2);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT CONTEQUIV.CONT_EQUIV_ID ,CONTEQUIV.CONT_ID, CONTEQUIV.ADMIN_SYS_TP_CD, CONTEQUIV.ADMIN_CLIENT_ID, CONTEQUIV.DESCRIPTION, CONTEQUIV.LAST_UPDATE_DT, CONTEQUIV.LAST_UPDATE_USER, CONTEQUIV.LAST_UPDATE_USER, CONTEQUIV.LAST_UPDATE_TX_ID, CONTEQUIV.XRETAILER_ID, CONTEQUIV.XSOURCE_RETAILER_FLAG, CONTEQUIV.XMODIFY_SYS_DT FROM CONTEQUIV WHERE CONTEQUIV.ADMIN_SYS_TP_CD = ? AND CONTEQUIV.ADMIN_CLIENT_ID = ?", pattern="tableAlias (CONTEQUIV => com.dwl.tcrm.coreParty.entityObject.EObjContEquiv, H_CONTEQUIV => com.dwl.tcrm.coreParty.entityObject.EObjContEquiv , CONTEQUIV => com.ibm.daimler.dsea.entityObject.EObjXContEquivExt , H_CONTEQUIV => com.ibm.daimler.dsea.entityObject.EObjXContEquivExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue2<EObjContEquiv,EObjXContEquivExt>> getPartyAdminSysKey (Object[] parameters)
  {
    return queryIterator (getPartyAdminSysKeyStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getPartyAdminSysKeyStatementDescriptor = createStatementDescriptor (
    "getPartyAdminSysKey(Object[])",
    "SELECT CONTEQUIV.CONT_EQUIV_ID ,CONTEQUIV.CONT_ID, CONTEQUIV.ADMIN_SYS_TP_CD, CONTEQUIV.ADMIN_CLIENT_ID, CONTEQUIV.DESCRIPTION, CONTEQUIV.LAST_UPDATE_DT, CONTEQUIV.LAST_UPDATE_USER, CONTEQUIV.LAST_UPDATE_USER, CONTEQUIV.LAST_UPDATE_TX_ID, CONTEQUIV.XRETAILER_ID, CONTEQUIV.XSOURCE_RETAILER_FLAG, CONTEQUIV.XMODIFY_SYS_DT FROM CONTEQUIV WHERE CONTEQUIV.ADMIN_SYS_TP_CD = ? AND CONTEQUIV.ADMIN_CLIENT_ID = ?",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"cont_equiv_id", "cont_id", "admin_sys_tp_cd", "admin_client_id", "description", "last_update_dt", "last_update_user", "last_update_user", "last_update_tx_id", "xretailer_id", "xsource_retailer_flag", "xmodify_sys_dt"},
    new GetPartyAdminSysKeyParameterHandler (),
    new int[][]{{Types.BIGINT, Types.VARCHAR}, {19, 20}, {0, 0}, {1, 1}},
    null,
    new GetPartyAdminSysKeyRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP}, {19, 19, 19, 20, 255, 0, 20, 20, 19, 19, 5, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    4);

  /**
   * @generated
   */
  public static class GetPartyAdminSysKeyParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.VARCHAR, parameters[1], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetPartyAdminSysKeyRowHandler extends BaseRowHandler<ResultQueue2<EObjContEquiv,EObjXContEquivExt>>
  {
    /**
     * @generated
     */
    public ResultQueue2<EObjContEquiv,EObjXContEquivExt> handle (java.sql.ResultSet rs, ResultQueue2<EObjContEquiv,EObjXContEquivExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue2<EObjContEquiv,EObjXContEquivExt> ();

      EObjContEquiv returnObject1 = new EObjContEquiv ();
      returnObject1.setContEquivIdPK(getLongObject (rs, 1)); 
      returnObject1.setContId(getLongObject (rs, 2)); 
      returnObject1.setAdminSysTpCd(getLongObject (rs, 3)); 
      returnObject1.setAdminClientId(getString (rs, 4)); 
      returnObject1.setDescription(getString (rs, 5)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 6)); 
      returnObject1.setLastUpdateUser(getString (rs, 7)); 
      returnObject1.setLastUpdateUser(getString (rs, 8)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 9)); 
      returnObject.add (returnObject1);

      EObjXContEquivExt returnObject2 = new EObjXContEquivExt ();
      returnObject2.setLastUpdateDt(getTimestamp (rs, 6)); 
      returnObject2.setLastUpdateUser(getString (rs, 7)); 
      returnObject2.setLastUpdateUser(getString (rs, 8)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 9)); 
      returnObject2.setXRetailerId(getLongObject (rs, 10)); 
      returnObject2.setXSourceRetailerFlag(getString (rs, 11)); 
      returnObject2.setXLastModifiedSystemDate(getTimestamp (rs, 12)); 
      returnObject.add (returnObject2);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT A.H_CONT_EQUIV_ID AS HIST_ID_PK, A.H_ACTION_CODE, A.H_CREATED_BY, A.H_CREATE_DT, A.H_END_DT, A.CONT_EQUIV_ID, A.CONT_ID, A.ADMIN_SYS_TP_CD, A.ADMIN_CLIENT_ID, A.DESCRIPTION, A.LAST_UPDATE_DT, A.LAST_UPDATE_USER, A.LAST_UPDATE_TX_ID, A.XRETAILER_ID, A.XSOURCE_RETAILER_FLAG, A.XMODIFY_SYS_DT FROM H_CONTEQUIV A WHERE A.CONT_ID = ? AND A.ADMIN_SYS_TP_CD = ? AND (? BETWEEN A.H_CREATE_DT AND A.H_END_DT OR (? >= A.H_CREATE_DT AND A.H_END_DT IS NULL ))", pattern="tableAlias (CONTEQUIV => com.dwl.tcrm.coreParty.entityObject.EObjContEquiv, H_CONTEQUIV => com.dwl.tcrm.coreParty.entityObject.EObjContEquiv , CONTEQUIV => com.ibm.daimler.dsea.entityObject.EObjXContEquivExt , H_CONTEQUIV => com.ibm.daimler.dsea.entityObject.EObjXContEquivExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue2<EObjContEquiv,EObjXContEquivExt>> getPartyAdminSysKeyHistoryByPartId (Object[] parameters)
  {
    return queryIterator (getPartyAdminSysKeyHistoryByPartIdStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getPartyAdminSysKeyHistoryByPartIdStatementDescriptor = createStatementDescriptor (
    "getPartyAdminSysKeyHistoryByPartId(Object[])",
    "SELECT A.H_CONT_EQUIV_ID AS HIST_ID_PK, A.H_ACTION_CODE, A.H_CREATED_BY, A.H_CREATE_DT, A.H_END_DT, A.CONT_EQUIV_ID, A.CONT_ID, A.ADMIN_SYS_TP_CD, A.ADMIN_CLIENT_ID, A.DESCRIPTION, A.LAST_UPDATE_DT, A.LAST_UPDATE_USER, A.LAST_UPDATE_TX_ID, A.XRETAILER_ID, A.XSOURCE_RETAILER_FLAG, A.XMODIFY_SYS_DT FROM H_CONTEQUIV A WHERE A.CONT_ID = ? AND A.ADMIN_SYS_TP_CD = ? AND (? BETWEEN A.H_CREATE_DT AND A.H_END_DT OR (? >= A.H_CREATE_DT AND A.H_END_DT IS NULL ))",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"hist_id_pk", "h_action_code", "h_created_by", "h_create_dt", "h_end_dt", "cont_equiv_id", "cont_id", "admin_sys_tp_cd", "admin_client_id", "description", "last_update_dt", "last_update_user", "last_update_tx_id", "xretailer_id", "xsource_retailer_flag", "xmodify_sys_dt"},
    new GetPartyAdminSysKeyHistoryByPartIdParameterHandler (),
    new int[][]{{Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP}, {19, 19, 0, 0}, {0, 0, 0, 0}, {1, 1, 1, 1}},
    null,
    new GetPartyAdminSysKeyHistoryByPartIdRowHandler (),
    new int[][]{ {Types.BIGINT, Types.CHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP}, {19, 1, 20, 0, 0, 19, 19, 19, 20, 255, 0, 20, 19, 19, 5, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    5);

  /**
   * @generated
   */
  public static class GetPartyAdminSysKeyHistoryByPartIdParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.BIGINT, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
      setObject (stmt, 4, Types.TIMESTAMP, parameters[3], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetPartyAdminSysKeyHistoryByPartIdRowHandler extends BaseRowHandler<ResultQueue2<EObjContEquiv,EObjXContEquivExt>>
  {
    /**
     * @generated
     */
    public ResultQueue2<EObjContEquiv,EObjXContEquivExt> handle (java.sql.ResultSet rs, ResultQueue2<EObjContEquiv,EObjXContEquivExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue2<EObjContEquiv,EObjXContEquivExt> ();

      EObjContEquiv returnObject1 = new EObjContEquiv ();
      returnObject1.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject1.setHistActionCode(getString (rs, 2)); 
      returnObject1.setHistCreatedBy(getString (rs, 3)); 
      returnObject1.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject1.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject1.setContEquivIdPK(getLongObject (rs, 6)); 
      returnObject1.setContId(getLongObject (rs, 7)); 
      returnObject1.setAdminSysTpCd(getLongObject (rs, 8)); 
      returnObject1.setAdminClientId(getString (rs, 9)); 
      returnObject1.setDescription(getString (rs, 10)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 11)); 
      returnObject1.setLastUpdateUser(getString (rs, 12)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 13)); 
      returnObject.add (returnObject1);

      EObjXContEquivExt returnObject2 = new EObjXContEquivExt ();
      returnObject2.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject2.setHistActionCode(getString (rs, 2)); 
      returnObject2.setHistCreatedBy(getString (rs, 3)); 
      returnObject2.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject2.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject2.setLastUpdateDt(getTimestamp (rs, 11)); 
      returnObject2.setLastUpdateUser(getString (rs, 12)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 13)); 
      returnObject2.setXRetailerId(getLongObject (rs, 14)); 
      returnObject2.setXSourceRetailerFlag(getString (rs, 15)); 
      returnObject2.setXLastModifiedSystemDate(getTimestamp (rs, 16)); 
      returnObject.add (returnObject2);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT CONTEQUIV.CONT_EQUIV_ID, CONTEQUIV.CONT_ID , CONTEQUIV.ADMIN_SYS_TP_CD , CONTEQUIV.ADMIN_CLIENT_ID , CONTEQUIV.DESCRIPTION, CONTEQUIV.LAST_UPDATE_DT, CONTEQUIV.LAST_UPDATE_USER , CONTEQUIV.LAST_UPDATE_TX_ID, CONTEQUIV.XRETAILER_ID, CONTEQUIV.XSOURCE_RETAILER_FLAG, CONTEQUIV.XMODIFY_SYS_DT FROM CONTEQUIV WHERE CONTEQUIV.ADMIN_SYS_TP_CD = ? AND CONTEQUIV.CONT_ID = ?", pattern="tableAlias (CONTEQUIV => com.dwl.tcrm.coreParty.entityObject.EObjContEquiv, H_CONTEQUIV => com.dwl.tcrm.coreParty.entityObject.EObjContEquiv , CONTEQUIV => com.ibm.daimler.dsea.entityObject.EObjXContEquivExt , H_CONTEQUIV => com.ibm.daimler.dsea.entityObject.EObjXContEquivExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue2<EObjContEquiv,EObjXContEquivExt>> getPartyAdminSysKeyByPartId (Object[] parameters)
  {
    return queryIterator (getPartyAdminSysKeyByPartIdStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getPartyAdminSysKeyByPartIdStatementDescriptor = createStatementDescriptor (
    "getPartyAdminSysKeyByPartId(Object[])",
    "SELECT CONTEQUIV.CONT_EQUIV_ID, CONTEQUIV.CONT_ID , CONTEQUIV.ADMIN_SYS_TP_CD , CONTEQUIV.ADMIN_CLIENT_ID , CONTEQUIV.DESCRIPTION, CONTEQUIV.LAST_UPDATE_DT, CONTEQUIV.LAST_UPDATE_USER , CONTEQUIV.LAST_UPDATE_TX_ID, CONTEQUIV.XRETAILER_ID, CONTEQUIV.XSOURCE_RETAILER_FLAG, CONTEQUIV.XMODIFY_SYS_DT FROM CONTEQUIV WHERE CONTEQUIV.ADMIN_SYS_TP_CD = ? AND CONTEQUIV.CONT_ID = ?",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"cont_equiv_id", "cont_id", "admin_sys_tp_cd", "admin_client_id", "description", "last_update_dt", "last_update_user", "last_update_tx_id", "xretailer_id", "xsource_retailer_flag", "xmodify_sys_dt"},
    new GetPartyAdminSysKeyByPartIdParameterHandler (),
    new int[][]{{Types.BIGINT, Types.BIGINT}, {19, 19}, {0, 0}, {1, 1}},
    null,
    new GetPartyAdminSysKeyByPartIdRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP}, {19, 19, 19, 20, 255, 0, 20, 19, 19, 5, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    6);

  /**
   * @generated
   */
  public static class GetPartyAdminSysKeyByPartIdParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.BIGINT, parameters[1], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetPartyAdminSysKeyByPartIdRowHandler extends BaseRowHandler<ResultQueue2<EObjContEquiv,EObjXContEquivExt>>
  {
    /**
     * @generated
     */
    public ResultQueue2<EObjContEquiv,EObjXContEquivExt> handle (java.sql.ResultSet rs, ResultQueue2<EObjContEquiv,EObjXContEquivExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue2<EObjContEquiv,EObjXContEquivExt> ();

      EObjContEquiv returnObject1 = new EObjContEquiv ();
      returnObject1.setContEquivIdPK(getLongObject (rs, 1)); 
      returnObject1.setContId(getLongObject (rs, 2)); 
      returnObject1.setAdminSysTpCd(getLongObject (rs, 3)); 
      returnObject1.setAdminClientId(getString (rs, 4)); 
      returnObject1.setDescription(getString (rs, 5)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 6)); 
      returnObject1.setLastUpdateUser(getString (rs, 7)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 8)); 
      returnObject.add (returnObject1);

      EObjXContEquivExt returnObject2 = new EObjXContEquivExt ();
      returnObject2.setLastUpdateDt(getTimestamp (rs, 6)); 
      returnObject2.setLastUpdateUser(getString (rs, 7)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 8)); 
      returnObject2.setXRetailerId(getLongObject (rs, 9)); 
      returnObject2.setXSourceRetailerFlag(getString (rs, 10)); 
      returnObject2.setXLastModifiedSystemDate(getTimestamp (rs, 11)); 
      returnObject.add (returnObject2);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT A.H_CONT_EQUIV_ID AS HIST_ID_PK, A.H_ACTION_CODE, A.H_CREATED_BY, A.H_CREATE_DT, A.H_END_DT, A.CONT_EQUIV_ID, A.CONT_ID, A.ADMIN_SYS_TP_CD, A.ADMIN_CLIENT_ID, A.DESCRIPTION, A.LAST_UPDATE_DT, A.LAST_UPDATE_USER, A.LAST_UPDATE_TX_ID, A.XRETAILER_ID, A.XSOURCE_RETAILER_FLAG, A.XMODIFY_SYS_DT FROM H_CONTEQUIV A WHERE A.CONT_ID = ? AND (? BETWEEN A.H_CREATE_DT AND A.H_END_DT OR (? >= A.H_CREATE_DT AND A.H_END_DT IS NULL ))", pattern="tableAlias (CONTEQUIV => com.dwl.tcrm.coreParty.entityObject.EObjContEquiv, H_CONTEQUIV => com.dwl.tcrm.coreParty.entityObject.EObjContEquiv , CONTEQUIV => com.ibm.daimler.dsea.entityObject.EObjXContEquivExt , H_CONTEQUIV => com.ibm.daimler.dsea.entityObject.EObjXContEquivExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue2<EObjContEquiv,EObjXContEquivExt>> getPartyAdminSysKeysHistory (Object[] parameters)
  {
    return queryIterator (getPartyAdminSysKeysHistoryStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getPartyAdminSysKeysHistoryStatementDescriptor = createStatementDescriptor (
    "getPartyAdminSysKeysHistory(Object[])",
    "SELECT A.H_CONT_EQUIV_ID AS HIST_ID_PK, A.H_ACTION_CODE, A.H_CREATED_BY, A.H_CREATE_DT, A.H_END_DT, A.CONT_EQUIV_ID, A.CONT_ID, A.ADMIN_SYS_TP_CD, A.ADMIN_CLIENT_ID, A.DESCRIPTION, A.LAST_UPDATE_DT, A.LAST_UPDATE_USER, A.LAST_UPDATE_TX_ID, A.XRETAILER_ID, A.XSOURCE_RETAILER_FLAG, A.XMODIFY_SYS_DT FROM H_CONTEQUIV A WHERE A.CONT_ID = ? AND (? BETWEEN A.H_CREATE_DT AND A.H_END_DT OR (? >= A.H_CREATE_DT AND A.H_END_DT IS NULL ))",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"hist_id_pk", "h_action_code", "h_created_by", "h_create_dt", "h_end_dt", "cont_equiv_id", "cont_id", "admin_sys_tp_cd", "admin_client_id", "description", "last_update_dt", "last_update_user", "last_update_tx_id", "xretailer_id", "xsource_retailer_flag", "xmodify_sys_dt"},
    new GetPartyAdminSysKeysHistoryParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP}, {19, 0, 0}, {0, 0, 0}, {1, 1, 1}},
    null,
    new GetPartyAdminSysKeysHistoryRowHandler (),
    new int[][]{ {Types.BIGINT, Types.CHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP}, {19, 1, 20, 0, 0, 19, 19, 19, 20, 255, 0, 20, 19, 19, 5, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    7);

  /**
   * @generated
   */
  public static class GetPartyAdminSysKeysHistoryParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetPartyAdminSysKeysHistoryRowHandler extends BaseRowHandler<ResultQueue2<EObjContEquiv,EObjXContEquivExt>>
  {
    /**
     * @generated
     */
    public ResultQueue2<EObjContEquiv,EObjXContEquivExt> handle (java.sql.ResultSet rs, ResultQueue2<EObjContEquiv,EObjXContEquivExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue2<EObjContEquiv,EObjXContEquivExt> ();

      EObjContEquiv returnObject1 = new EObjContEquiv ();
      returnObject1.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject1.setHistActionCode(getString (rs, 2)); 
      returnObject1.setHistCreatedBy(getString (rs, 3)); 
      returnObject1.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject1.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject1.setContEquivIdPK(getLongObject (rs, 6)); 
      returnObject1.setContId(getLongObject (rs, 7)); 
      returnObject1.setAdminSysTpCd(getLongObject (rs, 8)); 
      returnObject1.setAdminClientId(getString (rs, 9)); 
      returnObject1.setDescription(getString (rs, 10)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 11)); 
      returnObject1.setLastUpdateUser(getString (rs, 12)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 13)); 
      returnObject.add (returnObject1);

      EObjXContEquivExt returnObject2 = new EObjXContEquivExt ();
      returnObject2.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject2.setHistActionCode(getString (rs, 2)); 
      returnObject2.setHistCreatedBy(getString (rs, 3)); 
      returnObject2.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject2.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject2.setLastUpdateDt(getTimestamp (rs, 11)); 
      returnObject2.setLastUpdateUser(getString (rs, 12)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 13)); 
      returnObject2.setXRetailerId(getLongObject (rs, 14)); 
      returnObject2.setXSourceRetailerFlag(getString (rs, 15)); 
      returnObject2.setXLastModifiedSystemDate(getTimestamp (rs, 16)); 
      returnObject.add (returnObject2);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT CONTEQUIV.CONT_EQUIV_ID, CONTEQUIV.CONT_ID , CONTEQUIV.ADMIN_SYS_TP_CD , CONTEQUIV.ADMIN_CLIENT_ID, CONTEQUIV.DESCRIPTION, CONTEQUIV.LAST_UPDATE_DT, CONTEQUIV.LAST_UPDATE_USER , CONTEQUIV.LAST_UPDATE_TX_ID, CONTEQUIV.XRETAILER_ID, CONTEQUIV.XSOURCE_RETAILER_FLAG, CONTEQUIV.XMODIFY_SYS_DT FROM CONTEQUIV WHERE CONTEQUIV.CONT_ID = ?", pattern="tableAlias (CONTEQUIV => com.dwl.tcrm.coreParty.entityObject.EObjContEquiv, H_CONTEQUIV => com.dwl.tcrm.coreParty.entityObject.EObjContEquiv , CONTEQUIV => com.ibm.daimler.dsea.entityObject.EObjXContEquivExt , H_CONTEQUIV => com.ibm.daimler.dsea.entityObject.EObjXContEquivExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue2<EObjContEquiv,EObjXContEquivExt>> getPartyAdminSysKeys (Object[] parameters)
  {
    return queryIterator (getPartyAdminSysKeysStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getPartyAdminSysKeysStatementDescriptor = createStatementDescriptor (
    "getPartyAdminSysKeys(Object[])",
    "SELECT CONTEQUIV.CONT_EQUIV_ID, CONTEQUIV.CONT_ID , CONTEQUIV.ADMIN_SYS_TP_CD , CONTEQUIV.ADMIN_CLIENT_ID, CONTEQUIV.DESCRIPTION, CONTEQUIV.LAST_UPDATE_DT, CONTEQUIV.LAST_UPDATE_USER , CONTEQUIV.LAST_UPDATE_TX_ID, CONTEQUIV.XRETAILER_ID, CONTEQUIV.XSOURCE_RETAILER_FLAG, CONTEQUIV.XMODIFY_SYS_DT FROM CONTEQUIV WHERE CONTEQUIV.CONT_ID = ?",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"cont_equiv_id", "cont_id", "admin_sys_tp_cd", "admin_client_id", "description", "last_update_dt", "last_update_user", "last_update_tx_id", "xretailer_id", "xsource_retailer_flag", "xmodify_sys_dt"},
    new GetPartyAdminSysKeysParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetPartyAdminSysKeysRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP}, {19, 19, 19, 20, 255, 0, 20, 19, 19, 5, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    8);

  /**
   * @generated
   */
  public static class GetPartyAdminSysKeysParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetPartyAdminSysKeysRowHandler extends BaseRowHandler<ResultQueue2<EObjContEquiv,EObjXContEquivExt>>
  {
    /**
     * @generated
     */
    public ResultQueue2<EObjContEquiv,EObjXContEquivExt> handle (java.sql.ResultSet rs, ResultQueue2<EObjContEquiv,EObjXContEquivExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue2<EObjContEquiv,EObjXContEquivExt> ();

      EObjContEquiv returnObject1 = new EObjContEquiv ();
      returnObject1.setContEquivIdPK(getLongObject (rs, 1)); 
      returnObject1.setContId(getLongObject (rs, 2)); 
      returnObject1.setAdminSysTpCd(getLongObject (rs, 3)); 
      returnObject1.setAdminClientId(getString (rs, 4)); 
      returnObject1.setDescription(getString (rs, 5)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 6)); 
      returnObject1.setLastUpdateUser(getString (rs, 7)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 8)); 
      returnObject.add (returnObject1);

      EObjXContEquivExt returnObject2 = new EObjXContEquivExt ();
      returnObject2.setLastUpdateDt(getTimestamp (rs, 6)); 
      returnObject2.setLastUpdateUser(getString (rs, 7)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 8)); 
      returnObject2.setXRetailerId(getLongObject (rs, 9)); 
      returnObject2.setXSourceRetailerFlag(getString (rs, 10)); 
      returnObject2.setXLastModifiedSystemDate(getTimestamp (rs, 11)); 
      returnObject.add (returnObject2);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT A.CONT_EQUIV_ID, A.LAST_UPDATE_DT, A.XRETAILER_ID, A.XSOURCE_RETAILER_FLAG, A.XMODIFY_SYS_DT FROM H_CONTEQUIV A WHERE A.CONT_ID = ? AND (A.H_CREATE_DT BETWEEN ? AND ?)", pattern="tableAlias (CONTEQUIV => com.dwl.tcrm.coreParty.entityObject.EObjContEquiv, H_CONTEQUIV => com.dwl.tcrm.coreParty.entityObject.EObjContEquiv , CONTEQUIV => com.ibm.daimler.dsea.entityObject.EObjXContEquivExt , H_CONTEQUIV => com.ibm.daimler.dsea.entityObject.EObjXContEquivExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue2<EObjContEquiv,EObjXContEquivExt>> getPartyAdminSysKeysLightImage (Object[] parameters)
  {
    return queryIterator (getPartyAdminSysKeysLightImageStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getPartyAdminSysKeysLightImageStatementDescriptor = createStatementDescriptor (
    "getPartyAdminSysKeysLightImage(Object[])",
    "SELECT A.CONT_EQUIV_ID, A.LAST_UPDATE_DT, A.XRETAILER_ID, A.XSOURCE_RETAILER_FLAG, A.XMODIFY_SYS_DT FROM H_CONTEQUIV A WHERE A.CONT_ID = ? AND (A.H_CREATE_DT BETWEEN ? AND ?)",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"cont_equiv_id", "last_update_dt", "xretailer_id", "xsource_retailer_flag", "xmodify_sys_dt"},
    new GetPartyAdminSysKeysLightImageParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP}, {19, 0, 0}, {0, 0, 0}, {1, 1, 1}},
    null,
    new GetPartyAdminSysKeysLightImageRowHandler (),
    new int[][]{ {Types.BIGINT, Types.TIMESTAMP, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP}, {19, 0, 19, 5, 0}, {0, 0, 0, 0, 0}, {0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    9);

  /**
   * @generated
   */
  public static class GetPartyAdminSysKeysLightImageParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetPartyAdminSysKeysLightImageRowHandler extends BaseRowHandler<ResultQueue2<EObjContEquiv,EObjXContEquivExt>>
  {
    /**
     * @generated
     */
    public ResultQueue2<EObjContEquiv,EObjXContEquivExt> handle (java.sql.ResultSet rs, ResultQueue2<EObjContEquiv,EObjXContEquivExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue2<EObjContEquiv,EObjXContEquivExt> ();

      EObjContEquiv returnObject1 = new EObjContEquiv ();
      returnObject1.setContEquivIdPK(getLongObject (rs, 1)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 2)); 
      returnObject.add (returnObject1);

      EObjXContEquivExt returnObject2 = new EObjXContEquivExt ();
      returnObject2.setLastUpdateDt(getTimestamp (rs, 2)); 
      returnObject2.setXRetailerId(getLongObject (rs, 3)); 
      returnObject2.setXSourceRetailerFlag(getString (rs, 4)); 
      returnObject2.setXLastModifiedSystemDate(getTimestamp (rs, 5)); 
      returnObject.add (returnObject2);

    
      return returnObject;
    }
  }

}
