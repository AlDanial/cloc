/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[c117218ed027326137a5c2cca845bdf7]
 */


package com.ibm.daimler.dsea.entityObject;

import java.util.Iterator;
import com.ibm.mdm.base.db.EntityMapping;
import com.ibm.pdq.annotation.Select;
import com.ibm.pdq.annotation.Update;

import com.ibm.daimler.dsea.entityObject.EObjXVRCollapse;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * @generated
 */
public interface EObjXVRCollapseData {


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjXVRCollapseSql = "select XVRCollapsepk_Id, SUSPECT_IDS, GOLDEN_CONT_ID, ACTION, FLAG, Create_Date, MARKET_NAME, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from XVRCOLLAPSE where XVRCollapsepk_Id = ? ";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String createEObjXVRCollapseSql = "insert into XVRCOLLAPSE (XVRCollapsepk_Id, SUSPECT_IDS, GOLDEN_CONT_ID, ACTION, FLAG, Create_Date, MARKET_NAME, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( :xVRCollapsepkId, :suspectIds, :goldenContId, :action, :flag, :createDate, :marketName, :lastUpdateDt, :lastUpdateUser, :lastUpdateTxId)";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String updateEObjXVRCollapseSql = "update XVRCOLLAPSE set SUSPECT_IDS = :suspectIds, GOLDEN_CONT_ID = :goldenContId, ACTION = :action, FLAG = :flag, Create_Date = :createDate, MARKET_NAME = :marketName, LAST_UPDATE_DT = :lastUpdateDt, LAST_UPDATE_USER = :lastUpdateUser, LAST_UPDATE_TX_ID = :lastUpdateTxId where XVRCollapsepk_Id = :xVRCollapsepkId and LAST_UPDATE_DT = :oldLastUpdateDt";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String deleteEObjXVRCollapseSql = "delete from XVRCOLLAPSE where XVRCollapsepk_Id = ?";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXVRCollapseKeyField = "EObjXVRCollapse.xVRCollapsepkId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXVRCollapseGetFields =
    "EObjXVRCollapse.xVRCollapsepkId," +
    "EObjXVRCollapse.suspectIds," +
    "EObjXVRCollapse.goldenContId," +
    "EObjXVRCollapse.action," +
    "EObjXVRCollapse.flag," +
    "EObjXVRCollapse.createDate," +
    "EObjXVRCollapse.marketName," +
    "EObjXVRCollapse.lastUpdateDt," +
    "EObjXVRCollapse.lastUpdateUser," +
    "EObjXVRCollapse.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXVRCollapseAllFields =
    "com.ibm.daimler.dsea.entityObject.EObjXVRCollapse.xVRCollapsepkId," +
    "com.ibm.daimler.dsea.entityObject.EObjXVRCollapse.suspectIds," +
    "com.ibm.daimler.dsea.entityObject.EObjXVRCollapse.goldenContId," +
    "com.ibm.daimler.dsea.entityObject.EObjXVRCollapse.action," +
    "com.ibm.daimler.dsea.entityObject.EObjXVRCollapse.flag," +
    "com.ibm.daimler.dsea.entityObject.EObjXVRCollapse.createDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXVRCollapse.marketName," +
    "com.ibm.daimler.dsea.entityObject.EObjXVRCollapse.lastUpdateDt," +
    "com.ibm.daimler.dsea.entityObject.EObjXVRCollapse.lastUpdateUser," +
    "com.ibm.daimler.dsea.entityObject.EObjXVRCollapse.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXVRCollapseUpdateFields =
    "com.ibm.daimler.dsea.entityObject.EObjXVRCollapse.suspectIds," +
    "com.ibm.daimler.dsea.entityObject.EObjXVRCollapse.goldenContId," +
    "com.ibm.daimler.dsea.entityObject.EObjXVRCollapse.action," +
    "com.ibm.daimler.dsea.entityObject.EObjXVRCollapse.flag," +
    "com.ibm.daimler.dsea.entityObject.EObjXVRCollapse.createDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXVRCollapse.marketName," +
    "com.ibm.daimler.dsea.entityObject.EObjXVRCollapse.lastUpdateDt," +
    "com.ibm.daimler.dsea.entityObject.EObjXVRCollapse.lastUpdateUser," +
    "com.ibm.daimler.dsea.entityObject.EObjXVRCollapse.lastUpdateTxId," +
    "com.ibm.daimler.dsea.entityObject.EObjXVRCollapse.xVRCollapsepkId," +
    "com.ibm.daimler.dsea.entityObject.EObjXVRCollapse.oldLastUpdateDt";   

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Select XVRCollapse by parameters.
   * @generated
   */
  @Select(sql=getEObjXVRCollapseSql)
  @EntityMapping(parameters=EObjXVRCollapseKeyField, results=EObjXVRCollapseGetFields)
  Iterator<EObjXVRCollapse> getEObjXVRCollapse(Long xVRCollapsepkId);  
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Create XVRCollapse by EObjXVRCollapse Object.
   * @generated
   */
  @Update(sql=createEObjXVRCollapseSql)
  @EntityMapping(parameters=EObjXVRCollapseAllFields)
    int createEObjXVRCollapse(EObjXVRCollapse e); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Update one XVRCollapse by EObjXVRCollapse object.
   * @generated
   */
  @Update(sql=updateEObjXVRCollapseSql)
  @EntityMapping(parameters=EObjXVRCollapseUpdateFields)
    int updateEObjXVRCollapse(EObjXVRCollapse e); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Delete XVRCollapse by parameters.
   * @generated
   */
  @Update(sql=deleteEObjXVRCollapseSql)
  @EntityMapping(parameters=EObjXVRCollapseKeyField)
  int deleteEObjXVRCollapse(Long xVRCollapsepkId);

}

