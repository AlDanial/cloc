package com.ibm.daimler.dsea.entityObject;

import com.ibm.daimler.dsea.entityObject.EObjXContractDetails;
import com.ibm.pdq.runtime.generator.BaseParameterHandler;
import java.util.Iterator;
import com.ibm.mdm.base.db.ResultQueue1;
import java.sql.PreparedStatement;
import com.ibm.pdq.runtime.statement.StatementDescriptor;
import com.ibm.pdq.runtime.generator.BaseData;
import java.sql.SQLException;
import com.ibm.pdq.annotation.Metadata;
import com.ibm.pdq.runtime.generator.BaseRowHandler;
import com.ibm.pdq.runtime.statement.SqlStatementType;
import java.sql.Types;


@SuppressWarnings("unchecked")

/**
 * <!-- begin-user-doc -->
 * 
 * <!-- end-user-doc -->
 * 
 * @generated
 */
public class XContractDetailsInquiryDataImpl  extends BaseData implements XContractDetailsInquiryData
{

  /**
   * @generated
   */
  public static final String generatorVersion = "3.200.75";

  /**
   * @generated
   */
  public static final String identifier = "XContractDetailsInquiryData";

  /**
   * @generated
   */
  public static final long generationTime = 0x000001635e661ee3L;

  /**
   * @generated
   */
  public static final String collection = "NULLID";

  /**
   * @generated
   */
  public static final String packageVersion = null;

  /**
   * @generated
   */
  public static final boolean forceSingleBindIsolation = false;

  /**
   * @generated
   */
  public XContractDetailsInquiryDataImpl()
  {
    super();
  } 

  /**
   * @generated
   */
  public String getGeneratorVersion()
  {
    return generatorVersion;
  }

  /**
   * @Select( sql="SELECT r.CONTRACTPK_ID CONTRACTPK_ID, r.CONT_ID CONT_ID, r.FINANCE_PRODUCT FINANCE_PRODUCT, r.CONTRACT_NUMBER CONTRACT_NUMBER, r.CONTRACT_ST_TP_CD CONTRACT_ST_TP_CD, r.MARKET_NAME MARKET_NAME, r.Financial_Product_Group Financial_Product_Group, r.ADDR_LINE_ONE ADDR_LINE_ONE, r.ADDR_LINE_TWO ADDR_LINE_TWO, r.ADDR_LINE_THREE ADDR_LINE_THREE, r.POSTAL_CODE POSTAL_CODE, r.CITY_NAME CITY_NAME, r.RESIDENCE_NUMBER RESIDENCE_NUMBER, r.COUNTRY_TP_CD COUNTRY_TP_CD, r.BUILDING_NAME BUILDING_NAME, r.STREET_NAME STREET_NAME, r.STREET_NUMBER STREET_NUMBER, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.START_DT START_DT, r.END_DT END_DT, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.ODDays ODDays, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XCONTRACT r WHERE r.CONTRACTPK_ID = ? ", pattern="tableAlias (XCONTRACT => com.ibm.daimler.dsea.entityObject.EObjXContractDetails, H_XCONTRACT => com.ibm.daimler.dsea.entityObject.EObjXContractDetails)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue1<EObjXContractDetails>> getXContractDetails (Object[] parameters)
  {
    return queryIterator (getXContractDetailsStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getXContractDetailsStatementDescriptor = createStatementDescriptor (
    "getXContractDetails(Object[])",
    "SELECT r.CONTRACTPK_ID CONTRACTPK_ID, r.CONT_ID CONT_ID, r.FINANCE_PRODUCT FINANCE_PRODUCT, r.CONTRACT_NUMBER CONTRACT_NUMBER, r.CONTRACT_ST_TP_CD CONTRACT_ST_TP_CD, r.MARKET_NAME MARKET_NAME, r.Financial_Product_Group Financial_Product_Group, r.ADDR_LINE_ONE ADDR_LINE_ONE, r.ADDR_LINE_TWO ADDR_LINE_TWO, r.ADDR_LINE_THREE ADDR_LINE_THREE, r.POSTAL_CODE POSTAL_CODE, r.CITY_NAME CITY_NAME, r.RESIDENCE_NUMBER RESIDENCE_NUMBER, r.COUNTRY_TP_CD COUNTRY_TP_CD, r.BUILDING_NAME BUILDING_NAME, r.STREET_NAME STREET_NAME, r.STREET_NUMBER STREET_NUMBER, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.START_DT START_DT, r.END_DT END_DT, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.ODDays ODDays, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XCONTRACT r WHERE r.CONTRACTPK_ID = ? ",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"contractpk_id", "cont_id", "finance_product", "contract_number", "contract_st_tp_cd", "market_name", "financial_product_group", "addr_line_one", "addr_line_two", "addr_line_three", "postal_code", "city_name", "residence_number", "country_tp_cd", "building_name", "street_name", "street_number", "source_ident_tp_cd", "start_dt", "end_dt", "modify_sys_dt", "oddays", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetXContractDetailsParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetXContractDetailsRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.INTEGER, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 19, 500, 250, 19, 50, 250, 500, 500, 500, 250, 250, 250, 19, 250, 250, 250, 19, 0, 0, 0, 10, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    1);

  /**
   * @generated
   */
  public static class GetXContractDetailsParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetXContractDetailsRowHandler extends BaseRowHandler<ResultQueue1<EObjXContractDetails>>
  {
    /**
     * @generated
     */
    public ResultQueue1<EObjXContractDetails> handle (java.sql.ResultSet rs, ResultQueue1<EObjXContractDetails> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue1<EObjXContractDetails> ();

      EObjXContractDetails returnObject1 = new EObjXContractDetails ();
      returnObject1.setContractpkId(getLongObject (rs, 1)); 
      returnObject1.setContId(getLongObject (rs, 2)); 
      returnObject1.setFinanceProduct(getString (rs, 3)); 
      returnObject1.setContractNumber(getString (rs, 4)); 
      returnObject1.setContractStatus(getLongObject (rs, 5)); 
      returnObject1.setMarketName(getString (rs, 6)); 
      returnObject1.setFinancialProductGroup(getString (rs, 7)); 
      returnObject1.setAddressLineOne(getString (rs, 8)); 
      returnObject1.setAddressLineTwo(getString (rs, 9)); 
      returnObject1.setAddressLineThree(getString (rs, 10)); 
      returnObject1.setPostalCode(getString (rs, 11)); 
      returnObject1.setCityName(getString (rs, 12)); 
      returnObject1.setResidenceNumber(getString (rs, 13)); 
      returnObject1.setCountry(getLongObject (rs, 14)); 
      returnObject1.setBuildingName(getString (rs, 15)); 
      returnObject1.setStreetName(getString (rs, 16)); 
      returnObject1.setStreetNumber(getString (rs, 17)); 
      returnObject1.setSourceIdentifier(getLongObject (rs, 18)); 
      returnObject1.setStartDate(getTimestamp (rs, 19)); 
      returnObject1.setEndDate(getTimestamp (rs, 20)); 
      returnObject1.setLastModifiedSystemDate(getTimestamp (rs, 21)); 
      returnObject1.setODDays(getIntObject (rs, 22)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 23)); 
      returnObject1.setLastUpdateUser(getString (rs, 24)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 25)); 
      returnObject.add (returnObject1);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT r.H_CONTRACTPK_ID hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.CONTRACTPK_ID CONTRACTPK_ID, r.CONT_ID CONT_ID, r.FINANCE_PRODUCT FINANCE_PRODUCT, r.CONTRACT_NUMBER CONTRACT_NUMBER, r.CONTRACT_ST_TP_CD CONTRACT_ST_TP_CD, r.MARKET_NAME MARKET_NAME, r.Financial_Product_Group Financial_Product_Group, r.ADDR_LINE_ONE ADDR_LINE_ONE, r.ADDR_LINE_TWO ADDR_LINE_TWO, r.ADDR_LINE_THREE ADDR_LINE_THREE, r.POSTAL_CODE POSTAL_CODE, r.CITY_NAME CITY_NAME, r.RESIDENCE_NUMBER RESIDENCE_NUMBER, r.COUNTRY_TP_CD COUNTRY_TP_CD, r.BUILDING_NAME BUILDING_NAME, r.STREET_NAME STREET_NAME, r.STREET_NUMBER STREET_NUMBER, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.START_DT START_DT, r.END_DT END_DT, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.ODDays ODDays, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XCONTRACT r WHERE r.H_CONTRACTPK_ID = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))", pattern="tableAlias (XCONTRACT => com.ibm.daimler.dsea.entityObject.EObjXContractDetails, H_XCONTRACT => com.ibm.daimler.dsea.entityObject.EObjXContractDetails)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue1<EObjXContractDetails>> getXContractDetailsHistory (Object[] parameters)
  {
    return queryIterator (getXContractDetailsHistoryStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getXContractDetailsHistoryStatementDescriptor = createStatementDescriptor (
    "getXContractDetailsHistory(Object[])",
    "SELECT r.H_CONTRACTPK_ID hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.CONTRACTPK_ID CONTRACTPK_ID, r.CONT_ID CONT_ID, r.FINANCE_PRODUCT FINANCE_PRODUCT, r.CONTRACT_NUMBER CONTRACT_NUMBER, r.CONTRACT_ST_TP_CD CONTRACT_ST_TP_CD, r.MARKET_NAME MARKET_NAME, r.Financial_Product_Group Financial_Product_Group, r.ADDR_LINE_ONE ADDR_LINE_ONE, r.ADDR_LINE_TWO ADDR_LINE_TWO, r.ADDR_LINE_THREE ADDR_LINE_THREE, r.POSTAL_CODE POSTAL_CODE, r.CITY_NAME CITY_NAME, r.RESIDENCE_NUMBER RESIDENCE_NUMBER, r.COUNTRY_TP_CD COUNTRY_TP_CD, r.BUILDING_NAME BUILDING_NAME, r.STREET_NAME STREET_NAME, r.STREET_NUMBER STREET_NUMBER, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.START_DT START_DT, r.END_DT END_DT, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.ODDays ODDays, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XCONTRACT r WHERE r.H_CONTRACTPK_ID = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"historyidpk", "h_action_code", "h_created_by", "h_create_dt", "h_end_dt", "contractpk_id", "cont_id", "finance_product", "contract_number", "contract_st_tp_cd", "market_name", "financial_product_group", "addr_line_one", "addr_line_two", "addr_line_three", "postal_code", "city_name", "residence_number", "country_tp_cd", "building_name", "street_name", "street_number", "source_ident_tp_cd", "start_dt", "end_dt", "modify_sys_dt", "oddays", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetXContractDetailsHistoryParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP}, {19, 0, 0}, {0, 0, 0}, {1, 1, 1}},
    null,
    new GetXContractDetailsHistoryRowHandler (),
    new int[][]{ {Types.BIGINT, Types.CHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.INTEGER, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 1, 20, 0, 0, 19, 19, 500, 250, 19, 50, 250, 500, 500, 500, 250, 250, 250, 19, 250, 250, 250, 19, 0, 0, 0, 10, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    2);

  /**
   * @generated
   */
  public static class GetXContractDetailsHistoryParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetXContractDetailsHistoryRowHandler extends BaseRowHandler<ResultQueue1<EObjXContractDetails>>
  {
    /**
     * @generated
     */
    public ResultQueue1<EObjXContractDetails> handle (java.sql.ResultSet rs, ResultQueue1<EObjXContractDetails> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue1<EObjXContractDetails> ();

      EObjXContractDetails returnObject1 = new EObjXContractDetails ();
      returnObject1.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject1.setHistActionCode(getString (rs, 2)); 
      returnObject1.setHistCreatedBy(getString (rs, 3)); 
      returnObject1.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject1.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject1.setContractpkId(getLongObject (rs, 6)); 
      returnObject1.setContId(getLongObject (rs, 7)); 
      returnObject1.setFinanceProduct(getString (rs, 8)); 
      returnObject1.setContractNumber(getString (rs, 9)); 
      returnObject1.setContractStatus(getLongObject (rs, 10)); 
      returnObject1.setMarketName(getString (rs, 11)); 
      returnObject1.setFinancialProductGroup(getString (rs, 12)); 
      returnObject1.setAddressLineOne(getString (rs, 13)); 
      returnObject1.setAddressLineTwo(getString (rs, 14)); 
      returnObject1.setAddressLineThree(getString (rs, 15)); 
      returnObject1.setPostalCode(getString (rs, 16)); 
      returnObject1.setCityName(getString (rs, 17)); 
      returnObject1.setResidenceNumber(getString (rs, 18)); 
      returnObject1.setCountry(getLongObject (rs, 19)); 
      returnObject1.setBuildingName(getString (rs, 20)); 
      returnObject1.setStreetName(getString (rs, 21)); 
      returnObject1.setStreetNumber(getString (rs, 22)); 
      returnObject1.setSourceIdentifier(getLongObject (rs, 23)); 
      returnObject1.setStartDate(getTimestamp (rs, 24)); 
      returnObject1.setEndDate(getTimestamp (rs, 25)); 
      returnObject1.setLastModifiedSystemDate(getTimestamp (rs, 26)); 
      returnObject1.setODDays(getIntObject (rs, 27)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 28)); 
      returnObject1.setLastUpdateUser(getString (rs, 29)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 30)); 
      returnObject.add (returnObject1);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT r.CONTRACTPK_ID CONTRACTPK_ID, r.CONT_ID CONT_ID, r.FINANCE_PRODUCT FINANCE_PRODUCT, r.CONTRACT_NUMBER CONTRACT_NUMBER, r.CONTRACT_ST_TP_CD CONTRACT_ST_TP_CD, r.MARKET_NAME MARKET_NAME, r.Financial_Product_Group Financial_Product_Group, r.ADDR_LINE_ONE ADDR_LINE_ONE, r.ADDR_LINE_TWO ADDR_LINE_TWO, r.ADDR_LINE_THREE ADDR_LINE_THREE, r.POSTAL_CODE POSTAL_CODE, r.CITY_NAME CITY_NAME, r.RESIDENCE_NUMBER RESIDENCE_NUMBER, r.COUNTRY_TP_CD COUNTRY_TP_CD, r.BUILDING_NAME BUILDING_NAME, r.STREET_NAME STREET_NAME, r.STREET_NUMBER STREET_NUMBER, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.START_DT START_DT, r.END_DT END_DT, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.ODDays ODDays, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XCONTRACT r WHERE r.CONT_ID = ? ", pattern="tableAlias (XCONTRACT => com.ibm.daimler.dsea.entityObject.EObjXContractDetails, H_XCONTRACT => com.ibm.daimler.dsea.entityObject.EObjXContractDetails)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue1<EObjXContractDetails>> getAllXContractDetailsByPartyId (Object[] parameters)
  {
    return queryIterator (getAllXContractDetailsByPartyIdStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getAllXContractDetailsByPartyIdStatementDescriptor = createStatementDescriptor (
    "getAllXContractDetailsByPartyId(Object[])",
    "SELECT r.CONTRACTPK_ID CONTRACTPK_ID, r.CONT_ID CONT_ID, r.FINANCE_PRODUCT FINANCE_PRODUCT, r.CONTRACT_NUMBER CONTRACT_NUMBER, r.CONTRACT_ST_TP_CD CONTRACT_ST_TP_CD, r.MARKET_NAME MARKET_NAME, r.Financial_Product_Group Financial_Product_Group, r.ADDR_LINE_ONE ADDR_LINE_ONE, r.ADDR_LINE_TWO ADDR_LINE_TWO, r.ADDR_LINE_THREE ADDR_LINE_THREE, r.POSTAL_CODE POSTAL_CODE, r.CITY_NAME CITY_NAME, r.RESIDENCE_NUMBER RESIDENCE_NUMBER, r.COUNTRY_TP_CD COUNTRY_TP_CD, r.BUILDING_NAME BUILDING_NAME, r.STREET_NAME STREET_NAME, r.STREET_NUMBER STREET_NUMBER, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.START_DT START_DT, r.END_DT END_DT, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.ODDays ODDays, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XCONTRACT r WHERE r.CONT_ID = ? ",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"contractpk_id", "cont_id", "finance_product", "contract_number", "contract_st_tp_cd", "market_name", "financial_product_group", "addr_line_one", "addr_line_two", "addr_line_three", "postal_code", "city_name", "residence_number", "country_tp_cd", "building_name", "street_name", "street_number", "source_ident_tp_cd", "start_dt", "end_dt", "modify_sys_dt", "oddays", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetAllXContractDetailsByPartyIdParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetAllXContractDetailsByPartyIdRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.INTEGER, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 19, 500, 250, 19, 50, 250, 500, 500, 500, 250, 250, 250, 19, 250, 250, 250, 19, 0, 0, 0, 10, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    3);

  /**
   * @generated
   */
  public static class GetAllXContractDetailsByPartyIdParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetAllXContractDetailsByPartyIdRowHandler extends BaseRowHandler<ResultQueue1<EObjXContractDetails>>
  {
    /**
     * @generated
     */
    public ResultQueue1<EObjXContractDetails> handle (java.sql.ResultSet rs, ResultQueue1<EObjXContractDetails> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue1<EObjXContractDetails> ();

      EObjXContractDetails returnObject1 = new EObjXContractDetails ();
      returnObject1.setContractpkId(getLongObject (rs, 1)); 
      returnObject1.setContId(getLongObject (rs, 2)); 
      returnObject1.setFinanceProduct(getString (rs, 3)); 
      returnObject1.setContractNumber(getString (rs, 4)); 
      returnObject1.setContractStatus(getLongObject (rs, 5)); 
      returnObject1.setMarketName(getString (rs, 6)); 
      returnObject1.setFinancialProductGroup(getString (rs, 7)); 
      returnObject1.setAddressLineOne(getString (rs, 8)); 
      returnObject1.setAddressLineTwo(getString (rs, 9)); 
      returnObject1.setAddressLineThree(getString (rs, 10)); 
      returnObject1.setPostalCode(getString (rs, 11)); 
      returnObject1.setCityName(getString (rs, 12)); 
      returnObject1.setResidenceNumber(getString (rs, 13)); 
      returnObject1.setCountry(getLongObject (rs, 14)); 
      returnObject1.setBuildingName(getString (rs, 15)); 
      returnObject1.setStreetName(getString (rs, 16)); 
      returnObject1.setStreetNumber(getString (rs, 17)); 
      returnObject1.setSourceIdentifier(getLongObject (rs, 18)); 
      returnObject1.setStartDate(getTimestamp (rs, 19)); 
      returnObject1.setEndDate(getTimestamp (rs, 20)); 
      returnObject1.setLastModifiedSystemDate(getTimestamp (rs, 21)); 
      returnObject1.setODDays(getIntObject (rs, 22)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 23)); 
      returnObject1.setLastUpdateUser(getString (rs, 24)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 25)); 
      returnObject.add (returnObject1);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT r.H_CONTRACTPK_ID hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.CONTRACTPK_ID CONTRACTPK_ID, r.CONT_ID CONT_ID, r.FINANCE_PRODUCT FINANCE_PRODUCT, r.CONTRACT_NUMBER CONTRACT_NUMBER, r.CONTRACT_ST_TP_CD CONTRACT_ST_TP_CD, r.MARKET_NAME MARKET_NAME, r.Financial_Product_Group Financial_Product_Group, r.ADDR_LINE_ONE ADDR_LINE_ONE, r.ADDR_LINE_TWO ADDR_LINE_TWO, r.ADDR_LINE_THREE ADDR_LINE_THREE, r.POSTAL_CODE POSTAL_CODE, r.CITY_NAME CITY_NAME, r.RESIDENCE_NUMBER RESIDENCE_NUMBER, r.COUNTRY_TP_CD COUNTRY_TP_CD, r.BUILDING_NAME BUILDING_NAME, r.STREET_NAME STREET_NAME, r.STREET_NUMBER STREET_NUMBER, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.START_DT START_DT, r.END_DT END_DT, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.ODDays ODDays, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XCONTRACT r WHERE r.CONT_ID = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))", pattern="tableAlias (XCONTRACT => com.ibm.daimler.dsea.entityObject.EObjXContractDetails, H_XCONTRACT => com.ibm.daimler.dsea.entityObject.EObjXContractDetails)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue1<EObjXContractDetails>> getAllXContractDetailsByPartyIdHistory (Object[] parameters)
  {
    return queryIterator (getAllXContractDetailsByPartyIdHistoryStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getAllXContractDetailsByPartyIdHistoryStatementDescriptor = createStatementDescriptor (
    "getAllXContractDetailsByPartyIdHistory(Object[])",
    "SELECT r.H_CONTRACTPK_ID hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.CONTRACTPK_ID CONTRACTPK_ID, r.CONT_ID CONT_ID, r.FINANCE_PRODUCT FINANCE_PRODUCT, r.CONTRACT_NUMBER CONTRACT_NUMBER, r.CONTRACT_ST_TP_CD CONTRACT_ST_TP_CD, r.MARKET_NAME MARKET_NAME, r.Financial_Product_Group Financial_Product_Group, r.ADDR_LINE_ONE ADDR_LINE_ONE, r.ADDR_LINE_TWO ADDR_LINE_TWO, r.ADDR_LINE_THREE ADDR_LINE_THREE, r.POSTAL_CODE POSTAL_CODE, r.CITY_NAME CITY_NAME, r.RESIDENCE_NUMBER RESIDENCE_NUMBER, r.COUNTRY_TP_CD COUNTRY_TP_CD, r.BUILDING_NAME BUILDING_NAME, r.STREET_NAME STREET_NAME, r.STREET_NUMBER STREET_NUMBER, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.START_DT START_DT, r.END_DT END_DT, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.ODDays ODDays, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XCONTRACT r WHERE r.CONT_ID = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"historyidpk", "h_action_code", "h_created_by", "h_create_dt", "h_end_dt", "contractpk_id", "cont_id", "finance_product", "contract_number", "contract_st_tp_cd", "market_name", "financial_product_group", "addr_line_one", "addr_line_two", "addr_line_three", "postal_code", "city_name", "residence_number", "country_tp_cd", "building_name", "street_name", "street_number", "source_ident_tp_cd", "start_dt", "end_dt", "modify_sys_dt", "oddays", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetAllXContractDetailsByPartyIdHistoryParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP}, {19, 0, 0}, {0, 0, 0}, {1, 1, 1}},
    null,
    new GetAllXContractDetailsByPartyIdHistoryRowHandler (),
    new int[][]{ {Types.BIGINT, Types.CHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.INTEGER, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 1, 20, 0, 0, 19, 19, 500, 250, 19, 50, 250, 500, 500, 500, 250, 250, 250, 19, 250, 250, 250, 19, 0, 0, 0, 10, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    4);

  /**
   * @generated
   */
  public static class GetAllXContractDetailsByPartyIdHistoryParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetAllXContractDetailsByPartyIdHistoryRowHandler extends BaseRowHandler<ResultQueue1<EObjXContractDetails>>
  {
    /**
     * @generated
     */
    public ResultQueue1<EObjXContractDetails> handle (java.sql.ResultSet rs, ResultQueue1<EObjXContractDetails> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue1<EObjXContractDetails> ();

      EObjXContractDetails returnObject1 = new EObjXContractDetails ();
      returnObject1.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject1.setHistActionCode(getString (rs, 2)); 
      returnObject1.setHistCreatedBy(getString (rs, 3)); 
      returnObject1.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject1.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject1.setContractpkId(getLongObject (rs, 6)); 
      returnObject1.setContId(getLongObject (rs, 7)); 
      returnObject1.setFinanceProduct(getString (rs, 8)); 
      returnObject1.setContractNumber(getString (rs, 9)); 
      returnObject1.setContractStatus(getLongObject (rs, 10)); 
      returnObject1.setMarketName(getString (rs, 11)); 
      returnObject1.setFinancialProductGroup(getString (rs, 12)); 
      returnObject1.setAddressLineOne(getString (rs, 13)); 
      returnObject1.setAddressLineTwo(getString (rs, 14)); 
      returnObject1.setAddressLineThree(getString (rs, 15)); 
      returnObject1.setPostalCode(getString (rs, 16)); 
      returnObject1.setCityName(getString (rs, 17)); 
      returnObject1.setResidenceNumber(getString (rs, 18)); 
      returnObject1.setCountry(getLongObject (rs, 19)); 
      returnObject1.setBuildingName(getString (rs, 20)); 
      returnObject1.setStreetName(getString (rs, 21)); 
      returnObject1.setStreetNumber(getString (rs, 22)); 
      returnObject1.setSourceIdentifier(getLongObject (rs, 23)); 
      returnObject1.setStartDate(getTimestamp (rs, 24)); 
      returnObject1.setEndDate(getTimestamp (rs, 25)); 
      returnObject1.setLastModifiedSystemDate(getTimestamp (rs, 26)); 
      returnObject1.setODDays(getIntObject (rs, 27)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 28)); 
      returnObject1.setLastUpdateUser(getString (rs, 29)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 30)); 
      returnObject.add (returnObject1);

    
      return returnObject;
    }
  }

}
