/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[fc183e4447a132127ce96b8b90336a0f]
 */


package com.ibm.daimler.dsea.entityObject;

import java.util.Iterator;
import com.ibm.mdm.base.db.EntityMapping;
import com.ibm.pdq.annotation.Select;
import com.ibm.pdq.annotation.Update;

import com.ibm.daimler.dsea.entityObject.EObjXVehicle;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * @generated
 */
public interface EObjXVehicleData {


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjXVehicleSql = "select VEHICLEPK_ID, DIVISION, BUSINESS_UNIT, ACTIVITY, TYPE_CLASS, BAU_RELHE, BAU_MUSTER, SUB_MUSTER, ENGINE_NUM, COUNTRY_TP_CD, COLOR, TRIM, GLOBAL_VIN, LOCAL_VIN, LICENSE_PLATE, SOURCE_IDENT_TP_CD, MODIFY_SYS_DT, CREATE_DT, CHANGED_DT, LAST_SERVICE_DT, Market_Name, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from XVEHICLE where VEHICLEPK_ID = ? ";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String createEObjXVehicleSql = "insert into XVEHICLE (VEHICLEPK_ID, DIVISION, BUSINESS_UNIT, ACTIVITY, TYPE_CLASS, BAU_RELHE, BAU_MUSTER, SUB_MUSTER, ENGINE_NUM, COUNTRY_TP_CD, COLOR, TRIM, GLOBAL_VIN, LOCAL_VIN, LICENSE_PLATE, SOURCE_IDENT_TP_CD, MODIFY_SYS_DT, CREATE_DT, CHANGED_DT, LAST_SERVICE_DT, Market_Name, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( :vehiclepkId, :division, :businessUnit, :activity, :typeClass, :bauRelhe, :bauMuster, :subMuster, :engineNumber, :country, :color, :trim, :globalVIN, :localVIN, :licensePlate, :sourceIdentifier, :lastModifiedSystemDate, :createDate, :changedDate, :lastServiceDate, :marketName, :lastUpdateDt, :lastUpdateUser, :lastUpdateTxId)";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String updateEObjXVehicleSql = "update XVEHICLE set DIVISION = :division, BUSINESS_UNIT = :businessUnit, ACTIVITY = :activity, TYPE_CLASS = :typeClass, BAU_RELHE = :bauRelhe, BAU_MUSTER = :bauMuster, SUB_MUSTER = :subMuster, ENGINE_NUM = :engineNumber, COUNTRY_TP_CD = :country, COLOR = :color, TRIM = :trim, GLOBAL_VIN = :globalVIN, LOCAL_VIN = :localVIN, LICENSE_PLATE = :licensePlate, SOURCE_IDENT_TP_CD = :sourceIdentifier, MODIFY_SYS_DT = :lastModifiedSystemDate, CREATE_DT = :createDate, CHANGED_DT = :changedDate, LAST_SERVICE_DT = :lastServiceDate, Market_Name = :marketName, LAST_UPDATE_DT = :lastUpdateDt, LAST_UPDATE_USER = :lastUpdateUser, LAST_UPDATE_TX_ID = :lastUpdateTxId where VEHICLEPK_ID = :vehiclepkId and LAST_UPDATE_DT = :oldLastUpdateDt";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String deleteEObjXVehicleSql = "delete from XVEHICLE where VEHICLEPK_ID = ?";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXVehicleKeyField = "EObjXVehicle.vehiclepkId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXVehicleGetFields =
    "EObjXVehicle.vehiclepkId," +
    "EObjXVehicle.division," +
    "EObjXVehicle.businessUnit," +
    "EObjXVehicle.activity," +
    "EObjXVehicle.typeClass," +
    "EObjXVehicle.bauRelhe," +
    "EObjXVehicle.bauMuster," +
    "EObjXVehicle.subMuster," +
    "EObjXVehicle.engineNumber," +
    "EObjXVehicle.country," +
    "EObjXVehicle.color," +
    "EObjXVehicle.trim," +
    "EObjXVehicle.globalVIN," +
    "EObjXVehicle.localVIN," +
    "EObjXVehicle.licensePlate," +
    "EObjXVehicle.sourceIdentifier," +
    "EObjXVehicle.lastModifiedSystemDate," +
    "EObjXVehicle.createDate," +
    "EObjXVehicle.changedDate," +
    "EObjXVehicle.lastServiceDate," +
    "EObjXVehicle.marketName," +
    "EObjXVehicle.lastUpdateDt," +
    "EObjXVehicle.lastUpdateUser," +
    "EObjXVehicle.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXVehicleAllFields =
    "com.ibm.daimler.dsea.entityObject.EObjXVehicle.vehiclepkId," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicle.division," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicle.businessUnit," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicle.activity," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicle.typeClass," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicle.bauRelhe," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicle.bauMuster," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicle.subMuster," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicle.engineNumber," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicle.country," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicle.color," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicle.trim," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicle.globalVIN," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicle.localVIN," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicle.licensePlate," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicle.sourceIdentifier," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicle.lastModifiedSystemDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicle.createDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicle.changedDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicle.lastServiceDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicle.marketName," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicle.lastUpdateDt," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicle.lastUpdateUser," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicle.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXVehicleUpdateFields =
    "com.ibm.daimler.dsea.entityObject.EObjXVehicle.division," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicle.businessUnit," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicle.activity," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicle.typeClass," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicle.bauRelhe," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicle.bauMuster," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicle.subMuster," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicle.engineNumber," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicle.country," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicle.color," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicle.trim," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicle.globalVIN," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicle.localVIN," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicle.licensePlate," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicle.sourceIdentifier," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicle.lastModifiedSystemDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicle.createDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicle.changedDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicle.lastServiceDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicle.marketName," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicle.lastUpdateDt," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicle.lastUpdateUser," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicle.lastUpdateTxId," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicle.vehiclepkId," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicle.oldLastUpdateDt";   

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Select XVehicle by parameters.
   * @generated
   */
  @Select(sql=getEObjXVehicleSql)
  @EntityMapping(parameters=EObjXVehicleKeyField, results=EObjXVehicleGetFields)
  Iterator<EObjXVehicle> getEObjXVehicle(Long vehiclepkId);  
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Create XVehicle by EObjXVehicle Object.
   * @generated
   */
  @Update(sql=createEObjXVehicleSql)
  @EntityMapping(parameters=EObjXVehicleAllFields)
    int createEObjXVehicle(EObjXVehicle e); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Update one XVehicle by EObjXVehicle object.
   * @generated
   */
  @Update(sql=updateEObjXVehicleSql)
  @EntityMapping(parameters=EObjXVehicleUpdateFields)
    int updateEObjXVehicle(EObjXVehicle e); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Delete XVehicle by parameters.
   * @generated
   */
  @Update(sql=deleteEObjXVehicleSql)
  @EntityMapping(parameters=EObjXVehicleKeyField)
  int deleteEObjXVehicle(Long vehiclepkId);

}

