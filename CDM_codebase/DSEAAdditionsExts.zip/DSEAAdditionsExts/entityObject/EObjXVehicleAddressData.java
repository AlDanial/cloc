/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[55e4da73999677890d8f12124df2612f]
 */


package com.ibm.daimler.dsea.entityObject;

import java.util.Iterator;
import com.ibm.mdm.base.db.EntityMapping;
import com.ibm.pdq.annotation.Select;
import com.ibm.pdq.annotation.Update;

import com.ibm.daimler.dsea.entityObject.EObjXVehicleAddress;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * @generated
 */
public interface EObjXVehicleAddressData {


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjXVehicleAddressSql = "select VEHICLE_ADDRESSPK_ID, ADDRESS_USAGE_TYPE, PREFERRED_IND, ADDRESS_LINE_ONE, ADDRESS_LINE_TWO, ADDRESS_LINE_THREE, CITY_NAME, POSTAL_CODE, RESIDENCE_NUM, COUNTRY, PROVINCE_STATE, VEHICLE_ID, CONT_ID, SOURCE_IDENT_TP_CD, START_DT, MODIFY_SYS_DT, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from XVEHICLEADDRESS where VEHICLE_ADDRESSPK_ID = ? ";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String createEObjXVehicleAddressSql = "insert into XVEHICLEADDRESS (VEHICLE_ADDRESSPK_ID, ADDRESS_USAGE_TYPE, PREFERRED_IND, ADDRESS_LINE_ONE, ADDRESS_LINE_TWO, ADDRESS_LINE_THREE, CITY_NAME, POSTAL_CODE, RESIDENCE_NUM, COUNTRY, PROVINCE_STATE, VEHICLE_ID, CONT_ID, SOURCE_IDENT_TP_CD, START_DT, MODIFY_SYS_DT, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( :vehicleAddresspkId, :addressUsageType, :preferredInd, :addressLineOne, :addressLineTwo, :addressLineThree, :city, :zipPostalCode, :residenceNumber, :country, :provinceState, :vehicleId, :contId, :sourceIdentifier, :startDate, :lastModifiedSystemDate, :lastUpdateDt, :lastUpdateUser, :lastUpdateTxId)";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String updateEObjXVehicleAddressSql = "update XVEHICLEADDRESS set ADDRESS_USAGE_TYPE = :addressUsageType, PREFERRED_IND = :preferredInd, ADDRESS_LINE_ONE = :addressLineOne, ADDRESS_LINE_TWO = :addressLineTwo, ADDRESS_LINE_THREE = :addressLineThree, CITY_NAME = :city, POSTAL_CODE = :zipPostalCode, RESIDENCE_NUM = :residenceNumber, COUNTRY = :country, PROVINCE_STATE = :provinceState, VEHICLE_ID = :vehicleId, CONT_ID = :contId, SOURCE_IDENT_TP_CD = :sourceIdentifier, START_DT = :startDate, MODIFY_SYS_DT = :lastModifiedSystemDate, LAST_UPDATE_DT = :lastUpdateDt, LAST_UPDATE_USER = :lastUpdateUser, LAST_UPDATE_TX_ID = :lastUpdateTxId where VEHICLE_ADDRESSPK_ID = :vehicleAddresspkId and LAST_UPDATE_DT = :oldLastUpdateDt";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String deleteEObjXVehicleAddressSql = "delete from XVEHICLEADDRESS where VEHICLE_ADDRESSPK_ID = ?";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXVehicleAddressKeyField = "EObjXVehicleAddress.vehicleAddresspkId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXVehicleAddressGetFields =
    "EObjXVehicleAddress.vehicleAddresspkId," +
    "EObjXVehicleAddress.addressUsageType," +
    "EObjXVehicleAddress.preferredInd," +
    "EObjXVehicleAddress.addressLineOne," +
    "EObjXVehicleAddress.addressLineTwo," +
    "EObjXVehicleAddress.addressLineThree," +
    "EObjXVehicleAddress.city," +
    "EObjXVehicleAddress.zipPostalCode," +
    "EObjXVehicleAddress.residenceNumber," +
    "EObjXVehicleAddress.country," +
    "EObjXVehicleAddress.provinceState," +
    "EObjXVehicleAddress.vehicleId," +
    "EObjXVehicleAddress.contId," +
    "EObjXVehicleAddress.sourceIdentifier," +
    "EObjXVehicleAddress.startDate," +
    "EObjXVehicleAddress.lastModifiedSystemDate," +
    "EObjXVehicleAddress.lastUpdateDt," +
    "EObjXVehicleAddress.lastUpdateUser," +
    "EObjXVehicleAddress.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXVehicleAddressAllFields =
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleAddress.vehicleAddresspkId," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleAddress.addressUsageType," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleAddress.preferredInd," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleAddress.addressLineOne," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleAddress.addressLineTwo," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleAddress.addressLineThree," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleAddress.city," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleAddress.zipPostalCode," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleAddress.residenceNumber," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleAddress.country," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleAddress.provinceState," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleAddress.vehicleId," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleAddress.contId," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleAddress.sourceIdentifier," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleAddress.startDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleAddress.lastModifiedSystemDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleAddress.lastUpdateDt," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleAddress.lastUpdateUser," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleAddress.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXVehicleAddressUpdateFields =
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleAddress.addressUsageType," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleAddress.preferredInd," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleAddress.addressLineOne," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleAddress.addressLineTwo," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleAddress.addressLineThree," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleAddress.city," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleAddress.zipPostalCode," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleAddress.residenceNumber," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleAddress.country," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleAddress.provinceState," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleAddress.vehicleId," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleAddress.contId," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleAddress.sourceIdentifier," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleAddress.startDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleAddress.lastModifiedSystemDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleAddress.lastUpdateDt," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleAddress.lastUpdateUser," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleAddress.lastUpdateTxId," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleAddress.vehicleAddresspkId," +
    "com.ibm.daimler.dsea.entityObject.EObjXVehicleAddress.oldLastUpdateDt";   

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Select XVehicleAddress by parameters.
   * @generated
   */
  @Select(sql=getEObjXVehicleAddressSql)
  @EntityMapping(parameters=EObjXVehicleAddressKeyField, results=EObjXVehicleAddressGetFields)
  Iterator<EObjXVehicleAddress> getEObjXVehicleAddress(Long vehicleAddresspkId);  
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Create XVehicleAddress by EObjXVehicleAddress Object.
   * @generated
   */
  @Update(sql=createEObjXVehicleAddressSql)
  @EntityMapping(parameters=EObjXVehicleAddressAllFields)
    int createEObjXVehicleAddress(EObjXVehicleAddress e); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Update one XVehicleAddress by EObjXVehicleAddress object.
   * @generated
   */
  @Update(sql=updateEObjXVehicleAddressSql)
  @EntityMapping(parameters=EObjXVehicleAddressUpdateFields)
    int updateEObjXVehicleAddress(EObjXVehicleAddress e); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Delete XVehicleAddress by parameters.
   * @generated
   */
  @Update(sql=deleteEObjXVehicleAddressSql)
  @EntityMapping(parameters=EObjXVehicleAddressKeyField)
  int deleteEObjXVehicleAddress(Long vehicleAddresspkId);

}

