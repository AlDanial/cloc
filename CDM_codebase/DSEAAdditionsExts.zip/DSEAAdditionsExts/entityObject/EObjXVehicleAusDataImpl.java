package com.ibm.daimler.dsea.entityObject;

import com.ibm.pdq.runtime.generator.BaseParameterHandler;
import java.util.Iterator;
import java.sql.PreparedStatement;
import com.ibm.pdq.runtime.statement.StatementDescriptor;
import com.ibm.daimler.dsea.entityObject.EObjXVehicleAus;
import com.ibm.pdq.runtime.generator.BaseData;
import java.sql.SQLException;
import com.ibm.pdq.annotation.Metadata;
import com.ibm.pdq.runtime.generator.BaseRowHandler;
import com.ibm.pdq.runtime.statement.SqlStatementType;
import java.sql.Types;


/**
 * <!-- begin-user-doc -->
 * 
 * <!-- end-user-doc -->
 * 
 * @generated
 */
public class EObjXVehicleAusDataImpl  extends BaseData implements EObjXVehicleAusData
{

  /**
   * @generated
   */
  public static final String generatorVersion = "3.200.75";

  /**
   * @generated
   */
  public static final String identifier = "EObjXVehicleAusData";

  /**
   * @generated
   */
  public static final long generationTime = 0x00000166d4489522L;

  /**
   * @generated
   */
  public static final String collection = "NULLID";

  /**
   * @generated
   */
  public static final String packageVersion = null;

  /**
   * @generated
   */
  public static final boolean forceSingleBindIsolation = false;

  /**
   * @generated
   */
  public EObjXVehicleAusDataImpl()
  {
    super();
  } 

  /**
   * @generated
   */
  public String getGeneratorVersion()
  {
    return generatorVersion;
  }

  /**
   * @Select( sql="select XVehicle_Auspk_Id, GLOBAL_VIN, AMG_VEH, VEHICLE_TYPE, CLASS_SUMMARY, ODOMETER, ENGINE_NUM, VEHICLE_YEAR, MODEL, REG_NO, VEHICLE_CLASS, COMM_NO, MARKET_NAME, CIRCLE_OF_EXCELLENCE, SOURCE_IDENT_TP_CD, MODIFY_SYS_DT, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from XVEHICLEAUS where XVehicle_Auspk_Id = ? " )
   * 
   * @generated
   */
  public Iterator<EObjXVehicleAus> getEObjXVehicleAus (Long xVehicleAuspkId)
  {
    return queryIterator (getEObjXVehicleAusStatementDescriptor, xVehicleAuspkId);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getEObjXVehicleAusStatementDescriptor = createStatementDescriptor (
    "getEObjXVehicleAus(Long)",
    "select XVehicle_Auspk_Id, GLOBAL_VIN, AMG_VEH, VEHICLE_TYPE, CLASS_SUMMARY, ODOMETER, ENGINE_NUM, VEHICLE_YEAR, MODEL, REG_NO, VEHICLE_CLASS, COMM_NO, MARKET_NAME, CIRCLE_OF_EXCELLENCE, SOURCE_IDENT_TP_CD, MODIFY_SYS_DT, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from XVEHICLEAUS where XVehicle_Auspk_Id = ? ",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"xvehicle_auspk_id", "global_vin", "amg_veh", "vehicle_type", "class_summary", "odometer", "engine_num", "vehicle_year", "model", "reg_no", "vehicle_class", "comm_no", "market_name", "circle_of_excellence", "source_ident_tp_cd", "modify_sys_dt", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetEObjXVehicleAusParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetEObjXVehicleAusRowHandler (),
    new int[][]{ {Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 50, 5, 50, 250, 250, 50, 0, 250, 50, 100, 100, 10, 250, 19, 0, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    1);

  /**
   * @generated
   */
  public static class GetEObjXVehicleAusParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setLong (stmt, 1, Types.BIGINT, (Long)parameters[0]);
    }
  }

  /**
   * @generated
   */
  public static class GetEObjXVehicleAusRowHandler extends BaseRowHandler<EObjXVehicleAus>
  {
    /**
     * @generated
     */
    public EObjXVehicleAus handle (java.sql.ResultSet rs, EObjXVehicleAus returnObject) throws java.sql.SQLException
    {
      returnObject = new EObjXVehicleAus ();
      returnObject.setXVehicleAuspkId(getLongObject (rs, 1)); 
      returnObject.setGlobalVIN(getString (rs, 2)); 
      returnObject.setAmgVehicle(getString (rs, 3)); 
      returnObject.setVehicleType(getString (rs, 4)); 
      returnObject.setClassSummary(getString (rs, 5)); 
      returnObject.setOdoMeter(getString (rs, 6)); 
      returnObject.setEngineNum(getString (rs, 7)); 
      returnObject.setVehicleYear(getTimestamp (rs, 8)); 
      returnObject.setModel(getString (rs, 9)); 
      returnObject.setRegNum(getString (rs, 10)); 
      returnObject.setVehicleClass(getString (rs, 11)); 
      returnObject.setCommNo(getString (rs, 12)); 
      returnObject.setMarketName(getString (rs, 13)); 
      returnObject.setCircleOfExcellence(getString (rs, 14)); 
      returnObject.setSourceIdentifier(getLongObject (rs, 15)); 
      returnObject.setLastModifiedSystemDate(getTimestamp (rs, 16)); 
      returnObject.setLastUpdateDt(getTimestamp (rs, 17)); 
      returnObject.setLastUpdateUser(getString (rs, 18)); 
      returnObject.setLastUpdateTxId(getLongObject (rs, 19)); 
    
      return returnObject;
    }
  }

  /**
   * @Update( sql="insert into XVEHICLEAUS (XVehicle_Auspk_Id, GLOBAL_VIN, AMG_VEH, VEHICLE_TYPE, CLASS_SUMMARY, ODOMETER, ENGINE_NUM, VEHICLE_YEAR, MODEL, REG_NO, VEHICLE_CLASS, COMM_NO, MARKET_NAME, CIRCLE_OF_EXCELLENCE, SOURCE_IDENT_TP_CD, MODIFY_SYS_DT, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( :xVehicleAuspkId, :globalVIN, :amgVehicle, :vehicleType, :classSummary, :odoMeter, :engineNum, :vehicleYear, :model, :regNum, :vehicleClass, :commNo, :marketName, :circleOfExcellence, :sourceIdentifier, :lastModifiedSystemDate, :lastUpdateDt, :lastUpdateUser, :lastUpdateTxId)" )
   * 
   * @generated
   */
  public int createEObjXVehicleAus (EObjXVehicleAus e)
  {
    return update (createEObjXVehicleAusStatementDescriptor, e);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor createEObjXVehicleAusStatementDescriptor = createStatementDescriptor (
    "createEObjXVehicleAus(com.ibm.daimler.dsea.entityObject.EObjXVehicleAus)",
    "insert into XVEHICLEAUS (XVehicle_Auspk_Id, GLOBAL_VIN, AMG_VEH, VEHICLE_TYPE, CLASS_SUMMARY, ODOMETER, ENGINE_NUM, VEHICLE_YEAR, MODEL, REG_NO, VEHICLE_CLASS, COMM_NO, MARKET_NAME, CIRCLE_OF_EXCELLENCE, SOURCE_IDENT_TP_CD, MODIFY_SYS_DT, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values(  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? )",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.INSERT,
    null,
    new CreateEObjXVehicleAusParameterHandler (),
    new int[][]{{Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 50, 5, 50, 250, 250, 50, 0, 250, 50, 100, 100, 10, 250, 19, 0, 0, 0, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    2);

  /**
   * @generated
   */
  public static class CreateEObjXVehicleAusParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      EObjXVehicleAus bean0 = (EObjXVehicleAus) parameters[0];
      setLong (stmt, 1, Types.BIGINT, (Long)bean0.getXVehicleAuspkId());
      setString (stmt, 2, Types.VARCHAR, (String)bean0.getGlobalVIN());
      setString (stmt, 3, Types.VARCHAR, (String)bean0.getAmgVehicle());
      setString (stmt, 4, Types.VARCHAR, (String)bean0.getVehicleType());
      setString (stmt, 5, Types.VARCHAR, (String)bean0.getClassSummary());
      setString (stmt, 6, Types.VARCHAR, (String)bean0.getOdoMeter());
      setString (stmt, 7, Types.VARCHAR, (String)bean0.getEngineNum());
      setTimestamp (stmt, 8, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getVehicleYear());
      setString (stmt, 9, Types.VARCHAR, (String)bean0.getModel());
      setString (stmt, 10, Types.VARCHAR, (String)bean0.getRegNum());
      setString (stmt, 11, Types.VARCHAR, (String)bean0.getVehicleClass());
      setString (stmt, 12, Types.VARCHAR, (String)bean0.getCommNo());
      setString (stmt, 13, Types.VARCHAR, (String)bean0.getMarketName());
      setString (stmt, 14, Types.VARCHAR, (String)bean0.getCircleOfExcellence());
      setLong (stmt, 15, Types.BIGINT, (Long)bean0.getSourceIdentifier());
      setTimestamp (stmt, 16, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastModifiedSystemDate());
      setTimestamp (stmt, 17, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUpdateDt());
      setString (stmt, 18, Types.VARCHAR, (String)bean0.getLastUpdateUser());
      setLong (stmt, 19, Types.BIGINT, (Long)bean0.getLastUpdateTxId());
    }
  }

  /**
   * @Update( sql="update XVEHICLEAUS set GLOBAL_VIN = :globalVIN, AMG_VEH = :amgVehicle, VEHICLE_TYPE = :vehicleType, CLASS_SUMMARY = :classSummary, ODOMETER = :odoMeter, ENGINE_NUM = :engineNum, VEHICLE_YEAR = :vehicleYear, MODEL = :model, REG_NO = :regNum, VEHICLE_CLASS = :vehicleClass, COMM_NO = :commNo, MARKET_NAME = :marketName, CIRCLE_OF_EXCELLENCE = :circleOfExcellence, SOURCE_IDENT_TP_CD = :sourceIdentifier, MODIFY_SYS_DT = :lastModifiedSystemDate, LAST_UPDATE_DT = :lastUpdateDt, LAST_UPDATE_USER = :lastUpdateUser, LAST_UPDATE_TX_ID = :lastUpdateTxId where XVehicle_Auspk_Id = :xVehicleAuspkId and LAST_UPDATE_DT = :oldLastUpdateDt" )
   * 
   * @generated
   */
  public int updateEObjXVehicleAus (EObjXVehicleAus e)
  {
    return update (updateEObjXVehicleAusStatementDescriptor, e);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor updateEObjXVehicleAusStatementDescriptor = createStatementDescriptor (
    "updateEObjXVehicleAus(com.ibm.daimler.dsea.entityObject.EObjXVehicleAus)",
    "update XVEHICLEAUS set GLOBAL_VIN =  ? , AMG_VEH =  ? , VEHICLE_TYPE =  ? , CLASS_SUMMARY =  ? , ODOMETER =  ? , ENGINE_NUM =  ? , VEHICLE_YEAR =  ? , MODEL =  ? , REG_NO =  ? , VEHICLE_CLASS =  ? , COMM_NO =  ? , MARKET_NAME =  ? , CIRCLE_OF_EXCELLENCE =  ? , SOURCE_IDENT_TP_CD =  ? , MODIFY_SYS_DT =  ? , LAST_UPDATE_DT =  ? , LAST_UPDATE_USER =  ? , LAST_UPDATE_TX_ID =  ?  where XVehicle_Auspk_Id =  ?  and LAST_UPDATE_DT =  ? ",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.UPDATE,
    null,
    new UpdateEObjXVehicleAusParameterHandler (),
    new int[][]{{Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP}, {50, 5, 50, 250, 250, 50, 0, 250, 50, 100, 100, 10, 250, 19, 0, 0, 0, 19, 19, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    3);

  /**
   * @generated
   */
  public static class UpdateEObjXVehicleAusParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      EObjXVehicleAus bean0 = (EObjXVehicleAus) parameters[0];
      setString (stmt, 1, Types.VARCHAR, (String)bean0.getGlobalVIN());
      setString (stmt, 2, Types.VARCHAR, (String)bean0.getAmgVehicle());
      setString (stmt, 3, Types.VARCHAR, (String)bean0.getVehicleType());
      setString (stmt, 4, Types.VARCHAR, (String)bean0.getClassSummary());
      setString (stmt, 5, Types.VARCHAR, (String)bean0.getOdoMeter());
      setString (stmt, 6, Types.VARCHAR, (String)bean0.getEngineNum());
      setTimestamp (stmt, 7, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getVehicleYear());
      setString (stmt, 8, Types.VARCHAR, (String)bean0.getModel());
      setString (stmt, 9, Types.VARCHAR, (String)bean0.getRegNum());
      setString (stmt, 10, Types.VARCHAR, (String)bean0.getVehicleClass());
      setString (stmt, 11, Types.VARCHAR, (String)bean0.getCommNo());
      setString (stmt, 12, Types.VARCHAR, (String)bean0.getMarketName());
      setString (stmt, 13, Types.VARCHAR, (String)bean0.getCircleOfExcellence());
      setLong (stmt, 14, Types.BIGINT, (Long)bean0.getSourceIdentifier());
      setTimestamp (stmt, 15, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastModifiedSystemDate());
      setTimestamp (stmt, 16, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUpdateDt());
      setString (stmt, 17, Types.VARCHAR, (String)bean0.getLastUpdateUser());
      setLong (stmt, 18, Types.BIGINT, (Long)bean0.getLastUpdateTxId());
      setLong (stmt, 19, Types.BIGINT, (Long)bean0.getXVehicleAuspkId());
      setTimestamp (stmt, 20, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getOldLastUpdateDt());
    }
  }

  /**
   * @Update( sql="delete from XVEHICLEAUS where XVehicle_Auspk_Id = ?" )
   * 
   * @generated
   */
  public int deleteEObjXVehicleAus (Long xVehicleAuspkId)
  {
    return update (deleteEObjXVehicleAusStatementDescriptor, xVehicleAuspkId);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor deleteEObjXVehicleAusStatementDescriptor = createStatementDescriptor (
    "deleteEObjXVehicleAus(Long)",
    "delete from XVEHICLEAUS where XVehicle_Auspk_Id = ?",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.DELETE,
    null,
    new DeleteEObjXVehicleAusParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    4);

  /**
   * @generated
   */
  public static class DeleteEObjXVehicleAusParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setLong (stmt, 1, Types.BIGINT, (Long)parameters[0]);
    }
  }

}
