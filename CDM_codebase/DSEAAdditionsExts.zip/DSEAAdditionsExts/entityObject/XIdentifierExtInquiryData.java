/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[04adab2f7db5c80093c54416c264e8e7]
 */
package com.ibm.daimler.dsea.entityObject;


import com.ibm.mdm.base.db.EntityMapping;
import com.ibm.pdq.annotation.Select;


import com.dwl.tcrm.coreParty.entityObject.EObjIdentifier;

import com.ibm.mdm.base.db.ResultQueue2;

import java.util.Iterator;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * 
 * @generated
 */
public interface XIdentifierExtInquiryData {

  /**
   * MDM_TODO: CDKWB0050I The generated parameter and result lists in this file should be checked to ensure that each matches its
   * associated SQL query. Each list entry must be comma separated and identify a field within an entity object class.
   */ 
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */ 
   public final static String tableAliasString1 = "tableAlias (" + 
     "IDENTIFIER => com.dwl.tcrm.coreParty.entityObject.EObjIdentifier, " + 
     "H_IDENTIFIER => com.dwl.tcrm.coreParty.entityObject.EObjIdentifier , " + 
     "IDENTIFIER => com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt , " + 
     "H_IDENTIFIER => com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt" + 
     ")";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension
   * XIdentifier.
   *
   * @generated
   */ 
   public final static String getPartyIdentifiersHistoryByTypeSQL = "SELECT A.H_IDENTIFIER_ID AS HIST_ID_PK, A.H_ACTION_CODE , A.H_CREATED_BY , A.H_CREATE_DT , A.H_END_DT , A.IDENTIFIER_ID , A.ID_STATUS_TP_CD , A.CONT_ID, A.ID_TP_CD , A.REF_NUM , A.START_DT , A.END_DT , A.EXPIRY_DT , A.LAST_UPDATE_DT , A.LAST_UPDATE_USER , A.LAST_UPDATE_TX_ID , A.ASSIGNED_BY , A.IDENTIFIER_DESC , A.ISSUE_LOCATION , A.LAST_USED_DT , A.LAST_VERIFIED_DT , A.SOURCE_IDENT_TP_CD, A.XMODIFY_SYS_DT, A.XRETAILER_ID, A.XIDEN_RETAILER_FLAG, A.X_BPID" + 
     " FROM H_IDENTIFIER A" + 
     " WHERE A.CONT_ID = ? AND A.ID_TP_CD = ? AND (? BETWEEN A.H_CREATE_DT AND A.H_END_DT OR (? >= A.H_CREATE_DT AND A.H_END_DT IS NULL))";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyIdentifiersHistoryByTypeParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.idTpCd=ID_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.histCreateDt=H_CREATE_DT"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyIdentifiersHistoryByTypeResults =
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.historyIdPK=HIST_ID_PK," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.histActionCode=H_ACTION_CODE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.histCreatedBy=H_CREATED_BY," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.histEndDt=H_END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.identifierIdPK=IDENTIFIER_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.idStatusTpCd=ID_STATUS_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.idTpCd=ID_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.refNum=REF_NUM," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.startDt=START_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.endDt=END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.expiryDt=EXPIRY_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.assignedBy=ASSIGNED_BY," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.identifierDesc=IDENTIFIER_DESC," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.issueLocation=ISSUE_LOCATION," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.lastUsedDt=LAST_USED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.lastVerifiedDt=LAST_VERIFIED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.sourceIdentTpCd=SOURCE_IDENT_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt.XLastModifiedSystemDate=XMODIFY_SYS_DT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt.XRetailerId=XRETAILER_ID," + 
    "com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt.XIdentifierRetailerFlag=XIDEN_RETAILER_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt.X_BPID=X_BPID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension
   * XIdentifier.
   *
   * @generated
   */ 
   public final static String getPartyIdentifiersByTypeSQL = "SELECT IDENTIFIER.IDENTIFIER_ID , IDENTIFIER.ID_STATUS_TP_CD , IDENTIFIER.CONT_ID , IDENTIFIER.ID_TP_CD , IDENTIFIER.REF_NUM , IDENTIFIER.START_DT , IDENTIFIER.END_DT , IDENTIFIER.EXPIRY_DT , IDENTIFIER.LAST_UPDATE_DT ,IDENTIFIER.LAST_UPDATE_USER, IDENTIFIER.LAST_UPDATE_TX_ID , IDENTIFIER.ASSIGNED_BY , IDENTIFIER.IDENTIFIER_DESC , IDENTIFIER.ISSUE_LOCATION , IDENTIFIER.LAST_USED_DT , IDENTIFIER.LAST_VERIFIED_DT , IDENTIFIER.SOURCE_IDENT_TP_CD, IDENTIFIER.XMODIFY_SYS_DT, IDENTIFIER.XRETAILER_ID, IDENTIFIER.XIDEN_RETAILER_FLAG, IDENTIFIER.X_BPID" + 
     " FROM IDENTIFIER" + 
     " WHERE ((IDENTIFIER.CONT_ID = ? )AND ( IDENTIFIER.ID_TP_CD = ?) AND (IDENTIFIER.END_DT IS NULL OR IDENTIFIER.END_DT > ?))";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyIdentifiersByTypeParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.idTpCd=ID_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.endDt=END_DT"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyIdentifiersByTypeResults =
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.identifierIdPK=IDENTIFIER_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.idStatusTpCd=ID_STATUS_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.idTpCd=ID_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.refNum=REF_NUM," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.startDt=START_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.endDt=END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.expiryDt=EXPIRY_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.assignedBy=ASSIGNED_BY," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.identifierDesc=IDENTIFIER_DESC," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.issueLocation=ISSUE_LOCATION," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.lastUsedDt=LAST_USED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.lastVerifiedDt=LAST_VERIFIED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.sourceIdentTpCd=SOURCE_IDENT_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt.XLastModifiedSystemDate=XMODIFY_SYS_DT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt.XRetailerId=XRETAILER_ID," + 
    "com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt.XIdentifierRetailerFlag=XIDEN_RETAILER_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt.X_BPID=X_BPID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension
   * XIdentifier.
   *
   * @generated
   */ 
   public final static String getPartyIdentifiersHistorySQL = "SELECT DISTINCT A.H_IDENTIFIER_ID AS HIST_ID_PK, A.H_ACTION_CODE , A.H_CREATED_BY , A.H_CREATE_DT ,A.H_END_DT ,A.IDENTIFIER_ID ,A.ID_STATUS_TP_CD ,A.CONT_ID , A.ID_TP_CD ,A.REF_NUM ,A.START_DT ,A.END_DT ,A.EXPIRY_DT , A.LAST_UPDATE_DT, A.LAST_UPDATE_USER , A.LAST_UPDATE_TX_ID , A.ASSIGNED_BY , A.IDENTIFIER_DESC , A.ISSUE_LOCATION , A.LAST_USED_DT , A.LAST_VERIFIED_DT , A.SOURCE_IDENT_TP_CD, A.XMODIFY_SYS_DT, A.XRETAILER_ID, A.XIDEN_RETAILER_FLAG, A.X_BPID" + 
     " FROM H_IDENTIFIER A" + 
     " WHERE A.CONT_ID = ? AND (( ? BETWEEN A.H_CREATE_DT AND A.H_END_DT ) OR ( ? >= A.H_CREATE_DT AND A.H_END_DT IS NULL ))";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyIdentifiersHistoryParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.histCreateDt=H_CREATE_DT"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyIdentifiersHistoryResults =
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.historyIdPK=HIST_ID_PK," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.histActionCode=H_ACTION_CODE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.histCreatedBy=H_CREATED_BY," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.histEndDt=H_END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.identifierIdPK=IDENTIFIER_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.idStatusTpCd=ID_STATUS_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.idTpCd=ID_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.refNum=REF_NUM," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.startDt=START_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.endDt=END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.expiryDt=EXPIRY_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.assignedBy=ASSIGNED_BY," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.identifierDesc=IDENTIFIER_DESC," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.issueLocation=ISSUE_LOCATION," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.lastUsedDt=LAST_USED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.lastVerifiedDt=LAST_VERIFIED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.sourceIdentTpCd=SOURCE_IDENT_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt.XLastModifiedSystemDate=XMODIFY_SYS_DT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt.XRetailerId=XRETAILER_ID," + 
    "com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt.XIdentifierRetailerFlag=XIDEN_RETAILER_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt.X_BPID=X_BPID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension
   * XIdentifier.
   *
   * @generated
   */ 
   public final static String getPartyIdentifiersActiveSQL = "SELECT IDENTIFIER.IDENTIFIER_ID , IDENTIFIER.ID_STATUS_TP_CD , IDENTIFIER.CONT_ID , IDENTIFIER.ID_TP_CD , IDENTIFIER.REF_NUM , IDENTIFIER.START_DT , IDENTIFIER.END_DT , IDENTIFIER.EXPIRY_DT , IDENTIFIER.LAST_UPDATE_DT ,IDENTIFIER.LAST_UPDATE_USER, IDENTIFIER.LAST_UPDATE_TX_ID , IDENTIFIER.ASSIGNED_BY , IDENTIFIER.IDENTIFIER_DESC , IDENTIFIER.ISSUE_LOCATION , IDENTIFIER.LAST_USED_DT , IDENTIFIER.LAST_VERIFIED_DT , IDENTIFIER.SOURCE_IDENT_TP_CD, IDENTIFIER.XMODIFY_SYS_DT, IDENTIFIER.XRETAILER_ID, IDENTIFIER.XIDEN_RETAILER_FLAG, IDENTIFIER.X_BPID" + 
     " FROM IDENTIFIER" + 
     " WHERE ((IDENTIFIER.CONT_ID = ? ) AND ((IDENTIFIER.END_DT IS NULL) OR (IDENTIFIER.END_DT > ? )))";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyIdentifiersActiveParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.endDt=END_DT"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyIdentifiersActiveResults =
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.identifierIdPK=IDENTIFIER_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.idStatusTpCd=ID_STATUS_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.idTpCd=ID_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.refNum=REF_NUM," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.startDt=START_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.endDt=END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.expiryDt=EXPIRY_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.assignedBy=ASSIGNED_BY," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.identifierDesc=IDENTIFIER_DESC," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.issueLocation=ISSUE_LOCATION," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.lastUsedDt=LAST_USED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.lastVerifiedDt=LAST_VERIFIED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.sourceIdentTpCd=SOURCE_IDENT_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt.XLastModifiedSystemDate=XMODIFY_SYS_DT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt.XRetailerId=XRETAILER_ID," + 
    "com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt.XIdentifierRetailerFlag=XIDEN_RETAILER_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt.X_BPID=X_BPID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension
   * XIdentifier.
   *
   * @generated
   */ 
   public final static String getPartyIdentifiersInactiveSQL = "SELECT IDENTIFIER.IDENTIFIER_ID , IDENTIFIER.ID_STATUS_TP_CD , IDENTIFIER.CONT_ID , IDENTIFIER.ID_TP_CD , IDENTIFIER.REF_NUM , IDENTIFIER.START_DT, IDENTIFIER.END_DT , IDENTIFIER.EXPIRY_DT, IDENTIFIER.LAST_UPDATE_DT , IDENTIFIER.LAST_UPDATE_USER , IDENTIFIER.LAST_UPDATE_TX_ID , IDENTIFIER.ASSIGNED_BY , IDENTIFIER.IDENTIFIER_DESC , IDENTIFIER.ISSUE_LOCATION , IDENTIFIER.LAST_USED_DT , IDENTIFIER.LAST_VERIFIED_DT , IDENTIFIER.SOURCE_IDENT_TP_CD, IDENTIFIER.XMODIFY_SYS_DT, IDENTIFIER.XRETAILER_ID, IDENTIFIER.XIDEN_RETAILER_FLAG, IDENTIFIER.X_BPID" + 
     " FROM IDENTIFIER" + 
     " WHERE ((IDENTIFIER.CONT_ID = ? )AND (IDENTIFIER.END_DT < ?))";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyIdentifiersInactiveParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.endDt=END_DT"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyIdentifiersInactiveResults =
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.identifierIdPK=IDENTIFIER_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.idStatusTpCd=ID_STATUS_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.idTpCd=ID_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.refNum=REF_NUM," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.startDt=START_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.endDt=END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.expiryDt=EXPIRY_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.assignedBy=ASSIGNED_BY," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.identifierDesc=IDENTIFIER_DESC," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.issueLocation=ISSUE_LOCATION," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.lastUsedDt=LAST_USED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.lastVerifiedDt=LAST_VERIFIED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.sourceIdentTpCd=SOURCE_IDENT_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt.XLastModifiedSystemDate=XMODIFY_SYS_DT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt.XRetailerId=XRETAILER_ID," + 
    "com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt.XIdentifierRetailerFlag=XIDEN_RETAILER_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt.X_BPID=X_BPID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension
   * XIdentifier.
   *
   * @generated
   */ 
   public final static String getPartyIdentifiersAllSQL = "SELECT IDENTIFIER.IDENTIFIER_ID , IDENTIFIER.ID_STATUS_TP_CD , IDENTIFIER.CONT_ID , IDENTIFIER.ID_TP_CD , IDENTIFIER.REF_NUM , IDENTIFIER.START_DT , IDENTIFIER.END_DT , IDENTIFIER.EXPIRY_DT , IDENTIFIER.LAST_UPDATE_DT , IDENTIFIER.LAST_UPDATE_USER , IDENTIFIER.LAST_UPDATE_TX_ID , IDENTIFIER.ASSIGNED_BY , IDENTIFIER.IDENTIFIER_DESC , IDENTIFIER.ISSUE_LOCATION , IDENTIFIER.LAST_USED_DT , IDENTIFIER.LAST_VERIFIED_DT , IDENTIFIER.SOURCE_IDENT_TP_CD, IDENTIFIER.XMODIFY_SYS_DT, IDENTIFIER.XRETAILER_ID, IDENTIFIER.XIDEN_RETAILER_FLAG, IDENTIFIER.X_BPID" + 
     " FROM IDENTIFIER" + 
     " WHERE IDENTIFIER.CONT_ID = ?";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyIdentifiersAllParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.contId=CONT_ID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyIdentifiersAllResults =
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.identifierIdPK=IDENTIFIER_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.idStatusTpCd=ID_STATUS_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.idTpCd=ID_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.refNum=REF_NUM," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.startDt=START_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.endDt=END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.expiryDt=EXPIRY_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.assignedBy=ASSIGNED_BY," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.identifierDesc=IDENTIFIER_DESC," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.issueLocation=ISSUE_LOCATION," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.lastUsedDt=LAST_USED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.lastVerifiedDt=LAST_VERIFIED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.sourceIdentTpCd=SOURCE_IDENT_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt.XLastModifiedSystemDate=XMODIFY_SYS_DT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt.XRetailerId=XRETAILER_ID," + 
    "com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt.XIdentifierRetailerFlag=XIDEN_RETAILER_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt.X_BPID=X_BPID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension
   * XIdentifier.
   *
   * @generated
   */ 
   public final static String getPartyIdentifierByIdSQL = "SELECT IDENTIFIER.IDENTIFIER_ID , IDENTIFIER.ID_STATUS_TP_CD , IDENTIFIER.CONT_ID , IDENTIFIER.ID_TP_CD , IDENTIFIER.REF_NUM , IDENTIFIER.START_DT , IDENTIFIER.END_DT , IDENTIFIER.EXPIRY_DT , IDENTIFIER.LAST_UPDATE_DT , IDENTIFIER.LAST_UPDATE_USER , IDENTIFIER.LAST_UPDATE_TX_ID , IDENTIFIER.ASSIGNED_BY , IDENTIFIER.IDENTIFIER_DESC , IDENTIFIER.ISSUE_LOCATION , IDENTIFIER.LAST_USED_DT , IDENTIFIER.LAST_VERIFIED_DT , IDENTIFIER.SOURCE_IDENT_TP_CD, IDENTIFIER.XMODIFY_SYS_DT, IDENTIFIER.XRETAILER_ID, IDENTIFIER.XIDEN_RETAILER_FLAG, IDENTIFIER.X_BPID" + 
     " FROM IDENTIFIER" + 
     " WHERE (IDENTIFIER.IDENTIFIER_ID = ?)";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyIdentifierByIdParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.identifierIdPK=IDENTIFIER_ID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyIdentifierByIdResults =
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.identifierIdPK=IDENTIFIER_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.idStatusTpCd=ID_STATUS_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.idTpCd=ID_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.refNum=REF_NUM," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.startDt=START_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.endDt=END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.expiryDt=EXPIRY_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.assignedBy=ASSIGNED_BY," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.identifierDesc=IDENTIFIER_DESC," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.issueLocation=ISSUE_LOCATION," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.lastUsedDt=LAST_USED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.lastVerifiedDt=LAST_VERIFIED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.sourceIdentTpCd=SOURCE_IDENT_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt.XLastModifiedSystemDate=XMODIFY_SYS_DT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt.XRetailerId=XRETAILER_ID," + 
    "com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt.XIdentifierRetailerFlag=XIDEN_RETAILER_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt.X_BPID=X_BPID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension
   * XIdentifier.
   *
   * @generated
   */ 
   public final static String getPartyIdentifierHistoryByIdSQL = "SELECT A.H_IDENTIFIER_ID AS HIST_ID_PK, A.H_ACTION_CODE , A.H_CREATED_BY , A.H_CREATE_DT ,A.H_END_DT ,A.IDENTIFIER_ID ,A.ID_STATUS_TP_CD ,A.CONT_ID , A.ID_TP_CD,A.REF_NUM ,A.START_DT ,A.END_DT ,A.EXPIRY_DT , A.LAST_UPDATE_DT , A.LAST_UPDATE_USER , A.LAST_UPDATE_TX_ID , A.ASSIGNED_BY , A.IDENTIFIER_DESC , A.ISSUE_LOCATION, A.LAST_USED_DT , A.LAST_VERIFIED_DT , A.SOURCE_IDENT_TP_CD, A.XMODIFY_SYS_DT, A.XRETAILER_ID, A.XIDEN_RETAILER_FLAG, A.X_BPID" + 
     " FROM H_IDENTIFIER A" + 
     " WHERE H_IDENTIFIER_ID = ? AND (( ? BETWEEN A.H_CREATE_DT AND A.H_END_DT ) OR ( ? >= A.H_CREATE_DT AND A.H_END_DT IS NULL ))";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyIdentifierHistoryByIdParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.historyIdPK=H_IDENTIFIER_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.histCreateDt=H_CREATE_DT"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyIdentifierHistoryByIdResults =
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.historyIdPK=HIST_ID_PK," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.histActionCode=H_ACTION_CODE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.histCreatedBy=H_CREATED_BY," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.histEndDt=H_END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.identifierIdPK=IDENTIFIER_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.idStatusTpCd=ID_STATUS_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.idTpCd=ID_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.refNum=REF_NUM," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.startDt=START_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.endDt=END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.expiryDt=EXPIRY_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.assignedBy=ASSIGNED_BY," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.identifierDesc=IDENTIFIER_DESC," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.issueLocation=ISSUE_LOCATION," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.lastUsedDt=LAST_USED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.lastVerifiedDt=LAST_VERIFIED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.sourceIdentTpCd=SOURCE_IDENT_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt.XLastModifiedSystemDate=XMODIFY_SYS_DT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt.XRetailerId=XRETAILER_ID," + 
    "com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt.XIdentifierRetailerFlag=XIDEN_RETAILER_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt.X_BPID=X_BPID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension
   * XIdentifier.
   *
   * @generated
   */ 
   public final static String getPartyIdentifierImageSQL = "SELECT DISTINCT A.H_IDENTIFIER_ID AS HIST_ID_PK, A.H_ACTION_CODE , A.H_CREATED_BY, A.H_CREATE_DT , A.H_END_DT , A.IDENTIFIER_ID , A.ID_STATUS_TP_CD , A.CONT_ID , A.ID_TP_CD , A.REF_NUM , A.START_DT , A.END_DT , A.EXPIRY_DT , A.LAST_UPDATE_DT , A.LAST_UPDATE_USER , A.LAST_UPDATE_TX_ID , A.ASSIGNED_BY , A.IDENTIFIER_DESC , A.ISSUE_LOCATION, A.LAST_USED_DT , A.LAST_VERIFIED_DT , A.SOURCE_IDENT_TP_CD, A.XMODIFY_SYS_DT, A.XRETAILER_ID, A.XIDEN_RETAILER_FLAG, A.X_BPID" + 
     " FROM H_IDENTIFIER A" + 
     " WHERE A.CONT_ID = ? AND ( A.H_CREATE_DT BETWEEN ? AND ? )";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyIdentifierImageParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.histCreateDt=H_CREATE_DT"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyIdentifierImageResults =
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.historyIdPK=HIST_ID_PK," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.histActionCode=H_ACTION_CODE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.histCreatedBy=H_CREATED_BY," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.histEndDt=H_END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.identifierIdPK=IDENTIFIER_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.idStatusTpCd=ID_STATUS_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.idTpCd=ID_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.refNum=REF_NUM," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.startDt=START_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.endDt=END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.expiryDt=EXPIRY_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.assignedBy=ASSIGNED_BY," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.identifierDesc=IDENTIFIER_DESC," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.issueLocation=ISSUE_LOCATION," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.lastUsedDt=LAST_USED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.lastVerifiedDt=LAST_VERIFIED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.sourceIdentTpCd=SOURCE_IDENT_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt.XLastModifiedSystemDate=XMODIFY_SYS_DT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt.XRetailerId=XRETAILER_ID," + 
    "com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt.XIdentifierRetailerFlag=XIDEN_RETAILER_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt.X_BPID=X_BPID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension
   * XIdentifier.
   *
   * @generated
   */ 
   public final static String getPartyIdentificationLightImagesSQL = "SELECT DISTINCT A.IDENTIFIER_ID , A.LAST_UPDATE_DT, A.XMODIFY_SYS_DT, A.XRETAILER_ID, A.XIDEN_RETAILER_FLAG, A.X_BPID" + 
     " FROM H_IDENTIFIER A" + 
     " WHERE A.CONT_ID = ? AND ( A.H_CREATE_DT BETWEEN ? AND ? )";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyIdentificationLightImagesParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.histCreateDt=H_CREATE_DT"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyIdentificationLightImagesResults =
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.identifierIdPK=IDENTIFIER_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt.XLastModifiedSystemDate=XMODIFY_SYS_DT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt.XRetailerId=XRETAILER_ID," + 
    "com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt.XIdentifierRetailerFlag=XIDEN_RETAILER_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt.X_BPID=X_BPID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension
   * XIdentifier.
   *
   * @generated
   */ 
   public final static String getPartyIdentifiersByAssignedByHistorySQL = "SELECT DISTINCT A.H_IDENTIFIER_ID AS HIST_ID_PK, A.H_ACTION_CODE , A.H_CREATED_BY , A.H_CREATE_DT ,A.H_END_DT ,A.IDENTIFIER_ID ,A.ID_STATUS_TP_CD ,A.CONT_ID , A.ID_TP_CD ,A.REF_NUM ,A.START_DT,A.END_DT ,A.EXPIRY_DT , A.LAST_UPDATE_DT , A.LAST_UPDATE_USER , A.LAST_UPDATE_TX_ID , A.ASSIGNED_BY , A.IDENTIFIER_DESC , A.ISSUE_LOCATION, A.XMODIFY_SYS_DT, A.XRETAILER_ID, A.XIDEN_RETAILER_FLAG, A.X_BPID" + 
     " FROM H_IDENTIFIER A" + 
     " WHERE A.ASSIGNED_BY = ? AND (( ? BETWEEN A.H_CREATE_DT AND A.H_END_DT ) OR ( ? >= A.H_CREATE_DT AND A.H_END_DT IS NULL ))";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyIdentifiersByAssignedByHistoryParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.assignedBy=ASSIGNED_BY," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.histCreateDt=H_CREATE_DT"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyIdentifiersByAssignedByHistoryResults =
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.historyIdPK=HIST_ID_PK," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.histActionCode=H_ACTION_CODE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.histCreatedBy=H_CREATED_BY," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.histEndDt=H_END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.identifierIdPK=IDENTIFIER_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.idStatusTpCd=ID_STATUS_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.idTpCd=ID_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.refNum=REF_NUM," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.startDt=START_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.endDt=END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.expiryDt=EXPIRY_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.assignedBy=ASSIGNED_BY," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.identifierDesc=IDENTIFIER_DESC," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.issueLocation=ISSUE_LOCATION," + 
    "com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt.XLastModifiedSystemDate=XMODIFY_SYS_DT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt.XRetailerId=XRETAILER_ID," + 
    "com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt.XIdentifierRetailerFlag=XIDEN_RETAILER_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt.X_BPID=X_BPID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension
   * XIdentifier.
   *
   * @generated
   */ 
   public final static String getPartyIdentifiersByAssignedByActiveSQL = "SELECT IDENTIFIER.IDENTIFIER_ID , IDENTIFIER.ID_STATUS_TP_CD , IDENTIFIER.CONT_ID , IDENTIFIER.ID_TP_CD , IDENTIFIER.REF_NUM , IDENTIFIER.START_DT , IDENTIFIER.END_DT, IDENTIFIER.EXPIRY_DT , IDENTIFIER.LAST_UPDATE_DT ,IDENTIFIER.LAST_UPDATE_USER , IDENTIFIER.LAST_UPDATE_TX_ID, IDENTIFIER.ASSIGNED_BY , IDENTIFIER.IDENTIFIER_DESC , IDENTIFIER.ISSUE_LOCATION, IDENTIFIER.XMODIFY_SYS_DT, IDENTIFIER.XRETAILER_ID, IDENTIFIER.XIDEN_RETAILER_FLAG, IDENTIFIER.X_BPID" + 
     " FROM IDENTIFIER" + 
     " WHERE ((IDENTIFIER.ASSIGNED_BY = ? ) AND ((IDENTIFIER.END_DT IS NULL) OR (IDENTIFIER.END_DT > ? )))";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyIdentifiersByAssignedByActiveParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.assignedBy=ASSIGNED_BY," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.endDt=END_DT"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyIdentifiersByAssignedByActiveResults =
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.identifierIdPK=IDENTIFIER_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.idStatusTpCd=ID_STATUS_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.idTpCd=ID_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.refNum=REF_NUM," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.startDt=START_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.endDt=END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.expiryDt=EXPIRY_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.assignedBy=ASSIGNED_BY," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.identifierDesc=IDENTIFIER_DESC," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.issueLocation=ISSUE_LOCATION," + 
    "com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt.XLastModifiedSystemDate=XMODIFY_SYS_DT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt.XRetailerId=XRETAILER_ID," + 
    "com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt.XIdentifierRetailerFlag=XIDEN_RETAILER_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt.X_BPID=X_BPID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension
   * XIdentifier.
   *
   * @generated
   */ 
   public final static String getPartyIdentifiersByAssignedByInactiveSQL = "SELECT IDENTIFIER.IDENTIFIER_ID , IDENTIFIER.ID_STATUS_TP_CD , IDENTIFIER.CONT_ID , IDENTIFIER.ID_TP_CD , IDENTIFIER.REF_NUM , IDENTIFIER.START_DT , IDENTIFIER.END_DT , IDENTIFIER.EXPIRY_DT , IDENTIFIER.LAST_UPDATE_DT , IDENTIFIER.LAST_UPDATE_USER , IDENTIFIER.LAST_UPDATE_TX_ID , IDENTIFIER.ASSIGNED_BY , IDENTIFIER.IDENTIFIER_DESC , IDENTIFIER.ISSUE_LOCATION, IDENTIFIER.XMODIFY_SYS_DT, IDENTIFIER.XRETAILER_ID, IDENTIFIER.XIDEN_RETAILER_FLAG, IDENTIFIER.X_BPID" + 
     " FROM IDENTIFIER" + 
     " WHERE ((IDENTIFIER.ASSIGNED_BY = ? )AND (IDENTIFIER.END_DT < ?))";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyIdentifiersByAssignedByInactiveParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.assignedBy=ASSIGNED_BY," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.endDt=END_DT"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyIdentifiersByAssignedByInactiveResults =
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.identifierIdPK=IDENTIFIER_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.idStatusTpCd=ID_STATUS_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.idTpCd=ID_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.refNum=REF_NUM," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.startDt=START_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.endDt=END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.expiryDt=EXPIRY_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.assignedBy=ASSIGNED_BY," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.identifierDesc=IDENTIFIER_DESC," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.issueLocation=ISSUE_LOCATION," + 
    "com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt.XLastModifiedSystemDate=XMODIFY_SYS_DT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt.XRetailerId=XRETAILER_ID," + 
    "com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt.XIdentifierRetailerFlag=XIDEN_RETAILER_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt.X_BPID=X_BPID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension
   * XIdentifier.
   *
   * @generated
   */ 
   public final static String getPartyIdentifiersByAssignedByAllSQL = "SELECT IDENTIFIER.IDENTIFIER_ID , IDENTIFIER.ID_STATUS_TP_CD , IDENTIFIER.CONT_ID , IDENTIFIER.ID_TP_CD , IDENTIFIER.REF_NUM , IDENTIFIER.START_DT , IDENTIFIER.END_DT, IDENTIFIER.EXPIRY_DT , IDENTIFIER.LAST_UPDATE_DT , IDENTIFIER.LAST_UPDATE_USER , IDENTIFIER.LAST_UPDATE_TX_ID , IDENTIFIER.ASSIGNED_BY , IDENTIFIER.IDENTIFIER_DESC , IDENTIFIER.ISSUE_LOCATION ,IDENTIFIER.LAST_USED_DT , IDENTIFIER.LAST_VERIFIED_DT , IDENTIFIER.SOURCE_IDENT_TP_CD, IDENTIFIER.XMODIFY_SYS_DT, IDENTIFIER.XRETAILER_ID, IDENTIFIER.XIDEN_RETAILER_FLAG, IDENTIFIER.X_BPID" + 
     " FROM IDENTIFIER" + 
     " WHERE IDENTIFIER.ASSIGNED_BY = ?";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyIdentifiersByAssignedByAllParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.assignedBy=ASSIGNED_BY"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyIdentifiersByAssignedByAllResults =
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.identifierIdPK=IDENTIFIER_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.idStatusTpCd=ID_STATUS_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.idTpCd=ID_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.refNum=REF_NUM," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.startDt=START_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.endDt=END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.expiryDt=EXPIRY_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.assignedBy=ASSIGNED_BY," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.identifierDesc=IDENTIFIER_DESC," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.issueLocation=ISSUE_LOCATION," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.lastUsedDt=LAST_USED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.lastVerifiedDt=LAST_VERIFIED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.sourceIdentTpCd=SOURCE_IDENT_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt.XLastModifiedSystemDate=XMODIFY_SYS_DT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt.XRetailerId=XRETAILER_ID," + 
    "com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt.XIdentifierRetailerFlag=XIDEN_RETAILER_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt.X_BPID=X_BPID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension
   * XIdentifier.
   *
   * @generated
   */ 
   public final static String getPartyIdentifierMacroRoleSQL = "SELECT I.IDENTIFIER_ID , I.ID_STATUS_TP_CD , I.CONT_ID , I.ID_TP_CD , I.REF_NUM, I.START_DT , I.END_DT , I.EXPIRY_DT , I.LAST_UPDATE_DT ,I.LAST_UPDATE_USER , I.LAST_UPDATE_TX_ID , I.ASSIGNED_BY , I.IDENTIFIER_DESC , I.ISSUE_LOCATION , I.LAST_USED_DT , I.LAST_VERIFIED_DT, I.SOURCE_IDENT_TP_CD, I.XMODIFY_SYS_DT, I.XRETAILER_ID, I.XIDEN_RETAILER_FLAG, I.X_BPID" + 
     " FROM IDENTIFIER I, CONTMACROROLE MR, MACROROLEASSOC MRA" + 
     " WHERE I.CONT_ID = MR.CONT_ID AND MR.CONT_MACRO_ROLE_ID = MRA.CONT_MACRO_ROLE_ID AND UPPER(MRA.ENTITY_NAME) = 'IDENTIFIER' AND I.IDENTIFIER_ID = MRA.INSTANCE_PK AND I.CONT_ID = ? AND I.ID_TP_CD = ? AND MR.ROLE_TP_CD=? AND (I.END_DT IS NULL OR I.END_DT > ?)";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyIdentifierMacroRoleParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.idTpCd=ID_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContMacroRole.roleType=ROLE_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.endDt=END_DT"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyIdentifierMacroRoleResults =
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.identifierIdPK=IDENTIFIER_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.idStatusTpCd=ID_STATUS_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.idTpCd=ID_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.refNum=REF_NUM," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.startDt=START_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.endDt=END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.expiryDt=EXPIRY_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.assignedBy=ASSIGNED_BY," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.identifierDesc=IDENTIFIER_DESC," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.issueLocation=ISSUE_LOCATION," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.lastUsedDt=LAST_USED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.lastVerifiedDt=LAST_VERIFIED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjIdentifier.sourceIdentTpCd=SOURCE_IDENT_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt.XLastModifiedSystemDate=XMODIFY_SYS_DT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt.XRetailerId=XRETAILER_ID," + 
    "com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt.XIdentifierRetailerFlag=XIDEN_RETAILER_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt.X_BPID=X_BPID"; 


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getPartyIdentifiersHistoryByTypeSQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getPartyIdentifiersHistoryByTypeParameters, results=getPartyIdentifiersHistoryByTypeResults)
  		Iterator<ResultQueue2<EObjIdentifier, EObjXIdentifierExt>> getPartyIdentifiersHistoryByType(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getPartyIdentifiersByTypeSQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getPartyIdentifiersByTypeParameters, results=getPartyIdentifiersByTypeResults)
  		Iterator<ResultQueue2<EObjIdentifier, EObjXIdentifierExt>> getPartyIdentifiersByType(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getPartyIdentifiersHistorySQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getPartyIdentifiersHistoryParameters, results=getPartyIdentifiersHistoryResults)
  		Iterator<ResultQueue2<EObjIdentifier, EObjXIdentifierExt>> getPartyIdentifiersHistory(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getPartyIdentifiersActiveSQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getPartyIdentifiersActiveParameters, results=getPartyIdentifiersActiveResults)
  		Iterator<ResultQueue2<EObjIdentifier, EObjXIdentifierExt>> getPartyIdentifiersActive(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getPartyIdentifiersInactiveSQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getPartyIdentifiersInactiveParameters, results=getPartyIdentifiersInactiveResults)
  		Iterator<ResultQueue2<EObjIdentifier, EObjXIdentifierExt>> getPartyIdentifiersInactive(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getPartyIdentifiersAllSQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getPartyIdentifiersAllParameters, results=getPartyIdentifiersAllResults)
  		Iterator<ResultQueue2<EObjIdentifier, EObjXIdentifierExt>> getPartyIdentifiersAll(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getPartyIdentifierByIdSQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getPartyIdentifierByIdParameters, results=getPartyIdentifierByIdResults)
  		Iterator<ResultQueue2<EObjIdentifier, EObjXIdentifierExt>> getPartyIdentifierById(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getPartyIdentifierHistoryByIdSQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getPartyIdentifierHistoryByIdParameters, results=getPartyIdentifierHistoryByIdResults)
  		Iterator<ResultQueue2<EObjIdentifier, EObjXIdentifierExt>> getPartyIdentifierHistoryById(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getPartyIdentifierImageSQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getPartyIdentifierImageParameters, results=getPartyIdentifierImageResults)
  		Iterator<ResultQueue2<EObjIdentifier, EObjXIdentifierExt>> getPartyIdentifierImage(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getPartyIdentificationLightImagesSQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getPartyIdentificationLightImagesParameters, results=getPartyIdentificationLightImagesResults)
  		Iterator<ResultQueue2<EObjIdentifier, EObjXIdentifierExt>> getPartyIdentificationLightImages(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getPartyIdentifiersByAssignedByHistorySQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getPartyIdentifiersByAssignedByHistoryParameters, results=getPartyIdentifiersByAssignedByHistoryResults)
  		Iterator<ResultQueue2<EObjIdentifier, EObjXIdentifierExt>> getPartyIdentifiersByAssignedByHistory(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getPartyIdentifiersByAssignedByActiveSQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getPartyIdentifiersByAssignedByActiveParameters, results=getPartyIdentifiersByAssignedByActiveResults)
  		Iterator<ResultQueue2<EObjIdentifier, EObjXIdentifierExt>> getPartyIdentifiersByAssignedByActive(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getPartyIdentifiersByAssignedByInactiveSQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getPartyIdentifiersByAssignedByInactiveParameters, results=getPartyIdentifiersByAssignedByInactiveResults)
  		Iterator<ResultQueue2<EObjIdentifier, EObjXIdentifierExt>> getPartyIdentifiersByAssignedByInactive(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getPartyIdentifiersByAssignedByAllSQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getPartyIdentifiersByAssignedByAllParameters, results=getPartyIdentifiersByAssignedByAllResults)
  		Iterator<ResultQueue2<EObjIdentifier, EObjXIdentifierExt>> getPartyIdentifiersByAssignedByAll(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getPartyIdentifierMacroRoleSQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getPartyIdentifierMacroRoleParameters, results=getPartyIdentifierMacroRoleResults)
  		Iterator<ResultQueue2<EObjIdentifier, EObjXIdentifierExt>> getPartyIdentifierMacroRole(Object[] parameters);
 
}


