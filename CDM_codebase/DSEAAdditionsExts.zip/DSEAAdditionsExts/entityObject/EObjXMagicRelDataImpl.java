package com.ibm.daimler.dsea.entityObject;

import com.ibm.pdq.runtime.generator.BaseParameterHandler;
import java.util.Iterator;
import java.sql.PreparedStatement;
import com.ibm.pdq.runtime.statement.StatementDescriptor;
import com.ibm.pdq.runtime.generator.BaseData;
import java.sql.SQLException;
import com.ibm.pdq.annotation.Metadata;
import com.ibm.daimler.dsea.entityObject.EObjXMagicRel;
import com.ibm.pdq.runtime.generator.BaseRowHandler;
import com.ibm.pdq.runtime.statement.SqlStatementType;
import java.sql.Types;


/**
 * <!-- begin-user-doc -->
 * 
 * <!-- end-user-doc -->
 * 
 * @generated
 */
public class EObjXMagicRelDataImpl  extends BaseData implements EObjXMagicRelData
{

  /**
   * @generated
   */
  public static final String generatorVersion = "3.200.75";

  /**
   * @generated
   */
  public static final String identifier = "EObjXMagicRelData";

  /**
   * @generated
   */
  public static final long generationTime = 0x000001635e6606d0L;

  /**
   * @generated
   */
  public static final String collection = "NULLID";

  /**
   * @generated
   */
  public static final String packageVersion = null;

  /**
   * @generated
   */
  public static final boolean forceSingleBindIsolation = false;

  /**
   * @generated
   */
  public EObjXMagicRelDataImpl()
  {
    super();
  } 

  /**
   * @generated
   */
  public String getGeneratorVersion()
  {
    return generatorVersion;
  }

  /**
   * @Select( sql="select XMagic_Relpk_Id, UCID, Golden_Magic, Old_Magic, Old_Magic_Retailer, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from XMAGICREL where XMagic_Relpk_Id = ? " )
   * 
   * @generated
   */
  public Iterator<EObjXMagicRel> getEObjXMagicRel (Long xMagicRelpkId)
  {
    return queryIterator (getEObjXMagicRelStatementDescriptor, xMagicRelpkId);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getEObjXMagicRelStatementDescriptor = createStatementDescriptor (
    "getEObjXMagicRel(Long)",
    "select XMagic_Relpk_Id, UCID, Golden_Magic, Old_Magic, Old_Magic_Retailer, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from XMAGICREL where XMagic_Relpk_Id = ? ",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"xmagic_relpk_id", "ucid", "golden_magic", "old_magic", "old_magic_retailer", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetEObjXMagicRelParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetEObjXMagicRelRowHandler (),
    new int[][]{ {Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 250, 250, 250, 250, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    1);

  /**
   * @generated
   */
  public static class GetEObjXMagicRelParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setLong (stmt, 1, Types.BIGINT, (Long)parameters[0]);
    }
  }

  /**
   * @generated
   */
  public static class GetEObjXMagicRelRowHandler extends BaseRowHandler<EObjXMagicRel>
  {
    /**
     * @generated
     */
    public EObjXMagicRel handle (java.sql.ResultSet rs, EObjXMagicRel returnObject) throws java.sql.SQLException
    {
      returnObject = new EObjXMagicRel ();
      returnObject.setXMagicRelpkId(getLongObject (rs, 1)); 
      returnObject.setUCID(getString (rs, 2)); 
      returnObject.setGoldenMagic(getString (rs, 3)); 
      returnObject.setOldMagic(getString (rs, 4)); 
      returnObject.setOldMagicRetailer(getString (rs, 5)); 
      returnObject.setLastUpdateDt(getTimestamp (rs, 6)); 
      returnObject.setLastUpdateUser(getString (rs, 7)); 
      returnObject.setLastUpdateTxId(getLongObject (rs, 8)); 
    
      return returnObject;
    }
  }

  /**
   * @Update( sql="insert into XMAGICREL (XMagic_Relpk_Id, UCID, Golden_Magic, Old_Magic, Old_Magic_Retailer, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( :xMagicRelpkId, :uCID, :goldenMagic, :oldMagic, :oldMagicRetailer, :lastUpdateDt, :lastUpdateUser, :lastUpdateTxId)" )
   * 
   * @generated
   */
  public int createEObjXMagicRel (EObjXMagicRel e)
  {
    return update (createEObjXMagicRelStatementDescriptor, e);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor createEObjXMagicRelStatementDescriptor = createStatementDescriptor (
    "createEObjXMagicRel(com.ibm.daimler.dsea.entityObject.EObjXMagicRel)",
    "insert into XMAGICREL (XMagic_Relpk_Id, UCID, Golden_Magic, Old_Magic, Old_Magic_Retailer, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values(  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? )",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.INSERT,
    null,
    new CreateEObjXMagicRelParameterHandler (),
    new int[][]{{Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 250, 250, 250, 250, 0, 0, 19}, {0, 0, 0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1, 1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    2);

  /**
   * @generated
   */
  public static class CreateEObjXMagicRelParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      EObjXMagicRel bean0 = (EObjXMagicRel) parameters[0];
      setLong (stmt, 1, Types.BIGINT, (Long)bean0.getXMagicRelpkId());
      setString (stmt, 2, Types.VARCHAR, (String)bean0.getUCID());
      setString (stmt, 3, Types.VARCHAR, (String)bean0.getGoldenMagic());
      setString (stmt, 4, Types.VARCHAR, (String)bean0.getOldMagic());
      setString (stmt, 5, Types.VARCHAR, (String)bean0.getOldMagicRetailer());
      setTimestamp (stmt, 6, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUpdateDt());
      setString (stmt, 7, Types.VARCHAR, (String)bean0.getLastUpdateUser());
      setLong (stmt, 8, Types.BIGINT, (Long)bean0.getLastUpdateTxId());
    }
  }

  /**
   * @Update( sql="update XMAGICREL set UCID = :uCID, Golden_Magic = :goldenMagic, Old_Magic = :oldMagic, Old_Magic_Retailer = :oldMagicRetailer, LAST_UPDATE_DT = :lastUpdateDt, LAST_UPDATE_USER = :lastUpdateUser, LAST_UPDATE_TX_ID = :lastUpdateTxId where XMagic_Relpk_Id = :xMagicRelpkId and LAST_UPDATE_DT = :oldLastUpdateDt" )
   * 
   * @generated
   */
  public int updateEObjXMagicRel (EObjXMagicRel e)
  {
    return update (updateEObjXMagicRelStatementDescriptor, e);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor updateEObjXMagicRelStatementDescriptor = createStatementDescriptor (
    "updateEObjXMagicRel(com.ibm.daimler.dsea.entityObject.EObjXMagicRel)",
    "update XMAGICREL set UCID =  ? , Golden_Magic =  ? , Old_Magic =  ? , Old_Magic_Retailer =  ? , LAST_UPDATE_DT =  ? , LAST_UPDATE_USER =  ? , LAST_UPDATE_TX_ID =  ?  where XMagic_Relpk_Id =  ?  and LAST_UPDATE_DT =  ? ",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.UPDATE,
    null,
    new UpdateEObjXMagicRelParameterHandler (),
    new int[][]{{Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP}, {250, 250, 250, 250, 0, 0, 19, 19, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1, 1, 1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    3);

  /**
   * @generated
   */
  public static class UpdateEObjXMagicRelParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      EObjXMagicRel bean0 = (EObjXMagicRel) parameters[0];
      setString (stmt, 1, Types.VARCHAR, (String)bean0.getUCID());
      setString (stmt, 2, Types.VARCHAR, (String)bean0.getGoldenMagic());
      setString (stmt, 3, Types.VARCHAR, (String)bean0.getOldMagic());
      setString (stmt, 4, Types.VARCHAR, (String)bean0.getOldMagicRetailer());
      setTimestamp (stmt, 5, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUpdateDt());
      setString (stmt, 6, Types.VARCHAR, (String)bean0.getLastUpdateUser());
      setLong (stmt, 7, Types.BIGINT, (Long)bean0.getLastUpdateTxId());
      setLong (stmt, 8, Types.BIGINT, (Long)bean0.getXMagicRelpkId());
      setTimestamp (stmt, 9, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getOldLastUpdateDt());
    }
  }

  /**
   * @Update( sql="delete from XMAGICREL where XMagic_Relpk_Id = ?" )
   * 
   * @generated
   */
  public int deleteEObjXMagicRel (Long xMagicRelpkId)
  {
    return update (deleteEObjXMagicRelStatementDescriptor, xMagicRelpkId);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor deleteEObjXMagicRelStatementDescriptor = createStatementDescriptor (
    "deleteEObjXMagicRel(Long)",
    "delete from XMAGICREL where XMagic_Relpk_Id = ?",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.DELETE,
    null,
    new DeleteEObjXMagicRelParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    4);

  /**
   * @generated
   */
  public static class DeleteEObjXMagicRelParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setLong (stmt, 1, Types.BIGINT, (Long)parameters[0]);
    }
  }

}
