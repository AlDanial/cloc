/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[62b865429c026b3f2e6aaf16e356269f]
 */

package com.ibm.daimler.dsea.entityObject;


import com.ibm.mdm.base.db.ResultQueue1;
import java.util.Iterator;
import com.ibm.mdm.base.db.EntityMapping;
import com.ibm.pdq.annotation.Select;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * @generated
 */
public interface XCustomerVehicleAusInquiryData {
  
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String tableAliasString = "tableAlias (" + 
                                            "XCUSTOMERVEHICLEAUS => com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleAus, " +
                                            "H_XCUSTOMERVEHICLEAUS => com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleAus" +
                                            ")";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getXCustomerVehicleAusSql = "SELECT r.XCustomer_Vehicle_Auspk_Id XCustomer_Vehicle_Auspk_Id, r.CONT_ID CONT_ID, r.VEHICLE_ID VEHICLE_ID, r.RETAILER_ID RETAILER_ID, r.PURCHASE_DT PURCHASE_DT, r.END_DT END_DT, r.MARKET_NAME MARKET_NAME, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XCUSTOMERVEHICLEAUS r WHERE r.XCustomer_Vehicle_Auspk_Id = ? ";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXCustomerVehicleAusParameters =
    "EObjXCustomerVehicleAus.XCustomerVehicleAuspkId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXCustomerVehicleAusResults =
    "EObjXCustomerVehicleAus.XCustomerVehicleAuspkId," +
    "EObjXCustomerVehicleAus.ContId," +
    "EObjXCustomerVehicleAus.VehicleId," +
    "EObjXCustomerVehicleAus.RetailerId," +
    "EObjXCustomerVehicleAus.PurchaseDate," +
    "EObjXCustomerVehicleAus.EndDate," +
    "EObjXCustomerVehicleAus.MarketName," +
    "EObjXCustomerVehicleAus.SourceIdentifier," +
    "EObjXCustomerVehicleAus.LastModifiedSystemDate," +
    "EObjXCustomerVehicleAus.lastUpdateDt," +
    "EObjXCustomerVehicleAus.lastUpdateUser," +
    "EObjXCustomerVehicleAus.lastUpdateTxId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getXCustomerVehicleAusHistorySql = "SELECT r.H_XCustomer_Vehicle_Auspk_Id hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.XCustomer_Vehicle_Auspk_Id XCustomer_Vehicle_Auspk_Id, r.CONT_ID CONT_ID, r.VEHICLE_ID VEHICLE_ID, r.RETAILER_ID RETAILER_ID, r.PURCHASE_DT PURCHASE_DT, r.END_DT END_DT, r.MARKET_NAME MARKET_NAME, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XCUSTOMERVEHICLEAUS r WHERE r.H_XCustomer_Vehicle_Auspk_Id = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXCustomerVehicleAusHistoryParameters =
    "EObjXCustomerVehicleAus.XCustomerVehicleAuspkId," +
    "EObjXCustomerVehicleAus.lastUpdateDt," +
    "EObjXCustomerVehicleAus.lastUpdateDt";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXCustomerVehicleAusHistoryResults =
    "EObjXCustomerVehicleAus.historyIdPK," +
    "EObjXCustomerVehicleAus.histActionCode," +
    "EObjXCustomerVehicleAus.histCreatedBy," +
    "EObjXCustomerVehicleAus.histCreateDt," +
    "EObjXCustomerVehicleAus.histEndDt," +
    "EObjXCustomerVehicleAus.XCustomerVehicleAuspkId," +
    "EObjXCustomerVehicleAus.ContId," +
    "EObjXCustomerVehicleAus.VehicleId," +
    "EObjXCustomerVehicleAus.RetailerId," +
    "EObjXCustomerVehicleAus.PurchaseDate," +
    "EObjXCustomerVehicleAus.EndDate," +
    "EObjXCustomerVehicleAus.MarketName," +
    "EObjXCustomerVehicleAus.SourceIdentifier," +
    "EObjXCustomerVehicleAus.LastModifiedSystemDate," +
    "EObjXCustomerVehicleAus.lastUpdateDt," +
    "EObjXCustomerVehicleAus.lastUpdateUser," +
    "EObjXCustomerVehicleAus.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getAllXCustomerVehicleAusByPartyIdSql = "SELECT r.XCustomer_Vehicle_Auspk_Id XCustomer_Vehicle_Auspk_Id, r.CONT_ID CONT_ID, r.VEHICLE_ID VEHICLE_ID, r.RETAILER_ID RETAILER_ID, r.PURCHASE_DT PURCHASE_DT, r.END_DT END_DT, r.MARKET_NAME MARKET_NAME, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XCUSTOMERVEHICLEAUS r WHERE r.CONT_ID = ? ";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getAllXCustomerVehicleAusByPartyIdParameters =
    "EObjXCustomerVehicleAus.ContId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getAllXCustomerVehicleAusByPartyIdResults =
    "EObjXCustomerVehicleAus.XCustomerVehicleAuspkId," +
    "EObjXCustomerVehicleAus.ContId," +
    "EObjXCustomerVehicleAus.VehicleId," +
    "EObjXCustomerVehicleAus.RetailerId," +
    "EObjXCustomerVehicleAus.PurchaseDate," +
    "EObjXCustomerVehicleAus.EndDate," +
    "EObjXCustomerVehicleAus.MarketName," +
    "EObjXCustomerVehicleAus.SourceIdentifier," +
    "EObjXCustomerVehicleAus.LastModifiedSystemDate," +
    "EObjXCustomerVehicleAus.lastUpdateDt," +
    "EObjXCustomerVehicleAus.lastUpdateUser," +
    "EObjXCustomerVehicleAus.lastUpdateTxId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getAllXCustomerVehicleAusByPartyIdHistorySql = "SELECT r.H_XCustomer_Vehicle_Auspk_Id hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.XCustomer_Vehicle_Auspk_Id XCustomer_Vehicle_Auspk_Id, r.CONT_ID CONT_ID, r.VEHICLE_ID VEHICLE_ID, r.RETAILER_ID RETAILER_ID, r.PURCHASE_DT PURCHASE_DT, r.END_DT END_DT, r.MARKET_NAME MARKET_NAME, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XCUSTOMERVEHICLEAUS r WHERE r.CONT_ID = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getAllXCustomerVehicleAusByPartyIdHistoryParameters =
    "EObjXCustomerVehicleAus.ContId," +
    "EObjXCustomerVehicleAus.lastUpdateDt," +
    "EObjXCustomerVehicleAus.lastUpdateDt";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getAllXCustomerVehicleAusByPartyIdHistoryResults =
    "EObjXCustomerVehicleAus.historyIdPK," +
    "EObjXCustomerVehicleAus.histActionCode," +
    "EObjXCustomerVehicleAus.histCreatedBy," +
    "EObjXCustomerVehicleAus.histCreateDt," +
    "EObjXCustomerVehicleAus.histEndDt," +
    "EObjXCustomerVehicleAus.XCustomerVehicleAuspkId," +
    "EObjXCustomerVehicleAus.ContId," +
    "EObjXCustomerVehicleAus.VehicleId," +
    "EObjXCustomerVehicleAus.RetailerId," +
    "EObjXCustomerVehicleAus.PurchaseDate," +
    "EObjXCustomerVehicleAus.EndDate," +
    "EObjXCustomerVehicleAus.MarketName," +
    "EObjXCustomerVehicleAus.SourceIdentifier," +
    "EObjXCustomerVehicleAus.LastModifiedSystemDate," +
    "EObjXCustomerVehicleAus.lastUpdateDt," +
    "EObjXCustomerVehicleAus.lastUpdateUser," +
    "EObjXCustomerVehicleAus.lastUpdateTxId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getAllXCustomerVehicleAusByVehicleIdSql = "SELECT r.XCustomer_Vehicle_Auspk_Id XCustomer_Vehicle_Auspk_Id, r.CONT_ID CONT_ID, r.VEHICLE_ID VEHICLE_ID, r.RETAILER_ID RETAILER_ID, r.PURCHASE_DT PURCHASE_DT, r.END_DT END_DT, r.MARKET_NAME MARKET_NAME, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XCUSTOMERVEHICLEAUS r WHERE r.VEHICLE_ID = ? ";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getAllXCustomerVehicleAusByVehicleIdParameters =
    "EObjXCustomerVehicleAus.VehicleId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getAllXCustomerVehicleAusByVehicleIdResults =
    "EObjXCustomerVehicleAus.XCustomerVehicleAuspkId," +
    "EObjXCustomerVehicleAus.ContId," +
    "EObjXCustomerVehicleAus.VehicleId," +
    "EObjXCustomerVehicleAus.RetailerId," +
    "EObjXCustomerVehicleAus.PurchaseDate," +
    "EObjXCustomerVehicleAus.EndDate," +
    "EObjXCustomerVehicleAus.MarketName," +
    "EObjXCustomerVehicleAus.SourceIdentifier," +
    "EObjXCustomerVehicleAus.LastModifiedSystemDate," +
    "EObjXCustomerVehicleAus.lastUpdateDt," +
    "EObjXCustomerVehicleAus.lastUpdateUser," +
    "EObjXCustomerVehicleAus.lastUpdateTxId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getAllXCustomerVehicleAusByVehicleIdHistorySql = "SELECT r.H_XCustomer_Vehicle_Auspk_Id hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.XCustomer_Vehicle_Auspk_Id XCustomer_Vehicle_Auspk_Id, r.CONT_ID CONT_ID, r.VEHICLE_ID VEHICLE_ID, r.RETAILER_ID RETAILER_ID, r.PURCHASE_DT PURCHASE_DT, r.END_DT END_DT, r.MARKET_NAME MARKET_NAME, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XCUSTOMERVEHICLEAUS r WHERE r.VEHICLE_ID = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getAllXCustomerVehicleAusByVehicleIdHistoryParameters =
    "EObjXCustomerVehicleAus.VehicleId," +
    "EObjXCustomerVehicleAus.lastUpdateDt," +
    "EObjXCustomerVehicleAus.lastUpdateDt";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getAllXCustomerVehicleAusByVehicleIdHistoryResults =
    "EObjXCustomerVehicleAus.historyIdPK," +
    "EObjXCustomerVehicleAus.histActionCode," +
    "EObjXCustomerVehicleAus.histCreatedBy," +
    "EObjXCustomerVehicleAus.histCreateDt," +
    "EObjXCustomerVehicleAus.histEndDt," +
    "EObjXCustomerVehicleAus.XCustomerVehicleAuspkId," +
    "EObjXCustomerVehicleAus.ContId," +
    "EObjXCustomerVehicleAus.VehicleId," +
    "EObjXCustomerVehicleAus.RetailerId," +
    "EObjXCustomerVehicleAus.PurchaseDate," +
    "EObjXCustomerVehicleAus.EndDate," +
    "EObjXCustomerVehicleAus.MarketName," +
    "EObjXCustomerVehicleAus.SourceIdentifier," +
    "EObjXCustomerVehicleAus.LastModifiedSystemDate," +
    "EObjXCustomerVehicleAus.lastUpdateDt," +
    "EObjXCustomerVehicleAus.lastUpdateUser," +
    "EObjXCustomerVehicleAus.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getXCustomerVehicleAusSql, pattern=tableAliasString)
  @EntityMapping(parameters=getXCustomerVehicleAusParameters, results=getXCustomerVehicleAusResults)
  Iterator<ResultQueue1<EObjXCustomerVehicleAus>> getXCustomerVehicleAus(Object[] parameters);  


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getXCustomerVehicleAusHistorySql, pattern=tableAliasString)
  @EntityMapping(parameters=getXCustomerVehicleAusHistoryParameters, results=getXCustomerVehicleAusHistoryResults)
  Iterator<ResultQueue1<EObjXCustomerVehicleAus>> getXCustomerVehicleAusHistory(Object[] parameters);


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getAllXCustomerVehicleAusByPartyIdSql, pattern=tableAliasString)
  @EntityMapping(parameters=getAllXCustomerVehicleAusByPartyIdParameters, results=getAllXCustomerVehicleAusByPartyIdResults)
  Iterator<ResultQueue1<EObjXCustomerVehicleAus>> getAllXCustomerVehicleAusByPartyId(Object[] parameters);


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getAllXCustomerVehicleAusByPartyIdHistorySql, pattern=tableAliasString)
  @EntityMapping(parameters=getAllXCustomerVehicleAusByPartyIdHistoryParameters, results=getAllXCustomerVehicleAusByPartyIdHistoryResults)
  Iterator<ResultQueue1<EObjXCustomerVehicleAus>> getAllXCustomerVehicleAusByPartyIdHistory(Object[] parameters);


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getAllXCustomerVehicleAusByVehicleIdSql, pattern=tableAliasString)
  @EntityMapping(parameters=getAllXCustomerVehicleAusByVehicleIdParameters, results=getAllXCustomerVehicleAusByVehicleIdResults)
  Iterator<ResultQueue1<EObjXCustomerVehicleAus>> getAllXCustomerVehicleAusByVehicleId(Object[] parameters);


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getAllXCustomerVehicleAusByVehicleIdHistorySql, pattern=tableAliasString)
  @EntityMapping(parameters=getAllXCustomerVehicleAusByVehicleIdHistoryParameters, results=getAllXCustomerVehicleAusByVehicleIdHistoryResults)
  Iterator<ResultQueue1<EObjXCustomerVehicleAus>> getAllXCustomerVehicleAusByVehicleIdHistory(Object[] parameters);  


}


