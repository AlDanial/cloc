package com.ibm.daimler.dsea.entityObject;

import com.ibm.pdq.runtime.generator.BaseParameterHandler;
import java.util.Iterator;
import com.dwl.tcrm.coreParty.entityObject.EObjPersonName;
import com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt;
import java.sql.PreparedStatement;
import com.ibm.pdq.runtime.statement.StatementDescriptor;
import com.ibm.pdq.runtime.generator.BaseData;
import java.sql.SQLException;
import com.ibm.pdq.annotation.Metadata;
import com.ibm.pdq.runtime.generator.BaseRowHandler;
import com.ibm.pdq.runtime.statement.SqlStatementType;
import java.sql.Types;


/**
 * <!-- begin-user-doc -->
 * 
 * <!-- end-user-doc -->
 * 
 * @generated
 */
public class EObjXPersonNameExtDataImpl  extends BaseData implements EObjXPersonNameExtData
{

  /**
   * @generated
   */
  public static final String generatorVersion = "3.200.75";

  /**
   * @generated
   */
  public static final String identifier = "EObjXPersonNameExtData";

  /**
   * @generated
   */
  public static final long generationTime = 0x0000015e13f83e04L;

  /**
   * @generated
   */
  public static final String collection = "NULLID";

  /**
   * @generated
   */
  public static final String packageVersion = null;

  /**
   * @generated
   */
  public static final boolean forceSingleBindIsolation = false;

  /**
   * @generated
   */
  public EObjXPersonNameExtDataImpl()
  {
    super();
  } 

  /**
   * @generated
   */
  public String getGeneratorVersion()
  {
    return generatorVersion;
  }

  /**
   * @Select( sql="select XMODIFY_SYS_DT, XGIVEN_NAME_ONE_LOCAL, XGIVEN_NAME_TWO_LOCAL, XLAST_NAME_LOCAL, XPERSONNAME_RETAILER_FLAG, X_BPID, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from PERSONNAME where PERSON_NAME_ID = ? " )
   * 
   * @generated
   */
  public Iterator<EObjXPersonNameExt> getEObjXPersonNameExt (Long personNameIdPK)
  {
    return queryIterator (getEObjXPersonNameExtStatementDescriptor, personNameIdPK);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getEObjXPersonNameExtStatementDescriptor = createStatementDescriptor (
    "getEObjXPersonNameExt(Long)",
    "select XMODIFY_SYS_DT, XGIVEN_NAME_ONE_LOCAL, XGIVEN_NAME_TWO_LOCAL, XLAST_NAME_LOCAL, XPERSONNAME_RETAILER_FLAG, X_BPID, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from PERSONNAME where PERSON_NAME_ID = ? ",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"xmodify_sys_dt", "xgiven_name_one_local", "xgiven_name_two_local", "xlast_name_local", "xpersonname_retailer_flag", "x_bpid", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetEObjXPersonNameExtParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetEObjXPersonNameExtRowHandler (),
    new int[][]{ {Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {0, 500, 500, 500, 10, 50, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    1);

  /**
   * @generated
   */
  public static class GetEObjXPersonNameExtParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setLong (stmt, 1, Types.BIGINT, (Long)parameters[0]);
    }
  }

  /**
   * @generated
   */
  public static class GetEObjXPersonNameExtRowHandler extends BaseRowHandler<EObjXPersonNameExt>
  {
    /**
     * @generated
     */
    public EObjXPersonNameExt handle (java.sql.ResultSet rs, EObjXPersonNameExt returnObject) throws java.sql.SQLException
    {
      returnObject = new EObjXPersonNameExt ();
      returnObject.setXLastModifiedSystemDate(getTimestamp (rs, 1)); 
      returnObject.setXGivenNameOneLocal(getString (rs, 2)); 
      returnObject.setXGivenNameTwoLocal(getString (rs, 3)); 
      returnObject.setXLastNameLocal(getString (rs, 4)); 
      returnObject.setXPersonNameRetailerFlag(getString (rs, 5)); 
      returnObject.setX_BPID(getString (rs, 6)); 
      returnObject.setLastUpdateDt(getTimestamp (rs, 7)); 
      returnObject.setLastUpdateUser(getString (rs, 8)); 
      returnObject.setLastUpdateTxId(getLongObject (rs, 9)); 
    
      return returnObject;
    }
  }

  /**
   * @Update( sql="insert into PERSONNAME (LAST_USED_DT, LAST_VERIFIED_DT, END_DT, GIVEN_NAME_FOUR, GIVEN_NAME_ONE, GIVEN_NAME_THREE, GIVEN_NAME_TWO, LAST_NAME, PREFIX_DESC, PERSON_NAME_ID, CONT_ID, START_DT, SUFFIX_DESC, USE_STANDARD_IND, NAME_USAGE_TP_CD, PREFIX_NAME_TP_CD, GENERATION_TP_CD, SOURCE_IDENT_TP_CD, P_LAST_NAME, P_GIVEN_NAME_ONE, P_GIVEN_NAME_TWO, P_GIVEN_NAME_THREE, P_GIVEN_NAME_FOUR, XMODIFY_SYS_DT, XGIVEN_NAME_ONE_LOCAL, XGIVEN_NAME_TWO_LOCAL, XLAST_NAME_LOCAL, XPERSONNAME_RETAILER_FLAG, X_BPID, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( ?1.lastUsedDt, ?1.lastVerifiedDt, ?1.endDt, ?1.givenNameFour, ?1.givenNameOne, ?1.givenNameThree, ?1.givenNameTwo, ?1.lastName, ?1.prefixDesc, ?1.personNameIdPK, ?1.contId, ?1.startDt, ?1.suffixDesc, ?1.useStandardInd, ?1.nameUsageTpCd, ?1.prefixNameTpCd, ?1.generationTpCd, ?1.sourceIdentTpCd, ?1.pLastName, ?1.pGivenNameOne, ?1.pGivenNameTwo, ?1.pGivenNameThree, ?1.pGivenNameFour, ?2.xLastModifiedSystemDate, ?2.xGivenNameOneLocal, ?2.xGivenNameTwoLocal, ?2.xLastNameLocal, ?2.xPersonNameRetailerFlag, ?2.x_BPID, ?1.lastUpdateDt, ?1.lastUpdateUser, ?1.lastUpdateTxId)" )
   * 
   * @generated
   */
  public int createEObjXPersonNameExt (EObjPersonName e1, EObjXPersonNameExt e2)
  {
    return update (createEObjXPersonNameExtStatementDescriptor, e1, e2);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor createEObjXPersonNameExtStatementDescriptor = createStatementDescriptor (
    "createEObjXPersonNameExt(com.dwl.tcrm.coreParty.entityObject.EObjPersonName, com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt)",
    "insert into PERSONNAME (LAST_USED_DT, LAST_VERIFIED_DT, END_DT, GIVEN_NAME_FOUR, GIVEN_NAME_ONE, GIVEN_NAME_THREE, GIVEN_NAME_TWO, LAST_NAME, PREFIX_DESC, PERSON_NAME_ID, CONT_ID, START_DT, SUFFIX_DESC, USE_STANDARD_IND, NAME_USAGE_TP_CD, PREFIX_NAME_TP_CD, GENERATION_TP_CD, SOURCE_IDENT_TP_CD, P_LAST_NAME, P_GIVEN_NAME_ONE, P_GIVEN_NAME_TWO, P_GIVEN_NAME_THREE, P_GIVEN_NAME_FOUR, XMODIFY_SYS_DT, XGIVEN_NAME_ONE_LOCAL, XGIVEN_NAME_TWO_LOCAL, XLAST_NAME_LOCAL, XPERSONNAME_RETAILER_FLAG, X_BPID, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values(  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? )",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.INSERT,
    null,
    new CreateEObjXPersonNameExtParameterHandler (),
    new int[][]{{Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR, Types.CHAR, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {0, 0, 0, 25, 25, 25, 25, 30, 20, 19, 19, 0, 20, 1, 19, 19, 19, 19, 20, 20, 20, 20, 20, 0, 500, 500, 500, 10, 50, 0, 0, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    2);

  /**
   * @generated
   */
  public static class CreateEObjXPersonNameExtParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      EObjPersonName bean0 = (EObjPersonName) parameters[0];
      setTimestamp (stmt, 1, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUsedDt());
      setTimestamp (stmt, 2, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastVerifiedDt());
      setTimestamp (stmt, 3, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getEndDt());
      setString (stmt, 4, Types.VARCHAR, (String)bean0.getGivenNameFour());
      setString (stmt, 5, Types.VARCHAR, (String)bean0.getGivenNameOne());
      setString (stmt, 6, Types.VARCHAR, (String)bean0.getGivenNameThree());
      setString (stmt, 7, Types.VARCHAR, (String)bean0.getGivenNameTwo());
      setString (stmt, 8, Types.VARCHAR, (String)bean0.getLastName());
      setString (stmt, 9, Types.VARCHAR, (String)bean0.getPrefixDesc());
      setLong (stmt, 10, Types.BIGINT, (Long)bean0.getPersonNameIdPK());
      setLong (stmt, 11, Types.BIGINT, (Long)bean0.getContId());
      setTimestamp (stmt, 12, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getStartDt());
      setString (stmt, 13, Types.VARCHAR, (String)bean0.getSuffixDesc());
      setString (stmt, 14, Types.CHAR, (String)bean0.getUseStandardInd());
      setLong (stmt, 15, Types.BIGINT, (Long)bean0.getNameUsageTpCd());
      setLong (stmt, 16, Types.BIGINT, (Long)bean0.getPrefixNameTpCd());
      setLong (stmt, 17, Types.BIGINT, (Long)bean0.getGenerationTpCd());
      setLong (stmt, 18, Types.BIGINT, (Long)bean0.getSourceIdentTpCd());
      setString (stmt, 19, Types.VARCHAR, (String)bean0.getPLastName());
      setString (stmt, 20, Types.VARCHAR, (String)bean0.getPGivenNameOne());
      setString (stmt, 21, Types.VARCHAR, (String)bean0.getPGivenNameTwo());
      setString (stmt, 22, Types.VARCHAR, (String)bean0.getPGivenNameThree());
      setString (stmt, 23, Types.VARCHAR, (String)bean0.getPGivenNameFour());
      EObjXPersonNameExt bean1 = (EObjXPersonNameExt) parameters[1];
      setTimestamp (stmt, 24, Types.TIMESTAMP, (java.sql.Timestamp)bean1.getXLastModifiedSystemDate());
      setString (stmt, 25, Types.VARCHAR, (String)bean1.getXGivenNameOneLocal());
      setString (stmt, 26, Types.VARCHAR, (String)bean1.getXGivenNameTwoLocal());
      setString (stmt, 27, Types.VARCHAR, (String)bean1.getXLastNameLocal());
      setString (stmt, 28, Types.VARCHAR, (String)bean1.getXPersonNameRetailerFlag());
      setString (stmt, 29, Types.VARCHAR, (String)bean1.getX_BPID());
      setTimestamp (stmt, 30, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUpdateDt());
      setString (stmt, 31, Types.VARCHAR, (String)bean0.getLastUpdateUser());
      setLong (stmt, 32, Types.BIGINT, (Long)bean0.getLastUpdateTxId());
    }
  }

  /**
   * @Update( sql="update PERSONNAME set LAST_USED_DT = ?1.lastUsedDt, LAST_VERIFIED_DT = ?1.lastVerifiedDt, END_DT = ?1.endDt, GIVEN_NAME_FOUR = ?1.givenNameFour, GIVEN_NAME_ONE = ?1.givenNameOne, GIVEN_NAME_THREE = ?1.givenNameThree, GIVEN_NAME_TWO = ?1.givenNameTwo, LAST_NAME = ?1.lastName, PREFIX_DESC = ?1.prefixDesc, CONT_ID = ?1.contId, START_DT = ?1.startDt, SUFFIX_DESC = ?1.suffixDesc, USE_STANDARD_IND = ?1.useStandardInd, NAME_USAGE_TP_CD = ?1.nameUsageTpCd, PREFIX_NAME_TP_CD = ?1.prefixNameTpCd, GENERATION_TP_CD = ?1.generationTpCd, SOURCE_IDENT_TP_CD = ?1.sourceIdentTpCd, P_LAST_NAME = ?1.pLastName, P_GIVEN_NAME_ONE = ?1.pGivenNameOne, P_GIVEN_NAME_TWO = ?1.pGivenNameTwo, P_GIVEN_NAME_THREE = ?1.pGivenNameThree, P_GIVEN_NAME_FOUR = ?1.pGivenNameFour, XMODIFY_SYS_DT = ?2.xLastModifiedSystemDate, XGIVEN_NAME_ONE_LOCAL = ?2.xGivenNameOneLocal, XGIVEN_NAME_TWO_LOCAL = ?2.xGivenNameTwoLocal, XLAST_NAME_LOCAL = ?2.xLastNameLocal, XPERSONNAME_RETAILER_FLAG = ?2.xPersonNameRetailerFlag, X_BPID = ?2.x_BPID, LAST_UPDATE_DT = ?1.lastUpdateDt, LAST_UPDATE_USER = ?1.lastUpdateUser, LAST_UPDATE_TX_ID = ?1.lastUpdateTxId where PERSON_NAME_ID = ?1.personNameIdPK and LAST_UPDATE_DT = ?1.oldLastUpdateDt" )
   * 
   * @generated
   */
  public int updateEObjXPersonNameExt (EObjPersonName e1, EObjXPersonNameExt e2)
  {
    return update (updateEObjXPersonNameExtStatementDescriptor, e1, e2);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor updateEObjXPersonNameExtStatementDescriptor = createStatementDescriptor (
    "updateEObjXPersonNameExt(com.dwl.tcrm.coreParty.entityObject.EObjPersonName, com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt)",
    "update PERSONNAME set LAST_USED_DT =  ? , LAST_VERIFIED_DT =  ? , END_DT =  ? , GIVEN_NAME_FOUR =  ? , GIVEN_NAME_ONE =  ? , GIVEN_NAME_THREE =  ? , GIVEN_NAME_TWO =  ? , LAST_NAME =  ? , PREFIX_DESC =  ? , CONT_ID =  ? , START_DT =  ? , SUFFIX_DESC =  ? , USE_STANDARD_IND =  ? , NAME_USAGE_TP_CD =  ? , PREFIX_NAME_TP_CD =  ? , GENERATION_TP_CD =  ? , SOURCE_IDENT_TP_CD =  ? , P_LAST_NAME =  ? , P_GIVEN_NAME_ONE =  ? , P_GIVEN_NAME_TWO =  ? , P_GIVEN_NAME_THREE =  ? , P_GIVEN_NAME_FOUR =  ? , XMODIFY_SYS_DT =  ? , XGIVEN_NAME_ONE_LOCAL =  ? , XGIVEN_NAME_TWO_LOCAL =  ? , XLAST_NAME_LOCAL =  ? , XPERSONNAME_RETAILER_FLAG =  ? , X_BPID =  ? , LAST_UPDATE_DT =  ? , LAST_UPDATE_USER =  ? , LAST_UPDATE_TX_ID =  ?  where PERSON_NAME_ID =  ?  and LAST_UPDATE_DT =  ? ",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.UPDATE,
    null,
    new UpdateEObjXPersonNameExtParameterHandler (),
    new int[][]{{Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR, Types.CHAR, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP}, {0, 0, 0, 25, 25, 25, 25, 30, 20, 19, 0, 20, 1, 19, 19, 19, 19, 20, 20, 20, 20, 20, 0, 500, 500, 500, 10, 50, 0, 0, 19, 19, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    3);

  /**
   * @generated
   */
  public static class UpdateEObjXPersonNameExtParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      EObjPersonName bean0 = (EObjPersonName) parameters[0];
      setTimestamp (stmt, 1, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUsedDt());
      setTimestamp (stmt, 2, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastVerifiedDt());
      setTimestamp (stmt, 3, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getEndDt());
      setString (stmt, 4, Types.VARCHAR, (String)bean0.getGivenNameFour());
      setString (stmt, 5, Types.VARCHAR, (String)bean0.getGivenNameOne());
      setString (stmt, 6, Types.VARCHAR, (String)bean0.getGivenNameThree());
      setString (stmt, 7, Types.VARCHAR, (String)bean0.getGivenNameTwo());
      setString (stmt, 8, Types.VARCHAR, (String)bean0.getLastName());
      setString (stmt, 9, Types.VARCHAR, (String)bean0.getPrefixDesc());
      setLong (stmt, 10, Types.BIGINT, (Long)bean0.getContId());
      setTimestamp (stmt, 11, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getStartDt());
      setString (stmt, 12, Types.VARCHAR, (String)bean0.getSuffixDesc());
      setString (stmt, 13, Types.CHAR, (String)bean0.getUseStandardInd());
      setLong (stmt, 14, Types.BIGINT, (Long)bean0.getNameUsageTpCd());
      setLong (stmt, 15, Types.BIGINT, (Long)bean0.getPrefixNameTpCd());
      setLong (stmt, 16, Types.BIGINT, (Long)bean0.getGenerationTpCd());
      setLong (stmt, 17, Types.BIGINT, (Long)bean0.getSourceIdentTpCd());
      setString (stmt, 18, Types.VARCHAR, (String)bean0.getPLastName());
      setString (stmt, 19, Types.VARCHAR, (String)bean0.getPGivenNameOne());
      setString (stmt, 20, Types.VARCHAR, (String)bean0.getPGivenNameTwo());
      setString (stmt, 21, Types.VARCHAR, (String)bean0.getPGivenNameThree());
      setString (stmt, 22, Types.VARCHAR, (String)bean0.getPGivenNameFour());
      EObjXPersonNameExt bean1 = (EObjXPersonNameExt) parameters[1];
      setTimestamp (stmt, 23, Types.TIMESTAMP, (java.sql.Timestamp)bean1.getXLastModifiedSystemDate());
      setString (stmt, 24, Types.VARCHAR, (String)bean1.getXGivenNameOneLocal());
      setString (stmt, 25, Types.VARCHAR, (String)bean1.getXGivenNameTwoLocal());
      setString (stmt, 26, Types.VARCHAR, (String)bean1.getXLastNameLocal());
      setString (stmt, 27, Types.VARCHAR, (String)bean1.getXPersonNameRetailerFlag());
      setString (stmt, 28, Types.VARCHAR, (String)bean1.getX_BPID());
      setTimestamp (stmt, 29, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUpdateDt());
      setString (stmt, 30, Types.VARCHAR, (String)bean0.getLastUpdateUser());
      setLong (stmt, 31, Types.BIGINT, (Long)bean0.getLastUpdateTxId());
      setLong (stmt, 32, Types.BIGINT, (Long)bean0.getPersonNameIdPK());
      setTimestamp (stmt, 33, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getOldLastUpdateDt());
    }
  }

  /**
   * @Update( sql="delete from PERSONNAME where PERSON_NAME_ID = ?" )
   * 
   * @generated
   */
  public int deleteEObjXPersonNameExt (Long personNameIdPK)
  {
    return update (deleteEObjXPersonNameExtStatementDescriptor, personNameIdPK);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor deleteEObjXPersonNameExtStatementDescriptor = createStatementDescriptor (
    "deleteEObjXPersonNameExt(Long)",
    "delete from PERSONNAME where PERSON_NAME_ID = ?",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.DELETE,
    null,
    new DeleteEObjXPersonNameExtParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    4);

  /**
   * @generated
   */
  public static class DeleteEObjXPersonNameExtParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setLong (stmt, 1, Types.BIGINT, (Long)parameters[0]);
    }
  }

}
