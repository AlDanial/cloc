/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[01e9802e72b45a98b96212e0f6f9fbcc]
 */

package com.ibm.daimler.dsea.entityObject;


import com.ibm.mdm.base.db.ResultQueue1;
import java.util.Iterator;
import com.ibm.mdm.base.db.EntityMapping;
import com.ibm.pdq.annotation.Select;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * @generated
 */
public interface XDataSharingInquiryData {
  
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String tableAliasString = "tableAlias (" + 
                                            "XDATASHARING => com.ibm.daimler.dsea.entityObject.EObjXDataSharing, " +
                                            "H_XDATASHARING => com.ibm.daimler.dsea.entityObject.EObjXDataSharing" +
                                            ")";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getXDataSharingSql = "SELECT r.DATASHARINGPK_ID DATASHARINGPK_ID, r.DATA_SHARING_FLAG DATA_SHARING_FLAG, r.CONT_ID CONT_ID, r.Customer_Merge_Ind Customer_Merge_Ind, r.GCUpdate_Date GCUpdate_Date, r.Data_Sharing_Wholesale Data_Sharing_Wholesale, r.WSData_Sharing_Update_Date WSData_Sharing_Update_Date, r.RETAILER_ID RETAILER_ID, r.RETAILER_FLAG RETAILER_FLAG, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.START_DT START_DT, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XDATASHARING r WHERE r.DATASHARINGPK_ID = ? ";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXDataSharingParameters =
    "EObjXDataSharing.DataSharingpkId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXDataSharingResults =
    "EObjXDataSharing.DataSharingpkId," +
    "EObjXDataSharing.DataSharingFlag," +
    "EObjXDataSharing.ContId," +
    "EObjXDataSharing.CustomerMergeInd," +
    "EObjXDataSharing.GCUpdateDate," +
    "EObjXDataSharing.DataSharingWholesale," +
    "EObjXDataSharing.WSDataSharingUpdateDate," +
    "EObjXDataSharing.RetailerId," +
    "EObjXDataSharing.RetailerFlag," +
    "EObjXDataSharing.SourceIdentifier," +
    "EObjXDataSharing.StartDate," +
    "EObjXDataSharing.LastModifiedSystemDate," +
    "EObjXDataSharing.lastUpdateDt," +
    "EObjXDataSharing.lastUpdateUser," +
    "EObjXDataSharing.lastUpdateTxId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getXDataSharingHistorySql = "SELECT r.H_DATASHARINGPK_ID hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.DATASHARINGPK_ID DATASHARINGPK_ID, r.DATA_SHARING_FLAG DATA_SHARING_FLAG, r.CONT_ID CONT_ID, r.Customer_Merge_Ind Customer_Merge_Ind, r.GCUpdate_Date GCUpdate_Date, r.Data_Sharing_Wholesale Data_Sharing_Wholesale, r.WSData_Sharing_Update_Date WSData_Sharing_Update_Date, r.RETAILER_ID RETAILER_ID, r.RETAILER_FLAG RETAILER_FLAG, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.START_DT START_DT, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XDATASHARING r WHERE r.H_DATASHARINGPK_ID = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXDataSharingHistoryParameters =
    "EObjXDataSharing.DataSharingpkId," +
    "EObjXDataSharing.lastUpdateDt," +
    "EObjXDataSharing.lastUpdateDt";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXDataSharingHistoryResults =
    "EObjXDataSharing.historyIdPK," +
    "EObjXDataSharing.histActionCode," +
    "EObjXDataSharing.histCreatedBy," +
    "EObjXDataSharing.histCreateDt," +
    "EObjXDataSharing.histEndDt," +
    "EObjXDataSharing.DataSharingpkId," +
    "EObjXDataSharing.DataSharingFlag," +
    "EObjXDataSharing.ContId," +
    "EObjXDataSharing.CustomerMergeInd," +
    "EObjXDataSharing.GCUpdateDate," +
    "EObjXDataSharing.DataSharingWholesale," +
    "EObjXDataSharing.WSDataSharingUpdateDate," +
    "EObjXDataSharing.RetailerId," +
    "EObjXDataSharing.RetailerFlag," +
    "EObjXDataSharing.SourceIdentifier," +
    "EObjXDataSharing.StartDate," +
    "EObjXDataSharing.LastModifiedSystemDate," +
    "EObjXDataSharing.lastUpdateDt," +
    "EObjXDataSharing.lastUpdateUser," +
    "EObjXDataSharing.lastUpdateTxId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getDataSharingByPartyIdSql = "SELECT r.DATASHARINGPK_ID DATASHARINGPK_ID, r.DATA_SHARING_FLAG DATA_SHARING_FLAG, r.CONT_ID CONT_ID, r.Customer_Merge_Ind Customer_Merge_Ind, r.GCUpdate_Date GCUpdate_Date, r.Data_Sharing_Wholesale Data_Sharing_Wholesale, r.WSData_Sharing_Update_Date WSData_Sharing_Update_Date, r.RETAILER_ID RETAILER_ID, r.RETAILER_FLAG RETAILER_FLAG, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.START_DT START_DT, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XDATASHARING r WHERE r.CONT_ID = ? ";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getDataSharingByPartyIdParameters =
    "EObjXDataSharing.ContId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getDataSharingByPartyIdResults =
    "EObjXDataSharing.DataSharingpkId," +
    "EObjXDataSharing.DataSharingFlag," +
    "EObjXDataSharing.ContId," +
    "EObjXDataSharing.CustomerMergeInd," +
    "EObjXDataSharing.GCUpdateDate," +
    "EObjXDataSharing.DataSharingWholesale," +
    "EObjXDataSharing.WSDataSharingUpdateDate," +
    "EObjXDataSharing.RetailerId," +
    "EObjXDataSharing.RetailerFlag," +
    "EObjXDataSharing.SourceIdentifier," +
    "EObjXDataSharing.StartDate," +
    "EObjXDataSharing.LastModifiedSystemDate," +
    "EObjXDataSharing.lastUpdateDt," +
    "EObjXDataSharing.lastUpdateUser," +
    "EObjXDataSharing.lastUpdateTxId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getDataSharingByPartyIdHistorySql = "SELECT r.H_DATASHARINGPK_ID hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.DATASHARINGPK_ID DATASHARINGPK_ID, r.DATA_SHARING_FLAG DATA_SHARING_FLAG, r.CONT_ID CONT_ID, r.Customer_Merge_Ind Customer_Merge_Ind, r.GCUpdate_Date GCUpdate_Date, r.Data_Sharing_Wholesale Data_Sharing_Wholesale, r.WSData_Sharing_Update_Date WSData_Sharing_Update_Date, r.RETAILER_ID RETAILER_ID, r.RETAILER_FLAG RETAILER_FLAG, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.START_DT START_DT, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XDATASHARING r WHERE r.CONT_ID = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getDataSharingByPartyIdHistoryParameters =
    "EObjXDataSharing.ContId," +
    "EObjXDataSharing.lastUpdateDt," +
    "EObjXDataSharing.lastUpdateDt";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getDataSharingByPartyIdHistoryResults =
    "EObjXDataSharing.historyIdPK," +
    "EObjXDataSharing.histActionCode," +
    "EObjXDataSharing.histCreatedBy," +
    "EObjXDataSharing.histCreateDt," +
    "EObjXDataSharing.histEndDt," +
    "EObjXDataSharing.DataSharingpkId," +
    "EObjXDataSharing.DataSharingFlag," +
    "EObjXDataSharing.ContId," +
    "EObjXDataSharing.CustomerMergeInd," +
    "EObjXDataSharing.GCUpdateDate," +
    "EObjXDataSharing.DataSharingWholesale," +
    "EObjXDataSharing.WSDataSharingUpdateDate," +
    "EObjXDataSharing.RetailerId," +
    "EObjXDataSharing.RetailerFlag," +
    "EObjXDataSharing.SourceIdentifier," +
    "EObjXDataSharing.StartDate," +
    "EObjXDataSharing.LastModifiedSystemDate," +
    "EObjXDataSharing.lastUpdateDt," +
    "EObjXDataSharing.lastUpdateUser," +
    "EObjXDataSharing.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getXDataSharingSql, pattern=tableAliasString)
  @EntityMapping(parameters=getXDataSharingParameters, results=getXDataSharingResults)
  Iterator<ResultQueue1<EObjXDataSharing>> getXDataSharing(Object[] parameters);  


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getXDataSharingHistorySql, pattern=tableAliasString)
  @EntityMapping(parameters=getXDataSharingHistoryParameters, results=getXDataSharingHistoryResults)
  Iterator<ResultQueue1<EObjXDataSharing>> getXDataSharingHistory(Object[] parameters);  


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getDataSharingByPartyIdSql, pattern=tableAliasString)
  @EntityMapping(parameters=getDataSharingByPartyIdParameters, results=getDataSharingByPartyIdResults)
  Iterator<ResultQueue1<EObjXDataSharing>> getDataSharingByPartyId(Object[] parameters);  


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getDataSharingByPartyIdHistorySql, pattern=tableAliasString)
  @EntityMapping(parameters=getDataSharingByPartyIdHistoryParameters, results=getDataSharingByPartyIdHistoryResults)
  Iterator<ResultQueue1<EObjXDataSharing>> getDataSharingByPartyIdHistory(Object[] parameters);  


}


