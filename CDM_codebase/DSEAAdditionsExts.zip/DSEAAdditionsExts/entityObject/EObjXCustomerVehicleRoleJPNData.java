/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[45ec955943cfb78cfe283c3a6473ed7e]
 */


package com.ibm.daimler.dsea.entityObject;

import java.util.Iterator;
import com.ibm.mdm.base.db.EntityMapping;
import com.ibm.pdq.annotation.Select;
import com.ibm.pdq.annotation.Update;

import com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRoleJPN;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * @generated
 */
public interface EObjXCustomerVehicleRoleJPNData {


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjXCustomerVehicleRoleJPNSql = "select XCUSTOMERVEHICLEROLEJPNPK_ID, CUSTOMER_VEHICLE_ID, VEHICLE_ROLE_TP_CD, START_DT, END_DT, SOURCE_IDENT_TP_CD, CHANGED_DT, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from XCUSTOMERVEHICLEROLEJPN where XCUSTOMERVEHICLEROLEJPNPK_ID = ? ";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String createEObjXCustomerVehicleRoleJPNSql = "insert into XCUSTOMERVEHICLEROLEJPN (XCUSTOMERVEHICLEROLEJPNPK_ID, CUSTOMER_VEHICLE_ID, VEHICLE_ROLE_TP_CD, START_DT, END_DT, SOURCE_IDENT_TP_CD, CHANGED_DT, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( :xCustomerVehicleRoleJPNpkId, :customerVehicleId, :vehicleRole, :startDate, :endDate, :sourceIdentifier, :changedDate, :lastUpdateDt, :lastUpdateUser, :lastUpdateTxId)";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String updateEObjXCustomerVehicleRoleJPNSql = "update XCUSTOMERVEHICLEROLEJPN set CUSTOMER_VEHICLE_ID = :customerVehicleId, VEHICLE_ROLE_TP_CD = :vehicleRole, START_DT = :startDate, END_DT = :endDate, SOURCE_IDENT_TP_CD = :sourceIdentifier, CHANGED_DT = :changedDate, LAST_UPDATE_DT = :lastUpdateDt, LAST_UPDATE_USER = :lastUpdateUser, LAST_UPDATE_TX_ID = :lastUpdateTxId where XCUSTOMERVEHICLEROLEJPNPK_ID = :xCustomerVehicleRoleJPNpkId and LAST_UPDATE_DT = :oldLastUpdateDt";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String deleteEObjXCustomerVehicleRoleJPNSql = "delete from XCUSTOMERVEHICLEROLEJPN where XCUSTOMERVEHICLEROLEJPNPK_ID = ?";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXCustomerVehicleRoleJPNKeyField = "EObjXCustomerVehicleRoleJPN.xCustomerVehicleRoleJPNpkId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXCustomerVehicleRoleJPNGetFields =
    "EObjXCustomerVehicleRoleJPN.xCustomerVehicleRoleJPNpkId," +
    "EObjXCustomerVehicleRoleJPN.customerVehicleId," +
    "EObjXCustomerVehicleRoleJPN.vehicleRole," +
    "EObjXCustomerVehicleRoleJPN.startDate," +
    "EObjXCustomerVehicleRoleJPN.endDate," +
    "EObjXCustomerVehicleRoleJPN.sourceIdentifier," +
    "EObjXCustomerVehicleRoleJPN.changedDate," +
    "EObjXCustomerVehicleRoleJPN.lastUpdateDt," +
    "EObjXCustomerVehicleRoleJPN.lastUpdateUser," +
    "EObjXCustomerVehicleRoleJPN.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXCustomerVehicleRoleJPNAllFields =
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRoleJPN.xCustomerVehicleRoleJPNpkId," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRoleJPN.customerVehicleId," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRoleJPN.vehicleRole," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRoleJPN.startDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRoleJPN.endDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRoleJPN.sourceIdentifier," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRoleJPN.changedDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRoleJPN.lastUpdateDt," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRoleJPN.lastUpdateUser," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRoleJPN.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXCustomerVehicleRoleJPNUpdateFields =
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRoleJPN.customerVehicleId," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRoleJPN.vehicleRole," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRoleJPN.startDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRoleJPN.endDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRoleJPN.sourceIdentifier," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRoleJPN.changedDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRoleJPN.lastUpdateDt," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRoleJPN.lastUpdateUser," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRoleJPN.lastUpdateTxId," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRoleJPN.xCustomerVehicleRoleJPNpkId," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRoleJPN.oldLastUpdateDt";   

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Select XCustomerVehicleRoleJPN by parameters.
   * @generated
   */
  @Select(sql=getEObjXCustomerVehicleRoleJPNSql)
  @EntityMapping(parameters=EObjXCustomerVehicleRoleJPNKeyField, results=EObjXCustomerVehicleRoleJPNGetFields)
  Iterator<EObjXCustomerVehicleRoleJPN> getEObjXCustomerVehicleRoleJPN(Long xCustomerVehicleRoleJPNpkId);  
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Create XCustomerVehicleRoleJPN by EObjXCustomerVehicleRoleJPN Object.
   * @generated
   */
  @Update(sql=createEObjXCustomerVehicleRoleJPNSql)
  @EntityMapping(parameters=EObjXCustomerVehicleRoleJPNAllFields)
    int createEObjXCustomerVehicleRoleJPN(EObjXCustomerVehicleRoleJPN e); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Update one XCustomerVehicleRoleJPN by EObjXCustomerVehicleRoleJPN object.
   * @generated
   */
  @Update(sql=updateEObjXCustomerVehicleRoleJPNSql)
  @EntityMapping(parameters=EObjXCustomerVehicleRoleJPNUpdateFields)
    int updateEObjXCustomerVehicleRoleJPN(EObjXCustomerVehicleRoleJPN e); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Delete XCustomerVehicleRoleJPN by parameters.
   * @generated
   */
  @Update(sql=deleteEObjXCustomerVehicleRoleJPNSql)
  @EntityMapping(parameters=EObjXCustomerVehicleRoleJPNKeyField)
  int deleteEObjXCustomerVehicleRoleJPN(Long xCustomerVehicleRoleJPNpkId);

}

