package com.ibm.daimler.dsea.entityObject;

import com.ibm.pdq.runtime.generator.BaseParameterHandler;
import java.util.Iterator;
import com.ibm.daimler.dsea.entityObject.EObjXVehicleAddress;
import com.ibm.mdm.base.db.ResultQueue1;
import java.sql.PreparedStatement;
import com.ibm.pdq.runtime.statement.StatementDescriptor;
import com.ibm.pdq.runtime.generator.BaseData;
import java.sql.SQLException;
import com.ibm.pdq.annotation.Metadata;
import com.ibm.pdq.runtime.generator.BaseRowHandler;
import com.ibm.pdq.runtime.statement.SqlStatementType;
import java.sql.Types;


@SuppressWarnings("unchecked")

/**
 * <!-- begin-user-doc -->
 * 
 * <!-- end-user-doc -->
 * 
 * @generated
 */
public class XVehicleAddressInquiryDataImpl  extends BaseData implements XVehicleAddressInquiryData
{

  /**
   * @generated
   */
  public static final String generatorVersion = "3.200.75";

  /**
   * @generated
   */
  public static final String identifier = "XVehicleAddressInquiryData";

  /**
   * @generated
   */
  public static final long generationTime = 0x00000164465f3a6cL;

  /**
   * @generated
   */
  public static final String collection = "NULLID";

  /**
   * @generated
   */
  public static final String packageVersion = null;

  /**
   * @generated
   */
  public static final boolean forceSingleBindIsolation = false;

  /**
   * @generated
   */
  public XVehicleAddressInquiryDataImpl()
  {
    super();
  } 

  /**
   * @generated
   */
  public String getGeneratorVersion()
  {
    return generatorVersion;
  }

  /**
   * @Select( sql="SELECT r.VEHICLE_ADDRESSPK_ID VEHICLE_ADDRESSPK_ID, r.ADDRESS_USAGE_TYPE ADDRESS_USAGE_TYPE, r.PREFERRED_IND PREFERRED_IND, r.ADDRESS_LINE_ONE ADDRESS_LINE_ONE, r.ADDRESS_LINE_TWO ADDRESS_LINE_TWO, r.ADDRESS_LINE_THREE ADDRESS_LINE_THREE, r.CITY_NAME CITY_NAME, r.POSTAL_CODE POSTAL_CODE, r.RESIDENCE_NUM RESIDENCE_NUM, r.COUNTRY COUNTRY, r.PROVINCE_STATE PROVINCE_STATE, r.VEHICLE_ID VEHICLE_ID, r.CONT_ID CONT_ID, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.START_DT START_DT, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XVEHICLEADDRESS r WHERE r.VEHICLE_ADDRESSPK_ID = ? ", pattern="tableAlias (XVEHICLEADDRESS => com.ibm.daimler.dsea.entityObject.EObjXVehicleAddress, H_XVEHICLEADDRESS => com.ibm.daimler.dsea.entityObject.EObjXVehicleAddress)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue1<EObjXVehicleAddress>> getXVehicleAddress (Object[] parameters)
  {
    return queryIterator (getXVehicleAddressStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getXVehicleAddressStatementDescriptor = createStatementDescriptor (
    "getXVehicleAddress(Object[])",
    "SELECT r.VEHICLE_ADDRESSPK_ID VEHICLE_ADDRESSPK_ID, r.ADDRESS_USAGE_TYPE ADDRESS_USAGE_TYPE, r.PREFERRED_IND PREFERRED_IND, r.ADDRESS_LINE_ONE ADDRESS_LINE_ONE, r.ADDRESS_LINE_TWO ADDRESS_LINE_TWO, r.ADDRESS_LINE_THREE ADDRESS_LINE_THREE, r.CITY_NAME CITY_NAME, r.POSTAL_CODE POSTAL_CODE, r.RESIDENCE_NUM RESIDENCE_NUM, r.COUNTRY COUNTRY, r.PROVINCE_STATE PROVINCE_STATE, r.VEHICLE_ID VEHICLE_ID, r.CONT_ID CONT_ID, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.START_DT START_DT, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XVEHICLEADDRESS r WHERE r.VEHICLE_ADDRESSPK_ID = ? ",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"vehicle_addresspk_id", "address_usage_type", "preferred_ind", "address_line_one", "address_line_two", "address_line_three", "city_name", "postal_code", "residence_num", "country", "province_state", "vehicle_id", "cont_id", "source_ident_tp_cd", "start_dt", "modify_sys_dt", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetXVehicleAddressParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetXVehicleAddressRowHandler (),
    new int[][]{ {Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 100, 10, 500, 250, 150, 1000, 100, 1000, 150, 250, 19, 19, 19, 0, 0, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    1);

  /**
   * @generated
   */
  public static class GetXVehicleAddressParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetXVehicleAddressRowHandler extends BaseRowHandler<ResultQueue1<EObjXVehicleAddress>>
  {
    /**
     * @generated
     */
    public ResultQueue1<EObjXVehicleAddress> handle (java.sql.ResultSet rs, ResultQueue1<EObjXVehicleAddress> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue1<EObjXVehicleAddress> ();

      EObjXVehicleAddress returnObject1 = new EObjXVehicleAddress ();
      returnObject1.setVehicleAddresspkId(getLongObject (rs, 1)); 
      returnObject1.setAddressUsageType(getString (rs, 2)); 
      returnObject1.setPreferredInd(getString (rs, 3)); 
      returnObject1.setAddressLineOne(getString (rs, 4)); 
      returnObject1.setAddressLineTwo(getString (rs, 5)); 
      returnObject1.setAddressLineThree(getString (rs, 6)); 
      returnObject1.setCity(getString (rs, 7)); 
      returnObject1.setZipPostalCode(getString (rs, 8)); 
      returnObject1.setResidenceNumber(getString (rs, 9)); 
      returnObject1.setCountry(getString (rs, 10)); 
      returnObject1.setProvinceState(getString (rs, 11)); 
      returnObject1.setVehicleId(getLongObject (rs, 12)); 
      returnObject1.setContId(getLongObject (rs, 13)); 
      returnObject1.setSourceIdentifier(getLongObject (rs, 14)); 
      returnObject1.setStartDate(getTimestamp (rs, 15)); 
      returnObject1.setLastModifiedSystemDate(getTimestamp (rs, 16)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 17)); 
      returnObject1.setLastUpdateUser(getString (rs, 18)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 19)); 
      returnObject.add (returnObject1);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT r.H_VEHICLE_ADDRESSPK_ID hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.VEHICLE_ADDRESSPK_ID VEHICLE_ADDRESSPK_ID, r.ADDRESS_USAGE_TYPE ADDRESS_USAGE_TYPE, r.PREFERRED_IND PREFERRED_IND, r.ADDRESS_LINE_ONE ADDRESS_LINE_ONE, r.ADDRESS_LINE_TWO ADDRESS_LINE_TWO, r.ADDRESS_LINE_THREE ADDRESS_LINE_THREE, r.CITY_NAME CITY_NAME, r.POSTAL_CODE POSTAL_CODE, r.RESIDENCE_NUM RESIDENCE_NUM, r.COUNTRY COUNTRY, r.PROVINCE_STATE PROVINCE_STATE, r.VEHICLE_ID VEHICLE_ID, r.CONT_ID CONT_ID, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.START_DT START_DT, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XVEHICLEADDRESS r WHERE r.H_VEHICLE_ADDRESSPK_ID = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))", pattern="tableAlias (XVEHICLEADDRESS => com.ibm.daimler.dsea.entityObject.EObjXVehicleAddress, H_XVEHICLEADDRESS => com.ibm.daimler.dsea.entityObject.EObjXVehicleAddress)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue1<EObjXVehicleAddress>> getXVehicleAddressHistory (Object[] parameters)
  {
    return queryIterator (getXVehicleAddressHistoryStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getXVehicleAddressHistoryStatementDescriptor = createStatementDescriptor (
    "getXVehicleAddressHistory(Object[])",
    "SELECT r.H_VEHICLE_ADDRESSPK_ID hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.VEHICLE_ADDRESSPK_ID VEHICLE_ADDRESSPK_ID, r.ADDRESS_USAGE_TYPE ADDRESS_USAGE_TYPE, r.PREFERRED_IND PREFERRED_IND, r.ADDRESS_LINE_ONE ADDRESS_LINE_ONE, r.ADDRESS_LINE_TWO ADDRESS_LINE_TWO, r.ADDRESS_LINE_THREE ADDRESS_LINE_THREE, r.CITY_NAME CITY_NAME, r.POSTAL_CODE POSTAL_CODE, r.RESIDENCE_NUM RESIDENCE_NUM, r.COUNTRY COUNTRY, r.PROVINCE_STATE PROVINCE_STATE, r.VEHICLE_ID VEHICLE_ID, r.CONT_ID CONT_ID, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.START_DT START_DT, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XVEHICLEADDRESS r WHERE r.H_VEHICLE_ADDRESSPK_ID = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"historyidpk", "h_action_code", "h_created_by", "h_create_dt", "h_end_dt", "vehicle_addresspk_id", "address_usage_type", "preferred_ind", "address_line_one", "address_line_two", "address_line_three", "city_name", "postal_code", "residence_num", "country", "province_state", "vehicle_id", "cont_id", "source_ident_tp_cd", "start_dt", "modify_sys_dt", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetXVehicleAddressHistoryParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP}, {19, 0, 0}, {0, 0, 0}, {1, 1, 1}},
    null,
    new GetXVehicleAddressHistoryRowHandler (),
    new int[][]{ {Types.BIGINT, Types.CHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 1, 20, 0, 0, 19, 100, 10, 500, 250, 150, 1000, 100, 1000, 150, 250, 19, 19, 19, 0, 0, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    2);

  /**
   * @generated
   */
  public static class GetXVehicleAddressHistoryParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetXVehicleAddressHistoryRowHandler extends BaseRowHandler<ResultQueue1<EObjXVehicleAddress>>
  {
    /**
     * @generated
     */
    public ResultQueue1<EObjXVehicleAddress> handle (java.sql.ResultSet rs, ResultQueue1<EObjXVehicleAddress> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue1<EObjXVehicleAddress> ();

      EObjXVehicleAddress returnObject1 = new EObjXVehicleAddress ();
      returnObject1.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject1.setHistActionCode(getString (rs, 2)); 
      returnObject1.setHistCreatedBy(getString (rs, 3)); 
      returnObject1.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject1.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject1.setVehicleAddresspkId(getLongObject (rs, 6)); 
      returnObject1.setAddressUsageType(getString (rs, 7)); 
      returnObject1.setPreferredInd(getString (rs, 8)); 
      returnObject1.setAddressLineOne(getString (rs, 9)); 
      returnObject1.setAddressLineTwo(getString (rs, 10)); 
      returnObject1.setAddressLineThree(getString (rs, 11)); 
      returnObject1.setCity(getString (rs, 12)); 
      returnObject1.setZipPostalCode(getString (rs, 13)); 
      returnObject1.setResidenceNumber(getString (rs, 14)); 
      returnObject1.setCountry(getString (rs, 15)); 
      returnObject1.setProvinceState(getString (rs, 16)); 
      returnObject1.setVehicleId(getLongObject (rs, 17)); 
      returnObject1.setContId(getLongObject (rs, 18)); 
      returnObject1.setSourceIdentifier(getLongObject (rs, 19)); 
      returnObject1.setStartDate(getTimestamp (rs, 20)); 
      returnObject1.setLastModifiedSystemDate(getTimestamp (rs, 21)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 22)); 
      returnObject1.setLastUpdateUser(getString (rs, 23)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 24)); 
      returnObject.add (returnObject1);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT r.VEHICLE_ADDRESSPK_ID VEHICLE_ADDRESSPK_ID, r.ADDRESS_USAGE_TYPE ADDRESS_USAGE_TYPE, r.PREFERRED_IND PREFERRED_IND, r.ADDRESS_LINE_ONE ADDRESS_LINE_ONE, r.ADDRESS_LINE_TWO ADDRESS_LINE_TWO, r.ADDRESS_LINE_THREE ADDRESS_LINE_THREE, r.CITY_NAME CITY_NAME, r.POSTAL_CODE POSTAL_CODE, r.RESIDENCE_NUM RESIDENCE_NUM, r.COUNTRY COUNTRY, r.PROVINCE_STATE PROVINCE_STATE, r.VEHICLE_ID VEHICLE_ID, r.CONT_ID CONT_ID, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.START_DT START_DT, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XVEHICLEADDRESS r WHERE r.VEHICLE_ID = ? ", pattern="tableAlias (XVEHICLEADDRESS => com.ibm.daimler.dsea.entityObject.EObjXVehicleAddress, H_XVEHICLEADDRESS => com.ibm.daimler.dsea.entityObject.EObjXVehicleAddress)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue1<EObjXVehicleAddress>> getVehicleAddressByVehicleId (Object[] parameters)
  {
    return queryIterator (getVehicleAddressByVehicleIdStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getVehicleAddressByVehicleIdStatementDescriptor = createStatementDescriptor (
    "getVehicleAddressByVehicleId(Object[])",
    "SELECT r.VEHICLE_ADDRESSPK_ID VEHICLE_ADDRESSPK_ID, r.ADDRESS_USAGE_TYPE ADDRESS_USAGE_TYPE, r.PREFERRED_IND PREFERRED_IND, r.ADDRESS_LINE_ONE ADDRESS_LINE_ONE, r.ADDRESS_LINE_TWO ADDRESS_LINE_TWO, r.ADDRESS_LINE_THREE ADDRESS_LINE_THREE, r.CITY_NAME CITY_NAME, r.POSTAL_CODE POSTAL_CODE, r.RESIDENCE_NUM RESIDENCE_NUM, r.COUNTRY COUNTRY, r.PROVINCE_STATE PROVINCE_STATE, r.VEHICLE_ID VEHICLE_ID, r.CONT_ID CONT_ID, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.START_DT START_DT, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XVEHICLEADDRESS r WHERE r.VEHICLE_ID = ? ",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"vehicle_addresspk_id", "address_usage_type", "preferred_ind", "address_line_one", "address_line_two", "address_line_three", "city_name", "postal_code", "residence_num", "country", "province_state", "vehicle_id", "cont_id", "source_ident_tp_cd", "start_dt", "modify_sys_dt", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetVehicleAddressByVehicleIdParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetVehicleAddressByVehicleIdRowHandler (),
    new int[][]{ {Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 100, 10, 500, 250, 150, 1000, 100, 1000, 150, 250, 19, 19, 19, 0, 0, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    3);

  /**
   * @generated
   */
  public static class GetVehicleAddressByVehicleIdParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetVehicleAddressByVehicleIdRowHandler extends BaseRowHandler<ResultQueue1<EObjXVehicleAddress>>
  {
    /**
     * @generated
     */
    public ResultQueue1<EObjXVehicleAddress> handle (java.sql.ResultSet rs, ResultQueue1<EObjXVehicleAddress> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue1<EObjXVehicleAddress> ();

      EObjXVehicleAddress returnObject1 = new EObjXVehicleAddress ();
      returnObject1.setVehicleAddresspkId(getLongObject (rs, 1)); 
      returnObject1.setAddressUsageType(getString (rs, 2)); 
      returnObject1.setPreferredInd(getString (rs, 3)); 
      returnObject1.setAddressLineOne(getString (rs, 4)); 
      returnObject1.setAddressLineTwo(getString (rs, 5)); 
      returnObject1.setAddressLineThree(getString (rs, 6)); 
      returnObject1.setCity(getString (rs, 7)); 
      returnObject1.setZipPostalCode(getString (rs, 8)); 
      returnObject1.setResidenceNumber(getString (rs, 9)); 
      returnObject1.setCountry(getString (rs, 10)); 
      returnObject1.setProvinceState(getString (rs, 11)); 
      returnObject1.setVehicleId(getLongObject (rs, 12)); 
      returnObject1.setContId(getLongObject (rs, 13)); 
      returnObject1.setSourceIdentifier(getLongObject (rs, 14)); 
      returnObject1.setStartDate(getTimestamp (rs, 15)); 
      returnObject1.setLastModifiedSystemDate(getTimestamp (rs, 16)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 17)); 
      returnObject1.setLastUpdateUser(getString (rs, 18)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 19)); 
      returnObject.add (returnObject1);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT r.H_VEHICLE_ADDRESSPK_ID hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.VEHICLE_ADDRESSPK_ID VEHICLE_ADDRESSPK_ID, r.ADDRESS_USAGE_TYPE ADDRESS_USAGE_TYPE, r.PREFERRED_IND PREFERRED_IND, r.ADDRESS_LINE_ONE ADDRESS_LINE_ONE, r.ADDRESS_LINE_TWO ADDRESS_LINE_TWO, r.ADDRESS_LINE_THREE ADDRESS_LINE_THREE, r.CITY_NAME CITY_NAME, r.POSTAL_CODE POSTAL_CODE, r.RESIDENCE_NUM RESIDENCE_NUM, r.COUNTRY COUNTRY, r.PROVINCE_STATE PROVINCE_STATE, r.VEHICLE_ID VEHICLE_ID, r.CONT_ID CONT_ID, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.START_DT START_DT, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XVEHICLEADDRESS r WHERE r.VEHICLE_ID = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))", pattern="tableAlias (XVEHICLEADDRESS => com.ibm.daimler.dsea.entityObject.EObjXVehicleAddress, H_XVEHICLEADDRESS => com.ibm.daimler.dsea.entityObject.EObjXVehicleAddress)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue1<EObjXVehicleAddress>> getVehicleAddressByVehicleIdHistory (Object[] parameters)
  {
    return queryIterator (getVehicleAddressByVehicleIdHistoryStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getVehicleAddressByVehicleIdHistoryStatementDescriptor = createStatementDescriptor (
    "getVehicleAddressByVehicleIdHistory(Object[])",
    "SELECT r.H_VEHICLE_ADDRESSPK_ID hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.VEHICLE_ADDRESSPK_ID VEHICLE_ADDRESSPK_ID, r.ADDRESS_USAGE_TYPE ADDRESS_USAGE_TYPE, r.PREFERRED_IND PREFERRED_IND, r.ADDRESS_LINE_ONE ADDRESS_LINE_ONE, r.ADDRESS_LINE_TWO ADDRESS_LINE_TWO, r.ADDRESS_LINE_THREE ADDRESS_LINE_THREE, r.CITY_NAME CITY_NAME, r.POSTAL_CODE POSTAL_CODE, r.RESIDENCE_NUM RESIDENCE_NUM, r.COUNTRY COUNTRY, r.PROVINCE_STATE PROVINCE_STATE, r.VEHICLE_ID VEHICLE_ID, r.CONT_ID CONT_ID, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.START_DT START_DT, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XVEHICLEADDRESS r WHERE r.VEHICLE_ID = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"historyidpk", "h_action_code", "h_created_by", "h_create_dt", "h_end_dt", "vehicle_addresspk_id", "address_usage_type", "preferred_ind", "address_line_one", "address_line_two", "address_line_three", "city_name", "postal_code", "residence_num", "country", "province_state", "vehicle_id", "cont_id", "source_ident_tp_cd", "start_dt", "modify_sys_dt", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetVehicleAddressByVehicleIdHistoryParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP}, {19, 0, 0}, {0, 0, 0}, {1, 1, 1}},
    null,
    new GetVehicleAddressByVehicleIdHistoryRowHandler (),
    new int[][]{ {Types.BIGINT, Types.CHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 1, 20, 0, 0, 19, 100, 10, 500, 250, 150, 1000, 100, 1000, 150, 250, 19, 19, 19, 0, 0, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    4);

  /**
   * @generated
   */
  public static class GetVehicleAddressByVehicleIdHistoryParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetVehicleAddressByVehicleIdHistoryRowHandler extends BaseRowHandler<ResultQueue1<EObjXVehicleAddress>>
  {
    /**
     * @generated
     */
    public ResultQueue1<EObjXVehicleAddress> handle (java.sql.ResultSet rs, ResultQueue1<EObjXVehicleAddress> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue1<EObjXVehicleAddress> ();

      EObjXVehicleAddress returnObject1 = new EObjXVehicleAddress ();
      returnObject1.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject1.setHistActionCode(getString (rs, 2)); 
      returnObject1.setHistCreatedBy(getString (rs, 3)); 
      returnObject1.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject1.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject1.setVehicleAddresspkId(getLongObject (rs, 6)); 
      returnObject1.setAddressUsageType(getString (rs, 7)); 
      returnObject1.setPreferredInd(getString (rs, 8)); 
      returnObject1.setAddressLineOne(getString (rs, 9)); 
      returnObject1.setAddressLineTwo(getString (rs, 10)); 
      returnObject1.setAddressLineThree(getString (rs, 11)); 
      returnObject1.setCity(getString (rs, 12)); 
      returnObject1.setZipPostalCode(getString (rs, 13)); 
      returnObject1.setResidenceNumber(getString (rs, 14)); 
      returnObject1.setCountry(getString (rs, 15)); 
      returnObject1.setProvinceState(getString (rs, 16)); 
      returnObject1.setVehicleId(getLongObject (rs, 17)); 
      returnObject1.setContId(getLongObject (rs, 18)); 
      returnObject1.setSourceIdentifier(getLongObject (rs, 19)); 
      returnObject1.setStartDate(getTimestamp (rs, 20)); 
      returnObject1.setLastModifiedSystemDate(getTimestamp (rs, 21)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 22)); 
      returnObject1.setLastUpdateUser(getString (rs, 23)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 24)); 
      returnObject.add (returnObject1);

    
      return returnObject;
    }
  }

}
