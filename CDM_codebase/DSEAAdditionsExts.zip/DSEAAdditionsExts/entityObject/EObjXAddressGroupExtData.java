/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[d47eb7d9d81d8c6e8d2205cd219b15bc]
 */


package com.ibm.daimler.dsea.entityObject;

import java.util.Iterator;
import com.ibm.mdm.base.db.EntityMapping;
import com.ibm.pdq.annotation.Select;
import com.ibm.pdq.annotation.Update;

import com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup;

import com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * @generated
 */
public interface EObjXAddressGroupExtData {


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjXAddressGroupExtSql = "select XVERIFIED_TP_CD, XRETAILER_ID, XMODIFY_SYS_DT, XADDR_RETAILER_FLAG, TITLE_OF_HONOR, COMPANY_NAME, SFAddress_Id, X_BPID, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from ADDRESSGROUP where LOCATION_GROUP_ID = ? ";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String createEObjXAddressGroupExtSql = "insert into ADDRESSGROUP (ADDRESS_ID, CARE_OF_DESC, LOCATION_GROUP_ID, ADDR_USAGE_TP_CD, XVERIFIED_TP_CD, XRETAILER_ID, XMODIFY_SYS_DT, XADDR_RETAILER_FLAG, TITLE_OF_HONOR, COMPANY_NAME, SFAddress_Id, X_BPID, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( ?1.addressId, ?1.careOfDesc, ?1.locationGroupIdPK, ?1.addrUsageTpCd, ?2.xVerified, ?2.xRetailerId, ?2.xLastModifiedSystemDate, ?2.xAddressRetailerFlag, ?2.titleOfHonor, ?2.companyName, ?2.sFAddressId, ?2.x_BPID, ?1.lastUpdateDt, ?1.lastUpdateUser, ?1.lastUpdateTxId)";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String updateEObjXAddressGroupExtSql = "update ADDRESSGROUP set ADDRESS_ID = ?1.addressId, CARE_OF_DESC = ?1.careOfDesc, ADDR_USAGE_TP_CD = ?1.addrUsageTpCd, XVERIFIED_TP_CD = ?2.xVerified, XRETAILER_ID = ?2.xRetailerId, XMODIFY_SYS_DT = ?2.xLastModifiedSystemDate, XADDR_RETAILER_FLAG = ?2.xAddressRetailerFlag, TITLE_OF_HONOR = ?2.titleOfHonor, COMPANY_NAME = ?2.companyName, SFAddress_Id = ?2.sFAddressId, X_BPID = ?2.x_BPID, LAST_UPDATE_DT = ?1.lastUpdateDt, LAST_UPDATE_USER = ?1.lastUpdateUser, LAST_UPDATE_TX_ID = ?1.lastUpdateTxId where LOCATION_GROUP_ID = ?1.locationGroupIdPK and LAST_UPDATE_DT = ?1.oldLastUpdateDt";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String deleteEObjXAddressGroupExtSql = "delete from ADDRESSGROUP where LOCATION_GROUP_ID = ?";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXAddressGroupExtKeyField = "EObjXAddressGroupExt.locationGroupIdPK";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXAddressGroupExtGetFields =
    "EObjXAddressGroupExt.xVerified," +
    "EObjXAddressGroupExt.xRetailerId," +
    "EObjXAddressGroupExt.xLastModifiedSystemDate," +
    "EObjXAddressGroupExt.xAddressRetailerFlag," +
    "EObjXAddressGroupExt.titleOfHonor," +
    "EObjXAddressGroupExt.companyName," +
    "EObjXAddressGroupExt.sFAddressId," +
    "EObjXAddressGroupExt.x_BPID," +
    "EObjXAddressGroupExt.lastUpdateDt," +
    "EObjXAddressGroupExt.lastUpdateUser," +
    "EObjXAddressGroupExt.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXAddressGroupExtAllFields =
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.addressId," +
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.careOfDesc," +
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.locationGroupIdPK," +
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.addrUsageTpCd," +
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.xVerified," +
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.xRetailerId," +
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.xLastModifiedSystemDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.xAddressRetailerFlag," +
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.titleOfHonor," +
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.companyName," +
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.sFAddressId," +
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.x_BPID," +
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.lastUpdateDt," +
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.lastUpdateUser," +
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXAddressGroupExtUpdateFields =
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.addressId," +
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.careOfDesc," +
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.addrUsageTpCd," +
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.xVerified," +
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.xRetailerId," +
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.xLastModifiedSystemDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.xAddressRetailerFlag," +
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.titleOfHonor," +
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.companyName," +
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.sFAddressId," +
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.x_BPID," +
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.lastUpdateDt," +
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.lastUpdateUser," +
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.lastUpdateTxId," +
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.locationGroupIdPK," +
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.oldLastUpdateDt";   

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Select XAddressGroup by parameters.
   * @generated
   */
  @Select(sql=getEObjXAddressGroupExtSql)
  @EntityMapping(parameters=EObjXAddressGroupExtKeyField, results=EObjXAddressGroupExtGetFields)
  Iterator<EObjXAddressGroupExt> getEObjXAddressGroupExt(Long locationGroupIdPK);  
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Create XAddressGroup by EObjXAddressGroupExt Object.
   * @generated
   */
  @Update(sql=createEObjXAddressGroupExtSql)
  @EntityMapping(parameters=EObjXAddressGroupExtAllFields)
    int createEObjXAddressGroupExt(EObjAddressGroup e1, EObjXAddressGroupExt e2); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Update one XAddressGroup by EObjXAddressGroupExt object.
   * @generated
   */
  @Update(sql=updateEObjXAddressGroupExtSql)
  @EntityMapping(parameters=EObjXAddressGroupExtUpdateFields)
    int updateEObjXAddressGroupExt(EObjAddressGroup e1, EObjXAddressGroupExt e2); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Delete XAddressGroup by parameters.
   * @generated
   */
  @Update(sql=deleteEObjXAddressGroupExtSql)
  @EntityMapping(parameters=EObjXAddressGroupExtKeyField)
  int deleteEObjXAddressGroupExt(Long locationGroupIdPK);

}

