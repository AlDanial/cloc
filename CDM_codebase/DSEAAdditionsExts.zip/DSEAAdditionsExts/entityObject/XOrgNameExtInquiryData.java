/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[5ab956349fdb06b3acde103850fe71c9]
 */
package com.ibm.daimler.dsea.entityObject;


import com.ibm.mdm.base.db.EntityMapping;
import com.ibm.pdq.annotation.Select;


import com.dwl.tcrm.coreParty.entityObject.EObjOrgName;

import com.ibm.mdm.base.db.ResultQueue2;

import java.util.Iterator;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * 
 * @generated
 */
public interface XOrgNameExtInquiryData {

  /**
   * MDM_TODO: CDKWB0050I The generated parameter and result lists in this file should be checked to ensure that each matches its
   * associated SQL query. Each list entry must be comma separated and identify a field within an entity object class.
   */ 
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */ 
   public final static String tableAliasString1 = "tableAlias (" + 
     "ORGNAME => com.dwl.tcrm.coreParty.entityObject.EObjOrgName, " + 
     "H_ORGNAME => com.dwl.tcrm.coreParty.entityObject.EObjOrgName , " + 
     "ORGNAME => com.ibm.daimler.dsea.entityObject.EObjXOrgNameExt , " + 
     "H_ORGNAME => com.ibm.daimler.dsea.entityObject.EObjXOrgNameExt" + 
     ")";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension XOrgName.
   *
   * @generated
   */ 
   public final static String getOrgNameHistorySQL = "SELECT DISTINCT A.H_ORG_NAME_ID AS HIST_ID_PK , A.H_ACTION_CODE , A.H_CREATED_BY , A.H_CREATE_DT , A.H_END_DT , A.ORG_NAME_ID , A.CONT_ID , A.ORG_NAME , A.START_DT , A.END_DT , A.ORG_NAME_TP_CD, A.S_ORG_NAME , A.NAME_SEARCH_KEY , A.LAST_UPDATE_DT , A.LAST_UPDATE_USER , A.LAST_UPDATE_TX_ID , A.LAST_USED_DT , A.LAST_VERIFIED_DT , A.SOURCE_IDENT_TP_CD, A.STANDARD_IND, A.XMODIFY_SYS_DT, A.XORG_NAME_LOCAL, A.XORGNAME_RETAILER_FLAG, A.X_BPID" + 
     " FROM H_ORGNAME A" + 
     " WHERE A.CONT_ID = ? AND (( ? BETWEEN A.H_CREATE_DT AND A.H_END_DT ) OR ( ? >= A.H_CREATE_DT AND A.H_END_DT IS NULL ))";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getOrgNameHistoryParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.histCreateDt=H_CREATE_DT"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getOrgNameHistoryResults =
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.historyIdPK=HIST_ID_PK," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.histActionCode=H_ACTION_CODE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.histCreatedBy=H_CREATED_BY," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.histEndDt=H_END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.orgNameIdPK=ORG_NAME_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.orgName=ORG_NAME," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.startDt=START_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.endDt=END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.orgNameTpCd=ORG_NAME_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.sOrgName=S_ORG_NAME," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.nameSearchKey=NAME_SEARCH_KEY," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.lastUsedDt=LAST_USED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.lastVerifiedDt=LAST_VERIFIED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.sourceIdentTpCd=SOURCE_IDENT_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.orgNameStandardInd=STANDARD_IND," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgNameExt.XLastModifiedSystemDate=XMODIFY_SYS_DT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgNameExt.XOrganizationNameLocal=XORG_NAME_LOCAL," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgNameExt.XOrgNameRetailerFlag=XORGNAME_RETAILER_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgNameExt.X_BPID=X_BPID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension XOrgName.
   *
   * @generated
   */ 
   public final static String getOrgNameActiveSQL = "SELECT ORGNAME.ORG_NAME_ID, ORGNAME.CONT_ID , ORGNAME.ORG_NAME , ORGNAME.START_DT , ORGNAME.END_DT , ORGNAME.ORG_NAME_TP_CD , ORGNAME.S_ORG_NAME , ORGNAME.NAME_SEARCH_KEY , ORGNAME.LAST_UPDATE_DT , ORGNAME.LAST_UPDATE_USER ,ORGNAME.LAST_UPDATE_TX_ID , ORGNAME.LAST_USED_DT , ORGNAME.LAST_VERIFIED_DT , ORGNAME.SOURCE_IDENT_TP_CD, ORGNAME.P_ORG_NAME, ORGNAME.STANDARD_IND, ORGNAME.XMODIFY_SYS_DT, ORGNAME.XORG_NAME_LOCAL, ORGNAME.XORGNAME_RETAILER_FLAG, ORGNAME.X_BPID" + 
     " FROM ORGNAME" + 
     " WHERE ((ORGNAME.CONT_ID = ? ) AND (ORGNAME.END_DT IS NULL OR ORGNAME.END_DT > ?))";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getOrgNameActiveParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.endDt=END_DT"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getOrgNameActiveResults =
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.orgNameIdPK=ORG_NAME_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.orgName=ORG_NAME," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.startDt=START_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.endDt=END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.orgNameTpCd=ORG_NAME_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.sOrgName=S_ORG_NAME," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.nameSearchKey=NAME_SEARCH_KEY," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.lastUsedDt=LAST_USED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.lastVerifiedDt=LAST_VERIFIED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.sourceIdentTpCd=SOURCE_IDENT_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.pOrgName=P_ORG_NAME," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.orgNameStandardInd=STANDARD_IND," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgNameExt.XLastModifiedSystemDate=XMODIFY_SYS_DT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgNameExt.XOrganizationNameLocal=XORG_NAME_LOCAL," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgNameExt.XOrgNameRetailerFlag=XORGNAME_RETAILER_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgNameExt.X_BPID=X_BPID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension XOrgName.
   *
   * @generated
   */ 
   public final static String getOrgNameInactiveSQL = "SELECT ORGNAME.ORG_NAME_ID , ORGNAME.CONT_ID , ORGNAME.ORG_NAME , ORGNAME.START_DT , ORGNAME.END_DT , ORGNAME.ORG_NAME_TP_CD , ORGNAME.S_ORG_NAME , ORGNAME.NAME_SEARCH_KEY , ORGNAME.LAST_UPDATE_DT , ORGNAME.LAST_UPDATE_USER , ORGNAME.LAST_UPDATE_TX_ID , ORGNAME.LAST_USED_DT , ORGNAME.LAST_VERIFIED_DT , ORGNAME.SOURCE_IDENT_TP_CD, ORGNAME.STANDARD_IND, ORGNAME.XMODIFY_SYS_DT, ORGNAME.XORG_NAME_LOCAL, ORGNAME.XORGNAME_RETAILER_FLAG, ORGNAME.X_BPID" + 
     " FROM ORGNAME" + 
     " WHERE ((ORGNAME.CONT_ID = ? ) AND (ORGNAME.END_DT < ? ))";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getOrgNameInactiveParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.endDt=END_DT"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getOrgNameInactiveResults =
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.orgNameIdPK=ORG_NAME_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.orgName=ORG_NAME," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.startDt=START_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.endDt=END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.orgNameTpCd=ORG_NAME_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.sOrgName=S_ORG_NAME," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.nameSearchKey=NAME_SEARCH_KEY," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.lastUsedDt=LAST_USED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.lastVerifiedDt=LAST_VERIFIED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.sourceIdentTpCd=SOURCE_IDENT_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.orgNameStandardInd=STANDARD_IND," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgNameExt.XLastModifiedSystemDate=XMODIFY_SYS_DT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgNameExt.XOrganizationNameLocal=XORG_NAME_LOCAL," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgNameExt.XOrgNameRetailerFlag=XORGNAME_RETAILER_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgNameExt.X_BPID=X_BPID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension XOrgName.
   *
   * @generated
   */ 
   public final static String getOrgNameSQL = "SELECT ORGNAME.ORG_NAME_ID , ORGNAME.CONT_ID , ORGNAME.ORG_NAME , ORGNAME.START_DT , ORGNAME.END_DT , ORGNAME.ORG_NAME_TP_CD , ORGNAME.S_ORG_NAME , ORGNAME.NAME_SEARCH_KEY , ORGNAME.LAST_UPDATE_DT , ORGNAME.LAST_UPDATE_USER , ORGNAME.LAST_UPDATE_TX_ID , ORGNAME.LAST_USED_DT , ORGNAME.LAST_VERIFIED_DT , ORGNAME.SOURCE_IDENT_TP_CD, ORGNAME.STANDARD_IND, ORGNAME.XMODIFY_SYS_DT, ORGNAME.XORG_NAME_LOCAL, ORGNAME.XORGNAME_RETAILER_FLAG, ORGNAME.X_BPID" + 
     " FROM ORGNAME" + 
     " WHERE (ORGNAME.CONT_ID = ? )";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getOrgNameParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.contId=CONT_ID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getOrgNameResults =
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.orgNameIdPK=ORG_NAME_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.orgName=ORG_NAME," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.startDt=START_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.endDt=END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.orgNameTpCd=ORG_NAME_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.sOrgName=S_ORG_NAME," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.nameSearchKey=NAME_SEARCH_KEY," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.lastUsedDt=LAST_USED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.lastVerifiedDt=LAST_VERIFIED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.sourceIdentTpCd=SOURCE_IDENT_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.orgNameStandardInd=STANDARD_IND," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgNameExt.XLastModifiedSystemDate=XMODIFY_SYS_DT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgNameExt.XOrganizationNameLocal=XORG_NAME_LOCAL," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgNameExt.XOrgNameRetailerFlag=XORGNAME_RETAILER_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgNameExt.X_BPID=X_BPID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension XOrgName.
   *
   * @generated
   */ 
   public final static String getOrgNameHistoryByTypeSQL = "SELECT DISTINCT A.H_ORG_NAME_ID AS HIST_ID_PK, A.H_ACTION_CODE , A.H_CREATED_BY , A.H_CREATE_DT , A.H_END_DT , A.ORG_NAME_ID , A.CONT_ID , A.ORG_NAME , A.START_DT , A.END_DT , A.ORG_NAME_TP_CD , A.S_ORG_NAME , A.NAME_SEARCH_KEY , A.LAST_UPDATE_DT , A.LAST_UPDATE_USER , A.LAST_UPDATE_TX_ID , A.LAST_USED_DT , A.LAST_VERIFIED_DT , A.SOURCE_IDENT_TP_CD, A.STANDARD_IND, A.XMODIFY_SYS_DT, A.XORG_NAME_LOCAL, A.XORGNAME_RETAILER_FLAG, A.X_BPID" + 
     " FROM H_ORGNAME A" + 
     " WHERE A.CONT_ID = ? AND A.ORG_NAME_TP_CD = ? AND (? BETWEEN A.H_CREATE_DT AND A.H_END_DT OR (? >= A.H_CREATE_DT AND A.H_END_DT IS NULL ))";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getOrgNameHistoryByTypeParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.orgNameTpCd=ORG_NAME_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.histCreateDt=H_CREATE_DT"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getOrgNameHistoryByTypeResults =
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.historyIdPK=HIST_ID_PK," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.histActionCode=H_ACTION_CODE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.histCreatedBy=H_CREATED_BY," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.histEndDt=H_END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.orgNameIdPK=ORG_NAME_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.orgName=ORG_NAME," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.startDt=START_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.endDt=END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.orgNameTpCd=ORG_NAME_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.sOrgName=S_ORG_NAME," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.nameSearchKey=NAME_SEARCH_KEY," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.lastUsedDt=LAST_USED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.lastVerifiedDt=LAST_VERIFIED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.sourceIdentTpCd=SOURCE_IDENT_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.orgNameStandardInd=STANDARD_IND," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgNameExt.XLastModifiedSystemDate=XMODIFY_SYS_DT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgNameExt.XOrganizationNameLocal=XORG_NAME_LOCAL," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgNameExt.XOrgNameRetailerFlag=XORGNAME_RETAILER_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgNameExt.X_BPID=X_BPID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension XOrgName.
   *
   * @generated
   */ 
   public final static String getOrgNameByTypeSQL = "SELECT ORGNAME.ORG_NAME_ID , ORGNAME.CONT_ID , ORGNAME.ORG_NAME , ORGNAME.START_DT , ORGNAME.END_DT , ORGNAME.ORG_NAME_TP_CD , ORGNAME.S_ORG_NAME , ORGNAME.NAME_SEARCH_KEY , ORGNAME.LAST_UPDATE_DT , ORGNAME.LAST_UPDATE_USER , ORGNAME.LAST_UPDATE_TX_ID , ORGNAME.LAST_USED_DT , ORGNAME.LAST_VERIFIED_DT , ORGNAME.SOURCE_IDENT_TP_CD, ORGNAME.STANDARD_IND, ORGNAME.XMODIFY_SYS_DT, ORGNAME.XORG_NAME_LOCAL, ORGNAME.XORGNAME_RETAILER_FLAG, ORGNAME.X_BPID" + 
     " FROM ORGNAME" + 
     " WHERE ((ORGNAME.CONT_ID = ? ) AND (ORGNAME.ORG_NAME_TP_CD = ?) AND (ORGNAME.END_DT IS NULL OR ORGNAME.END_DT > ?))";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getOrgNameByTypeParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.orgNameTpCd=ORG_NAME_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.endDt=END_DT"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getOrgNameByTypeResults =
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.orgNameIdPK=ORG_NAME_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.orgName=ORG_NAME," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.startDt=START_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.endDt=END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.orgNameTpCd=ORG_NAME_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.sOrgName=S_ORG_NAME," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.nameSearchKey=NAME_SEARCH_KEY," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.lastUsedDt=LAST_USED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.lastVerifiedDt=LAST_VERIFIED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.sourceIdentTpCd=SOURCE_IDENT_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.orgNameStandardInd=STANDARD_IND," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgNameExt.XLastModifiedSystemDate=XMODIFY_SYS_DT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgNameExt.XOrganizationNameLocal=XORG_NAME_LOCAL," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgNameExt.XOrgNameRetailerFlag=XORGNAME_RETAILER_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgNameExt.X_BPID=X_BPID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension XOrgName.
   *
   * @generated
   */ 
   public final static String getOrgNameByIDSQL = "SELECT ORGNAME.ORG_NAME_ID ,ORGNAME.CONT_ID ,ORGNAME.ORG_NAME ,ORGNAME.START_DT ,ORGNAME.END_DT ,ORGNAME.ORG_NAME_TP_CD , ORGNAME.S_ORG_NAME ,ORGNAME.NAME_SEARCH_KEY ,ORGNAME.LAST_UPDATE_DT ,ORGNAME.LAST_UPDATE_USER , ORGNAME.LAST_UPDATE_TX_ID , ORGNAME.LAST_USED_DT , ORGNAME.LAST_VERIFIED_DT , ORGNAME.SOURCE_IDENT_TP_CD, ORGNAME.STANDARD_IND, ORGNAME.XMODIFY_SYS_DT, ORGNAME.XORG_NAME_LOCAL, ORGNAME.XORGNAME_RETAILER_FLAG, ORGNAME.X_BPID" + 
     " FROM ORGNAME" + 
     " WHERE (ORGNAME.ORG_NAME_ID = ?)";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getOrgNameByIDParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.orgNameIdPK=ORG_NAME_ID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getOrgNameByIDResults =
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.orgNameIdPK=ORG_NAME_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.orgName=ORG_NAME," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.startDt=START_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.endDt=END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.orgNameTpCd=ORG_NAME_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.sOrgName=S_ORG_NAME," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.nameSearchKey=NAME_SEARCH_KEY," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.lastUsedDt=LAST_USED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.lastVerifiedDt=LAST_VERIFIED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.sourceIdentTpCd=SOURCE_IDENT_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.orgNameStandardInd=STANDARD_IND," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgNameExt.XLastModifiedSystemDate=XMODIFY_SYS_DT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgNameExt.XOrganizationNameLocal=XORG_NAME_LOCAL," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgNameExt.XOrgNameRetailerFlag=XORGNAME_RETAILER_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgNameExt.X_BPID=X_BPID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension XOrgName.
   *
   * @generated
   */ 
   public final static String getOrgNameHistoryByIDSQL = "SELECT H_ORGNAME.H_ORG_NAME_ID AS HIST_ID_PK, H_ORGNAME.H_ACTION_CODE, H_ORGNAME.H_CREATED_BY, H_ORGNAME.H_CREATE_DT, H_ORGNAME.CONT_ID , H_ORGNAME.ORG_NAME , H_ORGNAME.START_DT , H_ORGNAME.END_DT , H_ORGNAME.ORG_NAME_TP_CD , H_ORGNAME.S_ORG_NAME , H_ORGNAME.NAME_SEARCH_KEY , H_ORGNAME.LAST_UPDATE_DT , H_ORGNAME.LAST_UPDATE_USER , H_ORGNAME.LAST_UPDATE_TX_ID , H_ORGNAME.LAST_USED_DT , H_ORGNAME.LAST_VERIFIED_DT , H_ORGNAME.SOURCE_IDENT_TP_CD, H_ORGNAME.STANDARD_IND,H_ORGNAME.ORG_NAME_ID,H_ORGNAME.H_END_DT, H_ORGNAME.XMODIFY_SYS_DT, H_ORGNAME.XORG_NAME_LOCAL, H_ORGNAME.XORGNAME_RETAILER_FLAG, H_ORGNAME.X_BPID" + 
     " FROM H_ORGNAME" + 
     " WHERE (H_ORGNAME.H_ORG_NAME_ID = ?) AND (( ? BETWEEN H_ORGNAME.H_CREATE_DT AND H_ORGNAME.H_END_DT ) OR ( ? >= H_ORGNAME.H_CREATE_DT AND H_ORGNAME.H_END_DT IS NULL ))";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getOrgNameHistoryByIDParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.historyIdPK=H_ORG_NAME_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.histCreateDt=H_CREATE_DT"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getOrgNameHistoryByIDResults =
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.historyIdPK=HIST_ID_PK," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.histActionCode=H_ACTION_CODE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.histCreatedBy=H_CREATED_BY," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.orgName=ORG_NAME," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.startDt=START_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.endDt=END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.orgNameTpCd=ORG_NAME_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.sOrgName=S_ORG_NAME," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.nameSearchKey=NAME_SEARCH_KEY," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.lastUsedDt=LAST_USED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.lastVerifiedDt=LAST_VERIFIED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.sourceIdentTpCd=SOURCE_IDENT_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.orgNameStandardInd=STANDARD_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.orgNameIdPK=ORG_NAME_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.histEndDt=H_END_DT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgNameExt.XLastModifiedSystemDate=XMODIFY_SYS_DT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgNameExt.XOrganizationNameLocal=XORG_NAME_LOCAL," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgNameExt.XOrgNameRetailerFlag=XORGNAME_RETAILER_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgNameExt.X_BPID=X_BPID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension XOrgName.
   *
   * @generated
   */ 
   public final static String getOrgNameImagesSQL = "SELECT DISTINCT A.H_ORG_NAME_ID AS HIST_ID_PK, A.H_ACTION_CODE , A.H_CREATED_BY , A.H_CREATE_DT , A.H_END_DT , A.ORG_NAME_ID , A.CONT_ID , A.ORG_NAME , A.START_DT , A.END_DT , A.ORG_NAME_TP_CD , A.S_ORG_NAME , A.NAME_SEARCH_KEY , A.LAST_UPDATE_DT , A.LAST_UPDATE_USER , A.LAST_UPDATE_TX_ID , A.LAST_USED_DT , A.LAST_VERIFIED_DT , A.SOURCE_IDENT_TP_CD, A.STANDARD_IND, A.XMODIFY_SYS_DT, A.XORG_NAME_LOCAL, A.XORGNAME_RETAILER_FLAG, A.X_BPID" + 
     " FROM H_ORGNAME A" + 
     " WHERE A.CONT_ID = ? AND ( A.H_CREATE_DT BETWEEN ? AND ? )";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getOrgNameImagesParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.histCreateDt=H_CREATE_DT"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getOrgNameImagesResults =
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.historyIdPK=HIST_ID_PK," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.histActionCode=H_ACTION_CODE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.histCreatedBy=H_CREATED_BY," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.histEndDt=H_END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.orgNameIdPK=ORG_NAME_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.orgName=ORG_NAME," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.startDt=START_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.endDt=END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.orgNameTpCd=ORG_NAME_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.sOrgName=S_ORG_NAME," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.nameSearchKey=NAME_SEARCH_KEY," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.lastUsedDt=LAST_USED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.lastVerifiedDt=LAST_VERIFIED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.sourceIdentTpCd=SOURCE_IDENT_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.orgNameStandardInd=STANDARD_IND," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgNameExt.XLastModifiedSystemDate=XMODIFY_SYS_DT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgNameExt.XOrganizationNameLocal=XORG_NAME_LOCAL," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgNameExt.XOrgNameRetailerFlag=XORGNAME_RETAILER_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgNameExt.X_BPID=X_BPID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension XOrgName.
   *
   * @generated
   */ 
   public final static String getOrgNameLightImagesSQL = "SELECT DISTINCT A.ORG_NAME_ID , A.LAST_UPDATE_DT, A.XMODIFY_SYS_DT, A.XORG_NAME_LOCAL, A.XORGNAME_RETAILER_FLAG, A.X_BPID" + 
     " FROM H_ORGNAME A" + 
     " WHERE A.CONT_ID = ? AND ( A.H_CREATE_DT BETWEEN ? AND ? )";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getOrgNameLightImagesParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.histCreateDt=H_CREATE_DT"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getOrgNameLightImagesResults =
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.orgNameIdPK=ORG_NAME_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgNameExt.XLastModifiedSystemDate=XMODIFY_SYS_DT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgNameExt.XOrganizationNameLocal=XORG_NAME_LOCAL," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgNameExt.XOrgNameRetailerFlag=XORGNAME_RETAILER_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgNameExt.X_BPID=X_BPID"; 


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getOrgNameHistorySQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getOrgNameHistoryParameters, results=getOrgNameHistoryResults)
  		Iterator<ResultQueue2<EObjOrgName, EObjXOrgNameExt>> getOrgNameHistory(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getOrgNameActiveSQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getOrgNameActiveParameters, results=getOrgNameActiveResults)
  		Iterator<ResultQueue2<EObjOrgName, EObjXOrgNameExt>> getOrgNameActive(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getOrgNameInactiveSQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getOrgNameInactiveParameters, results=getOrgNameInactiveResults)
  		Iterator<ResultQueue2<EObjOrgName, EObjXOrgNameExt>> getOrgNameInactive(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getOrgNameSQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getOrgNameParameters, results=getOrgNameResults)
  		Iterator<ResultQueue2<EObjOrgName, EObjXOrgNameExt>> getOrgName(Long parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getOrgNameHistoryByTypeSQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getOrgNameHistoryByTypeParameters, results=getOrgNameHistoryByTypeResults)
  		Iterator<ResultQueue2<EObjOrgName, EObjXOrgNameExt>> getOrgNameHistoryByType(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getOrgNameByTypeSQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getOrgNameByTypeParameters, results=getOrgNameByTypeResults)
  		Iterator<ResultQueue2<EObjOrgName, EObjXOrgNameExt>> getOrgNameByType(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getOrgNameByIDSQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getOrgNameByIDParameters, results=getOrgNameByIDResults)
  		Iterator<ResultQueue2<EObjOrgName, EObjXOrgNameExt>> getOrgNameByID(Long parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getOrgNameHistoryByIDSQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getOrgNameHistoryByIDParameters, results=getOrgNameHistoryByIDResults)
  		Iterator<ResultQueue2<EObjOrgName, EObjXOrgNameExt>> getOrgNameHistoryByID(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getOrgNameImagesSQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getOrgNameImagesParameters, results=getOrgNameImagesResults)
  		Iterator<ResultQueue2<EObjOrgName, EObjXOrgNameExt>> getOrgNameImages(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getOrgNameLightImagesSQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getOrgNameLightImagesParameters, results=getOrgNameLightImagesResults)
  		Iterator<ResultQueue2<EObjOrgName, EObjXOrgNameExt>> getOrgNameLightImages(Object[] parameters);
 
}


