package com.ibm.daimler.dsea.entityObject;

import com.ibm.pdq.runtime.generator.BaseParameterHandler;
import java.util.Iterator;
import java.sql.PreparedStatement;
import com.ibm.pdq.runtime.statement.StatementDescriptor;
import com.ibm.pdq.runtime.generator.BaseData;
import java.sql.SQLException;
import com.ibm.daimler.dsea.entityObject.EObjXAddressExt;
import com.ibm.pdq.annotation.Metadata;
import com.dwl.tcrm.coreParty.entityObject.EObjAddress;
import com.ibm.pdq.runtime.generator.BaseRowHandler;
import com.ibm.pdq.runtime.statement.SqlStatementType;
import java.sql.Types;


/**
 * <!-- begin-user-doc -->
 * 
 * <!-- end-user-doc -->
 * 
 * @generated
 */
public class EObjXAddressExtDataImpl  extends BaseData implements EObjXAddressExtData
{

  /**
   * @generated
   */
  public static final String generatorVersion = "3.200.75";

  /**
   * @generated
   */
  public static final String identifier = "EObjXAddressExtData";

  /**
   * @generated
   */
  public static final long generationTime = 0x0000015de99d0b46L;

  /**
   * @generated
   */
  public static final String collection = "NULLID";

  /**
   * @generated
   */
  public static final String packageVersion = null;

  /**
   * @generated
   */
  public static final boolean forceSingleBindIsolation = false;

  /**
   * @generated
   */
  public EObjXAddressExtDataImpl()
  {
    super();
  } 

  /**
   * @generated
   */
  public String getGeneratorVersion()
  {
    return generatorVersion;
  }

  /**
   * @Select( sql="select XADDR_VERIFICATION_DT, XSUBCITY_TP_CD, XDISTRICT_TP_CD, XBUILDING_NAME, XSTREET_NUMBER, XSTREET_NAME, XSuburb, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from ADDRESS where ADDRESS_ID = ? " )
   * 
   * @generated
   */
  public Iterator<EObjXAddressExt> getEObjXAddressExt (Long addressIdPK)
  {
    return queryIterator (getEObjXAddressExtStatementDescriptor, addressIdPK);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getEObjXAddressExtStatementDescriptor = createStatementDescriptor (
    "getEObjXAddressExt(Long)",
    "select XADDR_VERIFICATION_DT, XSUBCITY_TP_CD, XDISTRICT_TP_CD, XBUILDING_NAME, XSTREET_NUMBER, XSTREET_NAME, XSuburb, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from ADDRESS where ADDRESS_ID = ? ",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"xaddr_verification_dt", "xsubcity_tp_cd", "xdistrict_tp_cd", "xbuilding_name", "xstreet_number", "xstreet_name", "xsuburb", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetEObjXAddressExtParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetEObjXAddressExtRowHandler (),
    new int[][]{ {Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {0, 19, 19, 500, 500, 250, 255, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    1);

  /**
   * @generated
   */
  public static class GetEObjXAddressExtParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setLong (stmt, 1, Types.BIGINT, (Long)parameters[0]);
    }
  }

  /**
   * @generated
   */
  public static class GetEObjXAddressExtRowHandler extends BaseRowHandler<EObjXAddressExt>
  {
    /**
     * @generated
     */
    public EObjXAddressExt handle (java.sql.ResultSet rs, EObjXAddressExt returnObject) throws java.sql.SQLException
    {
      returnObject = new EObjXAddressExt ();
      returnObject.setXAddressVerificationDate(getTimestamp (rs, 1)); 
      returnObject.setXSubcity(getLongObject (rs, 2)); 
      returnObject.setXDistrict(getLongObject (rs, 3)); 
      returnObject.setXBuildingName(getString (rs, 4)); 
      returnObject.setXStreetNumber(getString (rs, 5)); 
      returnObject.setXStreetName(getString (rs, 6)); 
      returnObject.setXSuburb(getString (rs, 7)); 
      returnObject.setLastUpdateDt(getTimestamp (rs, 8)); 
      returnObject.setLastUpdateUser(getString (rs, 9)); 
      returnObject.setLastUpdateTxId(getLongObject (rs, 10)); 
    
      return returnObject;
    }
  }

  /**
   * @Update( sql="insert into ADDRESS (POSTAL_BARCODE, ADDR_LINE_ONE, ADDR_LINE_THREE, ADDR_LINE_TWO, CITY_NAME, COUNTY_CODE, LATITUDE_DEGREES, LONGITUDE_DEGREES, RESIDENCE_NUM, ADDR_STANDARD_IND, OVERRIDE_IND, POSTAL_CODE, ADDRESS_ID, BOX_ID, BUILDING_NAME, STREET_NUMBER, STREET_NAME, STREET_SUFFIX, PRE_DIRECTIONAL, POST_DIRECTIONAL, BOX_DESIGNATOR, STN_INFO, STN_ID, REGION, DEL_DESIGNATOR, DEL_ID, DEL_INFO, COUNTRY_TP_CD, PROV_STATE_TP_CD, RESIDENCE_TP_CD, P_CITY, P_STREET_NAME, STREET_PREFIX, P_ADDR_LINE_ONE, P_ADDR_LINE_THREE, P_ADDR_LINE_TWO, XADDR_VERIFICATION_DT, XSUBCITY_TP_CD, XDISTRICT_TP_CD, XBUILDING_NAME, XSTREET_NUMBER, XSTREET_NAME, XSuburb, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( ?1.postalBarCode, ?1.addrLineOne, ?1.addrLineThree, ?1.addrLineTwo, ?1.cityName, ?1.countyCode, ?1.latitudeDegrees, ?1.longtitudeDegrees, ?1.residenceNum, ?1.addrStandardInd, ?1.overrideInd, ?1.postalCode, ?1.addressIdPK, ?1.boxId, ?1.buildingName, ?1.streetNumber, ?1.streetName, ?1.streetSuffix, ?1.preDirectional, ?1.postDirectional, ?1.boxDesignator, ?1.stnInfo, ?1.stnId, ?1.region, ?1.delDesignator, ?1.delId, ?1.delInfo, ?1.countryTpCd, ?1.provStateTpCd, ?1.residenceTpCd, ?1.pCityName, ?1.pStreetName, ?1.streetPrefix, ?1.pAddrLineOne, ?1.pAddrLineThree, ?1.pAddrLineTwo, ?2.xAddressVerificationDate, ?2.xSubcity, ?2.xDistrict, ?2.xBuildingName, ?2.xStreetNumber, ?2.xStreetName, ?2.xSuburb, ?1.lastUpdateDt, ?1.lastUpdateUser, ?1.lastUpdateTxId)" )
   * 
   * @generated
   */
  public int createEObjXAddressExt (EObjAddress e1, EObjXAddressExt e2)
  {
    return update (createEObjXAddressExtStatementDescriptor, e1, e2);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor createEObjXAddressExtStatementDescriptor = createStatementDescriptor (
    "createEObjXAddressExt(com.dwl.tcrm.coreParty.entityObject.EObjAddress, com.ibm.daimler.dsea.entityObject.EObjXAddressExt)",
    "insert into ADDRESS (POSTAL_BARCODE, ADDR_LINE_ONE, ADDR_LINE_THREE, ADDR_LINE_TWO, CITY_NAME, COUNTY_CODE, LATITUDE_DEGREES, LONGITUDE_DEGREES, RESIDENCE_NUM, ADDR_STANDARD_IND, OVERRIDE_IND, POSTAL_CODE, ADDRESS_ID, BOX_ID, BUILDING_NAME, STREET_NUMBER, STREET_NAME, STREET_SUFFIX, PRE_DIRECTIONAL, POST_DIRECTIONAL, BOX_DESIGNATOR, STN_INFO, STN_ID, REGION, DEL_DESIGNATOR, DEL_ID, DEL_INFO, COUNTRY_TP_CD, PROV_STATE_TP_CD, RESIDENCE_TP_CD, P_CITY, P_STREET_NAME, STREET_PREFIX, P_ADDR_LINE_ONE, P_ADDR_LINE_THREE, P_ADDR_LINE_TWO, XADDR_VERIFICATION_DT, XSUBCITY_TP_CD, XDISTRICT_TP_CD, XBUILDING_NAME, XSTREET_NUMBER, XSTREET_NAME, XSuburb, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values(  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? )",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.INSERT,
    null,
    new CreateEObjXAddressExtParameterHandler (),
    new int[][]{{Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.CHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.CHAR, Types.CHAR, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.CHAR, Types.CHAR, Types.CHAR, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {30, 100, 100, 100, 50, 3, 10, 10, 10, 1, 1, 20, 19, 16, 64, 16, 64, 16, 16, 16, 16, 16, 16, 32, 16, 16, 50, 19, 19, 19, 20, 30, 16, 8, 8, 8, 0, 19, 19, 500, 500, 250, 255, 0, 0, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    2);

  /**
   * @generated
   */
  public static class CreateEObjXAddressExtParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      EObjAddress bean0 = (EObjAddress) parameters[0];
      setString (stmt, 1, Types.VARCHAR, (String)bean0.getPostalBarCode());
      setString (stmt, 2, Types.VARCHAR, (String)bean0.getAddrLineOne());
      setString (stmt, 3, Types.VARCHAR, (String)bean0.getAddrLineThree());
      setString (stmt, 4, Types.VARCHAR, (String)bean0.getAddrLineTwo());
      setString (stmt, 5, Types.VARCHAR, (String)bean0.getCityName());
      setString (stmt, 6, Types.CHAR, (String)bean0.getCountyCode());
      setString (stmt, 7, Types.VARCHAR, (String)bean0.getLatitudeDegrees());
      setString (stmt, 8, Types.VARCHAR, (String)bean0.getLongtitudeDegrees());
      setString (stmt, 9, Types.VARCHAR, (String)bean0.getResidenceNum());
      setString (stmt, 10, Types.CHAR, (String)bean0.getAddrStandardInd());
      setString (stmt, 11, Types.CHAR, (String)bean0.getOverrideInd());
      setString (stmt, 12, Types.VARCHAR, (String)bean0.getPostalCode());
      setLong (stmt, 13, Types.BIGINT, (Long)bean0.getAddressIdPK());
      setString (stmt, 14, Types.VARCHAR, (String)bean0.getBoxId());
      setString (stmt, 15, Types.VARCHAR, (String)bean0.getBuildingName());
      setString (stmt, 16, Types.VARCHAR, (String)bean0.getStreetNumber());
      setString (stmt, 17, Types.VARCHAR, (String)bean0.getStreetName());
      setString (stmt, 18, Types.VARCHAR, (String)bean0.getStreetSuffix());
      setString (stmt, 19, Types.VARCHAR, (String)bean0.getPreDirectional());
      setString (stmt, 20, Types.VARCHAR, (String)bean0.getPostDirectional());
      setString (stmt, 21, Types.VARCHAR, (String)bean0.getBoxDesignator());
      setString (stmt, 22, Types.VARCHAR, (String)bean0.getStnInfo());
      setString (stmt, 23, Types.VARCHAR, (String)bean0.getStnId());
      setString (stmt, 24, Types.VARCHAR, (String)bean0.getRegion());
      setString (stmt, 25, Types.VARCHAR, (String)bean0.getDelDesignator());
      setString (stmt, 26, Types.VARCHAR, (String)bean0.getDelId());
      setString (stmt, 27, Types.VARCHAR, (String)bean0.getDelInfo());
      setLong (stmt, 28, Types.BIGINT, (Long)bean0.getCountryTpCd());
      setLong (stmt, 29, Types.BIGINT, (Long)bean0.getProvStateTpCd());
      setLong (stmt, 30, Types.BIGINT, (Long)bean0.getResidenceTpCd());
      setString (stmt, 31, Types.VARCHAR, (String)bean0.getPCityName());
      setString (stmt, 32, Types.VARCHAR, (String)bean0.getPStreetName());
      setString (stmt, 33, Types.VARCHAR, (String)bean0.getStreetPrefix());
      setString (stmt, 34, Types.CHAR, (String)bean0.getPAddrLineOne());
      setString (stmt, 35, Types.CHAR, (String)bean0.getPAddrLineThree());
      setString (stmt, 36, Types.CHAR, (String)bean0.getPAddrLineTwo());
      EObjXAddressExt bean1 = (EObjXAddressExt) parameters[1];
      setTimestamp (stmt, 37, Types.TIMESTAMP, (java.sql.Timestamp)bean1.getXAddressVerificationDate());
      setLong (stmt, 38, Types.BIGINT, (Long)bean1.getXSubcity());
      setLong (stmt, 39, Types.BIGINT, (Long)bean1.getXDistrict());
      setString (stmt, 40, Types.VARCHAR, (String)bean1.getXBuildingName());
      setString (stmt, 41, Types.VARCHAR, (String)bean1.getXStreetNumber());
      setString (stmt, 42, Types.VARCHAR, (String)bean1.getXStreetName());
      setString (stmt, 43, Types.VARCHAR, (String)bean1.getXSuburb());
      setTimestamp (stmt, 44, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUpdateDt());
      setString (stmt, 45, Types.VARCHAR, (String)bean0.getLastUpdateUser());
      setLong (stmt, 46, Types.BIGINT, (Long)bean0.getLastUpdateTxId());
    }
  }

  /**
   * @Update( sql="update ADDRESS set POSTAL_BARCODE = ?1.postalBarCode, ADDR_LINE_ONE = ?1.addrLineOne, ADDR_LINE_THREE = ?1.addrLineThree, ADDR_LINE_TWO = ?1.addrLineTwo, CITY_NAME = ?1.cityName, COUNTY_CODE = ?1.countyCode, LATITUDE_DEGREES = ?1.latitudeDegrees, LONGITUDE_DEGREES = ?1.longtitudeDegrees, RESIDENCE_NUM = ?1.residenceNum, ADDR_STANDARD_IND = ?1.addrStandardInd, OVERRIDE_IND = ?1.overrideInd, POSTAL_CODE = ?1.postalCode, BOX_ID = ?1.boxId, BUILDING_NAME = ?1.buildingName, STREET_NUMBER = ?1.streetNumber, STREET_NAME = ?1.streetName, STREET_SUFFIX = ?1.streetSuffix, PRE_DIRECTIONAL = ?1.preDirectional, POST_DIRECTIONAL = ?1.postDirectional, BOX_DESIGNATOR = ?1.boxDesignator, STN_INFO = ?1.stnInfo, STN_ID = ?1.stnId, REGION = ?1.region, DEL_DESIGNATOR = ?1.delDesignator, DEL_ID = ?1.delId, DEL_INFO = ?1.delInfo, COUNTRY_TP_CD = ?1.countryTpCd, PROV_STATE_TP_CD = ?1.provStateTpCd, RESIDENCE_TP_CD = ?1.residenceTpCd, P_CITY = ?1.pCityName, P_STREET_NAME = ?1.pStreetName, STREET_PREFIX = ?1.streetPrefix, P_ADDR_LINE_ONE = ?1.pAddrLineOne, P_ADDR_LINE_THREE = ?1.pAddrLineThree, P_ADDR_LINE_TWO = ?1.pAddrLineTwo, XADDR_VERIFICATION_DT = ?2.xAddressVerificationDate, XSUBCITY_TP_CD = ?2.xSubcity, XDISTRICT_TP_CD = ?2.xDistrict, XBUILDING_NAME = ?2.xBuildingName, XSTREET_NUMBER = ?2.xStreetNumber, XSTREET_NAME = ?2.xStreetName, XSuburb = ?2.xSuburb, LAST_UPDATE_DT = ?1.lastUpdateDt, LAST_UPDATE_USER = ?1.lastUpdateUser, LAST_UPDATE_TX_ID = ?1.lastUpdateTxId where ADDRESS_ID = ?1.addressIdPK and LAST_UPDATE_DT = ?1.oldLastUpdateDt" )
   * 
   * @generated
   */
  public int updateEObjXAddressExt (EObjAddress e1, EObjXAddressExt e2)
  {
    return update (updateEObjXAddressExtStatementDescriptor, e1, e2);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor updateEObjXAddressExtStatementDescriptor = createStatementDescriptor (
    "updateEObjXAddressExt(com.dwl.tcrm.coreParty.entityObject.EObjAddress, com.ibm.daimler.dsea.entityObject.EObjXAddressExt)",
    "update ADDRESS set POSTAL_BARCODE =  ? , ADDR_LINE_ONE =  ? , ADDR_LINE_THREE =  ? , ADDR_LINE_TWO =  ? , CITY_NAME =  ? , COUNTY_CODE =  ? , LATITUDE_DEGREES =  ? , LONGITUDE_DEGREES =  ? , RESIDENCE_NUM =  ? , ADDR_STANDARD_IND =  ? , OVERRIDE_IND =  ? , POSTAL_CODE =  ? , BOX_ID =  ? , BUILDING_NAME =  ? , STREET_NUMBER =  ? , STREET_NAME =  ? , STREET_SUFFIX =  ? , PRE_DIRECTIONAL =  ? , POST_DIRECTIONAL =  ? , BOX_DESIGNATOR =  ? , STN_INFO =  ? , STN_ID =  ? , REGION =  ? , DEL_DESIGNATOR =  ? , DEL_ID =  ? , DEL_INFO =  ? , COUNTRY_TP_CD =  ? , PROV_STATE_TP_CD =  ? , RESIDENCE_TP_CD =  ? , P_CITY =  ? , P_STREET_NAME =  ? , STREET_PREFIX =  ? , P_ADDR_LINE_ONE =  ? , P_ADDR_LINE_THREE =  ? , P_ADDR_LINE_TWO =  ? , XADDR_VERIFICATION_DT =  ? , XSUBCITY_TP_CD =  ? , XDISTRICT_TP_CD =  ? , XBUILDING_NAME =  ? , XSTREET_NUMBER =  ? , XSTREET_NAME =  ? , XSuburb =  ? , LAST_UPDATE_DT =  ? , LAST_UPDATE_USER =  ? , LAST_UPDATE_TX_ID =  ?  where ADDRESS_ID =  ?  and LAST_UPDATE_DT =  ? ",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.UPDATE,
    null,
    new UpdateEObjXAddressExtParameterHandler (),
    new int[][]{{Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.CHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.CHAR, Types.CHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.CHAR, Types.CHAR, Types.CHAR, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP}, {30, 100, 100, 100, 50, 3, 10, 10, 10, 1, 1, 20, 16, 64, 16, 64, 16, 16, 16, 16, 16, 16, 32, 16, 16, 50, 19, 19, 19, 20, 30, 16, 8, 8, 8, 0, 19, 19, 500, 500, 250, 255, 0, 0, 19, 19, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    3);

  /**
   * @generated
   */
  public static class UpdateEObjXAddressExtParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      EObjAddress bean0 = (EObjAddress) parameters[0];
      setString (stmt, 1, Types.VARCHAR, (String)bean0.getPostalBarCode());
      setString (stmt, 2, Types.VARCHAR, (String)bean0.getAddrLineOne());
      setString (stmt, 3, Types.VARCHAR, (String)bean0.getAddrLineThree());
      setString (stmt, 4, Types.VARCHAR, (String)bean0.getAddrLineTwo());
      setString (stmt, 5, Types.VARCHAR, (String)bean0.getCityName());
      setString (stmt, 6, Types.CHAR, (String)bean0.getCountyCode());
      setString (stmt, 7, Types.VARCHAR, (String)bean0.getLatitudeDegrees());
      setString (stmt, 8, Types.VARCHAR, (String)bean0.getLongtitudeDegrees());
      setString (stmt, 9, Types.VARCHAR, (String)bean0.getResidenceNum());
      setString (stmt, 10, Types.CHAR, (String)bean0.getAddrStandardInd());
      setString (stmt, 11, Types.CHAR, (String)bean0.getOverrideInd());
      setString (stmt, 12, Types.VARCHAR, (String)bean0.getPostalCode());
      setString (stmt, 13, Types.VARCHAR, (String)bean0.getBoxId());
      setString (stmt, 14, Types.VARCHAR, (String)bean0.getBuildingName());
      setString (stmt, 15, Types.VARCHAR, (String)bean0.getStreetNumber());
      setString (stmt, 16, Types.VARCHAR, (String)bean0.getStreetName());
      setString (stmt, 17, Types.VARCHAR, (String)bean0.getStreetSuffix());
      setString (stmt, 18, Types.VARCHAR, (String)bean0.getPreDirectional());
      setString (stmt, 19, Types.VARCHAR, (String)bean0.getPostDirectional());
      setString (stmt, 20, Types.VARCHAR, (String)bean0.getBoxDesignator());
      setString (stmt, 21, Types.VARCHAR, (String)bean0.getStnInfo());
      setString (stmt, 22, Types.VARCHAR, (String)bean0.getStnId());
      setString (stmt, 23, Types.VARCHAR, (String)bean0.getRegion());
      setString (stmt, 24, Types.VARCHAR, (String)bean0.getDelDesignator());
      setString (stmt, 25, Types.VARCHAR, (String)bean0.getDelId());
      setString (stmt, 26, Types.VARCHAR, (String)bean0.getDelInfo());
      setLong (stmt, 27, Types.BIGINT, (Long)bean0.getCountryTpCd());
      setLong (stmt, 28, Types.BIGINT, (Long)bean0.getProvStateTpCd());
      setLong (stmt, 29, Types.BIGINT, (Long)bean0.getResidenceTpCd());
      setString (stmt, 30, Types.VARCHAR, (String)bean0.getPCityName());
      setString (stmt, 31, Types.VARCHAR, (String)bean0.getPStreetName());
      setString (stmt, 32, Types.VARCHAR, (String)bean0.getStreetPrefix());
      setString (stmt, 33, Types.CHAR, (String)bean0.getPAddrLineOne());
      setString (stmt, 34, Types.CHAR, (String)bean0.getPAddrLineThree());
      setString (stmt, 35, Types.CHAR, (String)bean0.getPAddrLineTwo());
      EObjXAddressExt bean1 = (EObjXAddressExt) parameters[1];
      setTimestamp (stmt, 36, Types.TIMESTAMP, (java.sql.Timestamp)bean1.getXAddressVerificationDate());
      setLong (stmt, 37, Types.BIGINT, (Long)bean1.getXSubcity());
      setLong (stmt, 38, Types.BIGINT, (Long)bean1.getXDistrict());
      setString (stmt, 39, Types.VARCHAR, (String)bean1.getXBuildingName());
      setString (stmt, 40, Types.VARCHAR, (String)bean1.getXStreetNumber());
      setString (stmt, 41, Types.VARCHAR, (String)bean1.getXStreetName());
      setString (stmt, 42, Types.VARCHAR, (String)bean1.getXSuburb());
      setTimestamp (stmt, 43, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUpdateDt());
      setString (stmt, 44, Types.VARCHAR, (String)bean0.getLastUpdateUser());
      setLong (stmt, 45, Types.BIGINT, (Long)bean0.getLastUpdateTxId());
      setLong (stmt, 46, Types.BIGINT, (Long)bean0.getAddressIdPK());
      setTimestamp (stmt, 47, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getOldLastUpdateDt());
    }
  }

  /**
   * @Update( sql="delete from ADDRESS where ADDRESS_ID = ?" )
   * 
   * @generated
   */
  public int deleteEObjXAddressExt (Long addressIdPK)
  {
    return update (deleteEObjXAddressExtStatementDescriptor, addressIdPK);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor deleteEObjXAddressExtStatementDescriptor = createStatementDescriptor (
    "deleteEObjXAddressExt(Long)",
    "delete from ADDRESS where ADDRESS_ID = ?",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.DELETE,
    null,
    new DeleteEObjXAddressExtParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    4);

  /**
   * @generated
   */
  public static class DeleteEObjXAddressExtParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setLong (stmt, 1, Types.BIGINT, (Long)parameters[0]);
    }
  }

}
