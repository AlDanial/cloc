package com.ibm.daimler.dsea.entityObject;

import com.ibm.pdq.runtime.generator.BaseParameterHandler;
import com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRole;
import java.util.Iterator;
import com.ibm.mdm.base.db.ResultQueue1;
import java.sql.PreparedStatement;
import com.ibm.pdq.runtime.statement.StatementDescriptor;
import com.ibm.pdq.runtime.generator.BaseData;
import java.sql.SQLException;
import com.ibm.pdq.annotation.Metadata;
import com.ibm.pdq.runtime.generator.BaseRowHandler;
import com.ibm.pdq.runtime.statement.SqlStatementType;
import java.sql.Types;


@SuppressWarnings("unchecked")

/**
 * <!-- begin-user-doc -->
 * 
 * <!-- end-user-doc -->
 * 
 * @generated
 */
public class XCustomerVehicleRoleInquiryDataImpl  extends BaseData implements XCustomerVehicleRoleInquiryData
{

  /**
   * @generated
   */
  public static final String generatorVersion = "3.200.75";

  /**
   * @generated
   */
  public static final String identifier = "XCustomerVehicleRoleInquiryData";

  /**
   * @generated
   */
  public static final long generationTime = 0x000001660aca0bc2L;

  /**
   * @generated
   */
  public static final String collection = "NULLID";

  /**
   * @generated
   */
  public static final String packageVersion = null;

  /**
   * @generated
   */
  public static final boolean forceSingleBindIsolation = false;

  /**
   * @generated
   */
  public XCustomerVehicleRoleInquiryDataImpl()
  {
    super();
  } 

  /**
   * @generated
   */
  public String getGeneratorVersion()
  {
    return generatorVersion;
  }

  /**
   * @Select( sql="SELECT r.CUSTOMERVEHICLEROLEPK_ID CUSTOMERVEHICLEROLEPK_ID, r.CUSTOMER_VEHICLE_ID CUSTOMER_VEHICLE_ID, r.VEHICLE_ROLE_TP_CD VEHICLE_ROLE_TP_CD, r.START_DT START_DT, r.END_DT END_DT, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.CHANGED_DT CHANGED_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XCUSTOMERVEHICLEROLE r WHERE r.CUSTOMERVEHICLEROLEPK_ID = ? ", pattern="tableAlias (XCUSTOMERVEHICLEROLE => com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRole, H_XCUSTOMERVEHICLEROLE => com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRole)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue1<EObjXCustomerVehicleRole>> getXCustomerVehicleRole (Object[] parameters)
  {
    return queryIterator (getXCustomerVehicleRoleStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getXCustomerVehicleRoleStatementDescriptor = createStatementDescriptor (
    "getXCustomerVehicleRole(Object[])",
    "SELECT r.CUSTOMERVEHICLEROLEPK_ID CUSTOMERVEHICLEROLEPK_ID, r.CUSTOMER_VEHICLE_ID CUSTOMER_VEHICLE_ID, r.VEHICLE_ROLE_TP_CD VEHICLE_ROLE_TP_CD, r.START_DT START_DT, r.END_DT END_DT, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.CHANGED_DT CHANGED_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XCUSTOMERVEHICLEROLE r WHERE r.CUSTOMERVEHICLEROLEPK_ID = ? ",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"customervehiclerolepk_id", "customer_vehicle_id", "vehicle_role_tp_cd", "start_dt", "end_dt", "source_ident_tp_cd", "changed_dt", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetXCustomerVehicleRoleParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetXCustomerVehicleRoleRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 19, 19, 0, 0, 19, 0, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    1);

  /**
   * @generated
   */
  public static class GetXCustomerVehicleRoleParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetXCustomerVehicleRoleRowHandler extends BaseRowHandler<ResultQueue1<EObjXCustomerVehicleRole>>
  {
    /**
     * @generated
     */
    public ResultQueue1<EObjXCustomerVehicleRole> handle (java.sql.ResultSet rs, ResultQueue1<EObjXCustomerVehicleRole> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue1<EObjXCustomerVehicleRole> ();

      EObjXCustomerVehicleRole returnObject1 = new EObjXCustomerVehicleRole ();
      returnObject1.setCustomerVehicleRolepkId(getLongObject (rs, 1)); 
      returnObject1.setCustomerVehicleId(getLongObject (rs, 2)); 
      returnObject1.setVehicleRole(getLongObject (rs, 3)); 
      returnObject1.setStartDate(getTimestamp (rs, 4)); 
      returnObject1.setEndDate(getTimestamp (rs, 5)); 
      returnObject1.setSourceIdentifier(getLongObject (rs, 6)); 
      returnObject1.setChangedDate(getTimestamp (rs, 7)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 8)); 
      returnObject1.setLastUpdateUser(getString (rs, 9)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 10)); 
      returnObject.add (returnObject1);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT r.H_CUSTOMERVEHICLEROLEPK_ID hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.CUSTOMERVEHICLEROLEPK_ID CUSTOMERVEHICLEROLEPK_ID, r.CUSTOMER_VEHICLE_ID CUSTOMER_VEHICLE_ID, r.VEHICLE_ROLE_TP_CD VEHICLE_ROLE_TP_CD, r.START_DT START_DT, r.END_DT END_DT, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.CHANGED_DT CHANGED_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XCUSTOMERVEHICLEROLE r WHERE r.H_CUSTOMERVEHICLEROLEPK_ID = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))", pattern="tableAlias (XCUSTOMERVEHICLEROLE => com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRole, H_XCUSTOMERVEHICLEROLE => com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRole)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue1<EObjXCustomerVehicleRole>> getXCustomerVehicleRoleHistory (Object[] parameters)
  {
    return queryIterator (getXCustomerVehicleRoleHistoryStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getXCustomerVehicleRoleHistoryStatementDescriptor = createStatementDescriptor (
    "getXCustomerVehicleRoleHistory(Object[])",
    "SELECT r.H_CUSTOMERVEHICLEROLEPK_ID hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.CUSTOMERVEHICLEROLEPK_ID CUSTOMERVEHICLEROLEPK_ID, r.CUSTOMER_VEHICLE_ID CUSTOMER_VEHICLE_ID, r.VEHICLE_ROLE_TP_CD VEHICLE_ROLE_TP_CD, r.START_DT START_DT, r.END_DT END_DT, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.CHANGED_DT CHANGED_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XCUSTOMERVEHICLEROLE r WHERE r.H_CUSTOMERVEHICLEROLEPK_ID = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"historyidpk", "h_action_code", "h_created_by", "h_create_dt", "h_end_dt", "customervehiclerolepk_id", "customer_vehicle_id", "vehicle_role_tp_cd", "start_dt", "end_dt", "source_ident_tp_cd", "changed_dt", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetXCustomerVehicleRoleHistoryParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP}, {19, 0, 0}, {0, 0, 0}, {1, 1, 1}},
    null,
    new GetXCustomerVehicleRoleHistoryRowHandler (),
    new int[][]{ {Types.BIGINT, Types.CHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 1, 20, 0, 0, 19, 19, 19, 0, 0, 19, 0, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    2);

  /**
   * @generated
   */
  public static class GetXCustomerVehicleRoleHistoryParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetXCustomerVehicleRoleHistoryRowHandler extends BaseRowHandler<ResultQueue1<EObjXCustomerVehicleRole>>
  {
    /**
     * @generated
     */
    public ResultQueue1<EObjXCustomerVehicleRole> handle (java.sql.ResultSet rs, ResultQueue1<EObjXCustomerVehicleRole> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue1<EObjXCustomerVehicleRole> ();

      EObjXCustomerVehicleRole returnObject1 = new EObjXCustomerVehicleRole ();
      returnObject1.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject1.setHistActionCode(getString (rs, 2)); 
      returnObject1.setHistCreatedBy(getString (rs, 3)); 
      returnObject1.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject1.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject1.setCustomerVehicleRolepkId(getLongObject (rs, 6)); 
      returnObject1.setCustomerVehicleId(getLongObject (rs, 7)); 
      returnObject1.setVehicleRole(getLongObject (rs, 8)); 
      returnObject1.setStartDate(getTimestamp (rs, 9)); 
      returnObject1.setEndDate(getTimestamp (rs, 10)); 
      returnObject1.setSourceIdentifier(getLongObject (rs, 11)); 
      returnObject1.setChangedDate(getTimestamp (rs, 12)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 13)); 
      returnObject1.setLastUpdateUser(getString (rs, 14)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 15)); 
      returnObject.add (returnObject1);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT r.CUSTOMERVEHICLEROLEPK_ID CUSTOMERVEHICLEROLEPK_ID, r.CUSTOMER_VEHICLE_ID CUSTOMER_VEHICLE_ID, r.VEHICLE_ROLE_TP_CD VEHICLE_ROLE_TP_CD, r.START_DT START_DT, r.END_DT END_DT, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.CHANGED_DT CHANGED_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XCUSTOMERVEHICLEROLE r WHERE r.CUSTOMER_VEHICLE_ID = ? ", pattern="tableAlias (XCUSTOMERVEHICLEROLE => com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRole, H_XCUSTOMERVEHICLEROLE => com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRole)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue1<EObjXCustomerVehicleRole>> getAllVehicleRoleByCustomerVehicleId (Object[] parameters)
  {
    return queryIterator (getAllVehicleRoleByCustomerVehicleIdStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getAllVehicleRoleByCustomerVehicleIdStatementDescriptor = createStatementDescriptor (
    "getAllVehicleRoleByCustomerVehicleId(Object[])",
    "SELECT r.CUSTOMERVEHICLEROLEPK_ID CUSTOMERVEHICLEROLEPK_ID, r.CUSTOMER_VEHICLE_ID CUSTOMER_VEHICLE_ID, r.VEHICLE_ROLE_TP_CD VEHICLE_ROLE_TP_CD, r.START_DT START_DT, r.END_DT END_DT, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.CHANGED_DT CHANGED_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XCUSTOMERVEHICLEROLE r WHERE r.CUSTOMER_VEHICLE_ID = ? ",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"customervehiclerolepk_id", "customer_vehicle_id", "vehicle_role_tp_cd", "start_dt", "end_dt", "source_ident_tp_cd", "changed_dt", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetAllVehicleRoleByCustomerVehicleIdParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetAllVehicleRoleByCustomerVehicleIdRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 19, 19, 0, 0, 19, 0, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    3);

  /**
   * @generated
   */
  public static class GetAllVehicleRoleByCustomerVehicleIdParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetAllVehicleRoleByCustomerVehicleIdRowHandler extends BaseRowHandler<ResultQueue1<EObjXCustomerVehicleRole>>
  {
    /**
     * @generated
     */
    public ResultQueue1<EObjXCustomerVehicleRole> handle (java.sql.ResultSet rs, ResultQueue1<EObjXCustomerVehicleRole> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue1<EObjXCustomerVehicleRole> ();

      EObjXCustomerVehicleRole returnObject1 = new EObjXCustomerVehicleRole ();
      returnObject1.setCustomerVehicleRolepkId(getLongObject (rs, 1)); 
      returnObject1.setCustomerVehicleId(getLongObject (rs, 2)); 
      returnObject1.setVehicleRole(getLongObject (rs, 3)); 
      returnObject1.setStartDate(getTimestamp (rs, 4)); 
      returnObject1.setEndDate(getTimestamp (rs, 5)); 
      returnObject1.setSourceIdentifier(getLongObject (rs, 6)); 
      returnObject1.setChangedDate(getTimestamp (rs, 7)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 8)); 
      returnObject1.setLastUpdateUser(getString (rs, 9)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 10)); 
      returnObject.add (returnObject1);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT r.H_CUSTOMERVEHICLEROLEPK_ID hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.CUSTOMERVEHICLEROLEPK_ID CUSTOMERVEHICLEROLEPK_ID, r.CUSTOMER_VEHICLE_ID CUSTOMER_VEHICLE_ID, r.VEHICLE_ROLE_TP_CD VEHICLE_ROLE_TP_CD, r.START_DT START_DT, r.END_DT END_DT, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.CHANGED_DT CHANGED_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XCUSTOMERVEHICLEROLE r WHERE r.CUSTOMER_VEHICLE_ID = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))", pattern="tableAlias (XCUSTOMERVEHICLEROLE => com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRole, H_XCUSTOMERVEHICLEROLE => com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRole)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue1<EObjXCustomerVehicleRole>> getAllVehicleRoleByCustomerVehicleIdHistory (Object[] parameters)
  {
    return queryIterator (getAllVehicleRoleByCustomerVehicleIdHistoryStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getAllVehicleRoleByCustomerVehicleIdHistoryStatementDescriptor = createStatementDescriptor (
    "getAllVehicleRoleByCustomerVehicleIdHistory(Object[])",
    "SELECT r.H_CUSTOMERVEHICLEROLEPK_ID hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.CUSTOMERVEHICLEROLEPK_ID CUSTOMERVEHICLEROLEPK_ID, r.CUSTOMER_VEHICLE_ID CUSTOMER_VEHICLE_ID, r.VEHICLE_ROLE_TP_CD VEHICLE_ROLE_TP_CD, r.START_DT START_DT, r.END_DT END_DT, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.CHANGED_DT CHANGED_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XCUSTOMERVEHICLEROLE r WHERE r.CUSTOMER_VEHICLE_ID = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"historyidpk", "h_action_code", "h_created_by", "h_create_dt", "h_end_dt", "customervehiclerolepk_id", "customer_vehicle_id", "vehicle_role_tp_cd", "start_dt", "end_dt", "source_ident_tp_cd", "changed_dt", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetAllVehicleRoleByCustomerVehicleIdHistoryParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP}, {19, 0, 0}, {0, 0, 0}, {1, 1, 1}},
    null,
    new GetAllVehicleRoleByCustomerVehicleIdHistoryRowHandler (),
    new int[][]{ {Types.BIGINT, Types.CHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 1, 20, 0, 0, 19, 19, 19, 0, 0, 19, 0, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    4);

  /**
   * @generated
   */
  public static class GetAllVehicleRoleByCustomerVehicleIdHistoryParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetAllVehicleRoleByCustomerVehicleIdHistoryRowHandler extends BaseRowHandler<ResultQueue1<EObjXCustomerVehicleRole>>
  {
    /**
     * @generated
     */
    public ResultQueue1<EObjXCustomerVehicleRole> handle (java.sql.ResultSet rs, ResultQueue1<EObjXCustomerVehicleRole> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue1<EObjXCustomerVehicleRole> ();

      EObjXCustomerVehicleRole returnObject1 = new EObjXCustomerVehicleRole ();
      returnObject1.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject1.setHistActionCode(getString (rs, 2)); 
      returnObject1.setHistCreatedBy(getString (rs, 3)); 
      returnObject1.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject1.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject1.setCustomerVehicleRolepkId(getLongObject (rs, 6)); 
      returnObject1.setCustomerVehicleId(getLongObject (rs, 7)); 
      returnObject1.setVehicleRole(getLongObject (rs, 8)); 
      returnObject1.setStartDate(getTimestamp (rs, 9)); 
      returnObject1.setEndDate(getTimestamp (rs, 10)); 
      returnObject1.setSourceIdentifier(getLongObject (rs, 11)); 
      returnObject1.setChangedDate(getTimestamp (rs, 12)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 13)); 
      returnObject1.setLastUpdateUser(getString (rs, 14)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 15)); 
      returnObject.add (returnObject1);

    
      return returnObject;
    }
  }

}
