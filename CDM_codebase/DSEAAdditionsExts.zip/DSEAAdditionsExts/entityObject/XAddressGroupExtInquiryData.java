/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[762d2620878b07f032544d9bcddc78e6]
 */
package com.ibm.daimler.dsea.entityObject;


import com.ibm.mdm.base.db.EntityMapping;
import com.ibm.pdq.annotation.Select;


import com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup;
import com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup;

import com.ibm.mdm.base.db.ResultQueue3;

import java.util.Iterator;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * 
 * @generated
 */
public interface XAddressGroupExtInquiryData {

  /**
   * MDM_TODO: CDKWB0050I The generated parameter and result lists in this file should be checked to ensure that each matches its
   * associated SQL query. Each list entry must be comma separated and identify a field within an entity object class.
   */ 
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */ 
   public final static String tableAliasString1 = "tableAlias (" + 
     "ADDRESSGROUP => com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup, " + 
     "H_ADDRESSGROUP => com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup, " + 
     "LOCATIONGROUP => com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup, " + 
     "H_LOCATIONGROUP => com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup , " + 
     "ADDRESSGROUP => com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt , " + 
     "H_ADDRESSGROUP => com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt" + 
     ")";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension
   * XAddressGroup.
   *
   * @generated
   */ 
   public final static String getPartyAddressesActiveSQL = "SELECT ADDRESSGROUP.LOCATION_GROUP_ID, ADDRESSGROUP.ADDRESS_ID , ADDRESSGROUP.CARE_OF_DESC, ADDRESSGROUP.ADDR_USAGE_TP_CD, ADDRESSGROUP.LAST_UPDATE_DT, ADDRESSGROUP.LAST_UPDATE_USER, ADDRESSGROUP.LAST_UPDATE_TX_ID , LOCATIONGROUP.LOCATION_GROUP_ID, LOCATIONGROUP.UNDEL_REASON_TP_CD, LOCATIONGROUP.CONT_ID , LOCATIONGROUP.MEMBER_IND , LOCATIONGROUP.PREFERRED_IND , LOCATIONGROUP.SOLICIT_IND, LOCATIONGROUP.LOC_GROUP_TP_CODE, LOCATIONGROUP.EFFECT_START_MMDD , LOCATIONGROUP.EFFECT_END_MMDD , LOCATIONGROUP.EFFECT_START_TM , LOCATIONGROUP.EFFECT_END_TM , LOCATIONGROUP.START_DT , LOCATIONGROUP.END_DT , LOCATIONGROUP.LAST_UPDATE_DT , LOCATIONGROUP.LAST_UPDATE_USER , LOCATIONGROUP.LAST_UPDATE_TX_ID , LOCATIONGROUP.LAST_USED_DT , LOCATIONGROUP.LAST_VERIFIED_DT , LOCATIONGROUP.SOURCE_IDENT_TP_CD, ADDRESSGROUP.XVERIFIED_TP_CD, ADDRESSGROUP.XRETAILER_ID, ADDRESSGROUP.XMODIFY_SYS_DT, ADDRESSGROUP.XADDR_RETAILER_FLAG, ADDRESSGROUP.TITLE_OF_HONOR, ADDRESSGROUP.COMPANY_NAME, ADDRESSGROUP.SFAddress_Id, ADDRESSGROUP.X_BPID" + 
     " FROM ADDRESSGROUP,LOCATIONGROUP" + 
     " WHERE ADDRESSGROUP.LOCATION_GROUP_ID = LOCATIONGROUP.LOCATION_GROUP_ID AND LOCATIONGROUP.CONT_ID = ? AND ((LOCATIONGROUP.END_DT IS NULL) OR (LOCATIONGROUP.END_DT > ? ))";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyAddressesActiveParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.endDt=END_DT"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyAddressesActiveResults =
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.locationGroupIdPK=LOCATION_GROUP_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.addressId=ADDRESS_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.careOfDesc=CARE_OF_DESC," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.addrUsageTpCd=ADDR_USAGE_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.locationGroupIdPK=LOCATION_GROUP_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.undelReasonTpCd=UNDEL_REASON_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.memberInd=MEMBER_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.preferredInd=PREFERRED_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.solicitInd=SOLICIT_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.locGroupTpCode=LOC_GROUP_TP_CODE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.effectStartMMDD=EFFECT_START_MMDD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.effectEndMMDD=EFFECT_END_MMDD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.effectStartTm=EFFECT_START_TM," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.effectEndTm=EFFECT_END_TM," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.startDt=START_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.endDt=END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastUsedDt=LAST_USED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastVerifiedDt=LAST_VERIFIED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.sourceIdentTpCd=SOURCE_IDENT_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.XVerified=XVERIFIED_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.XRetailerId=XRETAILER_ID," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.XLastModifiedSystemDate=XMODIFY_SYS_DT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.XAddressRetailerFlag=XADDR_RETAILER_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.TitleOfHonor=TITLE_OF_HONOR," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.CompanyName=COMPANY_NAME," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.SFAddressId=SFAddress_Id," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.X_BPID=X_BPID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension
   * XAddressGroup.
   *
   * @generated
   */ 
   public final static String getPartyAddressesInactiveSQL = "SELECT ADDRESSGROUP.LOCATION_GROUP_ID, ADDRESSGROUP.ADDRESS_ID, ADDRESSGROUP.CARE_OF_DESC, ADDRESSGROUP.ADDR_USAGE_TP_CD, ADDRESSGROUP.LAST_UPDATE_DT, ADDRESSGROUP.LAST_UPDATE_USER, ADDRESSGROUP.LAST_UPDATE_TX_ID, LOCATIONGROUP.LOCATION_GROUP_ID, LOCATIONGROUP.UNDEL_REASON_TP_CD, LOCATIONGROUP.CONT_ID, LOCATIONGROUP.MEMBER_IND, LOCATIONGROUP.PREFERRED_IND, LOCATIONGROUP.SOLICIT_IND , LOCATIONGROUP.LOC_GROUP_TP_CODE, LOCATIONGROUP.EFFECT_START_MMDD, LOCATIONGROUP.EFFECT_END_MMDD, LOCATIONGROUP.EFFECT_START_TM, LOCATIONGROUP.EFFECT_END_TM, LOCATIONGROUP.START_DT, LOCATIONGROUP.END_DT, LOCATIONGROUP.LAST_UPDATE_DT, LOCATIONGROUP.LAST_UPDATE_USER, LOCATIONGROUP.LAST_UPDATE_TX_ID, LOCATIONGROUP.LAST_USED_DT, LOCATIONGROUP.LAST_VERIFIED_DT, LOCATIONGROUP.SOURCE_IDENT_TP_CD, ADDRESSGROUP.XVERIFIED_TP_CD, ADDRESSGROUP.XRETAILER_ID, ADDRESSGROUP.XMODIFY_SYS_DT, ADDRESSGROUP.XADDR_RETAILER_FLAG, ADDRESSGROUP.TITLE_OF_HONOR, ADDRESSGROUP.COMPANY_NAME, ADDRESSGROUP.SFAddress_Id, ADDRESSGROUP.X_BPID" + 
     " FROM ADDRESSGROUP,LOCATIONGROUP" + 
     " WHERE ADDRESSGROUP.LOCATION_GROUP_ID = LOCATIONGROUP.LOCATION_GROUP_ID AND LOCATIONGROUP.CONT_ID = ? AND (LOCATIONGROUP.END_DT < ?)";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyAddressesInactiveParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.endDt=END_DT"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyAddressesInactiveResults =
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.locationGroupIdPK=LOCATION_GROUP_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.addressId=ADDRESS_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.careOfDesc=CARE_OF_DESC," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.addrUsageTpCd=ADDR_USAGE_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.locationGroupIdPK=LOCATION_GROUP_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.undelReasonTpCd=UNDEL_REASON_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.memberInd=MEMBER_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.preferredInd=PREFERRED_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.solicitInd=SOLICIT_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.locGroupTpCode=LOC_GROUP_TP_CODE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.effectStartMMDD=EFFECT_START_MMDD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.effectEndMMDD=EFFECT_END_MMDD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.effectStartTm=EFFECT_START_TM," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.effectEndTm=EFFECT_END_TM," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.startDt=START_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.endDt=END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastUsedDt=LAST_USED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastVerifiedDt=LAST_VERIFIED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.sourceIdentTpCd=SOURCE_IDENT_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.XVerified=XVERIFIED_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.XRetailerId=XRETAILER_ID," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.XLastModifiedSystemDate=XMODIFY_SYS_DT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.XAddressRetailerFlag=XADDR_RETAILER_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.TitleOfHonor=TITLE_OF_HONOR," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.CompanyName=COMPANY_NAME," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.SFAddressId=SFAddress_Id," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.X_BPID=X_BPID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension
   * XAddressGroup.
   *
   * @generated
   */ 
   public final static String getPartyAddressesByAddressIdSQL = "SELECT ADDRESSGROUP.LOCATION_GROUP_ID , ADDRESSGROUP.ADDRESS_ID , ADDRESSGROUP.CARE_OF_DESC , ADDRESSGROUP.ADDR_USAGE_TP_CD , ADDRESSGROUP.LAST_UPDATE_DT , ADDRESSGROUP.LAST_UPDATE_USER , ADDRESSGROUP.LAST_UPDATE_TX_ID , LOCATIONGROUP.LOCATION_GROUP_ID , LOCATIONGROUP.UNDEL_REASON_TP_CD , LOCATIONGROUP.CONT_ID , LOCATIONGROUP.MEMBER_IND , LOCATIONGROUP.PREFERRED_IND , LOCATIONGROUP.SOLICIT_IND , LOCATIONGROUP.LOC_GROUP_TP_CODE , LOCATIONGROUP.EFFECT_START_MMDD , LOCATIONGROUP.EFFECT_END_MMDD , LOCATIONGROUP.EFFECT_START_TM , LOCATIONGROUP.EFFECT_END_TM , LOCATIONGROUP.START_DT , LOCATIONGROUP.END_DT , LOCATIONGROUP.LAST_UPDATE_DT , LOCATIONGROUP.LAST_UPDATE_USER , LOCATIONGROUP.LAST_UPDATE_TX_ID , LOCATIONGROUP.LAST_USED_DT , LOCATIONGROUP.LAST_VERIFIED_DT , LOCATIONGROUP.SOURCE_IDENT_TP_CD, ADDRESSGROUP.XVERIFIED_TP_CD, ADDRESSGROUP.XRETAILER_ID, ADDRESSGROUP.XMODIFY_SYS_DT, ADDRESSGROUP.XADDR_RETAILER_FLAG, ADDRESSGROUP.TITLE_OF_HONOR, ADDRESSGROUP.COMPANY_NAME, ADDRESSGROUP.SFAddress_Id, ADDRESSGROUP.X_BPID" + 
     " FROM CONTACT, ADDRESSGROUP, LOCATIONGROUP" + 
     " WHERE ADDRESSGROUP.LOCATION_GROUP_ID = LOCATIONGROUP.LOCATION_GROUP_ID AND ADDRESSGROUP.ADDRESS_ID = ? AND ((LOCATIONGROUP.END_DT IS NULL) OR (LOCATIONGROUP.END_DT > ?)) AND (LOCATIONGROUP.CONT_ID = CONTACT.CONT_ID ) AND ((CONTACT.INACTIVATED_DT IS NULL) OR (CONTACT.INACTIVATED_DT > ? ))";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyAddressesByAddressIdParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.addressId=ADDRESS_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.endDt=END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.inactivatedDt=INACTIVATED_DT"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyAddressesByAddressIdResults =
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.locationGroupIdPK=LOCATION_GROUP_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.addressId=ADDRESS_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.careOfDesc=CARE_OF_DESC," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.addrUsageTpCd=ADDR_USAGE_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.locationGroupIdPK=LOCATION_GROUP_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.undelReasonTpCd=UNDEL_REASON_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.memberInd=MEMBER_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.preferredInd=PREFERRED_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.solicitInd=SOLICIT_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.locGroupTpCode=LOC_GROUP_TP_CODE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.effectStartMMDD=EFFECT_START_MMDD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.effectEndMMDD=EFFECT_END_MMDD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.effectStartTm=EFFECT_START_TM," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.effectEndTm=EFFECT_END_TM," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.startDt=START_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.endDt=END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastUsedDt=LAST_USED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastVerifiedDt=LAST_VERIFIED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.sourceIdentTpCd=SOURCE_IDENT_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.XVerified=XVERIFIED_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.XRetailerId=XRETAILER_ID," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.XLastModifiedSystemDate=XMODIFY_SYS_DT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.XAddressRetailerFlag=XADDR_RETAILER_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.TitleOfHonor=TITLE_OF_HONOR," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.CompanyName=COMPANY_NAME," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.SFAddressId=SFAddress_Id," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.X_BPID=X_BPID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension
   * XAddressGroup.
   *
   * @generated
   */ 
   public final static String getPartyAddressByIdSQL = "SELECT ADDRESSGROUP.LOCATION_GROUP_ID , ADDRESSGROUP.ADDRESS_ID , ADDRESSGROUP.CARE_OF_DESC, ADDRESSGROUP.ADDR_USAGE_TP_CD , ADDRESSGROUP.LAST_UPDATE_DT , ADDRESSGROUP.LAST_UPDATE_USER, ADDRESSGROUP.LAST_UPDATE_TX_ID, LOCATIONGROUP.LOCATION_GROUP_ID , LOCATIONGROUP.UNDEL_REASON_TP_CD , LOCATIONGROUP.CONT_ID , LOCATIONGROUP.MEMBER_IND, LOCATIONGROUP.PREFERRED_IND , LOCATIONGROUP.SOLICIT_IND , LOCATIONGROUP.LOC_GROUP_TP_CODE , LOCATIONGROUP.EFFECT_START_MMDD , LOCATIONGROUP.EFFECT_END_MMDD , LOCATIONGROUP.EFFECT_START_TM , LOCATIONGROUP.EFFECT_END_TM , LOCATIONGROUP.START_DT , LOCATIONGROUP.END_DT , LOCATIONGROUP.LAST_UPDATE_DT , LOCATIONGROUP.LAST_UPDATE_USER, LOCATIONGROUP.LAST_UPDATE_TX_ID, LOCATIONGROUP.LAST_USED_DT , LOCATIONGROUP.LAST_VERIFIED_DT , LOCATIONGROUP.SOURCE_IDENT_TP_CD, ADDRESSGROUP.XVERIFIED_TP_CD, ADDRESSGROUP.XRETAILER_ID, ADDRESSGROUP.XMODIFY_SYS_DT, ADDRESSGROUP.XADDR_RETAILER_FLAG, ADDRESSGROUP.TITLE_OF_HONOR, ADDRESSGROUP.COMPANY_NAME, ADDRESSGROUP.SFAddress_Id, ADDRESSGROUP.X_BPID" + 
     " FROM ADDRESSGROUP, LOCATIONGROUP" + 
     " WHERE ADDRESSGROUP.LOCATION_GROUP_ID = LOCATIONGROUP.LOCATION_GROUP_ID AND LOCATIONGROUP.LOCATION_GROUP_ID = ?";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyAddressByIdParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.locationGroupIdPK=LOCATION_GROUP_ID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyAddressByIdResults =
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.locationGroupIdPK=LOCATION_GROUP_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.addressId=ADDRESS_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.careOfDesc=CARE_OF_DESC," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.addrUsageTpCd=ADDR_USAGE_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.locationGroupIdPK=LOCATION_GROUP_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.undelReasonTpCd=UNDEL_REASON_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.memberInd=MEMBER_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.preferredInd=PREFERRED_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.solicitInd=SOLICIT_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.locGroupTpCode=LOC_GROUP_TP_CODE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.effectStartMMDD=EFFECT_START_MMDD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.effectEndMMDD=EFFECT_END_MMDD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.effectStartTm=EFFECT_START_TM," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.effectEndTm=EFFECT_END_TM," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.startDt=START_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.endDt=END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastUsedDt=LAST_USED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastVerifiedDt=LAST_VERIFIED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.sourceIdentTpCd=SOURCE_IDENT_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.XVerified=XVERIFIED_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.XRetailerId=XRETAILER_ID," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.XLastModifiedSystemDate=XMODIFY_SYS_DT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.XAddressRetailerFlag=XADDR_RETAILER_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.TitleOfHonor=TITLE_OF_HONOR," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.CompanyName=COMPANY_NAME," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.SFAddressId=SFAddress_Id," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.X_BPID=X_BPID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension
   * XAddressGroup.
   *
   * @generated
   */ 
   public final static String getPartyAddressesHistorySQL = "SELECT A.H_LOCATION_GROUP_I AS H_ADDRESS_GROUP_I, A.H_ACTION_CODE, A.H_CREATED_BY, A.H_CREATE_DT, A.H_END_DT, A.LOCATION_GROUP_ID, A.ADDRESS_ID, A.CARE_OF_DESC, A.ADDR_USAGE_TP_CD, A.LAST_UPDATE_DT, A.LAST_UPDATE_USER, A.LAST_UPDATE_TX_ID, B.H_LOCATION_GROUP_I AS H_LOCATION_GROUP_I, B.H_ACTION_CODE, B.H_CREATED_BY, B.H_CREATE_DT, B.H_END_DT, B.LOCATION_GROUP_ID, B.UNDEL_REASON_TP_CD , B.CONT_ID, B.MEMBER_IND, B.PREFERRED_IND, B.SOLICIT_IND, B.LOC_GROUP_TP_CODE, B.EFFECT_START_MMDD, B.EFFECT_END_MMDD , B.EFFECT_START_TM, B.EFFECT_END_TM, B.START_DT, B.END_DT, B.LAST_UPDATE_DT, B.LAST_UPDATE_USER, B.LAST_UPDATE_TX_ID , B.LAST_USED_DT, B.LAST_VERIFIED_DT, B.SOURCE_IDENT_TP_CD, A.XVERIFIED_TP_CD, A.XRETAILER_ID, A.XMODIFY_SYS_DT, A.XADDR_RETAILER_FLAG, A.TITLE_OF_HONOR, A.COMPANY_NAME, A.SFAddress_Id, A.X_BPID" + 
     " FROM H_ADDRESSGROUP A, H_LOCATIONGROUP B" + 
     " WHERE B.CONT_ID = ? AND A.H_LOCATION_GROUP_I = B.H_LOCATION_GROUP_I AND (( ? BETWEEN A.H_CREATE_DT AND A.H_END_DT ) OR ( ? >= A.H_CREATE_DT AND A.H_END_DT IS NULL )) AND (( ? BETWEEN B.H_CREATE_DT AND B.H_END_DT ) OR ( ? >= B.H_CREATE_DT AND B.H_END_DT IS NULL ))";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyAddressesHistoryParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.histCreateDt=H_CREATE_DT"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyAddressesHistoryResults =
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.locationGroupIdPK=H_ADDRESS_GROUP_I," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.histActionCode=H_ACTION_CODE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.histCreatedBy=H_CREATED_BY," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.histEndDt=H_END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.locationGroupIdPK=LOCATION_GROUP_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.addressId=ADDRESS_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.careOfDesc=CARE_OF_DESC," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.addrUsageTpCd=ADDR_USAGE_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.locationGroupIdPK=H_LOCATION_GROUP_I," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.histActionCode=H_ACTION_CODE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.histCreatedBy=H_CREATED_BY," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.histEndDt=H_END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.locationGroupIdPK=LOCATION_GROUP_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.undelReasonTpCd=UNDEL_REASON_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.memberInd=MEMBER_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.preferredInd=PREFERRED_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.solicitInd=SOLICIT_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.locGroupTpCode=LOC_GROUP_TP_CODE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.effectStartMMDD=EFFECT_START_MMDD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.effectEndMMDD=EFFECT_END_MMDD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.effectStartTm=EFFECT_START_TM," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.effectEndTm=EFFECT_END_TM," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.startDt=START_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.endDt=END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastUsedDt=LAST_USED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastVerifiedDt=LAST_VERIFIED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.sourceIdentTpCd=SOURCE_IDENT_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.XVerified=XVERIFIED_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.XRetailerId=XRETAILER_ID," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.XLastModifiedSystemDate=XMODIFY_SYS_DT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.XAddressRetailerFlag=XADDR_RETAILER_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.TitleOfHonor=TITLE_OF_HONOR," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.CompanyName=COMPANY_NAME," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.SFAddressId=SFAddress_Id," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.X_BPID=X_BPID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension
   * XAddressGroup.
   *
   * @generated
   */ 
   public final static String getPartyAddressesSQL = "SELECT ADDRESSGROUP.LOCATION_GROUP_ID, ADDRESSGROUP.ADDRESS_ID , ADDRESSGROUP.CARE_OF_DESC , ADDRESSGROUP.ADDR_USAGE_TP_CD , ADDRESSGROUP.LAST_UPDATE_DT , ADDRESSGROUP.LAST_UPDATE_USER , ADDRESSGROUP.LAST_UPDATE_TX_ID , LOCATIONGROUP.LOCATION_GROUP_ID , LOCATIONGROUP.UNDEL_REASON_TP_CD, LOCATIONGROUP.CONT_ID , LOCATIONGROUP.MEMBER_IND, LOCATIONGROUP.PREFERRED_IND , LOCATIONGROUP.SOLICIT_IND , LOCATIONGROUP.LOC_GROUP_TP_CODE , LOCATIONGROUP.EFFECT_START_MMDD , LOCATIONGROUP.EFFECT_END_MMDD , LOCATIONGROUP.EFFECT_START_TM , LOCATIONGROUP.EFFECT_END_TM , LOCATIONGROUP.START_DT , LOCATIONGROUP.END_DT , LOCATIONGROUP.LAST_UPDATE_DT , LOCATIONGROUP.LAST_UPDATE_USER , LOCATIONGROUP.LAST_UPDATE_TX_ID , LOCATIONGROUP.LAST_USED_DT , LOCATIONGROUP.LAST_VERIFIED_DT , LOCATIONGROUP.SOURCE_IDENT_TP_CD, ADDRESSGROUP.XVERIFIED_TP_CD, ADDRESSGROUP.XRETAILER_ID, ADDRESSGROUP.XMODIFY_SYS_DT, ADDRESSGROUP.XADDR_RETAILER_FLAG, ADDRESSGROUP.TITLE_OF_HONOR, ADDRESSGROUP.COMPANY_NAME, ADDRESSGROUP.SFAddress_Id, ADDRESSGROUP.X_BPID" + 
     " FROM ADDRESSGROUP, LOCATIONGROUP" + 
     " WHERE ADDRESSGROUP.LOCATION_GROUP_ID = LOCATIONGROUP.LOCATION_GROUP_ID AND LOCATIONGROUP.CONT_ID = ?";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyAddressesParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.contId=CONT_ID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyAddressesResults =
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.locationGroupIdPK=LOCATION_GROUP_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.addressId=ADDRESS_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.careOfDesc=CARE_OF_DESC," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.addrUsageTpCd=ADDR_USAGE_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.locationGroupIdPK=LOCATION_GROUP_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.undelReasonTpCd=UNDEL_REASON_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.memberInd=MEMBER_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.preferredInd=PREFERRED_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.solicitInd=SOLICIT_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.locGroupTpCode=LOC_GROUP_TP_CODE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.effectStartMMDD=EFFECT_START_MMDD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.effectEndMMDD=EFFECT_END_MMDD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.effectStartTm=EFFECT_START_TM," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.effectEndTm=EFFECT_END_TM," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.startDt=START_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.endDt=END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastUsedDt=LAST_USED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastVerifiedDt=LAST_VERIFIED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.sourceIdentTpCd=SOURCE_IDENT_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.XVerified=XVERIFIED_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.XRetailerId=XRETAILER_ID," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.XLastModifiedSystemDate=XMODIFY_SYS_DT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.XAddressRetailerFlag=XADDR_RETAILER_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.TitleOfHonor=TITLE_OF_HONOR," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.CompanyName=COMPANY_NAME," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.SFAddressId=SFAddress_Id," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.X_BPID=X_BPID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension
   * XAddressGroup.
   *
   * @generated
   */ 
   public final static String getPartyAddressHistorySQL = "SELECT DISTINCT A.H_LOCATION_GROUP_I AS H_ADDRESS_GROUP_I, A.H_ACTION_CODE , A.H_CREATED_BY , A.H_CREATE_DT , A.H_END_DT , A.LOCATION_GROUP_ID , A.ADDRESS_ID , A.CARE_OF_DESC , A.ADDR_USAGE_TP_CD , A.LAST_UPDATE_DT , A.LAST_UPDATE_USER , A.LAST_UPDATE_TX_ID , B.LOCATION_GROUP_ID , B.H_LOCATION_GROUP_I AS H_LOCATION_GROUP_I, B.H_ACTION_CODE , B.H_CREATED_BY , B.H_CREATE_DT , B.H_END_DT , B.UNDEL_REASON_TP_CD , B.CONT_ID , B.MEMBER_IND , B.PREFERRED_IND, B.SOLICIT_IND , B.LOC_GROUP_TP_CODE , B.EFFECT_START_MMDD , B.EFFECT_END_MMDD , B.EFFECT_START_TM , B.EFFECT_END_TM , B.START_DT , B.END_DT , B.LAST_UPDATE_DT , B.LAST_UPDATE_USER , B.LAST_UPDATE_TX_ID , B.LAST_USED_DT , B.LAST_VERIFIED_DT , B.SOURCE_IDENT_TP_CD, A.XVERIFIED_TP_CD, A.XRETAILER_ID, A.XMODIFY_SYS_DT, A.XADDR_RETAILER_FLAG, A.TITLE_OF_HONOR, A.COMPANY_NAME, A.SFAddress_Id, A.X_BPID" + 
     " FROM H_ADDRESSGROUP A,H_LOCATIONGROUP B" + 
     " WHERE A.H_LOCATION_GROUP_I = B.H_LOCATION_GROUP_I AND (B.CONT_ID = ? AND (? BETWEEN B.H_CREATE_DT AND B.H_END_DT AND B.END_DT IS NULL OR (? >= B.H_CREATE_DT AND B.H_END_DT IS NULL AND B.END_DT IS NULL))) AND (A.ADDR_USAGE_TP_CD =? AND (? BETWEEN A.H_CREATE_DT AND A.H_END_DT OR (? >= A.H_CREATE_DT AND A.H_END_DT IS NULL)))";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyAddressHistoryParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.addrUsageTpCd=ADDR_USAGE_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.histCreateDt=H_CREATE_DT"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyAddressHistoryResults =
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.locationGroupIdPK=H_ADDRESS_GROUP_I," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.histActionCode=H_ACTION_CODE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.histCreatedBy=H_CREATED_BY," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.histEndDt=H_END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.locationGroupIdPK=LOCATION_GROUP_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.addressId=ADDRESS_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.careOfDesc=CARE_OF_DESC," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.addrUsageTpCd=ADDR_USAGE_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.locationGroupIdPK=LOCATION_GROUP_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.locationGroupIdPK=H_LOCATION_GROUP_I," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.histActionCode=H_ACTION_CODE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.histCreatedBy=H_CREATED_BY," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.histEndDt=H_END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.undelReasonTpCd=UNDEL_REASON_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.memberInd=MEMBER_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.preferredInd=PREFERRED_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.solicitInd=SOLICIT_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.locGroupTpCode=LOC_GROUP_TP_CODE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.effectStartMMDD=EFFECT_START_MMDD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.effectEndMMDD=EFFECT_END_MMDD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.effectStartTm=EFFECT_START_TM," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.effectEndTm=EFFECT_END_TM," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.startDt=START_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.endDt=END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastUsedDt=LAST_USED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastVerifiedDt=LAST_VERIFIED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.sourceIdentTpCd=SOURCE_IDENT_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.XVerified=XVERIFIED_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.XRetailerId=XRETAILER_ID," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.XLastModifiedSystemDate=XMODIFY_SYS_DT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.XAddressRetailerFlag=XADDR_RETAILER_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.TitleOfHonor=TITLE_OF_HONOR," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.CompanyName=COMPANY_NAME," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.SFAddressId=SFAddress_Id," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.X_BPID=X_BPID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension
   * XAddressGroup.
   *
   * @generated
   */ 
   public final static String getPartyAddressSQL = "SELECT ADDRESSGROUP.LOCATION_GROUP_ID , ADDRESSGROUP.ADDRESS_ID, ADDRESSGROUP.CARE_OF_DESC , ADDRESSGROUP.ADDR_USAGE_TP_CD , ADDRESSGROUP.LAST_UPDATE_DT , ADDRESSGROUP.LAST_UPDATE_USER , ADDRESSGROUP.LAST_UPDATE_TX_ID , LOCATIONGROUP.LOCATION_GROUP_ID , LOCATIONGROUP.UNDEL_REASON_TP_CD , LOCATIONGROUP.CONT_ID , LOCATIONGROUP.MEMBER_IND , LOCATIONGROUP.PREFERRED_IND , LOCATIONGROUP.SOLICIT_IND, LOCATIONGROUP.LOC_GROUP_TP_CODE , LOCATIONGROUP.EFFECT_START_MMDD , LOCATIONGROUP.EFFECT_END_MMDD , LOCATIONGROUP.EFFECT_START_TM , LOCATIONGROUP.EFFECT_END_TM , LOCATIONGROUP.START_DT , LOCATIONGROUP.END_DT , LOCATIONGROUP.LAST_UPDATE_DT , LOCATIONGROUP.LAST_UPDATE_USER , LOCATIONGROUP.LAST_UPDATE_TX_ID , LOCATIONGROUP.LAST_USED_DT , LOCATIONGROUP.LAST_VERIFIED_DT , LOCATIONGROUP.SOURCE_IDENT_TP_CD, ADDRESSGROUP.XVERIFIED_TP_CD, ADDRESSGROUP.XRETAILER_ID, ADDRESSGROUP.XMODIFY_SYS_DT, ADDRESSGROUP.XADDR_RETAILER_FLAG, ADDRESSGROUP.TITLE_OF_HONOR, ADDRESSGROUP.COMPANY_NAME, ADDRESSGROUP.SFAddress_Id, ADDRESSGROUP.X_BPID" + 
     " FROM ADDRESSGROUP,LOCATIONGROUP" + 
     " WHERE ADDRESSGROUP.LOCATION_GROUP_ID = LOCATIONGROUP.LOCATION_GROUP_ID AND LOCATIONGROUP.CONT_ID = ? AND ADDRESSGROUP.ADDR_USAGE_TP_CD = ? AND ((LOCATIONGROUP.END_DT IS NULL) OR (LOCATIONGROUP.END_DT > ?))";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyAddressParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.addrUsageTpCd=ADDR_USAGE_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.endDt=END_DT"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyAddressResults =
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.locationGroupIdPK=LOCATION_GROUP_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.addressId=ADDRESS_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.careOfDesc=CARE_OF_DESC," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.addrUsageTpCd=ADDR_USAGE_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.locationGroupIdPK=LOCATION_GROUP_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.undelReasonTpCd=UNDEL_REASON_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.memberInd=MEMBER_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.preferredInd=PREFERRED_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.solicitInd=SOLICIT_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.locGroupTpCode=LOC_GROUP_TP_CODE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.effectStartMMDD=EFFECT_START_MMDD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.effectEndMMDD=EFFECT_END_MMDD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.effectStartTm=EFFECT_START_TM," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.effectEndTm=EFFECT_END_TM," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.startDt=START_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.endDt=END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastUsedDt=LAST_USED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastVerifiedDt=LAST_VERIFIED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.sourceIdentTpCd=SOURCE_IDENT_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.XVerified=XVERIFIED_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.XRetailerId=XRETAILER_ID," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.XLastModifiedSystemDate=XMODIFY_SYS_DT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.XAddressRetailerFlag=XADDR_RETAILER_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.TitleOfHonor=TITLE_OF_HONOR," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.CompanyName=COMPANY_NAME," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.SFAddressId=SFAddress_Id," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.X_BPID=X_BPID"; 
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */ 
   public final static String resultSetMapping1 = "<rsm>" + 
     "<col number='1' bean='com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup' property='historyIdPK'></col>" + 
     "<col number='2' bean='com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup' property='histActionCode'></col>" + 
     "<col number='3' bean='com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup' property='histCreatedBy'></col>" + 
     "<col number='4' bean='com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup' property='histCreateDt'></col>" + 
     "<col number='5' bean='com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup' property='histEndDt'></col>" + 
     "<col number='6' bean='com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup' property='locationGroupIdPK'></col>" + 
     "<col number='7' bean='com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup' property='addressId'></col>" + 
     "<col number='8' bean='com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup' property='careOfDesc'></col>" + 
     "<col number='9' bean='com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup' property='addrUsageTpCd'></col>" + 
     "<col number='10' bean='com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup' property='lastUpdateDt'></col>" + 
     "<col number='11' bean='com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup' property='lastUpdateUser'></col>" + 
     "<col number='12' bean='com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup' property='lastUpdateTxId'></col>" + 
     "<col number='13' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='historyIdPK'></col>" + 
     "<col number='14' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='histActionCode'></col>" + 
     "<col number='15' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='histCreatedBy'></col>" + 
     "<col number='16' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='histCreateDt'></col>" + 
     "<col number='17' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='histEndDt'></col>" + 
     "<col number='18' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='locationGroupIdPK'></col>" + 
     "<col number='19' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='undelReasonTpCd'></col>" + 
     "<col number='20' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='contId'></col>" + 
     "<col number='21' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='memberInd'></col>" + 
     "<col number='22' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='preferredInd'></col>" + 
     "<col number='23' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='solicitInd'></col>" + 
     "<col number='24' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='locGroupTpCode'></col>" + 
     "<col number='25' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='effectStartMMDD'></col>" + 
     "<col number='26' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='effectEndMMDD'></col>" + 
     "<col number='27' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='effectStartTm'></col>" + 
     "<col number='28' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='effectEndTm'></col>" + 
     "<col number='29' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='startDt'></col>" + 
     "<col number='30' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='endDt'></col>" + 
     "<col number='31' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='lastUpdateDt'></col>" + 
     "<col number='32' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='lastUpdateUser'></col>" + 
     "<col number='33' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='lastUpdateTxId'></col>" + 
     "<col number='34' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='lastUsedDt'></col>" + 
     "<col number='35' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='lastVerifiedDt'></col>" + 
     "<col number='36' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='sourceIdentTpCd'></col>" + 
     "<col number='37' bean='com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt' property='XVerified'></col>" + 
     "<col number='38' bean='com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt' property='XRetailerId'></col>" + 
     "<col number='39' bean='com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt' property='XLastModifiedSystemDate'></col>" + 
     "<col number='40' bean='com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt' property='XAddressRetailerFlag'></col>" + 
     "<col number='41' bean='com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt' property='TitleOfHonor'></col>" + 
     "<col number='42' bean='com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt' property='CompanyName'></col>" + 
     "<col number='43' bean='com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt' property='SFAddressId'></col>" + 
     "<col number='44' bean='com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt' property='X_BPID'></col>" + 
     "</rsm>";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension
   * XAddressGroup.
   *
   * @generated
   */ 
   public final static String getPartyAddressImageSQL = "SELECT DISTINCT A.H_LOCATION_GROUP_I AS H_ADDRESS_GROUP_I, A.H_ACTION_CODE , A.H_CREATED_BY , A.H_CREATE_DT , A.H_END_DT , A.LOCATION_GROUP_ID , A.ADDRESS_ID, A.CARE_OF_DESC , A.ADDR_USAGE_TP_CD , A.LAST_UPDATE_DT , A.LAST_UPDATE_USER , A.LAST_UPDATE_TX_ID , B.H_LOCATION_GROUP_I AS H_LOCATION_GROUP_I, B.H_ACTION_CODE , B.H_CREATED_BY , B.H_CREATE_DT , B.H_END_DT , B.LOCATION_GROUP_ID , B.UNDEL_REASON_TP_CD, B.CONT_ID , B.MEMBER_IND , B.PREFERRED_IND , B.SOLICIT_IND , B.LOC_GROUP_TP_CODE , B.EFFECT_START_MMDD, B.EFFECT_END_MMDD , B.EFFECT_START_TM , B.EFFECT_END_TM , B.START_DT , B.END_DT , B.LAST_UPDATE_DT , B.LAST_UPDATE_USER , B.LAST_UPDATE_TX_ID , B.LAST_USED_DT , B.LAST_VERIFIED_DT , B.SOURCE_IDENT_TP_CD, A.XVERIFIED_TP_CD, A.XRETAILER_ID, A.XMODIFY_SYS_DT, A.XADDR_RETAILER_FLAG, A.TITLE_OF_HONOR, A.COMPANY_NAME, A.SFAddress_Id, A.X_BPID" + 
     " FROM H_ADDRESSGROUP A, H_LOCATIONGROUP B" + 
     " WHERE B.CONT_ID = ? AND A.LOCATION_GROUP_ID = B.LOCATION_GROUP_ID AND A.LAST_UPDATE_TX_ID= B.LAST_UPDATE_TX_ID AND ( A.LAST_UPDATE_DT BETWEEN ? AND ? )" + 
     " UNION SELECT DISTINCT A.H_LOCATION_GROUP_I AS H_ADDRESS_GROUP_I, A.H_ACTION_CODE AS H_ACTION_CODE_1, A.H_CREATED_BY AS H_CREATED_BY_1, A.H_CREATE_DT AS H_CREATE_DT_1, A.H_END_DT AS H_END_DT_1, A.LOCATION_GROUP_ID AS LOCATIONGROUPID2, A.ADDRESS_ID AS ADDRESSID2, A.CARE_OF_DESC AS CAREOFDESC2, A.ADDR_USAGE_TP_CD AS ADDRUSAGETPCD2, A.LAST_UPDATE_DT AS LASTUPDATEDT2, A.LAST_UPDATE_USER AS LASTUPDATEUSER2, A.LAST_UPDATE_TX_ID AS LASTUPDATETXID2, B.H_LOCATION_GROUP_I AS H_LOCATION_GROUP_I, B.H_ACTION_CODE AS H_ACTION_CODE_2, B.H_CREATED_BY AS H_CREATED_BY_2, B.H_CREATE_DT AS H_CREATE_DT_2, B.H_END_DT AS H_END_DT_2, B.LOCATION_GROUP_ID AS LOCATIONGROUPID42, B.UNDEL_REASON_TP_CD AS UNDELREASONTPCD42, B.CONT_ID AS LOCALGROUP_CONT_ID, B.MEMBER_IND AS MEMBERIND42, B.PREFERRED_IND AS PREFERREDIND42, B.SOLICIT_IND AS SOLICITIND42, B.LOC_GROUP_TP_CODE AS LOCGROUPTPCODE42, B.EFFECT_START_MMDD AS EFFECTSTARTMMDD42, B.EFFECT_END_MMDD AS EFFECTENDMMDD42, B.EFFECT_START_TM AS EFFECTSTARTTM42, B.EFFECT_END_TM AS EFFECTENDTM42, B.START_DT AS STARTDT42, B.END_DT AS LOCALGROUP_END_DT, B.LAST_UPDATE_DT AS LASTUPDATEDT42, B.LAST_UPDATE_USER AS LASTUPDATEUSER42, B.LAST_UPDATE_TX_ID AS LASTUPDATETXID42, B.LAST_USED_DT AS LASTUSEDDT, B.LAST_VERIFIED_DT AS LASTVERIFIEDDT, B.SOURCE_IDENT_TP_CD AS SOURCEIDENTTPCD, A.XVERIFIED_TP_CD, A.XRETAILER_ID, A.XMODIFY_SYS_DT, A.XADDR_RETAILER_FLAG, A.TITLE_OF_HONOR, A.COMPANY_NAME, A.SFAddress_Id, A.X_BPID" + 
     " FROM H_LOCATIONGROUP B LEFT JOIN H_ADDRESSGROUP A ON A.LOCATION_GROUP_ID = B.LOCATION_GROUP_ID AND A.LAST_UPDATE_TX_ID=B.LAST_UPDATE_TX_ID" + 
     " WHERE B.CONT_ID = ? AND ( B.H_CREATE_DT BETWEEN ? AND ?)";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyAddressImageParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.histCreateDt=H_CREATE_DT"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyAddressImageResults =
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.locationGroupIdPK=H_ADDRESS_GROUP_I," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.histActionCode=H_ACTION_CODE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.histCreatedBy=H_CREATED_BY," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.histEndDt=H_END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.locationGroupIdPK=LOCATION_GROUP_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.addressId=ADDRESS_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.careOfDesc=CARE_OF_DESC," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.addrUsageTpCd=ADDR_USAGE_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.locationGroupIdPK=H_LOCATION_GROUP_I," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.histActionCode=H_ACTION_CODE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.histCreatedBy=H_CREATED_BY," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.histEndDt=H_END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.locationGroupIdPK=LOCATION_GROUP_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.undelReasonTpCd=UNDEL_REASON_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.memberInd=MEMBER_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.preferredInd=PREFERRED_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.solicitInd=SOLICIT_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.locGroupTpCode=LOC_GROUP_TP_CODE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.effectStartMMDD=EFFECT_START_MMDD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.effectEndMMDD=EFFECT_END_MMDD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.effectStartTm=EFFECT_START_TM," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.effectEndTm=EFFECT_END_TM," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.startDt=START_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.endDt=END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastUsedDt=LAST_USED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastVerifiedDt=LAST_VERIFIED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.sourceIdentTpCd=SOURCE_IDENT_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.XVerified=XVERIFIED_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.XRetailerId=XRETAILER_ID," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.XLastModifiedSystemDate=XMODIFY_SYS_DT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.XAddressRetailerFlag=XADDR_RETAILER_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.TitleOfHonor=TITLE_OF_HONOR," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.CompanyName=COMPANY_NAME," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.SFAddressId=SFAddress_Id," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.X_BPID=X_BPID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension
   * XAddressGroup.
   *
   * @generated
   */ 
   public final static String getPartyAddressLightImagesSQL = "SELECT DISTINCT A.LOCATION_GROUP_ID , A.ADDRESS_ID , A.LAST_UPDATE_DT , B.LOCATION_GROUP_ID , B.LAST_UPDATE_DT, A.XVERIFIED_TP_CD, A.XRETAILER_ID, A.XMODIFY_SYS_DT, A.XADDR_RETAILER_FLAG, A.TITLE_OF_HONOR, A.COMPANY_NAME, A.SFAddress_Id, A.X_BPID" + 
     " FROM H_ADDRESSGROUP A, H_LOCATIONGROUP B" + 
     " WHERE B.CONT_ID = ? AND A.LOCATION_GROUP_ID = B.LOCATION_GROUP_ID AND A.LAST_UPDATE_TX_ID = B.LAST_UPDATE_TX_ID AND (( A.LAST_UPDATE_DT BETWEEN ? AND ? ) OR ( B.H_CREATE_DT BETWEEN ? AND ?))";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyAddressLightImagesParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.histCreateDt=H_CREATE_DT"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyAddressLightImagesResults =
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.locationGroupIdPK=LOCATION_GROUP_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.addressId=ADDRESS_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.locationGroupIdPK=LOCATION_GROUP_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.XVerified=XVERIFIED_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.XRetailerId=XRETAILER_ID," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.XLastModifiedSystemDate=XMODIFY_SYS_DT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.XAddressRetailerFlag=XADDR_RETAILER_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.TitleOfHonor=TITLE_OF_HONOR," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.CompanyName=COMPANY_NAME," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.SFAddressId=SFAddress_Id," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.X_BPID=X_BPID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension
   * XAddressGroup.
   *
   * @generated
   */ 
   public final static String getPartyAddressHistoryByIdSQL = "SELECT A.H_LOCATION_GROUP_I AS H_ADDRESS_GROUP_I, A.H_ACTION_CODE , A.H_CREATED_BY , A.H_CREATE_DT , A.H_END_DT , A.LOCATION_GROUP_ID , A.ADDRESS_ID , A.CARE_OF_DESC , A.ADDR_USAGE_TP_CD , A.LAST_UPDATE_DT , A.LAST_UPDATE_USER , A.LAST_UPDATE_TX_ID , B.H_LOCATION_GROUP_I AS H_LOCATION_GROUP_I, B.H_ACTION_CODE , B.H_CREATED_BY , B.H_CREATE_DT , B.H_END_DT, B.LOCATION_GROUP_ID , B.UNDEL_REASON_TP_CD , B.CONT_ID , B.MEMBER_IND , B.PREFERRED_IND , B.SOLICIT_IND , B.LOC_GROUP_TP_CODE , B.EFFECT_START_MMDD , B.EFFECT_END_MMDD , B.EFFECT_START_TM , B.EFFECT_END_TM , B.START_DT , B.END_DT , B.LAST_UPDATE_DT , B.LAST_UPDATE_USER , B.LAST_UPDATE_TX_ID , B.LAST_USED_DT , B.LAST_VERIFIED_DT , B.SOURCE_IDENT_TP_CD, A.XVERIFIED_TP_CD, A.XRETAILER_ID, A.XMODIFY_SYS_DT, A.XADDR_RETAILER_FLAG, A.TITLE_OF_HONOR, A.COMPANY_NAME, A.SFAddress_Id, A.X_BPID" + 
     " FROM H_ADDRESSGROUP A, H_LOCATIONGROUP B" + 
     " WHERE B.H_LOCATION_GROUP_I = ? AND A.H_LOCATION_GROUP_I = B.H_LOCATION_GROUP_I AND (( ? BETWEEN A.H_CREATE_DT AND A.H_END_DT ) OR ( ? >= A.H_CREATE_DT AND A.H_END_DT IS NULL )) AND (( ? BETWEEN B.H_CREATE_DT AND B.H_END_DT ) OR ( ? >= B.H_CREATE_DT AND B.H_END_DT IS NULL ))";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyAddressHistoryByIdParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.locationGroupIdPK=H_LOCATION_GROUP_I," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.histCreateDt=H_CREATE_DT"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyAddressHistoryByIdResults =
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.locationGroupIdPK=H_ADDRESS_GROUP_I," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.histActionCode=H_ACTION_CODE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.histCreatedBy=H_CREATED_BY," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.histEndDt=H_END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.locationGroupIdPK=LOCATION_GROUP_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.addressId=ADDRESS_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.careOfDesc=CARE_OF_DESC," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.addrUsageTpCd=ADDR_USAGE_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.locationGroupIdPK=H_LOCATION_GROUP_I," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.histActionCode=H_ACTION_CODE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.histCreatedBy=H_CREATED_BY," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.histEndDt=H_END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.locationGroupIdPK=LOCATION_GROUP_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.undelReasonTpCd=UNDEL_REASON_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.memberInd=MEMBER_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.preferredInd=PREFERRED_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.solicitInd=SOLICIT_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.locGroupTpCode=LOC_GROUP_TP_CODE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.effectStartMMDD=EFFECT_START_MMDD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.effectEndMMDD=EFFECT_END_MMDD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.effectStartTm=EFFECT_START_TM," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.effectEndTm=EFFECT_END_TM," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.startDt=START_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.endDt=END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastUsedDt=LAST_USED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastVerifiedDt=LAST_VERIFIED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.sourceIdentTpCd=SOURCE_IDENT_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.XVerified=XVERIFIED_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.XRetailerId=XRETAILER_ID," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.XLastModifiedSystemDate=XMODIFY_SYS_DT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.XAddressRetailerFlag=XADDR_RETAILER_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.TitleOfHonor=TITLE_OF_HONOR," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.CompanyName=COMPANY_NAME," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.SFAddressId=SFAddress_Id," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.X_BPID=X_BPID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension
   * XAddressGroup.
   *
   * @generated
   */ 
   public final static String getPartyAddressesByAddressIdAllSQL = "SELECT ADDRESSGROUP.LOCATION_GROUP_ID , ADDRESSGROUP.ADDRESS_ID , ADDRESSGROUP.CARE_OF_DESC , ADDRESSGROUP.ADDR_USAGE_TP_CD , ADDRESSGROUP.LAST_UPDATE_DT , ADDRESSGROUP.LAST_UPDATE_USER , ADDRESSGROUP.LAST_UPDATE_TX_ID , LOCATIONGROUP.LOCATION_GROUP_ID , LOCATIONGROUP.UNDEL_REASON_TP_CD , LOCATIONGROUP.CONT_ID , LOCATIONGROUP.MEMBER_IND , LOCATIONGROUP.PREFERRED_IND , LOCATIONGROUP.SOLICIT_IND , LOCATIONGROUP.LOC_GROUP_TP_CODE , LOCATIONGROUP.EFFECT_START_MMDD , LOCATIONGROUP.EFFECT_END_MMDD , LOCATIONGROUP.EFFECT_START_TM , LOCATIONGROUP.EFFECT_END_TM , LOCATIONGROUP.START_DT , LOCATIONGROUP.END_DT , LOCATIONGROUP.LAST_UPDATE_DT , LOCATIONGROUP.LAST_UPDATE_USER , LOCATIONGROUP.LAST_UPDATE_TX_ID ,LOCATIONGROUP.LAST_USED_DT , LOCATIONGROUP.LAST_VERIFIED_DT , LOCATIONGROUP.SOURCE_IDENT_TP_CD, ADDRESSGROUP.XVERIFIED_TP_CD, ADDRESSGROUP.XRETAILER_ID, ADDRESSGROUP.XMODIFY_SYS_DT, ADDRESSGROUP.XADDR_RETAILER_FLAG, ADDRESSGROUP.TITLE_OF_HONOR, ADDRESSGROUP.COMPANY_NAME, ADDRESSGROUP.SFAddress_Id, ADDRESSGROUP.X_BPID" + 
     " FROM CONTACT, ADDRESSGROUP, LOCATIONGROUP" + 
     " WHERE ADDRESSGROUP.LOCATION_GROUP_ID = LOCATIONGROUP.LOCATION_GROUP_ID AND ADDRESSGROUP.ADDRESS_ID = ? AND (LOCATIONGROUP.CONT_ID = CONTACT.CONT_ID)";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyAddressesByAddressIdAllParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.addressId=ADDRESS_ID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyAddressesByAddressIdAllResults =
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.locationGroupIdPK=LOCATION_GROUP_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.addressId=ADDRESS_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.careOfDesc=CARE_OF_DESC," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.addrUsageTpCd=ADDR_USAGE_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.locationGroupIdPK=LOCATION_GROUP_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.undelReasonTpCd=UNDEL_REASON_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.memberInd=MEMBER_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.preferredInd=PREFERRED_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.solicitInd=SOLICIT_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.locGroupTpCode=LOC_GROUP_TP_CODE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.effectStartMMDD=EFFECT_START_MMDD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.effectEndMMDD=EFFECT_END_MMDD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.effectStartTm=EFFECT_START_TM," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.effectEndTm=EFFECT_END_TM," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.startDt=START_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.endDt=END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastUsedDt=LAST_USED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastVerifiedDt=LAST_VERIFIED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.sourceIdentTpCd=SOURCE_IDENT_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.XVerified=XVERIFIED_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.XRetailerId=XRETAILER_ID," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.XLastModifiedSystemDate=XMODIFY_SYS_DT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.XAddressRetailerFlag=XADDR_RETAILER_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.TitleOfHonor=TITLE_OF_HONOR," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.CompanyName=COMPANY_NAME," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.SFAddressId=SFAddress_Id," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.X_BPID=X_BPID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension
   * XAddressGroup.
   *
   * @generated
   */ 
   public final static String getPartyAddressesByAddressIdInactiveSQL = "SELECT ADDRESSGROUP.LOCATION_GROUP_ID , ADDRESSGROUP.ADDRESS_ID , ADDRESSGROUP.CARE_OF_DESC, ADDRESSGROUP.ADDR_USAGE_TP_CD , ADDRESSGROUP.LAST_UPDATE_DT , ADDRESSGROUP.LAST_UPDATE_USER , ADDRESSGROUP.LAST_UPDATE_TX_ID , LOCATIONGROUP.LOCATION_GROUP_ID , LOCATIONGROUP.UNDEL_REASON_TP_CD, LOCATIONGROUP.CONT_ID, LOCATIONGROUP.MEMBER_IND , LOCATIONGROUP.PREFERRED_IND , LOCATIONGROUP.SOLICIT_IND , LOCATIONGROUP.LOC_GROUP_TP_CODE , LOCATIONGROUP.EFFECT_START_MMDD , LOCATIONGROUP.EFFECT_END_MMDD , LOCATIONGROUP.EFFECT_START_TM , LOCATIONGROUP.EFFECT_END_TM , LOCATIONGROUP.START_DT , LOCATIONGROUP.END_DT, LOCATIONGROUP.LAST_UPDATE_DT , LOCATIONGROUP.LAST_UPDATE_USER , LOCATIONGROUP.LAST_UPDATE_TX_ID, ADDRESSGROUP.XVERIFIED_TP_CD, ADDRESSGROUP.XRETAILER_ID, ADDRESSGROUP.XMODIFY_SYS_DT, ADDRESSGROUP.XADDR_RETAILER_FLAG, ADDRESSGROUP.TITLE_OF_HONOR, ADDRESSGROUP.COMPANY_NAME, ADDRESSGROUP.SFAddress_Id, ADDRESSGROUP.X_BPID" + 
     " FROM CONTACT, ADDRESSGROUP, LOCATIONGROUP" + 
     " WHERE ADDRESSGROUP.LOCATION_GROUP_ID = LOCATIONGROUP.LOCATION_GROUP_ID AND ADDRESSGROUP.ADDRESS_ID = ? AND (LOCATIONGROUP.END_DT < ?) AND (LOCATIONGROUP.CONT_ID = CONTACT.CONT_ID ) AND (CONTACT.INACTIVATED_DT < ? )";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyAddressesByAddressIdInactiveParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.addressId=ADDRESS_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.endDt=END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.inactivatedDt=INACTIVATED_DT"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyAddressesByAddressIdInactiveResults =
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.locationGroupIdPK=LOCATION_GROUP_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.addressId=ADDRESS_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.careOfDesc=CARE_OF_DESC," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.addrUsageTpCd=ADDR_USAGE_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.locationGroupIdPK=LOCATION_GROUP_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.undelReasonTpCd=UNDEL_REASON_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.memberInd=MEMBER_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.preferredInd=PREFERRED_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.solicitInd=SOLICIT_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.locGroupTpCode=LOC_GROUP_TP_CODE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.effectStartMMDD=EFFECT_START_MMDD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.effectEndMMDD=EFFECT_END_MMDD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.effectStartTm=EFFECT_START_TM," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.effectEndTm=EFFECT_END_TM," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.startDt=START_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.endDt=END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.XVerified=XVERIFIED_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.XRetailerId=XRETAILER_ID," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.XLastModifiedSystemDate=XMODIFY_SYS_DT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.XAddressRetailerFlag=XADDR_RETAILER_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.TitleOfHonor=TITLE_OF_HONOR," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.CompanyName=COMPANY_NAME," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.SFAddressId=SFAddress_Id," + 
    "com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt.X_BPID=X_BPID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0062I This SQL query does not return additional fields defined by entity type extension XAddressGroup because
   * the base query does not return a primary key.
   *
   * @generated
   */ 
   public final static String getPartyAddressesHistoryByPartyIdSQL = "SELECT DISTINCT A.ADDRESS_ID, B.CONT_ID" + 
     " FROM H_ADDRESSGROUP A, H_LOCATIONGROUP B" + 
     " WHERE B.LOCATION_GROUP_ID = A.LOCATION_GROUP_ID AND A.ADDRESS_ID IN (SELECT ADDRESS_ID" + 
     " FROM H_ADDRESSGROUP" + 
     " WHERE LOCATION_GROUP_ID IN (SELECT LOCATION_GROUP_ID" + 
     " FROM H_LOCATIONGROUP" + 
     " WHERE CONT_ID = ? AND LOC_GROUP_TP_CODE = 'A'))";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyAddressesHistoryByPartyIdParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.contId=CONT_ID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyAddressesHistoryByPartyIdResults =
    "com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup.addressId=ADDRESS_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup.contId=CONT_ID"; 


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getPartyAddressesActiveSQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getPartyAddressesActiveParameters, results=getPartyAddressesActiveResults)
  		Iterator<ResultQueue3<EObjAddressGroup, EObjLocationGroup, EObjXAddressGroupExt>> getPartyAddressesActive(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getPartyAddressesInactiveSQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getPartyAddressesInactiveParameters, results=getPartyAddressesInactiveResults)
  		Iterator<ResultQueue3<EObjAddressGroup, EObjLocationGroup, EObjXAddressGroupExt>> getPartyAddressesInactive(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getPartyAddressesByAddressIdSQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getPartyAddressesByAddressIdParameters, results=getPartyAddressesByAddressIdResults)
  		Iterator<ResultQueue3<EObjAddressGroup, EObjLocationGroup, EObjXAddressGroupExt>> getPartyAddressesByAddressId(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getPartyAddressByIdSQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getPartyAddressByIdParameters, results=getPartyAddressByIdResults)
  		Iterator<ResultQueue3<EObjAddressGroup, EObjLocationGroup, EObjXAddressGroupExt>> getPartyAddressById(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getPartyAddressesHistorySQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getPartyAddressesHistoryParameters, results=getPartyAddressesHistoryResults)
  		Iterator<ResultQueue3<EObjAddressGroup, EObjLocationGroup, EObjXAddressGroupExt>> getPartyAddressesHistory(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getPartyAddressesSQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getPartyAddressesParameters, results=getPartyAddressesResults)
  		Iterator<ResultQueue3<EObjAddressGroup, EObjLocationGroup, EObjXAddressGroupExt>> getPartyAddresses(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getPartyAddressHistorySQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getPartyAddressHistoryParameters, results=getPartyAddressHistoryResults)
  		Iterator<ResultQueue3<EObjAddressGroup, EObjLocationGroup, EObjXAddressGroupExt>> getPartyAddressHistory(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getPartyAddressSQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getPartyAddressParameters, results=getPartyAddressResults)
  		Iterator<ResultQueue3<EObjAddressGroup, EObjLocationGroup, EObjXAddressGroupExt>> getPartyAddress(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getPartyAddressImageSQL , pattern=resultSetMapping1)
  @EntityMapping(parameters=getPartyAddressImageParameters, results=getPartyAddressImageResults)
  		Iterator<ResultQueue3<EObjAddressGroup, EObjLocationGroup, EObjXAddressGroupExt>> getPartyAddressImage(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getPartyAddressLightImagesSQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getPartyAddressLightImagesParameters, results=getPartyAddressLightImagesResults)
  		Iterator<ResultQueue3<EObjAddressGroup, EObjLocationGroup, EObjXAddressGroupExt>> getPartyAddressLightImages(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getPartyAddressHistoryByIdSQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getPartyAddressHistoryByIdParameters, results=getPartyAddressHistoryByIdResults)
  		Iterator<ResultQueue3<EObjAddressGroup, EObjLocationGroup, EObjXAddressGroupExt>> getPartyAddressHistoryById(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getPartyAddressesByAddressIdAllSQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getPartyAddressesByAddressIdAllParameters, results=getPartyAddressesByAddressIdAllResults)
  		Iterator<ResultQueue3<EObjAddressGroup, EObjLocationGroup, EObjXAddressGroupExt>> getPartyAddressesByAddressIdAll(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getPartyAddressesByAddressIdInactiveSQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getPartyAddressesByAddressIdInactiveParameters, results=getPartyAddressesByAddressIdInactiveResults)
  		Iterator<ResultQueue3<EObjAddressGroup, EObjLocationGroup, EObjXAddressGroupExt>> getPartyAddressesByAddressIdInactive(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getPartyAddressesHistoryByPartyIdSQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getPartyAddressesHistoryByPartyIdParameters, results=getPartyAddressesHistoryByPartyIdResults)
  		java.util.Iterator<com.ibm.mdm.base.db.ResultQueue2<com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup, com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup>> getPartyAddressesHistoryByPartyId(Object[] parameters);
 
}


