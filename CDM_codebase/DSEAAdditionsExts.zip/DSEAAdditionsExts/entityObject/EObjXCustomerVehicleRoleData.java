/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[6de991a9d8d42edf86abd20520656392]
 */


package com.ibm.daimler.dsea.entityObject;

import java.util.Iterator;
import com.ibm.mdm.base.db.EntityMapping;
import com.ibm.pdq.annotation.Select;
import com.ibm.pdq.annotation.Update;

import com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRole;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * @generated
 */
public interface EObjXCustomerVehicleRoleData {


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjXCustomerVehicleRoleSql = "select CUSTOMERVEHICLEROLEPK_ID, CUSTOMER_VEHICLE_ID, VEHICLE_ROLE_TP_CD, START_DT, END_DT, SOURCE_IDENT_TP_CD, CHANGED_DT, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from XCUSTOMERVEHICLEROLE where CUSTOMERVEHICLEROLEPK_ID = ? ";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String createEObjXCustomerVehicleRoleSql = "insert into XCUSTOMERVEHICLEROLE (CUSTOMERVEHICLEROLEPK_ID, CUSTOMER_VEHICLE_ID, VEHICLE_ROLE_TP_CD, START_DT, END_DT, SOURCE_IDENT_TP_CD, CHANGED_DT, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( :customerVehicleRolepkId, :customerVehicleId, :vehicleRole, :startDate, :endDate, :sourceIdentifier, :changedDate, :lastUpdateDt, :lastUpdateUser, :lastUpdateTxId)";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String updateEObjXCustomerVehicleRoleSql = "update XCUSTOMERVEHICLEROLE set CUSTOMER_VEHICLE_ID = :customerVehicleId, VEHICLE_ROLE_TP_CD = :vehicleRole, START_DT = :startDate, END_DT = :endDate, SOURCE_IDENT_TP_CD = :sourceIdentifier, CHANGED_DT = :changedDate, LAST_UPDATE_DT = :lastUpdateDt, LAST_UPDATE_USER = :lastUpdateUser, LAST_UPDATE_TX_ID = :lastUpdateTxId where CUSTOMERVEHICLEROLEPK_ID = :customerVehicleRolepkId and LAST_UPDATE_DT = :oldLastUpdateDt";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String deleteEObjXCustomerVehicleRoleSql = "delete from XCUSTOMERVEHICLEROLE where CUSTOMERVEHICLEROLEPK_ID = ?";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXCustomerVehicleRoleKeyField = "EObjXCustomerVehicleRole.customerVehicleRolepkId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXCustomerVehicleRoleGetFields =
    "EObjXCustomerVehicleRole.customerVehicleRolepkId," +
    "EObjXCustomerVehicleRole.customerVehicleId," +
    "EObjXCustomerVehicleRole.vehicleRole," +
    "EObjXCustomerVehicleRole.startDate," +
    "EObjXCustomerVehicleRole.endDate," +
    "EObjXCustomerVehicleRole.sourceIdentifier," +
    "EObjXCustomerVehicleRole.changedDate," +
    "EObjXCustomerVehicleRole.lastUpdateDt," +
    "EObjXCustomerVehicleRole.lastUpdateUser," +
    "EObjXCustomerVehicleRole.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXCustomerVehicleRoleAllFields =
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRole.customerVehicleRolepkId," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRole.customerVehicleId," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRole.vehicleRole," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRole.startDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRole.endDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRole.sourceIdentifier," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRole.changedDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRole.lastUpdateDt," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRole.lastUpdateUser," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRole.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXCustomerVehicleRoleUpdateFields =
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRole.customerVehicleId," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRole.vehicleRole," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRole.startDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRole.endDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRole.sourceIdentifier," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRole.changedDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRole.lastUpdateDt," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRole.lastUpdateUser," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRole.lastUpdateTxId," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRole.customerVehicleRolepkId," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRole.oldLastUpdateDt";   

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Select XCustomerVehicleRole by parameters.
   * @generated
   */
  @Select(sql=getEObjXCustomerVehicleRoleSql)
  @EntityMapping(parameters=EObjXCustomerVehicleRoleKeyField, results=EObjXCustomerVehicleRoleGetFields)
  Iterator<EObjXCustomerVehicleRole> getEObjXCustomerVehicleRole(Long customerVehicleRolepkId);  
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Create XCustomerVehicleRole by EObjXCustomerVehicleRole Object.
   * @generated
   */
  @Update(sql=createEObjXCustomerVehicleRoleSql)
  @EntityMapping(parameters=EObjXCustomerVehicleRoleAllFields)
    int createEObjXCustomerVehicleRole(EObjXCustomerVehicleRole e); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Update one XCustomerVehicleRole by EObjXCustomerVehicleRole object.
   * @generated
   */
  @Update(sql=updateEObjXCustomerVehicleRoleSql)
  @EntityMapping(parameters=EObjXCustomerVehicleRoleUpdateFields)
    int updateEObjXCustomerVehicleRole(EObjXCustomerVehicleRole e); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Delete XCustomerVehicleRole by parameters.
   * @generated
   */
  @Update(sql=deleteEObjXCustomerVehicleRoleSql)
  @EntityMapping(parameters=EObjXCustomerVehicleRoleKeyField)
  int deleteEObjXCustomerVehicleRole(Long customerVehicleRolepkId);

}

