package com.ibm.daimler.dsea.entityObject;

import com.ibm.pdq.runtime.generator.BaseParameterHandler;
import java.util.Iterator;
import com.ibm.daimler.dsea.entityObject.EObjXEpucidTemp;
import java.sql.PreparedStatement;
import com.ibm.pdq.runtime.statement.StatementDescriptor;
import com.ibm.pdq.runtime.generator.BaseData;
import java.sql.SQLException;
import com.ibm.pdq.annotation.Metadata;
import com.ibm.pdq.runtime.generator.BaseRowHandler;
import com.ibm.pdq.runtime.statement.SqlStatementType;
import java.sql.Types;


/**
 * <!-- begin-user-doc -->
 * 
 * <!-- end-user-doc -->
 * 
 * @generated
 */
public class EObjXEpucidTempDataImpl  extends BaseData implements EObjXEpucidTempData
{

  /**
   * @generated
   */
  public static final String generatorVersion = "3.200.75";

  /**
   * @generated
   */
  public static final String identifier = "EObjXEpucidTempData";

  /**
   * @generated
   */
  public static final long generationTime = 0x000001660aca0a7aL;

  /**
   * @generated
   */
  public static final String collection = "NULLID";

  /**
   * @generated
   */
  public static final String packageVersion = null;

  /**
   * @generated
   */
  public static final boolean forceSingleBindIsolation = false;

  /**
   * @generated
   */
  public EObjXEpucidTempDataImpl()
  {
    super();
  } 

  /**
   * @generated
   */
  public String getGeneratorVersion()
  {
    return generatorVersion;
  }

  /**
   * @Select( sql="select XEpucid_Temppk_Id, EPUCID, UCID, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from XEPUCIDTEMP where XEpucid_Temppk_Id = ? " )
   * 
   * @generated
   */
  public Iterator<EObjXEpucidTemp> getEObjXEpucidTemp (Long xEpucidTemppkId)
  {
    return queryIterator (getEObjXEpucidTempStatementDescriptor, xEpucidTemppkId);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getEObjXEpucidTempStatementDescriptor = createStatementDescriptor (
    "getEObjXEpucidTemp(Long)",
    "select XEpucid_Temppk_Id, EPUCID, UCID, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from XEPUCIDTEMP where XEpucid_Temppk_Id = ? ",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"xepucid_temppk_id", "epucid", "ucid", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetEObjXEpucidTempParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetEObjXEpucidTempRowHandler (),
    new int[][]{ {Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 250, 250, 0, 20, 19}, {0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    1);

  /**
   * @generated
   */
  public static class GetEObjXEpucidTempParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setLong (stmt, 1, Types.BIGINT, (Long)parameters[0]);
    }
  }

  /**
   * @generated
   */
  public static class GetEObjXEpucidTempRowHandler extends BaseRowHandler<EObjXEpucidTemp>
  {
    /**
     * @generated
     */
    public EObjXEpucidTemp handle (java.sql.ResultSet rs, EObjXEpucidTemp returnObject) throws java.sql.SQLException
    {
      returnObject = new EObjXEpucidTemp ();
      returnObject.setXEpucidTemppkId(getLongObject (rs, 1)); 
      returnObject.setEPUCID(getString (rs, 2)); 
      returnObject.setUCID(getString (rs, 3)); 
      returnObject.setLastUpdateDt(getTimestamp (rs, 4)); 
      returnObject.setLastUpdateUser(getString (rs, 5)); 
      returnObject.setLastUpdateTxId(getLongObject (rs, 6)); 
    
      return returnObject;
    }
  }

  /**
   * @Update( sql="insert into XEPUCIDTEMP (XEpucid_Temppk_Id, EPUCID, UCID, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( :xEpucidTemppkId, :ePUCID, :uCID, :lastUpdateDt, :lastUpdateUser, :lastUpdateTxId)" )
   * 
   * @generated
   */
  public int createEObjXEpucidTemp (EObjXEpucidTemp e)
  {
    return update (createEObjXEpucidTempStatementDescriptor, e);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor createEObjXEpucidTempStatementDescriptor = createStatementDescriptor (
    "createEObjXEpucidTemp(com.ibm.daimler.dsea.entityObject.EObjXEpucidTemp)",
    "insert into XEPUCIDTEMP (XEpucid_Temppk_Id, EPUCID, UCID, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values(  ? ,  ? ,  ? ,  ? ,  ? ,  ? )",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.INSERT,
    null,
    new CreateEObjXEpucidTempParameterHandler (),
    new int[][]{{Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 250, 250, 0, 0, 19}, {0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    2);

  /**
   * @generated
   */
  public static class CreateEObjXEpucidTempParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      EObjXEpucidTemp bean0 = (EObjXEpucidTemp) parameters[0];
      setLong (stmt, 1, Types.BIGINT, (Long)bean0.getXEpucidTemppkId());
      setString (stmt, 2, Types.VARCHAR, (String)bean0.getEPUCID());
      setString (stmt, 3, Types.VARCHAR, (String)bean0.getUCID());
      setTimestamp (stmt, 4, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUpdateDt());
      setString (stmt, 5, Types.VARCHAR, (String)bean0.getLastUpdateUser());
      setLong (stmt, 6, Types.BIGINT, (Long)bean0.getLastUpdateTxId());
    }
  }

  /**
   * @Update( sql="update XEPUCIDTEMP set EPUCID = :ePUCID, UCID = :uCID, LAST_UPDATE_DT = :lastUpdateDt, LAST_UPDATE_USER = :lastUpdateUser, LAST_UPDATE_TX_ID = :lastUpdateTxId where XEpucid_Temppk_Id = :xEpucidTemppkId and LAST_UPDATE_DT = :oldLastUpdateDt" )
   * 
   * @generated
   */
  public int updateEObjXEpucidTemp (EObjXEpucidTemp e)
  {
    return update (updateEObjXEpucidTempStatementDescriptor, e);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor updateEObjXEpucidTempStatementDescriptor = createStatementDescriptor (
    "updateEObjXEpucidTemp(com.ibm.daimler.dsea.entityObject.EObjXEpucidTemp)",
    "update XEPUCIDTEMP set EPUCID =  ? , UCID =  ? , LAST_UPDATE_DT =  ? , LAST_UPDATE_USER =  ? , LAST_UPDATE_TX_ID =  ?  where XEpucid_Temppk_Id =  ?  and LAST_UPDATE_DT =  ? ",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.UPDATE,
    null,
    new UpdateEObjXEpucidTempParameterHandler (),
    new int[][]{{Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP}, {250, 250, 0, 0, 19, 19, 0}, {0, 0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    3);

  /**
   * @generated
   */
  public static class UpdateEObjXEpucidTempParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      EObjXEpucidTemp bean0 = (EObjXEpucidTemp) parameters[0];
      setString (stmt, 1, Types.VARCHAR, (String)bean0.getEPUCID());
      setString (stmt, 2, Types.VARCHAR, (String)bean0.getUCID());
      setTimestamp (stmt, 3, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUpdateDt());
      setString (stmt, 4, Types.VARCHAR, (String)bean0.getLastUpdateUser());
      setLong (stmt, 5, Types.BIGINT, (Long)bean0.getLastUpdateTxId());
      setLong (stmt, 6, Types.BIGINT, (Long)bean0.getXEpucidTemppkId());
      setTimestamp (stmt, 7, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getOldLastUpdateDt());
    }
  }

  /**
   * @Update( sql="delete from XEPUCIDTEMP where XEpucid_Temppk_Id = ?" )
   * 
   * @generated
   */
  public int deleteEObjXEpucidTemp (Long xEpucidTemppkId)
  {
    return update (deleteEObjXEpucidTempStatementDescriptor, xEpucidTemppkId);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor deleteEObjXEpucidTempStatementDescriptor = createStatementDescriptor (
    "deleteEObjXEpucidTemp(Long)",
    "delete from XEPUCIDTEMP where XEpucid_Temppk_Id = ?",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.DELETE,
    null,
    new DeleteEObjXEpucidTempParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    4);

  /**
   * @generated
   */
  public static class DeleteEObjXEpucidTempParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setLong (stmt, 1, Types.BIGINT, (Long)parameters[0]);
    }
  }

}
