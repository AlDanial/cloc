/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[0a9d7afb530c7100b68231e6afbe84d0]
 */


package com.ibm.daimler.dsea.entityObject;

import java.util.Iterator;
import com.ibm.mdm.base.db.EntityMapping;
import com.ibm.pdq.annotation.Select;
import com.ibm.pdq.annotation.Update;

import com.dwl.tcrm.financial.entityObject.EObjContract;

import com.ibm.daimler.dsea.entityObject.EObjXContractExt;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * @generated
 */
public interface EObjXContractExtData {


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjXContractExtSql = "select XCONTRACT_NUM, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from CONTRACT where CONTRACT_ID = ? ";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String createEObjXContractExtSql = "insert into CONTRACT (ADMIN_CONTRACT_ID, CURR_CASH_VAL_AMT, PREMIUM_AMT, REPL_BY_CONTRACT, NEXT_BILL_DT, SERVICE_PROV_ID, SERVICE_ORG_NAME, BRAND_NAME, BUS_ORGUNIT_ID, LINE_OF_BUSINESS, ISSUE_LOCATION, CONTRACT_ID, MANAGED_ACCOUNT_IND, AGREEMENT_NAME, AGREEMENT_NICKNAME, SIGNED_DT, EXECUTED_DT, END_DT, REPLACES_CONTRACT, ACCOUNT_LAST_TRANSACTION_DT, TERMINATION_DT, AGREEMENT_DESCRIPTION, LAST_VERIFIED_DT, LAST_REVIEWED_DT, PRODUCT_ID, CLUSTER_KEY, ACCESS_TOKEN_VALUE, ADMIN_SYS_TP_CD, AGREEMENT_ST_TP_CD, AGREEMENT_TP_CD, BILL_TP_CD, PREMAMT_CUR_TP, CASHVAL_CUR_TP, CURRENCY_TP_CD, FREQ_MODE_TP_CD, CONTR_LANG_TP_CD, SERVICE_LEVEL_TP_CD, TERMINATION_REASON_TP_CD, XCONTRACT_NUM, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( ?1.adminContractId, ?1.currCashValAmt, ?1.premiumAmt, ?1.replByContract, ?1.nextBillDt, ?1.serviceProvId, ?1.serviceOrgName, ?1.brandName, ?1.busOrgunitId, ?1.lineOfBusiness, ?1.issueLocation, ?1.contractIdPK, ?1.managedAccountIndicator, ?1.agreementName, ?1.agreementNickName, ?1.signedDate, ?1.executedDate, ?1.endDate, ?1.replacesContract, ?1.accountLastTransactionDate, ?1.terminationDate, ?1.agreementDescription, ?1.lastVerifiedDate, ?1.lastReviewedDate, ?1.productId, ?1.clusterKey, ?1.accessTokenValue, ?1.adminSysTpCd, ?1.agreementStatusType, ?1.agreementType, ?1.billTpCd, ?1.premiumAmtCurTpCd, ?1.currCashValAmtCurTpCd, ?1.currencyTpCd, ?1.freqModeTpCd, ?1.contrLangTpCd, ?1.serviceLevelType, ?1.terminationReasonType, ?2.xContractNum, ?1.lastUpdateDt, ?1.lastUpdateUser, ?1.lastUpdateTxId)";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String updateEObjXContractExtSql = "update CONTRACT set ADMIN_CONTRACT_ID = ?1.adminContractId, CURR_CASH_VAL_AMT = ?1.currCashValAmt, PREMIUM_AMT = ?1.premiumAmt, REPL_BY_CONTRACT = ?1.replByContract, NEXT_BILL_DT = ?1.nextBillDt, SERVICE_PROV_ID = ?1.serviceProvId, SERVICE_ORG_NAME = ?1.serviceOrgName, BRAND_NAME = ?1.brandName, BUS_ORGUNIT_ID = ?1.busOrgunitId, LINE_OF_BUSINESS = ?1.lineOfBusiness, ISSUE_LOCATION = ?1.issueLocation, MANAGED_ACCOUNT_IND = ?1.managedAccountIndicator, AGREEMENT_NAME = ?1.agreementName, AGREEMENT_NICKNAME = ?1.agreementNickName, SIGNED_DT = ?1.signedDate, EXECUTED_DT = ?1.executedDate, END_DT = ?1.endDate, REPLACES_CONTRACT = ?1.replacesContract, ACCOUNT_LAST_TRANSACTION_DT = ?1.accountLastTransactionDate, TERMINATION_DT = ?1.terminationDate, AGREEMENT_DESCRIPTION = ?1.agreementDescription, LAST_VERIFIED_DT = ?1.lastVerifiedDate, LAST_REVIEWED_DT = ?1.lastReviewedDate, PRODUCT_ID = ?1.productId, CLUSTER_KEY = ?1.clusterKey, ACCESS_TOKEN_VALUE = ?1.accessTokenValue, ADMIN_SYS_TP_CD = ?1.adminSysTpCd, AGREEMENT_ST_TP_CD = ?1.agreementStatusType, AGREEMENT_TP_CD = ?1.agreementType, BILL_TP_CD = ?1.billTpCd, PREMAMT_CUR_TP = ?1.premiumAmtCurTpCd, CASHVAL_CUR_TP = ?1.currCashValAmtCurTpCd, CURRENCY_TP_CD = ?1.currencyTpCd, FREQ_MODE_TP_CD = ?1.freqModeTpCd, CONTR_LANG_TP_CD = ?1.contrLangTpCd, SERVICE_LEVEL_TP_CD = ?1.serviceLevelType, TERMINATION_REASON_TP_CD = ?1.terminationReasonType, XCONTRACT_NUM = ?2.xContractNum, LAST_UPDATE_DT = ?1.lastUpdateDt, LAST_UPDATE_USER = ?1.lastUpdateUser, LAST_UPDATE_TX_ID = ?1.lastUpdateTxId where CONTRACT_ID = ?1.contractIdPK and LAST_UPDATE_DT = ?1.oldLastUpdateDt";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String deleteEObjXContractExtSql = "delete from CONTRACT where CONTRACT_ID = ?";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXContractExtKeyField = "EObjXContractExt.contractIdPK";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXContractExtGetFields =
    "EObjXContractExt.xContractNum," +
    "EObjXContractExt.lastUpdateDt," +
    "EObjXContractExt.lastUpdateUser," +
    "EObjXContractExt.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXContractExtAllFields =
    "com.dwl.tcrm.financial.entityObject.EObjContract.adminContractId," +
    "com.dwl.tcrm.financial.entityObject.EObjContract.currCashValAmt," +
    "com.dwl.tcrm.financial.entityObject.EObjContract.premiumAmt," +
    "com.dwl.tcrm.financial.entityObject.EObjContract.replByContract," +
    "com.dwl.tcrm.financial.entityObject.EObjContract.nextBillDt," +
    "com.dwl.tcrm.financial.entityObject.EObjContract.serviceProvId," +
    "com.dwl.tcrm.financial.entityObject.EObjContract.serviceOrgName," +
    "com.dwl.tcrm.financial.entityObject.EObjContract.brandName," +
    "com.dwl.tcrm.financial.entityObject.EObjContract.busOrgunitId," +
    "com.dwl.tcrm.financial.entityObject.EObjContract.lineOfBusiness," +
    "com.dwl.tcrm.financial.entityObject.EObjContract.issueLocation," +
    "com.dwl.tcrm.financial.entityObject.EObjContract.contractIdPK," +
    "com.dwl.tcrm.financial.entityObject.EObjContract.managedAccountIndicator," +
    "com.dwl.tcrm.financial.entityObject.EObjContract.agreementName," +
    "com.dwl.tcrm.financial.entityObject.EObjContract.agreementNickName," +
    "com.dwl.tcrm.financial.entityObject.EObjContract.signedDate," +
    "com.dwl.tcrm.financial.entityObject.EObjContract.executedDate," +
    "com.dwl.tcrm.financial.entityObject.EObjContract.endDate," +
    "com.dwl.tcrm.financial.entityObject.EObjContract.replacesContract," +
    "com.dwl.tcrm.financial.entityObject.EObjContract.accountLastTransactionDate," +
    "com.dwl.tcrm.financial.entityObject.EObjContract.terminationDate," +
    "com.dwl.tcrm.financial.entityObject.EObjContract.agreementDescription," +
    "com.dwl.tcrm.financial.entityObject.EObjContract.lastVerifiedDate," +
    "com.dwl.tcrm.financial.entityObject.EObjContract.lastReviewedDate," +
    "com.dwl.tcrm.financial.entityObject.EObjContract.productId," +
    "com.dwl.tcrm.financial.entityObject.EObjContract.clusterKey," +
    "com.dwl.tcrm.financial.entityObject.EObjContract.accessTokenValue," +
    "com.dwl.tcrm.financial.entityObject.EObjContract.adminSysTpCd," +
    "com.dwl.tcrm.financial.entityObject.EObjContract.agreementStatusType," +
    "com.dwl.tcrm.financial.entityObject.EObjContract.agreementType," +
    "com.dwl.tcrm.financial.entityObject.EObjContract.billTpCd," +
    "com.dwl.tcrm.financial.entityObject.EObjContract.premiumAmtCurTpCd," +
    "com.dwl.tcrm.financial.entityObject.EObjContract.currCashValAmtCurTpCd," +
    "com.dwl.tcrm.financial.entityObject.EObjContract.currencyTpCd," +
    "com.dwl.tcrm.financial.entityObject.EObjContract.freqModeTpCd," +
    "com.dwl.tcrm.financial.entityObject.EObjContract.contrLangTpCd," +
    "com.dwl.tcrm.financial.entityObject.EObjContract.serviceLevelType," +
    "com.dwl.tcrm.financial.entityObject.EObjContract.terminationReasonType," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractExt.xContractNum," +
    "com.dwl.tcrm.financial.entityObject.EObjContract.lastUpdateDt," +
    "com.dwl.tcrm.financial.entityObject.EObjContract.lastUpdateUser," +
    "com.dwl.tcrm.financial.entityObject.EObjContract.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXContractExtUpdateFields =
    "com.dwl.tcrm.financial.entityObject.EObjContract.adminContractId," +
    "com.dwl.tcrm.financial.entityObject.EObjContract.currCashValAmt," +
    "com.dwl.tcrm.financial.entityObject.EObjContract.premiumAmt," +
    "com.dwl.tcrm.financial.entityObject.EObjContract.replByContract," +
    "com.dwl.tcrm.financial.entityObject.EObjContract.nextBillDt," +
    "com.dwl.tcrm.financial.entityObject.EObjContract.serviceProvId," +
    "com.dwl.tcrm.financial.entityObject.EObjContract.serviceOrgName," +
    "com.dwl.tcrm.financial.entityObject.EObjContract.brandName," +
    "com.dwl.tcrm.financial.entityObject.EObjContract.busOrgunitId," +
    "com.dwl.tcrm.financial.entityObject.EObjContract.lineOfBusiness," +
    "com.dwl.tcrm.financial.entityObject.EObjContract.issueLocation," +
    "com.dwl.tcrm.financial.entityObject.EObjContract.managedAccountIndicator," +
    "com.dwl.tcrm.financial.entityObject.EObjContract.agreementName," +
    "com.dwl.tcrm.financial.entityObject.EObjContract.agreementNickName," +
    "com.dwl.tcrm.financial.entityObject.EObjContract.signedDate," +
    "com.dwl.tcrm.financial.entityObject.EObjContract.executedDate," +
    "com.dwl.tcrm.financial.entityObject.EObjContract.endDate," +
    "com.dwl.tcrm.financial.entityObject.EObjContract.replacesContract," +
    "com.dwl.tcrm.financial.entityObject.EObjContract.accountLastTransactionDate," +
    "com.dwl.tcrm.financial.entityObject.EObjContract.terminationDate," +
    "com.dwl.tcrm.financial.entityObject.EObjContract.agreementDescription," +
    "com.dwl.tcrm.financial.entityObject.EObjContract.lastVerifiedDate," +
    "com.dwl.tcrm.financial.entityObject.EObjContract.lastReviewedDate," +
    "com.dwl.tcrm.financial.entityObject.EObjContract.productId," +
    "com.dwl.tcrm.financial.entityObject.EObjContract.clusterKey," +
    "com.dwl.tcrm.financial.entityObject.EObjContract.accessTokenValue," +
    "com.dwl.tcrm.financial.entityObject.EObjContract.adminSysTpCd," +
    "com.dwl.tcrm.financial.entityObject.EObjContract.agreementStatusType," +
    "com.dwl.tcrm.financial.entityObject.EObjContract.agreementType," +
    "com.dwl.tcrm.financial.entityObject.EObjContract.billTpCd," +
    "com.dwl.tcrm.financial.entityObject.EObjContract.premiumAmtCurTpCd," +
    "com.dwl.tcrm.financial.entityObject.EObjContract.currCashValAmtCurTpCd," +
    "com.dwl.tcrm.financial.entityObject.EObjContract.currencyTpCd," +
    "com.dwl.tcrm.financial.entityObject.EObjContract.freqModeTpCd," +
    "com.dwl.tcrm.financial.entityObject.EObjContract.contrLangTpCd," +
    "com.dwl.tcrm.financial.entityObject.EObjContract.serviceLevelType," +
    "com.dwl.tcrm.financial.entityObject.EObjContract.terminationReasonType," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractExt.xContractNum," +
    "com.dwl.tcrm.financial.entityObject.EObjContract.lastUpdateDt," +
    "com.dwl.tcrm.financial.entityObject.EObjContract.lastUpdateUser," +
    "com.dwl.tcrm.financial.entityObject.EObjContract.lastUpdateTxId," +
    "com.dwl.tcrm.financial.entityObject.EObjContract.contractIdPK," +
    "com.dwl.tcrm.financial.entityObject.EObjContract.oldLastUpdateDt";   

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Select XContract by parameters.
   * @generated
   */
  @Select(sql=getEObjXContractExtSql)
  @EntityMapping(parameters=EObjXContractExtKeyField, results=EObjXContractExtGetFields)
  Iterator<EObjXContractExt> getEObjXContractExt(Long contractIdPK);  
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Create XContract by EObjXContractExt Object.
   * @generated
   */
  @Update(sql=createEObjXContractExtSql)
  @EntityMapping(parameters=EObjXContractExtAllFields)
    int createEObjXContractExt(EObjContract e1, EObjXContractExt e2); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Update one XContract by EObjXContractExt object.
   * @generated
   */
  @Update(sql=updateEObjXContractExtSql)
  @EntityMapping(parameters=EObjXContractExtUpdateFields)
    int updateEObjXContractExt(EObjContract e1, EObjXContractExt e2); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Delete XContract by parameters.
   * @generated
   */
  @Update(sql=deleteEObjXContractExtSql)
  @EntityMapping(parameters=EObjXContractExtKeyField)
  int deleteEObjXContractExt(Long contractIdPK);

}

