/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[99fb0f3ffc5a4b12c4d7a1c654288789]
 */


package com.ibm.daimler.dsea.entityObject;

import java.util.Iterator;
import com.ibm.mdm.base.db.EntityMapping;
import com.ibm.pdq.annotation.Select;
import com.ibm.pdq.annotation.Update;

import com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleAus;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * @generated
 */
public interface EObjXCustomerVehicleAusData {


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjXCustomerVehicleAusSql = "select XCustomer_Vehicle_Auspk_Id, CONT_ID, VEHICLE_ID, RETAILER_ID, PURCHASE_DT, END_DT, MARKET_NAME, SOURCE_IDENT_TP_CD, MODIFY_SYS_DT, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from XCUSTOMERVEHICLEAUS where XCustomer_Vehicle_Auspk_Id = ? ";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String createEObjXCustomerVehicleAusSql = "insert into XCUSTOMERVEHICLEAUS (XCustomer_Vehicle_Auspk_Id, CONT_ID, VEHICLE_ID, RETAILER_ID, PURCHASE_DT, END_DT, MARKET_NAME, SOURCE_IDENT_TP_CD, MODIFY_SYS_DT, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( :xCustomerVehicleAuspkId, :contId, :vehicleId, :retailerId, :purchaseDate, :endDate, :marketName, :sourceIdentifier, :lastModifiedSystemDate, :lastUpdateDt, :lastUpdateUser, :lastUpdateTxId)";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String updateEObjXCustomerVehicleAusSql = "update XCUSTOMERVEHICLEAUS set CONT_ID = :contId, VEHICLE_ID = :vehicleId, RETAILER_ID = :retailerId, PURCHASE_DT = :purchaseDate, END_DT = :endDate, MARKET_NAME = :marketName, SOURCE_IDENT_TP_CD = :sourceIdentifier, MODIFY_SYS_DT = :lastModifiedSystemDate, LAST_UPDATE_DT = :lastUpdateDt, LAST_UPDATE_USER = :lastUpdateUser, LAST_UPDATE_TX_ID = :lastUpdateTxId where XCustomer_Vehicle_Auspk_Id = :xCustomerVehicleAuspkId and LAST_UPDATE_DT = :oldLastUpdateDt";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String deleteEObjXCustomerVehicleAusSql = "delete from XCUSTOMERVEHICLEAUS where XCustomer_Vehicle_Auspk_Id = ?";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXCustomerVehicleAusKeyField = "EObjXCustomerVehicleAus.xCustomerVehicleAuspkId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXCustomerVehicleAusGetFields =
    "EObjXCustomerVehicleAus.xCustomerVehicleAuspkId," +
    "EObjXCustomerVehicleAus.contId," +
    "EObjXCustomerVehicleAus.vehicleId," +
    "EObjXCustomerVehicleAus.retailerId," +
    "EObjXCustomerVehicleAus.purchaseDate," +
    "EObjXCustomerVehicleAus.endDate," +
    "EObjXCustomerVehicleAus.marketName," +
    "EObjXCustomerVehicleAus.sourceIdentifier," +
    "EObjXCustomerVehicleAus.lastModifiedSystemDate," +
    "EObjXCustomerVehicleAus.lastUpdateDt," +
    "EObjXCustomerVehicleAus.lastUpdateUser," +
    "EObjXCustomerVehicleAus.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXCustomerVehicleAusAllFields =
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleAus.xCustomerVehicleAuspkId," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleAus.contId," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleAus.vehicleId," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleAus.retailerId," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleAus.purchaseDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleAus.endDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleAus.marketName," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleAus.sourceIdentifier," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleAus.lastModifiedSystemDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleAus.lastUpdateDt," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleAus.lastUpdateUser," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleAus.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXCustomerVehicleAusUpdateFields =
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleAus.contId," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleAus.vehicleId," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleAus.retailerId," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleAus.purchaseDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleAus.endDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleAus.marketName," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleAus.sourceIdentifier," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleAus.lastModifiedSystemDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleAus.lastUpdateDt," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleAus.lastUpdateUser," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleAus.lastUpdateTxId," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleAus.xCustomerVehicleAuspkId," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleAus.oldLastUpdateDt";   

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Select XCustomerVehicleAus by parameters.
   * @generated
   */
  @Select(sql=getEObjXCustomerVehicleAusSql)
  @EntityMapping(parameters=EObjXCustomerVehicleAusKeyField, results=EObjXCustomerVehicleAusGetFields)
  Iterator<EObjXCustomerVehicleAus> getEObjXCustomerVehicleAus(Long xCustomerVehicleAuspkId);  
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Create XCustomerVehicleAus by EObjXCustomerVehicleAus Object.
   * @generated
   */
  @Update(sql=createEObjXCustomerVehicleAusSql)
  @EntityMapping(parameters=EObjXCustomerVehicleAusAllFields)
    int createEObjXCustomerVehicleAus(EObjXCustomerVehicleAus e); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Update one XCustomerVehicleAus by EObjXCustomerVehicleAus object.
   * @generated
   */
  @Update(sql=updateEObjXCustomerVehicleAusSql)
  @EntityMapping(parameters=EObjXCustomerVehicleAusUpdateFields)
    int updateEObjXCustomerVehicleAus(EObjXCustomerVehicleAus e); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Delete XCustomerVehicleAus by parameters.
   * @generated
   */
  @Update(sql=deleteEObjXCustomerVehicleAusSql)
  @EntityMapping(parameters=EObjXCustomerVehicleAusKeyField)
  int deleteEObjXCustomerVehicleAus(Long xCustomerVehicleAuspkId);

}

