/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[737c37f81a4f16e079b41f6c63d7dcbd]
 */
package com.ibm.daimler.dsea.entityObject;


import com.ibm.mdm.base.db.EntityMapping;
import com.ibm.pdq.annotation.Select;


import com.dwl.tcrm.coreParty.entityObject.EObjContactMethod;

import com.ibm.mdm.base.db.ResultQueue2;

import java.util.Iterator;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * 
 * @generated
 */
public interface XContactMethodExtInquiryData {

  /**
   * MDM_TODO: CDKWB0050I The generated parameter and result lists in this file should be checked to ensure that each matches its
   * associated SQL query. Each list entry must be comma separated and identify a field within an entity object class.
   */ 
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */ 
   public final static String tableAliasString1 = "tableAlias (" + 
     "CONTACTMETHOD => com.dwl.tcrm.coreParty.entityObject.EObjContactMethod, " + 
     "H_CONTACTMETHOD => com.dwl.tcrm.coreParty.entityObject.EObjContactMethod , " + 
     "CONTACTMETHOD => com.ibm.daimler.dsea.entityObject.EObjXContactMethodExt , " + 
     "H_CONTACTMETHOD => com.ibm.daimler.dsea.entityObject.EObjXContactMethodExt" + 
     ")";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension
   * XContactMethod.
   *
   * @generated
   */ 
   public final static String getConMethodHistorySQL = "SELECT DISTINCT A.H_CONTACT_METHOD_I AS HIST_ID_PK, A.H_ACTION_CODE, A.H_CREATED_BY, A.H_CREATE_DT, A.H_END_DT, A.CONTACT_METHOD_ID, A.REF_NUM, A.ADDRESS_ID, A.CONT_METH_CAT_CD, A.LAST_UPDATE_DT, A.LAST_UPDATE_USER, A.LAST_UPDATE_TX_ID, A.CONT_METH_STD_IND, A.PHONE_EXTENSION" + 
     " FROM H_CONTACTMETHOD A" + 
     " WHERE A.H_CONTACT_METHOD_I = ? AND (? BETWEEN A.H_CREATE_DT AND A.H_END_DT OR (? >= A.H_CREATE_DT AND A.H_END_DT IS NULL))";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getConMethodHistoryParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethod.contactMethodIdPK=H_CONTACT_METHOD_I," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethod.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethod.histCreateDt=H_CREATE_DT"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getConMethodHistoryResults =
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethod.historyIdPK=HIST_ID_PK," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethod.histActionCode=H_ACTION_CODE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethod.histCreatedBy=H_CREATED_BY," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethod.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethod.histEndDt=H_END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethod.contactMethodIdPK=CONTACT_METHOD_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethod.refNum=REF_NUM," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethod.addressId=ADDRESS_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethod.contMethCatCd=CONT_METH_CAT_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethod.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethod.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethod.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethod.contMethStandardInd=CONT_METH_STD_IND," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactMethodExt.PhoneExtension=PHONE_EXTENSION"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension
   * XContactMethod.
   *
   * @generated
   */ 
   public final static String getContactMethodSQL = "SELECT CONTACTMETHOD.CONTACT_METHOD_ID, CONTACTMETHOD.REF_NUM, CONTACTMETHOD.ADDRESS_ID, CONTACTMETHOD.CONT_METH_CAT_CD,CONTACTMETHOD.LAST_UPDATE_DT, CONTACTMETHOD.LAST_UPDATE_USER,CONTACTMETHOD.LAST_UPDATE_TX_ID,CONT_METH_STD_IND, CONTACTMETHOD.PHONE_EXTENSION" + 
     " FROM CONTACTMETHOD" + 
     " WHERE (CONTACTMETHOD.CONTACT_METHOD_ID =?)";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getContactMethodParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethod.contactMethodIdPK=CONTACT_METHOD_ID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getContactMethodResults =
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethod.contactMethodIdPK=CONTACT_METHOD_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethod.refNum=REF_NUM," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethod.addressId=ADDRESS_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethod.contMethCatCd=CONT_METH_CAT_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethod.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethod.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethod.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethod.contMethStandardInd=CONT_METH_STD_IND," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactMethodExt.PhoneExtension=PHONE_EXTENSION"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension
   * XContactMethod.
   *
   * @generated
   */ 
   public final static String getConMethodLightImgSQL = "SELECT DISTINCT A.CONTACT_METHOD_ID, A.LAST_UPDATE_DT, A.PHONE_EXTENSION" + 
     " FROM H_CONTACTMETHOD A" + 
     " WHERE A.CONTACT_METHOD_ID = ? AND ( A.H_CREATE_DT BETWEEN ? AND ? )";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getConMethodLightImgParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethod.contactMethodIdPK=CONTACT_METHOD_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethod.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethod.histCreateDt=H_CREATE_DT"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getConMethodLightImgResults =
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethod.contactMethodIdPK=CONTACT_METHOD_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethod.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContactMethodExt.PhoneExtension=PHONE_EXTENSION"; 


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getConMethodHistorySQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getConMethodHistoryParameters, results=getConMethodHistoryResults)
  		Iterator<ResultQueue2<EObjContactMethod, EObjXContactMethodExt>> getConMethodHistory(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getContactMethodSQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getContactMethodParameters, results=getContactMethodResults)
  		Iterator<ResultQueue2<EObjContactMethod, EObjXContactMethodExt>> getContactMethod(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getConMethodLightImgSQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getConMethodLightImgParameters, results=getConMethodLightImgResults)
  		Iterator<ResultQueue2<EObjContactMethod, EObjXContactMethodExt>> getConMethodLightImg(Object[] parameters);
 
}


