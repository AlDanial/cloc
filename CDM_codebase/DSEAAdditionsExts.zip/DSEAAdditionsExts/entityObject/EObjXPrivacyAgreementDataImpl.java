package com.ibm.daimler.dsea.entityObject;

import com.ibm.pdq.runtime.generator.BaseParameterHandler;
import java.util.Iterator;
import java.sql.PreparedStatement;
import com.ibm.pdq.runtime.statement.StatementDescriptor;
import com.ibm.daimler.dsea.entityObject.EObjXPrivacyAgreement;
import com.ibm.pdq.runtime.generator.BaseData;
import java.sql.SQLException;
import com.ibm.pdq.annotation.Metadata;
import com.ibm.pdq.runtime.generator.BaseRowHandler;
import com.ibm.pdq.runtime.statement.SqlStatementType;
import java.sql.Types;


/**
 * <!-- begin-user-doc -->
 * 
 * <!-- end-user-doc -->
 * 
 * @generated
 */
public class EObjXPrivacyAgreementDataImpl  extends BaseData implements EObjXPrivacyAgreementData
{

  /**
   * @generated
   */
  public static final String generatorVersion = "3.200.75";

  /**
   * @generated
   */
  public static final String identifier = "EObjXPrivacyAgreementData";

  /**
   * @generated
   */
  public static final long generationTime = 0x0000015e13f83e91L;

  /**
   * @generated
   */
  public static final String collection = "NULLID";

  /**
   * @generated
   */
  public static final String packageVersion = null;

  /**
   * @generated
   */
  public static final boolean forceSingleBindIsolation = false;

  /**
   * @generated
   */
  public EObjXPrivacyAgreementDataImpl()
  {
    super();
  } 

  /**
   * @generated
   */
  public String getGeneratorVersion()
  {
    return generatorVersion;
  }

  /**
   * @Select( sql="select PRIVAGREEMENTPK_ID, LOCATION_GROUP_ID, ACTION_TP_CD, SOURCE_IDENT_TP_CD, START_DT, END_DT, MODIFY_SYS_DT, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from XPRIVAGREEMENT where PRIVAGREEMENTPK_ID = ? " )
   * 
   * @generated
   */
  public Iterator<EObjXPrivacyAgreement> getEObjXPrivacyAgreement (Long privacyAgreementpkId)
  {
    return queryIterator (getEObjXPrivacyAgreementStatementDescriptor, privacyAgreementpkId);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getEObjXPrivacyAgreementStatementDescriptor = createStatementDescriptor (
    "getEObjXPrivacyAgreement(Long)",
    "select PRIVAGREEMENTPK_ID, LOCATION_GROUP_ID, ACTION_TP_CD, SOURCE_IDENT_TP_CD, START_DT, END_DT, MODIFY_SYS_DT, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from XPRIVAGREEMENT where PRIVAGREEMENTPK_ID = ? ",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"privagreementpk_id", "location_group_id", "action_tp_cd", "source_ident_tp_cd", "start_dt", "end_dt", "modify_sys_dt", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetEObjXPrivacyAgreementParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetEObjXPrivacyAgreementRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 19, 19, 19, 0, 0, 0, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    1);

  /**
   * @generated
   */
  public static class GetEObjXPrivacyAgreementParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setLong (stmt, 1, Types.BIGINT, (Long)parameters[0]);
    }
  }

  /**
   * @generated
   */
  public static class GetEObjXPrivacyAgreementRowHandler extends BaseRowHandler<EObjXPrivacyAgreement>
  {
    /**
     * @generated
     */
    public EObjXPrivacyAgreement handle (java.sql.ResultSet rs, EObjXPrivacyAgreement returnObject) throws java.sql.SQLException
    {
      returnObject = new EObjXPrivacyAgreement ();
      returnObject.setPrivacyAgreementpkId(getLongObject (rs, 1)); 
      returnObject.setLocationGroupId(getLongObject (rs, 2)); 
      returnObject.setAction(getLongObject (rs, 3)); 
      returnObject.setSourceIdentifier(getLongObject (rs, 4)); 
      returnObject.setStartDate(getTimestamp (rs, 5)); 
      returnObject.setEndDate(getTimestamp (rs, 6)); 
      returnObject.setLastModifiedSystemDate(getTimestamp (rs, 7)); 
      returnObject.setLastUpdateDt(getTimestamp (rs, 8)); 
      returnObject.setLastUpdateUser(getString (rs, 9)); 
      returnObject.setLastUpdateTxId(getLongObject (rs, 10)); 
    
      return returnObject;
    }
  }

  /**
   * @Update( sql="insert into XPRIVAGREEMENT (PRIVAGREEMENTPK_ID, LOCATION_GROUP_ID, ACTION_TP_CD, SOURCE_IDENT_TP_CD, START_DT, END_DT, MODIFY_SYS_DT, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( :privacyAgreementpkId, :locationGroupId, :action, :sourceIdentifier, :startDate, :endDate, :lastModifiedSystemDate, :lastUpdateDt, :lastUpdateUser, :lastUpdateTxId)" )
   * 
   * @generated
   */
  public int createEObjXPrivacyAgreement (EObjXPrivacyAgreement e)
  {
    return update (createEObjXPrivacyAgreementStatementDescriptor, e);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor createEObjXPrivacyAgreementStatementDescriptor = createStatementDescriptor (
    "createEObjXPrivacyAgreement(com.ibm.daimler.dsea.entityObject.EObjXPrivacyAgreement)",
    "insert into XPRIVAGREEMENT (PRIVAGREEMENTPK_ID, LOCATION_GROUP_ID, ACTION_TP_CD, SOURCE_IDENT_TP_CD, START_DT, END_DT, MODIFY_SYS_DT, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values(  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? )",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.INSERT,
    null,
    new CreateEObjXPrivacyAgreementParameterHandler (),
    new int[][]{{Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 19, 19, 19, 0, 0, 0, 0, 0, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1, 1, 1, 1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    2);

  /**
   * @generated
   */
  public static class CreateEObjXPrivacyAgreementParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      EObjXPrivacyAgreement bean0 = (EObjXPrivacyAgreement) parameters[0];
      setLong (stmt, 1, Types.BIGINT, (Long)bean0.getPrivacyAgreementpkId());
      setLong (stmt, 2, Types.BIGINT, (Long)bean0.getLocationGroupId());
      setLong (stmt, 3, Types.BIGINT, (Long)bean0.getAction());
      setLong (stmt, 4, Types.BIGINT, (Long)bean0.getSourceIdentifier());
      setTimestamp (stmt, 5, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getStartDate());
      setTimestamp (stmt, 6, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getEndDate());
      setTimestamp (stmt, 7, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastModifiedSystemDate());
      setTimestamp (stmt, 8, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUpdateDt());
      setString (stmt, 9, Types.VARCHAR, (String)bean0.getLastUpdateUser());
      setLong (stmt, 10, Types.BIGINT, (Long)bean0.getLastUpdateTxId());
    }
  }

  /**
   * @Update( sql="update XPRIVAGREEMENT set LOCATION_GROUP_ID = :locationGroupId, ACTION_TP_CD = :action, SOURCE_IDENT_TP_CD = :sourceIdentifier, START_DT = :startDate, END_DT = :endDate, MODIFY_SYS_DT = :lastModifiedSystemDate, LAST_UPDATE_DT = :lastUpdateDt, LAST_UPDATE_USER = :lastUpdateUser, LAST_UPDATE_TX_ID = :lastUpdateTxId where PRIVAGREEMENTPK_ID = :privacyAgreementpkId and LAST_UPDATE_DT = :oldLastUpdateDt" )
   * 
   * @generated
   */
  public int updateEObjXPrivacyAgreement (EObjXPrivacyAgreement e)
  {
    return update (updateEObjXPrivacyAgreementStatementDescriptor, e);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor updateEObjXPrivacyAgreementStatementDescriptor = createStatementDescriptor (
    "updateEObjXPrivacyAgreement(com.ibm.daimler.dsea.entityObject.EObjXPrivacyAgreement)",
    "update XPRIVAGREEMENT set LOCATION_GROUP_ID =  ? , ACTION_TP_CD =  ? , SOURCE_IDENT_TP_CD =  ? , START_DT =  ? , END_DT =  ? , MODIFY_SYS_DT =  ? , LAST_UPDATE_DT =  ? , LAST_UPDATE_USER =  ? , LAST_UPDATE_TX_ID =  ?  where PRIVAGREEMENTPK_ID =  ?  and LAST_UPDATE_DT =  ? ",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.UPDATE,
    null,
    new UpdateEObjXPrivacyAgreementParameterHandler (),
    new int[][]{{Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP}, {19, 19, 19, 0, 0, 0, 0, 0, 19, 19, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    3);

  /**
   * @generated
   */
  public static class UpdateEObjXPrivacyAgreementParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      EObjXPrivacyAgreement bean0 = (EObjXPrivacyAgreement) parameters[0];
      setLong (stmt, 1, Types.BIGINT, (Long)bean0.getLocationGroupId());
      setLong (stmt, 2, Types.BIGINT, (Long)bean0.getAction());
      setLong (stmt, 3, Types.BIGINT, (Long)bean0.getSourceIdentifier());
      setTimestamp (stmt, 4, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getStartDate());
      setTimestamp (stmt, 5, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getEndDate());
      setTimestamp (stmt, 6, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastModifiedSystemDate());
      setTimestamp (stmt, 7, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUpdateDt());
      setString (stmt, 8, Types.VARCHAR, (String)bean0.getLastUpdateUser());
      setLong (stmt, 9, Types.BIGINT, (Long)bean0.getLastUpdateTxId());
      setLong (stmt, 10, Types.BIGINT, (Long)bean0.getPrivacyAgreementpkId());
      setTimestamp (stmt, 11, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getOldLastUpdateDt());
    }
  }

  /**
   * @Update( sql="delete from XPRIVAGREEMENT where PRIVAGREEMENTPK_ID = ?" )
   * 
   * @generated
   */
  public int deleteEObjXPrivacyAgreement (Long privacyAgreementpkId)
  {
    return update (deleteEObjXPrivacyAgreementStatementDescriptor, privacyAgreementpkId);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor deleteEObjXPrivacyAgreementStatementDescriptor = createStatementDescriptor (
    "deleteEObjXPrivacyAgreement(Long)",
    "delete from XPRIVAGREEMENT where PRIVAGREEMENTPK_ID = ?",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.DELETE,
    null,
    new DeleteEObjXPrivacyAgreementParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    4);

  /**
   * @generated
   */
  public static class DeleteEObjXPrivacyAgreementParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setLong (stmt, 1, Types.BIGINT, (Long)parameters[0]);
    }
  }

}
