package com.ibm.daimler.dsea.entityObject;

import com.ibm.pdq.runtime.generator.BaseParameterHandler;
import java.util.Iterator;
import java.sql.PreparedStatement;
import com.ibm.pdq.runtime.statement.StatementDescriptor;
import com.ibm.pdq.runtime.generator.BaseData;
import java.sql.SQLException;
import com.ibm.pdq.annotation.Metadata;
import com.ibm.pdq.runtime.generator.BaseRowHandler;
import com.ibm.pdq.runtime.statement.SqlStatementType;
import com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleAus;
import java.sql.Types;


/**
 * <!-- begin-user-doc -->
 * 
 * <!-- end-user-doc -->
 * 
 * @generated
 */
public class EObjXCustomerVehicleAusDataImpl  extends BaseData implements EObjXCustomerVehicleAusData
{

  /**
   * @generated
   */
  public static final String generatorVersion = "3.200.75";

  /**
   * @generated
   */
  public static final String identifier = "EObjXCustomerVehicleAusData";

  /**
   * @generated
   */
  public static final long generationTime = 0x00000166d44893b1L;

  /**
   * @generated
   */
  public static final String collection = "NULLID";

  /**
   * @generated
   */
  public static final String packageVersion = null;

  /**
   * @generated
   */
  public static final boolean forceSingleBindIsolation = false;

  /**
   * @generated
   */
  public EObjXCustomerVehicleAusDataImpl()
  {
    super();
  } 

  /**
   * @generated
   */
  public String getGeneratorVersion()
  {
    return generatorVersion;
  }

  /**
   * @Select( sql="select XCustomer_Vehicle_Auspk_Id, CONT_ID, VEHICLE_ID, RETAILER_ID, PURCHASE_DT, END_DT, MARKET_NAME, SOURCE_IDENT_TP_CD, MODIFY_SYS_DT, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from XCUSTOMERVEHICLEAUS where XCustomer_Vehicle_Auspk_Id = ? " )
   * 
   * @generated
   */
  public Iterator<EObjXCustomerVehicleAus> getEObjXCustomerVehicleAus (Long xCustomerVehicleAuspkId)
  {
    return queryIterator (getEObjXCustomerVehicleAusStatementDescriptor, xCustomerVehicleAuspkId);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getEObjXCustomerVehicleAusStatementDescriptor = createStatementDescriptor (
    "getEObjXCustomerVehicleAus(Long)",
    "select XCustomer_Vehicle_Auspk_Id, CONT_ID, VEHICLE_ID, RETAILER_ID, PURCHASE_DT, END_DT, MARKET_NAME, SOURCE_IDENT_TP_CD, MODIFY_SYS_DT, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from XCUSTOMERVEHICLEAUS where XCustomer_Vehicle_Auspk_Id = ? ",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"xcustomer_vehicle_auspk_id", "cont_id", "vehicle_id", "retailer_id", "purchase_dt", "end_dt", "market_name", "source_ident_tp_cd", "modify_sys_dt", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetEObjXCustomerVehicleAusParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetEObjXCustomerVehicleAusRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 19, 19, 19, 0, 0, 10, 19, 0, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    1);

  /**
   * @generated
   */
  public static class GetEObjXCustomerVehicleAusParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setLong (stmt, 1, Types.BIGINT, (Long)parameters[0]);
    }
  }

  /**
   * @generated
   */
  public static class GetEObjXCustomerVehicleAusRowHandler extends BaseRowHandler<EObjXCustomerVehicleAus>
  {
    /**
     * @generated
     */
    public EObjXCustomerVehicleAus handle (java.sql.ResultSet rs, EObjXCustomerVehicleAus returnObject) throws java.sql.SQLException
    {
      returnObject = new EObjXCustomerVehicleAus ();
      returnObject.setXCustomerVehicleAuspkId(getLongObject (rs, 1)); 
      returnObject.setContId(getLongObject (rs, 2)); 
      returnObject.setVehicleId(getLongObject (rs, 3)); 
      returnObject.setRetailerId(getLongObject (rs, 4)); 
      returnObject.setPurchaseDate(getTimestamp (rs, 5)); 
      returnObject.setEndDate(getTimestamp (rs, 6)); 
      returnObject.setMarketName(getString (rs, 7)); 
      returnObject.setSourceIdentifier(getLongObject (rs, 8)); 
      returnObject.setLastModifiedSystemDate(getTimestamp (rs, 9)); 
      returnObject.setLastUpdateDt(getTimestamp (rs, 10)); 
      returnObject.setLastUpdateUser(getString (rs, 11)); 
      returnObject.setLastUpdateTxId(getLongObject (rs, 12)); 
    
      return returnObject;
    }
  }

  /**
   * @Update( sql="insert into XCUSTOMERVEHICLEAUS (XCustomer_Vehicle_Auspk_Id, CONT_ID, VEHICLE_ID, RETAILER_ID, PURCHASE_DT, END_DT, MARKET_NAME, SOURCE_IDENT_TP_CD, MODIFY_SYS_DT, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( :xCustomerVehicleAuspkId, :contId, :vehicleId, :retailerId, :purchaseDate, :endDate, :marketName, :sourceIdentifier, :lastModifiedSystemDate, :lastUpdateDt, :lastUpdateUser, :lastUpdateTxId)" )
   * 
   * @generated
   */
  public int createEObjXCustomerVehicleAus (EObjXCustomerVehicleAus e)
  {
    return update (createEObjXCustomerVehicleAusStatementDescriptor, e);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor createEObjXCustomerVehicleAusStatementDescriptor = createStatementDescriptor (
    "createEObjXCustomerVehicleAus(com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleAus)",
    "insert into XCUSTOMERVEHICLEAUS (XCustomer_Vehicle_Auspk_Id, CONT_ID, VEHICLE_ID, RETAILER_ID, PURCHASE_DT, END_DT, MARKET_NAME, SOURCE_IDENT_TP_CD, MODIFY_SYS_DT, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values(  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? )",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.INSERT,
    null,
    new CreateEObjXCustomerVehicleAusParameterHandler (),
    new int[][]{{Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 19, 19, 19, 0, 0, 10, 19, 0, 0, 0, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    2);

  /**
   * @generated
   */
  public static class CreateEObjXCustomerVehicleAusParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      EObjXCustomerVehicleAus bean0 = (EObjXCustomerVehicleAus) parameters[0];
      setLong (stmt, 1, Types.BIGINT, (Long)bean0.getXCustomerVehicleAuspkId());
      setLong (stmt, 2, Types.BIGINT, (Long)bean0.getContId());
      setLong (stmt, 3, Types.BIGINT, (Long)bean0.getVehicleId());
      setLong (stmt, 4, Types.BIGINT, (Long)bean0.getRetailerId());
      setTimestamp (stmt, 5, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getPurchaseDate());
      setTimestamp (stmt, 6, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getEndDate());
      setString (stmt, 7, Types.VARCHAR, (String)bean0.getMarketName());
      setLong (stmt, 8, Types.BIGINT, (Long)bean0.getSourceIdentifier());
      setTimestamp (stmt, 9, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastModifiedSystemDate());
      setTimestamp (stmt, 10, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUpdateDt());
      setString (stmt, 11, Types.VARCHAR, (String)bean0.getLastUpdateUser());
      setLong (stmt, 12, Types.BIGINT, (Long)bean0.getLastUpdateTxId());
    }
  }

  /**
   * @Update( sql="update XCUSTOMERVEHICLEAUS set CONT_ID = :contId, VEHICLE_ID = :vehicleId, RETAILER_ID = :retailerId, PURCHASE_DT = :purchaseDate, END_DT = :endDate, MARKET_NAME = :marketName, SOURCE_IDENT_TP_CD = :sourceIdentifier, MODIFY_SYS_DT = :lastModifiedSystemDate, LAST_UPDATE_DT = :lastUpdateDt, LAST_UPDATE_USER = :lastUpdateUser, LAST_UPDATE_TX_ID = :lastUpdateTxId where XCustomer_Vehicle_Auspk_Id = :xCustomerVehicleAuspkId and LAST_UPDATE_DT = :oldLastUpdateDt" )
   * 
   * @generated
   */
  public int updateEObjXCustomerVehicleAus (EObjXCustomerVehicleAus e)
  {
    return update (updateEObjXCustomerVehicleAusStatementDescriptor, e);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor updateEObjXCustomerVehicleAusStatementDescriptor = createStatementDescriptor (
    "updateEObjXCustomerVehicleAus(com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleAus)",
    "update XCUSTOMERVEHICLEAUS set CONT_ID =  ? , VEHICLE_ID =  ? , RETAILER_ID =  ? , PURCHASE_DT =  ? , END_DT =  ? , MARKET_NAME =  ? , SOURCE_IDENT_TP_CD =  ? , MODIFY_SYS_DT =  ? , LAST_UPDATE_DT =  ? , LAST_UPDATE_USER =  ? , LAST_UPDATE_TX_ID =  ?  where XCustomer_Vehicle_Auspk_Id =  ?  and LAST_UPDATE_DT =  ? ",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.UPDATE,
    null,
    new UpdateEObjXCustomerVehicleAusParameterHandler (),
    new int[][]{{Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP}, {19, 19, 19, 0, 0, 10, 19, 0, 0, 0, 19, 19, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    3);

  /**
   * @generated
   */
  public static class UpdateEObjXCustomerVehicleAusParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      EObjXCustomerVehicleAus bean0 = (EObjXCustomerVehicleAus) parameters[0];
      setLong (stmt, 1, Types.BIGINT, (Long)bean0.getContId());
      setLong (stmt, 2, Types.BIGINT, (Long)bean0.getVehicleId());
      setLong (stmt, 3, Types.BIGINT, (Long)bean0.getRetailerId());
      setTimestamp (stmt, 4, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getPurchaseDate());
      setTimestamp (stmt, 5, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getEndDate());
      setString (stmt, 6, Types.VARCHAR, (String)bean0.getMarketName());
      setLong (stmt, 7, Types.BIGINT, (Long)bean0.getSourceIdentifier());
      setTimestamp (stmt, 8, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastModifiedSystemDate());
      setTimestamp (stmt, 9, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUpdateDt());
      setString (stmt, 10, Types.VARCHAR, (String)bean0.getLastUpdateUser());
      setLong (stmt, 11, Types.BIGINT, (Long)bean0.getLastUpdateTxId());
      setLong (stmt, 12, Types.BIGINT, (Long)bean0.getXCustomerVehicleAuspkId());
      setTimestamp (stmt, 13, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getOldLastUpdateDt());
    }
  }

  /**
   * @Update( sql="delete from XCUSTOMERVEHICLEAUS where XCustomer_Vehicle_Auspk_Id = ?" )
   * 
   * @generated
   */
  public int deleteEObjXCustomerVehicleAus (Long xCustomerVehicleAuspkId)
  {
    return update (deleteEObjXCustomerVehicleAusStatementDescriptor, xCustomerVehicleAuspkId);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor deleteEObjXCustomerVehicleAusStatementDescriptor = createStatementDescriptor (
    "deleteEObjXCustomerVehicleAus(Long)",
    "delete from XCUSTOMERVEHICLEAUS where XCustomer_Vehicle_Auspk_Id = ?",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.DELETE,
    null,
    new DeleteEObjXCustomerVehicleAusParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    4);

  /**
   * @generated
   */
  public static class DeleteEObjXCustomerVehicleAusParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setLong (stmt, 1, Types.BIGINT, (Long)parameters[0]);
    }
  }

}
