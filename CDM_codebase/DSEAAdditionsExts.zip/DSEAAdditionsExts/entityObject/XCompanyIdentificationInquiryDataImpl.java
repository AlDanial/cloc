package com.ibm.daimler.dsea.entityObject;

import com.ibm.pdq.runtime.generator.BaseParameterHandler;
import java.util.Iterator;
import com.ibm.daimler.dsea.entityObject.EObjXCompanyIdentification;
import com.ibm.mdm.base.db.ResultQueue1;
import java.sql.PreparedStatement;
import com.ibm.pdq.runtime.statement.StatementDescriptor;
import com.ibm.pdq.runtime.generator.BaseData;
import java.sql.SQLException;
import com.ibm.pdq.annotation.Metadata;
import com.ibm.pdq.runtime.generator.BaseRowHandler;
import com.ibm.pdq.runtime.statement.SqlStatementType;
import java.sql.Types;


@SuppressWarnings("unchecked")

/**
 * <!-- begin-user-doc -->
 * 
 * <!-- end-user-doc -->
 * 
 * @generated
 */
public class XCompanyIdentificationInquiryDataImpl  extends BaseData implements XCompanyIdentificationInquiryData
{

  /**
   * @generated
   */
  public static final String generatorVersion = "3.200.75";

  /**
   * @generated
   */
  public static final String identifier = "XCompanyIdentificationInquiryData";

  /**
   * @generated
   */
  public static final long generationTime = 0x000001635e660c3dL;

  /**
   * @generated
   */
  public static final String collection = "NULLID";

  /**
   * @generated
   */
  public static final String packageVersion = null;

  /**
   * @generated
   */
  public static final boolean forceSingleBindIsolation = false;

  /**
   * @generated
   */
  public XCompanyIdentificationInquiryDataImpl()
  {
    super();
  } 

  /**
   * @generated
   */
  public String getGeneratorVersion()
  {
    return generatorVersion;
  }

  /**
   * @Select( sql="SELECT r.COMPANYIDENTIFICATIONPK_ID COMPANYIDENTIFICATIONPK_ID, r.COMPANYMAGIC_NUMBER COMPANYMAGIC_NUMBER, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XCOMPANYIDENTIFICATION r WHERE r.COMPANYIDENTIFICATIONPK_ID = ? ", pattern="tableAlias (XCOMPANYIDENTIFICATION => com.ibm.daimler.dsea.entityObject.EObjXCompanyIdentification, H_XCOMPANYIDENTIFICATION => com.ibm.daimler.dsea.entityObject.EObjXCompanyIdentification)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue1<EObjXCompanyIdentification>> getXCompanyIdentification (Object[] parameters)
  {
    return queryIterator (getXCompanyIdentificationStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getXCompanyIdentificationStatementDescriptor = createStatementDescriptor (
    "getXCompanyIdentification(Object[])",
    "SELECT r.COMPANYIDENTIFICATIONPK_ID COMPANYIDENTIFICATIONPK_ID, r.COMPANYMAGIC_NUMBER COMPANYMAGIC_NUMBER, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XCOMPANYIDENTIFICATION r WHERE r.COMPANYIDENTIFICATIONPK_ID = ? ",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"companyidentificationpk_id", "companymagic_number", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetXCompanyIdentificationParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetXCompanyIdentificationRowHandler (),
    new int[][]{ {Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 250, 0, 20, 19}, {0, 0, 0, 0, 0}, {0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    1);

  /**
   * @generated
   */
  public static class GetXCompanyIdentificationParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetXCompanyIdentificationRowHandler extends BaseRowHandler<ResultQueue1<EObjXCompanyIdentification>>
  {
    /**
     * @generated
     */
    public ResultQueue1<EObjXCompanyIdentification> handle (java.sql.ResultSet rs, ResultQueue1<EObjXCompanyIdentification> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue1<EObjXCompanyIdentification> ();

      EObjXCompanyIdentification returnObject1 = new EObjXCompanyIdentification ();
      returnObject1.setCompanyIdentificationpkId(getLongObject (rs, 1)); 
      returnObject1.setCompanyMagicNumber(getString (rs, 2)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 3)); 
      returnObject1.setLastUpdateUser(getString (rs, 4)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 5)); 
      returnObject.add (returnObject1);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT r.H_COMPANYIDENTIFICATIONPK_ID hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.COMPANYIDENTIFICATIONPK_ID COMPANYIDENTIFICATIONPK_ID, r.COMPANYMAGIC_NUMBER COMPANYMAGIC_NUMBER, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XCOMPANYIDENTIFICATION r WHERE r.H_COMPANYIDENTIFICATIONPK_ID = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))", pattern="tableAlias (XCOMPANYIDENTIFICATION => com.ibm.daimler.dsea.entityObject.EObjXCompanyIdentification, H_XCOMPANYIDENTIFICATION => com.ibm.daimler.dsea.entityObject.EObjXCompanyIdentification)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue1<EObjXCompanyIdentification>> getXCompanyIdentificationHistory (Object[] parameters)
  {
    return queryIterator (getXCompanyIdentificationHistoryStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getXCompanyIdentificationHistoryStatementDescriptor = createStatementDescriptor (
    "getXCompanyIdentificationHistory(Object[])",
    "SELECT r.H_COMPANYIDENTIFICATIONPK_ID hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.COMPANYIDENTIFICATIONPK_ID COMPANYIDENTIFICATIONPK_ID, r.COMPANYMAGIC_NUMBER COMPANYMAGIC_NUMBER, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XCOMPANYIDENTIFICATION r WHERE r.H_COMPANYIDENTIFICATIONPK_ID = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"historyidpk", "h_action_code", "h_created_by", "h_create_dt", "h_end_dt", "companyidentificationpk_id", "companymagic_number", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetXCompanyIdentificationHistoryParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP}, {19, 0, 0}, {0, 0, 0}, {1, 1, 1}},
    null,
    new GetXCompanyIdentificationHistoryRowHandler (),
    new int[][]{ {Types.BIGINT, Types.CHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 1, 20, 0, 0, 19, 250, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    2);

  /**
   * @generated
   */
  public static class GetXCompanyIdentificationHistoryParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetXCompanyIdentificationHistoryRowHandler extends BaseRowHandler<ResultQueue1<EObjXCompanyIdentification>>
  {
    /**
     * @generated
     */
    public ResultQueue1<EObjXCompanyIdentification> handle (java.sql.ResultSet rs, ResultQueue1<EObjXCompanyIdentification> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue1<EObjXCompanyIdentification> ();

      EObjXCompanyIdentification returnObject1 = new EObjXCompanyIdentification ();
      returnObject1.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject1.setHistActionCode(getString (rs, 2)); 
      returnObject1.setHistCreatedBy(getString (rs, 3)); 
      returnObject1.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject1.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject1.setCompanyIdentificationpkId(getLongObject (rs, 6)); 
      returnObject1.setCompanyMagicNumber(getString (rs, 7)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 8)); 
      returnObject1.setLastUpdateUser(getString (rs, 9)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 10)); 
      returnObject.add (returnObject1);

    
      return returnObject;
    }
  }

}
