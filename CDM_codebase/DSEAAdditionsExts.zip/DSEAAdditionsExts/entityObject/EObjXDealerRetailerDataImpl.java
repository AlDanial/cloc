package com.ibm.daimler.dsea.entityObject;

import com.ibm.pdq.runtime.generator.BaseParameterHandler;
import java.util.Iterator;
import java.sql.PreparedStatement;
import com.ibm.pdq.runtime.statement.StatementDescriptor;
import com.ibm.pdq.runtime.generator.BaseData;
import java.sql.SQLException;
import com.ibm.pdq.annotation.Metadata;
import com.ibm.daimler.dsea.entityObject.EObjXDealerRetailer;
import com.ibm.pdq.runtime.generator.BaseRowHandler;
import com.ibm.pdq.runtime.statement.SqlStatementType;
import java.sql.Types;


/**
 * <!-- begin-user-doc -->
 * 
 * <!-- end-user-doc -->
 * 
 * @generated
 */
public class EObjXDealerRetailerDataImpl  extends BaseData implements EObjXDealerRetailerData
{

  /**
   * @generated
   */
  public static final String generatorVersion = "3.200.75";

  /**
   * @generated
   */
  public static final String identifier = "EObjXDealerRetailerData";

  /**
   * @generated
   */
  public static final long generationTime = 0x000001635e66022fL;

  /**
   * @generated
   */
  public static final String collection = "NULLID";

  /**
   * @generated
   */
  public static final String packageVersion = null;

  /**
   * @generated
   */
  public static final boolean forceSingleBindIsolation = false;

  /**
   * @generated
   */
  public EObjXDealerRetailerDataImpl()
  {
    super();
  } 

  /**
   * @generated
   */
  public String getGeneratorVersion()
  {
    return generatorVersion;
  }

  /**
   * @Select( sql="select XDealer_Retailerpk_Id, Dealer_Code, Retailer_Code, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from XDEALERRETAILER where XDealer_Retailerpk_Id = ? " )
   * 
   * @generated
   */
  public Iterator<EObjXDealerRetailer> getEObjXDealerRetailer (Long xDealerRetailerpkId)
  {
    return queryIterator (getEObjXDealerRetailerStatementDescriptor, xDealerRetailerpkId);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getEObjXDealerRetailerStatementDescriptor = createStatementDescriptor (
    "getEObjXDealerRetailer(Long)",
    "select XDealer_Retailerpk_Id, Dealer_Code, Retailer_Code, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from XDEALERRETAILER where XDealer_Retailerpk_Id = ? ",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"xdealer_retailerpk_id", "dealer_code", "retailer_code", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetEObjXDealerRetailerParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetEObjXDealerRetailerRowHandler (),
    new int[][]{ {Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 250, 250, 0, 20, 19}, {0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    1);

  /**
   * @generated
   */
  public static class GetEObjXDealerRetailerParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setLong (stmt, 1, Types.BIGINT, (Long)parameters[0]);
    }
  }

  /**
   * @generated
   */
  public static class GetEObjXDealerRetailerRowHandler extends BaseRowHandler<EObjXDealerRetailer>
  {
    /**
     * @generated
     */
    public EObjXDealerRetailer handle (java.sql.ResultSet rs, EObjXDealerRetailer returnObject) throws java.sql.SQLException
    {
      returnObject = new EObjXDealerRetailer ();
      returnObject.setXDealerRetailerpkId(getLongObject (rs, 1)); 
      returnObject.setDealerCode(getString (rs, 2)); 
      returnObject.setRetailerCode(getString (rs, 3)); 
      returnObject.setLastUpdateDt(getTimestamp (rs, 4)); 
      returnObject.setLastUpdateUser(getString (rs, 5)); 
      returnObject.setLastUpdateTxId(getLongObject (rs, 6)); 
    
      return returnObject;
    }
  }

  /**
   * @Update( sql="insert into XDEALERRETAILER (XDealer_Retailerpk_Id, Dealer_Code, Retailer_Code, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( :xDealerRetailerpkId, :dealerCode, :retailerCode, :lastUpdateDt, :lastUpdateUser, :lastUpdateTxId)" )
   * 
   * @generated
   */
  public int createEObjXDealerRetailer (EObjXDealerRetailer e)
  {
    return update (createEObjXDealerRetailerStatementDescriptor, e);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor createEObjXDealerRetailerStatementDescriptor = createStatementDescriptor (
    "createEObjXDealerRetailer(com.ibm.daimler.dsea.entityObject.EObjXDealerRetailer)",
    "insert into XDEALERRETAILER (XDealer_Retailerpk_Id, Dealer_Code, Retailer_Code, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values(  ? ,  ? ,  ? ,  ? ,  ? ,  ? )",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.INSERT,
    null,
    new CreateEObjXDealerRetailerParameterHandler (),
    new int[][]{{Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 250, 250, 0, 0, 19}, {0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    2);

  /**
   * @generated
   */
  public static class CreateEObjXDealerRetailerParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      EObjXDealerRetailer bean0 = (EObjXDealerRetailer) parameters[0];
      setLong (stmt, 1, Types.BIGINT, (Long)bean0.getXDealerRetailerpkId());
      setString (stmt, 2, Types.VARCHAR, (String)bean0.getDealerCode());
      setString (stmt, 3, Types.VARCHAR, (String)bean0.getRetailerCode());
      setTimestamp (stmt, 4, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUpdateDt());
      setString (stmt, 5, Types.VARCHAR, (String)bean0.getLastUpdateUser());
      setLong (stmt, 6, Types.BIGINT, (Long)bean0.getLastUpdateTxId());
    }
  }

  /**
   * @Update( sql="update XDEALERRETAILER set Dealer_Code = :dealerCode, Retailer_Code = :retailerCode, LAST_UPDATE_DT = :lastUpdateDt, LAST_UPDATE_USER = :lastUpdateUser, LAST_UPDATE_TX_ID = :lastUpdateTxId where XDealer_Retailerpk_Id = :xDealerRetailerpkId and LAST_UPDATE_DT = :oldLastUpdateDt" )
   * 
   * @generated
   */
  public int updateEObjXDealerRetailer (EObjXDealerRetailer e)
  {
    return update (updateEObjXDealerRetailerStatementDescriptor, e);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor updateEObjXDealerRetailerStatementDescriptor = createStatementDescriptor (
    "updateEObjXDealerRetailer(com.ibm.daimler.dsea.entityObject.EObjXDealerRetailer)",
    "update XDEALERRETAILER set Dealer_Code =  ? , Retailer_Code =  ? , LAST_UPDATE_DT =  ? , LAST_UPDATE_USER =  ? , LAST_UPDATE_TX_ID =  ?  where XDealer_Retailerpk_Id =  ?  and LAST_UPDATE_DT =  ? ",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.UPDATE,
    null,
    new UpdateEObjXDealerRetailerParameterHandler (),
    new int[][]{{Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP}, {250, 250, 0, 0, 19, 19, 0}, {0, 0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    3);

  /**
   * @generated
   */
  public static class UpdateEObjXDealerRetailerParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      EObjXDealerRetailer bean0 = (EObjXDealerRetailer) parameters[0];
      setString (stmt, 1, Types.VARCHAR, (String)bean0.getDealerCode());
      setString (stmt, 2, Types.VARCHAR, (String)bean0.getRetailerCode());
      setTimestamp (stmt, 3, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUpdateDt());
      setString (stmt, 4, Types.VARCHAR, (String)bean0.getLastUpdateUser());
      setLong (stmt, 5, Types.BIGINT, (Long)bean0.getLastUpdateTxId());
      setLong (stmt, 6, Types.BIGINT, (Long)bean0.getXDealerRetailerpkId());
      setTimestamp (stmt, 7, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getOldLastUpdateDt());
    }
  }

  /**
   * @Update( sql="delete from XDEALERRETAILER where XDealer_Retailerpk_Id = ?" )
   * 
   * @generated
   */
  public int deleteEObjXDealerRetailer (Long xDealerRetailerpkId)
  {
    return update (deleteEObjXDealerRetailerStatementDescriptor, xDealerRetailerpkId);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor deleteEObjXDealerRetailerStatementDescriptor = createStatementDescriptor (
    "deleteEObjXDealerRetailer(Long)",
    "delete from XDEALERRETAILER where XDealer_Retailerpk_Id = ?",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.DELETE,
    null,
    new DeleteEObjXDealerRetailerParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    4);

  /**
   * @generated
   */
  public static class DeleteEObjXDealerRetailerParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setLong (stmt, 1, Types.BIGINT, (Long)parameters[0]);
    }
  }

}
