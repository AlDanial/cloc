/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[9e5eebe10a7c4f09bfd7c321751d5d0d]
 */

package com.ibm.daimler.dsea.entityObject;


import com.ibm.mdm.base.db.ResultQueue1;
import java.util.Iterator;
import com.ibm.mdm.base.db.EntityMapping;
import com.ibm.pdq.annotation.Select;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * @generated
 */
public interface XCustomerVehicleRoleAusInquiryData {
  
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String tableAliasString = "tableAlias (" + 
                                            "XCUSTOMERVEHICLEROLEAUS => com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRoleAus, " +
                                            "H_XCUSTOMERVEHICLEROLEAUS => com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRoleAus" +
                                            ")";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getXCustomerVehicleRoleAusSql = "SELECT r.XCustomer_Role_Auspk_Id XCustomer_Role_Auspk_Id, r.CUSTOMER_VEHICLE_ID CUSTOMER_VEHICLE_ID, r.VEHICLE_ROLE_TP_CD VEHICLE_ROLE_TP_CD, r.VEHICLE_REL_ST_TP_CD VEHICLE_REL_ST_TP_CD, r.START_DT START_DT, r.END_DT END_DT, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.XCustomer_Vehicle_Aus_Referenc XCustomer_Vehicle_Aus_Referenc, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XCUSTOMERVEHICLEROLEAUS r WHERE r.XCustomer_Role_Auspk_Id = ? ";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXCustomerVehicleRoleAusParameters =
    "EObjXCustomerVehicleRoleAus.XCustomerRoleAuspkId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXCustomerVehicleRoleAusResults =
    "EObjXCustomerVehicleRoleAus.XCustomerRoleAuspkId," +
    "EObjXCustomerVehicleRoleAus.CustomerVehicleId," +
    "EObjXCustomerVehicleRoleAus.VehicleRole," +
    "EObjXCustomerVehicleRoleAus.VehicleRelStatus," +
    "EObjXCustomerVehicleRoleAus.StartDate," +
    "EObjXCustomerVehicleRoleAus.EndDate," +
    "EObjXCustomerVehicleRoleAus.SourceIdentifier," +
    "EObjXCustomerVehicleRoleAus.LastModifiedSystemDate," +
    "EObjXCustomerVehicleRoleAus.XCustomerVehicleAusReference," +
    "EObjXCustomerVehicleRoleAus.lastUpdateDt," +
    "EObjXCustomerVehicleRoleAus.lastUpdateUser," +
    "EObjXCustomerVehicleRoleAus.lastUpdateTxId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getXCustomerVehicleRoleAusHistorySql = "SELECT r.H_XCustomer_Role_Auspk_Id hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.XCustomer_Role_Auspk_Id XCustomer_Role_Auspk_Id, r.CUSTOMER_VEHICLE_ID CUSTOMER_VEHICLE_ID, r.VEHICLE_ROLE_TP_CD VEHICLE_ROLE_TP_CD, r.VEHICLE_REL_ST_TP_CD VEHICLE_REL_ST_TP_CD, r.START_DT START_DT, r.END_DT END_DT, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.XCustomer_Vehicle_Aus_Referenc XCustomer_Vehicle_Aus_Referenc, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XCUSTOMERVEHICLEROLEAUS r WHERE r.H_XCustomer_Role_Auspk_Id = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXCustomerVehicleRoleAusHistoryParameters =
    "EObjXCustomerVehicleRoleAus.XCustomerRoleAuspkId," +
    "EObjXCustomerVehicleRoleAus.lastUpdateDt," +
    "EObjXCustomerVehicleRoleAus.lastUpdateDt";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXCustomerVehicleRoleAusHistoryResults =
    "EObjXCustomerVehicleRoleAus.historyIdPK," +
    "EObjXCustomerVehicleRoleAus.histActionCode," +
    "EObjXCustomerVehicleRoleAus.histCreatedBy," +
    "EObjXCustomerVehicleRoleAus.histCreateDt," +
    "EObjXCustomerVehicleRoleAus.histEndDt," +
    "EObjXCustomerVehicleRoleAus.XCustomerRoleAuspkId," +
    "EObjXCustomerVehicleRoleAus.CustomerVehicleId," +
    "EObjXCustomerVehicleRoleAus.VehicleRole," +
    "EObjXCustomerVehicleRoleAus.VehicleRelStatus," +
    "EObjXCustomerVehicleRoleAus.StartDate," +
    "EObjXCustomerVehicleRoleAus.EndDate," +
    "EObjXCustomerVehicleRoleAus.SourceIdentifier," +
    "EObjXCustomerVehicleRoleAus.LastModifiedSystemDate," +
    "EObjXCustomerVehicleRoleAus.XCustomerVehicleAusReference," +
    "EObjXCustomerVehicleRoleAus.lastUpdateDt," +
    "EObjXCustomerVehicleRoleAus.lastUpdateUser," +
    "EObjXCustomerVehicleRoleAus.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getAllVehicleRoleAusByCustomerVehicleIdSql = "SELECT r.XCustomer_Role_Auspk_Id XCustomer_Role_Auspk_Id, r.CUSTOMER_VEHICLE_ID CUSTOMER_VEHICLE_ID, r.VEHICLE_ROLE_TP_CD VEHICLE_ROLE_TP_CD, r.VEHICLE_REL_ST_TP_CD VEHICLE_REL_ST_TP_CD, r.START_DT START_DT, r.END_DT END_DT, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.XCustomer_Vehicle_Aus_Referenc XCustomer_Vehicle_Aus_Referenc, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XCUSTOMERVEHICLEROLEAUS r WHERE r.CUSTOMER_VEHICLE_ID = ? ";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getAllVehicleRoleAusByCustomerVehicleIdParameters =
    "EObjXCustomerVehicleRoleAus.CustomerVehicleId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getAllVehicleRoleAusByCustomerVehicleIdResults =
    "EObjXCustomerVehicleRoleAus.XCustomerRoleAuspkId," +
    "EObjXCustomerVehicleRoleAus.CustomerVehicleId," +
    "EObjXCustomerVehicleRoleAus.VehicleRole," +
    "EObjXCustomerVehicleRoleAus.VehicleRelStatus," +
    "EObjXCustomerVehicleRoleAus.StartDate," +
    "EObjXCustomerVehicleRoleAus.EndDate," +
    "EObjXCustomerVehicleRoleAus.SourceIdentifier," +
    "EObjXCustomerVehicleRoleAus.LastModifiedSystemDate," +
    "EObjXCustomerVehicleRoleAus.XCustomerVehicleAusReference," +
    "EObjXCustomerVehicleRoleAus.lastUpdateDt," +
    "EObjXCustomerVehicleRoleAus.lastUpdateUser," +
    "EObjXCustomerVehicleRoleAus.lastUpdateTxId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getAllVehicleRoleAusByCustomerVehicleIdHistorySql = "SELECT r.H_XCustomer_Role_Auspk_Id hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.XCustomer_Role_Auspk_Id XCustomer_Role_Auspk_Id, r.CUSTOMER_VEHICLE_ID CUSTOMER_VEHICLE_ID, r.VEHICLE_ROLE_TP_CD VEHICLE_ROLE_TP_CD, r.VEHICLE_REL_ST_TP_CD VEHICLE_REL_ST_TP_CD, r.START_DT START_DT, r.END_DT END_DT, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.XCustomer_Vehicle_Aus_Referenc XCustomer_Vehicle_Aus_Referenc, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XCUSTOMERVEHICLEROLEAUS r WHERE r.CUSTOMER_VEHICLE_ID = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getAllVehicleRoleAusByCustomerVehicleIdHistoryParameters =
    "EObjXCustomerVehicleRoleAus.CustomerVehicleId," +
    "EObjXCustomerVehicleRoleAus.lastUpdateDt," +
    "EObjXCustomerVehicleRoleAus.lastUpdateDt";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getAllVehicleRoleAusByCustomerVehicleIdHistoryResults =
    "EObjXCustomerVehicleRoleAus.historyIdPK," +
    "EObjXCustomerVehicleRoleAus.histActionCode," +
    "EObjXCustomerVehicleRoleAus.histCreatedBy," +
    "EObjXCustomerVehicleRoleAus.histCreateDt," +
    "EObjXCustomerVehicleRoleAus.histEndDt," +
    "EObjXCustomerVehicleRoleAus.XCustomerRoleAuspkId," +
    "EObjXCustomerVehicleRoleAus.CustomerVehicleId," +
    "EObjXCustomerVehicleRoleAus.VehicleRole," +
    "EObjXCustomerVehicleRoleAus.VehicleRelStatus," +
    "EObjXCustomerVehicleRoleAus.StartDate," +
    "EObjXCustomerVehicleRoleAus.EndDate," +
    "EObjXCustomerVehicleRoleAus.SourceIdentifier," +
    "EObjXCustomerVehicleRoleAus.LastModifiedSystemDate," +
    "EObjXCustomerVehicleRoleAus.XCustomerVehicleAusReference," +
    "EObjXCustomerVehicleRoleAus.lastUpdateDt," +
    "EObjXCustomerVehicleRoleAus.lastUpdateUser," +
    "EObjXCustomerVehicleRoleAus.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getAllXCustomerVehicleRoleAusByXCustomerVehicleAusSql = "SELECT r.XCustomer_Role_Auspk_Id XCustomer_Role_Auspk_Id, r.CUSTOMER_VEHICLE_ID CUSTOMER_VEHICLE_ID, r.VEHICLE_ROLE_TP_CD VEHICLE_ROLE_TP_CD, r.VEHICLE_REL_ST_TP_CD VEHICLE_REL_ST_TP_CD, r.START_DT START_DT, r.END_DT END_DT, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.XCustomer_Vehicle_Aus_Referenc XCustomer_Vehicle_Aus_Referenc, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XCUSTOMERVEHICLEROLEAUS r WHERE r.XCustomer_Vehicle_Aus_Referenc = ? ";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getAllXCustomerVehicleRoleAusByXCustomerVehicleAusParameters =
    "EObjXCustomerVehicleRoleAus.XCustomerVehicleAusReference";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getAllXCustomerVehicleRoleAusByXCustomerVehicleAusResults =
    "EObjXCustomerVehicleRoleAus.XCustomerRoleAuspkId," +
    "EObjXCustomerVehicleRoleAus.CustomerVehicleId," +
    "EObjXCustomerVehicleRoleAus.VehicleRole," +
    "EObjXCustomerVehicleRoleAus.VehicleRelStatus," +
    "EObjXCustomerVehicleRoleAus.StartDate," +
    "EObjXCustomerVehicleRoleAus.EndDate," +
    "EObjXCustomerVehicleRoleAus.SourceIdentifier," +
    "EObjXCustomerVehicleRoleAus.LastModifiedSystemDate," +
    "EObjXCustomerVehicleRoleAus.XCustomerVehicleAusReference," +
    "EObjXCustomerVehicleRoleAus.lastUpdateDt," +
    "EObjXCustomerVehicleRoleAus.lastUpdateUser," +
    "EObjXCustomerVehicleRoleAus.lastUpdateTxId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getAllXCustomerVehicleRoleAusByXCustomerVehicleAusHistorySql = "SELECT r.H_XCustomer_Role_Auspk_Id hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.XCustomer_Role_Auspk_Id XCustomer_Role_Auspk_Id, r.CUSTOMER_VEHICLE_ID CUSTOMER_VEHICLE_ID, r.VEHICLE_ROLE_TP_CD VEHICLE_ROLE_TP_CD, r.VEHICLE_REL_ST_TP_CD VEHICLE_REL_ST_TP_CD, r.START_DT START_DT, r.END_DT END_DT, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.XCustomer_Vehicle_Aus_Referenc XCustomer_Vehicle_Aus_Referenc, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XCUSTOMERVEHICLEROLEAUS r WHERE r.XCustomer_Vehicle_Aus_Referenc = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getAllXCustomerVehicleRoleAusByXCustomerVehicleAusHistoryParameters =
    "EObjXCustomerVehicleRoleAus.XCustomerVehicleAusReference," +
    "EObjXCustomerVehicleRoleAus.lastUpdateDt," +
    "EObjXCustomerVehicleRoleAus.lastUpdateDt";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getAllXCustomerVehicleRoleAusByXCustomerVehicleAusHistoryResults =
    "EObjXCustomerVehicleRoleAus.historyIdPK," +
    "EObjXCustomerVehicleRoleAus.histActionCode," +
    "EObjXCustomerVehicleRoleAus.histCreatedBy," +
    "EObjXCustomerVehicleRoleAus.histCreateDt," +
    "EObjXCustomerVehicleRoleAus.histEndDt," +
    "EObjXCustomerVehicleRoleAus.XCustomerRoleAuspkId," +
    "EObjXCustomerVehicleRoleAus.CustomerVehicleId," +
    "EObjXCustomerVehicleRoleAus.VehicleRole," +
    "EObjXCustomerVehicleRoleAus.VehicleRelStatus," +
    "EObjXCustomerVehicleRoleAus.StartDate," +
    "EObjXCustomerVehicleRoleAus.EndDate," +
    "EObjXCustomerVehicleRoleAus.SourceIdentifier," +
    "EObjXCustomerVehicleRoleAus.LastModifiedSystemDate," +
    "EObjXCustomerVehicleRoleAus.XCustomerVehicleAusReference," +
    "EObjXCustomerVehicleRoleAus.lastUpdateDt," +
    "EObjXCustomerVehicleRoleAus.lastUpdateUser," +
    "EObjXCustomerVehicleRoleAus.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getXCustomerVehicleRoleAusSql, pattern=tableAliasString)
  @EntityMapping(parameters=getXCustomerVehicleRoleAusParameters, results=getXCustomerVehicleRoleAusResults)
  Iterator<ResultQueue1<EObjXCustomerVehicleRoleAus>> getXCustomerVehicleRoleAus(Object[] parameters);  


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getXCustomerVehicleRoleAusHistorySql, pattern=tableAliasString)
  @EntityMapping(parameters=getXCustomerVehicleRoleAusHistoryParameters, results=getXCustomerVehicleRoleAusHistoryResults)
  Iterator<ResultQueue1<EObjXCustomerVehicleRoleAus>> getXCustomerVehicleRoleAusHistory(Object[] parameters);


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getAllVehicleRoleAusByCustomerVehicleIdSql, pattern=tableAliasString)
  @EntityMapping(parameters=getAllVehicleRoleAusByCustomerVehicleIdParameters, results=getAllVehicleRoleAusByCustomerVehicleIdResults)
  Iterator<ResultQueue1<EObjXCustomerVehicleRoleAus>> getAllVehicleRoleAusByCustomerVehicleId(Object[] parameters);


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getAllVehicleRoleAusByCustomerVehicleIdHistorySql, pattern=tableAliasString)
  @EntityMapping(parameters=getAllVehicleRoleAusByCustomerVehicleIdHistoryParameters, results=getAllVehicleRoleAusByCustomerVehicleIdHistoryResults)
  Iterator<ResultQueue1<EObjXCustomerVehicleRoleAus>> getAllVehicleRoleAusByCustomerVehicleIdHistory(Object[] parameters);


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getAllXCustomerVehicleRoleAusByXCustomerVehicleAusSql, pattern=tableAliasString)
  @EntityMapping(parameters=getAllXCustomerVehicleRoleAusByXCustomerVehicleAusParameters, results=getAllXCustomerVehicleRoleAusByXCustomerVehicleAusResults)
  Iterator<ResultQueue1<EObjXCustomerVehicleRoleAus>> getAllXCustomerVehicleRoleAusByXCustomerVehicleAus(Object[] parameters);


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getAllXCustomerVehicleRoleAusByXCustomerVehicleAusHistorySql, pattern=tableAliasString)
  @EntityMapping(parameters=getAllXCustomerVehicleRoleAusByXCustomerVehicleAusHistoryParameters, results=getAllXCustomerVehicleRoleAusByXCustomerVehicleAusHistoryResults)
  Iterator<ResultQueue1<EObjXCustomerVehicleRoleAus>> getAllXCustomerVehicleRoleAusByXCustomerVehicleAusHistory(Object[] parameters);  


}


