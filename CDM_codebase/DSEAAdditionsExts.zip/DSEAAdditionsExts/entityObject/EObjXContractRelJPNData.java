/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[b0a9dba970e86591b6d5f219bbb7347b]
 */


package com.ibm.daimler.dsea.entityObject;

import java.util.Iterator;
import com.ibm.mdm.base.db.EntityMapping;
import com.ibm.pdq.annotation.Select;
import com.ibm.pdq.annotation.Update;

import com.ibm.daimler.dsea.entityObject.EObjXContractRelJPN;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * @generated
 */
public interface EObjXContractRelJPNData {


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjXContractRelJPNSql = "select XCONTRACT_RELJPNPK_ID, CONTRACT_ID, CONT_ID, MARKET_NAME, PERSON_ORG_CODE, CONTRACT_ROLE, START_DT, END_DT, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from XCONTRACTRELJPN where XCONTRACT_RELJPNPK_ID = ? ";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String createEObjXContractRelJPNSql = "insert into XCONTRACTRELJPN (XCONTRACT_RELJPNPK_ID, CONTRACT_ID, CONT_ID, MARKET_NAME, PERSON_ORG_CODE, CONTRACT_ROLE, START_DT, END_DT, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( :xContractRelJPNpkId, :contractId, :contId, :marketName, :personOrgCode, :contractRole, :startDate, :endDate, :lastUpdateDt, :lastUpdateUser, :lastUpdateTxId)";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String updateEObjXContractRelJPNSql = "update XCONTRACTRELJPN set CONTRACT_ID = :contractId, CONT_ID = :contId, MARKET_NAME = :marketName, PERSON_ORG_CODE = :personOrgCode, CONTRACT_ROLE = :contractRole, START_DT = :startDate, END_DT = :endDate, LAST_UPDATE_DT = :lastUpdateDt, LAST_UPDATE_USER = :lastUpdateUser, LAST_UPDATE_TX_ID = :lastUpdateTxId where XCONTRACT_RELJPNPK_ID = :xContractRelJPNpkId and LAST_UPDATE_DT = :oldLastUpdateDt";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String deleteEObjXContractRelJPNSql = "delete from XCONTRACTRELJPN where XCONTRACT_RELJPNPK_ID = ?";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXContractRelJPNKeyField = "EObjXContractRelJPN.xContractRelJPNpkId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXContractRelJPNGetFields =
    "EObjXContractRelJPN.xContractRelJPNpkId," +
    "EObjXContractRelJPN.contractId," +
    "EObjXContractRelJPN.contId," +
    "EObjXContractRelJPN.marketName," +
    "EObjXContractRelJPN.personOrgCode," +
    "EObjXContractRelJPN.contractRole," +
    "EObjXContractRelJPN.startDate," +
    "EObjXContractRelJPN.endDate," +
    "EObjXContractRelJPN.lastUpdateDt," +
    "EObjXContractRelJPN.lastUpdateUser," +
    "EObjXContractRelJPN.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXContractRelJPNAllFields =
    "com.ibm.daimler.dsea.entityObject.EObjXContractRelJPN.xContractRelJPNpkId," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractRelJPN.contractId," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractRelJPN.contId," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractRelJPN.marketName," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractRelJPN.personOrgCode," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractRelJPN.contractRole," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractRelJPN.startDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractRelJPN.endDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractRelJPN.lastUpdateDt," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractRelJPN.lastUpdateUser," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractRelJPN.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXContractRelJPNUpdateFields =
    "com.ibm.daimler.dsea.entityObject.EObjXContractRelJPN.contractId," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractRelJPN.contId," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractRelJPN.marketName," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractRelJPN.personOrgCode," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractRelJPN.contractRole," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractRelJPN.startDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractRelJPN.endDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractRelJPN.lastUpdateDt," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractRelJPN.lastUpdateUser," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractRelJPN.lastUpdateTxId," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractRelJPN.xContractRelJPNpkId," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractRelJPN.oldLastUpdateDt";   

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Select XContractRelJPN by parameters.
   * @generated
   */
  @Select(sql=getEObjXContractRelJPNSql)
  @EntityMapping(parameters=EObjXContractRelJPNKeyField, results=EObjXContractRelJPNGetFields)
  Iterator<EObjXContractRelJPN> getEObjXContractRelJPN(Long xContractRelJPNpkId);  
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Create XContractRelJPN by EObjXContractRelJPN Object.
   * @generated
   */
  @Update(sql=createEObjXContractRelJPNSql)
  @EntityMapping(parameters=EObjXContractRelJPNAllFields)
    int createEObjXContractRelJPN(EObjXContractRelJPN e); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Update one XContractRelJPN by EObjXContractRelJPN object.
   * @generated
   */
  @Update(sql=updateEObjXContractRelJPNSql)
  @EntityMapping(parameters=EObjXContractRelJPNUpdateFields)
    int updateEObjXContractRelJPN(EObjXContractRelJPN e); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Delete XContractRelJPN by parameters.
   * @generated
   */
  @Update(sql=deleteEObjXContractRelJPNSql)
  @EntityMapping(parameters=EObjXContractRelJPNKeyField)
  int deleteEObjXContractRelJPN(Long xContractRelJPNpkId);

}

