/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[febe2d0ecf06dcf012a864c231a7c6f8]
 */


package com.ibm.daimler.dsea.entityObject;

import java.util.Iterator;
import com.ibm.mdm.base.db.EntityMapping;
import com.ibm.pdq.annotation.Select;
import com.ibm.pdq.annotation.Update;

import com.ibm.daimler.dsea.entityObject.EObjXConsent;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * @generated
 */
public interface EObjXConsentData {


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjXConsentSql = "select XConsentpk_Id, CONT_ID, COMM_CHANNNEL, CONSENT_ACTION_TP_CD, SOURCE_IDENT_TP_CD, RETAILER_ID, Retailer_Flag, LAST_MODIFIED_SYSTEM_DT, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from XCONSENT where XConsentpk_Id = ? ";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String createEObjXConsentSql = "insert into XCONSENT (XConsentpk_Id, CONT_ID, COMM_CHANNNEL, CONSENT_ACTION_TP_CD, SOURCE_IDENT_TP_CD, RETAILER_ID, Retailer_Flag, LAST_MODIFIED_SYSTEM_DT, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( :xConsentpkId, :contId, :communicationChannel, :consentAction, :sourceIdentifier, :retailerId, :retailerFlag, :lastModifiedSystemDate, :lastUpdateDt, :lastUpdateUser, :lastUpdateTxId)";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String updateEObjXConsentSql = "update XCONSENT set CONT_ID = :contId, COMM_CHANNNEL = :communicationChannel, CONSENT_ACTION_TP_CD = :consentAction, SOURCE_IDENT_TP_CD = :sourceIdentifier, RETAILER_ID = :retailerId, Retailer_Flag = :retailerFlag, LAST_MODIFIED_SYSTEM_DT = :lastModifiedSystemDate, LAST_UPDATE_DT = :lastUpdateDt, LAST_UPDATE_USER = :lastUpdateUser, LAST_UPDATE_TX_ID = :lastUpdateTxId where XConsentpk_Id = :xConsentpkId and LAST_UPDATE_DT = :oldLastUpdateDt";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String deleteEObjXConsentSql = "delete from XCONSENT where XConsentpk_Id = ?";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXConsentKeyField = "EObjXConsent.xConsentpkId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXConsentGetFields =
    "EObjXConsent.xConsentpkId," +
    "EObjXConsent.contId," +
    "EObjXConsent.communicationChannel," +
    "EObjXConsent.consentAction," +
    "EObjXConsent.sourceIdentifier," +
    "EObjXConsent.retailerId," +
    "EObjXConsent.retailerFlag," +
    "EObjXConsent.lastModifiedSystemDate," +
    "EObjXConsent.lastUpdateDt," +
    "EObjXConsent.lastUpdateUser," +
    "EObjXConsent.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXConsentAllFields =
    "com.ibm.daimler.dsea.entityObject.EObjXConsent.xConsentpkId," +
    "com.ibm.daimler.dsea.entityObject.EObjXConsent.contId," +
    "com.ibm.daimler.dsea.entityObject.EObjXConsent.communicationChannel," +
    "com.ibm.daimler.dsea.entityObject.EObjXConsent.consentAction," +
    "com.ibm.daimler.dsea.entityObject.EObjXConsent.sourceIdentifier," +
    "com.ibm.daimler.dsea.entityObject.EObjXConsent.retailerId," +
    "com.ibm.daimler.dsea.entityObject.EObjXConsent.retailerFlag," +
    "com.ibm.daimler.dsea.entityObject.EObjXConsent.lastModifiedSystemDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXConsent.lastUpdateDt," +
    "com.ibm.daimler.dsea.entityObject.EObjXConsent.lastUpdateUser," +
    "com.ibm.daimler.dsea.entityObject.EObjXConsent.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXConsentUpdateFields =
    "com.ibm.daimler.dsea.entityObject.EObjXConsent.contId," +
    "com.ibm.daimler.dsea.entityObject.EObjXConsent.communicationChannel," +
    "com.ibm.daimler.dsea.entityObject.EObjXConsent.consentAction," +
    "com.ibm.daimler.dsea.entityObject.EObjXConsent.sourceIdentifier," +
    "com.ibm.daimler.dsea.entityObject.EObjXConsent.retailerId," +
    "com.ibm.daimler.dsea.entityObject.EObjXConsent.retailerFlag," +
    "com.ibm.daimler.dsea.entityObject.EObjXConsent.lastModifiedSystemDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXConsent.lastUpdateDt," +
    "com.ibm.daimler.dsea.entityObject.EObjXConsent.lastUpdateUser," +
    "com.ibm.daimler.dsea.entityObject.EObjXConsent.lastUpdateTxId," +
    "com.ibm.daimler.dsea.entityObject.EObjXConsent.xConsentpkId," +
    "com.ibm.daimler.dsea.entityObject.EObjXConsent.oldLastUpdateDt";   

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Select XConsent by parameters.
   * @generated
   */
  @Select(sql=getEObjXConsentSql)
  @EntityMapping(parameters=EObjXConsentKeyField, results=EObjXConsentGetFields)
  Iterator<EObjXConsent> getEObjXConsent(Long xConsentpkId);  
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Create XConsent by EObjXConsent Object.
   * @generated
   */
  @Update(sql=createEObjXConsentSql)
  @EntityMapping(parameters=EObjXConsentAllFields)
    int createEObjXConsent(EObjXConsent e); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Update one XConsent by EObjXConsent object.
   * @generated
   */
  @Update(sql=updateEObjXConsentSql)
  @EntityMapping(parameters=EObjXConsentUpdateFields)
    int updateEObjXConsent(EObjXConsent e); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Delete XConsent by parameters.
   * @generated
   */
  @Update(sql=deleteEObjXConsentSql)
  @EntityMapping(parameters=EObjXConsentKeyField)
  int deleteEObjXConsent(Long xConsentpkId);

}

