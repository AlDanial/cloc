/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[07c821ad122572a4d3d0b5aca0077804]
 */

package com.ibm.daimler.dsea.entityObject;


import com.ibm.mdm.base.db.ResultQueue1;
import java.util.Iterator;
import com.ibm.mdm.base.db.EntityMapping;
import com.ibm.pdq.annotation.Select;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * @generated
 */
public interface XCustomerVehicleInquiryData {
  
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String tableAliasString = "tableAlias (" + 
                                            "XCUSTOMERVEHICLE => com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicle, " +
                                            "H_XCUSTOMERVEHICLE => com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicle" +
                                            ")";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getXCustomerVehicleSql = "SELECT r.CUSTOMERVEHICLEPK_ID CUSTOMERVEHICLEPK_ID, r.CONT_ID CONT_ID, r.VEHICLE_ID VEHICLE_ID, r.RETAILER_ID RETAILER_ID, r.CONNECTME_USAGE_TP_CD CONNECTME_USAGE_TP_CD, r.LICENSE_PLATE LICENSE_PLATE, r.VEHICLE_SALES_TP_CD VEHICLE_SALES_TP_CD, r.VEHICLE_USAGE_TP_CD VEHICLE_USAGE_TP_CD, r.VEHICLE_OWNERSHIP VEHICLE_OWNERSHIP, r.START_DT START_DT, r.END_DT END_DT, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.X_BPID X_BPID, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XCUSTOMERVEHICLE r WHERE r.CUSTOMERVEHICLEPK_ID = ? ";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXCustomerVehicleParameters =
    "EObjXCustomerVehicle.CustomerVehiclepkId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXCustomerVehicleResults =
    "EObjXCustomerVehicle.CustomerVehiclepkId," +
    "EObjXCustomerVehicle.ContId," +
    "EObjXCustomerVehicle.VehicleId," +
    "EObjXCustomerVehicle.RetailerId," +
    "EObjXCustomerVehicle.ConnectMeUsage," +
    "EObjXCustomerVehicle.LicensePlate," +
    "EObjXCustomerVehicle.VehicleSales," +
    "EObjXCustomerVehicle.VehicleUsage," +
    "EObjXCustomerVehicle.VehicleOwnerShip," +
    "EObjXCustomerVehicle.StartDate," +
    "EObjXCustomerVehicle.EndDate," +
    "EObjXCustomerVehicle.SourceIdentifier," +
    "EObjXCustomerVehicle.X_BPID," +
    "EObjXCustomerVehicle.lastUpdateDt," +
    "EObjXCustomerVehicle.lastUpdateUser," +
    "EObjXCustomerVehicle.lastUpdateTxId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getXCustomerVehicleHistorySql = "SELECT r.H_CUSTOMERVEHICLEPK_ID hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.CUSTOMERVEHICLEPK_ID CUSTOMERVEHICLEPK_ID, r.CONT_ID CONT_ID, r.VEHICLE_ID VEHICLE_ID, r.RETAILER_ID RETAILER_ID, r.CONNECTME_USAGE_TP_CD CONNECTME_USAGE_TP_CD, r.LICENSE_PLATE LICENSE_PLATE, r.VEHICLE_SALES_TP_CD VEHICLE_SALES_TP_CD, r.VEHICLE_USAGE_TP_CD VEHICLE_USAGE_TP_CD, r.VEHICLE_OWNERSHIP VEHICLE_OWNERSHIP, r.START_DT START_DT, r.END_DT END_DT, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.X_BPID X_BPID, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XCUSTOMERVEHICLE r WHERE r.H_CUSTOMERVEHICLEPK_ID = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXCustomerVehicleHistoryParameters =
    "EObjXCustomerVehicle.CustomerVehiclepkId," +
    "EObjXCustomerVehicle.lastUpdateDt," +
    "EObjXCustomerVehicle.lastUpdateDt";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXCustomerVehicleHistoryResults =
    "EObjXCustomerVehicle.historyIdPK," +
    "EObjXCustomerVehicle.histActionCode," +
    "EObjXCustomerVehicle.histCreatedBy," +
    "EObjXCustomerVehicle.histCreateDt," +
    "EObjXCustomerVehicle.histEndDt," +
    "EObjXCustomerVehicle.CustomerVehiclepkId," +
    "EObjXCustomerVehicle.ContId," +
    "EObjXCustomerVehicle.VehicleId," +
    "EObjXCustomerVehicle.RetailerId," +
    "EObjXCustomerVehicle.ConnectMeUsage," +
    "EObjXCustomerVehicle.LicensePlate," +
    "EObjXCustomerVehicle.VehicleSales," +
    "EObjXCustomerVehicle.VehicleUsage," +
    "EObjXCustomerVehicle.VehicleOwnerShip," +
    "EObjXCustomerVehicle.StartDate," +
    "EObjXCustomerVehicle.EndDate," +
    "EObjXCustomerVehicle.SourceIdentifier," +
    "EObjXCustomerVehicle.X_BPID," +
    "EObjXCustomerVehicle.lastUpdateDt," +
    "EObjXCustomerVehicle.lastUpdateUser," +
    "EObjXCustomerVehicle.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getAllXCustomerVehicleByPartyIdSql = "SELECT r.CUSTOMERVEHICLEPK_ID CUSTOMERVEHICLEPK_ID, r.CONT_ID CONT_ID, r.VEHICLE_ID VEHICLE_ID, r.RETAILER_ID RETAILER_ID, r.CONNECTME_USAGE_TP_CD CONNECTME_USAGE_TP_CD, r.LICENSE_PLATE LICENSE_PLATE, r.VEHICLE_SALES_TP_CD VEHICLE_SALES_TP_CD, r.VEHICLE_USAGE_TP_CD VEHICLE_USAGE_TP_CD, r.VEHICLE_OWNERSHIP VEHICLE_OWNERSHIP, r.START_DT START_DT, r.END_DT END_DT, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.X_BPID X_BPID, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XCUSTOMERVEHICLE r WHERE r.CONT_ID = ? ";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getAllXCustomerVehicleByPartyIdParameters =
    "EObjXCustomerVehicle.ContId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getAllXCustomerVehicleByPartyIdResults =
    "EObjXCustomerVehicle.CustomerVehiclepkId," +
    "EObjXCustomerVehicle.ContId," +
    "EObjXCustomerVehicle.VehicleId," +
    "EObjXCustomerVehicle.RetailerId," +
    "EObjXCustomerVehicle.ConnectMeUsage," +
    "EObjXCustomerVehicle.LicensePlate," +
    "EObjXCustomerVehicle.VehicleSales," +
    "EObjXCustomerVehicle.VehicleUsage," +
    "EObjXCustomerVehicle.VehicleOwnerShip," +
    "EObjXCustomerVehicle.StartDate," +
    "EObjXCustomerVehicle.EndDate," +
    "EObjXCustomerVehicle.SourceIdentifier," +
    "EObjXCustomerVehicle.X_BPID," +
    "EObjXCustomerVehicle.lastUpdateDt," +
    "EObjXCustomerVehicle.lastUpdateUser," +
    "EObjXCustomerVehicle.lastUpdateTxId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getAllXCustomerVehicleByPartyIdHistorySql = "SELECT r.H_CUSTOMERVEHICLEPK_ID hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.CUSTOMERVEHICLEPK_ID CUSTOMERVEHICLEPK_ID, r.CONT_ID CONT_ID, r.VEHICLE_ID VEHICLE_ID, r.RETAILER_ID RETAILER_ID, r.CONNECTME_USAGE_TP_CD CONNECTME_USAGE_TP_CD, r.LICENSE_PLATE LICENSE_PLATE, r.VEHICLE_SALES_TP_CD VEHICLE_SALES_TP_CD, r.VEHICLE_USAGE_TP_CD VEHICLE_USAGE_TP_CD, r.VEHICLE_OWNERSHIP VEHICLE_OWNERSHIP, r.START_DT START_DT, r.END_DT END_DT, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.X_BPID X_BPID, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XCUSTOMERVEHICLE r WHERE r.CONT_ID = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getAllXCustomerVehicleByPartyIdHistoryParameters =
    "EObjXCustomerVehicle.ContId," +
    "EObjXCustomerVehicle.lastUpdateDt," +
    "EObjXCustomerVehicle.lastUpdateDt";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getAllXCustomerVehicleByPartyIdHistoryResults =
    "EObjXCustomerVehicle.historyIdPK," +
    "EObjXCustomerVehicle.histActionCode," +
    "EObjXCustomerVehicle.histCreatedBy," +
    "EObjXCustomerVehicle.histCreateDt," +
    "EObjXCustomerVehicle.histEndDt," +
    "EObjXCustomerVehicle.CustomerVehiclepkId," +
    "EObjXCustomerVehicle.ContId," +
    "EObjXCustomerVehicle.VehicleId," +
    "EObjXCustomerVehicle.RetailerId," +
    "EObjXCustomerVehicle.ConnectMeUsage," +
    "EObjXCustomerVehicle.LicensePlate," +
    "EObjXCustomerVehicle.VehicleSales," +
    "EObjXCustomerVehicle.VehicleUsage," +
    "EObjXCustomerVehicle.VehicleOwnerShip," +
    "EObjXCustomerVehicle.StartDate," +
    "EObjXCustomerVehicle.EndDate," +
    "EObjXCustomerVehicle.SourceIdentifier," +
    "EObjXCustomerVehicle.X_BPID," +
    "EObjXCustomerVehicle.lastUpdateDt," +
    "EObjXCustomerVehicle.lastUpdateUser," +
    "EObjXCustomerVehicle.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getXCustomerVehicleSql, pattern=tableAliasString)
  @EntityMapping(parameters=getXCustomerVehicleParameters, results=getXCustomerVehicleResults)
  Iterator<ResultQueue1<EObjXCustomerVehicle>> getXCustomerVehicle(Object[] parameters);  


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getXCustomerVehicleHistorySql, pattern=tableAliasString)
  @EntityMapping(parameters=getXCustomerVehicleHistoryParameters, results=getXCustomerVehicleHistoryResults)
  Iterator<ResultQueue1<EObjXCustomerVehicle>> getXCustomerVehicleHistory(Object[] parameters);


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getAllXCustomerVehicleByPartyIdSql, pattern=tableAliasString)
  @EntityMapping(parameters=getAllXCustomerVehicleByPartyIdParameters, results=getAllXCustomerVehicleByPartyIdResults)
  Iterator<ResultQueue1<EObjXCustomerVehicle>> getAllXCustomerVehicleByPartyId(Object[] parameters);


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getAllXCustomerVehicleByPartyIdHistorySql, pattern=tableAliasString)
  @EntityMapping(parameters=getAllXCustomerVehicleByPartyIdHistoryParameters, results=getAllXCustomerVehicleByPartyIdHistoryResults)
  Iterator<ResultQueue1<EObjXCustomerVehicle>> getAllXCustomerVehicleByPartyIdHistory(Object[] parameters);  


}


