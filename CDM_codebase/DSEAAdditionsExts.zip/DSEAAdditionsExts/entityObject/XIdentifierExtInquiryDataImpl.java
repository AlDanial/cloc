package com.ibm.daimler.dsea.entityObject;

import com.ibm.pdq.runtime.generator.BaseParameterHandler;
import java.util.Iterator;
import java.sql.PreparedStatement;
import com.ibm.pdq.runtime.statement.StatementDescriptor;
import com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt;
import com.ibm.pdq.runtime.generator.BaseData;
import java.sql.SQLException;
import com.ibm.pdq.annotation.Metadata;
import com.dwl.tcrm.coreParty.entityObject.EObjIdentifier;
import com.ibm.mdm.base.db.ResultQueue2;
import com.ibm.pdq.runtime.generator.BaseRowHandler;
import com.ibm.pdq.runtime.statement.SqlStatementType;
import java.sql.Types;


@SuppressWarnings("unchecked")

/**
 * <!-- begin-user-doc -->
 * 
 * <!-- end-user-doc -->
 * 
 * @generated
 */
public class XIdentifierExtInquiryDataImpl  extends BaseData implements XIdentifierExtInquiryData
{

  /**
   * @generated
   */
  public static final String generatorVersion = "3.200.75";

  /**
   * @generated
   */
  public static final String identifier = "XIdentifierExtInquiryData";

  /**
   * @generated
   */
  public static final long generationTime = 0x0000016069b1da96L;

  /**
   * @generated
   */
  public static final String collection = "NULLID";

  /**
   * @generated
   */
  public static final String packageVersion = null;

  /**
   * @generated
   */
  public static final boolean forceSingleBindIsolation = false;

  /**
   * @generated
   */
  public XIdentifierExtInquiryDataImpl()
  {
    super();
  } 

  /**
   * @generated
   */
  public String getGeneratorVersion()
  {
    return generatorVersion;
  }

  /**
   * @Select( sql="SELECT A.H_IDENTIFIER_ID AS HIST_ID_PK, A.H_ACTION_CODE , A.H_CREATED_BY , A.H_CREATE_DT , A.H_END_DT , A.IDENTIFIER_ID , A.ID_STATUS_TP_CD , A.CONT_ID, A.ID_TP_CD , A.REF_NUM , A.START_DT , A.END_DT , A.EXPIRY_DT , A.LAST_UPDATE_DT , A.LAST_UPDATE_USER , A.LAST_UPDATE_TX_ID , A.ASSIGNED_BY , A.IDENTIFIER_DESC , A.ISSUE_LOCATION , A.LAST_USED_DT , A.LAST_VERIFIED_DT , A.SOURCE_IDENT_TP_CD, A.XMODIFY_SYS_DT, A.XRETAILER_ID, A.XIDEN_RETAILER_FLAG, A.X_BPID FROM H_IDENTIFIER A WHERE A.CONT_ID = ? AND A.ID_TP_CD = ? AND (? BETWEEN A.H_CREATE_DT AND A.H_END_DT OR (? >= A.H_CREATE_DT AND A.H_END_DT IS NULL))", pattern="tableAlias (IDENTIFIER => com.dwl.tcrm.coreParty.entityObject.EObjIdentifier, H_IDENTIFIER => com.dwl.tcrm.coreParty.entityObject.EObjIdentifier , IDENTIFIER => com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt , H_IDENTIFIER => com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue2<EObjIdentifier,EObjXIdentifierExt>> getPartyIdentifiersHistoryByType (Object[] parameters)
  {
    return queryIterator (getPartyIdentifiersHistoryByTypeStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getPartyIdentifiersHistoryByTypeStatementDescriptor = createStatementDescriptor (
    "getPartyIdentifiersHistoryByType(Object[])",
    "SELECT A.H_IDENTIFIER_ID AS HIST_ID_PK, A.H_ACTION_CODE , A.H_CREATED_BY , A.H_CREATE_DT , A.H_END_DT , A.IDENTIFIER_ID , A.ID_STATUS_TP_CD , A.CONT_ID, A.ID_TP_CD , A.REF_NUM , A.START_DT , A.END_DT , A.EXPIRY_DT , A.LAST_UPDATE_DT , A.LAST_UPDATE_USER , A.LAST_UPDATE_TX_ID , A.ASSIGNED_BY , A.IDENTIFIER_DESC , A.ISSUE_LOCATION , A.LAST_USED_DT , A.LAST_VERIFIED_DT , A.SOURCE_IDENT_TP_CD, A.XMODIFY_SYS_DT, A.XRETAILER_ID, A.XIDEN_RETAILER_FLAG, A.X_BPID FROM H_IDENTIFIER A WHERE A.CONT_ID = ? AND A.ID_TP_CD = ? AND (? BETWEEN A.H_CREATE_DT AND A.H_END_DT OR (? >= A.H_CREATE_DT AND A.H_END_DT IS NULL))",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"hist_id_pk", "h_action_code", "h_created_by", "h_create_dt", "h_end_dt", "identifier_id", "id_status_tp_cd", "cont_id", "id_tp_cd", "ref_num", "start_dt", "end_dt", "expiry_dt", "last_update_dt", "last_update_user", "last_update_tx_id", "assigned_by", "identifier_desc", "issue_location", "last_used_dt", "last_verified_dt", "source_ident_tp_cd", "xmodify_sys_dt", "xretailer_id", "xiden_retailer_flag", "x_bpid"},
    new GetPartyIdentifiersHistoryByTypeParameterHandler (),
    new int[][]{{Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP}, {19, 19, 0, 0}, {0, 0, 0, 0}, {1, 1, 1, 1}},
    null,
    new GetPartyIdentifiersHistoryByTypeRowHandler (),
    new int[][]{ {Types.BIGINT, Types.CHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.TIMESTAMP, Types.BIGINT, Types.VARCHAR, Types.VARCHAR}, {19, 1, 20, 0, 0, 19, 19, 19, 19, 50, 0, 0, 0, 0, 20, 19, 19, 255, 30, 0, 0, 19, 0, 19, 5, 50}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    1);

  /**
   * @generated
   */
  public static class GetPartyIdentifiersHistoryByTypeParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.BIGINT, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
      setObject (stmt, 4, Types.TIMESTAMP, parameters[3], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetPartyIdentifiersHistoryByTypeRowHandler extends BaseRowHandler<ResultQueue2<EObjIdentifier,EObjXIdentifierExt>>
  {
    /**
     * @generated
     */
    public ResultQueue2<EObjIdentifier,EObjXIdentifierExt> handle (java.sql.ResultSet rs, ResultQueue2<EObjIdentifier,EObjXIdentifierExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue2<EObjIdentifier,EObjXIdentifierExt> ();

      EObjIdentifier returnObject1 = new EObjIdentifier ();
      returnObject1.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject1.setHistActionCode(getString (rs, 2)); 
      returnObject1.setHistCreatedBy(getString (rs, 3)); 
      returnObject1.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject1.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject1.setIdentifierIdPK(getLongObject (rs, 6)); 
      returnObject1.setIdStatusTpCd(getLongObject (rs, 7)); 
      returnObject1.setContId(getLongObject (rs, 8)); 
      returnObject1.setIdTpCd(getLongObject (rs, 9)); 
      returnObject1.setRefNum(getString (rs, 10)); 
      returnObject1.setStartDt(getTimestamp (rs, 11)); 
      returnObject1.setEndDt(getTimestamp (rs, 12)); 
      returnObject1.setExpiryDt(getTimestamp (rs, 13)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 14)); 
      returnObject1.setLastUpdateUser(getString (rs, 15)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 16)); 
      returnObject1.setAssignedBy(getLongObject (rs, 17)); 
      returnObject1.setIdentifierDesc(getString (rs, 18)); 
      returnObject1.setIssueLocation(getString (rs, 19)); 
      returnObject1.setLastUsedDt(getTimestamp (rs, 20)); 
      returnObject1.setLastVerifiedDt(getTimestamp (rs, 21)); 
      returnObject1.setSourceIdentTpCd(getLongObject (rs, 22)); 
      returnObject.add (returnObject1);

      EObjXIdentifierExt returnObject2 = new EObjXIdentifierExt ();
      returnObject2.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject2.setHistActionCode(getString (rs, 2)); 
      returnObject2.setHistCreatedBy(getString (rs, 3)); 
      returnObject2.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject2.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject2.setLastUpdateDt(getTimestamp (rs, 14)); 
      returnObject2.setLastUpdateUser(getString (rs, 15)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 16)); 
      returnObject2.setXLastModifiedSystemDate(getTimestamp (rs, 23)); 
      returnObject2.setXRetailerId(getLongObject (rs, 24)); 
      returnObject2.setXIdentifierRetailerFlag(getString (rs, 25)); 
      returnObject2.setX_BPID(getString (rs, 26)); 
      returnObject.add (returnObject2);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT IDENTIFIER.IDENTIFIER_ID , IDENTIFIER.ID_STATUS_TP_CD , IDENTIFIER.CONT_ID , IDENTIFIER.ID_TP_CD , IDENTIFIER.REF_NUM , IDENTIFIER.START_DT , IDENTIFIER.END_DT , IDENTIFIER.EXPIRY_DT , IDENTIFIER.LAST_UPDATE_DT ,IDENTIFIER.LAST_UPDATE_USER, IDENTIFIER.LAST_UPDATE_TX_ID , IDENTIFIER.ASSIGNED_BY , IDENTIFIER.IDENTIFIER_DESC , IDENTIFIER.ISSUE_LOCATION , IDENTIFIER.LAST_USED_DT , IDENTIFIER.LAST_VERIFIED_DT , IDENTIFIER.SOURCE_IDENT_TP_CD, IDENTIFIER.XMODIFY_SYS_DT, IDENTIFIER.XRETAILER_ID, IDENTIFIER.XIDEN_RETAILER_FLAG, IDENTIFIER.X_BPID FROM IDENTIFIER WHERE ((IDENTIFIER.CONT_ID = ? )AND ( IDENTIFIER.ID_TP_CD = ?) AND (IDENTIFIER.END_DT IS NULL OR IDENTIFIER.END_DT > ?))", pattern="tableAlias (IDENTIFIER => com.dwl.tcrm.coreParty.entityObject.EObjIdentifier, H_IDENTIFIER => com.dwl.tcrm.coreParty.entityObject.EObjIdentifier , IDENTIFIER => com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt , H_IDENTIFIER => com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue2<EObjIdentifier,EObjXIdentifierExt>> getPartyIdentifiersByType (Object[] parameters)
  {
    return queryIterator (getPartyIdentifiersByTypeStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getPartyIdentifiersByTypeStatementDescriptor = createStatementDescriptor (
    "getPartyIdentifiersByType(Object[])",
    "SELECT IDENTIFIER.IDENTIFIER_ID , IDENTIFIER.ID_STATUS_TP_CD , IDENTIFIER.CONT_ID , IDENTIFIER.ID_TP_CD , IDENTIFIER.REF_NUM , IDENTIFIER.START_DT , IDENTIFIER.END_DT , IDENTIFIER.EXPIRY_DT , IDENTIFIER.LAST_UPDATE_DT ,IDENTIFIER.LAST_UPDATE_USER, IDENTIFIER.LAST_UPDATE_TX_ID , IDENTIFIER.ASSIGNED_BY , IDENTIFIER.IDENTIFIER_DESC , IDENTIFIER.ISSUE_LOCATION , IDENTIFIER.LAST_USED_DT , IDENTIFIER.LAST_VERIFIED_DT , IDENTIFIER.SOURCE_IDENT_TP_CD, IDENTIFIER.XMODIFY_SYS_DT, IDENTIFIER.XRETAILER_ID, IDENTIFIER.XIDEN_RETAILER_FLAG, IDENTIFIER.X_BPID FROM IDENTIFIER WHERE ((IDENTIFIER.CONT_ID = ? )AND ( IDENTIFIER.ID_TP_CD = ?) AND (IDENTIFIER.END_DT IS NULL OR IDENTIFIER.END_DT > ?))",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"identifier_id", "id_status_tp_cd", "cont_id", "id_tp_cd", "ref_num", "start_dt", "end_dt", "expiry_dt", "last_update_dt", "last_update_user", "last_update_tx_id", "assigned_by", "identifier_desc", "issue_location", "last_used_dt", "last_verified_dt", "source_ident_tp_cd", "xmodify_sys_dt", "xretailer_id", "xiden_retailer_flag", "x_bpid"},
    new GetPartyIdentifiersByTypeParameterHandler (),
    new int[][]{{Types.BIGINT, Types.BIGINT, Types.TIMESTAMP}, {19, 19, 0}, {0, 0, 0}, {1, 1, 1}},
    null,
    new GetPartyIdentifiersByTypeRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.TIMESTAMP, Types.BIGINT, Types.VARCHAR, Types.VARCHAR}, {19, 19, 19, 19, 50, 0, 0, 0, 0, 20, 19, 19, 255, 30, 0, 0, 19, 0, 19, 5, 50}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    2);

  /**
   * @generated
   */
  public static class GetPartyIdentifiersByTypeParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.BIGINT, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetPartyIdentifiersByTypeRowHandler extends BaseRowHandler<ResultQueue2<EObjIdentifier,EObjXIdentifierExt>>
  {
    /**
     * @generated
     */
    public ResultQueue2<EObjIdentifier,EObjXIdentifierExt> handle (java.sql.ResultSet rs, ResultQueue2<EObjIdentifier,EObjXIdentifierExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue2<EObjIdentifier,EObjXIdentifierExt> ();

      EObjIdentifier returnObject1 = new EObjIdentifier ();
      returnObject1.setIdentifierIdPK(getLongObject (rs, 1)); 
      returnObject1.setIdStatusTpCd(getLongObject (rs, 2)); 
      returnObject1.setContId(getLongObject (rs, 3)); 
      returnObject1.setIdTpCd(getLongObject (rs, 4)); 
      returnObject1.setRefNum(getString (rs, 5)); 
      returnObject1.setStartDt(getTimestamp (rs, 6)); 
      returnObject1.setEndDt(getTimestamp (rs, 7)); 
      returnObject1.setExpiryDt(getTimestamp (rs, 8)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 9)); 
      returnObject1.setLastUpdateUser(getString (rs, 10)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 11)); 
      returnObject1.setAssignedBy(getLongObject (rs, 12)); 
      returnObject1.setIdentifierDesc(getString (rs, 13)); 
      returnObject1.setIssueLocation(getString (rs, 14)); 
      returnObject1.setLastUsedDt(getTimestamp (rs, 15)); 
      returnObject1.setLastVerifiedDt(getTimestamp (rs, 16)); 
      returnObject1.setSourceIdentTpCd(getLongObject (rs, 17)); 
      returnObject.add (returnObject1);

      EObjXIdentifierExt returnObject2 = new EObjXIdentifierExt ();
      returnObject2.setLastUpdateDt(getTimestamp (rs, 9)); 
      returnObject2.setLastUpdateUser(getString (rs, 10)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 11)); 
      returnObject2.setXLastModifiedSystemDate(getTimestamp (rs, 18)); 
      returnObject2.setXRetailerId(getLongObject (rs, 19)); 
      returnObject2.setXIdentifierRetailerFlag(getString (rs, 20)); 
      returnObject2.setX_BPID(getString (rs, 21)); 
      returnObject.add (returnObject2);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT DISTINCT A.H_IDENTIFIER_ID AS HIST_ID_PK, A.H_ACTION_CODE , A.H_CREATED_BY , A.H_CREATE_DT ,A.H_END_DT ,A.IDENTIFIER_ID ,A.ID_STATUS_TP_CD ,A.CONT_ID , A.ID_TP_CD ,A.REF_NUM ,A.START_DT ,A.END_DT ,A.EXPIRY_DT , A.LAST_UPDATE_DT, A.LAST_UPDATE_USER , A.LAST_UPDATE_TX_ID , A.ASSIGNED_BY , A.IDENTIFIER_DESC , A.ISSUE_LOCATION , A.LAST_USED_DT , A.LAST_VERIFIED_DT , A.SOURCE_IDENT_TP_CD, A.XMODIFY_SYS_DT, A.XRETAILER_ID, A.XIDEN_RETAILER_FLAG, A.X_BPID FROM H_IDENTIFIER A WHERE A.CONT_ID = ? AND (( ? BETWEEN A.H_CREATE_DT AND A.H_END_DT ) OR ( ? >= A.H_CREATE_DT AND A.H_END_DT IS NULL ))", pattern="tableAlias (IDENTIFIER => com.dwl.tcrm.coreParty.entityObject.EObjIdentifier, H_IDENTIFIER => com.dwl.tcrm.coreParty.entityObject.EObjIdentifier , IDENTIFIER => com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt , H_IDENTIFIER => com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue2<EObjIdentifier,EObjXIdentifierExt>> getPartyIdentifiersHistory (Object[] parameters)
  {
    return queryIterator (getPartyIdentifiersHistoryStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getPartyIdentifiersHistoryStatementDescriptor = createStatementDescriptor (
    "getPartyIdentifiersHistory(Object[])",
    "SELECT DISTINCT A.H_IDENTIFIER_ID AS HIST_ID_PK, A.H_ACTION_CODE , A.H_CREATED_BY , A.H_CREATE_DT ,A.H_END_DT ,A.IDENTIFIER_ID ,A.ID_STATUS_TP_CD ,A.CONT_ID , A.ID_TP_CD ,A.REF_NUM ,A.START_DT ,A.END_DT ,A.EXPIRY_DT , A.LAST_UPDATE_DT, A.LAST_UPDATE_USER , A.LAST_UPDATE_TX_ID , A.ASSIGNED_BY , A.IDENTIFIER_DESC , A.ISSUE_LOCATION , A.LAST_USED_DT , A.LAST_VERIFIED_DT , A.SOURCE_IDENT_TP_CD, A.XMODIFY_SYS_DT, A.XRETAILER_ID, A.XIDEN_RETAILER_FLAG, A.X_BPID FROM H_IDENTIFIER A WHERE A.CONT_ID = ? AND (( ? BETWEEN A.H_CREATE_DT AND A.H_END_DT ) OR ( ? >= A.H_CREATE_DT AND A.H_END_DT IS NULL ))",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"hist_id_pk", "h_action_code", "h_created_by", "h_create_dt", "h_end_dt", "identifier_id", "id_status_tp_cd", "cont_id", "id_tp_cd", "ref_num", "start_dt", "end_dt", "expiry_dt", "last_update_dt", "last_update_user", "last_update_tx_id", "assigned_by", "identifier_desc", "issue_location", "last_used_dt", "last_verified_dt", "source_ident_tp_cd", "xmodify_sys_dt", "xretailer_id", "xiden_retailer_flag", "x_bpid"},
    new GetPartyIdentifiersHistoryParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP}, {19, 0, 0}, {0, 0, 0}, {1, 1, 1}},
    null,
    new GetPartyIdentifiersHistoryRowHandler (),
    new int[][]{ {Types.BIGINT, Types.CHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.TIMESTAMP, Types.BIGINT, Types.VARCHAR, Types.VARCHAR}, {19, 1, 20, 0, 0, 19, 19, 19, 19, 50, 0, 0, 0, 0, 20, 19, 19, 255, 30, 0, 0, 19, 0, 19, 5, 50}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    3);

  /**
   * @generated
   */
  public static class GetPartyIdentifiersHistoryParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetPartyIdentifiersHistoryRowHandler extends BaseRowHandler<ResultQueue2<EObjIdentifier,EObjXIdentifierExt>>
  {
    /**
     * @generated
     */
    public ResultQueue2<EObjIdentifier,EObjXIdentifierExt> handle (java.sql.ResultSet rs, ResultQueue2<EObjIdentifier,EObjXIdentifierExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue2<EObjIdentifier,EObjXIdentifierExt> ();

      EObjIdentifier returnObject1 = new EObjIdentifier ();
      returnObject1.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject1.setHistActionCode(getString (rs, 2)); 
      returnObject1.setHistCreatedBy(getString (rs, 3)); 
      returnObject1.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject1.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject1.setIdentifierIdPK(getLongObject (rs, 6)); 
      returnObject1.setIdStatusTpCd(getLongObject (rs, 7)); 
      returnObject1.setContId(getLongObject (rs, 8)); 
      returnObject1.setIdTpCd(getLongObject (rs, 9)); 
      returnObject1.setRefNum(getString (rs, 10)); 
      returnObject1.setStartDt(getTimestamp (rs, 11)); 
      returnObject1.setEndDt(getTimestamp (rs, 12)); 
      returnObject1.setExpiryDt(getTimestamp (rs, 13)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 14)); 
      returnObject1.setLastUpdateUser(getString (rs, 15)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 16)); 
      returnObject1.setAssignedBy(getLongObject (rs, 17)); 
      returnObject1.setIdentifierDesc(getString (rs, 18)); 
      returnObject1.setIssueLocation(getString (rs, 19)); 
      returnObject1.setLastUsedDt(getTimestamp (rs, 20)); 
      returnObject1.setLastVerifiedDt(getTimestamp (rs, 21)); 
      returnObject1.setSourceIdentTpCd(getLongObject (rs, 22)); 
      returnObject.add (returnObject1);

      EObjXIdentifierExt returnObject2 = new EObjXIdentifierExt ();
      returnObject2.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject2.setHistActionCode(getString (rs, 2)); 
      returnObject2.setHistCreatedBy(getString (rs, 3)); 
      returnObject2.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject2.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject2.setLastUpdateDt(getTimestamp (rs, 14)); 
      returnObject2.setLastUpdateUser(getString (rs, 15)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 16)); 
      returnObject2.setXLastModifiedSystemDate(getTimestamp (rs, 23)); 
      returnObject2.setXRetailerId(getLongObject (rs, 24)); 
      returnObject2.setXIdentifierRetailerFlag(getString (rs, 25)); 
      returnObject2.setX_BPID(getString (rs, 26)); 
      returnObject.add (returnObject2);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT IDENTIFIER.IDENTIFIER_ID , IDENTIFIER.ID_STATUS_TP_CD , IDENTIFIER.CONT_ID , IDENTIFIER.ID_TP_CD , IDENTIFIER.REF_NUM , IDENTIFIER.START_DT , IDENTIFIER.END_DT , IDENTIFIER.EXPIRY_DT , IDENTIFIER.LAST_UPDATE_DT ,IDENTIFIER.LAST_UPDATE_USER, IDENTIFIER.LAST_UPDATE_TX_ID , IDENTIFIER.ASSIGNED_BY , IDENTIFIER.IDENTIFIER_DESC , IDENTIFIER.ISSUE_LOCATION , IDENTIFIER.LAST_USED_DT , IDENTIFIER.LAST_VERIFIED_DT , IDENTIFIER.SOURCE_IDENT_TP_CD, IDENTIFIER.XMODIFY_SYS_DT, IDENTIFIER.XRETAILER_ID, IDENTIFIER.XIDEN_RETAILER_FLAG, IDENTIFIER.X_BPID FROM IDENTIFIER WHERE ((IDENTIFIER.CONT_ID = ? ) AND ((IDENTIFIER.END_DT IS NULL) OR (IDENTIFIER.END_DT > ? )))", pattern="tableAlias (IDENTIFIER => com.dwl.tcrm.coreParty.entityObject.EObjIdentifier, H_IDENTIFIER => com.dwl.tcrm.coreParty.entityObject.EObjIdentifier , IDENTIFIER => com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt , H_IDENTIFIER => com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue2<EObjIdentifier,EObjXIdentifierExt>> getPartyIdentifiersActive (Object[] parameters)
  {
    return queryIterator (getPartyIdentifiersActiveStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getPartyIdentifiersActiveStatementDescriptor = createStatementDescriptor (
    "getPartyIdentifiersActive(Object[])",
    "SELECT IDENTIFIER.IDENTIFIER_ID , IDENTIFIER.ID_STATUS_TP_CD , IDENTIFIER.CONT_ID , IDENTIFIER.ID_TP_CD , IDENTIFIER.REF_NUM , IDENTIFIER.START_DT , IDENTIFIER.END_DT , IDENTIFIER.EXPIRY_DT , IDENTIFIER.LAST_UPDATE_DT ,IDENTIFIER.LAST_UPDATE_USER, IDENTIFIER.LAST_UPDATE_TX_ID , IDENTIFIER.ASSIGNED_BY , IDENTIFIER.IDENTIFIER_DESC , IDENTIFIER.ISSUE_LOCATION , IDENTIFIER.LAST_USED_DT , IDENTIFIER.LAST_VERIFIED_DT , IDENTIFIER.SOURCE_IDENT_TP_CD, IDENTIFIER.XMODIFY_SYS_DT, IDENTIFIER.XRETAILER_ID, IDENTIFIER.XIDEN_RETAILER_FLAG, IDENTIFIER.X_BPID FROM IDENTIFIER WHERE ((IDENTIFIER.CONT_ID = ? ) AND ((IDENTIFIER.END_DT IS NULL) OR (IDENTIFIER.END_DT > ? )))",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"identifier_id", "id_status_tp_cd", "cont_id", "id_tp_cd", "ref_num", "start_dt", "end_dt", "expiry_dt", "last_update_dt", "last_update_user", "last_update_tx_id", "assigned_by", "identifier_desc", "issue_location", "last_used_dt", "last_verified_dt", "source_ident_tp_cd", "xmodify_sys_dt", "xretailer_id", "xiden_retailer_flag", "x_bpid"},
    new GetPartyIdentifiersActiveParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP}, {19, 0}, {0, 0}, {1, 1}},
    null,
    new GetPartyIdentifiersActiveRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.TIMESTAMP, Types.BIGINT, Types.VARCHAR, Types.VARCHAR}, {19, 19, 19, 19, 50, 0, 0, 0, 0, 20, 19, 19, 255, 30, 0, 0, 19, 0, 19, 5, 50}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    4);

  /**
   * @generated
   */
  public static class GetPartyIdentifiersActiveParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetPartyIdentifiersActiveRowHandler extends BaseRowHandler<ResultQueue2<EObjIdentifier,EObjXIdentifierExt>>
  {
    /**
     * @generated
     */
    public ResultQueue2<EObjIdentifier,EObjXIdentifierExt> handle (java.sql.ResultSet rs, ResultQueue2<EObjIdentifier,EObjXIdentifierExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue2<EObjIdentifier,EObjXIdentifierExt> ();

      EObjIdentifier returnObject1 = new EObjIdentifier ();
      returnObject1.setIdentifierIdPK(getLongObject (rs, 1)); 
      returnObject1.setIdStatusTpCd(getLongObject (rs, 2)); 
      returnObject1.setContId(getLongObject (rs, 3)); 
      returnObject1.setIdTpCd(getLongObject (rs, 4)); 
      returnObject1.setRefNum(getString (rs, 5)); 
      returnObject1.setStartDt(getTimestamp (rs, 6)); 
      returnObject1.setEndDt(getTimestamp (rs, 7)); 
      returnObject1.setExpiryDt(getTimestamp (rs, 8)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 9)); 
      returnObject1.setLastUpdateUser(getString (rs, 10)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 11)); 
      returnObject1.setAssignedBy(getLongObject (rs, 12)); 
      returnObject1.setIdentifierDesc(getString (rs, 13)); 
      returnObject1.setIssueLocation(getString (rs, 14)); 
      returnObject1.setLastUsedDt(getTimestamp (rs, 15)); 
      returnObject1.setLastVerifiedDt(getTimestamp (rs, 16)); 
      returnObject1.setSourceIdentTpCd(getLongObject (rs, 17)); 
      returnObject.add (returnObject1);

      EObjXIdentifierExt returnObject2 = new EObjXIdentifierExt ();
      returnObject2.setLastUpdateDt(getTimestamp (rs, 9)); 
      returnObject2.setLastUpdateUser(getString (rs, 10)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 11)); 
      returnObject2.setXLastModifiedSystemDate(getTimestamp (rs, 18)); 
      returnObject2.setXRetailerId(getLongObject (rs, 19)); 
      returnObject2.setXIdentifierRetailerFlag(getString (rs, 20)); 
      returnObject2.setX_BPID(getString (rs, 21)); 
      returnObject.add (returnObject2);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT IDENTIFIER.IDENTIFIER_ID , IDENTIFIER.ID_STATUS_TP_CD , IDENTIFIER.CONT_ID , IDENTIFIER.ID_TP_CD , IDENTIFIER.REF_NUM , IDENTIFIER.START_DT, IDENTIFIER.END_DT , IDENTIFIER.EXPIRY_DT, IDENTIFIER.LAST_UPDATE_DT , IDENTIFIER.LAST_UPDATE_USER , IDENTIFIER.LAST_UPDATE_TX_ID , IDENTIFIER.ASSIGNED_BY , IDENTIFIER.IDENTIFIER_DESC , IDENTIFIER.ISSUE_LOCATION , IDENTIFIER.LAST_USED_DT , IDENTIFIER.LAST_VERIFIED_DT , IDENTIFIER.SOURCE_IDENT_TP_CD, IDENTIFIER.XMODIFY_SYS_DT, IDENTIFIER.XRETAILER_ID, IDENTIFIER.XIDEN_RETAILER_FLAG, IDENTIFIER.X_BPID FROM IDENTIFIER WHERE ((IDENTIFIER.CONT_ID = ? )AND (IDENTIFIER.END_DT < ?))", pattern="tableAlias (IDENTIFIER => com.dwl.tcrm.coreParty.entityObject.EObjIdentifier, H_IDENTIFIER => com.dwl.tcrm.coreParty.entityObject.EObjIdentifier , IDENTIFIER => com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt , H_IDENTIFIER => com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue2<EObjIdentifier,EObjXIdentifierExt>> getPartyIdentifiersInactive (Object[] parameters)
  {
    return queryIterator (getPartyIdentifiersInactiveStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getPartyIdentifiersInactiveStatementDescriptor = createStatementDescriptor (
    "getPartyIdentifiersInactive(Object[])",
    "SELECT IDENTIFIER.IDENTIFIER_ID , IDENTIFIER.ID_STATUS_TP_CD , IDENTIFIER.CONT_ID , IDENTIFIER.ID_TP_CD , IDENTIFIER.REF_NUM , IDENTIFIER.START_DT, IDENTIFIER.END_DT , IDENTIFIER.EXPIRY_DT, IDENTIFIER.LAST_UPDATE_DT , IDENTIFIER.LAST_UPDATE_USER , IDENTIFIER.LAST_UPDATE_TX_ID , IDENTIFIER.ASSIGNED_BY , IDENTIFIER.IDENTIFIER_DESC , IDENTIFIER.ISSUE_LOCATION , IDENTIFIER.LAST_USED_DT , IDENTIFIER.LAST_VERIFIED_DT , IDENTIFIER.SOURCE_IDENT_TP_CD, IDENTIFIER.XMODIFY_SYS_DT, IDENTIFIER.XRETAILER_ID, IDENTIFIER.XIDEN_RETAILER_FLAG, IDENTIFIER.X_BPID FROM IDENTIFIER WHERE ((IDENTIFIER.CONT_ID = ? )AND (IDENTIFIER.END_DT < ?))",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"identifier_id", "id_status_tp_cd", "cont_id", "id_tp_cd", "ref_num", "start_dt", "end_dt", "expiry_dt", "last_update_dt", "last_update_user", "last_update_tx_id", "assigned_by", "identifier_desc", "issue_location", "last_used_dt", "last_verified_dt", "source_ident_tp_cd", "xmodify_sys_dt", "xretailer_id", "xiden_retailer_flag", "x_bpid"},
    new GetPartyIdentifiersInactiveParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP}, {19, 0}, {0, 0}, {1, 1}},
    null,
    new GetPartyIdentifiersInactiveRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.TIMESTAMP, Types.BIGINT, Types.VARCHAR, Types.VARCHAR}, {19, 19, 19, 19, 50, 0, 0, 0, 0, 20, 19, 19, 255, 30, 0, 0, 19, 0, 19, 5, 50}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    5);

  /**
   * @generated
   */
  public static class GetPartyIdentifiersInactiveParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetPartyIdentifiersInactiveRowHandler extends BaseRowHandler<ResultQueue2<EObjIdentifier,EObjXIdentifierExt>>
  {
    /**
     * @generated
     */
    public ResultQueue2<EObjIdentifier,EObjXIdentifierExt> handle (java.sql.ResultSet rs, ResultQueue2<EObjIdentifier,EObjXIdentifierExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue2<EObjIdentifier,EObjXIdentifierExt> ();

      EObjIdentifier returnObject1 = new EObjIdentifier ();
      returnObject1.setIdentifierIdPK(getLongObject (rs, 1)); 
      returnObject1.setIdStatusTpCd(getLongObject (rs, 2)); 
      returnObject1.setContId(getLongObject (rs, 3)); 
      returnObject1.setIdTpCd(getLongObject (rs, 4)); 
      returnObject1.setRefNum(getString (rs, 5)); 
      returnObject1.setStartDt(getTimestamp (rs, 6)); 
      returnObject1.setEndDt(getTimestamp (rs, 7)); 
      returnObject1.setExpiryDt(getTimestamp (rs, 8)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 9)); 
      returnObject1.setLastUpdateUser(getString (rs, 10)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 11)); 
      returnObject1.setAssignedBy(getLongObject (rs, 12)); 
      returnObject1.setIdentifierDesc(getString (rs, 13)); 
      returnObject1.setIssueLocation(getString (rs, 14)); 
      returnObject1.setLastUsedDt(getTimestamp (rs, 15)); 
      returnObject1.setLastVerifiedDt(getTimestamp (rs, 16)); 
      returnObject1.setSourceIdentTpCd(getLongObject (rs, 17)); 
      returnObject.add (returnObject1);

      EObjXIdentifierExt returnObject2 = new EObjXIdentifierExt ();
      returnObject2.setLastUpdateDt(getTimestamp (rs, 9)); 
      returnObject2.setLastUpdateUser(getString (rs, 10)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 11)); 
      returnObject2.setXLastModifiedSystemDate(getTimestamp (rs, 18)); 
      returnObject2.setXRetailerId(getLongObject (rs, 19)); 
      returnObject2.setXIdentifierRetailerFlag(getString (rs, 20)); 
      returnObject2.setX_BPID(getString (rs, 21)); 
      returnObject.add (returnObject2);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT IDENTIFIER.IDENTIFIER_ID , IDENTIFIER.ID_STATUS_TP_CD , IDENTIFIER.CONT_ID , IDENTIFIER.ID_TP_CD , IDENTIFIER.REF_NUM , IDENTIFIER.START_DT , IDENTIFIER.END_DT , IDENTIFIER.EXPIRY_DT , IDENTIFIER.LAST_UPDATE_DT , IDENTIFIER.LAST_UPDATE_USER , IDENTIFIER.LAST_UPDATE_TX_ID , IDENTIFIER.ASSIGNED_BY , IDENTIFIER.IDENTIFIER_DESC , IDENTIFIER.ISSUE_LOCATION , IDENTIFIER.LAST_USED_DT , IDENTIFIER.LAST_VERIFIED_DT , IDENTIFIER.SOURCE_IDENT_TP_CD, IDENTIFIER.XMODIFY_SYS_DT, IDENTIFIER.XRETAILER_ID, IDENTIFIER.XIDEN_RETAILER_FLAG, IDENTIFIER.X_BPID FROM IDENTIFIER WHERE IDENTIFIER.CONT_ID = ?", pattern="tableAlias (IDENTIFIER => com.dwl.tcrm.coreParty.entityObject.EObjIdentifier, H_IDENTIFIER => com.dwl.tcrm.coreParty.entityObject.EObjIdentifier , IDENTIFIER => com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt , H_IDENTIFIER => com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue2<EObjIdentifier,EObjXIdentifierExt>> getPartyIdentifiersAll (Object[] parameters)
  {
    return queryIterator (getPartyIdentifiersAllStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getPartyIdentifiersAllStatementDescriptor = createStatementDescriptor (
    "getPartyIdentifiersAll(Object[])",
    "SELECT IDENTIFIER.IDENTIFIER_ID , IDENTIFIER.ID_STATUS_TP_CD , IDENTIFIER.CONT_ID , IDENTIFIER.ID_TP_CD , IDENTIFIER.REF_NUM , IDENTIFIER.START_DT , IDENTIFIER.END_DT , IDENTIFIER.EXPIRY_DT , IDENTIFIER.LAST_UPDATE_DT , IDENTIFIER.LAST_UPDATE_USER , IDENTIFIER.LAST_UPDATE_TX_ID , IDENTIFIER.ASSIGNED_BY , IDENTIFIER.IDENTIFIER_DESC , IDENTIFIER.ISSUE_LOCATION , IDENTIFIER.LAST_USED_DT , IDENTIFIER.LAST_VERIFIED_DT , IDENTIFIER.SOURCE_IDENT_TP_CD, IDENTIFIER.XMODIFY_SYS_DT, IDENTIFIER.XRETAILER_ID, IDENTIFIER.XIDEN_RETAILER_FLAG, IDENTIFIER.X_BPID FROM IDENTIFIER WHERE IDENTIFIER.CONT_ID = ?",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"identifier_id", "id_status_tp_cd", "cont_id", "id_tp_cd", "ref_num", "start_dt", "end_dt", "expiry_dt", "last_update_dt", "last_update_user", "last_update_tx_id", "assigned_by", "identifier_desc", "issue_location", "last_used_dt", "last_verified_dt", "source_ident_tp_cd", "xmodify_sys_dt", "xretailer_id", "xiden_retailer_flag", "x_bpid"},
    new GetPartyIdentifiersAllParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetPartyIdentifiersAllRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.TIMESTAMP, Types.BIGINT, Types.VARCHAR, Types.VARCHAR}, {19, 19, 19, 19, 50, 0, 0, 0, 0, 20, 19, 19, 255, 30, 0, 0, 19, 0, 19, 5, 50}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    6);

  /**
   * @generated
   */
  public static class GetPartyIdentifiersAllParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetPartyIdentifiersAllRowHandler extends BaseRowHandler<ResultQueue2<EObjIdentifier,EObjXIdentifierExt>>
  {
    /**
     * @generated
     */
    public ResultQueue2<EObjIdentifier,EObjXIdentifierExt> handle (java.sql.ResultSet rs, ResultQueue2<EObjIdentifier,EObjXIdentifierExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue2<EObjIdentifier,EObjXIdentifierExt> ();

      EObjIdentifier returnObject1 = new EObjIdentifier ();
      returnObject1.setIdentifierIdPK(getLongObject (rs, 1)); 
      returnObject1.setIdStatusTpCd(getLongObject (rs, 2)); 
      returnObject1.setContId(getLongObject (rs, 3)); 
      returnObject1.setIdTpCd(getLongObject (rs, 4)); 
      returnObject1.setRefNum(getString (rs, 5)); 
      returnObject1.setStartDt(getTimestamp (rs, 6)); 
      returnObject1.setEndDt(getTimestamp (rs, 7)); 
      returnObject1.setExpiryDt(getTimestamp (rs, 8)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 9)); 
      returnObject1.setLastUpdateUser(getString (rs, 10)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 11)); 
      returnObject1.setAssignedBy(getLongObject (rs, 12)); 
      returnObject1.setIdentifierDesc(getString (rs, 13)); 
      returnObject1.setIssueLocation(getString (rs, 14)); 
      returnObject1.setLastUsedDt(getTimestamp (rs, 15)); 
      returnObject1.setLastVerifiedDt(getTimestamp (rs, 16)); 
      returnObject1.setSourceIdentTpCd(getLongObject (rs, 17)); 
      returnObject.add (returnObject1);

      EObjXIdentifierExt returnObject2 = new EObjXIdentifierExt ();
      returnObject2.setLastUpdateDt(getTimestamp (rs, 9)); 
      returnObject2.setLastUpdateUser(getString (rs, 10)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 11)); 
      returnObject2.setXLastModifiedSystemDate(getTimestamp (rs, 18)); 
      returnObject2.setXRetailerId(getLongObject (rs, 19)); 
      returnObject2.setXIdentifierRetailerFlag(getString (rs, 20)); 
      returnObject2.setX_BPID(getString (rs, 21)); 
      returnObject.add (returnObject2);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT IDENTIFIER.IDENTIFIER_ID , IDENTIFIER.ID_STATUS_TP_CD , IDENTIFIER.CONT_ID , IDENTIFIER.ID_TP_CD , IDENTIFIER.REF_NUM , IDENTIFIER.START_DT , IDENTIFIER.END_DT , IDENTIFIER.EXPIRY_DT , IDENTIFIER.LAST_UPDATE_DT , IDENTIFIER.LAST_UPDATE_USER , IDENTIFIER.LAST_UPDATE_TX_ID , IDENTIFIER.ASSIGNED_BY , IDENTIFIER.IDENTIFIER_DESC , IDENTIFIER.ISSUE_LOCATION , IDENTIFIER.LAST_USED_DT , IDENTIFIER.LAST_VERIFIED_DT , IDENTIFIER.SOURCE_IDENT_TP_CD, IDENTIFIER.XMODIFY_SYS_DT, IDENTIFIER.XRETAILER_ID, IDENTIFIER.XIDEN_RETAILER_FLAG, IDENTIFIER.X_BPID FROM IDENTIFIER WHERE (IDENTIFIER.IDENTIFIER_ID = ?)", pattern="tableAlias (IDENTIFIER => com.dwl.tcrm.coreParty.entityObject.EObjIdentifier, H_IDENTIFIER => com.dwl.tcrm.coreParty.entityObject.EObjIdentifier , IDENTIFIER => com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt , H_IDENTIFIER => com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue2<EObjIdentifier,EObjXIdentifierExt>> getPartyIdentifierById (Object[] parameters)
  {
    return queryIterator (getPartyIdentifierByIdStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getPartyIdentifierByIdStatementDescriptor = createStatementDescriptor (
    "getPartyIdentifierById(Object[])",
    "SELECT IDENTIFIER.IDENTIFIER_ID , IDENTIFIER.ID_STATUS_TP_CD , IDENTIFIER.CONT_ID , IDENTIFIER.ID_TP_CD , IDENTIFIER.REF_NUM , IDENTIFIER.START_DT , IDENTIFIER.END_DT , IDENTIFIER.EXPIRY_DT , IDENTIFIER.LAST_UPDATE_DT , IDENTIFIER.LAST_UPDATE_USER , IDENTIFIER.LAST_UPDATE_TX_ID , IDENTIFIER.ASSIGNED_BY , IDENTIFIER.IDENTIFIER_DESC , IDENTIFIER.ISSUE_LOCATION , IDENTIFIER.LAST_USED_DT , IDENTIFIER.LAST_VERIFIED_DT , IDENTIFIER.SOURCE_IDENT_TP_CD, IDENTIFIER.XMODIFY_SYS_DT, IDENTIFIER.XRETAILER_ID, IDENTIFIER.XIDEN_RETAILER_FLAG, IDENTIFIER.X_BPID FROM IDENTIFIER WHERE (IDENTIFIER.IDENTIFIER_ID = ?)",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"identifier_id", "id_status_tp_cd", "cont_id", "id_tp_cd", "ref_num", "start_dt", "end_dt", "expiry_dt", "last_update_dt", "last_update_user", "last_update_tx_id", "assigned_by", "identifier_desc", "issue_location", "last_used_dt", "last_verified_dt", "source_ident_tp_cd", "xmodify_sys_dt", "xretailer_id", "xiden_retailer_flag", "x_bpid"},
    new GetPartyIdentifierByIdParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetPartyIdentifierByIdRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.TIMESTAMP, Types.BIGINT, Types.VARCHAR, Types.VARCHAR}, {19, 19, 19, 19, 50, 0, 0, 0, 0, 20, 19, 19, 255, 30, 0, 0, 19, 0, 19, 5, 50}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    7);

  /**
   * @generated
   */
  public static class GetPartyIdentifierByIdParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetPartyIdentifierByIdRowHandler extends BaseRowHandler<ResultQueue2<EObjIdentifier,EObjXIdentifierExt>>
  {
    /**
     * @generated
     */
    public ResultQueue2<EObjIdentifier,EObjXIdentifierExt> handle (java.sql.ResultSet rs, ResultQueue2<EObjIdentifier,EObjXIdentifierExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue2<EObjIdentifier,EObjXIdentifierExt> ();

      EObjIdentifier returnObject1 = new EObjIdentifier ();
      returnObject1.setIdentifierIdPK(getLongObject (rs, 1)); 
      returnObject1.setIdStatusTpCd(getLongObject (rs, 2)); 
      returnObject1.setContId(getLongObject (rs, 3)); 
      returnObject1.setIdTpCd(getLongObject (rs, 4)); 
      returnObject1.setRefNum(getString (rs, 5)); 
      returnObject1.setStartDt(getTimestamp (rs, 6)); 
      returnObject1.setEndDt(getTimestamp (rs, 7)); 
      returnObject1.setExpiryDt(getTimestamp (rs, 8)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 9)); 
      returnObject1.setLastUpdateUser(getString (rs, 10)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 11)); 
      returnObject1.setAssignedBy(getLongObject (rs, 12)); 
      returnObject1.setIdentifierDesc(getString (rs, 13)); 
      returnObject1.setIssueLocation(getString (rs, 14)); 
      returnObject1.setLastUsedDt(getTimestamp (rs, 15)); 
      returnObject1.setLastVerifiedDt(getTimestamp (rs, 16)); 
      returnObject1.setSourceIdentTpCd(getLongObject (rs, 17)); 
      returnObject.add (returnObject1);

      EObjXIdentifierExt returnObject2 = new EObjXIdentifierExt ();
      returnObject2.setLastUpdateDt(getTimestamp (rs, 9)); 
      returnObject2.setLastUpdateUser(getString (rs, 10)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 11)); 
      returnObject2.setXLastModifiedSystemDate(getTimestamp (rs, 18)); 
      returnObject2.setXRetailerId(getLongObject (rs, 19)); 
      returnObject2.setXIdentifierRetailerFlag(getString (rs, 20)); 
      returnObject2.setX_BPID(getString (rs, 21)); 
      returnObject.add (returnObject2);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT A.H_IDENTIFIER_ID AS HIST_ID_PK, A.H_ACTION_CODE , A.H_CREATED_BY , A.H_CREATE_DT ,A.H_END_DT ,A.IDENTIFIER_ID ,A.ID_STATUS_TP_CD ,A.CONT_ID , A.ID_TP_CD,A.REF_NUM ,A.START_DT ,A.END_DT ,A.EXPIRY_DT , A.LAST_UPDATE_DT , A.LAST_UPDATE_USER , A.LAST_UPDATE_TX_ID , A.ASSIGNED_BY , A.IDENTIFIER_DESC , A.ISSUE_LOCATION, A.LAST_USED_DT , A.LAST_VERIFIED_DT , A.SOURCE_IDENT_TP_CD, A.XMODIFY_SYS_DT, A.XRETAILER_ID, A.XIDEN_RETAILER_FLAG, A.X_BPID FROM H_IDENTIFIER A WHERE H_IDENTIFIER_ID = ? AND (( ? BETWEEN A.H_CREATE_DT AND A.H_END_DT ) OR ( ? >= A.H_CREATE_DT AND A.H_END_DT IS NULL ))", pattern="tableAlias (IDENTIFIER => com.dwl.tcrm.coreParty.entityObject.EObjIdentifier, H_IDENTIFIER => com.dwl.tcrm.coreParty.entityObject.EObjIdentifier , IDENTIFIER => com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt , H_IDENTIFIER => com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue2<EObjIdentifier,EObjXIdentifierExt>> getPartyIdentifierHistoryById (Object[] parameters)
  {
    return queryIterator (getPartyIdentifierHistoryByIdStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getPartyIdentifierHistoryByIdStatementDescriptor = createStatementDescriptor (
    "getPartyIdentifierHistoryById(Object[])",
    "SELECT A.H_IDENTIFIER_ID AS HIST_ID_PK, A.H_ACTION_CODE , A.H_CREATED_BY , A.H_CREATE_DT ,A.H_END_DT ,A.IDENTIFIER_ID ,A.ID_STATUS_TP_CD ,A.CONT_ID , A.ID_TP_CD,A.REF_NUM ,A.START_DT ,A.END_DT ,A.EXPIRY_DT , A.LAST_UPDATE_DT , A.LAST_UPDATE_USER , A.LAST_UPDATE_TX_ID , A.ASSIGNED_BY , A.IDENTIFIER_DESC , A.ISSUE_LOCATION, A.LAST_USED_DT , A.LAST_VERIFIED_DT , A.SOURCE_IDENT_TP_CD, A.XMODIFY_SYS_DT, A.XRETAILER_ID, A.XIDEN_RETAILER_FLAG, A.X_BPID FROM H_IDENTIFIER A WHERE H_IDENTIFIER_ID = ? AND (( ? BETWEEN A.H_CREATE_DT AND A.H_END_DT ) OR ( ? >= A.H_CREATE_DT AND A.H_END_DT IS NULL ))",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"hist_id_pk", "h_action_code", "h_created_by", "h_create_dt", "h_end_dt", "identifier_id", "id_status_tp_cd", "cont_id", "id_tp_cd", "ref_num", "start_dt", "end_dt", "expiry_dt", "last_update_dt", "last_update_user", "last_update_tx_id", "assigned_by", "identifier_desc", "issue_location", "last_used_dt", "last_verified_dt", "source_ident_tp_cd", "xmodify_sys_dt", "xretailer_id", "xiden_retailer_flag", "x_bpid"},
    new GetPartyIdentifierHistoryByIdParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP}, {19, 0, 0}, {0, 0, 0}, {1, 1, 1}},
    null,
    new GetPartyIdentifierHistoryByIdRowHandler (),
    new int[][]{ {Types.BIGINT, Types.CHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.TIMESTAMP, Types.BIGINT, Types.VARCHAR, Types.VARCHAR}, {19, 1, 20, 0, 0, 19, 19, 19, 19, 50, 0, 0, 0, 0, 20, 19, 19, 255, 30, 0, 0, 19, 0, 19, 5, 50}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    8);

  /**
   * @generated
   */
  public static class GetPartyIdentifierHistoryByIdParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetPartyIdentifierHistoryByIdRowHandler extends BaseRowHandler<ResultQueue2<EObjIdentifier,EObjXIdentifierExt>>
  {
    /**
     * @generated
     */
    public ResultQueue2<EObjIdentifier,EObjXIdentifierExt> handle (java.sql.ResultSet rs, ResultQueue2<EObjIdentifier,EObjXIdentifierExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue2<EObjIdentifier,EObjXIdentifierExt> ();

      EObjIdentifier returnObject1 = new EObjIdentifier ();
      returnObject1.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject1.setHistActionCode(getString (rs, 2)); 
      returnObject1.setHistCreatedBy(getString (rs, 3)); 
      returnObject1.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject1.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject1.setIdentifierIdPK(getLongObject (rs, 6)); 
      returnObject1.setIdStatusTpCd(getLongObject (rs, 7)); 
      returnObject1.setContId(getLongObject (rs, 8)); 
      returnObject1.setIdTpCd(getLongObject (rs, 9)); 
      returnObject1.setRefNum(getString (rs, 10)); 
      returnObject1.setStartDt(getTimestamp (rs, 11)); 
      returnObject1.setEndDt(getTimestamp (rs, 12)); 
      returnObject1.setExpiryDt(getTimestamp (rs, 13)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 14)); 
      returnObject1.setLastUpdateUser(getString (rs, 15)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 16)); 
      returnObject1.setAssignedBy(getLongObject (rs, 17)); 
      returnObject1.setIdentifierDesc(getString (rs, 18)); 
      returnObject1.setIssueLocation(getString (rs, 19)); 
      returnObject1.setLastUsedDt(getTimestamp (rs, 20)); 
      returnObject1.setLastVerifiedDt(getTimestamp (rs, 21)); 
      returnObject1.setSourceIdentTpCd(getLongObject (rs, 22)); 
      returnObject.add (returnObject1);

      EObjXIdentifierExt returnObject2 = new EObjXIdentifierExt ();
      returnObject2.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject2.setHistActionCode(getString (rs, 2)); 
      returnObject2.setHistCreatedBy(getString (rs, 3)); 
      returnObject2.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject2.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject2.setLastUpdateDt(getTimestamp (rs, 14)); 
      returnObject2.setLastUpdateUser(getString (rs, 15)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 16)); 
      returnObject2.setXLastModifiedSystemDate(getTimestamp (rs, 23)); 
      returnObject2.setXRetailerId(getLongObject (rs, 24)); 
      returnObject2.setXIdentifierRetailerFlag(getString (rs, 25)); 
      returnObject2.setX_BPID(getString (rs, 26)); 
      returnObject.add (returnObject2);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT DISTINCT A.H_IDENTIFIER_ID AS HIST_ID_PK, A.H_ACTION_CODE , A.H_CREATED_BY, A.H_CREATE_DT , A.H_END_DT , A.IDENTIFIER_ID , A.ID_STATUS_TP_CD , A.CONT_ID , A.ID_TP_CD , A.REF_NUM , A.START_DT , A.END_DT , A.EXPIRY_DT , A.LAST_UPDATE_DT , A.LAST_UPDATE_USER , A.LAST_UPDATE_TX_ID , A.ASSIGNED_BY , A.IDENTIFIER_DESC , A.ISSUE_LOCATION, A.LAST_USED_DT , A.LAST_VERIFIED_DT , A.SOURCE_IDENT_TP_CD, A.XMODIFY_SYS_DT, A.XRETAILER_ID, A.XIDEN_RETAILER_FLAG, A.X_BPID FROM H_IDENTIFIER A WHERE A.CONT_ID = ? AND ( A.H_CREATE_DT BETWEEN ? AND ? )", pattern="tableAlias (IDENTIFIER => com.dwl.tcrm.coreParty.entityObject.EObjIdentifier, H_IDENTIFIER => com.dwl.tcrm.coreParty.entityObject.EObjIdentifier , IDENTIFIER => com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt , H_IDENTIFIER => com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue2<EObjIdentifier,EObjXIdentifierExt>> getPartyIdentifierImage (Object[] parameters)
  {
    return queryIterator (getPartyIdentifierImageStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getPartyIdentifierImageStatementDescriptor = createStatementDescriptor (
    "getPartyIdentifierImage(Object[])",
    "SELECT DISTINCT A.H_IDENTIFIER_ID AS HIST_ID_PK, A.H_ACTION_CODE , A.H_CREATED_BY, A.H_CREATE_DT , A.H_END_DT , A.IDENTIFIER_ID , A.ID_STATUS_TP_CD , A.CONT_ID , A.ID_TP_CD , A.REF_NUM , A.START_DT , A.END_DT , A.EXPIRY_DT , A.LAST_UPDATE_DT , A.LAST_UPDATE_USER , A.LAST_UPDATE_TX_ID , A.ASSIGNED_BY , A.IDENTIFIER_DESC , A.ISSUE_LOCATION, A.LAST_USED_DT , A.LAST_VERIFIED_DT , A.SOURCE_IDENT_TP_CD, A.XMODIFY_SYS_DT, A.XRETAILER_ID, A.XIDEN_RETAILER_FLAG, A.X_BPID FROM H_IDENTIFIER A WHERE A.CONT_ID = ? AND ( A.H_CREATE_DT BETWEEN ? AND ? )",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"hist_id_pk", "h_action_code", "h_created_by", "h_create_dt", "h_end_dt", "identifier_id", "id_status_tp_cd", "cont_id", "id_tp_cd", "ref_num", "start_dt", "end_dt", "expiry_dt", "last_update_dt", "last_update_user", "last_update_tx_id", "assigned_by", "identifier_desc", "issue_location", "last_used_dt", "last_verified_dt", "source_ident_tp_cd", "xmodify_sys_dt", "xretailer_id", "xiden_retailer_flag", "x_bpid"},
    new GetPartyIdentifierImageParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP}, {19, 0, 0}, {0, 0, 0}, {1, 1, 1}},
    null,
    new GetPartyIdentifierImageRowHandler (),
    new int[][]{ {Types.BIGINT, Types.CHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.TIMESTAMP, Types.BIGINT, Types.VARCHAR, Types.VARCHAR}, {19, 1, 20, 0, 0, 19, 19, 19, 19, 50, 0, 0, 0, 0, 20, 19, 19, 255, 30, 0, 0, 19, 0, 19, 5, 50}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    9);

  /**
   * @generated
   */
  public static class GetPartyIdentifierImageParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetPartyIdentifierImageRowHandler extends BaseRowHandler<ResultQueue2<EObjIdentifier,EObjXIdentifierExt>>
  {
    /**
     * @generated
     */
    public ResultQueue2<EObjIdentifier,EObjXIdentifierExt> handle (java.sql.ResultSet rs, ResultQueue2<EObjIdentifier,EObjXIdentifierExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue2<EObjIdentifier,EObjXIdentifierExt> ();

      EObjIdentifier returnObject1 = new EObjIdentifier ();
      returnObject1.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject1.setHistActionCode(getString (rs, 2)); 
      returnObject1.setHistCreatedBy(getString (rs, 3)); 
      returnObject1.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject1.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject1.setIdentifierIdPK(getLongObject (rs, 6)); 
      returnObject1.setIdStatusTpCd(getLongObject (rs, 7)); 
      returnObject1.setContId(getLongObject (rs, 8)); 
      returnObject1.setIdTpCd(getLongObject (rs, 9)); 
      returnObject1.setRefNum(getString (rs, 10)); 
      returnObject1.setStartDt(getTimestamp (rs, 11)); 
      returnObject1.setEndDt(getTimestamp (rs, 12)); 
      returnObject1.setExpiryDt(getTimestamp (rs, 13)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 14)); 
      returnObject1.setLastUpdateUser(getString (rs, 15)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 16)); 
      returnObject1.setAssignedBy(getLongObject (rs, 17)); 
      returnObject1.setIdentifierDesc(getString (rs, 18)); 
      returnObject1.setIssueLocation(getString (rs, 19)); 
      returnObject1.setLastUsedDt(getTimestamp (rs, 20)); 
      returnObject1.setLastVerifiedDt(getTimestamp (rs, 21)); 
      returnObject1.setSourceIdentTpCd(getLongObject (rs, 22)); 
      returnObject.add (returnObject1);

      EObjXIdentifierExt returnObject2 = new EObjXIdentifierExt ();
      returnObject2.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject2.setHistActionCode(getString (rs, 2)); 
      returnObject2.setHistCreatedBy(getString (rs, 3)); 
      returnObject2.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject2.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject2.setLastUpdateDt(getTimestamp (rs, 14)); 
      returnObject2.setLastUpdateUser(getString (rs, 15)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 16)); 
      returnObject2.setXLastModifiedSystemDate(getTimestamp (rs, 23)); 
      returnObject2.setXRetailerId(getLongObject (rs, 24)); 
      returnObject2.setXIdentifierRetailerFlag(getString (rs, 25)); 
      returnObject2.setX_BPID(getString (rs, 26)); 
      returnObject.add (returnObject2);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT DISTINCT A.IDENTIFIER_ID , A.LAST_UPDATE_DT, A.XMODIFY_SYS_DT, A.XRETAILER_ID, A.XIDEN_RETAILER_FLAG, A.X_BPID FROM H_IDENTIFIER A WHERE A.CONT_ID = ? AND ( A.H_CREATE_DT BETWEEN ? AND ? )", pattern="tableAlias (IDENTIFIER => com.dwl.tcrm.coreParty.entityObject.EObjIdentifier, H_IDENTIFIER => com.dwl.tcrm.coreParty.entityObject.EObjIdentifier , IDENTIFIER => com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt , H_IDENTIFIER => com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue2<EObjIdentifier,EObjXIdentifierExt>> getPartyIdentificationLightImages (Object[] parameters)
  {
    return queryIterator (getPartyIdentificationLightImagesStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getPartyIdentificationLightImagesStatementDescriptor = createStatementDescriptor (
    "getPartyIdentificationLightImages(Object[])",
    "SELECT DISTINCT A.IDENTIFIER_ID , A.LAST_UPDATE_DT, A.XMODIFY_SYS_DT, A.XRETAILER_ID, A.XIDEN_RETAILER_FLAG, A.X_BPID FROM H_IDENTIFIER A WHERE A.CONT_ID = ? AND ( A.H_CREATE_DT BETWEEN ? AND ? )",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"identifier_id", "last_update_dt", "xmodify_sys_dt", "xretailer_id", "xiden_retailer_flag", "x_bpid"},
    new GetPartyIdentificationLightImagesParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP}, {19, 0, 0}, {0, 0, 0}, {1, 1, 1}},
    null,
    new GetPartyIdentificationLightImagesRowHandler (),
    new int[][]{ {Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.VARCHAR, Types.VARCHAR}, {19, 0, 0, 19, 5, 50}, {0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    10);

  /**
   * @generated
   */
  public static class GetPartyIdentificationLightImagesParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetPartyIdentificationLightImagesRowHandler extends BaseRowHandler<ResultQueue2<EObjIdentifier,EObjXIdentifierExt>>
  {
    /**
     * @generated
     */
    public ResultQueue2<EObjIdentifier,EObjXIdentifierExt> handle (java.sql.ResultSet rs, ResultQueue2<EObjIdentifier,EObjXIdentifierExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue2<EObjIdentifier,EObjXIdentifierExt> ();

      EObjIdentifier returnObject1 = new EObjIdentifier ();
      returnObject1.setIdentifierIdPK(getLongObject (rs, 1)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 2)); 
      returnObject.add (returnObject1);

      EObjXIdentifierExt returnObject2 = new EObjXIdentifierExt ();
      returnObject2.setLastUpdateDt(getTimestamp (rs, 2)); 
      returnObject2.setXLastModifiedSystemDate(getTimestamp (rs, 3)); 
      returnObject2.setXRetailerId(getLongObject (rs, 4)); 
      returnObject2.setXIdentifierRetailerFlag(getString (rs, 5)); 
      returnObject2.setX_BPID(getString (rs, 6)); 
      returnObject.add (returnObject2);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT DISTINCT A.H_IDENTIFIER_ID AS HIST_ID_PK, A.H_ACTION_CODE , A.H_CREATED_BY , A.H_CREATE_DT ,A.H_END_DT ,A.IDENTIFIER_ID ,A.ID_STATUS_TP_CD ,A.CONT_ID , A.ID_TP_CD ,A.REF_NUM ,A.START_DT,A.END_DT ,A.EXPIRY_DT , A.LAST_UPDATE_DT , A.LAST_UPDATE_USER , A.LAST_UPDATE_TX_ID , A.ASSIGNED_BY , A.IDENTIFIER_DESC , A.ISSUE_LOCATION, A.XMODIFY_SYS_DT, A.XRETAILER_ID, A.XIDEN_RETAILER_FLAG, A.X_BPID FROM H_IDENTIFIER A WHERE A.ASSIGNED_BY = ? AND (( ? BETWEEN A.H_CREATE_DT AND A.H_END_DT ) OR ( ? >= A.H_CREATE_DT AND A.H_END_DT IS NULL ))", pattern="tableAlias (IDENTIFIER => com.dwl.tcrm.coreParty.entityObject.EObjIdentifier, H_IDENTIFIER => com.dwl.tcrm.coreParty.entityObject.EObjIdentifier , IDENTIFIER => com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt , H_IDENTIFIER => com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue2<EObjIdentifier,EObjXIdentifierExt>> getPartyIdentifiersByAssignedByHistory (Object[] parameters)
  {
    return queryIterator (getPartyIdentifiersByAssignedByHistoryStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getPartyIdentifiersByAssignedByHistoryStatementDescriptor = createStatementDescriptor (
    "getPartyIdentifiersByAssignedByHistory(Object[])",
    "SELECT DISTINCT A.H_IDENTIFIER_ID AS HIST_ID_PK, A.H_ACTION_CODE , A.H_CREATED_BY , A.H_CREATE_DT ,A.H_END_DT ,A.IDENTIFIER_ID ,A.ID_STATUS_TP_CD ,A.CONT_ID , A.ID_TP_CD ,A.REF_NUM ,A.START_DT,A.END_DT ,A.EXPIRY_DT , A.LAST_UPDATE_DT , A.LAST_UPDATE_USER , A.LAST_UPDATE_TX_ID , A.ASSIGNED_BY , A.IDENTIFIER_DESC , A.ISSUE_LOCATION, A.XMODIFY_SYS_DT, A.XRETAILER_ID, A.XIDEN_RETAILER_FLAG, A.X_BPID FROM H_IDENTIFIER A WHERE A.ASSIGNED_BY = ? AND (( ? BETWEEN A.H_CREATE_DT AND A.H_END_DT ) OR ( ? >= A.H_CREATE_DT AND A.H_END_DT IS NULL ))",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"hist_id_pk", "h_action_code", "h_created_by", "h_create_dt", "h_end_dt", "identifier_id", "id_status_tp_cd", "cont_id", "id_tp_cd", "ref_num", "start_dt", "end_dt", "expiry_dt", "last_update_dt", "last_update_user", "last_update_tx_id", "assigned_by", "identifier_desc", "issue_location", "xmodify_sys_dt", "xretailer_id", "xiden_retailer_flag", "x_bpid"},
    new GetPartyIdentifiersByAssignedByHistoryParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP}, {19, 0, 0}, {0, 0, 0}, {1, 1, 1}},
    null,
    new GetPartyIdentifiersByAssignedByHistoryRowHandler (),
    new int[][]{ {Types.BIGINT, Types.CHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.BIGINT, Types.VARCHAR, Types.VARCHAR}, {19, 1, 20, 0, 0, 19, 19, 19, 19, 50, 0, 0, 0, 0, 20, 19, 19, 255, 30, 0, 19, 5, 50}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    11);

  /**
   * @generated
   */
  public static class GetPartyIdentifiersByAssignedByHistoryParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetPartyIdentifiersByAssignedByHistoryRowHandler extends BaseRowHandler<ResultQueue2<EObjIdentifier,EObjXIdentifierExt>>
  {
    /**
     * @generated
     */
    public ResultQueue2<EObjIdentifier,EObjXIdentifierExt> handle (java.sql.ResultSet rs, ResultQueue2<EObjIdentifier,EObjXIdentifierExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue2<EObjIdentifier,EObjXIdentifierExt> ();

      EObjIdentifier returnObject1 = new EObjIdentifier ();
      returnObject1.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject1.setHistActionCode(getString (rs, 2)); 
      returnObject1.setHistCreatedBy(getString (rs, 3)); 
      returnObject1.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject1.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject1.setIdentifierIdPK(getLongObject (rs, 6)); 
      returnObject1.setIdStatusTpCd(getLongObject (rs, 7)); 
      returnObject1.setContId(getLongObject (rs, 8)); 
      returnObject1.setIdTpCd(getLongObject (rs, 9)); 
      returnObject1.setRefNum(getString (rs, 10)); 
      returnObject1.setStartDt(getTimestamp (rs, 11)); 
      returnObject1.setEndDt(getTimestamp (rs, 12)); 
      returnObject1.setExpiryDt(getTimestamp (rs, 13)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 14)); 
      returnObject1.setLastUpdateUser(getString (rs, 15)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 16)); 
      returnObject1.setAssignedBy(getLongObject (rs, 17)); 
      returnObject1.setIdentifierDesc(getString (rs, 18)); 
      returnObject1.setIssueLocation(getString (rs, 19)); 
      returnObject.add (returnObject1);

      EObjXIdentifierExt returnObject2 = new EObjXIdentifierExt ();
      returnObject2.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject2.setHistActionCode(getString (rs, 2)); 
      returnObject2.setHistCreatedBy(getString (rs, 3)); 
      returnObject2.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject2.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject2.setLastUpdateDt(getTimestamp (rs, 14)); 
      returnObject2.setLastUpdateUser(getString (rs, 15)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 16)); 
      returnObject2.setXLastModifiedSystemDate(getTimestamp (rs, 20)); 
      returnObject2.setXRetailerId(getLongObject (rs, 21)); 
      returnObject2.setXIdentifierRetailerFlag(getString (rs, 22)); 
      returnObject2.setX_BPID(getString (rs, 23)); 
      returnObject.add (returnObject2);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT IDENTIFIER.IDENTIFIER_ID , IDENTIFIER.ID_STATUS_TP_CD , IDENTIFIER.CONT_ID , IDENTIFIER.ID_TP_CD , IDENTIFIER.REF_NUM , IDENTIFIER.START_DT , IDENTIFIER.END_DT, IDENTIFIER.EXPIRY_DT , IDENTIFIER.LAST_UPDATE_DT ,IDENTIFIER.LAST_UPDATE_USER , IDENTIFIER.LAST_UPDATE_TX_ID, IDENTIFIER.ASSIGNED_BY , IDENTIFIER.IDENTIFIER_DESC , IDENTIFIER.ISSUE_LOCATION, IDENTIFIER.XMODIFY_SYS_DT, IDENTIFIER.XRETAILER_ID, IDENTIFIER.XIDEN_RETAILER_FLAG, IDENTIFIER.X_BPID FROM IDENTIFIER WHERE ((IDENTIFIER.ASSIGNED_BY = ? ) AND ((IDENTIFIER.END_DT IS NULL) OR (IDENTIFIER.END_DT > ? )))", pattern="tableAlias (IDENTIFIER => com.dwl.tcrm.coreParty.entityObject.EObjIdentifier, H_IDENTIFIER => com.dwl.tcrm.coreParty.entityObject.EObjIdentifier , IDENTIFIER => com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt , H_IDENTIFIER => com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue2<EObjIdentifier,EObjXIdentifierExt>> getPartyIdentifiersByAssignedByActive (Object[] parameters)
  {
    return queryIterator (getPartyIdentifiersByAssignedByActiveStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getPartyIdentifiersByAssignedByActiveStatementDescriptor = createStatementDescriptor (
    "getPartyIdentifiersByAssignedByActive(Object[])",
    "SELECT IDENTIFIER.IDENTIFIER_ID , IDENTIFIER.ID_STATUS_TP_CD , IDENTIFIER.CONT_ID , IDENTIFIER.ID_TP_CD , IDENTIFIER.REF_NUM , IDENTIFIER.START_DT , IDENTIFIER.END_DT, IDENTIFIER.EXPIRY_DT , IDENTIFIER.LAST_UPDATE_DT ,IDENTIFIER.LAST_UPDATE_USER , IDENTIFIER.LAST_UPDATE_TX_ID, IDENTIFIER.ASSIGNED_BY , IDENTIFIER.IDENTIFIER_DESC , IDENTIFIER.ISSUE_LOCATION, IDENTIFIER.XMODIFY_SYS_DT, IDENTIFIER.XRETAILER_ID, IDENTIFIER.XIDEN_RETAILER_FLAG, IDENTIFIER.X_BPID FROM IDENTIFIER WHERE ((IDENTIFIER.ASSIGNED_BY = ? ) AND ((IDENTIFIER.END_DT IS NULL) OR (IDENTIFIER.END_DT > ? )))",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"identifier_id", "id_status_tp_cd", "cont_id", "id_tp_cd", "ref_num", "start_dt", "end_dt", "expiry_dt", "last_update_dt", "last_update_user", "last_update_tx_id", "assigned_by", "identifier_desc", "issue_location", "xmodify_sys_dt", "xretailer_id", "xiden_retailer_flag", "x_bpid"},
    new GetPartyIdentifiersByAssignedByActiveParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP}, {19, 0}, {0, 0}, {1, 1}},
    null,
    new GetPartyIdentifiersByAssignedByActiveRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.BIGINT, Types.VARCHAR, Types.VARCHAR}, {19, 19, 19, 19, 50, 0, 0, 0, 0, 20, 19, 19, 255, 30, 0, 19, 5, 50}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    12);

  /**
   * @generated
   */
  public static class GetPartyIdentifiersByAssignedByActiveParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetPartyIdentifiersByAssignedByActiveRowHandler extends BaseRowHandler<ResultQueue2<EObjIdentifier,EObjXIdentifierExt>>
  {
    /**
     * @generated
     */
    public ResultQueue2<EObjIdentifier,EObjXIdentifierExt> handle (java.sql.ResultSet rs, ResultQueue2<EObjIdentifier,EObjXIdentifierExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue2<EObjIdentifier,EObjXIdentifierExt> ();

      EObjIdentifier returnObject1 = new EObjIdentifier ();
      returnObject1.setIdentifierIdPK(getLongObject (rs, 1)); 
      returnObject1.setIdStatusTpCd(getLongObject (rs, 2)); 
      returnObject1.setContId(getLongObject (rs, 3)); 
      returnObject1.setIdTpCd(getLongObject (rs, 4)); 
      returnObject1.setRefNum(getString (rs, 5)); 
      returnObject1.setStartDt(getTimestamp (rs, 6)); 
      returnObject1.setEndDt(getTimestamp (rs, 7)); 
      returnObject1.setExpiryDt(getTimestamp (rs, 8)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 9)); 
      returnObject1.setLastUpdateUser(getString (rs, 10)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 11)); 
      returnObject1.setAssignedBy(getLongObject (rs, 12)); 
      returnObject1.setIdentifierDesc(getString (rs, 13)); 
      returnObject1.setIssueLocation(getString (rs, 14)); 
      returnObject.add (returnObject1);

      EObjXIdentifierExt returnObject2 = new EObjXIdentifierExt ();
      returnObject2.setLastUpdateDt(getTimestamp (rs, 9)); 
      returnObject2.setLastUpdateUser(getString (rs, 10)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 11)); 
      returnObject2.setXLastModifiedSystemDate(getTimestamp (rs, 15)); 
      returnObject2.setXRetailerId(getLongObject (rs, 16)); 
      returnObject2.setXIdentifierRetailerFlag(getString (rs, 17)); 
      returnObject2.setX_BPID(getString (rs, 18)); 
      returnObject.add (returnObject2);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT IDENTIFIER.IDENTIFIER_ID , IDENTIFIER.ID_STATUS_TP_CD , IDENTIFIER.CONT_ID , IDENTIFIER.ID_TP_CD , IDENTIFIER.REF_NUM , IDENTIFIER.START_DT , IDENTIFIER.END_DT , IDENTIFIER.EXPIRY_DT , IDENTIFIER.LAST_UPDATE_DT , IDENTIFIER.LAST_UPDATE_USER , IDENTIFIER.LAST_UPDATE_TX_ID , IDENTIFIER.ASSIGNED_BY , IDENTIFIER.IDENTIFIER_DESC , IDENTIFIER.ISSUE_LOCATION, IDENTIFIER.XMODIFY_SYS_DT, IDENTIFIER.XRETAILER_ID, IDENTIFIER.XIDEN_RETAILER_FLAG, IDENTIFIER.X_BPID FROM IDENTIFIER WHERE ((IDENTIFIER.ASSIGNED_BY = ? )AND (IDENTIFIER.END_DT < ?))", pattern="tableAlias (IDENTIFIER => com.dwl.tcrm.coreParty.entityObject.EObjIdentifier, H_IDENTIFIER => com.dwl.tcrm.coreParty.entityObject.EObjIdentifier , IDENTIFIER => com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt , H_IDENTIFIER => com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue2<EObjIdentifier,EObjXIdentifierExt>> getPartyIdentifiersByAssignedByInactive (Object[] parameters)
  {
    return queryIterator (getPartyIdentifiersByAssignedByInactiveStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getPartyIdentifiersByAssignedByInactiveStatementDescriptor = createStatementDescriptor (
    "getPartyIdentifiersByAssignedByInactive(Object[])",
    "SELECT IDENTIFIER.IDENTIFIER_ID , IDENTIFIER.ID_STATUS_TP_CD , IDENTIFIER.CONT_ID , IDENTIFIER.ID_TP_CD , IDENTIFIER.REF_NUM , IDENTIFIER.START_DT , IDENTIFIER.END_DT , IDENTIFIER.EXPIRY_DT , IDENTIFIER.LAST_UPDATE_DT , IDENTIFIER.LAST_UPDATE_USER , IDENTIFIER.LAST_UPDATE_TX_ID , IDENTIFIER.ASSIGNED_BY , IDENTIFIER.IDENTIFIER_DESC , IDENTIFIER.ISSUE_LOCATION, IDENTIFIER.XMODIFY_SYS_DT, IDENTIFIER.XRETAILER_ID, IDENTIFIER.XIDEN_RETAILER_FLAG, IDENTIFIER.X_BPID FROM IDENTIFIER WHERE ((IDENTIFIER.ASSIGNED_BY = ? )AND (IDENTIFIER.END_DT < ?))",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"identifier_id", "id_status_tp_cd", "cont_id", "id_tp_cd", "ref_num", "start_dt", "end_dt", "expiry_dt", "last_update_dt", "last_update_user", "last_update_tx_id", "assigned_by", "identifier_desc", "issue_location", "xmodify_sys_dt", "xretailer_id", "xiden_retailer_flag", "x_bpid"},
    new GetPartyIdentifiersByAssignedByInactiveParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP}, {19, 0}, {0, 0}, {1, 1}},
    null,
    new GetPartyIdentifiersByAssignedByInactiveRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.BIGINT, Types.VARCHAR, Types.VARCHAR}, {19, 19, 19, 19, 50, 0, 0, 0, 0, 20, 19, 19, 255, 30, 0, 19, 5, 50}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    13);

  /**
   * @generated
   */
  public static class GetPartyIdentifiersByAssignedByInactiveParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetPartyIdentifiersByAssignedByInactiveRowHandler extends BaseRowHandler<ResultQueue2<EObjIdentifier,EObjXIdentifierExt>>
  {
    /**
     * @generated
     */
    public ResultQueue2<EObjIdentifier,EObjXIdentifierExt> handle (java.sql.ResultSet rs, ResultQueue2<EObjIdentifier,EObjXIdentifierExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue2<EObjIdentifier,EObjXIdentifierExt> ();

      EObjIdentifier returnObject1 = new EObjIdentifier ();
      returnObject1.setIdentifierIdPK(getLongObject (rs, 1)); 
      returnObject1.setIdStatusTpCd(getLongObject (rs, 2)); 
      returnObject1.setContId(getLongObject (rs, 3)); 
      returnObject1.setIdTpCd(getLongObject (rs, 4)); 
      returnObject1.setRefNum(getString (rs, 5)); 
      returnObject1.setStartDt(getTimestamp (rs, 6)); 
      returnObject1.setEndDt(getTimestamp (rs, 7)); 
      returnObject1.setExpiryDt(getTimestamp (rs, 8)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 9)); 
      returnObject1.setLastUpdateUser(getString (rs, 10)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 11)); 
      returnObject1.setAssignedBy(getLongObject (rs, 12)); 
      returnObject1.setIdentifierDesc(getString (rs, 13)); 
      returnObject1.setIssueLocation(getString (rs, 14)); 
      returnObject.add (returnObject1);

      EObjXIdentifierExt returnObject2 = new EObjXIdentifierExt ();
      returnObject2.setLastUpdateDt(getTimestamp (rs, 9)); 
      returnObject2.setLastUpdateUser(getString (rs, 10)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 11)); 
      returnObject2.setXLastModifiedSystemDate(getTimestamp (rs, 15)); 
      returnObject2.setXRetailerId(getLongObject (rs, 16)); 
      returnObject2.setXIdentifierRetailerFlag(getString (rs, 17)); 
      returnObject2.setX_BPID(getString (rs, 18)); 
      returnObject.add (returnObject2);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT IDENTIFIER.IDENTIFIER_ID , IDENTIFIER.ID_STATUS_TP_CD , IDENTIFIER.CONT_ID , IDENTIFIER.ID_TP_CD , IDENTIFIER.REF_NUM , IDENTIFIER.START_DT , IDENTIFIER.END_DT, IDENTIFIER.EXPIRY_DT , IDENTIFIER.LAST_UPDATE_DT , IDENTIFIER.LAST_UPDATE_USER , IDENTIFIER.LAST_UPDATE_TX_ID , IDENTIFIER.ASSIGNED_BY , IDENTIFIER.IDENTIFIER_DESC , IDENTIFIER.ISSUE_LOCATION ,IDENTIFIER.LAST_USED_DT , IDENTIFIER.LAST_VERIFIED_DT , IDENTIFIER.SOURCE_IDENT_TP_CD, IDENTIFIER.XMODIFY_SYS_DT, IDENTIFIER.XRETAILER_ID, IDENTIFIER.XIDEN_RETAILER_FLAG, IDENTIFIER.X_BPID FROM IDENTIFIER WHERE IDENTIFIER.ASSIGNED_BY = ?", pattern="tableAlias (IDENTIFIER => com.dwl.tcrm.coreParty.entityObject.EObjIdentifier, H_IDENTIFIER => com.dwl.tcrm.coreParty.entityObject.EObjIdentifier , IDENTIFIER => com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt , H_IDENTIFIER => com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue2<EObjIdentifier,EObjXIdentifierExt>> getPartyIdentifiersByAssignedByAll (Object[] parameters)
  {
    return queryIterator (getPartyIdentifiersByAssignedByAllStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getPartyIdentifiersByAssignedByAllStatementDescriptor = createStatementDescriptor (
    "getPartyIdentifiersByAssignedByAll(Object[])",
    "SELECT IDENTIFIER.IDENTIFIER_ID , IDENTIFIER.ID_STATUS_TP_CD , IDENTIFIER.CONT_ID , IDENTIFIER.ID_TP_CD , IDENTIFIER.REF_NUM , IDENTIFIER.START_DT , IDENTIFIER.END_DT, IDENTIFIER.EXPIRY_DT , IDENTIFIER.LAST_UPDATE_DT , IDENTIFIER.LAST_UPDATE_USER , IDENTIFIER.LAST_UPDATE_TX_ID , IDENTIFIER.ASSIGNED_BY , IDENTIFIER.IDENTIFIER_DESC , IDENTIFIER.ISSUE_LOCATION ,IDENTIFIER.LAST_USED_DT , IDENTIFIER.LAST_VERIFIED_DT , IDENTIFIER.SOURCE_IDENT_TP_CD, IDENTIFIER.XMODIFY_SYS_DT, IDENTIFIER.XRETAILER_ID, IDENTIFIER.XIDEN_RETAILER_FLAG, IDENTIFIER.X_BPID FROM IDENTIFIER WHERE IDENTIFIER.ASSIGNED_BY = ?",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"identifier_id", "id_status_tp_cd", "cont_id", "id_tp_cd", "ref_num", "start_dt", "end_dt", "expiry_dt", "last_update_dt", "last_update_user", "last_update_tx_id", "assigned_by", "identifier_desc", "issue_location", "last_used_dt", "last_verified_dt", "source_ident_tp_cd", "xmodify_sys_dt", "xretailer_id", "xiden_retailer_flag", "x_bpid"},
    new GetPartyIdentifiersByAssignedByAllParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetPartyIdentifiersByAssignedByAllRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.TIMESTAMP, Types.BIGINT, Types.VARCHAR, Types.VARCHAR}, {19, 19, 19, 19, 50, 0, 0, 0, 0, 20, 19, 19, 255, 30, 0, 0, 19, 0, 19, 5, 50}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    14);

  /**
   * @generated
   */
  public static class GetPartyIdentifiersByAssignedByAllParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetPartyIdentifiersByAssignedByAllRowHandler extends BaseRowHandler<ResultQueue2<EObjIdentifier,EObjXIdentifierExt>>
  {
    /**
     * @generated
     */
    public ResultQueue2<EObjIdentifier,EObjXIdentifierExt> handle (java.sql.ResultSet rs, ResultQueue2<EObjIdentifier,EObjXIdentifierExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue2<EObjIdentifier,EObjXIdentifierExt> ();

      EObjIdentifier returnObject1 = new EObjIdentifier ();
      returnObject1.setIdentifierIdPK(getLongObject (rs, 1)); 
      returnObject1.setIdStatusTpCd(getLongObject (rs, 2)); 
      returnObject1.setContId(getLongObject (rs, 3)); 
      returnObject1.setIdTpCd(getLongObject (rs, 4)); 
      returnObject1.setRefNum(getString (rs, 5)); 
      returnObject1.setStartDt(getTimestamp (rs, 6)); 
      returnObject1.setEndDt(getTimestamp (rs, 7)); 
      returnObject1.setExpiryDt(getTimestamp (rs, 8)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 9)); 
      returnObject1.setLastUpdateUser(getString (rs, 10)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 11)); 
      returnObject1.setAssignedBy(getLongObject (rs, 12)); 
      returnObject1.setIdentifierDesc(getString (rs, 13)); 
      returnObject1.setIssueLocation(getString (rs, 14)); 
      returnObject1.setLastUsedDt(getTimestamp (rs, 15)); 
      returnObject1.setLastVerifiedDt(getTimestamp (rs, 16)); 
      returnObject1.setSourceIdentTpCd(getLongObject (rs, 17)); 
      returnObject.add (returnObject1);

      EObjXIdentifierExt returnObject2 = new EObjXIdentifierExt ();
      returnObject2.setLastUpdateDt(getTimestamp (rs, 9)); 
      returnObject2.setLastUpdateUser(getString (rs, 10)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 11)); 
      returnObject2.setXLastModifiedSystemDate(getTimestamp (rs, 18)); 
      returnObject2.setXRetailerId(getLongObject (rs, 19)); 
      returnObject2.setXIdentifierRetailerFlag(getString (rs, 20)); 
      returnObject2.setX_BPID(getString (rs, 21)); 
      returnObject.add (returnObject2);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT I.IDENTIFIER_ID , I.ID_STATUS_TP_CD , I.CONT_ID , I.ID_TP_CD , I.REF_NUM, I.START_DT , I.END_DT , I.EXPIRY_DT , I.LAST_UPDATE_DT ,I.LAST_UPDATE_USER , I.LAST_UPDATE_TX_ID , I.ASSIGNED_BY , I.IDENTIFIER_DESC , I.ISSUE_LOCATION , I.LAST_USED_DT , I.LAST_VERIFIED_DT, I.SOURCE_IDENT_TP_CD, I.XMODIFY_SYS_DT, I.XRETAILER_ID, I.XIDEN_RETAILER_FLAG, I.X_BPID FROM IDENTIFIER I, CONTMACROROLE MR, MACROROLEASSOC MRA WHERE I.CONT_ID = MR.CONT_ID AND MR.CONT_MACRO_ROLE_ID = MRA.CONT_MACRO_ROLE_ID AND UPPER(MRA.ENTITY_NAME) = 'IDENTIFIER' AND I.IDENTIFIER_ID = MRA.INSTANCE_PK AND I.CONT_ID = ? AND I.ID_TP_CD = ? AND MR.ROLE_TP_CD=? AND (I.END_DT IS NULL OR I.END_DT > ?)", pattern="tableAlias (IDENTIFIER => com.dwl.tcrm.coreParty.entityObject.EObjIdentifier, H_IDENTIFIER => com.dwl.tcrm.coreParty.entityObject.EObjIdentifier , IDENTIFIER => com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt , H_IDENTIFIER => com.ibm.daimler.dsea.entityObject.EObjXIdentifierExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue2<EObjIdentifier,EObjXIdentifierExt>> getPartyIdentifierMacroRole (Object[] parameters)
  {
    return queryIterator (getPartyIdentifierMacroRoleStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getPartyIdentifierMacroRoleStatementDescriptor = createStatementDescriptor (
    "getPartyIdentifierMacroRole(Object[])",
    "SELECT I.IDENTIFIER_ID , I.ID_STATUS_TP_CD , I.CONT_ID , I.ID_TP_CD , I.REF_NUM, I.START_DT , I.END_DT , I.EXPIRY_DT , I.LAST_UPDATE_DT ,I.LAST_UPDATE_USER , I.LAST_UPDATE_TX_ID , I.ASSIGNED_BY , I.IDENTIFIER_DESC , I.ISSUE_LOCATION , I.LAST_USED_DT , I.LAST_VERIFIED_DT, I.SOURCE_IDENT_TP_CD, I.XMODIFY_SYS_DT, I.XRETAILER_ID, I.XIDEN_RETAILER_FLAG, I.X_BPID FROM IDENTIFIER I, CONTMACROROLE MR, MACROROLEASSOC MRA WHERE I.CONT_ID = MR.CONT_ID AND MR.CONT_MACRO_ROLE_ID = MRA.CONT_MACRO_ROLE_ID AND UPPER(MRA.ENTITY_NAME) = 'IDENTIFIER' AND I.IDENTIFIER_ID = MRA.INSTANCE_PK AND I.CONT_ID = ? AND I.ID_TP_CD = ? AND MR.ROLE_TP_CD=? AND (I.END_DT IS NULL OR I.END_DT > ?)",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"identifier_id", "id_status_tp_cd", "cont_id", "id_tp_cd", "ref_num", "start_dt", "end_dt", "expiry_dt", "last_update_dt", "last_update_user", "last_update_tx_id", "assigned_by", "identifier_desc", "issue_location", "last_used_dt", "last_verified_dt", "source_ident_tp_cd", "xmodify_sys_dt", "xretailer_id", "xiden_retailer_flag", "x_bpid"},
    new GetPartyIdentifierMacroRoleParameterHandler (),
    new int[][]{{Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP}, {19, 19, 19, 0}, {0, 0, 0, 0}, {1, 1, 1, 1}},
    null,
    new GetPartyIdentifierMacroRoleRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.TIMESTAMP, Types.BIGINT, Types.VARCHAR, Types.VARCHAR}, {19, 19, 19, 19, 50, 0, 0, 0, 0, 20, 19, 19, 255, 30, 0, 0, 19, 0, 19, 5, 50}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    15);

  /**
   * @generated
   */
  public static class GetPartyIdentifierMacroRoleParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.BIGINT, parameters[1], 0);
      setObject (stmt, 3, Types.BIGINT, parameters[2], 0);
      setObject (stmt, 4, Types.TIMESTAMP, parameters[3], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetPartyIdentifierMacroRoleRowHandler extends BaseRowHandler<ResultQueue2<EObjIdentifier,EObjXIdentifierExt>>
  {
    /**
     * @generated
     */
    public ResultQueue2<EObjIdentifier,EObjXIdentifierExt> handle (java.sql.ResultSet rs, ResultQueue2<EObjIdentifier,EObjXIdentifierExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue2<EObjIdentifier,EObjXIdentifierExt> ();

      EObjIdentifier returnObject1 = new EObjIdentifier ();
      returnObject1.setIdentifierIdPK(getLongObject (rs, 1)); 
      returnObject1.setIdStatusTpCd(getLongObject (rs, 2)); 
      returnObject1.setContId(getLongObject (rs, 3)); 
      returnObject1.setIdTpCd(getLongObject (rs, 4)); 
      returnObject1.setRefNum(getString (rs, 5)); 
      returnObject1.setStartDt(getTimestamp (rs, 6)); 
      returnObject1.setEndDt(getTimestamp (rs, 7)); 
      returnObject1.setExpiryDt(getTimestamp (rs, 8)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 9)); 
      returnObject1.setLastUpdateUser(getString (rs, 10)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 11)); 
      returnObject1.setAssignedBy(getLongObject (rs, 12)); 
      returnObject1.setIdentifierDesc(getString (rs, 13)); 
      returnObject1.setIssueLocation(getString (rs, 14)); 
      returnObject1.setLastUsedDt(getTimestamp (rs, 15)); 
      returnObject1.setLastVerifiedDt(getTimestamp (rs, 16)); 
      returnObject1.setSourceIdentTpCd(getLongObject (rs, 17)); 
      returnObject.add (returnObject1);

      EObjXIdentifierExt returnObject2 = new EObjXIdentifierExt ();
      returnObject2.setLastUpdateDt(getTimestamp (rs, 9)); 
      returnObject2.setLastUpdateUser(getString (rs, 10)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 11)); 
      returnObject2.setXLastModifiedSystemDate(getTimestamp (rs, 18)); 
      returnObject2.setXRetailerId(getLongObject (rs, 19)); 
      returnObject2.setXIdentifierRetailerFlag(getString (rs, 20)); 
      returnObject2.setX_BPID(getString (rs, 21)); 
      returnObject.add (returnObject2);

    
      return returnObject;
    }
  }

}
