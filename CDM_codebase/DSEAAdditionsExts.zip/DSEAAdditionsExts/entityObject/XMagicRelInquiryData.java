/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[2e7d7d48d6dc1bf7b741fa44801b93b9]
 */

package com.ibm.daimler.dsea.entityObject;


import com.ibm.mdm.base.db.ResultQueue1;
import java.util.Iterator;
import com.ibm.mdm.base.db.EntityMapping;
import com.ibm.pdq.annotation.Select;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * @generated
 */
public interface XMagicRelInquiryData {
  
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String tableAliasString = "tableAlias (" + 
                                            "XMAGICREL => com.ibm.daimler.dsea.entityObject.EObjXMagicRel, " +
                                            "H_XMAGICREL => com.ibm.daimler.dsea.entityObject.EObjXMagicRel" +
                                            ")";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getXMagicRelSql = "SELECT r.XMagic_Relpk_Id XMagic_Relpk_Id, r.UCID UCID, r.Golden_Magic Golden_Magic, r.Old_Magic Old_Magic, r.Old_Magic_Retailer Old_Magic_Retailer, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XMAGICREL r WHERE r.XMagic_Relpk_Id = ? ";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXMagicRelParameters =
    "EObjXMagicRel.XMagicRelpkId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXMagicRelResults =
    "EObjXMagicRel.XMagicRelpkId," +
    "EObjXMagicRel.UCID," +
    "EObjXMagicRel.GoldenMagic," +
    "EObjXMagicRel.OldMagic," +
    "EObjXMagicRel.OldMagicRetailer," +
    "EObjXMagicRel.lastUpdateDt," +
    "EObjXMagicRel.lastUpdateUser," +
    "EObjXMagicRel.lastUpdateTxId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getXMagicRelHistorySql = "SELECT r.H_XMagic_Relpk_Id hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.XMagic_Relpk_Id XMagic_Relpk_Id, r.UCID UCID, r.Golden_Magic Golden_Magic, r.Old_Magic Old_Magic, r.Old_Magic_Retailer Old_Magic_Retailer, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XMAGICREL r WHERE r.H_XMagic_Relpk_Id = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXMagicRelHistoryParameters =
    "EObjXMagicRel.XMagicRelpkId," +
    "EObjXMagicRel.lastUpdateDt," +
    "EObjXMagicRel.lastUpdateDt";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXMagicRelHistoryResults =
    "EObjXMagicRel.historyIdPK," +
    "EObjXMagicRel.histActionCode," +
    "EObjXMagicRel.histCreatedBy," +
    "EObjXMagicRel.histCreateDt," +
    "EObjXMagicRel.histEndDt," +
    "EObjXMagicRel.XMagicRelpkId," +
    "EObjXMagicRel.UCID," +
    "EObjXMagicRel.GoldenMagic," +
    "EObjXMagicRel.OldMagic," +
    "EObjXMagicRel.OldMagicRetailer," +
    "EObjXMagicRel.lastUpdateDt," +
    "EObjXMagicRel.lastUpdateUser," +
    "EObjXMagicRel.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getXMagicRelSql, pattern=tableAliasString)
  @EntityMapping(parameters=getXMagicRelParameters, results=getXMagicRelResults)
  Iterator<ResultQueue1<EObjXMagicRel>> getXMagicRel(Object[] parameters);  


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getXMagicRelHistorySql, pattern=tableAliasString)
  @EntityMapping(parameters=getXMagicRelHistoryParameters, results=getXMagicRelHistoryResults)
  Iterator<ResultQueue1<EObjXMagicRel>> getXMagicRelHistory(Object[] parameters);  


}


