/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[03fd02fdc25d6bd82a8f2f89eb23df39]
 */


package com.ibm.daimler.dsea.entityObject;

import java.util.Iterator;
import com.ibm.mdm.base.db.EntityMapping;
import com.ibm.pdq.annotation.Select;
import com.ibm.pdq.annotation.Update;

import com.dwl.tcrm.coreParty.entityObject.EObjContactRel;

import com.ibm.daimler.dsea.entityObject.EObjXContactRelExt;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * @generated
 */
public interface EObjXContactRelExtData {


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjXContactRelExtSql = "select XRETAILER_CODE, XCONTACT_ROLE, XCONTACT_POSITION, XCONTACTREL_RETAILER_FLAG, XSOURCE_IDENT_TP_CD, XMODIFY_SYS_DT, DELETE_FLAG, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from CONTACTREL where CONT_REL_ID = ? ";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String createEObjXContactRelExtSql = "insert into CONTACTREL (END_DT, CONT_REL_ID, REL_DESC, FROM_CONT_ID, TO_CONT_ID, START_DT, REL_TP_CD, END_REASON_TP_CD, REL_ASSIGN_TP_CD, XRETAILER_CODE, XCONTACT_ROLE, XCONTACT_POSITION, XCONTACTREL_RETAILER_FLAG, XSOURCE_IDENT_TP_CD, XMODIFY_SYS_DT, DELETE_FLAG, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( ?1.endDt, ?1.contRelIdPK, ?1.relDesc, ?1.fromContId, ?1.toContId, ?1.startDt, ?1.relTpCd, ?1.endReasonTpCd, ?1.relAssignTpCd, ?2.xRetailerCode, ?2.xContactRole, ?2.xContactPosition, ?2.xContactRelRetailerFlag, ?2.xSourceIdentifier, ?2.xLastModifiedSystemDate, ?2.deleteFlag, ?1.lastUpdateDt, ?1.lastUpdateUser, ?1.lastUpdateTxId)";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String updateEObjXContactRelExtSql = "update CONTACTREL set END_DT = ?1.endDt, REL_DESC = ?1.relDesc, FROM_CONT_ID = ?1.fromContId, TO_CONT_ID = ?1.toContId, START_DT = ?1.startDt, REL_TP_CD = ?1.relTpCd, END_REASON_TP_CD = ?1.endReasonTpCd, REL_ASSIGN_TP_CD = ?1.relAssignTpCd, XRETAILER_CODE = ?2.xRetailerCode, XCONTACT_ROLE = ?2.xContactRole, XCONTACT_POSITION = ?2.xContactPosition, XCONTACTREL_RETAILER_FLAG = ?2.xContactRelRetailerFlag, XSOURCE_IDENT_TP_CD = ?2.xSourceIdentifier, XMODIFY_SYS_DT = ?2.xLastModifiedSystemDate, DELETE_FLAG = ?2.deleteFlag, LAST_UPDATE_DT = ?1.lastUpdateDt, LAST_UPDATE_USER = ?1.lastUpdateUser, LAST_UPDATE_TX_ID = ?1.lastUpdateTxId where CONT_REL_ID = ?1.contRelIdPK and LAST_UPDATE_DT = ?1.oldLastUpdateDt";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String deleteEObjXContactRelExtSql = "delete from CONTACTREL where CONT_REL_ID = ?";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXContactRelExtKeyField = "EObjXContactRelExt.contRelIdPK";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXContactRelExtGetFields =
    "EObjXContactRelExt.xRetailerCode," +
    "EObjXContactRelExt.xContactRole," +
    "EObjXContactRelExt.xContactPosition," +
    "EObjXContactRelExt.xContactRelRetailerFlag," +
    "EObjXContactRelExt.xSourceIdentifier," +
    "EObjXContactRelExt.xLastModifiedSystemDate," +
    "EObjXContactRelExt.deleteFlag," +
    "EObjXContactRelExt.lastUpdateDt," +
    "EObjXContactRelExt.lastUpdateUser," +
    "EObjXContactRelExt.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXContactRelExtAllFields =
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.endDt," +
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.contRelIdPK," +
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.relDesc," +
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.fromContId," +
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.toContId," +
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.startDt," +
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.relTpCd," +
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.endReasonTpCd," +
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.relAssignTpCd," +
    "com.ibm.daimler.dsea.entityObject.EObjXContactRelExt.xRetailerCode," +
    "com.ibm.daimler.dsea.entityObject.EObjXContactRelExt.xContactRole," +
    "com.ibm.daimler.dsea.entityObject.EObjXContactRelExt.xContactPosition," +
    "com.ibm.daimler.dsea.entityObject.EObjXContactRelExt.xContactRelRetailerFlag," +
    "com.ibm.daimler.dsea.entityObject.EObjXContactRelExt.xSourceIdentifier," +
    "com.ibm.daimler.dsea.entityObject.EObjXContactRelExt.xLastModifiedSystemDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXContactRelExt.deleteFlag," +
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.lastUpdateDt," +
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.lastUpdateUser," +
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXContactRelExtUpdateFields =
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.endDt," +
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.relDesc," +
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.fromContId," +
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.toContId," +
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.startDt," +
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.relTpCd," +
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.endReasonTpCd," +
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.relAssignTpCd," +
    "com.ibm.daimler.dsea.entityObject.EObjXContactRelExt.xRetailerCode," +
    "com.ibm.daimler.dsea.entityObject.EObjXContactRelExt.xContactRole," +
    "com.ibm.daimler.dsea.entityObject.EObjXContactRelExt.xContactPosition," +
    "com.ibm.daimler.dsea.entityObject.EObjXContactRelExt.xContactRelRetailerFlag," +
    "com.ibm.daimler.dsea.entityObject.EObjXContactRelExt.xSourceIdentifier," +
    "com.ibm.daimler.dsea.entityObject.EObjXContactRelExt.xLastModifiedSystemDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXContactRelExt.deleteFlag," +
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.lastUpdateDt," +
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.lastUpdateUser," +
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.lastUpdateTxId," +
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.contRelIdPK," +
    "com.dwl.tcrm.coreParty.entityObject.EObjContactRel.oldLastUpdateDt";   

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Select XContactRel by parameters.
   * @generated
   */
  @Select(sql=getEObjXContactRelExtSql)
  @EntityMapping(parameters=EObjXContactRelExtKeyField, results=EObjXContactRelExtGetFields)
  Iterator<EObjXContactRelExt> getEObjXContactRelExt(Long contRelIdPK);  
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Create XContactRel by EObjXContactRelExt Object.
   * @generated
   */
  @Update(sql=createEObjXContactRelExtSql)
  @EntityMapping(parameters=EObjXContactRelExtAllFields)
    int createEObjXContactRelExt(EObjContactRel e1, EObjXContactRelExt e2); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Update one XContactRel by EObjXContactRelExt object.
   * @generated
   */
  @Update(sql=updateEObjXContactRelExtSql)
  @EntityMapping(parameters=EObjXContactRelExtUpdateFields)
    int updateEObjXContactRelExt(EObjContactRel e1, EObjXContactRelExt e2); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Delete XContactRel by parameters.
   * @generated
   */
  @Update(sql=deleteEObjXContactRelExtSql)
  @EntityMapping(parameters=EObjXContactRelExtKeyField)
  int deleteEObjXContactRelExt(Long contRelIdPK);

}

