/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[239cf2264a71d121293086f7de22af44]
 */

package com.ibm.daimler.dsea.entityObject;


import com.ibm.mdm.base.db.ResultQueue1;
import java.util.Iterator;
import com.ibm.mdm.base.db.EntityMapping;
import com.ibm.pdq.annotation.Select;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * @generated
 */
public interface XCustomerVehicleRoleJPNInquiryData {
  
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String tableAliasString = "tableAlias (" + 
                                            "XCUSTOMERVEHICLEROLEJPN => com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRoleJPN, " +
                                            "H_XCUSTOMERVEHICLEROLEJPN => com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRoleJPN" +
                                            ")";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getXCustomerVehicleRoleJPNSql = "SELECT r.XCUSTOMERVEHICLEROLEJPNPK_ID XCUSTOMERVEHICLEROLEJPNPK_ID, r.CUSTOMER_VEHICLE_ID CUSTOMER_VEHICLE_ID, r.VEHICLE_ROLE_TP_CD VEHICLE_ROLE_TP_CD, r.START_DT START_DT, r.END_DT END_DT, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.CHANGED_DT CHANGED_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XCUSTOMERVEHICLEROLEJPN r WHERE r.XCUSTOMERVEHICLEROLEJPNPK_ID = ? ";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXCustomerVehicleRoleJPNParameters =
    "EObjXCustomerVehicleRoleJPN.XCustomerVehicleRoleJPNpkId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXCustomerVehicleRoleJPNResults =
    "EObjXCustomerVehicleRoleJPN.XCustomerVehicleRoleJPNpkId," +
    "EObjXCustomerVehicleRoleJPN.CustomerVehicleId," +
    "EObjXCustomerVehicleRoleJPN.VehicleRole," +
    "EObjXCustomerVehicleRoleJPN.StartDate," +
    "EObjXCustomerVehicleRoleJPN.EndDate," +
    "EObjXCustomerVehicleRoleJPN.SourceIdentifier," +
    "EObjXCustomerVehicleRoleJPN.ChangedDate," +
    "EObjXCustomerVehicleRoleJPN.lastUpdateDt," +
    "EObjXCustomerVehicleRoleJPN.lastUpdateUser," +
    "EObjXCustomerVehicleRoleJPN.lastUpdateTxId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getXCustomerVehicleRoleJPNHistorySql = "SELECT r.H_XCUSTOMERVEHICLEROLEJPNPK_ID hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.XCUSTOMERVEHICLEROLEJPNPK_ID XCUSTOMERVEHICLEROLEJPNPK_ID, r.CUSTOMER_VEHICLE_ID CUSTOMER_VEHICLE_ID, r.VEHICLE_ROLE_TP_CD VEHICLE_ROLE_TP_CD, r.START_DT START_DT, r.END_DT END_DT, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.CHANGED_DT CHANGED_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XCUSTOMERVEHICLEROLEJPN r WHERE r.H_XCUSTOMERVEHICLEROLEJPNPK_ID = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXCustomerVehicleRoleJPNHistoryParameters =
    "EObjXCustomerVehicleRoleJPN.XCustomerVehicleRoleJPNpkId," +
    "EObjXCustomerVehicleRoleJPN.lastUpdateDt," +
    "EObjXCustomerVehicleRoleJPN.lastUpdateDt";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXCustomerVehicleRoleJPNHistoryResults =
    "EObjXCustomerVehicleRoleJPN.historyIdPK," +
    "EObjXCustomerVehicleRoleJPN.histActionCode," +
    "EObjXCustomerVehicleRoleJPN.histCreatedBy," +
    "EObjXCustomerVehicleRoleJPN.histCreateDt," +
    "EObjXCustomerVehicleRoleJPN.histEndDt," +
    "EObjXCustomerVehicleRoleJPN.XCustomerVehicleRoleJPNpkId," +
    "EObjXCustomerVehicleRoleJPN.CustomerVehicleId," +
    "EObjXCustomerVehicleRoleJPN.VehicleRole," +
    "EObjXCustomerVehicleRoleJPN.StartDate," +
    "EObjXCustomerVehicleRoleJPN.EndDate," +
    "EObjXCustomerVehicleRoleJPN.SourceIdentifier," +
    "EObjXCustomerVehicleRoleJPN.ChangedDate," +
    "EObjXCustomerVehicleRoleJPN.lastUpdateDt," +
    "EObjXCustomerVehicleRoleJPN.lastUpdateUser," +
    "EObjXCustomerVehicleRoleJPN.lastUpdateTxId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getAllVehicleRoleByCustomerVehicleJPNIdSql = "SELECT r.XCUSTOMERVEHICLEROLEJPNPK_ID XCUSTOMERVEHICLEROLEJPNPK_ID, r.CUSTOMER_VEHICLE_ID CUSTOMER_VEHICLE_ID, r.VEHICLE_ROLE_TP_CD VEHICLE_ROLE_TP_CD, r.START_DT START_DT, r.END_DT END_DT, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.CHANGED_DT CHANGED_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XCUSTOMERVEHICLEROLEJPN r WHERE r.CUSTOMER_VEHICLE_ID = ? ";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getAllVehicleRoleByCustomerVehicleJPNIdParameters =
    "EObjXCustomerVehicleRoleJPN.CustomerVehicleId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getAllVehicleRoleByCustomerVehicleJPNIdResults =
    "EObjXCustomerVehicleRoleJPN.XCustomerVehicleRoleJPNpkId," +
    "EObjXCustomerVehicleRoleJPN.CustomerVehicleId," +
    "EObjXCustomerVehicleRoleJPN.VehicleRole," +
    "EObjXCustomerVehicleRoleJPN.StartDate," +
    "EObjXCustomerVehicleRoleJPN.EndDate," +
    "EObjXCustomerVehicleRoleJPN.SourceIdentifier," +
    "EObjXCustomerVehicleRoleJPN.ChangedDate," +
    "EObjXCustomerVehicleRoleJPN.lastUpdateDt," +
    "EObjXCustomerVehicleRoleJPN.lastUpdateUser," +
    "EObjXCustomerVehicleRoleJPN.lastUpdateTxId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getAllVehicleRoleByCustomerVehicleJPNIdHistorySql = "SELECT r.H_XCUSTOMERVEHICLEROLEJPNPK_ID hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.XCUSTOMERVEHICLEROLEJPNPK_ID XCUSTOMERVEHICLEROLEJPNPK_ID, r.CUSTOMER_VEHICLE_ID CUSTOMER_VEHICLE_ID, r.VEHICLE_ROLE_TP_CD VEHICLE_ROLE_TP_CD, r.START_DT START_DT, r.END_DT END_DT, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.CHANGED_DT CHANGED_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XCUSTOMERVEHICLEROLEJPN r WHERE r.CUSTOMER_VEHICLE_ID = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getAllVehicleRoleByCustomerVehicleJPNIdHistoryParameters =
    "EObjXCustomerVehicleRoleJPN.CustomerVehicleId," +
    "EObjXCustomerVehicleRoleJPN.lastUpdateDt," +
    "EObjXCustomerVehicleRoleJPN.lastUpdateDt";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getAllVehicleRoleByCustomerVehicleJPNIdHistoryResults =
    "EObjXCustomerVehicleRoleJPN.historyIdPK," +
    "EObjXCustomerVehicleRoleJPN.histActionCode," +
    "EObjXCustomerVehicleRoleJPN.histCreatedBy," +
    "EObjXCustomerVehicleRoleJPN.histCreateDt," +
    "EObjXCustomerVehicleRoleJPN.histEndDt," +
    "EObjXCustomerVehicleRoleJPN.XCustomerVehicleRoleJPNpkId," +
    "EObjXCustomerVehicleRoleJPN.CustomerVehicleId," +
    "EObjXCustomerVehicleRoleJPN.VehicleRole," +
    "EObjXCustomerVehicleRoleJPN.StartDate," +
    "EObjXCustomerVehicleRoleJPN.EndDate," +
    "EObjXCustomerVehicleRoleJPN.SourceIdentifier," +
    "EObjXCustomerVehicleRoleJPN.ChangedDate," +
    "EObjXCustomerVehicleRoleJPN.lastUpdateDt," +
    "EObjXCustomerVehicleRoleJPN.lastUpdateUser," +
    "EObjXCustomerVehicleRoleJPN.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getXCustomerVehicleRoleJPNSql, pattern=tableAliasString)
  @EntityMapping(parameters=getXCustomerVehicleRoleJPNParameters, results=getXCustomerVehicleRoleJPNResults)
  Iterator<ResultQueue1<EObjXCustomerVehicleRoleJPN>> getXCustomerVehicleRoleJPN(Object[] parameters);  


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getXCustomerVehicleRoleJPNHistorySql, pattern=tableAliasString)
  @EntityMapping(parameters=getXCustomerVehicleRoleJPNHistoryParameters, results=getXCustomerVehicleRoleJPNHistoryResults)
  Iterator<ResultQueue1<EObjXCustomerVehicleRoleJPN>> getXCustomerVehicleRoleJPNHistory(Object[] parameters);  


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getAllVehicleRoleByCustomerVehicleJPNIdSql, pattern=tableAliasString)
  @EntityMapping(parameters=getAllVehicleRoleByCustomerVehicleJPNIdParameters, results=getAllVehicleRoleByCustomerVehicleJPNIdResults)
  Iterator<ResultQueue1<EObjXCustomerVehicleRoleJPN>> getAllVehicleRoleByCustomerVehicleJPNId(Object[] parameters);  


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getAllVehicleRoleByCustomerVehicleJPNIdHistorySql, pattern=tableAliasString)
  @EntityMapping(parameters=getAllVehicleRoleByCustomerVehicleJPNIdHistoryParameters, results=getAllVehicleRoleByCustomerVehicleJPNIdHistoryResults)
  Iterator<ResultQueue1<EObjXCustomerVehicleRoleJPN>> getAllVehicleRoleByCustomerVehicleJPNIdHistory(Object[] parameters);  


}


