/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[561bd2e7931c54fb56de24edbf1af498]
 */

package com.ibm.daimler.dsea.entityObject;


import com.ibm.mdm.base.db.ResultQueue1;
import java.util.Iterator;
import com.ibm.mdm.base.db.EntityMapping;
import com.ibm.pdq.annotation.Select;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * @generated
 */
public interface XVehicleInquiryData {
  
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String tableAliasString = "tableAlias (" + 
                                            "XVEHICLE => com.ibm.daimler.dsea.entityObject.EObjXVehicle, " +
                                            "H_XVEHICLE => com.ibm.daimler.dsea.entityObject.EObjXVehicle" +
                                            ")";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getXVehicleSql = "SELECT r.VEHICLEPK_ID VEHICLEPK_ID, r.DIVISION DIVISION, r.BUSINESS_UNIT BUSINESS_UNIT, r.ACTIVITY ACTIVITY, r.TYPE_CLASS TYPE_CLASS, r.BAU_RELHE BAU_RELHE, r.BAU_MUSTER BAU_MUSTER, r.SUB_MUSTER SUB_MUSTER, r.ENGINE_NUM ENGINE_NUM, r.COUNTRY_TP_CD COUNTRY_TP_CD, r.COLOR COLOR, r.TRIM TRIM, r.GLOBAL_VIN GLOBAL_VIN, r.LOCAL_VIN LOCAL_VIN, r.LICENSE_PLATE LICENSE_PLATE, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.CREATE_DT CREATE_DT, r.CHANGED_DT CHANGED_DT, r.LAST_SERVICE_DT LAST_SERVICE_DT, r.Market_Name Market_Name, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XVEHICLE r WHERE r.VEHICLEPK_ID = ? ";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXVehicleParameters =
    "EObjXVehicle.VehiclepkId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXVehicleResults =
    "EObjXVehicle.VehiclepkId," +
    "EObjXVehicle.Division," +
    "EObjXVehicle.BusinessUnit," +
    "EObjXVehicle.Activity," +
    "EObjXVehicle.TypeClass," +
    "EObjXVehicle.BauRelhe," +
    "EObjXVehicle.BauMuster," +
    "EObjXVehicle.SubMuster," +
    "EObjXVehicle.EngineNumber," +
    "EObjXVehicle.Country," +
    "EObjXVehicle.Color," +
    "EObjXVehicle.Trim," +
    "EObjXVehicle.GlobalVIN," +
    "EObjXVehicle.LocalVIN," +
    "EObjXVehicle.LicensePlate," +
    "EObjXVehicle.SourceIdentifier," +
    "EObjXVehicle.LastModifiedSystemDate," +
    "EObjXVehicle.CreateDate," +
    "EObjXVehicle.ChangedDate," +
    "EObjXVehicle.LastServiceDate," +
    "EObjXVehicle.MarketName," +
    "EObjXVehicle.lastUpdateDt," +
    "EObjXVehicle.lastUpdateUser," +
    "EObjXVehicle.lastUpdateTxId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getXVehicleHistorySql = "SELECT r.H_VEHICLEPK_ID hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.VEHICLEPK_ID VEHICLEPK_ID, r.DIVISION DIVISION, r.BUSINESS_UNIT BUSINESS_UNIT, r.ACTIVITY ACTIVITY, r.TYPE_CLASS TYPE_CLASS, r.BAU_RELHE BAU_RELHE, r.BAU_MUSTER BAU_MUSTER, r.SUB_MUSTER SUB_MUSTER, r.ENGINE_NUM ENGINE_NUM, r.COUNTRY_TP_CD COUNTRY_TP_CD, r.COLOR COLOR, r.TRIM TRIM, r.GLOBAL_VIN GLOBAL_VIN, r.LOCAL_VIN LOCAL_VIN, r.LICENSE_PLATE LICENSE_PLATE, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.CREATE_DT CREATE_DT, r.CHANGED_DT CHANGED_DT, r.LAST_SERVICE_DT LAST_SERVICE_DT, r.Market_Name Market_Name, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XVEHICLE r WHERE r.H_VEHICLEPK_ID = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXVehicleHistoryParameters =
    "EObjXVehicle.VehiclepkId," +
    "EObjXVehicle.lastUpdateDt," +
    "EObjXVehicle.lastUpdateDt";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXVehicleHistoryResults =
    "EObjXVehicle.historyIdPK," +
    "EObjXVehicle.histActionCode," +
    "EObjXVehicle.histCreatedBy," +
    "EObjXVehicle.histCreateDt," +
    "EObjXVehicle.histEndDt," +
    "EObjXVehicle.VehiclepkId," +
    "EObjXVehicle.Division," +
    "EObjXVehicle.BusinessUnit," +
    "EObjXVehicle.Activity," +
    "EObjXVehicle.TypeClass," +
    "EObjXVehicle.BauRelhe," +
    "EObjXVehicle.BauMuster," +
    "EObjXVehicle.SubMuster," +
    "EObjXVehicle.EngineNumber," +
    "EObjXVehicle.Country," +
    "EObjXVehicle.Color," +
    "EObjXVehicle.Trim," +
    "EObjXVehicle.GlobalVIN," +
    "EObjXVehicle.LocalVIN," +
    "EObjXVehicle.LicensePlate," +
    "EObjXVehicle.SourceIdentifier," +
    "EObjXVehicle.LastModifiedSystemDate," +
    "EObjXVehicle.CreateDate," +
    "EObjXVehicle.ChangedDate," +
    "EObjXVehicle.LastServiceDate," +
    "EObjXVehicle.MarketName," +
    "EObjXVehicle.lastUpdateDt," +
    "EObjXVehicle.lastUpdateUser," +
    "EObjXVehicle.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getXVehicleSql, pattern=tableAliasString)
  @EntityMapping(parameters=getXVehicleParameters, results=getXVehicleResults)
  Iterator<ResultQueue1<EObjXVehicle>> getXVehicle(Object[] parameters);  


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getXVehicleHistorySql, pattern=tableAliasString)
  @EntityMapping(parameters=getXVehicleHistoryParameters, results=getXVehicleHistoryResults)
  Iterator<ResultQueue1<EObjXVehicle>> getXVehicleHistory(Object[] parameters);  


}


