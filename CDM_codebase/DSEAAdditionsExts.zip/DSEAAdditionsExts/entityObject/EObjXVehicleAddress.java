/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[ff3fb9a48e138388546e07ec18b9e1a9]
 */

package com.ibm.daimler.dsea.entityObject;

import com.dwl.base.EObjCommon;
import com.ibm.mdm.base.db.DataType;
import com.ibm.pdq.annotation.Column;
import com.ibm.pdq.annotation.Table;


import com.ibm.pdq.annotation.Id;

import java.sql.Timestamp;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * The entity object corresponding to the XVehicleAddress business object. This
 * entity object should include all the attributes as defined by the business
 * object.
 * 
 * @generated
 */
@SuppressWarnings("serial")
@Table(name=EObjXVehicleAddress.tableName)
public class EObjXVehicleAddress extends EObjCommon {

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public static final String tableName = "XVEHICLEADDRESS";
    
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String vehicleAddresspkIdColumn = "VEHICLE_ADDRESSPK_ID";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String vehicleAddresspkIdJdbcType = "BIGINT";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    vehicleAddresspkIdPrecision = 19;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String addressUsageTypeColumn = "ADDRESS_USAGE_TYPE";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String addressUsageTypeJdbcType = "VARCHAR";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    addressUsageTypePrecision = 100;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String preferredIndColumn = "PREFERRED_IND";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String preferredIndJdbcType = "VARCHAR";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    preferredIndPrecision = 10;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String addressLineOneColumn = "ADDRESS_LINE_ONE";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String addressLineOneJdbcType = "VARCHAR";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    addressLineOnePrecision = 500;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String addressLineTwoColumn = "ADDRESS_LINE_TWO";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String addressLineTwoJdbcType = "VARCHAR";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    addressLineTwoPrecision = 250;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String addressLineThreeColumn = "ADDRESS_LINE_THREE";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String addressLineThreeJdbcType = "VARCHAR";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    addressLineThreePrecision = 150;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String cityColumn = "CITY_NAME";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String cityJdbcType = "VARCHAR";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    cityPrecision = 1000;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String zipPostalCodeColumn = "POSTAL_CODE";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String zipPostalCodeJdbcType = "VARCHAR";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    zipPostalCodePrecision = 100;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String residenceNumberColumn = "RESIDENCE_NUM";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String residenceNumberJdbcType = "VARCHAR";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    residenceNumberPrecision = 1000;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String countryColumn = "COUNTRY";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String countryJdbcType = "VARCHAR";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    countryPrecision = 150;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String provinceStateColumn = "PROVINCE_STATE";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String provinceStateJdbcType = "VARCHAR";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    provinceStatePrecision = 250;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String vehicleIdColumn = "VEHICLE_ID";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String vehicleIdJdbcType = "BIGINT";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    vehicleIdPrecision = 19;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String contIdColumn = "CONT_ID";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String contIdJdbcType = "BIGINT";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    contIdPrecision = 19;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String sourceIdentifierColumn = "SOURCE_IDENT_TP_CD";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String sourceIdentifierJdbcType = "BIGINT";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    sourceIdentifierPrecision = 19;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String startDateColumn = "START_DT";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String startDateJdbcType = "TIMESTAMP";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String lastModifiedSystemDateColumn = "MODIFY_SYS_DT";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String lastModifiedSystemDateJdbcType = "TIMESTAMP";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected Long vehicleAddresspkId;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String addressUsageType;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String preferredInd;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String addressLineOne;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String addressLineTwo;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String addressLineThree;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String city;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String zipPostalCode;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String residenceNumber;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String country;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String provinceState;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected Long vehicleId;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected Long contId;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected Long sourceIdentifier;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected  Timestamp startDate;
    //inside if 

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected  Timestamp lastModifiedSystemDate;
    //inside if 



    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Default constructor.     
     *
     * @generated
     */
    public EObjXVehicleAddress() {
        super();
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the vehicleAddresspkId attribute. 
     *
     * @generated
     */
    @Id
    @Column(name=vehicleAddresspkIdColumn)
    @DataType(jdbcType=vehicleAddresspkIdJdbcType, precision=vehicleAddresspkIdPrecision)
    public Long getVehicleAddresspkId (){
        return vehicleAddresspkId;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the vehicleAddresspkId attribute. 
     *
     * @param vehicleAddresspkId
     *     The new value of VehicleAddresspkId. 
     * @generated
     */
    public void setVehicleAddresspkId( Long vehicleAddresspkId ){
        this.vehicleAddresspkId = vehicleAddresspkId;
    
        super.setIdPK(vehicleAddresspkId);
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the addressUsageType attribute. 
     *
     * @generated
     */
    @Column(name=addressUsageTypeColumn)
    @DataType(jdbcType=addressUsageTypeJdbcType, precision=addressUsageTypePrecision)
    public String getAddressUsageType (){
        return addressUsageType;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the addressUsageType attribute. 
     *
     * @param addressUsageType
     *     The new value of AddressUsageType. 
     * @generated
     */
    public void setAddressUsageType( String addressUsageType ){
        this.addressUsageType = addressUsageType;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the preferredInd attribute. 
     *
     * @generated
     */
    @Column(name=preferredIndColumn)
    @DataType(jdbcType=preferredIndJdbcType, precision=preferredIndPrecision)
    public String getPreferredInd (){
        return preferredInd;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the preferredInd attribute. 
     *
     * @param preferredInd
     *     The new value of PreferredInd. 
     * @generated
     */
    public void setPreferredInd( String preferredInd ){
        this.preferredInd = preferredInd;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the addressLineOne attribute. 
     *
     * @generated
     */
    @Column(name=addressLineOneColumn)
    @DataType(jdbcType=addressLineOneJdbcType, precision=addressLineOnePrecision)
    public String getAddressLineOne (){
        return addressLineOne;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the addressLineOne attribute. 
     *
     * @param addressLineOne
     *     The new value of AddressLineOne. 
     * @generated
     */
    public void setAddressLineOne( String addressLineOne ){
        this.addressLineOne = addressLineOne;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the addressLineTwo attribute. 
     *
     * @generated
     */
    @Column(name=addressLineTwoColumn)
    @DataType(jdbcType=addressLineTwoJdbcType, precision=addressLineTwoPrecision)
    public String getAddressLineTwo (){
        return addressLineTwo;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the addressLineTwo attribute. 
     *
     * @param addressLineTwo
     *     The new value of AddressLineTwo. 
     * @generated
     */
    public void setAddressLineTwo( String addressLineTwo ){
        this.addressLineTwo = addressLineTwo;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the addressLineThree attribute. 
     *
     * @generated
     */
    @Column(name=addressLineThreeColumn)
    @DataType(jdbcType=addressLineThreeJdbcType, precision=addressLineThreePrecision)
    public String getAddressLineThree (){
        return addressLineThree;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the addressLineThree attribute. 
     *
     * @param addressLineThree
     *     The new value of AddressLineThree. 
     * @generated
     */
    public void setAddressLineThree( String addressLineThree ){
        this.addressLineThree = addressLineThree;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the city attribute. 
     *
     * @generated
     */
    @Column(name=cityColumn)
    @DataType(jdbcType=cityJdbcType, precision=cityPrecision)
    public String getCity (){
        return city;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the city attribute. 
     *
     * @param city
     *     The new value of City. 
     * @generated
     */
    public void setCity( String city ){
        this.city = city;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the zipPostalCode attribute. 
     *
     * @generated
     */
    @Column(name=zipPostalCodeColumn)
    @DataType(jdbcType=zipPostalCodeJdbcType, precision=zipPostalCodePrecision)
    public String getZipPostalCode (){
        return zipPostalCode;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the zipPostalCode attribute. 
     *
     * @param zipPostalCode
     *     The new value of ZipPostalCode. 
     * @generated
     */
    public void setZipPostalCode( String zipPostalCode ){
        this.zipPostalCode = zipPostalCode;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the residenceNumber attribute. 
     *
     * @generated
     */
    @Column(name=residenceNumberColumn)
    @DataType(jdbcType=residenceNumberJdbcType, precision=residenceNumberPrecision)
    public String getResidenceNumber (){
        return residenceNumber;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the residenceNumber attribute. 
     *
     * @param residenceNumber
     *     The new value of ResidenceNumber. 
     * @generated
     */
    public void setResidenceNumber( String residenceNumber ){
        this.residenceNumber = residenceNumber;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the country attribute. 
     *
     * @generated
     */
    @Column(name=countryColumn)
    @DataType(jdbcType=countryJdbcType, precision=countryPrecision)
    public String getCountry (){
        return country;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the country attribute. 
     *
     * @param country
     *     The new value of Country. 
     * @generated
     */
    public void setCountry( String country ){
        this.country = country;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the provinceState attribute. 
     *
     * @generated
     */
    @Column(name=provinceStateColumn)
    @DataType(jdbcType=provinceStateJdbcType, precision=provinceStatePrecision)
    public String getProvinceState (){
        return provinceState;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the provinceState attribute. 
     *
     * @param provinceState
     *     The new value of ProvinceState. 
     * @generated
     */
    public void setProvinceState( String provinceState ){
        this.provinceState = provinceState;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the vehicleId attribute. 
     *
     * @generated
     */
    @Column(name=vehicleIdColumn)
    @DataType(jdbcType=vehicleIdJdbcType, precision=vehicleIdPrecision)
    public Long getVehicleId (){
        return vehicleId;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the vehicleId attribute. 
     *
     * @param vehicleId
     *     The new value of VehicleId. 
     * @generated
     */
    public void setVehicleId( Long vehicleId ){
        this.vehicleId = vehicleId;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the contId attribute. 
     *
     * @generated
     */
    @Column(name=contIdColumn)
    @DataType(jdbcType=contIdJdbcType, precision=contIdPrecision)
    public Long getContId (){
        return contId;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the contId attribute. 
     *
     * @param contId
     *     The new value of ContId. 
     * @generated
     */
    public void setContId( Long contId ){
        this.contId = contId;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the sourceIdentifier attribute. 
     *
     * @generated
     */
    @Column(name=sourceIdentifierColumn)
    @DataType(jdbcType=sourceIdentifierJdbcType, precision=sourceIdentifierPrecision)
    public Long getSourceIdentifier (){
        return sourceIdentifier;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the sourceIdentifier attribute. 
     *
     * @param sourceIdentifier
     *     The new value of SourceIdentifier. 
     * @generated
     */
    public void setSourceIdentifier( Long sourceIdentifier ){
        this.sourceIdentifier = sourceIdentifier;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the startDate attribute. 
     *
     * @generated
     */
    @Column(name=startDateColumn)
    @DataType(jdbcType=startDateJdbcType)
    public Timestamp getStartDate (){
        return startDate;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the startDate attribute. 
     *
     * @param startDate
     *     The new value of StartDate. 
     * @generated
     */
    public void setStartDate( Timestamp startDate ){
        this.startDate = startDate;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the lastModifiedSystemDate attribute. 
     *
     * @generated
     */
    @Column(name=lastModifiedSystemDateColumn)
    @DataType(jdbcType=lastModifiedSystemDateJdbcType)
    public Timestamp getLastModifiedSystemDate (){
        return lastModifiedSystemDate;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the lastModifiedSystemDate attribute. 
     *
     * @param lastModifiedSystemDate
     *     The new value of LastModifiedSystemDate. 
     * @generated
     */
    public void setLastModifiedSystemDate( Timestamp lastModifiedSystemDate ){
        this.lastModifiedSystemDate = lastModifiedSystemDate;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the primary key. 
     *
     * @param aUniqueId
     *     The new value of the primary key. 
     * @generated
   */
	public void setPrimaryKey(Object aUniqueId) {
    this.setVehicleAddresspkId((Long)aUniqueId);
  }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the primary key.
     *
     * @generated
     */
	public Object getPrimaryKey() {
    return this.getVehicleAddresspkId();
  }
	 
}


