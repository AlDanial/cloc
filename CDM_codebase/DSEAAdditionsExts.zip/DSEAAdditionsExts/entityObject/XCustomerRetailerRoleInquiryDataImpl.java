package com.ibm.daimler.dsea.entityObject;

import com.ibm.pdq.runtime.generator.BaseParameterHandler;
import java.util.Iterator;
import com.ibm.mdm.base.db.ResultQueue1;
import com.ibm.daimler.dsea.entityObject.EObjXCustomerRetailerRole;
import java.sql.PreparedStatement;
import com.ibm.pdq.runtime.statement.StatementDescriptor;
import com.ibm.pdq.runtime.generator.BaseData;
import java.sql.SQLException;
import com.ibm.pdq.annotation.Metadata;
import com.ibm.pdq.runtime.generator.BaseRowHandler;
import com.ibm.pdq.runtime.statement.SqlStatementType;
import java.sql.Types;


@SuppressWarnings("unchecked")

/**
 * <!-- begin-user-doc -->
 * 
 * <!-- end-user-doc -->
 * 
 * @generated
 */
public class XCustomerRetailerRoleInquiryDataImpl  extends BaseData implements XCustomerRetailerRoleInquiryData
{

  /**
   * @generated
   */
  public static final String generatorVersion = "3.200.75";

  /**
   * @generated
   */
  public static final String identifier = "XCustomerRetailerRoleInquiryData";

  /**
   * @generated
   */
  public static final long generationTime = 0x0000015e13f845b2L;

  /**
   * @generated
   */
  public static final String collection = "NULLID";

  /**
   * @generated
   */
  public static final String packageVersion = null;

  /**
   * @generated
   */
  public static final boolean forceSingleBindIsolation = false;

  /**
   * @generated
   */
  public XCustomerRetailerRoleInquiryDataImpl()
  {
    super();
  } 

  /**
   * @generated
   */
  public String getGeneratorVersion()
  {
    return generatorVersion;
  }

  /**
   * @Select( sql="SELECT r.CUSTOMERRETAILERROLEPK_ID CUSTOMERRETAILERROLEPK_ID, r.CUSTOMER_RETAILER_ID CUSTOMER_RETAILER_ID, r.RETAILER_ROLE_TP_CD RETAILER_ROLE_TP_CD, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.START_DT START_DT, r.END_DT END_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XCUSTOMERRETAILERROLE r WHERE r.CUSTOMERRETAILERROLEPK_ID = ? ", pattern="tableAlias (XCUSTOMERRETAILERROLE => com.ibm.daimler.dsea.entityObject.EObjXCustomerRetailerRole, H_XCUSTOMERRETAILERROLE => com.ibm.daimler.dsea.entityObject.EObjXCustomerRetailerRole)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue1<EObjXCustomerRetailerRole>> getXCustomerRetailerRole (Object[] parameters)
  {
    return queryIterator (getXCustomerRetailerRoleStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getXCustomerRetailerRoleStatementDescriptor = createStatementDescriptor (
    "getXCustomerRetailerRole(Object[])",
    "SELECT r.CUSTOMERRETAILERROLEPK_ID CUSTOMERRETAILERROLEPK_ID, r.CUSTOMER_RETAILER_ID CUSTOMER_RETAILER_ID, r.RETAILER_ROLE_TP_CD RETAILER_ROLE_TP_CD, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.START_DT START_DT, r.END_DT END_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XCUSTOMERRETAILERROLE r WHERE r.CUSTOMERRETAILERROLEPK_ID = ? ",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"customerretailerrolepk_id", "customer_retailer_id", "retailer_role_tp_cd", "source_ident_tp_cd", "start_dt", "end_dt", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetXCustomerRetailerRoleParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetXCustomerRetailerRoleRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 19, 19, 19, 0, 0, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    1);

  /**
   * @generated
   */
  public static class GetXCustomerRetailerRoleParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetXCustomerRetailerRoleRowHandler extends BaseRowHandler<ResultQueue1<EObjXCustomerRetailerRole>>
  {
    /**
     * @generated
     */
    public ResultQueue1<EObjXCustomerRetailerRole> handle (java.sql.ResultSet rs, ResultQueue1<EObjXCustomerRetailerRole> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue1<EObjXCustomerRetailerRole> ();

      EObjXCustomerRetailerRole returnObject1 = new EObjXCustomerRetailerRole ();
      returnObject1.setCustomerRetailerRolepkId(getLongObject (rs, 1)); 
      returnObject1.setCustomerRetailerId(getLongObject (rs, 2)); 
      returnObject1.setRetailerRole(getLongObject (rs, 3)); 
      returnObject1.setSourceIdentifier(getLongObject (rs, 4)); 
      returnObject1.setStartDate(getTimestamp (rs, 5)); 
      returnObject1.setEndDate(getTimestamp (rs, 6)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 7)); 
      returnObject1.setLastUpdateUser(getString (rs, 8)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 9)); 
      returnObject.add (returnObject1);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT r.H_CUSTOMERRETAILERROLEPK_ID hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.CUSTOMERRETAILERROLEPK_ID CUSTOMERRETAILERROLEPK_ID, r.CUSTOMER_RETAILER_ID CUSTOMER_RETAILER_ID, r.RETAILER_ROLE_TP_CD RETAILER_ROLE_TP_CD, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.START_DT START_DT, r.END_DT END_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XCUSTOMERRETAILERROLE r WHERE r.H_CUSTOMERRETAILERROLEPK_ID = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))", pattern="tableAlias (XCUSTOMERRETAILERROLE => com.ibm.daimler.dsea.entityObject.EObjXCustomerRetailerRole, H_XCUSTOMERRETAILERROLE => com.ibm.daimler.dsea.entityObject.EObjXCustomerRetailerRole)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue1<EObjXCustomerRetailerRole>> getXCustomerRetailerRoleHistory (Object[] parameters)
  {
    return queryIterator (getXCustomerRetailerRoleHistoryStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getXCustomerRetailerRoleHistoryStatementDescriptor = createStatementDescriptor (
    "getXCustomerRetailerRoleHistory(Object[])",
    "SELECT r.H_CUSTOMERRETAILERROLEPK_ID hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.CUSTOMERRETAILERROLEPK_ID CUSTOMERRETAILERROLEPK_ID, r.CUSTOMER_RETAILER_ID CUSTOMER_RETAILER_ID, r.RETAILER_ROLE_TP_CD RETAILER_ROLE_TP_CD, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.START_DT START_DT, r.END_DT END_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XCUSTOMERRETAILERROLE r WHERE r.H_CUSTOMERRETAILERROLEPK_ID = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"historyidpk", "h_action_code", "h_created_by", "h_create_dt", "h_end_dt", "customerretailerrolepk_id", "customer_retailer_id", "retailer_role_tp_cd", "source_ident_tp_cd", "start_dt", "end_dt", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetXCustomerRetailerRoleHistoryParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP}, {19, 0, 0}, {0, 0, 0}, {1, 1, 1}},
    null,
    new GetXCustomerRetailerRoleHistoryRowHandler (),
    new int[][]{ {Types.BIGINT, Types.CHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 1, 20, 0, 0, 19, 19, 19, 19, 0, 0, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    2);

  /**
   * @generated
   */
  public static class GetXCustomerRetailerRoleHistoryParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetXCustomerRetailerRoleHistoryRowHandler extends BaseRowHandler<ResultQueue1<EObjXCustomerRetailerRole>>
  {
    /**
     * @generated
     */
    public ResultQueue1<EObjXCustomerRetailerRole> handle (java.sql.ResultSet rs, ResultQueue1<EObjXCustomerRetailerRole> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue1<EObjXCustomerRetailerRole> ();

      EObjXCustomerRetailerRole returnObject1 = new EObjXCustomerRetailerRole ();
      returnObject1.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject1.setHistActionCode(getString (rs, 2)); 
      returnObject1.setHistCreatedBy(getString (rs, 3)); 
      returnObject1.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject1.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject1.setCustomerRetailerRolepkId(getLongObject (rs, 6)); 
      returnObject1.setCustomerRetailerId(getLongObject (rs, 7)); 
      returnObject1.setRetailerRole(getLongObject (rs, 8)); 
      returnObject1.setSourceIdentifier(getLongObject (rs, 9)); 
      returnObject1.setStartDate(getTimestamp (rs, 10)); 
      returnObject1.setEndDate(getTimestamp (rs, 11)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 12)); 
      returnObject1.setLastUpdateUser(getString (rs, 13)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 14)); 
      returnObject.add (returnObject1);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT r.CUSTOMERRETAILERROLEPK_ID CUSTOMERRETAILERROLEPK_ID, r.CUSTOMER_RETAILER_ID CUSTOMER_RETAILER_ID, r.RETAILER_ROLE_TP_CD RETAILER_ROLE_TP_CD, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.START_DT START_DT, r.END_DT END_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XCUSTOMERRETAILERROLE r WHERE r.CUSTOMER_RETAILER_ID = ? ", pattern="tableAlias (XCUSTOMERRETAILERROLE => com.ibm.daimler.dsea.entityObject.EObjXCustomerRetailerRole, H_XCUSTOMERRETAILERROLE => com.ibm.daimler.dsea.entityObject.EObjXCustomerRetailerRole)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue1<EObjXCustomerRetailerRole>> getAllRetailerRoleByCustomerRetailerId (Object[] parameters)
  {
    return queryIterator (getAllRetailerRoleByCustomerRetailerIdStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getAllRetailerRoleByCustomerRetailerIdStatementDescriptor = createStatementDescriptor (
    "getAllRetailerRoleByCustomerRetailerId(Object[])",
    "SELECT r.CUSTOMERRETAILERROLEPK_ID CUSTOMERRETAILERROLEPK_ID, r.CUSTOMER_RETAILER_ID CUSTOMER_RETAILER_ID, r.RETAILER_ROLE_TP_CD RETAILER_ROLE_TP_CD, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.START_DT START_DT, r.END_DT END_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XCUSTOMERRETAILERROLE r WHERE r.CUSTOMER_RETAILER_ID = ? ",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"customerretailerrolepk_id", "customer_retailer_id", "retailer_role_tp_cd", "source_ident_tp_cd", "start_dt", "end_dt", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetAllRetailerRoleByCustomerRetailerIdParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetAllRetailerRoleByCustomerRetailerIdRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 19, 19, 19, 0, 0, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    3);

  /**
   * @generated
   */
  public static class GetAllRetailerRoleByCustomerRetailerIdParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetAllRetailerRoleByCustomerRetailerIdRowHandler extends BaseRowHandler<ResultQueue1<EObjXCustomerRetailerRole>>
  {
    /**
     * @generated
     */
    public ResultQueue1<EObjXCustomerRetailerRole> handle (java.sql.ResultSet rs, ResultQueue1<EObjXCustomerRetailerRole> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue1<EObjXCustomerRetailerRole> ();

      EObjXCustomerRetailerRole returnObject1 = new EObjXCustomerRetailerRole ();
      returnObject1.setCustomerRetailerRolepkId(getLongObject (rs, 1)); 
      returnObject1.setCustomerRetailerId(getLongObject (rs, 2)); 
      returnObject1.setRetailerRole(getLongObject (rs, 3)); 
      returnObject1.setSourceIdentifier(getLongObject (rs, 4)); 
      returnObject1.setStartDate(getTimestamp (rs, 5)); 
      returnObject1.setEndDate(getTimestamp (rs, 6)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 7)); 
      returnObject1.setLastUpdateUser(getString (rs, 8)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 9)); 
      returnObject.add (returnObject1);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT r.H_CUSTOMERRETAILERROLEPK_ID hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.CUSTOMERRETAILERROLEPK_ID CUSTOMERRETAILERROLEPK_ID, r.CUSTOMER_RETAILER_ID CUSTOMER_RETAILER_ID, r.RETAILER_ROLE_TP_CD RETAILER_ROLE_TP_CD, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.START_DT START_DT, r.END_DT END_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XCUSTOMERRETAILERROLE r WHERE r.CUSTOMER_RETAILER_ID = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))", pattern="tableAlias (XCUSTOMERRETAILERROLE => com.ibm.daimler.dsea.entityObject.EObjXCustomerRetailerRole, H_XCUSTOMERRETAILERROLE => com.ibm.daimler.dsea.entityObject.EObjXCustomerRetailerRole)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue1<EObjXCustomerRetailerRole>> getAllRetailerRoleByCustomerRetailerIdHistory (Object[] parameters)
  {
    return queryIterator (getAllRetailerRoleByCustomerRetailerIdHistoryStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getAllRetailerRoleByCustomerRetailerIdHistoryStatementDescriptor = createStatementDescriptor (
    "getAllRetailerRoleByCustomerRetailerIdHistory(Object[])",
    "SELECT r.H_CUSTOMERRETAILERROLEPK_ID hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.CUSTOMERRETAILERROLEPK_ID CUSTOMERRETAILERROLEPK_ID, r.CUSTOMER_RETAILER_ID CUSTOMER_RETAILER_ID, r.RETAILER_ROLE_TP_CD RETAILER_ROLE_TP_CD, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.START_DT START_DT, r.END_DT END_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XCUSTOMERRETAILERROLE r WHERE r.CUSTOMER_RETAILER_ID = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"historyidpk", "h_action_code", "h_created_by", "h_create_dt", "h_end_dt", "customerretailerrolepk_id", "customer_retailer_id", "retailer_role_tp_cd", "source_ident_tp_cd", "start_dt", "end_dt", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetAllRetailerRoleByCustomerRetailerIdHistoryParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP}, {19, 0, 0}, {0, 0, 0}, {1, 1, 1}},
    null,
    new GetAllRetailerRoleByCustomerRetailerIdHistoryRowHandler (),
    new int[][]{ {Types.BIGINT, Types.CHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 1, 20, 0, 0, 19, 19, 19, 19, 0, 0, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    4);

  /**
   * @generated
   */
  public static class GetAllRetailerRoleByCustomerRetailerIdHistoryParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetAllRetailerRoleByCustomerRetailerIdHistoryRowHandler extends BaseRowHandler<ResultQueue1<EObjXCustomerRetailerRole>>
  {
    /**
     * @generated
     */
    public ResultQueue1<EObjXCustomerRetailerRole> handle (java.sql.ResultSet rs, ResultQueue1<EObjXCustomerRetailerRole> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue1<EObjXCustomerRetailerRole> ();

      EObjXCustomerRetailerRole returnObject1 = new EObjXCustomerRetailerRole ();
      returnObject1.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject1.setHistActionCode(getString (rs, 2)); 
      returnObject1.setHistCreatedBy(getString (rs, 3)); 
      returnObject1.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject1.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject1.setCustomerRetailerRolepkId(getLongObject (rs, 6)); 
      returnObject1.setCustomerRetailerId(getLongObject (rs, 7)); 
      returnObject1.setRetailerRole(getLongObject (rs, 8)); 
      returnObject1.setSourceIdentifier(getLongObject (rs, 9)); 
      returnObject1.setStartDate(getTimestamp (rs, 10)); 
      returnObject1.setEndDate(getTimestamp (rs, 11)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 12)); 
      returnObject1.setLastUpdateUser(getString (rs, 13)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 14)); 
      returnObject.add (returnObject1);

    
      return returnObject;
    }
  }

}
