/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[c9c201807522143cd46f39de090072ae]
 */

package com.ibm.daimler.dsea.entityObject;


import com.ibm.mdm.base.db.ResultQueue1;
import java.util.Iterator;
import com.ibm.mdm.base.db.EntityMapping;
import com.ibm.pdq.annotation.Select;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * @generated
 */
public interface XDealerRetailerInquiryData {
  
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String tableAliasString = "tableAlias (" + 
                                            "XDEALERRETAILER => com.ibm.daimler.dsea.entityObject.EObjXDealerRetailer, " +
                                            "H_XDEALERRETAILER => com.ibm.daimler.dsea.entityObject.EObjXDealerRetailer" +
                                            ")";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getXDealerRetailerSql = "SELECT r.XDealer_Retailerpk_Id XDealer_Retailerpk_Id, r.Dealer_Code Dealer_Code, r.Retailer_Code Retailer_Code, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XDEALERRETAILER r WHERE r.XDealer_Retailerpk_Id = ? ";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXDealerRetailerParameters =
    "EObjXDealerRetailer.XDealerRetailerpkId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXDealerRetailerResults =
    "EObjXDealerRetailer.XDealerRetailerpkId," +
    "EObjXDealerRetailer.DealerCode," +
    "EObjXDealerRetailer.RetailerCode," +
    "EObjXDealerRetailer.lastUpdateDt," +
    "EObjXDealerRetailer.lastUpdateUser," +
    "EObjXDealerRetailer.lastUpdateTxId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getXDealerRetailerHistorySql = "SELECT r.H_XDealer_Retailerpk_Id hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.XDealer_Retailerpk_Id XDealer_Retailerpk_Id, r.Dealer_Code Dealer_Code, r.Retailer_Code Retailer_Code, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XDEALERRETAILER r WHERE r.H_XDealer_Retailerpk_Id = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXDealerRetailerHistoryParameters =
    "EObjXDealerRetailer.XDealerRetailerpkId," +
    "EObjXDealerRetailer.lastUpdateDt," +
    "EObjXDealerRetailer.lastUpdateDt";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXDealerRetailerHistoryResults =
    "EObjXDealerRetailer.historyIdPK," +
    "EObjXDealerRetailer.histActionCode," +
    "EObjXDealerRetailer.histCreatedBy," +
    "EObjXDealerRetailer.histCreateDt," +
    "EObjXDealerRetailer.histEndDt," +
    "EObjXDealerRetailer.XDealerRetailerpkId," +
    "EObjXDealerRetailer.DealerCode," +
    "EObjXDealerRetailer.RetailerCode," +
    "EObjXDealerRetailer.lastUpdateDt," +
    "EObjXDealerRetailer.lastUpdateUser," +
    "EObjXDealerRetailer.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getXDealerRetailerSql, pattern=tableAliasString)
  @EntityMapping(parameters=getXDealerRetailerParameters, results=getXDealerRetailerResults)
  Iterator<ResultQueue1<EObjXDealerRetailer>> getXDealerRetailer(Object[] parameters);  


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getXDealerRetailerHistorySql, pattern=tableAliasString)
  @EntityMapping(parameters=getXDealerRetailerHistoryParameters, results=getXDealerRetailerHistoryResults)
  Iterator<ResultQueue1<EObjXDealerRetailer>> getXDealerRetailerHistory(Object[] parameters);  


}


