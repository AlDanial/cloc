/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[a2fa7a248f72041f24d205e158a39d2b]
 */

package com.ibm.daimler.dsea.entityObject;


import com.ibm.mdm.base.db.ResultQueue1;
import java.util.Iterator;
import com.ibm.mdm.base.db.EntityMapping;
import com.ibm.pdq.annotation.Select;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * @generated
 */
public interface XGurantorIndividualInquiryData {
  
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String tableAliasString = "tableAlias (" + 
                                            "XGURANTORINDIVIDUAL => com.ibm.daimler.dsea.entityObject.EObjXGurantorIndividual, " +
                                            "H_XGURANTORINDIVIDUAL => com.ibm.daimler.dsea.entityObject.EObjXGurantorIndividual" +
                                            ")";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getXGurantorIndividualSql = "SELECT r.XGurantor_Individualpk_Id XGurantor_Individualpk_Id, r.CONTRACT_DETAILS_ID CONTRACT_DETAILS_ID, r.BPID BPID, r.ABN_NUMBER ABN_NUMBER, r.PREFIX_NAME_TP_CD PREFIX_NAME_TP_CD, r.GIVEN_NAME_ONE GIVEN_NAME_ONE, r.LAST_NAME LAST_NAME, r.GIVEN_NAME_ONE_LOCAL GIVEN_NAME_ONE_LOCAL, r.LAST_NAME_LOCAL LAST_NAME_LOCAL, r.BIRTH_DT BIRTH_DT, r.ADDR_USAGE_TP_CD ADDR_USAGE_TP_CD, r.ADDR_LINE_ONE ADDR_LINE_ONE, r.ADDR_LINE_TWO ADDR_LINE_TWO, r.ADDR_LINE_THREE ADDR_LINE_THREE, r.POSTAL_CODE POSTAL_CODE, r.CITY_NAME CITY_NAME, r.RESIDENCE_NUMBER RESIDENCE_NUMBER, r.COUNTRY_TP_CD COUNTRY_TP_CD, r.BUILDING_NAME BUILDING_NAME, r.STREET_NAME STREET_NAME, r.STREET_NUMBER STREET_NUMBER, r.MOBILE_NUMBER MOBILE_NUMBER, r.HOME_PHONE_NUMBER HOME_PHONE_NUMBER, r.WORK_PHONE_NUMBER WORK_PHONE_NUMBER, r.WORK_PHONE_NUMBER_EXT WORK_PHONE_NUMBER_EXT, r.FAX FAX, r.EMAIL EMAIL, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.START_DT START_DT, r.END_DT END_DT, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XGURANTORINDIVIDUAL r WHERE r.XGurantor_Individualpk_Id = ? ";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXGurantorIndividualParameters =
    "EObjXGurantorIndividual.XGurantorIndividualpkId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXGurantorIndividualResults =
    "EObjXGurantorIndividual.XGurantorIndividualpkId," +
    "EObjXGurantorIndividual.ContractDetailsId," +
    "EObjXGurantorIndividual.BPID," +
    "EObjXGurantorIndividual.ABNNumber," +
    "EObjXGurantorIndividual.Title," +
    "EObjXGurantorIndividual.GivenNameOne," +
    "EObjXGurantorIndividual.LastName," +
    "EObjXGurantorIndividual.GivenNameOneLocal," +
    "EObjXGurantorIndividual.LastNameLocal," +
    "EObjXGurantorIndividual.BirthDate," +
    "EObjXGurantorIndividual.AddressUsage," +
    "EObjXGurantorIndividual.AddressLineOne," +
    "EObjXGurantorIndividual.AddressLineTwo," +
    "EObjXGurantorIndividual.AddressLineThree," +
    "EObjXGurantorIndividual.PostalCode," +
    "EObjXGurantorIndividual.CityName," +
    "EObjXGurantorIndividual.ResidenceNumber," +
    "EObjXGurantorIndividual.Country," +
    "EObjXGurantorIndividual.BuildingName," +
    "EObjXGurantorIndividual.StreetName," +
    "EObjXGurantorIndividual.StreetNumber," +
    "EObjXGurantorIndividual.MobileNumber," +
    "EObjXGurantorIndividual.HomePhoneNumber," +
    "EObjXGurantorIndividual.WorkPhoneNumber," +
    "EObjXGurantorIndividual.WorkPhoneNumberExtension," +
    "EObjXGurantorIndividual.Fax," +
    "EObjXGurantorIndividual.Email," +
    "EObjXGurantorIndividual.SourceIdentifier," +
    "EObjXGurantorIndividual.StartDate," +
    "EObjXGurantorIndividual.EndDate," +
    "EObjXGurantorIndividual.LastModifiedSystemDate," +
    "EObjXGurantorIndividual.lastUpdateDt," +
    "EObjXGurantorIndividual.lastUpdateUser," +
    "EObjXGurantorIndividual.lastUpdateTxId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getXGurantorIndividualHistorySql = "SELECT r.H_XGurantor_Individualpk_Id hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.XGurantor_Individualpk_Id XGurantor_Individualpk_Id, r.CONTRACT_DETAILS_ID CONTRACT_DETAILS_ID, r.BPID BPID, r.ABN_NUMBER ABN_NUMBER, r.PREFIX_NAME_TP_CD PREFIX_NAME_TP_CD, r.GIVEN_NAME_ONE GIVEN_NAME_ONE, r.LAST_NAME LAST_NAME, r.GIVEN_NAME_ONE_LOCAL GIVEN_NAME_ONE_LOCAL, r.LAST_NAME_LOCAL LAST_NAME_LOCAL, r.BIRTH_DT BIRTH_DT, r.ADDR_USAGE_TP_CD ADDR_USAGE_TP_CD, r.ADDR_LINE_ONE ADDR_LINE_ONE, r.ADDR_LINE_TWO ADDR_LINE_TWO, r.ADDR_LINE_THREE ADDR_LINE_THREE, r.POSTAL_CODE POSTAL_CODE, r.CITY_NAME CITY_NAME, r.RESIDENCE_NUMBER RESIDENCE_NUMBER, r.COUNTRY_TP_CD COUNTRY_TP_CD, r.BUILDING_NAME BUILDING_NAME, r.STREET_NAME STREET_NAME, r.STREET_NUMBER STREET_NUMBER, r.MOBILE_NUMBER MOBILE_NUMBER, r.HOME_PHONE_NUMBER HOME_PHONE_NUMBER, r.WORK_PHONE_NUMBER WORK_PHONE_NUMBER, r.WORK_PHONE_NUMBER_EXT WORK_PHONE_NUMBER_EXT, r.FAX FAX, r.EMAIL EMAIL, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.START_DT START_DT, r.END_DT END_DT, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XGURANTORINDIVIDUAL r WHERE r.H_XGurantor_Individualpk_Id = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXGurantorIndividualHistoryParameters =
    "EObjXGurantorIndividual.XGurantorIndividualpkId," +
    "EObjXGurantorIndividual.lastUpdateDt," +
    "EObjXGurantorIndividual.lastUpdateDt";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXGurantorIndividualHistoryResults =
    "EObjXGurantorIndividual.historyIdPK," +
    "EObjXGurantorIndividual.histActionCode," +
    "EObjXGurantorIndividual.histCreatedBy," +
    "EObjXGurantorIndividual.histCreateDt," +
    "EObjXGurantorIndividual.histEndDt," +
    "EObjXGurantorIndividual.XGurantorIndividualpkId," +
    "EObjXGurantorIndividual.ContractDetailsId," +
    "EObjXGurantorIndividual.BPID," +
    "EObjXGurantorIndividual.ABNNumber," +
    "EObjXGurantorIndividual.Title," +
    "EObjXGurantorIndividual.GivenNameOne," +
    "EObjXGurantorIndividual.LastName," +
    "EObjXGurantorIndividual.GivenNameOneLocal," +
    "EObjXGurantorIndividual.LastNameLocal," +
    "EObjXGurantorIndividual.BirthDate," +
    "EObjXGurantorIndividual.AddressUsage," +
    "EObjXGurantorIndividual.AddressLineOne," +
    "EObjXGurantorIndividual.AddressLineTwo," +
    "EObjXGurantorIndividual.AddressLineThree," +
    "EObjXGurantorIndividual.PostalCode," +
    "EObjXGurantorIndividual.CityName," +
    "EObjXGurantorIndividual.ResidenceNumber," +
    "EObjXGurantorIndividual.Country," +
    "EObjXGurantorIndividual.BuildingName," +
    "EObjXGurantorIndividual.StreetName," +
    "EObjXGurantorIndividual.StreetNumber," +
    "EObjXGurantorIndividual.MobileNumber," +
    "EObjXGurantorIndividual.HomePhoneNumber," +
    "EObjXGurantorIndividual.WorkPhoneNumber," +
    "EObjXGurantorIndividual.WorkPhoneNumberExtension," +
    "EObjXGurantorIndividual.Fax," +
    "EObjXGurantorIndividual.Email," +
    "EObjXGurantorIndividual.SourceIdentifier," +
    "EObjXGurantorIndividual.StartDate," +
    "EObjXGurantorIndividual.EndDate," +
    "EObjXGurantorIndividual.LastModifiedSystemDate," +
    "EObjXGurantorIndividual.lastUpdateDt," +
    "EObjXGurantorIndividual.lastUpdateUser," +
    "EObjXGurantorIndividual.lastUpdateTxId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getAllXGurantorIndividualByContractDetailsIdSql = "SELECT r.XGurantor_Individualpk_Id XGurantor_Individualpk_Id, r.CONTRACT_DETAILS_ID CONTRACT_DETAILS_ID, r.BPID BPID, r.ABN_NUMBER ABN_NUMBER, r.PREFIX_NAME_TP_CD PREFIX_NAME_TP_CD, r.GIVEN_NAME_ONE GIVEN_NAME_ONE, r.LAST_NAME LAST_NAME, r.GIVEN_NAME_ONE_LOCAL GIVEN_NAME_ONE_LOCAL, r.LAST_NAME_LOCAL LAST_NAME_LOCAL, r.BIRTH_DT BIRTH_DT, r.ADDR_USAGE_TP_CD ADDR_USAGE_TP_CD, r.ADDR_LINE_ONE ADDR_LINE_ONE, r.ADDR_LINE_TWO ADDR_LINE_TWO, r.ADDR_LINE_THREE ADDR_LINE_THREE, r.POSTAL_CODE POSTAL_CODE, r.CITY_NAME CITY_NAME, r.RESIDENCE_NUMBER RESIDENCE_NUMBER, r.COUNTRY_TP_CD COUNTRY_TP_CD, r.BUILDING_NAME BUILDING_NAME, r.STREET_NAME STREET_NAME, r.STREET_NUMBER STREET_NUMBER, r.MOBILE_NUMBER MOBILE_NUMBER, r.HOME_PHONE_NUMBER HOME_PHONE_NUMBER, r.WORK_PHONE_NUMBER WORK_PHONE_NUMBER, r.WORK_PHONE_NUMBER_EXT WORK_PHONE_NUMBER_EXT, r.FAX FAX, r.EMAIL EMAIL, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.START_DT START_DT, r.END_DT END_DT, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XGURANTORINDIVIDUAL r WHERE r.CONTRACT_DETAILS_ID = ? ";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getAllXGurantorIndividualByContractDetailsIdParameters =
    "EObjXGurantorIndividual.ContractDetailsId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getAllXGurantorIndividualByContractDetailsIdResults =
    "EObjXGurantorIndividual.XGurantorIndividualpkId," +
    "EObjXGurantorIndividual.ContractDetailsId," +
    "EObjXGurantorIndividual.BPID," +
    "EObjXGurantorIndividual.ABNNumber," +
    "EObjXGurantorIndividual.Title," +
    "EObjXGurantorIndividual.GivenNameOne," +
    "EObjXGurantorIndividual.LastName," +
    "EObjXGurantorIndividual.GivenNameOneLocal," +
    "EObjXGurantorIndividual.LastNameLocal," +
    "EObjXGurantorIndividual.BirthDate," +
    "EObjXGurantorIndividual.AddressUsage," +
    "EObjXGurantorIndividual.AddressLineOne," +
    "EObjXGurantorIndividual.AddressLineTwo," +
    "EObjXGurantorIndividual.AddressLineThree," +
    "EObjXGurantorIndividual.PostalCode," +
    "EObjXGurantorIndividual.CityName," +
    "EObjXGurantorIndividual.ResidenceNumber," +
    "EObjXGurantorIndividual.Country," +
    "EObjXGurantorIndividual.BuildingName," +
    "EObjXGurantorIndividual.StreetName," +
    "EObjXGurantorIndividual.StreetNumber," +
    "EObjXGurantorIndividual.MobileNumber," +
    "EObjXGurantorIndividual.HomePhoneNumber," +
    "EObjXGurantorIndividual.WorkPhoneNumber," +
    "EObjXGurantorIndividual.WorkPhoneNumberExtension," +
    "EObjXGurantorIndividual.Fax," +
    "EObjXGurantorIndividual.Email," +
    "EObjXGurantorIndividual.SourceIdentifier," +
    "EObjXGurantorIndividual.StartDate," +
    "EObjXGurantorIndividual.EndDate," +
    "EObjXGurantorIndividual.LastModifiedSystemDate," +
    "EObjXGurantorIndividual.lastUpdateDt," +
    "EObjXGurantorIndividual.lastUpdateUser," +
    "EObjXGurantorIndividual.lastUpdateTxId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getAllXGurantorIndividualByContractDetailsIdHistorySql = "SELECT r.H_XGurantor_Individualpk_Id hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.XGurantor_Individualpk_Id XGurantor_Individualpk_Id, r.CONTRACT_DETAILS_ID CONTRACT_DETAILS_ID, r.BPID BPID, r.ABN_NUMBER ABN_NUMBER, r.PREFIX_NAME_TP_CD PREFIX_NAME_TP_CD, r.GIVEN_NAME_ONE GIVEN_NAME_ONE, r.LAST_NAME LAST_NAME, r.GIVEN_NAME_ONE_LOCAL GIVEN_NAME_ONE_LOCAL, r.LAST_NAME_LOCAL LAST_NAME_LOCAL, r.BIRTH_DT BIRTH_DT, r.ADDR_USAGE_TP_CD ADDR_USAGE_TP_CD, r.ADDR_LINE_ONE ADDR_LINE_ONE, r.ADDR_LINE_TWO ADDR_LINE_TWO, r.ADDR_LINE_THREE ADDR_LINE_THREE, r.POSTAL_CODE POSTAL_CODE, r.CITY_NAME CITY_NAME, r.RESIDENCE_NUMBER RESIDENCE_NUMBER, r.COUNTRY_TP_CD COUNTRY_TP_CD, r.BUILDING_NAME BUILDING_NAME, r.STREET_NAME STREET_NAME, r.STREET_NUMBER STREET_NUMBER, r.MOBILE_NUMBER MOBILE_NUMBER, r.HOME_PHONE_NUMBER HOME_PHONE_NUMBER, r.WORK_PHONE_NUMBER WORK_PHONE_NUMBER, r.WORK_PHONE_NUMBER_EXT WORK_PHONE_NUMBER_EXT, r.FAX FAX, r.EMAIL EMAIL, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.START_DT START_DT, r.END_DT END_DT, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XGURANTORINDIVIDUAL r WHERE r.CONTRACT_DETAILS_ID = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getAllXGurantorIndividualByContractDetailsIdHistoryParameters =
    "EObjXGurantorIndividual.ContractDetailsId," +
    "EObjXGurantorIndividual.lastUpdateDt," +
    "EObjXGurantorIndividual.lastUpdateDt";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getAllXGurantorIndividualByContractDetailsIdHistoryResults =
    "EObjXGurantorIndividual.historyIdPK," +
    "EObjXGurantorIndividual.histActionCode," +
    "EObjXGurantorIndividual.histCreatedBy," +
    "EObjXGurantorIndividual.histCreateDt," +
    "EObjXGurantorIndividual.histEndDt," +
    "EObjXGurantorIndividual.XGurantorIndividualpkId," +
    "EObjXGurantorIndividual.ContractDetailsId," +
    "EObjXGurantorIndividual.BPID," +
    "EObjXGurantorIndividual.ABNNumber," +
    "EObjXGurantorIndividual.Title," +
    "EObjXGurantorIndividual.GivenNameOne," +
    "EObjXGurantorIndividual.LastName," +
    "EObjXGurantorIndividual.GivenNameOneLocal," +
    "EObjXGurantorIndividual.LastNameLocal," +
    "EObjXGurantorIndividual.BirthDate," +
    "EObjXGurantorIndividual.AddressUsage," +
    "EObjXGurantorIndividual.AddressLineOne," +
    "EObjXGurantorIndividual.AddressLineTwo," +
    "EObjXGurantorIndividual.AddressLineThree," +
    "EObjXGurantorIndividual.PostalCode," +
    "EObjXGurantorIndividual.CityName," +
    "EObjXGurantorIndividual.ResidenceNumber," +
    "EObjXGurantorIndividual.Country," +
    "EObjXGurantorIndividual.BuildingName," +
    "EObjXGurantorIndividual.StreetName," +
    "EObjXGurantorIndividual.StreetNumber," +
    "EObjXGurantorIndividual.MobileNumber," +
    "EObjXGurantorIndividual.HomePhoneNumber," +
    "EObjXGurantorIndividual.WorkPhoneNumber," +
    "EObjXGurantorIndividual.WorkPhoneNumberExtension," +
    "EObjXGurantorIndividual.Fax," +
    "EObjXGurantorIndividual.Email," +
    "EObjXGurantorIndividual.SourceIdentifier," +
    "EObjXGurantorIndividual.StartDate," +
    "EObjXGurantorIndividual.EndDate," +
    "EObjXGurantorIndividual.LastModifiedSystemDate," +
    "EObjXGurantorIndividual.lastUpdateDt," +
    "EObjXGurantorIndividual.lastUpdateUser," +
    "EObjXGurantorIndividual.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getXGurantorIndividualSql, pattern=tableAliasString)
  @EntityMapping(parameters=getXGurantorIndividualParameters, results=getXGurantorIndividualResults)
  Iterator<ResultQueue1<EObjXGurantorIndividual>> getXGurantorIndividual(Object[] parameters);  


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getXGurantorIndividualHistorySql, pattern=tableAliasString)
  @EntityMapping(parameters=getXGurantorIndividualHistoryParameters, results=getXGurantorIndividualHistoryResults)
  Iterator<ResultQueue1<EObjXGurantorIndividual>> getXGurantorIndividualHistory(Object[] parameters);  


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getAllXGurantorIndividualByContractDetailsIdSql, pattern=tableAliasString)
  @EntityMapping(parameters=getAllXGurantorIndividualByContractDetailsIdParameters, results=getAllXGurantorIndividualByContractDetailsIdResults)
  Iterator<ResultQueue1<EObjXGurantorIndividual>> getAllXGurantorIndividualByContractDetailsId(Object[] parameters);  


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getAllXGurantorIndividualByContractDetailsIdHistorySql, pattern=tableAliasString)
  @EntityMapping(parameters=getAllXGurantorIndividualByContractDetailsIdHistoryParameters, results=getAllXGurantorIndividualByContractDetailsIdHistoryResults)
  Iterator<ResultQueue1<EObjXGurantorIndividual>> getAllXGurantorIndividualByContractDetailsIdHistory(Object[] parameters);  


}


