/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[d1a161c865393be2e9e23a2e058a1cc4]
 */

package com.ibm.daimler.dsea.entityObject;

import com.dwl.base.EObjCommon;
import com.ibm.mdm.base.db.DataType;
import com.ibm.pdq.annotation.Column;
import com.ibm.pdq.annotation.Table;
import java.sql.Timestamp;



/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * The entity object corresponding to the XContactRel business object. This
 * entity object should include all the attributes as defined by the business
 * object.
 * 
 * @generated
 */
@SuppressWarnings("serial")
@Table(name=EObjXContactRelExt.tableName)
public class EObjXContactRelExt extends EObjCommon {

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public static final String tableName = "CONTACTREL";
    
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String xRetailerCodeColumn = "XRETAILER_CODE";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String xRetailerCodeJdbcType = "VARCHAR";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    xRetailerCodePrecision = 255;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String xContactRoleColumn = "XCONTACT_ROLE";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String xContactRoleJdbcType = "VARCHAR";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    xContactRolePrecision = 255;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String xContactPositionColumn = "XCONTACT_POSITION";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String xContactPositionJdbcType = "VARCHAR";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    xContactPositionPrecision = 255;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String xSourceIdentifierColumn = "XSOURCE_IDENT_TP_CD";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String xSourceIdentifierJdbcType = "BIGINT";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    xSourceIdentifierPrecision = 19;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String xLastModifiedSystemDateColumn = "XMODIFY_SYS_DT";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String xLastModifiedSystemDateJdbcType = "TIMESTAMP";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String deleteFlagColumn = "DELETE_FLAG";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String deleteFlagJdbcType = "VARCHAR";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    deleteFlagPrecision = 10;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String xContactRelRetailerFlagColumn = "XCONTACTREL_RETAILER_FLAG";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String xContactRelRetailerFlagJdbcType = "VARCHAR";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    xContactRelRetailerFlagPrecision = 5;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected Long contRelIdPK;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String xRetailerCode;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String xContactRole;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String xContactPosition;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected Long xSourceIdentifier;


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected  Timestamp xLastModifiedSystemDate;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String deleteFlag;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String xContactRelRetailerFlag;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
	private EObjCommon baseEntity = null;
	
	
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Default constructor.     
     *
     * @generated
     */
    public EObjXContactRelExt(EObjCommon baseEntity) {
        super();
        setBaseEntity (baseEntity);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Default constructor.     
     *
     * @generated
     */
    public EObjXContactRelExt() {
        super();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the contRelIdPK attribute. 
     *
     * @generated
     **/
	public Long getContRelIdPK (){
      return contRelIdPK;
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the contRelIdPK attribute. 
     *
     * @param contRelIdPK
     *     The new value of contRelIdPK. 
     * @generated
     */
    public void setContRelIdPK( Long contRelIdPK ){
    this.contRelIdPK = contRelIdPK;
  }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xRetailerCode attribute. 
     *
     * @generated
     */
    @Column(name=xRetailerCodeColumn)
    @DataType(jdbcType=xRetailerCodeJdbcType, precision=xRetailerCodePrecision)
    public String getXRetailerCode (){
        return xRetailerCode;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xRetailerCode attribute. 
     *
     * @param xRetailerCode
     *     The new value of XRetailerCode. 
     * @generated
     */
    public void setXRetailerCode( String xRetailerCode ){
        this.xRetailerCode = xRetailerCode;
    
  }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xContactRole attribute. 
     *
     * @generated
     */
    @Column(name=xContactRoleColumn)
    @DataType(jdbcType=xContactRoleJdbcType, precision=xContactRolePrecision)
    public String getXContactRole (){
        return xContactRole;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xContactRole attribute. 
     *
     * @param xContactRole
     *     The new value of XContactRole. 
     * @generated
     */
    public void setXContactRole( String xContactRole ){
        this.xContactRole = xContactRole;
    
  }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xContactPosition attribute. 
     *
     * @generated
     */
    @Column(name=xContactPositionColumn)
    @DataType(jdbcType=xContactPositionJdbcType, precision=xContactPositionPrecision)
    public String getXContactPosition (){
        return xContactPosition;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xContactPosition attribute. 
     *
     * @param xContactPosition
     *     The new value of XContactPosition. 
     * @generated
     */
    public void setXContactPosition( String xContactPosition ){
        this.xContactPosition = xContactPosition;
    
  }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xSourceIdentifier attribute. 
     *
     * @generated
     */
    @Column(name=xSourceIdentifierColumn)
    @DataType(jdbcType=xSourceIdentifierJdbcType, precision=xSourceIdentifierPrecision)
    public Long getXSourceIdentifier (){
        return xSourceIdentifier;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xSourceIdentifier attribute. 
     *
     * @param xSourceIdentifier
     *     The new value of XSourceIdentifier. 
     * @generated
     */
    public void setXSourceIdentifier( Long xSourceIdentifier ){
        this.xSourceIdentifier = xSourceIdentifier;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xLastModifiedSystemDate attribute. 
     *
     * @generated
     */
    @Column(name=xLastModifiedSystemDateColumn)
    @DataType(jdbcType=xLastModifiedSystemDateJdbcType)
    public Timestamp getXLastModifiedSystemDate (){
        return xLastModifiedSystemDate;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xLastModifiedSystemDate attribute. 
     *
     * @param xLastModifiedSystemDate
     *     The new value of XLastModifiedSystemDate. 
     * @generated
     */
    public void setXLastModifiedSystemDate( Timestamp xLastModifiedSystemDate ){
        this.xLastModifiedSystemDate = xLastModifiedSystemDate;
    
  }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the deleteFlag attribute. 
     *
     * @generated
     */
    @Column(name=deleteFlagColumn)
    @DataType(jdbcType=deleteFlagJdbcType, precision=deleteFlagPrecision)
    public String getDeleteFlag (){
        return deleteFlag;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the deleteFlag attribute. 
     *
     * @param deleteFlag
     *     The new value of DeleteFlag. 
     * @generated
     */
    public void setDeleteFlag( String deleteFlag ){
        this.deleteFlag = deleteFlag;
    
  }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xContactRelRetailerFlag attribute. 
     *
     * @generated
     */
    @Column(name=xContactRelRetailerFlagColumn)
    @DataType(jdbcType=xContactRelRetailerFlagJdbcType, precision=xContactRelRetailerFlagPrecision)
    public String getXContactRelRetailerFlag (){
        return xContactRelRetailerFlag;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xContactRelRetailerFlag attribute. 
     *
     * @param xContactRelRetailerFlag
     *     The new value of XContactRelRetailerFlag. 
     * @generated
     */
    public void setXContactRelRetailerFlag( String xContactRelRetailerFlag ){
        this.xContactRelRetailerFlag = xContactRelRetailerFlag;
    
  }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the primary key. 
     *
     * @param aUniqueId
     *     The new value of the primary key. 
     * @generated
   */
	public void setPrimaryKey(Object aUniqueId) {
    this.setContRelIdPK((Long)aUniqueId);
  }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the primary key.
     *
     * @generated
     */
	public Object getPrimaryKey() {
    return this.getContRelIdPK();
  }
	 
	 /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes before the extension is added to the database.
     *
     * @generated
     */
    @Override
    protected void beforeAddEx()
    {
        enforceBaseEntityAttributes();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes before the extension is updated in the database
     *
     * @generated
     */
    @Override
    protected void beforeUpdateEx()
    {
        enforceBaseEntityAttributes ();
    }
    
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Handles optimistic locking.
     *
     * @generated
     */
    @Override
    protected void handleOptimisticLocking()
    {
        this.setOldLastUpdateDt(baseEntity.getLastUpdateDt());
        this.setLastUpdateDt(getNextLastUpdateDate());
        baseEntity.setLastUpdateDt(this.getLastUpdateDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Enforces and synchronizes the extension and base entity attributes.
     *
     * @generated
     */
    private void enforceBaseEntityAttributes()
    {
        this.setLastUpdateTxId(baseEntity.getLastUpdateTxId());
        this.setLastUpdateUser(baseEntity.getLastUpdateUser());
        this.setPrimaryKey(baseEntity.getPrimaryKey());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the base entity and syncs all attributes between extension and base entity.
     *
     * @generated
     */
    public void setBaseEntity (EObjCommon baseEntity)
    {
        if (baseEntity == null)
            throw new java.lang.IllegalArgumentException ("baseEntity is null");
        
        this.baseEntity = baseEntity;
        enforceBaseEntityAttributes();
        if( this.getLastUpdateDt() == null ){
        	this.setLastUpdateDt(baseEntity.getLastUpdateDt());
        	this.setOldLastUpdateDt(baseEntity.getOldLastUpdateDt());
        }
    }
}


