/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[d93fc36fecfa503c1478b19396f53b40]
 */


package com.ibm.daimler.dsea.entityObject;

import java.util.Iterator;
import com.ibm.mdm.base.db.EntityMapping;
import com.ibm.pdq.annotation.Select;
import com.ibm.pdq.annotation.Update;

import com.ibm.daimler.dsea.entityObject.EObjXContractDetailsJPN;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * @generated
 */
public interface EObjXContractDetailsJPNData {


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjXContractDetailsJPNSql = "select XContract_JPNPK_ID, CONT_ID, FINANCE_PRODUCT, CONTRACT_NUMBER, CONTRACT_ST_TP_CD, MARKET_NAME, GLOBAL_VIN, SOURCE_IDENT_TP_CD, START_DT, END_DT, MODIFY_SYS_DT, SFDC_ID, BATCH_IND, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from XCONTRACTDETAILSJPN where XContract_JPNPK_ID = ? ";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String createEObjXContractDetailsJPNSql = "insert into XCONTRACTDETAILSJPN (XContract_JPNPK_ID, CONT_ID, FINANCE_PRODUCT, CONTRACT_NUMBER, CONTRACT_ST_TP_CD, MARKET_NAME, GLOBAL_VIN, SOURCE_IDENT_TP_CD, START_DT, END_DT, MODIFY_SYS_DT, SFDC_ID, BATCH_IND, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( :xContractJPNpkId, :contId, :financeProduct, :contractNumber, :contractStatus, :marketName, :globalVIN, :sourceIdentifier, :startDate, :endDate, :lastModifiedSystemDate, :sFDCId, :batchInd, :lastUpdateDt, :lastUpdateUser, :lastUpdateTxId)";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String updateEObjXContractDetailsJPNSql = "update XCONTRACTDETAILSJPN set CONT_ID = :contId, FINANCE_PRODUCT = :financeProduct, CONTRACT_NUMBER = :contractNumber, CONTRACT_ST_TP_CD = :contractStatus, MARKET_NAME = :marketName, GLOBAL_VIN = :globalVIN, SOURCE_IDENT_TP_CD = :sourceIdentifier, START_DT = :startDate, END_DT = :endDate, MODIFY_SYS_DT = :lastModifiedSystemDate, SFDC_ID = :sFDCId, BATCH_IND = :batchInd, LAST_UPDATE_DT = :lastUpdateDt, LAST_UPDATE_USER = :lastUpdateUser, LAST_UPDATE_TX_ID = :lastUpdateTxId where XContract_JPNPK_ID = :xContractJPNpkId and LAST_UPDATE_DT = :oldLastUpdateDt";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String deleteEObjXContractDetailsJPNSql = "delete from XCONTRACTDETAILSJPN where XContract_JPNPK_ID = ?";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXContractDetailsJPNKeyField = "EObjXContractDetailsJPN.xContractJPNpkId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXContractDetailsJPNGetFields =
    "EObjXContractDetailsJPN.xContractJPNpkId," +
    "EObjXContractDetailsJPN.contId," +
    "EObjXContractDetailsJPN.financeProduct," +
    "EObjXContractDetailsJPN.contractNumber," +
    "EObjXContractDetailsJPN.contractStatus," +
    "EObjXContractDetailsJPN.marketName," +
    "EObjXContractDetailsJPN.globalVIN," +
    "EObjXContractDetailsJPN.sourceIdentifier," +
    "EObjXContractDetailsJPN.startDate," +
    "EObjXContractDetailsJPN.endDate," +
    "EObjXContractDetailsJPN.lastModifiedSystemDate," +
    "EObjXContractDetailsJPN.sFDCId," +
    "EObjXContractDetailsJPN.batchInd," +
    "EObjXContractDetailsJPN.lastUpdateDt," +
    "EObjXContractDetailsJPN.lastUpdateUser," +
    "EObjXContractDetailsJPN.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXContractDetailsJPNAllFields =
    "com.ibm.daimler.dsea.entityObject.EObjXContractDetailsJPN.xContractJPNpkId," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractDetailsJPN.contId," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractDetailsJPN.financeProduct," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractDetailsJPN.contractNumber," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractDetailsJPN.contractStatus," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractDetailsJPN.marketName," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractDetailsJPN.globalVIN," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractDetailsJPN.sourceIdentifier," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractDetailsJPN.startDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractDetailsJPN.endDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractDetailsJPN.lastModifiedSystemDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractDetailsJPN.sFDCId," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractDetailsJPN.batchInd," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractDetailsJPN.lastUpdateDt," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractDetailsJPN.lastUpdateUser," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractDetailsJPN.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXContractDetailsJPNUpdateFields =
    "com.ibm.daimler.dsea.entityObject.EObjXContractDetailsJPN.contId," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractDetailsJPN.financeProduct," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractDetailsJPN.contractNumber," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractDetailsJPN.contractStatus," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractDetailsJPN.marketName," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractDetailsJPN.globalVIN," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractDetailsJPN.sourceIdentifier," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractDetailsJPN.startDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractDetailsJPN.endDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractDetailsJPN.lastModifiedSystemDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractDetailsJPN.sFDCId," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractDetailsJPN.batchInd," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractDetailsJPN.lastUpdateDt," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractDetailsJPN.lastUpdateUser," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractDetailsJPN.lastUpdateTxId," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractDetailsJPN.xContractJPNpkId," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractDetailsJPN.oldLastUpdateDt";   

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Select XContractDetailsJPN by parameters.
   * @generated
   */
  @Select(sql=getEObjXContractDetailsJPNSql)
  @EntityMapping(parameters=EObjXContractDetailsJPNKeyField, results=EObjXContractDetailsJPNGetFields)
  Iterator<EObjXContractDetailsJPN> getEObjXContractDetailsJPN(Long xContractJPNpkId);  
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Create XContractDetailsJPN by EObjXContractDetailsJPN Object.
   * @generated
   */
  @Update(sql=createEObjXContractDetailsJPNSql)
  @EntityMapping(parameters=EObjXContractDetailsJPNAllFields)
    int createEObjXContractDetailsJPN(EObjXContractDetailsJPN e); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Update one XContractDetailsJPN by EObjXContractDetailsJPN object.
   * @generated
   */
  @Update(sql=updateEObjXContractDetailsJPNSql)
  @EntityMapping(parameters=EObjXContractDetailsJPNUpdateFields)
    int updateEObjXContractDetailsJPN(EObjXContractDetailsJPN e); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Delete XContractDetailsJPN by parameters.
   * @generated
   */
  @Update(sql=deleteEObjXContractDetailsJPNSql)
  @EntityMapping(parameters=EObjXContractDetailsJPNKeyField)
  int deleteEObjXContractDetailsJPN(Long xContractJPNpkId);

}

