package com.ibm.daimler.dsea.entityObject;

import com.ibm.pdq.runtime.generator.BaseParameterHandler;
import com.dwl.tcrm.coreParty.entityObject.EObjOrgName;
import java.util.Iterator;
import com.ibm.daimler.dsea.entityObject.EObjXOrgNameExt;
import java.sql.PreparedStatement;
import com.ibm.pdq.runtime.statement.StatementDescriptor;
import com.ibm.pdq.runtime.generator.BaseData;
import java.sql.SQLException;
import com.ibm.pdq.annotation.Metadata;
import com.ibm.mdm.base.db.ResultQueue2;
import com.ibm.pdq.runtime.generator.BaseRowHandler;
import com.ibm.pdq.runtime.statement.SqlStatementType;
import java.sql.Types;


@SuppressWarnings("unchecked")

/**
 * <!-- begin-user-doc -->
 * 
 * <!-- end-user-doc -->
 * 
 * @generated
 */
public class XOrgNameExtInquiryDataImpl  extends BaseData implements XOrgNameExtInquiryData
{

  /**
   * @generated
   */
  public static final String generatorVersion = "3.200.75";

  /**
   * @generated
   */
  public static final String identifier = "XOrgNameExtInquiryData";

  /**
   * @generated
   */
  public static final long generationTime = 0x0000015e13ff82b0L;

  /**
   * @generated
   */
  public static final String collection = "NULLID";

  /**
   * @generated
   */
  public static final String packageVersion = null;

  /**
   * @generated
   */
  public static final boolean forceSingleBindIsolation = false;

  /**
   * @generated
   */
  public XOrgNameExtInquiryDataImpl()
  {
    super();
  } 

  /**
   * @generated
   */
  public String getGeneratorVersion()
  {
    return generatorVersion;
  }

  /**
   * @Select( sql="SELECT DISTINCT A.H_ORG_NAME_ID AS HIST_ID_PK , A.H_ACTION_CODE , A.H_CREATED_BY , A.H_CREATE_DT , A.H_END_DT , A.ORG_NAME_ID , A.CONT_ID , A.ORG_NAME , A.START_DT , A.END_DT , A.ORG_NAME_TP_CD, A.S_ORG_NAME , A.NAME_SEARCH_KEY , A.LAST_UPDATE_DT , A.LAST_UPDATE_USER , A.LAST_UPDATE_TX_ID , A.LAST_USED_DT , A.LAST_VERIFIED_DT , A.SOURCE_IDENT_TP_CD, A.STANDARD_IND, A.XMODIFY_SYS_DT, A.XORG_NAME_LOCAL, A.XORGNAME_RETAILER_FLAG, A.X_BPID FROM H_ORGNAME A WHERE A.CONT_ID = ? AND (( ? BETWEEN A.H_CREATE_DT AND A.H_END_DT ) OR ( ? >= A.H_CREATE_DT AND A.H_END_DT IS NULL ))", pattern="tableAlias (ORGNAME => com.dwl.tcrm.coreParty.entityObject.EObjOrgName, H_ORGNAME => com.dwl.tcrm.coreParty.entityObject.EObjOrgName , ORGNAME => com.ibm.daimler.dsea.entityObject.EObjXOrgNameExt , H_ORGNAME => com.ibm.daimler.dsea.entityObject.EObjXOrgNameExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue2<EObjOrgName,EObjXOrgNameExt>> getOrgNameHistory (Object[] parameters)
  {
    return queryIterator (getOrgNameHistoryStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getOrgNameHistoryStatementDescriptor = createStatementDescriptor (
    "getOrgNameHistory(Object[])",
    "SELECT DISTINCT A.H_ORG_NAME_ID AS HIST_ID_PK , A.H_ACTION_CODE , A.H_CREATED_BY , A.H_CREATE_DT , A.H_END_DT , A.ORG_NAME_ID , A.CONT_ID , A.ORG_NAME , A.START_DT , A.END_DT , A.ORG_NAME_TP_CD, A.S_ORG_NAME , A.NAME_SEARCH_KEY , A.LAST_UPDATE_DT , A.LAST_UPDATE_USER , A.LAST_UPDATE_TX_ID , A.LAST_USED_DT , A.LAST_VERIFIED_DT , A.SOURCE_IDENT_TP_CD, A.STANDARD_IND, A.XMODIFY_SYS_DT, A.XORG_NAME_LOCAL, A.XORGNAME_RETAILER_FLAG, A.X_BPID FROM H_ORGNAME A WHERE A.CONT_ID = ? AND (( ? BETWEEN A.H_CREATE_DT AND A.H_END_DT ) OR ( ? >= A.H_CREATE_DT AND A.H_END_DT IS NULL ))",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"hist_id_pk", "h_action_code", "h_created_by", "h_create_dt", "h_end_dt", "org_name_id", "cont_id", "org_name", "start_dt", "end_dt", "org_name_tp_cd", "s_org_name", "name_search_key", "last_update_dt", "last_update_user", "last_update_tx_id", "last_used_dt", "last_verified_dt", "source_ident_tp_cd", "standard_ind", "xmodify_sys_dt", "xorg_name_local", "xorgname_retailer_flag", "x_bpid"},
    new GetOrgNameHistoryParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP}, {19, 0, 0}, {0, 0, 0}, {1, 1, 1}},
    null,
    new GetOrgNameHistoryRowHandler (),
    new int[][]{ {Types.BIGINT, Types.CHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.CHAR, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR}, {19, 1, 20, 0, 0, 19, 19, 255, 0, 0, 19, 255, 30, 0, 20, 19, 0, 0, 19, 1, 0, 500, 10, 50}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    1);

  /**
   * @generated
   */
  public static class GetOrgNameHistoryParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetOrgNameHistoryRowHandler extends BaseRowHandler<ResultQueue2<EObjOrgName,EObjXOrgNameExt>>
  {
    /**
     * @generated
     */
    public ResultQueue2<EObjOrgName,EObjXOrgNameExt> handle (java.sql.ResultSet rs, ResultQueue2<EObjOrgName,EObjXOrgNameExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue2<EObjOrgName,EObjXOrgNameExt> ();

      EObjOrgName returnObject1 = new EObjOrgName ();
      returnObject1.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject1.setHistActionCode(getString (rs, 2)); 
      returnObject1.setHistCreatedBy(getString (rs, 3)); 
      returnObject1.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject1.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject1.setOrgNameIdPK(getLongObject (rs, 6)); 
      returnObject1.setContId(getLongObject (rs, 7)); 
      returnObject1.setOrgName(getString (rs, 8)); 
      returnObject1.setStartDt(getTimestamp (rs, 9)); 
      returnObject1.setEndDt(getTimestamp (rs, 10)); 
      returnObject1.setOrgNameTpCd(getLongObject (rs, 11)); 
      returnObject1.setSOrgName(getString (rs, 12)); 
      returnObject1.setNameSearchKey(getString (rs, 13)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 14)); 
      returnObject1.setLastUpdateUser(getString (rs, 15)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 16)); 
      returnObject1.setLastUsedDt(getTimestamp (rs, 17)); 
      returnObject1.setLastVerifiedDt(getTimestamp (rs, 18)); 
      returnObject1.setSourceIdentTpCd(getLongObject (rs, 19)); 
      returnObject1.setOrgNameStandardInd(getString (rs, 20)); 
      returnObject.add (returnObject1);

      EObjXOrgNameExt returnObject2 = new EObjXOrgNameExt ();
      returnObject2.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject2.setHistActionCode(getString (rs, 2)); 
      returnObject2.setHistCreatedBy(getString (rs, 3)); 
      returnObject2.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject2.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject2.setLastUpdateDt(getTimestamp (rs, 14)); 
      returnObject2.setLastUpdateUser(getString (rs, 15)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 16)); 
      returnObject2.setXLastModifiedSystemDate(getTimestamp (rs, 21)); 
      returnObject2.setXOrganizationNameLocal(getString (rs, 22)); 
      returnObject2.setXOrgNameRetailerFlag(getString (rs, 23)); 
      returnObject2.setX_BPID(getString (rs, 24)); 
      returnObject.add (returnObject2);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT ORGNAME.ORG_NAME_ID, ORGNAME.CONT_ID , ORGNAME.ORG_NAME , ORGNAME.START_DT , ORGNAME.END_DT , ORGNAME.ORG_NAME_TP_CD , ORGNAME.S_ORG_NAME , ORGNAME.NAME_SEARCH_KEY , ORGNAME.LAST_UPDATE_DT , ORGNAME.LAST_UPDATE_USER ,ORGNAME.LAST_UPDATE_TX_ID , ORGNAME.LAST_USED_DT , ORGNAME.LAST_VERIFIED_DT , ORGNAME.SOURCE_IDENT_TP_CD, ORGNAME.P_ORG_NAME, ORGNAME.STANDARD_IND, ORGNAME.XMODIFY_SYS_DT, ORGNAME.XORG_NAME_LOCAL, ORGNAME.XORGNAME_RETAILER_FLAG, ORGNAME.X_BPID FROM ORGNAME WHERE ((ORGNAME.CONT_ID = ? ) AND (ORGNAME.END_DT IS NULL OR ORGNAME.END_DT > ?))", pattern="tableAlias (ORGNAME => com.dwl.tcrm.coreParty.entityObject.EObjOrgName, H_ORGNAME => com.dwl.tcrm.coreParty.entityObject.EObjOrgName , ORGNAME => com.ibm.daimler.dsea.entityObject.EObjXOrgNameExt , H_ORGNAME => com.ibm.daimler.dsea.entityObject.EObjXOrgNameExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue2<EObjOrgName,EObjXOrgNameExt>> getOrgNameActive (Object[] parameters)
  {
    return queryIterator (getOrgNameActiveStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getOrgNameActiveStatementDescriptor = createStatementDescriptor (
    "getOrgNameActive(Object[])",
    "SELECT ORGNAME.ORG_NAME_ID, ORGNAME.CONT_ID , ORGNAME.ORG_NAME , ORGNAME.START_DT , ORGNAME.END_DT , ORGNAME.ORG_NAME_TP_CD , ORGNAME.S_ORG_NAME , ORGNAME.NAME_SEARCH_KEY , ORGNAME.LAST_UPDATE_DT , ORGNAME.LAST_UPDATE_USER ,ORGNAME.LAST_UPDATE_TX_ID , ORGNAME.LAST_USED_DT , ORGNAME.LAST_VERIFIED_DT , ORGNAME.SOURCE_IDENT_TP_CD, ORGNAME.P_ORG_NAME, ORGNAME.STANDARD_IND, ORGNAME.XMODIFY_SYS_DT, ORGNAME.XORG_NAME_LOCAL, ORGNAME.XORGNAME_RETAILER_FLAG, ORGNAME.X_BPID FROM ORGNAME WHERE ((ORGNAME.CONT_ID = ? ) AND (ORGNAME.END_DT IS NULL OR ORGNAME.END_DT > ?))",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"org_name_id", "cont_id", "org_name", "start_dt", "end_dt", "org_name_tp_cd", "s_org_name", "name_search_key", "last_update_dt", "last_update_user", "last_update_tx_id", "last_used_dt", "last_verified_dt", "source_ident_tp_cd", "p_org_name", "standard_ind", "xmodify_sys_dt", "xorg_name_local", "xorgname_retailer_flag", "x_bpid"},
    new GetOrgNameActiveParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP}, {19, 0}, {0, 0}, {1, 1}},
    null,
    new GetOrgNameActiveRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.VARCHAR, Types.CHAR, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR}, {19, 19, 255, 0, 0, 19, 255, 30, 0, 20, 19, 0, 0, 19, 20, 1, 0, 500, 10, 50}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    2);

  /**
   * @generated
   */
  public static class GetOrgNameActiveParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetOrgNameActiveRowHandler extends BaseRowHandler<ResultQueue2<EObjOrgName,EObjXOrgNameExt>>
  {
    /**
     * @generated
     */
    public ResultQueue2<EObjOrgName,EObjXOrgNameExt> handle (java.sql.ResultSet rs, ResultQueue2<EObjOrgName,EObjXOrgNameExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue2<EObjOrgName,EObjXOrgNameExt> ();

      EObjOrgName returnObject1 = new EObjOrgName ();
      returnObject1.setOrgNameIdPK(getLongObject (rs, 1)); 
      returnObject1.setContId(getLongObject (rs, 2)); 
      returnObject1.setOrgName(getString (rs, 3)); 
      returnObject1.setStartDt(getTimestamp (rs, 4)); 
      returnObject1.setEndDt(getTimestamp (rs, 5)); 
      returnObject1.setOrgNameTpCd(getLongObject (rs, 6)); 
      returnObject1.setSOrgName(getString (rs, 7)); 
      returnObject1.setNameSearchKey(getString (rs, 8)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 9)); 
      returnObject1.setLastUpdateUser(getString (rs, 10)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 11)); 
      returnObject1.setLastUsedDt(getTimestamp (rs, 12)); 
      returnObject1.setLastVerifiedDt(getTimestamp (rs, 13)); 
      returnObject1.setSourceIdentTpCd(getLongObject (rs, 14)); 
      returnObject1.setPOrgName(getString (rs, 15)); 
      returnObject1.setOrgNameStandardInd(getString (rs, 16)); 
      returnObject.add (returnObject1);

      EObjXOrgNameExt returnObject2 = new EObjXOrgNameExt ();
      returnObject2.setLastUpdateDt(getTimestamp (rs, 9)); 
      returnObject2.setLastUpdateUser(getString (rs, 10)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 11)); 
      returnObject2.setXLastModifiedSystemDate(getTimestamp (rs, 17)); 
      returnObject2.setXOrganizationNameLocal(getString (rs, 18)); 
      returnObject2.setXOrgNameRetailerFlag(getString (rs, 19)); 
      returnObject2.setX_BPID(getString (rs, 20)); 
      returnObject.add (returnObject2);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT ORGNAME.ORG_NAME_ID , ORGNAME.CONT_ID , ORGNAME.ORG_NAME , ORGNAME.START_DT , ORGNAME.END_DT , ORGNAME.ORG_NAME_TP_CD , ORGNAME.S_ORG_NAME , ORGNAME.NAME_SEARCH_KEY , ORGNAME.LAST_UPDATE_DT , ORGNAME.LAST_UPDATE_USER , ORGNAME.LAST_UPDATE_TX_ID , ORGNAME.LAST_USED_DT , ORGNAME.LAST_VERIFIED_DT , ORGNAME.SOURCE_IDENT_TP_CD, ORGNAME.STANDARD_IND, ORGNAME.XMODIFY_SYS_DT, ORGNAME.XORG_NAME_LOCAL, ORGNAME.XORGNAME_RETAILER_FLAG, ORGNAME.X_BPID FROM ORGNAME WHERE ((ORGNAME.CONT_ID = ? ) AND (ORGNAME.END_DT < ? ))", pattern="tableAlias (ORGNAME => com.dwl.tcrm.coreParty.entityObject.EObjOrgName, H_ORGNAME => com.dwl.tcrm.coreParty.entityObject.EObjOrgName , ORGNAME => com.ibm.daimler.dsea.entityObject.EObjXOrgNameExt , H_ORGNAME => com.ibm.daimler.dsea.entityObject.EObjXOrgNameExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue2<EObjOrgName,EObjXOrgNameExt>> getOrgNameInactive (Object[] parameters)
  {
    return queryIterator (getOrgNameInactiveStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getOrgNameInactiveStatementDescriptor = createStatementDescriptor (
    "getOrgNameInactive(Object[])",
    "SELECT ORGNAME.ORG_NAME_ID , ORGNAME.CONT_ID , ORGNAME.ORG_NAME , ORGNAME.START_DT , ORGNAME.END_DT , ORGNAME.ORG_NAME_TP_CD , ORGNAME.S_ORG_NAME , ORGNAME.NAME_SEARCH_KEY , ORGNAME.LAST_UPDATE_DT , ORGNAME.LAST_UPDATE_USER , ORGNAME.LAST_UPDATE_TX_ID , ORGNAME.LAST_USED_DT , ORGNAME.LAST_VERIFIED_DT , ORGNAME.SOURCE_IDENT_TP_CD, ORGNAME.STANDARD_IND, ORGNAME.XMODIFY_SYS_DT, ORGNAME.XORG_NAME_LOCAL, ORGNAME.XORGNAME_RETAILER_FLAG, ORGNAME.X_BPID FROM ORGNAME WHERE ((ORGNAME.CONT_ID = ? ) AND (ORGNAME.END_DT < ? ))",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"org_name_id", "cont_id", "org_name", "start_dt", "end_dt", "org_name_tp_cd", "s_org_name", "name_search_key", "last_update_dt", "last_update_user", "last_update_tx_id", "last_used_dt", "last_verified_dt", "source_ident_tp_cd", "standard_ind", "xmodify_sys_dt", "xorg_name_local", "xorgname_retailer_flag", "x_bpid"},
    new GetOrgNameInactiveParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP}, {19, 0}, {0, 0}, {1, 1}},
    null,
    new GetOrgNameInactiveRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.CHAR, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR}, {19, 19, 255, 0, 0, 19, 255, 30, 0, 20, 19, 0, 0, 19, 1, 0, 500, 10, 50}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    3);

  /**
   * @generated
   */
  public static class GetOrgNameInactiveParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetOrgNameInactiveRowHandler extends BaseRowHandler<ResultQueue2<EObjOrgName,EObjXOrgNameExt>>
  {
    /**
     * @generated
     */
    public ResultQueue2<EObjOrgName,EObjXOrgNameExt> handle (java.sql.ResultSet rs, ResultQueue2<EObjOrgName,EObjXOrgNameExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue2<EObjOrgName,EObjXOrgNameExt> ();

      EObjOrgName returnObject1 = new EObjOrgName ();
      returnObject1.setOrgNameIdPK(getLongObject (rs, 1)); 
      returnObject1.setContId(getLongObject (rs, 2)); 
      returnObject1.setOrgName(getString (rs, 3)); 
      returnObject1.setStartDt(getTimestamp (rs, 4)); 
      returnObject1.setEndDt(getTimestamp (rs, 5)); 
      returnObject1.setOrgNameTpCd(getLongObject (rs, 6)); 
      returnObject1.setSOrgName(getString (rs, 7)); 
      returnObject1.setNameSearchKey(getString (rs, 8)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 9)); 
      returnObject1.setLastUpdateUser(getString (rs, 10)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 11)); 
      returnObject1.setLastUsedDt(getTimestamp (rs, 12)); 
      returnObject1.setLastVerifiedDt(getTimestamp (rs, 13)); 
      returnObject1.setSourceIdentTpCd(getLongObject (rs, 14)); 
      returnObject1.setOrgNameStandardInd(getString (rs, 15)); 
      returnObject.add (returnObject1);

      EObjXOrgNameExt returnObject2 = new EObjXOrgNameExt ();
      returnObject2.setLastUpdateDt(getTimestamp (rs, 9)); 
      returnObject2.setLastUpdateUser(getString (rs, 10)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 11)); 
      returnObject2.setXLastModifiedSystemDate(getTimestamp (rs, 16)); 
      returnObject2.setXOrganizationNameLocal(getString (rs, 17)); 
      returnObject2.setXOrgNameRetailerFlag(getString (rs, 18)); 
      returnObject2.setX_BPID(getString (rs, 19)); 
      returnObject.add (returnObject2);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT ORGNAME.ORG_NAME_ID , ORGNAME.CONT_ID , ORGNAME.ORG_NAME , ORGNAME.START_DT , ORGNAME.END_DT , ORGNAME.ORG_NAME_TP_CD , ORGNAME.S_ORG_NAME , ORGNAME.NAME_SEARCH_KEY , ORGNAME.LAST_UPDATE_DT , ORGNAME.LAST_UPDATE_USER , ORGNAME.LAST_UPDATE_TX_ID , ORGNAME.LAST_USED_DT , ORGNAME.LAST_VERIFIED_DT , ORGNAME.SOURCE_IDENT_TP_CD, ORGNAME.STANDARD_IND, ORGNAME.XMODIFY_SYS_DT, ORGNAME.XORG_NAME_LOCAL, ORGNAME.XORGNAME_RETAILER_FLAG, ORGNAME.X_BPID FROM ORGNAME WHERE (ORGNAME.CONT_ID = ? )", pattern="tableAlias (ORGNAME => com.dwl.tcrm.coreParty.entityObject.EObjOrgName, H_ORGNAME => com.dwl.tcrm.coreParty.entityObject.EObjOrgName , ORGNAME => com.ibm.daimler.dsea.entityObject.EObjXOrgNameExt , H_ORGNAME => com.ibm.daimler.dsea.entityObject.EObjXOrgNameExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue2<EObjOrgName,EObjXOrgNameExt>> getOrgName (Long parameters)
  {
    return queryIterator (getOrgNameStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getOrgNameStatementDescriptor = createStatementDescriptor (
    "getOrgName(Long)",
    "SELECT ORGNAME.ORG_NAME_ID , ORGNAME.CONT_ID , ORGNAME.ORG_NAME , ORGNAME.START_DT , ORGNAME.END_DT , ORGNAME.ORG_NAME_TP_CD , ORGNAME.S_ORG_NAME , ORGNAME.NAME_SEARCH_KEY , ORGNAME.LAST_UPDATE_DT , ORGNAME.LAST_UPDATE_USER , ORGNAME.LAST_UPDATE_TX_ID , ORGNAME.LAST_USED_DT , ORGNAME.LAST_VERIFIED_DT , ORGNAME.SOURCE_IDENT_TP_CD, ORGNAME.STANDARD_IND, ORGNAME.XMODIFY_SYS_DT, ORGNAME.XORG_NAME_LOCAL, ORGNAME.XORGNAME_RETAILER_FLAG, ORGNAME.X_BPID FROM ORGNAME WHERE (ORGNAME.CONT_ID = ? )",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"org_name_id", "cont_id", "org_name", "start_dt", "end_dt", "org_name_tp_cd", "s_org_name", "name_search_key", "last_update_dt", "last_update_user", "last_update_tx_id", "last_used_dt", "last_verified_dt", "source_ident_tp_cd", "standard_ind", "xmodify_sys_dt", "xorg_name_local", "xorgname_retailer_flag", "x_bpid"},
    new GetOrgNameParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetOrgNameRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.CHAR, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR}, {19, 19, 255, 0, 0, 19, 255, 30, 0, 20, 19, 0, 0, 19, 1, 0, 500, 10, 50}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    4);

  /**
   * @generated
   */
  public static class GetOrgNameParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setLong (stmt, 1, Types.BIGINT, (Long)parameters[0]);
    }
  }

  /**
   * @generated
   */
  public static class GetOrgNameRowHandler extends BaseRowHandler<ResultQueue2<EObjOrgName,EObjXOrgNameExt>>
  {
    /**
     * @generated
     */
    public ResultQueue2<EObjOrgName,EObjXOrgNameExt> handle (java.sql.ResultSet rs, ResultQueue2<EObjOrgName,EObjXOrgNameExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue2<EObjOrgName,EObjXOrgNameExt> ();

      EObjOrgName returnObject1 = new EObjOrgName ();
      returnObject1.setOrgNameIdPK(getLongObject (rs, 1)); 
      returnObject1.setContId(getLongObject (rs, 2)); 
      returnObject1.setOrgName(getString (rs, 3)); 
      returnObject1.setStartDt(getTimestamp (rs, 4)); 
      returnObject1.setEndDt(getTimestamp (rs, 5)); 
      returnObject1.setOrgNameTpCd(getLongObject (rs, 6)); 
      returnObject1.setSOrgName(getString (rs, 7)); 
      returnObject1.setNameSearchKey(getString (rs, 8)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 9)); 
      returnObject1.setLastUpdateUser(getString (rs, 10)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 11)); 
      returnObject1.setLastUsedDt(getTimestamp (rs, 12)); 
      returnObject1.setLastVerifiedDt(getTimestamp (rs, 13)); 
      returnObject1.setSourceIdentTpCd(getLongObject (rs, 14)); 
      returnObject1.setOrgNameStandardInd(getString (rs, 15)); 
      returnObject.add (returnObject1);

      EObjXOrgNameExt returnObject2 = new EObjXOrgNameExt ();
      returnObject2.setLastUpdateDt(getTimestamp (rs, 9)); 
      returnObject2.setLastUpdateUser(getString (rs, 10)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 11)); 
      returnObject2.setXLastModifiedSystemDate(getTimestamp (rs, 16)); 
      returnObject2.setXOrganizationNameLocal(getString (rs, 17)); 
      returnObject2.setXOrgNameRetailerFlag(getString (rs, 18)); 
      returnObject2.setX_BPID(getString (rs, 19)); 
      returnObject.add (returnObject2);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT DISTINCT A.H_ORG_NAME_ID AS HIST_ID_PK, A.H_ACTION_CODE , A.H_CREATED_BY , A.H_CREATE_DT , A.H_END_DT , A.ORG_NAME_ID , A.CONT_ID , A.ORG_NAME , A.START_DT , A.END_DT , A.ORG_NAME_TP_CD , A.S_ORG_NAME , A.NAME_SEARCH_KEY , A.LAST_UPDATE_DT , A.LAST_UPDATE_USER , A.LAST_UPDATE_TX_ID , A.LAST_USED_DT , A.LAST_VERIFIED_DT , A.SOURCE_IDENT_TP_CD, A.STANDARD_IND, A.XMODIFY_SYS_DT, A.XORG_NAME_LOCAL, A.XORGNAME_RETAILER_FLAG, A.X_BPID FROM H_ORGNAME A WHERE A.CONT_ID = ? AND A.ORG_NAME_TP_CD = ? AND (? BETWEEN A.H_CREATE_DT AND A.H_END_DT OR (? >= A.H_CREATE_DT AND A.H_END_DT IS NULL ))", pattern="tableAlias (ORGNAME => com.dwl.tcrm.coreParty.entityObject.EObjOrgName, H_ORGNAME => com.dwl.tcrm.coreParty.entityObject.EObjOrgName , ORGNAME => com.ibm.daimler.dsea.entityObject.EObjXOrgNameExt , H_ORGNAME => com.ibm.daimler.dsea.entityObject.EObjXOrgNameExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue2<EObjOrgName,EObjXOrgNameExt>> getOrgNameHistoryByType (Object[] parameters)
  {
    return queryIterator (getOrgNameHistoryByTypeStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getOrgNameHistoryByTypeStatementDescriptor = createStatementDescriptor (
    "getOrgNameHistoryByType(Object[])",
    "SELECT DISTINCT A.H_ORG_NAME_ID AS HIST_ID_PK, A.H_ACTION_CODE , A.H_CREATED_BY , A.H_CREATE_DT , A.H_END_DT , A.ORG_NAME_ID , A.CONT_ID , A.ORG_NAME , A.START_DT , A.END_DT , A.ORG_NAME_TP_CD , A.S_ORG_NAME , A.NAME_SEARCH_KEY , A.LAST_UPDATE_DT , A.LAST_UPDATE_USER , A.LAST_UPDATE_TX_ID , A.LAST_USED_DT , A.LAST_VERIFIED_DT , A.SOURCE_IDENT_TP_CD, A.STANDARD_IND, A.XMODIFY_SYS_DT, A.XORG_NAME_LOCAL, A.XORGNAME_RETAILER_FLAG, A.X_BPID FROM H_ORGNAME A WHERE A.CONT_ID = ? AND A.ORG_NAME_TP_CD = ? AND (? BETWEEN A.H_CREATE_DT AND A.H_END_DT OR (? >= A.H_CREATE_DT AND A.H_END_DT IS NULL ))",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"hist_id_pk", "h_action_code", "h_created_by", "h_create_dt", "h_end_dt", "org_name_id", "cont_id", "org_name", "start_dt", "end_dt", "org_name_tp_cd", "s_org_name", "name_search_key", "last_update_dt", "last_update_user", "last_update_tx_id", "last_used_dt", "last_verified_dt", "source_ident_tp_cd", "standard_ind", "xmodify_sys_dt", "xorg_name_local", "xorgname_retailer_flag", "x_bpid"},
    new GetOrgNameHistoryByTypeParameterHandler (),
    new int[][]{{Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP}, {19, 19, 0, 0}, {0, 0, 0, 0}, {1, 1, 1, 1}},
    null,
    new GetOrgNameHistoryByTypeRowHandler (),
    new int[][]{ {Types.BIGINT, Types.CHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.CHAR, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR}, {19, 1, 20, 0, 0, 19, 19, 255, 0, 0, 19, 255, 30, 0, 20, 19, 0, 0, 19, 1, 0, 500, 10, 50}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    5);

  /**
   * @generated
   */
  public static class GetOrgNameHistoryByTypeParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.BIGINT, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
      setObject (stmt, 4, Types.TIMESTAMP, parameters[3], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetOrgNameHistoryByTypeRowHandler extends BaseRowHandler<ResultQueue2<EObjOrgName,EObjXOrgNameExt>>
  {
    /**
     * @generated
     */
    public ResultQueue2<EObjOrgName,EObjXOrgNameExt> handle (java.sql.ResultSet rs, ResultQueue2<EObjOrgName,EObjXOrgNameExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue2<EObjOrgName,EObjXOrgNameExt> ();

      EObjOrgName returnObject1 = new EObjOrgName ();
      returnObject1.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject1.setHistActionCode(getString (rs, 2)); 
      returnObject1.setHistCreatedBy(getString (rs, 3)); 
      returnObject1.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject1.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject1.setOrgNameIdPK(getLongObject (rs, 6)); 
      returnObject1.setContId(getLongObject (rs, 7)); 
      returnObject1.setOrgName(getString (rs, 8)); 
      returnObject1.setStartDt(getTimestamp (rs, 9)); 
      returnObject1.setEndDt(getTimestamp (rs, 10)); 
      returnObject1.setOrgNameTpCd(getLongObject (rs, 11)); 
      returnObject1.setSOrgName(getString (rs, 12)); 
      returnObject1.setNameSearchKey(getString (rs, 13)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 14)); 
      returnObject1.setLastUpdateUser(getString (rs, 15)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 16)); 
      returnObject1.setLastUsedDt(getTimestamp (rs, 17)); 
      returnObject1.setLastVerifiedDt(getTimestamp (rs, 18)); 
      returnObject1.setSourceIdentTpCd(getLongObject (rs, 19)); 
      returnObject1.setOrgNameStandardInd(getString (rs, 20)); 
      returnObject.add (returnObject1);

      EObjXOrgNameExt returnObject2 = new EObjXOrgNameExt ();
      returnObject2.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject2.setHistActionCode(getString (rs, 2)); 
      returnObject2.setHistCreatedBy(getString (rs, 3)); 
      returnObject2.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject2.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject2.setLastUpdateDt(getTimestamp (rs, 14)); 
      returnObject2.setLastUpdateUser(getString (rs, 15)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 16)); 
      returnObject2.setXLastModifiedSystemDate(getTimestamp (rs, 21)); 
      returnObject2.setXOrganizationNameLocal(getString (rs, 22)); 
      returnObject2.setXOrgNameRetailerFlag(getString (rs, 23)); 
      returnObject2.setX_BPID(getString (rs, 24)); 
      returnObject.add (returnObject2);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT ORGNAME.ORG_NAME_ID , ORGNAME.CONT_ID , ORGNAME.ORG_NAME , ORGNAME.START_DT , ORGNAME.END_DT , ORGNAME.ORG_NAME_TP_CD , ORGNAME.S_ORG_NAME , ORGNAME.NAME_SEARCH_KEY , ORGNAME.LAST_UPDATE_DT , ORGNAME.LAST_UPDATE_USER , ORGNAME.LAST_UPDATE_TX_ID , ORGNAME.LAST_USED_DT , ORGNAME.LAST_VERIFIED_DT , ORGNAME.SOURCE_IDENT_TP_CD, ORGNAME.STANDARD_IND, ORGNAME.XMODIFY_SYS_DT, ORGNAME.XORG_NAME_LOCAL, ORGNAME.XORGNAME_RETAILER_FLAG, ORGNAME.X_BPID FROM ORGNAME WHERE ((ORGNAME.CONT_ID = ? ) AND (ORGNAME.ORG_NAME_TP_CD = ?) AND (ORGNAME.END_DT IS NULL OR ORGNAME.END_DT > ?))", pattern="tableAlias (ORGNAME => com.dwl.tcrm.coreParty.entityObject.EObjOrgName, H_ORGNAME => com.dwl.tcrm.coreParty.entityObject.EObjOrgName , ORGNAME => com.ibm.daimler.dsea.entityObject.EObjXOrgNameExt , H_ORGNAME => com.ibm.daimler.dsea.entityObject.EObjXOrgNameExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue2<EObjOrgName,EObjXOrgNameExt>> getOrgNameByType (Object[] parameters)
  {
    return queryIterator (getOrgNameByTypeStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getOrgNameByTypeStatementDescriptor = createStatementDescriptor (
    "getOrgNameByType(Object[])",
    "SELECT ORGNAME.ORG_NAME_ID , ORGNAME.CONT_ID , ORGNAME.ORG_NAME , ORGNAME.START_DT , ORGNAME.END_DT , ORGNAME.ORG_NAME_TP_CD , ORGNAME.S_ORG_NAME , ORGNAME.NAME_SEARCH_KEY , ORGNAME.LAST_UPDATE_DT , ORGNAME.LAST_UPDATE_USER , ORGNAME.LAST_UPDATE_TX_ID , ORGNAME.LAST_USED_DT , ORGNAME.LAST_VERIFIED_DT , ORGNAME.SOURCE_IDENT_TP_CD, ORGNAME.STANDARD_IND, ORGNAME.XMODIFY_SYS_DT, ORGNAME.XORG_NAME_LOCAL, ORGNAME.XORGNAME_RETAILER_FLAG, ORGNAME.X_BPID FROM ORGNAME WHERE ((ORGNAME.CONT_ID = ? ) AND (ORGNAME.ORG_NAME_TP_CD = ?) AND (ORGNAME.END_DT IS NULL OR ORGNAME.END_DT > ?))",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"org_name_id", "cont_id", "org_name", "start_dt", "end_dt", "org_name_tp_cd", "s_org_name", "name_search_key", "last_update_dt", "last_update_user", "last_update_tx_id", "last_used_dt", "last_verified_dt", "source_ident_tp_cd", "standard_ind", "xmodify_sys_dt", "xorg_name_local", "xorgname_retailer_flag", "x_bpid"},
    new GetOrgNameByTypeParameterHandler (),
    new int[][]{{Types.BIGINT, Types.BIGINT, Types.TIMESTAMP}, {19, 19, 0}, {0, 0, 0}, {1, 1, 1}},
    null,
    new GetOrgNameByTypeRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.CHAR, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR}, {19, 19, 255, 0, 0, 19, 255, 30, 0, 20, 19, 0, 0, 19, 1, 0, 500, 10, 50}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    6);

  /**
   * @generated
   */
  public static class GetOrgNameByTypeParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.BIGINT, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetOrgNameByTypeRowHandler extends BaseRowHandler<ResultQueue2<EObjOrgName,EObjXOrgNameExt>>
  {
    /**
     * @generated
     */
    public ResultQueue2<EObjOrgName,EObjXOrgNameExt> handle (java.sql.ResultSet rs, ResultQueue2<EObjOrgName,EObjXOrgNameExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue2<EObjOrgName,EObjXOrgNameExt> ();

      EObjOrgName returnObject1 = new EObjOrgName ();
      returnObject1.setOrgNameIdPK(getLongObject (rs, 1)); 
      returnObject1.setContId(getLongObject (rs, 2)); 
      returnObject1.setOrgName(getString (rs, 3)); 
      returnObject1.setStartDt(getTimestamp (rs, 4)); 
      returnObject1.setEndDt(getTimestamp (rs, 5)); 
      returnObject1.setOrgNameTpCd(getLongObject (rs, 6)); 
      returnObject1.setSOrgName(getString (rs, 7)); 
      returnObject1.setNameSearchKey(getString (rs, 8)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 9)); 
      returnObject1.setLastUpdateUser(getString (rs, 10)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 11)); 
      returnObject1.setLastUsedDt(getTimestamp (rs, 12)); 
      returnObject1.setLastVerifiedDt(getTimestamp (rs, 13)); 
      returnObject1.setSourceIdentTpCd(getLongObject (rs, 14)); 
      returnObject1.setOrgNameStandardInd(getString (rs, 15)); 
      returnObject.add (returnObject1);

      EObjXOrgNameExt returnObject2 = new EObjXOrgNameExt ();
      returnObject2.setLastUpdateDt(getTimestamp (rs, 9)); 
      returnObject2.setLastUpdateUser(getString (rs, 10)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 11)); 
      returnObject2.setXLastModifiedSystemDate(getTimestamp (rs, 16)); 
      returnObject2.setXOrganizationNameLocal(getString (rs, 17)); 
      returnObject2.setXOrgNameRetailerFlag(getString (rs, 18)); 
      returnObject2.setX_BPID(getString (rs, 19)); 
      returnObject.add (returnObject2);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT ORGNAME.ORG_NAME_ID ,ORGNAME.CONT_ID ,ORGNAME.ORG_NAME ,ORGNAME.START_DT ,ORGNAME.END_DT ,ORGNAME.ORG_NAME_TP_CD , ORGNAME.S_ORG_NAME ,ORGNAME.NAME_SEARCH_KEY ,ORGNAME.LAST_UPDATE_DT ,ORGNAME.LAST_UPDATE_USER , ORGNAME.LAST_UPDATE_TX_ID , ORGNAME.LAST_USED_DT , ORGNAME.LAST_VERIFIED_DT , ORGNAME.SOURCE_IDENT_TP_CD, ORGNAME.STANDARD_IND, ORGNAME.XMODIFY_SYS_DT, ORGNAME.XORG_NAME_LOCAL, ORGNAME.XORGNAME_RETAILER_FLAG, ORGNAME.X_BPID FROM ORGNAME WHERE (ORGNAME.ORG_NAME_ID = ?)", pattern="tableAlias (ORGNAME => com.dwl.tcrm.coreParty.entityObject.EObjOrgName, H_ORGNAME => com.dwl.tcrm.coreParty.entityObject.EObjOrgName , ORGNAME => com.ibm.daimler.dsea.entityObject.EObjXOrgNameExt , H_ORGNAME => com.ibm.daimler.dsea.entityObject.EObjXOrgNameExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue2<EObjOrgName,EObjXOrgNameExt>> getOrgNameByID (Long parameters)
  {
    return queryIterator (getOrgNameByIDStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getOrgNameByIDStatementDescriptor = createStatementDescriptor (
    "getOrgNameByID(Long)",
    "SELECT ORGNAME.ORG_NAME_ID ,ORGNAME.CONT_ID ,ORGNAME.ORG_NAME ,ORGNAME.START_DT ,ORGNAME.END_DT ,ORGNAME.ORG_NAME_TP_CD , ORGNAME.S_ORG_NAME ,ORGNAME.NAME_SEARCH_KEY ,ORGNAME.LAST_UPDATE_DT ,ORGNAME.LAST_UPDATE_USER , ORGNAME.LAST_UPDATE_TX_ID , ORGNAME.LAST_USED_DT , ORGNAME.LAST_VERIFIED_DT , ORGNAME.SOURCE_IDENT_TP_CD, ORGNAME.STANDARD_IND, ORGNAME.XMODIFY_SYS_DT, ORGNAME.XORG_NAME_LOCAL, ORGNAME.XORGNAME_RETAILER_FLAG, ORGNAME.X_BPID FROM ORGNAME WHERE (ORGNAME.ORG_NAME_ID = ?)",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"org_name_id", "cont_id", "org_name", "start_dt", "end_dt", "org_name_tp_cd", "s_org_name", "name_search_key", "last_update_dt", "last_update_user", "last_update_tx_id", "last_used_dt", "last_verified_dt", "source_ident_tp_cd", "standard_ind", "xmodify_sys_dt", "xorg_name_local", "xorgname_retailer_flag", "x_bpid"},
    new GetOrgNameByIDParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetOrgNameByIDRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.CHAR, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR}, {19, 19, 255, 0, 0, 19, 255, 30, 0, 20, 19, 0, 0, 19, 1, 0, 500, 10, 50}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    7);

  /**
   * @generated
   */
  public static class GetOrgNameByIDParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setLong (stmt, 1, Types.BIGINT, (Long)parameters[0]);
    }
  }

  /**
   * @generated
   */
  public static class GetOrgNameByIDRowHandler extends BaseRowHandler<ResultQueue2<EObjOrgName,EObjXOrgNameExt>>
  {
    /**
     * @generated
     */
    public ResultQueue2<EObjOrgName,EObjXOrgNameExt> handle (java.sql.ResultSet rs, ResultQueue2<EObjOrgName,EObjXOrgNameExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue2<EObjOrgName,EObjXOrgNameExt> ();

      EObjOrgName returnObject1 = new EObjOrgName ();
      returnObject1.setOrgNameIdPK(getLongObject (rs, 1)); 
      returnObject1.setContId(getLongObject (rs, 2)); 
      returnObject1.setOrgName(getString (rs, 3)); 
      returnObject1.setStartDt(getTimestamp (rs, 4)); 
      returnObject1.setEndDt(getTimestamp (rs, 5)); 
      returnObject1.setOrgNameTpCd(getLongObject (rs, 6)); 
      returnObject1.setSOrgName(getString (rs, 7)); 
      returnObject1.setNameSearchKey(getString (rs, 8)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 9)); 
      returnObject1.setLastUpdateUser(getString (rs, 10)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 11)); 
      returnObject1.setLastUsedDt(getTimestamp (rs, 12)); 
      returnObject1.setLastVerifiedDt(getTimestamp (rs, 13)); 
      returnObject1.setSourceIdentTpCd(getLongObject (rs, 14)); 
      returnObject1.setOrgNameStandardInd(getString (rs, 15)); 
      returnObject.add (returnObject1);

      EObjXOrgNameExt returnObject2 = new EObjXOrgNameExt ();
      returnObject2.setLastUpdateDt(getTimestamp (rs, 9)); 
      returnObject2.setLastUpdateUser(getString (rs, 10)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 11)); 
      returnObject2.setXLastModifiedSystemDate(getTimestamp (rs, 16)); 
      returnObject2.setXOrganizationNameLocal(getString (rs, 17)); 
      returnObject2.setXOrgNameRetailerFlag(getString (rs, 18)); 
      returnObject2.setX_BPID(getString (rs, 19)); 
      returnObject.add (returnObject2);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT H_ORGNAME.H_ORG_NAME_ID AS HIST_ID_PK, H_ORGNAME.H_ACTION_CODE, H_ORGNAME.H_CREATED_BY, H_ORGNAME.H_CREATE_DT, H_ORGNAME.CONT_ID , H_ORGNAME.ORG_NAME , H_ORGNAME.START_DT , H_ORGNAME.END_DT , H_ORGNAME.ORG_NAME_TP_CD , H_ORGNAME.S_ORG_NAME , H_ORGNAME.NAME_SEARCH_KEY , H_ORGNAME.LAST_UPDATE_DT , H_ORGNAME.LAST_UPDATE_USER , H_ORGNAME.LAST_UPDATE_TX_ID , H_ORGNAME.LAST_USED_DT , H_ORGNAME.LAST_VERIFIED_DT , H_ORGNAME.SOURCE_IDENT_TP_CD, H_ORGNAME.STANDARD_IND,H_ORGNAME.ORG_NAME_ID,H_ORGNAME.H_END_DT, H_ORGNAME.XMODIFY_SYS_DT, H_ORGNAME.XORG_NAME_LOCAL, H_ORGNAME.XORGNAME_RETAILER_FLAG, H_ORGNAME.X_BPID FROM H_ORGNAME WHERE (H_ORGNAME.H_ORG_NAME_ID = ?) AND (( ? BETWEEN H_ORGNAME.H_CREATE_DT AND H_ORGNAME.H_END_DT ) OR ( ? >= H_ORGNAME.H_CREATE_DT AND H_ORGNAME.H_END_DT IS NULL ))", pattern="tableAlias (ORGNAME => com.dwl.tcrm.coreParty.entityObject.EObjOrgName, H_ORGNAME => com.dwl.tcrm.coreParty.entityObject.EObjOrgName , ORGNAME => com.ibm.daimler.dsea.entityObject.EObjXOrgNameExt , H_ORGNAME => com.ibm.daimler.dsea.entityObject.EObjXOrgNameExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue2<EObjOrgName,EObjXOrgNameExt>> getOrgNameHistoryByID (Object[] parameters)
  {
    return queryIterator (getOrgNameHistoryByIDStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getOrgNameHistoryByIDStatementDescriptor = createStatementDescriptor (
    "getOrgNameHistoryByID(Object[])",
    "SELECT H_ORGNAME.H_ORG_NAME_ID AS HIST_ID_PK, H_ORGNAME.H_ACTION_CODE, H_ORGNAME.H_CREATED_BY, H_ORGNAME.H_CREATE_DT, H_ORGNAME.CONT_ID , H_ORGNAME.ORG_NAME , H_ORGNAME.START_DT , H_ORGNAME.END_DT , H_ORGNAME.ORG_NAME_TP_CD , H_ORGNAME.S_ORG_NAME , H_ORGNAME.NAME_SEARCH_KEY , H_ORGNAME.LAST_UPDATE_DT , H_ORGNAME.LAST_UPDATE_USER , H_ORGNAME.LAST_UPDATE_TX_ID , H_ORGNAME.LAST_USED_DT , H_ORGNAME.LAST_VERIFIED_DT , H_ORGNAME.SOURCE_IDENT_TP_CD, H_ORGNAME.STANDARD_IND,H_ORGNAME.ORG_NAME_ID,H_ORGNAME.H_END_DT, H_ORGNAME.XMODIFY_SYS_DT, H_ORGNAME.XORG_NAME_LOCAL, H_ORGNAME.XORGNAME_RETAILER_FLAG, H_ORGNAME.X_BPID FROM H_ORGNAME WHERE (H_ORGNAME.H_ORG_NAME_ID = ?) AND (( ? BETWEEN H_ORGNAME.H_CREATE_DT AND H_ORGNAME.H_END_DT ) OR ( ? >= H_ORGNAME.H_CREATE_DT AND H_ORGNAME.H_END_DT IS NULL ))",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"hist_id_pk", "h_action_code", "h_created_by", "h_create_dt", "cont_id", "org_name", "start_dt", "end_dt", "org_name_tp_cd", "s_org_name", "name_search_key", "last_update_dt", "last_update_user", "last_update_tx_id", "last_used_dt", "last_verified_dt", "source_ident_tp_cd", "standard_ind", "org_name_id", "h_end_dt", "xmodify_sys_dt", "xorg_name_local", "xorgname_retailer_flag", "x_bpid"},
    new GetOrgNameHistoryByIDParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP}, {19, 0, 0}, {0, 0, 0}, {1, 1, 1}},
    null,
    new GetOrgNameHistoryByIDRowHandler (),
    new int[][]{ {Types.BIGINT, Types.CHAR, Types.VARCHAR, Types.TIMESTAMP, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.CHAR, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR}, {19, 1, 20, 0, 19, 255, 0, 0, 19, 255, 30, 0, 20, 19, 0, 0, 19, 1, 19, 0, 0, 500, 10, 50}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    8);

  /**
   * @generated
   */
  public static class GetOrgNameHistoryByIDParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetOrgNameHistoryByIDRowHandler extends BaseRowHandler<ResultQueue2<EObjOrgName,EObjXOrgNameExt>>
  {
    /**
     * @generated
     */
    public ResultQueue2<EObjOrgName,EObjXOrgNameExt> handle (java.sql.ResultSet rs, ResultQueue2<EObjOrgName,EObjXOrgNameExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue2<EObjOrgName,EObjXOrgNameExt> ();

      EObjOrgName returnObject1 = new EObjOrgName ();
      returnObject1.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject1.setHistActionCode(getString (rs, 2)); 
      returnObject1.setHistCreatedBy(getString (rs, 3)); 
      returnObject1.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject1.setContId(getLongObject (rs, 5)); 
      returnObject1.setOrgName(getString (rs, 6)); 
      returnObject1.setStartDt(getTimestamp (rs, 7)); 
      returnObject1.setEndDt(getTimestamp (rs, 8)); 
      returnObject1.setOrgNameTpCd(getLongObject (rs, 9)); 
      returnObject1.setSOrgName(getString (rs, 10)); 
      returnObject1.setNameSearchKey(getString (rs, 11)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 12)); 
      returnObject1.setLastUpdateUser(getString (rs, 13)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 14)); 
      returnObject1.setLastUsedDt(getTimestamp (rs, 15)); 
      returnObject1.setLastVerifiedDt(getTimestamp (rs, 16)); 
      returnObject1.setSourceIdentTpCd(getLongObject (rs, 17)); 
      returnObject1.setOrgNameStandardInd(getString (rs, 18)); 
      returnObject1.setOrgNameIdPK(getLongObject (rs, 19)); 
      returnObject1.setHistEndDt(getTimestamp (rs, 20)); 
      returnObject.add (returnObject1);

      EObjXOrgNameExt returnObject2 = new EObjXOrgNameExt ();
      returnObject2.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject2.setHistActionCode(getString (rs, 2)); 
      returnObject2.setHistCreatedBy(getString (rs, 3)); 
      returnObject2.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject2.setLastUpdateDt(getTimestamp (rs, 12)); 
      returnObject2.setLastUpdateUser(getString (rs, 13)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 14)); 
      returnObject2.setHistEndDt(getTimestamp (rs, 20)); 
      returnObject2.setXLastModifiedSystemDate(getTimestamp (rs, 21)); 
      returnObject2.setXOrganizationNameLocal(getString (rs, 22)); 
      returnObject2.setXOrgNameRetailerFlag(getString (rs, 23)); 
      returnObject2.setX_BPID(getString (rs, 24)); 
      returnObject.add (returnObject2);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT DISTINCT A.H_ORG_NAME_ID AS HIST_ID_PK, A.H_ACTION_CODE , A.H_CREATED_BY , A.H_CREATE_DT , A.H_END_DT , A.ORG_NAME_ID , A.CONT_ID , A.ORG_NAME , A.START_DT , A.END_DT , A.ORG_NAME_TP_CD , A.S_ORG_NAME , A.NAME_SEARCH_KEY , A.LAST_UPDATE_DT , A.LAST_UPDATE_USER , A.LAST_UPDATE_TX_ID , A.LAST_USED_DT , A.LAST_VERIFIED_DT , A.SOURCE_IDENT_TP_CD, A.STANDARD_IND, A.XMODIFY_SYS_DT, A.XORG_NAME_LOCAL, A.XORGNAME_RETAILER_FLAG, A.X_BPID FROM H_ORGNAME A WHERE A.CONT_ID = ? AND ( A.H_CREATE_DT BETWEEN ? AND ? )", pattern="tableAlias (ORGNAME => com.dwl.tcrm.coreParty.entityObject.EObjOrgName, H_ORGNAME => com.dwl.tcrm.coreParty.entityObject.EObjOrgName , ORGNAME => com.ibm.daimler.dsea.entityObject.EObjXOrgNameExt , H_ORGNAME => com.ibm.daimler.dsea.entityObject.EObjXOrgNameExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue2<EObjOrgName,EObjXOrgNameExt>> getOrgNameImages (Object[] parameters)
  {
    return queryIterator (getOrgNameImagesStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getOrgNameImagesStatementDescriptor = createStatementDescriptor (
    "getOrgNameImages(Object[])",
    "SELECT DISTINCT A.H_ORG_NAME_ID AS HIST_ID_PK, A.H_ACTION_CODE , A.H_CREATED_BY , A.H_CREATE_DT , A.H_END_DT , A.ORG_NAME_ID , A.CONT_ID , A.ORG_NAME , A.START_DT , A.END_DT , A.ORG_NAME_TP_CD , A.S_ORG_NAME , A.NAME_SEARCH_KEY , A.LAST_UPDATE_DT , A.LAST_UPDATE_USER , A.LAST_UPDATE_TX_ID , A.LAST_USED_DT , A.LAST_VERIFIED_DT , A.SOURCE_IDENT_TP_CD, A.STANDARD_IND, A.XMODIFY_SYS_DT, A.XORG_NAME_LOCAL, A.XORGNAME_RETAILER_FLAG, A.X_BPID FROM H_ORGNAME A WHERE A.CONT_ID = ? AND ( A.H_CREATE_DT BETWEEN ? AND ? )",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"hist_id_pk", "h_action_code", "h_created_by", "h_create_dt", "h_end_dt", "org_name_id", "cont_id", "org_name", "start_dt", "end_dt", "org_name_tp_cd", "s_org_name", "name_search_key", "last_update_dt", "last_update_user", "last_update_tx_id", "last_used_dt", "last_verified_dt", "source_ident_tp_cd", "standard_ind", "xmodify_sys_dt", "xorg_name_local", "xorgname_retailer_flag", "x_bpid"},
    new GetOrgNameImagesParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP}, {19, 0, 0}, {0, 0, 0}, {1, 1, 1}},
    null,
    new GetOrgNameImagesRowHandler (),
    new int[][]{ {Types.BIGINT, Types.CHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.CHAR, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR}, {19, 1, 20, 0, 0, 19, 19, 255, 0, 0, 19, 255, 30, 0, 20, 19, 0, 0, 19, 1, 0, 500, 10, 50}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    9);

  /**
   * @generated
   */
  public static class GetOrgNameImagesParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetOrgNameImagesRowHandler extends BaseRowHandler<ResultQueue2<EObjOrgName,EObjXOrgNameExt>>
  {
    /**
     * @generated
     */
    public ResultQueue2<EObjOrgName,EObjXOrgNameExt> handle (java.sql.ResultSet rs, ResultQueue2<EObjOrgName,EObjXOrgNameExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue2<EObjOrgName,EObjXOrgNameExt> ();

      EObjOrgName returnObject1 = new EObjOrgName ();
      returnObject1.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject1.setHistActionCode(getString (rs, 2)); 
      returnObject1.setHistCreatedBy(getString (rs, 3)); 
      returnObject1.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject1.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject1.setOrgNameIdPK(getLongObject (rs, 6)); 
      returnObject1.setContId(getLongObject (rs, 7)); 
      returnObject1.setOrgName(getString (rs, 8)); 
      returnObject1.setStartDt(getTimestamp (rs, 9)); 
      returnObject1.setEndDt(getTimestamp (rs, 10)); 
      returnObject1.setOrgNameTpCd(getLongObject (rs, 11)); 
      returnObject1.setSOrgName(getString (rs, 12)); 
      returnObject1.setNameSearchKey(getString (rs, 13)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 14)); 
      returnObject1.setLastUpdateUser(getString (rs, 15)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 16)); 
      returnObject1.setLastUsedDt(getTimestamp (rs, 17)); 
      returnObject1.setLastVerifiedDt(getTimestamp (rs, 18)); 
      returnObject1.setSourceIdentTpCd(getLongObject (rs, 19)); 
      returnObject1.setOrgNameStandardInd(getString (rs, 20)); 
      returnObject.add (returnObject1);

      EObjXOrgNameExt returnObject2 = new EObjXOrgNameExt ();
      returnObject2.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject2.setHistActionCode(getString (rs, 2)); 
      returnObject2.setHistCreatedBy(getString (rs, 3)); 
      returnObject2.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject2.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject2.setLastUpdateDt(getTimestamp (rs, 14)); 
      returnObject2.setLastUpdateUser(getString (rs, 15)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 16)); 
      returnObject2.setXLastModifiedSystemDate(getTimestamp (rs, 21)); 
      returnObject2.setXOrganizationNameLocal(getString (rs, 22)); 
      returnObject2.setXOrgNameRetailerFlag(getString (rs, 23)); 
      returnObject2.setX_BPID(getString (rs, 24)); 
      returnObject.add (returnObject2);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT DISTINCT A.ORG_NAME_ID , A.LAST_UPDATE_DT, A.XMODIFY_SYS_DT, A.XORG_NAME_LOCAL, A.XORGNAME_RETAILER_FLAG, A.X_BPID FROM H_ORGNAME A WHERE A.CONT_ID = ? AND ( A.H_CREATE_DT BETWEEN ? AND ? )", pattern="tableAlias (ORGNAME => com.dwl.tcrm.coreParty.entityObject.EObjOrgName, H_ORGNAME => com.dwl.tcrm.coreParty.entityObject.EObjOrgName , ORGNAME => com.ibm.daimler.dsea.entityObject.EObjXOrgNameExt , H_ORGNAME => com.ibm.daimler.dsea.entityObject.EObjXOrgNameExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue2<EObjOrgName,EObjXOrgNameExt>> getOrgNameLightImages (Object[] parameters)
  {
    return queryIterator (getOrgNameLightImagesStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getOrgNameLightImagesStatementDescriptor = createStatementDescriptor (
    "getOrgNameLightImages(Object[])",
    "SELECT DISTINCT A.ORG_NAME_ID , A.LAST_UPDATE_DT, A.XMODIFY_SYS_DT, A.XORG_NAME_LOCAL, A.XORGNAME_RETAILER_FLAG, A.X_BPID FROM H_ORGNAME A WHERE A.CONT_ID = ? AND ( A.H_CREATE_DT BETWEEN ? AND ? )",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"org_name_id", "last_update_dt", "xmodify_sys_dt", "xorg_name_local", "xorgname_retailer_flag", "x_bpid"},
    new GetOrgNameLightImagesParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP}, {19, 0, 0}, {0, 0, 0}, {1, 1, 1}},
    null,
    new GetOrgNameLightImagesRowHandler (),
    new int[][]{ {Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR}, {19, 0, 0, 500, 10, 50}, {0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    10);

  /**
   * @generated
   */
  public static class GetOrgNameLightImagesParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetOrgNameLightImagesRowHandler extends BaseRowHandler<ResultQueue2<EObjOrgName,EObjXOrgNameExt>>
  {
    /**
     * @generated
     */
    public ResultQueue2<EObjOrgName,EObjXOrgNameExt> handle (java.sql.ResultSet rs, ResultQueue2<EObjOrgName,EObjXOrgNameExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue2<EObjOrgName,EObjXOrgNameExt> ();

      EObjOrgName returnObject1 = new EObjOrgName ();
      returnObject1.setOrgNameIdPK(getLongObject (rs, 1)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 2)); 
      returnObject.add (returnObject1);

      EObjXOrgNameExt returnObject2 = new EObjXOrgNameExt ();
      returnObject2.setLastUpdateDt(getTimestamp (rs, 2)); 
      returnObject2.setXLastModifiedSystemDate(getTimestamp (rs, 3)); 
      returnObject2.setXOrganizationNameLocal(getString (rs, 4)); 
      returnObject2.setXOrgNameRetailerFlag(getString (rs, 5)); 
      returnObject2.setX_BPID(getString (rs, 6)); 
      returnObject.add (returnObject2);

    
      return returnObject;
    }
  }

}
