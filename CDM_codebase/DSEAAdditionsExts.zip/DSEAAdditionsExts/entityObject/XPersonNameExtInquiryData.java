/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[ee3ad7c77bf8264211c3625c72b34881]
 */
package com.ibm.daimler.dsea.entityObject;


import com.ibm.mdm.base.db.EntityMapping;
import com.ibm.pdq.annotation.Select;


import com.dwl.tcrm.coreParty.entityObject.EObjPersonName;
import com.dwl.tcrm.coreParty.entityObject.EObjPersonSearch;

import com.ibm.mdm.base.db.ResultQueue2;
import com.ibm.mdm.base.db.ResultQueue3;

import java.util.Iterator;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * 
 * @generated
 */
public interface XPersonNameExtInquiryData {

  /**
   * MDM_TODO: CDKWB0050I The generated parameter and result lists in this file should be checked to ensure that each matches its
   * associated SQL query. Each list entry must be comma separated and identify a field within an entity object class.
   */ 
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */ 
   public final static String tableAliasString1 = "tableAlias (" + 
     "PERSONNAME => com.dwl.tcrm.coreParty.entityObject.EObjPersonName, " + 
     "H_PERSONNAME => com.dwl.tcrm.coreParty.entityObject.EObjPersonName, " + 
     "PERSONSEARCH => com.dwl.tcrm.coreParty.entityObject.EObjPersonSearch, " + 
     "H_PERSONSEARCH => com.dwl.tcrm.coreParty.entityObject.EObjPersonSearch , " + 
     "PERSONNAME => com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt , " + 
     "H_PERSONNAME => com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt" + 
     ")";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension
   * XPersonName.
   *
   * @generated
   */ 
   public final static String getPersonNamesHistorySQL = "SELECT DISTINCT A.H_PERSON_NAME_ID AS HIST_ID_PK , A.H_ACTION_CODE , A.H_CREATED_BY , A.H_CREATE_DT , A.H_END_DT , A.PERSON_NAME_ID , A.PREFIX_NAME_TP_CD , A.PREFIX_DESC , A.NAME_USAGE_TP_CD , A.GIVEN_NAME_ONE , A.GIVEN_NAME_TWO , A.GIVEN_NAME_THREE , A.GIVEN_NAME_FOUR , A.LAST_NAME , A.GENERATION_TP_CD , A.SUFFIX_DESC , A.START_DT , A.END_DT , A.CONT_ID , A.USE_STANDARD_IND , A.LAST_UPDATE_DT , A.LAST_UPDATE_USER , A.LAST_UPDATE_TX_ID , A.LAST_USED_DT , A.LAST_VERIFIED_DT , A.SOURCE_IDENT_TP_CD , B.GIVEN_NAME_ONE , B.GIVEN_NAME_TWO , B.GIVEN_NAME_THREE , B.GIVEN_NAME_FOUR , B.LAST_NAME , B.LAST_UPDATE_TX_ID, B.STANDARD_IND, A.XMODIFY_SYS_DT, A.XGIVEN_NAME_ONE_LOCAL, A.XGIVEN_NAME_TWO_LOCAL, A.XLAST_NAME_LOCAL, A.XPERSONNAME_RETAILER_FLAG, A.X_BPID" + 
     " FROM H_PERSONNAME A,H_PERSONSEARCH B" + 
     " WHERE A.CONT_ID = ? AND A.H_PERSON_NAME_ID = B.PERSON_NAME_ID AND (( ? BETWEEN A.H_CREATE_DT AND A.H_END_DT ) OR ( ? >= A.H_CREATE_DT AND A.H_END_DT IS NULL )) AND (( ? BETWEEN B.H_CREATE_DT AND B.H_END_DT ) OR ( ? >= B.H_CREATE_DT AND B.H_END_DT IS NULL ))";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPersonNamesHistoryParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonSearch.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonSearch.histCreateDt=H_CREATE_DT"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPersonNamesHistoryResults =
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.historyIdPK=HIST_ID_PK," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.histActionCode=H_ACTION_CODE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.histCreatedBy=H_CREATED_BY," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.histEndDt=H_END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.personNameIdPK=PERSON_NAME_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.prefixNameTpCd=PREFIX_NAME_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.prefixDesc=PREFIX_DESC," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.nameUsageTpCd=NAME_USAGE_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.givenNameOne=GIVEN_NAME_ONE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.givenNameTwo=GIVEN_NAME_TWO," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.givenNameThree=GIVEN_NAME_THREE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.givenNameFour=GIVEN_NAME_FOUR," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastName=LAST_NAME," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.generationTpCd=GENERATION_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.suffixDesc=SUFFIX_DESC," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.startDt=START_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.endDt=END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.useStandardInd=USE_STANDARD_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastUsedDt=LAST_USED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastVerifiedDt=LAST_VERIFIED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.sourceIdentTpCd=SOURCE_IDENT_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonSearch.givenNameOne=GIVEN_NAME_ONE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonSearch.givenNameTwo=GIVEN_NAME_TWO," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonSearch.givenNameThree=GIVEN_NAME_THREE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonSearch.givenNameFour=GIVEN_NAME_FOUR," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonSearch.lastName=LAST_NAME," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonSearch.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonSearch.personNameStandardInd=STANDARD_IND," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.XLastModifiedSystemDate=XMODIFY_SYS_DT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.XGivenNameOneLocal=XGIVEN_NAME_ONE_LOCAL," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.XGivenNameTwoLocal=XGIVEN_NAME_TWO_LOCAL," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.XLastNameLocal=XLAST_NAME_LOCAL," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.XPersonNameRetailerFlag=XPERSONNAME_RETAILER_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.X_BPID=X_BPID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension
   * XPersonName.
   *
   * @generated
   */ 
   public final static String getPersonNamesActiveSQL = "SELECT PERSONNAME.PERSON_NAME_ID , PERSONNAME.PREFIX_NAME_TP_CD , PERSONNAME.PREFIX_DESC , PERSONNAME.NAME_USAGE_TP_CD , PERSONNAME.GIVEN_NAME_ONE , PERSONNAME.GIVEN_NAME_TWO , PERSONNAME.GIVEN_NAME_THREE , PERSONNAME.GIVEN_NAME_FOUR , PERSONNAME.LAST_NAME , PERSONNAME.GENERATION_TP_CD , PERSONNAME.SUFFIX_DESC , PERSONNAME.START_DT , PERSONNAME.END_DT , PERSONNAME.CONT_ID , PERSONNAME.USE_STANDARD_IND , PERSONNAME.LAST_UPDATE_DT , PERSONNAME.LAST_UPDATE_USER , PERSONNAME.LAST_UPDATE_TX_ID , PERSONNAME.LAST_USED_DT , PERSONNAME.LAST_VERIFIED_DT , PERSONNAME.SOURCE_IDENT_TP_CD , PERSONNAME.P_LAST_NAME, PERSONNAME.P_GIVEN_NAME_ONE, PERSONNAME.P_GIVEN_NAME_TWO, PERSONSEARCH.GIVEN_NAME_ONE , PERSONSEARCH.GIVEN_NAME_TWO , PERSONSEARCH.GIVEN_NAME_THREE , PERSONSEARCH.GIVEN_NAME_FOUR , PERSONSEARCH.LAST_NAME , PERSONSEARCH.LAST_UPDATE_TX_ID, PERSONSEARCH.STANDARD_IND, PERSONNAME.XMODIFY_SYS_DT, PERSONNAME.XGIVEN_NAME_ONE_LOCAL, PERSONNAME.XGIVEN_NAME_TWO_LOCAL, PERSONNAME.XLAST_NAME_LOCAL, PERSONNAME.XPERSONNAME_RETAILER_FLAG, PERSONNAME.X_BPID" + 
     " FROM PERSONNAME, PERSONSEARCH" + 
     " WHERE PERSONNAME.CONT_ID = ? AND (PERSONNAME.END_DT IS NULL OR PERSONNAME.END_DT> ? ) AND PERSONNAME.PERSON_NAME_ID = PERSONSEARCH.PERSON_NAME_ID";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPersonNamesActiveParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.endDt=END_DT"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPersonNamesActiveResults =
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.personNameIdPK=PERSON_NAME_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.prefixNameTpCd=PREFIX_NAME_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.prefixDesc=PREFIX_DESC," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.nameUsageTpCd=NAME_USAGE_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.givenNameOne=GIVEN_NAME_ONE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.givenNameTwo=GIVEN_NAME_TWO," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.givenNameThree=GIVEN_NAME_THREE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.givenNameFour=GIVEN_NAME_FOUR," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastName=LAST_NAME," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.generationTpCd=GENERATION_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.suffixDesc=SUFFIX_DESC," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.startDt=START_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.endDt=END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.useStandardInd=USE_STANDARD_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastUsedDt=LAST_USED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastVerifiedDt=LAST_VERIFIED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.sourceIdentTpCd=SOURCE_IDENT_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.pLastName=P_LAST_NAME," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.pGivenNameOne=P_GIVEN_NAME_ONE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.pGivenNameTwo=P_GIVEN_NAME_TWO," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonSearch.givenNameOne=GIVEN_NAME_ONE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonSearch.givenNameTwo=GIVEN_NAME_TWO," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonSearch.givenNameThree=GIVEN_NAME_THREE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonSearch.givenNameFour=GIVEN_NAME_FOUR," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonSearch.lastName=LAST_NAME," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonSearch.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonSearch.personNameStandardInd=STANDARD_IND," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.XLastModifiedSystemDate=XMODIFY_SYS_DT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.XGivenNameOneLocal=XGIVEN_NAME_ONE_LOCAL," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.XGivenNameTwoLocal=XGIVEN_NAME_TWO_LOCAL," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.XLastNameLocal=XLAST_NAME_LOCAL," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.XPersonNameRetailerFlag=XPERSONNAME_RETAILER_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.X_BPID=X_BPID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension
   * XPersonName.
   *
   * @generated
   */ 
   public final static String getPersonNamesInActiveSQL = "SELECT PERSONNAME.PERSON_NAME_ID , PERSONNAME.PREFIX_NAME_TP_CD , PERSONNAME.PREFIX_DESC , PERSONNAME.NAME_USAGE_TP_CD , PERSONNAME.GIVEN_NAME_ONE , PERSONNAME.GIVEN_NAME_TWO , PERSONNAME.GIVEN_NAME_THREE , PERSONNAME.GIVEN_NAME_FOUR , PERSONNAME.LAST_NAME , PERSONNAME.GENERATION_TP_CD , PERSONNAME.SUFFIX_DESC , PERSONNAME.START_DT , PERSONNAME.END_DT , PERSONNAME.CONT_ID , PERSONNAME.USE_STANDARD_IND , PERSONNAME.LAST_UPDATE_DT , PERSONNAME.LAST_UPDATE_USER , PERSONNAME.LAST_UPDATE_TX_ID , PERSONNAME.LAST_USED_DT , PERSONNAME.LAST_VERIFIED_DT , PERSONNAME.SOURCE_IDENT_TP_CD , PERSONSEARCH.GIVEN_NAME_ONE , PERSONSEARCH.GIVEN_NAME_TWO , PERSONSEARCH.GIVEN_NAME_THREE , PERSONSEARCH.GIVEN_NAME_FOUR , PERSONSEARCH.LAST_NAME , PERSONSEARCH.LAST_UPDATE_TX_ID, PERSONSEARCH.STANDARD_IND, PERSONNAME.XMODIFY_SYS_DT, PERSONNAME.XGIVEN_NAME_ONE_LOCAL, PERSONNAME.XGIVEN_NAME_TWO_LOCAL, PERSONNAME.XLAST_NAME_LOCAL, PERSONNAME.XPERSONNAME_RETAILER_FLAG, PERSONNAME.X_BPID" + 
     " FROM PERSONNAME,PERSONSEARCH" + 
     " WHERE PERSONNAME.CONT_ID = ? AND (PERSONNAME.END_DT< ? ) AND PERSONNAME.PERSON_NAME_ID = PERSONSEARCH.PERSON_NAME_ID";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPersonNamesInActiveParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.endDt=END_DT"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPersonNamesInActiveResults =
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.personNameIdPK=PERSON_NAME_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.prefixNameTpCd=PREFIX_NAME_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.prefixDesc=PREFIX_DESC," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.nameUsageTpCd=NAME_USAGE_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.givenNameOne=GIVEN_NAME_ONE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.givenNameTwo=GIVEN_NAME_TWO," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.givenNameThree=GIVEN_NAME_THREE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.givenNameFour=GIVEN_NAME_FOUR," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastName=LAST_NAME," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.generationTpCd=GENERATION_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.suffixDesc=SUFFIX_DESC," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.startDt=START_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.endDt=END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.useStandardInd=USE_STANDARD_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastUsedDt=LAST_USED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastVerifiedDt=LAST_VERIFIED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.sourceIdentTpCd=SOURCE_IDENT_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonSearch.givenNameOne=GIVEN_NAME_ONE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonSearch.givenNameTwo=GIVEN_NAME_TWO," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonSearch.givenNameThree=GIVEN_NAME_THREE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonSearch.givenNameFour=GIVEN_NAME_FOUR," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonSearch.lastName=LAST_NAME," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonSearch.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonSearch.personNameStandardInd=STANDARD_IND," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.XLastModifiedSystemDate=XMODIFY_SYS_DT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.XGivenNameOneLocal=XGIVEN_NAME_ONE_LOCAL," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.XGivenNameTwoLocal=XGIVEN_NAME_TWO_LOCAL," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.XLastNameLocal=XLAST_NAME_LOCAL," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.XPersonNameRetailerFlag=XPERSONNAME_RETAILER_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.X_BPID=X_BPID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension
   * XPersonName.
   *
   * @generated
   */ 
   public final static String getPersonNamesAllSQL = "SELECT PERSONNAME.PERSON_NAME_ID , PERSONNAME.PREFIX_NAME_TP_CD , PERSONNAME.PREFIX_DESC , PERSONNAME.NAME_USAGE_TP_CD , PERSONNAME.GIVEN_NAME_ONE , PERSONNAME.GIVEN_NAME_TWO , PERSONNAME.GIVEN_NAME_THREE , PERSONNAME.GIVEN_NAME_FOUR , PERSONNAME.LAST_NAME , PERSONNAME.GENERATION_TP_CD , PERSONNAME.SUFFIX_DESC , PERSONNAME.START_DT , PERSONNAME.END_DT , PERSONNAME.CONT_ID , PERSONNAME.USE_STANDARD_IND , PERSONNAME.LAST_UPDATE_DT , PERSONNAME.LAST_UPDATE_USER , PERSONNAME.LAST_UPDATE_TX_ID , PERSONNAME.LAST_USED_DT , PERSONNAME.LAST_VERIFIED_DT , PERSONNAME.SOURCE_IDENT_TP_CD , PERSONSEARCH.GIVEN_NAME_ONE , PERSONSEARCH.GIVEN_NAME_TWO , PERSONSEARCH.GIVEN_NAME_THREE , PERSONSEARCH.GIVEN_NAME_FOUR , PERSONSEARCH.LAST_NAME , PERSONSEARCH.LAST_UPDATE_TX_ID, PERSONSEARCH.STANDARD_IND, PERSONNAME.XMODIFY_SYS_DT, PERSONNAME.XGIVEN_NAME_ONE_LOCAL, PERSONNAME.XGIVEN_NAME_TWO_LOCAL, PERSONNAME.XLAST_NAME_LOCAL, PERSONNAME.XPERSONNAME_RETAILER_FLAG, PERSONNAME.X_BPID" + 
     " FROM PERSONNAME,PERSONSEARCH" + 
     " WHERE PERSONNAME.CONT_ID = ? AND PERSONNAME.PERSON_NAME_ID = PERSONSEARCH.PERSON_NAME_ID";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPersonNamesAllParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.contId=CONT_ID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPersonNamesAllResults =
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.personNameIdPK=PERSON_NAME_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.prefixNameTpCd=PREFIX_NAME_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.prefixDesc=PREFIX_DESC," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.nameUsageTpCd=NAME_USAGE_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.givenNameOne=GIVEN_NAME_ONE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.givenNameTwo=GIVEN_NAME_TWO," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.givenNameThree=GIVEN_NAME_THREE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.givenNameFour=GIVEN_NAME_FOUR," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastName=LAST_NAME," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.generationTpCd=GENERATION_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.suffixDesc=SUFFIX_DESC," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.startDt=START_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.endDt=END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.useStandardInd=USE_STANDARD_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastUsedDt=LAST_USED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastVerifiedDt=LAST_VERIFIED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.sourceIdentTpCd=SOURCE_IDENT_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonSearch.givenNameOne=GIVEN_NAME_ONE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonSearch.givenNameTwo=GIVEN_NAME_TWO," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonSearch.givenNameThree=GIVEN_NAME_THREE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonSearch.givenNameFour=GIVEN_NAME_FOUR," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonSearch.lastName=LAST_NAME," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonSearch.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonSearch.personNameStandardInd=STANDARD_IND," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.XLastModifiedSystemDate=XMODIFY_SYS_DT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.XGivenNameOneLocal=XGIVEN_NAME_ONE_LOCAL," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.XGivenNameTwoLocal=XGIVEN_NAME_TWO_LOCAL," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.XLastNameLocal=XLAST_NAME_LOCAL," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.XPersonNameRetailerFlag=XPERSONNAME_RETAILER_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.X_BPID=X_BPID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension
   * XPersonName.
   *
   * @generated
   */ 
   public final static String getPersonNameWithTypeHistorySQL = "SELECT DISTINCT A.H_PERSON_NAME_ID AS HIST_ID_PK ,A.H_ACTION_CODE ,A.H_CREATED_BY ,A.H_CREATE_DT ,A.H_END_DT ,A.PERSON_NAME_ID ,A.PREFIX_NAME_TP_CD ,A.PREFIX_DESC ,A.NAME_USAGE_TP_CD ,A.GIVEN_NAME_ONE ,A.GIVEN_NAME_TWO ,A.GIVEN_NAME_THREE ,A.GIVEN_NAME_FOUR ,A.LAST_NAME , A.GENERATION_TP_CD , A.SUFFIX_DESC ,A.START_DT ,A.END_DT ,A.CONT_ID ,A.USE_STANDARD_IND ,A.LAST_UPDATE_DT ,A.LAST_UPDATE_USER , A.LAST_UPDATE_TX_ID , A.LAST_USED_DT , A.LAST_VERIFIED_DT , A.SOURCE_IDENT_TP_CD , B.GIVEN_NAME_ONE ,B.GIVEN_NAME_TWO ,B.GIVEN_NAME_THREE ,B.GIVEN_NAME_FOUR ,B.LAST_NAME , B.LAST_UPDATE_TX_ID, B.STANDARD_IND, A.XMODIFY_SYS_DT, A.XGIVEN_NAME_ONE_LOCAL, A.XGIVEN_NAME_TWO_LOCAL, A.XLAST_NAME_LOCAL, A.XPERSONNAME_RETAILER_FLAG, A.X_BPID" + 
     " FROM H_PERSONNAME A, H_PERSONSEARCH B" + 
     " WHERE A.H_PERSON_NAME_ID = B.PERSON_NAME_ID AND A.CONT_ID = ? AND A.NAME_USAGE_TP_CD = ? AND (? BETWEEN A.H_CREATE_DT AND A.H_END_DT OR (? >= A.H_CREATE_DT AND A.H_END_DT IS NULL )) AND (( ? BETWEEN B.H_CREATE_DT AND B.H_END_DT ) OR ( ? >= B.H_CREATE_DT AND B.H_END_DT IS NULL ))";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPersonNameWithTypeHistoryParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.nameUsageTpCd=NAME_USAGE_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonSearch.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonSearch.histCreateDt=H_CREATE_DT"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPersonNameWithTypeHistoryResults =
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.historyIdPK=HIST_ID_PK," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.histActionCode=H_ACTION_CODE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.histCreatedBy=H_CREATED_BY," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.histEndDt=H_END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.personNameIdPK=PERSON_NAME_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.prefixNameTpCd=PREFIX_NAME_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.prefixDesc=PREFIX_DESC," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.nameUsageTpCd=NAME_USAGE_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.givenNameOne=GIVEN_NAME_ONE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.givenNameTwo=GIVEN_NAME_TWO," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.givenNameThree=GIVEN_NAME_THREE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.givenNameFour=GIVEN_NAME_FOUR," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastName=LAST_NAME," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.generationTpCd=GENERATION_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.suffixDesc=SUFFIX_DESC," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.startDt=START_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.endDt=END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.useStandardInd=USE_STANDARD_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastUsedDt=LAST_USED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastVerifiedDt=LAST_VERIFIED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.sourceIdentTpCd=SOURCE_IDENT_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonSearch.givenNameOne=GIVEN_NAME_ONE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonSearch.givenNameTwo=GIVEN_NAME_TWO," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonSearch.givenNameThree=GIVEN_NAME_THREE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonSearch.givenNameFour=GIVEN_NAME_FOUR," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonSearch.lastName=LAST_NAME," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonSearch.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonSearch.personNameStandardInd=STANDARD_IND," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.XLastModifiedSystemDate=XMODIFY_SYS_DT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.XGivenNameOneLocal=XGIVEN_NAME_ONE_LOCAL," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.XGivenNameTwoLocal=XGIVEN_NAME_TWO_LOCAL," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.XLastNameLocal=XLAST_NAME_LOCAL," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.XPersonNameRetailerFlag=XPERSONNAME_RETAILER_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.X_BPID=X_BPID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension
   * XPersonName.
   *
   * @generated
   */ 
   public final static String getPersonNameWithTypeSQL = "SELECT PERSONNAME.PERSON_NAME_ID ,PERSONNAME.PREFIX_NAME_TP_CD ,PERSONNAME.PREFIX_DESC ,PERSONNAME.NAME_USAGE_TP_CD ,PERSONNAME.GIVEN_NAME_ONE ,PERSONNAME.GIVEN_NAME_TWO ,PERSONNAME.GIVEN_NAME_THREE ,PERSONNAME.GIVEN_NAME_FOUR ,PERSONNAME.LAST_NAME , PERSONNAME.GENERATION_TP_CD , PERSONNAME.SUFFIX_DESC ,PERSONNAME.START_DT ,PERSONNAME.END_DT ,PERSONNAME.CONT_ID ,PERSONNAME.USE_STANDARD_IND ,PERSONNAME.LAST_UPDATE_DT ,PERSONNAME.LAST_UPDATE_USER , PERSONNAME.LAST_UPDATE_TX_ID , PERSONNAME.LAST_USED_DT , PERSONNAME.LAST_VERIFIED_DT , PERSONNAME.SOURCE_IDENT_TP_CD , PERSONSEARCH.GIVEN_NAME_ONE ,PERSONSEARCH.GIVEN_NAME_TWO ,PERSONSEARCH.GIVEN_NAME_THREE ,PERSONSEARCH.GIVEN_NAME_FOUR ,PERSONSEARCH.LAST_NAME , PERSONSEARCH.LAST_UPDATE_TX_ID, PERSONSEARCH.STANDARD_IND, PERSONNAME.XMODIFY_SYS_DT, PERSONNAME.XGIVEN_NAME_ONE_LOCAL, PERSONNAME.XGIVEN_NAME_TWO_LOCAL, PERSONNAME.XLAST_NAME_LOCAL, PERSONNAME.XPERSONNAME_RETAILER_FLAG, PERSONNAME.X_BPID" + 
     " FROM PERSONNAME , PERSONSEARCH" + 
     " WHERE PERSONNAME.CONT_ID = ? AND (PERSONNAME.NAME_USAGE_TP_CD = ?) AND (PERSONNAME.END_DT IS NULL OR PERSONNAME.END_DT> ? ) AND PERSONNAME.PERSON_NAME_ID = PERSONSEARCH.PERSON_NAME_ID";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPersonNameWithTypeParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.nameUsageTpCd=NAME_USAGE_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.endDt=END_DT"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPersonNameWithTypeResults =
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.personNameIdPK=PERSON_NAME_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.prefixNameTpCd=PREFIX_NAME_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.prefixDesc=PREFIX_DESC," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.nameUsageTpCd=NAME_USAGE_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.givenNameOne=GIVEN_NAME_ONE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.givenNameTwo=GIVEN_NAME_TWO," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.givenNameThree=GIVEN_NAME_THREE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.givenNameFour=GIVEN_NAME_FOUR," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastName=LAST_NAME," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.generationTpCd=GENERATION_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.suffixDesc=SUFFIX_DESC," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.startDt=START_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.endDt=END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.useStandardInd=USE_STANDARD_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastUsedDt=LAST_USED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastVerifiedDt=LAST_VERIFIED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.sourceIdentTpCd=SOURCE_IDENT_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonSearch.givenNameOne=GIVEN_NAME_ONE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonSearch.givenNameTwo=GIVEN_NAME_TWO," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonSearch.givenNameThree=GIVEN_NAME_THREE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonSearch.givenNameFour=GIVEN_NAME_FOUR," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonSearch.lastName=LAST_NAME," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonSearch.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonSearch.personNameStandardInd=STANDARD_IND," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.XLastModifiedSystemDate=XMODIFY_SYS_DT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.XGivenNameOneLocal=XGIVEN_NAME_ONE_LOCAL," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.XGivenNameTwoLocal=XGIVEN_NAME_TWO_LOCAL," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.XLastNameLocal=XLAST_NAME_LOCAL," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.XPersonNameRetailerFlag=XPERSONNAME_RETAILER_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.X_BPID=X_BPID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension
   * XPersonName.
   *
   * @generated
   */ 
   public final static String getPersonNameByIDSQL = "SELECT PERSONNAME.PERSON_NAME_ID , PERSONNAME.PREFIX_NAME_TP_CD , PERSONNAME.PREFIX_DESC , PERSONNAME.NAME_USAGE_TP_CD , PERSONNAME.GIVEN_NAME_ONE , PERSONNAME.GIVEN_NAME_TWO , PERSONNAME.GIVEN_NAME_THREE , PERSONNAME.GIVEN_NAME_FOUR , PERSONNAME.LAST_NAME , PERSONNAME.GENERATION_TP_CD , PERSONNAME.SUFFIX_DESC , PERSONNAME.START_DT , PERSONNAME.END_DT , PERSONNAME.CONT_ID , PERSONNAME.USE_STANDARD_IND , PERSONNAME.LAST_UPDATE_DT , PERSONNAME.LAST_UPDATE_USER , PERSONNAME.LAST_USED_DT , PERSONNAME.LAST_VERIFIED_DT , PERSONNAME.SOURCE_IDENT_TP_CD , PERSONNAME.LAST_USED_DT , PERSONNAME.LAST_VERIFIED_DT , PERSONNAME.SOURCE_IDENT_TP_CD , PERSONSEARCH.GIVEN_NAME_ONE , PERSONSEARCH.GIVEN_NAME_TWO , PERSONSEARCH.GIVEN_NAME_THREE , PERSONSEARCH.GIVEN_NAME_FOUR , PERSONSEARCH.LAST_NAME , PERSONNAME.LAST_UPDATE_TX_ID, PERSONSEARCH.STANDARD_IND, PERSONNAME.XMODIFY_SYS_DT, PERSONNAME.XGIVEN_NAME_ONE_LOCAL, PERSONNAME.XGIVEN_NAME_TWO_LOCAL, PERSONNAME.XLAST_NAME_LOCAL, PERSONNAME.XPERSONNAME_RETAILER_FLAG, PERSONNAME.X_BPID" + 
     " FROM PERSONNAME , PERSONSEARCH" + 
     " WHERE PERSONNAME.PERSON_NAME_ID = ? AND PERSONNAME.PERSON_NAME_ID = PERSONSEARCH.PERSON_NAME_ID";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPersonNameByIDParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.personNameIdPK=PERSON_NAME_ID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPersonNameByIDResults =
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.personNameIdPK=PERSON_NAME_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.prefixNameTpCd=PREFIX_NAME_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.prefixDesc=PREFIX_DESC," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.nameUsageTpCd=NAME_USAGE_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.givenNameOne=GIVEN_NAME_ONE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.givenNameTwo=GIVEN_NAME_TWO," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.givenNameThree=GIVEN_NAME_THREE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.givenNameFour=GIVEN_NAME_FOUR," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastName=LAST_NAME," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.generationTpCd=GENERATION_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.suffixDesc=SUFFIX_DESC," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.startDt=START_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.endDt=END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.useStandardInd=USE_STANDARD_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastUsedDt=LAST_USED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastVerifiedDt=LAST_VERIFIED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.sourceIdentTpCd=SOURCE_IDENT_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastUsedDt=LAST_USED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastVerifiedDt=LAST_VERIFIED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.sourceIdentTpCd=SOURCE_IDENT_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonSearch.givenNameOne=GIVEN_NAME_ONE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonSearch.givenNameTwo=GIVEN_NAME_TWO," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonSearch.givenNameThree=GIVEN_NAME_THREE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonSearch.givenNameFour=GIVEN_NAME_FOUR," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonSearch.lastName=LAST_NAME," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonSearch.personNameStandardInd=STANDARD_IND," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.XLastModifiedSystemDate=XMODIFY_SYS_DT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.XGivenNameOneLocal=XGIVEN_NAME_ONE_LOCAL," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.XGivenNameTwoLocal=XGIVEN_NAME_TWO_LOCAL," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.XLastNameLocal=XLAST_NAME_LOCAL," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.XPersonNameRetailerFlag=XPERSONNAME_RETAILER_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.X_BPID=X_BPID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension
   * XPersonName.
   *
   * @generated
   */ 
   public final static String getPersonNameByIDHistorySQL = "SELECT H_PERSONNAME.H_PERSON_NAME_ID AS HIST_ID_PK, H_PERSONNAME.H_ACTION_CODE, H_PERSONNAME.H_CREATED_BY, H_PERSONNAME.H_CREATE_DT, H_PERSONNAME.PREFIX_NAME_TP_CD , H_PERSONNAME.PREFIX_DESC , H_PERSONNAME.NAME_USAGE_TP_CD , H_PERSONNAME.GIVEN_NAME_ONE , H_PERSONNAME.GIVEN_NAME_TWO , H_PERSONNAME.GIVEN_NAME_THREE , H_PERSONNAME.GIVEN_NAME_FOUR , H_PERSONNAME.LAST_NAME , H_PERSONNAME.GENERATION_TP_CD , H_PERSONNAME.SUFFIX_DESC , H_PERSONNAME.START_DT , H_PERSONNAME.END_DT , H_PERSONNAME.CONT_ID , H_PERSONNAME.USE_STANDARD_IND , H_PERSONNAME.LAST_UPDATE_DT , H_PERSONNAME.LAST_UPDATE_USER , H_PERSONNAME.LAST_USED_DT , H_PERSONNAME.LAST_VERIFIED_DT , H_PERSONNAME.SOURCE_IDENT_TP_CD , H_PERSONNAME.LAST_USED_DT , H_PERSONNAME.LAST_VERIFIED_DT , H_PERSONNAME.SOURCE_IDENT_TP_CD , H_PERSONSEARCH.GIVEN_NAME_ONE , H_PERSONSEARCH.GIVEN_NAME_TWO , H_PERSONSEARCH.GIVEN_NAME_THREE , H_PERSONSEARCH.GIVEN_NAME_FOUR , H_PERSONSEARCH.LAST_NAME , H_PERSONNAME.LAST_UPDATE_TX_ID, H_PERSONSEARCH.STANDARD_IND,H_PERSONNAME.PERSON_NAME_ID,H_PERSONNAME.H_END_DT, H_PERSONNAME.XMODIFY_SYS_DT, H_PERSONNAME.XGIVEN_NAME_ONE_LOCAL, H_PERSONNAME.XGIVEN_NAME_TWO_LOCAL, H_PERSONNAME.XLAST_NAME_LOCAL, H_PERSONNAME.XPERSONNAME_RETAILER_FLAG, H_PERSONNAME.X_BPID" + 
     " FROM H_PERSONNAME , H_PERSONSEARCH" + 
     " WHERE H_PERSONNAME.H_PERSON_NAME_ID = ? AND H_PERSONNAME.H_PERSON_NAME_ID = H_PERSONSEARCH.PERSON_NAME_ID AND (( ? BETWEEN H_PERSONNAME.H_CREATE_DT AND H_PERSONNAME.H_END_DT ) OR ( ? >= H_PERSONNAME.H_CREATE_DT AND H_PERSONNAME.H_END_DT IS NULL )) AND (( ? BETWEEN H_PERSONSEARCH.H_CREATE_DT AND H_PERSONSEARCH.H_END_DT ) OR ( ? >= H_PERSONSEARCH.H_CREATE_DT AND H_PERSONSEARCH.H_END_DT IS NULL ))";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPersonNameByIDHistoryParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.historyIdPK=H_PERSON_NAME_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonSearch.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonSearch.histCreateDt=H_CREATE_DT"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPersonNameByIDHistoryResults =
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.historyIdPK=HIST_ID_PK," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.histActionCode=H_ACTION_CODE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.histCreatedBy=H_CREATED_BY," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.prefixNameTpCd=PREFIX_NAME_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.prefixDesc=PREFIX_DESC," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.nameUsageTpCd=NAME_USAGE_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.givenNameOne=GIVEN_NAME_ONE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.givenNameTwo=GIVEN_NAME_TWO," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.givenNameThree=GIVEN_NAME_THREE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.givenNameFour=GIVEN_NAME_FOUR," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastName=LAST_NAME," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.generationTpCd=GENERATION_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.suffixDesc=SUFFIX_DESC," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.startDt=START_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.endDt=END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.useStandardInd=USE_STANDARD_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastUsedDt=LAST_USED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastVerifiedDt=LAST_VERIFIED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.sourceIdentTpCd=SOURCE_IDENT_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastUsedDt=LAST_USED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastVerifiedDt=LAST_VERIFIED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.sourceIdentTpCd=SOURCE_IDENT_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonSearch.givenNameOne=GIVEN_NAME_ONE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonSearch.givenNameTwo=GIVEN_NAME_TWO," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonSearch.givenNameThree=GIVEN_NAME_THREE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonSearch.givenNameFour=GIVEN_NAME_FOUR," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonSearch.lastName=LAST_NAME," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonSearch.personNameStandardInd=STANDARD_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.personNameIdPK=PERSON_NAME_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.histEndDt=H_END_DT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.XLastModifiedSystemDate=XMODIFY_SYS_DT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.XGivenNameOneLocal=XGIVEN_NAME_ONE_LOCAL," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.XGivenNameTwoLocal=XGIVEN_NAME_TWO_LOCAL," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.XLastNameLocal=XLAST_NAME_LOCAL," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.XPersonNameRetailerFlag=XPERSONNAME_RETAILER_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.X_BPID=X_BPID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension
   * XPersonName.
   *
   * @generated
   */ 
   public final static String getPersonNameImagesSQL = "SELECT DISTINCT A.H_PERSON_NAME_ID AS HIST_ID_PK , A.H_ACTION_CODE , A.H_CREATED_BY , A.H_CREATE_DT , A.H_END_DT , A.PERSON_NAME_ID , A.PREFIX_NAME_TP_CD , A.PREFIX_DESC , A.NAME_USAGE_TP_CD , A.GIVEN_NAME_ONE , A.GIVEN_NAME_TWO , A.GIVEN_NAME_THREE , A.GIVEN_NAME_FOUR , A.LAST_NAME , A.GENERATION_TP_CD , A.SUFFIX_DESC , A.START_DT , A.END_DT , A.CONT_ID , A.USE_STANDARD_IND , A.LAST_UPDATE_DT , A.LAST_UPDATE_USER , A.LAST_UPDATE_TX_ID , A.LAST_USED_DT , A.LAST_VERIFIED_DT , A.SOURCE_IDENT_TP_CD, A.XMODIFY_SYS_DT, A.XGIVEN_NAME_ONE_LOCAL, A.XGIVEN_NAME_TWO_LOCAL, A.XLAST_NAME_LOCAL, A.XPERSONNAME_RETAILER_FLAG, A.X_BPID" + 
     " FROM H_PERSONNAME A" + 
     " WHERE A.CONT_ID = ? AND ( A.H_CREATE_DT BETWEEN ? AND ?)";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPersonNameImagesParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.histCreateDt=H_CREATE_DT"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPersonNameImagesResults =
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.historyIdPK=HIST_ID_PK," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.histActionCode=H_ACTION_CODE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.histCreatedBy=H_CREATED_BY," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.histEndDt=H_END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.personNameIdPK=PERSON_NAME_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.prefixNameTpCd=PREFIX_NAME_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.prefixDesc=PREFIX_DESC," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.nameUsageTpCd=NAME_USAGE_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.givenNameOne=GIVEN_NAME_ONE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.givenNameTwo=GIVEN_NAME_TWO," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.givenNameThree=GIVEN_NAME_THREE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.givenNameFour=GIVEN_NAME_FOUR," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastName=LAST_NAME," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.generationTpCd=GENERATION_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.suffixDesc=SUFFIX_DESC," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.startDt=START_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.endDt=END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.useStandardInd=USE_STANDARD_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastUsedDt=LAST_USED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastVerifiedDt=LAST_VERIFIED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.sourceIdentTpCd=SOURCE_IDENT_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.XLastModifiedSystemDate=XMODIFY_SYS_DT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.XGivenNameOneLocal=XGIVEN_NAME_ONE_LOCAL," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.XGivenNameTwoLocal=XGIVEN_NAME_TWO_LOCAL," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.XLastNameLocal=XLAST_NAME_LOCAL," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.XPersonNameRetailerFlag=XPERSONNAME_RETAILER_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.X_BPID=X_BPID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension
   * XPersonName.
   *
   * @generated
   */ 
   public final static String getPersonNameLightImagesSQL = "SELECT DISTINCT A.PERSON_NAME_ID , A.LAST_UPDATE_DT, A.XMODIFY_SYS_DT, A.XGIVEN_NAME_ONE_LOCAL, A.XGIVEN_NAME_TWO_LOCAL, A.XLAST_NAME_LOCAL, A.XPERSONNAME_RETAILER_FLAG, A.X_BPID" + 
     " FROM H_PERSONNAME A" + 
     " WHERE A.CONT_ID = ? AND ( A.H_CREATE_DT BETWEEN ? AND ?)";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPersonNameLightImagesParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.histCreateDt=H_CREATE_DT"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPersonNameLightImagesResults =
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.personNameIdPK=PERSON_NAME_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.XLastModifiedSystemDate=XMODIFY_SYS_DT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.XGivenNameOneLocal=XGIVEN_NAME_ONE_LOCAL," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.XGivenNameTwoLocal=XGIVEN_NAME_TWO_LOCAL," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.XLastNameLocal=XLAST_NAME_LOCAL," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.XPersonNameRetailerFlag=XPERSONNAME_RETAILER_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.X_BPID=X_BPID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension
   * XPersonName.
   *
   * @generated
   */ 
   public final static String getPersonNamesNotStandardizedHistorySQL = "SELECT DISTINCT A.H_PERSON_NAME_ID AS HIST_ID_PK , A.H_ACTION_CODE , A.H_CREATED_BY , A.H_CREATE_DT , A.H_END_DT , A.PERSON_NAME_ID , A.PREFIX_NAME_TP_CD , A.PREFIX_DESC , A.NAME_USAGE_TP_CD , A.GIVEN_NAME_ONE , A.GIVEN_NAME_TWO , A.GIVEN_NAME_THREE , A.GIVEN_NAME_FOUR , A.LAST_NAME , A.GENERATION_TP_CD , A.SUFFIX_DESC , A.START_DT , A.END_DT , A.CONT_ID , A.USE_STANDARD_IND , A.LAST_UPDATE_DT , A.LAST_UPDATE_USER , A.LAST_UPDATE_TX_ID , A.LAST_USED_DT , A.LAST_VERIFIED_DT , A.SOURCE_IDENT_TP_CD, A.XMODIFY_SYS_DT, A.XGIVEN_NAME_ONE_LOCAL, A.XGIVEN_NAME_TWO_LOCAL, A.XLAST_NAME_LOCAL, A.XPERSONNAME_RETAILER_FLAG, A.X_BPID" + 
     " FROM H_PERSONNAME A" + 
     " WHERE A.CONT_ID = ? AND (( ? BETWEEN A.H_CREATE_DT AND A.H_END_DT ) OR ( ? >= A.H_CREATE_DT AND A.H_END_DT IS NULL ))";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPersonNamesNotStandardizedHistoryParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.histCreateDt=H_CREATE_DT"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPersonNamesNotStandardizedHistoryResults =
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.historyIdPK=HIST_ID_PK," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.histActionCode=H_ACTION_CODE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.histCreatedBy=H_CREATED_BY," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.histEndDt=H_END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.personNameIdPK=PERSON_NAME_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.prefixNameTpCd=PREFIX_NAME_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.prefixDesc=PREFIX_DESC," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.nameUsageTpCd=NAME_USAGE_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.givenNameOne=GIVEN_NAME_ONE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.givenNameTwo=GIVEN_NAME_TWO," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.givenNameThree=GIVEN_NAME_THREE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.givenNameFour=GIVEN_NAME_FOUR," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastName=LAST_NAME," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.generationTpCd=GENERATION_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.suffixDesc=SUFFIX_DESC," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.startDt=START_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.endDt=END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.useStandardInd=USE_STANDARD_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastUsedDt=LAST_USED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastVerifiedDt=LAST_VERIFIED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.sourceIdentTpCd=SOURCE_IDENT_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.XLastModifiedSystemDate=XMODIFY_SYS_DT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.XGivenNameOneLocal=XGIVEN_NAME_ONE_LOCAL," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.XGivenNameTwoLocal=XGIVEN_NAME_TWO_LOCAL," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.XLastNameLocal=XLAST_NAME_LOCAL," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.XPersonNameRetailerFlag=XPERSONNAME_RETAILER_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.X_BPID=X_BPID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension
   * XPersonName.
   *
   * @generated
   */ 
   public final static String getPersonNamesNotStandardizedActiveSQL = "SELECT PERSONNAME.PERSON_NAME_ID , PERSONNAME.PREFIX_NAME_TP_CD , PERSONNAME.PREFIX_DESC , PERSONNAME.NAME_USAGE_TP_CD , PERSONNAME.GIVEN_NAME_ONE , PERSONNAME.GIVEN_NAME_TWO , PERSONNAME.GIVEN_NAME_THREE , PERSONNAME.GIVEN_NAME_FOUR , PERSONNAME.LAST_NAME , PERSONNAME.GENERATION_TP_CD , PERSONNAME.SUFFIX_DESC , PERSONNAME.START_DT , PERSONNAME.END_DT , PERSONNAME.CONT_ID , PERSONNAME.USE_STANDARD_IND , PERSONNAME.LAST_UPDATE_DT , PERSONNAME.LAST_UPDATE_USER , PERSONNAME.LAST_UPDATE_TX_ID , PERSONNAME.LAST_USED_DT , PERSONNAME.LAST_VERIFIED_DT , PERSONNAME.SOURCE_IDENT_TP_CD, PERSONNAME.XMODIFY_SYS_DT, PERSONNAME.XGIVEN_NAME_ONE_LOCAL, PERSONNAME.XGIVEN_NAME_TWO_LOCAL, PERSONNAME.XLAST_NAME_LOCAL, PERSONNAME.XPERSONNAME_RETAILER_FLAG, PERSONNAME.X_BPID" + 
     " FROM PERSONNAME" + 
     " WHERE PERSONNAME.CONT_ID = ? AND (PERSONNAME.END_DT IS NULL OR PERSONNAME.END_DT> ? )";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPersonNamesNotStandardizedActiveParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.endDt=END_DT"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPersonNamesNotStandardizedActiveResults =
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.personNameIdPK=PERSON_NAME_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.prefixNameTpCd=PREFIX_NAME_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.prefixDesc=PREFIX_DESC," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.nameUsageTpCd=NAME_USAGE_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.givenNameOne=GIVEN_NAME_ONE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.givenNameTwo=GIVEN_NAME_TWO," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.givenNameThree=GIVEN_NAME_THREE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.givenNameFour=GIVEN_NAME_FOUR," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastName=LAST_NAME," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.generationTpCd=GENERATION_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.suffixDesc=SUFFIX_DESC," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.startDt=START_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.endDt=END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.useStandardInd=USE_STANDARD_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastUsedDt=LAST_USED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastVerifiedDt=LAST_VERIFIED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.sourceIdentTpCd=SOURCE_IDENT_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.XLastModifiedSystemDate=XMODIFY_SYS_DT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.XGivenNameOneLocal=XGIVEN_NAME_ONE_LOCAL," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.XGivenNameTwoLocal=XGIVEN_NAME_TWO_LOCAL," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.XLastNameLocal=XLAST_NAME_LOCAL," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.XPersonNameRetailerFlag=XPERSONNAME_RETAILER_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.X_BPID=X_BPID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension
   * XPersonName.
   *
   * @generated
   */ 
   public final static String getPersonNamesNotStandardizedInActiveSQL = "SELECT PERSONNAME.PERSON_NAME_ID , PERSONNAME.PREFIX_NAME_TP_CD , PERSONNAME.PREFIX_DESC , PERSONNAME.NAME_USAGE_TP_CD , PERSONNAME.GIVEN_NAME_ONE , PERSONNAME.GIVEN_NAME_TWO , PERSONNAME.GIVEN_NAME_THREE , PERSONNAME.GIVEN_NAME_FOUR , PERSONNAME.LAST_NAME , PERSONNAME.GENERATION_TP_CD , PERSONNAME.SUFFIX_DESC , PERSONNAME.START_DT , PERSONNAME.END_DT , PERSONNAME.CONT_ID , PERSONNAME.USE_STANDARD_IND , PERSONNAME.LAST_UPDATE_DT , PERSONNAME.LAST_UPDATE_USER , PERSONNAME.LAST_UPDATE_TX_ID , PERSONNAME.LAST_USED_DT , PERSONNAME.LAST_VERIFIED_DT , PERSONNAME.SOURCE_IDENT_TP_CD, PERSONNAME.XMODIFY_SYS_DT, PERSONNAME.XGIVEN_NAME_ONE_LOCAL, PERSONNAME.XGIVEN_NAME_TWO_LOCAL, PERSONNAME.XLAST_NAME_LOCAL, PERSONNAME.XPERSONNAME_RETAILER_FLAG, PERSONNAME.X_BPID" + 
     " FROM PERSONNAME" + 
     " WHERE PERSONNAME.CONT_ID = ? AND PERSONNAME.END_DT< ?";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPersonNamesNotStandardizedInActiveParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.endDt=END_DT"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPersonNamesNotStandardizedInActiveResults =
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.personNameIdPK=PERSON_NAME_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.prefixNameTpCd=PREFIX_NAME_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.prefixDesc=PREFIX_DESC," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.nameUsageTpCd=NAME_USAGE_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.givenNameOne=GIVEN_NAME_ONE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.givenNameTwo=GIVEN_NAME_TWO," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.givenNameThree=GIVEN_NAME_THREE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.givenNameFour=GIVEN_NAME_FOUR," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastName=LAST_NAME," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.generationTpCd=GENERATION_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.suffixDesc=SUFFIX_DESC," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.startDt=START_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.endDt=END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.useStandardInd=USE_STANDARD_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastUsedDt=LAST_USED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastVerifiedDt=LAST_VERIFIED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.sourceIdentTpCd=SOURCE_IDENT_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.XLastModifiedSystemDate=XMODIFY_SYS_DT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.XGivenNameOneLocal=XGIVEN_NAME_ONE_LOCAL," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.XGivenNameTwoLocal=XGIVEN_NAME_TWO_LOCAL," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.XLastNameLocal=XLAST_NAME_LOCAL," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.XPersonNameRetailerFlag=XPERSONNAME_RETAILER_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.X_BPID=X_BPID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension
   * XPersonName.
   *
   * @generated
   */ 
   public final static String getPersonNamesNotStandardizedAllSQL = "SELECT PERSONNAME.PERSON_NAME_ID , PERSONNAME.PREFIX_NAME_TP_CD , PERSONNAME.PREFIX_DESC , PERSONNAME.NAME_USAGE_TP_CD , PERSONNAME.GIVEN_NAME_ONE , PERSONNAME.GIVEN_NAME_TWO , PERSONNAME.GIVEN_NAME_THREE , PERSONNAME.GIVEN_NAME_FOUR , PERSONNAME.LAST_NAME , PERSONNAME.GENERATION_TP_CD , PERSONNAME.SUFFIX_DESC , PERSONNAME.START_DT , PERSONNAME.END_DT , PERSONNAME.CONT_ID , PERSONNAME.USE_STANDARD_IND , PERSONNAME.LAST_UPDATE_DT , PERSONNAME.LAST_UPDATE_USER , PERSONNAME.LAST_UPDATE_TX_ID , PERSONNAME.LAST_USED_DT , PERSONNAME.LAST_VERIFIED_DT , PERSONNAME.SOURCE_IDENT_TP_CD, PERSONNAME.XMODIFY_SYS_DT, PERSONNAME.XGIVEN_NAME_ONE_LOCAL, PERSONNAME.XGIVEN_NAME_TWO_LOCAL, PERSONNAME.XLAST_NAME_LOCAL, PERSONNAME.XPERSONNAME_RETAILER_FLAG, PERSONNAME.X_BPID" + 
     " FROM PERSONNAME" + 
     " WHERE PERSONNAME.CONT_ID = ?";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPersonNamesNotStandardizedAllParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.contId=CONT_ID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPersonNamesNotStandardizedAllResults =
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.personNameIdPK=PERSON_NAME_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.prefixNameTpCd=PREFIX_NAME_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.prefixDesc=PREFIX_DESC," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.nameUsageTpCd=NAME_USAGE_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.givenNameOne=GIVEN_NAME_ONE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.givenNameTwo=GIVEN_NAME_TWO," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.givenNameThree=GIVEN_NAME_THREE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.givenNameFour=GIVEN_NAME_FOUR," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastName=LAST_NAME," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.generationTpCd=GENERATION_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.suffixDesc=SUFFIX_DESC," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.startDt=START_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.endDt=END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.useStandardInd=USE_STANDARD_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastUsedDt=LAST_USED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastVerifiedDt=LAST_VERIFIED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.sourceIdentTpCd=SOURCE_IDENT_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.XLastModifiedSystemDate=XMODIFY_SYS_DT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.XGivenNameOneLocal=XGIVEN_NAME_ONE_LOCAL," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.XGivenNameTwoLocal=XGIVEN_NAME_TWO_LOCAL," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.XLastNameLocal=XLAST_NAME_LOCAL," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.XPersonNameRetailerFlag=XPERSONNAME_RETAILER_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.X_BPID=X_BPID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension
   * XPersonName.
   *
   * @generated
   */ 
   public final static String getPersonNameNotStandardizedWithTypeHistorySQL = "SELECT DISTINCT A.H_PERSON_NAME_ID AS HIST_ID_PK ,A.H_ACTION_CODE ,A.H_CREATED_BY ,A.H_CREATE_DT ,A.H_END_DT ,A.PERSON_NAME_ID ,A.PREFIX_NAME_TP_CD ,A.PREFIX_DESC ,A.NAME_USAGE_TP_CD ,A.GIVEN_NAME_ONE ,A.GIVEN_NAME_TWO ,A.GIVEN_NAME_THREE ,A.GIVEN_NAME_FOUR ,A.LAST_NAME , A.GENERATION_TP_CD , A.SUFFIX_DESC ,A.START_DT ,A.END_DT ,A.CONT_ID ,A.USE_STANDARD_IND ,A.LAST_UPDATE_DT ,A.LAST_UPDATE_USER , A.LAST_UPDATE_TX_ID , A.LAST_USED_DT , A.LAST_VERIFIED_DT , A.SOURCE_IDENT_TP_CD, A.XMODIFY_SYS_DT, A.XGIVEN_NAME_ONE_LOCAL, A.XGIVEN_NAME_TWO_LOCAL, A.XLAST_NAME_LOCAL, A.XPERSONNAME_RETAILER_FLAG, A.X_BPID" + 
     " FROM H_PERSONNAME A" + 
     " WHERE A.CONT_ID = ? AND A.NAME_USAGE_TP_CD = ? AND (? BETWEEN A.H_CREATE_DT AND A.H_END_DT OR (? >= A.H_CREATE_DT AND A.H_END_DT IS NULL ))";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPersonNameNotStandardizedWithTypeHistoryParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.nameUsageTpCd=NAME_USAGE_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.histCreateDt=H_CREATE_DT"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPersonNameNotStandardizedWithTypeHistoryResults =
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.historyIdPK=HIST_ID_PK," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.histActionCode=H_ACTION_CODE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.histCreatedBy=H_CREATED_BY," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.histEndDt=H_END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.personNameIdPK=PERSON_NAME_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.prefixNameTpCd=PREFIX_NAME_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.prefixDesc=PREFIX_DESC," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.nameUsageTpCd=NAME_USAGE_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.givenNameOne=GIVEN_NAME_ONE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.givenNameTwo=GIVEN_NAME_TWO," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.givenNameThree=GIVEN_NAME_THREE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.givenNameFour=GIVEN_NAME_FOUR," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastName=LAST_NAME," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.generationTpCd=GENERATION_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.suffixDesc=SUFFIX_DESC," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.startDt=START_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.endDt=END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.useStandardInd=USE_STANDARD_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastUsedDt=LAST_USED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastVerifiedDt=LAST_VERIFIED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.sourceIdentTpCd=SOURCE_IDENT_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.XLastModifiedSystemDate=XMODIFY_SYS_DT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.XGivenNameOneLocal=XGIVEN_NAME_ONE_LOCAL," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.XGivenNameTwoLocal=XGIVEN_NAME_TWO_LOCAL," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.XLastNameLocal=XLAST_NAME_LOCAL," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.XPersonNameRetailerFlag=XPERSONNAME_RETAILER_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.X_BPID=X_BPID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension
   * XPersonName.
   *
   * @generated
   */ 
   public final static String getPersonNameNotStandardizedWithTypeSQL = "SELECT PERSONNAME.PERSON_NAME_ID ,PERSONNAME.PREFIX_NAME_TP_CD ,PERSONNAME.PREFIX_DESC ,PERSONNAME.NAME_USAGE_TP_CD ,PERSONNAME.GIVEN_NAME_ONE ,PERSONNAME.GIVEN_NAME_TWO ,PERSONNAME.GIVEN_NAME_THREE ,PERSONNAME.GIVEN_NAME_FOUR ,PERSONNAME.LAST_NAME , PERSONNAME.GENERATION_TP_CD , PERSONNAME.SUFFIX_DESC ,PERSONNAME.START_DT ,PERSONNAME.END_DT ,PERSONNAME.CONT_ID ,PERSONNAME.USE_STANDARD_IND ,PERSONNAME.LAST_UPDATE_DT ,PERSONNAME.LAST_UPDATE_USER , PERSONNAME.LAST_UPDATE_TX_ID , PERSONNAME.LAST_USED_DT , PERSONNAME.LAST_VERIFIED_DT , PERSONNAME.SOURCE_IDENT_TP_CD, PERSONNAME.XMODIFY_SYS_DT, PERSONNAME.XGIVEN_NAME_ONE_LOCAL, PERSONNAME.XGIVEN_NAME_TWO_LOCAL, PERSONNAME.XLAST_NAME_LOCAL, PERSONNAME.XPERSONNAME_RETAILER_FLAG, PERSONNAME.X_BPID" + 
     " FROM PERSONNAME" + 
     " WHERE PERSONNAME.CONT_ID = ? AND (PERSONNAME.NAME_USAGE_TP_CD = ?) AND (PERSONNAME.END_DT IS NULL OR PERSONNAME.END_DT> ? )";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPersonNameNotStandardizedWithTypeParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.nameUsageTpCd=NAME_USAGE_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.endDt=END_DT"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPersonNameNotStandardizedWithTypeResults =
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.personNameIdPK=PERSON_NAME_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.prefixNameTpCd=PREFIX_NAME_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.prefixDesc=PREFIX_DESC," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.nameUsageTpCd=NAME_USAGE_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.givenNameOne=GIVEN_NAME_ONE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.givenNameTwo=GIVEN_NAME_TWO," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.givenNameThree=GIVEN_NAME_THREE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.givenNameFour=GIVEN_NAME_FOUR," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastName=LAST_NAME," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.generationTpCd=GENERATION_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.suffixDesc=SUFFIX_DESC," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.startDt=START_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.endDt=END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.useStandardInd=USE_STANDARD_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastUsedDt=LAST_USED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastVerifiedDt=LAST_VERIFIED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.sourceIdentTpCd=SOURCE_IDENT_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.XLastModifiedSystemDate=XMODIFY_SYS_DT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.XGivenNameOneLocal=XGIVEN_NAME_ONE_LOCAL," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.XGivenNameTwoLocal=XGIVEN_NAME_TWO_LOCAL," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.XLastNameLocal=XLAST_NAME_LOCAL," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.XPersonNameRetailerFlag=XPERSONNAME_RETAILER_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.X_BPID=X_BPID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension
   * XPersonName.
   *
   * @generated
   */ 
   public final static String getPersonNameNotStandardizedByIDSQL = "SELECT PERSONNAME.PERSON_NAME_ID , PERSONNAME.PREFIX_NAME_TP_CD , PERSONNAME.PREFIX_DESC , PERSONNAME.NAME_USAGE_TP_CD , PERSONNAME.GIVEN_NAME_ONE , PERSONNAME.GIVEN_NAME_TWO , PERSONNAME.GIVEN_NAME_THREE , PERSONNAME.GIVEN_NAME_FOUR , PERSONNAME.LAST_NAME , PERSONNAME.GENERATION_TP_CD , PERSONNAME.SUFFIX_DESC , PERSONNAME.START_DT , PERSONNAME.END_DT , PERSONNAME.CONT_ID , PERSONNAME.USE_STANDARD_IND , PERSONNAME.LAST_UPDATE_DT , PERSONNAME.LAST_UPDATE_USER , PERSONNAME.LAST_UPDATE_TX_ID , PERSONNAME.LAST_USED_DT , PERSONNAME.LAST_VERIFIED_DT , PERSONNAME.SOURCE_IDENT_TP_CD, PERSONNAME.XMODIFY_SYS_DT, PERSONNAME.XGIVEN_NAME_ONE_LOCAL, PERSONNAME.XGIVEN_NAME_TWO_LOCAL, PERSONNAME.XLAST_NAME_LOCAL, PERSONNAME.XPERSONNAME_RETAILER_FLAG, PERSONNAME.X_BPID" + 
     " FROM PERSONNAME" + 
     " WHERE PERSONNAME.PERSON_NAME_ID = ?";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPersonNameNotStandardizedByIDParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.personNameIdPK=PERSON_NAME_ID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPersonNameNotStandardizedByIDResults =
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.personNameIdPK=PERSON_NAME_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.prefixNameTpCd=PREFIX_NAME_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.prefixDesc=PREFIX_DESC," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.nameUsageTpCd=NAME_USAGE_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.givenNameOne=GIVEN_NAME_ONE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.givenNameTwo=GIVEN_NAME_TWO," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.givenNameThree=GIVEN_NAME_THREE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.givenNameFour=GIVEN_NAME_FOUR," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastName=LAST_NAME," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.generationTpCd=GENERATION_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.suffixDesc=SUFFIX_DESC," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.startDt=START_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.endDt=END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.useStandardInd=USE_STANDARD_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastUsedDt=LAST_USED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastVerifiedDt=LAST_VERIFIED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.sourceIdentTpCd=SOURCE_IDENT_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.XLastModifiedSystemDate=XMODIFY_SYS_DT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.XGivenNameOneLocal=XGIVEN_NAME_ONE_LOCAL," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.XGivenNameTwoLocal=XGIVEN_NAME_TWO_LOCAL," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.XLastNameLocal=XLAST_NAME_LOCAL," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.XPersonNameRetailerFlag=XPERSONNAME_RETAILER_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.X_BPID=X_BPID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension
   * XPersonName.
   *
   * @generated
   */ 
   public final static String getPersonNameNotStandardizedHistoryByIdSQL = "SELECT H_PERSONNAME.H_PERSON_NAME_ID AS HIST_ID_PK , H_PERSONNAME.H_ACTION_CODE, H_PERSONNAME.H_CREATED_BY, H_PERSONNAME.H_CREATE_DT, H_PERSONNAME.PREFIX_NAME_TP_CD , H_PERSONNAME.PREFIX_DESC , H_PERSONNAME.NAME_USAGE_TP_CD , H_PERSONNAME.GIVEN_NAME_ONE , H_PERSONNAME.GIVEN_NAME_TWO , H_PERSONNAME.GIVEN_NAME_THREE , H_PERSONNAME.GIVEN_NAME_FOUR , H_PERSONNAME.LAST_NAME , H_PERSONNAME.GENERATION_TP_CD , H_PERSONNAME.SUFFIX_DESC , H_PERSONNAME.START_DT , H_PERSONNAME.END_DT , H_PERSONNAME.CONT_ID , H_PERSONNAME.USE_STANDARD_IND , H_PERSONNAME.LAST_UPDATE_DT , H_PERSONNAME.LAST_UPDATE_USER , H_PERSONNAME.LAST_UPDATE_TX_ID , H_PERSONNAME.LAST_USED_DT , H_PERSONNAME.LAST_VERIFIED_DT , H_PERSONNAME.SOURCE_IDENT_TP_CD, H_PERSONNAME.XMODIFY_SYS_DT, H_PERSONNAME.XGIVEN_NAME_ONE_LOCAL, H_PERSONNAME.XGIVEN_NAME_TWO_LOCAL, H_PERSONNAME.XLAST_NAME_LOCAL, H_PERSONNAME.XPERSONNAME_RETAILER_FLAG, H_PERSONNAME.X_BPID" + 
     " FROM H_PERSONNAME" + 
     " WHERE H_PERSONNAME.H_PERSON_NAME_ID = ? AND (( ? BETWEEN H_PERSONNAME.H_CREATE_DT AND H_PERSONNAME.H_END_DT ) OR ( ? >= H_PERSONNAME.H_CREATE_DT AND H_PERSONNAME.H_END_DT IS NULL ))";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPersonNameNotStandardizedHistoryByIdParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.historyIdPK=H_PERSON_NAME_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.histCreateDt=H_CREATE_DT"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPersonNameNotStandardizedHistoryByIdResults =
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.historyIdPK=HIST_ID_PK," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.histActionCode=H_ACTION_CODE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.histCreatedBy=H_CREATED_BY," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.prefixNameTpCd=PREFIX_NAME_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.prefixDesc=PREFIX_DESC," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.nameUsageTpCd=NAME_USAGE_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.givenNameOne=GIVEN_NAME_ONE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.givenNameTwo=GIVEN_NAME_TWO," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.givenNameThree=GIVEN_NAME_THREE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.givenNameFour=GIVEN_NAME_FOUR," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastName=LAST_NAME," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.generationTpCd=GENERATION_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.suffixDesc=SUFFIX_DESC," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.startDt=START_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.endDt=END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.useStandardInd=USE_STANDARD_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastUsedDt=LAST_USED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.lastVerifiedDt=LAST_VERIFIED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjPersonName.sourceIdentTpCd=SOURCE_IDENT_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.XLastModifiedSystemDate=XMODIFY_SYS_DT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.XGivenNameOneLocal=XGIVEN_NAME_ONE_LOCAL," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.XGivenNameTwoLocal=XGIVEN_NAME_TWO_LOCAL," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.XLastNameLocal=XLAST_NAME_LOCAL," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.XPersonNameRetailerFlag=XPERSONNAME_RETAILER_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt.X_BPID=X_BPID"; 


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getPersonNamesHistorySQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getPersonNamesHistoryParameters, results=getPersonNamesHistoryResults)
  		Iterator<ResultQueue3<EObjPersonName, EObjPersonSearch, EObjXPersonNameExt>> getPersonNamesHistory(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getPersonNamesActiveSQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getPersonNamesActiveParameters, results=getPersonNamesActiveResults)
  		Iterator<ResultQueue3<EObjPersonName, EObjPersonSearch, EObjXPersonNameExt>> getPersonNamesActive(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getPersonNamesInActiveSQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getPersonNamesInActiveParameters, results=getPersonNamesInActiveResults)
  		Iterator<ResultQueue3<EObjPersonName, EObjPersonSearch, EObjXPersonNameExt>> getPersonNamesInActive(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getPersonNamesAllSQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getPersonNamesAllParameters, results=getPersonNamesAllResults)
  		Iterator<ResultQueue3<EObjPersonName, EObjPersonSearch, EObjXPersonNameExt>> getPersonNamesAll(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getPersonNameWithTypeHistorySQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getPersonNameWithTypeHistoryParameters, results=getPersonNameWithTypeHistoryResults)
  		Iterator<ResultQueue3<EObjPersonName, EObjPersonSearch, EObjXPersonNameExt>> getPersonNameWithTypeHistory(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getPersonNameWithTypeSQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getPersonNameWithTypeParameters, results=getPersonNameWithTypeResults)
  		Iterator<ResultQueue3<EObjPersonName, EObjPersonSearch, EObjXPersonNameExt>> getPersonNameWithType(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getPersonNameByIDSQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getPersonNameByIDParameters, results=getPersonNameByIDResults)
  		Iterator<ResultQueue3<EObjPersonName, EObjPersonSearch, EObjXPersonNameExt>> getPersonNameByID(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getPersonNameByIDHistorySQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getPersonNameByIDHistoryParameters, results=getPersonNameByIDHistoryResults)
  		Iterator<ResultQueue3<EObjPersonName, EObjPersonSearch, EObjXPersonNameExt>> getPersonNameByIDHistory(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getPersonNameImagesSQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getPersonNameImagesParameters, results=getPersonNameImagesResults)
  		Iterator<ResultQueue2<EObjPersonName, EObjXPersonNameExt>> getPersonNameImages(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getPersonNameLightImagesSQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getPersonNameLightImagesParameters, results=getPersonNameLightImagesResults)
  		Iterator<ResultQueue2<EObjPersonName, EObjXPersonNameExt>> getPersonNameLightImages(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getPersonNamesNotStandardizedHistorySQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getPersonNamesNotStandardizedHistoryParameters, results=getPersonNamesNotStandardizedHistoryResults)
  		Iterator<ResultQueue2<EObjPersonName, EObjXPersonNameExt>> getPersonNamesNotStandardizedHistory(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getPersonNamesNotStandardizedActiveSQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getPersonNamesNotStandardizedActiveParameters, results=getPersonNamesNotStandardizedActiveResults)
  		Iterator<ResultQueue2<EObjPersonName, EObjXPersonNameExt>> getPersonNamesNotStandardizedActive(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getPersonNamesNotStandardizedInActiveSQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getPersonNamesNotStandardizedInActiveParameters, results=getPersonNamesNotStandardizedInActiveResults)
  		Iterator<ResultQueue2<EObjPersonName, EObjXPersonNameExt>> getPersonNamesNotStandardizedInActive(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getPersonNamesNotStandardizedAllSQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getPersonNamesNotStandardizedAllParameters, results=getPersonNamesNotStandardizedAllResults)
  		Iterator<ResultQueue2<EObjPersonName, EObjXPersonNameExt>> getPersonNamesNotStandardizedAll(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getPersonNameNotStandardizedWithTypeHistorySQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getPersonNameNotStandardizedWithTypeHistoryParameters, results=getPersonNameNotStandardizedWithTypeHistoryResults)
  		Iterator<ResultQueue2<EObjPersonName, EObjXPersonNameExt>> getPersonNameNotStandardizedWithTypeHistory(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getPersonNameNotStandardizedWithTypeSQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getPersonNameNotStandardizedWithTypeParameters, results=getPersonNameNotStandardizedWithTypeResults)
  		Iterator<ResultQueue2<EObjPersonName, EObjXPersonNameExt>> getPersonNameNotStandardizedWithType(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getPersonNameNotStandardizedByIDSQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getPersonNameNotStandardizedByIDParameters, results=getPersonNameNotStandardizedByIDResults)
  		Iterator<ResultQueue2<EObjPersonName, EObjXPersonNameExt>> getPersonNameNotStandardizedByID(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getPersonNameNotStandardizedHistoryByIdSQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getPersonNameNotStandardizedHistoryByIdParameters, results=getPersonNameNotStandardizedHistoryByIdResults)
  		Iterator<ResultQueue2<EObjPersonName, EObjXPersonNameExt>> getPersonNameNotStandardizedHistoryById(Object[] parameters);
 
}


