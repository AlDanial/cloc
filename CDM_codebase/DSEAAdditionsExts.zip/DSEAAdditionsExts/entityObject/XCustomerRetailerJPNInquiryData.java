/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[d865c1c25a49dc01ab12b4c3844f34e9]
 */

package com.ibm.daimler.dsea.entityObject;


import com.ibm.mdm.base.db.ResultQueue1;
import java.util.Iterator;
import com.ibm.mdm.base.db.EntityMapping;
import com.ibm.pdq.annotation.Select;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * @generated
 */
public interface XCustomerRetailerJPNInquiryData {
  
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String tableAliasString = "tableAlias (" + 
                                            "XCUSTOMERRETAILERJPN => com.ibm.daimler.dsea.entityObject.EObjXCustomerRetailerJPN, " +
                                            "H_XCUSTOMERRETAILERJPN => com.ibm.daimler.dsea.entityObject.EObjXCustomerRetailerJPN" +
                                            ")";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getXCustomerRetailerJPNSql = "SELECT r.XCUSTOMERRETAILERJPNPK_ID XCUSTOMERRETAILERJPNPK_ID, r.CONT_ID CONT_ID, r.RETAILER_ID RETAILER_ID, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.START_DT START_DT, r.END_DT END_DT, r.DELETE_FLAG DELETE_FLAG, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XCUSTOMERRETAILERJPN r WHERE r.XCUSTOMERRETAILERJPNPK_ID = ? ";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXCustomerRetailerJPNParameters =
    "EObjXCustomerRetailerJPN.XCustomerRetailerJPNpkId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXCustomerRetailerJPNResults =
    "EObjXCustomerRetailerJPN.XCustomerRetailerJPNpkId," +
    "EObjXCustomerRetailerJPN.ContId," +
    "EObjXCustomerRetailerJPN.RetailerId," +
    "EObjXCustomerRetailerJPN.SourceIdentifier," +
    "EObjXCustomerRetailerJPN.StartDate," +
    "EObjXCustomerRetailerJPN.EndDate," +
    "EObjXCustomerRetailerJPN.DeleteFlag," +
    "EObjXCustomerRetailerJPN.lastUpdateDt," +
    "EObjXCustomerRetailerJPN.lastUpdateUser," +
    "EObjXCustomerRetailerJPN.lastUpdateTxId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getXCustomerRetailerJPNHistorySql = "SELECT r.H_XCUSTOMERRETAILERJPNPK_ID hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.XCUSTOMERRETAILERJPNPK_ID XCUSTOMERRETAILERJPNPK_ID, r.CONT_ID CONT_ID, r.RETAILER_ID RETAILER_ID, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.START_DT START_DT, r.END_DT END_DT, r.DELETE_FLAG DELETE_FLAG, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XCUSTOMERRETAILERJPN r WHERE r.H_XCUSTOMERRETAILERJPNPK_ID = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXCustomerRetailerJPNHistoryParameters =
    "EObjXCustomerRetailerJPN.XCustomerRetailerJPNpkId," +
    "EObjXCustomerRetailerJPN.lastUpdateDt," +
    "EObjXCustomerRetailerJPN.lastUpdateDt";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXCustomerRetailerJPNHistoryResults =
    "EObjXCustomerRetailerJPN.historyIdPK," +
    "EObjXCustomerRetailerJPN.histActionCode," +
    "EObjXCustomerRetailerJPN.histCreatedBy," +
    "EObjXCustomerRetailerJPN.histCreateDt," +
    "EObjXCustomerRetailerJPN.histEndDt," +
    "EObjXCustomerRetailerJPN.XCustomerRetailerJPNpkId," +
    "EObjXCustomerRetailerJPN.ContId," +
    "EObjXCustomerRetailerJPN.RetailerId," +
    "EObjXCustomerRetailerJPN.SourceIdentifier," +
    "EObjXCustomerRetailerJPN.StartDate," +
    "EObjXCustomerRetailerJPN.EndDate," +
    "EObjXCustomerRetailerJPN.DeleteFlag," +
    "EObjXCustomerRetailerJPN.lastUpdateDt," +
    "EObjXCustomerRetailerJPN.lastUpdateUser," +
    "EObjXCustomerRetailerJPN.lastUpdateTxId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getAllXCustomerRetailerJPNByPartyIdSql = "SELECT r.XCUSTOMERRETAILERJPNPK_ID XCUSTOMERRETAILERJPNPK_ID, r.CONT_ID CONT_ID, r.RETAILER_ID RETAILER_ID, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.START_DT START_DT, r.END_DT END_DT, r.DELETE_FLAG DELETE_FLAG, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XCUSTOMERRETAILERJPN r WHERE r.CONT_ID = ? ";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getAllXCustomerRetailerJPNByPartyIdParameters =
    "EObjXCustomerRetailerJPN.ContId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getAllXCustomerRetailerJPNByPartyIdResults =
    "EObjXCustomerRetailerJPN.XCustomerRetailerJPNpkId," +
    "EObjXCustomerRetailerJPN.ContId," +
    "EObjXCustomerRetailerJPN.RetailerId," +
    "EObjXCustomerRetailerJPN.SourceIdentifier," +
    "EObjXCustomerRetailerJPN.StartDate," +
    "EObjXCustomerRetailerJPN.EndDate," +
    "EObjXCustomerRetailerJPN.DeleteFlag," +
    "EObjXCustomerRetailerJPN.lastUpdateDt," +
    "EObjXCustomerRetailerJPN.lastUpdateUser," +
    "EObjXCustomerRetailerJPN.lastUpdateTxId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getAllXCustomerRetailerJPNByPartyIdHistorySql = "SELECT r.H_XCUSTOMERRETAILERJPNPK_ID hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.XCUSTOMERRETAILERJPNPK_ID XCUSTOMERRETAILERJPNPK_ID, r.CONT_ID CONT_ID, r.RETAILER_ID RETAILER_ID, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.START_DT START_DT, r.END_DT END_DT, r.DELETE_FLAG DELETE_FLAG, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XCUSTOMERRETAILERJPN r WHERE r.CONT_ID = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getAllXCustomerRetailerJPNByPartyIdHistoryParameters =
    "EObjXCustomerRetailerJPN.ContId," +
    "EObjXCustomerRetailerJPN.lastUpdateDt," +
    "EObjXCustomerRetailerJPN.lastUpdateDt";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getAllXCustomerRetailerJPNByPartyIdHistoryResults =
    "EObjXCustomerRetailerJPN.historyIdPK," +
    "EObjXCustomerRetailerJPN.histActionCode," +
    "EObjXCustomerRetailerJPN.histCreatedBy," +
    "EObjXCustomerRetailerJPN.histCreateDt," +
    "EObjXCustomerRetailerJPN.histEndDt," +
    "EObjXCustomerRetailerJPN.XCustomerRetailerJPNpkId," +
    "EObjXCustomerRetailerJPN.ContId," +
    "EObjXCustomerRetailerJPN.RetailerId," +
    "EObjXCustomerRetailerJPN.SourceIdentifier," +
    "EObjXCustomerRetailerJPN.StartDate," +
    "EObjXCustomerRetailerJPN.EndDate," +
    "EObjXCustomerRetailerJPN.DeleteFlag," +
    "EObjXCustomerRetailerJPN.lastUpdateDt," +
    "EObjXCustomerRetailerJPN.lastUpdateUser," +
    "EObjXCustomerRetailerJPN.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getXCustomerRetailerJPNSql, pattern=tableAliasString)
  @EntityMapping(parameters=getXCustomerRetailerJPNParameters, results=getXCustomerRetailerJPNResults)
  Iterator<ResultQueue1<EObjXCustomerRetailerJPN>> getXCustomerRetailerJPN(Object[] parameters);  


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getXCustomerRetailerJPNHistorySql, pattern=tableAliasString)
  @EntityMapping(parameters=getXCustomerRetailerJPNHistoryParameters, results=getXCustomerRetailerJPNHistoryResults)
  Iterator<ResultQueue1<EObjXCustomerRetailerJPN>> getXCustomerRetailerJPNHistory(Object[] parameters);  


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getAllXCustomerRetailerJPNByPartyIdSql, pattern=tableAliasString)
  @EntityMapping(parameters=getAllXCustomerRetailerJPNByPartyIdParameters, results=getAllXCustomerRetailerJPNByPartyIdResults)
  Iterator<ResultQueue1<EObjXCustomerRetailerJPN>> getAllXCustomerRetailerJPNByPartyId(Object[] parameters);  


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getAllXCustomerRetailerJPNByPartyIdHistorySql, pattern=tableAliasString)
  @EntityMapping(parameters=getAllXCustomerRetailerJPNByPartyIdHistoryParameters, results=getAllXCustomerRetailerJPNByPartyIdHistoryResults)
  Iterator<ResultQueue1<EObjXCustomerRetailerJPN>> getAllXCustomerRetailerJPNByPartyIdHistory(Object[] parameters);  


}


