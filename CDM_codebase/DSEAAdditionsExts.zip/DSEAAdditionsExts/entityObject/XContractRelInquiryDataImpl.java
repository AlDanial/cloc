package com.ibm.daimler.dsea.entityObject;

import com.ibm.pdq.runtime.generator.BaseParameterHandler;
import com.ibm.daimler.dsea.entityObject.EObjXContractRel;
import java.util.Iterator;
import com.ibm.mdm.base.db.ResultQueue1;
import java.sql.PreparedStatement;
import com.ibm.pdq.runtime.statement.StatementDescriptor;
import com.ibm.pdq.runtime.generator.BaseData;
import java.sql.SQLException;
import com.ibm.pdq.annotation.Metadata;
import com.ibm.pdq.runtime.generator.BaseRowHandler;
import com.ibm.pdq.runtime.statement.SqlStatementType;
import java.sql.Types;


@SuppressWarnings("unchecked")

/**
 * <!-- begin-user-doc -->
 * 
 * <!-- end-user-doc -->
 * 
 * @generated
 */
public class XContractRelInquiryDataImpl  extends BaseData implements XContractRelInquiryData
{

  /**
   * @generated
   */
  public static final String generatorVersion = "3.200.75";

  /**
   * @generated
   */
  public static final String identifier = "XContractRelInquiryData";

  /**
   * @generated
   */
  public static final long generationTime = 0x000001635e662420L;

  /**
   * @generated
   */
  public static final String collection = "NULLID";

  /**
   * @generated
   */
  public static final String packageVersion = null;

  /**
   * @generated
   */
  public static final boolean forceSingleBindIsolation = false;

  /**
   * @generated
   */
  public XContractRelInquiryDataImpl()
  {
    super();
  } 

  /**
   * @generated
   */
  public String getGeneratorVersion()
  {
    return generatorVersion;
  }

  /**
   * @Select( sql="SELECT r.XContract_Relpk_Id XContract_Relpk_Id, r.Contract_Id Contract_Id, r.Cont_Id Cont_Id, r.Market Market, r.Person_Org_Code Person_Org_Code, r.Contract_Role Contract_Role, r.Start_Date Start_Date, r.End_Date End_Date, r.X_BPID X_BPID, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XCONTRACTREL r WHERE r.XContract_Relpk_Id = ? ", pattern="tableAlias (XCONTRACTREL => com.ibm.daimler.dsea.entityObject.EObjXContractRel, H_XCONTRACTREL => com.ibm.daimler.dsea.entityObject.EObjXContractRel)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue1<EObjXContractRel>> getXContractRel (Object[] parameters)
  {
    return queryIterator (getXContractRelStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getXContractRelStatementDescriptor = createStatementDescriptor (
    "getXContractRel(Object[])",
    "SELECT r.XContract_Relpk_Id XContract_Relpk_Id, r.Contract_Id Contract_Id, r.Cont_Id Cont_Id, r.Market Market, r.Person_Org_Code Person_Org_Code, r.Contract_Role Contract_Role, r.Start_Date Start_Date, r.End_Date End_Date, r.X_BPID X_BPID, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XCONTRACTREL r WHERE r.XContract_Relpk_Id = ? ",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"xcontract_relpk_id", "contract_id", "cont_id", "market", "person_org_code", "contract_role", "start_date", "end_date", "x_bpid", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetXContractRelParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetXContractRelRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 19, 19, 250, 1, 250, 0, 0, 50, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    1);

  /**
   * @generated
   */
  public static class GetXContractRelParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetXContractRelRowHandler extends BaseRowHandler<ResultQueue1<EObjXContractRel>>
  {
    /**
     * @generated
     */
    public ResultQueue1<EObjXContractRel> handle (java.sql.ResultSet rs, ResultQueue1<EObjXContractRel> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue1<EObjXContractRel> ();

      EObjXContractRel returnObject1 = new EObjXContractRel ();
      returnObject1.setXContractRelpkId(getLongObject (rs, 1)); 
      returnObject1.setContractId(getLongObject (rs, 2)); 
      returnObject1.setContId(getLongObject (rs, 3)); 
      returnObject1.setMarket(getString (rs, 4)); 
      returnObject1.setPersonOrgCode(getString (rs, 5)); 
      returnObject1.setContractRole(getString (rs, 6)); 
      returnObject1.setStartDate(getTimestamp (rs, 7)); 
      returnObject1.setEndDate(getTimestamp (rs, 8)); 
      returnObject1.setX_BPID(getString (rs, 9)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 10)); 
      returnObject1.setLastUpdateUser(getString (rs, 11)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 12)); 
      returnObject.add (returnObject1);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT r.H_XContract_Relpk_Id hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.XContract_Relpk_Id XContract_Relpk_Id, r.Contract_Id Contract_Id, r.Cont_Id Cont_Id, r.Market Market, r.Person_Org_Code Person_Org_Code, r.Contract_Role Contract_Role, r.Start_Date Start_Date, r.End_Date End_Date, r.X_BPID X_BPID, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XCONTRACTREL r WHERE r.H_XContract_Relpk_Id = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))", pattern="tableAlias (XCONTRACTREL => com.ibm.daimler.dsea.entityObject.EObjXContractRel, H_XCONTRACTREL => com.ibm.daimler.dsea.entityObject.EObjXContractRel)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue1<EObjXContractRel>> getXContractRelHistory (Object[] parameters)
  {
    return queryIterator (getXContractRelHistoryStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getXContractRelHistoryStatementDescriptor = createStatementDescriptor (
    "getXContractRelHistory(Object[])",
    "SELECT r.H_XContract_Relpk_Id hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.XContract_Relpk_Id XContract_Relpk_Id, r.Contract_Id Contract_Id, r.Cont_Id Cont_Id, r.Market Market, r.Person_Org_Code Person_Org_Code, r.Contract_Role Contract_Role, r.Start_Date Start_Date, r.End_Date End_Date, r.X_BPID X_BPID, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XCONTRACTREL r WHERE r.H_XContract_Relpk_Id = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"historyidpk", "h_action_code", "h_created_by", "h_create_dt", "h_end_dt", "xcontract_relpk_id", "contract_id", "cont_id", "market", "person_org_code", "contract_role", "start_date", "end_date", "x_bpid", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetXContractRelHistoryParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP}, {19, 0, 0}, {0, 0, 0}, {1, 1, 1}},
    null,
    new GetXContractRelHistoryRowHandler (),
    new int[][]{ {Types.BIGINT, Types.CHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 1, 20, 0, 0, 19, 19, 19, 250, 1, 250, 0, 0, 50, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    2);

  /**
   * @generated
   */
  public static class GetXContractRelHistoryParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetXContractRelHistoryRowHandler extends BaseRowHandler<ResultQueue1<EObjXContractRel>>
  {
    /**
     * @generated
     */
    public ResultQueue1<EObjXContractRel> handle (java.sql.ResultSet rs, ResultQueue1<EObjXContractRel> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue1<EObjXContractRel> ();

      EObjXContractRel returnObject1 = new EObjXContractRel ();
      returnObject1.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject1.setHistActionCode(getString (rs, 2)); 
      returnObject1.setHistCreatedBy(getString (rs, 3)); 
      returnObject1.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject1.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject1.setXContractRelpkId(getLongObject (rs, 6)); 
      returnObject1.setContractId(getLongObject (rs, 7)); 
      returnObject1.setContId(getLongObject (rs, 8)); 
      returnObject1.setMarket(getString (rs, 9)); 
      returnObject1.setPersonOrgCode(getString (rs, 10)); 
      returnObject1.setContractRole(getString (rs, 11)); 
      returnObject1.setStartDate(getTimestamp (rs, 12)); 
      returnObject1.setEndDate(getTimestamp (rs, 13)); 
      returnObject1.setX_BPID(getString (rs, 14)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 15)); 
      returnObject1.setLastUpdateUser(getString (rs, 16)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 17)); 
      returnObject.add (returnObject1);

    
      return returnObject;
    }
  }

}
