package com.ibm.daimler.dsea.entityObject;

import com.ibm.pdq.runtime.generator.BaseParameterHandler;
import java.util.Iterator;
import com.ibm.daimler.dsea.entityObject.EObjXCustomerRetailerJPN;
import java.sql.PreparedStatement;
import com.ibm.pdq.runtime.statement.StatementDescriptor;
import com.ibm.pdq.runtime.generator.BaseData;
import java.sql.SQLException;
import com.ibm.pdq.annotation.Metadata;
import com.ibm.pdq.runtime.generator.BaseRowHandler;
import com.ibm.pdq.runtime.statement.SqlStatementType;
import java.sql.Types;


/**
 * <!-- begin-user-doc -->
 * 
 * <!-- end-user-doc -->
 * 
 * @generated
 */
public class EObjXCustomerRetailerJPNDataImpl  extends BaseData implements EObjXCustomerRetailerJPNData
{

  /**
   * @generated
   */
  public static final String generatorVersion = "3.200.75";

  /**
   * @generated
   */
  public static final String identifier = "EObjXCustomerRetailerJPNData";

  /**
   * @generated
   */
  public static final long generationTime = 0x000001642283fad1L;

  /**
   * @generated
   */
  public static final String collection = "NULLID";

  /**
   * @generated
   */
  public static final String packageVersion = null;

  /**
   * @generated
   */
  public static final boolean forceSingleBindIsolation = false;

  /**
   * @generated
   */
  public EObjXCustomerRetailerJPNDataImpl()
  {
    super();
  } 

  /**
   * @generated
   */
  public String getGeneratorVersion()
  {
    return generatorVersion;
  }

  /**
   * @Select( sql="select XCUSTOMERRETAILERJPNPK_ID, CONT_ID, RETAILER_ID, SOURCE_IDENT_TP_CD, START_DT, END_DT, DELETE_FLAG, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from XCUSTOMERRETAILERJPN where XCUSTOMERRETAILERJPNPK_ID = ? " )
   * 
   * @generated
   */
  public Iterator<EObjXCustomerRetailerJPN> getEObjXCustomerRetailerJPN (Long xCustomerRetailerJPNpkId)
  {
    return queryIterator (getEObjXCustomerRetailerJPNStatementDescriptor, xCustomerRetailerJPNpkId);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getEObjXCustomerRetailerJPNStatementDescriptor = createStatementDescriptor (
    "getEObjXCustomerRetailerJPN(Long)",
    "select XCUSTOMERRETAILERJPNPK_ID, CONT_ID, RETAILER_ID, SOURCE_IDENT_TP_CD, START_DT, END_DT, DELETE_FLAG, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from XCUSTOMERRETAILERJPN where XCUSTOMERRETAILERJPNPK_ID = ? ",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"xcustomerretailerjpnpk_id", "cont_id", "retailer_id", "source_ident_tp_cd", "start_dt", "end_dt", "delete_flag", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetEObjXCustomerRetailerJPNParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetEObjXCustomerRetailerJPNRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 19, 19, 19, 0, 0, 10, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    1);

  /**
   * @generated
   */
  public static class GetEObjXCustomerRetailerJPNParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setLong (stmt, 1, Types.BIGINT, (Long)parameters[0]);
    }
  }

  /**
   * @generated
   */
  public static class GetEObjXCustomerRetailerJPNRowHandler extends BaseRowHandler<EObjXCustomerRetailerJPN>
  {
    /**
     * @generated
     */
    public EObjXCustomerRetailerJPN handle (java.sql.ResultSet rs, EObjXCustomerRetailerJPN returnObject) throws java.sql.SQLException
    {
      returnObject = new EObjXCustomerRetailerJPN ();
      returnObject.setXCustomerRetailerJPNpkId(getLongObject (rs, 1)); 
      returnObject.setContId(getLongObject (rs, 2)); 
      returnObject.setRetailerId(getLongObject (rs, 3)); 
      returnObject.setSourceIdentifier(getLongObject (rs, 4)); 
      returnObject.setStartDate(getTimestamp (rs, 5)); 
      returnObject.setEndDate(getTimestamp (rs, 6)); 
      returnObject.setDeleteFlag(getString (rs, 7)); 
      returnObject.setLastUpdateDt(getTimestamp (rs, 8)); 
      returnObject.setLastUpdateUser(getString (rs, 9)); 
      returnObject.setLastUpdateTxId(getLongObject (rs, 10)); 
    
      return returnObject;
    }
  }

  /**
   * @Update( sql="insert into XCUSTOMERRETAILERJPN (XCUSTOMERRETAILERJPNPK_ID, CONT_ID, RETAILER_ID, SOURCE_IDENT_TP_CD, START_DT, END_DT, DELETE_FLAG, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( :xCustomerRetailerJPNpkId, :contId, :retailerId, :sourceIdentifier, :startDate, :endDate, :deleteFlag, :lastUpdateDt, :lastUpdateUser, :lastUpdateTxId)" )
   * 
   * @generated
   */
  public int createEObjXCustomerRetailerJPN (EObjXCustomerRetailerJPN e)
  {
    return update (createEObjXCustomerRetailerJPNStatementDescriptor, e);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor createEObjXCustomerRetailerJPNStatementDescriptor = createStatementDescriptor (
    "createEObjXCustomerRetailerJPN(com.ibm.daimler.dsea.entityObject.EObjXCustomerRetailerJPN)",
    "insert into XCUSTOMERRETAILERJPN (XCUSTOMERRETAILERJPNPK_ID, CONT_ID, RETAILER_ID, SOURCE_IDENT_TP_CD, START_DT, END_DT, DELETE_FLAG, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values(  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? )",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.INSERT,
    null,
    new CreateEObjXCustomerRetailerJPNParameterHandler (),
    new int[][]{{Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 19, 19, 19, 0, 0, 10, 0, 0, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1, 1, 1, 1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    2);

  /**
   * @generated
   */
  public static class CreateEObjXCustomerRetailerJPNParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      EObjXCustomerRetailerJPN bean0 = (EObjXCustomerRetailerJPN) parameters[0];
      setLong (stmt, 1, Types.BIGINT, (Long)bean0.getXCustomerRetailerJPNpkId());
      setLong (stmt, 2, Types.BIGINT, (Long)bean0.getContId());
      setLong (stmt, 3, Types.BIGINT, (Long)bean0.getRetailerId());
      setLong (stmt, 4, Types.BIGINT, (Long)bean0.getSourceIdentifier());
      setTimestamp (stmt, 5, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getStartDate());
      setTimestamp (stmt, 6, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getEndDate());
      setString (stmt, 7, Types.VARCHAR, (String)bean0.getDeleteFlag());
      setTimestamp (stmt, 8, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUpdateDt());
      setString (stmt, 9, Types.VARCHAR, (String)bean0.getLastUpdateUser());
      setLong (stmt, 10, Types.BIGINT, (Long)bean0.getLastUpdateTxId());
    }
  }

  /**
   * @Update( sql="update XCUSTOMERRETAILERJPN set CONT_ID = :contId, RETAILER_ID = :retailerId, SOURCE_IDENT_TP_CD = :sourceIdentifier, START_DT = :startDate, END_DT = :endDate, DELETE_FLAG = :deleteFlag, LAST_UPDATE_DT = :lastUpdateDt, LAST_UPDATE_USER = :lastUpdateUser, LAST_UPDATE_TX_ID = :lastUpdateTxId where XCUSTOMERRETAILERJPNPK_ID = :xCustomerRetailerJPNpkId and LAST_UPDATE_DT = :oldLastUpdateDt" )
   * 
   * @generated
   */
  public int updateEObjXCustomerRetailerJPN (EObjXCustomerRetailerJPN e)
  {
    return update (updateEObjXCustomerRetailerJPNStatementDescriptor, e);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor updateEObjXCustomerRetailerJPNStatementDescriptor = createStatementDescriptor (
    "updateEObjXCustomerRetailerJPN(com.ibm.daimler.dsea.entityObject.EObjXCustomerRetailerJPN)",
    "update XCUSTOMERRETAILERJPN set CONT_ID =  ? , RETAILER_ID =  ? , SOURCE_IDENT_TP_CD =  ? , START_DT =  ? , END_DT =  ? , DELETE_FLAG =  ? , LAST_UPDATE_DT =  ? , LAST_UPDATE_USER =  ? , LAST_UPDATE_TX_ID =  ?  where XCUSTOMERRETAILERJPNPK_ID =  ?  and LAST_UPDATE_DT =  ? ",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.UPDATE,
    null,
    new UpdateEObjXCustomerRetailerJPNParameterHandler (),
    new int[][]{{Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP}, {19, 19, 19, 0, 0, 10, 0, 0, 19, 19, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    3);

  /**
   * @generated
   */
  public static class UpdateEObjXCustomerRetailerJPNParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      EObjXCustomerRetailerJPN bean0 = (EObjXCustomerRetailerJPN) parameters[0];
      setLong (stmt, 1, Types.BIGINT, (Long)bean0.getContId());
      setLong (stmt, 2, Types.BIGINT, (Long)bean0.getRetailerId());
      setLong (stmt, 3, Types.BIGINT, (Long)bean0.getSourceIdentifier());
      setTimestamp (stmt, 4, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getStartDate());
      setTimestamp (stmt, 5, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getEndDate());
      setString (stmt, 6, Types.VARCHAR, (String)bean0.getDeleteFlag());
      setTimestamp (stmt, 7, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUpdateDt());
      setString (stmt, 8, Types.VARCHAR, (String)bean0.getLastUpdateUser());
      setLong (stmt, 9, Types.BIGINT, (Long)bean0.getLastUpdateTxId());
      setLong (stmt, 10, Types.BIGINT, (Long)bean0.getXCustomerRetailerJPNpkId());
      setTimestamp (stmt, 11, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getOldLastUpdateDt());
    }
  }

  /**
   * @Update( sql="delete from XCUSTOMERRETAILERJPN where XCUSTOMERRETAILERJPNPK_ID = ?" )
   * 
   * @generated
   */
  public int deleteEObjXCustomerRetailerJPN (Long xCustomerRetailerJPNpkId)
  {
    return update (deleteEObjXCustomerRetailerJPNStatementDescriptor, xCustomerRetailerJPNpkId);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor deleteEObjXCustomerRetailerJPNStatementDescriptor = createStatementDescriptor (
    "deleteEObjXCustomerRetailerJPN(Long)",
    "delete from XCUSTOMERRETAILERJPN where XCUSTOMERRETAILERJPNPK_ID = ?",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.DELETE,
    null,
    new DeleteEObjXCustomerRetailerJPNParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    4);

  /**
   * @generated
   */
  public static class DeleteEObjXCustomerRetailerJPNParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setLong (stmt, 1, Types.BIGINT, (Long)parameters[0]);
    }
  }

}
