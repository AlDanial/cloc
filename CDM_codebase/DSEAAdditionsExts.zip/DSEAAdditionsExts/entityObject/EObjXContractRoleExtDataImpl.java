package com.ibm.daimler.dsea.entityObject;

import com.ibm.pdq.runtime.generator.BaseParameterHandler;
import java.util.Iterator;
import java.sql.PreparedStatement;
import com.ibm.pdq.runtime.statement.StatementDescriptor;
import com.ibm.daimler.dsea.entityObject.EObjXContractRoleExt;
import com.ibm.pdq.runtime.generator.BaseData;
import java.sql.SQLException;
import com.ibm.pdq.annotation.Metadata;
import com.dwl.tcrm.financial.entityObject.EObjContractRole;
import com.ibm.pdq.runtime.generator.BaseRowHandler;
import com.ibm.pdq.runtime.statement.SqlStatementType;
import java.sql.Types;


/**
 * <!-- begin-user-doc -->
 * 
 * <!-- end-user-doc -->
 * 
 * @generated
 */
public class EObjXContractRoleExtDataImpl  extends BaseData implements EObjXContractRoleExtData
{

  /**
   * @generated
   */
  public static final String generatorVersion = "3.200.75";

  /**
   * @generated
   */
  public static final String identifier = "EObjXContractRoleExtData";

  /**
   * @generated
   */
  public static final long generationTime = 0x0000015e13f838f5L;

  /**
   * @generated
   */
  public static final String collection = "NULLID";

  /**
   * @generated
   */
  public static final String packageVersion = null;

  /**
   * @generated
   */
  public static final boolean forceSingleBindIsolation = false;

  /**
   * @generated
   */
  public EObjXContractRoleExtDataImpl()
  {
    super();
  } 

  /**
   * @generated
   */
  public String getGeneratorVersion()
  {
    return generatorVersion;
  }

  /**
   * @Select( sql="select XSOURCE_IDENT_TP_CD, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from CONTRACTROLE where CONTRACT_ROLE_ID = ? " )
   * 
   * @generated
   */
  public Iterator<EObjXContractRoleExt> getEObjXContractRoleExt (Long contractRoleIdPK)
  {
    return queryIterator (getEObjXContractRoleExtStatementDescriptor, contractRoleIdPK);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getEObjXContractRoleExtStatementDescriptor = createStatementDescriptor (
    "getEObjXContractRoleExt(Long)",
    "select XSOURCE_IDENT_TP_CD, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from CONTRACTROLE where CONTRACT_ROLE_ID = ? ",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"xsource_ident_tp_cd", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetEObjXContractRoleExtParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetEObjXContractRoleExtRowHandler (),
    new int[][]{ {Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 0, 20, 19}, {0, 0, 0, 0}, {0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    1);

  /**
   * @generated
   */
  public static class GetEObjXContractRoleExtParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setLong (stmt, 1, Types.BIGINT, (Long)parameters[0]);
    }
  }

  /**
   * @generated
   */
  public static class GetEObjXContractRoleExtRowHandler extends BaseRowHandler<EObjXContractRoleExt>
  {
    /**
     * @generated
     */
    public EObjXContractRoleExt handle (java.sql.ResultSet rs, EObjXContractRoleExt returnObject) throws java.sql.SQLException
    {
      returnObject = new EObjXContractRoleExt ();
      returnObject.setXSourceIdentifier(getLongObject (rs, 1)); 
      returnObject.setLastUpdateDt(getTimestamp (rs, 2)); 
      returnObject.setLastUpdateUser(getString (rs, 3)); 
      returnObject.setLastUpdateTxId(getLongObject (rs, 4)); 
    
      return returnObject;
    }
  }

  /**
   * @Update( sql="insert into CONTRACTROLE (CONTR_COMPONENT_ID, CONTRACT_ROLE_ID, DISTRIB_PCT, END_DT, IRREVOC_IND, CONT_ID, START_DT, REGISTERED_NAME, RECORDED_START_DT, ARRANGEMENT_DESC, RECORDED_END_DT, SHARE_DIST_TP_CD, END_REASON_TP_CD, ARRANGEMENT_TP_CD, CONTR_ROLE_TP_CD, XSOURCE_IDENT_TP_CD, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( ?1.contrComponentId, ?1.contractRoleIdPK, ?1.distribPct, ?1.endDt, ?1.irrevocInd, ?1.contId, ?1.startDt, ?1.registeredName, ?1.recordedStartDt, ?1.arrangementDesc, ?1.recordedEndDt, ?1.shareDistTpCd, ?1.endReasonTpCd, ?1.arrangementTpCd, ?1.contractRoleTpCd, ?2.xSourceIdentifier, ?1.lastUpdateDt, ?1.lastUpdateUser, ?1.lastUpdateTxId)" )
   * 
   * @generated
   */
  public int createEObjXContractRoleExt (EObjContractRole e1, EObjXContractRoleExt e2)
  {
    return update (createEObjXContractRoleExtStatementDescriptor, e1, e2);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor createEObjXContractRoleExtStatementDescriptor = createStatementDescriptor (
    "createEObjXContractRoleExt(com.dwl.tcrm.financial.entityObject.EObjContractRole, com.ibm.daimler.dsea.entityObject.EObjXContractRoleExt)",
    "insert into CONTRACTROLE (CONTR_COMPONENT_ID, CONTRACT_ROLE_ID, DISTRIB_PCT, END_DT, IRREVOC_IND, CONT_ID, START_DT, REGISTERED_NAME, RECORDED_START_DT, ARRANGEMENT_DESC, RECORDED_END_DT, SHARE_DIST_TP_CD, END_REASON_TP_CD, ARRANGEMENT_TP_CD, CONTR_ROLE_TP_CD, XSOURCE_IDENT_TP_CD, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values(  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? )",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.INSERT,
    null,
    new CreateEObjXContractRoleExtParameterHandler (),
    new int[][]{{Types.BIGINT, Types.BIGINT, Types.DECIMAL, Types.TIMESTAMP, Types.CHAR, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 19, 5, 0, 1, 19, 0, 255, 0, 255, 0, 19, 19, 19, 19, 19, 0, 0, 19}, {0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    2);

  /**
   * @generated
   */
  public static class CreateEObjXContractRoleExtParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      EObjContractRole bean0 = (EObjContractRole) parameters[0];
      setLong (stmt, 1, Types.BIGINT, (Long)bean0.getContrComponentId());
      setLong (stmt, 2, Types.BIGINT, (Long)bean0.getContractRoleIdPK());
      setBigDecimal (stmt, 3, Types.DECIMAL, (java.math.BigDecimal)bean0.getDistribPct());
      setTimestamp (stmt, 4, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getEndDt());
      setString (stmt, 5, Types.CHAR, (String)bean0.getIrrevocInd());
      setLong (stmt, 6, Types.BIGINT, (Long)bean0.getContId());
      setTimestamp (stmt, 7, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getStartDt());
      setString (stmt, 8, Types.VARCHAR, (String)bean0.getRegisteredName());
      setTimestamp (stmt, 9, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getRecordedStartDt());
      setString (stmt, 10, Types.VARCHAR, (String)bean0.getArrangementDesc());
      setTimestamp (stmt, 11, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getRecordedEndDt());
      setLong (stmt, 12, Types.BIGINT, (Long)bean0.getShareDistTpCd());
      setLong (stmt, 13, Types.BIGINT, (Long)bean0.getEndReasonTpCd());
      setLong (stmt, 14, Types.BIGINT, (Long)bean0.getArrangementTpCd());
      setLong (stmt, 15, Types.BIGINT, (Long)bean0.getContractRoleTpCd());
      EObjXContractRoleExt bean1 = (EObjXContractRoleExt) parameters[1];
      setLong (stmt, 16, Types.BIGINT, (Long)bean1.getXSourceIdentifier());
      setTimestamp (stmt, 17, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUpdateDt());
      setString (stmt, 18, Types.VARCHAR, (String)bean0.getLastUpdateUser());
      setLong (stmt, 19, Types.BIGINT, (Long)bean0.getLastUpdateTxId());
    }
  }

  /**
   * @Update( sql="update CONTRACTROLE set CONTR_COMPONENT_ID = ?1.contrComponentId, DISTRIB_PCT = ?1.distribPct, END_DT = ?1.endDt, IRREVOC_IND = ?1.irrevocInd, CONT_ID = ?1.contId, START_DT = ?1.startDt, REGISTERED_NAME = ?1.registeredName, RECORDED_START_DT = ?1.recordedStartDt, ARRANGEMENT_DESC = ?1.arrangementDesc, RECORDED_END_DT = ?1.recordedEndDt, SHARE_DIST_TP_CD = ?1.shareDistTpCd, END_REASON_TP_CD = ?1.endReasonTpCd, ARRANGEMENT_TP_CD = ?1.arrangementTpCd, CONTR_ROLE_TP_CD = ?1.contractRoleTpCd, XSOURCE_IDENT_TP_CD = ?2.xSourceIdentifier, LAST_UPDATE_DT = ?1.lastUpdateDt, LAST_UPDATE_USER = ?1.lastUpdateUser, LAST_UPDATE_TX_ID = ?1.lastUpdateTxId where CONTRACT_ROLE_ID = ?1.contractRoleIdPK and LAST_UPDATE_DT = ?1.oldLastUpdateDt" )
   * 
   * @generated
   */
  public int updateEObjXContractRoleExt (EObjContractRole e1, EObjXContractRoleExt e2)
  {
    return update (updateEObjXContractRoleExtStatementDescriptor, e1, e2);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor updateEObjXContractRoleExtStatementDescriptor = createStatementDescriptor (
    "updateEObjXContractRoleExt(com.dwl.tcrm.financial.entityObject.EObjContractRole, com.ibm.daimler.dsea.entityObject.EObjXContractRoleExt)",
    "update CONTRACTROLE set CONTR_COMPONENT_ID =  ? , DISTRIB_PCT =  ? , END_DT =  ? , IRREVOC_IND =  ? , CONT_ID =  ? , START_DT =  ? , REGISTERED_NAME =  ? , RECORDED_START_DT =  ? , ARRANGEMENT_DESC =  ? , RECORDED_END_DT =  ? , SHARE_DIST_TP_CD =  ? , END_REASON_TP_CD =  ? , ARRANGEMENT_TP_CD =  ? , CONTR_ROLE_TP_CD =  ? , XSOURCE_IDENT_TP_CD =  ? , LAST_UPDATE_DT =  ? , LAST_UPDATE_USER =  ? , LAST_UPDATE_TX_ID =  ?  where CONTRACT_ROLE_ID =  ?  and LAST_UPDATE_DT =  ? ",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.UPDATE,
    null,
    new UpdateEObjXContractRoleExtParameterHandler (),
    new int[][]{{Types.BIGINT, Types.DECIMAL, Types.TIMESTAMP, Types.CHAR, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP}, {19, 5, 0, 1, 19, 0, 255, 0, 255, 0, 19, 19, 19, 19, 19, 0, 0, 19, 19, 0}, {0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    3);

  /**
   * @generated
   */
  public static class UpdateEObjXContractRoleExtParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      EObjContractRole bean0 = (EObjContractRole) parameters[0];
      setLong (stmt, 1, Types.BIGINT, (Long)bean0.getContrComponentId());
      setBigDecimal (stmt, 2, Types.DECIMAL, (java.math.BigDecimal)bean0.getDistribPct());
      setTimestamp (stmt, 3, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getEndDt());
      setString (stmt, 4, Types.CHAR, (String)bean0.getIrrevocInd());
      setLong (stmt, 5, Types.BIGINT, (Long)bean0.getContId());
      setTimestamp (stmt, 6, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getStartDt());
      setString (stmt, 7, Types.VARCHAR, (String)bean0.getRegisteredName());
      setTimestamp (stmt, 8, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getRecordedStartDt());
      setString (stmt, 9, Types.VARCHAR, (String)bean0.getArrangementDesc());
      setTimestamp (stmt, 10, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getRecordedEndDt());
      setLong (stmt, 11, Types.BIGINT, (Long)bean0.getShareDistTpCd());
      setLong (stmt, 12, Types.BIGINT, (Long)bean0.getEndReasonTpCd());
      setLong (stmt, 13, Types.BIGINT, (Long)bean0.getArrangementTpCd());
      setLong (stmt, 14, Types.BIGINT, (Long)bean0.getContractRoleTpCd());
      EObjXContractRoleExt bean1 = (EObjXContractRoleExt) parameters[1];
      setLong (stmt, 15, Types.BIGINT, (Long)bean1.getXSourceIdentifier());
      setTimestamp (stmt, 16, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUpdateDt());
      setString (stmt, 17, Types.VARCHAR, (String)bean0.getLastUpdateUser());
      setLong (stmt, 18, Types.BIGINT, (Long)bean0.getLastUpdateTxId());
      setLong (stmt, 19, Types.BIGINT, (Long)bean0.getContractRoleIdPK());
      setTimestamp (stmt, 20, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getOldLastUpdateDt());
    }
  }

  /**
   * @Update( sql="delete from CONTRACTROLE where CONTRACT_ROLE_ID = ?" )
   * 
   * @generated
   */
  public int deleteEObjXContractRoleExt (Long contractRoleIdPK)
  {
    return update (deleteEObjXContractRoleExtStatementDescriptor, contractRoleIdPK);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor deleteEObjXContractRoleExtStatementDescriptor = createStatementDescriptor (
    "deleteEObjXContractRoleExt(Long)",
    "delete from CONTRACTROLE where CONTRACT_ROLE_ID = ?",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.DELETE,
    null,
    new DeleteEObjXContractRoleExtParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    4);

  /**
   * @generated
   */
  public static class DeleteEObjXContractRoleExtParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setLong (stmt, 1, Types.BIGINT, (Long)parameters[0]);
    }
  }

}
