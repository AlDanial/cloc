/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[6dacd9fca9fb68fffbb757c1e3970d1f]
 */


package com.ibm.daimler.dsea.entityObject;

import java.util.Iterator;
import com.ibm.mdm.base.db.EntityMapping;
import com.ibm.pdq.annotation.Select;
import com.ibm.pdq.annotation.Update;

import com.ibm.daimler.dsea.entityObject.EObjXContractRel;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * @generated
 */
public interface EObjXContractRelData {


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjXContractRelSql = "select XContract_Relpk_Id, Contract_Id, Cont_Id, Market, Person_Org_Code, Contract_Role, Start_Date, End_Date, X_BPID, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from XCONTRACTREL where XContract_Relpk_Id = ? ";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String createEObjXContractRelSql = "insert into XCONTRACTREL (XContract_Relpk_Id, Contract_Id, Cont_Id, Market, Person_Org_Code, Contract_Role, Start_Date, End_Date, X_BPID, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( :xContractRelpkId, :contractId, :contId, :market, :personOrgCode, :contractRole, :startDate, :endDate, :x_BPID, :lastUpdateDt, :lastUpdateUser, :lastUpdateTxId)";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String updateEObjXContractRelSql = "update XCONTRACTREL set Contract_Id = :contractId, Cont_Id = :contId, Market = :market, Person_Org_Code = :personOrgCode, Contract_Role = :contractRole, Start_Date = :startDate, End_Date = :endDate, X_BPID = :x_BPID, LAST_UPDATE_DT = :lastUpdateDt, LAST_UPDATE_USER = :lastUpdateUser, LAST_UPDATE_TX_ID = :lastUpdateTxId where XContract_Relpk_Id = :xContractRelpkId and LAST_UPDATE_DT = :oldLastUpdateDt";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String deleteEObjXContractRelSql = "delete from XCONTRACTREL where XContract_Relpk_Id = ?";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXContractRelKeyField = "EObjXContractRel.xContractRelpkId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXContractRelGetFields =
    "EObjXContractRel.xContractRelpkId," +
    "EObjXContractRel.contractId," +
    "EObjXContractRel.contId," +
    "EObjXContractRel.market," +
    "EObjXContractRel.personOrgCode," +
    "EObjXContractRel.contractRole," +
    "EObjXContractRel.startDate," +
    "EObjXContractRel.endDate," +
    "EObjXContractRel.x_BPID," +
    "EObjXContractRel.lastUpdateDt," +
    "EObjXContractRel.lastUpdateUser," +
    "EObjXContractRel.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXContractRelAllFields =
    "com.ibm.daimler.dsea.entityObject.EObjXContractRel.xContractRelpkId," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractRel.contractId," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractRel.contId," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractRel.market," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractRel.personOrgCode," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractRel.contractRole," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractRel.startDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractRel.endDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractRel.x_BPID," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractRel.lastUpdateDt," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractRel.lastUpdateUser," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractRel.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXContractRelUpdateFields =
    "com.ibm.daimler.dsea.entityObject.EObjXContractRel.contractId," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractRel.contId," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractRel.market," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractRel.personOrgCode," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractRel.contractRole," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractRel.startDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractRel.endDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractRel.x_BPID," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractRel.lastUpdateDt," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractRel.lastUpdateUser," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractRel.lastUpdateTxId," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractRel.xContractRelpkId," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractRel.oldLastUpdateDt";   

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Select XContractRel by parameters.
   * @generated
   */
  @Select(sql=getEObjXContractRelSql)
  @EntityMapping(parameters=EObjXContractRelKeyField, results=EObjXContractRelGetFields)
  Iterator<EObjXContractRel> getEObjXContractRel(Long xContractRelpkId);  
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Create XContractRel by EObjXContractRel Object.
   * @generated
   */
  @Update(sql=createEObjXContractRelSql)
  @EntityMapping(parameters=EObjXContractRelAllFields)
    int createEObjXContractRel(EObjXContractRel e); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Update one XContractRel by EObjXContractRel object.
   * @generated
   */
  @Update(sql=updateEObjXContractRelSql)
  @EntityMapping(parameters=EObjXContractRelUpdateFields)
    int updateEObjXContractRel(EObjXContractRel e); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Delete XContractRel by parameters.
   * @generated
   */
  @Update(sql=deleteEObjXContractRelSql)
  @EntityMapping(parameters=EObjXContractRelKeyField)
  int deleteEObjXContractRel(Long xContractRelpkId);

}

