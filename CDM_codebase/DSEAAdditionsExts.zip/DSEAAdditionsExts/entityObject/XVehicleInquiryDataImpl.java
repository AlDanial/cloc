package com.ibm.daimler.dsea.entityObject;

import com.ibm.pdq.runtime.generator.BaseParameterHandler;
import com.ibm.daimler.dsea.entityObject.EObjXVehicle;
import java.util.Iterator;
import com.ibm.mdm.base.db.ResultQueue1;
import java.sql.PreparedStatement;
import com.ibm.pdq.runtime.statement.StatementDescriptor;
import com.ibm.pdq.runtime.generator.BaseData;
import java.sql.SQLException;
import com.ibm.pdq.annotation.Metadata;
import com.ibm.pdq.runtime.generator.BaseRowHandler;
import com.ibm.pdq.runtime.statement.SqlStatementType;
import java.sql.Types;


@SuppressWarnings("unchecked")

/**
 * <!-- begin-user-doc -->
 * 
 * <!-- end-user-doc -->
 * 
 * @generated
 */
public class XVehicleInquiryDataImpl  extends BaseData implements XVehicleInquiryData
{

  /**
   * @generated
   */
  public static final String generatorVersion = "3.200.75";

  /**
   * @generated
   */
  public static final String identifier = "XVehicleInquiryData";

  /**
   * @generated
   */
  public static final long generationTime = 0x000001685145f134L;

  /**
   * @generated
   */
  public static final String collection = "NULLID";

  /**
   * @generated
   */
  public static final String packageVersion = null;

  /**
   * @generated
   */
  public static final boolean forceSingleBindIsolation = false;

  /**
   * @generated
   */
  public XVehicleInquiryDataImpl()
  {
    super();
  } 

  /**
   * @generated
   */
  public String getGeneratorVersion()
  {
    return generatorVersion;
  }

  /**
   * @Select( sql="SELECT r.VEHICLEPK_ID VEHICLEPK_ID, r.DIVISION DIVISION, r.BUSINESS_UNIT BUSINESS_UNIT, r.ACTIVITY ACTIVITY, r.TYPE_CLASS TYPE_CLASS, r.BAU_RELHE BAU_RELHE, r.BAU_MUSTER BAU_MUSTER, r.SUB_MUSTER SUB_MUSTER, r.ENGINE_NUM ENGINE_NUM, r.COUNTRY_TP_CD COUNTRY_TP_CD, r.COLOR COLOR, r.TRIM TRIM, r.GLOBAL_VIN GLOBAL_VIN, r.LOCAL_VIN LOCAL_VIN, r.LICENSE_PLATE LICENSE_PLATE, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.CREATE_DT CREATE_DT, r.CHANGED_DT CHANGED_DT, r.LAST_SERVICE_DT LAST_SERVICE_DT, r.Market_Name Market_Name, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XVEHICLE r WHERE r.VEHICLEPK_ID = ? ", pattern="tableAlias (XVEHICLE => com.ibm.daimler.dsea.entityObject.EObjXVehicle, H_XVEHICLE => com.ibm.daimler.dsea.entityObject.EObjXVehicle)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue1<EObjXVehicle>> getXVehicle (Object[] parameters)
  {
    return queryIterator (getXVehicleStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getXVehicleStatementDescriptor = createStatementDescriptor (
    "getXVehicle(Object[])",
    "SELECT r.VEHICLEPK_ID VEHICLEPK_ID, r.DIVISION DIVISION, r.BUSINESS_UNIT BUSINESS_UNIT, r.ACTIVITY ACTIVITY, r.TYPE_CLASS TYPE_CLASS, r.BAU_RELHE BAU_RELHE, r.BAU_MUSTER BAU_MUSTER, r.SUB_MUSTER SUB_MUSTER, r.ENGINE_NUM ENGINE_NUM, r.COUNTRY_TP_CD COUNTRY_TP_CD, r.COLOR COLOR, r.TRIM TRIM, r.GLOBAL_VIN GLOBAL_VIN, r.LOCAL_VIN LOCAL_VIN, r.LICENSE_PLATE LICENSE_PLATE, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.CREATE_DT CREATE_DT, r.CHANGED_DT CHANGED_DT, r.LAST_SERVICE_DT LAST_SERVICE_DT, r.Market_Name Market_Name, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XVEHICLE r WHERE r.VEHICLEPK_ID = ? ",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"vehiclepk_id", "division", "business_unit", "activity", "type_class", "bau_relhe", "bau_muster", "sub_muster", "engine_num", "country_tp_cd", "color", "trim", "global_vin", "local_vin", "license_plate", "source_ident_tp_cd", "modify_sys_dt", "create_dt", "changed_dt", "last_service_dt", "market_name", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetXVehicleParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetXVehicleRowHandler (),
    new int[][]{ {Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 20, 20, 20, 20, 20, 20, 10, 20, 19, 50, 50, 20, 20, 20, 19, 0, 0, 0, 0, 250, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    1);

  /**
   * @generated
   */
  public static class GetXVehicleParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetXVehicleRowHandler extends BaseRowHandler<ResultQueue1<EObjXVehicle>>
  {
    /**
     * @generated
     */
    public ResultQueue1<EObjXVehicle> handle (java.sql.ResultSet rs, ResultQueue1<EObjXVehicle> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue1<EObjXVehicle> ();

      EObjXVehicle returnObject1 = new EObjXVehicle ();
      returnObject1.setVehiclepkId(getLongObject (rs, 1)); 
      returnObject1.setDivision(getString (rs, 2)); 
      returnObject1.setBusinessUnit(getString (rs, 3)); 
      returnObject1.setActivity(getString (rs, 4)); 
      returnObject1.setTypeClass(getString (rs, 5)); 
      returnObject1.setBauRelhe(getString (rs, 6)); 
      returnObject1.setBauMuster(getString (rs, 7)); 
      returnObject1.setSubMuster(getString (rs, 8)); 
      returnObject1.setEngineNumber(getString (rs, 9)); 
      returnObject1.setCountry(getLongObject (rs, 10)); 
      returnObject1.setColor(getString (rs, 11)); 
      returnObject1.setTrim(getString (rs, 12)); 
      returnObject1.setGlobalVIN(getString (rs, 13)); 
      returnObject1.setLocalVIN(getString (rs, 14)); 
      returnObject1.setLicensePlate(getString (rs, 15)); 
      returnObject1.setSourceIdentifier(getLongObject (rs, 16)); 
      returnObject1.setLastModifiedSystemDate(getTimestamp (rs, 17)); 
      returnObject1.setCreateDate(getTimestamp (rs, 18)); 
      returnObject1.setChangedDate(getTimestamp (rs, 19)); 
      returnObject1.setLastServiceDate(getTimestamp (rs, 20)); 
      returnObject1.setMarketName(getString (rs, 21)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 22)); 
      returnObject1.setLastUpdateUser(getString (rs, 23)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 24)); 
      returnObject.add (returnObject1);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT r.H_VEHICLEPK_ID hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.VEHICLEPK_ID VEHICLEPK_ID, r.DIVISION DIVISION, r.BUSINESS_UNIT BUSINESS_UNIT, r.ACTIVITY ACTIVITY, r.TYPE_CLASS TYPE_CLASS, r.BAU_RELHE BAU_RELHE, r.BAU_MUSTER BAU_MUSTER, r.SUB_MUSTER SUB_MUSTER, r.ENGINE_NUM ENGINE_NUM, r.COUNTRY_TP_CD COUNTRY_TP_CD, r.COLOR COLOR, r.TRIM TRIM, r.GLOBAL_VIN GLOBAL_VIN, r.LOCAL_VIN LOCAL_VIN, r.LICENSE_PLATE LICENSE_PLATE, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.CREATE_DT CREATE_DT, r.CHANGED_DT CHANGED_DT, r.LAST_SERVICE_DT LAST_SERVICE_DT, r.Market_Name Market_Name, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XVEHICLE r WHERE r.H_VEHICLEPK_ID = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))", pattern="tableAlias (XVEHICLE => com.ibm.daimler.dsea.entityObject.EObjXVehicle, H_XVEHICLE => com.ibm.daimler.dsea.entityObject.EObjXVehicle)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue1<EObjXVehicle>> getXVehicleHistory (Object[] parameters)
  {
    return queryIterator (getXVehicleHistoryStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getXVehicleHistoryStatementDescriptor = createStatementDescriptor (
    "getXVehicleHistory(Object[])",
    "SELECT r.H_VEHICLEPK_ID hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.VEHICLEPK_ID VEHICLEPK_ID, r.DIVISION DIVISION, r.BUSINESS_UNIT BUSINESS_UNIT, r.ACTIVITY ACTIVITY, r.TYPE_CLASS TYPE_CLASS, r.BAU_RELHE BAU_RELHE, r.BAU_MUSTER BAU_MUSTER, r.SUB_MUSTER SUB_MUSTER, r.ENGINE_NUM ENGINE_NUM, r.COUNTRY_TP_CD COUNTRY_TP_CD, r.COLOR COLOR, r.TRIM TRIM, r.GLOBAL_VIN GLOBAL_VIN, r.LOCAL_VIN LOCAL_VIN, r.LICENSE_PLATE LICENSE_PLATE, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.CREATE_DT CREATE_DT, r.CHANGED_DT CHANGED_DT, r.LAST_SERVICE_DT LAST_SERVICE_DT, r.Market_Name Market_Name, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XVEHICLE r WHERE r.H_VEHICLEPK_ID = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"historyidpk", "h_action_code", "h_created_by", "h_create_dt", "h_end_dt", "vehiclepk_id", "division", "business_unit", "activity", "type_class", "bau_relhe", "bau_muster", "sub_muster", "engine_num", "country_tp_cd", "color", "trim", "global_vin", "local_vin", "license_plate", "source_ident_tp_cd", "modify_sys_dt", "create_dt", "changed_dt", "last_service_dt", "market_name", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetXVehicleHistoryParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP}, {19, 0, 0}, {0, 0, 0}, {1, 1, 1}},
    null,
    new GetXVehicleHistoryRowHandler (),
    new int[][]{ {Types.BIGINT, Types.CHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 1, 20, 0, 0, 19, 20, 20, 20, 20, 20, 20, 10, 20, 19, 50, 50, 20, 20, 20, 19, 0, 0, 0, 0, 250, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    2);

  /**
   * @generated
   */
  public static class GetXVehicleHistoryParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetXVehicleHistoryRowHandler extends BaseRowHandler<ResultQueue1<EObjXVehicle>>
  {
    /**
     * @generated
     */
    public ResultQueue1<EObjXVehicle> handle (java.sql.ResultSet rs, ResultQueue1<EObjXVehicle> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue1<EObjXVehicle> ();

      EObjXVehicle returnObject1 = new EObjXVehicle ();
      returnObject1.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject1.setHistActionCode(getString (rs, 2)); 
      returnObject1.setHistCreatedBy(getString (rs, 3)); 
      returnObject1.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject1.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject1.setVehiclepkId(getLongObject (rs, 6)); 
      returnObject1.setDivision(getString (rs, 7)); 
      returnObject1.setBusinessUnit(getString (rs, 8)); 
      returnObject1.setActivity(getString (rs, 9)); 
      returnObject1.setTypeClass(getString (rs, 10)); 
      returnObject1.setBauRelhe(getString (rs, 11)); 
      returnObject1.setBauMuster(getString (rs, 12)); 
      returnObject1.setSubMuster(getString (rs, 13)); 
      returnObject1.setEngineNumber(getString (rs, 14)); 
      returnObject1.setCountry(getLongObject (rs, 15)); 
      returnObject1.setColor(getString (rs, 16)); 
      returnObject1.setTrim(getString (rs, 17)); 
      returnObject1.setGlobalVIN(getString (rs, 18)); 
      returnObject1.setLocalVIN(getString (rs, 19)); 
      returnObject1.setLicensePlate(getString (rs, 20)); 
      returnObject1.setSourceIdentifier(getLongObject (rs, 21)); 
      returnObject1.setLastModifiedSystemDate(getTimestamp (rs, 22)); 
      returnObject1.setCreateDate(getTimestamp (rs, 23)); 
      returnObject1.setChangedDate(getTimestamp (rs, 24)); 
      returnObject1.setLastServiceDate(getTimestamp (rs, 25)); 
      returnObject1.setMarketName(getString (rs, 26)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 27)); 
      returnObject1.setLastUpdateUser(getString (rs, 28)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 29)); 
      returnObject.add (returnObject1);

    
      return returnObject;
    }
  }

}
