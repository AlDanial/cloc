/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[b59224bba6b06927e2cd97d5308f2a77]
 */


package com.ibm.daimler.dsea.entityObject;

import java.util.Iterator;
import com.ibm.mdm.base.db.EntityMapping;
import com.ibm.pdq.annotation.Select;
import com.ibm.pdq.annotation.Update;

import com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup;

import com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * @generated
 */
public interface EObjXContactMethodGroupExtData {


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjXContactMethodGroupExtSql = "select XVERIFIED_TP_CD, XRETAILER_ID, XMODIFY_SYS_DT, XCONTACT_RETAILER_FLAG, X_BPID, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from CONTACTMETHODGROUP where LOCATION_GROUP_ID = ? ";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String createEObjXContactMethodGroupExtSql = "insert into CONTACTMETHODGROUP (TEXT_ONLY_IND, ATTACH_ALLOW_IND, COMMENT_DESC, CONTACT_METHOD_ID, MESSAGE_SIZE, LOCATION_GROUP_ID, CONT_METH_TP_CD, METHOD_ST_TP_CD, XVERIFIED_TP_CD, XRETAILER_ID, XMODIFY_SYS_DT, XCONTACT_RETAILER_FLAG, X_BPID, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( ?1.textOnlyInd, ?1.attachAllowInd, ?1.commentDesc, ?1.contactMethodId, ?1.messageSize, ?1.locationGroupIdPK, ?1.contMethTpCd, ?1.methodStTpCd, ?2.xVerified, ?2.xRetailerId, ?2.xLastModifiedSystemDate, ?2.xContactRetailerFlag, ?2.x_BPID, ?1.lastUpdateDt, ?1.lastUpdateUser, ?1.lastUpdateTxId)";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String updateEObjXContactMethodGroupExtSql = "update CONTACTMETHODGROUP set TEXT_ONLY_IND = ?1.textOnlyInd, ATTACH_ALLOW_IND = ?1.attachAllowInd, COMMENT_DESC = ?1.commentDesc, CONTACT_METHOD_ID = ?1.contactMethodId, MESSAGE_SIZE = ?1.messageSize, CONT_METH_TP_CD = ?1.contMethTpCd, METHOD_ST_TP_CD = ?1.methodStTpCd, XVERIFIED_TP_CD = ?2.xVerified, XRETAILER_ID = ?2.xRetailerId, XMODIFY_SYS_DT = ?2.xLastModifiedSystemDate, XCONTACT_RETAILER_FLAG = ?2.xContactRetailerFlag, X_BPID = ?2.x_BPID, LAST_UPDATE_DT = ?1.lastUpdateDt, LAST_UPDATE_USER = ?1.lastUpdateUser, LAST_UPDATE_TX_ID = ?1.lastUpdateTxId where LOCATION_GROUP_ID = ?1.locationGroupIdPK and LAST_UPDATE_DT = ?1.oldLastUpdateDt";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String deleteEObjXContactMethodGroupExtSql = "delete from CONTACTMETHODGROUP where LOCATION_GROUP_ID = ?";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXContactMethodGroupExtKeyField = "EObjXContactMethodGroupExt.locationGroupIdPK";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXContactMethodGroupExtGetFields =
    "EObjXContactMethodGroupExt.xVerified," +
    "EObjXContactMethodGroupExt.xRetailerId," +
    "EObjXContactMethodGroupExt.xLastModifiedSystemDate," +
    "EObjXContactMethodGroupExt.xContactRetailerFlag," +
    "EObjXContactMethodGroupExt.x_BPID," +
    "EObjXContactMethodGroupExt.lastUpdateDt," +
    "EObjXContactMethodGroupExt.lastUpdateUser," +
    "EObjXContactMethodGroupExt.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXContactMethodGroupExtAllFields =
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.textOnlyInd," +
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.attachAllowInd," +
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.commentDesc," +
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.contactMethodId," +
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.messageSize," +
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.locationGroupIdPK," +
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.contMethTpCd," +
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.methodStTpCd," +
    "com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt.xVerified," +
    "com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt.xRetailerId," +
    "com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt.xLastModifiedSystemDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt.xContactRetailerFlag," +
    "com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt.x_BPID," +
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.lastUpdateDt," +
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.lastUpdateUser," +
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXContactMethodGroupExtUpdateFields =
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.textOnlyInd," +
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.attachAllowInd," +
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.commentDesc," +
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.contactMethodId," +
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.messageSize," +
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.contMethTpCd," +
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.methodStTpCd," +
    "com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt.xVerified," +
    "com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt.xRetailerId," +
    "com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt.xLastModifiedSystemDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt.xContactRetailerFlag," +
    "com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt.x_BPID," +
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.lastUpdateDt," +
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.lastUpdateUser," +
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.lastUpdateTxId," +
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.locationGroupIdPK," +
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup.oldLastUpdateDt";   

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Select XContactMethodGroup by parameters.
   * @generated
   */
  @Select(sql=getEObjXContactMethodGroupExtSql)
  @EntityMapping(parameters=EObjXContactMethodGroupExtKeyField, results=EObjXContactMethodGroupExtGetFields)
  Iterator<EObjXContactMethodGroupExt> getEObjXContactMethodGroupExt(Long locationGroupIdPK);  
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Create XContactMethodGroup by EObjXContactMethodGroupExt Object.
   * @generated
   */
  @Update(sql=createEObjXContactMethodGroupExtSql)
  @EntityMapping(parameters=EObjXContactMethodGroupExtAllFields)
    int createEObjXContactMethodGroupExt(EObjContactMethodGroup e1, EObjXContactMethodGroupExt e2); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Update one XContactMethodGroup by EObjXContactMethodGroupExt object.
   * @generated
   */
  @Update(sql=updateEObjXContactMethodGroupExtSql)
  @EntityMapping(parameters=EObjXContactMethodGroupExtUpdateFields)
    int updateEObjXContactMethodGroupExt(EObjContactMethodGroup e1, EObjXContactMethodGroupExt e2); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Delete XContactMethodGroup by parameters.
   * @generated
   */
  @Update(sql=deleteEObjXContactMethodGroupExtSql)
  @EntityMapping(parameters=EObjXContactMethodGroupExtKeyField)
  int deleteEObjXContactMethodGroupExt(Long locationGroupIdPK);

}

