/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[6580633a7b7aa4cae5d95bdc7f43ef09]
 */

package com.ibm.daimler.dsea.entityObject;


import com.ibm.mdm.base.db.ResultQueue1;
import java.util.Iterator;
import com.ibm.mdm.base.db.EntityMapping;
import com.ibm.pdq.annotation.Select;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * @generated
 */
public interface XRetailerInquiryData {
  
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String tableAliasString = "tableAlias (" + 
                                            "XRETAILER => com.ibm.daimler.dsea.entityObject.EObjXRetailer, " +
                                            "H_XRETAILER => com.ibm.daimler.dsea.entityObject.EObjXRetailer" +
                                            ")";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getXRetailerSql = "SELECT r.RETAILERPK_ID RETAILERPK_ID, r.RETAILER_CODE RETAILER_CODE, r.RETAILER_NAME RETAILER_NAME, r.BRANCH_NAME BRANCH_NAME, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.GS_CODE GS_CODE, r.GC_CODE GC_CODE, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.ND_CODE ND_CODE, r.MARKET_NAME MARKET_NAME, r.DEALER_ACTIVE_FLAG DEALER_ACTIVE_FLAG, r.DEALER_GROUP DEALER_GROUP, r.DEALER_ROLLOUT_FLAG DEALER_ROLLOUT_FLAG, r.BATCH_IND BATCH_IND, r.CREATE_DT CREATE_DT, r.CHANGED_DT CHANGED_DT, r.CRM_COMPANY_CODE CRM_COMPANY_CODE, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XRETAILER r WHERE r.RETAILERPK_ID = ? ";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXRetailerParameters =
    "EObjXRetailer.RetailerpkId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXRetailerResults =
    "EObjXRetailer.RetailerpkId," +
    "EObjXRetailer.RetailerCode," +
    "EObjXRetailer.RetailerName," +
    "EObjXRetailer.BranchName," +
    "EObjXRetailer.SourceIdentifier," +
    "EObjXRetailer.GSCode," +
    "EObjXRetailer.GCCode," +
    "EObjXRetailer.LastModifiedSystemDate," +
    "EObjXRetailer.NDCode," +
    "EObjXRetailer.MarketName," +
    "EObjXRetailer.DealerActiveFlag," +
    "EObjXRetailer.DealerGroup," +
    "EObjXRetailer.DealerRolloutFlag," +
    "EObjXRetailer.BatchInd," +
    "EObjXRetailer.CreateDate," +
    "EObjXRetailer.ChangedDate," +
    "EObjXRetailer.CRMCompanyCode," +
    "EObjXRetailer.lastUpdateDt," +
    "EObjXRetailer.lastUpdateUser," +
    "EObjXRetailer.lastUpdateTxId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getXRetailerHistorySql = "SELECT r.H_RETAILERPK_ID hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.RETAILERPK_ID RETAILERPK_ID, r.RETAILER_CODE RETAILER_CODE, r.RETAILER_NAME RETAILER_NAME, r.BRANCH_NAME BRANCH_NAME, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.GS_CODE GS_CODE, r.GC_CODE GC_CODE, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.ND_CODE ND_CODE, r.MARKET_NAME MARKET_NAME, r.DEALER_ACTIVE_FLAG DEALER_ACTIVE_FLAG, r.DEALER_GROUP DEALER_GROUP, r.DEALER_ROLLOUT_FLAG DEALER_ROLLOUT_FLAG, r.BATCH_IND BATCH_IND, r.CREATE_DT CREATE_DT, r.CHANGED_DT CHANGED_DT, r.CRM_COMPANY_CODE CRM_COMPANY_CODE, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XRETAILER r WHERE r.H_RETAILERPK_ID = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXRetailerHistoryParameters =
    "EObjXRetailer.RetailerpkId," +
    "EObjXRetailer.lastUpdateDt," +
    "EObjXRetailer.lastUpdateDt";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXRetailerHistoryResults =
    "EObjXRetailer.historyIdPK," +
    "EObjXRetailer.histActionCode," +
    "EObjXRetailer.histCreatedBy," +
    "EObjXRetailer.histCreateDt," +
    "EObjXRetailer.histEndDt," +
    "EObjXRetailer.RetailerpkId," +
    "EObjXRetailer.RetailerCode," +
    "EObjXRetailer.RetailerName," +
    "EObjXRetailer.BranchName," +
    "EObjXRetailer.SourceIdentifier," +
    "EObjXRetailer.GSCode," +
    "EObjXRetailer.GCCode," +
    "EObjXRetailer.LastModifiedSystemDate," +
    "EObjXRetailer.NDCode," +
    "EObjXRetailer.MarketName," +
    "EObjXRetailer.DealerActiveFlag," +
    "EObjXRetailer.DealerGroup," +
    "EObjXRetailer.DealerRolloutFlag," +
    "EObjXRetailer.BatchInd," +
    "EObjXRetailer.CreateDate," +
    "EObjXRetailer.ChangedDate," +
    "EObjXRetailer.CRMCompanyCode," +
    "EObjXRetailer.lastUpdateDt," +
    "EObjXRetailer.lastUpdateUser," +
    "EObjXRetailer.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getXRetailerByRetailerCodeSql = "SELECT r.RETAILERPK_ID RETAILERPK_ID, r.RETAILER_CODE RETAILER_CODE, r.RETAILER_NAME RETAILER_NAME, r.BRANCH_NAME BRANCH_NAME, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.GS_CODE GS_CODE, r.GC_CODE GC_CODE, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.ND_CODE ND_CODE, r.MARKET_NAME MARKET_NAME, r.DEALER_ACTIVE_FLAG DEALER_ACTIVE_FLAG, r.DEALER_GROUP DEALER_GROUP, r.DEALER_ROLLOUT_FLAG DEALER_ROLLOUT_FLAG, r.BATCH_IND BATCH_IND, r.CREATE_DT CREATE_DT, r.CHANGED_DT CHANGED_DT, r.CRM_COMPANY_CODE CRM_COMPANY_CODE, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XRETAILER r WHERE r.RETAILER_CODE = ? ";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXRetailerByRetailerCodeParameters =
    "EObjXRetailer.RetailerCode";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXRetailerByRetailerCodeResults =
    "EObjXRetailer.RetailerpkId," +
    "EObjXRetailer.RetailerCode," +
    "EObjXRetailer.RetailerName," +
    "EObjXRetailer.BranchName," +
    "EObjXRetailer.SourceIdentifier," +
    "EObjXRetailer.GSCode," +
    "EObjXRetailer.GCCode," +
    "EObjXRetailer.LastModifiedSystemDate," +
    "EObjXRetailer.NDCode," +
    "EObjXRetailer.MarketName," +
    "EObjXRetailer.DealerActiveFlag," +
    "EObjXRetailer.DealerGroup," +
    "EObjXRetailer.DealerRolloutFlag," +
    "EObjXRetailer.BatchInd," +
    "EObjXRetailer.CreateDate," +
    "EObjXRetailer.ChangedDate," +
    "EObjXRetailer.CRMCompanyCode," +
    "EObjXRetailer.lastUpdateDt," +
    "EObjXRetailer.lastUpdateUser," +
    "EObjXRetailer.lastUpdateTxId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getXRetailerByRetailerCodeHistorySql = "SELECT r.H_RETAILERPK_ID hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.RETAILERPK_ID RETAILERPK_ID, r.RETAILER_CODE RETAILER_CODE, r.RETAILER_NAME RETAILER_NAME, r.BRANCH_NAME BRANCH_NAME, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.GS_CODE GS_CODE, r.GC_CODE GC_CODE, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.ND_CODE ND_CODE, r.MARKET_NAME MARKET_NAME, r.DEALER_ACTIVE_FLAG DEALER_ACTIVE_FLAG, r.DEALER_GROUP DEALER_GROUP, r.DEALER_ROLLOUT_FLAG DEALER_ROLLOUT_FLAG, r.BATCH_IND BATCH_IND, r.CREATE_DT CREATE_DT, r.CHANGED_DT CHANGED_DT, r.CRM_COMPANY_CODE CRM_COMPANY_CODE, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XRETAILER r WHERE r.RETAILER_CODE = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXRetailerByRetailerCodeHistoryParameters =
    "EObjXRetailer.RetailerCode," +
    "EObjXRetailer.lastUpdateDt," +
    "EObjXRetailer.lastUpdateDt";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXRetailerByRetailerCodeHistoryResults =
    "EObjXRetailer.historyIdPK," +
    "EObjXRetailer.histActionCode," +
    "EObjXRetailer.histCreatedBy," +
    "EObjXRetailer.histCreateDt," +
    "EObjXRetailer.histEndDt," +
    "EObjXRetailer.RetailerpkId," +
    "EObjXRetailer.RetailerCode," +
    "EObjXRetailer.RetailerName," +
    "EObjXRetailer.BranchName," +
    "EObjXRetailer.SourceIdentifier," +
    "EObjXRetailer.GSCode," +
    "EObjXRetailer.GCCode," +
    "EObjXRetailer.LastModifiedSystemDate," +
    "EObjXRetailer.NDCode," +
    "EObjXRetailer.MarketName," +
    "EObjXRetailer.DealerActiveFlag," +
    "EObjXRetailer.DealerGroup," +
    "EObjXRetailer.DealerRolloutFlag," +
    "EObjXRetailer.BatchInd," +
    "EObjXRetailer.CreateDate," +
    "EObjXRetailer.ChangedDate," +
    "EObjXRetailer.CRMCompanyCode," +
    "EObjXRetailer.lastUpdateDt," +
    "EObjXRetailer.lastUpdateUser," +
    "EObjXRetailer.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getXRetailerByNDCodeSql = "SELECT r.RETAILERPK_ID RETAILERPK_ID, r.RETAILER_CODE RETAILER_CODE, r.RETAILER_NAME RETAILER_NAME, r.BRANCH_NAME BRANCH_NAME, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.GS_CODE GS_CODE, r.GC_CODE GC_CODE, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.ND_CODE ND_CODE, r.MARKET_NAME MARKET_NAME, r.DEALER_ACTIVE_FLAG DEALER_ACTIVE_FLAG, r.DEALER_GROUP DEALER_GROUP, r.DEALER_ROLLOUT_FLAG DEALER_ROLLOUT_FLAG, r.BATCH_IND BATCH_IND, r.CREATE_DT CREATE_DT, r.CHANGED_DT CHANGED_DT, r.CRM_COMPANY_CODE CRM_COMPANY_CODE, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XRETAILER r WHERE r.ND_CODE = ? ";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXRetailerByNDCodeParameters =
    "EObjXRetailer.NDCode";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXRetailerByNDCodeResults =
    "EObjXRetailer.RetailerpkId," +
    "EObjXRetailer.RetailerCode," +
    "EObjXRetailer.RetailerName," +
    "EObjXRetailer.BranchName," +
    "EObjXRetailer.SourceIdentifier," +
    "EObjXRetailer.GSCode," +
    "EObjXRetailer.GCCode," +
    "EObjXRetailer.LastModifiedSystemDate," +
    "EObjXRetailer.NDCode," +
    "EObjXRetailer.MarketName," +
    "EObjXRetailer.DealerActiveFlag," +
    "EObjXRetailer.DealerGroup," +
    "EObjXRetailer.DealerRolloutFlag," +
    "EObjXRetailer.BatchInd," +
    "EObjXRetailer.CreateDate," +
    "EObjXRetailer.ChangedDate," +
    "EObjXRetailer.CRMCompanyCode," +
    "EObjXRetailer.lastUpdateDt," +
    "EObjXRetailer.lastUpdateUser," +
    "EObjXRetailer.lastUpdateTxId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getXRetailerByNDCodeHistorySql = "SELECT r.H_RETAILERPK_ID hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.RETAILERPK_ID RETAILERPK_ID, r.RETAILER_CODE RETAILER_CODE, r.RETAILER_NAME RETAILER_NAME, r.BRANCH_NAME BRANCH_NAME, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.GS_CODE GS_CODE, r.GC_CODE GC_CODE, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.ND_CODE ND_CODE, r.MARKET_NAME MARKET_NAME, r.DEALER_ACTIVE_FLAG DEALER_ACTIVE_FLAG, r.DEALER_GROUP DEALER_GROUP, r.DEALER_ROLLOUT_FLAG DEALER_ROLLOUT_FLAG, r.BATCH_IND BATCH_IND, r.CREATE_DT CREATE_DT, r.CHANGED_DT CHANGED_DT, r.CRM_COMPANY_CODE CRM_COMPANY_CODE, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XRETAILER r WHERE r.ND_CODE = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXRetailerByNDCodeHistoryParameters =
    "EObjXRetailer.NDCode," +
    "EObjXRetailer.lastUpdateDt," +
    "EObjXRetailer.lastUpdateDt";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXRetailerByNDCodeHistoryResults =
    "EObjXRetailer.historyIdPK," +
    "EObjXRetailer.histActionCode," +
    "EObjXRetailer.histCreatedBy," +
    "EObjXRetailer.histCreateDt," +
    "EObjXRetailer.histEndDt," +
    "EObjXRetailer.RetailerpkId," +
    "EObjXRetailer.RetailerCode," +
    "EObjXRetailer.RetailerName," +
    "EObjXRetailer.BranchName," +
    "EObjXRetailer.SourceIdentifier," +
    "EObjXRetailer.GSCode," +
    "EObjXRetailer.GCCode," +
    "EObjXRetailer.LastModifiedSystemDate," +
    "EObjXRetailer.NDCode," +
    "EObjXRetailer.MarketName," +
    "EObjXRetailer.DealerActiveFlag," +
    "EObjXRetailer.DealerGroup," +
    "EObjXRetailer.DealerRolloutFlag," +
    "EObjXRetailer.BatchInd," +
    "EObjXRetailer.CreateDate," +
    "EObjXRetailer.ChangedDate," +
    "EObjXRetailer.CRMCompanyCode," +
    "EObjXRetailer.lastUpdateDt," +
    "EObjXRetailer.lastUpdateUser," +
    "EObjXRetailer.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getXRetailerByGSCodeSql = "SELECT r.RETAILERPK_ID RETAILERPK_ID, r.RETAILER_CODE RETAILER_CODE, r.RETAILER_NAME RETAILER_NAME, r.BRANCH_NAME BRANCH_NAME, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.GS_CODE GS_CODE, r.GC_CODE GC_CODE, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.ND_CODE ND_CODE, r.MARKET_NAME MARKET_NAME, r.DEALER_ACTIVE_FLAG DEALER_ACTIVE_FLAG, r.DEALER_GROUP DEALER_GROUP, r.DEALER_ROLLOUT_FLAG DEALER_ROLLOUT_FLAG, r.BATCH_IND BATCH_IND, r.CREATE_DT CREATE_DT, r.CHANGED_DT CHANGED_DT, r.CRM_COMPANY_CODE CRM_COMPANY_CODE, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XRETAILER r WHERE r.GS_CODE = ? ";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXRetailerByGSCodeParameters =
    "EObjXRetailer.GSCode";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXRetailerByGSCodeResults =
    "EObjXRetailer.RetailerpkId," +
    "EObjXRetailer.RetailerCode," +
    "EObjXRetailer.RetailerName," +
    "EObjXRetailer.BranchName," +
    "EObjXRetailer.SourceIdentifier," +
    "EObjXRetailer.GSCode," +
    "EObjXRetailer.GCCode," +
    "EObjXRetailer.LastModifiedSystemDate," +
    "EObjXRetailer.NDCode," +
    "EObjXRetailer.MarketName," +
    "EObjXRetailer.DealerActiveFlag," +
    "EObjXRetailer.DealerGroup," +
    "EObjXRetailer.DealerRolloutFlag," +
    "EObjXRetailer.BatchInd," +
    "EObjXRetailer.CreateDate," +
    "EObjXRetailer.ChangedDate," +
    "EObjXRetailer.CRMCompanyCode," +
    "EObjXRetailer.lastUpdateDt," +
    "EObjXRetailer.lastUpdateUser," +
    "EObjXRetailer.lastUpdateTxId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getXRetailerByGSCodeHistorySql = "SELECT r.H_RETAILERPK_ID hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.RETAILERPK_ID RETAILERPK_ID, r.RETAILER_CODE RETAILER_CODE, r.RETAILER_NAME RETAILER_NAME, r.BRANCH_NAME BRANCH_NAME, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.GS_CODE GS_CODE, r.GC_CODE GC_CODE, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.ND_CODE ND_CODE, r.MARKET_NAME MARKET_NAME, r.DEALER_ACTIVE_FLAG DEALER_ACTIVE_FLAG, r.DEALER_GROUP DEALER_GROUP, r.DEALER_ROLLOUT_FLAG DEALER_ROLLOUT_FLAG, r.BATCH_IND BATCH_IND, r.CREATE_DT CREATE_DT, r.CHANGED_DT CHANGED_DT, r.CRM_COMPANY_CODE CRM_COMPANY_CODE, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XRETAILER r WHERE r.GS_CODE = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXRetailerByGSCodeHistoryParameters =
    "EObjXRetailer.GSCode," +
    "EObjXRetailer.lastUpdateDt," +
    "EObjXRetailer.lastUpdateDt";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXRetailerByGSCodeHistoryResults =
    "EObjXRetailer.historyIdPK," +
    "EObjXRetailer.histActionCode," +
    "EObjXRetailer.histCreatedBy," +
    "EObjXRetailer.histCreateDt," +
    "EObjXRetailer.histEndDt," +
    "EObjXRetailer.RetailerpkId," +
    "EObjXRetailer.RetailerCode," +
    "EObjXRetailer.RetailerName," +
    "EObjXRetailer.BranchName," +
    "EObjXRetailer.SourceIdentifier," +
    "EObjXRetailer.GSCode," +
    "EObjXRetailer.GCCode," +
    "EObjXRetailer.LastModifiedSystemDate," +
    "EObjXRetailer.NDCode," +
    "EObjXRetailer.MarketName," +
    "EObjXRetailer.DealerActiveFlag," +
    "EObjXRetailer.DealerGroup," +
    "EObjXRetailer.DealerRolloutFlag," +
    "EObjXRetailer.BatchInd," +
    "EObjXRetailer.CreateDate," +
    "EObjXRetailer.ChangedDate," +
    "EObjXRetailer.CRMCompanyCode," +
    "EObjXRetailer.lastUpdateDt," +
    "EObjXRetailer.lastUpdateUser," +
    "EObjXRetailer.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getXRetailerByGSCodeAndMarketNameSql = "SELECT r.RETAILERPK_ID RETAILERPK_ID, r.RETAILER_CODE RETAILER_CODE, r.RETAILER_NAME RETAILER_NAME, r.BRANCH_NAME BRANCH_NAME, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.GS_CODE GS_CODE, r.GC_CODE GC_CODE, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.ND_CODE ND_CODE, r.MARKET_NAME MARKET_NAME, r.DEALER_ACTIVE_FLAG DEALER_ACTIVE_FLAG, r.DEALER_GROUP DEALER_GROUP, r.DEALER_ROLLOUT_FLAG DEALER_ROLLOUT_FLAG, r.BATCH_IND BATCH_IND, r.CREATE_DT CREATE_DT, r.CHANGED_DT CHANGED_DT, r.CRM_COMPANY_CODE CRM_COMPANY_CODE, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XRETAILER r WHERE r.GS_CODE = ?  AND r.MARKET_NAME = ? ";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXRetailerByGSCodeAndMarketNameParameters =
    "EObjXRetailer.GSCode," +
    "EObjXRetailer.MarketName";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXRetailerByGSCodeAndMarketNameResults =
    "EObjXRetailer.RetailerpkId," +
    "EObjXRetailer.RetailerCode," +
    "EObjXRetailer.RetailerName," +
    "EObjXRetailer.BranchName," +
    "EObjXRetailer.SourceIdentifier," +
    "EObjXRetailer.GSCode," +
    "EObjXRetailer.GCCode," +
    "EObjXRetailer.LastModifiedSystemDate," +
    "EObjXRetailer.NDCode," +
    "EObjXRetailer.MarketName," +
    "EObjXRetailer.DealerActiveFlag," +
    "EObjXRetailer.DealerGroup," +
    "EObjXRetailer.DealerRolloutFlag," +
    "EObjXRetailer.BatchInd," +
    "EObjXRetailer.CreateDate," +
    "EObjXRetailer.ChangedDate," +
    "EObjXRetailer.CRMCompanyCode," +
    "EObjXRetailer.lastUpdateDt," +
    "EObjXRetailer.lastUpdateUser," +
    "EObjXRetailer.lastUpdateTxId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getXRetailerByGSCodeAndMarketNameHistorySql = "SELECT r.H_RETAILERPK_ID hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.RETAILERPK_ID RETAILERPK_ID, r.RETAILER_CODE RETAILER_CODE, r.RETAILER_NAME RETAILER_NAME, r.BRANCH_NAME BRANCH_NAME, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.GS_CODE GS_CODE, r.GC_CODE GC_CODE, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.ND_CODE ND_CODE, r.MARKET_NAME MARKET_NAME, r.DEALER_ACTIVE_FLAG DEALER_ACTIVE_FLAG, r.DEALER_GROUP DEALER_GROUP, r.DEALER_ROLLOUT_FLAG DEALER_ROLLOUT_FLAG, r.BATCH_IND BATCH_IND, r.CREATE_DT CREATE_DT, r.CHANGED_DT CHANGED_DT, r.CRM_COMPANY_CODE CRM_COMPANY_CODE, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XRETAILER r WHERE r.GS_CODE = ?  AND r.MARKET_NAME = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXRetailerByGSCodeAndMarketNameHistoryParameters =
    "EObjXRetailer.GSCode," +
    "EObjXRetailer.MarketName," +
    "EObjXRetailer.lastUpdateDt," +
    "EObjXRetailer.lastUpdateDt";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXRetailerByGSCodeAndMarketNameHistoryResults =
    "EObjXRetailer.historyIdPK," +
    "EObjXRetailer.histActionCode," +
    "EObjXRetailer.histCreatedBy," +
    "EObjXRetailer.histCreateDt," +
    "EObjXRetailer.histEndDt," +
    "EObjXRetailer.RetailerpkId," +
    "EObjXRetailer.RetailerCode," +
    "EObjXRetailer.RetailerName," +
    "EObjXRetailer.BranchName," +
    "EObjXRetailer.SourceIdentifier," +
    "EObjXRetailer.GSCode," +
    "EObjXRetailer.GCCode," +
    "EObjXRetailer.LastModifiedSystemDate," +
    "EObjXRetailer.NDCode," +
    "EObjXRetailer.MarketName," +
    "EObjXRetailer.DealerActiveFlag," +
    "EObjXRetailer.DealerGroup," +
    "EObjXRetailer.DealerRolloutFlag," +
    "EObjXRetailer.BatchInd," +
    "EObjXRetailer.CreateDate," +
    "EObjXRetailer.ChangedDate," +
    "EObjXRetailer.CRMCompanyCode," +
    "EObjXRetailer.lastUpdateDt," +
    "EObjXRetailer.lastUpdateUser," +
    "EObjXRetailer.lastUpdateTxId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getXRetailerByRetailerCodeAndMarketNameSql = "SELECT r.RETAILERPK_ID RETAILERPK_ID, r.RETAILER_CODE RETAILER_CODE, r.RETAILER_NAME RETAILER_NAME, r.BRANCH_NAME BRANCH_NAME, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.GS_CODE GS_CODE, r.GC_CODE GC_CODE, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.ND_CODE ND_CODE, r.MARKET_NAME MARKET_NAME, r.DEALER_ACTIVE_FLAG DEALER_ACTIVE_FLAG, r.DEALER_GROUP DEALER_GROUP, r.DEALER_ROLLOUT_FLAG DEALER_ROLLOUT_FLAG, r.BATCH_IND BATCH_IND, r.CREATE_DT CREATE_DT, r.CHANGED_DT CHANGED_DT, r.CRM_COMPANY_CODE CRM_COMPANY_CODE, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XRETAILER r WHERE r.RETAILER_CODE = ?  AND r.MARKET_NAME = ? ";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXRetailerByRetailerCodeAndMarketNameParameters =
    "EObjXRetailer.RetailerCode," +
    "EObjXRetailer.MarketName";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXRetailerByRetailerCodeAndMarketNameResults =
    "EObjXRetailer.RetailerpkId," +
    "EObjXRetailer.RetailerCode," +
    "EObjXRetailer.RetailerName," +
    "EObjXRetailer.BranchName," +
    "EObjXRetailer.SourceIdentifier," +
    "EObjXRetailer.GSCode," +
    "EObjXRetailer.GCCode," +
    "EObjXRetailer.LastModifiedSystemDate," +
    "EObjXRetailer.NDCode," +
    "EObjXRetailer.MarketName," +
    "EObjXRetailer.DealerActiveFlag," +
    "EObjXRetailer.DealerGroup," +
    "EObjXRetailer.DealerRolloutFlag," +
    "EObjXRetailer.BatchInd," +
    "EObjXRetailer.CreateDate," +
    "EObjXRetailer.ChangedDate," +
    "EObjXRetailer.CRMCompanyCode," +
    "EObjXRetailer.lastUpdateDt," +
    "EObjXRetailer.lastUpdateUser," +
    "EObjXRetailer.lastUpdateTxId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getXRetailerByRetailerCodeAndMarketNameHistorySql = "SELECT r.H_RETAILERPK_ID hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.RETAILERPK_ID RETAILERPK_ID, r.RETAILER_CODE RETAILER_CODE, r.RETAILER_NAME RETAILER_NAME, r.BRANCH_NAME BRANCH_NAME, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.GS_CODE GS_CODE, r.GC_CODE GC_CODE, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.ND_CODE ND_CODE, r.MARKET_NAME MARKET_NAME, r.DEALER_ACTIVE_FLAG DEALER_ACTIVE_FLAG, r.DEALER_GROUP DEALER_GROUP, r.DEALER_ROLLOUT_FLAG DEALER_ROLLOUT_FLAG, r.BATCH_IND BATCH_IND, r.CREATE_DT CREATE_DT, r.CHANGED_DT CHANGED_DT, r.CRM_COMPANY_CODE CRM_COMPANY_CODE, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XRETAILER r WHERE r.RETAILER_CODE = ?  AND r.MARKET_NAME = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXRetailerByRetailerCodeAndMarketNameHistoryParameters =
    "EObjXRetailer.RetailerCode," +
    "EObjXRetailer.MarketName," +
    "EObjXRetailer.lastUpdateDt," +
    "EObjXRetailer.lastUpdateDt";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXRetailerByRetailerCodeAndMarketNameHistoryResults =
    "EObjXRetailer.historyIdPK," +
    "EObjXRetailer.histActionCode," +
    "EObjXRetailer.histCreatedBy," +
    "EObjXRetailer.histCreateDt," +
    "EObjXRetailer.histEndDt," +
    "EObjXRetailer.RetailerpkId," +
    "EObjXRetailer.RetailerCode," +
    "EObjXRetailer.RetailerName," +
    "EObjXRetailer.BranchName," +
    "EObjXRetailer.SourceIdentifier," +
    "EObjXRetailer.GSCode," +
    "EObjXRetailer.GCCode," +
    "EObjXRetailer.LastModifiedSystemDate," +
    "EObjXRetailer.NDCode," +
    "EObjXRetailer.MarketName," +
    "EObjXRetailer.DealerActiveFlag," +
    "EObjXRetailer.DealerGroup," +
    "EObjXRetailer.DealerRolloutFlag," +
    "EObjXRetailer.BatchInd," +
    "EObjXRetailer.CreateDate," +
    "EObjXRetailer.ChangedDate," +
    "EObjXRetailer.CRMCompanyCode," +
    "EObjXRetailer.lastUpdateDt," +
    "EObjXRetailer.lastUpdateUser," +
    "EObjXRetailer.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getXRetailerByNDCodeAndMarketNameSql = "SELECT r.RETAILERPK_ID RETAILERPK_ID, r.RETAILER_CODE RETAILER_CODE, r.RETAILER_NAME RETAILER_NAME, r.BRANCH_NAME BRANCH_NAME, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.GS_CODE GS_CODE, r.GC_CODE GC_CODE, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.ND_CODE ND_CODE, r.MARKET_NAME MARKET_NAME, r.DEALER_ACTIVE_FLAG DEALER_ACTIVE_FLAG, r.DEALER_GROUP DEALER_GROUP, r.DEALER_ROLLOUT_FLAG DEALER_ROLLOUT_FLAG, r.BATCH_IND BATCH_IND, r.CREATE_DT CREATE_DT, r.CHANGED_DT CHANGED_DT, r.CRM_COMPANY_CODE CRM_COMPANY_CODE, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XRETAILER r WHERE r.ND_CODE = ?  AND r.MARKET_NAME = ? ";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXRetailerByNDCodeAndMarketNameParameters =
    "EObjXRetailer.NDCode," +
    "EObjXRetailer.MarketName";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXRetailerByNDCodeAndMarketNameResults =
    "EObjXRetailer.RetailerpkId," +
    "EObjXRetailer.RetailerCode," +
    "EObjXRetailer.RetailerName," +
    "EObjXRetailer.BranchName," +
    "EObjXRetailer.SourceIdentifier," +
    "EObjXRetailer.GSCode," +
    "EObjXRetailer.GCCode," +
    "EObjXRetailer.LastModifiedSystemDate," +
    "EObjXRetailer.NDCode," +
    "EObjXRetailer.MarketName," +
    "EObjXRetailer.DealerActiveFlag," +
    "EObjXRetailer.DealerGroup," +
    "EObjXRetailer.DealerRolloutFlag," +
    "EObjXRetailer.BatchInd," +
    "EObjXRetailer.CreateDate," +
    "EObjXRetailer.ChangedDate," +
    "EObjXRetailer.CRMCompanyCode," +
    "EObjXRetailer.lastUpdateDt," +
    "EObjXRetailer.lastUpdateUser," +
    "EObjXRetailer.lastUpdateTxId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getXRetailerByNDCodeAndMarketNameHistorySql = "SELECT r.H_RETAILERPK_ID hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.RETAILERPK_ID RETAILERPK_ID, r.RETAILER_CODE RETAILER_CODE, r.RETAILER_NAME RETAILER_NAME, r.BRANCH_NAME BRANCH_NAME, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.GS_CODE GS_CODE, r.GC_CODE GC_CODE, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.ND_CODE ND_CODE, r.MARKET_NAME MARKET_NAME, r.DEALER_ACTIVE_FLAG DEALER_ACTIVE_FLAG, r.DEALER_GROUP DEALER_GROUP, r.DEALER_ROLLOUT_FLAG DEALER_ROLLOUT_FLAG, r.BATCH_IND BATCH_IND, r.CREATE_DT CREATE_DT, r.CHANGED_DT CHANGED_DT, r.CRM_COMPANY_CODE CRM_COMPANY_CODE, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XRETAILER r WHERE r.ND_CODE = ?  AND r.MARKET_NAME = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXRetailerByNDCodeAndMarketNameHistoryParameters =
    "EObjXRetailer.NDCode," +
    "EObjXRetailer.MarketName," +
    "EObjXRetailer.lastUpdateDt," +
    "EObjXRetailer.lastUpdateDt";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXRetailerByNDCodeAndMarketNameHistoryResults =
    "EObjXRetailer.historyIdPK," +
    "EObjXRetailer.histActionCode," +
    "EObjXRetailer.histCreatedBy," +
    "EObjXRetailer.histCreateDt," +
    "EObjXRetailer.histEndDt," +
    "EObjXRetailer.RetailerpkId," +
    "EObjXRetailer.RetailerCode," +
    "EObjXRetailer.RetailerName," +
    "EObjXRetailer.BranchName," +
    "EObjXRetailer.SourceIdentifier," +
    "EObjXRetailer.GSCode," +
    "EObjXRetailer.GCCode," +
    "EObjXRetailer.LastModifiedSystemDate," +
    "EObjXRetailer.NDCode," +
    "EObjXRetailer.MarketName," +
    "EObjXRetailer.DealerActiveFlag," +
    "EObjXRetailer.DealerGroup," +
    "EObjXRetailer.DealerRolloutFlag," +
    "EObjXRetailer.BatchInd," +
    "EObjXRetailer.CreateDate," +
    "EObjXRetailer.ChangedDate," +
    "EObjXRetailer.CRMCompanyCode," +
    "EObjXRetailer.lastUpdateDt," +
    "EObjXRetailer.lastUpdateUser," +
    "EObjXRetailer.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getXRetailerSql, pattern=tableAliasString)
  @EntityMapping(parameters=getXRetailerParameters, results=getXRetailerResults)
  Iterator<ResultQueue1<EObjXRetailer>> getXRetailer(Object[] parameters);  


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getXRetailerHistorySql, pattern=tableAliasString)
  @EntityMapping(parameters=getXRetailerHistoryParameters, results=getXRetailerHistoryResults)
  Iterator<ResultQueue1<EObjXRetailer>> getXRetailerHistory(Object[] parameters);


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getXRetailerByRetailerCodeSql, pattern=tableAliasString)
  @EntityMapping(parameters=getXRetailerByRetailerCodeParameters, results=getXRetailerByRetailerCodeResults)
  Iterator<ResultQueue1<EObjXRetailer>> getXRetailerByRetailerCode(Object[] parameters);


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getXRetailerByRetailerCodeHistorySql, pattern=tableAliasString)
  @EntityMapping(parameters=getXRetailerByRetailerCodeHistoryParameters, results=getXRetailerByRetailerCodeHistoryResults)
  Iterator<ResultQueue1<EObjXRetailer>> getXRetailerByRetailerCodeHistory(Object[] parameters);


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getXRetailerByNDCodeSql, pattern=tableAliasString)
  @EntityMapping(parameters=getXRetailerByNDCodeParameters, results=getXRetailerByNDCodeResults)
  Iterator<ResultQueue1<EObjXRetailer>> getXRetailerByNDCode(Object[] parameters);


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getXRetailerByNDCodeHistorySql, pattern=tableAliasString)
  @EntityMapping(parameters=getXRetailerByNDCodeHistoryParameters, results=getXRetailerByNDCodeHistoryResults)
  Iterator<ResultQueue1<EObjXRetailer>> getXRetailerByNDCodeHistory(Object[] parameters);


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getXRetailerByGSCodeSql, pattern=tableAliasString)
  @EntityMapping(parameters=getXRetailerByGSCodeParameters, results=getXRetailerByGSCodeResults)
  Iterator<ResultQueue1<EObjXRetailer>> getXRetailerByGSCode(Object[] parameters);


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getXRetailerByGSCodeHistorySql, pattern=tableAliasString)
  @EntityMapping(parameters=getXRetailerByGSCodeHistoryParameters, results=getXRetailerByGSCodeHistoryResults)
  Iterator<ResultQueue1<EObjXRetailer>> getXRetailerByGSCodeHistory(Object[] parameters);


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getXRetailerByGSCodeAndMarketNameSql, pattern=tableAliasString)
  @EntityMapping(parameters=getXRetailerByGSCodeAndMarketNameParameters, results=getXRetailerByGSCodeAndMarketNameResults)
  Iterator<ResultQueue1<EObjXRetailer>> getXRetailerByGSCodeAndMarketName(Object[] parameters);


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getXRetailerByGSCodeAndMarketNameHistorySql, pattern=tableAliasString)
  @EntityMapping(parameters=getXRetailerByGSCodeAndMarketNameHistoryParameters, results=getXRetailerByGSCodeAndMarketNameHistoryResults)
  Iterator<ResultQueue1<EObjXRetailer>> getXRetailerByGSCodeAndMarketNameHistory(Object[] parameters);


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getXRetailerByRetailerCodeAndMarketNameSql, pattern=tableAliasString)
  @EntityMapping(parameters=getXRetailerByRetailerCodeAndMarketNameParameters, results=getXRetailerByRetailerCodeAndMarketNameResults)
  Iterator<ResultQueue1<EObjXRetailer>> getXRetailerByRetailerCodeAndMarketName(Object[] parameters);


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getXRetailerByRetailerCodeAndMarketNameHistorySql, pattern=tableAliasString)
  @EntityMapping(parameters=getXRetailerByRetailerCodeAndMarketNameHistoryParameters, results=getXRetailerByRetailerCodeAndMarketNameHistoryResults)
  Iterator<ResultQueue1<EObjXRetailer>> getXRetailerByRetailerCodeAndMarketNameHistory(Object[] parameters);


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getXRetailerByNDCodeAndMarketNameSql, pattern=tableAliasString)
  @EntityMapping(parameters=getXRetailerByNDCodeAndMarketNameParameters, results=getXRetailerByNDCodeAndMarketNameResults)
  Iterator<ResultQueue1<EObjXRetailer>> getXRetailerByNDCodeAndMarketName(Object[] parameters);


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getXRetailerByNDCodeAndMarketNameHistorySql, pattern=tableAliasString)
  @EntityMapping(parameters=getXRetailerByNDCodeAndMarketNameHistoryParameters, results=getXRetailerByNDCodeAndMarketNameHistoryResults)
  Iterator<ResultQueue1<EObjXRetailer>> getXRetailerByNDCodeAndMarketNameHistory(Object[] parameters);  


}


