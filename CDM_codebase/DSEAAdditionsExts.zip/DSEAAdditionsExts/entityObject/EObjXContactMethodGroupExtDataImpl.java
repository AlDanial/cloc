package com.ibm.daimler.dsea.entityObject;

import com.ibm.pdq.runtime.generator.BaseParameterHandler;
import java.util.Iterator;
import com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup;
import java.sql.PreparedStatement;
import com.ibm.pdq.runtime.statement.StatementDescriptor;
import com.ibm.pdq.runtime.generator.BaseData;
import java.sql.SQLException;
import com.ibm.pdq.annotation.Metadata;
import com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt;
import com.ibm.pdq.runtime.generator.BaseRowHandler;
import com.ibm.pdq.runtime.statement.SqlStatementType;
import java.sql.Types;


/**
 * <!-- begin-user-doc -->
 * 
 * <!-- end-user-doc -->
 * 
 * @generated
 */
public class EObjXContactMethodGroupExtDataImpl  extends BaseData implements EObjXContactMethodGroupExtData
{

  /**
   * @generated
   */
  public static final String generatorVersion = "3.200.75";

  /**
   * @generated
   */
  public static final String identifier = "EObjXContactMethodGroupExtData";

  /**
   * @generated
   */
  public static final long generationTime = 0x0000015e1852d33bL;

  /**
   * @generated
   */
  public static final String collection = "NULLID";

  /**
   * @generated
   */
  public static final String packageVersion = null;

  /**
   * @generated
   */
  public static final boolean forceSingleBindIsolation = false;

  /**
   * @generated
   */
  public EObjXContactMethodGroupExtDataImpl()
  {
    super();
  } 

  /**
   * @generated
   */
  public String getGeneratorVersion()
  {
    return generatorVersion;
  }

  /**
   * @Select( sql="select XVERIFIED_TP_CD, XRETAILER_ID, XMODIFY_SYS_DT, XCONTACT_RETAILER_FLAG, X_BPID, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from CONTACTMETHODGROUP where LOCATION_GROUP_ID = ? " )
   * 
   * @generated
   */
  public Iterator<EObjXContactMethodGroupExt> getEObjXContactMethodGroupExt (Long locationGroupIdPK)
  {
    return queryIterator (getEObjXContactMethodGroupExtStatementDescriptor, locationGroupIdPK);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getEObjXContactMethodGroupExtStatementDescriptor = createStatementDescriptor (
    "getEObjXContactMethodGroupExt(Long)",
    "select XVERIFIED_TP_CD, XRETAILER_ID, XMODIFY_SYS_DT, XCONTACT_RETAILER_FLAG, X_BPID, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from CONTACTMETHODGROUP where LOCATION_GROUP_ID = ? ",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"xverified_tp_cd", "xretailer_id", "xmodify_sys_dt", "xcontact_retailer_flag", "x_bpid", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetEObjXContactMethodGroupExtParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetEObjXContactMethodGroupExtRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 19, 0, 5, 50, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    1);

  /**
   * @generated
   */
  public static class GetEObjXContactMethodGroupExtParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setLong (stmt, 1, Types.BIGINT, (Long)parameters[0]);
    }
  }

  /**
   * @generated
   */
  public static class GetEObjXContactMethodGroupExtRowHandler extends BaseRowHandler<EObjXContactMethodGroupExt>
  {
    /**
     * @generated
     */
    public EObjXContactMethodGroupExt handle (java.sql.ResultSet rs, EObjXContactMethodGroupExt returnObject) throws java.sql.SQLException
    {
      returnObject = new EObjXContactMethodGroupExt ();
      returnObject.setXVerified(getLongObject (rs, 1)); 
      returnObject.setXRetailerId(getLongObject (rs, 2)); 
      returnObject.setXLastModifiedSystemDate(getTimestamp (rs, 3)); 
      returnObject.setXContactRetailerFlag(getString (rs, 4)); 
      returnObject.setX_BPID(getString (rs, 5)); 
      returnObject.setLastUpdateDt(getTimestamp (rs, 6)); 
      returnObject.setLastUpdateUser(getString (rs, 7)); 
      returnObject.setLastUpdateTxId(getLongObject (rs, 8)); 
    
      return returnObject;
    }
  }

  /**
   * @Update( sql="insert into CONTACTMETHODGROUP (TEXT_ONLY_IND, ATTACH_ALLOW_IND, COMMENT_DESC, CONTACT_METHOD_ID, MESSAGE_SIZE, LOCATION_GROUP_ID, CONT_METH_TP_CD, METHOD_ST_TP_CD, XVERIFIED_TP_CD, XRETAILER_ID, XMODIFY_SYS_DT, XCONTACT_RETAILER_FLAG, X_BPID, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( ?1.textOnlyInd, ?1.attachAllowInd, ?1.commentDesc, ?1.contactMethodId, ?1.messageSize, ?1.locationGroupIdPK, ?1.contMethTpCd, ?1.methodStTpCd, ?2.xVerified, ?2.xRetailerId, ?2.xLastModifiedSystemDate, ?2.xContactRetailerFlag, ?2.x_BPID, ?1.lastUpdateDt, ?1.lastUpdateUser, ?1.lastUpdateTxId)" )
   * 
   * @generated
   */
  public int createEObjXContactMethodGroupExt (EObjContactMethodGroup e1, EObjXContactMethodGroupExt e2)
  {
    return update (createEObjXContactMethodGroupExtStatementDescriptor, e1, e2);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor createEObjXContactMethodGroupExtStatementDescriptor = createStatementDescriptor (
    "createEObjXContactMethodGroupExt(com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup, com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt)",
    "insert into CONTACTMETHODGROUP (TEXT_ONLY_IND, ATTACH_ALLOW_IND, COMMENT_DESC, CONTACT_METHOD_ID, MESSAGE_SIZE, LOCATION_GROUP_ID, CONT_METH_TP_CD, METHOD_ST_TP_CD, XVERIFIED_TP_CD, XRETAILER_ID, XMODIFY_SYS_DT, XCONTACT_RETAILER_FLAG, X_BPID, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values(  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? )",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.INSERT,
    null,
    new CreateEObjXContactMethodGroupExtParameterHandler (),
    new int[][]{{Types.CHAR, Types.CHAR, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {1, 1, 100, 19, 20, 19, 19, 19, 19, 19, 0, 5, 50, 0, 0, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    2);

  /**
   * @generated
   */
  public static class CreateEObjXContactMethodGroupExtParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      EObjContactMethodGroup bean0 = (EObjContactMethodGroup) parameters[0];
      setString (stmt, 1, Types.CHAR, (String)bean0.getTextOnlyInd());
      setString (stmt, 2, Types.CHAR, (String)bean0.getAttachAllowInd());
      setString (stmt, 3, Types.VARCHAR, (String)bean0.getCommentDesc());
      setLong (stmt, 4, Types.BIGINT, (Long)bean0.getContactMethodId());
      setString (stmt, 5, Types.VARCHAR, (String)bean0.getMessageSize());
      setLong (stmt, 6, Types.BIGINT, (Long)bean0.getLocationGroupIdPK());
      setLong (stmt, 7, Types.BIGINT, (Long)bean0.getContMethTpCd());
      setLong (stmt, 8, Types.BIGINT, (Long)bean0.getMethodStTpCd());
      EObjXContactMethodGroupExt bean1 = (EObjXContactMethodGroupExt) parameters[1];
      setLong (stmt, 9, Types.BIGINT, (Long)bean1.getXVerified());
      setLong (stmt, 10, Types.BIGINT, (Long)bean1.getXRetailerId());
      setTimestamp (stmt, 11, Types.TIMESTAMP, (java.sql.Timestamp)bean1.getXLastModifiedSystemDate());
      setString (stmt, 12, Types.VARCHAR, (String)bean1.getXContactRetailerFlag());
      setString (stmt, 13, Types.VARCHAR, (String)bean1.getX_BPID());
      setTimestamp (stmt, 14, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUpdateDt());
      setString (stmt, 15, Types.VARCHAR, (String)bean0.getLastUpdateUser());
      setLong (stmt, 16, Types.BIGINT, (Long)bean0.getLastUpdateTxId());
    }
  }

  /**
   * @Update( sql="update CONTACTMETHODGROUP set TEXT_ONLY_IND = ?1.textOnlyInd, ATTACH_ALLOW_IND = ?1.attachAllowInd, COMMENT_DESC = ?1.commentDesc, CONTACT_METHOD_ID = ?1.contactMethodId, MESSAGE_SIZE = ?1.messageSize, CONT_METH_TP_CD = ?1.contMethTpCd, METHOD_ST_TP_CD = ?1.methodStTpCd, XVERIFIED_TP_CD = ?2.xVerified, XRETAILER_ID = ?2.xRetailerId, XMODIFY_SYS_DT = ?2.xLastModifiedSystemDate, XCONTACT_RETAILER_FLAG = ?2.xContactRetailerFlag, X_BPID = ?2.x_BPID, LAST_UPDATE_DT = ?1.lastUpdateDt, LAST_UPDATE_USER = ?1.lastUpdateUser, LAST_UPDATE_TX_ID = ?1.lastUpdateTxId where LOCATION_GROUP_ID = ?1.locationGroupIdPK and LAST_UPDATE_DT = ?1.oldLastUpdateDt" )
   * 
   * @generated
   */
  public int updateEObjXContactMethodGroupExt (EObjContactMethodGroup e1, EObjXContactMethodGroupExt e2)
  {
    return update (updateEObjXContactMethodGroupExtStatementDescriptor, e1, e2);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor updateEObjXContactMethodGroupExtStatementDescriptor = createStatementDescriptor (
    "updateEObjXContactMethodGroupExt(com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup, com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt)",
    "update CONTACTMETHODGROUP set TEXT_ONLY_IND =  ? , ATTACH_ALLOW_IND =  ? , COMMENT_DESC =  ? , CONTACT_METHOD_ID =  ? , MESSAGE_SIZE =  ? , CONT_METH_TP_CD =  ? , METHOD_ST_TP_CD =  ? , XVERIFIED_TP_CD =  ? , XRETAILER_ID =  ? , XMODIFY_SYS_DT =  ? , XCONTACT_RETAILER_FLAG =  ? , X_BPID =  ? , LAST_UPDATE_DT =  ? , LAST_UPDATE_USER =  ? , LAST_UPDATE_TX_ID =  ?  where LOCATION_GROUP_ID =  ?  and LAST_UPDATE_DT =  ? ",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.UPDATE,
    null,
    new UpdateEObjXContactMethodGroupExtParameterHandler (),
    new int[][]{{Types.CHAR, Types.CHAR, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP}, {1, 1, 100, 19, 20, 19, 19, 19, 19, 0, 5, 50, 0, 0, 19, 19, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    3);

  /**
   * @generated
   */
  public static class UpdateEObjXContactMethodGroupExtParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      EObjContactMethodGroup bean0 = (EObjContactMethodGroup) parameters[0];
      setString (stmt, 1, Types.CHAR, (String)bean0.getTextOnlyInd());
      setString (stmt, 2, Types.CHAR, (String)bean0.getAttachAllowInd());
      setString (stmt, 3, Types.VARCHAR, (String)bean0.getCommentDesc());
      setLong (stmt, 4, Types.BIGINT, (Long)bean0.getContactMethodId());
      setString (stmt, 5, Types.VARCHAR, (String)bean0.getMessageSize());
      setLong (stmt, 6, Types.BIGINT, (Long)bean0.getContMethTpCd());
      setLong (stmt, 7, Types.BIGINT, (Long)bean0.getMethodStTpCd());
      EObjXContactMethodGroupExt bean1 = (EObjXContactMethodGroupExt) parameters[1];
      setLong (stmt, 8, Types.BIGINT, (Long)bean1.getXVerified());
      setLong (stmt, 9, Types.BIGINT, (Long)bean1.getXRetailerId());
      setTimestamp (stmt, 10, Types.TIMESTAMP, (java.sql.Timestamp)bean1.getXLastModifiedSystemDate());
      setString (stmt, 11, Types.VARCHAR, (String)bean1.getXContactRetailerFlag());
      setString (stmt, 12, Types.VARCHAR, (String)bean1.getX_BPID());
      setTimestamp (stmt, 13, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUpdateDt());
      setString (stmt, 14, Types.VARCHAR, (String)bean0.getLastUpdateUser());
      setLong (stmt, 15, Types.BIGINT, (Long)bean0.getLastUpdateTxId());
      setLong (stmt, 16, Types.BIGINT, (Long)bean0.getLocationGroupIdPK());
      setTimestamp (stmt, 17, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getOldLastUpdateDt());
    }
  }

  /**
   * @Update( sql="delete from CONTACTMETHODGROUP where LOCATION_GROUP_ID = ?" )
   * 
   * @generated
   */
  public int deleteEObjXContactMethodGroupExt (Long locationGroupIdPK)
  {
    return update (deleteEObjXContactMethodGroupExtStatementDescriptor, locationGroupIdPK);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor deleteEObjXContactMethodGroupExtStatementDescriptor = createStatementDescriptor (
    "deleteEObjXContactMethodGroupExt(Long)",
    "delete from CONTACTMETHODGROUP where LOCATION_GROUP_ID = ?",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.DELETE,
    null,
    new DeleteEObjXContactMethodGroupExtParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    4);

  /**
   * @generated
   */
  public static class DeleteEObjXContactMethodGroupExtParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setLong (stmt, 1, Types.BIGINT, (Long)parameters[0]);
    }
  }

}
