/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[1174af8f5f23ce3a37a4be78ff5a4302]
 */
package com.ibm.daimler.dsea.entityObject;


import com.ibm.mdm.base.db.EntityMapping;
import com.ibm.pdq.annotation.Select;


import com.dwl.tcrm.coreParty.entityObject.EObjContSummary;
import com.dwl.tcrm.coreParty.entityObject.EObjContact;
import com.dwl.tcrm.coreParty.entityObject.EObjOrg;

import com.ibm.mdm.base.db.ResultQueue3;
import com.ibm.mdm.base.db.ResultQueue4;

import java.util.Iterator;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * 
 * @generated
 */
public interface XOrgExtInquiryData {

  /**
   * MDM_TODO: CDKWB0050I The generated parameter and result lists in this file should be checked to ensure that each matches its
   * associated SQL query. Each list entry must be comma separated and identify a field within an entity object class.
   */ 
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */ 
   public final static String tableAliasString1 = "tableAlias (" + 
     "CONTSUMMARY => com.dwl.tcrm.coreParty.entityObject.EObjContSummary, " + 
     "ORG => com.dwl.tcrm.coreParty.entityObject.EObjOrg, " + 
     "H_ORG => com.dwl.tcrm.coreParty.entityObject.EObjOrg, " + 
     "CONTACT => com.dwl.tcrm.coreParty.entityObject.EObjContact, " + 
     "H_CONTACT => com.dwl.tcrm.coreParty.entityObject.EObjContact , " + 
     "ORG => com.ibm.daimler.dsea.entityObject.EObjXOrgExt , " + 
     "H_ORG => com.ibm.daimler.dsea.entityObject.EObjXOrgExt" + 
     ")";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension XOrg.
   *
   * @generated
   */ 
   public final static String getOrganizationHistorySQL = "SELECT DISTINCT A.H_CONT_ID AS H_CONT_ID_ORG, A.H_ACTION_CODE, A.H_CREATED_BY, A.H_CREATE_DT, A.H_END_DT, A.CONT_ID, A.ORG_TP_CD, A.INDUSTRY_TP_CD, A.ESTABLISHED_DT, A.BUY_SELL_AGR_TP_CD, A.PROFIT_IND, A.LAST_UPDATE_DT, A.LAST_UPDATE_USER,A.LAST_UPDATE_TX_ID, B.H_CONT_ID AS H_CONT_ID, B.H_ACTION_CODE, B.H_CREATED_BY, B.H_CREATE_DT, B.H_END_DT, B.CONT_ID, B.ACCE_COMP_TP_CD, B.PREF_LANG_TP_CD, B.CREATED_DT, B.SINCE_DT, B.LEFT_DT, B.INACTIVATED_DT, B.CONTACT_NAME, B.PERSON_ORG_CODE, B.SOLICIT_IND, B.CONFIDENTIAL_IND, B.CLIENT_IMP_TP_CD, B.CLIENT_ST_TP_CD, B.CLIENT_POTEN_TP_CD, B.RPTING_FREQ_TP_CD, B.LAST_STATEMENT_DT, B.PROVIDED_BY_CONT, B.LAST_UPDATE_DT, B.LAST_UPDATE_USER, B.LAST_UPDATE_TX_ID, B.LAST_USED_DT, B.LAST_VERIFIED_DT, B.SOURCE_IDENT_TP_CD, B.DO_NOT_DELETE_IND, B.ALERT_IND, B.ACCESS_TOKEN_VALUE, B.PENDING_CDC_IND, B.ENTITYLINK_ST_TP_CD, B.ENTITY_ID, B.ENTITY_TYPE, B.ENTITY_STATUS_TP_CD, A.XDEFUNCT_IND, A.XWEBSITE, A.XMARKET_NAME, A.XBATCH_IND, A.XNUMOFEMP_TP_CD, A.XMODIFY_SYS_DT, A.XSOURCE_TYPE_FLAG, A.XGENERATED_BY, A.XCORP_CAT_TP_CD, A.XCORP_GROUP_TP_CD, A.XPERSONAL_AGREEMENT, A.XDo_Not_Merge_Flag, A.DELETE_FLAG, A.INFO_REMOVE_FLAG, A.DEDUP_HIDDEN_FLAG, A.PREF_COMMUNICATION_CHANNEL, A.YANASE_FLAG, A.FINANCE_PARTY_TYPE, A.CONTRACT_NUMBER, A.XPrivacy_Act, A.XFleet, A.XPC_Ind, A.XVANS_Ind, A.Last_Activity_Date, A.X_CUST_TYPE" + 
     " FROM H_ORG A, H_CONTACT B" + 
     " WHERE A.H_CONT_ID = ? AND A.H_CONT_ID = B.H_CONT_ID AND (( ? BETWEEN A.H_CREATE_DT AND A.H_END_DT ) OR ( ? >= A.H_CREATE_DT AND A.H_END_DT IS NULL )) AND (( ? BETWEEN B.H_CREATE_DT AND B.H_END_DT ) OR ( ? >= B.H_CREATE_DT AND B.H_END_DT IS NULL ))";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getOrganizationHistoryParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjOrg.historyIdPK=H_CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrg.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrg.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.histCreateDt=H_CREATE_DT"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getOrganizationHistoryResults =
    "com.dwl.tcrm.coreParty.entityObject.EObjOrg.historyIdPK=H_CONT_ID_ORG," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrg.histActionCode=H_ACTION_CODE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrg.histCreatedBy=H_CREATED_BY," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrg.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrg.histEndDt=H_END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrg.contIdPK=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrg.orgTpCd=ORG_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrg.industryTpCd=INDUSTRY_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrg.establishedDt=ESTABLISHED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrg.buySellAgrTpCd=BUY_SELL_AGR_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrg.profitInd=PROFIT_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrg.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrg.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrg.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.historyIdPK=H_CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.histActionCode=H_ACTION_CODE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.histCreatedBy=H_CREATED_BY," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.histEndDt=H_END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.contIdPK=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.acceCompTpCd=ACCE_COMP_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.prefLangTpCd=PREF_LANG_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.createdDt=CREATED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.sinceDt=SINCE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.leftDt=LEFT_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.inactivatedDt=INACTIVATED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.contactName=CONTACT_NAME," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.personOrgCode=PERSON_ORG_CODE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.solicitInd=SOLICIT_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.confidentialInd=CONFIDENTIAL_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.clientImpTpCd=CLIENT_IMP_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.clientStTpCd=CLIENT_ST_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.clientPotenTpCd=CLIENT_POTEN_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.rptingFreqTpCd=RPTING_FREQ_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.lastStatementDt=LAST_STATEMENT_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.providedByCont=PROVIDED_BY_CONT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.lastUsedDt=LAST_USED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.lastVerifiedDt=LAST_VERIFIED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.sourceIdentTpCd=SOURCE_IDENT_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.doNotDelInd=DO_NOT_DELETE_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.alertInd=ALERT_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.accessTokenValue=ACCESS_TOKEN_VALUE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.pendingCDCInd=PENDING_CDC_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.entitylink_st_tp_cd=ENTITYLINK_ST_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.entity_id=ENTITY_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.entity_type=ENTITY_TYPE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.entityStatusTpCd=ENTITY_STATUS_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.XDefunctInd=XDEFUNCT_IND," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.XWebsite=XWEBSITE," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.XMarketName=XMARKET_NAME," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.XBatchInd=XBATCH_IND," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.XNumberOfEmployees=XNUMOFEMP_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.XLastModifiedSystemDate=XMODIFY_SYS_DT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.XSourceTypeFlag=XSOURCE_TYPE_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.XGenerated_by=XGENERATED_BY," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.XCorporateCategory=XCORP_CAT_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.XCorporateGroup=XCORP_GROUP_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.XPersonalAgreement=XPERSONAL_AGREEMENT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.XDoNotMergeFlag=XDo_Not_Merge_Flag," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.DeleteFlag=DELETE_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.InfoRemoveFlag=INFO_REMOVE_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.DedupHiddenFlag=DEDUP_HIDDEN_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.PrefCommunicationChannel=PREF_COMMUNICATION_CHANNEL," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.YanaseFlag=YANASE_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.FinancePartyType=FINANCE_PARTY_TYPE," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.ContractNumber=CONTRACT_NUMBER," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.XPrivacyAct=XPrivacy_Act," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.XFleet=XFleet," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.XPC_Ind=XPC_Ind," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.XVANS_Ind=XVANS_Ind," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.LastActivityDate=Last_Activity_Date," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.X_CUST_TYPE=X_CUST_TYPE"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension XOrg.
   *
   * @generated
   */ 
   public final static String getOrganizationIndicatorsSQL = "SELECT ORG.CONT_ID, ORG.ORG_TP_CD, ORG.INDUSTRY_TP_CD, ORG.ESTABLISHED_DT, ORG.BUY_SELL_AGR_TP_CD, ORG.PROFIT_IND, ORG.LAST_UPDATE_DT, ORG.LAST_UPDATE_USER, ORG.LAST_UPDATE_TX_ID, CONTACT.CONT_ID, CONTACT.ACCE_COMP_TP_CD, CONTACT.PREF_LANG_TP_CD, CONTACT.CREATED_DT, CONTACT.SINCE_DT, CONTACT.LEFT_DT, CONTACT.INACTIVATED_DT, CONTACT.CONTACT_NAME, CONTACT.PERSON_ORG_CODE, CONTACT.SOLICIT_IND, CONTACT.CONFIDENTIAL_IND, CONTACT.CLIENT_IMP_TP_CD, CONTACT.CLIENT_ST_TP_CD, CONTACT.CLIENT_POTEN_TP_CD, CONTACT.RPTING_FREQ_TP_CD, CONTACT.LAST_STATEMENT_DT, CONTACT.PROVIDED_BY_CONT, CONTACT.LAST_UPDATE_DT, CONTACT.LAST_UPDATE_USER, CONTACT.ALERT_IND, CONTACT.LAST_UPDATE_TX_ID, CONTACT.LAST_USED_DT, CONTACT.LAST_VERIFIED_DT, CONTACT.SOURCE_IDENT_TP_CD, CONTACT.DO_NOT_DELETE_IND, CS.CONT_ID, CS.PRIVPREF_IND, CS.MISCVALUE_IND, CS.CONTACTREL_IND, CS.BANKACCOUNT_IND, CS.CHARGECARD_IND, CS.INCOMESOURCE_IND, CS.PAYROLLDEDUCT_IND, CS.IDENTIFIER_IND, CS.ALERT_IND, CS.CONTEQUIV_IND, CS.INTERACTION_IND, CS.ADDRESSGROUP_IND, CS.CONTMETHGROUP_IND, CS.LOBREL_IND, CS.LAST_UPDATE_DT, CS.LAST_UPDATE_USER, CS.LAST_UPDATE_TX_ID, CONTACT.ACCESS_TOKEN_VALUE, CONTACT.PENDING_CDC_IND, CONTACT.ENTITYLINK_ST_TP_CD, CONTACT.ENTITY_ID, CONTACT.ENTITY_TYPE, CONTACT.ENTITY_STATUS_TP_CD, ORG.XDEFUNCT_IND, ORG.XWEBSITE, ORG.XMARKET_NAME, ORG.XBATCH_IND, ORG.XNUMOFEMP_TP_CD, ORG.XMODIFY_SYS_DT, ORG.XSOURCE_TYPE_FLAG, ORG.XGENERATED_BY, ORG.XCORP_CAT_TP_CD, ORG.XCORP_GROUP_TP_CD, ORG.XPERSONAL_AGREEMENT, ORG.XDo_Not_Merge_Flag, ORG.DELETE_FLAG, ORG.INFO_REMOVE_FLAG, ORG.DEDUP_HIDDEN_FLAG, ORG.PREF_COMMUNICATION_CHANNEL, ORG.YANASE_FLAG, ORG.FINANCE_PARTY_TYPE, ORG.CONTRACT_NUMBER, ORG.XPrivacy_Act, ORG.XFleet, ORG.XPC_Ind, ORG.XVANS_Ind, ORG.Last_Activity_Date, ORG.X_CUST_TYPE" + 
     " FROM ORG, CONTACT LEFT OUTER JOIN CONTSUMMARY CS ON CONTACT.CONT_ID = CS.CONT_ID" + 
     " WHERE ORG.CONT_ID = CONTACT.CONT_ID AND ORG.CONT_ID = ?";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getOrganizationIndicatorsParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjOrg.contIdPK=CONT_ID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getOrganizationIndicatorsResults =
    "com.dwl.tcrm.coreParty.entityObject.EObjOrg.contIdPK=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrg.orgTpCd=ORG_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrg.industryTpCd=INDUSTRY_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrg.establishedDt=ESTABLISHED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrg.buySellAgrTpCd=BUY_SELL_AGR_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrg.profitInd=PROFIT_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrg.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrg.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrg.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.contIdPK=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.acceCompTpCd=ACCE_COMP_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.prefLangTpCd=PREF_LANG_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.createdDt=CREATED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.sinceDt=SINCE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.leftDt=LEFT_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.inactivatedDt=INACTIVATED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.contactName=CONTACT_NAME," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.personOrgCode=PERSON_ORG_CODE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.solicitInd=SOLICIT_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.confidentialInd=CONFIDENTIAL_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.clientImpTpCd=CLIENT_IMP_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.clientStTpCd=CLIENT_ST_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.clientPotenTpCd=CLIENT_POTEN_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.rptingFreqTpCd=RPTING_FREQ_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.lastStatementDt=LAST_STATEMENT_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.providedByCont=PROVIDED_BY_CONT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.alertInd=ALERT_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.lastUsedDt=LAST_USED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.lastVerifiedDt=LAST_VERIFIED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.sourceIdentTpCd=SOURCE_IDENT_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.doNotDelInd=DO_NOT_DELETE_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContSummary.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContSummary.privPrefInd=PRIVPREF_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContSummary.miscValueInd=MISCVALUE_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContSummary.contactrelInd=CONTACTREL_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContSummary.bankAccountInd=BANKACCOUNT_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContSummary.chargeCardInd=CHARGECARD_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContSummary.incomeSourceInd=INCOMESOURCE_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContSummary.payrollDeductInd=PAYROLLDEDUCT_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContSummary.identifierInd=IDENTIFIER_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContSummary.alertInd=ALERT_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContSummary.contEquivInd=CONTEQUIV_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContSummary.interactionInd=INTERACTION_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContSummary.addressGroupInd=ADDRESSGROUP_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContSummary.contMethGroupInd=CONTMETHGROUP_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContSummary.lobRelInd=LOBREL_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContSummary.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContSummary.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContSummary.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.accessTokenValue=ACCESS_TOKEN_VALUE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.pendingCDCInd=PENDING_CDC_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.entitylink_st_tp_cd=ENTITYLINK_ST_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.entity_id=ENTITY_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.entity_type=ENTITY_TYPE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.entityStatusTpCd=ENTITY_STATUS_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.XDefunctInd=XDEFUNCT_IND," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.XWebsite=XWEBSITE," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.XMarketName=XMARKET_NAME," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.XBatchInd=XBATCH_IND," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.XNumberOfEmployees=XNUMOFEMP_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.XLastModifiedSystemDate=XMODIFY_SYS_DT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.XSourceTypeFlag=XSOURCE_TYPE_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.XGenerated_by=XGENERATED_BY," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.XCorporateCategory=XCORP_CAT_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.XCorporateGroup=XCORP_GROUP_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.XPersonalAgreement=XPERSONAL_AGREEMENT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.XDoNotMergeFlag=XDo_Not_Merge_Flag," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.DeleteFlag=DELETE_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.InfoRemoveFlag=INFO_REMOVE_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.DedupHiddenFlag=DEDUP_HIDDEN_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.PrefCommunicationChannel=PREF_COMMUNICATION_CHANNEL," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.YanaseFlag=YANASE_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.FinancePartyType=FINANCE_PARTY_TYPE," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.ContractNumber=CONTRACT_NUMBER," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.XPrivacyAct=XPrivacy_Act," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.XFleet=XFleet," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.XPC_Ind=XPC_Ind," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.XVANS_Ind=XVANS_Ind," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.LastActivityDate=Last_Activity_Date," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.X_CUST_TYPE=X_CUST_TYPE"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension XOrg.
   *
   * @generated
   */ 
   public final static String getOrganizationSQL = "SELECT ORG.CONT_ID, ORG.ORG_TP_CD, ORG.INDUSTRY_TP_CD, ORG.ESTABLISHED_DT, ORG.BUY_SELL_AGR_TP_CD, ORG.PROFIT_IND, ORG.LAST_UPDATE_DT, ORG.LAST_UPDATE_USER, ORG.LAST_UPDATE_TX_ID, CONTACT.CONT_ID, CONTACT.ACCE_COMP_TP_CD, CONTACT.PREF_LANG_TP_CD, CONTACT.CREATED_DT, CONTACT.SINCE_DT, CONTACT.LEFT_DT, CONTACT.INACTIVATED_DT, CONTACT.CONTACT_NAME, CONTACT.PERSON_ORG_CODE, CONTACT.SOLICIT_IND, CONTACT.CONFIDENTIAL_IND, CONTACT.CLIENT_IMP_TP_CD, CONTACT.CLIENT_ST_TP_CD, CONTACT.CLIENT_POTEN_TP_CD, CONTACT.RPTING_FREQ_TP_CD, CONTACT.LAST_STATEMENT_DT, CONTACT.PROVIDED_BY_CONT, CONTACT.LAST_UPDATE_DT, CONTACT.LAST_UPDATE_USER, CONTACT.ALERT_IND, CONTACT.LAST_UPDATE_TX_ID, CONTACT.LAST_USED_DT, CONTACT.LAST_VERIFIED_DT, CONTACT.SOURCE_IDENT_TP_CD, CONTACT.DO_NOT_DELETE_IND, CONTACT.ACCESS_TOKEN_VALUE, CONTACT.PENDING_CDC_IND, CONTACT.ENTITYLINK_ST_TP_CD, CONTACT.ENTITY_ID, CONTACT.ENTITY_TYPE, CONTACT.ENTITY_STATUS_TP_CD, ORG.XDEFUNCT_IND, ORG.XWEBSITE, ORG.XMARKET_NAME, ORG.XBATCH_IND, ORG.XNUMOFEMP_TP_CD, ORG.XMODIFY_SYS_DT, ORG.XSOURCE_TYPE_FLAG, ORG.XGENERATED_BY, ORG.XCORP_CAT_TP_CD, ORG.XCORP_GROUP_TP_CD, ORG.XPERSONAL_AGREEMENT, ORG.XDo_Not_Merge_Flag, ORG.DELETE_FLAG, ORG.INFO_REMOVE_FLAG, ORG.DEDUP_HIDDEN_FLAG, ORG.PREF_COMMUNICATION_CHANNEL, ORG.YANASE_FLAG, ORG.FINANCE_PARTY_TYPE, ORG.CONTRACT_NUMBER, ORG.XPrivacy_Act, ORG.XFleet, ORG.XPC_Ind, ORG.XVANS_Ind, ORG.Last_Activity_Date, ORG.X_CUST_TYPE" + 
     " FROM ORG, CONTACT" + 
     " WHERE ORG.CONT_ID = CONTACT.CONT_ID AND ORG.CONT_ID = ?";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getOrganizationParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjOrg.contIdPK=CONT_ID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getOrganizationResults =
    "com.dwl.tcrm.coreParty.entityObject.EObjOrg.contIdPK=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrg.orgTpCd=ORG_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrg.industryTpCd=INDUSTRY_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrg.establishedDt=ESTABLISHED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrg.buySellAgrTpCd=BUY_SELL_AGR_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrg.profitInd=PROFIT_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrg.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrg.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrg.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.contIdPK=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.acceCompTpCd=ACCE_COMP_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.prefLangTpCd=PREF_LANG_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.createdDt=CREATED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.sinceDt=SINCE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.leftDt=LEFT_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.inactivatedDt=INACTIVATED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.contactName=CONTACT_NAME," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.personOrgCode=PERSON_ORG_CODE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.solicitInd=SOLICIT_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.confidentialInd=CONFIDENTIAL_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.clientImpTpCd=CLIENT_IMP_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.clientStTpCd=CLIENT_ST_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.clientPotenTpCd=CLIENT_POTEN_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.rptingFreqTpCd=RPTING_FREQ_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.lastStatementDt=LAST_STATEMENT_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.providedByCont=PROVIDED_BY_CONT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.alertInd=ALERT_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.lastUsedDt=LAST_USED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.lastVerifiedDt=LAST_VERIFIED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.sourceIdentTpCd=SOURCE_IDENT_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.doNotDelInd=DO_NOT_DELETE_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.accessTokenValue=ACCESS_TOKEN_VALUE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.pendingCDCInd=PENDING_CDC_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.entitylink_st_tp_cd=ENTITYLINK_ST_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.entity_id=ENTITY_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.entity_type=ENTITY_TYPE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.entityStatusTpCd=ENTITY_STATUS_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.XDefunctInd=XDEFUNCT_IND," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.XWebsite=XWEBSITE," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.XMarketName=XMARKET_NAME," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.XBatchInd=XBATCH_IND," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.XNumberOfEmployees=XNUMOFEMP_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.XLastModifiedSystemDate=XMODIFY_SYS_DT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.XSourceTypeFlag=XSOURCE_TYPE_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.XGenerated_by=XGENERATED_BY," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.XCorporateCategory=XCORP_CAT_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.XCorporateGroup=XCORP_GROUP_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.XPersonalAgreement=XPERSONAL_AGREEMENT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.XDoNotMergeFlag=XDo_Not_Merge_Flag," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.DeleteFlag=DELETE_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.InfoRemoveFlag=INFO_REMOVE_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.DedupHiddenFlag=DEDUP_HIDDEN_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.PrefCommunicationChannel=PREF_COMMUNICATION_CHANNEL," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.YanaseFlag=YANASE_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.FinancePartyType=FINANCE_PARTY_TYPE," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.ContractNumber=CONTRACT_NUMBER," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.XPrivacyAct=XPrivacy_Act," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.XFleet=XFleet," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.XPC_Ind=XPC_Ind," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.XVANS_Ind=XVANS_Ind," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.LastActivityDate=Last_Activity_Date," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.X_CUST_TYPE=X_CUST_TYPE"; 
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */ 
   public final static String resultSetMapping1 = "<rsm>" + 
     "<col number='1' bean='com.dwl.tcrm.coreParty.entityObject.EObjOrg' property='historyIdPK'></col>" + 
     "<col number='2' bean='com.dwl.tcrm.coreParty.entityObject.EObjOrg' property='histActionCode'></col>" + 
     "<col number='3' bean='com.dwl.tcrm.coreParty.entityObject.EObjOrg' property='histCreatedBy'></col>" + 
     "<col number='4' bean='com.dwl.tcrm.coreParty.entityObject.EObjOrg' property='histCreateDt'></col>" + 
     "<col number='5' bean='com.dwl.tcrm.coreParty.entityObject.EObjOrg' property='histEndDt'></col>" + 
     "<col number='6' bean='com.dwl.tcrm.coreParty.entityObject.EObjOrg' property='contIdPK'></col>" + 
     "<col number='7' bean='com.dwl.tcrm.coreParty.entityObject.EObjOrg' property='orgTpCd'></col>" + 
     "<col number='8' bean='com.dwl.tcrm.coreParty.entityObject.EObjOrg' property='industryTpCd'></col>" + 
     "<col number='9' bean='com.dwl.tcrm.coreParty.entityObject.EObjOrg' property='establishedDt'></col>" + 
     "<col number='10' bean='com.dwl.tcrm.coreParty.entityObject.EObjOrg' property='buySellAgrTpCd'></col>" + 
     "<col number='11' bean='com.dwl.tcrm.coreParty.entityObject.EObjOrg' property='profitInd'></col>" + 
     "<col number='12' bean='com.dwl.tcrm.coreParty.entityObject.EObjOrg' property='lastUpdateDt'></col>" + 
     "<col number='13' bean='com.dwl.tcrm.coreParty.entityObject.EObjOrg' property='lastUpdateUser'></col>" + 
     "<col number='14' bean='com.dwl.tcrm.coreParty.entityObject.EObjOrg' property='lastUpdateTxId'></col>" + 
     "<col number='15' bean='com.dwl.tcrm.coreParty.entityObject.EObjContact' property='historyIdPK'></col>" + 
     "<col number='16' bean='com.dwl.tcrm.coreParty.entityObject.EObjContact' property='histActionCode'></col>" + 
     "<col number='17' bean='com.dwl.tcrm.coreParty.entityObject.EObjContact' property='histCreatedBy'></col>" + 
     "<col number='18' bean='com.dwl.tcrm.coreParty.entityObject.EObjContact' property='histCreateDt'></col>" + 
     "<col number='19' bean='com.dwl.tcrm.coreParty.entityObject.EObjContact' property='histEndDt'></col>" + 
     "<col number='20' bean='com.dwl.tcrm.coreParty.entityObject.EObjContact' property='contIdPK'></col>" + 
     "<col number='21' bean='com.dwl.tcrm.coreParty.entityObject.EObjContact' property='acceCompTpCd'></col>" + 
     "<col number='22' bean='com.dwl.tcrm.coreParty.entityObject.EObjContact' property='prefLangTpCd'></col>" + 
     "<col number='23' bean='com.dwl.tcrm.coreParty.entityObject.EObjContact' property='createdDt'></col>" + 
     "<col number='24' bean='com.dwl.tcrm.coreParty.entityObject.EObjContact' property='sinceDt'></col>" + 
     "<col number='25' bean='com.dwl.tcrm.coreParty.entityObject.EObjContact' property='leftDt'></col>" + 
     "<col number='26' bean='com.dwl.tcrm.coreParty.entityObject.EObjContact' property='inactivatedDt'></col>" + 
     "<col number='27' bean='com.dwl.tcrm.coreParty.entityObject.EObjContact' property='contactName'></col>" + 
     "<col number='28' bean='com.dwl.tcrm.coreParty.entityObject.EObjContact' property='personOrgCode'></col>" + 
     "<col number='29' bean='com.dwl.tcrm.coreParty.entityObject.EObjContact' property='solicitInd'></col>" + 
     "<col number='30' bean='com.dwl.tcrm.coreParty.entityObject.EObjContact' property='confidentialInd'></col>" + 
     "<col number='31' bean='com.dwl.tcrm.coreParty.entityObject.EObjContact' property='clientImpTpCd'></col>" + 
     "<col number='32' bean='com.dwl.tcrm.coreParty.entityObject.EObjContact' property='clientStTpCd'></col>" + 
     "<col number='33' bean='com.dwl.tcrm.coreParty.entityObject.EObjContact' property='clientPotenTpCd'></col>" + 
     "<col number='34' bean='com.dwl.tcrm.coreParty.entityObject.EObjContact' property='rptingFreqTpCd'></col>" + 
     "<col number='35' bean='com.dwl.tcrm.coreParty.entityObject.EObjContact' property='lastStatementDt'></col>" + 
     "<col number='36' bean='com.dwl.tcrm.coreParty.entityObject.EObjContact' property='providedByCont'></col>" + 
     "<col number='37' bean='com.dwl.tcrm.coreParty.entityObject.EObjContact' property='lastUpdateDt'></col>" + 
     "<col number='38' bean='com.dwl.tcrm.coreParty.entityObject.EObjContact' property='lastUpdateUser'></col>" + 
     "<col number='39' bean='com.dwl.tcrm.coreParty.entityObject.EObjContact' property='lastUpdateTxId'></col>" + 
     "<col number='40' bean='com.dwl.tcrm.coreParty.entityObject.EObjContact' property='lastUsedDt'></col>" + 
     "<col number='41' bean='com.dwl.tcrm.coreParty.entityObject.EObjContact' property='lastVerifiedDt'></col>" + 
     "<col number='42' bean='com.dwl.tcrm.coreParty.entityObject.EObjContact' property='sourceIdentTpCd'></col>" + 
     "<col number='43' bean='com.dwl.tcrm.coreParty.entityObject.EObjContact' property='doNotDelInd'></col>" + 
     "<col number='44' bean='com.dwl.tcrm.coreParty.entityObject.EObjContact' property='alertInd'></col>" + 
     "<col number='45' bean='com.dwl.tcrm.coreParty.entityObject.EObjContact' property='accessTokenValue'></col>" + 
     "<col number='46' bean='com.dwl.tcrm.coreParty.entityObject.EObjContact' property='pendingCDCInd'></col>" + 
     "<col number='47' bean='com.dwl.tcrm.coreParty.entityObject.EObjContact' property='entitylink_st_tp_cd'></col>" + 
     "<col number='48' bean='com.dwl.tcrm.coreParty.entityObject.EObjContact' property='entity_id'></col>" + 
     "<col number='49' bean='com.dwl.tcrm.coreParty.entityObject.EObjContact' property='entity_type'></col>" + 
     "<col number='50' bean='com.dwl.tcrm.coreParty.entityObject.EObjContact' property='entityStatusTpCd'></col>" + 
     "<col number='51' bean='com.ibm.daimler.dsea.entityObject.EObjXOrgExt' property='XDefunctInd'></col>" + 
     "<col number='52' bean='com.ibm.daimler.dsea.entityObject.EObjXOrgExt' property='XWebsite'></col>" + 
     "<col number='53' bean='com.ibm.daimler.dsea.entityObject.EObjXOrgExt' property='XMarketName'></col>" + 
     "<col number='54' bean='com.ibm.daimler.dsea.entityObject.EObjXOrgExt' property='XBatchInd'></col>" + 
     "<col number='55' bean='com.ibm.daimler.dsea.entityObject.EObjXOrgExt' property='XNumberOfEmployees'></col>" + 
     "<col number='56' bean='com.ibm.daimler.dsea.entityObject.EObjXOrgExt' property='XLastModifiedSystemDate'></col>" + 
     "<col number='57' bean='com.ibm.daimler.dsea.entityObject.EObjXOrgExt' property='XSourceTypeFlag'></col>" + 
     "<col number='58' bean='com.ibm.daimler.dsea.entityObject.EObjXOrgExt' property='XGenerated_by'></col>" + 
     "<col number='59' bean='com.ibm.daimler.dsea.entityObject.EObjXOrgExt' property='XCorporateCategory'></col>" + 
     "<col number='60' bean='com.ibm.daimler.dsea.entityObject.EObjXOrgExt' property='XCorporateGroup'></col>" + 
     "<col number='61' bean='com.ibm.daimler.dsea.entityObject.EObjXOrgExt' property='XPersonalAgreement'></col>" + 
     "<col number='62' bean='com.ibm.daimler.dsea.entityObject.EObjXOrgExt' property='XDoNotMergeFlag'></col>" + 
     "<col number='63' bean='com.ibm.daimler.dsea.entityObject.EObjXOrgExt' property='DeleteFlag'></col>" + 
     "<col number='64' bean='com.ibm.daimler.dsea.entityObject.EObjXOrgExt' property='InfoRemoveFlag'></col>" + 
     "<col number='65' bean='com.ibm.daimler.dsea.entityObject.EObjXOrgExt' property='DedupHiddenFlag'></col>" + 
     "<col number='66' bean='com.ibm.daimler.dsea.entityObject.EObjXOrgExt' property='PrefCommunicationChannel'></col>" + 
     "<col number='67' bean='com.ibm.daimler.dsea.entityObject.EObjXOrgExt' property='YanaseFlag'></col>" + 
     "<col number='68' bean='com.ibm.daimler.dsea.entityObject.EObjXOrgExt' property='FinancePartyType'></col>" + 
     "<col number='69' bean='com.ibm.daimler.dsea.entityObject.EObjXOrgExt' property='ContractNumber'></col>" + 
     "<col number='70' bean='com.ibm.daimler.dsea.entityObject.EObjXOrgExt' property='XPrivacyAct'></col>" + 
     "<col number='71' bean='com.ibm.daimler.dsea.entityObject.EObjXOrgExt' property='XFleet'></col>" + 
     "<col number='72' bean='com.ibm.daimler.dsea.entityObject.EObjXOrgExt' property='XPC_Ind'></col>" + 
     "<col number='73' bean='com.ibm.daimler.dsea.entityObject.EObjXOrgExt' property='XVANS_Ind'></col>" + 
     "<col number='74' bean='com.ibm.daimler.dsea.entityObject.EObjXOrgExt' property='LastActivityDate'></col>" + 
     "<col number='75' bean='com.ibm.daimler.dsea.entityObject.EObjXOrgExt' property='X_CUST_TYPE'></col>" + 
     "</rsm>";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension XOrg.
   *
   * @generated
   */ 
   public final static String getOrganizationImagesSQL = "SELECT DISTINCT A.H_CONT_ID AS H_CONT_ID_ORG, A.H_ACTION_CODE,A.H_CREATED_BY,A.H_CREATE_DT,A.H_END_DT, A.CONT_ID,A.ORG_TP_CD,A.INDUSTRY_TP_CD,A.ESTABLISHED_DT, A.BUY_SELL_AGR_TP_CD,A.PROFIT_IND,A.LAST_UPDATE_DT, A.LAST_UPDATE_USER, A.LAST_UPDATE_TX_ID, B.H_CONT_ID AS H_CONT_ID,B.H_ACTION_CODE,B.H_CREATED_BY,B.H_CREATE_DT,B.H_END_DT,B.CONT_ID,B.ACCE_COMP_TP_CD, B.PREF_LANG_TP_CD,B.CREATED_DT, B.SINCE_DT, B.LEFT_DT, B.INACTIVATED_DT,B.CONTACT_NAME,B.PERSON_ORG_CODE,B.SOLICIT_IND,B.CONFIDENTIAL_IND,B.CLIENT_IMP_TP_CD,B.CLIENT_ST_TP_CD,B.CLIENT_POTEN_TP_CD,B.RPTING_FREQ_TP_CD,B.LAST_STATEMENT_DT,B.PROVIDED_BY_CONT,B.LAST_UPDATE_DT,B.LAST_UPDATE_USER,B.LAST_UPDATE_TX_ID, B.LAST_USED_DT, B.LAST_VERIFIED_DT, B.SOURCE_IDENT_TP_CD, B.DO_NOT_DELETE_IND ,B.ALERT_IND, B.ACCESS_TOKEN_VALUE, B.PENDING_CDC_IND, B.ENTITYLINK_ST_TP_CD, B.ENTITY_ID, B.ENTITY_TYPE, B.ENTITY_STATUS_TP_CD, A.XDEFUNCT_IND, A.XWEBSITE, A.XMARKET_NAME, A.XBATCH_IND, A.XNUMOFEMP_TP_CD, A.XMODIFY_SYS_DT, A.XSOURCE_TYPE_FLAG, A.XGENERATED_BY, A.XCORP_CAT_TP_CD, A.XCORP_GROUP_TP_CD, A.XPERSONAL_AGREEMENT, A.XDo_Not_Merge_Flag, A.DELETE_FLAG, A.INFO_REMOVE_FLAG, A.DEDUP_HIDDEN_FLAG, A.PREF_COMMUNICATION_CHANNEL, A.YANASE_FLAG, A.FINANCE_PARTY_TYPE, A.CONTRACT_NUMBER, A.XPrivacy_Act, A.XFleet, A.XPC_Ind, A.XVANS_Ind, A.Last_Activity_Date, A.X_CUST_TYPE" + 
     " FROM H_CONTACT B LEFT JOIN H_ORG A ON A.CONT_ID = B.CONT_ID AND A.LAST_UPDATE_TX_ID = B.LAST_UPDATE_TX_ID" + 
     " WHERE B.CONT_ID = ? AND (A.H_CREATE_DT BETWEEN ? AND ?)" + 
     " UNION SELECT DISTINCT A.H_CONT_ID AS H_CONT_ID_ORG,A.H_ACTION_CODE,A.H_CREATED_BY, A.H_CREATE_DT, A.H_END_DT,A.CONT_ID,A.ORG_TP_CD, A.INDUSTRY_TP_CD,A.ESTABLISHED_DT,A.BUY_SELL_AGR_TP_CD,A.PROFIT_IND,A.LAST_UPDATE_DT, A.LAST_UPDATE_USER,A.LAST_UPDATE_TX_ID,B.H_CONT_ID AS H_CONT_ID,B.H_ACTION_CODE,B.H_CREATED_BY, B.H_CREATE_DT,B.H_END_DT,B.CONT_ID,B.ACCE_COMP_TP_CD,B.PREF_LANG_TP_CD,B.CREATED_DT,B.SINCE_DT,B.LEFT_DT,B.INACTIVATED_DT,B.CONTACT_NAME,B.PERSON_ORG_CODE,B.SOLICIT_IND,B.CONFIDENTIAL_IND,B.CLIENT_IMP_TP_CD,B.CLIENT_ST_TP_CD,B.CLIENT_POTEN_TP_CD,B.RPTING_FREQ_TP_CD,B.LAST_STATEMENT_DT,B.PROVIDED_BY_CONT,B.LAST_UPDATE_DT,B.LAST_UPDATE_USER, B.LAST_UPDATE_TX_ID, B.LAST_USED_DT, B.LAST_VERIFIED_DT, B.SOURCE_IDENT_TP_CD, B.DO_NOT_DELETE_IND, B.ALERT_IND, B.ACCESS_TOKEN_VALUE, B.PENDING_CDC_IND,B.ENTITYLINK_ST_TP_CD, B.ENTITY_ID, B.ENTITY_TYPE, B.ENTITY_STATUS_TP_CD, A.XDEFUNCT_IND, A.XWEBSITE, A.XMARKET_NAME, A.XBATCH_IND, A.XNUMOFEMP_TP_CD, A.XMODIFY_SYS_DT, A.XSOURCE_TYPE_FLAG, A.XGENERATED_BY, A.XCORP_CAT_TP_CD, A.XCORP_GROUP_TP_CD, A.XPERSONAL_AGREEMENT, A.XDo_Not_Merge_Flag, A.DELETE_FLAG, A.INFO_REMOVE_FLAG, A.DEDUP_HIDDEN_FLAG, A.PREF_COMMUNICATION_CHANNEL, A.YANASE_FLAG, A.FINANCE_PARTY_TYPE, A.CONTRACT_NUMBER, A.XPrivacy_Act, A.XFleet, A.XPC_Ind, A.XVANS_Ind, A.Last_Activity_Date, A.X_CUST_TYPE" + 
     " FROM H_ORG A LEFT JOIN H_CONTACT B ON A.CONT_ID = B.CONT_ID AND A.LAST_UPDATE_TX_ID = B.LAST_UPDATE_TX_ID" + 
     " WHERE A.CONT_ID = ? AND ( A.H_CREATE_DT BETWEEN ? AND ?)";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getOrganizationImagesParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.contIdPK=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrg.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrg.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrg.contIdPK=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrg.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrg.histCreateDt=H_CREATE_DT"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getOrganizationImagesResults =
    "com.dwl.tcrm.coreParty.entityObject.EObjOrg.historyIdPK=H_CONT_ID_ORG," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrg.histActionCode=H_ACTION_CODE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrg.histCreatedBy=H_CREATED_BY," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrg.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrg.histEndDt=H_END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrg.contIdPK=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrg.orgTpCd=ORG_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrg.industryTpCd=INDUSTRY_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrg.establishedDt=ESTABLISHED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrg.buySellAgrTpCd=BUY_SELL_AGR_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrg.profitInd=PROFIT_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrg.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrg.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrg.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.historyIdPK=H_CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.histActionCode=H_ACTION_CODE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.histCreatedBy=H_CREATED_BY," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.histEndDt=H_END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.contIdPK=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.acceCompTpCd=ACCE_COMP_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.prefLangTpCd=PREF_LANG_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.createdDt=CREATED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.sinceDt=SINCE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.leftDt=LEFT_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.inactivatedDt=INACTIVATED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.contactName=CONTACT_NAME," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.personOrgCode=PERSON_ORG_CODE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.solicitInd=SOLICIT_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.confidentialInd=CONFIDENTIAL_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.clientImpTpCd=CLIENT_IMP_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.clientStTpCd=CLIENT_ST_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.clientPotenTpCd=CLIENT_POTEN_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.rptingFreqTpCd=RPTING_FREQ_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.lastStatementDt=LAST_STATEMENT_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.providedByCont=PROVIDED_BY_CONT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.lastUsedDt=LAST_USED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.lastVerifiedDt=LAST_VERIFIED_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.sourceIdentTpCd=SOURCE_IDENT_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.doNotDelInd=DO_NOT_DELETE_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.alertInd=ALERT_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.accessTokenValue=ACCESS_TOKEN_VALUE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.pendingCDCInd=PENDING_CDC_IND," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.entitylink_st_tp_cd=ENTITYLINK_ST_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.entity_id=ENTITY_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.entity_type=ENTITY_TYPE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.entityStatusTpCd=ENTITY_STATUS_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.XDefunctInd=XDEFUNCT_IND," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.XWebsite=XWEBSITE," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.XMarketName=XMARKET_NAME," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.XBatchInd=XBATCH_IND," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.XNumberOfEmployees=XNUMOFEMP_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.XLastModifiedSystemDate=XMODIFY_SYS_DT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.XSourceTypeFlag=XSOURCE_TYPE_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.XGenerated_by=XGENERATED_BY," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.XCorporateCategory=XCORP_CAT_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.XCorporateGroup=XCORP_GROUP_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.XPersonalAgreement=XPERSONAL_AGREEMENT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.XDoNotMergeFlag=XDo_Not_Merge_Flag," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.DeleteFlag=DELETE_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.InfoRemoveFlag=INFO_REMOVE_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.DedupHiddenFlag=DEDUP_HIDDEN_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.PrefCommunicationChannel=PREF_COMMUNICATION_CHANNEL," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.YanaseFlag=YANASE_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.FinancePartyType=FINANCE_PARTY_TYPE," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.ContractNumber=CONTRACT_NUMBER," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.XPrivacyAct=XPrivacy_Act," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.XFleet=XFleet," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.XPC_Ind=XPC_Ind," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.XVANS_Ind=XVANS_Ind," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.LastActivityDate=Last_Activity_Date," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.X_CUST_TYPE=X_CUST_TYPE"; 
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */ 
   public final static String resultSetMapping2 = "<rsm>" + 
     "<col number='1' bean='com.dwl.tcrm.coreParty.entityObject.EObjOrg' property='contIdPK'></col>" + 
     "<col number='2' bean='com.dwl.tcrm.coreParty.entityObject.EObjOrg' property='lastUpdateDt'></col>" + 
     "<col number='3' bean='com.dwl.tcrm.coreParty.entityObject.EObjContact' property='accessTokenValue'></col>" + 
     "<col number='4' bean='com.dwl.tcrm.coreParty.entityObject.EObjContact' property='pendingCDCInd'></col>" + 
     "<col number='5' bean='com.ibm.daimler.dsea.entityObject.EObjXOrgExt' property='XDefunctInd'></col>" + 
     "<col number='6' bean='com.ibm.daimler.dsea.entityObject.EObjXOrgExt' property='XWebsite'></col>" + 
     "<col number='7' bean='com.ibm.daimler.dsea.entityObject.EObjXOrgExt' property='XMarketName'></col>" + 
     "<col number='8' bean='com.ibm.daimler.dsea.entityObject.EObjXOrgExt' property='XBatchInd'></col>" + 
     "<col number='9' bean='com.ibm.daimler.dsea.entityObject.EObjXOrgExt' property='XNumberOfEmployees'></col>" + 
     "<col number='10' bean='com.ibm.daimler.dsea.entityObject.EObjXOrgExt' property='XLastModifiedSystemDate'></col>" + 
     "<col number='11' bean='com.ibm.daimler.dsea.entityObject.EObjXOrgExt' property='XSourceTypeFlag'></col>" + 
     "<col number='12' bean='com.ibm.daimler.dsea.entityObject.EObjXOrgExt' property='XGenerated_by'></col>" + 
     "<col number='13' bean='com.ibm.daimler.dsea.entityObject.EObjXOrgExt' property='XCorporateCategory'></col>" + 
     "<col number='14' bean='com.ibm.daimler.dsea.entityObject.EObjXOrgExt' property='XCorporateGroup'></col>" + 
     "<col number='15' bean='com.ibm.daimler.dsea.entityObject.EObjXOrgExt' property='XPersonalAgreement'></col>" + 
     "<col number='16' bean='com.ibm.daimler.dsea.entityObject.EObjXOrgExt' property='XDoNotMergeFlag'></col>" + 
     "<col number='17' bean='com.ibm.daimler.dsea.entityObject.EObjXOrgExt' property='DeleteFlag'></col>" + 
     "<col number='18' bean='com.ibm.daimler.dsea.entityObject.EObjXOrgExt' property='InfoRemoveFlag'></col>" + 
     "<col number='19' bean='com.ibm.daimler.dsea.entityObject.EObjXOrgExt' property='DedupHiddenFlag'></col>" + 
     "<col number='20' bean='com.ibm.daimler.dsea.entityObject.EObjXOrgExt' property='PrefCommunicationChannel'></col>" + 
     "<col number='21' bean='com.ibm.daimler.dsea.entityObject.EObjXOrgExt' property='YanaseFlag'></col>" + 
     "<col number='22' bean='com.ibm.daimler.dsea.entityObject.EObjXOrgExt' property='FinancePartyType'></col>" + 
     "<col number='23' bean='com.ibm.daimler.dsea.entityObject.EObjXOrgExt' property='ContractNumber'></col>" + 
     "<col number='24' bean='com.ibm.daimler.dsea.entityObject.EObjXOrgExt' property='XPrivacyAct'></col>" + 
     "<col number='25' bean='com.ibm.daimler.dsea.entityObject.EObjXOrgExt' property='XFleet'></col>" + 
     "<col number='26' bean='com.ibm.daimler.dsea.entityObject.EObjXOrgExt' property='XPC_Ind'></col>" + 
     "<col number='27' bean='com.ibm.daimler.dsea.entityObject.EObjXOrgExt' property='XVANS_Ind'></col>" + 
     "<col number='28' bean='com.ibm.daimler.dsea.entityObject.EObjXOrgExt' property='LastActivityDate'></col>" + 
     "<col number='29' bean='com.ibm.daimler.dsea.entityObject.EObjXOrgExt' property='X_CUST_TYPE'></col>" + 
     "</rsm>";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension XOrg.
   *
   * @generated
   */ 
   public final static String getOrganizationsLightImagesSQL = "SELECT DISTINCT A.CONT_ID, A.LAST_UPDATE_DT, B.ACCESS_TOKEN_VALUE, B.PENDING_CDC_IND, A.XDEFUNCT_IND, A.XWEBSITE, A.XMARKET_NAME, A.XBATCH_IND, A.XNUMOFEMP_TP_CD, A.XMODIFY_SYS_DT, A.XSOURCE_TYPE_FLAG, A.XGENERATED_BY, A.XCORP_CAT_TP_CD, A.XCORP_GROUP_TP_CD, A.XPERSONAL_AGREEMENT, A.XDo_Not_Merge_Flag, A.DELETE_FLAG, A.INFO_REMOVE_FLAG, A.DEDUP_HIDDEN_FLAG, A.PREF_COMMUNICATION_CHANNEL, A.YANASE_FLAG, A.FINANCE_PARTY_TYPE, A.CONTRACT_NUMBER, A.XPrivacy_Act, A.XFleet, A.XPC_Ind, A.XVANS_Ind, A.Last_Activity_Date, A.X_CUST_TYPE" + 
     " FROM H_CONTACT B LEFT JOIN H_ORG A ON A.CONT_ID = B.CONT_ID AND A.LAST_UPDATE_TX_ID = B.LAST_UPDATE_TX_ID" + 
     " WHERE B.CONT_ID = ? AND (A.H_CREATE_DT BETWEEN ? AND ?)" + 
     " UNION SELECT DISTINCT A.CONT_ID, A.LAST_UPDATE_DT, B.ACCESS_TOKEN_VALUE, B.PENDING_CDC_IND, A.XDEFUNCT_IND, A.XWEBSITE, A.XMARKET_NAME, A.XBATCH_IND, A.XNUMOFEMP_TP_CD, A.XMODIFY_SYS_DT, A.XSOURCE_TYPE_FLAG, A.XGENERATED_BY, A.XCORP_CAT_TP_CD, A.XCORP_GROUP_TP_CD, A.XPERSONAL_AGREEMENT, A.XDo_Not_Merge_Flag, A.DELETE_FLAG, A.INFO_REMOVE_FLAG, A.DEDUP_HIDDEN_FLAG, A.PREF_COMMUNICATION_CHANNEL, A.YANASE_FLAG, A.FINANCE_PARTY_TYPE, A.CONTRACT_NUMBER, A.XPrivacy_Act, A.XFleet, A.XPC_Ind, A.XVANS_Ind, A.Last_Activity_Date, A.X_CUST_TYPE" + 
     " FROM H_ORG A LEFT JOIN H_CONTACT B ON A.CONT_ID = B.CONT_ID AND A.LAST_UPDATE_TX_ID = B.LAST_UPDATE_TX_ID" + 
     " WHERE A.CONT_ID = ? AND ( A.H_CREATE_DT BETWEEN ? AND ?)";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getOrganizationsLightImagesParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.contIdPK=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrg.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrg.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrg.contIdPK=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrg.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrg.histCreateDt=H_CREATE_DT"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getOrganizationsLightImagesResults =
    "com.dwl.tcrm.coreParty.entityObject.EObjOrg.contIdPK=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjOrg.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.accessTokenValue=ACCESS_TOKEN_VALUE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContact.pendingCDCInd=PENDING_CDC_IND," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.XDefunctInd=XDEFUNCT_IND," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.XWebsite=XWEBSITE," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.XMarketName=XMARKET_NAME," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.XBatchInd=XBATCH_IND," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.XNumberOfEmployees=XNUMOFEMP_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.XLastModifiedSystemDate=XMODIFY_SYS_DT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.XSourceTypeFlag=XSOURCE_TYPE_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.XGenerated_by=XGENERATED_BY," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.XCorporateCategory=XCORP_CAT_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.XCorporateGroup=XCORP_GROUP_TP_CD," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.XPersonalAgreement=XPERSONAL_AGREEMENT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.XDoNotMergeFlag=XDo_Not_Merge_Flag," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.DeleteFlag=DELETE_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.InfoRemoveFlag=INFO_REMOVE_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.DedupHiddenFlag=DEDUP_HIDDEN_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.PrefCommunicationChannel=PREF_COMMUNICATION_CHANNEL," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.YanaseFlag=YANASE_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.FinancePartyType=FINANCE_PARTY_TYPE," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.ContractNumber=CONTRACT_NUMBER," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.XPrivacyAct=XPrivacy_Act," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.XFleet=XFleet," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.XPC_Ind=XPC_Ind," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.XVANS_Ind=XVANS_Ind," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.LastActivityDate=Last_Activity_Date," + 
    "com.ibm.daimler.dsea.entityObject.EObjXOrgExt.X_CUST_TYPE=X_CUST_TYPE"; 


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getOrganizationHistorySQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getOrganizationHistoryParameters, results=getOrganizationHistoryResults)
  		Iterator<ResultQueue3<EObjContact, EObjOrg, EObjXOrgExt>> getOrganizationHistory(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getOrganizationIndicatorsSQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getOrganizationIndicatorsParameters, results=getOrganizationIndicatorsResults)
  		Iterator<ResultQueue4<EObjContact, EObjOrg, EObjContSummary, EObjXOrgExt>> getOrganizationIndicators(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getOrganizationSQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getOrganizationParameters, results=getOrganizationResults)
  		Iterator<ResultQueue3<EObjContact, EObjOrg, EObjXOrgExt>> getOrganization(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getOrganizationImagesSQL , pattern=resultSetMapping1)
  @EntityMapping(parameters=getOrganizationImagesParameters, results=getOrganizationImagesResults)
  		Iterator<ResultQueue3<EObjContact, EObjOrg, EObjXOrgExt>> getOrganizationImages(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getOrganizationsLightImagesSQL , pattern=resultSetMapping2)
  @EntityMapping(parameters=getOrganizationsLightImagesParameters, results=getOrganizationsLightImagesResults)
  		Iterator<ResultQueue3<EObjContact, EObjOrg, EObjXOrgExt>> getOrganizationsLightImages(Object[] parameters);
 
}


