/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[7016179655920bb2ad5259b33fd1fb02]
 */


package com.ibm.daimler.dsea.entityObject;

import java.util.Iterator;
import com.ibm.mdm.base.db.EntityMapping;
import com.ibm.pdq.annotation.Select;
import com.ibm.pdq.annotation.Update;

import com.ibm.daimler.dsea.entityObject.EObjXPreference;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * @generated
 */
public interface EObjXPreferenceData {


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjXPreferenceSql = "select PREFERENCEPK_ID, LOCATION_GROUP_ID, PREFERENCE_TP_CD, SOURCE_IDENT_TP_CD, START_DT, END_DT, MODIFY_SYS_DT, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from XPREFERENCE where PREFERENCEPK_ID = ? ";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String createEObjXPreferenceSql = "insert into XPREFERENCE (PREFERENCEPK_ID, LOCATION_GROUP_ID, PREFERENCE_TP_CD, SOURCE_IDENT_TP_CD, START_DT, END_DT, MODIFY_SYS_DT, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( :preferencepkId, :locationGroupId, :preferred, :sourceIdentifier, :startDate, :endDate, :lastModifiedSystemDate, :lastUpdateDt, :lastUpdateUser, :lastUpdateTxId)";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String updateEObjXPreferenceSql = "update XPREFERENCE set LOCATION_GROUP_ID = :locationGroupId, PREFERENCE_TP_CD = :preferred, SOURCE_IDENT_TP_CD = :sourceIdentifier, START_DT = :startDate, END_DT = :endDate, MODIFY_SYS_DT = :lastModifiedSystemDate, LAST_UPDATE_DT = :lastUpdateDt, LAST_UPDATE_USER = :lastUpdateUser, LAST_UPDATE_TX_ID = :lastUpdateTxId where PREFERENCEPK_ID = :preferencepkId and LAST_UPDATE_DT = :oldLastUpdateDt";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated NOT
   */
  public static final String deleteEObjXPreferenceSql = "delete from XPREFERENCE where LOCATION_GROUP_ID = ?";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXPreferenceKeyField = "EObjXPreference.preferencepkId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated NOT
   */
  
  public static final String EObjXPreferenceDeleteKeyField = "EObjXPreference.locationGroupId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXPreferenceGetFields =
    "EObjXPreference.preferencepkId," +
    "EObjXPreference.locationGroupId," +
    "EObjXPreference.preferred," +
    "EObjXPreference.sourceIdentifier," +
    "EObjXPreference.startDate," +
    "EObjXPreference.endDate," +
    "EObjXPreference.lastModifiedSystemDate," +
    "EObjXPreference.lastUpdateDt," +
    "EObjXPreference.lastUpdateUser," +
    "EObjXPreference.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXPreferenceAllFields =
    "com.ibm.daimler.dsea.entityObject.EObjXPreference.preferencepkId," +
    "com.ibm.daimler.dsea.entityObject.EObjXPreference.locationGroupId," +
    "com.ibm.daimler.dsea.entityObject.EObjXPreference.preferred," +
    "com.ibm.daimler.dsea.entityObject.EObjXPreference.sourceIdentifier," +
    "com.ibm.daimler.dsea.entityObject.EObjXPreference.startDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXPreference.endDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXPreference.lastModifiedSystemDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXPreference.lastUpdateDt," +
    "com.ibm.daimler.dsea.entityObject.EObjXPreference.lastUpdateUser," +
    "com.ibm.daimler.dsea.entityObject.EObjXPreference.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXPreferenceUpdateFields =
    "com.ibm.daimler.dsea.entityObject.EObjXPreference.locationGroupId," +
    "com.ibm.daimler.dsea.entityObject.EObjXPreference.preferred," +
    "com.ibm.daimler.dsea.entityObject.EObjXPreference.sourceIdentifier," +
    "com.ibm.daimler.dsea.entityObject.EObjXPreference.startDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXPreference.endDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXPreference.lastModifiedSystemDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXPreference.lastUpdateDt," +
    "com.ibm.daimler.dsea.entityObject.EObjXPreference.lastUpdateUser," +
    "com.ibm.daimler.dsea.entityObject.EObjXPreference.lastUpdateTxId," +
    "com.ibm.daimler.dsea.entityObject.EObjXPreference.preferencepkId," +
    "com.ibm.daimler.dsea.entityObject.EObjXPreference.oldLastUpdateDt";   

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Select XPreference by parameters.
   * @generated
   */
  @Select(sql=getEObjXPreferenceSql)
  @EntityMapping(parameters=EObjXPreferenceKeyField, results=EObjXPreferenceGetFields)
  Iterator<EObjXPreference> getEObjXPreference(Long preferencepkId);  
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Create XPreference by EObjXPreference Object.
   * @generated
   */
  @Update(sql=createEObjXPreferenceSql)
  @EntityMapping(parameters=EObjXPreferenceAllFields)
    int createEObjXPreference(EObjXPreference e); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Update one XPreference by EObjXPreference object.
   * @generated
   */
  @Update(sql=updateEObjXPreferenceSql)
  @EntityMapping(parameters=EObjXPreferenceUpdateFields)
    int updateEObjXPreference(EObjXPreference e); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Delete XPreference by parameters.
   * @generated NOT
   */
  @Update(sql=deleteEObjXPreferenceSql)
  @EntityMapping(parameters=EObjXPreferenceDeleteKeyField)
  int deleteEObjXPreference(Long locationGroupId);

}

