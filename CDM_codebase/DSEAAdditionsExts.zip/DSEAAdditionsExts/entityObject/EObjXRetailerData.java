/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[19ead2984734cae96ebbff73eb510a5b]
 */


package com.ibm.daimler.dsea.entityObject;

import java.util.Iterator;
import com.ibm.mdm.base.db.EntityMapping;
import com.ibm.pdq.annotation.Select;
import com.ibm.pdq.annotation.Update;

import com.ibm.daimler.dsea.entityObject.EObjXRetailer;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * @generated
 */
public interface EObjXRetailerData {


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjXRetailerSql = "select RETAILERPK_ID, RETAILER_CODE, RETAILER_NAME, BRANCH_NAME, SOURCE_IDENT_TP_CD, GS_CODE, GC_CODE, MODIFY_SYS_DT, ND_CODE, MARKET_NAME, DEALER_ACTIVE_FLAG, DEALER_GROUP, DEALER_ROLLOUT_FLAG, BATCH_IND, CREATE_DT, CHANGED_DT, CRM_COMPANY_CODE, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from XRETAILER where RETAILERPK_ID = ? ";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String createEObjXRetailerSql = "insert into XRETAILER (RETAILERPK_ID, RETAILER_CODE, RETAILER_NAME, BRANCH_NAME, SOURCE_IDENT_TP_CD, GS_CODE, GC_CODE, MODIFY_SYS_DT, ND_CODE, MARKET_NAME, DEALER_ACTIVE_FLAG, DEALER_GROUP, DEALER_ROLLOUT_FLAG, BATCH_IND, CREATE_DT, CHANGED_DT, CRM_COMPANY_CODE, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( :retailerpkId, :retailerCode, :retailerName, :branchName, :sourceIdentifier, :gSCode, :gCCode, :lastModifiedSystemDate, :nDCode, :marketName, :dealerActiveFlag, :dealerGroup, :dealerRolloutFlag, :batchInd, :createDate, :changedDate, :cRMCompanyCode, :lastUpdateDt, :lastUpdateUser, :lastUpdateTxId)";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String updateEObjXRetailerSql = "update XRETAILER set RETAILER_CODE = :retailerCode, RETAILER_NAME = :retailerName, BRANCH_NAME = :branchName, SOURCE_IDENT_TP_CD = :sourceIdentifier, GS_CODE = :gSCode, GC_CODE = :gCCode, MODIFY_SYS_DT = :lastModifiedSystemDate, ND_CODE = :nDCode, MARKET_NAME = :marketName, DEALER_ACTIVE_FLAG = :dealerActiveFlag, DEALER_GROUP = :dealerGroup, DEALER_ROLLOUT_FLAG = :dealerRolloutFlag, BATCH_IND = :batchInd, CREATE_DT = :createDate, CHANGED_DT = :changedDate, CRM_COMPANY_CODE = :cRMCompanyCode, LAST_UPDATE_DT = :lastUpdateDt, LAST_UPDATE_USER = :lastUpdateUser, LAST_UPDATE_TX_ID = :lastUpdateTxId where RETAILERPK_ID = :retailerpkId and LAST_UPDATE_DT = :oldLastUpdateDt";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String deleteEObjXRetailerSql = "delete from XRETAILER where RETAILERPK_ID = ?";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXRetailerKeyField = "EObjXRetailer.retailerpkId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXRetailerGetFields =
    "EObjXRetailer.retailerpkId," +
    "EObjXRetailer.retailerCode," +
    "EObjXRetailer.retailerName," +
    "EObjXRetailer.branchName," +
    "EObjXRetailer.sourceIdentifier," +
    "EObjXRetailer.gSCode," +
    "EObjXRetailer.gCCode," +
    "EObjXRetailer.lastModifiedSystemDate," +
    "EObjXRetailer.nDCode," +
    "EObjXRetailer.marketName," +
    "EObjXRetailer.dealerActiveFlag," +
    "EObjXRetailer.dealerGroup," +
    "EObjXRetailer.dealerRolloutFlag," +
    "EObjXRetailer.batchInd," +
    "EObjXRetailer.createDate," +
    "EObjXRetailer.changedDate," +
    "EObjXRetailer.cRMCompanyCode," +
    "EObjXRetailer.lastUpdateDt," +
    "EObjXRetailer.lastUpdateUser," +
    "EObjXRetailer.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXRetailerAllFields =
    "com.ibm.daimler.dsea.entityObject.EObjXRetailer.retailerpkId," +
    "com.ibm.daimler.dsea.entityObject.EObjXRetailer.retailerCode," +
    "com.ibm.daimler.dsea.entityObject.EObjXRetailer.retailerName," +
    "com.ibm.daimler.dsea.entityObject.EObjXRetailer.branchName," +
    "com.ibm.daimler.dsea.entityObject.EObjXRetailer.sourceIdentifier," +
    "com.ibm.daimler.dsea.entityObject.EObjXRetailer.gSCode," +
    "com.ibm.daimler.dsea.entityObject.EObjXRetailer.gCCode," +
    "com.ibm.daimler.dsea.entityObject.EObjXRetailer.lastModifiedSystemDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXRetailer.nDCode," +
    "com.ibm.daimler.dsea.entityObject.EObjXRetailer.marketName," +
    "com.ibm.daimler.dsea.entityObject.EObjXRetailer.dealerActiveFlag," +
    "com.ibm.daimler.dsea.entityObject.EObjXRetailer.dealerGroup," +
    "com.ibm.daimler.dsea.entityObject.EObjXRetailer.dealerRolloutFlag," +
    "com.ibm.daimler.dsea.entityObject.EObjXRetailer.batchInd," +
    "com.ibm.daimler.dsea.entityObject.EObjXRetailer.createDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXRetailer.changedDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXRetailer.cRMCompanyCode," +
    "com.ibm.daimler.dsea.entityObject.EObjXRetailer.lastUpdateDt," +
    "com.ibm.daimler.dsea.entityObject.EObjXRetailer.lastUpdateUser," +
    "com.ibm.daimler.dsea.entityObject.EObjXRetailer.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXRetailerUpdateFields =
    "com.ibm.daimler.dsea.entityObject.EObjXRetailer.retailerCode," +
    "com.ibm.daimler.dsea.entityObject.EObjXRetailer.retailerName," +
    "com.ibm.daimler.dsea.entityObject.EObjXRetailer.branchName," +
    "com.ibm.daimler.dsea.entityObject.EObjXRetailer.sourceIdentifier," +
    "com.ibm.daimler.dsea.entityObject.EObjXRetailer.gSCode," +
    "com.ibm.daimler.dsea.entityObject.EObjXRetailer.gCCode," +
    "com.ibm.daimler.dsea.entityObject.EObjXRetailer.lastModifiedSystemDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXRetailer.nDCode," +
    "com.ibm.daimler.dsea.entityObject.EObjXRetailer.marketName," +
    "com.ibm.daimler.dsea.entityObject.EObjXRetailer.dealerActiveFlag," +
    "com.ibm.daimler.dsea.entityObject.EObjXRetailer.dealerGroup," +
    "com.ibm.daimler.dsea.entityObject.EObjXRetailer.dealerRolloutFlag," +
    "com.ibm.daimler.dsea.entityObject.EObjXRetailer.batchInd," +
    "com.ibm.daimler.dsea.entityObject.EObjXRetailer.createDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXRetailer.changedDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXRetailer.cRMCompanyCode," +
    "com.ibm.daimler.dsea.entityObject.EObjXRetailer.lastUpdateDt," +
    "com.ibm.daimler.dsea.entityObject.EObjXRetailer.lastUpdateUser," +
    "com.ibm.daimler.dsea.entityObject.EObjXRetailer.lastUpdateTxId," +
    "com.ibm.daimler.dsea.entityObject.EObjXRetailer.retailerpkId," +
    "com.ibm.daimler.dsea.entityObject.EObjXRetailer.oldLastUpdateDt";   

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Select XRetailer by parameters.
   * @generated
   */
  @Select(sql=getEObjXRetailerSql)
  @EntityMapping(parameters=EObjXRetailerKeyField, results=EObjXRetailerGetFields)
  Iterator<EObjXRetailer> getEObjXRetailer(Long retailerpkId);  
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Create XRetailer by EObjXRetailer Object.
   * @generated
   */
  @Update(sql=createEObjXRetailerSql)
  @EntityMapping(parameters=EObjXRetailerAllFields)
    int createEObjXRetailer(EObjXRetailer e); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Update one XRetailer by EObjXRetailer object.
   * @generated
   */
  @Update(sql=updateEObjXRetailerSql)
  @EntityMapping(parameters=EObjXRetailerUpdateFields)
    int updateEObjXRetailer(EObjXRetailer e); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Delete XRetailer by parameters.
   * @generated
   */
  @Update(sql=deleteEObjXRetailerSql)
  @EntityMapping(parameters=EObjXRetailerKeyField)
  int deleteEObjXRetailer(Long retailerpkId);

}

