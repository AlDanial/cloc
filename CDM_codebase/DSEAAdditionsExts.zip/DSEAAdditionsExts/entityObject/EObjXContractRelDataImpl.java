package com.ibm.daimler.dsea.entityObject;

import com.ibm.pdq.runtime.generator.BaseParameterHandler;
import com.ibm.daimler.dsea.entityObject.EObjXContractRel;
import java.util.Iterator;
import java.sql.PreparedStatement;
import com.ibm.pdq.runtime.statement.StatementDescriptor;
import com.ibm.pdq.runtime.generator.BaseData;
import java.sql.SQLException;
import com.ibm.pdq.annotation.Metadata;
import com.ibm.pdq.runtime.generator.BaseRowHandler;
import com.ibm.pdq.runtime.statement.SqlStatementType;
import java.sql.Types;


/**
 * <!-- begin-user-doc -->
 * 
 * <!-- end-user-doc -->
 * 
 * @generated
 */
public class EObjXContractRelDataImpl  extends BaseData implements EObjXContractRelData
{

  /**
   * @generated
   */
  public static final String generatorVersion = "3.200.75";

  /**
   * @generated
   */
  public static final String identifier = "EObjXContractRelData";

  /**
   * @generated
   */
  public static final long generationTime = 0x000001635e65ffceL;

  /**
   * @generated
   */
  public static final String collection = "NULLID";

  /**
   * @generated
   */
  public static final String packageVersion = null;

  /**
   * @generated
   */
  public static final boolean forceSingleBindIsolation = false;

  /**
   * @generated
   */
  public EObjXContractRelDataImpl()
  {
    super();
  } 

  /**
   * @generated
   */
  public String getGeneratorVersion()
  {
    return generatorVersion;
  }

  /**
   * @Select( sql="select XContract_Relpk_Id, Contract_Id, Cont_Id, Market, Person_Org_Code, Contract_Role, Start_Date, End_Date, X_BPID, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from XCONTRACTREL where XContract_Relpk_Id = ? " )
   * 
   * @generated
   */
  public Iterator<EObjXContractRel> getEObjXContractRel (Long xContractRelpkId)
  {
    return queryIterator (getEObjXContractRelStatementDescriptor, xContractRelpkId);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getEObjXContractRelStatementDescriptor = createStatementDescriptor (
    "getEObjXContractRel(Long)",
    "select XContract_Relpk_Id, Contract_Id, Cont_Id, Market, Person_Org_Code, Contract_Role, Start_Date, End_Date, X_BPID, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from XCONTRACTREL where XContract_Relpk_Id = ? ",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"xcontract_relpk_id", "contract_id", "cont_id", "market", "person_org_code", "contract_role", "start_date", "end_date", "x_bpid", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetEObjXContractRelParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetEObjXContractRelRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 19, 19, 250, 1, 250, 0, 0, 50, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    1);

  /**
   * @generated
   */
  public static class GetEObjXContractRelParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setLong (stmt, 1, Types.BIGINT, (Long)parameters[0]);
    }
  }

  /**
   * @generated
   */
  public static class GetEObjXContractRelRowHandler extends BaseRowHandler<EObjXContractRel>
  {
    /**
     * @generated
     */
    public EObjXContractRel handle (java.sql.ResultSet rs, EObjXContractRel returnObject) throws java.sql.SQLException
    {
      returnObject = new EObjXContractRel ();
      returnObject.setXContractRelpkId(getLongObject (rs, 1)); 
      returnObject.setContractId(getLongObject (rs, 2)); 
      returnObject.setContId(getLongObject (rs, 3)); 
      returnObject.setMarket(getString (rs, 4)); 
      returnObject.setPersonOrgCode(getString (rs, 5)); 
      returnObject.setContractRole(getString (rs, 6)); 
      returnObject.setStartDate(getTimestamp (rs, 7)); 
      returnObject.setEndDate(getTimestamp (rs, 8)); 
      returnObject.setX_BPID(getString (rs, 9)); 
      returnObject.setLastUpdateDt(getTimestamp (rs, 10)); 
      returnObject.setLastUpdateUser(getString (rs, 11)); 
      returnObject.setLastUpdateTxId(getLongObject (rs, 12)); 
    
      return returnObject;
    }
  }

  /**
   * @Update( sql="insert into XCONTRACTREL (XContract_Relpk_Id, Contract_Id, Cont_Id, Market, Person_Org_Code, Contract_Role, Start_Date, End_Date, X_BPID, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( :xContractRelpkId, :contractId, :contId, :market, :personOrgCode, :contractRole, :startDate, :endDate, :x_BPID, :lastUpdateDt, :lastUpdateUser, :lastUpdateTxId)" )
   * 
   * @generated
   */
  public int createEObjXContractRel (EObjXContractRel e)
  {
    return update (createEObjXContractRelStatementDescriptor, e);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor createEObjXContractRelStatementDescriptor = createStatementDescriptor (
    "createEObjXContractRel(com.ibm.daimler.dsea.entityObject.EObjXContractRel)",
    "insert into XCONTRACTREL (XContract_Relpk_Id, Contract_Id, Cont_Id, Market, Person_Org_Code, Contract_Role, Start_Date, End_Date, X_BPID, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values(  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? )",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.INSERT,
    null,
    new CreateEObjXContractRelParameterHandler (),
    new int[][]{{Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 19, 19, 250, 1, 250, 0, 0, 50, 0, 0, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    2);

  /**
   * @generated
   */
  public static class CreateEObjXContractRelParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      EObjXContractRel bean0 = (EObjXContractRel) parameters[0];
      setLong (stmt, 1, Types.BIGINT, (Long)bean0.getXContractRelpkId());
      setLong (stmt, 2, Types.BIGINT, (Long)bean0.getContractId());
      setLong (stmt, 3, Types.BIGINT, (Long)bean0.getContId());
      setString (stmt, 4, Types.VARCHAR, (String)bean0.getMarket());
      setString (stmt, 5, Types.VARCHAR, (String)bean0.getPersonOrgCode());
      setString (stmt, 6, Types.VARCHAR, (String)bean0.getContractRole());
      setTimestamp (stmt, 7, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getStartDate());
      setTimestamp (stmt, 8, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getEndDate());
      setString (stmt, 9, Types.VARCHAR, (String)bean0.getX_BPID());
      setTimestamp (stmt, 10, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUpdateDt());
      setString (stmt, 11, Types.VARCHAR, (String)bean0.getLastUpdateUser());
      setLong (stmt, 12, Types.BIGINT, (Long)bean0.getLastUpdateTxId());
    }
  }

  /**
   * @Update( sql="update XCONTRACTREL set Contract_Id = :contractId, Cont_Id = :contId, Market = :market, Person_Org_Code = :personOrgCode, Contract_Role = :contractRole, Start_Date = :startDate, End_Date = :endDate, X_BPID = :x_BPID, LAST_UPDATE_DT = :lastUpdateDt, LAST_UPDATE_USER = :lastUpdateUser, LAST_UPDATE_TX_ID = :lastUpdateTxId where XContract_Relpk_Id = :xContractRelpkId and LAST_UPDATE_DT = :oldLastUpdateDt" )
   * 
   * @generated
   */
  public int updateEObjXContractRel (EObjXContractRel e)
  {
    return update (updateEObjXContractRelStatementDescriptor, e);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor updateEObjXContractRelStatementDescriptor = createStatementDescriptor (
    "updateEObjXContractRel(com.ibm.daimler.dsea.entityObject.EObjXContractRel)",
    "update XCONTRACTREL set Contract_Id =  ? , Cont_Id =  ? , Market =  ? , Person_Org_Code =  ? , Contract_Role =  ? , Start_Date =  ? , End_Date =  ? , X_BPID =  ? , LAST_UPDATE_DT =  ? , LAST_UPDATE_USER =  ? , LAST_UPDATE_TX_ID =  ?  where XContract_Relpk_Id =  ?  and LAST_UPDATE_DT =  ? ",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.UPDATE,
    null,
    new UpdateEObjXContractRelParameterHandler (),
    new int[][]{{Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP}, {19, 19, 250, 1, 250, 0, 0, 50, 0, 0, 19, 19, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    3);

  /**
   * @generated
   */
  public static class UpdateEObjXContractRelParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      EObjXContractRel bean0 = (EObjXContractRel) parameters[0];
      setLong (stmt, 1, Types.BIGINT, (Long)bean0.getContractId());
      setLong (stmt, 2, Types.BIGINT, (Long)bean0.getContId());
      setString (stmt, 3, Types.VARCHAR, (String)bean0.getMarket());
      setString (stmt, 4, Types.VARCHAR, (String)bean0.getPersonOrgCode());
      setString (stmt, 5, Types.VARCHAR, (String)bean0.getContractRole());
      setTimestamp (stmt, 6, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getStartDate());
      setTimestamp (stmt, 7, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getEndDate());
      setString (stmt, 8, Types.VARCHAR, (String)bean0.getX_BPID());
      setTimestamp (stmt, 9, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUpdateDt());
      setString (stmt, 10, Types.VARCHAR, (String)bean0.getLastUpdateUser());
      setLong (stmt, 11, Types.BIGINT, (Long)bean0.getLastUpdateTxId());
      setLong (stmt, 12, Types.BIGINT, (Long)bean0.getXContractRelpkId());
      setTimestamp (stmt, 13, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getOldLastUpdateDt());
    }
  }

  /**
   * @Update( sql="delete from XCONTRACTREL where XContract_Relpk_Id = ?" )
   * 
   * @generated
   */
  public int deleteEObjXContractRel (Long xContractRelpkId)
  {
    return update (deleteEObjXContractRelStatementDescriptor, xContractRelpkId);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor deleteEObjXContractRelStatementDescriptor = createStatementDescriptor (
    "deleteEObjXContractRel(Long)",
    "delete from XCONTRACTREL where XContract_Relpk_Id = ?",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.DELETE,
    null,
    new DeleteEObjXContractRelParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    4);

  /**
   * @generated
   */
  public static class DeleteEObjXContractRelParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setLong (stmt, 1, Types.BIGINT, (Long)parameters[0]);
    }
  }

}
