/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[736899ff90d697533591e4ca24f61ac3]
 */


package com.ibm.daimler.dsea.entityObject;

import java.util.Iterator;
import com.ibm.mdm.base.db.EntityMapping;
import com.ibm.pdq.annotation.Select;
import com.ibm.pdq.annotation.Update;

import com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRoleAus;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * @generated
 */
public interface EObjXCustomerVehicleRoleAusData {


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjXCustomerVehicleRoleAusSql = "select XCustomer_Role_Auspk_Id, CUSTOMER_VEHICLE_ID, VEHICLE_ROLE_TP_CD, VEHICLE_REL_ST_TP_CD, START_DT, END_DT, SOURCE_IDENT_TP_CD, MODIFY_SYS_DT, XCustomer_Vehicle_Aus_Referenc, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from XCUSTOMERVEHICLEROLEAUS where XCustomer_Role_Auspk_Id = ? ";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String createEObjXCustomerVehicleRoleAusSql = "insert into XCUSTOMERVEHICLEROLEAUS (XCustomer_Role_Auspk_Id, CUSTOMER_VEHICLE_ID, VEHICLE_ROLE_TP_CD, VEHICLE_REL_ST_TP_CD, START_DT, END_DT, SOURCE_IDENT_TP_CD, MODIFY_SYS_DT, XCustomer_Vehicle_Aus_Referenc, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( :xCustomerRoleAuspkId, :customerVehicleId, :vehicleRole, :vehicleRelStatus, :startDate, :endDate, :sourceIdentifier, :lastModifiedSystemDate, :xCustomerVehicleAusReference, :lastUpdateDt, :lastUpdateUser, :lastUpdateTxId)";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String updateEObjXCustomerVehicleRoleAusSql = "update XCUSTOMERVEHICLEROLEAUS set CUSTOMER_VEHICLE_ID = :customerVehicleId, VEHICLE_ROLE_TP_CD = :vehicleRole, VEHICLE_REL_ST_TP_CD = :vehicleRelStatus, START_DT = :startDate, END_DT = :endDate, SOURCE_IDENT_TP_CD = :sourceIdentifier, MODIFY_SYS_DT = :lastModifiedSystemDate, XCustomer_Vehicle_Aus_Referenc = :xCustomerVehicleAusReference, LAST_UPDATE_DT = :lastUpdateDt, LAST_UPDATE_USER = :lastUpdateUser, LAST_UPDATE_TX_ID = :lastUpdateTxId where XCustomer_Role_Auspk_Id = :xCustomerRoleAuspkId and LAST_UPDATE_DT = :oldLastUpdateDt";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String deleteEObjXCustomerVehicleRoleAusSql = "delete from XCUSTOMERVEHICLEROLEAUS where XCustomer_Role_Auspk_Id = ?";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXCustomerVehicleRoleAusKeyField = "EObjXCustomerVehicleRoleAus.xCustomerRoleAuspkId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXCustomerVehicleRoleAusGetFields =
    "EObjXCustomerVehicleRoleAus.xCustomerRoleAuspkId," +
    "EObjXCustomerVehicleRoleAus.customerVehicleId," +
    "EObjXCustomerVehicleRoleAus.vehicleRole," +
    "EObjXCustomerVehicleRoleAus.vehicleRelStatus," +
    "EObjXCustomerVehicleRoleAus.startDate," +
    "EObjXCustomerVehicleRoleAus.endDate," +
    "EObjXCustomerVehicleRoleAus.sourceIdentifier," +
    "EObjXCustomerVehicleRoleAus.lastModifiedSystemDate," +
    "EObjXCustomerVehicleRoleAus.xCustomerVehicleAusReference," +
    "EObjXCustomerVehicleRoleAus.lastUpdateDt," +
    "EObjXCustomerVehicleRoleAus.lastUpdateUser," +
    "EObjXCustomerVehicleRoleAus.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXCustomerVehicleRoleAusAllFields =
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRoleAus.xCustomerRoleAuspkId," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRoleAus.customerVehicleId," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRoleAus.vehicleRole," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRoleAus.vehicleRelStatus," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRoleAus.startDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRoleAus.endDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRoleAus.sourceIdentifier," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRoleAus.lastModifiedSystemDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRoleAus.xCustomerVehicleAusReference," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRoleAus.lastUpdateDt," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRoleAus.lastUpdateUser," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRoleAus.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXCustomerVehicleRoleAusUpdateFields =
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRoleAus.customerVehicleId," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRoleAus.vehicleRole," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRoleAus.vehicleRelStatus," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRoleAus.startDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRoleAus.endDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRoleAus.sourceIdentifier," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRoleAus.lastModifiedSystemDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRoleAus.xCustomerVehicleAusReference," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRoleAus.lastUpdateDt," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRoleAus.lastUpdateUser," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRoleAus.lastUpdateTxId," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRoleAus.xCustomerRoleAuspkId," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRoleAus.oldLastUpdateDt";   

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Select XCustomerVehicleRoleAus by parameters.
   * @generated
   */
  @Select(sql=getEObjXCustomerVehicleRoleAusSql)
  @EntityMapping(parameters=EObjXCustomerVehicleRoleAusKeyField, results=EObjXCustomerVehicleRoleAusGetFields)
  Iterator<EObjXCustomerVehicleRoleAus> getEObjXCustomerVehicleRoleAus(Long xCustomerRoleAuspkId);  
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Create XCustomerVehicleRoleAus by EObjXCustomerVehicleRoleAus Object.
   * @generated
   */
  @Update(sql=createEObjXCustomerVehicleRoleAusSql)
  @EntityMapping(parameters=EObjXCustomerVehicleRoleAusAllFields)
    int createEObjXCustomerVehicleRoleAus(EObjXCustomerVehicleRoleAus e); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Update one XCustomerVehicleRoleAus by EObjXCustomerVehicleRoleAus object.
   * @generated
   */
  @Update(sql=updateEObjXCustomerVehicleRoleAusSql)
  @EntityMapping(parameters=EObjXCustomerVehicleRoleAusUpdateFields)
    int updateEObjXCustomerVehicleRoleAus(EObjXCustomerVehicleRoleAus e); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Delete XCustomerVehicleRoleAus by parameters.
   * @generated
   */
  @Update(sql=deleteEObjXCustomerVehicleRoleAusSql)
  @EntityMapping(parameters=EObjXCustomerVehicleRoleAusKeyField)
  int deleteEObjXCustomerVehicleRoleAus(Long xCustomerRoleAuspkId);

}

