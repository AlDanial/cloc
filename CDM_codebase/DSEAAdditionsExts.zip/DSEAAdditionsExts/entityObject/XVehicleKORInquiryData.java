/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[ce3dc2d5886456af7ed6365eb5edafea]
 */

package com.ibm.daimler.dsea.entityObject;


import com.ibm.mdm.base.db.ResultQueue1;
import java.util.Iterator;
import com.ibm.mdm.base.db.EntityMapping;
import com.ibm.pdq.annotation.Select;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * @generated
 */
public interface XVehicleKORInquiryData {
  
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String tableAliasString = "tableAlias (" + 
                                            "XVEHICLEKOR => com.ibm.daimler.dsea.entityObject.EObjXVehicleKOR, " +
                                            "H_XVEHICLEKOR => com.ibm.daimler.dsea.entityObject.EObjXVehicleKOR" +
                                            ")";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getXVehicleKORSql = "SELECT r.XVehicle_KORpk_Id XVehicle_KORpk_Id, r.Global_VIN Global_VIN, r.BAU_MUSTER BAU_MUSTER, r.TYPE_CLASS TYPE_CLASS, r.SUB_MUSTER SUB_MUSTER, r.COLOR COLOR, r.TRIM TRIM, r.BATCH_IND BATCH_IND, r.MARKET_NAME MARKET_NAME, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.CREATE_DT CREATE_DT, r.CHANGED_DT CHANGED_DT, r.LAST_SERVICE_DT LAST_SERVICE_DT, r.SFDC_ID SFDC_ID, r.VEHICLE_ADDRESS_TYPE VEHICLE_ADDRESS_TYPE, r.VEHICLE_TYPE VEHICLE_TYPE, r.DELETE_FLAG DELETE_FLAG, r.END_DT END_DT, r.ENGINE_NUM ENGINE_NUM, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.Local_VIN Local_VIN, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XVEHICLEKOR r WHERE r.XVehicle_KORpk_Id = ? ";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXVehicleKORParameters =
    "EObjXVehicleKOR.XVehicleKORpkId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXVehicleKORResults =
    "EObjXVehicleKOR.XVehicleKORpkId," +
    "EObjXVehicleKOR.GlobalVIN," +
    "EObjXVehicleKOR.BauMuster," +
    "EObjXVehicleKOR.TypeClass," +
    "EObjXVehicleKOR.SubMuster," +
    "EObjXVehicleKOR.Color," +
    "EObjXVehicleKOR.Trim," +
    "EObjXVehicleKOR.BatchInd," +
    "EObjXVehicleKOR.MarketName," +
    "EObjXVehicleKOR.LastModifiedSystemDate," +
    "EObjXVehicleKOR.CreateDate," +
    "EObjXVehicleKOR.ChangedDate," +
    "EObjXVehicleKOR.LastServiceDate," +
    "EObjXVehicleKOR.SFDCId," +
    "EObjXVehicleKOR.VehicleAddressType," +
    "EObjXVehicleKOR.VehicleType," +
    "EObjXVehicleKOR.DeleteFlag," +
    "EObjXVehicleKOR.EndDate," +
    "EObjXVehicleKOR.EngineNumber," +
    "EObjXVehicleKOR.SourceIdentifier," +
    "EObjXVehicleKOR.LocalVIN," +
    "EObjXVehicleKOR.lastUpdateDt," +
    "EObjXVehicleKOR.lastUpdateUser," +
    "EObjXVehicleKOR.lastUpdateTxId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getXVehicleKORHistorySql = "SELECT r.H_XVehicle_KORpk_Id hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.XVehicle_KORpk_Id XVehicle_KORpk_Id, r.Global_VIN Global_VIN, r.BAU_MUSTER BAU_MUSTER, r.TYPE_CLASS TYPE_CLASS, r.SUB_MUSTER SUB_MUSTER, r.COLOR COLOR, r.TRIM TRIM, r.BATCH_IND BATCH_IND, r.MARKET_NAME MARKET_NAME, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.CREATE_DT CREATE_DT, r.CHANGED_DT CHANGED_DT, r.LAST_SERVICE_DT LAST_SERVICE_DT, r.SFDC_ID SFDC_ID, r.VEHICLE_ADDRESS_TYPE VEHICLE_ADDRESS_TYPE, r.VEHICLE_TYPE VEHICLE_TYPE, r.DELETE_FLAG DELETE_FLAG, r.END_DT END_DT, r.ENGINE_NUM ENGINE_NUM, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.Local_VIN Local_VIN, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XVEHICLEKOR r WHERE r.H_XVehicle_KORpk_Id = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXVehicleKORHistoryParameters =
    "EObjXVehicleKOR.XVehicleKORpkId," +
    "EObjXVehicleKOR.lastUpdateDt," +
    "EObjXVehicleKOR.lastUpdateDt";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXVehicleKORHistoryResults =
    "EObjXVehicleKOR.historyIdPK," +
    "EObjXVehicleKOR.histActionCode," +
    "EObjXVehicleKOR.histCreatedBy," +
    "EObjXVehicleKOR.histCreateDt," +
    "EObjXVehicleKOR.histEndDt," +
    "EObjXVehicleKOR.XVehicleKORpkId," +
    "EObjXVehicleKOR.GlobalVIN," +
    "EObjXVehicleKOR.BauMuster," +
    "EObjXVehicleKOR.TypeClass," +
    "EObjXVehicleKOR.SubMuster," +
    "EObjXVehicleKOR.Color," +
    "EObjXVehicleKOR.Trim," +
    "EObjXVehicleKOR.BatchInd," +
    "EObjXVehicleKOR.MarketName," +
    "EObjXVehicleKOR.LastModifiedSystemDate," +
    "EObjXVehicleKOR.CreateDate," +
    "EObjXVehicleKOR.ChangedDate," +
    "EObjXVehicleKOR.LastServiceDate," +
    "EObjXVehicleKOR.SFDCId," +
    "EObjXVehicleKOR.VehicleAddressType," +
    "EObjXVehicleKOR.VehicleType," +
    "EObjXVehicleKOR.DeleteFlag," +
    "EObjXVehicleKOR.EndDate," +
    "EObjXVehicleKOR.EngineNumber," +
    "EObjXVehicleKOR.SourceIdentifier," +
    "EObjXVehicleKOR.LocalVIN," +
    "EObjXVehicleKOR.lastUpdateDt," +
    "EObjXVehicleKOR.lastUpdateUser," +
    "EObjXVehicleKOR.lastUpdateTxId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getXVehicleKORByGlobalVINSql = "SELECT r.XVehicle_KORpk_Id XVehicle_KORpk_Id, r.Global_VIN Global_VIN, r.BAU_MUSTER BAU_MUSTER, r.TYPE_CLASS TYPE_CLASS, r.SUB_MUSTER SUB_MUSTER, r.COLOR COLOR, r.TRIM TRIM, r.BATCH_IND BATCH_IND, r.MARKET_NAME MARKET_NAME, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.CREATE_DT CREATE_DT, r.CHANGED_DT CHANGED_DT, r.LAST_SERVICE_DT LAST_SERVICE_DT, r.SFDC_ID SFDC_ID, r.VEHICLE_ADDRESS_TYPE VEHICLE_ADDRESS_TYPE, r.VEHICLE_TYPE VEHICLE_TYPE, r.DELETE_FLAG DELETE_FLAG, r.END_DT END_DT, r.ENGINE_NUM ENGINE_NUM, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.Local_VIN Local_VIN, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XVEHICLEKOR r WHERE r.Global_VIN = ? ";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXVehicleKORByGlobalVINParameters =
    "EObjXVehicleKOR.GlobalVIN";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXVehicleKORByGlobalVINResults =
    "EObjXVehicleKOR.XVehicleKORpkId," +
    "EObjXVehicleKOR.GlobalVIN," +
    "EObjXVehicleKOR.BauMuster," +
    "EObjXVehicleKOR.TypeClass," +
    "EObjXVehicleKOR.SubMuster," +
    "EObjXVehicleKOR.Color," +
    "EObjXVehicleKOR.Trim," +
    "EObjXVehicleKOR.BatchInd," +
    "EObjXVehicleKOR.MarketName," +
    "EObjXVehicleKOR.LastModifiedSystemDate," +
    "EObjXVehicleKOR.CreateDate," +
    "EObjXVehicleKOR.ChangedDate," +
    "EObjXVehicleKOR.LastServiceDate," +
    "EObjXVehicleKOR.SFDCId," +
    "EObjXVehicleKOR.VehicleAddressType," +
    "EObjXVehicleKOR.VehicleType," +
    "EObjXVehicleKOR.DeleteFlag," +
    "EObjXVehicleKOR.EndDate," +
    "EObjXVehicleKOR.EngineNumber," +
    "EObjXVehicleKOR.SourceIdentifier," +
    "EObjXVehicleKOR.LocalVIN," +
    "EObjXVehicleKOR.lastUpdateDt," +
    "EObjXVehicleKOR.lastUpdateUser," +
    "EObjXVehicleKOR.lastUpdateTxId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getXVehicleKORByGlobalVINHistorySql = "SELECT r.H_XVehicle_KORpk_Id hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.XVehicle_KORpk_Id XVehicle_KORpk_Id, r.Global_VIN Global_VIN, r.BAU_MUSTER BAU_MUSTER, r.TYPE_CLASS TYPE_CLASS, r.SUB_MUSTER SUB_MUSTER, r.COLOR COLOR, r.TRIM TRIM, r.BATCH_IND BATCH_IND, r.MARKET_NAME MARKET_NAME, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.CREATE_DT CREATE_DT, r.CHANGED_DT CHANGED_DT, r.LAST_SERVICE_DT LAST_SERVICE_DT, r.SFDC_ID SFDC_ID, r.VEHICLE_ADDRESS_TYPE VEHICLE_ADDRESS_TYPE, r.VEHICLE_TYPE VEHICLE_TYPE, r.DELETE_FLAG DELETE_FLAG, r.END_DT END_DT, r.ENGINE_NUM ENGINE_NUM, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.Local_VIN Local_VIN, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XVEHICLEKOR r WHERE r.Global_VIN = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXVehicleKORByGlobalVINHistoryParameters =
    "EObjXVehicleKOR.GlobalVIN," +
    "EObjXVehicleKOR.lastUpdateDt," +
    "EObjXVehicleKOR.lastUpdateDt";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXVehicleKORByGlobalVINHistoryResults =
    "EObjXVehicleKOR.historyIdPK," +
    "EObjXVehicleKOR.histActionCode," +
    "EObjXVehicleKOR.histCreatedBy," +
    "EObjXVehicleKOR.histCreateDt," +
    "EObjXVehicleKOR.histEndDt," +
    "EObjXVehicleKOR.XVehicleKORpkId," +
    "EObjXVehicleKOR.GlobalVIN," +
    "EObjXVehicleKOR.BauMuster," +
    "EObjXVehicleKOR.TypeClass," +
    "EObjXVehicleKOR.SubMuster," +
    "EObjXVehicleKOR.Color," +
    "EObjXVehicleKOR.Trim," +
    "EObjXVehicleKOR.BatchInd," +
    "EObjXVehicleKOR.MarketName," +
    "EObjXVehicleKOR.LastModifiedSystemDate," +
    "EObjXVehicleKOR.CreateDate," +
    "EObjXVehicleKOR.ChangedDate," +
    "EObjXVehicleKOR.LastServiceDate," +
    "EObjXVehicleKOR.SFDCId," +
    "EObjXVehicleKOR.VehicleAddressType," +
    "EObjXVehicleKOR.VehicleType," +
    "EObjXVehicleKOR.DeleteFlag," +
    "EObjXVehicleKOR.EndDate," +
    "EObjXVehicleKOR.EngineNumber," +
    "EObjXVehicleKOR.SourceIdentifier," +
    "EObjXVehicleKOR.LocalVIN," +
    "EObjXVehicleKOR.lastUpdateDt," +
    "EObjXVehicleKOR.lastUpdateUser," +
    "EObjXVehicleKOR.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getXVehicleKORSql, pattern=tableAliasString)
  @EntityMapping(parameters=getXVehicleKORParameters, results=getXVehicleKORResults)
  Iterator<ResultQueue1<EObjXVehicleKOR>> getXVehicleKOR(Object[] parameters);  


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getXVehicleKORHistorySql, pattern=tableAliasString)
  @EntityMapping(parameters=getXVehicleKORHistoryParameters, results=getXVehicleKORHistoryResults)
  Iterator<ResultQueue1<EObjXVehicleKOR>> getXVehicleKORHistory(Object[] parameters);  


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getXVehicleKORByGlobalVINSql, pattern=tableAliasString)
  @EntityMapping(parameters=getXVehicleKORByGlobalVINParameters, results=getXVehicleKORByGlobalVINResults)
  Iterator<ResultQueue1<EObjXVehicleKOR>> getXVehicleKORByGlobalVIN(Object[] parameters);  


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getXVehicleKORByGlobalVINHistorySql, pattern=tableAliasString)
  @EntityMapping(parameters=getXVehicleKORByGlobalVINHistoryParameters, results=getXVehicleKORByGlobalVINHistoryResults)
  Iterator<ResultQueue1<EObjXVehicleKOR>> getXVehicleKORByGlobalVINHistory(Object[] parameters);  


}


