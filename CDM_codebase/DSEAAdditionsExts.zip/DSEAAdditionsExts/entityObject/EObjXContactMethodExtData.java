/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[b2481d3a4fcadc82d440a8d1a7f563cc]
 */


package com.ibm.daimler.dsea.entityObject;

import java.util.Iterator;
import com.ibm.mdm.base.db.EntityMapping;
import com.ibm.pdq.annotation.Select;
import com.ibm.pdq.annotation.Update;

import com.dwl.tcrm.coreParty.entityObject.EObjContactMethod;

import com.ibm.daimler.dsea.entityObject.EObjXContactMethodExt;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * @generated
 */
public interface EObjXContactMethodExtData {


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjXContactMethodExtSql = "select PHONE_EXTENSION, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from CONTACTMETHOD where CONTACT_METHOD_ID = ? ";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String createEObjXContactMethodExtSql = "insert into CONTACTMETHOD (ADDRESS_ID, CONTACT_METHOD_ID, REF_NUM, CONT_METH_STD_IND, CONT_METH_CAT_CD, PHONE_EXTENSION, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( ?1.addressId, ?1.contactMethodIdPK, ?1.refNum, ?1.contMethStandardInd, ?1.contMethCatCd, ?2.phoneExtension, ?1.lastUpdateDt, ?1.lastUpdateUser, ?1.lastUpdateTxId)";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String updateEObjXContactMethodExtSql = "update CONTACTMETHOD set ADDRESS_ID = ?1.addressId, REF_NUM = ?1.refNum, CONT_METH_STD_IND = ?1.contMethStandardInd, CONT_METH_CAT_CD = ?1.contMethCatCd, PHONE_EXTENSION = ?2.phoneExtension, LAST_UPDATE_DT = ?1.lastUpdateDt, LAST_UPDATE_USER = ?1.lastUpdateUser, LAST_UPDATE_TX_ID = ?1.lastUpdateTxId where CONTACT_METHOD_ID = ?1.contactMethodIdPK and LAST_UPDATE_DT = ?1.oldLastUpdateDt";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String deleteEObjXContactMethodExtSql = "delete from CONTACTMETHOD where CONTACT_METHOD_ID = ?";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXContactMethodExtKeyField = "EObjXContactMethodExt.contactMethodIdPK";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXContactMethodExtGetFields =
    "EObjXContactMethodExt.phoneExtension," +
    "EObjXContactMethodExt.lastUpdateDt," +
    "EObjXContactMethodExt.lastUpdateUser," +
    "EObjXContactMethodExt.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXContactMethodExtAllFields =
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethod.addressId," +
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethod.contactMethodIdPK," +
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethod.refNum," +
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethod.contMethStandardInd," +
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethod.contMethCatCd," +
    "com.ibm.daimler.dsea.entityObject.EObjXContactMethodExt.phoneExtension," +
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethod.lastUpdateDt," +
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethod.lastUpdateUser," +
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethod.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXContactMethodExtUpdateFields =
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethod.addressId," +
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethod.refNum," +
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethod.contMethStandardInd," +
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethod.contMethCatCd," +
    "com.ibm.daimler.dsea.entityObject.EObjXContactMethodExt.phoneExtension," +
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethod.lastUpdateDt," +
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethod.lastUpdateUser," +
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethod.lastUpdateTxId," +
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethod.contactMethodIdPK," +
    "com.dwl.tcrm.coreParty.entityObject.EObjContactMethod.oldLastUpdateDt";   

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Select XContactMethod by parameters.
   * @generated
   */
  @Select(sql=getEObjXContactMethodExtSql)
  @EntityMapping(parameters=EObjXContactMethodExtKeyField, results=EObjXContactMethodExtGetFields)
  Iterator<EObjXContactMethodExt> getEObjXContactMethodExt(Long contactMethodIdPK);  
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Create XContactMethod by EObjXContactMethodExt Object.
   * @generated
   */
  @Update(sql=createEObjXContactMethodExtSql)
  @EntityMapping(parameters=EObjXContactMethodExtAllFields)
    int createEObjXContactMethodExt(EObjContactMethod e1, EObjXContactMethodExt e2); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Update one XContactMethod by EObjXContactMethodExt object.
   * @generated
   */
  @Update(sql=updateEObjXContactMethodExtSql)
  @EntityMapping(parameters=EObjXContactMethodExtUpdateFields)
    int updateEObjXContactMethodExt(EObjContactMethod e1, EObjXContactMethodExt e2); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Delete XContactMethod by parameters.
   * @generated
   */
  @Update(sql=deleteEObjXContactMethodExtSql)
  @EntityMapping(parameters=EObjXContactMethodExtKeyField)
  int deleteEObjXContactMethodExt(Long contactMethodIdPK);

}

