package com.ibm.daimler.dsea.entityObject;

import com.ibm.pdq.runtime.generator.BaseParameterHandler;
import java.util.Iterator;
import java.sql.PreparedStatement;
import com.ibm.pdq.runtime.statement.StatementDescriptor;
import com.ibm.pdq.runtime.generator.BaseData;
import java.sql.SQLException;
import com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleJPN;
import com.ibm.pdq.annotation.Metadata;
import com.ibm.pdq.runtime.generator.BaseRowHandler;
import com.ibm.pdq.runtime.statement.SqlStatementType;
import java.sql.Types;


/**
 * <!-- begin-user-doc -->
 * 
 * <!-- end-user-doc -->
 * 
 * @generated
 */
public class EObjXCustomerVehicleJPNDataImpl  extends BaseData implements EObjXCustomerVehicleJPNData
{

  /**
   * @generated
   */
  public static final String generatorVersion = "3.200.75";

  /**
   * @generated
   */
  public static final String identifier = "EObjXCustomerVehicleJPNData";

  /**
   * @generated
   */
  public static final long generationTime = 0x00000164c354c4a5L;

  /**
   * @generated
   */
  public static final String collection = "NULLID";

  /**
   * @generated
   */
  public static final String packageVersion = null;

  /**
   * @generated
   */
  public static final boolean forceSingleBindIsolation = false;

  /**
   * @generated
   */
  public EObjXCustomerVehicleJPNDataImpl()
  {
    super();
  } 

  /**
   * @generated
   */
  public String getGeneratorVersion()
  {
    return generatorVersion;
  }

  /**
   * @Select( sql="select XCustomer_Vehicle_JPNPK_ID, CONT_ID, VEHICLE_ID, RETAILER_ID, CONNECTME_USAGE_TP_CD, LICENSE_PLATE, VEHICLE_SALES_TP_CD, VEHICLE_USAGE_TP_CD, VEHICLE_OWNERSHIP, START_DT, END_DT, SOURCE_IDENT_TP_CD, CUSTVEHRET_FLAG, DELETE_FLAG, SFDC_ID, SERVICE_NAME, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from XCUSTOMERVEHICLEJPN where XCustomer_Vehicle_JPNPK_ID = ? " )
   * 
   * @generated
   */
  public Iterator<EObjXCustomerVehicleJPN> getEObjXCustomerVehicleJPN (Long xCustomerVehicleJPNpkId)
  {
    return queryIterator (getEObjXCustomerVehicleJPNStatementDescriptor, xCustomerVehicleJPNpkId);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getEObjXCustomerVehicleJPNStatementDescriptor = createStatementDescriptor (
    "getEObjXCustomerVehicleJPN(Long)",
    "select XCustomer_Vehicle_JPNPK_ID, CONT_ID, VEHICLE_ID, RETAILER_ID, CONNECTME_USAGE_TP_CD, LICENSE_PLATE, VEHICLE_SALES_TP_CD, VEHICLE_USAGE_TP_CD, VEHICLE_OWNERSHIP, START_DT, END_DT, SOURCE_IDENT_TP_CD, CUSTVEHRET_FLAG, DELETE_FLAG, SFDC_ID, SERVICE_NAME, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from XCUSTOMERVEHICLEJPN where XCustomer_Vehicle_JPNPK_ID = ? ",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"xcustomer_vehicle_jpnpk_id", "cont_id", "vehicle_id", "retailer_id", "connectme_usage_tp_cd", "license_plate", "vehicle_sales_tp_cd", "vehicle_usage_tp_cd", "vehicle_ownership", "start_dt", "end_dt", "source_ident_tp_cd", "custvehret_flag", "delete_flag", "sfdc_id", "service_name", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetEObjXCustomerVehicleJPNParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetEObjXCustomerVehicleJPNRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 19, 19, 19, 19, 20, 19, 19, 250, 0, 0, 19, 5, 10, 50, 120, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    1);

  /**
   * @generated
   */
  public static class GetEObjXCustomerVehicleJPNParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setLong (stmt, 1, Types.BIGINT, (Long)parameters[0]);
    }
  }

  /**
   * @generated
   */
  public static class GetEObjXCustomerVehicleJPNRowHandler extends BaseRowHandler<EObjXCustomerVehicleJPN>
  {
    /**
     * @generated
     */
    public EObjXCustomerVehicleJPN handle (java.sql.ResultSet rs, EObjXCustomerVehicleJPN returnObject) throws java.sql.SQLException
    {
      returnObject = new EObjXCustomerVehicleJPN ();
      returnObject.setXCustomerVehicleJPNpkId(getLongObject (rs, 1)); 
      returnObject.setContId(getLongObject (rs, 2)); 
      returnObject.setVehicleId(getLongObject (rs, 3)); 
      returnObject.setRetailerId(getLongObject (rs, 4)); 
      returnObject.setConnectMeUsage(getLongObject (rs, 5)); 
      returnObject.setLicensePlate(getString (rs, 6)); 
      returnObject.setVehicleSales(getLongObject (rs, 7)); 
      returnObject.setVehicleUsage(getLongObject (rs, 8)); 
      returnObject.setVehicleOwnerShip(getString (rs, 9)); 
      returnObject.setStartDate(getTimestamp (rs, 10)); 
      returnObject.setEndDate(getTimestamp (rs, 11)); 
      returnObject.setSourceIdentifier(getLongObject (rs, 12)); 
      returnObject.setCustVehRetFlag(getString (rs, 13)); 
      returnObject.setDeleteFlag(getString (rs, 14)); 
      returnObject.setSFDCId(getString (rs, 15)); 
      returnObject.setServiceName(getString (rs, 16)); 
      returnObject.setLastUpdateDt(getTimestamp (rs, 17)); 
      returnObject.setLastUpdateUser(getString (rs, 18)); 
      returnObject.setLastUpdateTxId(getLongObject (rs, 19)); 
    
      return returnObject;
    }
  }

  /**
   * @Update( sql="insert into XCUSTOMERVEHICLEJPN (XCustomer_Vehicle_JPNPK_ID, CONT_ID, VEHICLE_ID, RETAILER_ID, CONNECTME_USAGE_TP_CD, LICENSE_PLATE, VEHICLE_SALES_TP_CD, VEHICLE_USAGE_TP_CD, VEHICLE_OWNERSHIP, START_DT, END_DT, SOURCE_IDENT_TP_CD, CUSTVEHRET_FLAG, DELETE_FLAG, SFDC_ID, SERVICE_NAME, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( :xCustomerVehicleJPNpkId, :contId, :vehicleId, :retailerId, :connectMeUsage, :licensePlate, :vehicleSales, :vehicleUsage, :vehicleOwnerShip, :startDate, :endDate, :sourceIdentifier, :custVehRetFlag, :deleteFlag, :sFDCId, :serviceName, :lastUpdateDt, :lastUpdateUser, :lastUpdateTxId)" )
   * 
   * @generated
   */
  public int createEObjXCustomerVehicleJPN (EObjXCustomerVehicleJPN e)
  {
    return update (createEObjXCustomerVehicleJPNStatementDescriptor, e);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor createEObjXCustomerVehicleJPNStatementDescriptor = createStatementDescriptor (
    "createEObjXCustomerVehicleJPN(com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleJPN)",
    "insert into XCUSTOMERVEHICLEJPN (XCustomer_Vehicle_JPNPK_ID, CONT_ID, VEHICLE_ID, RETAILER_ID, CONNECTME_USAGE_TP_CD, LICENSE_PLATE, VEHICLE_SALES_TP_CD, VEHICLE_USAGE_TP_CD, VEHICLE_OWNERSHIP, START_DT, END_DT, SOURCE_IDENT_TP_CD, CUSTVEHRET_FLAG, DELETE_FLAG, SFDC_ID, SERVICE_NAME, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values(  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? )",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.INSERT,
    null,
    new CreateEObjXCustomerVehicleJPNParameterHandler (),
    new int[][]{{Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 19, 19, 19, 19, 20, 19, 19, 250, 0, 0, 19, 5, 10, 50, 120, 0, 0, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    2);

  /**
   * @generated
   */
  public static class CreateEObjXCustomerVehicleJPNParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      EObjXCustomerVehicleJPN bean0 = (EObjXCustomerVehicleJPN) parameters[0];
      setLong (stmt, 1, Types.BIGINT, (Long)bean0.getXCustomerVehicleJPNpkId());
      setLong (stmt, 2, Types.BIGINT, (Long)bean0.getContId());
      setLong (stmt, 3, Types.BIGINT, (Long)bean0.getVehicleId());
      setLong (stmt, 4, Types.BIGINT, (Long)bean0.getRetailerId());
      setLong (stmt, 5, Types.BIGINT, (Long)bean0.getConnectMeUsage());
      setString (stmt, 6, Types.VARCHAR, (String)bean0.getLicensePlate());
      setLong (stmt, 7, Types.BIGINT, (Long)bean0.getVehicleSales());
      setLong (stmt, 8, Types.BIGINT, (Long)bean0.getVehicleUsage());
      setString (stmt, 9, Types.VARCHAR, (String)bean0.getVehicleOwnerShip());
      setTimestamp (stmt, 10, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getStartDate());
      setTimestamp (stmt, 11, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getEndDate());
      setLong (stmt, 12, Types.BIGINT, (Long)bean0.getSourceIdentifier());
      setString (stmt, 13, Types.VARCHAR, (String)bean0.getCustVehRetFlag());
      setString (stmt, 14, Types.VARCHAR, (String)bean0.getDeleteFlag());
      setString (stmt, 15, Types.VARCHAR, (String)bean0.getSFDCId());
      setString (stmt, 16, Types.VARCHAR, (String)bean0.getServiceName());
      setTimestamp (stmt, 17, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUpdateDt());
      setString (stmt, 18, Types.VARCHAR, (String)bean0.getLastUpdateUser());
      setLong (stmt, 19, Types.BIGINT, (Long)bean0.getLastUpdateTxId());
    }
  }

  /**
   * @Update( sql="update XCUSTOMERVEHICLEJPN set CONT_ID = :contId, VEHICLE_ID = :vehicleId, RETAILER_ID = :retailerId, CONNECTME_USAGE_TP_CD = :connectMeUsage, LICENSE_PLATE = :licensePlate, VEHICLE_SALES_TP_CD = :vehicleSales, VEHICLE_USAGE_TP_CD = :vehicleUsage, VEHICLE_OWNERSHIP = :vehicleOwnerShip, START_DT = :startDate, END_DT = :endDate, SOURCE_IDENT_TP_CD = :sourceIdentifier, CUSTVEHRET_FLAG = :custVehRetFlag, DELETE_FLAG = :deleteFlag, SFDC_ID = :sFDCId, SERVICE_NAME = :serviceName, LAST_UPDATE_DT = :lastUpdateDt, LAST_UPDATE_USER = :lastUpdateUser, LAST_UPDATE_TX_ID = :lastUpdateTxId where XCustomer_Vehicle_JPNPK_ID = :xCustomerVehicleJPNpkId and LAST_UPDATE_DT = :oldLastUpdateDt" )
   * 
   * @generated
   */
  public int updateEObjXCustomerVehicleJPN (EObjXCustomerVehicleJPN e)
  {
    return update (updateEObjXCustomerVehicleJPNStatementDescriptor, e);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor updateEObjXCustomerVehicleJPNStatementDescriptor = createStatementDescriptor (
    "updateEObjXCustomerVehicleJPN(com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleJPN)",
    "update XCUSTOMERVEHICLEJPN set CONT_ID =  ? , VEHICLE_ID =  ? , RETAILER_ID =  ? , CONNECTME_USAGE_TP_CD =  ? , LICENSE_PLATE =  ? , VEHICLE_SALES_TP_CD =  ? , VEHICLE_USAGE_TP_CD =  ? , VEHICLE_OWNERSHIP =  ? , START_DT =  ? , END_DT =  ? , SOURCE_IDENT_TP_CD =  ? , CUSTVEHRET_FLAG =  ? , DELETE_FLAG =  ? , SFDC_ID =  ? , SERVICE_NAME =  ? , LAST_UPDATE_DT =  ? , LAST_UPDATE_USER =  ? , LAST_UPDATE_TX_ID =  ?  where XCustomer_Vehicle_JPNPK_ID =  ?  and LAST_UPDATE_DT =  ? ",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.UPDATE,
    null,
    new UpdateEObjXCustomerVehicleJPNParameterHandler (),
    new int[][]{{Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP}, {19, 19, 19, 19, 20, 19, 19, 250, 0, 0, 19, 5, 10, 50, 120, 0, 0, 19, 19, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    3);

  /**
   * @generated
   */
  public static class UpdateEObjXCustomerVehicleJPNParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      EObjXCustomerVehicleJPN bean0 = (EObjXCustomerVehicleJPN) parameters[0];
      setLong (stmt, 1, Types.BIGINT, (Long)bean0.getContId());
      setLong (stmt, 2, Types.BIGINT, (Long)bean0.getVehicleId());
      setLong (stmt, 3, Types.BIGINT, (Long)bean0.getRetailerId());
      setLong (stmt, 4, Types.BIGINT, (Long)bean0.getConnectMeUsage());
      setString (stmt, 5, Types.VARCHAR, (String)bean0.getLicensePlate());
      setLong (stmt, 6, Types.BIGINT, (Long)bean0.getVehicleSales());
      setLong (stmt, 7, Types.BIGINT, (Long)bean0.getVehicleUsage());
      setString (stmt, 8, Types.VARCHAR, (String)bean0.getVehicleOwnerShip());
      setTimestamp (stmt, 9, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getStartDate());
      setTimestamp (stmt, 10, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getEndDate());
      setLong (stmt, 11, Types.BIGINT, (Long)bean0.getSourceIdentifier());
      setString (stmt, 12, Types.VARCHAR, (String)bean0.getCustVehRetFlag());
      setString (stmt, 13, Types.VARCHAR, (String)bean0.getDeleteFlag());
      setString (stmt, 14, Types.VARCHAR, (String)bean0.getSFDCId());
      setString (stmt, 15, Types.VARCHAR, (String)bean0.getServiceName());
      setTimestamp (stmt, 16, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUpdateDt());
      setString (stmt, 17, Types.VARCHAR, (String)bean0.getLastUpdateUser());
      setLong (stmt, 18, Types.BIGINT, (Long)bean0.getLastUpdateTxId());
      setLong (stmt, 19, Types.BIGINT, (Long)bean0.getXCustomerVehicleJPNpkId());
      setTimestamp (stmt, 20, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getOldLastUpdateDt());
    }
  }

  /**
   * @Update( sql="delete from XCUSTOMERVEHICLEJPN where XCustomer_Vehicle_JPNPK_ID = ?" )
   * 
   * @generated
   */
  public int deleteEObjXCustomerVehicleJPN (Long xCustomerVehicleJPNpkId)
  {
    return update (deleteEObjXCustomerVehicleJPNStatementDescriptor, xCustomerVehicleJPNpkId);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor deleteEObjXCustomerVehicleJPNStatementDescriptor = createStatementDescriptor (
    "deleteEObjXCustomerVehicleJPN(Long)",
    "delete from XCUSTOMERVEHICLEJPN where XCustomer_Vehicle_JPNPK_ID = ?",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.DELETE,
    null,
    new DeleteEObjXCustomerVehicleJPNParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    4);

  /**
   * @generated
   */
  public static class DeleteEObjXCustomerVehicleJPNParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setLong (stmt, 1, Types.BIGINT, (Long)parameters[0]);
    }
  }

}
