/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[e6737a60e1297259101b5fbbc644d9a1]
 */


package com.ibm.daimler.dsea.entityObject;

import java.util.Iterator;
import com.ibm.mdm.base.db.EntityMapping;
import com.ibm.pdq.annotation.Select;
import com.ibm.pdq.annotation.Update;

import com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRoleKOR;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * @generated
 */
public interface EObjXCustomerVehicleRoleKORData {


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjXCustomerVehicleRoleKORSql = "select XCUSTOMERVEHICLEROLEKORPK_ID, CUSTOMER_VEHICLE_ID, VEHICLE_ROLE_TP_CD, START_DT, END_DT, SOURCE_IDENT_TP_CD, CHANGED_DT, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from XCUSTOMERVEHICLEROLEKOR where XCUSTOMERVEHICLEROLEKORPK_ID = ? ";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String createEObjXCustomerVehicleRoleKORSql = "insert into XCUSTOMERVEHICLEROLEKOR (XCUSTOMERVEHICLEROLEKORPK_ID, CUSTOMER_VEHICLE_ID, VEHICLE_ROLE_TP_CD, START_DT, END_DT, SOURCE_IDENT_TP_CD, CHANGED_DT, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( :xCustomerVehicleRoleKORpkId, :customerVehicleId, :vehicleRole, :startDate, :endDate, :sourceIdentifier, :changedDate, :lastUpdateDt, :lastUpdateUser, :lastUpdateTxId)";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String updateEObjXCustomerVehicleRoleKORSql = "update XCUSTOMERVEHICLEROLEKOR set CUSTOMER_VEHICLE_ID = :customerVehicleId, VEHICLE_ROLE_TP_CD = :vehicleRole, START_DT = :startDate, END_DT = :endDate, SOURCE_IDENT_TP_CD = :sourceIdentifier, CHANGED_DT = :changedDate, LAST_UPDATE_DT = :lastUpdateDt, LAST_UPDATE_USER = :lastUpdateUser, LAST_UPDATE_TX_ID = :lastUpdateTxId where XCUSTOMERVEHICLEROLEKORPK_ID = :xCustomerVehicleRoleKORpkId and LAST_UPDATE_DT = :oldLastUpdateDt";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String deleteEObjXCustomerVehicleRoleKORSql = "delete from XCUSTOMERVEHICLEROLEKOR where XCUSTOMERVEHICLEROLEKORPK_ID = ?";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXCustomerVehicleRoleKORKeyField = "EObjXCustomerVehicleRoleKOR.xCustomerVehicleRoleKORpkId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXCustomerVehicleRoleKORGetFields =
    "EObjXCustomerVehicleRoleKOR.xCustomerVehicleRoleKORpkId," +
    "EObjXCustomerVehicleRoleKOR.customerVehicleId," +
    "EObjXCustomerVehicleRoleKOR.vehicleRole," +
    "EObjXCustomerVehicleRoleKOR.startDate," +
    "EObjXCustomerVehicleRoleKOR.endDate," +
    "EObjXCustomerVehicleRoleKOR.sourceIdentifier," +
    "EObjXCustomerVehicleRoleKOR.changedDate," +
    "EObjXCustomerVehicleRoleKOR.lastUpdateDt," +
    "EObjXCustomerVehicleRoleKOR.lastUpdateUser," +
    "EObjXCustomerVehicleRoleKOR.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXCustomerVehicleRoleKORAllFields =
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRoleKOR.xCustomerVehicleRoleKORpkId," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRoleKOR.customerVehicleId," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRoleKOR.vehicleRole," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRoleKOR.startDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRoleKOR.endDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRoleKOR.sourceIdentifier," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRoleKOR.changedDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRoleKOR.lastUpdateDt," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRoleKOR.lastUpdateUser," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRoleKOR.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXCustomerVehicleRoleKORUpdateFields =
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRoleKOR.customerVehicleId," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRoleKOR.vehicleRole," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRoleKOR.startDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRoleKOR.endDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRoleKOR.sourceIdentifier," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRoleKOR.changedDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRoleKOR.lastUpdateDt," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRoleKOR.lastUpdateUser," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRoleKOR.lastUpdateTxId," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRoleKOR.xCustomerVehicleRoleKORpkId," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRoleKOR.oldLastUpdateDt";   

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Select XCustomerVehicleRoleKOR by parameters.
   * @generated
   */
  @Select(sql=getEObjXCustomerVehicleRoleKORSql)
  @EntityMapping(parameters=EObjXCustomerVehicleRoleKORKeyField, results=EObjXCustomerVehicleRoleKORGetFields)
  Iterator<EObjXCustomerVehicleRoleKOR> getEObjXCustomerVehicleRoleKOR(Long xCustomerVehicleRoleKORpkId);  
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Create XCustomerVehicleRoleKOR by EObjXCustomerVehicleRoleKOR Object.
   * @generated
   */
  @Update(sql=createEObjXCustomerVehicleRoleKORSql)
  @EntityMapping(parameters=EObjXCustomerVehicleRoleKORAllFields)
    int createEObjXCustomerVehicleRoleKOR(EObjXCustomerVehicleRoleKOR e); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Update one XCustomerVehicleRoleKOR by EObjXCustomerVehicleRoleKOR object.
   * @generated
   */
  @Update(sql=updateEObjXCustomerVehicleRoleKORSql)
  @EntityMapping(parameters=EObjXCustomerVehicleRoleKORUpdateFields)
    int updateEObjXCustomerVehicleRoleKOR(EObjXCustomerVehicleRoleKOR e); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Delete XCustomerVehicleRoleKOR by parameters.
   * @generated
   */
  @Update(sql=deleteEObjXCustomerVehicleRoleKORSql)
  @EntityMapping(parameters=EObjXCustomerVehicleRoleKORKeyField)
  int deleteEObjXCustomerVehicleRoleKOR(Long xCustomerVehicleRoleKORpkId);

}

