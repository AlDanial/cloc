/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[09ec24b26a1b570a554ec8044de2a1e0]
 */

package com.ibm.daimler.dsea.entityObject;

import com.dwl.base.EObjCommon;
import com.ibm.mdm.base.db.DataType;
import com.ibm.pdq.annotation.Column;
import com.ibm.pdq.annotation.Table;


import com.ibm.pdq.annotation.Id;

import java.sql.Timestamp;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * The entity object corresponding to the XCustomerVehicleKOR business object.
 * This entity object should include all the attributes as defined by the
 * business object.
 * 
 * @generated
 */
@SuppressWarnings("serial")
@Table(name=EObjXCustomerVehicleKOR.tableName)
public class EObjXCustomerVehicleKOR extends EObjCommon {

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public static final String tableName = "XCUSTOMERVEHICLEKOR";
    
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
//    private static final String groupNameColumn = "GROUP_NAME";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
   /* private static final String groupNameJdbcType = "VARCHAR";
    *//**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     *//*
    private static final int    groupNamePrecision = 250;
    *//**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String xCustomerVehicleKORpkIdColumn = "XCUSTOMER_VEHICLE_KORPK_ID";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String xCustomerVehicleKORpkIdJdbcType = "BIGINT";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    xCustomerVehicleKORpkIdPrecision = 19;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String contIdColumn = "CONT_ID";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String contIdJdbcType = "BIGINT";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    contIdPrecision = 19;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String vehicleIdColumn = "VEHICLE_ID";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String vehicleIdJdbcType = "BIGINT";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    vehicleIdPrecision = 19;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String retailerIdColumn = "RETAILER_ID";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String retailerIdJdbcType = "BIGINT";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    retailerIdPrecision = 19;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String connectMeUsageColumn = "CONNECTME_USAGE_TP_CD";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String connectMeUsageJdbcType = "BIGINT";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    connectMeUsagePrecision = 19;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String licensePlateColumn = "LICENSE_PLATE";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String licensePlateJdbcType = "VARCHAR";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    licensePlatePrecision = 20;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String vehicleSalesColumn = "VEHICLE_SALES_TP_CD";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String vehicleSalesJdbcType = "BIGINT";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    vehicleSalesPrecision = 19;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String vehicleUsageColumn = "VEHICLE_USAGE_TP_CD";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String vehicleUsageJdbcType = "BIGINT";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    vehicleUsagePrecision = 19;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String vehicleOwnerShipColumn = "VEHICLE_OWNERSHIP";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String vehicleOwnerShipJdbcType = "VARCHAR";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    vehicleOwnerShipPrecision = 250;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String startDateColumn = "START_DT";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String startDateJdbcType = "TIMESTAMP";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String endDateColumn = "END_DT";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String endDateJdbcType = "TIMESTAMP";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String sourceIdentifierColumn = "SOURCE_IDENT_TP_CD";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String sourceIdentifierJdbcType = "BIGINT";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    sourceIdentifierPrecision = 19;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String custVehRetFlagColumn = "CUSTVEHRET_FLAG";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String custVehRetFlagJdbcType = "VARCHAR";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    custVehRetFlagPrecision = 5;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String deleteFlagColumn = "DELETE_FLAG";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String deleteFlagJdbcType = "VARCHAR";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    deleteFlagPrecision = 10;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String sFDCIdColumn = "SFDC_ID";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String sFDCIdJdbcType = "VARCHAR";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    sFDCIdPrecision = 50;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String serviceNameColumn = "SERVICE_NAME";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String serviceNameJdbcType = "VARCHAR";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    serviceNamePrecision = 120;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
//    protected String groupName;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected Long xCustomerVehicleKORpkId;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected Long contId;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected Long vehicleId;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected Long retailerId;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected Long connectMeUsage;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String licensePlate;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected Long vehicleSales;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected Long vehicleUsage;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String vehicleOwnerShip;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected  Timestamp startDate;
    //inside if 

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected  Timestamp endDate;
    //inside if 

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected Long sourceIdentifier;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String custVehRetFlag;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String deleteFlag;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String sFDCId;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String serviceName;



    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Default constructor.     
     *
     * @generated
     */
    public EObjXCustomerVehicleKOR() {
        super();
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the groupName attribute. 
     *
     * @generated not
     */
    /*@Column(name=groupNameColumn)
    @DataType(jdbcType=groupNameJdbcType, precision=groupNamePrecision)
    public String getGroupName (){
        return groupName;
    }*/
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the groupName attribute. 
     *
     * @param groupName
     *     The new value of groupName. 
     * @generated not
     */
   /* public void setGroupName( String groupName ){
        this.groupName = groupName;
		
	}*/
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xCustomerVehicleKORpkId attribute. 
     *
     * @generated
     */
    @Id
    @Column(name=xCustomerVehicleKORpkIdColumn)
    @DataType(jdbcType=xCustomerVehicleKORpkIdJdbcType, precision=xCustomerVehicleKORpkIdPrecision)
    public Long getXCustomerVehicleKORpkId (){
        return xCustomerVehicleKORpkId;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xCustomerVehicleKORpkId attribute. 
     *
     * @param xCustomerVehicleKORpkId
     *     The new value of XCustomerVehicleKORpkId. 
     * @generated
     */
    public void setXCustomerVehicleKORpkId( Long xCustomerVehicleKORpkId ){
        this.xCustomerVehicleKORpkId = xCustomerVehicleKORpkId;
    
        super.setIdPK(xCustomerVehicleKORpkId);
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the contId attribute. 
     *
     * @generated
     */
    @Column(name=contIdColumn)
    @DataType(jdbcType=contIdJdbcType, precision=contIdPrecision)
    public Long getContId (){
        return contId;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the contId attribute. 
     *
     * @param contId
     *     The new value of ContId. 
     * @generated
     */
    public void setContId( Long contId ){
        this.contId = contId;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the vehicleId attribute. 
     *
     * @generated
     */
    @Column(name=vehicleIdColumn)
    @DataType(jdbcType=vehicleIdJdbcType, precision=vehicleIdPrecision)
    public Long getVehicleId (){
        return vehicleId;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the vehicleId attribute. 
     *
     * @param vehicleId
     *     The new value of VehicleId. 
     * @generated
     */
    public void setVehicleId( Long vehicleId ){
        this.vehicleId = vehicleId;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the retailerId attribute. 
     *
     * @generated
     */
    @Column(name=retailerIdColumn)
    @DataType(jdbcType=retailerIdJdbcType, precision=retailerIdPrecision)
    public Long getRetailerId (){
        return retailerId;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the retailerId attribute. 
     *
     * @param retailerId
     *     The new value of RetailerId. 
     * @generated
     */
    public void setRetailerId( Long retailerId ){
        this.retailerId = retailerId;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the connectMeUsage attribute. 
     *
     * @generated
     */
    @Column(name=connectMeUsageColumn)
    @DataType(jdbcType=connectMeUsageJdbcType, precision=connectMeUsagePrecision)
    public Long getConnectMeUsage (){
        return connectMeUsage;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the connectMeUsage attribute. 
     *
     * @param connectMeUsage
     *     The new value of ConnectMeUsage. 
     * @generated
     */
    public void setConnectMeUsage( Long connectMeUsage ){
        this.connectMeUsage = connectMeUsage;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the licensePlate attribute. 
     *
     * @generated
     */
    @Column(name=licensePlateColumn)
    @DataType(jdbcType=licensePlateJdbcType, precision=licensePlatePrecision)
    public String getLicensePlate (){
        return licensePlate;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the licensePlate attribute. 
     *
     * @param licensePlate
     *     The new value of LicensePlate. 
     * @generated
     */
    public void setLicensePlate( String licensePlate ){
        this.licensePlate = licensePlate;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the vehicleSales attribute. 
     *
     * @generated
     */
    @Column(name=vehicleSalesColumn)
    @DataType(jdbcType=vehicleSalesJdbcType, precision=vehicleSalesPrecision)
    public Long getVehicleSales (){
        return vehicleSales;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the vehicleSales attribute. 
     *
     * @param vehicleSales
     *     The new value of VehicleSales. 
     * @generated
     */
    public void setVehicleSales( Long vehicleSales ){
        this.vehicleSales = vehicleSales;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the vehicleUsage attribute. 
     *
     * @generated
     */
    @Column(name=vehicleUsageColumn)
    @DataType(jdbcType=vehicleUsageJdbcType, precision=vehicleUsagePrecision)
    public Long getVehicleUsage (){
        return vehicleUsage;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the vehicleUsage attribute. 
     *
     * @param vehicleUsage
     *     The new value of VehicleUsage. 
     * @generated
     */
    public void setVehicleUsage( Long vehicleUsage ){
        this.vehicleUsage = vehicleUsage;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the vehicleOwnerShip attribute. 
     *
     * @generated
     */
    @Column(name=vehicleOwnerShipColumn)
    @DataType(jdbcType=vehicleOwnerShipJdbcType, precision=vehicleOwnerShipPrecision)
    public String getVehicleOwnerShip (){
        return vehicleOwnerShip;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the vehicleOwnerShip attribute. 
     *
     * @param vehicleOwnerShip
     *     The new value of VehicleOwnerShip. 
     * @generated
     */
    public void setVehicleOwnerShip( String vehicleOwnerShip ){
        this.vehicleOwnerShip = vehicleOwnerShip;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the startDate attribute. 
     *
     * @generated
     */
    @Column(name=startDateColumn)
    @DataType(jdbcType=startDateJdbcType)
    public Timestamp getStartDate (){
        return startDate;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the startDate attribute. 
     *
     * @param startDate
     *     The new value of StartDate. 
     * @generated
     */
    public void setStartDate( Timestamp startDate ){
        this.startDate = startDate;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the endDate attribute. 
     *
     * @generated
     */
    @Column(name=endDateColumn)
    @DataType(jdbcType=endDateJdbcType)
    public Timestamp getEndDate (){
        return endDate;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the endDate attribute. 
     *
     * @param endDate
     *     The new value of EndDate. 
     * @generated
     */
    public void setEndDate( Timestamp endDate ){
        this.endDate = endDate;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the sourceIdentifier attribute. 
     *
     * @generated
     */
    @Column(name=sourceIdentifierColumn)
    @DataType(jdbcType=sourceIdentifierJdbcType, precision=sourceIdentifierPrecision)
    public Long getSourceIdentifier (){
        return sourceIdentifier;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the sourceIdentifier attribute. 
     *
     * @param sourceIdentifier
     *     The new value of SourceIdentifier. 
     * @generated
     */
    public void setSourceIdentifier( Long sourceIdentifier ){
        this.sourceIdentifier = sourceIdentifier;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the custVehRetFlag attribute. 
     *
     * @generated
     */
    @Column(name=custVehRetFlagColumn)
    @DataType(jdbcType=custVehRetFlagJdbcType, precision=custVehRetFlagPrecision)
    public String getCustVehRetFlag (){
        return custVehRetFlag;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the custVehRetFlag attribute. 
     *
     * @param custVehRetFlag
     *     The new value of CustVehRetFlag. 
     * @generated
     */
    public void setCustVehRetFlag( String custVehRetFlag ){
        this.custVehRetFlag = custVehRetFlag;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the deleteFlag attribute. 
     *
     * @generated
     */
    @Column(name=deleteFlagColumn)
    @DataType(jdbcType=deleteFlagJdbcType, precision=deleteFlagPrecision)
    public String getDeleteFlag (){
        return deleteFlag;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the deleteFlag attribute. 
     *
     * @param deleteFlag
     *     The new value of DeleteFlag. 
     * @generated
     */
    public void setDeleteFlag( String deleteFlag ){
        this.deleteFlag = deleteFlag;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the sFDCId attribute. 
     *
     * @generated
     */
    @Column(name=sFDCIdColumn)
    @DataType(jdbcType=sFDCIdJdbcType, precision=sFDCIdPrecision)
    public String getSFDCId (){
        return sFDCId;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the sFDCId attribute. 
     *
     * @param sFDCId
     *     The new value of SFDCId. 
     * @generated
     */
    public void setSFDCId( String sFDCId ){
        this.sFDCId = sFDCId;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the serviceName attribute. 
     *
     * @generated
     */
    @Column(name=serviceNameColumn)
    @DataType(jdbcType=serviceNameJdbcType, precision=serviceNamePrecision)
    public String getServiceName (){
        return serviceName;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the serviceName attribute. 
     *
     * @param serviceName
     *     The new value of ServiceName. 
     * @generated
     */
    public void setServiceName( String serviceName ){
        this.serviceName = serviceName;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the primary key. 
     *
     * @param aUniqueId
     *     The new value of the primary key. 
     * @generated
   */
	public void setPrimaryKey(Object aUniqueId) {
    this.setXCustomerVehicleKORpkId((Long)aUniqueId);
  }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the primary key.
     *
     * @generated
     */
	public Object getPrimaryKey() {
    return this.getXCustomerVehicleKORpkId();
  }
	 
}


