package com.ibm.daimler.dsea.entityObject;

import com.ibm.pdq.runtime.generator.BaseParameterHandler;
import java.util.Iterator;
import com.ibm.mdm.base.db.ResultQueue1;
import com.ibm.daimler.dsea.entityObject.EObjXContractExt;
import java.sql.PreparedStatement;
import com.ibm.pdq.runtime.statement.StatementDescriptor;
import com.ibm.pdq.runtime.generator.BaseData;
import java.sql.SQLException;
import com.ibm.pdq.annotation.Metadata;
import com.ibm.mdm.base.db.ResultQueue2;
import com.dwl.tcrm.financial.entityObject.EObjContract;
import com.ibm.pdq.runtime.generator.BaseRowHandler;
import com.ibm.pdq.runtime.statement.SqlStatementType;
import java.sql.Types;


@SuppressWarnings("unchecked")

/**
 * <!-- begin-user-doc -->
 * 
 * <!-- end-user-doc -->
 * 
 * @generated
 */
public class XContractExtInquiryDataImpl  extends BaseData implements XContractExtInquiryData
{

  /**
   * @generated
   */
  public static final String generatorVersion = "3.200.75";

  /**
   * @generated
   */
  public static final String identifier = "XContractExtInquiryData";

  /**
   * @generated
   */
  public static final long generationTime = 0x0000015de99d17d9L;

  /**
   * @generated
   */
  public static final String collection = "NULLID";

  /**
   * @generated
   */
  public static final String packageVersion = null;

  /**
   * @generated
   */
  public static final boolean forceSingleBindIsolation = false;

  /**
   * @generated
   */
  public XContractExtInquiryDataImpl()
  {
    super();
  } 

  /**
   * @generated
   */
  public String getGeneratorVersion()
  {
    return generatorVersion;
  }

  /**
   * @Select( sql="SELECT DISTINCT A.H_CONTRACT_ID AS HIST_ID_PK , A.H_ACTION_CODE , A.H_CREATED_BY , A.H_CREATE_DT , A.H_END_DT , A.CONTRACT_ID , A.CURRENCY_TP_CD , A.FREQ_MODE_TP_CD , A.CONTR_LANG_TP_CD , A.LINE_OF_BUSINESS , A.BILL_TP_CD , A.REPL_BY_CONTRACT , A.PREMIUM_AMT , A.PREMAMT_CUR_TP , A.NEXT_BILL_DT , A.CURR_CASH_VAL_AMT , A.CASHVAL_CUR_TP , A.BRAND_NAME , A.SERVICE_ORG_NAME , A.BUS_ORGUNIT_ID , A.LAST_UPDATE_DT , A.LAST_UPDATE_USER , A.SERVICE_PROV_ID , A.LAST_UPDATE_TX_ID , A.ISSUE_LOCATION , A.MANAGED_ACCOUNT_IND , A.AGREEMENT_NAME , A.AGREEMENT_NICKNAME , A.SIGNED_DT , A.EXECUTED_DT , A.END_DT , A.REPLACES_CONTRACT , A.ACCOUNT_LAST_TRANSACTION_DT , A.TERMINATION_DT , A.TERMINATION_REASON_TP_CD , A.AGREEMENT_DESCRIPTION , A.AGREEMENT_ST_TP_CD , A.AGREEMENT_TP_CD , A.SERVICE_LEVEL_TP_CD , A.LAST_VERIFIED_DT , A.LAST_REVIEWED_DT , A.PRODUCT_ID , A.ADMIN_CONTRACT_ID , A.ADMIN_SYS_TP_CD , A.ACCESS_TOKEN_VALUE , A.CLUSTER_KEY, A.XCONTRACT_NUM FROM H_CONTRACT A WHERE A.H_CONTRACT_ID = ? AND (( ? BETWEEN A.H_CREATE_DT AND A.H_END_DT ) OR ( ? >= A.H_CREATE_DT AND A.H_END_DT IS NULL ))", pattern="tableAlias (CONTRACT => com.dwl.tcrm.financial.entityObject.EObjContract, H_CONTRACT => com.dwl.tcrm.financial.entityObject.EObjContract , CONTRACT => com.ibm.daimler.dsea.entityObject.EObjXContractExt , H_CONTRACT => com.ibm.daimler.dsea.entityObject.EObjXContractExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue2<EObjContract,EObjXContractExt>> getEObjCONTRACT_HISTORY (Object[] parameters)
  {
    return queryIterator (getEObjCONTRACT_HISTORYStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getEObjCONTRACT_HISTORYStatementDescriptor = createStatementDescriptor (
    "getEObjCONTRACT_HISTORY(Object[])",
    "SELECT DISTINCT A.H_CONTRACT_ID AS HIST_ID_PK , A.H_ACTION_CODE , A.H_CREATED_BY , A.H_CREATE_DT , A.H_END_DT , A.CONTRACT_ID , A.CURRENCY_TP_CD , A.FREQ_MODE_TP_CD , A.CONTR_LANG_TP_CD , A.LINE_OF_BUSINESS , A.BILL_TP_CD , A.REPL_BY_CONTRACT , A.PREMIUM_AMT , A.PREMAMT_CUR_TP , A.NEXT_BILL_DT , A.CURR_CASH_VAL_AMT , A.CASHVAL_CUR_TP , A.BRAND_NAME , A.SERVICE_ORG_NAME , A.BUS_ORGUNIT_ID , A.LAST_UPDATE_DT , A.LAST_UPDATE_USER , A.SERVICE_PROV_ID , A.LAST_UPDATE_TX_ID , A.ISSUE_LOCATION , A.MANAGED_ACCOUNT_IND , A.AGREEMENT_NAME , A.AGREEMENT_NICKNAME , A.SIGNED_DT , A.EXECUTED_DT , A.END_DT , A.REPLACES_CONTRACT , A.ACCOUNT_LAST_TRANSACTION_DT , A.TERMINATION_DT , A.TERMINATION_REASON_TP_CD , A.AGREEMENT_DESCRIPTION , A.AGREEMENT_ST_TP_CD , A.AGREEMENT_TP_CD , A.SERVICE_LEVEL_TP_CD , A.LAST_VERIFIED_DT , A.LAST_REVIEWED_DT , A.PRODUCT_ID , A.ADMIN_CONTRACT_ID , A.ADMIN_SYS_TP_CD , A.ACCESS_TOKEN_VALUE , A.CLUSTER_KEY, A.XCONTRACT_NUM FROM H_CONTRACT A WHERE A.H_CONTRACT_ID = ? AND (( ? BETWEEN A.H_CREATE_DT AND A.H_END_DT ) OR ( ? >= A.H_CREATE_DT AND A.H_END_DT IS NULL ))",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"hist_id_pk", "h_action_code", "h_created_by", "h_create_dt", "h_end_dt", "contract_id", "currency_tp_cd", "freq_mode_tp_cd", "contr_lang_tp_cd", "line_of_business", "bill_tp_cd", "repl_by_contract", "premium_amt", "premamt_cur_tp", "next_bill_dt", "curr_cash_val_amt", "cashval_cur_tp", "brand_name", "service_org_name", "bus_orgunit_id", "last_update_dt", "last_update_user", "service_prov_id", "last_update_tx_id", "issue_location", "managed_account_ind", "agreement_name", "agreement_nickname", "signed_dt", "executed_dt", "end_dt", "replaces_contract", "account_last_transaction_dt", "termination_dt", "termination_reason_tp_cd", "agreement_description", "agreement_st_tp_cd", "agreement_tp_cd", "service_level_tp_cd", "last_verified_dt", "last_reviewed_dt", "product_id", "admin_contract_id", "admin_sys_tp_cd", "access_token_value", "cluster_key", "xcontract_num"},
    new GetEObjCONTRACT_HISTORYParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP}, {19, 0, 0}, {0, 0, 0}, {1, 1, 1}},
    null,
    new GetEObjCONTRACT_HISTORYRowHandler (),
    new int[][]{ {Types.BIGINT, Types.CHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.DECIMAL, Types.BIGINT, Types.TIMESTAMP, Types.DECIMAL, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.CHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.VARCHAR}, {19, 1, 20, 0, 0, 19, 19, 19, 19, 30, 19, 19, 17, 19, 0, 17, 19, 30, 70, 30, 0, 20, 30, 19, 30, 1, 120, 120, 0, 0, 0, 19, 0, 0, 19, 250, 19, 19, 19, 0, 0, 19, 150, 19, 50, 19, 50}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    1);

  /**
   * @generated
   */
  public static class GetEObjCONTRACT_HISTORYParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetEObjCONTRACT_HISTORYRowHandler extends BaseRowHandler<ResultQueue2<EObjContract,EObjXContractExt>>
  {
    /**
     * @generated
     */
    public ResultQueue2<EObjContract,EObjXContractExt> handle (java.sql.ResultSet rs, ResultQueue2<EObjContract,EObjXContractExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue2<EObjContract,EObjXContractExt> ();

      EObjContract returnObject1 = new EObjContract ();
      returnObject1.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject1.setHistActionCode(getString (rs, 2)); 
      returnObject1.setHistCreatedBy(getString (rs, 3)); 
      returnObject1.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject1.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject1.setContractIdPK(getLongObject (rs, 6)); 
      returnObject1.setCurrencyTpCd(getLongObject (rs, 7)); 
      returnObject1.setFreqModeTpCd(getLongObject (rs, 8)); 
      returnObject1.setContrLangTpCd(getLongObject (rs, 9)); 
      returnObject1.setLineOfBusiness(getString (rs, 10)); 
      returnObject1.setBillTpCd(getLongObject (rs, 11)); 
      returnObject1.setReplByContract(getLongObject (rs, 12)); 
      returnObject1.setPremiumAmt(getBigDecimal (rs, 13)); 
      returnObject1.setPremiumAmtCurTpCd(getLongObject (rs, 14)); 
      returnObject1.setNextBillDt(getTimestamp (rs, 15)); 
      returnObject1.setCurrCashValAmt(getBigDecimal (rs, 16)); 
      returnObject1.setCurrCashValAmtCurTpCd(getLongObject (rs, 17)); 
      returnObject1.setBrandName(getString (rs, 18)); 
      returnObject1.setServiceOrgName(getString (rs, 19)); 
      returnObject1.setBusOrgunitId(getString (rs, 20)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 21)); 
      returnObject1.setLastUpdateUser(getString (rs, 22)); 
      returnObject1.setServiceProvId(getString (rs, 23)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 24)); 
      returnObject1.setIssueLocation(getString (rs, 25)); 
      returnObject1.setManagedAccountIndicator(getString (rs, 26)); 
      returnObject1.setAgreementName(getString (rs, 27)); 
      returnObject1.setAgreementNickName(getString (rs, 28)); 
      returnObject1.setSignedDate(getTimestamp (rs, 29)); 
      returnObject1.setExecutedDate(getTimestamp (rs, 30)); 
      returnObject1.setEndDate(getTimestamp (rs, 31)); 
      returnObject1.setReplacesContract(getLongObject (rs, 32)); 
      returnObject1.setAccountLastTransactionDate(getTimestamp (rs, 33)); 
      returnObject1.setTerminationDate(getTimestamp (rs, 34)); 
      returnObject1.setTerminationReasonType(getLongObject (rs, 35)); 
      returnObject1.setAgreementDescription(getString (rs, 36)); 
      returnObject1.setAgreementStatusType(getLongObject (rs, 37)); 
      returnObject1.setAgreementType(getLongObject (rs, 38)); 
      returnObject1.setServiceLevelType(getLongObject (rs, 39)); 
      returnObject1.setLastVerifiedDate(getTimestamp (rs, 40)); 
      returnObject1.setLastReviewedDate(getTimestamp (rs, 41)); 
      returnObject1.setProductId(getLongObject (rs, 42)); 
      returnObject1.setAdminContractId(getString (rs, 43)); 
      returnObject1.setAdminSysTpCd(getLongObject (rs, 44)); 
      returnObject1.setAccessTokenValue(getString (rs, 45)); 
      returnObject1.setClusterKey(getLongObject (rs, 46)); 
      returnObject.add (returnObject1);

      EObjXContractExt returnObject2 = new EObjXContractExt ();
      returnObject2.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject2.setHistActionCode(getString (rs, 2)); 
      returnObject2.setHistCreatedBy(getString (rs, 3)); 
      returnObject2.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject2.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject2.setLastUpdateDt(getTimestamp (rs, 21)); 
      returnObject2.setLastUpdateUser(getString (rs, 22)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 24)); 
      returnObject2.setXContractNum(getString (rs, 47)); 
      returnObject.add (returnObject2);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT CONTRACT.CONTRACT_ID , CONTRACT.CURRENCY_TP_CD , CONTRACT.FREQ_MODE_TP_CD , CONTRACT.CONTR_LANG_TP_CD , CONTRACT.LINE_OF_BUSINESS , CONTRACT.BILL_TP_CD , CONTRACT.REPL_BY_CONTRACT , CONTRACT.PREMIUM_AMT , CONTRACT.PREMAMT_CUR_TP , CONTRACT.NEXT_BILL_DT , CONTRACT.CURR_CASH_VAL_AMT , CONTRACT.CASHVAL_CUR_TP , CONTRACT.BRAND_NAME , CONTRACT.SERVICE_ORG_NAME , CONTRACT.BUS_ORGUNIT_ID , CONTRACT.LAST_UPDATE_DT , CONTRACT.LAST_UPDATE_USER , CONTRACT.SERVICE_PROV_ID , CONTRACT.LAST_UPDATE_TX_ID , CONTRACT.ISSUE_LOCATION , CONTRACT.MANAGED_ACCOUNT_IND , CONTRACT.AGREEMENT_NAME , CONTRACT.AGREEMENT_NICKNAME , CONTRACT.SIGNED_DT , CONTRACT.EXECUTED_DT , CONTRACT.END_DT , CONTRACT.REPLACES_CONTRACT , CONTRACT.ACCOUNT_LAST_TRANSACTION_DT , CONTRACT.TERMINATION_DT , CONTRACT.TERMINATION_REASON_TP_CD , CONTRACT.AGREEMENT_DESCRIPTION , CONTRACT.AGREEMENT_ST_TP_CD , CONTRACT.AGREEMENT_TP_CD , CONTRACT.SERVICE_LEVEL_TP_CD , CONTRACT.LAST_VERIFIED_DT , CONTRACT.LAST_REVIEWED_DT , CONTRACT.PRODUCT_ID , CONTRACT.ADMIN_CONTRACT_ID , CONTRACT.ADMIN_SYS_TP_CD , CONTRACT.ACCESS_TOKEN_VALUE , CONTRACT.CLUSTER_KEY, CONTRACT.XCONTRACT_NUM FROM CONTRACT WHERE CONTRACT.CONTRACT_ID = ?", pattern="tableAlias (CONTRACT => com.dwl.tcrm.financial.entityObject.EObjContract, H_CONTRACT => com.dwl.tcrm.financial.entityObject.EObjContract , CONTRACT => com.ibm.daimler.dsea.entityObject.EObjXContractExt , H_CONTRACT => com.ibm.daimler.dsea.entityObject.EObjXContractExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue2<EObjContract,EObjXContractExt>> getEObjCONTRACT (Object[] parameters)
  {
    return queryIterator (getEObjCONTRACTStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getEObjCONTRACTStatementDescriptor = createStatementDescriptor (
    "getEObjCONTRACT(Object[])",
    "SELECT CONTRACT.CONTRACT_ID , CONTRACT.CURRENCY_TP_CD , CONTRACT.FREQ_MODE_TP_CD , CONTRACT.CONTR_LANG_TP_CD , CONTRACT.LINE_OF_BUSINESS , CONTRACT.BILL_TP_CD , CONTRACT.REPL_BY_CONTRACT , CONTRACT.PREMIUM_AMT , CONTRACT.PREMAMT_CUR_TP , CONTRACT.NEXT_BILL_DT , CONTRACT.CURR_CASH_VAL_AMT , CONTRACT.CASHVAL_CUR_TP , CONTRACT.BRAND_NAME , CONTRACT.SERVICE_ORG_NAME , CONTRACT.BUS_ORGUNIT_ID , CONTRACT.LAST_UPDATE_DT , CONTRACT.LAST_UPDATE_USER , CONTRACT.SERVICE_PROV_ID , CONTRACT.LAST_UPDATE_TX_ID , CONTRACT.ISSUE_LOCATION , CONTRACT.MANAGED_ACCOUNT_IND , CONTRACT.AGREEMENT_NAME , CONTRACT.AGREEMENT_NICKNAME , CONTRACT.SIGNED_DT , CONTRACT.EXECUTED_DT , CONTRACT.END_DT , CONTRACT.REPLACES_CONTRACT , CONTRACT.ACCOUNT_LAST_TRANSACTION_DT , CONTRACT.TERMINATION_DT , CONTRACT.TERMINATION_REASON_TP_CD , CONTRACT.AGREEMENT_DESCRIPTION , CONTRACT.AGREEMENT_ST_TP_CD , CONTRACT.AGREEMENT_TP_CD , CONTRACT.SERVICE_LEVEL_TP_CD , CONTRACT.LAST_VERIFIED_DT , CONTRACT.LAST_REVIEWED_DT , CONTRACT.PRODUCT_ID , CONTRACT.ADMIN_CONTRACT_ID , CONTRACT.ADMIN_SYS_TP_CD , CONTRACT.ACCESS_TOKEN_VALUE , CONTRACT.CLUSTER_KEY, CONTRACT.XCONTRACT_NUM FROM CONTRACT WHERE CONTRACT.CONTRACT_ID = ?",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"contract_id", "currency_tp_cd", "freq_mode_tp_cd", "contr_lang_tp_cd", "line_of_business", "bill_tp_cd", "repl_by_contract", "premium_amt", "premamt_cur_tp", "next_bill_dt", "curr_cash_val_amt", "cashval_cur_tp", "brand_name", "service_org_name", "bus_orgunit_id", "last_update_dt", "last_update_user", "service_prov_id", "last_update_tx_id", "issue_location", "managed_account_ind", "agreement_name", "agreement_nickname", "signed_dt", "executed_dt", "end_dt", "replaces_contract", "account_last_transaction_dt", "termination_dt", "termination_reason_tp_cd", "agreement_description", "agreement_st_tp_cd", "agreement_tp_cd", "service_level_tp_cd", "last_verified_dt", "last_reviewed_dt", "product_id", "admin_contract_id", "admin_sys_tp_cd", "access_token_value", "cluster_key", "xcontract_num"},
    new GetEObjCONTRACTParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetEObjCONTRACTRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.DECIMAL, Types.BIGINT, Types.TIMESTAMP, Types.DECIMAL, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.CHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.VARCHAR}, {19, 19, 19, 19, 30, 19, 19, 17, 19, 0, 17, 19, 30, 70, 30, 0, 20, 30, 19, 30, 1, 120, 120, 0, 0, 0, 19, 0, 0, 19, 250, 19, 19, 19, 0, 0, 19, 150, 19, 50, 19, 50}, {0, 0, 0, 0, 0, 0, 0, 3, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    2);

  /**
   * @generated
   */
  public static class GetEObjCONTRACTParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetEObjCONTRACTRowHandler extends BaseRowHandler<ResultQueue2<EObjContract,EObjXContractExt>>
  {
    /**
     * @generated
     */
    public ResultQueue2<EObjContract,EObjXContractExt> handle (java.sql.ResultSet rs, ResultQueue2<EObjContract,EObjXContractExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue2<EObjContract,EObjXContractExt> ();

      EObjContract returnObject1 = new EObjContract ();
      returnObject1.setContractIdPK(getLongObject (rs, 1)); 
      returnObject1.setCurrencyTpCd(getLongObject (rs, 2)); 
      returnObject1.setFreqModeTpCd(getLongObject (rs, 3)); 
      returnObject1.setContrLangTpCd(getLongObject (rs, 4)); 
      returnObject1.setLineOfBusiness(getString (rs, 5)); 
      returnObject1.setBillTpCd(getLongObject (rs, 6)); 
      returnObject1.setReplByContract(getLongObject (rs, 7)); 
      returnObject1.setPremiumAmt(getBigDecimal (rs, 8)); 
      returnObject1.setPremiumAmtCurTpCd(getLongObject (rs, 9)); 
      returnObject1.setNextBillDt(getTimestamp (rs, 10)); 
      returnObject1.setCurrCashValAmt(getBigDecimal (rs, 11)); 
      returnObject1.setCurrCashValAmtCurTpCd(getLongObject (rs, 12)); 
      returnObject1.setBrandName(getString (rs, 13)); 
      returnObject1.setServiceOrgName(getString (rs, 14)); 
      returnObject1.setBusOrgunitId(getString (rs, 15)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 16)); 
      returnObject1.setLastUpdateUser(getString (rs, 17)); 
      returnObject1.setServiceProvId(getString (rs, 18)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 19)); 
      returnObject1.setIssueLocation(getString (rs, 20)); 
      returnObject1.setManagedAccountIndicator(getString (rs, 21)); 
      returnObject1.setAgreementName(getString (rs, 22)); 
      returnObject1.setAgreementNickName(getString (rs, 23)); 
      returnObject1.setSignedDate(getTimestamp (rs, 24)); 
      returnObject1.setExecutedDate(getTimestamp (rs, 25)); 
      returnObject1.setEndDate(getTimestamp (rs, 26)); 
      returnObject1.setReplacesContract(getLongObject (rs, 27)); 
      returnObject1.setAccountLastTransactionDate(getTimestamp (rs, 28)); 
      returnObject1.setTerminationDate(getTimestamp (rs, 29)); 
      returnObject1.setTerminationReasonType(getLongObject (rs, 30)); 
      returnObject1.setAgreementDescription(getString (rs, 31)); 
      returnObject1.setAgreementStatusType(getLongObject (rs, 32)); 
      returnObject1.setAgreementType(getLongObject (rs, 33)); 
      returnObject1.setServiceLevelType(getLongObject (rs, 34)); 
      returnObject1.setLastVerifiedDate(getTimestamp (rs, 35)); 
      returnObject1.setLastReviewedDate(getTimestamp (rs, 36)); 
      returnObject1.setProductId(getLongObject (rs, 37)); 
      returnObject1.setAdminContractId(getString (rs, 38)); 
      returnObject1.setAdminSysTpCd(getLongObject (rs, 39)); 
      returnObject1.setAccessTokenValue(getString (rs, 40)); 
      returnObject1.setClusterKey(getLongObject (rs, 41)); 
      returnObject.add (returnObject1);

      EObjXContractExt returnObject2 = new EObjXContractExt ();
      returnObject2.setLastUpdateDt(getTimestamp (rs, 16)); 
      returnObject2.setLastUpdateUser(getString (rs, 17)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 19)); 
      returnObject2.setXContractNum(getString (rs, 42)); 
      returnObject.add (returnObject2);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT DISTINCT CC.CONTRACT_ID FROM CONTRACTROLE CR, CONTRACTCOMPONENT CC WHERE CC.CONTR_COMPONENT_ID = CR.CONTR_COMPONENT_ID AND CR.CONT_ID = ?", pattern="tableAlias (CONTRACTCOMPONENT => com.dwl.tcrm.financial.entityObject.EObjContractComponent, H_CONTRACTCOMPONEN => com.dwl.tcrm.financial.entityObject.EObjContractComponent, ADDRESSGROUP => com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup, H_ADDRESSGROUP => com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup, LOCATIONGROUP => com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup, H_LOCATIONGROUP => com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup, ROLELOCATION => com.dwl.tcrm.financial.entityObject.EObjRoleLocation, H_ROLELOCATION => com.dwl.tcrm.financial.entityObject.EObjRoleLocation, CONTRACTROLE => com.dwl.tcrm.financial.entityObject.EObjContractRole, H_CONTRACTROLE => com.dwl.tcrm.financial.entityObject.EObjContractRole, CONTACTMETHODGROUP => com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup, H_CONTACTMETHODGRO => com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup)" )
   * 
   * @generated
   */
  public java.util.Iterator<com.ibm.mdm.base.db.ResultQueue1<com.dwl.tcrm.financial.entityObject.EObjContract>> getEObjCONTRACT_IDS_ALL (Object[] parameters)
  {
    return queryIterator (getEObjCONTRACT_IDS_ALLStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getEObjCONTRACT_IDS_ALLStatementDescriptor = createStatementDescriptor (
    "getEObjCONTRACT_IDS_ALL(Object[])",
    "SELECT DISTINCT CC.CONTRACT_ID FROM CONTRACTROLE CR, CONTRACTCOMPONENT CC WHERE CC.CONTR_COMPONENT_ID = CR.CONTR_COMPONENT_ID AND CR.CONT_ID = ?",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"contract_id"},
    new GetEObjCONTRACT_IDS_ALLParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetEObjCONTRACT_IDS_ALLRowHandler (),
    new int[][]{ {Types.BIGINT}, {19}, {0}, {0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    3);

  /**
   * @generated
   */
  public static class GetEObjCONTRACT_IDS_ALLParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetEObjCONTRACT_IDS_ALLRowHandler extends BaseRowHandler<ResultQueue1<EObjContract>>
  {
    /**
     * @generated
     */
    public ResultQueue1<EObjContract> handle (java.sql.ResultSet rs, ResultQueue1<EObjContract> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue1<EObjContract> ();

      EObjContract returnObject1 = new EObjContract ();
      returnObject.add (returnObject1);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT DISTINCT CC.CONTRACT_ID FROM CONTRACTROLE CR, CONTRACTCOMPONENT CC WHERE CC.CONTR_COMPONENT_ID = CR.CONTR_COMPONENT_ID AND CR.CONT_ID = ? AND (CR.END_DT IS NULL OR CR.END_DT > ? )", pattern="tableAlias (CONTRACTCOMPONENT => com.dwl.tcrm.financial.entityObject.EObjContractComponent, H_CONTRACTCOMPONEN => com.dwl.tcrm.financial.entityObject.EObjContractComponent, ADDRESSGROUP => com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup, H_ADDRESSGROUP => com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup, LOCATIONGROUP => com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup, H_LOCATIONGROUP => com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup, ROLELOCATION => com.dwl.tcrm.financial.entityObject.EObjRoleLocation, H_ROLELOCATION => com.dwl.tcrm.financial.entityObject.EObjRoleLocation, CONTRACTROLE => com.dwl.tcrm.financial.entityObject.EObjContractRole, H_CONTRACTROLE => com.dwl.tcrm.financial.entityObject.EObjContractRole, CONTACTMETHODGROUP => com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup, H_CONTACTMETHODGRO => com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup)" )
   * 
   * @generated
   */
  public java.util.Iterator<com.ibm.mdm.base.db.ResultQueue1<com.dwl.tcrm.financial.entityObject.EObjContract>> getEObjCONTRACT_IDS_ACTIVE (Object[] parameters)
  {
    return queryIterator (getEObjCONTRACT_IDS_ACTIVEStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getEObjCONTRACT_IDS_ACTIVEStatementDescriptor = createStatementDescriptor (
    "getEObjCONTRACT_IDS_ACTIVE(Object[])",
    "SELECT DISTINCT CC.CONTRACT_ID FROM CONTRACTROLE CR, CONTRACTCOMPONENT CC WHERE CC.CONTR_COMPONENT_ID = CR.CONTR_COMPONENT_ID AND CR.CONT_ID = ? AND (CR.END_DT IS NULL OR CR.END_DT > ? )",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"contract_id"},
    new GetEObjCONTRACT_IDS_ACTIVEParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP}, {19, 0}, {0, 0}, {1, 1}},
    null,
    new GetEObjCONTRACT_IDS_ACTIVERowHandler (),
    new int[][]{ {Types.BIGINT}, {19}, {0}, {0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    4);

  /**
   * @generated
   */
  public static class GetEObjCONTRACT_IDS_ACTIVEParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetEObjCONTRACT_IDS_ACTIVERowHandler extends BaseRowHandler<ResultQueue1<EObjContract>>
  {
    /**
     * @generated
     */
    public ResultQueue1<EObjContract> handle (java.sql.ResultSet rs, ResultQueue1<EObjContract> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue1<EObjContract> ();

      EObjContract returnObject1 = new EObjContract ();
      returnObject.add (returnObject1);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT DISTINCT CC.CONTRACT_ID FROM CONTRACTROLE CR, CONTRACTCOMPONENT CC WHERE CC.CONTR_COMPONENT_ID = CR.CONTR_COMPONENT_ID AND CR.CONT_ID = ? AND (CR.END_DT < ? )", pattern="tableAlias (CONTRACTCOMPONENT => com.dwl.tcrm.financial.entityObject.EObjContractComponent, H_CONTRACTCOMPONEN => com.dwl.tcrm.financial.entityObject.EObjContractComponent, ADDRESSGROUP => com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup, H_ADDRESSGROUP => com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup, LOCATIONGROUP => com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup, H_LOCATIONGROUP => com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup, ROLELOCATION => com.dwl.tcrm.financial.entityObject.EObjRoleLocation, H_ROLELOCATION => com.dwl.tcrm.financial.entityObject.EObjRoleLocation, CONTRACTROLE => com.dwl.tcrm.financial.entityObject.EObjContractRole, H_CONTRACTROLE => com.dwl.tcrm.financial.entityObject.EObjContractRole, CONTACTMETHODGROUP => com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup, H_CONTACTMETHODGRO => com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup)" )
   * 
   * @generated
   */
  public java.util.Iterator<com.ibm.mdm.base.db.ResultQueue1<com.dwl.tcrm.financial.entityObject.EObjContract>> getEObjCONTRACT_IDS_INACTIVE (Object[] parameters)
  {
    return queryIterator (getEObjCONTRACT_IDS_INACTIVEStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getEObjCONTRACT_IDS_INACTIVEStatementDescriptor = createStatementDescriptor (
    "getEObjCONTRACT_IDS_INACTIVE(Object[])",
    "SELECT DISTINCT CC.CONTRACT_ID FROM CONTRACTROLE CR, CONTRACTCOMPONENT CC WHERE CC.CONTR_COMPONENT_ID = CR.CONTR_COMPONENT_ID AND CR.CONT_ID = ? AND (CR.END_DT < ? )",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"contract_id"},
    new GetEObjCONTRACT_IDS_INACTIVEParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP}, {19, 0}, {0, 0}, {1, 1}},
    null,
    new GetEObjCONTRACT_IDS_INACTIVERowHandler (),
    new int[][]{ {Types.BIGINT}, {19}, {0}, {0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    5);

  /**
   * @generated
   */
  public static class GetEObjCONTRACT_IDS_INACTIVEParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetEObjCONTRACT_IDS_INACTIVERowHandler extends BaseRowHandler<ResultQueue1<EObjContract>>
  {
    /**
     * @generated
     */
    public ResultQueue1<EObjContract> handle (java.sql.ResultSet rs, ResultQueue1<EObjContract> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue1<EObjContract> ();

      EObjContract returnObject1 = new EObjContract ();
      returnObject.add (returnObject1);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT DISTINCT CC.CONTRACT_ID FROM H_CONTRACTROLE CR, H_CONTRACTCOMPONEN CC WHERE CC.H_CONTR_COMPONENT_ = CR.CONTR_COMPONENT_ID AND CR.CONT_ID = ? AND (? BETWEEN CR.H_CREATE_DT AND CR.H_END_DT OR ? >= CR.H_CREATE_DT AND CR.H_END_DT IS NULL )", pattern="tableAlias (CONTRACTCOMPONENT => com.dwl.tcrm.financial.entityObject.EObjContractComponent, H_CONTRACTCOMPONEN => com.dwl.tcrm.financial.entityObject.EObjContractComponent, ADDRESSGROUP => com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup, H_ADDRESSGROUP => com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup, LOCATIONGROUP => com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup, H_LOCATIONGROUP => com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup, ROLELOCATION => com.dwl.tcrm.financial.entityObject.EObjRoleLocation, H_ROLELOCATION => com.dwl.tcrm.financial.entityObject.EObjRoleLocation, CONTRACTROLE => com.dwl.tcrm.financial.entityObject.EObjContractRole, H_CONTRACTROLE => com.dwl.tcrm.financial.entityObject.EObjContractRole, CONTACTMETHODGROUP => com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup, H_CONTACTMETHODGRO => com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup)" )
   * 
   * @generated
   */
  public java.util.Iterator<com.ibm.mdm.base.db.ResultQueue1<com.dwl.tcrm.financial.entityObject.EObjContract>> getEObjCONTRACT_IDS_HISTORY (Object[] parameters)
  {
    return queryIterator (getEObjCONTRACT_IDS_HISTORYStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getEObjCONTRACT_IDS_HISTORYStatementDescriptor = createStatementDescriptor (
    "getEObjCONTRACT_IDS_HISTORY(Object[])",
    "SELECT DISTINCT CC.CONTRACT_ID FROM H_CONTRACTROLE CR, H_CONTRACTCOMPONEN CC WHERE CC.H_CONTR_COMPONENT_ = CR.CONTR_COMPONENT_ID AND CR.CONT_ID = ? AND (? BETWEEN CR.H_CREATE_DT AND CR.H_END_DT OR ? >= CR.H_CREATE_DT AND CR.H_END_DT IS NULL )",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"contract_id"},
    new GetEObjCONTRACT_IDS_HISTORYParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP}, {19, 0, 0}, {0, 0, 0}, {1, 1, 1}},
    null,
    new GetEObjCONTRACT_IDS_HISTORYRowHandler (),
    new int[][]{ {Types.BIGINT}, {19}, {0}, {0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    6);

  /**
   * @generated
   */
  public static class GetEObjCONTRACT_IDS_HISTORYParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetEObjCONTRACT_IDS_HISTORYRowHandler extends BaseRowHandler<ResultQueue1<EObjContract>>
  {
    /**
     * @generated
     */
    public ResultQueue1<EObjContract> handle (java.sql.ResultSet rs, ResultQueue1<EObjContract> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue1<EObjContract> ();

      EObjContract returnObject1 = new EObjContract ();
      returnObject.add (returnObject1);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT DISTINCT H_CONTRACTCOMPONEN.CONTRACT_ID FROM H_ADDRESSGROUP, H_LOCATIONGROUP ,H_ROLELOCATION, H_CONTRACTROLE, H_CONTRACTCOMPONEN WHERE H_ADDRESSGROUP.H_LOCATION_GROUP_I=H_LOCATIONGROUP.H_LOCATION_GROUP_I AND H_LOCATIONGROUP.H_LOCATION_GROUP_I=H_ROLELOCATION.LOCATION_GROUP_ID AND H_LOCATIONGROUP.CONT_ID=H_CONTRACTROLE.CONT_ID AND H_CONTRACTROLE.CONTR_COMPONENT_ID=H_CONTRACTCOMPONEN.H_CONTR_COMPONENT_ AND H_ROLELOCATION.CONTRACT_ROLE_ID = H_CONTRACTROLE.H_CONTRACT_ROLE_ID AND H_ADDRESSGROUP.ADDRESS_ID = ? AND (? BETWEEN H_ADDRESSGROUP.H_CREATE_DT AND H_ADDRESSGROUP.H_END_DT OR ? >= H_ADDRESSGROUP.H_CREATE_DT AND H_ADDRESSGROUP.H_END_DT IS NULL )", pattern="tableAlias (CONTRACTCOMPONENT => com.dwl.tcrm.financial.entityObject.EObjContractComponent, H_CONTRACTCOMPONEN => com.dwl.tcrm.financial.entityObject.EObjContractComponent, ADDRESSGROUP => com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup, H_ADDRESSGROUP => com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup, LOCATIONGROUP => com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup, H_LOCATIONGROUP => com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup, ROLELOCATION => com.dwl.tcrm.financial.entityObject.EObjRoleLocation, H_ROLELOCATION => com.dwl.tcrm.financial.entityObject.EObjRoleLocation, CONTRACTROLE => com.dwl.tcrm.financial.entityObject.EObjContractRole, H_CONTRACTROLE => com.dwl.tcrm.financial.entityObject.EObjContractRole, CONTACTMETHODGROUP => com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup, H_CONTACTMETHODGRO => com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup)" )
   * 
   * @generated
   */
  public java.util.Iterator<com.ibm.mdm.base.db.ResultQueue1<com.dwl.tcrm.financial.entityObject.EObjContract>> getEObjCONTRACT_IDS_BY_ADDRESS_ID_HISTORY (Object[] parameters)
  {
    return queryIterator (getEObjCONTRACT_IDS_BY_ADDRESS_ID_HISTORYStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getEObjCONTRACT_IDS_BY_ADDRESS_ID_HISTORYStatementDescriptor = createStatementDescriptor (
    "getEObjCONTRACT_IDS_BY_ADDRESS_ID_HISTORY(Object[])",
    "SELECT DISTINCT H_CONTRACTCOMPONEN.CONTRACT_ID FROM H_ADDRESSGROUP, H_LOCATIONGROUP ,H_ROLELOCATION, H_CONTRACTROLE, H_CONTRACTCOMPONEN WHERE H_ADDRESSGROUP.H_LOCATION_GROUP_I=H_LOCATIONGROUP.H_LOCATION_GROUP_I AND H_LOCATIONGROUP.H_LOCATION_GROUP_I=H_ROLELOCATION.LOCATION_GROUP_ID AND H_LOCATIONGROUP.CONT_ID=H_CONTRACTROLE.CONT_ID AND H_CONTRACTROLE.CONTR_COMPONENT_ID=H_CONTRACTCOMPONEN.H_CONTR_COMPONENT_ AND H_ROLELOCATION.CONTRACT_ROLE_ID = H_CONTRACTROLE.H_CONTRACT_ROLE_ID AND H_ADDRESSGROUP.ADDRESS_ID = ? AND (? BETWEEN H_ADDRESSGROUP.H_CREATE_DT AND H_ADDRESSGROUP.H_END_DT OR ? >= H_ADDRESSGROUP.H_CREATE_DT AND H_ADDRESSGROUP.H_END_DT IS NULL )",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"contract_id"},
    new GetEObjCONTRACT_IDS_BY_ADDRESS_ID_HISTORYParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP}, {19, 0, 0}, {0, 0, 0}, {1, 1, 1}},
    null,
    new GetEObjCONTRACT_IDS_BY_ADDRESS_ID_HISTORYRowHandler (),
    new int[][]{ {Types.BIGINT}, {19}, {0}, {0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    7);

  /**
   * @generated
   */
  public static class GetEObjCONTRACT_IDS_BY_ADDRESS_ID_HISTORYParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetEObjCONTRACT_IDS_BY_ADDRESS_ID_HISTORYRowHandler extends BaseRowHandler<ResultQueue1<EObjContract>>
  {
    /**
     * @generated
     */
    public ResultQueue1<EObjContract> handle (java.sql.ResultSet rs, ResultQueue1<EObjContract> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue1<EObjContract> ();

      EObjContract returnObject1 = new EObjContract ();
      returnObject.add (returnObject1);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT DISTINCT CONTRACTCOMPONENT.CONTRACT_ID FROM ADDRESSGROUP, LOCATIONGROUP, ROLELOCATION, CONTRACTROLE, CONTRACTCOMPONENT WHERE ADDRESSGROUP.ADDRESS_ID=? AND ADDRESSGROUP.LOCATION_GROUP_ID=LOCATIONGROUP.LOCATION_GROUP_ID AND LOCATIONGROUP.LOCATION_GROUP_ID=ROLELOCATION.LOCATION_GROUP_ID AND LOCATIONGROUP.CONT_ID=CONTRACTROLE.CONT_ID AND CONTRACTROLE.CONTR_COMPONENT_ID=CONTRACTCOMPONENT.CONTR_COMPONENT_ID AND ROLELOCATION.CONTRACT_ROLE_ID=CONTRACTROLE.CONTRACT_ROLE_ID", pattern="tableAlias (CONTRACTCOMPONENT => com.dwl.tcrm.financial.entityObject.EObjContractComponent, H_CONTRACTCOMPONEN => com.dwl.tcrm.financial.entityObject.EObjContractComponent, ADDRESSGROUP => com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup, H_ADDRESSGROUP => com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup, LOCATIONGROUP => com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup, H_LOCATIONGROUP => com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup, ROLELOCATION => com.dwl.tcrm.financial.entityObject.EObjRoleLocation, H_ROLELOCATION => com.dwl.tcrm.financial.entityObject.EObjRoleLocation, CONTRACTROLE => com.dwl.tcrm.financial.entityObject.EObjContractRole, H_CONTRACTROLE => com.dwl.tcrm.financial.entityObject.EObjContractRole, CONTACTMETHODGROUP => com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup, H_CONTACTMETHODGRO => com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup)" )
   * 
   * @generated
   */
  public java.util.Iterator<com.ibm.mdm.base.db.ResultQueue1<com.dwl.tcrm.financial.entityObject.EObjContract>> getEObjCONTRACT_IDS_BY_ADDRESS_ID_ALL (Object[] parameters)
  {
    return queryIterator (getEObjCONTRACT_IDS_BY_ADDRESS_ID_ALLStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getEObjCONTRACT_IDS_BY_ADDRESS_ID_ALLStatementDescriptor = createStatementDescriptor (
    "getEObjCONTRACT_IDS_BY_ADDRESS_ID_ALL(Object[])",
    "SELECT DISTINCT CONTRACTCOMPONENT.CONTRACT_ID FROM ADDRESSGROUP, LOCATIONGROUP, ROLELOCATION, CONTRACTROLE, CONTRACTCOMPONENT WHERE ADDRESSGROUP.ADDRESS_ID=? AND ADDRESSGROUP.LOCATION_GROUP_ID=LOCATIONGROUP.LOCATION_GROUP_ID AND LOCATIONGROUP.LOCATION_GROUP_ID=ROLELOCATION.LOCATION_GROUP_ID AND LOCATIONGROUP.CONT_ID=CONTRACTROLE.CONT_ID AND CONTRACTROLE.CONTR_COMPONENT_ID=CONTRACTCOMPONENT.CONTR_COMPONENT_ID AND ROLELOCATION.CONTRACT_ROLE_ID=CONTRACTROLE.CONTRACT_ROLE_ID",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"contract_id"},
    new GetEObjCONTRACT_IDS_BY_ADDRESS_ID_ALLParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetEObjCONTRACT_IDS_BY_ADDRESS_ID_ALLRowHandler (),
    new int[][]{ {Types.BIGINT}, {19}, {0}, {0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    8);

  /**
   * @generated
   */
  public static class GetEObjCONTRACT_IDS_BY_ADDRESS_ID_ALLParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetEObjCONTRACT_IDS_BY_ADDRESS_ID_ALLRowHandler extends BaseRowHandler<ResultQueue1<EObjContract>>
  {
    /**
     * @generated
     */
    public ResultQueue1<EObjContract> handle (java.sql.ResultSet rs, ResultQueue1<EObjContract> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue1<EObjContract> ();

      EObjContract returnObject1 = new EObjContract ();
      returnObject.add (returnObject1);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT DISTINCT H_CONTRACTCOMPONEN.CONTRACT_ID FROM H_CONTACTMETHODGRO, H_LOCATIONGROUP ,H_ROLELOCATION, H_CONTRACTROLE, H_CONTRACTCOMPONEN WHERE H_CONTACTMETHODGRO.H_LOCATION_GROUP_I=H_LOCATIONGROUP.H_LOCATION_GROUP_I AND H_LOCATIONGROUP.H_LOCATION_GROUP_I=H_ROLELOCATION.LOCATION_GROUP_ID AND H_LOCATIONGROUP.CONT_ID=H_CONTRACTROLE.CONT_ID AND H_CONTRACTROLE.CONTR_COMPONENT_ID=H_CONTRACTCOMPONEN.H_CONTR_COMPONENT_ AND H_ROLELOCATION.CONTRACT_ROLE_ID = H_CONTRACTROLE.H_CONTRACT_ROLE_ID AND H_CONTACTMETHODGRO.CONTACT_METHOD_ID = ? AND (? BETWEEN H_CONTACTMETHODGRO.H_CREATE_DT AND H_CONTACTMETHODGRO.H_END_DT OR ? >= H_CONTACTMETHODGRO.H_CREATE_DT AND H_CONTACTMETHODGRO.H_END_DT IS NULL )", pattern="tableAlias (CONTRACTCOMPONENT => com.dwl.tcrm.financial.entityObject.EObjContractComponent, H_CONTRACTCOMPONEN => com.dwl.tcrm.financial.entityObject.EObjContractComponent, ADDRESSGROUP => com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup, H_ADDRESSGROUP => com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup, LOCATIONGROUP => com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup, H_LOCATIONGROUP => com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup, ROLELOCATION => com.dwl.tcrm.financial.entityObject.EObjRoleLocation, H_ROLELOCATION => com.dwl.tcrm.financial.entityObject.EObjRoleLocation, CONTRACTROLE => com.dwl.tcrm.financial.entityObject.EObjContractRole, H_CONTRACTROLE => com.dwl.tcrm.financial.entityObject.EObjContractRole, CONTACTMETHODGROUP => com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup, H_CONTACTMETHODGRO => com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup)" )
   * 
   * @generated
   */
  public java.util.Iterator<com.ibm.mdm.base.db.ResultQueue1<com.dwl.tcrm.financial.entityObject.EObjContract>> getEObjCONTRACT_IDS_BY_CONTACT_METHOD_ID_HISTORY (Object[] parameters)
  {
    return queryIterator (getEObjCONTRACT_IDS_BY_CONTACT_METHOD_ID_HISTORYStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getEObjCONTRACT_IDS_BY_CONTACT_METHOD_ID_HISTORYStatementDescriptor = createStatementDescriptor (
    "getEObjCONTRACT_IDS_BY_CONTACT_METHOD_ID_HISTORY(Object[])",
    "SELECT DISTINCT H_CONTRACTCOMPONEN.CONTRACT_ID FROM H_CONTACTMETHODGRO, H_LOCATIONGROUP ,H_ROLELOCATION, H_CONTRACTROLE, H_CONTRACTCOMPONEN WHERE H_CONTACTMETHODGRO.H_LOCATION_GROUP_I=H_LOCATIONGROUP.H_LOCATION_GROUP_I AND H_LOCATIONGROUP.H_LOCATION_GROUP_I=H_ROLELOCATION.LOCATION_GROUP_ID AND H_LOCATIONGROUP.CONT_ID=H_CONTRACTROLE.CONT_ID AND H_CONTRACTROLE.CONTR_COMPONENT_ID=H_CONTRACTCOMPONEN.H_CONTR_COMPONENT_ AND H_ROLELOCATION.CONTRACT_ROLE_ID = H_CONTRACTROLE.H_CONTRACT_ROLE_ID AND H_CONTACTMETHODGRO.CONTACT_METHOD_ID = ? AND (? BETWEEN H_CONTACTMETHODGRO.H_CREATE_DT AND H_CONTACTMETHODGRO.H_END_DT OR ? >= H_CONTACTMETHODGRO.H_CREATE_DT AND H_CONTACTMETHODGRO.H_END_DT IS NULL )",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"contract_id"},
    new GetEObjCONTRACT_IDS_BY_CONTACT_METHOD_ID_HISTORYParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP}, {19, 0, 0}, {0, 0, 0}, {1, 1, 1}},
    null,
    new GetEObjCONTRACT_IDS_BY_CONTACT_METHOD_ID_HISTORYRowHandler (),
    new int[][]{ {Types.BIGINT}, {19}, {0}, {0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    9);

  /**
   * @generated
   */
  public static class GetEObjCONTRACT_IDS_BY_CONTACT_METHOD_ID_HISTORYParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetEObjCONTRACT_IDS_BY_CONTACT_METHOD_ID_HISTORYRowHandler extends BaseRowHandler<ResultQueue1<EObjContract>>
  {
    /**
     * @generated
     */
    public ResultQueue1<EObjContract> handle (java.sql.ResultSet rs, ResultQueue1<EObjContract> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue1<EObjContract> ();

      EObjContract returnObject1 = new EObjContract ();
      returnObject.add (returnObject1);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT DISTINCT CONTRACTCOMPONENT.CONTRACT_ID FROM CONTACTMETHODGROUP, LOCATIONGROUP, ROLELOCATION, CONTRACTROLE, CONTRACTCOMPONENT WHERE CONTACTMETHODGROUP.CONTACT_METHOD_ID=? AND CONTACTMETHODGROUP.LOCATION_GROUP_ID=LOCATIONGROUP.LOCATION_GROUP_ID AND LOCATIONGROUP.LOCATION_GROUP_ID=ROLELOCATION.LOCATION_GROUP_ID AND LOCATIONGROUP.CONT_ID=CONTRACTROLE.CONT_ID AND CONTRACTROLE.CONTR_COMPONENT_ID=CONTRACTCOMPONENT.CONTR_COMPONENT_ID AND ROLELOCATION.CONTRACT_ROLE_ID = CONTRACTROLE.CONTRACT_ROLE_ID", pattern="tableAlias (CONTRACTCOMPONENT => com.dwl.tcrm.financial.entityObject.EObjContractComponent, H_CONTRACTCOMPONEN => com.dwl.tcrm.financial.entityObject.EObjContractComponent, ADDRESSGROUP => com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup, H_ADDRESSGROUP => com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup, LOCATIONGROUP => com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup, H_LOCATIONGROUP => com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup, ROLELOCATION => com.dwl.tcrm.financial.entityObject.EObjRoleLocation, H_ROLELOCATION => com.dwl.tcrm.financial.entityObject.EObjRoleLocation, CONTRACTROLE => com.dwl.tcrm.financial.entityObject.EObjContractRole, H_CONTRACTROLE => com.dwl.tcrm.financial.entityObject.EObjContractRole, CONTACTMETHODGROUP => com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup, H_CONTACTMETHODGRO => com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup)" )
   * 
   * @generated
   */
  public java.util.Iterator<com.ibm.mdm.base.db.ResultQueue1<com.dwl.tcrm.financial.entityObject.EObjContract>> getEObjCONTRACT_IDS_BY_CONTACT_METHOD_ID_ALL (Object[] parameters)
  {
    return queryIterator (getEObjCONTRACT_IDS_BY_CONTACT_METHOD_ID_ALLStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getEObjCONTRACT_IDS_BY_CONTACT_METHOD_ID_ALLStatementDescriptor = createStatementDescriptor (
    "getEObjCONTRACT_IDS_BY_CONTACT_METHOD_ID_ALL(Object[])",
    "SELECT DISTINCT CONTRACTCOMPONENT.CONTRACT_ID FROM CONTACTMETHODGROUP, LOCATIONGROUP, ROLELOCATION, CONTRACTROLE, CONTRACTCOMPONENT WHERE CONTACTMETHODGROUP.CONTACT_METHOD_ID=? AND CONTACTMETHODGROUP.LOCATION_GROUP_ID=LOCATIONGROUP.LOCATION_GROUP_ID AND LOCATIONGROUP.LOCATION_GROUP_ID=ROLELOCATION.LOCATION_GROUP_ID AND LOCATIONGROUP.CONT_ID=CONTRACTROLE.CONT_ID AND CONTRACTROLE.CONTR_COMPONENT_ID=CONTRACTCOMPONENT.CONTR_COMPONENT_ID AND ROLELOCATION.CONTRACT_ROLE_ID = CONTRACTROLE.CONTRACT_ROLE_ID",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"contract_id"},
    new GetEObjCONTRACT_IDS_BY_CONTACT_METHOD_ID_ALLParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetEObjCONTRACT_IDS_BY_CONTACT_METHOD_ID_ALLRowHandler (),
    new int[][]{ {Types.BIGINT}, {19}, {0}, {0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    10);

  /**
   * @generated
   */
  public static class GetEObjCONTRACT_IDS_BY_CONTACT_METHOD_ID_ALLParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetEObjCONTRACT_IDS_BY_CONTACT_METHOD_ID_ALLRowHandler extends BaseRowHandler<ResultQueue1<EObjContract>>
  {
    /**
     * @generated
     */
    public ResultQueue1<EObjContract> handle (java.sql.ResultSet rs, ResultQueue1<EObjContract> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue1<EObjContract> ();

      EObjContract returnObject1 = new EObjContract ();
      returnObject.add (returnObject1);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT CONTRACT_ID , LAST_UPDATE_DT , H_CONTRACT.ACCESS_TOKEN_VALUE, H_CONTRACT.XCONTRACT_NUM FROM H_CONTRACT WHERE CONTRACT_ID = ? AND (H_CREATE_DT BETWEEN ? AND ?)", pattern="tableAlias (CONTRACT => com.dwl.tcrm.financial.entityObject.EObjContract, H_CONTRACT => com.dwl.tcrm.financial.entityObject.EObjContract , CONTRACT => com.ibm.daimler.dsea.entityObject.EObjXContractExt , H_CONTRACT => com.ibm.daimler.dsea.entityObject.EObjXContractExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue2<EObjContract,EObjXContractExt>> getEObjCONTRACTS_LIGHT_IMAGES (Object[] parameters)
  {
    return queryIterator (getEObjCONTRACTS_LIGHT_IMAGESStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getEObjCONTRACTS_LIGHT_IMAGESStatementDescriptor = createStatementDescriptor (
    "getEObjCONTRACTS_LIGHT_IMAGES(Object[])",
    "SELECT CONTRACT_ID , LAST_UPDATE_DT , H_CONTRACT.ACCESS_TOKEN_VALUE, H_CONTRACT.XCONTRACT_NUM FROM H_CONTRACT WHERE CONTRACT_ID = ? AND (H_CREATE_DT BETWEEN ? AND ?)",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"contract_id", "last_update_dt", "access_token_value", "xcontract_num"},
    new GetEObjCONTRACTS_LIGHT_IMAGESParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP}, {19, 0, 0}, {0, 0, 0}, {1, 1, 1}},
    null,
    new GetEObjCONTRACTS_LIGHT_IMAGESRowHandler (),
    new int[][]{ {Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR}, {19, 0, 50, 50}, {0, 0, 0, 0}, {0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    11);

  /**
   * @generated
   */
  public static class GetEObjCONTRACTS_LIGHT_IMAGESParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetEObjCONTRACTS_LIGHT_IMAGESRowHandler extends BaseRowHandler<ResultQueue2<EObjContract,EObjXContractExt>>
  {
    /**
     * @generated
     */
    public ResultQueue2<EObjContract,EObjXContractExt> handle (java.sql.ResultSet rs, ResultQueue2<EObjContract,EObjXContractExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue2<EObjContract,EObjXContractExt> ();

      EObjContract returnObject1 = new EObjContract ();
      returnObject1.setContractIdPK(getLongObject (rs, 1)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 2)); 
      returnObject1.setAccessTokenValue(getString (rs, 3)); 
      returnObject.add (returnObject1);

      EObjXContractExt returnObject2 = new EObjXContractExt ();
      returnObject2.setLastUpdateDt(getTimestamp (rs, 2)); 
      returnObject2.setXContractNum(getString (rs, 4)); 
      returnObject.add (returnObject2);

    
      return returnObject;
    }
  }

}
