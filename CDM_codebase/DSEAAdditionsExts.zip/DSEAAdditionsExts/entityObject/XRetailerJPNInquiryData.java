/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[20555a3e94c4f2f20cc2e7c44a26d987]
 */

package com.ibm.daimler.dsea.entityObject;


import com.ibm.mdm.base.db.ResultQueue1;
import java.util.Iterator;
import com.ibm.mdm.base.db.EntityMapping;
import com.ibm.pdq.annotation.Select;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * @generated
 */
public interface XRetailerJPNInquiryData {
  
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String tableAliasString = "tableAlias (" + 
                                            "XRETAILERJPN => com.ibm.daimler.dsea.entityObject.EObjXRetailerJPN, " +
                                            "H_XRETAILERJPN => com.ibm.daimler.dsea.entityObject.EObjXRetailerJPN" +
                                            ")";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getXRetailerJPNSql = "SELECT r.XRETAILERJPNPK_ID XRETAILERJPNPK_ID, r.RETAILER_CODE RETAILER_CODE, r.RETAILER_NAME RETAILER_NAME, r.BRANCH_NAME BRANCH_NAME, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.GS_CODE GS_CODE, r.GC_CODE GC_CODE, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.ND_CODE ND_CODE, r.MARKET_NAME MARKET_NAME, r.DEALER_ACTIVE_FLAG DEALER_ACTIVE_FLAG, r.Dealer_Group Dealer_Group, r.DEALER_ROLLOUT_FLAG DEALER_ROLLOUT_FLAG, r.BATCH_IND BATCH_IND, r.CREATE_DT CREATE_DT, r.CHANGED_DT CHANGED_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XRETAILERJPN r WHERE r.XRETAILERJPNPK_ID = ? ";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXRetailerJPNParameters =
    "EObjXRetailerJPN.XRetailerJPNpkId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXRetailerJPNResults =
    "EObjXRetailerJPN.XRetailerJPNpkId," +
    "EObjXRetailerJPN.RetailerCode," +
    "EObjXRetailerJPN.RetailerName," +
    "EObjXRetailerJPN.BranchName," +
    "EObjXRetailerJPN.SourceIdentifier," +
    "EObjXRetailerJPN.GSCode," +
    "EObjXRetailerJPN.GCCode," +
    "EObjXRetailerJPN.LastModifiedSystemDate," +
    "EObjXRetailerJPN.NDCode," +
    "EObjXRetailerJPN.MarketName," +
    "EObjXRetailerJPN.DealerActiveFlag," +
    "EObjXRetailerJPN.DealerGroup," +
    "EObjXRetailerJPN.DealerRolloutFlag," +
    "EObjXRetailerJPN.BatchInd," +
    "EObjXRetailerJPN.CreateDate," +
    "EObjXRetailerJPN.ChangedDate," +
    "EObjXRetailerJPN.lastUpdateDt," +
    "EObjXRetailerJPN.lastUpdateUser," +
    "EObjXRetailerJPN.lastUpdateTxId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getXRetailerJPNHistorySql = "SELECT r.H_XRETAILERJPNPK_ID hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.XRETAILERJPNPK_ID XRETAILERJPNPK_ID, r.RETAILER_CODE RETAILER_CODE, r.RETAILER_NAME RETAILER_NAME, r.BRANCH_NAME BRANCH_NAME, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.GS_CODE GS_CODE, r.GC_CODE GC_CODE, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.ND_CODE ND_CODE, r.MARKET_NAME MARKET_NAME, r.DEALER_ACTIVE_FLAG DEALER_ACTIVE_FLAG, r.Dealer_Group Dealer_Group, r.DEALER_ROLLOUT_FLAG DEALER_ROLLOUT_FLAG, r.BATCH_IND BATCH_IND, r.CREATE_DT CREATE_DT, r.CHANGED_DT CHANGED_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XRETAILERJPN r WHERE r.H_XRETAILERJPNPK_ID = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXRetailerJPNHistoryParameters =
    "EObjXRetailerJPN.XRetailerJPNpkId," +
    "EObjXRetailerJPN.lastUpdateDt," +
    "EObjXRetailerJPN.lastUpdateDt";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXRetailerJPNHistoryResults =
    "EObjXRetailerJPN.historyIdPK," +
    "EObjXRetailerJPN.histActionCode," +
    "EObjXRetailerJPN.histCreatedBy," +
    "EObjXRetailerJPN.histCreateDt," +
    "EObjXRetailerJPN.histEndDt," +
    "EObjXRetailerJPN.XRetailerJPNpkId," +
    "EObjXRetailerJPN.RetailerCode," +
    "EObjXRetailerJPN.RetailerName," +
    "EObjXRetailerJPN.BranchName," +
    "EObjXRetailerJPN.SourceIdentifier," +
    "EObjXRetailerJPN.GSCode," +
    "EObjXRetailerJPN.GCCode," +
    "EObjXRetailerJPN.LastModifiedSystemDate," +
    "EObjXRetailerJPN.NDCode," +
    "EObjXRetailerJPN.MarketName," +
    "EObjXRetailerJPN.DealerActiveFlag," +
    "EObjXRetailerJPN.DealerGroup," +
    "EObjXRetailerJPN.DealerRolloutFlag," +
    "EObjXRetailerJPN.BatchInd," +
    "EObjXRetailerJPN.CreateDate," +
    "EObjXRetailerJPN.ChangedDate," +
    "EObjXRetailerJPN.lastUpdateDt," +
    "EObjXRetailerJPN.lastUpdateUser," +
    "EObjXRetailerJPN.lastUpdateTxId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getXRetailerJPNByRetailerCodeSql = "SELECT r.XRETAILERJPNPK_ID XRETAILERJPNPK_ID, r.RETAILER_CODE RETAILER_CODE, r.RETAILER_NAME RETAILER_NAME, r.BRANCH_NAME BRANCH_NAME, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.GS_CODE GS_CODE, r.GC_CODE GC_CODE, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.ND_CODE ND_CODE, r.MARKET_NAME MARKET_NAME, r.DEALER_ACTIVE_FLAG DEALER_ACTIVE_FLAG, r.Dealer_Group Dealer_Group, r.DEALER_ROLLOUT_FLAG DEALER_ROLLOUT_FLAG, r.BATCH_IND BATCH_IND, r.CREATE_DT CREATE_DT, r.CHANGED_DT CHANGED_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XRETAILERJPN r WHERE r.RETAILER_CODE = ? ";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXRetailerJPNByRetailerCodeParameters =
    "EObjXRetailerJPN.RetailerCode";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXRetailerJPNByRetailerCodeResults =
    "EObjXRetailerJPN.XRetailerJPNpkId," +
    "EObjXRetailerJPN.RetailerCode," +
    "EObjXRetailerJPN.RetailerName," +
    "EObjXRetailerJPN.BranchName," +
    "EObjXRetailerJPN.SourceIdentifier," +
    "EObjXRetailerJPN.GSCode," +
    "EObjXRetailerJPN.GCCode," +
    "EObjXRetailerJPN.LastModifiedSystemDate," +
    "EObjXRetailerJPN.NDCode," +
    "EObjXRetailerJPN.MarketName," +
    "EObjXRetailerJPN.DealerActiveFlag," +
    "EObjXRetailerJPN.DealerGroup," +
    "EObjXRetailerJPN.DealerRolloutFlag," +
    "EObjXRetailerJPN.BatchInd," +
    "EObjXRetailerJPN.CreateDate," +
    "EObjXRetailerJPN.ChangedDate," +
    "EObjXRetailerJPN.lastUpdateDt," +
    "EObjXRetailerJPN.lastUpdateUser," +
    "EObjXRetailerJPN.lastUpdateTxId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getXRetailerJPNByRetailerCodeHistorySql = "SELECT r.H_XRETAILERJPNPK_ID hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.XRETAILERJPNPK_ID XRETAILERJPNPK_ID, r.RETAILER_CODE RETAILER_CODE, r.RETAILER_NAME RETAILER_NAME, r.BRANCH_NAME BRANCH_NAME, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.GS_CODE GS_CODE, r.GC_CODE GC_CODE, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.ND_CODE ND_CODE, r.MARKET_NAME MARKET_NAME, r.DEALER_ACTIVE_FLAG DEALER_ACTIVE_FLAG, r.Dealer_Group Dealer_Group, r.DEALER_ROLLOUT_FLAG DEALER_ROLLOUT_FLAG, r.BATCH_IND BATCH_IND, r.CREATE_DT CREATE_DT, r.CHANGED_DT CHANGED_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XRETAILERJPN r WHERE r.RETAILER_CODE = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXRetailerJPNByRetailerCodeHistoryParameters =
    "EObjXRetailerJPN.RetailerCode," +
    "EObjXRetailerJPN.lastUpdateDt," +
    "EObjXRetailerJPN.lastUpdateDt";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXRetailerJPNByRetailerCodeHistoryResults =
    "EObjXRetailerJPN.historyIdPK," +
    "EObjXRetailerJPN.histActionCode," +
    "EObjXRetailerJPN.histCreatedBy," +
    "EObjXRetailerJPN.histCreateDt," +
    "EObjXRetailerJPN.histEndDt," +
    "EObjXRetailerJPN.XRetailerJPNpkId," +
    "EObjXRetailerJPN.RetailerCode," +
    "EObjXRetailerJPN.RetailerName," +
    "EObjXRetailerJPN.BranchName," +
    "EObjXRetailerJPN.SourceIdentifier," +
    "EObjXRetailerJPN.GSCode," +
    "EObjXRetailerJPN.GCCode," +
    "EObjXRetailerJPN.LastModifiedSystemDate," +
    "EObjXRetailerJPN.NDCode," +
    "EObjXRetailerJPN.MarketName," +
    "EObjXRetailerJPN.DealerActiveFlag," +
    "EObjXRetailerJPN.DealerGroup," +
    "EObjXRetailerJPN.DealerRolloutFlag," +
    "EObjXRetailerJPN.BatchInd," +
    "EObjXRetailerJPN.CreateDate," +
    "EObjXRetailerJPN.ChangedDate," +
    "EObjXRetailerJPN.lastUpdateDt," +
    "EObjXRetailerJPN.lastUpdateUser," +
    "EObjXRetailerJPN.lastUpdateTxId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getXRetailerJPNByNDCodeSql = "SELECT r.XRETAILERJPNPK_ID XRETAILERJPNPK_ID, r.RETAILER_CODE RETAILER_CODE, r.RETAILER_NAME RETAILER_NAME, r.BRANCH_NAME BRANCH_NAME, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.GS_CODE GS_CODE, r.GC_CODE GC_CODE, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.ND_CODE ND_CODE, r.MARKET_NAME MARKET_NAME, r.DEALER_ACTIVE_FLAG DEALER_ACTIVE_FLAG, r.Dealer_Group Dealer_Group, r.DEALER_ROLLOUT_FLAG DEALER_ROLLOUT_FLAG, r.BATCH_IND BATCH_IND, r.CREATE_DT CREATE_DT, r.CHANGED_DT CHANGED_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XRETAILERJPN r WHERE r.ND_CODE = ? ";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXRetailerJPNByNDCodeParameters =
    "EObjXRetailerJPN.NDCode";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXRetailerJPNByNDCodeResults =
    "EObjXRetailerJPN.XRetailerJPNpkId," +
    "EObjXRetailerJPN.RetailerCode," +
    "EObjXRetailerJPN.RetailerName," +
    "EObjXRetailerJPN.BranchName," +
    "EObjXRetailerJPN.SourceIdentifier," +
    "EObjXRetailerJPN.GSCode," +
    "EObjXRetailerJPN.GCCode," +
    "EObjXRetailerJPN.LastModifiedSystemDate," +
    "EObjXRetailerJPN.NDCode," +
    "EObjXRetailerJPN.MarketName," +
    "EObjXRetailerJPN.DealerActiveFlag," +
    "EObjXRetailerJPN.DealerGroup," +
    "EObjXRetailerJPN.DealerRolloutFlag," +
    "EObjXRetailerJPN.BatchInd," +
    "EObjXRetailerJPN.CreateDate," +
    "EObjXRetailerJPN.ChangedDate," +
    "EObjXRetailerJPN.lastUpdateDt," +
    "EObjXRetailerJPN.lastUpdateUser," +
    "EObjXRetailerJPN.lastUpdateTxId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getXRetailerJPNByNDCodeHistorySql = "SELECT r.H_XRETAILERJPNPK_ID hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.XRETAILERJPNPK_ID XRETAILERJPNPK_ID, r.RETAILER_CODE RETAILER_CODE, r.RETAILER_NAME RETAILER_NAME, r.BRANCH_NAME BRANCH_NAME, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.GS_CODE GS_CODE, r.GC_CODE GC_CODE, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.ND_CODE ND_CODE, r.MARKET_NAME MARKET_NAME, r.DEALER_ACTIVE_FLAG DEALER_ACTIVE_FLAG, r.Dealer_Group Dealer_Group, r.DEALER_ROLLOUT_FLAG DEALER_ROLLOUT_FLAG, r.BATCH_IND BATCH_IND, r.CREATE_DT CREATE_DT, r.CHANGED_DT CHANGED_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XRETAILERJPN r WHERE r.ND_CODE = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXRetailerJPNByNDCodeHistoryParameters =
    "EObjXRetailerJPN.NDCode," +
    "EObjXRetailerJPN.lastUpdateDt," +
    "EObjXRetailerJPN.lastUpdateDt";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXRetailerJPNByNDCodeHistoryResults =
    "EObjXRetailerJPN.historyIdPK," +
    "EObjXRetailerJPN.histActionCode," +
    "EObjXRetailerJPN.histCreatedBy," +
    "EObjXRetailerJPN.histCreateDt," +
    "EObjXRetailerJPN.histEndDt," +
    "EObjXRetailerJPN.XRetailerJPNpkId," +
    "EObjXRetailerJPN.RetailerCode," +
    "EObjXRetailerJPN.RetailerName," +
    "EObjXRetailerJPN.BranchName," +
    "EObjXRetailerJPN.SourceIdentifier," +
    "EObjXRetailerJPN.GSCode," +
    "EObjXRetailerJPN.GCCode," +
    "EObjXRetailerJPN.LastModifiedSystemDate," +
    "EObjXRetailerJPN.NDCode," +
    "EObjXRetailerJPN.MarketName," +
    "EObjXRetailerJPN.DealerActiveFlag," +
    "EObjXRetailerJPN.DealerGroup," +
    "EObjXRetailerJPN.DealerRolloutFlag," +
    "EObjXRetailerJPN.BatchInd," +
    "EObjXRetailerJPN.CreateDate," +
    "EObjXRetailerJPN.ChangedDate," +
    "EObjXRetailerJPN.lastUpdateDt," +
    "EObjXRetailerJPN.lastUpdateUser," +
    "EObjXRetailerJPN.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getXRetailerJPNSql, pattern=tableAliasString)
  @EntityMapping(parameters=getXRetailerJPNParameters, results=getXRetailerJPNResults)
  Iterator<ResultQueue1<EObjXRetailerJPN>> getXRetailerJPN(Object[] parameters);  


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getXRetailerJPNHistorySql, pattern=tableAliasString)
  @EntityMapping(parameters=getXRetailerJPNHistoryParameters, results=getXRetailerJPNHistoryResults)
  Iterator<ResultQueue1<EObjXRetailerJPN>> getXRetailerJPNHistory(Object[] parameters);  


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getXRetailerJPNByRetailerCodeSql, pattern=tableAliasString)
  @EntityMapping(parameters=getXRetailerJPNByRetailerCodeParameters, results=getXRetailerJPNByRetailerCodeResults)
  Iterator<ResultQueue1<EObjXRetailerJPN>> getXRetailerJPNByRetailerCode(Object[] parameters);  


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getXRetailerJPNByRetailerCodeHistorySql, pattern=tableAliasString)
  @EntityMapping(parameters=getXRetailerJPNByRetailerCodeHistoryParameters, results=getXRetailerJPNByRetailerCodeHistoryResults)
  Iterator<ResultQueue1<EObjXRetailerJPN>> getXRetailerJPNByRetailerCodeHistory(Object[] parameters);  


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getXRetailerJPNByNDCodeSql, pattern=tableAliasString)
  @EntityMapping(parameters=getXRetailerJPNByNDCodeParameters, results=getXRetailerJPNByNDCodeResults)
  Iterator<ResultQueue1<EObjXRetailerJPN>> getXRetailerJPNByNDCode(Object[] parameters);  


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getXRetailerJPNByNDCodeHistorySql, pattern=tableAliasString)
  @EntityMapping(parameters=getXRetailerJPNByNDCodeHistoryParameters, results=getXRetailerJPNByNDCodeHistoryResults)
  Iterator<ResultQueue1<EObjXRetailerJPN>> getXRetailerJPNByNDCodeHistory(Object[] parameters);  


}


