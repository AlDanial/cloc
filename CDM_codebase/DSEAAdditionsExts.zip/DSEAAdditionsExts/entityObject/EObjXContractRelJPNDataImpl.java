package com.ibm.daimler.dsea.entityObject;

import com.ibm.pdq.runtime.generator.BaseParameterHandler;
import java.util.Iterator;
import java.sql.PreparedStatement;
import com.ibm.pdq.runtime.statement.StatementDescriptor;
import com.ibm.pdq.runtime.generator.BaseData;
import java.sql.SQLException;
import com.ibm.pdq.annotation.Metadata;
import com.ibm.pdq.runtime.generator.BaseRowHandler;
import com.ibm.daimler.dsea.entityObject.EObjXContractRelJPN;
import com.ibm.pdq.runtime.statement.SqlStatementType;
import java.sql.Types;


/**
 * <!-- begin-user-doc -->
 * 
 * <!-- end-user-doc -->
 * 
 * @generated
 */
public class EObjXContractRelJPNDataImpl  extends BaseData implements EObjXContractRelJPNData
{

  /**
   * @generated
   */
  public static final String generatorVersion = "3.200.75";

  /**
   * @generated
   */
  public static final String identifier = "EObjXContractRelJPNData";

  /**
   * @generated
   */
  public static final long generationTime = 0x0000016676bfedb3L;

  /**
   * @generated
   */
  public static final String collection = "NULLID";

  /**
   * @generated
   */
  public static final String packageVersion = null;

  /**
   * @generated
   */
  public static final boolean forceSingleBindIsolation = false;

  /**
   * @generated
   */
  public EObjXContractRelJPNDataImpl()
  {
    super();
  } 

  /**
   * @generated
   */
  public String getGeneratorVersion()
  {
    return generatorVersion;
  }

  /**
   * @Select( sql="select XCONTRACT_RELJPNPK_ID, CONTRACT_ID, CONT_ID, MARKET_NAME, PERSON_ORG_CODE, CONTRACT_ROLE, START_DT, END_DT, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from XCONTRACTRELJPN where XCONTRACT_RELJPNPK_ID = ? " )
   * 
   * @generated
   */
  public Iterator<EObjXContractRelJPN> getEObjXContractRelJPN (Long xContractRelJPNpkId)
  {
    return queryIterator (getEObjXContractRelJPNStatementDescriptor, xContractRelJPNpkId);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getEObjXContractRelJPNStatementDescriptor = createStatementDescriptor (
    "getEObjXContractRelJPN(Long)",
    "select XCONTRACT_RELJPNPK_ID, CONTRACT_ID, CONT_ID, MARKET_NAME, PERSON_ORG_CODE, CONTRACT_ROLE, START_DT, END_DT, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from XCONTRACTRELJPN where XCONTRACT_RELJPNPK_ID = ? ",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"xcontract_reljpnpk_id", "contract_id", "cont_id", "market_name", "person_org_code", "contract_role", "start_dt", "end_dt", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetEObjXContractRelJPNParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetEObjXContractRelJPNRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 19, 19, 50, 1, 250, 0, 0, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    1);

  /**
   * @generated
   */
  public static class GetEObjXContractRelJPNParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setLong (stmt, 1, Types.BIGINT, (Long)parameters[0]);
    }
  }

  /**
   * @generated
   */
  public static class GetEObjXContractRelJPNRowHandler extends BaseRowHandler<EObjXContractRelJPN>
  {
    /**
     * @generated
     */
    public EObjXContractRelJPN handle (java.sql.ResultSet rs, EObjXContractRelJPN returnObject) throws java.sql.SQLException
    {
      returnObject = new EObjXContractRelJPN ();
      returnObject.setXContractRelJPNpkId(getLongObject (rs, 1)); 
      returnObject.setContractId(getLongObject (rs, 2)); 
      returnObject.setContId(getLongObject (rs, 3)); 
      returnObject.setMarketName(getString (rs, 4)); 
      returnObject.setPersonOrgCode(getString (rs, 5)); 
      returnObject.setContractRole(getString (rs, 6)); 
      returnObject.setStartDate(getTimestamp (rs, 7)); 
      returnObject.setEndDate(getTimestamp (rs, 8)); 
      returnObject.setLastUpdateDt(getTimestamp (rs, 9)); 
      returnObject.setLastUpdateUser(getString (rs, 10)); 
      returnObject.setLastUpdateTxId(getLongObject (rs, 11)); 
    
      return returnObject;
    }
  }

  /**
   * @Update( sql="insert into XCONTRACTRELJPN (XCONTRACT_RELJPNPK_ID, CONTRACT_ID, CONT_ID, MARKET_NAME, PERSON_ORG_CODE, CONTRACT_ROLE, START_DT, END_DT, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( :xContractRelJPNpkId, :contractId, :contId, :marketName, :personOrgCode, :contractRole, :startDate, :endDate, :lastUpdateDt, :lastUpdateUser, :lastUpdateTxId)" )
   * 
   * @generated
   */
  public int createEObjXContractRelJPN (EObjXContractRelJPN e)
  {
    return update (createEObjXContractRelJPNStatementDescriptor, e);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor createEObjXContractRelJPNStatementDescriptor = createStatementDescriptor (
    "createEObjXContractRelJPN(com.ibm.daimler.dsea.entityObject.EObjXContractRelJPN)",
    "insert into XCONTRACTRELJPN (XCONTRACT_RELJPNPK_ID, CONTRACT_ID, CONT_ID, MARKET_NAME, PERSON_ORG_CODE, CONTRACT_ROLE, START_DT, END_DT, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values(  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? )",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.INSERT,
    null,
    new CreateEObjXContractRelJPNParameterHandler (),
    new int[][]{{Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 19, 19, 50, 1, 250, 0, 0, 0, 0, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    2);

  /**
   * @generated
   */
  public static class CreateEObjXContractRelJPNParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      EObjXContractRelJPN bean0 = (EObjXContractRelJPN) parameters[0];
      setLong (stmt, 1, Types.BIGINT, (Long)bean0.getXContractRelJPNpkId());
      setLong (stmt, 2, Types.BIGINT, (Long)bean0.getContractId());
      setLong (stmt, 3, Types.BIGINT, (Long)bean0.getContId());
      setString (stmt, 4, Types.VARCHAR, (String)bean0.getMarketName());
      setString (stmt, 5, Types.VARCHAR, (String)bean0.getPersonOrgCode());
      setString (stmt, 6, Types.VARCHAR, (String)bean0.getContractRole());
      setTimestamp (stmt, 7, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getStartDate());
      setTimestamp (stmt, 8, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getEndDate());
      setTimestamp (stmt, 9, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUpdateDt());
      setString (stmt, 10, Types.VARCHAR, (String)bean0.getLastUpdateUser());
      setLong (stmt, 11, Types.BIGINT, (Long)bean0.getLastUpdateTxId());
    }
  }

  /**
   * @Update( sql="update XCONTRACTRELJPN set CONTRACT_ID = :contractId, CONT_ID = :contId, MARKET_NAME = :marketName, PERSON_ORG_CODE = :personOrgCode, CONTRACT_ROLE = :contractRole, START_DT = :startDate, END_DT = :endDate, LAST_UPDATE_DT = :lastUpdateDt, LAST_UPDATE_USER = :lastUpdateUser, LAST_UPDATE_TX_ID = :lastUpdateTxId where XCONTRACT_RELJPNPK_ID = :xContractRelJPNpkId and LAST_UPDATE_DT = :oldLastUpdateDt" )
   * 
   * @generated
   */
  public int updateEObjXContractRelJPN (EObjXContractRelJPN e)
  {
    return update (updateEObjXContractRelJPNStatementDescriptor, e);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor updateEObjXContractRelJPNStatementDescriptor = createStatementDescriptor (
    "updateEObjXContractRelJPN(com.ibm.daimler.dsea.entityObject.EObjXContractRelJPN)",
    "update XCONTRACTRELJPN set CONTRACT_ID =  ? , CONT_ID =  ? , MARKET_NAME =  ? , PERSON_ORG_CODE =  ? , CONTRACT_ROLE =  ? , START_DT =  ? , END_DT =  ? , LAST_UPDATE_DT =  ? , LAST_UPDATE_USER =  ? , LAST_UPDATE_TX_ID =  ?  where XCONTRACT_RELJPNPK_ID =  ?  and LAST_UPDATE_DT =  ? ",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.UPDATE,
    null,
    new UpdateEObjXContractRelJPNParameterHandler (),
    new int[][]{{Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP}, {19, 19, 50, 1, 250, 0, 0, 0, 0, 19, 19, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    3);

  /**
   * @generated
   */
  public static class UpdateEObjXContractRelJPNParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      EObjXContractRelJPN bean0 = (EObjXContractRelJPN) parameters[0];
      setLong (stmt, 1, Types.BIGINT, (Long)bean0.getContractId());
      setLong (stmt, 2, Types.BIGINT, (Long)bean0.getContId());
      setString (stmt, 3, Types.VARCHAR, (String)bean0.getMarketName());
      setString (stmt, 4, Types.VARCHAR, (String)bean0.getPersonOrgCode());
      setString (stmt, 5, Types.VARCHAR, (String)bean0.getContractRole());
      setTimestamp (stmt, 6, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getStartDate());
      setTimestamp (stmt, 7, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getEndDate());
      setTimestamp (stmt, 8, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUpdateDt());
      setString (stmt, 9, Types.VARCHAR, (String)bean0.getLastUpdateUser());
      setLong (stmt, 10, Types.BIGINT, (Long)bean0.getLastUpdateTxId());
      setLong (stmt, 11, Types.BIGINT, (Long)bean0.getXContractRelJPNpkId());
      setTimestamp (stmt, 12, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getOldLastUpdateDt());
    }
  }

  /**
   * @Update( sql="delete from XCONTRACTRELJPN where XCONTRACT_RELJPNPK_ID = ?" )
   * 
   * @generated
   */
  public int deleteEObjXContractRelJPN (Long xContractRelJPNpkId)
  {
    return update (deleteEObjXContractRelJPNStatementDescriptor, xContractRelJPNpkId);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor deleteEObjXContractRelJPNStatementDescriptor = createStatementDescriptor (
    "deleteEObjXContractRelJPN(Long)",
    "delete from XCONTRACTRELJPN where XCONTRACT_RELJPNPK_ID = ?",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.DELETE,
    null,
    new DeleteEObjXContractRelJPNParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    4);

  /**
   * @generated
   */
  public static class DeleteEObjXContractRelJPNParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setLong (stmt, 1, Types.BIGINT, (Long)parameters[0]);
    }
  }

}
