package com.ibm.daimler.dsea.entityObject;

import com.ibm.pdq.runtime.generator.BaseParameterHandler;
import java.util.Iterator;
import com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt;
import com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup;
import java.sql.PreparedStatement;
import com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup;
import com.ibm.pdq.runtime.statement.StatementDescriptor;
import com.ibm.pdq.runtime.generator.BaseData;
import java.sql.SQLException;
import com.ibm.pdq.annotation.Metadata;
import com.ibm.mdm.base.db.ResultQueue3;
import com.ibm.mdm.base.db.ResultQueue2;
import com.ibm.pdq.runtime.generator.BaseRowHandler;
import com.ibm.pdq.runtime.statement.SqlStatementType;
import java.sql.Types;


@SuppressWarnings("unchecked")

/**
 * <!-- begin-user-doc -->
 * 
 * <!-- end-user-doc -->
 * 
 * @generated
 */
public class XAddressGroupExtInquiryDataImpl  extends BaseData implements XAddressGroupExtInquiryData
{

  /**
   * @generated
   */
  public static final String generatorVersion = "3.200.75";

  /**
   * @generated
   */
  public static final String identifier = "XAddressGroupExtInquiryData";

  /**
   * @generated
   */
  public static final long generationTime = 0x00000164c354c9a7L;

  /**
   * @generated
   */
  public static final String collection = "NULLID";

  /**
   * @generated
   */
  public static final String packageVersion = null;

  /**
   * @generated
   */
  public static final boolean forceSingleBindIsolation = false;

  /**
   * @generated
   */
  public XAddressGroupExtInquiryDataImpl()
  {
    super();
  } 

  /**
   * @generated
   */
  public String getGeneratorVersion()
  {
    return generatorVersion;
  }

  /**
   * @Select( sql="SELECT ADDRESSGROUP.LOCATION_GROUP_ID, ADDRESSGROUP.ADDRESS_ID , ADDRESSGROUP.CARE_OF_DESC, ADDRESSGROUP.ADDR_USAGE_TP_CD, ADDRESSGROUP.LAST_UPDATE_DT, ADDRESSGROUP.LAST_UPDATE_USER, ADDRESSGROUP.LAST_UPDATE_TX_ID , LOCATIONGROUP.LOCATION_GROUP_ID, LOCATIONGROUP.UNDEL_REASON_TP_CD, LOCATIONGROUP.CONT_ID , LOCATIONGROUP.MEMBER_IND , LOCATIONGROUP.PREFERRED_IND , LOCATIONGROUP.SOLICIT_IND, LOCATIONGROUP.LOC_GROUP_TP_CODE, LOCATIONGROUP.EFFECT_START_MMDD , LOCATIONGROUP.EFFECT_END_MMDD , LOCATIONGROUP.EFFECT_START_TM , LOCATIONGROUP.EFFECT_END_TM , LOCATIONGROUP.START_DT , LOCATIONGROUP.END_DT , LOCATIONGROUP.LAST_UPDATE_DT , LOCATIONGROUP.LAST_UPDATE_USER , LOCATIONGROUP.LAST_UPDATE_TX_ID , LOCATIONGROUP.LAST_USED_DT , LOCATIONGROUP.LAST_VERIFIED_DT , LOCATIONGROUP.SOURCE_IDENT_TP_CD, ADDRESSGROUP.XVERIFIED_TP_CD, ADDRESSGROUP.XRETAILER_ID, ADDRESSGROUP.XMODIFY_SYS_DT, ADDRESSGROUP.XADDR_RETAILER_FLAG, ADDRESSGROUP.TITLE_OF_HONOR, ADDRESSGROUP.COMPANY_NAME, ADDRESSGROUP.SFAddress_Id, ADDRESSGROUP.X_BPID FROM ADDRESSGROUP,LOCATIONGROUP WHERE ADDRESSGROUP.LOCATION_GROUP_ID = LOCATIONGROUP.LOCATION_GROUP_ID AND LOCATIONGROUP.CONT_ID = ? AND ((LOCATIONGROUP.END_DT IS NULL) OR (LOCATIONGROUP.END_DT > ? ))", pattern="tableAlias (ADDRESSGROUP => com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup, H_ADDRESSGROUP => com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup, LOCATIONGROUP => com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup, H_LOCATIONGROUP => com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup , ADDRESSGROUP => com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt , H_ADDRESSGROUP => com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue3<EObjAddressGroup,EObjLocationGroup,EObjXAddressGroupExt>> getPartyAddressesActive (Object[] parameters)
  {
    return queryIterator (getPartyAddressesActiveStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getPartyAddressesActiveStatementDescriptor = createStatementDescriptor (
    "getPartyAddressesActive(Object[])",
    "SELECT ADDRESSGROUP.LOCATION_GROUP_ID, ADDRESSGROUP.ADDRESS_ID , ADDRESSGROUP.CARE_OF_DESC, ADDRESSGROUP.ADDR_USAGE_TP_CD, ADDRESSGROUP.LAST_UPDATE_DT, ADDRESSGROUP.LAST_UPDATE_USER, ADDRESSGROUP.LAST_UPDATE_TX_ID , LOCATIONGROUP.LOCATION_GROUP_ID, LOCATIONGROUP.UNDEL_REASON_TP_CD, LOCATIONGROUP.CONT_ID , LOCATIONGROUP.MEMBER_IND , LOCATIONGROUP.PREFERRED_IND , LOCATIONGROUP.SOLICIT_IND, LOCATIONGROUP.LOC_GROUP_TP_CODE, LOCATIONGROUP.EFFECT_START_MMDD , LOCATIONGROUP.EFFECT_END_MMDD , LOCATIONGROUP.EFFECT_START_TM , LOCATIONGROUP.EFFECT_END_TM , LOCATIONGROUP.START_DT , LOCATIONGROUP.END_DT , LOCATIONGROUP.LAST_UPDATE_DT , LOCATIONGROUP.LAST_UPDATE_USER , LOCATIONGROUP.LAST_UPDATE_TX_ID , LOCATIONGROUP.LAST_USED_DT , LOCATIONGROUP.LAST_VERIFIED_DT , LOCATIONGROUP.SOURCE_IDENT_TP_CD, ADDRESSGROUP.XVERIFIED_TP_CD, ADDRESSGROUP.XRETAILER_ID, ADDRESSGROUP.XMODIFY_SYS_DT, ADDRESSGROUP.XADDR_RETAILER_FLAG, ADDRESSGROUP.TITLE_OF_HONOR, ADDRESSGROUP.COMPANY_NAME, ADDRESSGROUP.SFAddress_Id, ADDRESSGROUP.X_BPID FROM ADDRESSGROUP,LOCATIONGROUP WHERE ADDRESSGROUP.LOCATION_GROUP_ID = LOCATIONGROUP.LOCATION_GROUP_ID AND LOCATIONGROUP.CONT_ID = ? AND ((LOCATIONGROUP.END_DT IS NULL) OR (LOCATIONGROUP.END_DT > ? ))",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"location_group_id", "address_id", "care_of_desc", "addr_usage_tp_cd", "last_update_dt", "last_update_user", "last_update_tx_id", "location_group_id", "undel_reason_tp_cd", "cont_id", "member_ind", "preferred_ind", "solicit_ind", "loc_group_tp_code", "effect_start_mmdd", "effect_end_mmdd", "effect_start_tm", "effect_end_tm", "start_dt", "end_dt", "last_update_dt", "last_update_user", "last_update_tx_id", "last_used_dt", "last_verified_dt", "source_ident_tp_cd", "xverified_tp_cd", "xretailer_id", "xmodify_sys_dt", "xaddr_retailer_flag", "title_of_honor", "company_name", "sfaddress_id", "x_bpid"},
    new GetPartyAddressesActiveParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP}, {19, 0}, {0, 0}, {1, 1}},
    null,
    new GetPartyAddressesActiveRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR}, {19, 19, 50, 19, 0, 20, 19, 19, 19, 19, 0, 0, 0, 0, 10, 10, 10, 10, 0, 0, 0, 20, 19, 0, 0, 19, 19, 19, 0, 5, 255, 255, 250, 50}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    1);

  /**
   * @generated
   */
  public static class GetPartyAddressesActiveParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetPartyAddressesActiveRowHandler extends BaseRowHandler<ResultQueue3<EObjAddressGroup,EObjLocationGroup,EObjXAddressGroupExt>>
  {
    /**
     * @generated
     */
    public ResultQueue3<EObjAddressGroup,EObjLocationGroup,EObjXAddressGroupExt> handle (java.sql.ResultSet rs, ResultQueue3<EObjAddressGroup,EObjLocationGroup,EObjXAddressGroupExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue3<EObjAddressGroup,EObjLocationGroup,EObjXAddressGroupExt> ();

      EObjAddressGroup returnObject1 = new EObjAddressGroup ();
      returnObject1.setLocationGroupIdPK(getLongObject (rs, 1)); 
      returnObject1.setAddressId(getLongObject (rs, 2)); 
      returnObject1.setCareOfDesc(getString (rs, 3)); 
      returnObject1.setAddrUsageTpCd(getLongObject (rs, 4)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 5)); 
      returnObject1.setLastUpdateUser(getString (rs, 6)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 7)); 
      returnObject.add (returnObject1);

      EObjLocationGroup returnObject2 = new EObjLocationGroup ();
      returnObject2.setLocationGroupIdPK(getLongObject (rs, 8)); 
      returnObject2.setUndelReasonTpCd(getLongObject (rs, 9)); 
      returnObject2.setContId(getLongObject (rs, 10)); 
      returnObject2.setMemberInd(getString (rs, 11)); 
      returnObject2.setPreferredInd(getString (rs, 12)); 
      returnObject2.setSolicitInd(getString (rs, 13)); 
      returnObject2.setLocGroupTpCode(getString (rs, 14)); 
      returnObject2.setEffectStartMMDD(getIntObject (rs, 15)); 
      returnObject2.setEffectEndMMDD(getIntObject (rs, 16)); 
      returnObject2.setEffectStartTm(getIntObject (rs, 17)); 
      returnObject2.setEffectEndTm(getIntObject (rs, 18)); 
      returnObject2.setStartDt(getTimestamp (rs, 19)); 
      returnObject2.setEndDt(getTimestamp (rs, 20)); 
      returnObject2.setLastUpdateDt(getTimestamp (rs, 21)); 
      returnObject2.setLastUpdateUser(getString (rs, 22)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 23)); 
      returnObject2.setLastUsedDt(getTimestamp (rs, 24)); 
      returnObject2.setLastVerifiedDt(getTimestamp (rs, 25)); 
      returnObject2.setSourceIdentTpCd(getLongObject (rs, 26)); 
      returnObject.add (returnObject2);

      EObjXAddressGroupExt returnObject3 = new EObjXAddressGroupExt ();
      returnObject3.setLastUpdateDt(getTimestamp (rs, 5)); 
      returnObject3.setLastUpdateUser(getString (rs, 6)); 
      returnObject3.setLastUpdateTxId(getLongObject (rs, 7)); 
      returnObject3.setXVerified(getLongObject (rs, 27)); 
      returnObject3.setXRetailerId(getLongObject (rs, 28)); 
      returnObject3.setXLastModifiedSystemDate(getTimestamp (rs, 29)); 
      returnObject3.setXAddressRetailerFlag(getString (rs, 30)); 
      returnObject3.setTitleOfHonor(getString (rs, 31)); 
      returnObject3.setCompanyName(getString (rs, 32)); 
      returnObject3.setSFAddressId(getString (rs, 33)); 
      returnObject3.setX_BPID(getString (rs, 34)); 
      returnObject.add (returnObject3);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT ADDRESSGROUP.LOCATION_GROUP_ID, ADDRESSGROUP.ADDRESS_ID, ADDRESSGROUP.CARE_OF_DESC, ADDRESSGROUP.ADDR_USAGE_TP_CD, ADDRESSGROUP.LAST_UPDATE_DT, ADDRESSGROUP.LAST_UPDATE_USER, ADDRESSGROUP.LAST_UPDATE_TX_ID, LOCATIONGROUP.LOCATION_GROUP_ID, LOCATIONGROUP.UNDEL_REASON_TP_CD, LOCATIONGROUP.CONT_ID, LOCATIONGROUP.MEMBER_IND, LOCATIONGROUP.PREFERRED_IND, LOCATIONGROUP.SOLICIT_IND , LOCATIONGROUP.LOC_GROUP_TP_CODE, LOCATIONGROUP.EFFECT_START_MMDD, LOCATIONGROUP.EFFECT_END_MMDD, LOCATIONGROUP.EFFECT_START_TM, LOCATIONGROUP.EFFECT_END_TM, LOCATIONGROUP.START_DT, LOCATIONGROUP.END_DT, LOCATIONGROUP.LAST_UPDATE_DT, LOCATIONGROUP.LAST_UPDATE_USER, LOCATIONGROUP.LAST_UPDATE_TX_ID, LOCATIONGROUP.LAST_USED_DT, LOCATIONGROUP.LAST_VERIFIED_DT, LOCATIONGROUP.SOURCE_IDENT_TP_CD, ADDRESSGROUP.XVERIFIED_TP_CD, ADDRESSGROUP.XRETAILER_ID, ADDRESSGROUP.XMODIFY_SYS_DT, ADDRESSGROUP.XADDR_RETAILER_FLAG, ADDRESSGROUP.TITLE_OF_HONOR, ADDRESSGROUP.COMPANY_NAME, ADDRESSGROUP.SFAddress_Id, ADDRESSGROUP.X_BPID FROM ADDRESSGROUP,LOCATIONGROUP WHERE ADDRESSGROUP.LOCATION_GROUP_ID = LOCATIONGROUP.LOCATION_GROUP_ID AND LOCATIONGROUP.CONT_ID = ? AND (LOCATIONGROUP.END_DT < ?)", pattern="tableAlias (ADDRESSGROUP => com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup, H_ADDRESSGROUP => com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup, LOCATIONGROUP => com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup, H_LOCATIONGROUP => com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup , ADDRESSGROUP => com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt , H_ADDRESSGROUP => com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue3<EObjAddressGroup,EObjLocationGroup,EObjXAddressGroupExt>> getPartyAddressesInactive (Object[] parameters)
  {
    return queryIterator (getPartyAddressesInactiveStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getPartyAddressesInactiveStatementDescriptor = createStatementDescriptor (
    "getPartyAddressesInactive(Object[])",
    "SELECT ADDRESSGROUP.LOCATION_GROUP_ID, ADDRESSGROUP.ADDRESS_ID, ADDRESSGROUP.CARE_OF_DESC, ADDRESSGROUP.ADDR_USAGE_TP_CD, ADDRESSGROUP.LAST_UPDATE_DT, ADDRESSGROUP.LAST_UPDATE_USER, ADDRESSGROUP.LAST_UPDATE_TX_ID, LOCATIONGROUP.LOCATION_GROUP_ID, LOCATIONGROUP.UNDEL_REASON_TP_CD, LOCATIONGROUP.CONT_ID, LOCATIONGROUP.MEMBER_IND, LOCATIONGROUP.PREFERRED_IND, LOCATIONGROUP.SOLICIT_IND , LOCATIONGROUP.LOC_GROUP_TP_CODE, LOCATIONGROUP.EFFECT_START_MMDD, LOCATIONGROUP.EFFECT_END_MMDD, LOCATIONGROUP.EFFECT_START_TM, LOCATIONGROUP.EFFECT_END_TM, LOCATIONGROUP.START_DT, LOCATIONGROUP.END_DT, LOCATIONGROUP.LAST_UPDATE_DT, LOCATIONGROUP.LAST_UPDATE_USER, LOCATIONGROUP.LAST_UPDATE_TX_ID, LOCATIONGROUP.LAST_USED_DT, LOCATIONGROUP.LAST_VERIFIED_DT, LOCATIONGROUP.SOURCE_IDENT_TP_CD, ADDRESSGROUP.XVERIFIED_TP_CD, ADDRESSGROUP.XRETAILER_ID, ADDRESSGROUP.XMODIFY_SYS_DT, ADDRESSGROUP.XADDR_RETAILER_FLAG, ADDRESSGROUP.TITLE_OF_HONOR, ADDRESSGROUP.COMPANY_NAME, ADDRESSGROUP.SFAddress_Id, ADDRESSGROUP.X_BPID FROM ADDRESSGROUP,LOCATIONGROUP WHERE ADDRESSGROUP.LOCATION_GROUP_ID = LOCATIONGROUP.LOCATION_GROUP_ID AND LOCATIONGROUP.CONT_ID = ? AND (LOCATIONGROUP.END_DT < ?)",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"location_group_id", "address_id", "care_of_desc", "addr_usage_tp_cd", "last_update_dt", "last_update_user", "last_update_tx_id", "location_group_id", "undel_reason_tp_cd", "cont_id", "member_ind", "preferred_ind", "solicit_ind", "loc_group_tp_code", "effect_start_mmdd", "effect_end_mmdd", "effect_start_tm", "effect_end_tm", "start_dt", "end_dt", "last_update_dt", "last_update_user", "last_update_tx_id", "last_used_dt", "last_verified_dt", "source_ident_tp_cd", "xverified_tp_cd", "xretailer_id", "xmodify_sys_dt", "xaddr_retailer_flag", "title_of_honor", "company_name", "sfaddress_id", "x_bpid"},
    new GetPartyAddressesInactiveParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP}, {19, 0}, {0, 0}, {1, 1}},
    null,
    new GetPartyAddressesInactiveRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR}, {19, 19, 50, 19, 0, 20, 19, 19, 19, 19, 0, 0, 0, 0, 10, 10, 10, 10, 0, 0, 0, 20, 19, 0, 0, 19, 19, 19, 0, 5, 255, 255, 250, 50}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    2);

  /**
   * @generated
   */
  public static class GetPartyAddressesInactiveParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetPartyAddressesInactiveRowHandler extends BaseRowHandler<ResultQueue3<EObjAddressGroup,EObjLocationGroup,EObjXAddressGroupExt>>
  {
    /**
     * @generated
     */
    public ResultQueue3<EObjAddressGroup,EObjLocationGroup,EObjXAddressGroupExt> handle (java.sql.ResultSet rs, ResultQueue3<EObjAddressGroup,EObjLocationGroup,EObjXAddressGroupExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue3<EObjAddressGroup,EObjLocationGroup,EObjXAddressGroupExt> ();

      EObjAddressGroup returnObject1 = new EObjAddressGroup ();
      returnObject1.setLocationGroupIdPK(getLongObject (rs, 1)); 
      returnObject1.setAddressId(getLongObject (rs, 2)); 
      returnObject1.setCareOfDesc(getString (rs, 3)); 
      returnObject1.setAddrUsageTpCd(getLongObject (rs, 4)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 5)); 
      returnObject1.setLastUpdateUser(getString (rs, 6)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 7)); 
      returnObject.add (returnObject1);

      EObjLocationGroup returnObject2 = new EObjLocationGroup ();
      returnObject2.setLocationGroupIdPK(getLongObject (rs, 8)); 
      returnObject2.setUndelReasonTpCd(getLongObject (rs, 9)); 
      returnObject2.setContId(getLongObject (rs, 10)); 
      returnObject2.setMemberInd(getString (rs, 11)); 
      returnObject2.setPreferredInd(getString (rs, 12)); 
      returnObject2.setSolicitInd(getString (rs, 13)); 
      returnObject2.setLocGroupTpCode(getString (rs, 14)); 
      returnObject2.setEffectStartMMDD(getIntObject (rs, 15)); 
      returnObject2.setEffectEndMMDD(getIntObject (rs, 16)); 
      returnObject2.setEffectStartTm(getIntObject (rs, 17)); 
      returnObject2.setEffectEndTm(getIntObject (rs, 18)); 
      returnObject2.setStartDt(getTimestamp (rs, 19)); 
      returnObject2.setEndDt(getTimestamp (rs, 20)); 
      returnObject2.setLastUpdateDt(getTimestamp (rs, 21)); 
      returnObject2.setLastUpdateUser(getString (rs, 22)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 23)); 
      returnObject2.setLastUsedDt(getTimestamp (rs, 24)); 
      returnObject2.setLastVerifiedDt(getTimestamp (rs, 25)); 
      returnObject2.setSourceIdentTpCd(getLongObject (rs, 26)); 
      returnObject.add (returnObject2);

      EObjXAddressGroupExt returnObject3 = new EObjXAddressGroupExt ();
      returnObject3.setLastUpdateDt(getTimestamp (rs, 5)); 
      returnObject3.setLastUpdateUser(getString (rs, 6)); 
      returnObject3.setLastUpdateTxId(getLongObject (rs, 7)); 
      returnObject3.setXVerified(getLongObject (rs, 27)); 
      returnObject3.setXRetailerId(getLongObject (rs, 28)); 
      returnObject3.setXLastModifiedSystemDate(getTimestamp (rs, 29)); 
      returnObject3.setXAddressRetailerFlag(getString (rs, 30)); 
      returnObject3.setTitleOfHonor(getString (rs, 31)); 
      returnObject3.setCompanyName(getString (rs, 32)); 
      returnObject3.setSFAddressId(getString (rs, 33)); 
      returnObject3.setX_BPID(getString (rs, 34)); 
      returnObject.add (returnObject3);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT ADDRESSGROUP.LOCATION_GROUP_ID , ADDRESSGROUP.ADDRESS_ID , ADDRESSGROUP.CARE_OF_DESC , ADDRESSGROUP.ADDR_USAGE_TP_CD , ADDRESSGROUP.LAST_UPDATE_DT , ADDRESSGROUP.LAST_UPDATE_USER , ADDRESSGROUP.LAST_UPDATE_TX_ID , LOCATIONGROUP.LOCATION_GROUP_ID , LOCATIONGROUP.UNDEL_REASON_TP_CD , LOCATIONGROUP.CONT_ID , LOCATIONGROUP.MEMBER_IND , LOCATIONGROUP.PREFERRED_IND , LOCATIONGROUP.SOLICIT_IND , LOCATIONGROUP.LOC_GROUP_TP_CODE , LOCATIONGROUP.EFFECT_START_MMDD , LOCATIONGROUP.EFFECT_END_MMDD , LOCATIONGROUP.EFFECT_START_TM , LOCATIONGROUP.EFFECT_END_TM , LOCATIONGROUP.START_DT , LOCATIONGROUP.END_DT , LOCATIONGROUP.LAST_UPDATE_DT , LOCATIONGROUP.LAST_UPDATE_USER , LOCATIONGROUP.LAST_UPDATE_TX_ID , LOCATIONGROUP.LAST_USED_DT , LOCATIONGROUP.LAST_VERIFIED_DT , LOCATIONGROUP.SOURCE_IDENT_TP_CD, ADDRESSGROUP.XVERIFIED_TP_CD, ADDRESSGROUP.XRETAILER_ID, ADDRESSGROUP.XMODIFY_SYS_DT, ADDRESSGROUP.XADDR_RETAILER_FLAG, ADDRESSGROUP.TITLE_OF_HONOR, ADDRESSGROUP.COMPANY_NAME, ADDRESSGROUP.SFAddress_Id, ADDRESSGROUP.X_BPID FROM CONTACT, ADDRESSGROUP, LOCATIONGROUP WHERE ADDRESSGROUP.LOCATION_GROUP_ID = LOCATIONGROUP.LOCATION_GROUP_ID AND ADDRESSGROUP.ADDRESS_ID = ? AND ((LOCATIONGROUP.END_DT IS NULL) OR (LOCATIONGROUP.END_DT > ?)) AND (LOCATIONGROUP.CONT_ID = CONTACT.CONT_ID ) AND ((CONTACT.INACTIVATED_DT IS NULL) OR (CONTACT.INACTIVATED_DT > ? ))", pattern="tableAlias (ADDRESSGROUP => com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup, H_ADDRESSGROUP => com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup, LOCATIONGROUP => com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup, H_LOCATIONGROUP => com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup , ADDRESSGROUP => com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt , H_ADDRESSGROUP => com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue3<EObjAddressGroup,EObjLocationGroup,EObjXAddressGroupExt>> getPartyAddressesByAddressId (Object[] parameters)
  {
    return queryIterator (getPartyAddressesByAddressIdStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getPartyAddressesByAddressIdStatementDescriptor = createStatementDescriptor (
    "getPartyAddressesByAddressId(Object[])",
    "SELECT ADDRESSGROUP.LOCATION_GROUP_ID , ADDRESSGROUP.ADDRESS_ID , ADDRESSGROUP.CARE_OF_DESC , ADDRESSGROUP.ADDR_USAGE_TP_CD , ADDRESSGROUP.LAST_UPDATE_DT , ADDRESSGROUP.LAST_UPDATE_USER , ADDRESSGROUP.LAST_UPDATE_TX_ID , LOCATIONGROUP.LOCATION_GROUP_ID , LOCATIONGROUP.UNDEL_REASON_TP_CD , LOCATIONGROUP.CONT_ID , LOCATIONGROUP.MEMBER_IND , LOCATIONGROUP.PREFERRED_IND , LOCATIONGROUP.SOLICIT_IND , LOCATIONGROUP.LOC_GROUP_TP_CODE , LOCATIONGROUP.EFFECT_START_MMDD , LOCATIONGROUP.EFFECT_END_MMDD , LOCATIONGROUP.EFFECT_START_TM , LOCATIONGROUP.EFFECT_END_TM , LOCATIONGROUP.START_DT , LOCATIONGROUP.END_DT , LOCATIONGROUP.LAST_UPDATE_DT , LOCATIONGROUP.LAST_UPDATE_USER , LOCATIONGROUP.LAST_UPDATE_TX_ID , LOCATIONGROUP.LAST_USED_DT , LOCATIONGROUP.LAST_VERIFIED_DT , LOCATIONGROUP.SOURCE_IDENT_TP_CD, ADDRESSGROUP.XVERIFIED_TP_CD, ADDRESSGROUP.XRETAILER_ID, ADDRESSGROUP.XMODIFY_SYS_DT, ADDRESSGROUP.XADDR_RETAILER_FLAG, ADDRESSGROUP.TITLE_OF_HONOR, ADDRESSGROUP.COMPANY_NAME, ADDRESSGROUP.SFAddress_Id, ADDRESSGROUP.X_BPID FROM CONTACT, ADDRESSGROUP, LOCATIONGROUP WHERE ADDRESSGROUP.LOCATION_GROUP_ID = LOCATIONGROUP.LOCATION_GROUP_ID AND ADDRESSGROUP.ADDRESS_ID = ? AND ((LOCATIONGROUP.END_DT IS NULL) OR (LOCATIONGROUP.END_DT > ?)) AND (LOCATIONGROUP.CONT_ID = CONTACT.CONT_ID ) AND ((CONTACT.INACTIVATED_DT IS NULL) OR (CONTACT.INACTIVATED_DT > ? ))",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"location_group_id", "address_id", "care_of_desc", "addr_usage_tp_cd", "last_update_dt", "last_update_user", "last_update_tx_id", "location_group_id", "undel_reason_tp_cd", "cont_id", "member_ind", "preferred_ind", "solicit_ind", "loc_group_tp_code", "effect_start_mmdd", "effect_end_mmdd", "effect_start_tm", "effect_end_tm", "start_dt", "end_dt", "last_update_dt", "last_update_user", "last_update_tx_id", "last_used_dt", "last_verified_dt", "source_ident_tp_cd", "xverified_tp_cd", "xretailer_id", "xmodify_sys_dt", "xaddr_retailer_flag", "title_of_honor", "company_name", "sfaddress_id", "x_bpid"},
    new GetPartyAddressesByAddressIdParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP}, {19, 0, 0}, {0, 0, 0}, {1, 1, 1}},
    null,
    new GetPartyAddressesByAddressIdRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR}, {19, 19, 50, 19, 0, 20, 19, 19, 19, 19, 0, 0, 0, 0, 10, 10, 10, 10, 0, 0, 0, 20, 19, 0, 0, 19, 19, 19, 0, 5, 255, 255, 250, 50}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    3);

  /**
   * @generated
   */
  public static class GetPartyAddressesByAddressIdParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetPartyAddressesByAddressIdRowHandler extends BaseRowHandler<ResultQueue3<EObjAddressGroup,EObjLocationGroup,EObjXAddressGroupExt>>
  {
    /**
     * @generated
     */
    public ResultQueue3<EObjAddressGroup,EObjLocationGroup,EObjXAddressGroupExt> handle (java.sql.ResultSet rs, ResultQueue3<EObjAddressGroup,EObjLocationGroup,EObjXAddressGroupExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue3<EObjAddressGroup,EObjLocationGroup,EObjXAddressGroupExt> ();

      EObjAddressGroup returnObject1 = new EObjAddressGroup ();
      returnObject1.setLocationGroupIdPK(getLongObject (rs, 1)); 
      returnObject1.setAddressId(getLongObject (rs, 2)); 
      returnObject1.setCareOfDesc(getString (rs, 3)); 
      returnObject1.setAddrUsageTpCd(getLongObject (rs, 4)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 5)); 
      returnObject1.setLastUpdateUser(getString (rs, 6)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 7)); 
      returnObject.add (returnObject1);

      EObjLocationGroup returnObject2 = new EObjLocationGroup ();
      returnObject2.setLocationGroupIdPK(getLongObject (rs, 8)); 
      returnObject2.setUndelReasonTpCd(getLongObject (rs, 9)); 
      returnObject2.setContId(getLongObject (rs, 10)); 
      returnObject2.setMemberInd(getString (rs, 11)); 
      returnObject2.setPreferredInd(getString (rs, 12)); 
      returnObject2.setSolicitInd(getString (rs, 13)); 
      returnObject2.setLocGroupTpCode(getString (rs, 14)); 
      returnObject2.setEffectStartMMDD(getIntObject (rs, 15)); 
      returnObject2.setEffectEndMMDD(getIntObject (rs, 16)); 
      returnObject2.setEffectStartTm(getIntObject (rs, 17)); 
      returnObject2.setEffectEndTm(getIntObject (rs, 18)); 
      returnObject2.setStartDt(getTimestamp (rs, 19)); 
      returnObject2.setEndDt(getTimestamp (rs, 20)); 
      returnObject2.setLastUpdateDt(getTimestamp (rs, 21)); 
      returnObject2.setLastUpdateUser(getString (rs, 22)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 23)); 
      returnObject2.setLastUsedDt(getTimestamp (rs, 24)); 
      returnObject2.setLastVerifiedDt(getTimestamp (rs, 25)); 
      returnObject2.setSourceIdentTpCd(getLongObject (rs, 26)); 
      returnObject.add (returnObject2);

      EObjXAddressGroupExt returnObject3 = new EObjXAddressGroupExt ();
      returnObject3.setLastUpdateDt(getTimestamp (rs, 5)); 
      returnObject3.setLastUpdateUser(getString (rs, 6)); 
      returnObject3.setLastUpdateTxId(getLongObject (rs, 7)); 
      returnObject3.setXVerified(getLongObject (rs, 27)); 
      returnObject3.setXRetailerId(getLongObject (rs, 28)); 
      returnObject3.setXLastModifiedSystemDate(getTimestamp (rs, 29)); 
      returnObject3.setXAddressRetailerFlag(getString (rs, 30)); 
      returnObject3.setTitleOfHonor(getString (rs, 31)); 
      returnObject3.setCompanyName(getString (rs, 32)); 
      returnObject3.setSFAddressId(getString (rs, 33)); 
      returnObject3.setX_BPID(getString (rs, 34)); 
      returnObject.add (returnObject3);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT ADDRESSGROUP.LOCATION_GROUP_ID , ADDRESSGROUP.ADDRESS_ID , ADDRESSGROUP.CARE_OF_DESC, ADDRESSGROUP.ADDR_USAGE_TP_CD , ADDRESSGROUP.LAST_UPDATE_DT , ADDRESSGROUP.LAST_UPDATE_USER, ADDRESSGROUP.LAST_UPDATE_TX_ID, LOCATIONGROUP.LOCATION_GROUP_ID , LOCATIONGROUP.UNDEL_REASON_TP_CD , LOCATIONGROUP.CONT_ID , LOCATIONGROUP.MEMBER_IND, LOCATIONGROUP.PREFERRED_IND , LOCATIONGROUP.SOLICIT_IND , LOCATIONGROUP.LOC_GROUP_TP_CODE , LOCATIONGROUP.EFFECT_START_MMDD , LOCATIONGROUP.EFFECT_END_MMDD , LOCATIONGROUP.EFFECT_START_TM , LOCATIONGROUP.EFFECT_END_TM , LOCATIONGROUP.START_DT , LOCATIONGROUP.END_DT , LOCATIONGROUP.LAST_UPDATE_DT , LOCATIONGROUP.LAST_UPDATE_USER, LOCATIONGROUP.LAST_UPDATE_TX_ID, LOCATIONGROUP.LAST_USED_DT , LOCATIONGROUP.LAST_VERIFIED_DT , LOCATIONGROUP.SOURCE_IDENT_TP_CD, ADDRESSGROUP.XVERIFIED_TP_CD, ADDRESSGROUP.XRETAILER_ID, ADDRESSGROUP.XMODIFY_SYS_DT, ADDRESSGROUP.XADDR_RETAILER_FLAG, ADDRESSGROUP.TITLE_OF_HONOR, ADDRESSGROUP.COMPANY_NAME, ADDRESSGROUP.SFAddress_Id, ADDRESSGROUP.X_BPID FROM ADDRESSGROUP, LOCATIONGROUP WHERE ADDRESSGROUP.LOCATION_GROUP_ID = LOCATIONGROUP.LOCATION_GROUP_ID AND LOCATIONGROUP.LOCATION_GROUP_ID = ?", pattern="tableAlias (ADDRESSGROUP => com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup, H_ADDRESSGROUP => com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup, LOCATIONGROUP => com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup, H_LOCATIONGROUP => com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup , ADDRESSGROUP => com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt , H_ADDRESSGROUP => com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue3<EObjAddressGroup,EObjLocationGroup,EObjXAddressGroupExt>> getPartyAddressById (Object[] parameters)
  {
    return queryIterator (getPartyAddressByIdStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getPartyAddressByIdStatementDescriptor = createStatementDescriptor (
    "getPartyAddressById(Object[])",
    "SELECT ADDRESSGROUP.LOCATION_GROUP_ID , ADDRESSGROUP.ADDRESS_ID , ADDRESSGROUP.CARE_OF_DESC, ADDRESSGROUP.ADDR_USAGE_TP_CD , ADDRESSGROUP.LAST_UPDATE_DT , ADDRESSGROUP.LAST_UPDATE_USER, ADDRESSGROUP.LAST_UPDATE_TX_ID, LOCATIONGROUP.LOCATION_GROUP_ID , LOCATIONGROUP.UNDEL_REASON_TP_CD , LOCATIONGROUP.CONT_ID , LOCATIONGROUP.MEMBER_IND, LOCATIONGROUP.PREFERRED_IND , LOCATIONGROUP.SOLICIT_IND , LOCATIONGROUP.LOC_GROUP_TP_CODE , LOCATIONGROUP.EFFECT_START_MMDD , LOCATIONGROUP.EFFECT_END_MMDD , LOCATIONGROUP.EFFECT_START_TM , LOCATIONGROUP.EFFECT_END_TM , LOCATIONGROUP.START_DT , LOCATIONGROUP.END_DT , LOCATIONGROUP.LAST_UPDATE_DT , LOCATIONGROUP.LAST_UPDATE_USER, LOCATIONGROUP.LAST_UPDATE_TX_ID, LOCATIONGROUP.LAST_USED_DT , LOCATIONGROUP.LAST_VERIFIED_DT , LOCATIONGROUP.SOURCE_IDENT_TP_CD, ADDRESSGROUP.XVERIFIED_TP_CD, ADDRESSGROUP.XRETAILER_ID, ADDRESSGROUP.XMODIFY_SYS_DT, ADDRESSGROUP.XADDR_RETAILER_FLAG, ADDRESSGROUP.TITLE_OF_HONOR, ADDRESSGROUP.COMPANY_NAME, ADDRESSGROUP.SFAddress_Id, ADDRESSGROUP.X_BPID FROM ADDRESSGROUP, LOCATIONGROUP WHERE ADDRESSGROUP.LOCATION_GROUP_ID = LOCATIONGROUP.LOCATION_GROUP_ID AND LOCATIONGROUP.LOCATION_GROUP_ID = ?",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"location_group_id", "address_id", "care_of_desc", "addr_usage_tp_cd", "last_update_dt", "last_update_user", "last_update_tx_id", "location_group_id", "undel_reason_tp_cd", "cont_id", "member_ind", "preferred_ind", "solicit_ind", "loc_group_tp_code", "effect_start_mmdd", "effect_end_mmdd", "effect_start_tm", "effect_end_tm", "start_dt", "end_dt", "last_update_dt", "last_update_user", "last_update_tx_id", "last_used_dt", "last_verified_dt", "source_ident_tp_cd", "xverified_tp_cd", "xretailer_id", "xmodify_sys_dt", "xaddr_retailer_flag", "title_of_honor", "company_name", "sfaddress_id", "x_bpid"},
    new GetPartyAddressByIdParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetPartyAddressByIdRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR}, {19, 19, 50, 19, 0, 20, 19, 19, 19, 19, 0, 0, 0, 0, 10, 10, 10, 10, 0, 0, 0, 20, 19, 0, 0, 19, 19, 19, 0, 5, 255, 255, 250, 50}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    4);

  /**
   * @generated
   */
  public static class GetPartyAddressByIdParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetPartyAddressByIdRowHandler extends BaseRowHandler<ResultQueue3<EObjAddressGroup,EObjLocationGroup,EObjXAddressGroupExt>>
  {
    /**
     * @generated
     */
    public ResultQueue3<EObjAddressGroup,EObjLocationGroup,EObjXAddressGroupExt> handle (java.sql.ResultSet rs, ResultQueue3<EObjAddressGroup,EObjLocationGroup,EObjXAddressGroupExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue3<EObjAddressGroup,EObjLocationGroup,EObjXAddressGroupExt> ();

      EObjAddressGroup returnObject1 = new EObjAddressGroup ();
      returnObject1.setLocationGroupIdPK(getLongObject (rs, 1)); 
      returnObject1.setAddressId(getLongObject (rs, 2)); 
      returnObject1.setCareOfDesc(getString (rs, 3)); 
      returnObject1.setAddrUsageTpCd(getLongObject (rs, 4)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 5)); 
      returnObject1.setLastUpdateUser(getString (rs, 6)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 7)); 
      returnObject.add (returnObject1);

      EObjLocationGroup returnObject2 = new EObjLocationGroup ();
      returnObject2.setLocationGroupIdPK(getLongObject (rs, 8)); 
      returnObject2.setUndelReasonTpCd(getLongObject (rs, 9)); 
      returnObject2.setContId(getLongObject (rs, 10)); 
      returnObject2.setMemberInd(getString (rs, 11)); 
      returnObject2.setPreferredInd(getString (rs, 12)); 
      returnObject2.setSolicitInd(getString (rs, 13)); 
      returnObject2.setLocGroupTpCode(getString (rs, 14)); 
      returnObject2.setEffectStartMMDD(getIntObject (rs, 15)); 
      returnObject2.setEffectEndMMDD(getIntObject (rs, 16)); 
      returnObject2.setEffectStartTm(getIntObject (rs, 17)); 
      returnObject2.setEffectEndTm(getIntObject (rs, 18)); 
      returnObject2.setStartDt(getTimestamp (rs, 19)); 
      returnObject2.setEndDt(getTimestamp (rs, 20)); 
      returnObject2.setLastUpdateDt(getTimestamp (rs, 21)); 
      returnObject2.setLastUpdateUser(getString (rs, 22)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 23)); 
      returnObject2.setLastUsedDt(getTimestamp (rs, 24)); 
      returnObject2.setLastVerifiedDt(getTimestamp (rs, 25)); 
      returnObject2.setSourceIdentTpCd(getLongObject (rs, 26)); 
      returnObject.add (returnObject2);

      EObjXAddressGroupExt returnObject3 = new EObjXAddressGroupExt ();
      returnObject3.setLastUpdateDt(getTimestamp (rs, 5)); 
      returnObject3.setLastUpdateUser(getString (rs, 6)); 
      returnObject3.setLastUpdateTxId(getLongObject (rs, 7)); 
      returnObject3.setXVerified(getLongObject (rs, 27)); 
      returnObject3.setXRetailerId(getLongObject (rs, 28)); 
      returnObject3.setXLastModifiedSystemDate(getTimestamp (rs, 29)); 
      returnObject3.setXAddressRetailerFlag(getString (rs, 30)); 
      returnObject3.setTitleOfHonor(getString (rs, 31)); 
      returnObject3.setCompanyName(getString (rs, 32)); 
      returnObject3.setSFAddressId(getString (rs, 33)); 
      returnObject3.setX_BPID(getString (rs, 34)); 
      returnObject.add (returnObject3);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT A.H_LOCATION_GROUP_I AS H_ADDRESS_GROUP_I, A.H_ACTION_CODE, A.H_CREATED_BY, A.H_CREATE_DT, A.H_END_DT, A.LOCATION_GROUP_ID, A.ADDRESS_ID, A.CARE_OF_DESC, A.ADDR_USAGE_TP_CD, A.LAST_UPDATE_DT, A.LAST_UPDATE_USER, A.LAST_UPDATE_TX_ID, B.H_LOCATION_GROUP_I AS H_LOCATION_GROUP_I, B.H_ACTION_CODE, B.H_CREATED_BY, B.H_CREATE_DT, B.H_END_DT, B.LOCATION_GROUP_ID, B.UNDEL_REASON_TP_CD , B.CONT_ID, B.MEMBER_IND, B.PREFERRED_IND, B.SOLICIT_IND, B.LOC_GROUP_TP_CODE, B.EFFECT_START_MMDD, B.EFFECT_END_MMDD , B.EFFECT_START_TM, B.EFFECT_END_TM, B.START_DT, B.END_DT, B.LAST_UPDATE_DT, B.LAST_UPDATE_USER, B.LAST_UPDATE_TX_ID , B.LAST_USED_DT, B.LAST_VERIFIED_DT, B.SOURCE_IDENT_TP_CD, A.XVERIFIED_TP_CD, A.XRETAILER_ID, A.XMODIFY_SYS_DT, A.XADDR_RETAILER_FLAG, A.TITLE_OF_HONOR, A.COMPANY_NAME, A.SFAddress_Id, A.X_BPID FROM H_ADDRESSGROUP A, H_LOCATIONGROUP B WHERE B.CONT_ID = ? AND A.H_LOCATION_GROUP_I = B.H_LOCATION_GROUP_I AND (( ? BETWEEN A.H_CREATE_DT AND A.H_END_DT ) OR ( ? >= A.H_CREATE_DT AND A.H_END_DT IS NULL )) AND (( ? BETWEEN B.H_CREATE_DT AND B.H_END_DT ) OR ( ? >= B.H_CREATE_DT AND B.H_END_DT IS NULL ))", pattern="tableAlias (ADDRESSGROUP => com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup, H_ADDRESSGROUP => com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup, LOCATIONGROUP => com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup, H_LOCATIONGROUP => com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup , ADDRESSGROUP => com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt , H_ADDRESSGROUP => com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue3<EObjAddressGroup,EObjLocationGroup,EObjXAddressGroupExt>> getPartyAddressesHistory (Object[] parameters)
  {
    return queryIterator (getPartyAddressesHistoryStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getPartyAddressesHistoryStatementDescriptor = createStatementDescriptor (
    "getPartyAddressesHistory(Object[])",
    "SELECT A.H_LOCATION_GROUP_I AS H_ADDRESS_GROUP_I, A.H_ACTION_CODE, A.H_CREATED_BY, A.H_CREATE_DT, A.H_END_DT, A.LOCATION_GROUP_ID, A.ADDRESS_ID, A.CARE_OF_DESC, A.ADDR_USAGE_TP_CD, A.LAST_UPDATE_DT, A.LAST_UPDATE_USER, A.LAST_UPDATE_TX_ID, B.H_LOCATION_GROUP_I AS H_LOCATION_GROUP_I, B.H_ACTION_CODE, B.H_CREATED_BY, B.H_CREATE_DT, B.H_END_DT, B.LOCATION_GROUP_ID, B.UNDEL_REASON_TP_CD , B.CONT_ID, B.MEMBER_IND, B.PREFERRED_IND, B.SOLICIT_IND, B.LOC_GROUP_TP_CODE, B.EFFECT_START_MMDD, B.EFFECT_END_MMDD , B.EFFECT_START_TM, B.EFFECT_END_TM, B.START_DT, B.END_DT, B.LAST_UPDATE_DT, B.LAST_UPDATE_USER, B.LAST_UPDATE_TX_ID , B.LAST_USED_DT, B.LAST_VERIFIED_DT, B.SOURCE_IDENT_TP_CD, A.XVERIFIED_TP_CD, A.XRETAILER_ID, A.XMODIFY_SYS_DT, A.XADDR_RETAILER_FLAG, A.TITLE_OF_HONOR, A.COMPANY_NAME, A.SFAddress_Id, A.X_BPID FROM H_ADDRESSGROUP A, H_LOCATIONGROUP B WHERE B.CONT_ID = ? AND A.H_LOCATION_GROUP_I = B.H_LOCATION_GROUP_I AND (( ? BETWEEN A.H_CREATE_DT AND A.H_END_DT ) OR ( ? >= A.H_CREATE_DT AND A.H_END_DT IS NULL )) AND (( ? BETWEEN B.H_CREATE_DT AND B.H_END_DT ) OR ( ? >= B.H_CREATE_DT AND B.H_END_DT IS NULL ))",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"h_address_group_i", "h_action_code", "h_created_by", "h_create_dt", "h_end_dt", "location_group_id", "address_id", "care_of_desc", "addr_usage_tp_cd", "last_update_dt", "last_update_user", "last_update_tx_id", "h_location_group_i", "h_action_code", "h_created_by", "h_create_dt", "h_end_dt", "location_group_id", "undel_reason_tp_cd", "cont_id", "member_ind", "preferred_ind", "solicit_ind", "loc_group_tp_code", "effect_start_mmdd", "effect_end_mmdd", "effect_start_tm", "effect_end_tm", "start_dt", "end_dt", "last_update_dt", "last_update_user", "last_update_tx_id", "last_used_dt", "last_verified_dt", "source_ident_tp_cd", "xverified_tp_cd", "xretailer_id", "xmodify_sys_dt", "xaddr_retailer_flag", "title_of_honor", "company_name", "sfaddress_id", "x_bpid"},
    new GetPartyAddressesHistoryParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP}, {19, 0, 0, 0, 0}, {0, 0, 0, 0, 0}, {1, 1, 1, 1, 1}},
    null,
    new GetPartyAddressesHistoryRowHandler (),
    new int[][]{ {Types.BIGINT, Types.CHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.CHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR}, {19, 1, 20, 0, 0, 19, 19, 50, 19, 0, 20, 19, 19, 1, 20, 0, 0, 19, 19, 19, 0, 0, 0, 0, 10, 10, 10, 10, 0, 0, 0, 20, 19, 0, 0, 19, 19, 19, 0, 5, 255, 255, 250, 50}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    5);

  /**
   * @generated
   */
  public static class GetPartyAddressesHistoryParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
      setObject (stmt, 4, Types.TIMESTAMP, parameters[3], 0);
      setObject (stmt, 5, Types.TIMESTAMP, parameters[4], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetPartyAddressesHistoryRowHandler extends BaseRowHandler<ResultQueue3<EObjAddressGroup,EObjLocationGroup,EObjXAddressGroupExt>>
  {
    /**
     * @generated
     */
    public ResultQueue3<EObjAddressGroup,EObjLocationGroup,EObjXAddressGroupExt> handle (java.sql.ResultSet rs, ResultQueue3<EObjAddressGroup,EObjLocationGroup,EObjXAddressGroupExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue3<EObjAddressGroup,EObjLocationGroup,EObjXAddressGroupExt> ();

      EObjAddressGroup returnObject1 = new EObjAddressGroup ();
      returnObject1.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject1.setHistActionCode(getString (rs, 2)); 
      returnObject1.setHistCreatedBy(getString (rs, 3)); 
      returnObject1.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject1.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject1.setLocationGroupIdPK(getLongObject (rs, 6)); 
      returnObject1.setAddressId(getLongObject (rs, 7)); 
      returnObject1.setCareOfDesc(getString (rs, 8)); 
      returnObject1.setAddrUsageTpCd(getLongObject (rs, 9)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 10)); 
      returnObject1.setLastUpdateUser(getString (rs, 11)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 12)); 
      returnObject.add (returnObject1);

      EObjLocationGroup returnObject2 = new EObjLocationGroup ();
      returnObject2.setHistoryIdPK(getLongObject (rs, 13)); 
      returnObject2.setHistActionCode(getString (rs, 14)); 
      returnObject2.setHistCreatedBy(getString (rs, 15)); 
      returnObject2.setHistCreateDt(getTimestamp (rs, 16)); 
      returnObject2.setHistEndDt(getTimestamp (rs, 17)); 
      returnObject2.setLocationGroupIdPK(getLongObject (rs, 18)); 
      returnObject2.setUndelReasonTpCd(getLongObject (rs, 19)); 
      returnObject2.setContId(getLongObject (rs, 20)); 
      returnObject2.setMemberInd(getString (rs, 21)); 
      returnObject2.setPreferredInd(getString (rs, 22)); 
      returnObject2.setSolicitInd(getString (rs, 23)); 
      returnObject2.setLocGroupTpCode(getString (rs, 24)); 
      returnObject2.setEffectStartMMDD(getIntObject (rs, 25)); 
      returnObject2.setEffectEndMMDD(getIntObject (rs, 26)); 
      returnObject2.setEffectStartTm(getIntObject (rs, 27)); 
      returnObject2.setEffectEndTm(getIntObject (rs, 28)); 
      returnObject2.setStartDt(getTimestamp (rs, 29)); 
      returnObject2.setEndDt(getTimestamp (rs, 30)); 
      returnObject2.setLastUpdateDt(getTimestamp (rs, 31)); 
      returnObject2.setLastUpdateUser(getString (rs, 32)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 33)); 
      returnObject2.setLastUsedDt(getTimestamp (rs, 34)); 
      returnObject2.setLastVerifiedDt(getTimestamp (rs, 35)); 
      returnObject2.setSourceIdentTpCd(getLongObject (rs, 36)); 
      returnObject.add (returnObject2);

      EObjXAddressGroupExt returnObject3 = new EObjXAddressGroupExt ();
      returnObject3.setHistActionCode(getString (rs, 2)); 
      returnObject3.setHistCreatedBy(getString (rs, 3)); 
      returnObject3.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject3.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject3.setLastUpdateDt(getTimestamp (rs, 10)); 
      returnObject3.setLastUpdateUser(getString (rs, 11)); 
      returnObject3.setLastUpdateTxId(getLongObject (rs, 12)); 
      returnObject3.setXVerified(getLongObject (rs, 37)); 
      returnObject3.setXRetailerId(getLongObject (rs, 38)); 
      returnObject3.setXLastModifiedSystemDate(getTimestamp (rs, 39)); 
      returnObject3.setXAddressRetailerFlag(getString (rs, 40)); 
      returnObject3.setTitleOfHonor(getString (rs, 41)); 
      returnObject3.setCompanyName(getString (rs, 42)); 
      returnObject3.setSFAddressId(getString (rs, 43)); 
      returnObject3.setX_BPID(getString (rs, 44)); 
      returnObject.add (returnObject3);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT ADDRESSGROUP.LOCATION_GROUP_ID, ADDRESSGROUP.ADDRESS_ID , ADDRESSGROUP.CARE_OF_DESC , ADDRESSGROUP.ADDR_USAGE_TP_CD , ADDRESSGROUP.LAST_UPDATE_DT , ADDRESSGROUP.LAST_UPDATE_USER , ADDRESSGROUP.LAST_UPDATE_TX_ID , LOCATIONGROUP.LOCATION_GROUP_ID , LOCATIONGROUP.UNDEL_REASON_TP_CD, LOCATIONGROUP.CONT_ID , LOCATIONGROUP.MEMBER_IND, LOCATIONGROUP.PREFERRED_IND , LOCATIONGROUP.SOLICIT_IND , LOCATIONGROUP.LOC_GROUP_TP_CODE , LOCATIONGROUP.EFFECT_START_MMDD , LOCATIONGROUP.EFFECT_END_MMDD , LOCATIONGROUP.EFFECT_START_TM , LOCATIONGROUP.EFFECT_END_TM , LOCATIONGROUP.START_DT , LOCATIONGROUP.END_DT , LOCATIONGROUP.LAST_UPDATE_DT , LOCATIONGROUP.LAST_UPDATE_USER , LOCATIONGROUP.LAST_UPDATE_TX_ID , LOCATIONGROUP.LAST_USED_DT , LOCATIONGROUP.LAST_VERIFIED_DT , LOCATIONGROUP.SOURCE_IDENT_TP_CD, ADDRESSGROUP.XVERIFIED_TP_CD, ADDRESSGROUP.XRETAILER_ID, ADDRESSGROUP.XMODIFY_SYS_DT, ADDRESSGROUP.XADDR_RETAILER_FLAG, ADDRESSGROUP.TITLE_OF_HONOR, ADDRESSGROUP.COMPANY_NAME, ADDRESSGROUP.SFAddress_Id, ADDRESSGROUP.X_BPID FROM ADDRESSGROUP, LOCATIONGROUP WHERE ADDRESSGROUP.LOCATION_GROUP_ID = LOCATIONGROUP.LOCATION_GROUP_ID AND LOCATIONGROUP.CONT_ID = ?", pattern="tableAlias (ADDRESSGROUP => com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup, H_ADDRESSGROUP => com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup, LOCATIONGROUP => com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup, H_LOCATIONGROUP => com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup , ADDRESSGROUP => com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt , H_ADDRESSGROUP => com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue3<EObjAddressGroup,EObjLocationGroup,EObjXAddressGroupExt>> getPartyAddresses (Object[] parameters)
  {
    return queryIterator (getPartyAddressesStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getPartyAddressesStatementDescriptor = createStatementDescriptor (
    "getPartyAddresses(Object[])",
    "SELECT ADDRESSGROUP.LOCATION_GROUP_ID, ADDRESSGROUP.ADDRESS_ID , ADDRESSGROUP.CARE_OF_DESC , ADDRESSGROUP.ADDR_USAGE_TP_CD , ADDRESSGROUP.LAST_UPDATE_DT , ADDRESSGROUP.LAST_UPDATE_USER , ADDRESSGROUP.LAST_UPDATE_TX_ID , LOCATIONGROUP.LOCATION_GROUP_ID , LOCATIONGROUP.UNDEL_REASON_TP_CD, LOCATIONGROUP.CONT_ID , LOCATIONGROUP.MEMBER_IND, LOCATIONGROUP.PREFERRED_IND , LOCATIONGROUP.SOLICIT_IND , LOCATIONGROUP.LOC_GROUP_TP_CODE , LOCATIONGROUP.EFFECT_START_MMDD , LOCATIONGROUP.EFFECT_END_MMDD , LOCATIONGROUP.EFFECT_START_TM , LOCATIONGROUP.EFFECT_END_TM , LOCATIONGROUP.START_DT , LOCATIONGROUP.END_DT , LOCATIONGROUP.LAST_UPDATE_DT , LOCATIONGROUP.LAST_UPDATE_USER , LOCATIONGROUP.LAST_UPDATE_TX_ID , LOCATIONGROUP.LAST_USED_DT , LOCATIONGROUP.LAST_VERIFIED_DT , LOCATIONGROUP.SOURCE_IDENT_TP_CD, ADDRESSGROUP.XVERIFIED_TP_CD, ADDRESSGROUP.XRETAILER_ID, ADDRESSGROUP.XMODIFY_SYS_DT, ADDRESSGROUP.XADDR_RETAILER_FLAG, ADDRESSGROUP.TITLE_OF_HONOR, ADDRESSGROUP.COMPANY_NAME, ADDRESSGROUP.SFAddress_Id, ADDRESSGROUP.X_BPID FROM ADDRESSGROUP, LOCATIONGROUP WHERE ADDRESSGROUP.LOCATION_GROUP_ID = LOCATIONGROUP.LOCATION_GROUP_ID AND LOCATIONGROUP.CONT_ID = ?",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"location_group_id", "address_id", "care_of_desc", "addr_usage_tp_cd", "last_update_dt", "last_update_user", "last_update_tx_id", "location_group_id", "undel_reason_tp_cd", "cont_id", "member_ind", "preferred_ind", "solicit_ind", "loc_group_tp_code", "effect_start_mmdd", "effect_end_mmdd", "effect_start_tm", "effect_end_tm", "start_dt", "end_dt", "last_update_dt", "last_update_user", "last_update_tx_id", "last_used_dt", "last_verified_dt", "source_ident_tp_cd", "xverified_tp_cd", "xretailer_id", "xmodify_sys_dt", "xaddr_retailer_flag", "title_of_honor", "company_name", "sfaddress_id", "x_bpid"},
    new GetPartyAddressesParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetPartyAddressesRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR}, {19, 19, 50, 19, 0, 20, 19, 19, 19, 19, 0, 0, 0, 0, 10, 10, 10, 10, 0, 0, 0, 20, 19, 0, 0, 19, 19, 19, 0, 5, 255, 255, 250, 50}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    6);

  /**
   * @generated
   */
  public static class GetPartyAddressesParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetPartyAddressesRowHandler extends BaseRowHandler<ResultQueue3<EObjAddressGroup,EObjLocationGroup,EObjXAddressGroupExt>>
  {
    /**
     * @generated
     */
    public ResultQueue3<EObjAddressGroup,EObjLocationGroup,EObjXAddressGroupExt> handle (java.sql.ResultSet rs, ResultQueue3<EObjAddressGroup,EObjLocationGroup,EObjXAddressGroupExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue3<EObjAddressGroup,EObjLocationGroup,EObjXAddressGroupExt> ();

      EObjAddressGroup returnObject1 = new EObjAddressGroup ();
      returnObject1.setLocationGroupIdPK(getLongObject (rs, 1)); 
      returnObject1.setAddressId(getLongObject (rs, 2)); 
      returnObject1.setCareOfDesc(getString (rs, 3)); 
      returnObject1.setAddrUsageTpCd(getLongObject (rs, 4)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 5)); 
      returnObject1.setLastUpdateUser(getString (rs, 6)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 7)); 
      returnObject.add (returnObject1);

      EObjLocationGroup returnObject2 = new EObjLocationGroup ();
      returnObject2.setLocationGroupIdPK(getLongObject (rs, 8)); 
      returnObject2.setUndelReasonTpCd(getLongObject (rs, 9)); 
      returnObject2.setContId(getLongObject (rs, 10)); 
      returnObject2.setMemberInd(getString (rs, 11)); 
      returnObject2.setPreferredInd(getString (rs, 12)); 
      returnObject2.setSolicitInd(getString (rs, 13)); 
      returnObject2.setLocGroupTpCode(getString (rs, 14)); 
      returnObject2.setEffectStartMMDD(getIntObject (rs, 15)); 
      returnObject2.setEffectEndMMDD(getIntObject (rs, 16)); 
      returnObject2.setEffectStartTm(getIntObject (rs, 17)); 
      returnObject2.setEffectEndTm(getIntObject (rs, 18)); 
      returnObject2.setStartDt(getTimestamp (rs, 19)); 
      returnObject2.setEndDt(getTimestamp (rs, 20)); 
      returnObject2.setLastUpdateDt(getTimestamp (rs, 21)); 
      returnObject2.setLastUpdateUser(getString (rs, 22)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 23)); 
      returnObject2.setLastUsedDt(getTimestamp (rs, 24)); 
      returnObject2.setLastVerifiedDt(getTimestamp (rs, 25)); 
      returnObject2.setSourceIdentTpCd(getLongObject (rs, 26)); 
      returnObject.add (returnObject2);

      EObjXAddressGroupExt returnObject3 = new EObjXAddressGroupExt ();
      returnObject3.setLastUpdateDt(getTimestamp (rs, 5)); 
      returnObject3.setLastUpdateUser(getString (rs, 6)); 
      returnObject3.setLastUpdateTxId(getLongObject (rs, 7)); 
      returnObject3.setXVerified(getLongObject (rs, 27)); 
      returnObject3.setXRetailerId(getLongObject (rs, 28)); 
      returnObject3.setXLastModifiedSystemDate(getTimestamp (rs, 29)); 
      returnObject3.setXAddressRetailerFlag(getString (rs, 30)); 
      returnObject3.setTitleOfHonor(getString (rs, 31)); 
      returnObject3.setCompanyName(getString (rs, 32)); 
      returnObject3.setSFAddressId(getString (rs, 33)); 
      returnObject3.setX_BPID(getString (rs, 34)); 
      returnObject.add (returnObject3);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT DISTINCT A.H_LOCATION_GROUP_I AS H_ADDRESS_GROUP_I, A.H_ACTION_CODE , A.H_CREATED_BY , A.H_CREATE_DT , A.H_END_DT , A.LOCATION_GROUP_ID , A.ADDRESS_ID , A.CARE_OF_DESC , A.ADDR_USAGE_TP_CD , A.LAST_UPDATE_DT , A.LAST_UPDATE_USER , A.LAST_UPDATE_TX_ID , B.LOCATION_GROUP_ID , B.H_LOCATION_GROUP_I AS H_LOCATION_GROUP_I, B.H_ACTION_CODE , B.H_CREATED_BY , B.H_CREATE_DT , B.H_END_DT , B.UNDEL_REASON_TP_CD , B.CONT_ID , B.MEMBER_IND , B.PREFERRED_IND, B.SOLICIT_IND , B.LOC_GROUP_TP_CODE , B.EFFECT_START_MMDD , B.EFFECT_END_MMDD , B.EFFECT_START_TM , B.EFFECT_END_TM , B.START_DT , B.END_DT , B.LAST_UPDATE_DT , B.LAST_UPDATE_USER , B.LAST_UPDATE_TX_ID , B.LAST_USED_DT , B.LAST_VERIFIED_DT , B.SOURCE_IDENT_TP_CD, A.XVERIFIED_TP_CD, A.XRETAILER_ID, A.XMODIFY_SYS_DT, A.XADDR_RETAILER_FLAG, A.TITLE_OF_HONOR, A.COMPANY_NAME, A.SFAddress_Id, A.X_BPID FROM H_ADDRESSGROUP A,H_LOCATIONGROUP B WHERE A.H_LOCATION_GROUP_I = B.H_LOCATION_GROUP_I AND (B.CONT_ID = ? AND (? BETWEEN B.H_CREATE_DT AND B.H_END_DT AND B.END_DT IS NULL OR (? >= B.H_CREATE_DT AND B.H_END_DT IS NULL AND B.END_DT IS NULL))) AND (A.ADDR_USAGE_TP_CD =? AND (? BETWEEN A.H_CREATE_DT AND A.H_END_DT OR (? >= A.H_CREATE_DT AND A.H_END_DT IS NULL)))", pattern="tableAlias (ADDRESSGROUP => com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup, H_ADDRESSGROUP => com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup, LOCATIONGROUP => com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup, H_LOCATIONGROUP => com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup , ADDRESSGROUP => com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt , H_ADDRESSGROUP => com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue3<EObjAddressGroup,EObjLocationGroup,EObjXAddressGroupExt>> getPartyAddressHistory (Object[] parameters)
  {
    return queryIterator (getPartyAddressHistoryStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getPartyAddressHistoryStatementDescriptor = createStatementDescriptor (
    "getPartyAddressHistory(Object[])",
    "SELECT DISTINCT A.H_LOCATION_GROUP_I AS H_ADDRESS_GROUP_I, A.H_ACTION_CODE , A.H_CREATED_BY , A.H_CREATE_DT , A.H_END_DT , A.LOCATION_GROUP_ID , A.ADDRESS_ID , A.CARE_OF_DESC , A.ADDR_USAGE_TP_CD , A.LAST_UPDATE_DT , A.LAST_UPDATE_USER , A.LAST_UPDATE_TX_ID , B.LOCATION_GROUP_ID , B.H_LOCATION_GROUP_I AS H_LOCATION_GROUP_I, B.H_ACTION_CODE , B.H_CREATED_BY , B.H_CREATE_DT , B.H_END_DT , B.UNDEL_REASON_TP_CD , B.CONT_ID , B.MEMBER_IND , B.PREFERRED_IND, B.SOLICIT_IND , B.LOC_GROUP_TP_CODE , B.EFFECT_START_MMDD , B.EFFECT_END_MMDD , B.EFFECT_START_TM , B.EFFECT_END_TM , B.START_DT , B.END_DT , B.LAST_UPDATE_DT , B.LAST_UPDATE_USER , B.LAST_UPDATE_TX_ID , B.LAST_USED_DT , B.LAST_VERIFIED_DT , B.SOURCE_IDENT_TP_CD, A.XVERIFIED_TP_CD, A.XRETAILER_ID, A.XMODIFY_SYS_DT, A.XADDR_RETAILER_FLAG, A.TITLE_OF_HONOR, A.COMPANY_NAME, A.SFAddress_Id, A.X_BPID FROM H_ADDRESSGROUP A,H_LOCATIONGROUP B WHERE A.H_LOCATION_GROUP_I = B.H_LOCATION_GROUP_I AND (B.CONT_ID = ? AND (? BETWEEN B.H_CREATE_DT AND B.H_END_DT AND B.END_DT IS NULL OR (? >= B.H_CREATE_DT AND B.H_END_DT IS NULL AND B.END_DT IS NULL))) AND (A.ADDR_USAGE_TP_CD =? AND (? BETWEEN A.H_CREATE_DT AND A.H_END_DT OR (? >= A.H_CREATE_DT AND A.H_END_DT IS NULL)))",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"h_address_group_i", "h_action_code", "h_created_by", "h_create_dt", "h_end_dt", "location_group_id", "address_id", "care_of_desc", "addr_usage_tp_cd", "last_update_dt", "last_update_user", "last_update_tx_id", "location_group_id", "h_location_group_i", "h_action_code", "h_created_by", "h_create_dt", "h_end_dt", "undel_reason_tp_cd", "cont_id", "member_ind", "preferred_ind", "solicit_ind", "loc_group_tp_code", "effect_start_mmdd", "effect_end_mmdd", "effect_start_tm", "effect_end_tm", "start_dt", "end_dt", "last_update_dt", "last_update_user", "last_update_tx_id", "last_used_dt", "last_verified_dt", "source_ident_tp_cd", "xverified_tp_cd", "xretailer_id", "xmodify_sys_dt", "xaddr_retailer_flag", "title_of_honor", "company_name", "sfaddress_id", "x_bpid"},
    new GetPartyAddressHistoryParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP}, {19, 0, 0, 19, 0, 0}, {0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1}},
    null,
    new GetPartyAddressHistoryRowHandler (),
    new int[][]{ {Types.BIGINT, Types.CHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.CHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR}, {19, 1, 20, 0, 0, 19, 19, 50, 19, 0, 20, 19, 19, 19, 1, 20, 0, 0, 19, 19, 0, 0, 0, 0, 10, 10, 10, 10, 0, 0, 0, 20, 19, 0, 0, 19, 19, 19, 0, 5, 255, 255, 250, 50}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    7);

  /**
   * @generated
   */
  public static class GetPartyAddressHistoryParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
      setObject (stmt, 4, Types.BIGINT, parameters[3], 0);
      setObject (stmt, 5, Types.TIMESTAMP, parameters[4], 0);
      setObject (stmt, 6, Types.TIMESTAMP, parameters[5], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetPartyAddressHistoryRowHandler extends BaseRowHandler<ResultQueue3<EObjAddressGroup,EObjLocationGroup,EObjXAddressGroupExt>>
  {
    /**
     * @generated
     */
    public ResultQueue3<EObjAddressGroup,EObjLocationGroup,EObjXAddressGroupExt> handle (java.sql.ResultSet rs, ResultQueue3<EObjAddressGroup,EObjLocationGroup,EObjXAddressGroupExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue3<EObjAddressGroup,EObjLocationGroup,EObjXAddressGroupExt> ();

      EObjAddressGroup returnObject1 = new EObjAddressGroup ();
      returnObject1.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject1.setHistActionCode(getString (rs, 2)); 
      returnObject1.setHistCreatedBy(getString (rs, 3)); 
      returnObject1.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject1.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject1.setLocationGroupIdPK(getLongObject (rs, 6)); 
      returnObject1.setAddressId(getLongObject (rs, 7)); 
      returnObject1.setCareOfDesc(getString (rs, 8)); 
      returnObject1.setAddrUsageTpCd(getLongObject (rs, 9)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 10)); 
      returnObject1.setLastUpdateUser(getString (rs, 11)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 12)); 
      returnObject.add (returnObject1);

      EObjLocationGroup returnObject2 = new EObjLocationGroup ();
      returnObject2.setLocationGroupIdPK(getLongObject (rs, 13)); 
      returnObject2.setHistoryIdPK(getLongObject (rs, 14)); 
      returnObject2.setHistActionCode(getString (rs, 15)); 
      returnObject2.setHistCreatedBy(getString (rs, 16)); 
      returnObject2.setHistCreateDt(getTimestamp (rs, 17)); 
      returnObject2.setHistEndDt(getTimestamp (rs, 18)); 
      returnObject2.setUndelReasonTpCd(getLongObject (rs, 19)); 
      returnObject2.setContId(getLongObject (rs, 20)); 
      returnObject2.setMemberInd(getString (rs, 21)); 
      returnObject2.setPreferredInd(getString (rs, 22)); 
      returnObject2.setSolicitInd(getString (rs, 23)); 
      returnObject2.setLocGroupTpCode(getString (rs, 24)); 
      returnObject2.setEffectStartMMDD(getIntObject (rs, 25)); 
      returnObject2.setEffectEndMMDD(getIntObject (rs, 26)); 
      returnObject2.setEffectStartTm(getIntObject (rs, 27)); 
      returnObject2.setEffectEndTm(getIntObject (rs, 28)); 
      returnObject2.setStartDt(getTimestamp (rs, 29)); 
      returnObject2.setEndDt(getTimestamp (rs, 30)); 
      returnObject2.setLastUpdateDt(getTimestamp (rs, 31)); 
      returnObject2.setLastUpdateUser(getString (rs, 32)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 33)); 
      returnObject2.setLastUsedDt(getTimestamp (rs, 34)); 
      returnObject2.setLastVerifiedDt(getTimestamp (rs, 35)); 
      returnObject2.setSourceIdentTpCd(getLongObject (rs, 36)); 
      returnObject.add (returnObject2);

      EObjXAddressGroupExt returnObject3 = new EObjXAddressGroupExt ();
      returnObject3.setHistActionCode(getString (rs, 2)); 
      returnObject3.setHistCreatedBy(getString (rs, 3)); 
      returnObject3.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject3.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject3.setLastUpdateDt(getTimestamp (rs, 10)); 
      returnObject3.setLastUpdateUser(getString (rs, 11)); 
      returnObject3.setLastUpdateTxId(getLongObject (rs, 12)); 
      returnObject3.setXVerified(getLongObject (rs, 37)); 
      returnObject3.setXRetailerId(getLongObject (rs, 38)); 
      returnObject3.setXLastModifiedSystemDate(getTimestamp (rs, 39)); 
      returnObject3.setXAddressRetailerFlag(getString (rs, 40)); 
      returnObject3.setTitleOfHonor(getString (rs, 41)); 
      returnObject3.setCompanyName(getString (rs, 42)); 
      returnObject3.setSFAddressId(getString (rs, 43)); 
      returnObject3.setX_BPID(getString (rs, 44)); 
      returnObject.add (returnObject3);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT ADDRESSGROUP.LOCATION_GROUP_ID , ADDRESSGROUP.ADDRESS_ID, ADDRESSGROUP.CARE_OF_DESC , ADDRESSGROUP.ADDR_USAGE_TP_CD , ADDRESSGROUP.LAST_UPDATE_DT , ADDRESSGROUP.LAST_UPDATE_USER , ADDRESSGROUP.LAST_UPDATE_TX_ID , LOCATIONGROUP.LOCATION_GROUP_ID , LOCATIONGROUP.UNDEL_REASON_TP_CD , LOCATIONGROUP.CONT_ID , LOCATIONGROUP.MEMBER_IND , LOCATIONGROUP.PREFERRED_IND , LOCATIONGROUP.SOLICIT_IND, LOCATIONGROUP.LOC_GROUP_TP_CODE , LOCATIONGROUP.EFFECT_START_MMDD , LOCATIONGROUP.EFFECT_END_MMDD , LOCATIONGROUP.EFFECT_START_TM , LOCATIONGROUP.EFFECT_END_TM , LOCATIONGROUP.START_DT , LOCATIONGROUP.END_DT , LOCATIONGROUP.LAST_UPDATE_DT , LOCATIONGROUP.LAST_UPDATE_USER , LOCATIONGROUP.LAST_UPDATE_TX_ID , LOCATIONGROUP.LAST_USED_DT , LOCATIONGROUP.LAST_VERIFIED_DT , LOCATIONGROUP.SOURCE_IDENT_TP_CD, ADDRESSGROUP.XVERIFIED_TP_CD, ADDRESSGROUP.XRETAILER_ID, ADDRESSGROUP.XMODIFY_SYS_DT, ADDRESSGROUP.XADDR_RETAILER_FLAG, ADDRESSGROUP.TITLE_OF_HONOR, ADDRESSGROUP.COMPANY_NAME, ADDRESSGROUP.SFAddress_Id, ADDRESSGROUP.X_BPID FROM ADDRESSGROUP,LOCATIONGROUP WHERE ADDRESSGROUP.LOCATION_GROUP_ID = LOCATIONGROUP.LOCATION_GROUP_ID AND LOCATIONGROUP.CONT_ID = ? AND ADDRESSGROUP.ADDR_USAGE_TP_CD = ? AND ((LOCATIONGROUP.END_DT IS NULL) OR (LOCATIONGROUP.END_DT > ?))", pattern="tableAlias (ADDRESSGROUP => com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup, H_ADDRESSGROUP => com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup, LOCATIONGROUP => com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup, H_LOCATIONGROUP => com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup , ADDRESSGROUP => com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt , H_ADDRESSGROUP => com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue3<EObjAddressGroup,EObjLocationGroup,EObjXAddressGroupExt>> getPartyAddress (Object[] parameters)
  {
    return queryIterator (getPartyAddressStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getPartyAddressStatementDescriptor = createStatementDescriptor (
    "getPartyAddress(Object[])",
    "SELECT ADDRESSGROUP.LOCATION_GROUP_ID , ADDRESSGROUP.ADDRESS_ID, ADDRESSGROUP.CARE_OF_DESC , ADDRESSGROUP.ADDR_USAGE_TP_CD , ADDRESSGROUP.LAST_UPDATE_DT , ADDRESSGROUP.LAST_UPDATE_USER , ADDRESSGROUP.LAST_UPDATE_TX_ID , LOCATIONGROUP.LOCATION_GROUP_ID , LOCATIONGROUP.UNDEL_REASON_TP_CD , LOCATIONGROUP.CONT_ID , LOCATIONGROUP.MEMBER_IND , LOCATIONGROUP.PREFERRED_IND , LOCATIONGROUP.SOLICIT_IND, LOCATIONGROUP.LOC_GROUP_TP_CODE , LOCATIONGROUP.EFFECT_START_MMDD , LOCATIONGROUP.EFFECT_END_MMDD , LOCATIONGROUP.EFFECT_START_TM , LOCATIONGROUP.EFFECT_END_TM , LOCATIONGROUP.START_DT , LOCATIONGROUP.END_DT , LOCATIONGROUP.LAST_UPDATE_DT , LOCATIONGROUP.LAST_UPDATE_USER , LOCATIONGROUP.LAST_UPDATE_TX_ID , LOCATIONGROUP.LAST_USED_DT , LOCATIONGROUP.LAST_VERIFIED_DT , LOCATIONGROUP.SOURCE_IDENT_TP_CD, ADDRESSGROUP.XVERIFIED_TP_CD, ADDRESSGROUP.XRETAILER_ID, ADDRESSGROUP.XMODIFY_SYS_DT, ADDRESSGROUP.XADDR_RETAILER_FLAG, ADDRESSGROUP.TITLE_OF_HONOR, ADDRESSGROUP.COMPANY_NAME, ADDRESSGROUP.SFAddress_Id, ADDRESSGROUP.X_BPID FROM ADDRESSGROUP,LOCATIONGROUP WHERE ADDRESSGROUP.LOCATION_GROUP_ID = LOCATIONGROUP.LOCATION_GROUP_ID AND LOCATIONGROUP.CONT_ID = ? AND ADDRESSGROUP.ADDR_USAGE_TP_CD = ? AND ((LOCATIONGROUP.END_DT IS NULL) OR (LOCATIONGROUP.END_DT > ?))",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"location_group_id", "address_id", "care_of_desc", "addr_usage_tp_cd", "last_update_dt", "last_update_user", "last_update_tx_id", "location_group_id", "undel_reason_tp_cd", "cont_id", "member_ind", "preferred_ind", "solicit_ind", "loc_group_tp_code", "effect_start_mmdd", "effect_end_mmdd", "effect_start_tm", "effect_end_tm", "start_dt", "end_dt", "last_update_dt", "last_update_user", "last_update_tx_id", "last_used_dt", "last_verified_dt", "source_ident_tp_cd", "xverified_tp_cd", "xretailer_id", "xmodify_sys_dt", "xaddr_retailer_flag", "title_of_honor", "company_name", "sfaddress_id", "x_bpid"},
    new GetPartyAddressParameterHandler (),
    new int[][]{{Types.BIGINT, Types.BIGINT, Types.TIMESTAMP}, {19, 19, 0}, {0, 0, 0}, {1, 1, 1}},
    null,
    new GetPartyAddressRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR}, {19, 19, 50, 19, 0, 20, 19, 19, 19, 19, 0, 0, 0, 0, 10, 10, 10, 10, 0, 0, 0, 20, 19, 0, 0, 19, 19, 19, 0, 5, 255, 255, 250, 50}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    8);

  /**
   * @generated
   */
  public static class GetPartyAddressParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.BIGINT, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetPartyAddressRowHandler extends BaseRowHandler<ResultQueue3<EObjAddressGroup,EObjLocationGroup,EObjXAddressGroupExt>>
  {
    /**
     * @generated
     */
    public ResultQueue3<EObjAddressGroup,EObjLocationGroup,EObjXAddressGroupExt> handle (java.sql.ResultSet rs, ResultQueue3<EObjAddressGroup,EObjLocationGroup,EObjXAddressGroupExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue3<EObjAddressGroup,EObjLocationGroup,EObjXAddressGroupExt> ();

      EObjAddressGroup returnObject1 = new EObjAddressGroup ();
      returnObject1.setLocationGroupIdPK(getLongObject (rs, 1)); 
      returnObject1.setAddressId(getLongObject (rs, 2)); 
      returnObject1.setCareOfDesc(getString (rs, 3)); 
      returnObject1.setAddrUsageTpCd(getLongObject (rs, 4)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 5)); 
      returnObject1.setLastUpdateUser(getString (rs, 6)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 7)); 
      returnObject.add (returnObject1);

      EObjLocationGroup returnObject2 = new EObjLocationGroup ();
      returnObject2.setLocationGroupIdPK(getLongObject (rs, 8)); 
      returnObject2.setUndelReasonTpCd(getLongObject (rs, 9)); 
      returnObject2.setContId(getLongObject (rs, 10)); 
      returnObject2.setMemberInd(getString (rs, 11)); 
      returnObject2.setPreferredInd(getString (rs, 12)); 
      returnObject2.setSolicitInd(getString (rs, 13)); 
      returnObject2.setLocGroupTpCode(getString (rs, 14)); 
      returnObject2.setEffectStartMMDD(getIntObject (rs, 15)); 
      returnObject2.setEffectEndMMDD(getIntObject (rs, 16)); 
      returnObject2.setEffectStartTm(getIntObject (rs, 17)); 
      returnObject2.setEffectEndTm(getIntObject (rs, 18)); 
      returnObject2.setStartDt(getTimestamp (rs, 19)); 
      returnObject2.setEndDt(getTimestamp (rs, 20)); 
      returnObject2.setLastUpdateDt(getTimestamp (rs, 21)); 
      returnObject2.setLastUpdateUser(getString (rs, 22)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 23)); 
      returnObject2.setLastUsedDt(getTimestamp (rs, 24)); 
      returnObject2.setLastVerifiedDt(getTimestamp (rs, 25)); 
      returnObject2.setSourceIdentTpCd(getLongObject (rs, 26)); 
      returnObject.add (returnObject2);

      EObjXAddressGroupExt returnObject3 = new EObjXAddressGroupExt ();
      returnObject3.setLastUpdateDt(getTimestamp (rs, 5)); 
      returnObject3.setLastUpdateUser(getString (rs, 6)); 
      returnObject3.setLastUpdateTxId(getLongObject (rs, 7)); 
      returnObject3.setXVerified(getLongObject (rs, 27)); 
      returnObject3.setXRetailerId(getLongObject (rs, 28)); 
      returnObject3.setXLastModifiedSystemDate(getTimestamp (rs, 29)); 
      returnObject3.setXAddressRetailerFlag(getString (rs, 30)); 
      returnObject3.setTitleOfHonor(getString (rs, 31)); 
      returnObject3.setCompanyName(getString (rs, 32)); 
      returnObject3.setSFAddressId(getString (rs, 33)); 
      returnObject3.setX_BPID(getString (rs, 34)); 
      returnObject.add (returnObject3);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT DISTINCT A.H_LOCATION_GROUP_I AS H_ADDRESS_GROUP_I, A.H_ACTION_CODE , A.H_CREATED_BY , A.H_CREATE_DT , A.H_END_DT , A.LOCATION_GROUP_ID , A.ADDRESS_ID, A.CARE_OF_DESC , A.ADDR_USAGE_TP_CD , A.LAST_UPDATE_DT , A.LAST_UPDATE_USER , A.LAST_UPDATE_TX_ID , B.H_LOCATION_GROUP_I AS H_LOCATION_GROUP_I, B.H_ACTION_CODE , B.H_CREATED_BY , B.H_CREATE_DT , B.H_END_DT , B.LOCATION_GROUP_ID , B.UNDEL_REASON_TP_CD, B.CONT_ID , B.MEMBER_IND , B.PREFERRED_IND , B.SOLICIT_IND , B.LOC_GROUP_TP_CODE , B.EFFECT_START_MMDD, B.EFFECT_END_MMDD , B.EFFECT_START_TM , B.EFFECT_END_TM , B.START_DT , B.END_DT , B.LAST_UPDATE_DT , B.LAST_UPDATE_USER , B.LAST_UPDATE_TX_ID , B.LAST_USED_DT , B.LAST_VERIFIED_DT , B.SOURCE_IDENT_TP_CD, A.XVERIFIED_TP_CD, A.XRETAILER_ID, A.XMODIFY_SYS_DT, A.XADDR_RETAILER_FLAG, A.TITLE_OF_HONOR, A.COMPANY_NAME, A.SFAddress_Id, A.X_BPID FROM H_ADDRESSGROUP A, H_LOCATIONGROUP B WHERE B.CONT_ID = ? AND A.LOCATION_GROUP_ID = B.LOCATION_GROUP_ID AND A.LAST_UPDATE_TX_ID= B.LAST_UPDATE_TX_ID AND ( A.LAST_UPDATE_DT BETWEEN ? AND ? ) UNION SELECT DISTINCT A.H_LOCATION_GROUP_I AS H_ADDRESS_GROUP_I, A.H_ACTION_CODE AS H_ACTION_CODE_1, A.H_CREATED_BY AS H_CREATED_BY_1, A.H_CREATE_DT AS H_CREATE_DT_1, A.H_END_DT AS H_END_DT_1, A.LOCATION_GROUP_ID AS LOCATIONGROUPID2, A.ADDRESS_ID AS ADDRESSID2, A.CARE_OF_DESC AS CAREOFDESC2, A.ADDR_USAGE_TP_CD AS ADDRUSAGETPCD2, A.LAST_UPDATE_DT AS LASTUPDATEDT2, A.LAST_UPDATE_USER AS LASTUPDATEUSER2, A.LAST_UPDATE_TX_ID AS LASTUPDATETXID2, B.H_LOCATION_GROUP_I AS H_LOCATION_GROUP_I, B.H_ACTION_CODE AS H_ACTION_CODE_2, B.H_CREATED_BY AS H_CREATED_BY_2, B.H_CREATE_DT AS H_CREATE_DT_2, B.H_END_DT AS H_END_DT_2, B.LOCATION_GROUP_ID AS LOCATIONGROUPID42, B.UNDEL_REASON_TP_CD AS UNDELREASONTPCD42, B.CONT_ID AS LOCALGROUP_CONT_ID, B.MEMBER_IND AS MEMBERIND42, B.PREFERRED_IND AS PREFERREDIND42, B.SOLICIT_IND AS SOLICITIND42, B.LOC_GROUP_TP_CODE AS LOCGROUPTPCODE42, B.EFFECT_START_MMDD AS EFFECTSTARTMMDD42, B.EFFECT_END_MMDD AS EFFECTENDMMDD42, B.EFFECT_START_TM AS EFFECTSTARTTM42, B.EFFECT_END_TM AS EFFECTENDTM42, B.START_DT AS STARTDT42, B.END_DT AS LOCALGROUP_END_DT, B.LAST_UPDATE_DT AS LASTUPDATEDT42, B.LAST_UPDATE_USER AS LASTUPDATEUSER42, B.LAST_UPDATE_TX_ID AS LASTUPDATETXID42, B.LAST_USED_DT AS LASTUSEDDT, B.LAST_VERIFIED_DT AS LASTVERIFIEDDT, B.SOURCE_IDENT_TP_CD AS SOURCEIDENTTPCD, A.XVERIFIED_TP_CD, A.XRETAILER_ID, A.XMODIFY_SYS_DT, A.XADDR_RETAILER_FLAG, A.TITLE_OF_HONOR, A.COMPANY_NAME, A.SFAddress_Id FROM H_LOCATIONGROUP B LEFT JOIN H_ADDRESSGROUP A ON A.LOCATION_GROUP_ID = B.LOCATION_GROUP_ID AND A.LAST_UPDATE_TX_ID=B.LAST_UPDATE_TX_ID WHERE B.CONT_ID = ? AND ( B.H_CREATE_DT BETWEEN ? AND ?)", pattern="<rsm><col number='1' bean='com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup' property='historyIdPK'></col><col number='2' bean='com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup' property='histActionCode'></col><col number='3' bean='com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup' property='histCreatedBy'></col><col number='4' bean='com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup' property='histCreateDt'></col><col number='5' bean='com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup' property='histEndDt'></col><col number='6' bean='com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup' property='locationGroupIdPK'></col><col number='7' bean='com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup' property='addressId'></col><col number='8' bean='com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup' property='careOfDesc'></col><col number='9' bean='com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup' property='addrUsageTpCd'></col><col number='10' bean='com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup' property='lastUpdateDt'></col><col number='11' bean='com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup' property='lastUpdateUser'></col><col number='12' bean='com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup' property='lastUpdateTxId'></col><col number='13' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='historyIdPK'></col><col number='14' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='histActionCode'></col><col number='15' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='histCreatedBy'></col><col number='16' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='histCreateDt'></col><col number='17' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='histEndDt'></col><col number='18' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='locationGroupIdPK'></col><col number='19' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='undelReasonTpCd'></col><col number='20' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='contId'></col><col number='21' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='memberInd'></col><col number='22' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='preferredInd'></col><col number='23' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='solicitInd'></col><col number='24' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='locGroupTpCode'></col><col number='25' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='effectStartMMDD'></col><col number='26' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='effectEndMMDD'></col><col number='27' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='effectStartTm'></col><col number='28' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='effectEndTm'></col><col number='29' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='startDt'></col><col number='30' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='endDt'></col><col number='31' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='lastUpdateDt'></col><col number='32' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='lastUpdateUser'></col><col number='33' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='lastUpdateTxId'></col><col number='34' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='lastUsedDt'></col><col number='35' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='lastVerifiedDt'></col><col number='36' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='sourceIdentTpCd'></col><col number='37' bean='com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt' property='XVerified'></col><col number='38' bean='com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt' property='XRetailerId'></col><col number='39' bean='com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt' property='XLastModifiedSystemDate'></col><col number='40' bean='com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt' property='XAddressRetailerFlag'></col><col number='41' bean='com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt' property='TitleOfHonor'></col><col number='42' bean='com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt' property='CompanyName'></col><col number='43' bean='com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt' property='SFAddressId'></col></rsm>" )
   * 
   * @generated
   */
  public Iterator<ResultQueue3<EObjAddressGroup,EObjLocationGroup,EObjXAddressGroupExt>> getPartyAddressImage (Object[] parameters)
  {
    return queryIterator (getPartyAddressImageStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getPartyAddressImageStatementDescriptor = createStatementDescriptor (
    "getPartyAddressImage(Object[])",
    "SELECT DISTINCT A.H_LOCATION_GROUP_I AS H_ADDRESS_GROUP_I, A.H_ACTION_CODE , A.H_CREATED_BY , A.H_CREATE_DT , A.H_END_DT , A.LOCATION_GROUP_ID , A.ADDRESS_ID, A.CARE_OF_DESC , A.ADDR_USAGE_TP_CD , A.LAST_UPDATE_DT , A.LAST_UPDATE_USER , A.LAST_UPDATE_TX_ID , B.H_LOCATION_GROUP_I AS H_LOCATION_GROUP_I, B.H_ACTION_CODE , B.H_CREATED_BY , B.H_CREATE_DT , B.H_END_DT , B.LOCATION_GROUP_ID , B.UNDEL_REASON_TP_CD, B.CONT_ID , B.MEMBER_IND , B.PREFERRED_IND , B.SOLICIT_IND , B.LOC_GROUP_TP_CODE , B.EFFECT_START_MMDD, B.EFFECT_END_MMDD , B.EFFECT_START_TM , B.EFFECT_END_TM , B.START_DT , B.END_DT , B.LAST_UPDATE_DT , B.LAST_UPDATE_USER , B.LAST_UPDATE_TX_ID , B.LAST_USED_DT , B.LAST_VERIFIED_DT , B.SOURCE_IDENT_TP_CD, A.XVERIFIED_TP_CD, A.XRETAILER_ID, A.XMODIFY_SYS_DT, A.XADDR_RETAILER_FLAG, A.TITLE_OF_HONOR, A.COMPANY_NAME, A.SFAddress_Id, A.X_BPID FROM H_ADDRESSGROUP A, H_LOCATIONGROUP B WHERE B.CONT_ID = ? AND A.LOCATION_GROUP_ID = B.LOCATION_GROUP_ID AND A.LAST_UPDATE_TX_ID= B.LAST_UPDATE_TX_ID AND ( A.LAST_UPDATE_DT BETWEEN ? AND ? ) UNION SELECT DISTINCT A.H_LOCATION_GROUP_I AS H_ADDRESS_GROUP_I, A.H_ACTION_CODE AS H_ACTION_CODE_1, A.H_CREATED_BY AS H_CREATED_BY_1, A.H_CREATE_DT AS H_CREATE_DT_1, A.H_END_DT AS H_END_DT_1, A.LOCATION_GROUP_ID AS LOCATIONGROUPID2, A.ADDRESS_ID AS ADDRESSID2, A.CARE_OF_DESC AS CAREOFDESC2, A.ADDR_USAGE_TP_CD AS ADDRUSAGETPCD2, A.LAST_UPDATE_DT AS LASTUPDATEDT2, A.LAST_UPDATE_USER AS LASTUPDATEUSER2, A.LAST_UPDATE_TX_ID AS LASTUPDATETXID2, B.H_LOCATION_GROUP_I AS H_LOCATION_GROUP_I, B.H_ACTION_CODE AS H_ACTION_CODE_2, B.H_CREATED_BY AS H_CREATED_BY_2, B.H_CREATE_DT AS H_CREATE_DT_2, B.H_END_DT AS H_END_DT_2, B.LOCATION_GROUP_ID AS LOCATIONGROUPID42, B.UNDEL_REASON_TP_CD AS UNDELREASONTPCD42, B.CONT_ID AS LOCALGROUP_CONT_ID, B.MEMBER_IND AS MEMBERIND42, B.PREFERRED_IND AS PREFERREDIND42, B.SOLICIT_IND AS SOLICITIND42, B.LOC_GROUP_TP_CODE AS LOCGROUPTPCODE42, B.EFFECT_START_MMDD AS EFFECTSTARTMMDD42, B.EFFECT_END_MMDD AS EFFECTENDMMDD42, B.EFFECT_START_TM AS EFFECTSTARTTM42, B.EFFECT_END_TM AS EFFECTENDTM42, B.START_DT AS STARTDT42, B.END_DT AS LOCALGROUP_END_DT, B.LAST_UPDATE_DT AS LASTUPDATEDT42, B.LAST_UPDATE_USER AS LASTUPDATEUSER42, B.LAST_UPDATE_TX_ID AS LASTUPDATETXID42, B.LAST_USED_DT AS LASTUSEDDT, B.LAST_VERIFIED_DT AS LASTVERIFIEDDT, B.SOURCE_IDENT_TP_CD AS SOURCEIDENTTPCD, A.XVERIFIED_TP_CD, A.XRETAILER_ID, A.XMODIFY_SYS_DT, A.XADDR_RETAILER_FLAG, A.TITLE_OF_HONOR, A.COMPANY_NAME, A.SFAddress_Id FROM H_LOCATIONGROUP B LEFT JOIN H_ADDRESSGROUP A ON A.LOCATION_GROUP_ID = B.LOCATION_GROUP_ID AND A.LAST_UPDATE_TX_ID=B.LAST_UPDATE_TX_ID WHERE B.CONT_ID = ? AND ( B.H_CREATE_DT BETWEEN ? AND ?)",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"h_address_group_i", "h_action_code", "h_created_by", "h_create_dt", "h_end_dt", "location_group_id", "address_id", "care_of_desc", "addr_usage_tp_cd", "last_update_dt", "last_update_user", "last_update_tx_id", "h_location_group_i", "h_action_code", "h_created_by", "h_create_dt", "h_end_dt", "location_group_id", "undel_reason_tp_cd", "cont_id", "member_ind", "preferred_ind", "solicit_ind", "loc_group_tp_code", "effect_start_mmdd", "effect_end_mmdd", "effect_start_tm", "effect_end_tm", "start_dt", "end_dt", "last_update_dt", "last_update_user", "last_update_tx_id", "last_used_dt", "last_verified_dt", "source_ident_tp_cd", "xverified_tp_cd", "xretailer_id", "xmodify_sys_dt", "xaddr_retailer_flag", "title_of_honor", "company_name", "sfaddress_id", "x_bpid"},
    new GetPartyAddressImageParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP}, {19, 0, 0, 19, 0, 0}, {0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1}},
    null,
    new GetPartyAddressImageRowHandler (),
    new int[][]{ {Types.BIGINT, Types.CHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.CHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR}, {19, 1, 20, 0, 0, 19, 19, 50, 19, 0, 20, 19, 19, 1, 20, 0, 0, 19, 19, 19, 0, 0, 0, 0, 10, 10, 10, 10, 0, 0, 0, 20, 19, 0, 0, 19, 19, 19, 0, 5, 255, 255, 250, 50}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    9);

  /**
   * @generated
   */
  public static class GetPartyAddressImageParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
      setObject (stmt, 4, Types.BIGINT, parameters[3], 0);
      setObject (stmt, 5, Types.TIMESTAMP, parameters[4], 0);
      setObject (stmt, 6, Types.TIMESTAMP, parameters[5], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetPartyAddressImageRowHandler extends BaseRowHandler<ResultQueue3<EObjAddressGroup,EObjLocationGroup,EObjXAddressGroupExt>>
  {
    /**
     * @generated
     */
    public ResultQueue3<EObjAddressGroup,EObjLocationGroup,EObjXAddressGroupExt> handle (java.sql.ResultSet rs, ResultQueue3<EObjAddressGroup,EObjLocationGroup,EObjXAddressGroupExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue3<EObjAddressGroup,EObjLocationGroup,EObjXAddressGroupExt> ();

      EObjAddressGroup returnObject1 = new EObjAddressGroup ();
      returnObject1.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject1.setHistActionCode(getString (rs, 2)); 
      returnObject1.setHistCreatedBy(getString (rs, 3)); 
      returnObject1.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject1.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject1.setLocationGroupIdPK(getLongObject (rs, 6)); 
      returnObject1.setAddressId(getLongObject (rs, 7)); 
      returnObject1.setCareOfDesc(getString (rs, 8)); 
      returnObject1.setAddrUsageTpCd(getLongObject (rs, 9)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 10)); 
      returnObject1.setLastUpdateUser(getString (rs, 11)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 12)); 
      returnObject.add (returnObject1);

      EObjLocationGroup returnObject2 = new EObjLocationGroup ();
      returnObject2.setHistoryIdPK(getLongObject (rs, 13)); 
      returnObject2.setHistActionCode(getString (rs, 14)); 
      returnObject2.setHistCreatedBy(getString (rs, 15)); 
      returnObject2.setHistCreateDt(getTimestamp (rs, 16)); 
      returnObject2.setHistEndDt(getTimestamp (rs, 17)); 
      returnObject2.setLocationGroupIdPK(getLongObject (rs, 18)); 
      returnObject2.setUndelReasonTpCd(getLongObject (rs, 19)); 
      returnObject2.setContId(getLongObject (rs, 20)); 
      returnObject2.setMemberInd(getString (rs, 21)); 
      returnObject2.setPreferredInd(getString (rs, 22)); 
      returnObject2.setSolicitInd(getString (rs, 23)); 
      returnObject2.setLocGroupTpCode(getString (rs, 24)); 
      returnObject2.setEffectStartMMDD(getIntObject (rs, 25)); 
      returnObject2.setEffectEndMMDD(getIntObject (rs, 26)); 
      returnObject2.setEffectStartTm(getIntObject (rs, 27)); 
      returnObject2.setEffectEndTm(getIntObject (rs, 28)); 
      returnObject2.setStartDt(getTimestamp (rs, 29)); 
      returnObject2.setEndDt(getTimestamp (rs, 30)); 
      returnObject2.setLastUpdateDt(getTimestamp (rs, 31)); 
      returnObject2.setLastUpdateUser(getString (rs, 32)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 33)); 
      returnObject2.setLastUsedDt(getTimestamp (rs, 34)); 
      returnObject2.setLastVerifiedDt(getTimestamp (rs, 35)); 
      returnObject2.setSourceIdentTpCd(getLongObject (rs, 36)); 
      returnObject.add (returnObject2);

      EObjXAddressGroupExt returnObject3 = new EObjXAddressGroupExt ();
      returnObject3.setXVerified(getLongObject (rs, 37)); 
      returnObject3.setXRetailerId(getLongObject (rs, 38)); 
      returnObject3.setXLastModifiedSystemDate(getTimestamp (rs, 39)); 
      returnObject3.setXAddressRetailerFlag(getString (rs, 40)); 
      returnObject3.setTitleOfHonor(getString (rs, 41)); 
      returnObject3.setCompanyName(getString (rs, 42)); 
      returnObject3.setSFAddressId(getString (rs, 43)); 
      returnObject3.setX_BPID(getString (rs, 44)); 
      returnObject.add (returnObject3);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT DISTINCT A.LOCATION_GROUP_ID , A.ADDRESS_ID , A.LAST_UPDATE_DT , B.LOCATION_GROUP_ID , B.LAST_UPDATE_DT, A.XVERIFIED_TP_CD, A.XRETAILER_ID, A.XMODIFY_SYS_DT, A.XADDR_RETAILER_FLAG, A.TITLE_OF_HONOR, A.COMPANY_NAME, A.SFAddress_Id, A.X_BPID FROM H_ADDRESSGROUP A, H_LOCATIONGROUP B WHERE B.CONT_ID = ? AND A.LOCATION_GROUP_ID = B.LOCATION_GROUP_ID AND A.LAST_UPDATE_TX_ID = B.LAST_UPDATE_TX_ID AND (( A.LAST_UPDATE_DT BETWEEN ? AND ? ) OR ( B.H_CREATE_DT BETWEEN ? AND ?))", pattern="tableAlias (ADDRESSGROUP => com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup, H_ADDRESSGROUP => com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup, LOCATIONGROUP => com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup, H_LOCATIONGROUP => com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup , ADDRESSGROUP => com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt , H_ADDRESSGROUP => com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue3<EObjAddressGroup,EObjLocationGroup,EObjXAddressGroupExt>> getPartyAddressLightImages (Object[] parameters)
  {
    return queryIterator (getPartyAddressLightImagesStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getPartyAddressLightImagesStatementDescriptor = createStatementDescriptor (
    "getPartyAddressLightImages(Object[])",
    "SELECT DISTINCT A.LOCATION_GROUP_ID , A.ADDRESS_ID , A.LAST_UPDATE_DT , B.LOCATION_GROUP_ID , B.LAST_UPDATE_DT, A.XVERIFIED_TP_CD, A.XRETAILER_ID, A.XMODIFY_SYS_DT, A.XADDR_RETAILER_FLAG, A.TITLE_OF_HONOR, A.COMPANY_NAME, A.SFAddress_Id, A.X_BPID FROM H_ADDRESSGROUP A, H_LOCATIONGROUP B WHERE B.CONT_ID = ? AND A.LOCATION_GROUP_ID = B.LOCATION_GROUP_ID AND A.LAST_UPDATE_TX_ID = B.LAST_UPDATE_TX_ID AND (( A.LAST_UPDATE_DT BETWEEN ? AND ? ) OR ( B.H_CREATE_DT BETWEEN ? AND ?))",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"location_group_id", "address_id", "last_update_dt", "location_group_id", "last_update_dt", "xverified_tp_cd", "xretailer_id", "xmodify_sys_dt", "xaddr_retailer_flag", "title_of_honor", "company_name", "sfaddress_id", "x_bpid"},
    new GetPartyAddressLightImagesParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP}, {19, 0, 0, 0, 0}, {0, 0, 0, 0, 0}, {1, 1, 1, 1, 1}},
    null,
    new GetPartyAddressLightImagesRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.BIGINT, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR}, {19, 19, 0, 19, 0, 19, 19, 0, 5, 255, 255, 250, 50}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    10);

  /**
   * @generated
   */
  public static class GetPartyAddressLightImagesParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
      setObject (stmt, 4, Types.TIMESTAMP, parameters[3], 0);
      setObject (stmt, 5, Types.TIMESTAMP, parameters[4], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetPartyAddressLightImagesRowHandler extends BaseRowHandler<ResultQueue3<EObjAddressGroup,EObjLocationGroup,EObjXAddressGroupExt>>
  {
    /**
     * @generated
     */
    public ResultQueue3<EObjAddressGroup,EObjLocationGroup,EObjXAddressGroupExt> handle (java.sql.ResultSet rs, ResultQueue3<EObjAddressGroup,EObjLocationGroup,EObjXAddressGroupExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue3<EObjAddressGroup,EObjLocationGroup,EObjXAddressGroupExt> ();

      EObjAddressGroup returnObject1 = new EObjAddressGroup ();
      returnObject1.setLocationGroupIdPK(getLongObject (rs, 1)); 
      returnObject1.setAddressId(getLongObject (rs, 2)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 3)); 
      returnObject.add (returnObject1);

      EObjLocationGroup returnObject2 = new EObjLocationGroup ();
      returnObject2.setLocationGroupIdPK(getLongObject (rs, 4)); 
      returnObject2.setLastUpdateDt(getTimestamp (rs, 5)); 
      returnObject.add (returnObject2);

      EObjXAddressGroupExt returnObject3 = new EObjXAddressGroupExt ();
      returnObject3.setLastUpdateDt(getTimestamp (rs, 3)); 
      returnObject3.setXVerified(getLongObject (rs, 6)); 
      returnObject3.setXRetailerId(getLongObject (rs, 7)); 
      returnObject3.setXLastModifiedSystemDate(getTimestamp (rs, 8)); 
      returnObject3.setXAddressRetailerFlag(getString (rs, 9)); 
      returnObject3.setTitleOfHonor(getString (rs, 10)); 
      returnObject3.setCompanyName(getString (rs, 11)); 
      returnObject3.setSFAddressId(getString (rs, 12)); 
      returnObject3.setX_BPID(getString (rs, 13)); 
      returnObject.add (returnObject3);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT A.H_LOCATION_GROUP_I AS H_ADDRESS_GROUP_I, A.H_ACTION_CODE , A.H_CREATED_BY , A.H_CREATE_DT , A.H_END_DT , A.LOCATION_GROUP_ID , A.ADDRESS_ID , A.CARE_OF_DESC , A.ADDR_USAGE_TP_CD , A.LAST_UPDATE_DT , A.LAST_UPDATE_USER , A.LAST_UPDATE_TX_ID , B.H_LOCATION_GROUP_I AS H_LOCATION_GROUP_I, B.H_ACTION_CODE , B.H_CREATED_BY , B.H_CREATE_DT , B.H_END_DT, B.LOCATION_GROUP_ID , B.UNDEL_REASON_TP_CD , B.CONT_ID , B.MEMBER_IND , B.PREFERRED_IND , B.SOLICIT_IND , B.LOC_GROUP_TP_CODE , B.EFFECT_START_MMDD , B.EFFECT_END_MMDD , B.EFFECT_START_TM , B.EFFECT_END_TM , B.START_DT , B.END_DT , B.LAST_UPDATE_DT , B.LAST_UPDATE_USER , B.LAST_UPDATE_TX_ID , B.LAST_USED_DT , B.LAST_VERIFIED_DT , B.SOURCE_IDENT_TP_CD, A.XVERIFIED_TP_CD, A.XRETAILER_ID, A.XMODIFY_SYS_DT, A.XADDR_RETAILER_FLAG, A.TITLE_OF_HONOR, A.COMPANY_NAME, A.SFAddress_Id, A.X_BPID FROM H_ADDRESSGROUP A, H_LOCATIONGROUP B WHERE B.H_LOCATION_GROUP_I = ? AND A.H_LOCATION_GROUP_I = B.H_LOCATION_GROUP_I AND (( ? BETWEEN A.H_CREATE_DT AND A.H_END_DT ) OR ( ? >= A.H_CREATE_DT AND A.H_END_DT IS NULL )) AND (( ? BETWEEN B.H_CREATE_DT AND B.H_END_DT ) OR ( ? >= B.H_CREATE_DT AND B.H_END_DT IS NULL ))", pattern="tableAlias (ADDRESSGROUP => com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup, H_ADDRESSGROUP => com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup, LOCATIONGROUP => com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup, H_LOCATIONGROUP => com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup , ADDRESSGROUP => com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt , H_ADDRESSGROUP => com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue3<EObjAddressGroup,EObjLocationGroup,EObjXAddressGroupExt>> getPartyAddressHistoryById (Object[] parameters)
  {
    return queryIterator (getPartyAddressHistoryByIdStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getPartyAddressHistoryByIdStatementDescriptor = createStatementDescriptor (
    "getPartyAddressHistoryById(Object[])",
    "SELECT A.H_LOCATION_GROUP_I AS H_ADDRESS_GROUP_I, A.H_ACTION_CODE , A.H_CREATED_BY , A.H_CREATE_DT , A.H_END_DT , A.LOCATION_GROUP_ID , A.ADDRESS_ID , A.CARE_OF_DESC , A.ADDR_USAGE_TP_CD , A.LAST_UPDATE_DT , A.LAST_UPDATE_USER , A.LAST_UPDATE_TX_ID , B.H_LOCATION_GROUP_I AS H_LOCATION_GROUP_I, B.H_ACTION_CODE , B.H_CREATED_BY , B.H_CREATE_DT , B.H_END_DT, B.LOCATION_GROUP_ID , B.UNDEL_REASON_TP_CD , B.CONT_ID , B.MEMBER_IND , B.PREFERRED_IND , B.SOLICIT_IND , B.LOC_GROUP_TP_CODE , B.EFFECT_START_MMDD , B.EFFECT_END_MMDD , B.EFFECT_START_TM , B.EFFECT_END_TM , B.START_DT , B.END_DT , B.LAST_UPDATE_DT , B.LAST_UPDATE_USER , B.LAST_UPDATE_TX_ID , B.LAST_USED_DT , B.LAST_VERIFIED_DT , B.SOURCE_IDENT_TP_CD, A.XVERIFIED_TP_CD, A.XRETAILER_ID, A.XMODIFY_SYS_DT, A.XADDR_RETAILER_FLAG, A.TITLE_OF_HONOR, A.COMPANY_NAME, A.SFAddress_Id, A.X_BPID FROM H_ADDRESSGROUP A, H_LOCATIONGROUP B WHERE B.H_LOCATION_GROUP_I = ? AND A.H_LOCATION_GROUP_I = B.H_LOCATION_GROUP_I AND (( ? BETWEEN A.H_CREATE_DT AND A.H_END_DT ) OR ( ? >= A.H_CREATE_DT AND A.H_END_DT IS NULL )) AND (( ? BETWEEN B.H_CREATE_DT AND B.H_END_DT ) OR ( ? >= B.H_CREATE_DT AND B.H_END_DT IS NULL ))",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"h_address_group_i", "h_action_code", "h_created_by", "h_create_dt", "h_end_dt", "location_group_id", "address_id", "care_of_desc", "addr_usage_tp_cd", "last_update_dt", "last_update_user", "last_update_tx_id", "h_location_group_i", "h_action_code", "h_created_by", "h_create_dt", "h_end_dt", "location_group_id", "undel_reason_tp_cd", "cont_id", "member_ind", "preferred_ind", "solicit_ind", "loc_group_tp_code", "effect_start_mmdd", "effect_end_mmdd", "effect_start_tm", "effect_end_tm", "start_dt", "end_dt", "last_update_dt", "last_update_user", "last_update_tx_id", "last_used_dt", "last_verified_dt", "source_ident_tp_cd", "xverified_tp_cd", "xretailer_id", "xmodify_sys_dt", "xaddr_retailer_flag", "title_of_honor", "company_name", "sfaddress_id", "x_bpid"},
    new GetPartyAddressHistoryByIdParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP}, {19, 0, 0, 0, 0}, {0, 0, 0, 0, 0}, {1, 1, 1, 1, 1}},
    null,
    new GetPartyAddressHistoryByIdRowHandler (),
    new int[][]{ {Types.BIGINT, Types.CHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.CHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR}, {19, 1, 20, 0, 0, 19, 19, 50, 19, 0, 20, 19, 19, 1, 20, 0, 0, 19, 19, 19, 0, 0, 0, 0, 10, 10, 10, 10, 0, 0, 0, 20, 19, 0, 0, 19, 19, 19, 0, 5, 255, 255, 250, 50}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    11);

  /**
   * @generated
   */
  public static class GetPartyAddressHistoryByIdParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
      setObject (stmt, 4, Types.TIMESTAMP, parameters[3], 0);
      setObject (stmt, 5, Types.TIMESTAMP, parameters[4], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetPartyAddressHistoryByIdRowHandler extends BaseRowHandler<ResultQueue3<EObjAddressGroup,EObjLocationGroup,EObjXAddressGroupExt>>
  {
    /**
     * @generated
     */
    public ResultQueue3<EObjAddressGroup,EObjLocationGroup,EObjXAddressGroupExt> handle (java.sql.ResultSet rs, ResultQueue3<EObjAddressGroup,EObjLocationGroup,EObjXAddressGroupExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue3<EObjAddressGroup,EObjLocationGroup,EObjXAddressGroupExt> ();

      EObjAddressGroup returnObject1 = new EObjAddressGroup ();
      returnObject1.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject1.setHistActionCode(getString (rs, 2)); 
      returnObject1.setHistCreatedBy(getString (rs, 3)); 
      returnObject1.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject1.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject1.setLocationGroupIdPK(getLongObject (rs, 6)); 
      returnObject1.setAddressId(getLongObject (rs, 7)); 
      returnObject1.setCareOfDesc(getString (rs, 8)); 
      returnObject1.setAddrUsageTpCd(getLongObject (rs, 9)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 10)); 
      returnObject1.setLastUpdateUser(getString (rs, 11)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 12)); 
      returnObject.add (returnObject1);

      EObjLocationGroup returnObject2 = new EObjLocationGroup ();
      returnObject2.setHistoryIdPK(getLongObject (rs, 13)); 
      returnObject2.setHistActionCode(getString (rs, 14)); 
      returnObject2.setHistCreatedBy(getString (rs, 15)); 
      returnObject2.setHistCreateDt(getTimestamp (rs, 16)); 
      returnObject2.setHistEndDt(getTimestamp (rs, 17)); 
      returnObject2.setLocationGroupIdPK(getLongObject (rs, 18)); 
      returnObject2.setUndelReasonTpCd(getLongObject (rs, 19)); 
      returnObject2.setContId(getLongObject (rs, 20)); 
      returnObject2.setMemberInd(getString (rs, 21)); 
      returnObject2.setPreferredInd(getString (rs, 22)); 
      returnObject2.setSolicitInd(getString (rs, 23)); 
      returnObject2.setLocGroupTpCode(getString (rs, 24)); 
      returnObject2.setEffectStartMMDD(getIntObject (rs, 25)); 
      returnObject2.setEffectEndMMDD(getIntObject (rs, 26)); 
      returnObject2.setEffectStartTm(getIntObject (rs, 27)); 
      returnObject2.setEffectEndTm(getIntObject (rs, 28)); 
      returnObject2.setStartDt(getTimestamp (rs, 29)); 
      returnObject2.setEndDt(getTimestamp (rs, 30)); 
      returnObject2.setLastUpdateDt(getTimestamp (rs, 31)); 
      returnObject2.setLastUpdateUser(getString (rs, 32)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 33)); 
      returnObject2.setLastUsedDt(getTimestamp (rs, 34)); 
      returnObject2.setLastVerifiedDt(getTimestamp (rs, 35)); 
      returnObject2.setSourceIdentTpCd(getLongObject (rs, 36)); 
      returnObject.add (returnObject2);

      EObjXAddressGroupExt returnObject3 = new EObjXAddressGroupExt ();
      returnObject3.setHistActionCode(getString (rs, 2)); 
      returnObject3.setHistCreatedBy(getString (rs, 3)); 
      returnObject3.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject3.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject3.setLastUpdateDt(getTimestamp (rs, 10)); 
      returnObject3.setLastUpdateUser(getString (rs, 11)); 
      returnObject3.setLastUpdateTxId(getLongObject (rs, 12)); 
      returnObject3.setXVerified(getLongObject (rs, 37)); 
      returnObject3.setXRetailerId(getLongObject (rs, 38)); 
      returnObject3.setXLastModifiedSystemDate(getTimestamp (rs, 39)); 
      returnObject3.setXAddressRetailerFlag(getString (rs, 40)); 
      returnObject3.setTitleOfHonor(getString (rs, 41)); 
      returnObject3.setCompanyName(getString (rs, 42)); 
      returnObject3.setSFAddressId(getString (rs, 43)); 
      returnObject3.setX_BPID(getString (rs, 44)); 
      returnObject.add (returnObject3);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT ADDRESSGROUP.LOCATION_GROUP_ID , ADDRESSGROUP.ADDRESS_ID , ADDRESSGROUP.CARE_OF_DESC , ADDRESSGROUP.ADDR_USAGE_TP_CD , ADDRESSGROUP.LAST_UPDATE_DT , ADDRESSGROUP.LAST_UPDATE_USER , ADDRESSGROUP.LAST_UPDATE_TX_ID , LOCATIONGROUP.LOCATION_GROUP_ID , LOCATIONGROUP.UNDEL_REASON_TP_CD , LOCATIONGROUP.CONT_ID , LOCATIONGROUP.MEMBER_IND , LOCATIONGROUP.PREFERRED_IND , LOCATIONGROUP.SOLICIT_IND , LOCATIONGROUP.LOC_GROUP_TP_CODE , LOCATIONGROUP.EFFECT_START_MMDD , LOCATIONGROUP.EFFECT_END_MMDD , LOCATIONGROUP.EFFECT_START_TM , LOCATIONGROUP.EFFECT_END_TM , LOCATIONGROUP.START_DT , LOCATIONGROUP.END_DT , LOCATIONGROUP.LAST_UPDATE_DT , LOCATIONGROUP.LAST_UPDATE_USER , LOCATIONGROUP.LAST_UPDATE_TX_ID ,LOCATIONGROUP.LAST_USED_DT , LOCATIONGROUP.LAST_VERIFIED_DT , LOCATIONGROUP.SOURCE_IDENT_TP_CD, ADDRESSGROUP.XVERIFIED_TP_CD, ADDRESSGROUP.XRETAILER_ID, ADDRESSGROUP.XMODIFY_SYS_DT, ADDRESSGROUP.XADDR_RETAILER_FLAG, ADDRESSGROUP.TITLE_OF_HONOR, ADDRESSGROUP.COMPANY_NAME, ADDRESSGROUP.SFAddress_Id, ADDRESSGROUP.X_BPID FROM CONTACT, ADDRESSGROUP, LOCATIONGROUP WHERE ADDRESSGROUP.LOCATION_GROUP_ID = LOCATIONGROUP.LOCATION_GROUP_ID AND ADDRESSGROUP.ADDRESS_ID = ? AND (LOCATIONGROUP.CONT_ID = CONTACT.CONT_ID)", pattern="tableAlias (ADDRESSGROUP => com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup, H_ADDRESSGROUP => com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup, LOCATIONGROUP => com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup, H_LOCATIONGROUP => com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup , ADDRESSGROUP => com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt , H_ADDRESSGROUP => com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue3<EObjAddressGroup,EObjLocationGroup,EObjXAddressGroupExt>> getPartyAddressesByAddressIdAll (Object[] parameters)
  {
    return queryIterator (getPartyAddressesByAddressIdAllStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getPartyAddressesByAddressIdAllStatementDescriptor = createStatementDescriptor (
    "getPartyAddressesByAddressIdAll(Object[])",
    "SELECT ADDRESSGROUP.LOCATION_GROUP_ID , ADDRESSGROUP.ADDRESS_ID , ADDRESSGROUP.CARE_OF_DESC , ADDRESSGROUP.ADDR_USAGE_TP_CD , ADDRESSGROUP.LAST_UPDATE_DT , ADDRESSGROUP.LAST_UPDATE_USER , ADDRESSGROUP.LAST_UPDATE_TX_ID , LOCATIONGROUP.LOCATION_GROUP_ID , LOCATIONGROUP.UNDEL_REASON_TP_CD , LOCATIONGROUP.CONT_ID , LOCATIONGROUP.MEMBER_IND , LOCATIONGROUP.PREFERRED_IND , LOCATIONGROUP.SOLICIT_IND , LOCATIONGROUP.LOC_GROUP_TP_CODE , LOCATIONGROUP.EFFECT_START_MMDD , LOCATIONGROUP.EFFECT_END_MMDD , LOCATIONGROUP.EFFECT_START_TM , LOCATIONGROUP.EFFECT_END_TM , LOCATIONGROUP.START_DT , LOCATIONGROUP.END_DT , LOCATIONGROUP.LAST_UPDATE_DT , LOCATIONGROUP.LAST_UPDATE_USER , LOCATIONGROUP.LAST_UPDATE_TX_ID ,LOCATIONGROUP.LAST_USED_DT , LOCATIONGROUP.LAST_VERIFIED_DT , LOCATIONGROUP.SOURCE_IDENT_TP_CD, ADDRESSGROUP.XVERIFIED_TP_CD, ADDRESSGROUP.XRETAILER_ID, ADDRESSGROUP.XMODIFY_SYS_DT, ADDRESSGROUP.XADDR_RETAILER_FLAG, ADDRESSGROUP.TITLE_OF_HONOR, ADDRESSGROUP.COMPANY_NAME, ADDRESSGROUP.SFAddress_Id, ADDRESSGROUP.X_BPID FROM CONTACT, ADDRESSGROUP, LOCATIONGROUP WHERE ADDRESSGROUP.LOCATION_GROUP_ID = LOCATIONGROUP.LOCATION_GROUP_ID AND ADDRESSGROUP.ADDRESS_ID = ? AND (LOCATIONGROUP.CONT_ID = CONTACT.CONT_ID)",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"location_group_id", "address_id", "care_of_desc", "addr_usage_tp_cd", "last_update_dt", "last_update_user", "last_update_tx_id", "location_group_id", "undel_reason_tp_cd", "cont_id", "member_ind", "preferred_ind", "solicit_ind", "loc_group_tp_code", "effect_start_mmdd", "effect_end_mmdd", "effect_start_tm", "effect_end_tm", "start_dt", "end_dt", "last_update_dt", "last_update_user", "last_update_tx_id", "last_used_dt", "last_verified_dt", "source_ident_tp_cd", "xverified_tp_cd", "xretailer_id", "xmodify_sys_dt", "xaddr_retailer_flag", "title_of_honor", "company_name", "sfaddress_id", "x_bpid"},
    new GetPartyAddressesByAddressIdAllParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetPartyAddressesByAddressIdAllRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR}, {19, 19, 50, 19, 0, 20, 19, 19, 19, 19, 0, 0, 0, 0, 10, 10, 10, 10, 0, 0, 0, 20, 19, 0, 0, 19, 19, 19, 0, 5, 255, 255, 250, 50}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    12);

  /**
   * @generated
   */
  public static class GetPartyAddressesByAddressIdAllParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetPartyAddressesByAddressIdAllRowHandler extends BaseRowHandler<ResultQueue3<EObjAddressGroup,EObjLocationGroup,EObjXAddressGroupExt>>
  {
    /**
     * @generated
     */
    public ResultQueue3<EObjAddressGroup,EObjLocationGroup,EObjXAddressGroupExt> handle (java.sql.ResultSet rs, ResultQueue3<EObjAddressGroup,EObjLocationGroup,EObjXAddressGroupExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue3<EObjAddressGroup,EObjLocationGroup,EObjXAddressGroupExt> ();

      EObjAddressGroup returnObject1 = new EObjAddressGroup ();
      returnObject1.setLocationGroupIdPK(getLongObject (rs, 1)); 
      returnObject1.setAddressId(getLongObject (rs, 2)); 
      returnObject1.setCareOfDesc(getString (rs, 3)); 
      returnObject1.setAddrUsageTpCd(getLongObject (rs, 4)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 5)); 
      returnObject1.setLastUpdateUser(getString (rs, 6)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 7)); 
      returnObject.add (returnObject1);

      EObjLocationGroup returnObject2 = new EObjLocationGroup ();
      returnObject2.setLocationGroupIdPK(getLongObject (rs, 8)); 
      returnObject2.setUndelReasonTpCd(getLongObject (rs, 9)); 
      returnObject2.setContId(getLongObject (rs, 10)); 
      returnObject2.setMemberInd(getString (rs, 11)); 
      returnObject2.setPreferredInd(getString (rs, 12)); 
      returnObject2.setSolicitInd(getString (rs, 13)); 
      returnObject2.setLocGroupTpCode(getString (rs, 14)); 
      returnObject2.setEffectStartMMDD(getIntObject (rs, 15)); 
      returnObject2.setEffectEndMMDD(getIntObject (rs, 16)); 
      returnObject2.setEffectStartTm(getIntObject (rs, 17)); 
      returnObject2.setEffectEndTm(getIntObject (rs, 18)); 
      returnObject2.setStartDt(getTimestamp (rs, 19)); 
      returnObject2.setEndDt(getTimestamp (rs, 20)); 
      returnObject2.setLastUpdateDt(getTimestamp (rs, 21)); 
      returnObject2.setLastUpdateUser(getString (rs, 22)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 23)); 
      returnObject2.setLastUsedDt(getTimestamp (rs, 24)); 
      returnObject2.setLastVerifiedDt(getTimestamp (rs, 25)); 
      returnObject2.setSourceIdentTpCd(getLongObject (rs, 26)); 
      returnObject.add (returnObject2);

      EObjXAddressGroupExt returnObject3 = new EObjXAddressGroupExt ();
      returnObject3.setLastUpdateDt(getTimestamp (rs, 5)); 
      returnObject3.setLastUpdateUser(getString (rs, 6)); 
      returnObject3.setLastUpdateTxId(getLongObject (rs, 7)); 
      returnObject3.setXVerified(getLongObject (rs, 27)); 
      returnObject3.setXRetailerId(getLongObject (rs, 28)); 
      returnObject3.setXLastModifiedSystemDate(getTimestamp (rs, 29)); 
      returnObject3.setXAddressRetailerFlag(getString (rs, 30)); 
      returnObject3.setTitleOfHonor(getString (rs, 31)); 
      returnObject3.setCompanyName(getString (rs, 32)); 
      returnObject3.setSFAddressId(getString (rs, 33)); 
      returnObject3.setX_BPID(getString (rs, 34)); 
      returnObject.add (returnObject3);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT ADDRESSGROUP.LOCATION_GROUP_ID , ADDRESSGROUP.ADDRESS_ID , ADDRESSGROUP.CARE_OF_DESC, ADDRESSGROUP.ADDR_USAGE_TP_CD , ADDRESSGROUP.LAST_UPDATE_DT , ADDRESSGROUP.LAST_UPDATE_USER , ADDRESSGROUP.LAST_UPDATE_TX_ID , LOCATIONGROUP.LOCATION_GROUP_ID , LOCATIONGROUP.UNDEL_REASON_TP_CD, LOCATIONGROUP.CONT_ID, LOCATIONGROUP.MEMBER_IND , LOCATIONGROUP.PREFERRED_IND , LOCATIONGROUP.SOLICIT_IND , LOCATIONGROUP.LOC_GROUP_TP_CODE , LOCATIONGROUP.EFFECT_START_MMDD , LOCATIONGROUP.EFFECT_END_MMDD , LOCATIONGROUP.EFFECT_START_TM , LOCATIONGROUP.EFFECT_END_TM , LOCATIONGROUP.START_DT , LOCATIONGROUP.END_DT, LOCATIONGROUP.LAST_UPDATE_DT , LOCATIONGROUP.LAST_UPDATE_USER , LOCATIONGROUP.LAST_UPDATE_TX_ID, ADDRESSGROUP.XVERIFIED_TP_CD, ADDRESSGROUP.XRETAILER_ID, ADDRESSGROUP.XMODIFY_SYS_DT, ADDRESSGROUP.XADDR_RETAILER_FLAG, ADDRESSGROUP.TITLE_OF_HONOR, ADDRESSGROUP.COMPANY_NAME, ADDRESSGROUP.SFAddress_Id, ADDRESSGROUP.X_BPID FROM CONTACT, ADDRESSGROUP, LOCATIONGROUP WHERE ADDRESSGROUP.LOCATION_GROUP_ID = LOCATIONGROUP.LOCATION_GROUP_ID AND ADDRESSGROUP.ADDRESS_ID = ? AND (LOCATIONGROUP.END_DT < ?) AND (LOCATIONGROUP.CONT_ID = CONTACT.CONT_ID ) AND (CONTACT.INACTIVATED_DT < ? )", pattern="tableAlias (ADDRESSGROUP => com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup, H_ADDRESSGROUP => com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup, LOCATIONGROUP => com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup, H_LOCATIONGROUP => com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup , ADDRESSGROUP => com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt , H_ADDRESSGROUP => com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue3<EObjAddressGroup,EObjLocationGroup,EObjXAddressGroupExt>> getPartyAddressesByAddressIdInactive (Object[] parameters)
  {
    return queryIterator (getPartyAddressesByAddressIdInactiveStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getPartyAddressesByAddressIdInactiveStatementDescriptor = createStatementDescriptor (
    "getPartyAddressesByAddressIdInactive(Object[])",
    "SELECT ADDRESSGROUP.LOCATION_GROUP_ID , ADDRESSGROUP.ADDRESS_ID , ADDRESSGROUP.CARE_OF_DESC, ADDRESSGROUP.ADDR_USAGE_TP_CD , ADDRESSGROUP.LAST_UPDATE_DT , ADDRESSGROUP.LAST_UPDATE_USER , ADDRESSGROUP.LAST_UPDATE_TX_ID , LOCATIONGROUP.LOCATION_GROUP_ID , LOCATIONGROUP.UNDEL_REASON_TP_CD, LOCATIONGROUP.CONT_ID, LOCATIONGROUP.MEMBER_IND , LOCATIONGROUP.PREFERRED_IND , LOCATIONGROUP.SOLICIT_IND , LOCATIONGROUP.LOC_GROUP_TP_CODE , LOCATIONGROUP.EFFECT_START_MMDD , LOCATIONGROUP.EFFECT_END_MMDD , LOCATIONGROUP.EFFECT_START_TM , LOCATIONGROUP.EFFECT_END_TM , LOCATIONGROUP.START_DT , LOCATIONGROUP.END_DT, LOCATIONGROUP.LAST_UPDATE_DT , LOCATIONGROUP.LAST_UPDATE_USER , LOCATIONGROUP.LAST_UPDATE_TX_ID, ADDRESSGROUP.XVERIFIED_TP_CD, ADDRESSGROUP.XRETAILER_ID, ADDRESSGROUP.XMODIFY_SYS_DT, ADDRESSGROUP.XADDR_RETAILER_FLAG, ADDRESSGROUP.TITLE_OF_HONOR, ADDRESSGROUP.COMPANY_NAME, ADDRESSGROUP.SFAddress_Id, ADDRESSGROUP.X_BPID FROM CONTACT, ADDRESSGROUP, LOCATIONGROUP WHERE ADDRESSGROUP.LOCATION_GROUP_ID = LOCATIONGROUP.LOCATION_GROUP_ID AND ADDRESSGROUP.ADDRESS_ID = ? AND (LOCATIONGROUP.END_DT < ?) AND (LOCATIONGROUP.CONT_ID = CONTACT.CONT_ID ) AND (CONTACT.INACTIVATED_DT < ? )",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"location_group_id", "address_id", "care_of_desc", "addr_usage_tp_cd", "last_update_dt", "last_update_user", "last_update_tx_id", "location_group_id", "undel_reason_tp_cd", "cont_id", "member_ind", "preferred_ind", "solicit_ind", "loc_group_tp_code", "effect_start_mmdd", "effect_end_mmdd", "effect_start_tm", "effect_end_tm", "start_dt", "end_dt", "last_update_dt", "last_update_user", "last_update_tx_id", "xverified_tp_cd", "xretailer_id", "xmodify_sys_dt", "xaddr_retailer_flag", "title_of_honor", "company_name", "sfaddress_id", "x_bpid"},
    new GetPartyAddressesByAddressIdInactiveParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP}, {19, 0, 0}, {0, 0, 0}, {1, 1, 1}},
    null,
    new GetPartyAddressesByAddressIdInactiveRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR}, {19, 19, 50, 19, 0, 20, 19, 19, 19, 19, 0, 0, 0, 0, 10, 10, 10, 10, 0, 0, 0, 20, 19, 19, 19, 0, 5, 255, 255, 250, 50}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    13);

  /**
   * @generated
   */
  public static class GetPartyAddressesByAddressIdInactiveParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetPartyAddressesByAddressIdInactiveRowHandler extends BaseRowHandler<ResultQueue3<EObjAddressGroup,EObjLocationGroup,EObjXAddressGroupExt>>
  {
    /**
     * @generated
     */
    public ResultQueue3<EObjAddressGroup,EObjLocationGroup,EObjXAddressGroupExt> handle (java.sql.ResultSet rs, ResultQueue3<EObjAddressGroup,EObjLocationGroup,EObjXAddressGroupExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue3<EObjAddressGroup,EObjLocationGroup,EObjXAddressGroupExt> ();

      EObjAddressGroup returnObject1 = new EObjAddressGroup ();
      returnObject1.setLocationGroupIdPK(getLongObject (rs, 1)); 
      returnObject1.setAddressId(getLongObject (rs, 2)); 
      returnObject1.setCareOfDesc(getString (rs, 3)); 
      returnObject1.setAddrUsageTpCd(getLongObject (rs, 4)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 5)); 
      returnObject1.setLastUpdateUser(getString (rs, 6)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 7)); 
      returnObject.add (returnObject1);

      EObjLocationGroup returnObject2 = new EObjLocationGroup ();
      returnObject2.setLocationGroupIdPK(getLongObject (rs, 8)); 
      returnObject2.setUndelReasonTpCd(getLongObject (rs, 9)); 
      returnObject2.setContId(getLongObject (rs, 10)); 
      returnObject2.setMemberInd(getString (rs, 11)); 
      returnObject2.setPreferredInd(getString (rs, 12)); 
      returnObject2.setSolicitInd(getString (rs, 13)); 
      returnObject2.setLocGroupTpCode(getString (rs, 14)); 
      returnObject2.setEffectStartMMDD(getIntObject (rs, 15)); 
      returnObject2.setEffectEndMMDD(getIntObject (rs, 16)); 
      returnObject2.setEffectStartTm(getIntObject (rs, 17)); 
      returnObject2.setEffectEndTm(getIntObject (rs, 18)); 
      returnObject2.setStartDt(getTimestamp (rs, 19)); 
      returnObject2.setEndDt(getTimestamp (rs, 20)); 
      returnObject2.setLastUpdateDt(getTimestamp (rs, 21)); 
      returnObject2.setLastUpdateUser(getString (rs, 22)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 23)); 
      returnObject.add (returnObject2);

      EObjXAddressGroupExt returnObject3 = new EObjXAddressGroupExt ();
      returnObject3.setLastUpdateDt(getTimestamp (rs, 5)); 
      returnObject3.setLastUpdateUser(getString (rs, 6)); 
      returnObject3.setLastUpdateTxId(getLongObject (rs, 7)); 
      returnObject3.setXVerified(getLongObject (rs, 24)); 
      returnObject3.setXRetailerId(getLongObject (rs, 25)); 
      returnObject3.setXLastModifiedSystemDate(getTimestamp (rs, 26)); 
      returnObject3.setXAddressRetailerFlag(getString (rs, 27)); 
      returnObject3.setTitleOfHonor(getString (rs, 28)); 
      returnObject3.setCompanyName(getString (rs, 29)); 
      returnObject3.setSFAddressId(getString (rs, 30)); 
      returnObject3.setX_BPID(getString (rs, 31)); 
      returnObject.add (returnObject3);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT DISTINCT A.ADDRESS_ID, B.CONT_ID FROM H_ADDRESSGROUP A, H_LOCATIONGROUP B WHERE B.LOCATION_GROUP_ID = A.LOCATION_GROUP_ID AND A.ADDRESS_ID IN (SELECT ADDRESS_ID FROM H_ADDRESSGROUP WHERE LOCATION_GROUP_ID IN (SELECT LOCATION_GROUP_ID FROM H_LOCATIONGROUP WHERE CONT_ID = ? AND LOC_GROUP_TP_CODE = 'A'))", pattern="tableAlias (ADDRESSGROUP => com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup, H_ADDRESSGROUP => com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup, LOCATIONGROUP => com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup, H_LOCATIONGROUP => com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup , ADDRESSGROUP => com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt , H_ADDRESSGROUP => com.ibm.daimler.dsea.entityObject.EObjXAddressGroupExt)" )
   * 
   * @generated
   */
  public java.util.Iterator<com.ibm.mdm.base.db.ResultQueue2<com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup,com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup>> getPartyAddressesHistoryByPartyId (Object[] parameters)
  {
    return queryIterator (getPartyAddressesHistoryByPartyIdStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getPartyAddressesHistoryByPartyIdStatementDescriptor = createStatementDescriptor (
    "getPartyAddressesHistoryByPartyId(Object[])",
    "SELECT DISTINCT A.ADDRESS_ID, B.CONT_ID FROM H_ADDRESSGROUP A, H_LOCATIONGROUP B WHERE B.LOCATION_GROUP_ID = A.LOCATION_GROUP_ID AND A.ADDRESS_ID IN (SELECT ADDRESS_ID FROM H_ADDRESSGROUP WHERE LOCATION_GROUP_ID IN (SELECT LOCATION_GROUP_ID FROM H_LOCATIONGROUP WHERE CONT_ID = ? AND LOC_GROUP_TP_CODE = 'A'))",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"address_id", "cont_id"},
    new GetPartyAddressesHistoryByPartyIdParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetPartyAddressesHistoryByPartyIdRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT}, {19, 19}, {0, 0}, {0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    14);

  /**
   * @generated
   */
  public static class GetPartyAddressesHistoryByPartyIdParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetPartyAddressesHistoryByPartyIdRowHandler extends BaseRowHandler<ResultQueue2<EObjAddressGroup,EObjLocationGroup>>
  {
    /**
     * @generated
     */
    public ResultQueue2<EObjAddressGroup,EObjLocationGroup> handle (java.sql.ResultSet rs, ResultQueue2<EObjAddressGroup,EObjLocationGroup> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue2<EObjAddressGroup,EObjLocationGroup> ();

      EObjAddressGroup returnObject1 = new EObjAddressGroup ();
      returnObject1.setAddressId(getLongObject (rs, 1)); 
      returnObject.add (returnObject1);

      EObjLocationGroup returnObject2 = new EObjLocationGroup ();
      returnObject2.setContId(getLongObject (rs, 2)); 
      returnObject.add (returnObject2);

    
      return returnObject;
    }
  }

}
