/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[79d7721c85ee0add33cda9e382ae4e3d]
 */

package com.ibm.daimler.dsea.entityObject;


import com.ibm.mdm.base.db.ResultQueue1;
import java.util.Iterator;
import com.ibm.mdm.base.db.EntityMapping;
import com.ibm.pdq.annotation.Select;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * @generated
 */
public interface XVRCollapseInquiryData {
  
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String tableAliasString = "tableAlias (" + 
                                            "XVRCOLLAPSE => com.ibm.daimler.dsea.entityObject.EObjXVRCollapse, " +
                                            "H_XVRCOLLAPSE => com.ibm.daimler.dsea.entityObject.EObjXVRCollapse" +
                                            ")";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getXVRCollapseSql = "SELECT r.XVRCollapsepk_Id XVRCollapsepk_Id, r.SUSPECT_IDS SUSPECT_IDS, r.GOLDEN_CONT_ID GOLDEN_CONT_ID, r.ACTION ACTION, r.FLAG FLAG, r.Create_Date Create_Date, r.MARKET_NAME MARKET_NAME, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XVRCOLLAPSE r WHERE r.XVRCollapsepk_Id = ? ";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXVRCollapseParameters =
    "EObjXVRCollapse.XVRCollapsepkId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXVRCollapseResults =
    "EObjXVRCollapse.XVRCollapsepkId," +
    "EObjXVRCollapse.SuspectIds," +
    "EObjXVRCollapse.GoldenContId," +
    "EObjXVRCollapse.Action," +
    "EObjXVRCollapse.Flag," +
    "EObjXVRCollapse.CreateDate," +
    "EObjXVRCollapse.MarketName," +
    "EObjXVRCollapse.lastUpdateDt," +
    "EObjXVRCollapse.lastUpdateUser," +
    "EObjXVRCollapse.lastUpdateTxId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getXVRCollapseHistorySql = "SELECT r.H_XVRCollapsepk_Id hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.XVRCollapsepk_Id XVRCollapsepk_Id, r.SUSPECT_IDS SUSPECT_IDS, r.GOLDEN_CONT_ID GOLDEN_CONT_ID, r.ACTION ACTION, r.FLAG FLAG, r.Create_Date Create_Date, r.MARKET_NAME MARKET_NAME, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XVRCOLLAPSE r WHERE r.H_XVRCollapsepk_Id = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXVRCollapseHistoryParameters =
    "EObjXVRCollapse.XVRCollapsepkId," +
    "EObjXVRCollapse.lastUpdateDt," +
    "EObjXVRCollapse.lastUpdateDt";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXVRCollapseHistoryResults =
    "EObjXVRCollapse.historyIdPK," +
    "EObjXVRCollapse.histActionCode," +
    "EObjXVRCollapse.histCreatedBy," +
    "EObjXVRCollapse.histCreateDt," +
    "EObjXVRCollapse.histEndDt," +
    "EObjXVRCollapse.XVRCollapsepkId," +
    "EObjXVRCollapse.SuspectIds," +
    "EObjXVRCollapse.GoldenContId," +
    "EObjXVRCollapse.Action," +
    "EObjXVRCollapse.Flag," +
    "EObjXVRCollapse.CreateDate," +
    "EObjXVRCollapse.MarketName," +
    "EObjXVRCollapse.lastUpdateDt," +
    "EObjXVRCollapse.lastUpdateUser," +
    "EObjXVRCollapse.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getXVRCollapseSql, pattern=tableAliasString)
  @EntityMapping(parameters=getXVRCollapseParameters, results=getXVRCollapseResults)
  Iterator<ResultQueue1<EObjXVRCollapse>> getXVRCollapse(Object[] parameters);  


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getXVRCollapseHistorySql, pattern=tableAliasString)
  @EntityMapping(parameters=getXVRCollapseHistoryParameters, results=getXVRCollapseHistoryResults)
  Iterator<ResultQueue1<EObjXVRCollapse>> getXVRCollapseHistory(Object[] parameters);  


}


