/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[f778ffc7b0dc420318cda155140de23a]
 */


package com.ibm.daimler.dsea.entityObject;

import java.util.Iterator;
import com.ibm.mdm.base.db.EntityMapping;
import com.ibm.pdq.annotation.Select;
import com.ibm.pdq.annotation.Update;

import com.ibm.daimler.dsea.entityObject.EObjXDeleteAudit;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * @generated
 */
public interface EObjXDeleteAuditData {


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjXDeleteAuditSql = "select XDelete_Auditpk_Id, CONT_ID, ADMIN_CLIENT_ID, ADMIN_SYSTEM_VALUE, DESCRIPTION, DELETE_DATE, MARKET_NAME, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from XDELETEAUDIT where XDelete_Auditpk_Id = ? ";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String createEObjXDeleteAuditSql = "insert into XDELETEAUDIT (XDelete_Auditpk_Id, CONT_ID, ADMIN_CLIENT_ID, ADMIN_SYSTEM_VALUE, DESCRIPTION, DELETE_DATE, MARKET_NAME, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( :xDeleteAuditpkId, :cONT_ID, :aDMIN_CLIENT_ID, :aDMIN_SYSTEM_VALUE, :dESCRIPTION, :dELETE_DATE, :mARKET_NAME, :lastUpdateDt, :lastUpdateUser, :lastUpdateTxId)";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String updateEObjXDeleteAuditSql = "update XDELETEAUDIT set CONT_ID = :cONT_ID, ADMIN_CLIENT_ID = :aDMIN_CLIENT_ID, ADMIN_SYSTEM_VALUE = :aDMIN_SYSTEM_VALUE, DESCRIPTION = :dESCRIPTION, DELETE_DATE = :dELETE_DATE, MARKET_NAME = :mARKET_NAME, LAST_UPDATE_DT = :lastUpdateDt, LAST_UPDATE_USER = :lastUpdateUser, LAST_UPDATE_TX_ID = :lastUpdateTxId where XDelete_Auditpk_Id = :xDeleteAuditpkId and LAST_UPDATE_DT = :oldLastUpdateDt";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String deleteEObjXDeleteAuditSql = "delete from XDELETEAUDIT where XDelete_Auditpk_Id = ?";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXDeleteAuditKeyField = "EObjXDeleteAudit.xDeleteAuditpkId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXDeleteAuditGetFields =
    "EObjXDeleteAudit.xDeleteAuditpkId," +
    "EObjXDeleteAudit.cONT_ID," +
    "EObjXDeleteAudit.aDMIN_CLIENT_ID," +
    "EObjXDeleteAudit.aDMIN_SYSTEM_VALUE," +
    "EObjXDeleteAudit.dESCRIPTION," +
    "EObjXDeleteAudit.dELETE_DATE," +
    "EObjXDeleteAudit.mARKET_NAME," +
    "EObjXDeleteAudit.lastUpdateDt," +
    "EObjXDeleteAudit.lastUpdateUser," +
    "EObjXDeleteAudit.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXDeleteAuditAllFields =
    "com.ibm.daimler.dsea.entityObject.EObjXDeleteAudit.xDeleteAuditpkId," +
    "com.ibm.daimler.dsea.entityObject.EObjXDeleteAudit.cONT_ID," +
    "com.ibm.daimler.dsea.entityObject.EObjXDeleteAudit.aDMIN_CLIENT_ID," +
    "com.ibm.daimler.dsea.entityObject.EObjXDeleteAudit.aDMIN_SYSTEM_VALUE," +
    "com.ibm.daimler.dsea.entityObject.EObjXDeleteAudit.dESCRIPTION," +
    "com.ibm.daimler.dsea.entityObject.EObjXDeleteAudit.dELETE_DATE," +
    "com.ibm.daimler.dsea.entityObject.EObjXDeleteAudit.mARKET_NAME," +
    "com.ibm.daimler.dsea.entityObject.EObjXDeleteAudit.lastUpdateDt," +
    "com.ibm.daimler.dsea.entityObject.EObjXDeleteAudit.lastUpdateUser," +
    "com.ibm.daimler.dsea.entityObject.EObjXDeleteAudit.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXDeleteAuditUpdateFields =
    "com.ibm.daimler.dsea.entityObject.EObjXDeleteAudit.cONT_ID," +
    "com.ibm.daimler.dsea.entityObject.EObjXDeleteAudit.aDMIN_CLIENT_ID," +
    "com.ibm.daimler.dsea.entityObject.EObjXDeleteAudit.aDMIN_SYSTEM_VALUE," +
    "com.ibm.daimler.dsea.entityObject.EObjXDeleteAudit.dESCRIPTION," +
    "com.ibm.daimler.dsea.entityObject.EObjXDeleteAudit.dELETE_DATE," +
    "com.ibm.daimler.dsea.entityObject.EObjXDeleteAudit.mARKET_NAME," +
    "com.ibm.daimler.dsea.entityObject.EObjXDeleteAudit.lastUpdateDt," +
    "com.ibm.daimler.dsea.entityObject.EObjXDeleteAudit.lastUpdateUser," +
    "com.ibm.daimler.dsea.entityObject.EObjXDeleteAudit.lastUpdateTxId," +
    "com.ibm.daimler.dsea.entityObject.EObjXDeleteAudit.xDeleteAuditpkId," +
    "com.ibm.daimler.dsea.entityObject.EObjXDeleteAudit.oldLastUpdateDt";   

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Select XDeleteAudit by parameters.
   * @generated
   */
  @Select(sql=getEObjXDeleteAuditSql)
  @EntityMapping(parameters=EObjXDeleteAuditKeyField, results=EObjXDeleteAuditGetFields)
  Iterator<EObjXDeleteAudit> getEObjXDeleteAudit(Long xDeleteAuditpkId);  
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Create XDeleteAudit by EObjXDeleteAudit Object.
   * @generated
   */
  @Update(sql=createEObjXDeleteAuditSql)
  @EntityMapping(parameters=EObjXDeleteAuditAllFields)
    int createEObjXDeleteAudit(EObjXDeleteAudit e); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Update one XDeleteAudit by EObjXDeleteAudit object.
   * @generated
   */
  @Update(sql=updateEObjXDeleteAuditSql)
  @EntityMapping(parameters=EObjXDeleteAuditUpdateFields)
    int updateEObjXDeleteAudit(EObjXDeleteAudit e); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Delete XDeleteAudit by parameters.
   * @generated
   */
  @Update(sql=deleteEObjXDeleteAuditSql)
  @EntityMapping(parameters=EObjXDeleteAuditKeyField)
  int deleteEObjXDeleteAudit(Long xDeleteAuditpkId);

}

