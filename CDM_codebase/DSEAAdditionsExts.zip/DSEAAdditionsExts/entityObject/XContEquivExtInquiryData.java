/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[3c2de83918a54f28c08401c61fd36e7b]
 */
package com.ibm.daimler.dsea.entityObject;


import com.ibm.mdm.base.db.EntityMapping;
import com.ibm.pdq.annotation.Select;


import com.dwl.tcrm.coreParty.entityObject.EObjContEquiv;

import com.ibm.mdm.base.db.ResultQueue2;

import java.util.Iterator;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * 
 * @generated
 */
public interface XContEquivExtInquiryData {

  /**
   * MDM_TODO: CDKWB0050I The generated parameter and result lists in this file should be checked to ensure that each matches its
   * associated SQL query. Each list entry must be comma separated and identify a field within an entity object class.
   */ 
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */ 
   public final static String tableAliasString1 = "tableAlias (" + 
     "CONTEQUIV => com.dwl.tcrm.coreParty.entityObject.EObjContEquiv, " + 
     "H_CONTEQUIV => com.dwl.tcrm.coreParty.entityObject.EObjContEquiv , " + 
     "CONTEQUIV => com.ibm.daimler.dsea.entityObject.EObjXContEquivExt , " + 
     "H_CONTEQUIV => com.ibm.daimler.dsea.entityObject.EObjXContEquivExt" + 
     ")";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension
   * XContEquiv.
   *
   * @generated
   */ 
   public final static String getPartyAdminSysKeyByIdHistorySQL = "SELECT A.H_CONT_EQUIV_ID AS HIST_ID_PK, A.H_ACTION_CODE, A.H_CREATED_BY, A.H_CREATE_DT, A.H_END_DT, A.CONT_EQUIV_ID, A.CONT_ID, A.ADMIN_SYS_TP_CD, A.ADMIN_CLIENT_ID, A.DESCRIPTION, A.LAST_UPDATE_DT, A.LAST_UPDATE_USER, A.LAST_UPDATE_TX_ID, A.XRETAILER_ID, A.XSOURCE_RETAILER_FLAG, A.XMODIFY_SYS_DT" + 
     " FROM H_CONTEQUIV A" + 
     " WHERE A.H_CREATE_DT = (SELECT MAX(A1.H_CREATE_DT)" + 
     " FROM H_CONTEQUIV A1" + 
     " WHERE A1.CONT_EQUIV_ID = A.CONT_EQUIV_ID AND CONT_EQUIV_ID = ? AND A1.LAST_UPDATE_DT <= ?)";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyAdminSysKeyByIdHistoryParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.contEquivIdPK=CONT_EQUIV_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.lastUpdateDt=LAST_UPDATE_DT"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyAdminSysKeyByIdHistoryResults =
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.historyIdPK=HIST_ID_PK," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.histActionCode=H_ACTION_CODE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.histCreatedBy=H_CREATED_BY," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.histEndDt=H_END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.contEquivIdPK=CONT_EQUIV_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.adminSysTpCd=ADMIN_SYS_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.adminClientId=ADMIN_CLIENT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.description=DESCRIPTION," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContEquivExt.XRetailerId=XRETAILER_ID," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContEquivExt.XSourceRetailerFlag=XSOURCE_RETAILER_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContEquivExt.XLastModifiedSystemDate=XMODIFY_SYS_DT"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension
   * XContEquiv.
   *
   * @generated
   */ 
   public final static String getPartyAdminSysKeyByIdSQL = "SELECT CONTEQUIV.CONT_EQUIV_ID, CONTEQUIV.CONT_ID , CONTEQUIV.ADMIN_SYS_TP_CD, CONTEQUIV.ADMIN_CLIENT_ID, CONTEQUIV.DESCRIPTION , CONTEQUIV.LAST_UPDATE_DT, CONTEQUIV.LAST_UPDATE_USER , CONTEQUIV.LAST_UPDATE_TX_ID, CONTEQUIV.XRETAILER_ID, CONTEQUIV.XSOURCE_RETAILER_FLAG, CONTEQUIV.XMODIFY_SYS_DT" + 
     " FROM CONTEQUIV" + 
     " WHERE CONTEQUIV.CONT_EQUIV_ID = ?";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyAdminSysKeyByIdParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.contEquivIdPK=CONT_EQUIV_ID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyAdminSysKeyByIdResults =
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.contEquivIdPK=CONT_EQUIV_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.adminSysTpCd=ADMIN_SYS_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.adminClientId=ADMIN_CLIENT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.description=DESCRIPTION," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContEquivExt.XRetailerId=XRETAILER_ID," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContEquivExt.XSourceRetailerFlag=XSOURCE_RETAILER_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContEquivExt.XLastModifiedSystemDate=XMODIFY_SYS_DT"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension
   * XContEquiv.
   *
   * @generated
   */ 
   public final static String getPartyAdminSysKeyHistorySQL = "SELECT A.H_CONT_EQUIV_ID AS HIST_ID_PK, A.H_ACTION_CODE, A.H_CREATED_BY, A.H_CREATE_DT, A.H_END_DT, A.CONT_EQUIV_ID, A.CONT_ID, A.ADMIN_SYS_TP_CD, A.ADMIN_CLIENT_ID, A.DESCRIPTION, A.LAST_UPDATE_DT, A.LAST_UPDATE_USER, A.LAST_UPDATE_TX_ID, A.XRETAILER_ID, A.XSOURCE_RETAILER_FLAG, A.XMODIFY_SYS_DT" + 
     " FROM H_CONTEQUIV A" + 
     " WHERE A.ADMIN_SYS_TP_CD = ? AND A.ADMIN_CLIENT_ID = ? AND (? BETWEEN A.H_CREATE_DT AND A.H_END_DT OR (? >= A.H_CREATE_DT AND A.H_END_DT IS NULL ))";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyAdminSysKeyHistoryParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.adminSysTpCd=ADMIN_SYS_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.adminClientId=ADMIN_CLIENT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.histCreateDt=H_CREATE_DT"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyAdminSysKeyHistoryResults =
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.historyIdPK=HIST_ID_PK," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.histActionCode=H_ACTION_CODE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.histCreatedBy=H_CREATED_BY," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.histEndDt=H_END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.contEquivIdPK=CONT_EQUIV_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.adminSysTpCd=ADMIN_SYS_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.adminClientId=ADMIN_CLIENT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.description=DESCRIPTION," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContEquivExt.XRetailerId=XRETAILER_ID," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContEquivExt.XSourceRetailerFlag=XSOURCE_RETAILER_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContEquivExt.XLastModifiedSystemDate=XMODIFY_SYS_DT"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension
   * XContEquiv.
   *
   * @generated
   */ 
   public final static String getPartyAdminSysKeySQL = "SELECT CONTEQUIV.CONT_EQUIV_ID ,CONTEQUIV.CONT_ID, CONTEQUIV.ADMIN_SYS_TP_CD, CONTEQUIV.ADMIN_CLIENT_ID, CONTEQUIV.DESCRIPTION, CONTEQUIV.LAST_UPDATE_DT, CONTEQUIV.LAST_UPDATE_USER, CONTEQUIV.LAST_UPDATE_USER, CONTEQUIV.LAST_UPDATE_TX_ID, CONTEQUIV.XRETAILER_ID, CONTEQUIV.XSOURCE_RETAILER_FLAG, CONTEQUIV.XMODIFY_SYS_DT" + 
     " FROM CONTEQUIV" + 
     " WHERE CONTEQUIV.ADMIN_SYS_TP_CD = ? AND CONTEQUIV.ADMIN_CLIENT_ID = ?";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyAdminSysKeyParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.adminSysTpCd=ADMIN_SYS_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.adminClientId=ADMIN_CLIENT_ID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyAdminSysKeyResults =
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.contEquivIdPK=CONT_EQUIV_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.adminSysTpCd=ADMIN_SYS_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.adminClientId=ADMIN_CLIENT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.description=DESCRIPTION," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContEquivExt.XRetailerId=XRETAILER_ID," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContEquivExt.XSourceRetailerFlag=XSOURCE_RETAILER_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContEquivExt.XLastModifiedSystemDate=XMODIFY_SYS_DT"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension
   * XContEquiv.
   *
   * @generated
   */ 
   public final static String getPartyAdminSysKeyHistoryByPartIdSQL = "SELECT A.H_CONT_EQUIV_ID AS HIST_ID_PK, A.H_ACTION_CODE, A.H_CREATED_BY, A.H_CREATE_DT, A.H_END_DT, A.CONT_EQUIV_ID, A.CONT_ID, A.ADMIN_SYS_TP_CD, A.ADMIN_CLIENT_ID, A.DESCRIPTION, A.LAST_UPDATE_DT, A.LAST_UPDATE_USER, A.LAST_UPDATE_TX_ID, A.XRETAILER_ID, A.XSOURCE_RETAILER_FLAG, A.XMODIFY_SYS_DT" + 
     " FROM H_CONTEQUIV A" + 
     " WHERE A.CONT_ID = ? AND A.ADMIN_SYS_TP_CD = ? AND (? BETWEEN A.H_CREATE_DT AND A.H_END_DT OR (? >= A.H_CREATE_DT AND A.H_END_DT IS NULL ))";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyAdminSysKeyHistoryByPartIdParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.adminSysTpCd=ADMIN_SYS_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.histCreateDt=H_CREATE_DT"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyAdminSysKeyHistoryByPartIdResults =
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.historyIdPK=HIST_ID_PK," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.histActionCode=H_ACTION_CODE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.histCreatedBy=H_CREATED_BY," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.histEndDt=H_END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.contEquivIdPK=CONT_EQUIV_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.adminSysTpCd=ADMIN_SYS_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.adminClientId=ADMIN_CLIENT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.description=DESCRIPTION," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContEquivExt.XRetailerId=XRETAILER_ID," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContEquivExt.XSourceRetailerFlag=XSOURCE_RETAILER_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContEquivExt.XLastModifiedSystemDate=XMODIFY_SYS_DT"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension
   * XContEquiv.
   *
   * @generated
   */ 
   public final static String getPartyAdminSysKeyByPartIdSQL = "SELECT CONTEQUIV.CONT_EQUIV_ID, CONTEQUIV.CONT_ID , CONTEQUIV.ADMIN_SYS_TP_CD , CONTEQUIV.ADMIN_CLIENT_ID , CONTEQUIV.DESCRIPTION, CONTEQUIV.LAST_UPDATE_DT, CONTEQUIV.LAST_UPDATE_USER , CONTEQUIV.LAST_UPDATE_TX_ID, CONTEQUIV.XRETAILER_ID, CONTEQUIV.XSOURCE_RETAILER_FLAG, CONTEQUIV.XMODIFY_SYS_DT" + 
     " FROM CONTEQUIV" + 
     " WHERE CONTEQUIV.ADMIN_SYS_TP_CD = ? AND CONTEQUIV.CONT_ID = ?";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyAdminSysKeyByPartIdParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.adminSysTpCd=ADMIN_SYS_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.contId=CONT_ID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyAdminSysKeyByPartIdResults =
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.contEquivIdPK=CONT_EQUIV_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.adminSysTpCd=ADMIN_SYS_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.adminClientId=ADMIN_CLIENT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.description=DESCRIPTION," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContEquivExt.XRetailerId=XRETAILER_ID," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContEquivExt.XSourceRetailerFlag=XSOURCE_RETAILER_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContEquivExt.XLastModifiedSystemDate=XMODIFY_SYS_DT"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension
   * XContEquiv.
   *
   * @generated
   */ 
   public final static String getPartyAdminSysKeysHistorySQL = "SELECT A.H_CONT_EQUIV_ID AS HIST_ID_PK, A.H_ACTION_CODE, A.H_CREATED_BY, A.H_CREATE_DT, A.H_END_DT, A.CONT_EQUIV_ID, A.CONT_ID, A.ADMIN_SYS_TP_CD, A.ADMIN_CLIENT_ID, A.DESCRIPTION, A.LAST_UPDATE_DT, A.LAST_UPDATE_USER, A.LAST_UPDATE_TX_ID, A.XRETAILER_ID, A.XSOURCE_RETAILER_FLAG, A.XMODIFY_SYS_DT" + 
     " FROM H_CONTEQUIV A" + 
     " WHERE A.CONT_ID = ? AND (? BETWEEN A.H_CREATE_DT AND A.H_END_DT OR (? >= A.H_CREATE_DT AND A.H_END_DT IS NULL ))";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyAdminSysKeysHistoryParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.histCreateDt=H_CREATE_DT"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyAdminSysKeysHistoryResults =
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.historyIdPK=HIST_ID_PK," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.histActionCode=H_ACTION_CODE," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.histCreatedBy=H_CREATED_BY," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.histEndDt=H_END_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.contEquivIdPK=CONT_EQUIV_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.adminSysTpCd=ADMIN_SYS_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.adminClientId=ADMIN_CLIENT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.description=DESCRIPTION," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContEquivExt.XRetailerId=XRETAILER_ID," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContEquivExt.XSourceRetailerFlag=XSOURCE_RETAILER_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContEquivExt.XLastModifiedSystemDate=XMODIFY_SYS_DT"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension
   * XContEquiv.
   *
   * @generated
   */ 
   public final static String getPartyAdminSysKeysSQL = "SELECT CONTEQUIV.CONT_EQUIV_ID, CONTEQUIV.CONT_ID , CONTEQUIV.ADMIN_SYS_TP_CD , CONTEQUIV.ADMIN_CLIENT_ID, CONTEQUIV.DESCRIPTION, CONTEQUIV.LAST_UPDATE_DT, CONTEQUIV.LAST_UPDATE_USER , CONTEQUIV.LAST_UPDATE_TX_ID, CONTEQUIV.XRETAILER_ID, CONTEQUIV.XSOURCE_RETAILER_FLAG, CONTEQUIV.XMODIFY_SYS_DT" + 
     " FROM CONTEQUIV" + 
     " WHERE CONTEQUIV.CONT_ID = ?";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyAdminSysKeysParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.contId=CONT_ID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyAdminSysKeysResults =
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.contEquivIdPK=CONT_EQUIV_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.adminSysTpCd=ADMIN_SYS_TP_CD," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.adminClientId=ADMIN_CLIENT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.description=DESCRIPTION," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContEquivExt.XRetailerId=XRETAILER_ID," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContEquivExt.XSourceRetailerFlag=XSOURCE_RETAILER_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContEquivExt.XLastModifiedSystemDate=XMODIFY_SYS_DT"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension
   * XContEquiv.
   *
   * @generated
   */ 
   public final static String getPartyAdminSysKeysLightImageSQL = "SELECT A.CONT_EQUIV_ID, A.LAST_UPDATE_DT, A.XRETAILER_ID, A.XSOURCE_RETAILER_FLAG, A.XMODIFY_SYS_DT" + 
     " FROM H_CONTEQUIV A" + 
     " WHERE A.CONT_ID = ? AND (A.H_CREATE_DT BETWEEN ? AND ?)";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyAdminSysKeysLightImageParameters =
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.contId=CONT_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.histCreateDt=H_CREATE_DT"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getPartyAdminSysKeysLightImageResults =
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.contEquivIdPK=CONT_EQUIV_ID," + 
    "com.dwl.tcrm.coreParty.entityObject.EObjContEquiv.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContEquivExt.XRetailerId=XRETAILER_ID," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContEquivExt.XSourceRetailerFlag=XSOURCE_RETAILER_FLAG," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContEquivExt.XLastModifiedSystemDate=XMODIFY_SYS_DT"; 


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getPartyAdminSysKeyByIdHistorySQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getPartyAdminSysKeyByIdHistoryParameters, results=getPartyAdminSysKeyByIdHistoryResults)
  		Iterator<ResultQueue2<EObjContEquiv, EObjXContEquivExt>> getPartyAdminSysKeyByIdHistory(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getPartyAdminSysKeyByIdSQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getPartyAdminSysKeyByIdParameters, results=getPartyAdminSysKeyByIdResults)
  		Iterator<ResultQueue2<EObjContEquiv, EObjXContEquivExt>> getPartyAdminSysKeyById(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getPartyAdminSysKeyHistorySQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getPartyAdminSysKeyHistoryParameters, results=getPartyAdminSysKeyHistoryResults)
  		Iterator<ResultQueue2<EObjContEquiv, EObjXContEquivExt>> getPartyAdminSysKeyHistory(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getPartyAdminSysKeySQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getPartyAdminSysKeyParameters, results=getPartyAdminSysKeyResults)
  		Iterator<ResultQueue2<EObjContEquiv, EObjXContEquivExt>> getPartyAdminSysKey(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getPartyAdminSysKeyHistoryByPartIdSQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getPartyAdminSysKeyHistoryByPartIdParameters, results=getPartyAdminSysKeyHistoryByPartIdResults)
  		Iterator<ResultQueue2<EObjContEquiv, EObjXContEquivExt>> getPartyAdminSysKeyHistoryByPartId(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getPartyAdminSysKeyByPartIdSQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getPartyAdminSysKeyByPartIdParameters, results=getPartyAdminSysKeyByPartIdResults)
  		Iterator<ResultQueue2<EObjContEquiv, EObjXContEquivExt>> getPartyAdminSysKeyByPartId(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getPartyAdminSysKeysHistorySQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getPartyAdminSysKeysHistoryParameters, results=getPartyAdminSysKeysHistoryResults)
  		Iterator<ResultQueue2<EObjContEquiv, EObjXContEquivExt>> getPartyAdminSysKeysHistory(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getPartyAdminSysKeysSQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getPartyAdminSysKeysParameters, results=getPartyAdminSysKeysResults)
  		Iterator<ResultQueue2<EObjContEquiv, EObjXContEquivExt>> getPartyAdminSysKeys(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getPartyAdminSysKeysLightImageSQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getPartyAdminSysKeysLightImageParameters, results=getPartyAdminSysKeysLightImageResults)
  		Iterator<ResultQueue2<EObjContEquiv, EObjXContEquivExt>> getPartyAdminSysKeysLightImage(Object[] parameters);
 
}


