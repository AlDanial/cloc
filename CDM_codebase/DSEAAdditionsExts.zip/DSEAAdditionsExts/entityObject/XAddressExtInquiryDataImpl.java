package com.ibm.daimler.dsea.entityObject;

import com.ibm.pdq.runtime.generator.BaseParameterHandler;
import java.util.Iterator;
import java.sql.PreparedStatement;
import com.ibm.pdq.runtime.statement.StatementDescriptor;
import com.ibm.pdq.runtime.generator.BaseData;
import java.sql.SQLException;
import com.ibm.daimler.dsea.entityObject.EObjXAddressExt;
import com.ibm.pdq.annotation.Metadata;
import com.ibm.mdm.base.db.ResultQueue2;
import com.dwl.tcrm.coreParty.entityObject.EObjAddress;
import com.ibm.pdq.runtime.generator.BaseRowHandler;
import com.ibm.pdq.runtime.statement.SqlStatementType;
import java.sql.Types;


@SuppressWarnings("unchecked")

/**
 * <!-- begin-user-doc -->
 * 
 * <!-- end-user-doc -->
 * 
 * @generated
 */
public class XAddressExtInquiryDataImpl  extends BaseData implements XAddressExtInquiryData
{

  /**
   * @generated
   */
  public static final String generatorVersion = "3.200.75";

  /**
   * @generated
   */
  public static final String identifier = "XAddressExtInquiryData";

  /**
   * @generated
   */
  public static final long generationTime = 0x0000015de99d12b3L;

  /**
   * @generated
   */
  public static final String collection = "NULLID";

  /**
   * @generated
   */
  public static final String packageVersion = null;

  /**
   * @generated
   */
  public static final boolean forceSingleBindIsolation = false;

  /**
   * @generated
   */
  public XAddressExtInquiryDataImpl()
  {
    super();
  } 

  /**
   * @generated
   */
  public String getGeneratorVersion()
  {
    return generatorVersion;
  }

  /**
   * @Select( sql="SELECT DISTINCT A.H_ADDRESS_ID AS HIST_ID_PK, A.H_ACTION_CODE, A.H_CREATED_BY, A.H_CREATE_DT, A.H_END_DT, A.ADDRESS_ID, A.RESIDENCE_TP_CD, A.ADDR_LINE_ONE, A.ADDR_LINE_TWO, A.ADDR_LINE_THREE, A.P_ADDR_LINE_ONE, A.P_ADDR_LINE_TWO, A.P_ADDR_LINE_THREE, A.CITY_NAME, A.POSTAL_CODE,A.POSTAL_BARCODE, A.RESIDENCE_NUM, A.PROV_STATE_TP_CD, A.COUNTY_CODE, A.COUNTRY_TP_CD, A.ADDR_STANDARD_IND, A.OVERRIDE_IND, A.LATITUDE_DEGREES, A.LONGITUDE_DEGREES, A.LAST_UPDATE_DT, A.LAST_UPDATE_USER, A.LAST_UPDATE_TX_ID, A.BUILDING_NAME, A.STREET_NUMBER, A.STREET_NAME, A.STREET_SUFFIX, A.STREET_PREFIX, A.PRE_DIRECTIONAL, A.POST_DIRECTIONAL, A.BOX_DESIGNATOR, A.BOX_ID, A.STN_INFO, A.STN_ID, A.REGION, A.DEL_DESIGNATOR, A.DEL_ID, A.DEL_INFO, A.XADDR_VERIFICATION_DT, A.XSUBCITY_TP_CD, A.XDISTRICT_TP_CD, A.XBUILDING_NAME, A.XSTREET_NUMBER, A.XSTREET_NAME, A.XSuburb FROM H_ADDRESS A WHERE A.H_ADDRESS_ID = ? AND (( ? BETWEEN A.H_CREATE_DT AND A.H_END_DT ) OR ( ? >= A.H_CREATE_DT AND A.H_END_DT IS NULL ))", pattern="tableAlias (ADDRESS => com.dwl.tcrm.coreParty.entityObject.EObjAddress, H_ADDRESS => com.dwl.tcrm.coreParty.entityObject.EObjAddress, addressgroup => com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup, locationgroup => com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup, contmacrorole => com.dwl.tcrm.coreParty.entityObject.EObjContMacroRole, macroroleassoc => com.dwl.tcrm.coreParty.entityObject.EObjMacroRoleAssoc , ADDRESS => com.ibm.daimler.dsea.entityObject.EObjXAddressExt , H_ADDRESS => com.ibm.daimler.dsea.entityObject.EObjXAddressExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue2<EObjAddress,EObjXAddressExt>> getAddressHistory (Object[] parameters)
  {
    return queryIterator (getAddressHistoryStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getAddressHistoryStatementDescriptor = createStatementDescriptor (
    "getAddressHistory(Object[])",
    "SELECT DISTINCT A.H_ADDRESS_ID AS HIST_ID_PK, A.H_ACTION_CODE, A.H_CREATED_BY, A.H_CREATE_DT, A.H_END_DT, A.ADDRESS_ID, A.RESIDENCE_TP_CD, A.ADDR_LINE_ONE, A.ADDR_LINE_TWO, A.ADDR_LINE_THREE, A.P_ADDR_LINE_ONE, A.P_ADDR_LINE_TWO, A.P_ADDR_LINE_THREE, A.CITY_NAME, A.POSTAL_CODE,A.POSTAL_BARCODE, A.RESIDENCE_NUM, A.PROV_STATE_TP_CD, A.COUNTY_CODE, A.COUNTRY_TP_CD, A.ADDR_STANDARD_IND, A.OVERRIDE_IND, A.LATITUDE_DEGREES, A.LONGITUDE_DEGREES, A.LAST_UPDATE_DT, A.LAST_UPDATE_USER, A.LAST_UPDATE_TX_ID, A.BUILDING_NAME, A.STREET_NUMBER, A.STREET_NAME, A.STREET_SUFFIX, A.STREET_PREFIX, A.PRE_DIRECTIONAL, A.POST_DIRECTIONAL, A.BOX_DESIGNATOR, A.BOX_ID, A.STN_INFO, A.STN_ID, A.REGION, A.DEL_DESIGNATOR, A.DEL_ID, A.DEL_INFO, A.XADDR_VERIFICATION_DT, A.XSUBCITY_TP_CD, A.XDISTRICT_TP_CD, A.XBUILDING_NAME, A.XSTREET_NUMBER, A.XSTREET_NAME, A.XSuburb FROM H_ADDRESS A WHERE A.H_ADDRESS_ID = ? AND (( ? BETWEEN A.H_CREATE_DT AND A.H_END_DT ) OR ( ? >= A.H_CREATE_DT AND A.H_END_DT IS NULL ))",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"hist_id_pk", "h_action_code", "h_created_by", "h_create_dt", "h_end_dt", "address_id", "residence_tp_cd", "addr_line_one", "addr_line_two", "addr_line_three", "p_addr_line_one", "p_addr_line_two", "p_addr_line_three", "city_name", "postal_code", "postal_barcode", "residence_num", "prov_state_tp_cd", "county_code", "country_tp_cd", "addr_standard_ind", "override_ind", "latitude_degrees", "longitude_degrees", "last_update_dt", "last_update_user", "last_update_tx_id", "building_name", "street_number", "street_name", "street_suffix", "street_prefix", "pre_directional", "post_directional", "box_designator", "box_id", "stn_info", "stn_id", "region", "del_designator", "del_id", "del_info", "xaddr_verification_dt", "xsubcity_tp_cd", "xdistrict_tp_cd", "xbuilding_name", "xstreet_number", "xstreet_name", "xsuburb"},
    new GetAddressHistoryParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP}, {19, 0, 0}, {0, 0, 0}, {1, 1, 1}},
    null,
    new GetAddressHistoryRowHandler (),
    new int[][]{ {Types.BIGINT, Types.CHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.CHAR, Types.CHAR, Types.CHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.CHAR, Types.BIGINT, Types.CHAR, Types.CHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR}, {19, 1, 20, 0, 0, 19, 19, 100, 100, 100, 8, 8, 8, 50, 20, 30, 10, 19, 3, 19, 1, 1, 10, 10, 0, 20, 19, 64, 16, 64, 16, 16, 16, 16, 16, 16, 16, 16, 32, 16, 16, 50, 0, 19, 19, 500, 500, 250, 255}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    1);

  /**
   * @generated
   */
  public static class GetAddressHistoryParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetAddressHistoryRowHandler extends BaseRowHandler<ResultQueue2<EObjAddress,EObjXAddressExt>>
  {
    /**
     * @generated
     */
    public ResultQueue2<EObjAddress,EObjXAddressExt> handle (java.sql.ResultSet rs, ResultQueue2<EObjAddress,EObjXAddressExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue2<EObjAddress,EObjXAddressExt> ();

      EObjAddress returnObject1 = new EObjAddress ();
      returnObject1.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject1.setHistActionCode(getString (rs, 2)); 
      returnObject1.setHistCreatedBy(getString (rs, 3)); 
      returnObject1.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject1.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject1.setAddressIdPK(getLongObject (rs, 6)); 
      returnObject1.setResidenceTpCd(getLongObject (rs, 7)); 
      returnObject1.setAddrLineOne(getString (rs, 8)); 
      returnObject1.setAddrLineTwo(getString (rs, 9)); 
      returnObject1.setAddrLineThree(getString (rs, 10)); 
      returnObject1.setPAddrLineOne(getString (rs, 11)); 
      returnObject1.setPAddrLineTwo(getString (rs, 12)); 
      returnObject1.setPAddrLineThree(getString (rs, 13)); 
      returnObject1.setCityName(getString (rs, 14)); 
      returnObject1.setPostalCode(getString (rs, 15)); 
      returnObject1.setPostalBarCode(getString (rs, 16)); 
      returnObject1.setResidenceNum(getString (rs, 17)); 
      returnObject1.setProvStateTpCd(getLongObject (rs, 18)); 
      returnObject1.setCountyCode(getString (rs, 19)); 
      returnObject1.setCountryTpCd(getLongObject (rs, 20)); 
      returnObject1.setAddrStandardInd(getString (rs, 21)); 
      returnObject1.setOverrideInd(getString (rs, 22)); 
      returnObject1.setLatitudeDegrees(getString (rs, 23)); 
      returnObject1.setLongtitudeDegrees(getString (rs, 24)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 25)); 
      returnObject1.setLastUpdateUser(getString (rs, 26)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 27)); 
      returnObject1.setBuildingName(getString (rs, 28)); 
      returnObject1.setStreetNumber(getString (rs, 29)); 
      returnObject1.setStreetName(getString (rs, 30)); 
      returnObject1.setStreetSuffix(getString (rs, 31)); 
      returnObject1.setStreetPrefix(getString (rs, 32)); 
      returnObject1.setPreDirectional(getString (rs, 33)); 
      returnObject1.setPostDirectional(getString (rs, 34)); 
      returnObject1.setBoxDesignator(getString (rs, 35)); 
      returnObject1.setBoxId(getString (rs, 36)); 
      returnObject1.setStnInfo(getString (rs, 37)); 
      returnObject1.setStnId(getString (rs, 38)); 
      returnObject1.setRegion(getString (rs, 39)); 
      returnObject1.setDelDesignator(getString (rs, 40)); 
      returnObject1.setDelId(getString (rs, 41)); 
      returnObject1.setDelInfo(getString (rs, 42)); 
      returnObject.add (returnObject1);

      EObjXAddressExt returnObject2 = new EObjXAddressExt ();
      returnObject2.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject2.setHistActionCode(getString (rs, 2)); 
      returnObject2.setHistCreatedBy(getString (rs, 3)); 
      returnObject2.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject2.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject2.setLastUpdateDt(getTimestamp (rs, 25)); 
      returnObject2.setLastUpdateUser(getString (rs, 26)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 27)); 
      returnObject2.setXAddressVerificationDate(getTimestamp (rs, 43)); 
      returnObject2.setXSubcity(getLongObject (rs, 44)); 
      returnObject2.setXDistrict(getLongObject (rs, 45)); 
      returnObject2.setXBuildingName(getString (rs, 46)); 
      returnObject2.setXStreetNumber(getString (rs, 47)); 
      returnObject2.setXStreetName(getString (rs, 48)); 
      returnObject2.setXSuburb(getString (rs, 49)); 
      returnObject.add (returnObject2);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT ADDRESS.ADDRESS_ID, ADDRESS.RESIDENCE_TP_CD, ADDRESS.ADDR_LINE_ONE, ADDRESS.ADDR_LINE_TWO, ADDRESS.ADDR_LINE_THREE, ADDRESS.P_ADDR_LINE_ONE, ADDRESS.P_ADDR_LINE_TWO, ADDRESS.P_ADDR_LINE_THREE, ADDRESS.CITY_NAME, ADDRESS.POSTAL_CODE, ADDRESS.POSTAL_BARCODE ,ADDRESS.RESIDENCE_NUM, ADDRESS.PROV_STATE_TP_CD, ADDRESS.COUNTY_CODE, ADDRESS.COUNTRY_TP_CD, ADDRESS.ADDR_STANDARD_IND, ADDRESS.OVERRIDE_IND , ADDRESS.LATITUDE_DEGREES, ADDRESS.LONGITUDE_DEGREES, ADDRESS.LAST_UPDATE_DT, ADDRESS.LAST_UPDATE_USER, ADDRESS.LAST_UPDATE_TX_ID, ADDRESS.BUILDING_NAME, ADDRESS.STREET_NUMBER, ADDRESS.STREET_NAME, ADDRESS.STREET_SUFFIX, ADDRESS.STREET_PREFIX, ADDRESS.PRE_DIRECTIONAL, ADDRESS.POST_DIRECTIONAL, ADDRESS.BOX_DESIGNATOR, ADDRESS.BOX_ID, ADDRESS.STN_INFO, ADDRESS.STN_ID, ADDRESS.REGION, ADDRESS.DEL_DESIGNATOR, ADDRESS.DEL_ID, ADDRESS.DEL_INFO, ADDRESS.P_CITY, ADDRESS.P_STREET_NAME, ADDRESS.XADDR_VERIFICATION_DT, ADDRESS.XSUBCITY_TP_CD, ADDRESS.XDISTRICT_TP_CD, ADDRESS.XBUILDING_NAME, ADDRESS.XSTREET_NUMBER, ADDRESS.XSTREET_NAME, ADDRESS.XSuburb FROM ADDRESS WHERE (ADDRESS.ADDRESS_ID = ?)", pattern="tableAlias (ADDRESS => com.dwl.tcrm.coreParty.entityObject.EObjAddress, H_ADDRESS => com.dwl.tcrm.coreParty.entityObject.EObjAddress, addressgroup => com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup, locationgroup => com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup, contmacrorole => com.dwl.tcrm.coreParty.entityObject.EObjContMacroRole, macroroleassoc => com.dwl.tcrm.coreParty.entityObject.EObjMacroRoleAssoc , ADDRESS => com.ibm.daimler.dsea.entityObject.EObjXAddressExt , H_ADDRESS => com.ibm.daimler.dsea.entityObject.EObjXAddressExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue2<EObjAddress,EObjXAddressExt>> getAddress (Object[] parameters)
  {
    return queryIterator (getAddressStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getAddressStatementDescriptor = createStatementDescriptor (
    "getAddress(Object[])",
    "SELECT ADDRESS.ADDRESS_ID, ADDRESS.RESIDENCE_TP_CD, ADDRESS.ADDR_LINE_ONE, ADDRESS.ADDR_LINE_TWO, ADDRESS.ADDR_LINE_THREE, ADDRESS.P_ADDR_LINE_ONE, ADDRESS.P_ADDR_LINE_TWO, ADDRESS.P_ADDR_LINE_THREE, ADDRESS.CITY_NAME, ADDRESS.POSTAL_CODE, ADDRESS.POSTAL_BARCODE ,ADDRESS.RESIDENCE_NUM, ADDRESS.PROV_STATE_TP_CD, ADDRESS.COUNTY_CODE, ADDRESS.COUNTRY_TP_CD, ADDRESS.ADDR_STANDARD_IND, ADDRESS.OVERRIDE_IND , ADDRESS.LATITUDE_DEGREES, ADDRESS.LONGITUDE_DEGREES, ADDRESS.LAST_UPDATE_DT, ADDRESS.LAST_UPDATE_USER, ADDRESS.LAST_UPDATE_TX_ID, ADDRESS.BUILDING_NAME, ADDRESS.STREET_NUMBER, ADDRESS.STREET_NAME, ADDRESS.STREET_SUFFIX, ADDRESS.STREET_PREFIX, ADDRESS.PRE_DIRECTIONAL, ADDRESS.POST_DIRECTIONAL, ADDRESS.BOX_DESIGNATOR, ADDRESS.BOX_ID, ADDRESS.STN_INFO, ADDRESS.STN_ID, ADDRESS.REGION, ADDRESS.DEL_DESIGNATOR, ADDRESS.DEL_ID, ADDRESS.DEL_INFO, ADDRESS.P_CITY, ADDRESS.P_STREET_NAME, ADDRESS.XADDR_VERIFICATION_DT, ADDRESS.XSUBCITY_TP_CD, ADDRESS.XDISTRICT_TP_CD, ADDRESS.XBUILDING_NAME, ADDRESS.XSTREET_NUMBER, ADDRESS.XSTREET_NAME, ADDRESS.XSuburb FROM ADDRESS WHERE (ADDRESS.ADDRESS_ID = ?)",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"address_id", "residence_tp_cd", "addr_line_one", "addr_line_two", "addr_line_three", "p_addr_line_one", "p_addr_line_two", "p_addr_line_three", "city_name", "postal_code", "postal_barcode", "residence_num", "prov_state_tp_cd", "county_code", "country_tp_cd", "addr_standard_ind", "override_ind", "latitude_degrees", "longitude_degrees", "last_update_dt", "last_update_user", "last_update_tx_id", "building_name", "street_number", "street_name", "street_suffix", "street_prefix", "pre_directional", "post_directional", "box_designator", "box_id", "stn_info", "stn_id", "region", "del_designator", "del_id", "del_info", "p_city", "p_street_name", "xaddr_verification_dt", "xsubcity_tp_cd", "xdistrict_tp_cd", "xbuilding_name", "xstreet_number", "xstreet_name", "xsuburb"},
    new GetAddressParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetAddressRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.CHAR, Types.CHAR, Types.CHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.CHAR, Types.BIGINT, Types.CHAR, Types.CHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR}, {19, 19, 100, 100, 100, 8, 8, 8, 50, 20, 30, 10, 19, 3, 19, 1, 1, 10, 10, 0, 20, 19, 64, 16, 64, 16, 16, 16, 16, 16, 16, 16, 16, 32, 16, 16, 50, 20, 30, 0, 19, 19, 500, 500, 250, 255}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    2);

  /**
   * @generated
   */
  public static class GetAddressParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetAddressRowHandler extends BaseRowHandler<ResultQueue2<EObjAddress,EObjXAddressExt>>
  {
    /**
     * @generated
     */
    public ResultQueue2<EObjAddress,EObjXAddressExt> handle (java.sql.ResultSet rs, ResultQueue2<EObjAddress,EObjXAddressExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue2<EObjAddress,EObjXAddressExt> ();

      EObjAddress returnObject1 = new EObjAddress ();
      returnObject1.setAddressIdPK(getLongObject (rs, 1)); 
      returnObject1.setResidenceTpCd(getLongObject (rs, 2)); 
      returnObject1.setAddrLineOne(getString (rs, 3)); 
      returnObject1.setAddrLineTwo(getString (rs, 4)); 
      returnObject1.setAddrLineThree(getString (rs, 5)); 
      returnObject1.setPAddrLineOne(getString (rs, 6)); 
      returnObject1.setPAddrLineTwo(getString (rs, 7)); 
      returnObject1.setPAddrLineThree(getString (rs, 8)); 
      returnObject1.setCityName(getString (rs, 9)); 
      returnObject1.setPostalCode(getString (rs, 10)); 
      returnObject1.setPostalBarCode(getString (rs, 11)); 
      returnObject1.setResidenceNum(getString (rs, 12)); 
      returnObject1.setProvStateTpCd(getLongObject (rs, 13)); 
      returnObject1.setCountyCode(getString (rs, 14)); 
      returnObject1.setCountryTpCd(getLongObject (rs, 15)); 
      returnObject1.setAddrStandardInd(getString (rs, 16)); 
      returnObject1.setOverrideInd(getString (rs, 17)); 
      returnObject1.setLatitudeDegrees(getString (rs, 18)); 
      returnObject1.setLongtitudeDegrees(getString (rs, 19)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 20)); 
      returnObject1.setLastUpdateUser(getString (rs, 21)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 22)); 
      returnObject1.setBuildingName(getString (rs, 23)); 
      returnObject1.setStreetNumber(getString (rs, 24)); 
      returnObject1.setStreetName(getString (rs, 25)); 
      returnObject1.setStreetSuffix(getString (rs, 26)); 
      returnObject1.setStreetPrefix(getString (rs, 27)); 
      returnObject1.setPreDirectional(getString (rs, 28)); 
      returnObject1.setPostDirectional(getString (rs, 29)); 
      returnObject1.setBoxDesignator(getString (rs, 30)); 
      returnObject1.setBoxId(getString (rs, 31)); 
      returnObject1.setStnInfo(getString (rs, 32)); 
      returnObject1.setStnId(getString (rs, 33)); 
      returnObject1.setRegion(getString (rs, 34)); 
      returnObject1.setDelDesignator(getString (rs, 35)); 
      returnObject1.setDelId(getString (rs, 36)); 
      returnObject1.setDelInfo(getString (rs, 37)); 
      returnObject1.setPCityName(getString (rs, 38)); 
      returnObject1.setPStreetName(getString (rs, 39)); 
      returnObject.add (returnObject1);

      EObjXAddressExt returnObject2 = new EObjXAddressExt ();
      returnObject2.setLastUpdateDt(getTimestamp (rs, 20)); 
      returnObject2.setLastUpdateUser(getString (rs, 21)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 22)); 
      returnObject2.setXAddressVerificationDate(getTimestamp (rs, 40)); 
      returnObject2.setXSubcity(getLongObject (rs, 41)); 
      returnObject2.setXDistrict(getLongObject (rs, 42)); 
      returnObject2.setXBuildingName(getString (rs, 43)); 
      returnObject2.setXStreetNumber(getString (rs, 44)); 
      returnObject2.setXStreetName(getString (rs, 45)); 
      returnObject2.setXSuburb(getString (rs, 46)); 
      returnObject.add (returnObject2);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT ADDRESS.ADDRESS_ID, ADDRESS.RESIDENCE_TP_CD, ADDRESS.ADDR_LINE_ONE, ADDRESS.ADDR_LINE_TWO, ADDRESS.ADDR_LINE_THREE, ADDRESS.P_ADDR_LINE_ONE, ADDRESS.P_ADDR_LINE_TWO, ADDRESS.P_ADDR_LINE_THREE, ADDRESS.CITY_NAME, ADDRESS.POSTAL_CODE, ADDRESS.POSTAL_BARCODE ,ADDRESS.RESIDENCE_NUM, ADDRESS.PROV_STATE_TP_CD, ADDRESS.COUNTY_CODE, ADDRESS.COUNTRY_TP_CD, ADDRESS.ADDR_STANDARD_IND, ADDRESS.OVERRIDE_IND , ADDRESS.LATITUDE_DEGREES, ADDRESS.LONGITUDE_DEGREES, ADDRESS.LAST_UPDATE_DT, ADDRESS.LAST_UPDATE_USER, ADDRESS.LAST_UPDATE_TX_ID, ADDRESS.BUILDING_NAME, ADDRESS.STREET_NUMBER, ADDRESS.STREET_NAME, ADDRESS.STREET_SUFFIX, ADDRESS.STREET_PREFIX, ADDRESS.PRE_DIRECTIONAL, ADDRESS.POST_DIRECTIONAL, ADDRESS.BOX_DESIGNATOR, ADDRESS.BOX_ID, ADDRESS.STN_INFO, ADDRESS.STN_ID, ADDRESS.REGION, ADDRESS.DEL_DESIGNATOR, ADDRESS.DEL_ID, ADDRESS.DEL_INFO, ADDRESS.XADDR_VERIFICATION_DT, ADDRESS.XSUBCITY_TP_CD, ADDRESS.XDISTRICT_TP_CD, ADDRESS.XBUILDING_NAME, ADDRESS.XSTREET_NUMBER, ADDRESS.XSTREET_NAME, ADDRESS.XSuburb FROM ADDRESS, ADDRESSGROUP A, LOCATIONGROUP B, CONTMACROROLE C, MACROROLEASSOC D WHERE ADDRESS.ADDRESS_ID = A.ADDRESS_ID AND A.LOCATION_GROUP_ID = B.LOCATION_GROUP_ID AND B.CONT_ID = C.CONT_ID AND C.CONT_MACRO_ROLE_ID = D.CONT_MACRO_ROLE_ID AND UPPER(D.ENTITY_NAME) = 'ADDRESSGROUP' AND A.LOCATION_GROUP_ID = D.INSTANCE_PK AND B.CONT_ID = ? AND A.ADDR_USAGE_TP_CD = ? AND C.ROLE_TP_CD = ? AND (B.END_DT IS NULL OR B.END_DT > ?)", pattern="tableAlias (ADDRESS => com.dwl.tcrm.coreParty.entityObject.EObjAddress, H_ADDRESS => com.dwl.tcrm.coreParty.entityObject.EObjAddress, addressgroup => com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup, locationgroup => com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup, contmacrorole => com.dwl.tcrm.coreParty.entityObject.EObjContMacroRole, macroroleassoc => com.dwl.tcrm.coreParty.entityObject.EObjMacroRoleAssoc , ADDRESS => com.ibm.daimler.dsea.entityObject.EObjXAddressExt , H_ADDRESS => com.ibm.daimler.dsea.entityObject.EObjXAddressExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue2<EObjAddress,EObjXAddressExt>> getAddressGroupMicro (Object[] parameters)
  {
    return queryIterator (getAddressGroupMicroStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getAddressGroupMicroStatementDescriptor = createStatementDescriptor (
    "getAddressGroupMicro(Object[])",
    "SELECT ADDRESS.ADDRESS_ID, ADDRESS.RESIDENCE_TP_CD, ADDRESS.ADDR_LINE_ONE, ADDRESS.ADDR_LINE_TWO, ADDRESS.ADDR_LINE_THREE, ADDRESS.P_ADDR_LINE_ONE, ADDRESS.P_ADDR_LINE_TWO, ADDRESS.P_ADDR_LINE_THREE, ADDRESS.CITY_NAME, ADDRESS.POSTAL_CODE, ADDRESS.POSTAL_BARCODE ,ADDRESS.RESIDENCE_NUM, ADDRESS.PROV_STATE_TP_CD, ADDRESS.COUNTY_CODE, ADDRESS.COUNTRY_TP_CD, ADDRESS.ADDR_STANDARD_IND, ADDRESS.OVERRIDE_IND , ADDRESS.LATITUDE_DEGREES, ADDRESS.LONGITUDE_DEGREES, ADDRESS.LAST_UPDATE_DT, ADDRESS.LAST_UPDATE_USER, ADDRESS.LAST_UPDATE_TX_ID, ADDRESS.BUILDING_NAME, ADDRESS.STREET_NUMBER, ADDRESS.STREET_NAME, ADDRESS.STREET_SUFFIX, ADDRESS.STREET_PREFIX, ADDRESS.PRE_DIRECTIONAL, ADDRESS.POST_DIRECTIONAL, ADDRESS.BOX_DESIGNATOR, ADDRESS.BOX_ID, ADDRESS.STN_INFO, ADDRESS.STN_ID, ADDRESS.REGION, ADDRESS.DEL_DESIGNATOR, ADDRESS.DEL_ID, ADDRESS.DEL_INFO, ADDRESS.XADDR_VERIFICATION_DT, ADDRESS.XSUBCITY_TP_CD, ADDRESS.XDISTRICT_TP_CD, ADDRESS.XBUILDING_NAME, ADDRESS.XSTREET_NUMBER, ADDRESS.XSTREET_NAME, ADDRESS.XSuburb FROM ADDRESS, ADDRESSGROUP A, LOCATIONGROUP B, CONTMACROROLE C, MACROROLEASSOC D WHERE ADDRESS.ADDRESS_ID = A.ADDRESS_ID AND A.LOCATION_GROUP_ID = B.LOCATION_GROUP_ID AND B.CONT_ID = C.CONT_ID AND C.CONT_MACRO_ROLE_ID = D.CONT_MACRO_ROLE_ID AND UPPER(D.ENTITY_NAME) = 'ADDRESSGROUP' AND A.LOCATION_GROUP_ID = D.INSTANCE_PK AND B.CONT_ID = ? AND A.ADDR_USAGE_TP_CD = ? AND C.ROLE_TP_CD = ? AND (B.END_DT IS NULL OR B.END_DT > ?)",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"address_id", "residence_tp_cd", "addr_line_one", "addr_line_two", "addr_line_three", "p_addr_line_one", "p_addr_line_two", "p_addr_line_three", "city_name", "postal_code", "postal_barcode", "residence_num", "prov_state_tp_cd", "county_code", "country_tp_cd", "addr_standard_ind", "override_ind", "latitude_degrees", "longitude_degrees", "last_update_dt", "last_update_user", "last_update_tx_id", "building_name", "street_number", "street_name", "street_suffix", "street_prefix", "pre_directional", "post_directional", "box_designator", "box_id", "stn_info", "stn_id", "region", "del_designator", "del_id", "del_info", "xaddr_verification_dt", "xsubcity_tp_cd", "xdistrict_tp_cd", "xbuilding_name", "xstreet_number", "xstreet_name", "xsuburb"},
    new GetAddressGroupMicroParameterHandler (),
    new int[][]{{Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP}, {19, 19, 19, 0}, {0, 0, 0, 0}, {1, 1, 1, 1}},
    null,
    new GetAddressGroupMicroRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.CHAR, Types.CHAR, Types.CHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.CHAR, Types.BIGINT, Types.CHAR, Types.CHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR}, {19, 19, 100, 100, 100, 8, 8, 8, 50, 20, 30, 10, 19, 3, 19, 1, 1, 10, 10, 0, 20, 19, 64, 16, 64, 16, 16, 16, 16, 16, 16, 16, 16, 32, 16, 16, 50, 0, 19, 19, 500, 500, 250, 255}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    3);

  /**
   * @generated
   */
  public static class GetAddressGroupMicroParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.BIGINT, parameters[1], 0);
      setObject (stmt, 3, Types.BIGINT, parameters[2], 0);
      setObject (stmt, 4, Types.TIMESTAMP, parameters[3], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetAddressGroupMicroRowHandler extends BaseRowHandler<ResultQueue2<EObjAddress,EObjXAddressExt>>
  {
    /**
     * @generated
     */
    public ResultQueue2<EObjAddress,EObjXAddressExt> handle (java.sql.ResultSet rs, ResultQueue2<EObjAddress,EObjXAddressExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue2<EObjAddress,EObjXAddressExt> ();

      EObjAddress returnObject1 = new EObjAddress ();
      returnObject1.setAddressIdPK(getLongObject (rs, 1)); 
      returnObject1.setResidenceTpCd(getLongObject (rs, 2)); 
      returnObject1.setAddrLineOne(getString (rs, 3)); 
      returnObject1.setAddrLineTwo(getString (rs, 4)); 
      returnObject1.setAddrLineThree(getString (rs, 5)); 
      returnObject1.setPAddrLineOne(getString (rs, 6)); 
      returnObject1.setPAddrLineTwo(getString (rs, 7)); 
      returnObject1.setPAddrLineThree(getString (rs, 8)); 
      returnObject1.setCityName(getString (rs, 9)); 
      returnObject1.setPostalCode(getString (rs, 10)); 
      returnObject1.setPostalBarCode(getString (rs, 11)); 
      returnObject1.setResidenceNum(getString (rs, 12)); 
      returnObject1.setProvStateTpCd(getLongObject (rs, 13)); 
      returnObject1.setCountyCode(getString (rs, 14)); 
      returnObject1.setCountryTpCd(getLongObject (rs, 15)); 
      returnObject1.setAddrStandardInd(getString (rs, 16)); 
      returnObject1.setOverrideInd(getString (rs, 17)); 
      returnObject1.setLatitudeDegrees(getString (rs, 18)); 
      returnObject1.setLongtitudeDegrees(getString (rs, 19)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 20)); 
      returnObject1.setLastUpdateUser(getString (rs, 21)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 22)); 
      returnObject1.setBuildingName(getString (rs, 23)); 
      returnObject1.setStreetNumber(getString (rs, 24)); 
      returnObject1.setStreetName(getString (rs, 25)); 
      returnObject1.setStreetSuffix(getString (rs, 26)); 
      returnObject1.setStreetPrefix(getString (rs, 27)); 
      returnObject1.setPreDirectional(getString (rs, 28)); 
      returnObject1.setPostDirectional(getString (rs, 29)); 
      returnObject1.setBoxDesignator(getString (rs, 30)); 
      returnObject1.setBoxId(getString (rs, 31)); 
      returnObject1.setStnInfo(getString (rs, 32)); 
      returnObject1.setStnId(getString (rs, 33)); 
      returnObject1.setRegion(getString (rs, 34)); 
      returnObject1.setDelDesignator(getString (rs, 35)); 
      returnObject1.setDelId(getString (rs, 36)); 
      returnObject1.setDelInfo(getString (rs, 37)); 
      returnObject.add (returnObject1);

      EObjXAddressExt returnObject2 = new EObjXAddressExt ();
      returnObject2.setLastUpdateDt(getTimestamp (rs, 20)); 
      returnObject2.setLastUpdateUser(getString (rs, 21)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 22)); 
      returnObject2.setXAddressVerificationDate(getTimestamp (rs, 38)); 
      returnObject2.setXSubcity(getLongObject (rs, 39)); 
      returnObject2.setXDistrict(getLongObject (rs, 40)); 
      returnObject2.setXBuildingName(getString (rs, 41)); 
      returnObject2.setXStreetNumber(getString (rs, 42)); 
      returnObject2.setXStreetName(getString (rs, 43)); 
      returnObject2.setXSuburb(getString (rs, 44)); 
      returnObject.add (returnObject2);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT DISTINCT A.ADDRESS_ID, A.LAST_UPDATE_DT, A.XADDR_VERIFICATION_DT, A.XSUBCITY_TP_CD, A.XDISTRICT_TP_CD, A.XBUILDING_NAME, A.XSTREET_NUMBER, A.XSTREET_NAME, A.XSuburb FROM H_ADDRESS A WHERE A.ADDRESS_ID = ? AND ( A.H_CREATE_DT BETWEEN ? AND ? )", pattern="tableAlias (ADDRESS => com.dwl.tcrm.coreParty.entityObject.EObjAddress, H_ADDRESS => com.dwl.tcrm.coreParty.entityObject.EObjAddress, addressgroup => com.dwl.tcrm.coreParty.entityObject.EObjAddressGroup, locationgroup => com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup, contmacrorole => com.dwl.tcrm.coreParty.entityObject.EObjContMacroRole, macroroleassoc => com.dwl.tcrm.coreParty.entityObject.EObjMacroRoleAssoc , ADDRESS => com.ibm.daimler.dsea.entityObject.EObjXAddressExt , H_ADDRESS => com.ibm.daimler.dsea.entityObject.EObjXAddressExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue2<EObjAddress,EObjXAddressExt>> getAddressLightImages (Object[] parameters)
  {
    return queryIterator (getAddressLightImagesStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getAddressLightImagesStatementDescriptor = createStatementDescriptor (
    "getAddressLightImages(Object[])",
    "SELECT DISTINCT A.ADDRESS_ID, A.LAST_UPDATE_DT, A.XADDR_VERIFICATION_DT, A.XSUBCITY_TP_CD, A.XDISTRICT_TP_CD, A.XBUILDING_NAME, A.XSTREET_NUMBER, A.XSTREET_NAME, A.XSuburb FROM H_ADDRESS A WHERE A.ADDRESS_ID = ? AND ( A.H_CREATE_DT BETWEEN ? AND ? )",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"address_id", "last_update_dt", "xaddr_verification_dt", "xsubcity_tp_cd", "xdistrict_tp_cd", "xbuilding_name", "xstreet_number", "xstreet_name", "xsuburb"},
    new GetAddressLightImagesParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP}, {19, 0, 0}, {0, 0, 0}, {1, 1, 1}},
    null,
    new GetAddressLightImagesRowHandler (),
    new int[][]{ {Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR}, {19, 0, 0, 19, 19, 500, 500, 250, 255}, {0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    4);

  /**
   * @generated
   */
  public static class GetAddressLightImagesParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetAddressLightImagesRowHandler extends BaseRowHandler<ResultQueue2<EObjAddress,EObjXAddressExt>>
  {
    /**
     * @generated
     */
    public ResultQueue2<EObjAddress,EObjXAddressExt> handle (java.sql.ResultSet rs, ResultQueue2<EObjAddress,EObjXAddressExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue2<EObjAddress,EObjXAddressExt> ();

      EObjAddress returnObject1 = new EObjAddress ();
      returnObject1.setAddressIdPK(getLongObject (rs, 1)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 2)); 
      returnObject.add (returnObject1);

      EObjXAddressExt returnObject2 = new EObjXAddressExt ();
      returnObject2.setLastUpdateDt(getTimestamp (rs, 2)); 
      returnObject2.setXAddressVerificationDate(getTimestamp (rs, 3)); 
      returnObject2.setXSubcity(getLongObject (rs, 4)); 
      returnObject2.setXDistrict(getLongObject (rs, 5)); 
      returnObject2.setXBuildingName(getString (rs, 6)); 
      returnObject2.setXStreetNumber(getString (rs, 7)); 
      returnObject2.setXStreetName(getString (rs, 8)); 
      returnObject2.setXSuburb(getString (rs, 9)); 
      returnObject.add (returnObject2);

    
      return returnObject;
    }
  }

}
