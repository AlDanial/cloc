package com.ibm.daimler.dsea.entityObject;

import com.ibm.pdq.runtime.generator.BaseParameterHandler;
import com.ibm.daimler.dsea.entityObject.EObjXVehicleKOR;
import java.util.Iterator;
import java.sql.PreparedStatement;
import com.ibm.pdq.runtime.statement.StatementDescriptor;
import com.ibm.pdq.runtime.generator.BaseData;
import java.sql.SQLException;
import com.ibm.pdq.annotation.Metadata;
import com.ibm.pdq.runtime.generator.BaseRowHandler;
import com.ibm.pdq.runtime.statement.SqlStatementType;
import java.sql.Types;


/**
 * <!-- begin-user-doc -->
 * 
 * <!-- end-user-doc -->
 * 
 * @generated
 */
public class EObjXVehicleKORDataImpl  extends BaseData implements EObjXVehicleKORData
{

  /**
   * @generated
   */
  public static final String generatorVersion = "3.200.75";

  /**
   * @generated
   */
  public static final String identifier = "EObjXVehicleKORData";

  /**
   * @generated
   */
  public static final long generationTime = 0x00000166f7ce1a97L;

  /**
   * @generated
   */
  public static final String collection = "NULLID";

  /**
   * @generated
   */
  public static final String packageVersion = null;

  /**
   * @generated
   */
  public static final boolean forceSingleBindIsolation = false;

  /**
   * @generated
   */
  public EObjXVehicleKORDataImpl()
  {
    super();
  } 

  /**
   * @generated
   */
  public String getGeneratorVersion()
  {
    return generatorVersion;
  }

  /**
   * @Select( sql="select XVehicle_KORpk_Id, Global_VIN, BAU_MUSTER, TYPE_CLASS, SUB_MUSTER, COLOR, TRIM, BATCH_IND, MARKET_NAME, MODIFY_SYS_DT, CREATE_DT, CHANGED_DT, LAST_SERVICE_DT, SFDC_ID, VEHICLE_ADDRESS_TYPE, VEHICLE_TYPE, DELETE_FLAG, END_DT, ENGINE_NUM, SOURCE_IDENT_TP_CD, Local_VIN, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from XVEHICLEKOR where XVehicle_KORpk_Id = ? " )
   * 
   * @generated
   */
  public Iterator<EObjXVehicleKOR> getEObjXVehicleKOR (Long xVehicleKORpkId)
  {
    return queryIterator (getEObjXVehicleKORStatementDescriptor, xVehicleKORpkId);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getEObjXVehicleKORStatementDescriptor = createStatementDescriptor (
    "getEObjXVehicleKOR(Long)",
    "select XVehicle_KORpk_Id, Global_VIN, BAU_MUSTER, TYPE_CLASS, SUB_MUSTER, COLOR, TRIM, BATCH_IND, MARKET_NAME, MODIFY_SYS_DT, CREATE_DT, CHANGED_DT, LAST_SERVICE_DT, SFDC_ID, VEHICLE_ADDRESS_TYPE, VEHICLE_TYPE, DELETE_FLAG, END_DT, ENGINE_NUM, SOURCE_IDENT_TP_CD, Local_VIN, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from XVEHICLEKOR where XVehicle_KORpk_Id = ? ",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"xvehicle_korpk_id", "global_vin", "bau_muster", "type_class", "sub_muster", "color", "trim", "batch_ind", "market_name", "modify_sys_dt", "create_dt", "changed_dt", "last_service_dt", "sfdc_id", "vehicle_address_type", "vehicle_type", "delete_flag", "end_dt", "engine_num", "source_ident_tp_cd", "local_vin", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetEObjXVehicleKORParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetEObjXVehicleKORRowHandler (),
    new int[][]{ {Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 50, 20, 255, 255, 255, 255, 5, 50, 0, 0, 0, 0, 50, 255, 50, 10, 0, 20, 19, 50, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    1);

  /**
   * @generated
   */
  public static class GetEObjXVehicleKORParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setLong (stmt, 1, Types.BIGINT, (Long)parameters[0]);
    }
  }

  /**
   * @generated
   */
  public static class GetEObjXVehicleKORRowHandler extends BaseRowHandler<EObjXVehicleKOR>
  {
    /**
     * @generated
     */
    public EObjXVehicleKOR handle (java.sql.ResultSet rs, EObjXVehicleKOR returnObject) throws java.sql.SQLException
    {
      returnObject = new EObjXVehicleKOR ();
      returnObject.setXVehicleKORpkId(getLongObject (rs, 1)); 
      returnObject.setGlobalVIN(getString (rs, 2)); 
      returnObject.setBauMuster(getString (rs, 3)); 
      returnObject.setTypeClass(getString (rs, 4)); 
      returnObject.setSubMuster(getString (rs, 5)); 
      returnObject.setColor(getString (rs, 6)); 
      returnObject.setTrim(getString (rs, 7)); 
      returnObject.setBatchInd(getString (rs, 8)); 
      returnObject.setMarketName(getString (rs, 9)); 
      returnObject.setLastModifiedSystemDate(getTimestamp (rs, 10)); 
      returnObject.setCreateDate(getTimestamp (rs, 11)); 
      returnObject.setChangedDate(getTimestamp (rs, 12)); 
      returnObject.setLastServiceDate(getTimestamp (rs, 13)); 
      returnObject.setSFDCId(getString (rs, 14)); 
      returnObject.setVehicleAddressType(getString (rs, 15)); 
      returnObject.setVehicleType(getString (rs, 16)); 
      returnObject.setDeleteFlag(getString (rs, 17)); 
      returnObject.setEndDate(getTimestamp (rs, 18)); 
      returnObject.setEngineNumber(getString (rs, 19)); 
      returnObject.setSourceIdentifier(getLongObject (rs, 20)); 
      returnObject.setLocalVIN(getString (rs, 21)); 
      returnObject.setLastUpdateDt(getTimestamp (rs, 22)); 
      returnObject.setLastUpdateUser(getString (rs, 23)); 
      returnObject.setLastUpdateTxId(getLongObject (rs, 24)); 
    
      return returnObject;
    }
  }

  /**
   * @Update( sql="insert into XVEHICLEKOR (XVehicle_KORpk_Id, Global_VIN, BAU_MUSTER, TYPE_CLASS, SUB_MUSTER, COLOR, TRIM, BATCH_IND, MARKET_NAME, MODIFY_SYS_DT, CREATE_DT, CHANGED_DT, LAST_SERVICE_DT, SFDC_ID, VEHICLE_ADDRESS_TYPE, VEHICLE_TYPE, DELETE_FLAG, END_DT, ENGINE_NUM, SOURCE_IDENT_TP_CD, Local_VIN, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( :xVehicleKORpkId, :globalVIN, :bauMuster, :typeClass, :subMuster, :color, :trim, :batchInd, :marketName, :lastModifiedSystemDate, :createDate, :changedDate, :lastServiceDate, :sFDCId, :vehicleAddressType, :vehicleType, :deleteFlag, :endDate, :engineNumber, :sourceIdentifier, :localVIN, :lastUpdateDt, :lastUpdateUser, :lastUpdateTxId)" )
   * 
   * @generated
   */
  public int createEObjXVehicleKOR (EObjXVehicleKOR e)
  {
    return update (createEObjXVehicleKORStatementDescriptor, e);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor createEObjXVehicleKORStatementDescriptor = createStatementDescriptor (
    "createEObjXVehicleKOR(com.ibm.daimler.dsea.entityObject.EObjXVehicleKOR)",
    "insert into XVEHICLEKOR (XVehicle_KORpk_Id, Global_VIN, BAU_MUSTER, TYPE_CLASS, SUB_MUSTER, COLOR, TRIM, BATCH_IND, MARKET_NAME, MODIFY_SYS_DT, CREATE_DT, CHANGED_DT, LAST_SERVICE_DT, SFDC_ID, VEHICLE_ADDRESS_TYPE, VEHICLE_TYPE, DELETE_FLAG, END_DT, ENGINE_NUM, SOURCE_IDENT_TP_CD, Local_VIN, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values(  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? )",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.INSERT,
    null,
    new CreateEObjXVehicleKORParameterHandler (),
    new int[][]{{Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 50, 20, 255, 255, 255, 255, 5, 50, 0, 0, 0, 0, 50, 255, 50, 10, 0, 20, 19, 50, 0, 0, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    2);

  /**
   * @generated
   */
  public static class CreateEObjXVehicleKORParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      EObjXVehicleKOR bean0 = (EObjXVehicleKOR) parameters[0];
      setLong (stmt, 1, Types.BIGINT, (Long)bean0.getXVehicleKORpkId());
      setString (stmt, 2, Types.VARCHAR, (String)bean0.getGlobalVIN());
      setString (stmt, 3, Types.VARCHAR, (String)bean0.getBauMuster());
      setString (stmt, 4, Types.VARCHAR, (String)bean0.getTypeClass());
      setString (stmt, 5, Types.VARCHAR, (String)bean0.getSubMuster());
      setString (stmt, 6, Types.VARCHAR, (String)bean0.getColor());
      setString (stmt, 7, Types.VARCHAR, (String)bean0.getTrim());
      setString (stmt, 8, Types.VARCHAR, (String)bean0.getBatchInd());
      setString (stmt, 9, Types.VARCHAR, (String)bean0.getMarketName());
      setTimestamp (stmt, 10, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastModifiedSystemDate());
      setTimestamp (stmt, 11, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getCreateDate());
      setTimestamp (stmt, 12, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getChangedDate());
      setTimestamp (stmt, 13, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastServiceDate());
      setString (stmt, 14, Types.VARCHAR, (String)bean0.getSFDCId());
      setString (stmt, 15, Types.VARCHAR, (String)bean0.getVehicleAddressType());
      setString (stmt, 16, Types.VARCHAR, (String)bean0.getVehicleType());
      setString (stmt, 17, Types.VARCHAR, (String)bean0.getDeleteFlag());
      setTimestamp (stmt, 18, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getEndDate());
      setString (stmt, 19, Types.VARCHAR, (String)bean0.getEngineNumber());
      setLong (stmt, 20, Types.BIGINT, (Long)bean0.getSourceIdentifier());
      setString (stmt, 21, Types.VARCHAR, (String)bean0.getLocalVIN());
      setTimestamp (stmt, 22, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUpdateDt());
      setString (stmt, 23, Types.VARCHAR, (String)bean0.getLastUpdateUser());
      setLong (stmt, 24, Types.BIGINT, (Long)bean0.getLastUpdateTxId());
    }
  }

  /**
   * @Update( sql="update XVEHICLEKOR set Global_VIN = :globalVIN, BAU_MUSTER = :bauMuster, TYPE_CLASS = :typeClass, SUB_MUSTER = :subMuster, COLOR = :color, TRIM = :trim, BATCH_IND = :batchInd, MARKET_NAME = :marketName, MODIFY_SYS_DT = :lastModifiedSystemDate, CREATE_DT = :createDate, CHANGED_DT = :changedDate, LAST_SERVICE_DT = :lastServiceDate, SFDC_ID = :sFDCId, VEHICLE_ADDRESS_TYPE = :vehicleAddressType, VEHICLE_TYPE = :vehicleType, DELETE_FLAG = :deleteFlag, END_DT = :endDate, ENGINE_NUM = :engineNumber, SOURCE_IDENT_TP_CD = :sourceIdentifier, Local_VIN = :localVIN, LAST_UPDATE_DT = :lastUpdateDt, LAST_UPDATE_USER = :lastUpdateUser, LAST_UPDATE_TX_ID = :lastUpdateTxId where XVehicle_KORpk_Id = :xVehicleKORpkId and LAST_UPDATE_DT = :oldLastUpdateDt" )
   * 
   * @generated
   */
  public int updateEObjXVehicleKOR (EObjXVehicleKOR e)
  {
    return update (updateEObjXVehicleKORStatementDescriptor, e);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor updateEObjXVehicleKORStatementDescriptor = createStatementDescriptor (
    "updateEObjXVehicleKOR(com.ibm.daimler.dsea.entityObject.EObjXVehicleKOR)",
    "update XVEHICLEKOR set Global_VIN =  ? , BAU_MUSTER =  ? , TYPE_CLASS =  ? , SUB_MUSTER =  ? , COLOR =  ? , TRIM =  ? , BATCH_IND =  ? , MARKET_NAME =  ? , MODIFY_SYS_DT =  ? , CREATE_DT =  ? , CHANGED_DT =  ? , LAST_SERVICE_DT =  ? , SFDC_ID =  ? , VEHICLE_ADDRESS_TYPE =  ? , VEHICLE_TYPE =  ? , DELETE_FLAG =  ? , END_DT =  ? , ENGINE_NUM =  ? , SOURCE_IDENT_TP_CD =  ? , Local_VIN =  ? , LAST_UPDATE_DT =  ? , LAST_UPDATE_USER =  ? , LAST_UPDATE_TX_ID =  ?  where XVehicle_KORpk_Id =  ?  and LAST_UPDATE_DT =  ? ",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.UPDATE,
    null,
    new UpdateEObjXVehicleKORParameterHandler (),
    new int[][]{{Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP}, {50, 20, 255, 255, 255, 255, 5, 50, 0, 0, 0, 0, 50, 255, 50, 10, 0, 20, 19, 50, 0, 0, 19, 19, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    3);

  /**
   * @generated
   */
  public static class UpdateEObjXVehicleKORParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      EObjXVehicleKOR bean0 = (EObjXVehicleKOR) parameters[0];
      setString (stmt, 1, Types.VARCHAR, (String)bean0.getGlobalVIN());
      setString (stmt, 2, Types.VARCHAR, (String)bean0.getBauMuster());
      setString (stmt, 3, Types.VARCHAR, (String)bean0.getTypeClass());
      setString (stmt, 4, Types.VARCHAR, (String)bean0.getSubMuster());
      setString (stmt, 5, Types.VARCHAR, (String)bean0.getColor());
      setString (stmt, 6, Types.VARCHAR, (String)bean0.getTrim());
      setString (stmt, 7, Types.VARCHAR, (String)bean0.getBatchInd());
      setString (stmt, 8, Types.VARCHAR, (String)bean0.getMarketName());
      setTimestamp (stmt, 9, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastModifiedSystemDate());
      setTimestamp (stmt, 10, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getCreateDate());
      setTimestamp (stmt, 11, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getChangedDate());
      setTimestamp (stmt, 12, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastServiceDate());
      setString (stmt, 13, Types.VARCHAR, (String)bean0.getSFDCId());
      setString (stmt, 14, Types.VARCHAR, (String)bean0.getVehicleAddressType());
      setString (stmt, 15, Types.VARCHAR, (String)bean0.getVehicleType());
      setString (stmt, 16, Types.VARCHAR, (String)bean0.getDeleteFlag());
      setTimestamp (stmt, 17, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getEndDate());
      setString (stmt, 18, Types.VARCHAR, (String)bean0.getEngineNumber());
      setLong (stmt, 19, Types.BIGINT, (Long)bean0.getSourceIdentifier());
      setString (stmt, 20, Types.VARCHAR, (String)bean0.getLocalVIN());
      setTimestamp (stmt, 21, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUpdateDt());
      setString (stmt, 22, Types.VARCHAR, (String)bean0.getLastUpdateUser());
      setLong (stmt, 23, Types.BIGINT, (Long)bean0.getLastUpdateTxId());
      setLong (stmt, 24, Types.BIGINT, (Long)bean0.getXVehicleKORpkId());
      setTimestamp (stmt, 25, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getOldLastUpdateDt());
    }
  }

  /**
   * @Update( sql="delete from XVEHICLEKOR where XVehicle_KORpk_Id = ?" )
   * 
   * @generated
   */
  public int deleteEObjXVehicleKOR (Long xVehicleKORpkId)
  {
    return update (deleteEObjXVehicleKORStatementDescriptor, xVehicleKORpkId);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor deleteEObjXVehicleKORStatementDescriptor = createStatementDescriptor (
    "deleteEObjXVehicleKOR(Long)",
    "delete from XVEHICLEKOR where XVehicle_KORpk_Id = ?",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.DELETE,
    null,
    new DeleteEObjXVehicleKORParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    4);

  /**
   * @generated
   */
  public static class DeleteEObjXVehicleKORParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setLong (stmt, 1, Types.BIGINT, (Long)parameters[0]);
    }
  }

}
