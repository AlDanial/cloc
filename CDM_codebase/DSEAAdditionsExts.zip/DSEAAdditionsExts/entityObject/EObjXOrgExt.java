/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[9ffa3fa7c0e73c89fec2c125d40b943b]
 */

package com.ibm.daimler.dsea.entityObject;

import com.dwl.base.EObjCommon;
import com.ibm.mdm.base.db.DataType;
import com.ibm.pdq.annotation.Column;
import com.ibm.pdq.annotation.Table;
import java.sql.Timestamp;



/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * The entity object corresponding to the XOrg business object. This entity
 * object should include all the attributes as defined by the business object.
 * 
 * @generated
 */
@SuppressWarnings("serial")
@Table(name=EObjXOrgExt.tableName)
public class EObjXOrgExt extends EObjCommon {

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public static final String tableName = "ORG";
    
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String xDefunctIndColumn = "XDEFUNCT_IND";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String xDefunctIndJdbcType = "VARCHAR";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    xDefunctIndPrecision = 5;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String xWebsiteColumn = "XWEBSITE";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String xWebsiteJdbcType = "VARCHAR";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    xWebsitePrecision = 255;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String xMarketNameColumn = "XMARKET_NAME";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String xMarketNameJdbcType = "VARCHAR";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    xMarketNamePrecision = 50;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String xBatchIndColumn = "XBATCH_IND";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String xBatchIndJdbcType = "VARCHAR";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    xBatchIndPrecision = 5;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String xNumberOfEmployeesColumn = "XNUMOFEMP_TP_CD";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String xNumberOfEmployeesJdbcType = "BIGINT";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    xNumberOfEmployeesPrecision = 19;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String xSourceTypeFlagColumn = "XSOURCE_TYPE_FLAG";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String xSourceTypeFlagJdbcType = "VARCHAR";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    xSourceTypeFlagPrecision = 50;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String xGenerated_byColumn = "XGENERATED_BY";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String xGenerated_byJdbcType = "VARCHAR";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    xGenerated_byPrecision = 50;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String xCorporateCategoryColumn = "XCORP_CAT_TP_CD";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String xCorporateCategoryJdbcType = "BIGINT";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    xCorporateCategoryPrecision = 19;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String xCorporateGroupColumn = "XCORP_GROUP_TP_CD";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String xCorporateGroupJdbcType = "BIGINT";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    xCorporateGroupPrecision = 19;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String xPersonalAgreementColumn = "XPERSONAL_AGREEMENT";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String xPersonalAgreementJdbcType = "VARCHAR";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    xPersonalAgreementPrecision = 20;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String xDoNotMergeFlagColumn = "XDO_NOT_MERGE_FLAG";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String xDoNotMergeFlagJdbcType = "VARCHAR";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    xDoNotMergeFlagPrecision = 5;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String deleteFlagColumn = "DELETE_FLAG";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String deleteFlagJdbcType = "VARCHAR";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    deleteFlagPrecision = 10;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String infoRemoveFlagColumn = "INFO_REMOVE_FLAG";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String infoRemoveFlagJdbcType = "VARCHAR";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    infoRemoveFlagPrecision = 10;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String dedupHiddenFlagColumn = "DEDUP_HIDDEN_FLAG";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String dedupHiddenFlagJdbcType = "VARCHAR";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    dedupHiddenFlagPrecision = 10;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String prefCommunicationChannelColumn = "PREF_COMMUNICATION_CHANNEL";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String prefCommunicationChannelJdbcType = "VARCHAR";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    prefCommunicationChannelPrecision = 255;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String yanaseFlagColumn = "YANASE_FLAG";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String yanaseFlagJdbcType = "VARCHAR";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    yanaseFlagPrecision = 10;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String financePartyTypeColumn = "FINANCE_PARTY_TYPE";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String financePartyTypeJdbcType = "VARCHAR";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    financePartyTypePrecision = 10;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String contractNumberColumn = "CONTRACT_NUMBER";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String contractNumberJdbcType = "VARCHAR";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    contractNumberPrecision = 250;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String xPrivacyActColumn = "XPRIVACY_ACT";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String xPrivacyActJdbcType = "VARCHAR";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    xPrivacyActPrecision = 250;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String xFleetColumn = "XFLEET";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String xFleetJdbcType = "VARCHAR";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    xFleetPrecision = 5;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String lastActivityDateColumn = "LAST_ACTIVITY_DATE";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String lastActivityDateJdbcType = "TIMESTAMP";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String x_CUST_TYPEColumn = "X_CUST_TYPE";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String x_CUST_TYPEJdbcType = "VARCHAR";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    x_CUST_TYPEPrecision = 10;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String xPC_IndColumn = "XPC_IND";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String xPC_IndJdbcType = "VARCHAR";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    xPC_IndPrecision = 10;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String xVANS_IndColumn = "XVANS_IND";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String xVANS_IndJdbcType = "VARCHAR";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    xVANS_IndPrecision = 10;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String xLastModifiedSystemDateColumn = "XMODIFY_SYS_DT";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String xLastModifiedSystemDateJdbcType = "TIMESTAMP";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected Long contIdPK;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String xDefunctInd;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String xWebsite;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String xMarketName;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String xBatchInd;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected Long xNumberOfEmployees;


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String xSourceTypeFlag;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String xGenerated_by;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected Long xCorporateCategory;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected Long xCorporateGroup;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String xPersonalAgreement;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String xDoNotMergeFlag;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String deleteFlag;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String infoRemoveFlag;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String dedupHiddenFlag;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String prefCommunicationChannel;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String yanaseFlag;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String financePartyType;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String contractNumber;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String xPrivacyAct;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String xFleet;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected  Timestamp lastActivityDate;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String x_CUST_TYPE;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String xPC_Ind;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String xVANS_Ind;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected  Timestamp xLastModifiedSystemDate;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
	private EObjCommon baseEntity = null;
	
	
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Default constructor.     
     *
     * @generated
     */
    public EObjXOrgExt(EObjCommon baseEntity) {
        super();
        setBaseEntity (baseEntity);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Default constructor.     
     *
     * @generated
     */
    public EObjXOrgExt() {
        super();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the contIdPK attribute. 
     *
     * @generated
     **/
	public Long getContIdPK (){
      return contIdPK;
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the contIdPK attribute. 
     *
     * @param contIdPK
     *     The new value of contIdPK. 
     * @generated
     */
    public void setContIdPK( Long contIdPK ){
    this.contIdPK = contIdPK;
  }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xDefunctInd attribute. 
     *
     * @generated
     */
    @Column(name=xDefunctIndColumn)
    @DataType(jdbcType=xDefunctIndJdbcType, precision=xDefunctIndPrecision)
    public String getXDefunctInd (){
        return xDefunctInd;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xDefunctInd attribute. 
     *
     * @param xDefunctInd
     *     The new value of XDefunctInd. 
     * @generated
     */
    public void setXDefunctInd( String xDefunctInd ){
        this.xDefunctInd = xDefunctInd;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xWebsite attribute. 
     *
     * @generated
     */
    @Column(name=xWebsiteColumn)
    @DataType(jdbcType=xWebsiteJdbcType, precision=xWebsitePrecision)
    public String getXWebsite (){
        return xWebsite;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xWebsite attribute. 
     *
     * @param xWebsite
     *     The new value of XWebsite. 
     * @generated
     */
    public void setXWebsite( String xWebsite ){
        this.xWebsite = xWebsite;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xMarketName attribute. 
     *
     * @generated
     */
    @Column(name=xMarketNameColumn)
    @DataType(jdbcType=xMarketNameJdbcType, precision=xMarketNamePrecision)
    public String getXMarketName (){
        return xMarketName;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xMarketName attribute. 
     *
     * @param xMarketName
     *     The new value of XMarketName. 
     * @generated
     */
    public void setXMarketName( String xMarketName ){
        this.xMarketName = xMarketName;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xBatchInd attribute. 
     *
     * @generated
     */
    @Column(name=xBatchIndColumn)
    @DataType(jdbcType=xBatchIndJdbcType, precision=xBatchIndPrecision)
    public String getXBatchInd (){
        return xBatchInd;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xBatchInd attribute. 
     *
     * @param xBatchInd
     *     The new value of XBatchInd. 
     * @generated
     */
    public void setXBatchInd( String xBatchInd ){
        this.xBatchInd = xBatchInd;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xNumberOfEmployees attribute. 
     *
     * @generated
     */
    @Column(name=xNumberOfEmployeesColumn)
    @DataType(jdbcType=xNumberOfEmployeesJdbcType, precision=xNumberOfEmployeesPrecision)
    public Long getXNumberOfEmployees (){
        return xNumberOfEmployees;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xNumberOfEmployees attribute. 
     *
     * @param xNumberOfEmployees
     *     The new value of XNumberOfEmployees. 
     * @generated
     */
    public void setXNumberOfEmployees( Long xNumberOfEmployees ){
        this.xNumberOfEmployees = xNumberOfEmployees;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xSourceTypeFlag attribute. 
     *
     * @generated
     */
    @Column(name=xSourceTypeFlagColumn)
    @DataType(jdbcType=xSourceTypeFlagJdbcType, precision=xSourceTypeFlagPrecision)
    public String getXSourceTypeFlag (){
        return xSourceTypeFlag;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xSourceTypeFlag attribute. 
     *
     * @param xSourceTypeFlag
     *     The new value of XSourceTypeFlag. 
     * @generated
     */
    public void setXSourceTypeFlag( String xSourceTypeFlag ){
        this.xSourceTypeFlag = xSourceTypeFlag;
    
  }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xGenerated_by attribute. 
     *
     * @generated
     */
    @Column(name=xGenerated_byColumn)
    @DataType(jdbcType=xGenerated_byJdbcType, precision=xGenerated_byPrecision)
    public String getXGenerated_by (){
        return xGenerated_by;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xGenerated_by attribute. 
     *
     * @param xGenerated_by
     *     The new value of XGenerated_by. 
     * @generated
     */
    public void setXGenerated_by( String xGenerated_by ){
        this.xGenerated_by = xGenerated_by;
    
  }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xCorporateCategory attribute. 
     *
     * @generated
     */
    @Column(name=xCorporateCategoryColumn)
    @DataType(jdbcType=xCorporateCategoryJdbcType, precision=xCorporateCategoryPrecision)
    public Long getXCorporateCategory (){
        return xCorporateCategory;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xCorporateCategory attribute. 
     *
     * @param xCorporateCategory
     *     The new value of XCorporateCategory. 
     * @generated
     */
    public void setXCorporateCategory( Long xCorporateCategory ){
        this.xCorporateCategory = xCorporateCategory;
    
  }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xCorporateGroup attribute. 
     *
     * @generated
     */
    @Column(name=xCorporateGroupColumn)
    @DataType(jdbcType=xCorporateGroupJdbcType, precision=xCorporateGroupPrecision)
    public Long getXCorporateGroup (){
        return xCorporateGroup;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xCorporateGroup attribute. 
     *
     * @param xCorporateGroup
     *     The new value of XCorporateGroup. 
     * @generated
     */
    public void setXCorporateGroup( Long xCorporateGroup ){
        this.xCorporateGroup = xCorporateGroup;
    
  }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xPersonalAgreement attribute. 
     *
     * @generated
     */
    @Column(name=xPersonalAgreementColumn)
    @DataType(jdbcType=xPersonalAgreementJdbcType, precision=xPersonalAgreementPrecision)
    public String getXPersonalAgreement (){
        return xPersonalAgreement;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xPersonalAgreement attribute. 
     *
     * @param xPersonalAgreement
     *     The new value of XPersonalAgreement. 
     * @generated
     */
    public void setXPersonalAgreement( String xPersonalAgreement ){
        this.xPersonalAgreement = xPersonalAgreement;
    
  }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xDoNotMergeFlag attribute. 
     *
     * @generated
     */
    @Column(name=xDoNotMergeFlagColumn)
    @DataType(jdbcType=xDoNotMergeFlagJdbcType, precision=xDoNotMergeFlagPrecision)
    public String getXDoNotMergeFlag (){
        return xDoNotMergeFlag;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xDoNotMergeFlag attribute. 
     *
     * @param xDoNotMergeFlag
     *     The new value of XDoNotMergeFlag. 
     * @generated
     */
    public void setXDoNotMergeFlag( String xDoNotMergeFlag ){
        this.xDoNotMergeFlag = xDoNotMergeFlag;
    
  }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the deleteFlag attribute. 
     *
     * @generated
     */
    @Column(name=deleteFlagColumn)
    @DataType(jdbcType=deleteFlagJdbcType, precision=deleteFlagPrecision)
    public String getDeleteFlag (){
        return deleteFlag;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the deleteFlag attribute. 
     *
     * @param deleteFlag
     *     The new value of DeleteFlag. 
     * @generated
     */
    public void setDeleteFlag( String deleteFlag ){
        this.deleteFlag = deleteFlag;
    
  }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the infoRemoveFlag attribute. 
     *
     * @generated
     */
    @Column(name=infoRemoveFlagColumn)
    @DataType(jdbcType=infoRemoveFlagJdbcType, precision=infoRemoveFlagPrecision)
    public String getInfoRemoveFlag (){
        return infoRemoveFlag;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the infoRemoveFlag attribute. 
     *
     * @param infoRemoveFlag
     *     The new value of InfoRemoveFlag. 
     * @generated
     */
    public void setInfoRemoveFlag( String infoRemoveFlag ){
        this.infoRemoveFlag = infoRemoveFlag;
    
  }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the dedupHiddenFlag attribute. 
     *
     * @generated
     */
    @Column(name=dedupHiddenFlagColumn)
    @DataType(jdbcType=dedupHiddenFlagJdbcType, precision=dedupHiddenFlagPrecision)
    public String getDedupHiddenFlag (){
        return dedupHiddenFlag;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the dedupHiddenFlag attribute. 
     *
     * @param dedupHiddenFlag
     *     The new value of DedupHiddenFlag. 
     * @generated
     */
    public void setDedupHiddenFlag( String dedupHiddenFlag ){
        this.dedupHiddenFlag = dedupHiddenFlag;
    
  }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the prefCommunicationChannel attribute. 
     *
     * @generated
     */
    @Column(name=prefCommunicationChannelColumn)
    @DataType(jdbcType=prefCommunicationChannelJdbcType, precision=prefCommunicationChannelPrecision)
    public String getPrefCommunicationChannel (){
        return prefCommunicationChannel;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the prefCommunicationChannel attribute. 
     *
     * @param prefCommunicationChannel
     *     The new value of PrefCommunicationChannel. 
     * @generated
     */
    public void setPrefCommunicationChannel( String prefCommunicationChannel ){
        this.prefCommunicationChannel = prefCommunicationChannel;
    
  }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the yanaseFlag attribute. 
     *
     * @generated
     */
    @Column(name=yanaseFlagColumn)
    @DataType(jdbcType=yanaseFlagJdbcType, precision=yanaseFlagPrecision)
    public String getYanaseFlag (){
        return yanaseFlag;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the yanaseFlag attribute. 
     *
     * @param yanaseFlag
     *     The new value of YanaseFlag. 
     * @generated
     */
    public void setYanaseFlag( String yanaseFlag ){
        this.yanaseFlag = yanaseFlag;
    
  }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the financePartyType attribute. 
     *
     * @generated
     */
    @Column(name=financePartyTypeColumn)
    @DataType(jdbcType=financePartyTypeJdbcType, precision=financePartyTypePrecision)
    public String getFinancePartyType (){
        return financePartyType;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the financePartyType attribute. 
     *
     * @param financePartyType
     *     The new value of FinancePartyType. 
     * @generated
     */
    public void setFinancePartyType( String financePartyType ){
        this.financePartyType = financePartyType;
    
  }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the contractNumber attribute. 
     *
     * @generated
     */
    @Column(name=contractNumberColumn)
    @DataType(jdbcType=contractNumberJdbcType, precision=contractNumberPrecision)
    public String getContractNumber (){
        return contractNumber;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the contractNumber attribute. 
     *
     * @param contractNumber
     *     The new value of ContractNumber. 
     * @generated
     */
    public void setContractNumber( String contractNumber ){
        this.contractNumber = contractNumber;
    
  }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xPrivacyAct attribute. 
     *
     * @generated
     */
    @Column(name=xPrivacyActColumn)
    @DataType(jdbcType=xPrivacyActJdbcType, precision=xPrivacyActPrecision)
    public String getXPrivacyAct (){
        return xPrivacyAct;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xPrivacyAct attribute. 
     *
     * @param xPrivacyAct
     *     The new value of XPrivacyAct. 
     * @generated
     */
    public void setXPrivacyAct( String xPrivacyAct ){
        this.xPrivacyAct = xPrivacyAct;
    
  }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xFleet attribute. 
     *
     * @generated
     */
    @Column(name=xFleetColumn)
    @DataType(jdbcType=xFleetJdbcType, precision=xFleetPrecision)
    public String getXFleet (){
        return xFleet;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xFleet attribute. 
     *
     * @param xFleet
     *     The new value of XFleet. 
     * @generated
     */
    public void setXFleet( String xFleet ){
        this.xFleet = xFleet;
    
  }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the lastActivityDate attribute. 
     *
     * @generated
     */
    @Column(name=lastActivityDateColumn)
    @DataType(jdbcType=lastActivityDateJdbcType)
    public Timestamp getLastActivityDate (){
        return lastActivityDate;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the lastActivityDate attribute. 
     *
     * @param lastActivityDate
     *     The new value of LastActivityDate. 
     * @generated
     */
    public void setLastActivityDate( Timestamp lastActivityDate ){
        this.lastActivityDate = lastActivityDate;
    
  }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the x_CUST_TYPE attribute. 
     *
     * @generated
     */
    @Column(name=x_CUST_TYPEColumn)
    @DataType(jdbcType=x_CUST_TYPEJdbcType, precision=x_CUST_TYPEPrecision)
    public String getX_CUST_TYPE (){
        return x_CUST_TYPE;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the x_CUST_TYPE attribute. 
     *
     * @param x_CUST_TYPE
     *     The new value of X_CUST_TYPE. 
     * @generated
     */
    public void setX_CUST_TYPE( String x_CUST_TYPE ){
        this.x_CUST_TYPE = x_CUST_TYPE;
    
  }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xPC_Ind attribute. 
     *
     * @generated
     */
    @Column(name=xPC_IndColumn)
    @DataType(jdbcType=xPC_IndJdbcType, precision=xPC_IndPrecision)
    public String getXPC_Ind (){
        return xPC_Ind;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xPC_Ind attribute. 
     *
     * @param xPC_Ind
     *     The new value of XPC_Ind. 
     * @generated
     */
    public void setXPC_Ind( String xPC_Ind ){
        this.xPC_Ind = xPC_Ind;
    
  }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xVANS_Ind attribute. 
     *
     * @generated
     */
    @Column(name=xVANS_IndColumn)
    @DataType(jdbcType=xVANS_IndJdbcType, precision=xVANS_IndPrecision)
    public String getXVANS_Ind (){
        return xVANS_Ind;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xVANS_Ind attribute. 
     *
     * @param xVANS_Ind
     *     The new value of XVANS_Ind. 
     * @generated
     */
    public void setXVANS_Ind( String xVANS_Ind ){
        this.xVANS_Ind = xVANS_Ind;
    
  }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xLastModifiedSystemDate attribute. 
     *
     * @generated
     */
    @Column(name=xLastModifiedSystemDateColumn)
    @DataType(jdbcType=xLastModifiedSystemDateJdbcType)
    public Timestamp getXLastModifiedSystemDate (){
        return xLastModifiedSystemDate;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xLastModifiedSystemDate attribute. 
     *
     * @param xLastModifiedSystemDate
     *     The new value of XLastModifiedSystemDate. 
     * @generated
     */
    public void setXLastModifiedSystemDate( Timestamp xLastModifiedSystemDate ){
        this.xLastModifiedSystemDate = xLastModifiedSystemDate;
    
  }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the primary key. 
     *
     * @param aUniqueId
     *     The new value of the primary key. 
     * @generated
   */
	public void setPrimaryKey(Object aUniqueId) {
    this.setContIdPK((Long)aUniqueId);
  }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the primary key.
     *
     * @generated
     */
	public Object getPrimaryKey() {
    return this.getContIdPK();
  }
	 
	 /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes before the extension is added to the database.
     *
     * @generated
     */
    @Override
    protected void beforeAddEx()
    {
        enforceBaseEntityAttributes();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes before the extension is updated in the database
     *
     * @generated
     */
    @Override
    protected void beforeUpdateEx()
    {
        enforceBaseEntityAttributes ();
    }
    
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Handles optimistic locking.
     *
     * @generated
     */
    @Override
    protected void handleOptimisticLocking()
    {
        this.setOldLastUpdateDt(baseEntity.getLastUpdateDt());
        this.setLastUpdateDt(getNextLastUpdateDate());
        baseEntity.setLastUpdateDt(this.getLastUpdateDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Enforces and synchronizes the extension and base entity attributes.
     *
     * @generated
     */
    private void enforceBaseEntityAttributes()
    {
        this.setLastUpdateTxId(baseEntity.getLastUpdateTxId());
        this.setLastUpdateUser(baseEntity.getLastUpdateUser());
        this.setPrimaryKey(baseEntity.getPrimaryKey());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the base entity and syncs all attributes between extension and base entity.
     *
     * @generated
     */
    public void setBaseEntity (EObjCommon baseEntity)
    {
        if (baseEntity == null)
            throw new java.lang.IllegalArgumentException ("baseEntity is null");
        
        this.baseEntity = baseEntity;
        enforceBaseEntityAttributes();
        if( this.getLastUpdateDt() == null ){
        	this.setLastUpdateDt(baseEntity.getLastUpdateDt());
        	this.setOldLastUpdateDt(baseEntity.getOldLastUpdateDt());
        }
    }
}


