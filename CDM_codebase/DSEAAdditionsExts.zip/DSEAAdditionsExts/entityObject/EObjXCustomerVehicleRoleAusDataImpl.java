package com.ibm.daimler.dsea.entityObject;

import com.ibm.pdq.runtime.generator.BaseParameterHandler;
import java.util.Iterator;
import java.sql.PreparedStatement;
import com.ibm.pdq.runtime.statement.StatementDescriptor;
import com.ibm.pdq.runtime.generator.BaseData;
import java.sql.SQLException;
import com.ibm.pdq.annotation.Metadata;
import com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRoleAus;
import com.ibm.pdq.runtime.generator.BaseRowHandler;
import com.ibm.pdq.runtime.statement.SqlStatementType;
import java.sql.Types;


/**
 * <!-- begin-user-doc -->
 * 
 * <!-- end-user-doc -->
 * 
 * @generated
 */
public class EObjXCustomerVehicleRoleAusDataImpl  extends BaseData implements EObjXCustomerVehicleRoleAusData
{

  /**
   * @generated
   */
  public static final String generatorVersion = "3.200.75";

  /**
   * @generated
   */
  public static final String identifier = "EObjXCustomerVehicleRoleAusData";

  /**
   * @generated
   */
  public static final long generationTime = 0x00000166d4c6e341L;

  /**
   * @generated
   */
  public static final String collection = "NULLID";

  /**
   * @generated
   */
  public static final String packageVersion = null;

  /**
   * @generated
   */
  public static final boolean forceSingleBindIsolation = false;

  /**
   * @generated
   */
  public EObjXCustomerVehicleRoleAusDataImpl()
  {
    super();
  } 

  /**
   * @generated
   */
  public String getGeneratorVersion()
  {
    return generatorVersion;
  }

  /**
   * @Select( sql="select XCustomer_Role_Auspk_Id, CUSTOMER_VEHICLE_ID, VEHICLE_ROLE_TP_CD, VEHICLE_REL_ST_TP_CD, START_DT, END_DT, SOURCE_IDENT_TP_CD, MODIFY_SYS_DT, XCustomer_Vehicle_Aus_Referenc, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from XCUSTOMERVEHICLEROLEAUS where XCustomer_Role_Auspk_Id = ? " )
   * 
   * @generated
   */
  public Iterator<EObjXCustomerVehicleRoleAus> getEObjXCustomerVehicleRoleAus (Long xCustomerRoleAuspkId)
  {
    return queryIterator (getEObjXCustomerVehicleRoleAusStatementDescriptor, xCustomerRoleAuspkId);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getEObjXCustomerVehicleRoleAusStatementDescriptor = createStatementDescriptor (
    "getEObjXCustomerVehicleRoleAus(Long)",
    "select XCustomer_Role_Auspk_Id, CUSTOMER_VEHICLE_ID, VEHICLE_ROLE_TP_CD, VEHICLE_REL_ST_TP_CD, START_DT, END_DT, SOURCE_IDENT_TP_CD, MODIFY_SYS_DT, XCustomer_Vehicle_Aus_Referenc, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from XCUSTOMERVEHICLEROLEAUS where XCustomer_Role_Auspk_Id = ? ",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"xcustomer_role_auspk_id", "customer_vehicle_id", "vehicle_role_tp_cd", "vehicle_rel_st_tp_cd", "start_dt", "end_dt", "source_ident_tp_cd", "modify_sys_dt", "xcustomer_vehicle_aus_referenc", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetEObjXCustomerVehicleRoleAusParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetEObjXCustomerVehicleRoleAusRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.TIMESTAMP, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 19, 19, 19, 0, 0, 19, 0, 19, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    1);

  /**
   * @generated
   */
  public static class GetEObjXCustomerVehicleRoleAusParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setLong (stmt, 1, Types.BIGINT, (Long)parameters[0]);
    }
  }

  /**
   * @generated
   */
  public static class GetEObjXCustomerVehicleRoleAusRowHandler extends BaseRowHandler<EObjXCustomerVehicleRoleAus>
  {
    /**
     * @generated
     */
    public EObjXCustomerVehicleRoleAus handle (java.sql.ResultSet rs, EObjXCustomerVehicleRoleAus returnObject) throws java.sql.SQLException
    {
      returnObject = new EObjXCustomerVehicleRoleAus ();
      returnObject.setXCustomerRoleAuspkId(getLongObject (rs, 1)); 
      returnObject.setCustomerVehicleId(getLongObject (rs, 2)); 
      returnObject.setVehicleRole(getLongObject (rs, 3)); 
      returnObject.setVehicleRelStatus(getLongObject (rs, 4)); 
      returnObject.setStartDate(getTimestamp (rs, 5)); 
      returnObject.setEndDate(getTimestamp (rs, 6)); 
      returnObject.setSourceIdentifier(getLongObject (rs, 7)); 
      returnObject.setLastModifiedSystemDate(getTimestamp (rs, 8)); 
      returnObject.setXCustomerVehicleAusReference(getLongObject (rs, 9)); 
      returnObject.setLastUpdateDt(getTimestamp (rs, 10)); 
      returnObject.setLastUpdateUser(getString (rs, 11)); 
      returnObject.setLastUpdateTxId(getLongObject (rs, 12)); 
    
      return returnObject;
    }
  }

  /**
   * @Update( sql="insert into XCUSTOMERVEHICLEROLEAUS (XCustomer_Role_Auspk_Id, CUSTOMER_VEHICLE_ID, VEHICLE_ROLE_TP_CD, VEHICLE_REL_ST_TP_CD, START_DT, END_DT, SOURCE_IDENT_TP_CD, MODIFY_SYS_DT, XCustomer_Vehicle_Aus_Referenc, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( :xCustomerRoleAuspkId, :customerVehicleId, :vehicleRole, :vehicleRelStatus, :startDate, :endDate, :sourceIdentifier, :lastModifiedSystemDate, :xCustomerVehicleAusReference, :lastUpdateDt, :lastUpdateUser, :lastUpdateTxId)" )
   * 
   * @generated
   */
  public int createEObjXCustomerVehicleRoleAus (EObjXCustomerVehicleRoleAus e)
  {
    return update (createEObjXCustomerVehicleRoleAusStatementDescriptor, e);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor createEObjXCustomerVehicleRoleAusStatementDescriptor = createStatementDescriptor (
    "createEObjXCustomerVehicleRoleAus(com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRoleAus)",
    "insert into XCUSTOMERVEHICLEROLEAUS (XCustomer_Role_Auspk_Id, CUSTOMER_VEHICLE_ID, VEHICLE_ROLE_TP_CD, VEHICLE_REL_ST_TP_CD, START_DT, END_DT, SOURCE_IDENT_TP_CD, MODIFY_SYS_DT, XCustomer_Vehicle_Aus_Referenc, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values(  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? )",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.INSERT,
    null,
    new CreateEObjXCustomerVehicleRoleAusParameterHandler (),
    new int[][]{{Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.TIMESTAMP, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 19, 19, 19, 0, 0, 19, 0, 19, 0, 0, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    2);

  /**
   * @generated
   */
  public static class CreateEObjXCustomerVehicleRoleAusParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      EObjXCustomerVehicleRoleAus bean0 = (EObjXCustomerVehicleRoleAus) parameters[0];
      setLong (stmt, 1, Types.BIGINT, (Long)bean0.getXCustomerRoleAuspkId());
      setLong (stmt, 2, Types.BIGINT, (Long)bean0.getCustomerVehicleId());
      setLong (stmt, 3, Types.BIGINT, (Long)bean0.getVehicleRole());
      setLong (stmt, 4, Types.BIGINT, (Long)bean0.getVehicleRelStatus());
      setTimestamp (stmt, 5, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getStartDate());
      setTimestamp (stmt, 6, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getEndDate());
      setLong (stmt, 7, Types.BIGINT, (Long)bean0.getSourceIdentifier());
      setTimestamp (stmt, 8, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastModifiedSystemDate());
      setLong (stmt, 9, Types.BIGINT, (Long)bean0.getXCustomerVehicleAusReference());
      setTimestamp (stmt, 10, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUpdateDt());
      setString (stmt, 11, Types.VARCHAR, (String)bean0.getLastUpdateUser());
      setLong (stmt, 12, Types.BIGINT, (Long)bean0.getLastUpdateTxId());
    }
  }

  /**
   * @Update( sql="update XCUSTOMERVEHICLEROLEAUS set CUSTOMER_VEHICLE_ID = :customerVehicleId, VEHICLE_ROLE_TP_CD = :vehicleRole, VEHICLE_REL_ST_TP_CD = :vehicleRelStatus, START_DT = :startDate, END_DT = :endDate, SOURCE_IDENT_TP_CD = :sourceIdentifier, MODIFY_SYS_DT = :lastModifiedSystemDate, XCustomer_Vehicle_Aus_Referenc = :xCustomerVehicleAusReference, LAST_UPDATE_DT = :lastUpdateDt, LAST_UPDATE_USER = :lastUpdateUser, LAST_UPDATE_TX_ID = :lastUpdateTxId where XCustomer_Role_Auspk_Id = :xCustomerRoleAuspkId and LAST_UPDATE_DT = :oldLastUpdateDt" )
   * 
   * @generated
   */
  public int updateEObjXCustomerVehicleRoleAus (EObjXCustomerVehicleRoleAus e)
  {
    return update (updateEObjXCustomerVehicleRoleAusStatementDescriptor, e);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor updateEObjXCustomerVehicleRoleAusStatementDescriptor = createStatementDescriptor (
    "updateEObjXCustomerVehicleRoleAus(com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRoleAus)",
    "update XCUSTOMERVEHICLEROLEAUS set CUSTOMER_VEHICLE_ID =  ? , VEHICLE_ROLE_TP_CD =  ? , VEHICLE_REL_ST_TP_CD =  ? , START_DT =  ? , END_DT =  ? , SOURCE_IDENT_TP_CD =  ? , MODIFY_SYS_DT =  ? , XCustomer_Vehicle_Aus_Referenc =  ? , LAST_UPDATE_DT =  ? , LAST_UPDATE_USER =  ? , LAST_UPDATE_TX_ID =  ?  where XCustomer_Role_Auspk_Id =  ?  and LAST_UPDATE_DT =  ? ",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.UPDATE,
    null,
    new UpdateEObjXCustomerVehicleRoleAusParameterHandler (),
    new int[][]{{Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.TIMESTAMP, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP}, {19, 19, 19, 0, 0, 19, 0, 19, 0, 0, 19, 19, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    3);

  /**
   * @generated
   */
  public static class UpdateEObjXCustomerVehicleRoleAusParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      EObjXCustomerVehicleRoleAus bean0 = (EObjXCustomerVehicleRoleAus) parameters[0];
      setLong (stmt, 1, Types.BIGINT, (Long)bean0.getCustomerVehicleId());
      setLong (stmt, 2, Types.BIGINT, (Long)bean0.getVehicleRole());
      setLong (stmt, 3, Types.BIGINT, (Long)bean0.getVehicleRelStatus());
      setTimestamp (stmt, 4, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getStartDate());
      setTimestamp (stmt, 5, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getEndDate());
      setLong (stmt, 6, Types.BIGINT, (Long)bean0.getSourceIdentifier());
      setTimestamp (stmt, 7, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastModifiedSystemDate());
      setLong (stmt, 8, Types.BIGINT, (Long)bean0.getXCustomerVehicleAusReference());
      setTimestamp (stmt, 9, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUpdateDt());
      setString (stmt, 10, Types.VARCHAR, (String)bean0.getLastUpdateUser());
      setLong (stmt, 11, Types.BIGINT, (Long)bean0.getLastUpdateTxId());
      setLong (stmt, 12, Types.BIGINT, (Long)bean0.getXCustomerRoleAuspkId());
      setTimestamp (stmt, 13, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getOldLastUpdateDt());
    }
  }

  /**
   * @Update( sql="delete from XCUSTOMERVEHICLEROLEAUS where XCustomer_Role_Auspk_Id = ?" )
   * 
   * @generated
   */
  public int deleteEObjXCustomerVehicleRoleAus (Long xCustomerRoleAuspkId)
  {
    return update (deleteEObjXCustomerVehicleRoleAusStatementDescriptor, xCustomerRoleAuspkId);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor deleteEObjXCustomerVehicleRoleAusStatementDescriptor = createStatementDescriptor (
    "deleteEObjXCustomerVehicleRoleAus(Long)",
    "delete from XCUSTOMERVEHICLEROLEAUS where XCustomer_Role_Auspk_Id = ?",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.DELETE,
    null,
    new DeleteEObjXCustomerVehicleRoleAusParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    4);

  /**
   * @generated
   */
  public static class DeleteEObjXCustomerVehicleRoleAusParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setLong (stmt, 1, Types.BIGINT, (Long)parameters[0]);
    }
  }

}
