/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[5fd62ee23d8d05897ed6806dbce5867f]
 */

package com.ibm.daimler.dsea.entityObject;

import com.dwl.base.EObjCommon;
import com.ibm.mdm.base.db.DataType;
import com.ibm.pdq.annotation.Column;
import com.ibm.pdq.annotation.Table;


import com.ibm.pdq.annotation.Id;

import java.sql.Timestamp;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * The entity object corresponding to the XDeleteAudit business object. This
 * entity object should include all the attributes as defined by the business
 * object.
 * 
 * @generated
 */
@SuppressWarnings("serial")
@Table(name=EObjXDeleteAudit.tableName)
public class EObjXDeleteAudit extends EObjCommon {

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public static final String tableName = "XDELETEAUDIT";
    
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String xDeleteAuditpkIdColumn = "XDELETE_AUDITPK_ID";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String xDeleteAuditpkIdJdbcType = "BIGINT";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    xDeleteAuditpkIdPrecision = 19;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String cONT_IDColumn = "CONT_ID";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String cONT_IDJdbcType = "BIGINT";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    cONT_IDPrecision = 19;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String aDMIN_CLIENT_IDColumn = "ADMIN_CLIENT_ID";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String aDMIN_CLIENT_IDJdbcType = "VARCHAR";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    aDMIN_CLIENT_IDPrecision = 50;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String aDMIN_SYSTEM_VALUEColumn = "ADMIN_SYSTEM_VALUE";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String aDMIN_SYSTEM_VALUEJdbcType = "VARCHAR";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    aDMIN_SYSTEM_VALUEPrecision = 50;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String dESCRIPTIONColumn = "DESCRIPTION";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String dESCRIPTIONJdbcType = "VARCHAR";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    dESCRIPTIONPrecision = 250;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String dELETE_DATEColumn = "DELETE_DATE";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String dELETE_DATEJdbcType = "TIMESTAMP";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String mARKET_NAMEColumn = "MARKET_NAME";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String mARKET_NAMEJdbcType = "VARCHAR";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    mARKET_NAMEPrecision = 50;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected Long xDeleteAuditpkId;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected Long cONT_ID;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String aDMIN_CLIENT_ID;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String aDMIN_SYSTEM_VALUE;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String dESCRIPTION;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected  Timestamp dELETE_DATE;
    //inside if 

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String mARKET_NAME;



    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Default constructor.     
     *
     * @generated
     */
    public EObjXDeleteAudit() {
        super();
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xDeleteAuditpkId attribute. 
     *
     * @generated
     */
    @Id
    @Column(name=xDeleteAuditpkIdColumn)
    @DataType(jdbcType=xDeleteAuditpkIdJdbcType, precision=xDeleteAuditpkIdPrecision)
    public Long getXDeleteAuditpkId (){
        return xDeleteAuditpkId;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xDeleteAuditpkId attribute. 
     *
     * @param xDeleteAuditpkId
     *     The new value of XDeleteAuditpkId. 
     * @generated
     */
    public void setXDeleteAuditpkId( Long xDeleteAuditpkId ){
        this.xDeleteAuditpkId = xDeleteAuditpkId;
		
        super.setIdPK(xDeleteAuditpkId);
	}
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the cONT_ID attribute. 
     *
     * @generated
     */
    @Column(name=cONT_IDColumn)
    @DataType(jdbcType=cONT_IDJdbcType, precision=cONT_IDPrecision)
    public Long getCONT_ID (){
        return cONT_ID;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the cONT_ID attribute. 
     *
     * @param cONT_ID
     *     The new value of CONT_ID. 
     * @generated
     */
    public void setCONT_ID( Long cONT_ID ){
        this.cONT_ID = cONT_ID;
		
	}
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the aDMIN_CLIENT_ID attribute. 
     *
     * @generated
     */
    @Column(name=aDMIN_CLIENT_IDColumn)
    @DataType(jdbcType=aDMIN_CLIENT_IDJdbcType, precision=aDMIN_CLIENT_IDPrecision)
    public String getADMIN_CLIENT_ID (){
        return aDMIN_CLIENT_ID;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the aDMIN_CLIENT_ID attribute. 
     *
     * @param aDMIN_CLIENT_ID
     *     The new value of ADMIN_CLIENT_ID. 
     * @generated
     */
    public void setADMIN_CLIENT_ID( String aDMIN_CLIENT_ID ){
        this.aDMIN_CLIENT_ID = aDMIN_CLIENT_ID;
		
	}
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the aDMIN_SYSTEM_VALUE attribute. 
     *
     * @generated
     */
    @Column(name=aDMIN_SYSTEM_VALUEColumn)
    @DataType(jdbcType=aDMIN_SYSTEM_VALUEJdbcType, precision=aDMIN_SYSTEM_VALUEPrecision)
    public String getADMIN_SYSTEM_VALUE (){
        return aDMIN_SYSTEM_VALUE;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the aDMIN_SYSTEM_VALUE attribute. 
     *
     * @param aDMIN_SYSTEM_VALUE
     *     The new value of ADMIN_SYSTEM_VALUE. 
     * @generated
     */
    public void setADMIN_SYSTEM_VALUE( String aDMIN_SYSTEM_VALUE ){
        this.aDMIN_SYSTEM_VALUE = aDMIN_SYSTEM_VALUE;
		
	}
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the dESCRIPTION attribute. 
     *
     * @generated
     */
    @Column(name=dESCRIPTIONColumn)
    @DataType(jdbcType=dESCRIPTIONJdbcType, precision=dESCRIPTIONPrecision)
    public String getDESCRIPTION (){
        return dESCRIPTION;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the dESCRIPTION attribute. 
     *
     * @param dESCRIPTION
     *     The new value of DESCRIPTION. 
     * @generated
     */
    public void setDESCRIPTION( String dESCRIPTION ){
        this.dESCRIPTION = dESCRIPTION;
		
	}
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the dELETE_DATE attribute. 
     *
     * @generated
     */
    @Column(name=dELETE_DATEColumn)
    @DataType(jdbcType=dELETE_DATEJdbcType)
    public Timestamp getDELETE_DATE (){
        return dELETE_DATE;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the dELETE_DATE attribute. 
     *
     * @param dELETE_DATE
     *     The new value of DELETE_DATE. 
     * @generated
     */
    public void setDELETE_DATE( Timestamp dELETE_DATE ){
        this.dELETE_DATE = dELETE_DATE;
		
	}
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the mARKET_NAME attribute. 
     *
     * @generated
     */
    @Column(name=mARKET_NAMEColumn)
    @DataType(jdbcType=mARKET_NAMEJdbcType, precision=mARKET_NAMEPrecision)
    public String getMARKET_NAME (){
        return mARKET_NAME;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the mARKET_NAME attribute. 
     *
     * @param mARKET_NAME
     *     The new value of MARKET_NAME. 
     * @generated
     */
    public void setMARKET_NAME( String mARKET_NAME ){
        this.mARKET_NAME = mARKET_NAME;
		
	}
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the primary key. 
     *
     * @param aUniqueId
     *     The new value of the primary key. 
     * @generated
	 */
	public void setPrimaryKey(Object aUniqueId) {
		this.setXDeleteAuditpkId((Long)aUniqueId);
	}

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the primary key.
     *
     * @generated
     */
	public Object getPrimaryKey() {
		return this.getXDeleteAuditpkId();
	}
	 
}


