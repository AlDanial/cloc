package com.ibm.daimler.dsea.entityObject;

import com.ibm.pdq.runtime.generator.BaseParameterHandler;
import com.ibm.daimler.dsea.entityObject.EObjXVehicle;
import java.util.Iterator;
import java.sql.PreparedStatement;
import com.ibm.pdq.runtime.statement.StatementDescriptor;
import com.ibm.pdq.runtime.generator.BaseData;
import java.sql.SQLException;
import com.ibm.pdq.annotation.Metadata;
import com.ibm.pdq.runtime.generator.BaseRowHandler;
import com.ibm.pdq.runtime.statement.SqlStatementType;
import java.sql.Types;


/**
 * <!-- begin-user-doc -->
 * 
 * <!-- end-user-doc -->
 * 
 * @generated
 */
public class EObjXVehicleDataImpl  extends BaseData implements EObjXVehicleData
{

  /**
   * @generated
   */
  public static final String generatorVersion = "3.200.75";

  /**
   * @generated
   */
  public static final String identifier = "EObjXVehicleData";

  /**
   * @generated
   */
  public static final long generationTime = 0x000001685145f03aL;

  /**
   * @generated
   */
  public static final String collection = "NULLID";

  /**
   * @generated
   */
  public static final String packageVersion = null;

  /**
   * @generated
   */
  public static final boolean forceSingleBindIsolation = false;

  /**
   * @generated
   */
  public EObjXVehicleDataImpl()
  {
    super();
  } 

  /**
   * @generated
   */
  public String getGeneratorVersion()
  {
    return generatorVersion;
  }

  /**
   * @Select( sql="select VEHICLEPK_ID, DIVISION, BUSINESS_UNIT, ACTIVITY, TYPE_CLASS, BAU_RELHE, BAU_MUSTER, SUB_MUSTER, ENGINE_NUM, COUNTRY_TP_CD, COLOR, TRIM, GLOBAL_VIN, LOCAL_VIN, LICENSE_PLATE, SOURCE_IDENT_TP_CD, MODIFY_SYS_DT, CREATE_DT, CHANGED_DT, LAST_SERVICE_DT, Market_Name, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from XVEHICLE where VEHICLEPK_ID = ? " )
   * 
   * @generated
   */
  public Iterator<EObjXVehicle> getEObjXVehicle (Long vehiclepkId)
  {
    return queryIterator (getEObjXVehicleStatementDescriptor, vehiclepkId);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getEObjXVehicleStatementDescriptor = createStatementDescriptor (
    "getEObjXVehicle(Long)",
    "select VEHICLEPK_ID, DIVISION, BUSINESS_UNIT, ACTIVITY, TYPE_CLASS, BAU_RELHE, BAU_MUSTER, SUB_MUSTER, ENGINE_NUM, COUNTRY_TP_CD, COLOR, TRIM, GLOBAL_VIN, LOCAL_VIN, LICENSE_PLATE, SOURCE_IDENT_TP_CD, MODIFY_SYS_DT, CREATE_DT, CHANGED_DT, LAST_SERVICE_DT, Market_Name, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from XVEHICLE where VEHICLEPK_ID = ? ",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"vehiclepk_id", "division", "business_unit", "activity", "type_class", "bau_relhe", "bau_muster", "sub_muster", "engine_num", "country_tp_cd", "color", "trim", "global_vin", "local_vin", "license_plate", "source_ident_tp_cd", "modify_sys_dt", "create_dt", "changed_dt", "last_service_dt", "market_name", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetEObjXVehicleParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetEObjXVehicleRowHandler (),
    new int[][]{ {Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 20, 20, 20, 20, 20, 20, 10, 20, 19, 50, 50, 20, 20, 20, 19, 0, 0, 0, 0, 250, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    1);

  /**
   * @generated
   */
  public static class GetEObjXVehicleParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setLong (stmt, 1, Types.BIGINT, (Long)parameters[0]);
    }
  }

  /**
   * @generated
   */
  public static class GetEObjXVehicleRowHandler extends BaseRowHandler<EObjXVehicle>
  {
    /**
     * @generated
     */
    public EObjXVehicle handle (java.sql.ResultSet rs, EObjXVehicle returnObject) throws java.sql.SQLException
    {
      returnObject = new EObjXVehicle ();
      returnObject.setVehiclepkId(getLongObject (rs, 1)); 
      returnObject.setDivision(getString (rs, 2)); 
      returnObject.setBusinessUnit(getString (rs, 3)); 
      returnObject.setActivity(getString (rs, 4)); 
      returnObject.setTypeClass(getString (rs, 5)); 
      returnObject.setBauRelhe(getString (rs, 6)); 
      returnObject.setBauMuster(getString (rs, 7)); 
      returnObject.setSubMuster(getString (rs, 8)); 
      returnObject.setEngineNumber(getString (rs, 9)); 
      returnObject.setCountry(getLongObject (rs, 10)); 
      returnObject.setColor(getString (rs, 11)); 
      returnObject.setTrim(getString (rs, 12)); 
      returnObject.setGlobalVIN(getString (rs, 13)); 
      returnObject.setLocalVIN(getString (rs, 14)); 
      returnObject.setLicensePlate(getString (rs, 15)); 
      returnObject.setSourceIdentifier(getLongObject (rs, 16)); 
      returnObject.setLastModifiedSystemDate(getTimestamp (rs, 17)); 
      returnObject.setCreateDate(getTimestamp (rs, 18)); 
      returnObject.setChangedDate(getTimestamp (rs, 19)); 
      returnObject.setLastServiceDate(getTimestamp (rs, 20)); 
      returnObject.setMarketName(getString (rs, 21)); 
      returnObject.setLastUpdateDt(getTimestamp (rs, 22)); 
      returnObject.setLastUpdateUser(getString (rs, 23)); 
      returnObject.setLastUpdateTxId(getLongObject (rs, 24)); 
    
      return returnObject;
    }
  }

  /**
   * @Update( sql="insert into XVEHICLE (VEHICLEPK_ID, DIVISION, BUSINESS_UNIT, ACTIVITY, TYPE_CLASS, BAU_RELHE, BAU_MUSTER, SUB_MUSTER, ENGINE_NUM, COUNTRY_TP_CD, COLOR, TRIM, GLOBAL_VIN, LOCAL_VIN, LICENSE_PLATE, SOURCE_IDENT_TP_CD, MODIFY_SYS_DT, CREATE_DT, CHANGED_DT, LAST_SERVICE_DT, Market_Name, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( :vehiclepkId, :division, :businessUnit, :activity, :typeClass, :bauRelhe, :bauMuster, :subMuster, :engineNumber, :country, :color, :trim, :globalVIN, :localVIN, :licensePlate, :sourceIdentifier, :lastModifiedSystemDate, :createDate, :changedDate, :lastServiceDate, :marketName, :lastUpdateDt, :lastUpdateUser, :lastUpdateTxId)" )
   * 
   * @generated
   */
  public int createEObjXVehicle (EObjXVehicle e)
  {
    return update (createEObjXVehicleStatementDescriptor, e);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor createEObjXVehicleStatementDescriptor = createStatementDescriptor (
    "createEObjXVehicle(com.ibm.daimler.dsea.entityObject.EObjXVehicle)",
    "insert into XVEHICLE (VEHICLEPK_ID, DIVISION, BUSINESS_UNIT, ACTIVITY, TYPE_CLASS, BAU_RELHE, BAU_MUSTER, SUB_MUSTER, ENGINE_NUM, COUNTRY_TP_CD, COLOR, TRIM, GLOBAL_VIN, LOCAL_VIN, LICENSE_PLATE, SOURCE_IDENT_TP_CD, MODIFY_SYS_DT, CREATE_DT, CHANGED_DT, LAST_SERVICE_DT, Market_Name, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values(  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? )",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.INSERT,
    null,
    new CreateEObjXVehicleParameterHandler (),
    new int[][]{{Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 20, 20, 20, 20, 20, 20, 10, 20, 19, 50, 50, 20, 20, 20, 19, 0, 0, 0, 0, 250, 0, 0, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    2);

  /**
   * @generated
   */
  public static class CreateEObjXVehicleParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      EObjXVehicle bean0 = (EObjXVehicle) parameters[0];
      setLong (stmt, 1, Types.BIGINT, (Long)bean0.getVehiclepkId());
      setString (stmt, 2, Types.VARCHAR, (String)bean0.getDivision());
      setString (stmt, 3, Types.VARCHAR, (String)bean0.getBusinessUnit());
      setString (stmt, 4, Types.VARCHAR, (String)bean0.getActivity());
      setString (stmt, 5, Types.VARCHAR, (String)bean0.getTypeClass());
      setString (stmt, 6, Types.VARCHAR, (String)bean0.getBauRelhe());
      setString (stmt, 7, Types.VARCHAR, (String)bean0.getBauMuster());
      setString (stmt, 8, Types.VARCHAR, (String)bean0.getSubMuster());
      setString (stmt, 9, Types.VARCHAR, (String)bean0.getEngineNumber());
      setLong (stmt, 10, Types.BIGINT, (Long)bean0.getCountry());
      setString (stmt, 11, Types.VARCHAR, (String)bean0.getColor());
      setString (stmt, 12, Types.VARCHAR, (String)bean0.getTrim());
      setString (stmt, 13, Types.VARCHAR, (String)bean0.getGlobalVIN());
      setString (stmt, 14, Types.VARCHAR, (String)bean0.getLocalVIN());
      setString (stmt, 15, Types.VARCHAR, (String)bean0.getLicensePlate());
      setLong (stmt, 16, Types.BIGINT, (Long)bean0.getSourceIdentifier());
      setTimestamp (stmt, 17, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastModifiedSystemDate());
      setTimestamp (stmt, 18, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getCreateDate());
      setTimestamp (stmt, 19, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getChangedDate());
      setTimestamp (stmt, 20, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastServiceDate());
      setString (stmt, 21, Types.VARCHAR, (String)bean0.getMarketName());
      setTimestamp (stmt, 22, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUpdateDt());
      setString (stmt, 23, Types.VARCHAR, (String)bean0.getLastUpdateUser());
      setLong (stmt, 24, Types.BIGINT, (Long)bean0.getLastUpdateTxId());
    }
  }

  /**
   * @Update( sql="update XVEHICLE set DIVISION = :division, BUSINESS_UNIT = :businessUnit, ACTIVITY = :activity, TYPE_CLASS = :typeClass, BAU_RELHE = :bauRelhe, BAU_MUSTER = :bauMuster, SUB_MUSTER = :subMuster, ENGINE_NUM = :engineNumber, COUNTRY_TP_CD = :country, COLOR = :color, TRIM = :trim, GLOBAL_VIN = :globalVIN, LOCAL_VIN = :localVIN, LICENSE_PLATE = :licensePlate, SOURCE_IDENT_TP_CD = :sourceIdentifier, MODIFY_SYS_DT = :lastModifiedSystemDate, CREATE_DT = :createDate, CHANGED_DT = :changedDate, LAST_SERVICE_DT = :lastServiceDate, Market_Name = :marketName, LAST_UPDATE_DT = :lastUpdateDt, LAST_UPDATE_USER = :lastUpdateUser, LAST_UPDATE_TX_ID = :lastUpdateTxId where VEHICLEPK_ID = :vehiclepkId and LAST_UPDATE_DT = :oldLastUpdateDt" )
   * 
   * @generated
   */
  public int updateEObjXVehicle (EObjXVehicle e)
  {
    return update (updateEObjXVehicleStatementDescriptor, e);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor updateEObjXVehicleStatementDescriptor = createStatementDescriptor (
    "updateEObjXVehicle(com.ibm.daimler.dsea.entityObject.EObjXVehicle)",
    "update XVEHICLE set DIVISION =  ? , BUSINESS_UNIT =  ? , ACTIVITY =  ? , TYPE_CLASS =  ? , BAU_RELHE =  ? , BAU_MUSTER =  ? , SUB_MUSTER =  ? , ENGINE_NUM =  ? , COUNTRY_TP_CD =  ? , COLOR =  ? , TRIM =  ? , GLOBAL_VIN =  ? , LOCAL_VIN =  ? , LICENSE_PLATE =  ? , SOURCE_IDENT_TP_CD =  ? , MODIFY_SYS_DT =  ? , CREATE_DT =  ? , CHANGED_DT =  ? , LAST_SERVICE_DT =  ? , Market_Name =  ? , LAST_UPDATE_DT =  ? , LAST_UPDATE_USER =  ? , LAST_UPDATE_TX_ID =  ?  where VEHICLEPK_ID =  ?  and LAST_UPDATE_DT =  ? ",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.UPDATE,
    null,
    new UpdateEObjXVehicleParameterHandler (),
    new int[][]{{Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP}, {20, 20, 20, 20, 20, 20, 10, 20, 19, 50, 50, 20, 20, 20, 19, 0, 0, 0, 0, 250, 0, 0, 19, 19, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    3);

  /**
   * @generated
   */
  public static class UpdateEObjXVehicleParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      EObjXVehicle bean0 = (EObjXVehicle) parameters[0];
      setString (stmt, 1, Types.VARCHAR, (String)bean0.getDivision());
      setString (stmt, 2, Types.VARCHAR, (String)bean0.getBusinessUnit());
      setString (stmt, 3, Types.VARCHAR, (String)bean0.getActivity());
      setString (stmt, 4, Types.VARCHAR, (String)bean0.getTypeClass());
      setString (stmt, 5, Types.VARCHAR, (String)bean0.getBauRelhe());
      setString (stmt, 6, Types.VARCHAR, (String)bean0.getBauMuster());
      setString (stmt, 7, Types.VARCHAR, (String)bean0.getSubMuster());
      setString (stmt, 8, Types.VARCHAR, (String)bean0.getEngineNumber());
      setLong (stmt, 9, Types.BIGINT, (Long)bean0.getCountry());
      setString (stmt, 10, Types.VARCHAR, (String)bean0.getColor());
      setString (stmt, 11, Types.VARCHAR, (String)bean0.getTrim());
      setString (stmt, 12, Types.VARCHAR, (String)bean0.getGlobalVIN());
      setString (stmt, 13, Types.VARCHAR, (String)bean0.getLocalVIN());
      setString (stmt, 14, Types.VARCHAR, (String)bean0.getLicensePlate());
      setLong (stmt, 15, Types.BIGINT, (Long)bean0.getSourceIdentifier());
      setTimestamp (stmt, 16, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastModifiedSystemDate());
      setTimestamp (stmt, 17, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getCreateDate());
      setTimestamp (stmt, 18, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getChangedDate());
      setTimestamp (stmt, 19, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastServiceDate());
      setString (stmt, 20, Types.VARCHAR, (String)bean0.getMarketName());
      setTimestamp (stmt, 21, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUpdateDt());
      setString (stmt, 22, Types.VARCHAR, (String)bean0.getLastUpdateUser());
      setLong (stmt, 23, Types.BIGINT, (Long)bean0.getLastUpdateTxId());
      setLong (stmt, 24, Types.BIGINT, (Long)bean0.getVehiclepkId());
      setTimestamp (stmt, 25, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getOldLastUpdateDt());
    }
  }

  /**
   * @Update( sql="delete from XVEHICLE where VEHICLEPK_ID = ?" )
   * 
   * @generated
   */
  public int deleteEObjXVehicle (Long vehiclepkId)
  {
    return update (deleteEObjXVehicleStatementDescriptor, vehiclepkId);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor deleteEObjXVehicleStatementDescriptor = createStatementDescriptor (
    "deleteEObjXVehicle(Long)",
    "delete from XVEHICLE where VEHICLEPK_ID = ?",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.DELETE,
    null,
    new DeleteEObjXVehicleParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    4);

  /**
   * @generated
   */
  public static class DeleteEObjXVehicleParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setLong (stmt, 1, Types.BIGINT, (Long)parameters[0]);
    }
  }

}
