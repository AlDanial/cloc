package com.ibm.daimler.dsea.entityObject;

import com.ibm.pdq.runtime.generator.BaseParameterHandler;
import java.util.Iterator;
import com.ibm.mdm.base.db.ResultQueue1;
import java.sql.PreparedStatement;
import com.ibm.pdq.runtime.statement.StatementDescriptor;
import com.ibm.pdq.runtime.generator.BaseData;
import java.sql.SQLException;
import com.ibm.pdq.annotation.Metadata;
import com.ibm.daimler.dsea.entityObject.EObjXGurantorCompany;
import com.ibm.pdq.runtime.generator.BaseRowHandler;
import com.ibm.pdq.runtime.statement.SqlStatementType;
import java.sql.Types;


@SuppressWarnings("unchecked")

/**
 * <!-- begin-user-doc -->
 * 
 * <!-- end-user-doc -->
 * 
 * @generated
 */
public class XGurantorCompanyInquiryDataImpl  extends BaseData implements XGurantorCompanyInquiryData
{

  /**
   * @generated
   */
  public static final String generatorVersion = "3.200.75";

  /**
   * @generated
   */
  public static final String identifier = "XGurantorCompanyInquiryData";

  /**
   * @generated
   */
  public static final long generationTime = 0x00000161d1eb31b7L;

  /**
   * @generated
   */
  public static final String collection = "NULLID";

  /**
   * @generated
   */
  public static final String packageVersion = null;

  /**
   * @generated
   */
  public static final boolean forceSingleBindIsolation = false;

  /**
   * @generated
   */
  public XGurantorCompanyInquiryDataImpl()
  {
    super();
  } 

  /**
   * @generated
   */
  public String getGeneratorVersion()
  {
    return generatorVersion;
  }

  /**
   * @Select( sql="SELECT r.XGurantor_Companypk_Id XGurantor_Companypk_Id, r.CONTRACT_DETAILS_ID CONTRACT_DETAILS_ID, r.BPID BPID, r.CAN_NUMBER CAN_NUMBER, r.INDUSTRY_TP_CD INDUSTRY_TP_CD, r.COMPANY_NAME COMPANY_NAME, r.COMPANY_NAME_LOCAL COMPANY_NAME_LOCAL, r.ADDR_USAGE_TP_CD ADDR_USAGE_TP_CD, r.ADDR_LINE_ONE ADDR_LINE_ONE, r.ADDR_LINE_TWO ADDR_LINE_TWO, r.ADDR_LINE_THREE ADDR_LINE_THREE, r.POSTAL_CODE POSTAL_CODE, r.CITY_NAME CITY_NAME, r.RESIDENCE_NUMBER RESIDENCE_NUMBER, r.COUNTRY_TP_CD COUNTRY_TP_CD, r.BUILDING_NAME BUILDING_NAME, r.STREET_NAME STREET_NAME, r.STREET_NUMBER STREET_NUMBER, r.MOBILE_NUMBER MOBILE_NUMBER, r.HOME_PHONE_NUMBER HOME_PHONE_NUMBER, r.WORK_PHONE_NUMBER WORK_PHONE_NUMBER, r.WORK_PHONE_NUMBER_EXT WORK_PHONE_NUMBER_EXT, r.FAX FAX, r.EMAIL EMAIL, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.START_DT START_DT, r.END_DT END_DT, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XGURANTORCOMPANY r WHERE r.XGurantor_Companypk_Id = ? ", pattern="tableAlias (XGURANTORCOMPANY => com.ibm.daimler.dsea.entityObject.EObjXGurantorCompany, H_XGURANTORCOMPANY => com.ibm.daimler.dsea.entityObject.EObjXGurantorCompany)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue1<EObjXGurantorCompany>> getXGurantorCompany (Object[] parameters)
  {
    return queryIterator (getXGurantorCompanyStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getXGurantorCompanyStatementDescriptor = createStatementDescriptor (
    "getXGurantorCompany(Object[])",
    "SELECT r.XGurantor_Companypk_Id XGurantor_Companypk_Id, r.CONTRACT_DETAILS_ID CONTRACT_DETAILS_ID, r.BPID BPID, r.CAN_NUMBER CAN_NUMBER, r.INDUSTRY_TP_CD INDUSTRY_TP_CD, r.COMPANY_NAME COMPANY_NAME, r.COMPANY_NAME_LOCAL COMPANY_NAME_LOCAL, r.ADDR_USAGE_TP_CD ADDR_USAGE_TP_CD, r.ADDR_LINE_ONE ADDR_LINE_ONE, r.ADDR_LINE_TWO ADDR_LINE_TWO, r.ADDR_LINE_THREE ADDR_LINE_THREE, r.POSTAL_CODE POSTAL_CODE, r.CITY_NAME CITY_NAME, r.RESIDENCE_NUMBER RESIDENCE_NUMBER, r.COUNTRY_TP_CD COUNTRY_TP_CD, r.BUILDING_NAME BUILDING_NAME, r.STREET_NAME STREET_NAME, r.STREET_NUMBER STREET_NUMBER, r.MOBILE_NUMBER MOBILE_NUMBER, r.HOME_PHONE_NUMBER HOME_PHONE_NUMBER, r.WORK_PHONE_NUMBER WORK_PHONE_NUMBER, r.WORK_PHONE_NUMBER_EXT WORK_PHONE_NUMBER_EXT, r.FAX FAX, r.EMAIL EMAIL, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.START_DT START_DT, r.END_DT END_DT, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XGURANTORCOMPANY r WHERE r.XGurantor_Companypk_Id = ? ",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"xgurantor_companypk_id", "contract_details_id", "bpid", "can_number", "industry_tp_cd", "company_name", "company_name_local", "addr_usage_tp_cd", "addr_line_one", "addr_line_two", "addr_line_three", "postal_code", "city_name", "residence_number", "country_tp_cd", "building_name", "street_name", "street_number", "mobile_number", "home_phone_number", "work_phone_number", "work_phone_number_ext", "fax", "email", "source_ident_tp_cd", "start_dt", "end_dt", "modify_sys_dt", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetXGurantorCompanyParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetXGurantorCompanyRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 19, 500, 500, 19, 500, 500, 19, 500, 500, 500, 250, 250, 250, 19, 250, 250, 250, 250, 250, 250, 250, 250, 250, 19, 0, 0, 0, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    1);

  /**
   * @generated
   */
  public static class GetXGurantorCompanyParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetXGurantorCompanyRowHandler extends BaseRowHandler<ResultQueue1<EObjXGurantorCompany>>
  {
    /**
     * @generated
     */
    public ResultQueue1<EObjXGurantorCompany> handle (java.sql.ResultSet rs, ResultQueue1<EObjXGurantorCompany> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue1<EObjXGurantorCompany> ();

      EObjXGurantorCompany returnObject1 = new EObjXGurantorCompany ();
      returnObject1.setXGurantorCompanypkId(getLongObject (rs, 1)); 
      returnObject1.setContractDetailsId(getLongObject (rs, 2)); 
      returnObject1.setBPID(getString (rs, 3)); 
      returnObject1.setCANNumber(getString (rs, 4)); 
      returnObject1.setIndustry(getLongObject (rs, 5)); 
      returnObject1.setCompanyName(getString (rs, 6)); 
      returnObject1.setCompanyNameLocal(getString (rs, 7)); 
      returnObject1.setAddressUsage(getLongObject (rs, 8)); 
      returnObject1.setAddressLineOne(getString (rs, 9)); 
      returnObject1.setAddressLineTwo(getString (rs, 10)); 
      returnObject1.setAddressLineThree(getString (rs, 11)); 
      returnObject1.setPostalCode(getString (rs, 12)); 
      returnObject1.setCityName(getString (rs, 13)); 
      returnObject1.setResidenceNumber(getString (rs, 14)); 
      returnObject1.setCountry(getLongObject (rs, 15)); 
      returnObject1.setBuildingName(getString (rs, 16)); 
      returnObject1.setStreetName(getString (rs, 17)); 
      returnObject1.setStreetNumber(getString (rs, 18)); 
      returnObject1.setMobileNumber(getString (rs, 19)); 
      returnObject1.setHomePhoneNumber(getString (rs, 20)); 
      returnObject1.setWorkPhoneNumber(getString (rs, 21)); 
      returnObject1.setWorkPhoneNumberExtension(getString (rs, 22)); 
      returnObject1.setFax(getString (rs, 23)); 
      returnObject1.setEmail(getString (rs, 24)); 
      returnObject1.setSourceIdentifier(getLongObject (rs, 25)); 
      returnObject1.setStartDate(getTimestamp (rs, 26)); 
      returnObject1.setEndDate(getTimestamp (rs, 27)); 
      returnObject1.setLastModifiedSystemDate(getTimestamp (rs, 28)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 29)); 
      returnObject1.setLastUpdateUser(getString (rs, 30)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 31)); 
      returnObject.add (returnObject1);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT r.H_XGurantor_Companypk_Id hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.XGurantor_Companypk_Id XGurantor_Companypk_Id, r.CONTRACT_DETAILS_ID CONTRACT_DETAILS_ID, r.BPID BPID, r.CAN_NUMBER CAN_NUMBER, r.INDUSTRY_TP_CD INDUSTRY_TP_CD, r.COMPANY_NAME COMPANY_NAME, r.COMPANY_NAME_LOCAL COMPANY_NAME_LOCAL, r.ADDR_USAGE_TP_CD ADDR_USAGE_TP_CD, r.ADDR_LINE_ONE ADDR_LINE_ONE, r.ADDR_LINE_TWO ADDR_LINE_TWO, r.ADDR_LINE_THREE ADDR_LINE_THREE, r.POSTAL_CODE POSTAL_CODE, r.CITY_NAME CITY_NAME, r.RESIDENCE_NUMBER RESIDENCE_NUMBER, r.COUNTRY_TP_CD COUNTRY_TP_CD, r.BUILDING_NAME BUILDING_NAME, r.STREET_NAME STREET_NAME, r.STREET_NUMBER STREET_NUMBER, r.MOBILE_NUMBER MOBILE_NUMBER, r.HOME_PHONE_NUMBER HOME_PHONE_NUMBER, r.WORK_PHONE_NUMBER WORK_PHONE_NUMBER, r.WORK_PHONE_NUMBER_EXT WORK_PHONE_NUMBER_EXT, r.FAX FAX, r.EMAIL EMAIL, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.START_DT START_DT, r.END_DT END_DT, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XGURANTORCOMPANY r WHERE r.H_XGurantor_Companypk_Id = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))", pattern="tableAlias (XGURANTORCOMPANY => com.ibm.daimler.dsea.entityObject.EObjXGurantorCompany, H_XGURANTORCOMPANY => com.ibm.daimler.dsea.entityObject.EObjXGurantorCompany)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue1<EObjXGurantorCompany>> getXGurantorCompanyHistory (Object[] parameters)
  {
    return queryIterator (getXGurantorCompanyHistoryStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getXGurantorCompanyHistoryStatementDescriptor = createStatementDescriptor (
    "getXGurantorCompanyHistory(Object[])",
    "SELECT r.H_XGurantor_Companypk_Id hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.XGurantor_Companypk_Id XGurantor_Companypk_Id, r.CONTRACT_DETAILS_ID CONTRACT_DETAILS_ID, r.BPID BPID, r.CAN_NUMBER CAN_NUMBER, r.INDUSTRY_TP_CD INDUSTRY_TP_CD, r.COMPANY_NAME COMPANY_NAME, r.COMPANY_NAME_LOCAL COMPANY_NAME_LOCAL, r.ADDR_USAGE_TP_CD ADDR_USAGE_TP_CD, r.ADDR_LINE_ONE ADDR_LINE_ONE, r.ADDR_LINE_TWO ADDR_LINE_TWO, r.ADDR_LINE_THREE ADDR_LINE_THREE, r.POSTAL_CODE POSTAL_CODE, r.CITY_NAME CITY_NAME, r.RESIDENCE_NUMBER RESIDENCE_NUMBER, r.COUNTRY_TP_CD COUNTRY_TP_CD, r.BUILDING_NAME BUILDING_NAME, r.STREET_NAME STREET_NAME, r.STREET_NUMBER STREET_NUMBER, r.MOBILE_NUMBER MOBILE_NUMBER, r.HOME_PHONE_NUMBER HOME_PHONE_NUMBER, r.WORK_PHONE_NUMBER WORK_PHONE_NUMBER, r.WORK_PHONE_NUMBER_EXT WORK_PHONE_NUMBER_EXT, r.FAX FAX, r.EMAIL EMAIL, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.START_DT START_DT, r.END_DT END_DT, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XGURANTORCOMPANY r WHERE r.H_XGurantor_Companypk_Id = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"historyidpk", "h_action_code", "h_created_by", "h_create_dt", "h_end_dt", "xgurantor_companypk_id", "contract_details_id", "bpid", "can_number", "industry_tp_cd", "company_name", "company_name_local", "addr_usage_tp_cd", "addr_line_one", "addr_line_two", "addr_line_three", "postal_code", "city_name", "residence_number", "country_tp_cd", "building_name", "street_name", "street_number", "mobile_number", "home_phone_number", "work_phone_number", "work_phone_number_ext", "fax", "email", "source_ident_tp_cd", "start_dt", "end_dt", "modify_sys_dt", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetXGurantorCompanyHistoryParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP}, {19, 0, 0}, {0, 0, 0}, {1, 1, 1}},
    null,
    new GetXGurantorCompanyHistoryRowHandler (),
    new int[][]{ {Types.BIGINT, Types.CHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 1, 20, 0, 0, 19, 19, 500, 500, 19, 500, 500, 19, 500, 500, 500, 250, 250, 250, 19, 250, 250, 250, 250, 250, 250, 250, 250, 250, 19, 0, 0, 0, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    2);

  /**
   * @generated
   */
  public static class GetXGurantorCompanyHistoryParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetXGurantorCompanyHistoryRowHandler extends BaseRowHandler<ResultQueue1<EObjXGurantorCompany>>
  {
    /**
     * @generated
     */
    public ResultQueue1<EObjXGurantorCompany> handle (java.sql.ResultSet rs, ResultQueue1<EObjXGurantorCompany> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue1<EObjXGurantorCompany> ();

      EObjXGurantorCompany returnObject1 = new EObjXGurantorCompany ();
      returnObject1.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject1.setHistActionCode(getString (rs, 2)); 
      returnObject1.setHistCreatedBy(getString (rs, 3)); 
      returnObject1.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject1.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject1.setXGurantorCompanypkId(getLongObject (rs, 6)); 
      returnObject1.setContractDetailsId(getLongObject (rs, 7)); 
      returnObject1.setBPID(getString (rs, 8)); 
      returnObject1.setCANNumber(getString (rs, 9)); 
      returnObject1.setIndustry(getLongObject (rs, 10)); 
      returnObject1.setCompanyName(getString (rs, 11)); 
      returnObject1.setCompanyNameLocal(getString (rs, 12)); 
      returnObject1.setAddressUsage(getLongObject (rs, 13)); 
      returnObject1.setAddressLineOne(getString (rs, 14)); 
      returnObject1.setAddressLineTwo(getString (rs, 15)); 
      returnObject1.setAddressLineThree(getString (rs, 16)); 
      returnObject1.setPostalCode(getString (rs, 17)); 
      returnObject1.setCityName(getString (rs, 18)); 
      returnObject1.setResidenceNumber(getString (rs, 19)); 
      returnObject1.setCountry(getLongObject (rs, 20)); 
      returnObject1.setBuildingName(getString (rs, 21)); 
      returnObject1.setStreetName(getString (rs, 22)); 
      returnObject1.setStreetNumber(getString (rs, 23)); 
      returnObject1.setMobileNumber(getString (rs, 24)); 
      returnObject1.setHomePhoneNumber(getString (rs, 25)); 
      returnObject1.setWorkPhoneNumber(getString (rs, 26)); 
      returnObject1.setWorkPhoneNumberExtension(getString (rs, 27)); 
      returnObject1.setFax(getString (rs, 28)); 
      returnObject1.setEmail(getString (rs, 29)); 
      returnObject1.setSourceIdentifier(getLongObject (rs, 30)); 
      returnObject1.setStartDate(getTimestamp (rs, 31)); 
      returnObject1.setEndDate(getTimestamp (rs, 32)); 
      returnObject1.setLastModifiedSystemDate(getTimestamp (rs, 33)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 34)); 
      returnObject1.setLastUpdateUser(getString (rs, 35)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 36)); 
      returnObject.add (returnObject1);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT r.XGurantor_Companypk_Id XGurantor_Companypk_Id, r.CONTRACT_DETAILS_ID CONTRACT_DETAILS_ID, r.BPID BPID, r.CAN_NUMBER CAN_NUMBER, r.INDUSTRY_TP_CD INDUSTRY_TP_CD, r.COMPANY_NAME COMPANY_NAME, r.COMPANY_NAME_LOCAL COMPANY_NAME_LOCAL, r.ADDR_USAGE_TP_CD ADDR_USAGE_TP_CD, r.ADDR_LINE_ONE ADDR_LINE_ONE, r.ADDR_LINE_TWO ADDR_LINE_TWO, r.ADDR_LINE_THREE ADDR_LINE_THREE, r.POSTAL_CODE POSTAL_CODE, r.CITY_NAME CITY_NAME, r.RESIDENCE_NUMBER RESIDENCE_NUMBER, r.COUNTRY_TP_CD COUNTRY_TP_CD, r.BUILDING_NAME BUILDING_NAME, r.STREET_NAME STREET_NAME, r.STREET_NUMBER STREET_NUMBER, r.MOBILE_NUMBER MOBILE_NUMBER, r.HOME_PHONE_NUMBER HOME_PHONE_NUMBER, r.WORK_PHONE_NUMBER WORK_PHONE_NUMBER, r.WORK_PHONE_NUMBER_EXT WORK_PHONE_NUMBER_EXT, r.FAX FAX, r.EMAIL EMAIL, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.START_DT START_DT, r.END_DT END_DT, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XGURANTORCOMPANY r WHERE r.CONTRACT_DETAILS_ID = ? ", pattern="tableAlias (XGURANTORCOMPANY => com.ibm.daimler.dsea.entityObject.EObjXGurantorCompany, H_XGURANTORCOMPANY => com.ibm.daimler.dsea.entityObject.EObjXGurantorCompany)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue1<EObjXGurantorCompany>> getAllXGurantorCompanyByContractDetailsId (Object[] parameters)
  {
    return queryIterator (getAllXGurantorCompanyByContractDetailsIdStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getAllXGurantorCompanyByContractDetailsIdStatementDescriptor = createStatementDescriptor (
    "getAllXGurantorCompanyByContractDetailsId(Object[])",
    "SELECT r.XGurantor_Companypk_Id XGurantor_Companypk_Id, r.CONTRACT_DETAILS_ID CONTRACT_DETAILS_ID, r.BPID BPID, r.CAN_NUMBER CAN_NUMBER, r.INDUSTRY_TP_CD INDUSTRY_TP_CD, r.COMPANY_NAME COMPANY_NAME, r.COMPANY_NAME_LOCAL COMPANY_NAME_LOCAL, r.ADDR_USAGE_TP_CD ADDR_USAGE_TP_CD, r.ADDR_LINE_ONE ADDR_LINE_ONE, r.ADDR_LINE_TWO ADDR_LINE_TWO, r.ADDR_LINE_THREE ADDR_LINE_THREE, r.POSTAL_CODE POSTAL_CODE, r.CITY_NAME CITY_NAME, r.RESIDENCE_NUMBER RESIDENCE_NUMBER, r.COUNTRY_TP_CD COUNTRY_TP_CD, r.BUILDING_NAME BUILDING_NAME, r.STREET_NAME STREET_NAME, r.STREET_NUMBER STREET_NUMBER, r.MOBILE_NUMBER MOBILE_NUMBER, r.HOME_PHONE_NUMBER HOME_PHONE_NUMBER, r.WORK_PHONE_NUMBER WORK_PHONE_NUMBER, r.WORK_PHONE_NUMBER_EXT WORK_PHONE_NUMBER_EXT, r.FAX FAX, r.EMAIL EMAIL, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.START_DT START_DT, r.END_DT END_DT, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XGURANTORCOMPANY r WHERE r.CONTRACT_DETAILS_ID = ? ",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"xgurantor_companypk_id", "contract_details_id", "bpid", "can_number", "industry_tp_cd", "company_name", "company_name_local", "addr_usage_tp_cd", "addr_line_one", "addr_line_two", "addr_line_three", "postal_code", "city_name", "residence_number", "country_tp_cd", "building_name", "street_name", "street_number", "mobile_number", "home_phone_number", "work_phone_number", "work_phone_number_ext", "fax", "email", "source_ident_tp_cd", "start_dt", "end_dt", "modify_sys_dt", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetAllXGurantorCompanyByContractDetailsIdParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetAllXGurantorCompanyByContractDetailsIdRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 19, 500, 500, 19, 500, 500, 19, 500, 500, 500, 250, 250, 250, 19, 250, 250, 250, 250, 250, 250, 250, 250, 250, 19, 0, 0, 0, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    3);

  /**
   * @generated
   */
  public static class GetAllXGurantorCompanyByContractDetailsIdParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetAllXGurantorCompanyByContractDetailsIdRowHandler extends BaseRowHandler<ResultQueue1<EObjXGurantorCompany>>
  {
    /**
     * @generated
     */
    public ResultQueue1<EObjXGurantorCompany> handle (java.sql.ResultSet rs, ResultQueue1<EObjXGurantorCompany> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue1<EObjXGurantorCompany> ();

      EObjXGurantorCompany returnObject1 = new EObjXGurantorCompany ();
      returnObject1.setXGurantorCompanypkId(getLongObject (rs, 1)); 
      returnObject1.setContractDetailsId(getLongObject (rs, 2)); 
      returnObject1.setBPID(getString (rs, 3)); 
      returnObject1.setCANNumber(getString (rs, 4)); 
      returnObject1.setIndustry(getLongObject (rs, 5)); 
      returnObject1.setCompanyName(getString (rs, 6)); 
      returnObject1.setCompanyNameLocal(getString (rs, 7)); 
      returnObject1.setAddressUsage(getLongObject (rs, 8)); 
      returnObject1.setAddressLineOne(getString (rs, 9)); 
      returnObject1.setAddressLineTwo(getString (rs, 10)); 
      returnObject1.setAddressLineThree(getString (rs, 11)); 
      returnObject1.setPostalCode(getString (rs, 12)); 
      returnObject1.setCityName(getString (rs, 13)); 
      returnObject1.setResidenceNumber(getString (rs, 14)); 
      returnObject1.setCountry(getLongObject (rs, 15)); 
      returnObject1.setBuildingName(getString (rs, 16)); 
      returnObject1.setStreetName(getString (rs, 17)); 
      returnObject1.setStreetNumber(getString (rs, 18)); 
      returnObject1.setMobileNumber(getString (rs, 19)); 
      returnObject1.setHomePhoneNumber(getString (rs, 20)); 
      returnObject1.setWorkPhoneNumber(getString (rs, 21)); 
      returnObject1.setWorkPhoneNumberExtension(getString (rs, 22)); 
      returnObject1.setFax(getString (rs, 23)); 
      returnObject1.setEmail(getString (rs, 24)); 
      returnObject1.setSourceIdentifier(getLongObject (rs, 25)); 
      returnObject1.setStartDate(getTimestamp (rs, 26)); 
      returnObject1.setEndDate(getTimestamp (rs, 27)); 
      returnObject1.setLastModifiedSystemDate(getTimestamp (rs, 28)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 29)); 
      returnObject1.setLastUpdateUser(getString (rs, 30)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 31)); 
      returnObject.add (returnObject1);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT r.H_XGurantor_Companypk_Id hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.XGurantor_Companypk_Id XGurantor_Companypk_Id, r.CONTRACT_DETAILS_ID CONTRACT_DETAILS_ID, r.BPID BPID, r.CAN_NUMBER CAN_NUMBER, r.INDUSTRY_TP_CD INDUSTRY_TP_CD, r.COMPANY_NAME COMPANY_NAME, r.COMPANY_NAME_LOCAL COMPANY_NAME_LOCAL, r.ADDR_USAGE_TP_CD ADDR_USAGE_TP_CD, r.ADDR_LINE_ONE ADDR_LINE_ONE, r.ADDR_LINE_TWO ADDR_LINE_TWO, r.ADDR_LINE_THREE ADDR_LINE_THREE, r.POSTAL_CODE POSTAL_CODE, r.CITY_NAME CITY_NAME, r.RESIDENCE_NUMBER RESIDENCE_NUMBER, r.COUNTRY_TP_CD COUNTRY_TP_CD, r.BUILDING_NAME BUILDING_NAME, r.STREET_NAME STREET_NAME, r.STREET_NUMBER STREET_NUMBER, r.MOBILE_NUMBER MOBILE_NUMBER, r.HOME_PHONE_NUMBER HOME_PHONE_NUMBER, r.WORK_PHONE_NUMBER WORK_PHONE_NUMBER, r.WORK_PHONE_NUMBER_EXT WORK_PHONE_NUMBER_EXT, r.FAX FAX, r.EMAIL EMAIL, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.START_DT START_DT, r.END_DT END_DT, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XGURANTORCOMPANY r WHERE r.CONTRACT_DETAILS_ID = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))", pattern="tableAlias (XGURANTORCOMPANY => com.ibm.daimler.dsea.entityObject.EObjXGurantorCompany, H_XGURANTORCOMPANY => com.ibm.daimler.dsea.entityObject.EObjXGurantorCompany)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue1<EObjXGurantorCompany>> getAllXGurantorCompanyByContractDetailsIdHistory (Object[] parameters)
  {
    return queryIterator (getAllXGurantorCompanyByContractDetailsIdHistoryStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getAllXGurantorCompanyByContractDetailsIdHistoryStatementDescriptor = createStatementDescriptor (
    "getAllXGurantorCompanyByContractDetailsIdHistory(Object[])",
    "SELECT r.H_XGurantor_Companypk_Id hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.XGurantor_Companypk_Id XGurantor_Companypk_Id, r.CONTRACT_DETAILS_ID CONTRACT_DETAILS_ID, r.BPID BPID, r.CAN_NUMBER CAN_NUMBER, r.INDUSTRY_TP_CD INDUSTRY_TP_CD, r.COMPANY_NAME COMPANY_NAME, r.COMPANY_NAME_LOCAL COMPANY_NAME_LOCAL, r.ADDR_USAGE_TP_CD ADDR_USAGE_TP_CD, r.ADDR_LINE_ONE ADDR_LINE_ONE, r.ADDR_LINE_TWO ADDR_LINE_TWO, r.ADDR_LINE_THREE ADDR_LINE_THREE, r.POSTAL_CODE POSTAL_CODE, r.CITY_NAME CITY_NAME, r.RESIDENCE_NUMBER RESIDENCE_NUMBER, r.COUNTRY_TP_CD COUNTRY_TP_CD, r.BUILDING_NAME BUILDING_NAME, r.STREET_NAME STREET_NAME, r.STREET_NUMBER STREET_NUMBER, r.MOBILE_NUMBER MOBILE_NUMBER, r.HOME_PHONE_NUMBER HOME_PHONE_NUMBER, r.WORK_PHONE_NUMBER WORK_PHONE_NUMBER, r.WORK_PHONE_NUMBER_EXT WORK_PHONE_NUMBER_EXT, r.FAX FAX, r.EMAIL EMAIL, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.START_DT START_DT, r.END_DT END_DT, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XGURANTORCOMPANY r WHERE r.CONTRACT_DETAILS_ID = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"historyidpk", "h_action_code", "h_created_by", "h_create_dt", "h_end_dt", "xgurantor_companypk_id", "contract_details_id", "bpid", "can_number", "industry_tp_cd", "company_name", "company_name_local", "addr_usage_tp_cd", "addr_line_one", "addr_line_two", "addr_line_three", "postal_code", "city_name", "residence_number", "country_tp_cd", "building_name", "street_name", "street_number", "mobile_number", "home_phone_number", "work_phone_number", "work_phone_number_ext", "fax", "email", "source_ident_tp_cd", "start_dt", "end_dt", "modify_sys_dt", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetAllXGurantorCompanyByContractDetailsIdHistoryParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP}, {19, 0, 0}, {0, 0, 0}, {1, 1, 1}},
    null,
    new GetAllXGurantorCompanyByContractDetailsIdHistoryRowHandler (),
    new int[][]{ {Types.BIGINT, Types.CHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 1, 20, 0, 0, 19, 19, 500, 500, 19, 500, 500, 19, 500, 500, 500, 250, 250, 250, 19, 250, 250, 250, 250, 250, 250, 250, 250, 250, 19, 0, 0, 0, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    4);

  /**
   * @generated
   */
  public static class GetAllXGurantorCompanyByContractDetailsIdHistoryParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetAllXGurantorCompanyByContractDetailsIdHistoryRowHandler extends BaseRowHandler<ResultQueue1<EObjXGurantorCompany>>
  {
    /**
     * @generated
     */
    public ResultQueue1<EObjXGurantorCompany> handle (java.sql.ResultSet rs, ResultQueue1<EObjXGurantorCompany> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue1<EObjXGurantorCompany> ();

      EObjXGurantorCompany returnObject1 = new EObjXGurantorCompany ();
      returnObject1.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject1.setHistActionCode(getString (rs, 2)); 
      returnObject1.setHistCreatedBy(getString (rs, 3)); 
      returnObject1.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject1.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject1.setXGurantorCompanypkId(getLongObject (rs, 6)); 
      returnObject1.setContractDetailsId(getLongObject (rs, 7)); 
      returnObject1.setBPID(getString (rs, 8)); 
      returnObject1.setCANNumber(getString (rs, 9)); 
      returnObject1.setIndustry(getLongObject (rs, 10)); 
      returnObject1.setCompanyName(getString (rs, 11)); 
      returnObject1.setCompanyNameLocal(getString (rs, 12)); 
      returnObject1.setAddressUsage(getLongObject (rs, 13)); 
      returnObject1.setAddressLineOne(getString (rs, 14)); 
      returnObject1.setAddressLineTwo(getString (rs, 15)); 
      returnObject1.setAddressLineThree(getString (rs, 16)); 
      returnObject1.setPostalCode(getString (rs, 17)); 
      returnObject1.setCityName(getString (rs, 18)); 
      returnObject1.setResidenceNumber(getString (rs, 19)); 
      returnObject1.setCountry(getLongObject (rs, 20)); 
      returnObject1.setBuildingName(getString (rs, 21)); 
      returnObject1.setStreetName(getString (rs, 22)); 
      returnObject1.setStreetNumber(getString (rs, 23)); 
      returnObject1.setMobileNumber(getString (rs, 24)); 
      returnObject1.setHomePhoneNumber(getString (rs, 25)); 
      returnObject1.setWorkPhoneNumber(getString (rs, 26)); 
      returnObject1.setWorkPhoneNumberExtension(getString (rs, 27)); 
      returnObject1.setFax(getString (rs, 28)); 
      returnObject1.setEmail(getString (rs, 29)); 
      returnObject1.setSourceIdentifier(getLongObject (rs, 30)); 
      returnObject1.setStartDate(getTimestamp (rs, 31)); 
      returnObject1.setEndDate(getTimestamp (rs, 32)); 
      returnObject1.setLastModifiedSystemDate(getTimestamp (rs, 33)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 34)); 
      returnObject1.setLastUpdateUser(getString (rs, 35)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 36)); 
      returnObject.add (returnObject1);

    
      return returnObject;
    }
  }

}
