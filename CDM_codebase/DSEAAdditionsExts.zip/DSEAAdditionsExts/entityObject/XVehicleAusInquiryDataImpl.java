package com.ibm.daimler.dsea.entityObject;

import com.ibm.pdq.runtime.generator.BaseParameterHandler;
import java.util.Iterator;
import com.ibm.mdm.base.db.ResultQueue1;
import java.sql.PreparedStatement;
import com.ibm.pdq.runtime.statement.StatementDescriptor;
import com.ibm.daimler.dsea.entityObject.EObjXVehicleAus;
import com.ibm.pdq.runtime.generator.BaseData;
import java.sql.SQLException;
import com.ibm.pdq.annotation.Metadata;
import com.ibm.pdq.runtime.generator.BaseRowHandler;
import com.ibm.pdq.runtime.statement.SqlStatementType;
import java.sql.Types;


@SuppressWarnings("unchecked")

/**
 * <!-- begin-user-doc -->
 * 
 * <!-- end-user-doc -->
 * 
 * @generated
 */
public class XVehicleAusInquiryDataImpl  extends BaseData implements XVehicleAusInquiryData
{

  /**
   * @generated
   */
  public static final String generatorVersion = "3.200.75";

  /**
   * @generated
   */
  public static final String identifier = "XVehicleAusInquiryData";

  /**
   * @generated
   */
  public static final long generationTime = 0x00000166d448991dL;

  /**
   * @generated
   */
  public static final String collection = "NULLID";

  /**
   * @generated
   */
  public static final String packageVersion = null;

  /**
   * @generated
   */
  public static final boolean forceSingleBindIsolation = false;

  /**
   * @generated
   */
  public XVehicleAusInquiryDataImpl()
  {
    super();
  } 

  /**
   * @generated
   */
  public String getGeneratorVersion()
  {
    return generatorVersion;
  }

  /**
   * @Select( sql="SELECT r.XVehicle_Auspk_Id XVehicle_Auspk_Id, r.GLOBAL_VIN GLOBAL_VIN, r.AMG_VEH AMG_VEH, r.VEHICLE_TYPE VEHICLE_TYPE, r.CLASS_SUMMARY CLASS_SUMMARY, r.ODOMETER ODOMETER, r.ENGINE_NUM ENGINE_NUM, r.VEHICLE_YEAR VEHICLE_YEAR, r.MODEL MODEL, r.REG_NO REG_NO, r.VEHICLE_CLASS VEHICLE_CLASS, r.COMM_NO COMM_NO, r.MARKET_NAME MARKET_NAME, r.CIRCLE_OF_EXCELLENCE CIRCLE_OF_EXCELLENCE, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XVEHICLEAUS r WHERE r.XVehicle_Auspk_Id = ? ", pattern="tableAlias (XVEHICLEAUS => com.ibm.daimler.dsea.entityObject.EObjXVehicleAus, H_XVEHICLEAUS => com.ibm.daimler.dsea.entityObject.EObjXVehicleAus)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue1<EObjXVehicleAus>> getXVehicleAus (Object[] parameters)
  {
    return queryIterator (getXVehicleAusStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getXVehicleAusStatementDescriptor = createStatementDescriptor (
    "getXVehicleAus(Object[])",
    "SELECT r.XVehicle_Auspk_Id XVehicle_Auspk_Id, r.GLOBAL_VIN GLOBAL_VIN, r.AMG_VEH AMG_VEH, r.VEHICLE_TYPE VEHICLE_TYPE, r.CLASS_SUMMARY CLASS_SUMMARY, r.ODOMETER ODOMETER, r.ENGINE_NUM ENGINE_NUM, r.VEHICLE_YEAR VEHICLE_YEAR, r.MODEL MODEL, r.REG_NO REG_NO, r.VEHICLE_CLASS VEHICLE_CLASS, r.COMM_NO COMM_NO, r.MARKET_NAME MARKET_NAME, r.CIRCLE_OF_EXCELLENCE CIRCLE_OF_EXCELLENCE, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XVEHICLEAUS r WHERE r.XVehicle_Auspk_Id = ? ",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"xvehicle_auspk_id", "global_vin", "amg_veh", "vehicle_type", "class_summary", "odometer", "engine_num", "vehicle_year", "model", "reg_no", "vehicle_class", "comm_no", "market_name", "circle_of_excellence", "source_ident_tp_cd", "modify_sys_dt", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetXVehicleAusParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetXVehicleAusRowHandler (),
    new int[][]{ {Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 50, 5, 50, 250, 250, 50, 0, 250, 50, 100, 100, 10, 250, 19, 0, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    1);

  /**
   * @generated
   */
  public static class GetXVehicleAusParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetXVehicleAusRowHandler extends BaseRowHandler<ResultQueue1<EObjXVehicleAus>>
  {
    /**
     * @generated
     */
    public ResultQueue1<EObjXVehicleAus> handle (java.sql.ResultSet rs, ResultQueue1<EObjXVehicleAus> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue1<EObjXVehicleAus> ();

      EObjXVehicleAus returnObject1 = new EObjXVehicleAus ();
      returnObject1.setXVehicleAuspkId(getLongObject (rs, 1)); 
      returnObject1.setGlobalVIN(getString (rs, 2)); 
      returnObject1.setAmgVehicle(getString (rs, 3)); 
      returnObject1.setVehicleType(getString (rs, 4)); 
      returnObject1.setClassSummary(getString (rs, 5)); 
      returnObject1.setOdoMeter(getString (rs, 6)); 
      returnObject1.setEngineNum(getString (rs, 7)); 
      returnObject1.setVehicleYear(getTimestamp (rs, 8)); 
      returnObject1.setModel(getString (rs, 9)); 
      returnObject1.setRegNum(getString (rs, 10)); 
      returnObject1.setVehicleClass(getString (rs, 11)); 
      returnObject1.setCommNo(getString (rs, 12)); 
      returnObject1.setMarketName(getString (rs, 13)); 
      returnObject1.setCircleOfExcellence(getString (rs, 14)); 
      returnObject1.setSourceIdentifier(getLongObject (rs, 15)); 
      returnObject1.setLastModifiedSystemDate(getTimestamp (rs, 16)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 17)); 
      returnObject1.setLastUpdateUser(getString (rs, 18)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 19)); 
      returnObject.add (returnObject1);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT r.H_XVehicle_Auspk_Id hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.XVehicle_Auspk_Id XVehicle_Auspk_Id, r.GLOBAL_VIN GLOBAL_VIN, r.AMG_VEH AMG_VEH, r.VEHICLE_TYPE VEHICLE_TYPE, r.CLASS_SUMMARY CLASS_SUMMARY, r.ODOMETER ODOMETER, r.ENGINE_NUM ENGINE_NUM, r.VEHICLE_YEAR VEHICLE_YEAR, r.MODEL MODEL, r.REG_NO REG_NO, r.VEHICLE_CLASS VEHICLE_CLASS, r.COMM_NO COMM_NO, r.MARKET_NAME MARKET_NAME, r.CIRCLE_OF_EXCELLENCE CIRCLE_OF_EXCELLENCE, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XVEHICLEAUS r WHERE r.H_XVehicle_Auspk_Id = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))", pattern="tableAlias (XVEHICLEAUS => com.ibm.daimler.dsea.entityObject.EObjXVehicleAus, H_XVEHICLEAUS => com.ibm.daimler.dsea.entityObject.EObjXVehicleAus)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue1<EObjXVehicleAus>> getXVehicleAusHistory (Object[] parameters)
  {
    return queryIterator (getXVehicleAusHistoryStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getXVehicleAusHistoryStatementDescriptor = createStatementDescriptor (
    "getXVehicleAusHistory(Object[])",
    "SELECT r.H_XVehicle_Auspk_Id hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.XVehicle_Auspk_Id XVehicle_Auspk_Id, r.GLOBAL_VIN GLOBAL_VIN, r.AMG_VEH AMG_VEH, r.VEHICLE_TYPE VEHICLE_TYPE, r.CLASS_SUMMARY CLASS_SUMMARY, r.ODOMETER ODOMETER, r.ENGINE_NUM ENGINE_NUM, r.VEHICLE_YEAR VEHICLE_YEAR, r.MODEL MODEL, r.REG_NO REG_NO, r.VEHICLE_CLASS VEHICLE_CLASS, r.COMM_NO COMM_NO, r.MARKET_NAME MARKET_NAME, r.CIRCLE_OF_EXCELLENCE CIRCLE_OF_EXCELLENCE, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XVEHICLEAUS r WHERE r.H_XVehicle_Auspk_Id = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"historyidpk", "h_action_code", "h_created_by", "h_create_dt", "h_end_dt", "xvehicle_auspk_id", "global_vin", "amg_veh", "vehicle_type", "class_summary", "odometer", "engine_num", "vehicle_year", "model", "reg_no", "vehicle_class", "comm_no", "market_name", "circle_of_excellence", "source_ident_tp_cd", "modify_sys_dt", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetXVehicleAusHistoryParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP}, {19, 0, 0}, {0, 0, 0}, {1, 1, 1}},
    null,
    new GetXVehicleAusHistoryRowHandler (),
    new int[][]{ {Types.BIGINT, Types.CHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 1, 20, 0, 0, 19, 50, 5, 50, 250, 250, 50, 0, 250, 50, 100, 100, 10, 250, 19, 0, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    2);

  /**
   * @generated
   */
  public static class GetXVehicleAusHistoryParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetXVehicleAusHistoryRowHandler extends BaseRowHandler<ResultQueue1<EObjXVehicleAus>>
  {
    /**
     * @generated
     */
    public ResultQueue1<EObjXVehicleAus> handle (java.sql.ResultSet rs, ResultQueue1<EObjXVehicleAus> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue1<EObjXVehicleAus> ();

      EObjXVehicleAus returnObject1 = new EObjXVehicleAus ();
      returnObject1.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject1.setHistActionCode(getString (rs, 2)); 
      returnObject1.setHistCreatedBy(getString (rs, 3)); 
      returnObject1.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject1.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject1.setXVehicleAuspkId(getLongObject (rs, 6)); 
      returnObject1.setGlobalVIN(getString (rs, 7)); 
      returnObject1.setAmgVehicle(getString (rs, 8)); 
      returnObject1.setVehicleType(getString (rs, 9)); 
      returnObject1.setClassSummary(getString (rs, 10)); 
      returnObject1.setOdoMeter(getString (rs, 11)); 
      returnObject1.setEngineNum(getString (rs, 12)); 
      returnObject1.setVehicleYear(getTimestamp (rs, 13)); 
      returnObject1.setModel(getString (rs, 14)); 
      returnObject1.setRegNum(getString (rs, 15)); 
      returnObject1.setVehicleClass(getString (rs, 16)); 
      returnObject1.setCommNo(getString (rs, 17)); 
      returnObject1.setMarketName(getString (rs, 18)); 
      returnObject1.setCircleOfExcellence(getString (rs, 19)); 
      returnObject1.setSourceIdentifier(getLongObject (rs, 20)); 
      returnObject1.setLastModifiedSystemDate(getTimestamp (rs, 21)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 22)); 
      returnObject1.setLastUpdateUser(getString (rs, 23)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 24)); 
      returnObject.add (returnObject1);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT r.XVehicle_Auspk_Id XVehicle_Auspk_Id, r.GLOBAL_VIN GLOBAL_VIN, r.AMG_VEH AMG_VEH, r.VEHICLE_TYPE VEHICLE_TYPE, r.CLASS_SUMMARY CLASS_SUMMARY, r.ODOMETER ODOMETER, r.ENGINE_NUM ENGINE_NUM, r.VEHICLE_YEAR VEHICLE_YEAR, r.MODEL MODEL, r.REG_NO REG_NO, r.VEHICLE_CLASS VEHICLE_CLASS, r.COMM_NO COMM_NO, r.MARKET_NAME MARKET_NAME, r.CIRCLE_OF_EXCELLENCE CIRCLE_OF_EXCELLENCE, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XVEHICLEAUS r WHERE r.GLOBAL_VIN = ?  AND r.MARKET_NAME = ? ", pattern="tableAlias (XVEHICLEAUS => com.ibm.daimler.dsea.entityObject.EObjXVehicleAus, H_XVEHICLEAUS => com.ibm.daimler.dsea.entityObject.EObjXVehicleAus)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue1<EObjXVehicleAus>> getXvehicleAusByGlobalVINAndMarketName (Object[] parameters)
  {
    return queryIterator (getXvehicleAusByGlobalVINAndMarketNameStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getXvehicleAusByGlobalVINAndMarketNameStatementDescriptor = createStatementDescriptor (
    "getXvehicleAusByGlobalVINAndMarketName(Object[])",
    "SELECT r.XVehicle_Auspk_Id XVehicle_Auspk_Id, r.GLOBAL_VIN GLOBAL_VIN, r.AMG_VEH AMG_VEH, r.VEHICLE_TYPE VEHICLE_TYPE, r.CLASS_SUMMARY CLASS_SUMMARY, r.ODOMETER ODOMETER, r.ENGINE_NUM ENGINE_NUM, r.VEHICLE_YEAR VEHICLE_YEAR, r.MODEL MODEL, r.REG_NO REG_NO, r.VEHICLE_CLASS VEHICLE_CLASS, r.COMM_NO COMM_NO, r.MARKET_NAME MARKET_NAME, r.CIRCLE_OF_EXCELLENCE CIRCLE_OF_EXCELLENCE, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XVEHICLEAUS r WHERE r.GLOBAL_VIN = ?  AND r.MARKET_NAME = ? ",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"xvehicle_auspk_id", "global_vin", "amg_veh", "vehicle_type", "class_summary", "odometer", "engine_num", "vehicle_year", "model", "reg_no", "vehicle_class", "comm_no", "market_name", "circle_of_excellence", "source_ident_tp_cd", "modify_sys_dt", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetXvehicleAusByGlobalVINAndMarketNameParameterHandler (),
    new int[][]{{Types.VARCHAR, Types.VARCHAR}, {50, 10}, {0, 0}, {1, 1}},
    null,
    new GetXvehicleAusByGlobalVINAndMarketNameRowHandler (),
    new int[][]{ {Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 50, 5, 50, 250, 250, 50, 0, 250, 50, 100, 100, 10, 250, 19, 0, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    3);

  /**
   * @generated
   */
  public static class GetXvehicleAusByGlobalVINAndMarketNameParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.VARCHAR, parameters[0], 0);
      setObject (stmt, 2, Types.VARCHAR, parameters[1], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetXvehicleAusByGlobalVINAndMarketNameRowHandler extends BaseRowHandler<ResultQueue1<EObjXVehicleAus>>
  {
    /**
     * @generated
     */
    public ResultQueue1<EObjXVehicleAus> handle (java.sql.ResultSet rs, ResultQueue1<EObjXVehicleAus> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue1<EObjXVehicleAus> ();

      EObjXVehicleAus returnObject1 = new EObjXVehicleAus ();
      returnObject1.setXVehicleAuspkId(getLongObject (rs, 1)); 
      returnObject1.setGlobalVIN(getString (rs, 2)); 
      returnObject1.setAmgVehicle(getString (rs, 3)); 
      returnObject1.setVehicleType(getString (rs, 4)); 
      returnObject1.setClassSummary(getString (rs, 5)); 
      returnObject1.setOdoMeter(getString (rs, 6)); 
      returnObject1.setEngineNum(getString (rs, 7)); 
      returnObject1.setVehicleYear(getTimestamp (rs, 8)); 
      returnObject1.setModel(getString (rs, 9)); 
      returnObject1.setRegNum(getString (rs, 10)); 
      returnObject1.setVehicleClass(getString (rs, 11)); 
      returnObject1.setCommNo(getString (rs, 12)); 
      returnObject1.setMarketName(getString (rs, 13)); 
      returnObject1.setCircleOfExcellence(getString (rs, 14)); 
      returnObject1.setSourceIdentifier(getLongObject (rs, 15)); 
      returnObject1.setLastModifiedSystemDate(getTimestamp (rs, 16)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 17)); 
      returnObject1.setLastUpdateUser(getString (rs, 18)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 19)); 
      returnObject.add (returnObject1);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT r.H_XVehicle_Auspk_Id hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.XVehicle_Auspk_Id XVehicle_Auspk_Id, r.GLOBAL_VIN GLOBAL_VIN, r.AMG_VEH AMG_VEH, r.VEHICLE_TYPE VEHICLE_TYPE, r.CLASS_SUMMARY CLASS_SUMMARY, r.ODOMETER ODOMETER, r.ENGINE_NUM ENGINE_NUM, r.VEHICLE_YEAR VEHICLE_YEAR, r.MODEL MODEL, r.REG_NO REG_NO, r.VEHICLE_CLASS VEHICLE_CLASS, r.COMM_NO COMM_NO, r.MARKET_NAME MARKET_NAME, r.CIRCLE_OF_EXCELLENCE CIRCLE_OF_EXCELLENCE, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XVEHICLEAUS r WHERE r.GLOBAL_VIN = ?  AND r.MARKET_NAME = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))", pattern="tableAlias (XVEHICLEAUS => com.ibm.daimler.dsea.entityObject.EObjXVehicleAus, H_XVEHICLEAUS => com.ibm.daimler.dsea.entityObject.EObjXVehicleAus)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue1<EObjXVehicleAus>> getXvehicleAusByGlobalVINAndMarketNameHistory (Object[] parameters)
  {
    return queryIterator (getXvehicleAusByGlobalVINAndMarketNameHistoryStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getXvehicleAusByGlobalVINAndMarketNameHistoryStatementDescriptor = createStatementDescriptor (
    "getXvehicleAusByGlobalVINAndMarketNameHistory(Object[])",
    "SELECT r.H_XVehicle_Auspk_Id hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.XVehicle_Auspk_Id XVehicle_Auspk_Id, r.GLOBAL_VIN GLOBAL_VIN, r.AMG_VEH AMG_VEH, r.VEHICLE_TYPE VEHICLE_TYPE, r.CLASS_SUMMARY CLASS_SUMMARY, r.ODOMETER ODOMETER, r.ENGINE_NUM ENGINE_NUM, r.VEHICLE_YEAR VEHICLE_YEAR, r.MODEL MODEL, r.REG_NO REG_NO, r.VEHICLE_CLASS VEHICLE_CLASS, r.COMM_NO COMM_NO, r.MARKET_NAME MARKET_NAME, r.CIRCLE_OF_EXCELLENCE CIRCLE_OF_EXCELLENCE, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XVEHICLEAUS r WHERE r.GLOBAL_VIN = ?  AND r.MARKET_NAME = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"historyidpk", "h_action_code", "h_created_by", "h_create_dt", "h_end_dt", "xvehicle_auspk_id", "global_vin", "amg_veh", "vehicle_type", "class_summary", "odometer", "engine_num", "vehicle_year", "model", "reg_no", "vehicle_class", "comm_no", "market_name", "circle_of_excellence", "source_ident_tp_cd", "modify_sys_dt", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetXvehicleAusByGlobalVINAndMarketNameHistoryParameterHandler (),
    new int[][]{{Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP}, {50, 10, 0, 0}, {0, 0, 0, 0}, {1, 1, 1, 1}},
    null,
    new GetXvehicleAusByGlobalVINAndMarketNameHistoryRowHandler (),
    new int[][]{ {Types.BIGINT, Types.CHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 1, 20, 0, 0, 19, 50, 5, 50, 250, 250, 50, 0, 250, 50, 100, 100, 10, 250, 19, 0, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    4);

  /**
   * @generated
   */
  public static class GetXvehicleAusByGlobalVINAndMarketNameHistoryParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.VARCHAR, parameters[0], 0);
      setObject (stmt, 2, Types.VARCHAR, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
      setObject (stmt, 4, Types.TIMESTAMP, parameters[3], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetXvehicleAusByGlobalVINAndMarketNameHistoryRowHandler extends BaseRowHandler<ResultQueue1<EObjXVehicleAus>>
  {
    /**
     * @generated
     */
    public ResultQueue1<EObjXVehicleAus> handle (java.sql.ResultSet rs, ResultQueue1<EObjXVehicleAus> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue1<EObjXVehicleAus> ();

      EObjXVehicleAus returnObject1 = new EObjXVehicleAus ();
      returnObject1.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject1.setHistActionCode(getString (rs, 2)); 
      returnObject1.setHistCreatedBy(getString (rs, 3)); 
      returnObject1.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject1.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject1.setXVehicleAuspkId(getLongObject (rs, 6)); 
      returnObject1.setGlobalVIN(getString (rs, 7)); 
      returnObject1.setAmgVehicle(getString (rs, 8)); 
      returnObject1.setVehicleType(getString (rs, 9)); 
      returnObject1.setClassSummary(getString (rs, 10)); 
      returnObject1.setOdoMeter(getString (rs, 11)); 
      returnObject1.setEngineNum(getString (rs, 12)); 
      returnObject1.setVehicleYear(getTimestamp (rs, 13)); 
      returnObject1.setModel(getString (rs, 14)); 
      returnObject1.setRegNum(getString (rs, 15)); 
      returnObject1.setVehicleClass(getString (rs, 16)); 
      returnObject1.setCommNo(getString (rs, 17)); 
      returnObject1.setMarketName(getString (rs, 18)); 
      returnObject1.setCircleOfExcellence(getString (rs, 19)); 
      returnObject1.setSourceIdentifier(getLongObject (rs, 20)); 
      returnObject1.setLastModifiedSystemDate(getTimestamp (rs, 21)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 22)); 
      returnObject1.setLastUpdateUser(getString (rs, 23)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 24)); 
      returnObject.add (returnObject1);

    
      return returnObject;
    }
  }

}
