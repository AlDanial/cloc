/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[5e9532b4fd4f800b63b613374942ef7c]
 */

package com.ibm.daimler.dsea.entityObject;


import com.ibm.mdm.base.db.ResultQueue1;
import java.util.Iterator;
import com.ibm.mdm.base.db.EntityMapping;
import com.ibm.pdq.annotation.Select;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * @generated
 */
public interface XCustomerVehicleJPNInquiryData {
  
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String tableAliasString = "tableAlias (" + 
                                            "XCUSTOMERVEHICLEJPN => com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleJPN, " +
                                            "H_XCUSTOMERVEHICLEJPN => com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleJPN" +
                                            ")";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getXCustomerVehicleJPNSql = "SELECT r.XCustomer_Vehicle_JPNPK_ID XCustomer_Vehicle_JPNPK_ID, r.CONT_ID CONT_ID, r.VEHICLE_ID VEHICLE_ID, r.RETAILER_ID RETAILER_ID, r.CONNECTME_USAGE_TP_CD CONNECTME_USAGE_TP_CD, r.LICENSE_PLATE LICENSE_PLATE, r.VEHICLE_SALES_TP_CD VEHICLE_SALES_TP_CD, r.VEHICLE_USAGE_TP_CD VEHICLE_USAGE_TP_CD, r.VEHICLE_OWNERSHIP VEHICLE_OWNERSHIP, r.START_DT START_DT, r.END_DT END_DT, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.CUSTVEHRET_FLAG CUSTVEHRET_FLAG, r.DELETE_FLAG DELETE_FLAG, r.SFDC_ID SFDC_ID, r.SERVICE_NAME SERVICE_NAME, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XCUSTOMERVEHICLEJPN r WHERE r.XCustomer_Vehicle_JPNPK_ID = ? ";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXCustomerVehicleJPNParameters =
    "EObjXCustomerVehicleJPN.XCustomerVehicleJPNpkId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXCustomerVehicleJPNResults =
    "EObjXCustomerVehicleJPN.XCustomerVehicleJPNpkId," +
    "EObjXCustomerVehicleJPN.ContId," +
    "EObjXCustomerVehicleJPN.VehicleId," +
    "EObjXCustomerVehicleJPN.RetailerId," +
    "EObjXCustomerVehicleJPN.ConnectMeUsage," +
    "EObjXCustomerVehicleJPN.LicensePlate," +
    "EObjXCustomerVehicleJPN.VehicleSales," +
    "EObjXCustomerVehicleJPN.VehicleUsage," +
    "EObjXCustomerVehicleJPN.VehicleOwnerShip," +
    "EObjXCustomerVehicleJPN.StartDate," +
    "EObjXCustomerVehicleJPN.EndDate," +
    "EObjXCustomerVehicleJPN.SourceIdentifier," +
    "EObjXCustomerVehicleJPN.CustVehRetFlag," +
    "EObjXCustomerVehicleJPN.DeleteFlag," +
    "EObjXCustomerVehicleJPN.SFDCId," +
    "EObjXCustomerVehicleJPN.ServiceName," +
    "EObjXCustomerVehicleJPN.lastUpdateDt," +
    "EObjXCustomerVehicleJPN.lastUpdateUser," +
    "EObjXCustomerVehicleJPN.lastUpdateTxId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getXCustomerVehicleJPNHistorySql = "SELECT r.H_XCustomer_Vehicle_JPNPK_ID hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.XCustomer_Vehicle_JPNPK_ID XCustomer_Vehicle_JPNPK_ID, r.CONT_ID CONT_ID, r.VEHICLE_ID VEHICLE_ID, r.RETAILER_ID RETAILER_ID, r.CONNECTME_USAGE_TP_CD CONNECTME_USAGE_TP_CD, r.LICENSE_PLATE LICENSE_PLATE, r.VEHICLE_SALES_TP_CD VEHICLE_SALES_TP_CD, r.VEHICLE_USAGE_TP_CD VEHICLE_USAGE_TP_CD, r.VEHICLE_OWNERSHIP VEHICLE_OWNERSHIP, r.START_DT START_DT, r.END_DT END_DT, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.CUSTVEHRET_FLAG CUSTVEHRET_FLAG, r.DELETE_FLAG DELETE_FLAG, r.SFDC_ID SFDC_ID, r.SERVICE_NAME SERVICE_NAME, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XCUSTOMERVEHICLEJPN r WHERE r.H_XCustomer_Vehicle_JPNPK_ID = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXCustomerVehicleJPNHistoryParameters =
    "EObjXCustomerVehicleJPN.XCustomerVehicleJPNpkId," +
    "EObjXCustomerVehicleJPN.lastUpdateDt," +
    "EObjXCustomerVehicleJPN.lastUpdateDt";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXCustomerVehicleJPNHistoryResults =
    "EObjXCustomerVehicleJPN.historyIdPK," +
    "EObjXCustomerVehicleJPN.histActionCode," +
    "EObjXCustomerVehicleJPN.histCreatedBy," +
    "EObjXCustomerVehicleJPN.histCreateDt," +
    "EObjXCustomerVehicleJPN.histEndDt," +
    "EObjXCustomerVehicleJPN.XCustomerVehicleJPNpkId," +
    "EObjXCustomerVehicleJPN.ContId," +
    "EObjXCustomerVehicleJPN.VehicleId," +
    "EObjXCustomerVehicleJPN.RetailerId," +
    "EObjXCustomerVehicleJPN.ConnectMeUsage," +
    "EObjXCustomerVehicleJPN.LicensePlate," +
    "EObjXCustomerVehicleJPN.VehicleSales," +
    "EObjXCustomerVehicleJPN.VehicleUsage," +
    "EObjXCustomerVehicleJPN.VehicleOwnerShip," +
    "EObjXCustomerVehicleJPN.StartDate," +
    "EObjXCustomerVehicleJPN.EndDate," +
    "EObjXCustomerVehicleJPN.SourceIdentifier," +
    "EObjXCustomerVehicleJPN.CustVehRetFlag," +
    "EObjXCustomerVehicleJPN.DeleteFlag," +
    "EObjXCustomerVehicleJPN.SFDCId," +
    "EObjXCustomerVehicleJPN.ServiceName," +
    "EObjXCustomerVehicleJPN.lastUpdateDt," +
    "EObjXCustomerVehicleJPN.lastUpdateUser," +
    "EObjXCustomerVehicleJPN.lastUpdateTxId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getAllXCustomerVehicleJPNByPartyIdSql = "SELECT r.XCustomer_Vehicle_JPNPK_ID XCustomer_Vehicle_JPNPK_ID, r.CONT_ID CONT_ID, r.VEHICLE_ID VEHICLE_ID, r.RETAILER_ID RETAILER_ID, r.CONNECTME_USAGE_TP_CD CONNECTME_USAGE_TP_CD, r.LICENSE_PLATE LICENSE_PLATE, r.VEHICLE_SALES_TP_CD VEHICLE_SALES_TP_CD, r.VEHICLE_USAGE_TP_CD VEHICLE_USAGE_TP_CD, r.VEHICLE_OWNERSHIP VEHICLE_OWNERSHIP, r.START_DT START_DT, r.END_DT END_DT, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.CUSTVEHRET_FLAG CUSTVEHRET_FLAG, r.DELETE_FLAG DELETE_FLAG, r.SFDC_ID SFDC_ID, r.SERVICE_NAME SERVICE_NAME, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XCUSTOMERVEHICLEJPN r WHERE r.CONT_ID = ? ";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getAllXCustomerVehicleJPNByPartyIdParameters =
    "EObjXCustomerVehicleJPN.ContId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getAllXCustomerVehicleJPNByPartyIdResults =
    "EObjXCustomerVehicleJPN.XCustomerVehicleJPNpkId," +
    "EObjXCustomerVehicleJPN.ContId," +
    "EObjXCustomerVehicleJPN.VehicleId," +
    "EObjXCustomerVehicleJPN.RetailerId," +
    "EObjXCustomerVehicleJPN.ConnectMeUsage," +
    "EObjXCustomerVehicleJPN.LicensePlate," +
    "EObjXCustomerVehicleJPN.VehicleSales," +
    "EObjXCustomerVehicleJPN.VehicleUsage," +
    "EObjXCustomerVehicleJPN.VehicleOwnerShip," +
    "EObjXCustomerVehicleJPN.StartDate," +
    "EObjXCustomerVehicleJPN.EndDate," +
    "EObjXCustomerVehicleJPN.SourceIdentifier," +
    "EObjXCustomerVehicleJPN.CustVehRetFlag," +
    "EObjXCustomerVehicleJPN.DeleteFlag," +
    "EObjXCustomerVehicleJPN.SFDCId," +
    "EObjXCustomerVehicleJPN.ServiceName," +
    "EObjXCustomerVehicleJPN.lastUpdateDt," +
    "EObjXCustomerVehicleJPN.lastUpdateUser," +
    "EObjXCustomerVehicleJPN.lastUpdateTxId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getAllXCustomerVehicleJPNByPartyIdHistorySql = "SELECT r.H_XCustomer_Vehicle_JPNPK_ID hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.XCustomer_Vehicle_JPNPK_ID XCustomer_Vehicle_JPNPK_ID, r.CONT_ID CONT_ID, r.VEHICLE_ID VEHICLE_ID, r.RETAILER_ID RETAILER_ID, r.CONNECTME_USAGE_TP_CD CONNECTME_USAGE_TP_CD, r.LICENSE_PLATE LICENSE_PLATE, r.VEHICLE_SALES_TP_CD VEHICLE_SALES_TP_CD, r.VEHICLE_USAGE_TP_CD VEHICLE_USAGE_TP_CD, r.VEHICLE_OWNERSHIP VEHICLE_OWNERSHIP, r.START_DT START_DT, r.END_DT END_DT, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.CUSTVEHRET_FLAG CUSTVEHRET_FLAG, r.DELETE_FLAG DELETE_FLAG, r.SFDC_ID SFDC_ID, r.SERVICE_NAME SERVICE_NAME, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XCUSTOMERVEHICLEJPN r WHERE r.CONT_ID = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getAllXCustomerVehicleJPNByPartyIdHistoryParameters =
    "EObjXCustomerVehicleJPN.ContId," +
    "EObjXCustomerVehicleJPN.lastUpdateDt," +
    "EObjXCustomerVehicleJPN.lastUpdateDt";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getAllXCustomerVehicleJPNByPartyIdHistoryResults =
    "EObjXCustomerVehicleJPN.historyIdPK," +
    "EObjXCustomerVehicleJPN.histActionCode," +
    "EObjXCustomerVehicleJPN.histCreatedBy," +
    "EObjXCustomerVehicleJPN.histCreateDt," +
    "EObjXCustomerVehicleJPN.histEndDt," +
    "EObjXCustomerVehicleJPN.XCustomerVehicleJPNpkId," +
    "EObjXCustomerVehicleJPN.ContId," +
    "EObjXCustomerVehicleJPN.VehicleId," +
    "EObjXCustomerVehicleJPN.RetailerId," +
    "EObjXCustomerVehicleJPN.ConnectMeUsage," +
    "EObjXCustomerVehicleJPN.LicensePlate," +
    "EObjXCustomerVehicleJPN.VehicleSales," +
    "EObjXCustomerVehicleJPN.VehicleUsage," +
    "EObjXCustomerVehicleJPN.VehicleOwnerShip," +
    "EObjXCustomerVehicleJPN.StartDate," +
    "EObjXCustomerVehicleJPN.EndDate," +
    "EObjXCustomerVehicleJPN.SourceIdentifier," +
    "EObjXCustomerVehicleJPN.CustVehRetFlag," +
    "EObjXCustomerVehicleJPN.DeleteFlag," +
    "EObjXCustomerVehicleJPN.SFDCId," +
    "EObjXCustomerVehicleJPN.ServiceName," +
    "EObjXCustomerVehicleJPN.lastUpdateDt," +
    "EObjXCustomerVehicleJPN.lastUpdateUser," +
    "EObjXCustomerVehicleJPN.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getAllCVRByVehicleIdSql = "SELECT r.XCustomer_Vehicle_JPNPK_ID XCustomer_Vehicle_JPNPK_ID, r.CONT_ID CONT_ID, r.VEHICLE_ID VEHICLE_ID, r.RETAILER_ID RETAILER_ID, r.CONNECTME_USAGE_TP_CD CONNECTME_USAGE_TP_CD, r.LICENSE_PLATE LICENSE_PLATE, r.VEHICLE_SALES_TP_CD VEHICLE_SALES_TP_CD, r.VEHICLE_USAGE_TP_CD VEHICLE_USAGE_TP_CD, r.VEHICLE_OWNERSHIP VEHICLE_OWNERSHIP, r.START_DT START_DT, r.END_DT END_DT, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.CUSTVEHRET_FLAG CUSTVEHRET_FLAG, r.DELETE_FLAG DELETE_FLAG, r.SFDC_ID SFDC_ID, r.SERVICE_NAME SERVICE_NAME, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XCUSTOMERVEHICLEJPN r WHERE r.VEHICLE_ID = ? ";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getAllCVRByVehicleIdParameters =
    "EObjXCustomerVehicleJPN.VehicleId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getAllCVRByVehicleIdResults =
    "EObjXCustomerVehicleJPN.XCustomerVehicleJPNpkId," +
    "EObjXCustomerVehicleJPN.ContId," +
    "EObjXCustomerVehicleJPN.VehicleId," +
    "EObjXCustomerVehicleJPN.RetailerId," +
    "EObjXCustomerVehicleJPN.ConnectMeUsage," +
    "EObjXCustomerVehicleJPN.LicensePlate," +
    "EObjXCustomerVehicleJPN.VehicleSales," +
    "EObjXCustomerVehicleJPN.VehicleUsage," +
    "EObjXCustomerVehicleJPN.VehicleOwnerShip," +
    "EObjXCustomerVehicleJPN.StartDate," +
    "EObjXCustomerVehicleJPN.EndDate," +
    "EObjXCustomerVehicleJPN.SourceIdentifier," +
    "EObjXCustomerVehicleJPN.CustVehRetFlag," +
    "EObjXCustomerVehicleJPN.DeleteFlag," +
    "EObjXCustomerVehicleJPN.SFDCId," +
    "EObjXCustomerVehicleJPN.ServiceName," +
    "EObjXCustomerVehicleJPN.lastUpdateDt," +
    "EObjXCustomerVehicleJPN.lastUpdateUser," +
    "EObjXCustomerVehicleJPN.lastUpdateTxId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getAllCVRByVehicleIdHistorySql = "SELECT r.H_XCustomer_Vehicle_JPNPK_ID hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.XCustomer_Vehicle_JPNPK_ID XCustomer_Vehicle_JPNPK_ID, r.CONT_ID CONT_ID, r.VEHICLE_ID VEHICLE_ID, r.RETAILER_ID RETAILER_ID, r.CONNECTME_USAGE_TP_CD CONNECTME_USAGE_TP_CD, r.LICENSE_PLATE LICENSE_PLATE, r.VEHICLE_SALES_TP_CD VEHICLE_SALES_TP_CD, r.VEHICLE_USAGE_TP_CD VEHICLE_USAGE_TP_CD, r.VEHICLE_OWNERSHIP VEHICLE_OWNERSHIP, r.START_DT START_DT, r.END_DT END_DT, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.CUSTVEHRET_FLAG CUSTVEHRET_FLAG, r.DELETE_FLAG DELETE_FLAG, r.SFDC_ID SFDC_ID, r.SERVICE_NAME SERVICE_NAME, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XCUSTOMERVEHICLEJPN r WHERE r.VEHICLE_ID = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getAllCVRByVehicleIdHistoryParameters =
    "EObjXCustomerVehicleJPN.VehicleId," +
    "EObjXCustomerVehicleJPN.lastUpdateDt," +
    "EObjXCustomerVehicleJPN.lastUpdateDt";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getAllCVRByVehicleIdHistoryResults =
    "EObjXCustomerVehicleJPN.historyIdPK," +
    "EObjXCustomerVehicleJPN.histActionCode," +
    "EObjXCustomerVehicleJPN.histCreatedBy," +
    "EObjXCustomerVehicleJPN.histCreateDt," +
    "EObjXCustomerVehicleJPN.histEndDt," +
    "EObjXCustomerVehicleJPN.XCustomerVehicleJPNpkId," +
    "EObjXCustomerVehicleJPN.ContId," +
    "EObjXCustomerVehicleJPN.VehicleId," +
    "EObjXCustomerVehicleJPN.RetailerId," +
    "EObjXCustomerVehicleJPN.ConnectMeUsage," +
    "EObjXCustomerVehicleJPN.LicensePlate," +
    "EObjXCustomerVehicleJPN.VehicleSales," +
    "EObjXCustomerVehicleJPN.VehicleUsage," +
    "EObjXCustomerVehicleJPN.VehicleOwnerShip," +
    "EObjXCustomerVehicleJPN.StartDate," +
    "EObjXCustomerVehicleJPN.EndDate," +
    "EObjXCustomerVehicleJPN.SourceIdentifier," +
    "EObjXCustomerVehicleJPN.CustVehRetFlag," +
    "EObjXCustomerVehicleJPN.DeleteFlag," +
    "EObjXCustomerVehicleJPN.SFDCId," +
    "EObjXCustomerVehicleJPN.ServiceName," +
    "EObjXCustomerVehicleJPN.lastUpdateDt," +
    "EObjXCustomerVehicleJPN.lastUpdateUser," +
    "EObjXCustomerVehicleJPN.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getXCustomerVehicleJPNSql, pattern=tableAliasString)
  @EntityMapping(parameters=getXCustomerVehicleJPNParameters, results=getXCustomerVehicleJPNResults)
  Iterator<ResultQueue1<EObjXCustomerVehicleJPN>> getXCustomerVehicleJPN(Object[] parameters);  


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getXCustomerVehicleJPNHistorySql, pattern=tableAliasString)
  @EntityMapping(parameters=getXCustomerVehicleJPNHistoryParameters, results=getXCustomerVehicleJPNHistoryResults)
  Iterator<ResultQueue1<EObjXCustomerVehicleJPN>> getXCustomerVehicleJPNHistory(Object[] parameters);  


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getAllXCustomerVehicleJPNByPartyIdSql, pattern=tableAliasString)
  @EntityMapping(parameters=getAllXCustomerVehicleJPNByPartyIdParameters, results=getAllXCustomerVehicleJPNByPartyIdResults)
  Iterator<ResultQueue1<EObjXCustomerVehicleJPN>> getAllXCustomerVehicleJPNByPartyId(Object[] parameters);  


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getAllXCustomerVehicleJPNByPartyIdHistorySql, pattern=tableAliasString)
  @EntityMapping(parameters=getAllXCustomerVehicleJPNByPartyIdHistoryParameters, results=getAllXCustomerVehicleJPNByPartyIdHistoryResults)
  Iterator<ResultQueue1<EObjXCustomerVehicleJPN>> getAllXCustomerVehicleJPNByPartyIdHistory(Object[] parameters);


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getAllCVRByVehicleIdSql, pattern=tableAliasString)
  @EntityMapping(parameters=getAllCVRByVehicleIdParameters, results=getAllCVRByVehicleIdResults)
  Iterator<ResultQueue1<EObjXCustomerVehicleJPN>> getAllCVRByVehicleId(Object[] parameters);


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getAllCVRByVehicleIdHistorySql, pattern=tableAliasString)
  @EntityMapping(parameters=getAllCVRByVehicleIdHistoryParameters, results=getAllCVRByVehicleIdHistoryResults)
  Iterator<ResultQueue1<EObjXCustomerVehicleJPN>> getAllCVRByVehicleIdHistory(Object[] parameters);  


}


