/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[a4619ecd41ef05213c47313863d1aa75]
 */
package com.ibm.daimler.dsea.entityObject;


import com.ibm.mdm.base.db.EntityMapping;
import com.ibm.pdq.annotation.Select;


import com.dwl.tcrm.financial.entityObject.EObjContractRole;

import com.ibm.mdm.base.db.ResultQueue2;

import java.util.Iterator;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * 
 * @generated
 */
public interface XContractRoleExtInquiryData {

  /**
   * MDM_TODO: CDKWB0050I The generated parameter and result lists in this file should be checked to ensure that each matches its
   * associated SQL query. Each list entry must be comma separated and identify a field within an entity object class.
   */ 
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */ 
   public final static String tableAliasString1 = "tableAlias (" + 
     "CONTRACTROLE => com.dwl.tcrm.financial.entityObject.EObjContractRole, " + 
     "H_CONTRACTROLE => com.dwl.tcrm.financial.entityObject.EObjContractRole , " + 
     "CONTRACTROLE => com.ibm.daimler.dsea.entityObject.EObjXContractRoleExt , " + 
     "H_CONTRACTROLE => com.ibm.daimler.dsea.entityObject.EObjXContractRoleExt" + 
     ")";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension
   * XContractRole.
   *
   * @generated
   */ 
   public final static String getEObjCONTRACT_PARTY_ROLES_BY_CONTRACT_ID_HISTORYSQL = "SELECT A.H_CONTRACT_ROLE_ID AS HIST_ID_PK , A.H_ACTION_CODE , A.H_CREATED_BY , A.H_CREATE_DT , A.H_END_DT , A.CONTRACT_ROLE_ID , A.CONT_ID , A.CONTR_COMPONENT_ID , A.CONTR_ROLE_TP_CD , A.DISTRIB_PCT , A.IRREVOC_IND , A.START_DT , A.END_DT , A.REGISTERED_NAME , A.RECORDED_START_DT , A.RECORDED_END_DT , A.LAST_UPDATE_DT , A.LAST_UPDATE_USER , A.ARRANGEMENT_TP_CD , A.SHARE_DIST_TP_CD , A.END_REASON_TP_CD , A.LAST_UPDATE_TX_ID , A.ARRANGEMENT_DESC, A.XSOURCE_IDENT_TP_CD" + 
     " FROM H_CONTRACTROLE A" + 
     " WHERE A.CONTR_COMPONENT_ID IN (SELECT H_CONTRACTCOMPONEN.CONTR_COMPONENT_ID" + 
     " FROM H_CONTRACTCOMPONEN" + 
     " WHERE CONTRACT_ID = ?) AND (H_CREATE_DT BETWEEN ? AND ?)";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjCONTRACT_PARTY_ROLES_BY_CONTRACT_ID_HISTORYParameters =
    "com.dwl.tcrm.financial.entityObject.EObjContractComponent.contractId=CONTRACT_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractComponent.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractComponent.histCreateDt=H_CREATE_DT"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjCONTRACT_PARTY_ROLES_BY_CONTRACT_ID_HISTORYResults =
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.historyIdPK=HIST_ID_PK," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.histActionCode=H_ACTION_CODE," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.histCreatedBy=H_CREATED_BY," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.histEndDt=H_END_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.contractRoleIdPK=CONTRACT_ROLE_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.contId=CONT_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.contrComponentId=CONTR_COMPONENT_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.contractRoleTpCd=CONTR_ROLE_TP_CD," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.distribPct=DISTRIB_PCT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.irrevocInd=IRREVOC_IND," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.startDt=START_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.endDt=END_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.registeredName=REGISTERED_NAME," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.recordedStartDt=RECORDED_START_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.recordedEndDt=RECORDED_END_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.arrangementTpCd=ARRANGEMENT_TP_CD," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.shareDistTpCd=SHARE_DIST_TP_CD," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.endReasonTpCd=END_REASON_TP_CD," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.arrangementDesc=ARRANGEMENT_DESC," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContractRoleExt.XSourceIdentifier=XSOURCE_IDENT_TP_CD"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension
   * XContractRole.
   *
   * @generated
   */ 
   public final static String getEObjCONTRACT_PARTY_ROLE_BY_CONTRACT_WITHOUT_DATE_FILTER_HISTORYSQL = "SELECT A.H_CONTRACT_ROLE_ID AS HIST_ID_PK , A.H_ACTION_CODE , A.H_CREATED_BY , A.H_CREATE_DT , A.H_END_DT , A.CONTRACT_ROLE_ID , A.CONT_ID , A.CONTR_COMPONENT_ID , A.CONTR_ROLE_TP_CD , A.DISTRIB_PCT , A.IRREVOC_IND , A.START_DT , A.END_DT , A.REGISTERED_NAME , A.RECORDED_START_DT , A.RECORDED_END_DT , A.LAST_UPDATE_DT , A.LAST_UPDATE_USER , A.ARRANGEMENT_TP_CD , A.SHARE_DIST_TP_CD , A.END_REASON_TP_CD , A.LAST_UPDATE_TX_ID , A.ARRANGEMENT_DESC, A.XSOURCE_IDENT_TP_CD" + 
     " FROM H_CONTRACTROLE A" + 
     " WHERE A.CONTR_COMPONENT_ID IN (SELECT H_CONTRACTCOMPONEN.CONTR_COMPONENT_ID" + 
     " FROM H_CONTRACTCOMPONEN" + 
     " WHERE CONTRACT_ID = ?)";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjCONTRACT_PARTY_ROLE_BY_CONTRACT_WITHOUT_DATE_FILTER_HISTORYParameters =
    "com.dwl.tcrm.financial.entityObject.EObjContractComponent.contractId=CONTRACT_ID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjCONTRACT_PARTY_ROLE_BY_CONTRACT_WITHOUT_DATE_FILTER_HISTORYResults =
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.historyIdPK=HIST_ID_PK," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.histActionCode=H_ACTION_CODE," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.histCreatedBy=H_CREATED_BY," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.histEndDt=H_END_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.contractRoleIdPK=CONTRACT_ROLE_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.contId=CONT_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.contrComponentId=CONTR_COMPONENT_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.contractRoleTpCd=CONTR_ROLE_TP_CD," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.distribPct=DISTRIB_PCT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.irrevocInd=IRREVOC_IND," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.startDt=START_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.endDt=END_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.registeredName=REGISTERED_NAME," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.recordedStartDt=RECORDED_START_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.recordedEndDt=RECORDED_END_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.arrangementTpCd=ARRANGEMENT_TP_CD," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.shareDistTpCd=SHARE_DIST_TP_CD," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.endReasonTpCd=END_REASON_TP_CD," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.arrangementDesc=ARRANGEMENT_DESC," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContractRoleExt.XSourceIdentifier=XSOURCE_IDENT_TP_CD"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension
   * XContractRole.
   *
   * @generated
   */ 
   public final static String getEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_HISTORYSQL = "SELECT A.H_CONTRACT_ROLE_ID AS HIST_ID_PK , A.H_ACTION_CODE , A.H_CREATED_BY , A.H_CREATE_DT , A.H_END_DT , A.CONTRACT_ROLE_ID , A.CONT_ID , A.CONTR_COMPONENT_ID , A.CONTR_ROLE_TP_CD , A.DISTRIB_PCT , A.IRREVOC_IND , A.START_DT , A.END_DT , A.REGISTERED_NAME , A.RECORDED_START_DT , A.RECORDED_END_DT , A.LAST_UPDATE_DT , A.LAST_UPDATE_USER , A.ARRANGEMENT_TP_CD , A.SHARE_DIST_TP_CD , A.END_REASON_TP_CD , A.LAST_UPDATE_TX_ID , A.ARRANGEMENT_DESC, A.XSOURCE_IDENT_TP_CD" + 
     " FROM H_CONTRACTROLE A" + 
     " WHERE A.CONT_ID = ? AND (A.H_CREATE_DT BETWEEN ? AND ? )";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_HISTORYParameters =
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.contId=CONT_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.histCreateDt=H_CREATE_DT"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_HISTORYResults =
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.historyIdPK=HIST_ID_PK," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.histActionCode=H_ACTION_CODE," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.histCreatedBy=H_CREATED_BY," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.histEndDt=H_END_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.contractRoleIdPK=CONTRACT_ROLE_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.contId=CONT_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.contrComponentId=CONTR_COMPONENT_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.contractRoleTpCd=CONTR_ROLE_TP_CD," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.distribPct=DISTRIB_PCT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.irrevocInd=IRREVOC_IND," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.startDt=START_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.endDt=END_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.registeredName=REGISTERED_NAME," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.recordedStartDt=RECORDED_START_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.recordedEndDt=RECORDED_END_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.arrangementTpCd=ARRANGEMENT_TP_CD," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.shareDistTpCd=SHARE_DIST_TP_CD," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.endReasonTpCd=END_REASON_TP_CD," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.arrangementDesc=ARRANGEMENT_DESC," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContractRoleExt.XSourceIdentifier=XSOURCE_IDENT_TP_CD"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension
   * XContractRole.
   *
   * @generated
   */ 
   public final static String getEObjCONTRACT_PARTY_ROLES_HISTORYSQL = "SELECT DISTINCT A.H_CONTRACT_ROLE_ID AS HIST_ID_PK , A.H_ACTION_CODE , A.H_CREATED_BY , A.H_CREATE_DT , A.H_END_DT , A.CONTRACT_ROLE_ID , A.CONT_ID , A.CONTR_COMPONENT_ID , A.CONTR_ROLE_TP_CD , A.DISTRIB_PCT , A.IRREVOC_IND , A.START_DT , A.END_DT , A.REGISTERED_NAME , A.RECORDED_START_DT , A.RECORDED_END_DT , A.LAST_UPDATE_DT , A.LAST_UPDATE_USER , A.ARRANGEMENT_TP_CD , A.SHARE_DIST_TP_CD , A.END_REASON_TP_CD , A.LAST_UPDATE_TX_ID ,A.ARRANGEMENT_DESC, A.XSOURCE_IDENT_TP_CD" + 
     " FROM H_CONTRACTROLE A" + 
     " WHERE A.CONTR_COMPONENT_ID = ? AND (? BETWEEN A.H_CREATE_DT AND A.H_END_DT OR ? >= A.H_CREATE_DT AND A.H_END_DT IS NULL )";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjCONTRACT_PARTY_ROLES_HISTORYParameters =
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.contrComponentId=CONTR_COMPONENT_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.histCreateDt=H_CREATE_DT"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjCONTRACT_PARTY_ROLES_HISTORYResults =
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.historyIdPK=HIST_ID_PK," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.histActionCode=H_ACTION_CODE," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.histCreatedBy=H_CREATED_BY," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.histEndDt=H_END_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.contractRoleIdPK=CONTRACT_ROLE_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.contId=CONT_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.contrComponentId=CONTR_COMPONENT_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.contractRoleTpCd=CONTR_ROLE_TP_CD," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.distribPct=DISTRIB_PCT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.irrevocInd=IRREVOC_IND," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.startDt=START_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.endDt=END_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.registeredName=REGISTERED_NAME," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.recordedStartDt=RECORDED_START_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.recordedEndDt=RECORDED_END_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.arrangementTpCd=ARRANGEMENT_TP_CD," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.shareDistTpCd=SHARE_DIST_TP_CD," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.endReasonTpCd=END_REASON_TP_CD," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.arrangementDesc=ARRANGEMENT_DESC," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContractRoleExt.XSourceIdentifier=XSOURCE_IDENT_TP_CD"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension
   * XContractRole.
   *
   * @generated
   */ 
   public final static String getEObjCONTRACT_PARTY_ROLES_ACTIVESQL = "SELECT CONTRACTROLE.CONTRACT_ROLE_ID , CONTRACTROLE.CONT_ID , CONTRACTROLE.CONTR_COMPONENT_ID , CONTRACTROLE.CONTR_ROLE_TP_CD , CONTRACTROLE.DISTRIB_PCT , CONTRACTROLE.IRREVOC_IND , CONTRACTROLE.START_DT , CONTRACTROLE.END_DT ,CONTRACTROLE.REGISTERED_NAME , CONTRACTROLE.RECORDED_START_DT , CONTRACTROLE.RECORDED_END_DT , CONTRACTROLE.LAST_UPDATE_DT , CONTRACTROLE.LAST_UPDATE_USER , CONTRACTROLE.ARRANGEMENT_TP_CD ,CONTRACTROLE.SHARE_DIST_TP_CD , CONTRACTROLE.END_REASON_TP_CD , CONTRACTROLE.LAST_UPDATE_TX_ID ,CONTRACTROLE.ARRANGEMENT_DESC, CONTRACTROLE.XSOURCE_IDENT_TP_CD" + 
     " FROM CONTRACTROLE" + 
     " WHERE (CONTRACTROLE.CONTR_COMPONENT_ID = ?) AND (CONTRACTROLE.END_DT IS NULL OR CONTRACTROLE.END_DT > ? )";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjCONTRACT_PARTY_ROLES_ACTIVEParameters =
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.contrComponentId=CONTR_COMPONENT_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.endDt=END_DT"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjCONTRACT_PARTY_ROLES_ACTIVEResults =
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.contractRoleIdPK=CONTRACT_ROLE_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.contId=CONT_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.contrComponentId=CONTR_COMPONENT_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.contractRoleTpCd=CONTR_ROLE_TP_CD," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.distribPct=DISTRIB_PCT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.irrevocInd=IRREVOC_IND," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.startDt=START_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.endDt=END_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.registeredName=REGISTERED_NAME," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.recordedStartDt=RECORDED_START_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.recordedEndDt=RECORDED_END_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.arrangementTpCd=ARRANGEMENT_TP_CD," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.shareDistTpCd=SHARE_DIST_TP_CD," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.endReasonTpCd=END_REASON_TP_CD," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.arrangementDesc=ARRANGEMENT_DESC," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContractRoleExt.XSourceIdentifier=XSOURCE_IDENT_TP_CD"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension
   * XContractRole.
   *
   * @generated
   */ 
   public final static String getEObjCONTRACT_PARTY_ROLES_INACTIVESQL = "SELECT CONTRACTROLE.CONTRACT_ROLE_ID , CONTRACTROLE.CONT_ID , CONTRACTROLE.CONTR_COMPONENT_ID , CONTRACTROLE.CONTR_ROLE_TP_CD , CONTRACTROLE.DISTRIB_PCT , CONTRACTROLE.IRREVOC_IND , CONTRACTROLE.START_DT , CONTRACTROLE.END_DT , CONTRACTROLE.REGISTERED_NAME , CONTRACTROLE.RECORDED_START_DT , CONTRACTROLE.RECORDED_END_DT ,CONTRACTROLE.LAST_UPDATE_DT , CONTRACTROLE.LAST_UPDATE_USER , CONTRACTROLE.ARRANGEMENT_TP_CD ,CONTRACTROLE.SHARE_DIST_TP_CD , CONTRACTROLE.END_REASON_TP_CD , CONTRACTROLE.LAST_UPDATE_TX_ID ,CONTRACTROLE.ARRANGEMENT_DESC, CONTRACTROLE.XSOURCE_IDENT_TP_CD" + 
     " FROM CONTRACTROLE" + 
     " WHERE CONTRACTROLE.CONTR_COMPONENT_ID = ? AND CONTRACTROLE.END_DT < ?";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjCONTRACT_PARTY_ROLES_INACTIVEParameters =
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.contrComponentId=CONTR_COMPONENT_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.endDt=END_DT"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjCONTRACT_PARTY_ROLES_INACTIVEResults =
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.contractRoleIdPK=CONTRACT_ROLE_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.contId=CONT_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.contrComponentId=CONTR_COMPONENT_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.contractRoleTpCd=CONTR_ROLE_TP_CD," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.distribPct=DISTRIB_PCT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.irrevocInd=IRREVOC_IND," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.startDt=START_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.endDt=END_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.registeredName=REGISTERED_NAME," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.recordedStartDt=RECORDED_START_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.recordedEndDt=RECORDED_END_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.arrangementTpCd=ARRANGEMENT_TP_CD," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.shareDistTpCd=SHARE_DIST_TP_CD," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.endReasonTpCd=END_REASON_TP_CD," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.arrangementDesc=ARRANGEMENT_DESC," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContractRoleExt.XSourceIdentifier=XSOURCE_IDENT_TP_CD"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension
   * XContractRole.
   *
   * @generated
   */ 
   public final static String getEObjCONTRACT_PARTY_ROLES_ALLSQL = "SELECT CONTRACTROLE.CONTRACT_ROLE_ID , CONTRACTROLE.CONT_ID , CONTRACTROLE.CONTR_COMPONENT_ID , CONTRACTROLE.CONTR_ROLE_TP_CD , CONTRACTROLE.DISTRIB_PCT , CONTRACTROLE.IRREVOC_IND , CONTRACTROLE.START_DT , CONTRACTROLE.END_DT , CONTRACTROLE.REGISTERED_NAME , CONTRACTROLE.RECORDED_START_DT , CONTRACTROLE.RECORDED_END_DT , CONTRACTROLE.LAST_UPDATE_DT , CONTRACTROLE.LAST_UPDATE_USER , CONTRACTROLE.ARRANGEMENT_TP_CD , CONTRACTROLE.SHARE_DIST_TP_CD , CONTRACTROLE.END_REASON_TP_CD ,CONTRACTROLE.LAST_UPDATE_TX_ID ,CONTRACTROLE.ARRANGEMENT_DESC, CONTRACTROLE.XSOURCE_IDENT_TP_CD" + 
     " FROM CONTRACTROLE" + 
     " WHERE CONTRACTROLE.CONTR_COMPONENT_ID = ?";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjCONTRACT_PARTY_ROLES_ALLParameters =
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.contrComponentId=CONTR_COMPONENT_ID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjCONTRACT_PARTY_ROLES_ALLResults =
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.contractRoleIdPK=CONTRACT_ROLE_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.contId=CONT_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.contrComponentId=CONTR_COMPONENT_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.contractRoleTpCd=CONTR_ROLE_TP_CD," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.distribPct=DISTRIB_PCT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.irrevocInd=IRREVOC_IND," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.startDt=START_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.endDt=END_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.registeredName=REGISTERED_NAME," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.recordedStartDt=RECORDED_START_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.recordedEndDt=RECORDED_END_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.arrangementTpCd=ARRANGEMENT_TP_CD," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.shareDistTpCd=SHARE_DIST_TP_CD," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.endReasonTpCd=END_REASON_TP_CD," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.arrangementDesc=ARRANGEMENT_DESC," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContractRoleExt.XSourceIdentifier=XSOURCE_IDENT_TP_CD"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension
   * XContractRole.
   *
   * @generated
   */ 
   public final static String getEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_AND_DATE_HISTORYSQL = "SELECT A.H_CONTRACT_ROLE_ID AS HIST_ID_PK , A.H_ACTION_CODE , A.H_CREATED_BY , A.H_CREATE_DT , A.H_END_DT , A.CONTRACT_ROLE_ID , A.CONT_ID , A.CONTR_COMPONENT_ID , A.CONTR_ROLE_TP_CD , A.DISTRIB_PCT , A.IRREVOC_IND , A.START_DT , A.END_DT , A.REGISTERED_NAME , A.RECORDED_START_DT , A.RECORDED_END_DT , A.LAST_UPDATE_DT , A.LAST_UPDATE_USER , A.ARRANGEMENT_TP_CD , A.SHARE_DIST_TP_CD , A.END_REASON_TP_CD , A.LAST_UPDATE_TX_ID , A.ARRANGEMENT_DESC, A.XSOURCE_IDENT_TP_CD" + 
     " FROM H_CONTRACTROLE A" + 
     " WHERE A.CONT_ID = ? AND (? BETWEEN A.H_CREATE_DT AND A.H_END_DT OR ? >= A.H_CREATE_DT AND A.H_END_DT IS NULL )";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_AND_DATE_HISTORYParameters =
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.contId=CONT_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.histCreateDt=H_CREATE_DT"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_AND_DATE_HISTORYResults =
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.historyIdPK=HIST_ID_PK," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.histActionCode=H_ACTION_CODE," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.histCreatedBy=H_CREATED_BY," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.histEndDt=H_END_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.contractRoleIdPK=CONTRACT_ROLE_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.contId=CONT_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.contrComponentId=CONTR_COMPONENT_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.contractRoleTpCd=CONTR_ROLE_TP_CD," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.distribPct=DISTRIB_PCT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.irrevocInd=IRREVOC_IND," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.startDt=START_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.endDt=END_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.registeredName=REGISTERED_NAME," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.recordedStartDt=RECORDED_START_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.recordedEndDt=RECORDED_END_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.arrangementTpCd=ARRANGEMENT_TP_CD," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.shareDistTpCd=SHARE_DIST_TP_CD," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.endReasonTpCd=END_REASON_TP_CD," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.arrangementDesc=ARRANGEMENT_DESC," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContractRoleExt.XSourceIdentifier=XSOURCE_IDENT_TP_CD"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension
   * XContractRole.
   *
   * @generated
   */ 
   public final static String getEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_ACTIVESQL = "SELECT CONTRACTROLE.CONTRACT_ROLE_ID , CONTRACTROLE.CONT_ID , CONTRACTROLE.CONTR_COMPONENT_ID , CONTRACTROLE.CONTR_ROLE_TP_CD , CONTRACTROLE.DISTRIB_PCT , CONTRACTROLE.IRREVOC_IND , CONTRACTROLE.START_DT , CONTRACTROLE.END_DT , CONTRACTROLE.REGISTERED_NAME , CONTRACTROLE.RECORDED_START_DT , CONTRACTROLE.RECORDED_END_DT , CONTRACTROLE.LAST_UPDATE_DT , CONTRACTROLE.LAST_UPDATE_USER , CONTRACTROLE.ARRANGEMENT_TP_CD , CONTRACTROLE.SHARE_DIST_TP_CD , CONTRACTROLE.END_REASON_TP_CD , CONTRACTROLE.LAST_UPDATE_TX_ID ,CONTRACTROLE.ARRANGEMENT_DESC, CONTRACTROLE.XSOURCE_IDENT_TP_CD" + 
     " FROM CONTRACTROLE" + 
     " WHERE CONTRACTROLE.CONT_ID = ? AND (CONTRACTROLE.END_DT IS NULL OR CONTRACTROLE.END_DT > ? )";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_ACTIVEParameters =
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.contId=CONT_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.endDt=END_DT"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_ACTIVEResults =
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.contractRoleIdPK=CONTRACT_ROLE_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.contId=CONT_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.contrComponentId=CONTR_COMPONENT_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.contractRoleTpCd=CONTR_ROLE_TP_CD," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.distribPct=DISTRIB_PCT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.irrevocInd=IRREVOC_IND," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.startDt=START_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.endDt=END_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.registeredName=REGISTERED_NAME," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.recordedStartDt=RECORDED_START_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.recordedEndDt=RECORDED_END_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.arrangementTpCd=ARRANGEMENT_TP_CD," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.shareDistTpCd=SHARE_DIST_TP_CD," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.endReasonTpCd=END_REASON_TP_CD," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.arrangementDesc=ARRANGEMENT_DESC," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContractRoleExt.XSourceIdentifier=XSOURCE_IDENT_TP_CD"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension
   * XContractRole.
   *
   * @generated
   */ 
   public final static String getEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_INACTIVESQL = "SELECT CONTRACTROLE.CONTRACT_ROLE_ID , CONTRACTROLE.CONT_ID , CONTRACTROLE.CONTR_COMPONENT_ID , CONTRACTROLE.CONTR_ROLE_TP_CD , CONTRACTROLE.DISTRIB_PCT , CONTRACTROLE.IRREVOC_IND , CONTRACTROLE.START_DT , CONTRACTROLE.END_DT , CONTRACTROLE.REGISTERED_NAME , CONTRACTROLE.RECORDED_START_DT , CONTRACTROLE.RECORDED_END_DT , CONTRACTROLE.LAST_UPDATE_DT , CONTRACTROLE.LAST_UPDATE_USER , CONTRACTROLE.ARRANGEMENT_TP_CD , CONTRACTROLE.SHARE_DIST_TP_CD , CONTRACTROLE.END_REASON_TP_CD ,CONTRACTROLE.LAST_UPDATE_TX_ID ,CONTRACTROLE.ARRANGEMENT_DESC, CONTRACTROLE.XSOURCE_IDENT_TP_CD" + 
     " FROM CONTRACTROLE" + 
     " WHERE CONTRACTROLE.CONT_ID = ? AND CONTRACTROLE.END_DT < ?";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_INACTIVEParameters =
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.contId=CONT_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.endDt=END_DT"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_INACTIVEResults =
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.contractRoleIdPK=CONTRACT_ROLE_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.contId=CONT_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.contrComponentId=CONTR_COMPONENT_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.contractRoleTpCd=CONTR_ROLE_TP_CD," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.distribPct=DISTRIB_PCT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.irrevocInd=IRREVOC_IND," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.startDt=START_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.endDt=END_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.registeredName=REGISTERED_NAME," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.recordedStartDt=RECORDED_START_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.recordedEndDt=RECORDED_END_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.arrangementTpCd=ARRANGEMENT_TP_CD," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.shareDistTpCd=SHARE_DIST_TP_CD," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.endReasonTpCd=END_REASON_TP_CD," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.arrangementDesc=ARRANGEMENT_DESC," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContractRoleExt.XSourceIdentifier=XSOURCE_IDENT_TP_CD"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension
   * XContractRole.
   *
   * @generated
   */ 
   public final static String getEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_ALLSQL = "SELECT CONTRACTROLE.CONTRACT_ROLE_ID , CONTRACTROLE.CONT_ID , CONTRACTROLE.CONTR_COMPONENT_ID , CONTRACTROLE.CONTR_ROLE_TP_CD , CONTRACTROLE.DISTRIB_PCT , CONTRACTROLE.IRREVOC_IND , CONTRACTROLE.START_DT , CONTRACTROLE.END_DT , CONTRACTROLE.REGISTERED_NAME , CONTRACTROLE.RECORDED_START_DT , CONTRACTROLE.RECORDED_END_DT , CONTRACTROLE.LAST_UPDATE_DT , CONTRACTROLE.LAST_UPDATE_USER , CONTRACTROLE.ARRANGEMENT_TP_CD ,CONTRACTROLE.SHARE_DIST_TP_CD , CONTRACTROLE.END_REASON_TP_CD , CONTRACTROLE.LAST_UPDATE_TX_ID ,CONTRACTROLE.ARRANGEMENT_DESC, CONTRACTROLE.XSOURCE_IDENT_TP_CD" + 
     " FROM CONTRACTROLE" + 
     " WHERE CONTRACTROLE.CONT_ID = ?";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_ALLParameters =
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.contId=CONT_ID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_ALLResults =
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.contractRoleIdPK=CONTRACT_ROLE_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.contId=CONT_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.contrComponentId=CONTR_COMPONENT_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.contractRoleTpCd=CONTR_ROLE_TP_CD," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.distribPct=DISTRIB_PCT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.irrevocInd=IRREVOC_IND," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.startDt=START_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.endDt=END_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.registeredName=REGISTERED_NAME," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.recordedStartDt=RECORDED_START_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.recordedEndDt=RECORDED_END_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.arrangementTpCd=ARRANGEMENT_TP_CD," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.shareDistTpCd=SHARE_DIST_TP_CD," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.endReasonTpCd=END_REASON_TP_CD," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.arrangementDesc=ARRANGEMENT_DESC," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContractRoleExt.XSourceIdentifier=XSOURCE_IDENT_TP_CD"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension
   * XContractRole.
   *
   * @generated
   */ 
   public final static String getEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_AND_COMPONENT_HISTORYSQL = "SELECT A.H_CONTRACT_ROLE_ID AS HIST_ID_PK , A.H_ACTION_CODE , A.H_CREATED_BY , A.H_CREATE_DT , A.H_END_DT , A.CONTRACT_ROLE_ID , A.CONT_ID , A.CONTR_COMPONENT_ID , A.CONTR_ROLE_TP_CD , A.DISTRIB_PCT , A.IRREVOC_IND , A.START_DT , A.END_DT , A.REGISTERED_NAME , A.RECORDED_START_DT , A.RECORDED_END_DT , A.LAST_UPDATE_DT , A.LAST_UPDATE_USER , A.ARRANGEMENT_TP_CD , A.SHARE_DIST_TP_CD , A.END_REASON_TP_CD , A.LAST_UPDATE_TX_ID, A.XSOURCE_IDENT_TP_CD" + 
     " FROM H_CONTRACTROLE A" + 
     " WHERE A.CONT_ID = ? AND A.CONTR_COMPONENT_ID = ? AND (? BETWEEN A.H_CREATE_DT AND A.H_END_DT OR ? >= A.H_CREATE_DT AND A.H_END_DT IS NULL)";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_AND_COMPONENT_HISTORYParameters =
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.contId=CONT_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.contrComponentId=CONTR_COMPONENT_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.histCreateDt=H_CREATE_DT"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_AND_COMPONENT_HISTORYResults =
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.historyIdPK=HIST_ID_PK," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.histActionCode=H_ACTION_CODE," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.histCreatedBy=H_CREATED_BY," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.histEndDt=H_END_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.contractRoleIdPK=CONTRACT_ROLE_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.contId=CONT_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.contrComponentId=CONTR_COMPONENT_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.contractRoleTpCd=CONTR_ROLE_TP_CD," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.distribPct=DISTRIB_PCT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.irrevocInd=IRREVOC_IND," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.startDt=START_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.endDt=END_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.registeredName=REGISTERED_NAME," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.recordedStartDt=RECORDED_START_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.recordedEndDt=RECORDED_END_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.arrangementTpCd=ARRANGEMENT_TP_CD," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.shareDistTpCd=SHARE_DIST_TP_CD," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.endReasonTpCd=END_REASON_TP_CD," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContractRoleExt.XSourceIdentifier=XSOURCE_IDENT_TP_CD"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension
   * XContractRole.
   *
   * @generated
   */ 
   public final static String getEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_AND_COMPONENT_ACTIVESQL = "SELECT CONTRACTROLE.CONTRACT_ROLE_ID , CONTRACTROLE.CONT_ID , CONTRACTROLE.CONTR_COMPONENT_ID , CONTRACTROLE.CONTR_ROLE_TP_CD , CONTRACTROLE.DISTRIB_PCT , CONTRACTROLE.IRREVOC_IND , CONTRACTROLE.START_DT , CONTRACTROLE.END_DT , CONTRACTROLE.REGISTERED_NAME , CONTRACTROLE.RECORDED_START_DT , CONTRACTROLE.RECORDED_END_DT , CONTRACTROLE.LAST_UPDATE_DT , CONTRACTROLE.LAST_UPDATE_USER , CONTRACTROLE.ARRANGEMENT_TP_CD ,CONTRACTROLE.SHARE_DIST_TP_CD , CONTRACTROLE.END_REASON_TP_CD , CONTRACTROLE.LAST_UPDATE_TX_ID ,CONTRACTROLE.ARRANGEMENT_DESC, CONTRACTROLE.XSOURCE_IDENT_TP_CD" + 
     " FROM CONTRACTROLE" + 
     " WHERE (CONTRACTROLE.CONT_ID = ?) AND (CONTRACTROLE.CONTR_COMPONENT_ID = ?) AND (CONTRACTROLE.END_DT IS NULL OR CONTRACTROLE.END_DT > ? )";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_AND_COMPONENT_ACTIVEParameters =
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.contId=CONT_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.contrComponentId=CONTR_COMPONENT_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.endDt=END_DT"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_AND_COMPONENT_ACTIVEResults =
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.contractRoleIdPK=CONTRACT_ROLE_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.contId=CONT_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.contrComponentId=CONTR_COMPONENT_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.contractRoleTpCd=CONTR_ROLE_TP_CD," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.distribPct=DISTRIB_PCT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.irrevocInd=IRREVOC_IND," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.startDt=START_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.endDt=END_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.registeredName=REGISTERED_NAME," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.recordedStartDt=RECORDED_START_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.recordedEndDt=RECORDED_END_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.arrangementTpCd=ARRANGEMENT_TP_CD," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.shareDistTpCd=SHARE_DIST_TP_CD," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.endReasonTpCd=END_REASON_TP_CD," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.arrangementDesc=ARRANGEMENT_DESC," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContractRoleExt.XSourceIdentifier=XSOURCE_IDENT_TP_CD"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension
   * XContractRole.
   *
   * @generated
   */ 
   public final static String getEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_AND_COMPONENT_ID_INACTIVESQL = "SELECT CONTRACTROLE.CONTRACT_ROLE_ID , CONTRACTROLE.CONT_ID , CONTRACTROLE.CONTR_COMPONENT_ID , CONTRACTROLE.CONTR_ROLE_TP_CD , CONTRACTROLE.DISTRIB_PCT , CONTRACTROLE.IRREVOC_IND , CONTRACTROLE.START_DT , CONTRACTROLE.END_DT ,CONTRACTROLE.REGISTERED_NAME , CONTRACTROLE.RECORDED_START_DT , CONTRACTROLE.RECORDED_END_DT , CONTRACTROLE.LAST_UPDATE_DT , CONTRACTROLE.LAST_UPDATE_USER , CONTRACTROLE.ARRANGEMENT_TP_CD ,CONTRACTROLE.SHARE_DIST_TP_CD , CONTRACTROLE.END_REASON_TP_CD , CONTRACTROLE.LAST_UPDATE_TX_ID , CONTRACTROLE.ARRANGEMENT_DESC, CONTRACTROLE.XSOURCE_IDENT_TP_CD" + 
     " FROM CONTRACTROLE" + 
     " WHERE (CONTRACTROLE.CONT_ID = ?) AND (CONTRACTROLE.CONTR_COMPONENT_ID = ?) AND (CONTRACTROLE.END_DT < ? )";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_AND_COMPONENT_ID_INACTIVEParameters =
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.contId=CONT_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.contrComponentId=CONTR_COMPONENT_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.endDt=END_DT"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_AND_COMPONENT_ID_INACTIVEResults =
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.contractRoleIdPK=CONTRACT_ROLE_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.contId=CONT_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.contrComponentId=CONTR_COMPONENT_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.contractRoleTpCd=CONTR_ROLE_TP_CD," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.distribPct=DISTRIB_PCT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.irrevocInd=IRREVOC_IND," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.startDt=START_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.endDt=END_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.registeredName=REGISTERED_NAME," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.recordedStartDt=RECORDED_START_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.recordedEndDt=RECORDED_END_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.arrangementTpCd=ARRANGEMENT_TP_CD," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.shareDistTpCd=SHARE_DIST_TP_CD," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.endReasonTpCd=END_REASON_TP_CD," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.arrangementDesc=ARRANGEMENT_DESC," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContractRoleExt.XSourceIdentifier=XSOURCE_IDENT_TP_CD"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension
   * XContractRole.
   *
   * @generated
   */ 
   public final static String getEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_AND_COMPONENT_ID_ALL_QUERY_RECORDSSQL = "SELECT CONTRACTROLE.CONTRACT_ROLE_ID , CONTRACTROLE.CONT_ID , CONTRACTROLE.CONTR_COMPONENT_ID , CONTRACTROLE.CONTR_ROLE_TP_CD , CONTRACTROLE.DISTRIB_PCT , CONTRACTROLE.IRREVOC_IND , CONTRACTROLE.START_DT , CONTRACTROLE.END_DT , CONTRACTROLE.REGISTERED_NAME , CONTRACTROLE.RECORDED_START_DT , CONTRACTROLE.RECORDED_END_DT , CONTRACTROLE.LAST_UPDATE_DT , CONTRACTROLE.LAST_UPDATE_USER , CONTRACTROLE.ARRANGEMENT_TP_CD , CONTRACTROLE.SHARE_DIST_TP_CD , CONTRACTROLE.END_REASON_TP_CD , CONTRACTROLE.LAST_UPDATE_TX_ID , CONTRACTROLE.ARRANGEMENT_DESC, CONTRACTROLE.XSOURCE_IDENT_TP_CD" + 
     " FROM CONTRACTROLE" + 
     " WHERE (CONTRACTROLE.CONT_ID = ?) AND (CONTRACTROLE.CONTR_COMPONENT_ID = ?)";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_AND_COMPONENT_ID_ALL_QUERY_RECORDSParameters =
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.contId=CONT_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.contrComponentId=CONTR_COMPONENT_ID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_AND_COMPONENT_ID_ALL_QUERY_RECORDSResults =
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.contractRoleIdPK=CONTRACT_ROLE_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.contId=CONT_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.contrComponentId=CONTR_COMPONENT_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.contractRoleTpCd=CONTR_ROLE_TP_CD," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.distribPct=DISTRIB_PCT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.irrevocInd=IRREVOC_IND," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.startDt=START_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.endDt=END_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.registeredName=REGISTERED_NAME," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.recordedStartDt=RECORDED_START_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.recordedEndDt=RECORDED_END_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.arrangementTpCd=ARRANGEMENT_TP_CD," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.shareDistTpCd=SHARE_DIST_TP_CD," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.endReasonTpCd=END_REASON_TP_CD," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.arrangementDesc=ARRANGEMENT_DESC," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContractRoleExt.XSourceIdentifier=XSOURCE_IDENT_TP_CD"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension
   * XContractRole.
   *
   * @generated
   */ 
   public final static String getEObjCONTRACT_PARTY_ROLE_HISTORYSQL = "SELECT A.H_CONTRACT_ROLE_ID AS HIST_ID_PK , A.H_ACTION_CODE , A.H_CREATED_BY , A.H_CREATE_DT , A.H_END_DT , A.CONTRACT_ROLE_ID , A.CONT_ID , A.CONTR_COMPONENT_ID , A.CONTR_ROLE_TP_CD , A.DISTRIB_PCT , A.IRREVOC_IND , A.START_DT , A.END_DT , A.REGISTERED_NAME , A.RECORDED_START_DT , A.RECORDED_END_DT , A.LAST_UPDATE_DT , A.LAST_UPDATE_USER , A.ARRANGEMENT_TP_CD , A.SHARE_DIST_TP_CD , A.END_REASON_TP_CD , A.LAST_UPDATE_TX_ID , A.ARRANGEMENT_DESC, A.XSOURCE_IDENT_TP_CD" + 
     " FROM H_CONTRACTROLE A" + 
     " WHERE A.H_CONTRACT_ROLE_ID = ? AND (? BETWEEN A.H_CREATE_DT AND A.H_END_DT OR ? >= A.H_CREATE_DT AND A.H_END_DT IS NULL )";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjCONTRACT_PARTY_ROLE_HISTORYParameters =
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.historyIdPK=H_CONTRACT_ROLE_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.histCreateDt=H_CREATE_DT"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjCONTRACT_PARTY_ROLE_HISTORYResults =
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.historyIdPK=HIST_ID_PK," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.histActionCode=H_ACTION_CODE," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.histCreatedBy=H_CREATED_BY," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.histCreateDt=H_CREATE_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.histEndDt=H_END_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.contractRoleIdPK=CONTRACT_ROLE_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.contId=CONT_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.contrComponentId=CONTR_COMPONENT_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.contractRoleTpCd=CONTR_ROLE_TP_CD," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.distribPct=DISTRIB_PCT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.irrevocInd=IRREVOC_IND," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.startDt=START_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.endDt=END_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.registeredName=REGISTERED_NAME," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.recordedStartDt=RECORDED_START_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.recordedEndDt=RECORDED_END_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.arrangementTpCd=ARRANGEMENT_TP_CD," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.shareDistTpCd=SHARE_DIST_TP_CD," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.endReasonTpCd=END_REASON_TP_CD," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.arrangementDesc=ARRANGEMENT_DESC," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContractRoleExt.XSourceIdentifier=XSOURCE_IDENT_TP_CD"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->	
   *
   * CDKWB0060I This SQL query has been modified to return additional fields defined by entity type extension
   * XContractRole.
   *
   * @generated
   */ 
   public final static String getEObjCONTRACT_PARTY_ROLESQL = "SELECT CONTRACTROLE.CONTRACT_ROLE_ID , CONTRACTROLE.CONT_ID , CONTRACTROLE.CONTR_COMPONENT_ID , CONTRACTROLE.CONTR_ROLE_TP_CD , CONTRACTROLE.DISTRIB_PCT , CONTRACTROLE.IRREVOC_IND , CONTRACTROLE.START_DT , CONTRACTROLE.END_DT , CONTRACTROLE.REGISTERED_NAME , CONTRACTROLE.RECORDED_START_DT , CONTRACTROLE.RECORDED_END_DT , CONTRACTROLE.LAST_UPDATE_DT , CONTRACTROLE.LAST_UPDATE_USER ,CONTRACTROLE.ARRANGEMENT_TP_CD ,CONTRACTROLE.SHARE_DIST_TP_CD , CONTRACTROLE.END_REASON_TP_CD , CONTRACTROLE.LAST_UPDATE_TX_ID ,CONTRACTROLE.ARRANGEMENT_DESC, CONTRACTROLE.XSOURCE_IDENT_TP_CD" + 
     " FROM CONTRACTROLE" + 
     " WHERE CONTRACTROLE.CONTRACT_ROLE_ID = ?";
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjCONTRACT_PARTY_ROLEParameters =
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.contractRoleIdPK=CONTRACT_ROLE_ID"; 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjCONTRACT_PARTY_ROLEResults =
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.contractRoleIdPK=CONTRACT_ROLE_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.contId=CONT_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.contrComponentId=CONTR_COMPONENT_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.contractRoleTpCd=CONTR_ROLE_TP_CD," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.distribPct=DISTRIB_PCT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.irrevocInd=IRREVOC_IND," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.startDt=START_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.endDt=END_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.registeredName=REGISTERED_NAME," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.recordedStartDt=RECORDED_START_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.recordedEndDt=RECORDED_END_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.lastUpdateDt=LAST_UPDATE_DT," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.lastUpdateUser=LAST_UPDATE_USER," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.arrangementTpCd=ARRANGEMENT_TP_CD," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.shareDistTpCd=SHARE_DIST_TP_CD," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.endReasonTpCd=END_REASON_TP_CD," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.lastUpdateTxId=LAST_UPDATE_TX_ID," + 
    "com.dwl.tcrm.financial.entityObject.EObjContractRole.arrangementDesc=ARRANGEMENT_DESC," + 
    "com.ibm.daimler.dsea.entityObject.EObjXContractRoleExt.XSourceIdentifier=XSOURCE_IDENT_TP_CD"; 


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getEObjCONTRACT_PARTY_ROLES_BY_CONTRACT_ID_HISTORYSQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getEObjCONTRACT_PARTY_ROLES_BY_CONTRACT_ID_HISTORYParameters, results=getEObjCONTRACT_PARTY_ROLES_BY_CONTRACT_ID_HISTORYResults)
  		Iterator<ResultQueue2<EObjContractRole, EObjXContractRoleExt>> getEObjCONTRACT_PARTY_ROLES_BY_CONTRACT_ID_HISTORY(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getEObjCONTRACT_PARTY_ROLE_BY_CONTRACT_WITHOUT_DATE_FILTER_HISTORYSQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getEObjCONTRACT_PARTY_ROLE_BY_CONTRACT_WITHOUT_DATE_FILTER_HISTORYParameters, results=getEObjCONTRACT_PARTY_ROLE_BY_CONTRACT_WITHOUT_DATE_FILTER_HISTORYResults)
  		Iterator<ResultQueue2<EObjContractRole, EObjXContractRoleExt>> getEObjCONTRACT_PARTY_ROLE_BY_CONTRACT_WITHOUT_DATE_FILTER_HISTORY(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_HISTORYSQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_HISTORYParameters, results=getEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_HISTORYResults)
  		Iterator<ResultQueue2<EObjContractRole, EObjXContractRoleExt>> getEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_HISTORY(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getEObjCONTRACT_PARTY_ROLES_HISTORYSQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getEObjCONTRACT_PARTY_ROLES_HISTORYParameters, results=getEObjCONTRACT_PARTY_ROLES_HISTORYResults)
  		Iterator<ResultQueue2<EObjContractRole, EObjXContractRoleExt>> getEObjCONTRACT_PARTY_ROLES_HISTORY(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getEObjCONTRACT_PARTY_ROLES_ACTIVESQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getEObjCONTRACT_PARTY_ROLES_ACTIVEParameters, results=getEObjCONTRACT_PARTY_ROLES_ACTIVEResults)
  		Iterator<ResultQueue2<EObjContractRole, EObjXContractRoleExt>> getEObjCONTRACT_PARTY_ROLES_ACTIVE(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getEObjCONTRACT_PARTY_ROLES_INACTIVESQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getEObjCONTRACT_PARTY_ROLES_INACTIVEParameters, results=getEObjCONTRACT_PARTY_ROLES_INACTIVEResults)
  		Iterator<ResultQueue2<EObjContractRole, EObjXContractRoleExt>> getEObjCONTRACT_PARTY_ROLES_INACTIVE(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getEObjCONTRACT_PARTY_ROLES_ALLSQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getEObjCONTRACT_PARTY_ROLES_ALLParameters, results=getEObjCONTRACT_PARTY_ROLES_ALLResults)
  		Iterator<ResultQueue2<EObjContractRole, EObjXContractRoleExt>> getEObjCONTRACT_PARTY_ROLES_ALL(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_AND_DATE_HISTORYSQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_AND_DATE_HISTORYParameters, results=getEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_AND_DATE_HISTORYResults)
  		Iterator<ResultQueue2<EObjContractRole, EObjXContractRoleExt>> getEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_AND_DATE_HISTORY(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_ACTIVESQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_ACTIVEParameters, results=getEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_ACTIVEResults)
  		Iterator<ResultQueue2<EObjContractRole, EObjXContractRoleExt>> getEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_ACTIVE(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_INACTIVESQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_INACTIVEParameters, results=getEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_INACTIVEResults)
  		Iterator<ResultQueue2<EObjContractRole, EObjXContractRoleExt>> getEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_INACTIVE(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_ALLSQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_ALLParameters, results=getEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_ALLResults)
  		Iterator<ResultQueue2<EObjContractRole, EObjXContractRoleExt>> getEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_ALL(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_AND_COMPONENT_HISTORYSQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_AND_COMPONENT_HISTORYParameters, results=getEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_AND_COMPONENT_HISTORYResults)
  		Iterator<ResultQueue2<EObjContractRole, EObjXContractRoleExt>> getEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_AND_COMPONENT_HISTORY(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_AND_COMPONENT_ACTIVESQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_AND_COMPONENT_ACTIVEParameters, results=getEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_AND_COMPONENT_ACTIVEResults)
  		Iterator<ResultQueue2<EObjContractRole, EObjXContractRoleExt>> getEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_AND_COMPONENT_ACTIVE(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_AND_COMPONENT_ID_INACTIVESQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_AND_COMPONENT_ID_INACTIVEParameters, results=getEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_AND_COMPONENT_ID_INACTIVEResults)
  		Iterator<ResultQueue2<EObjContractRole, EObjXContractRoleExt>> getEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_AND_COMPONENT_ID_INACTIVE(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_AND_COMPONENT_ID_ALL_QUERY_RECORDSSQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_AND_COMPONENT_ID_ALL_QUERY_RECORDSParameters, results=getEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_AND_COMPONENT_ID_ALL_QUERY_RECORDSResults)
  		Iterator<ResultQueue2<EObjContractRole, EObjXContractRoleExt>> getEObjCONTRACT_PARTY_ROLES_BY_PARTY_ID_AND_COMPONENT_ID_ALL_QUERY_RECORDS(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getEObjCONTRACT_PARTY_ROLE_HISTORYSQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getEObjCONTRACT_PARTY_ROLE_HISTORYParameters, results=getEObjCONTRACT_PARTY_ROLE_HISTORYResults)
  		Iterator<ResultQueue2<EObjContractRole, EObjXContractRoleExt>> getEObjCONTRACT_PARTY_ROLE_HISTORY(Object[] parameters);
 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   **/ 
  @Select(sql=getEObjCONTRACT_PARTY_ROLESQL , pattern=tableAliasString1)
  @EntityMapping(parameters=getEObjCONTRACT_PARTY_ROLEParameters, results=getEObjCONTRACT_PARTY_ROLEResults)
  		Iterator<ResultQueue2<EObjContractRole, EObjXContractRoleExt>> getEObjCONTRACT_PARTY_ROLE(Object[] parameters);
 
}


