package com.ibm.daimler.dsea.entityObject;

import com.ibm.pdq.runtime.generator.BaseParameterHandler;
import java.util.Iterator;
import java.sql.PreparedStatement;
import com.ibm.daimler.dsea.entityObject.EObjXDataSharing;
import com.ibm.pdq.runtime.statement.StatementDescriptor;
import com.ibm.pdq.runtime.generator.BaseData;
import java.sql.SQLException;
import com.ibm.pdq.annotation.Metadata;
import com.ibm.pdq.runtime.generator.BaseRowHandler;
import com.ibm.pdq.runtime.statement.SqlStatementType;
import java.sql.Types;


/**
 * <!-- begin-user-doc -->
 * 
 * <!-- end-user-doc -->
 * 
 * @generated
 */
public class EObjXDataSharingDataImpl  extends BaseData implements EObjXDataSharingData
{

  /**
   * @generated
   */
  public static final String generatorVersion = "3.200.75";

  /**
   * @generated
   */
  public static final String identifier = "EObjXDataSharingData";

  /**
   * @generated
   */
  public static final long generationTime = 0x00000164465f38c1L;

  /**
   * @generated
   */
  public static final String collection = "NULLID";

  /**
   * @generated
   */
  public static final String packageVersion = null;

  /**
   * @generated
   */
  public static final boolean forceSingleBindIsolation = false;

  /**
   * @generated
   */
  public EObjXDataSharingDataImpl()
  {
    super();
  } 

  /**
   * @generated
   */
  public String getGeneratorVersion()
  {
    return generatorVersion;
  }

  /**
   * @Select( sql="select DATASHARINGPK_ID, DATA_SHARING_FLAG, CONT_ID, Customer_Merge_Ind, GCUpdate_Date, Data_Sharing_Wholesale, WSData_Sharing_Update_Date, RETAILER_ID, RETAILER_FLAG, SOURCE_IDENT_TP_CD, START_DT, MODIFY_SYS_DT, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from XDATASHARING where DATASHARINGPK_ID = ? " )
   * 
   * @generated
   */
  public Iterator<EObjXDataSharing> getEObjXDataSharing (Long dataSharingpkId)
  {
    return queryIterator (getEObjXDataSharingStatementDescriptor, dataSharingpkId);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getEObjXDataSharingStatementDescriptor = createStatementDescriptor (
    "getEObjXDataSharing(Long)",
    "select DATASHARINGPK_ID, DATA_SHARING_FLAG, CONT_ID, Customer_Merge_Ind, GCUpdate_Date, Data_Sharing_Wholesale, WSData_Sharing_Update_Date, RETAILER_ID, RETAILER_FLAG, SOURCE_IDENT_TP_CD, START_DT, MODIFY_SYS_DT, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from XDATASHARING where DATASHARINGPK_ID = ? ",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"datasharingpk_id", "data_sharing_flag", "cont_id", "customer_merge_ind", "gcupdate_date", "data_sharing_wholesale", "wsdata_sharing_update_date", "retailer_id", "retailer_flag", "source_ident_tp_cd", "start_dt", "modify_sys_dt", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetEObjXDataSharingParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetEObjXDataSharingRowHandler (),
    new int[][]{ {Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.TIMESTAMP, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 10, 19, 250, 0, 250, 0, 19, 10, 19, 0, 0, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    1);

  /**
   * @generated
   */
  public static class GetEObjXDataSharingParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setLong (stmt, 1, Types.BIGINT, (Long)parameters[0]);
    }
  }

  /**
   * @generated
   */
  public static class GetEObjXDataSharingRowHandler extends BaseRowHandler<EObjXDataSharing>
  {
    /**
     * @generated
     */
    public EObjXDataSharing handle (java.sql.ResultSet rs, EObjXDataSharing returnObject) throws java.sql.SQLException
    {
      returnObject = new EObjXDataSharing ();
      returnObject.setDataSharingpkId(getLongObject (rs, 1)); 
      returnObject.setDataSharingFlag(getString (rs, 2)); 
      returnObject.setContId(getLongObject (rs, 3)); 
      returnObject.setCustomerMergeInd(getString (rs, 4)); 
      returnObject.setGCUpdateDate(getTimestamp (rs, 5)); 
      returnObject.setDataSharingWholesale(getString (rs, 6)); 
      returnObject.setWSDataSharingUpdateDate(getTimestamp (rs, 7)); 
      returnObject.setRetailerId(getLongObject (rs, 8)); 
      returnObject.setRetailerFlag(getString (rs, 9)); 
      returnObject.setSourceIdentifier(getLongObject (rs, 10)); 
      returnObject.setStartDate(getTimestamp (rs, 11)); 
      returnObject.setLastModifiedSystemDate(getTimestamp (rs, 12)); 
      returnObject.setLastUpdateDt(getTimestamp (rs, 13)); 
      returnObject.setLastUpdateUser(getString (rs, 14)); 
      returnObject.setLastUpdateTxId(getLongObject (rs, 15)); 
    
      return returnObject;
    }
  }

  /**
   * @Update( sql="insert into XDATASHARING (DATASHARINGPK_ID, DATA_SHARING_FLAG, CONT_ID, Customer_Merge_Ind, GCUpdate_Date, Data_Sharing_Wholesale, WSData_Sharing_Update_Date, RETAILER_ID, RETAILER_FLAG, SOURCE_IDENT_TP_CD, START_DT, MODIFY_SYS_DT, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( :dataSharingpkId, :dataSharingFlag, :contId, :customerMergeInd, :gCUpdateDate, :dataSharingWholesale, :wSDataSharingUpdateDate, :retailerId, :retailerFlag, :sourceIdentifier, :startDate, :lastModifiedSystemDate, :lastUpdateDt, :lastUpdateUser, :lastUpdateTxId)" )
   * 
   * @generated
   */
  public int createEObjXDataSharing (EObjXDataSharing e)
  {
    return update (createEObjXDataSharingStatementDescriptor, e);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor createEObjXDataSharingStatementDescriptor = createStatementDescriptor (
    "createEObjXDataSharing(com.ibm.daimler.dsea.entityObject.EObjXDataSharing)",
    "insert into XDATASHARING (DATASHARINGPK_ID, DATA_SHARING_FLAG, CONT_ID, Customer_Merge_Ind, GCUpdate_Date, Data_Sharing_Wholesale, WSData_Sharing_Update_Date, RETAILER_ID, RETAILER_FLAG, SOURCE_IDENT_TP_CD, START_DT, MODIFY_SYS_DT, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values(  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? )",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.INSERT,
    null,
    new CreateEObjXDataSharingParameterHandler (),
    new int[][]{{Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.TIMESTAMP, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 10, 19, 250, 0, 250, 0, 19, 10, 19, 0, 0, 0, 0, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    2);

  /**
   * @generated
   */
  public static class CreateEObjXDataSharingParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      EObjXDataSharing bean0 = (EObjXDataSharing) parameters[0];
      setLong (stmt, 1, Types.BIGINT, (Long)bean0.getDataSharingpkId());
      setString (stmt, 2, Types.VARCHAR, (String)bean0.getDataSharingFlag());
      setLong (stmt, 3, Types.BIGINT, (Long)bean0.getContId());
      setString (stmt, 4, Types.VARCHAR, (String)bean0.getCustomerMergeInd());
      setTimestamp (stmt, 5, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getGCUpdateDate());
      setString (stmt, 6, Types.VARCHAR, (String)bean0.getDataSharingWholesale());
      setTimestamp (stmt, 7, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getWSDataSharingUpdateDate());
      setLong (stmt, 8, Types.BIGINT, (Long)bean0.getRetailerId());
      setString (stmt, 9, Types.VARCHAR, (String)bean0.getRetailerFlag());
      setLong (stmt, 10, Types.BIGINT, (Long)bean0.getSourceIdentifier());
      setTimestamp (stmt, 11, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getStartDate());
      setTimestamp (stmt, 12, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastModifiedSystemDate());
      setTimestamp (stmt, 13, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUpdateDt());
      setString (stmt, 14, Types.VARCHAR, (String)bean0.getLastUpdateUser());
      setLong (stmt, 15, Types.BIGINT, (Long)bean0.getLastUpdateTxId());
    }
  }

  /**
   * @Update( sql="update XDATASHARING set DATA_SHARING_FLAG = :dataSharingFlag, CONT_ID = :contId, Customer_Merge_Ind = :customerMergeInd, GCUpdate_Date = :gCUpdateDate, Data_Sharing_Wholesale = :dataSharingWholesale, WSData_Sharing_Update_Date = :wSDataSharingUpdateDate, RETAILER_ID = :retailerId, RETAILER_FLAG = :retailerFlag, SOURCE_IDENT_TP_CD = :sourceIdentifier, START_DT = :startDate, MODIFY_SYS_DT = :lastModifiedSystemDate, LAST_UPDATE_DT = :lastUpdateDt, LAST_UPDATE_USER = :lastUpdateUser, LAST_UPDATE_TX_ID = :lastUpdateTxId where DATASHARINGPK_ID = :dataSharingpkId and LAST_UPDATE_DT = :oldLastUpdateDt" )
   * 
   * @generated
   */
  public int updateEObjXDataSharing (EObjXDataSharing e)
  {
    return update (updateEObjXDataSharingStatementDescriptor, e);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor updateEObjXDataSharingStatementDescriptor = createStatementDescriptor (
    "updateEObjXDataSharing(com.ibm.daimler.dsea.entityObject.EObjXDataSharing)",
    "update XDATASHARING set DATA_SHARING_FLAG =  ? , CONT_ID =  ? , Customer_Merge_Ind =  ? , GCUpdate_Date =  ? , Data_Sharing_Wholesale =  ? , WSData_Sharing_Update_Date =  ? , RETAILER_ID =  ? , RETAILER_FLAG =  ? , SOURCE_IDENT_TP_CD =  ? , START_DT =  ? , MODIFY_SYS_DT =  ? , LAST_UPDATE_DT =  ? , LAST_UPDATE_USER =  ? , LAST_UPDATE_TX_ID =  ?  where DATASHARINGPK_ID =  ?  and LAST_UPDATE_DT =  ? ",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.UPDATE,
    null,
    new UpdateEObjXDataSharingParameterHandler (),
    new int[][]{{Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.TIMESTAMP, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP}, {10, 19, 250, 0, 250, 0, 19, 10, 19, 0, 0, 0, 0, 19, 19, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    3);

  /**
   * @generated
   */
  public static class UpdateEObjXDataSharingParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      EObjXDataSharing bean0 = (EObjXDataSharing) parameters[0];
      setString (stmt, 1, Types.VARCHAR, (String)bean0.getDataSharingFlag());
      setLong (stmt, 2, Types.BIGINT, (Long)bean0.getContId());
      setString (stmt, 3, Types.VARCHAR, (String)bean0.getCustomerMergeInd());
      setTimestamp (stmt, 4, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getGCUpdateDate());
      setString (stmt, 5, Types.VARCHAR, (String)bean0.getDataSharingWholesale());
      setTimestamp (stmt, 6, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getWSDataSharingUpdateDate());
      setLong (stmt, 7, Types.BIGINT, (Long)bean0.getRetailerId());
      setString (stmt, 8, Types.VARCHAR, (String)bean0.getRetailerFlag());
      setLong (stmt, 9, Types.BIGINT, (Long)bean0.getSourceIdentifier());
      setTimestamp (stmt, 10, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getStartDate());
      setTimestamp (stmt, 11, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastModifiedSystemDate());
      setTimestamp (stmt, 12, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUpdateDt());
      setString (stmt, 13, Types.VARCHAR, (String)bean0.getLastUpdateUser());
      setLong (stmt, 14, Types.BIGINT, (Long)bean0.getLastUpdateTxId());
      setLong (stmt, 15, Types.BIGINT, (Long)bean0.getDataSharingpkId());
      setTimestamp (stmt, 16, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getOldLastUpdateDt());
    }
  }

  /**
   * @Update( sql="delete from XDATASHARING where DATASHARINGPK_ID = ?" )
   * 
   * @generated
   */
  public int deleteEObjXDataSharing (Long dataSharingpkId)
  {
    return update (deleteEObjXDataSharingStatementDescriptor, dataSharingpkId);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor deleteEObjXDataSharingStatementDescriptor = createStatementDescriptor (
    "deleteEObjXDataSharing(Long)",
    "delete from XDATASHARING where DATASHARINGPK_ID = ?",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.DELETE,
    null,
    new DeleteEObjXDataSharingParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    4);

  /**
   * @generated
   */
  public static class DeleteEObjXDataSharingParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setLong (stmt, 1, Types.BIGINT, (Long)parameters[0]);
    }
  }

}
