package com.ibm.daimler.dsea.entityObject;

import com.ibm.pdq.runtime.generator.BaseParameterHandler;
import java.util.Iterator;
import com.ibm.daimler.dsea.entityObject.EObjXVehicleAddress;
import java.sql.PreparedStatement;
import com.ibm.pdq.runtime.statement.StatementDescriptor;
import com.ibm.pdq.runtime.generator.BaseData;
import java.sql.SQLException;
import com.ibm.pdq.annotation.Metadata;
import com.ibm.pdq.runtime.generator.BaseRowHandler;
import com.ibm.pdq.runtime.statement.SqlStatementType;
import java.sql.Types;


/**
 * <!-- begin-user-doc -->
 * 
 * <!-- end-user-doc -->
 * 
 * @generated
 */
public class EObjXVehicleAddressDataImpl  extends BaseData implements EObjXVehicleAddressData
{

  /**
   * @generated
   */
  public static final String generatorVersion = "3.200.75";

  /**
   * @generated
   */
  public static final String identifier = "EObjXVehicleAddressData";

  /**
   * @generated
   */
  public static final long generationTime = 0x00000164465f3962L;

  /**
   * @generated
   */
  public static final String collection = "NULLID";

  /**
   * @generated
   */
  public static final String packageVersion = null;

  /**
   * @generated
   */
  public static final boolean forceSingleBindIsolation = false;

  /**
   * @generated
   */
  public EObjXVehicleAddressDataImpl()
  {
    super();
  } 

  /**
   * @generated
   */
  public String getGeneratorVersion()
  {
    return generatorVersion;
  }

  /**
   * @Select( sql="select VEHICLE_ADDRESSPK_ID, ADDRESS_USAGE_TYPE, PREFERRED_IND, ADDRESS_LINE_ONE, ADDRESS_LINE_TWO, ADDRESS_LINE_THREE, CITY_NAME, POSTAL_CODE, RESIDENCE_NUM, COUNTRY, PROVINCE_STATE, VEHICLE_ID, CONT_ID, SOURCE_IDENT_TP_CD, START_DT, MODIFY_SYS_DT, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from XVEHICLEADDRESS where VEHICLE_ADDRESSPK_ID = ? " )
   * 
   * @generated
   */
  public Iterator<EObjXVehicleAddress> getEObjXVehicleAddress (Long vehicleAddresspkId)
  {
    return queryIterator (getEObjXVehicleAddressStatementDescriptor, vehicleAddresspkId);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getEObjXVehicleAddressStatementDescriptor = createStatementDescriptor (
    "getEObjXVehicleAddress(Long)",
    "select VEHICLE_ADDRESSPK_ID, ADDRESS_USAGE_TYPE, PREFERRED_IND, ADDRESS_LINE_ONE, ADDRESS_LINE_TWO, ADDRESS_LINE_THREE, CITY_NAME, POSTAL_CODE, RESIDENCE_NUM, COUNTRY, PROVINCE_STATE, VEHICLE_ID, CONT_ID, SOURCE_IDENT_TP_CD, START_DT, MODIFY_SYS_DT, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from XVEHICLEADDRESS where VEHICLE_ADDRESSPK_ID = ? ",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"vehicle_addresspk_id", "address_usage_type", "preferred_ind", "address_line_one", "address_line_two", "address_line_three", "city_name", "postal_code", "residence_num", "country", "province_state", "vehicle_id", "cont_id", "source_ident_tp_cd", "start_dt", "modify_sys_dt", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetEObjXVehicleAddressParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetEObjXVehicleAddressRowHandler (),
    new int[][]{ {Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 100, 10, 500, 250, 150, 1000, 100, 1000, 150, 250, 19, 19, 19, 0, 0, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    1);

  /**
   * @generated
   */
  public static class GetEObjXVehicleAddressParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setLong (stmt, 1, Types.BIGINT, (Long)parameters[0]);
    }
  }

  /**
   * @generated
   */
  public static class GetEObjXVehicleAddressRowHandler extends BaseRowHandler<EObjXVehicleAddress>
  {
    /**
     * @generated
     */
    public EObjXVehicleAddress handle (java.sql.ResultSet rs, EObjXVehicleAddress returnObject) throws java.sql.SQLException
    {
      returnObject = new EObjXVehicleAddress ();
      returnObject.setVehicleAddresspkId(getLongObject (rs, 1)); 
      returnObject.setAddressUsageType(getString (rs, 2)); 
      returnObject.setPreferredInd(getString (rs, 3)); 
      returnObject.setAddressLineOne(getString (rs, 4)); 
      returnObject.setAddressLineTwo(getString (rs, 5)); 
      returnObject.setAddressLineThree(getString (rs, 6)); 
      returnObject.setCity(getString (rs, 7)); 
      returnObject.setZipPostalCode(getString (rs, 8)); 
      returnObject.setResidenceNumber(getString (rs, 9)); 
      returnObject.setCountry(getString (rs, 10)); 
      returnObject.setProvinceState(getString (rs, 11)); 
      returnObject.setVehicleId(getLongObject (rs, 12)); 
      returnObject.setContId(getLongObject (rs, 13)); 
      returnObject.setSourceIdentifier(getLongObject (rs, 14)); 
      returnObject.setStartDate(getTimestamp (rs, 15)); 
      returnObject.setLastModifiedSystemDate(getTimestamp (rs, 16)); 
      returnObject.setLastUpdateDt(getTimestamp (rs, 17)); 
      returnObject.setLastUpdateUser(getString (rs, 18)); 
      returnObject.setLastUpdateTxId(getLongObject (rs, 19)); 
    
      return returnObject;
    }
  }

  /**
   * @Update( sql="insert into XVEHICLEADDRESS (VEHICLE_ADDRESSPK_ID, ADDRESS_USAGE_TYPE, PREFERRED_IND, ADDRESS_LINE_ONE, ADDRESS_LINE_TWO, ADDRESS_LINE_THREE, CITY_NAME, POSTAL_CODE, RESIDENCE_NUM, COUNTRY, PROVINCE_STATE, VEHICLE_ID, CONT_ID, SOURCE_IDENT_TP_CD, START_DT, MODIFY_SYS_DT, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( :vehicleAddresspkId, :addressUsageType, :preferredInd, :addressLineOne, :addressLineTwo, :addressLineThree, :city, :zipPostalCode, :residenceNumber, :country, :provinceState, :vehicleId, :contId, :sourceIdentifier, :startDate, :lastModifiedSystemDate, :lastUpdateDt, :lastUpdateUser, :lastUpdateTxId)" )
   * 
   * @generated
   */
  public int createEObjXVehicleAddress (EObjXVehicleAddress e)
  {
    return update (createEObjXVehicleAddressStatementDescriptor, e);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor createEObjXVehicleAddressStatementDescriptor = createStatementDescriptor (
    "createEObjXVehicleAddress(com.ibm.daimler.dsea.entityObject.EObjXVehicleAddress)",
    "insert into XVEHICLEADDRESS (VEHICLE_ADDRESSPK_ID, ADDRESS_USAGE_TYPE, PREFERRED_IND, ADDRESS_LINE_ONE, ADDRESS_LINE_TWO, ADDRESS_LINE_THREE, CITY_NAME, POSTAL_CODE, RESIDENCE_NUM, COUNTRY, PROVINCE_STATE, VEHICLE_ID, CONT_ID, SOURCE_IDENT_TP_CD, START_DT, MODIFY_SYS_DT, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values(  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? )",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.INSERT,
    null,
    new CreateEObjXVehicleAddressParameterHandler (),
    new int[][]{{Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 100, 10, 500, 250, 150, 1000, 100, 1000, 150, 250, 19, 19, 19, 0, 0, 0, 0, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    2);

  /**
   * @generated
   */
  public static class CreateEObjXVehicleAddressParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      EObjXVehicleAddress bean0 = (EObjXVehicleAddress) parameters[0];
      setLong (stmt, 1, Types.BIGINT, (Long)bean0.getVehicleAddresspkId());
      setString (stmt, 2, Types.VARCHAR, (String)bean0.getAddressUsageType());
      setString (stmt, 3, Types.VARCHAR, (String)bean0.getPreferredInd());
      setString (stmt, 4, Types.VARCHAR, (String)bean0.getAddressLineOne());
      setString (stmt, 5, Types.VARCHAR, (String)bean0.getAddressLineTwo());
      setString (stmt, 6, Types.VARCHAR, (String)bean0.getAddressLineThree());
      setString (stmt, 7, Types.VARCHAR, (String)bean0.getCity());
      setString (stmt, 8, Types.VARCHAR, (String)bean0.getZipPostalCode());
      setString (stmt, 9, Types.VARCHAR, (String)bean0.getResidenceNumber());
      setString (stmt, 10, Types.VARCHAR, (String)bean0.getCountry());
      setString (stmt, 11, Types.VARCHAR, (String)bean0.getProvinceState());
      setLong (stmt, 12, Types.BIGINT, (Long)bean0.getVehicleId());
      setLong (stmt, 13, Types.BIGINT, (Long)bean0.getContId());
      setLong (stmt, 14, Types.BIGINT, (Long)bean0.getSourceIdentifier());
      setTimestamp (stmt, 15, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getStartDate());
      setTimestamp (stmt, 16, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastModifiedSystemDate());
      setTimestamp (stmt, 17, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUpdateDt());
      setString (stmt, 18, Types.VARCHAR, (String)bean0.getLastUpdateUser());
      setLong (stmt, 19, Types.BIGINT, (Long)bean0.getLastUpdateTxId());
    }
  }

  /**
   * @Update( sql="update XVEHICLEADDRESS set ADDRESS_USAGE_TYPE = :addressUsageType, PREFERRED_IND = :preferredInd, ADDRESS_LINE_ONE = :addressLineOne, ADDRESS_LINE_TWO = :addressLineTwo, ADDRESS_LINE_THREE = :addressLineThree, CITY_NAME = :city, POSTAL_CODE = :zipPostalCode, RESIDENCE_NUM = :residenceNumber, COUNTRY = :country, PROVINCE_STATE = :provinceState, VEHICLE_ID = :vehicleId, CONT_ID = :contId, SOURCE_IDENT_TP_CD = :sourceIdentifier, START_DT = :startDate, MODIFY_SYS_DT = :lastModifiedSystemDate, LAST_UPDATE_DT = :lastUpdateDt, LAST_UPDATE_USER = :lastUpdateUser, LAST_UPDATE_TX_ID = :lastUpdateTxId where VEHICLE_ADDRESSPK_ID = :vehicleAddresspkId and LAST_UPDATE_DT = :oldLastUpdateDt" )
   * 
   * @generated
   */
  public int updateEObjXVehicleAddress (EObjXVehicleAddress e)
  {
    return update (updateEObjXVehicleAddressStatementDescriptor, e);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor updateEObjXVehicleAddressStatementDescriptor = createStatementDescriptor (
    "updateEObjXVehicleAddress(com.ibm.daimler.dsea.entityObject.EObjXVehicleAddress)",
    "update XVEHICLEADDRESS set ADDRESS_USAGE_TYPE =  ? , PREFERRED_IND =  ? , ADDRESS_LINE_ONE =  ? , ADDRESS_LINE_TWO =  ? , ADDRESS_LINE_THREE =  ? , CITY_NAME =  ? , POSTAL_CODE =  ? , RESIDENCE_NUM =  ? , COUNTRY =  ? , PROVINCE_STATE =  ? , VEHICLE_ID =  ? , CONT_ID =  ? , SOURCE_IDENT_TP_CD =  ? , START_DT =  ? , MODIFY_SYS_DT =  ? , LAST_UPDATE_DT =  ? , LAST_UPDATE_USER =  ? , LAST_UPDATE_TX_ID =  ?  where VEHICLE_ADDRESSPK_ID =  ?  and LAST_UPDATE_DT =  ? ",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.UPDATE,
    null,
    new UpdateEObjXVehicleAddressParameterHandler (),
    new int[][]{{Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP}, {100, 10, 500, 250, 150, 1000, 100, 1000, 150, 250, 19, 19, 19, 0, 0, 0, 0, 19, 19, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    3);

  /**
   * @generated
   */
  public static class UpdateEObjXVehicleAddressParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      EObjXVehicleAddress bean0 = (EObjXVehicleAddress) parameters[0];
      setString (stmt, 1, Types.VARCHAR, (String)bean0.getAddressUsageType());
      setString (stmt, 2, Types.VARCHAR, (String)bean0.getPreferredInd());
      setString (stmt, 3, Types.VARCHAR, (String)bean0.getAddressLineOne());
      setString (stmt, 4, Types.VARCHAR, (String)bean0.getAddressLineTwo());
      setString (stmt, 5, Types.VARCHAR, (String)bean0.getAddressLineThree());
      setString (stmt, 6, Types.VARCHAR, (String)bean0.getCity());
      setString (stmt, 7, Types.VARCHAR, (String)bean0.getZipPostalCode());
      setString (stmt, 8, Types.VARCHAR, (String)bean0.getResidenceNumber());
      setString (stmt, 9, Types.VARCHAR, (String)bean0.getCountry());
      setString (stmt, 10, Types.VARCHAR, (String)bean0.getProvinceState());
      setLong (stmt, 11, Types.BIGINT, (Long)bean0.getVehicleId());
      setLong (stmt, 12, Types.BIGINT, (Long)bean0.getContId());
      setLong (stmt, 13, Types.BIGINT, (Long)bean0.getSourceIdentifier());
      setTimestamp (stmt, 14, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getStartDate());
      setTimestamp (stmt, 15, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastModifiedSystemDate());
      setTimestamp (stmt, 16, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUpdateDt());
      setString (stmt, 17, Types.VARCHAR, (String)bean0.getLastUpdateUser());
      setLong (stmt, 18, Types.BIGINT, (Long)bean0.getLastUpdateTxId());
      setLong (stmt, 19, Types.BIGINT, (Long)bean0.getVehicleAddresspkId());
      setTimestamp (stmt, 20, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getOldLastUpdateDt());
    }
  }

  /**
   * @Update( sql="delete from XVEHICLEADDRESS where VEHICLE_ADDRESSPK_ID = ?" )
   * 
   * @generated
   */
  public int deleteEObjXVehicleAddress (Long vehicleAddresspkId)
  {
    return update (deleteEObjXVehicleAddressStatementDescriptor, vehicleAddresspkId);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor deleteEObjXVehicleAddressStatementDescriptor = createStatementDescriptor (
    "deleteEObjXVehicleAddress(Long)",
    "delete from XVEHICLEADDRESS where VEHICLE_ADDRESSPK_ID = ?",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.DELETE,
    null,
    new DeleteEObjXVehicleAddressParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    4);

  /**
   * @generated
   */
  public static class DeleteEObjXVehicleAddressParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setLong (stmt, 1, Types.BIGINT, (Long)parameters[0]);
    }
  }

}
