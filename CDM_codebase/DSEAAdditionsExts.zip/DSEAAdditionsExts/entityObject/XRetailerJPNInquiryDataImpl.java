package com.ibm.daimler.dsea.entityObject;

import com.ibm.pdq.runtime.generator.BaseParameterHandler;
import com.ibm.daimler.dsea.entityObject.EObjXRetailerJPN;
import java.util.Iterator;
import com.ibm.mdm.base.db.ResultQueue1;
import java.sql.PreparedStatement;
import com.ibm.pdq.runtime.statement.StatementDescriptor;
import com.ibm.pdq.runtime.generator.BaseData;
import java.sql.SQLException;
import com.ibm.pdq.annotation.Metadata;
import com.ibm.pdq.runtime.generator.BaseRowHandler;
import com.ibm.pdq.runtime.statement.SqlStatementType;
import java.sql.Types;


@SuppressWarnings("unchecked")

/**
 * <!-- begin-user-doc -->
 * 
 * <!-- end-user-doc -->
 * 
 * @generated
 */
public class XRetailerJPNInquiryDataImpl  extends BaseData implements XRetailerJPNInquiryData
{

  /**
   * @generated
   */
  public static final String generatorVersion = "3.200.75";

  /**
   * @generated
   */
  public static final String identifier = "XRetailerJPNInquiryData";

  /**
   * @generated
   */
  public static final long generationTime = 0x0000016422840995L;

  /**
   * @generated
   */
  public static final String collection = "NULLID";

  /**
   * @generated
   */
  public static final String packageVersion = null;

  /**
   * @generated
   */
  public static final boolean forceSingleBindIsolation = false;

  /**
   * @generated
   */
  public XRetailerJPNInquiryDataImpl()
  {
    super();
  } 

  /**
   * @generated
   */
  public String getGeneratorVersion()
  {
    return generatorVersion;
  }

  /**
   * @Select( sql="SELECT r.XRETAILERJPNPK_ID XRETAILERJPNPK_ID, r.RETAILER_CODE RETAILER_CODE, r.RETAILER_NAME RETAILER_NAME, r.BRANCH_NAME BRANCH_NAME, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.GS_CODE GS_CODE, r.GC_CODE GC_CODE, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.ND_CODE ND_CODE, r.MARKET_NAME MARKET_NAME, r.DEALER_ACTIVE_FLAG DEALER_ACTIVE_FLAG, r.Dealer_Group Dealer_Group, r.DEALER_ROLLOUT_FLAG DEALER_ROLLOUT_FLAG, r.BATCH_IND BATCH_IND, r.CREATE_DT CREATE_DT, r.CHANGED_DT CHANGED_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XRETAILERJPN r WHERE r.XRETAILERJPNPK_ID = ? ", pattern="tableAlias (XRETAILERJPN => com.ibm.daimler.dsea.entityObject.EObjXRetailerJPN, H_XRETAILERJPN => com.ibm.daimler.dsea.entityObject.EObjXRetailerJPN)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue1<EObjXRetailerJPN>> getXRetailerJPN (Object[] parameters)
  {
    return queryIterator (getXRetailerJPNStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getXRetailerJPNStatementDescriptor = createStatementDescriptor (
    "getXRetailerJPN(Object[])",
    "SELECT r.XRETAILERJPNPK_ID XRETAILERJPNPK_ID, r.RETAILER_CODE RETAILER_CODE, r.RETAILER_NAME RETAILER_NAME, r.BRANCH_NAME BRANCH_NAME, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.GS_CODE GS_CODE, r.GC_CODE GC_CODE, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.ND_CODE ND_CODE, r.MARKET_NAME MARKET_NAME, r.DEALER_ACTIVE_FLAG DEALER_ACTIVE_FLAG, r.Dealer_Group Dealer_Group, r.DEALER_ROLLOUT_FLAG DEALER_ROLLOUT_FLAG, r.BATCH_IND BATCH_IND, r.CREATE_DT CREATE_DT, r.CHANGED_DT CHANGED_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XRETAILERJPN r WHERE r.XRETAILERJPNPK_ID = ? ",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"xretailerjpnpk_id", "retailer_code", "retailer_name", "branch_name", "source_ident_tp_cd", "gs_code", "gc_code", "modify_sys_dt", "nd_code", "market_name", "dealer_active_flag", "dealer_group", "dealer_rollout_flag", "batch_ind", "create_dt", "changed_dt", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetXRetailerJPNParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetXRetailerJPNRowHandler (),
    new int[][]{ {Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 20, 255, 255, 19, 20, 20, 0, 20, 50, 5, 255, 5, 5, 0, 0, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    1);

  /**
   * @generated
   */
  public static class GetXRetailerJPNParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetXRetailerJPNRowHandler extends BaseRowHandler<ResultQueue1<EObjXRetailerJPN>>
  {
    /**
     * @generated
     */
    public ResultQueue1<EObjXRetailerJPN> handle (java.sql.ResultSet rs, ResultQueue1<EObjXRetailerJPN> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue1<EObjXRetailerJPN> ();

      EObjXRetailerJPN returnObject1 = new EObjXRetailerJPN ();
      returnObject1.setXRetailerJPNpkId(getLongObject (rs, 1)); 
      returnObject1.setRetailerCode(getString (rs, 2)); 
      returnObject1.setRetailerName(getString (rs, 3)); 
      returnObject1.setBranchName(getString (rs, 4)); 
      returnObject1.setSourceIdentifier(getLongObject (rs, 5)); 
      returnObject1.setGSCode(getString (rs, 6)); 
      returnObject1.setGCCode(getString (rs, 7)); 
      returnObject1.setLastModifiedSystemDate(getTimestamp (rs, 8)); 
      returnObject1.setNDCode(getString (rs, 9)); 
      returnObject1.setMarketName(getString (rs, 10)); 
      returnObject1.setDealerActiveFlag(getString (rs, 11)); 
      returnObject1.setDealerGroup(getString (rs, 12)); 
      returnObject1.setDealerRolloutFlag(getString (rs, 13)); 
      returnObject1.setBatchInd(getString (rs, 14)); 
      returnObject1.setCreateDate(getTimestamp (rs, 15)); 
      returnObject1.setChangedDate(getTimestamp (rs, 16)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 17)); 
      returnObject1.setLastUpdateUser(getString (rs, 18)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 19)); 
      returnObject.add (returnObject1);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT r.H_XRETAILERJPNPK_ID hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.XRETAILERJPNPK_ID XRETAILERJPNPK_ID, r.RETAILER_CODE RETAILER_CODE, r.RETAILER_NAME RETAILER_NAME, r.BRANCH_NAME BRANCH_NAME, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.GS_CODE GS_CODE, r.GC_CODE GC_CODE, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.ND_CODE ND_CODE, r.MARKET_NAME MARKET_NAME, r.DEALER_ACTIVE_FLAG DEALER_ACTIVE_FLAG, r.Dealer_Group Dealer_Group, r.DEALER_ROLLOUT_FLAG DEALER_ROLLOUT_FLAG, r.BATCH_IND BATCH_IND, r.CREATE_DT CREATE_DT, r.CHANGED_DT CHANGED_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XRETAILERJPN r WHERE r.H_XRETAILERJPNPK_ID = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))", pattern="tableAlias (XRETAILERJPN => com.ibm.daimler.dsea.entityObject.EObjXRetailerJPN, H_XRETAILERJPN => com.ibm.daimler.dsea.entityObject.EObjXRetailerJPN)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue1<EObjXRetailerJPN>> getXRetailerJPNHistory (Object[] parameters)
  {
    return queryIterator (getXRetailerJPNHistoryStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getXRetailerJPNHistoryStatementDescriptor = createStatementDescriptor (
    "getXRetailerJPNHistory(Object[])",
    "SELECT r.H_XRETAILERJPNPK_ID hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.XRETAILERJPNPK_ID XRETAILERJPNPK_ID, r.RETAILER_CODE RETAILER_CODE, r.RETAILER_NAME RETAILER_NAME, r.BRANCH_NAME BRANCH_NAME, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.GS_CODE GS_CODE, r.GC_CODE GC_CODE, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.ND_CODE ND_CODE, r.MARKET_NAME MARKET_NAME, r.DEALER_ACTIVE_FLAG DEALER_ACTIVE_FLAG, r.Dealer_Group Dealer_Group, r.DEALER_ROLLOUT_FLAG DEALER_ROLLOUT_FLAG, r.BATCH_IND BATCH_IND, r.CREATE_DT CREATE_DT, r.CHANGED_DT CHANGED_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XRETAILERJPN r WHERE r.H_XRETAILERJPNPK_ID = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"historyidpk", "h_action_code", "h_created_by", "h_create_dt", "h_end_dt", "xretailerjpnpk_id", "retailer_code", "retailer_name", "branch_name", "source_ident_tp_cd", "gs_code", "gc_code", "modify_sys_dt", "nd_code", "market_name", "dealer_active_flag", "dealer_group", "dealer_rollout_flag", "batch_ind", "create_dt", "changed_dt", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetXRetailerJPNHistoryParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP}, {19, 0, 0}, {0, 0, 0}, {1, 1, 1}},
    null,
    new GetXRetailerJPNHistoryRowHandler (),
    new int[][]{ {Types.BIGINT, Types.CHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 1, 20, 0, 0, 19, 20, 255, 255, 19, 20, 20, 0, 20, 50, 5, 255, 5, 5, 0, 0, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    2);

  /**
   * @generated
   */
  public static class GetXRetailerJPNHistoryParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetXRetailerJPNHistoryRowHandler extends BaseRowHandler<ResultQueue1<EObjXRetailerJPN>>
  {
    /**
     * @generated
     */
    public ResultQueue1<EObjXRetailerJPN> handle (java.sql.ResultSet rs, ResultQueue1<EObjXRetailerJPN> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue1<EObjXRetailerJPN> ();

      EObjXRetailerJPN returnObject1 = new EObjXRetailerJPN ();
      returnObject1.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject1.setHistActionCode(getString (rs, 2)); 
      returnObject1.setHistCreatedBy(getString (rs, 3)); 
      returnObject1.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject1.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject1.setXRetailerJPNpkId(getLongObject (rs, 6)); 
      returnObject1.setRetailerCode(getString (rs, 7)); 
      returnObject1.setRetailerName(getString (rs, 8)); 
      returnObject1.setBranchName(getString (rs, 9)); 
      returnObject1.setSourceIdentifier(getLongObject (rs, 10)); 
      returnObject1.setGSCode(getString (rs, 11)); 
      returnObject1.setGCCode(getString (rs, 12)); 
      returnObject1.setLastModifiedSystemDate(getTimestamp (rs, 13)); 
      returnObject1.setNDCode(getString (rs, 14)); 
      returnObject1.setMarketName(getString (rs, 15)); 
      returnObject1.setDealerActiveFlag(getString (rs, 16)); 
      returnObject1.setDealerGroup(getString (rs, 17)); 
      returnObject1.setDealerRolloutFlag(getString (rs, 18)); 
      returnObject1.setBatchInd(getString (rs, 19)); 
      returnObject1.setCreateDate(getTimestamp (rs, 20)); 
      returnObject1.setChangedDate(getTimestamp (rs, 21)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 22)); 
      returnObject1.setLastUpdateUser(getString (rs, 23)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 24)); 
      returnObject.add (returnObject1);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT r.XRETAILERJPNPK_ID XRETAILERJPNPK_ID, r.RETAILER_CODE RETAILER_CODE, r.RETAILER_NAME RETAILER_NAME, r.BRANCH_NAME BRANCH_NAME, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.GS_CODE GS_CODE, r.GC_CODE GC_CODE, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.ND_CODE ND_CODE, r.MARKET_NAME MARKET_NAME, r.DEALER_ACTIVE_FLAG DEALER_ACTIVE_FLAG, r.Dealer_Group Dealer_Group, r.DEALER_ROLLOUT_FLAG DEALER_ROLLOUT_FLAG, r.BATCH_IND BATCH_IND, r.CREATE_DT CREATE_DT, r.CHANGED_DT CHANGED_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XRETAILERJPN r WHERE r.RETAILER_CODE = ? ", pattern="tableAlias (XRETAILERJPN => com.ibm.daimler.dsea.entityObject.EObjXRetailerJPN, H_XRETAILERJPN => com.ibm.daimler.dsea.entityObject.EObjXRetailerJPN)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue1<EObjXRetailerJPN>> getXRetailerJPNByRetailerCode (Object[] parameters)
  {
    return queryIterator (getXRetailerJPNByRetailerCodeStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getXRetailerJPNByRetailerCodeStatementDescriptor = createStatementDescriptor (
    "getXRetailerJPNByRetailerCode(Object[])",
    "SELECT r.XRETAILERJPNPK_ID XRETAILERJPNPK_ID, r.RETAILER_CODE RETAILER_CODE, r.RETAILER_NAME RETAILER_NAME, r.BRANCH_NAME BRANCH_NAME, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.GS_CODE GS_CODE, r.GC_CODE GC_CODE, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.ND_CODE ND_CODE, r.MARKET_NAME MARKET_NAME, r.DEALER_ACTIVE_FLAG DEALER_ACTIVE_FLAG, r.Dealer_Group Dealer_Group, r.DEALER_ROLLOUT_FLAG DEALER_ROLLOUT_FLAG, r.BATCH_IND BATCH_IND, r.CREATE_DT CREATE_DT, r.CHANGED_DT CHANGED_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XRETAILERJPN r WHERE r.RETAILER_CODE = ? ",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"xretailerjpnpk_id", "retailer_code", "retailer_name", "branch_name", "source_ident_tp_cd", "gs_code", "gc_code", "modify_sys_dt", "nd_code", "market_name", "dealer_active_flag", "dealer_group", "dealer_rollout_flag", "batch_ind", "create_dt", "changed_dt", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetXRetailerJPNByRetailerCodeParameterHandler (),
    new int[][]{{Types.VARCHAR}, {20}, {0}, {1}},
    null,
    new GetXRetailerJPNByRetailerCodeRowHandler (),
    new int[][]{ {Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 20, 255, 255, 19, 20, 20, 0, 20, 50, 5, 255, 5, 5, 0, 0, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    3);

  /**
   * @generated
   */
  public static class GetXRetailerJPNByRetailerCodeParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.VARCHAR, parameters[0], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetXRetailerJPNByRetailerCodeRowHandler extends BaseRowHandler<ResultQueue1<EObjXRetailerJPN>>
  {
    /**
     * @generated
     */
    public ResultQueue1<EObjXRetailerJPN> handle (java.sql.ResultSet rs, ResultQueue1<EObjXRetailerJPN> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue1<EObjXRetailerJPN> ();

      EObjXRetailerJPN returnObject1 = new EObjXRetailerJPN ();
      returnObject1.setXRetailerJPNpkId(getLongObject (rs, 1)); 
      returnObject1.setRetailerCode(getString (rs, 2)); 
      returnObject1.setRetailerName(getString (rs, 3)); 
      returnObject1.setBranchName(getString (rs, 4)); 
      returnObject1.setSourceIdentifier(getLongObject (rs, 5)); 
      returnObject1.setGSCode(getString (rs, 6)); 
      returnObject1.setGCCode(getString (rs, 7)); 
      returnObject1.setLastModifiedSystemDate(getTimestamp (rs, 8)); 
      returnObject1.setNDCode(getString (rs, 9)); 
      returnObject1.setMarketName(getString (rs, 10)); 
      returnObject1.setDealerActiveFlag(getString (rs, 11)); 
      returnObject1.setDealerGroup(getString (rs, 12)); 
      returnObject1.setDealerRolloutFlag(getString (rs, 13)); 
      returnObject1.setBatchInd(getString (rs, 14)); 
      returnObject1.setCreateDate(getTimestamp (rs, 15)); 
      returnObject1.setChangedDate(getTimestamp (rs, 16)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 17)); 
      returnObject1.setLastUpdateUser(getString (rs, 18)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 19)); 
      returnObject.add (returnObject1);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT r.H_XRETAILERJPNPK_ID hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.XRETAILERJPNPK_ID XRETAILERJPNPK_ID, r.RETAILER_CODE RETAILER_CODE, r.RETAILER_NAME RETAILER_NAME, r.BRANCH_NAME BRANCH_NAME, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.GS_CODE GS_CODE, r.GC_CODE GC_CODE, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.ND_CODE ND_CODE, r.MARKET_NAME MARKET_NAME, r.DEALER_ACTIVE_FLAG DEALER_ACTIVE_FLAG, r.Dealer_Group Dealer_Group, r.DEALER_ROLLOUT_FLAG DEALER_ROLLOUT_FLAG, r.BATCH_IND BATCH_IND, r.CREATE_DT CREATE_DT, r.CHANGED_DT CHANGED_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XRETAILERJPN r WHERE r.RETAILER_CODE = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))", pattern="tableAlias (XRETAILERJPN => com.ibm.daimler.dsea.entityObject.EObjXRetailerJPN, H_XRETAILERJPN => com.ibm.daimler.dsea.entityObject.EObjXRetailerJPN)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue1<EObjXRetailerJPN>> getXRetailerJPNByRetailerCodeHistory (Object[] parameters)
  {
    return queryIterator (getXRetailerJPNByRetailerCodeHistoryStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getXRetailerJPNByRetailerCodeHistoryStatementDescriptor = createStatementDescriptor (
    "getXRetailerJPNByRetailerCodeHistory(Object[])",
    "SELECT r.H_XRETAILERJPNPK_ID hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.XRETAILERJPNPK_ID XRETAILERJPNPK_ID, r.RETAILER_CODE RETAILER_CODE, r.RETAILER_NAME RETAILER_NAME, r.BRANCH_NAME BRANCH_NAME, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.GS_CODE GS_CODE, r.GC_CODE GC_CODE, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.ND_CODE ND_CODE, r.MARKET_NAME MARKET_NAME, r.DEALER_ACTIVE_FLAG DEALER_ACTIVE_FLAG, r.Dealer_Group Dealer_Group, r.DEALER_ROLLOUT_FLAG DEALER_ROLLOUT_FLAG, r.BATCH_IND BATCH_IND, r.CREATE_DT CREATE_DT, r.CHANGED_DT CHANGED_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XRETAILERJPN r WHERE r.RETAILER_CODE = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"historyidpk", "h_action_code", "h_created_by", "h_create_dt", "h_end_dt", "xretailerjpnpk_id", "retailer_code", "retailer_name", "branch_name", "source_ident_tp_cd", "gs_code", "gc_code", "modify_sys_dt", "nd_code", "market_name", "dealer_active_flag", "dealer_group", "dealer_rollout_flag", "batch_ind", "create_dt", "changed_dt", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetXRetailerJPNByRetailerCodeHistoryParameterHandler (),
    new int[][]{{Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP}, {20, 0, 0}, {0, 0, 0}, {1, 1, 1}},
    null,
    new GetXRetailerJPNByRetailerCodeHistoryRowHandler (),
    new int[][]{ {Types.BIGINT, Types.CHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 1, 20, 0, 0, 19, 20, 255, 255, 19, 20, 20, 0, 20, 50, 5, 255, 5, 5, 0, 0, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    4);

  /**
   * @generated
   */
  public static class GetXRetailerJPNByRetailerCodeHistoryParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.VARCHAR, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetXRetailerJPNByRetailerCodeHistoryRowHandler extends BaseRowHandler<ResultQueue1<EObjXRetailerJPN>>
  {
    /**
     * @generated
     */
    public ResultQueue1<EObjXRetailerJPN> handle (java.sql.ResultSet rs, ResultQueue1<EObjXRetailerJPN> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue1<EObjXRetailerJPN> ();

      EObjXRetailerJPN returnObject1 = new EObjXRetailerJPN ();
      returnObject1.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject1.setHistActionCode(getString (rs, 2)); 
      returnObject1.setHistCreatedBy(getString (rs, 3)); 
      returnObject1.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject1.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject1.setXRetailerJPNpkId(getLongObject (rs, 6)); 
      returnObject1.setRetailerCode(getString (rs, 7)); 
      returnObject1.setRetailerName(getString (rs, 8)); 
      returnObject1.setBranchName(getString (rs, 9)); 
      returnObject1.setSourceIdentifier(getLongObject (rs, 10)); 
      returnObject1.setGSCode(getString (rs, 11)); 
      returnObject1.setGCCode(getString (rs, 12)); 
      returnObject1.setLastModifiedSystemDate(getTimestamp (rs, 13)); 
      returnObject1.setNDCode(getString (rs, 14)); 
      returnObject1.setMarketName(getString (rs, 15)); 
      returnObject1.setDealerActiveFlag(getString (rs, 16)); 
      returnObject1.setDealerGroup(getString (rs, 17)); 
      returnObject1.setDealerRolloutFlag(getString (rs, 18)); 
      returnObject1.setBatchInd(getString (rs, 19)); 
      returnObject1.setCreateDate(getTimestamp (rs, 20)); 
      returnObject1.setChangedDate(getTimestamp (rs, 21)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 22)); 
      returnObject1.setLastUpdateUser(getString (rs, 23)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 24)); 
      returnObject.add (returnObject1);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT r.XRETAILERJPNPK_ID XRETAILERJPNPK_ID, r.RETAILER_CODE RETAILER_CODE, r.RETAILER_NAME RETAILER_NAME, r.BRANCH_NAME BRANCH_NAME, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.GS_CODE GS_CODE, r.GC_CODE GC_CODE, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.ND_CODE ND_CODE, r.MARKET_NAME MARKET_NAME, r.DEALER_ACTIVE_FLAG DEALER_ACTIVE_FLAG, r.Dealer_Group Dealer_Group, r.DEALER_ROLLOUT_FLAG DEALER_ROLLOUT_FLAG, r.BATCH_IND BATCH_IND, r.CREATE_DT CREATE_DT, r.CHANGED_DT CHANGED_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XRETAILERJPN r WHERE r.ND_CODE = ? ", pattern="tableAlias (XRETAILERJPN => com.ibm.daimler.dsea.entityObject.EObjXRetailerJPN, H_XRETAILERJPN => com.ibm.daimler.dsea.entityObject.EObjXRetailerJPN)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue1<EObjXRetailerJPN>> getXRetailerJPNByNDCode (Object[] parameters)
  {
    return queryIterator (getXRetailerJPNByNDCodeStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getXRetailerJPNByNDCodeStatementDescriptor = createStatementDescriptor (
    "getXRetailerJPNByNDCode(Object[])",
    "SELECT r.XRETAILERJPNPK_ID XRETAILERJPNPK_ID, r.RETAILER_CODE RETAILER_CODE, r.RETAILER_NAME RETAILER_NAME, r.BRANCH_NAME BRANCH_NAME, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.GS_CODE GS_CODE, r.GC_CODE GC_CODE, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.ND_CODE ND_CODE, r.MARKET_NAME MARKET_NAME, r.DEALER_ACTIVE_FLAG DEALER_ACTIVE_FLAG, r.Dealer_Group Dealer_Group, r.DEALER_ROLLOUT_FLAG DEALER_ROLLOUT_FLAG, r.BATCH_IND BATCH_IND, r.CREATE_DT CREATE_DT, r.CHANGED_DT CHANGED_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XRETAILERJPN r WHERE r.ND_CODE = ? ",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"xretailerjpnpk_id", "retailer_code", "retailer_name", "branch_name", "source_ident_tp_cd", "gs_code", "gc_code", "modify_sys_dt", "nd_code", "market_name", "dealer_active_flag", "dealer_group", "dealer_rollout_flag", "batch_ind", "create_dt", "changed_dt", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetXRetailerJPNByNDCodeParameterHandler (),
    new int[][]{{Types.VARCHAR}, {20}, {0}, {1}},
    null,
    new GetXRetailerJPNByNDCodeRowHandler (),
    new int[][]{ {Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 20, 255, 255, 19, 20, 20, 0, 20, 50, 5, 255, 5, 5, 0, 0, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    5);

  /**
   * @generated
   */
  public static class GetXRetailerJPNByNDCodeParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.VARCHAR, parameters[0], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetXRetailerJPNByNDCodeRowHandler extends BaseRowHandler<ResultQueue1<EObjXRetailerJPN>>
  {
    /**
     * @generated
     */
    public ResultQueue1<EObjXRetailerJPN> handle (java.sql.ResultSet rs, ResultQueue1<EObjXRetailerJPN> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue1<EObjXRetailerJPN> ();

      EObjXRetailerJPN returnObject1 = new EObjXRetailerJPN ();
      returnObject1.setXRetailerJPNpkId(getLongObject (rs, 1)); 
      returnObject1.setRetailerCode(getString (rs, 2)); 
      returnObject1.setRetailerName(getString (rs, 3)); 
      returnObject1.setBranchName(getString (rs, 4)); 
      returnObject1.setSourceIdentifier(getLongObject (rs, 5)); 
      returnObject1.setGSCode(getString (rs, 6)); 
      returnObject1.setGCCode(getString (rs, 7)); 
      returnObject1.setLastModifiedSystemDate(getTimestamp (rs, 8)); 
      returnObject1.setNDCode(getString (rs, 9)); 
      returnObject1.setMarketName(getString (rs, 10)); 
      returnObject1.setDealerActiveFlag(getString (rs, 11)); 
      returnObject1.setDealerGroup(getString (rs, 12)); 
      returnObject1.setDealerRolloutFlag(getString (rs, 13)); 
      returnObject1.setBatchInd(getString (rs, 14)); 
      returnObject1.setCreateDate(getTimestamp (rs, 15)); 
      returnObject1.setChangedDate(getTimestamp (rs, 16)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 17)); 
      returnObject1.setLastUpdateUser(getString (rs, 18)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 19)); 
      returnObject.add (returnObject1);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT r.H_XRETAILERJPNPK_ID hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.XRETAILERJPNPK_ID XRETAILERJPNPK_ID, r.RETAILER_CODE RETAILER_CODE, r.RETAILER_NAME RETAILER_NAME, r.BRANCH_NAME BRANCH_NAME, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.GS_CODE GS_CODE, r.GC_CODE GC_CODE, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.ND_CODE ND_CODE, r.MARKET_NAME MARKET_NAME, r.DEALER_ACTIVE_FLAG DEALER_ACTIVE_FLAG, r.Dealer_Group Dealer_Group, r.DEALER_ROLLOUT_FLAG DEALER_ROLLOUT_FLAG, r.BATCH_IND BATCH_IND, r.CREATE_DT CREATE_DT, r.CHANGED_DT CHANGED_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XRETAILERJPN r WHERE r.ND_CODE = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))", pattern="tableAlias (XRETAILERJPN => com.ibm.daimler.dsea.entityObject.EObjXRetailerJPN, H_XRETAILERJPN => com.ibm.daimler.dsea.entityObject.EObjXRetailerJPN)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue1<EObjXRetailerJPN>> getXRetailerJPNByNDCodeHistory (Object[] parameters)
  {
    return queryIterator (getXRetailerJPNByNDCodeHistoryStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getXRetailerJPNByNDCodeHistoryStatementDescriptor = createStatementDescriptor (
    "getXRetailerJPNByNDCodeHistory(Object[])",
    "SELECT r.H_XRETAILERJPNPK_ID hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.XRETAILERJPNPK_ID XRETAILERJPNPK_ID, r.RETAILER_CODE RETAILER_CODE, r.RETAILER_NAME RETAILER_NAME, r.BRANCH_NAME BRANCH_NAME, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.GS_CODE GS_CODE, r.GC_CODE GC_CODE, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.ND_CODE ND_CODE, r.MARKET_NAME MARKET_NAME, r.DEALER_ACTIVE_FLAG DEALER_ACTIVE_FLAG, r.Dealer_Group Dealer_Group, r.DEALER_ROLLOUT_FLAG DEALER_ROLLOUT_FLAG, r.BATCH_IND BATCH_IND, r.CREATE_DT CREATE_DT, r.CHANGED_DT CHANGED_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XRETAILERJPN r WHERE r.ND_CODE = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"historyidpk", "h_action_code", "h_created_by", "h_create_dt", "h_end_dt", "xretailerjpnpk_id", "retailer_code", "retailer_name", "branch_name", "source_ident_tp_cd", "gs_code", "gc_code", "modify_sys_dt", "nd_code", "market_name", "dealer_active_flag", "dealer_group", "dealer_rollout_flag", "batch_ind", "create_dt", "changed_dt", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetXRetailerJPNByNDCodeHistoryParameterHandler (),
    new int[][]{{Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP}, {20, 0, 0}, {0, 0, 0}, {1, 1, 1}},
    null,
    new GetXRetailerJPNByNDCodeHistoryRowHandler (),
    new int[][]{ {Types.BIGINT, Types.CHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 1, 20, 0, 0, 19, 20, 255, 255, 19, 20, 20, 0, 20, 50, 5, 255, 5, 5, 0, 0, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    6);

  /**
   * @generated
   */
  public static class GetXRetailerJPNByNDCodeHistoryParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.VARCHAR, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetXRetailerJPNByNDCodeHistoryRowHandler extends BaseRowHandler<ResultQueue1<EObjXRetailerJPN>>
  {
    /**
     * @generated
     */
    public ResultQueue1<EObjXRetailerJPN> handle (java.sql.ResultSet rs, ResultQueue1<EObjXRetailerJPN> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue1<EObjXRetailerJPN> ();

      EObjXRetailerJPN returnObject1 = new EObjXRetailerJPN ();
      returnObject1.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject1.setHistActionCode(getString (rs, 2)); 
      returnObject1.setHistCreatedBy(getString (rs, 3)); 
      returnObject1.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject1.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject1.setXRetailerJPNpkId(getLongObject (rs, 6)); 
      returnObject1.setRetailerCode(getString (rs, 7)); 
      returnObject1.setRetailerName(getString (rs, 8)); 
      returnObject1.setBranchName(getString (rs, 9)); 
      returnObject1.setSourceIdentifier(getLongObject (rs, 10)); 
      returnObject1.setGSCode(getString (rs, 11)); 
      returnObject1.setGCCode(getString (rs, 12)); 
      returnObject1.setLastModifiedSystemDate(getTimestamp (rs, 13)); 
      returnObject1.setNDCode(getString (rs, 14)); 
      returnObject1.setMarketName(getString (rs, 15)); 
      returnObject1.setDealerActiveFlag(getString (rs, 16)); 
      returnObject1.setDealerGroup(getString (rs, 17)); 
      returnObject1.setDealerRolloutFlag(getString (rs, 18)); 
      returnObject1.setBatchInd(getString (rs, 19)); 
      returnObject1.setCreateDate(getTimestamp (rs, 20)); 
      returnObject1.setChangedDate(getTimestamp (rs, 21)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 22)); 
      returnObject1.setLastUpdateUser(getString (rs, 23)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 24)); 
      returnObject.add (returnObject1);

    
      return returnObject;
    }
  }

}
