/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[cba04f438b7dc66152e3457c0d0e3cd0]
 */


package com.ibm.daimler.dsea.entityObject;

import java.util.Iterator;
import com.ibm.mdm.base.db.EntityMapping;
import com.ibm.pdq.annotation.Select;
import com.ibm.pdq.annotation.Update;

import com.ibm.daimler.dsea.entityObject.EObjXContractDetails;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * @generated
 */
public interface EObjXContractDetailsData {


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjXContractDetailsSql = "select CONTRACTPK_ID, CONT_ID, FINANCE_PRODUCT, CONTRACT_NUMBER, CONTRACT_ST_TP_CD, MARKET_NAME, Financial_Product_Group, ADDR_LINE_ONE, ADDR_LINE_TWO, ADDR_LINE_THREE, POSTAL_CODE, CITY_NAME, RESIDENCE_NUMBER, COUNTRY_TP_CD, BUILDING_NAME, STREET_NAME, STREET_NUMBER, SOURCE_IDENT_TP_CD, START_DT, END_DT, MODIFY_SYS_DT, ODDays, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from XCONTRACT where CONTRACTPK_ID = ? ";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String createEObjXContractDetailsSql = "insert into XCONTRACT (CONTRACTPK_ID, CONT_ID, FINANCE_PRODUCT, CONTRACT_NUMBER, CONTRACT_ST_TP_CD, MARKET_NAME, Financial_Product_Group, ADDR_LINE_ONE, ADDR_LINE_TWO, ADDR_LINE_THREE, POSTAL_CODE, CITY_NAME, RESIDENCE_NUMBER, COUNTRY_TP_CD, BUILDING_NAME, STREET_NAME, STREET_NUMBER, SOURCE_IDENT_TP_CD, START_DT, END_DT, MODIFY_SYS_DT, ODDays, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( :contractpkId, :contId, :financeProduct, :contractNumber, :contractStatus, :marketName, :financialProductGroup, :addressLineOne, :addressLineTwo, :addressLineThree, :postalCode, :cityName, :residenceNumber, :country, :buildingName, :streetName, :streetNumber, :sourceIdentifier, :startDate, :endDate, :lastModifiedSystemDate, :oDDays, :lastUpdateDt, :lastUpdateUser, :lastUpdateTxId)";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String updateEObjXContractDetailsSql = "update XCONTRACT set CONT_ID = :contId, FINANCE_PRODUCT = :financeProduct, CONTRACT_NUMBER = :contractNumber, CONTRACT_ST_TP_CD = :contractStatus, MARKET_NAME = :marketName, Financial_Product_Group = :financialProductGroup, ADDR_LINE_ONE = :addressLineOne, ADDR_LINE_TWO = :addressLineTwo, ADDR_LINE_THREE = :addressLineThree, POSTAL_CODE = :postalCode, CITY_NAME = :cityName, RESIDENCE_NUMBER = :residenceNumber, COUNTRY_TP_CD = :country, BUILDING_NAME = :buildingName, STREET_NAME = :streetName, STREET_NUMBER = :streetNumber, SOURCE_IDENT_TP_CD = :sourceIdentifier, START_DT = :startDate, END_DT = :endDate, MODIFY_SYS_DT = :lastModifiedSystemDate, ODDays = :oDDays, LAST_UPDATE_DT = :lastUpdateDt, LAST_UPDATE_USER = :lastUpdateUser, LAST_UPDATE_TX_ID = :lastUpdateTxId where CONTRACTPK_ID = :contractpkId and LAST_UPDATE_DT = :oldLastUpdateDt";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String deleteEObjXContractDetailsSql = "delete from XCONTRACT where CONTRACTPK_ID = ?";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXContractDetailsKeyField = "EObjXContractDetails.contractpkId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXContractDetailsGetFields =
    "EObjXContractDetails.contractpkId," +
    "EObjXContractDetails.contId," +
    "EObjXContractDetails.financeProduct," +
    "EObjXContractDetails.contractNumber," +
    "EObjXContractDetails.contractStatus," +
    "EObjXContractDetails.marketName," +
    "EObjXContractDetails.financialProductGroup," +
    "EObjXContractDetails.addressLineOne," +
    "EObjXContractDetails.addressLineTwo," +
    "EObjXContractDetails.addressLineThree," +
    "EObjXContractDetails.postalCode," +
    "EObjXContractDetails.cityName," +
    "EObjXContractDetails.residenceNumber," +
    "EObjXContractDetails.country," +
    "EObjXContractDetails.buildingName," +
    "EObjXContractDetails.streetName," +
    "EObjXContractDetails.streetNumber," +
    "EObjXContractDetails.sourceIdentifier," +
    "EObjXContractDetails.startDate," +
    "EObjXContractDetails.endDate," +
    "EObjXContractDetails.lastModifiedSystemDate," +
    "EObjXContractDetails.oDDays," +
    "EObjXContractDetails.lastUpdateDt," +
    "EObjXContractDetails.lastUpdateUser," +
    "EObjXContractDetails.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXContractDetailsAllFields =
    "com.ibm.daimler.dsea.entityObject.EObjXContractDetails.contractpkId," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractDetails.contId," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractDetails.financeProduct," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractDetails.contractNumber," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractDetails.contractStatus," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractDetails.marketName," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractDetails.financialProductGroup," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractDetails.addressLineOne," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractDetails.addressLineTwo," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractDetails.addressLineThree," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractDetails.postalCode," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractDetails.cityName," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractDetails.residenceNumber," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractDetails.country," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractDetails.buildingName," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractDetails.streetName," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractDetails.streetNumber," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractDetails.sourceIdentifier," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractDetails.startDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractDetails.endDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractDetails.lastModifiedSystemDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractDetails.oDDays," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractDetails.lastUpdateDt," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractDetails.lastUpdateUser," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractDetails.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXContractDetailsUpdateFields =
    "com.ibm.daimler.dsea.entityObject.EObjXContractDetails.contId," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractDetails.financeProduct," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractDetails.contractNumber," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractDetails.contractStatus," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractDetails.marketName," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractDetails.financialProductGroup," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractDetails.addressLineOne," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractDetails.addressLineTwo," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractDetails.addressLineThree," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractDetails.postalCode," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractDetails.cityName," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractDetails.residenceNumber," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractDetails.country," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractDetails.buildingName," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractDetails.streetName," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractDetails.streetNumber," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractDetails.sourceIdentifier," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractDetails.startDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractDetails.endDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractDetails.lastModifiedSystemDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractDetails.oDDays," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractDetails.lastUpdateDt," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractDetails.lastUpdateUser," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractDetails.lastUpdateTxId," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractDetails.contractpkId," +
    "com.ibm.daimler.dsea.entityObject.EObjXContractDetails.oldLastUpdateDt";   

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Select XContractDetails by parameters.
   * @generated
   */
  @Select(sql=getEObjXContractDetailsSql)
  @EntityMapping(parameters=EObjXContractDetailsKeyField, results=EObjXContractDetailsGetFields)
  Iterator<EObjXContractDetails> getEObjXContractDetails(Long contractpkId);  
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Create XContractDetails by EObjXContractDetails Object.
   * @generated
   */
  @Update(sql=createEObjXContractDetailsSql)
  @EntityMapping(parameters=EObjXContractDetailsAllFields)
    int createEObjXContractDetails(EObjXContractDetails e); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Update one XContractDetails by EObjXContractDetails object.
   * @generated
   */
  @Update(sql=updateEObjXContractDetailsSql)
  @EntityMapping(parameters=EObjXContractDetailsUpdateFields)
    int updateEObjXContractDetails(EObjXContractDetails e); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Delete XContractDetails by parameters.
   * @generated
   */
  @Update(sql=deleteEObjXContractDetailsSql)
  @EntityMapping(parameters=EObjXContractDetailsKeyField)
  int deleteEObjXContractDetails(Long contractpkId);

}

