/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[1c6b2b39bb3624dd7bc71a2f4e37f4c2]
 */


package com.ibm.daimler.dsea.entityObject;

import java.util.Iterator;
import com.ibm.mdm.base.db.EntityMapping;
import com.ibm.pdq.annotation.Select;
import com.ibm.pdq.annotation.Update;

import com.dwl.tcrm.coreParty.entityObject.EObjOrgName;

import com.ibm.daimler.dsea.entityObject.EObjXOrgNameExt;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * @generated
 */
public interface EObjXOrgNameExtData {


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjXOrgNameExtSql = "select XMODIFY_SYS_DT, XORG_NAME_LOCAL, XORGNAME_RETAILER_FLAG, X_BPID, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from ORGNAME where ORG_NAME_ID = ? ";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String createEObjXOrgNameExtSql = "insert into ORGNAME (LAST_USED_DT, LAST_VERIFIED_DT, END_DT, ORG_NAME, ORG_NAME_ID, CONT_ID, START_DT, S_ORG_NAME, SOURCE_IDENT_TP_CD, ORG_NAME_TP_CD, P_ORG_NAME, STANDARD_IND, NAME_SEARCH_KEY, XMODIFY_SYS_DT, XORG_NAME_LOCAL, XORGNAME_RETAILER_FLAG, X_BPID, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( ?1.lastUsedDt, ?1.lastVerifiedDt, ?1.endDt, ?1.orgName, ?1.orgNameIdPK, ?1.contId, ?1.startDt, ?1.sOrgName, ?1.sourceIdentTpCd, ?1.orgNameTpCd, ?1.pOrgName, ?1.orgNameStandardInd, ?1.nameSearchKey, ?2.xLastModifiedSystemDate, ?2.xOrganizationNameLocal, ?2.xOrgNameRetailerFlag, ?2.x_BPID, ?1.lastUpdateDt, ?1.lastUpdateUser, ?1.lastUpdateTxId)";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String updateEObjXOrgNameExtSql = "update ORGNAME set LAST_USED_DT = ?1.lastUsedDt, LAST_VERIFIED_DT = ?1.lastVerifiedDt, END_DT = ?1.endDt, ORG_NAME = ?1.orgName, CONT_ID = ?1.contId, START_DT = ?1.startDt, S_ORG_NAME = ?1.sOrgName, SOURCE_IDENT_TP_CD = ?1.sourceIdentTpCd, ORG_NAME_TP_CD = ?1.orgNameTpCd, P_ORG_NAME = ?1.pOrgName, STANDARD_IND = ?1.orgNameStandardInd, NAME_SEARCH_KEY = ?1.nameSearchKey, XMODIFY_SYS_DT = ?2.xLastModifiedSystemDate, XORG_NAME_LOCAL = ?2.xOrganizationNameLocal, XORGNAME_RETAILER_FLAG = ?2.xOrgNameRetailerFlag, X_BPID = ?2.x_BPID, LAST_UPDATE_DT = ?1.lastUpdateDt, LAST_UPDATE_USER = ?1.lastUpdateUser, LAST_UPDATE_TX_ID = ?1.lastUpdateTxId where ORG_NAME_ID = ?1.orgNameIdPK and LAST_UPDATE_DT = ?1.oldLastUpdateDt";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String deleteEObjXOrgNameExtSql = "delete from ORGNAME where ORG_NAME_ID = ?";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXOrgNameExtKeyField = "EObjXOrgNameExt.orgNameIdPK";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXOrgNameExtGetFields =
    "EObjXOrgNameExt.xLastModifiedSystemDate," +
    "EObjXOrgNameExt.xOrganizationNameLocal," +
    "EObjXOrgNameExt.xOrgNameRetailerFlag," +
    "EObjXOrgNameExt.x_BPID," +
    "EObjXOrgNameExt.lastUpdateDt," +
    "EObjXOrgNameExt.lastUpdateUser," +
    "EObjXOrgNameExt.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXOrgNameExtAllFields =
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.lastUsedDt," +
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.lastVerifiedDt," +
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.endDt," +
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.orgName," +
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.orgNameIdPK," +
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.contId," +
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.startDt," +
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.sOrgName," +
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.sourceIdentTpCd," +
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.orgNameTpCd," +
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.pOrgName," +
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.orgNameStandardInd," +
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.nameSearchKey," +
    "com.ibm.daimler.dsea.entityObject.EObjXOrgNameExt.xLastModifiedSystemDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXOrgNameExt.xOrganizationNameLocal," +
    "com.ibm.daimler.dsea.entityObject.EObjXOrgNameExt.xOrgNameRetailerFlag," +
    "com.ibm.daimler.dsea.entityObject.EObjXOrgNameExt.x_BPID," +
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.lastUpdateDt," +
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.lastUpdateUser," +
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXOrgNameExtUpdateFields =
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.lastUsedDt," +
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.lastVerifiedDt," +
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.endDt," +
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.orgName," +
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.contId," +
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.startDt," +
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.sOrgName," +
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.sourceIdentTpCd," +
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.orgNameTpCd," +
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.pOrgName," +
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.orgNameStandardInd," +
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.nameSearchKey," +
    "com.ibm.daimler.dsea.entityObject.EObjXOrgNameExt.xLastModifiedSystemDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXOrgNameExt.xOrganizationNameLocal," +
    "com.ibm.daimler.dsea.entityObject.EObjXOrgNameExt.xOrgNameRetailerFlag," +
    "com.ibm.daimler.dsea.entityObject.EObjXOrgNameExt.x_BPID," +
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.lastUpdateDt," +
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.lastUpdateUser," +
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.lastUpdateTxId," +
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.orgNameIdPK," +
    "com.dwl.tcrm.coreParty.entityObject.EObjOrgName.oldLastUpdateDt";   

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Select XOrgName by parameters.
   * @generated
   */
  @Select(sql=getEObjXOrgNameExtSql)
  @EntityMapping(parameters=EObjXOrgNameExtKeyField, results=EObjXOrgNameExtGetFields)
  Iterator<EObjXOrgNameExt> getEObjXOrgNameExt(Long orgNameIdPK);  
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Create XOrgName by EObjXOrgNameExt Object.
   * @generated
   */
  @Update(sql=createEObjXOrgNameExtSql)
  @EntityMapping(parameters=EObjXOrgNameExtAllFields)
    int createEObjXOrgNameExt(EObjOrgName e1, EObjXOrgNameExt e2); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Update one XOrgName by EObjXOrgNameExt object.
   * @generated
   */
  @Update(sql=updateEObjXOrgNameExtSql)
  @EntityMapping(parameters=EObjXOrgNameExtUpdateFields)
    int updateEObjXOrgNameExt(EObjOrgName e1, EObjXOrgNameExt e2); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Delete XOrgName by parameters.
   * @generated
   */
  @Update(sql=deleteEObjXOrgNameExtSql)
  @EntityMapping(parameters=EObjXOrgNameExtKeyField)
  int deleteEObjXOrgNameExt(Long orgNameIdPK);

}

