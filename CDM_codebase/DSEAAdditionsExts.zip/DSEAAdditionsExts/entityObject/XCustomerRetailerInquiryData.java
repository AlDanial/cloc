/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[dff5828a2f105914a6803cb192ca4823]
 */

package com.ibm.daimler.dsea.entityObject;


import com.ibm.mdm.base.db.ResultQueue1;
import java.util.Iterator;
import com.ibm.mdm.base.db.EntityMapping;
import com.ibm.pdq.annotation.Select;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * @generated
 */
public interface XCustomerRetailerInquiryData {
  
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String tableAliasString = "tableAlias (" + 
                                            "XCUSTOMERRETAILER => com.ibm.daimler.dsea.entityObject.EObjXCustomerRetailer, " +
                                            "H_XCUSTOMERRETAILER => com.ibm.daimler.dsea.entityObject.EObjXCustomerRetailer" +
                                            ")";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getXCustomerRetailerSql = "SELECT r.CUSTOMERRETAILERPK_ID CUSTOMERRETAILERPK_ID, r.CONT_ID CONT_ID, r.RETAILER_ID RETAILER_ID, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.START_DT START_DT, r.END_DT END_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XCUSTOMERRETAILER r WHERE r.CUSTOMERRETAILERPK_ID = ? ";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXCustomerRetailerParameters =
    "EObjXCustomerRetailer.CustomerRetailerpkId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXCustomerRetailerResults =
    "EObjXCustomerRetailer.CustomerRetailerpkId," +
    "EObjXCustomerRetailer.ContId," +
    "EObjXCustomerRetailer.RetailerId," +
    "EObjXCustomerRetailer.SourceIdentifier," +
    "EObjXCustomerRetailer.StartDate," +
    "EObjXCustomerRetailer.EndDate," +
    "EObjXCustomerRetailer.lastUpdateDt," +
    "EObjXCustomerRetailer.lastUpdateUser," +
    "EObjXCustomerRetailer.lastUpdateTxId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getXCustomerRetailerHistorySql = "SELECT r.H_CUSTOMERRETAILERPK_ID hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.CUSTOMERRETAILERPK_ID CUSTOMERRETAILERPK_ID, r.CONT_ID CONT_ID, r.RETAILER_ID RETAILER_ID, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.START_DT START_DT, r.END_DT END_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XCUSTOMERRETAILER r WHERE r.H_CUSTOMERRETAILERPK_ID = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXCustomerRetailerHistoryParameters =
    "EObjXCustomerRetailer.CustomerRetailerpkId," +
    "EObjXCustomerRetailer.lastUpdateDt," +
    "EObjXCustomerRetailer.lastUpdateDt";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXCustomerRetailerHistoryResults =
    "EObjXCustomerRetailer.historyIdPK," +
    "EObjXCustomerRetailer.histActionCode," +
    "EObjXCustomerRetailer.histCreatedBy," +
    "EObjXCustomerRetailer.histCreateDt," +
    "EObjXCustomerRetailer.histEndDt," +
    "EObjXCustomerRetailer.CustomerRetailerpkId," +
    "EObjXCustomerRetailer.ContId," +
    "EObjXCustomerRetailer.RetailerId," +
    "EObjXCustomerRetailer.SourceIdentifier," +
    "EObjXCustomerRetailer.StartDate," +
    "EObjXCustomerRetailer.EndDate," +
    "EObjXCustomerRetailer.lastUpdateDt," +
    "EObjXCustomerRetailer.lastUpdateUser," +
    "EObjXCustomerRetailer.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getAllXCustomerRetailerByPartyIdSql = "SELECT r.CUSTOMERRETAILERPK_ID CUSTOMERRETAILERPK_ID, r.CONT_ID CONT_ID, r.RETAILER_ID RETAILER_ID, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.START_DT START_DT, r.END_DT END_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XCUSTOMERRETAILER r WHERE r.CONT_ID = ? ";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getAllXCustomerRetailerByPartyIdParameters =
    "EObjXCustomerRetailer.ContId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getAllXCustomerRetailerByPartyIdResults =
    "EObjXCustomerRetailer.CustomerRetailerpkId," +
    "EObjXCustomerRetailer.ContId," +
    "EObjXCustomerRetailer.RetailerId," +
    "EObjXCustomerRetailer.SourceIdentifier," +
    "EObjXCustomerRetailer.StartDate," +
    "EObjXCustomerRetailer.EndDate," +
    "EObjXCustomerRetailer.lastUpdateDt," +
    "EObjXCustomerRetailer.lastUpdateUser," +
    "EObjXCustomerRetailer.lastUpdateTxId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getAllXCustomerRetailerByPartyIdHistorySql = "SELECT r.H_CUSTOMERRETAILERPK_ID hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.CUSTOMERRETAILERPK_ID CUSTOMERRETAILERPK_ID, r.CONT_ID CONT_ID, r.RETAILER_ID RETAILER_ID, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.START_DT START_DT, r.END_DT END_DT, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XCUSTOMERRETAILER r WHERE r.CONT_ID = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getAllXCustomerRetailerByPartyIdHistoryParameters =
    "EObjXCustomerRetailer.ContId," +
    "EObjXCustomerRetailer.lastUpdateDt," +
    "EObjXCustomerRetailer.lastUpdateDt";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getAllXCustomerRetailerByPartyIdHistoryResults =
    "EObjXCustomerRetailer.historyIdPK," +
    "EObjXCustomerRetailer.histActionCode," +
    "EObjXCustomerRetailer.histCreatedBy," +
    "EObjXCustomerRetailer.histCreateDt," +
    "EObjXCustomerRetailer.histEndDt," +
    "EObjXCustomerRetailer.CustomerRetailerpkId," +
    "EObjXCustomerRetailer.ContId," +
    "EObjXCustomerRetailer.RetailerId," +
    "EObjXCustomerRetailer.SourceIdentifier," +
    "EObjXCustomerRetailer.StartDate," +
    "EObjXCustomerRetailer.EndDate," +
    "EObjXCustomerRetailer.lastUpdateDt," +
    "EObjXCustomerRetailer.lastUpdateUser," +
    "EObjXCustomerRetailer.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getXCustomerRetailerSql, pattern=tableAliasString)
  @EntityMapping(parameters=getXCustomerRetailerParameters, results=getXCustomerRetailerResults)
  Iterator<ResultQueue1<EObjXCustomerRetailer>> getXCustomerRetailer(Object[] parameters);  


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getXCustomerRetailerHistorySql, pattern=tableAliasString)
  @EntityMapping(parameters=getXCustomerRetailerHistoryParameters, results=getXCustomerRetailerHistoryResults)
  Iterator<ResultQueue1<EObjXCustomerRetailer>> getXCustomerRetailerHistory(Object[] parameters);


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getAllXCustomerRetailerByPartyIdSql, pattern=tableAliasString)
  @EntityMapping(parameters=getAllXCustomerRetailerByPartyIdParameters, results=getAllXCustomerRetailerByPartyIdResults)
  Iterator<ResultQueue1<EObjXCustomerRetailer>> getAllXCustomerRetailerByPartyId(Object[] parameters);


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getAllXCustomerRetailerByPartyIdHistorySql, pattern=tableAliasString)
  @EntityMapping(parameters=getAllXCustomerRetailerByPartyIdHistoryParameters, results=getAllXCustomerRetailerByPartyIdHistoryResults)
  Iterator<ResultQueue1<EObjXCustomerRetailer>> getAllXCustomerRetailerByPartyIdHistory(Object[] parameters);  


}


