/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[4fe9a92a0b32ae9b8181cc3f52c621b1]
 */


package com.ibm.daimler.dsea.entityObject;

import java.util.Iterator;
import com.ibm.mdm.base.db.EntityMapping;
import com.ibm.pdq.annotation.Select;
import com.ibm.pdq.annotation.Update;

import com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleKOR;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * @generated
 */
public interface EObjXCustomerVehicleKORData {


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjXCustomerVehicleKORSql = "select XCustomer_Vehicle_KORpk_Id, Cont_Id, VEHICLE_ID, RETAILER_ID, CONNECTME_USAGE_TP_CD, LICENSE_PLATE, VEHICLE_SALES_TP_CD, VEHICLE_USAGE_TP_CD, VEHICLE_OWNERSHIP, START_DT, END_DT, SOURCE_IDENT_TP_CD, CUSTVEHRET_FLAG, DELETE_FLAG, SFDC_ID, SERVICE_NAME, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from XCUSTOMERVEHICLEKOR where XCustomer_Vehicle_KORpk_Id = ? ";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String createEObjXCustomerVehicleKORSql = "insert into XCUSTOMERVEHICLEKOR (XCustomer_Vehicle_KORpk_Id, Cont_Id, VEHICLE_ID, RETAILER_ID, CONNECTME_USAGE_TP_CD, LICENSE_PLATE, VEHICLE_SALES_TP_CD, VEHICLE_USAGE_TP_CD, VEHICLE_OWNERSHIP, START_DT, END_DT, SOURCE_IDENT_TP_CD, CUSTVEHRET_FLAG, DELETE_FLAG, SFDC_ID, SERVICE_NAME, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( :xCustomerVehicleKORpkId, :contId, :vehicleId, :retailerId, :connectMeUsage, :licensePlate, :vehicleSales, :vehicleUsage, :vehicleOwnerShip, :startDate, :endDate, :sourceIdentifier, :custVehRetFlag, :deleteFlag, :sFDCId, :serviceName, :lastUpdateDt, :lastUpdateUser, :lastUpdateTxId)";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String updateEObjXCustomerVehicleKORSql = "update XCUSTOMERVEHICLEKOR set Cont_Id = :contId, VEHICLE_ID = :vehicleId, RETAILER_ID = :retailerId, CONNECTME_USAGE_TP_CD = :connectMeUsage, LICENSE_PLATE = :licensePlate, VEHICLE_SALES_TP_CD = :vehicleSales, VEHICLE_USAGE_TP_CD = :vehicleUsage, VEHICLE_OWNERSHIP = :vehicleOwnerShip, START_DT = :startDate, END_DT = :endDate, SOURCE_IDENT_TP_CD = :sourceIdentifier, CUSTVEHRET_FLAG = :custVehRetFlag, DELETE_FLAG = :deleteFlag, SFDC_ID = :sFDCId, SERVICE_NAME = :serviceName, LAST_UPDATE_DT = :lastUpdateDt, LAST_UPDATE_USER = :lastUpdateUser, LAST_UPDATE_TX_ID = :lastUpdateTxId where XCustomer_Vehicle_KORpk_Id = :xCustomerVehicleKORpkId and LAST_UPDATE_DT = :oldLastUpdateDt";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String deleteEObjXCustomerVehicleKORSql = "delete from XCUSTOMERVEHICLEKOR where XCustomer_Vehicle_KORpk_Id = ?";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXCustomerVehicleKORKeyField = "EObjXCustomerVehicleKOR.xCustomerVehicleKORpkId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXCustomerVehicleKORGetFields =
   // "EObjXCustomerVehicleKOR.groupName," +
    "EObjXCustomerVehicleKOR.xCustomerVehicleKORpkId," +
    "EObjXCustomerVehicleKOR.contId," +
    "EObjXCustomerVehicleKOR.vehicleId," +
    "EObjXCustomerVehicleKOR.retailerId," +
    "EObjXCustomerVehicleKOR.connectMeUsage," +
    "EObjXCustomerVehicleKOR.licensePlate," +
    "EObjXCustomerVehicleKOR.vehicleSales," +
    "EObjXCustomerVehicleKOR.vehicleUsage," +
    "EObjXCustomerVehicleKOR.vehicleOwnerShip," +
    "EObjXCustomerVehicleKOR.startDate," +
    "EObjXCustomerVehicleKOR.endDate," +
    "EObjXCustomerVehicleKOR.sourceIdentifier," +
    "EObjXCustomerVehicleKOR.custVehRetFlag," +
    "EObjXCustomerVehicleKOR.deleteFlag," +
    "EObjXCustomerVehicleKOR.sFDCId," +
    "EObjXCustomerVehicleKOR.serviceName," +
    "EObjXCustomerVehicleKOR.lastUpdateDt," +
    "EObjXCustomerVehicleKOR.lastUpdateUser," +
    "EObjXCustomerVehicleKOR.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXCustomerVehicleKORAllFields =
   // "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleKOR.groupName," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleKOR.xCustomerVehicleKORpkId," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleKOR.contId," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleKOR.vehicleId," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleKOR.retailerId," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleKOR.connectMeUsage," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleKOR.licensePlate," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleKOR.vehicleSales," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleKOR.vehicleUsage," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleKOR.vehicleOwnerShip," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleKOR.startDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleKOR.endDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleKOR.sourceIdentifier," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleKOR.custVehRetFlag," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleKOR.deleteFlag," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleKOR.sFDCId," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleKOR.serviceName," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleKOR.lastUpdateDt," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleKOR.lastUpdateUser," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleKOR.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXCustomerVehicleKORUpdateFields =
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleKOR.contId," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleKOR.vehicleId," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleKOR.retailerId," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleKOR.connectMeUsage," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleKOR.licensePlate," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleKOR.vehicleSales," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleKOR.vehicleUsage," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleKOR.vehicleOwnerShip," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleKOR.startDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleKOR.endDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleKOR.sourceIdentifier," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleKOR.custVehRetFlag," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleKOR.deleteFlag," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleKOR.sFDCId," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleKOR.serviceName," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleKOR.lastUpdateDt," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleKOR.lastUpdateUser," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleKOR.lastUpdateTxId," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleKOR.xCustomerVehicleKORpkId," +
    "com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleKOR.oldLastUpdateDt";   

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Select XCustomerVehicleKOR by parameters.
   * @generated
   */
  @Select(sql=getEObjXCustomerVehicleKORSql)
  @EntityMapping(parameters=EObjXCustomerVehicleKORKeyField, results=EObjXCustomerVehicleKORGetFields)
  Iterator<EObjXCustomerVehicleKOR> getEObjXCustomerVehicleKOR(Long xCustomerVehicleKORpkId);  
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Create XCustomerVehicleKOR by EObjXCustomerVehicleKOR Object.
   * @generated
   */
  @Update(sql=createEObjXCustomerVehicleKORSql)
  @EntityMapping(parameters=EObjXCustomerVehicleKORAllFields)
    int createEObjXCustomerVehicleKOR(EObjXCustomerVehicleKOR e); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Update one XCustomerVehicleKOR by EObjXCustomerVehicleKOR object.
   * @generated
   */
  @Update(sql=updateEObjXCustomerVehicleKORSql)
  @EntityMapping(parameters=EObjXCustomerVehicleKORUpdateFields)
    int updateEObjXCustomerVehicleKOR(EObjXCustomerVehicleKOR e); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Delete XCustomerVehicleKOR by parameters.
   * @generated
   */
  @Update(sql=deleteEObjXCustomerVehicleKORSql)
  @EntityMapping(parameters=EObjXCustomerVehicleKORKeyField)
  int deleteEObjXCustomerVehicleKOR(Long xCustomerVehicleKORpkId);

}

