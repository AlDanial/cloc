package com.ibm.daimler.dsea.entityObject;

import com.ibm.pdq.runtime.generator.BaseParameterHandler;
import java.util.Iterator;
import com.ibm.daimler.dsea.entityObject.EObjXContactRelExt;
import java.sql.PreparedStatement;
import com.ibm.pdq.runtime.statement.StatementDescriptor;
import com.ibm.pdq.runtime.generator.BaseData;
import java.sql.SQLException;
import com.ibm.pdq.annotation.Metadata;
import com.dwl.tcrm.coreParty.entityObject.EObjContactRel;
import com.ibm.pdq.runtime.generator.BaseRowHandler;
import com.ibm.pdq.runtime.statement.SqlStatementType;
import java.sql.Types;


/**
 * <!-- begin-user-doc -->
 * 
 * <!-- end-user-doc -->
 * 
 * @generated
 */
public class EObjXContactRelExtDataImpl  extends BaseData implements EObjXContactRelExtData
{

  /**
   * @generated
   */
  public static final String generatorVersion = "3.200.75";

  /**
   * @generated
   */
  public static final String identifier = "EObjXContactRelExtData";

  /**
   * @generated
   */
  public static final long generationTime = 0x000001642283fa93L;

  /**
   * @generated
   */
  public static final String collection = "NULLID";

  /**
   * @generated
   */
  public static final String packageVersion = null;

  /**
   * @generated
   */
  public static final boolean forceSingleBindIsolation = false;

  /**
   * @generated
   */
  public EObjXContactRelExtDataImpl()
  {
    super();
  } 

  /**
   * @generated
   */
  public String getGeneratorVersion()
  {
    return generatorVersion;
  }

  /**
   * @Select( sql="select XRETAILER_CODE, XCONTACT_ROLE, XCONTACT_POSITION, XCONTACTREL_RETAILER_FLAG, XSOURCE_IDENT_TP_CD, XMODIFY_SYS_DT, DELETE_FLAG, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from CONTACTREL where CONT_REL_ID = ? " )
   * 
   * @generated
   */
  public Iterator<EObjXContactRelExt> getEObjXContactRelExt (Long contRelIdPK)
  {
    return queryIterator (getEObjXContactRelExtStatementDescriptor, contRelIdPK);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getEObjXContactRelExtStatementDescriptor = createStatementDescriptor (
    "getEObjXContactRelExt(Long)",
    "select XRETAILER_CODE, XCONTACT_ROLE, XCONTACT_POSITION, XCONTACTREL_RETAILER_FLAG, XSOURCE_IDENT_TP_CD, XMODIFY_SYS_DT, DELETE_FLAG, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from CONTACTREL where CONT_REL_ID = ? ",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"xretailer_code", "xcontact_role", "xcontact_position", "xcontactrel_retailer_flag", "xsource_ident_tp_cd", "xmodify_sys_dt", "delete_flag", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetEObjXContactRelExtParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetEObjXContactRelExtRowHandler (),
    new int[][]{ {Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {255, 255, 255, 5, 19, 0, 10, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    1);

  /**
   * @generated
   */
  public static class GetEObjXContactRelExtParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setLong (stmt, 1, Types.BIGINT, (Long)parameters[0]);
    }
  }

  /**
   * @generated
   */
  public static class GetEObjXContactRelExtRowHandler extends BaseRowHandler<EObjXContactRelExt>
  {
    /**
     * @generated
     */
    public EObjXContactRelExt handle (java.sql.ResultSet rs, EObjXContactRelExt returnObject) throws java.sql.SQLException
    {
      returnObject = new EObjXContactRelExt ();
      returnObject.setXRetailerCode(getString (rs, 1)); 
      returnObject.setXContactRole(getString (rs, 2)); 
      returnObject.setXContactPosition(getString (rs, 3)); 
      returnObject.setXContactRelRetailerFlag(getString (rs, 4)); 
      returnObject.setXSourceIdentifier(getLongObject (rs, 5)); 
      returnObject.setXLastModifiedSystemDate(getTimestamp (rs, 6)); 
      returnObject.setDeleteFlag(getString (rs, 7)); 
      returnObject.setLastUpdateDt(getTimestamp (rs, 8)); 
      returnObject.setLastUpdateUser(getString (rs, 9)); 
      returnObject.setLastUpdateTxId(getLongObject (rs, 10)); 
    
      return returnObject;
    }
  }

  /**
   * @Update( sql="insert into CONTACTREL (END_DT, CONT_REL_ID, REL_DESC, FROM_CONT_ID, TO_CONT_ID, START_DT, REL_TP_CD, END_REASON_TP_CD, REL_ASSIGN_TP_CD, XRETAILER_CODE, XCONTACT_ROLE, XCONTACT_POSITION, XCONTACTREL_RETAILER_FLAG, XSOURCE_IDENT_TP_CD, XMODIFY_SYS_DT, DELETE_FLAG, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( ?1.endDt, ?1.contRelIdPK, ?1.relDesc, ?1.fromContId, ?1.toContId, ?1.startDt, ?1.relTpCd, ?1.endReasonTpCd, ?1.relAssignTpCd, ?2.xRetailerCode, ?2.xContactRole, ?2.xContactPosition, ?2.xContactRelRetailerFlag, ?2.xSourceIdentifier, ?2.xLastModifiedSystemDate, ?2.deleteFlag, ?1.lastUpdateDt, ?1.lastUpdateUser, ?1.lastUpdateTxId)" )
   * 
   * @generated
   */
  public int createEObjXContactRelExt (EObjContactRel e1, EObjXContactRelExt e2)
  {
    return update (createEObjXContactRelExtStatementDescriptor, e1, e2);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor createEObjXContactRelExtStatementDescriptor = createStatementDescriptor (
    "createEObjXContactRelExt(com.dwl.tcrm.coreParty.entityObject.EObjContactRel, com.ibm.daimler.dsea.entityObject.EObjXContactRelExt)",
    "insert into CONTACTREL (END_DT, CONT_REL_ID, REL_DESC, FROM_CONT_ID, TO_CONT_ID, START_DT, REL_TP_CD, END_REASON_TP_CD, REL_ASSIGN_TP_CD, XRETAILER_CODE, XCONTACT_ROLE, XCONTACT_POSITION, XCONTACTREL_RETAILER_FLAG, XSOURCE_IDENT_TP_CD, XMODIFY_SYS_DT, DELETE_FLAG, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values(  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? )",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.INSERT,
    null,
    new CreateEObjXContactRelExtParameterHandler (),
    new int[][]{{Types.TIMESTAMP, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {0, 19, 255, 19, 19, 0, 19, 19, 19, 255, 255, 255, 5, 19, 0, 10, 0, 0, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    2);

  /**
   * @generated
   */
  public static class CreateEObjXContactRelExtParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      EObjContactRel bean0 = (EObjContactRel) parameters[0];
      setTimestamp (stmt, 1, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getEndDt());
      setLong (stmt, 2, Types.BIGINT, (Long)bean0.getContRelIdPK());
      setString (stmt, 3, Types.VARCHAR, (String)bean0.getRelDesc());
      setLong (stmt, 4, Types.BIGINT, (Long)bean0.getFromContId());
      setLong (stmt, 5, Types.BIGINT, (Long)bean0.getToContId());
      setTimestamp (stmt, 6, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getStartDt());
      setLong (stmt, 7, Types.BIGINT, (Long)bean0.getRelTpCd());
      setLong (stmt, 8, Types.BIGINT, (Long)bean0.getEndReasonTpCd());
      setLong (stmt, 9, Types.BIGINT, (Long)bean0.getRelAssignTpCd());
      EObjXContactRelExt bean1 = (EObjXContactRelExt) parameters[1];
      setString (stmt, 10, Types.VARCHAR, (String)bean1.getXRetailerCode());
      setString (stmt, 11, Types.VARCHAR, (String)bean1.getXContactRole());
      setString (stmt, 12, Types.VARCHAR, (String)bean1.getXContactPosition());
      setString (stmt, 13, Types.VARCHAR, (String)bean1.getXContactRelRetailerFlag());
      setLong (stmt, 14, Types.BIGINT, (Long)bean1.getXSourceIdentifier());
      setTimestamp (stmt, 15, Types.TIMESTAMP, (java.sql.Timestamp)bean1.getXLastModifiedSystemDate());
      setString (stmt, 16, Types.VARCHAR, (String)bean1.getDeleteFlag());
      setTimestamp (stmt, 17, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUpdateDt());
      setString (stmt, 18, Types.VARCHAR, (String)bean0.getLastUpdateUser());
      setLong (stmt, 19, Types.BIGINT, (Long)bean0.getLastUpdateTxId());
    }
  }

  /**
   * @Update( sql="update CONTACTREL set END_DT = ?1.endDt, REL_DESC = ?1.relDesc, FROM_CONT_ID = ?1.fromContId, TO_CONT_ID = ?1.toContId, START_DT = ?1.startDt, REL_TP_CD = ?1.relTpCd, END_REASON_TP_CD = ?1.endReasonTpCd, REL_ASSIGN_TP_CD = ?1.relAssignTpCd, XRETAILER_CODE = ?2.xRetailerCode, XCONTACT_ROLE = ?2.xContactRole, XCONTACT_POSITION = ?2.xContactPosition, XCONTACTREL_RETAILER_FLAG = ?2.xContactRelRetailerFlag, XSOURCE_IDENT_TP_CD = ?2.xSourceIdentifier, XMODIFY_SYS_DT = ?2.xLastModifiedSystemDate, DELETE_FLAG = ?2.deleteFlag, LAST_UPDATE_DT = ?1.lastUpdateDt, LAST_UPDATE_USER = ?1.lastUpdateUser, LAST_UPDATE_TX_ID = ?1.lastUpdateTxId where CONT_REL_ID = ?1.contRelIdPK and LAST_UPDATE_DT = ?1.oldLastUpdateDt" )
   * 
   * @generated
   */
  public int updateEObjXContactRelExt (EObjContactRel e1, EObjXContactRelExt e2)
  {
    return update (updateEObjXContactRelExtStatementDescriptor, e1, e2);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor updateEObjXContactRelExtStatementDescriptor = createStatementDescriptor (
    "updateEObjXContactRelExt(com.dwl.tcrm.coreParty.entityObject.EObjContactRel, com.ibm.daimler.dsea.entityObject.EObjXContactRelExt)",
    "update CONTACTREL set END_DT =  ? , REL_DESC =  ? , FROM_CONT_ID =  ? , TO_CONT_ID =  ? , START_DT =  ? , REL_TP_CD =  ? , END_REASON_TP_CD =  ? , REL_ASSIGN_TP_CD =  ? , XRETAILER_CODE =  ? , XCONTACT_ROLE =  ? , XCONTACT_POSITION =  ? , XCONTACTREL_RETAILER_FLAG =  ? , XSOURCE_IDENT_TP_CD =  ? , XMODIFY_SYS_DT =  ? , DELETE_FLAG =  ? , LAST_UPDATE_DT =  ? , LAST_UPDATE_USER =  ? , LAST_UPDATE_TX_ID =  ?  where CONT_REL_ID =  ?  and LAST_UPDATE_DT =  ? ",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.UPDATE,
    null,
    new UpdateEObjXContactRelExtParameterHandler (),
    new int[][]{{Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP}, {0, 255, 19, 19, 0, 19, 19, 19, 255, 255, 255, 5, 19, 0, 10, 0, 0, 19, 19, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    3);

  /**
   * @generated
   */
  public static class UpdateEObjXContactRelExtParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      EObjContactRel bean0 = (EObjContactRel) parameters[0];
      setTimestamp (stmt, 1, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getEndDt());
      setString (stmt, 2, Types.VARCHAR, (String)bean0.getRelDesc());
      setLong (stmt, 3, Types.BIGINT, (Long)bean0.getFromContId());
      setLong (stmt, 4, Types.BIGINT, (Long)bean0.getToContId());
      setTimestamp (stmt, 5, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getStartDt());
      setLong (stmt, 6, Types.BIGINT, (Long)bean0.getRelTpCd());
      setLong (stmt, 7, Types.BIGINT, (Long)bean0.getEndReasonTpCd());
      setLong (stmt, 8, Types.BIGINT, (Long)bean0.getRelAssignTpCd());
      EObjXContactRelExt bean1 = (EObjXContactRelExt) parameters[1];
      setString (stmt, 9, Types.VARCHAR, (String)bean1.getXRetailerCode());
      setString (stmt, 10, Types.VARCHAR, (String)bean1.getXContactRole());
      setString (stmt, 11, Types.VARCHAR, (String)bean1.getXContactPosition());
      setString (stmt, 12, Types.VARCHAR, (String)bean1.getXContactRelRetailerFlag());
      setLong (stmt, 13, Types.BIGINT, (Long)bean1.getXSourceIdentifier());
      setTimestamp (stmt, 14, Types.TIMESTAMP, (java.sql.Timestamp)bean1.getXLastModifiedSystemDate());
      setString (stmt, 15, Types.VARCHAR, (String)bean1.getDeleteFlag());
      setTimestamp (stmt, 16, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUpdateDt());
      setString (stmt, 17, Types.VARCHAR, (String)bean0.getLastUpdateUser());
      setLong (stmt, 18, Types.BIGINT, (Long)bean0.getLastUpdateTxId());
      setLong (stmt, 19, Types.BIGINT, (Long)bean0.getContRelIdPK());
      setTimestamp (stmt, 20, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getOldLastUpdateDt());
    }
  }

  /**
   * @Update( sql="delete from CONTACTREL where CONT_REL_ID = ?" )
   * 
   * @generated
   */
  public int deleteEObjXContactRelExt (Long contRelIdPK)
  {
    return update (deleteEObjXContactRelExtStatementDescriptor, contRelIdPK);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor deleteEObjXContactRelExtStatementDescriptor = createStatementDescriptor (
    "deleteEObjXContactRelExt(Long)",
    "delete from CONTACTREL where CONT_REL_ID = ?",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.DELETE,
    null,
    new DeleteEObjXContactRelExtParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    4);

  /**
   * @generated
   */
  public static class DeleteEObjXContactRelExtParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setLong (stmt, 1, Types.BIGINT, (Long)parameters[0]);
    }
  }

}
