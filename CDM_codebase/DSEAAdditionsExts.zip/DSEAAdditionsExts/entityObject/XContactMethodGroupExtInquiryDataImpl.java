package com.ibm.daimler.dsea.entityObject;

import com.ibm.pdq.runtime.generator.BaseParameterHandler;
import java.util.Iterator;
import com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup;
import com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup;
import java.sql.PreparedStatement;
import com.ibm.pdq.runtime.statement.StatementDescriptor;
import com.ibm.pdq.runtime.generator.BaseData;
import java.sql.SQLException;
import com.ibm.pdq.annotation.Metadata;
import com.ibm.mdm.base.db.ResultQueue3;
import com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt;
import com.ibm.pdq.runtime.generator.BaseRowHandler;
import com.ibm.pdq.runtime.statement.SqlStatementType;
import java.sql.Types;


@SuppressWarnings("unchecked")

/**
 * <!-- begin-user-doc -->
 * 
 * <!-- end-user-doc -->
 * 
 * @generated
 */
public class XContactMethodGroupExtInquiryDataImpl  extends BaseData implements XContactMethodGroupExtInquiryData
{

  /**
   * @generated
   */
  public static final String generatorVersion = "3.200.75";

  /**
   * @generated
   */
  public static final String identifier = "XContactMethodGroupExtInquiryData";

  /**
   * @generated
   */
  public static final long generationTime = 0x0000015e1852d6c9L;

  /**
   * @generated
   */
  public static final String collection = "NULLID";

  /**
   * @generated
   */
  public static final String packageVersion = null;

  /**
   * @generated
   */
  public static final boolean forceSingleBindIsolation = false;

  /**
   * @generated
   */
  public XContactMethodGroupExtInquiryDataImpl()
  {
    super();
  } 

  /**
   * @generated
   */
  public String getGeneratorVersion()
  {
    return generatorVersion;
  }

  /**
   * @Select( sql="SELECT DISTINCT A.H_LOCATION_GROUP_I AS H_CONT_METHOD_GRP_ID, A.H_ACTION_CODE, A.H_CREATED_BY, A.H_CREATE_DT, A.H_END_DT, A.LOCATION_GROUP_ID, A.CONTACT_METHOD_ID, A.CONT_METH_TP_CD, A.METHOD_ST_TP_CD, A.ATTACH_ALLOW_IND, A.TEXT_ONLY_IND, A.MESSAGE_SIZE, A.COMMENT_DESC, A.LAST_UPDATE_DT, A.LAST_UPDATE_USER, A.LAST_UPDATE_TX_ID, B.H_LOCATION_GROUP_I AS H_LOCATION_GROUP_I, B.H_ACTION_CODE, B.H_CREATED_BY, B.H_CREATE_DT, B.H_END_DT, B.LOCATION_GROUP_ID, B.UNDEL_REASON_TP_CD, B.CONT_ID, B.MEMBER_IND, B.PREFERRED_IND, B.SOLICIT_IND, B.LOC_GROUP_TP_CODE, B.EFFECT_START_MMDD, B.EFFECT_END_MMDD, B.EFFECT_START_TM, B.EFFECT_END_TM, B.START_DT, B.END_DT, B.LAST_UPDATE_DT, B.LAST_UPDATE_USER, B.LAST_UPDATE_TX_ID, B.LAST_USED_DT, B.LAST_VERIFIED_DT, B.SOURCE_IDENT_TP_CD, A.XVERIFIED_TP_CD, A.XRETAILER_ID, A.XMODIFY_SYS_DT, A.XCONTACT_RETAILER_FLAG, A.X_BPID FROM H_CONTACTMETHODGRO A,H_LOCATIONGROUP B WHERE B.CONT_ID = ? AND A.H_LOCATION_GROUP_I = B.H_LOCATION_GROUP_I AND (( ? BETWEEN A.H_CREATE_DT AND A.H_END_DT ) OR ( ? >= A.H_CREATE_DT AND A.H_END_DT IS NULL )) AND (( ? BETWEEN B.H_CREATE_DT AND B.H_END_DT ) OR ( ? >= B.H_CREATE_DT AND B.H_END_DT IS NULL ))", pattern="tableAlias (CONTACTMETHODGROUP => com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup, H_CONTACTMETHODGRO => com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup, LOCATIONGROUP => com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup, H_LOCATIONGROUP => com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup , CONTACTMETHODGROUP => com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt , H_CONTACTMETHODGRO => com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue3<EObjContactMethodGroup,EObjLocationGroup,EObjXContactMethodGroupExt>> getPartyContactMethodsHistory (Object[] parameters)
  {
    return queryIterator (getPartyContactMethodsHistoryStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getPartyContactMethodsHistoryStatementDescriptor = createStatementDescriptor (
    "getPartyContactMethodsHistory(Object[])",
    "SELECT DISTINCT A.H_LOCATION_GROUP_I AS H_CONT_METHOD_GRP_ID, A.H_ACTION_CODE, A.H_CREATED_BY, A.H_CREATE_DT, A.H_END_DT, A.LOCATION_GROUP_ID, A.CONTACT_METHOD_ID, A.CONT_METH_TP_CD, A.METHOD_ST_TP_CD, A.ATTACH_ALLOW_IND, A.TEXT_ONLY_IND, A.MESSAGE_SIZE, A.COMMENT_DESC, A.LAST_UPDATE_DT, A.LAST_UPDATE_USER, A.LAST_UPDATE_TX_ID, B.H_LOCATION_GROUP_I AS H_LOCATION_GROUP_I, B.H_ACTION_CODE, B.H_CREATED_BY, B.H_CREATE_DT, B.H_END_DT, B.LOCATION_GROUP_ID, B.UNDEL_REASON_TP_CD, B.CONT_ID, B.MEMBER_IND, B.PREFERRED_IND, B.SOLICIT_IND, B.LOC_GROUP_TP_CODE, B.EFFECT_START_MMDD, B.EFFECT_END_MMDD, B.EFFECT_START_TM, B.EFFECT_END_TM, B.START_DT, B.END_DT, B.LAST_UPDATE_DT, B.LAST_UPDATE_USER, B.LAST_UPDATE_TX_ID, B.LAST_USED_DT, B.LAST_VERIFIED_DT, B.SOURCE_IDENT_TP_CD, A.XVERIFIED_TP_CD, A.XRETAILER_ID, A.XMODIFY_SYS_DT, A.XCONTACT_RETAILER_FLAG, A.X_BPID FROM H_CONTACTMETHODGRO A,H_LOCATIONGROUP B WHERE B.CONT_ID = ? AND A.H_LOCATION_GROUP_I = B.H_LOCATION_GROUP_I AND (( ? BETWEEN A.H_CREATE_DT AND A.H_END_DT ) OR ( ? >= A.H_CREATE_DT AND A.H_END_DT IS NULL )) AND (( ? BETWEEN B.H_CREATE_DT AND B.H_END_DT ) OR ( ? >= B.H_CREATE_DT AND B.H_END_DT IS NULL ))",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"h_cont_method_grp_id", "h_action_code", "h_created_by", "h_create_dt", "h_end_dt", "location_group_id", "contact_method_id", "cont_meth_tp_cd", "method_st_tp_cd", "attach_allow_ind", "text_only_ind", "message_size", "comment_desc", "last_update_dt", "last_update_user", "last_update_tx_id", "h_location_group_i", "h_action_code", "h_created_by", "h_create_dt", "h_end_dt", "location_group_id", "undel_reason_tp_cd", "cont_id", "member_ind", "preferred_ind", "solicit_ind", "loc_group_tp_code", "effect_start_mmdd", "effect_end_mmdd", "effect_start_tm", "effect_end_tm", "start_dt", "end_dt", "last_update_dt", "last_update_user", "last_update_tx_id", "last_used_dt", "last_verified_dt", "source_ident_tp_cd", "xverified_tp_cd", "xretailer_id", "xmodify_sys_dt", "xcontact_retailer_flag", "x_bpid"},
    new GetPartyContactMethodsHistoryParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP}, {19, 0, 0, 0, 0}, {0, 0, 0, 0, 0}, {1, 1, 1, 1, 1}},
    null,
    new GetPartyContactMethodsHistoryRowHandler (),
    new int[][]{ {Types.BIGINT, Types.CHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.CHAR, Types.CHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.CHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR}, {19, 1, 20, 0, 0, 19, 19, 19, 19, 1, 1, 20, 100, 0, 20, 19, 19, 1, 20, 0, 0, 19, 19, 19, 0, 0, 0, 0, 10, 10, 10, 10, 0, 0, 0, 20, 19, 0, 0, 19, 19, 19, 0, 5, 50}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    1);

  /**
   * @generated
   */
  public static class GetPartyContactMethodsHistoryParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
      setObject (stmt, 4, Types.TIMESTAMP, parameters[3], 0);
      setObject (stmt, 5, Types.TIMESTAMP, parameters[4], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetPartyContactMethodsHistoryRowHandler extends BaseRowHandler<ResultQueue3<EObjContactMethodGroup,EObjLocationGroup,EObjXContactMethodGroupExt>>
  {
    /**
     * @generated
     */
    public ResultQueue3<EObjContactMethodGroup,EObjLocationGroup,EObjXContactMethodGroupExt> handle (java.sql.ResultSet rs, ResultQueue3<EObjContactMethodGroup,EObjLocationGroup,EObjXContactMethodGroupExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue3<EObjContactMethodGroup,EObjLocationGroup,EObjXContactMethodGroupExt> ();

      EObjContactMethodGroup returnObject1 = new EObjContactMethodGroup ();
      returnObject1.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject1.setHistActionCode(getString (rs, 2)); 
      returnObject1.setHistCreatedBy(getString (rs, 3)); 
      returnObject1.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject1.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject1.setLocationGroupIdPK(getLongObject (rs, 6)); 
      returnObject1.setContactMethodId(getLongObject (rs, 7)); 
      returnObject1.setContMethTpCd(getLongObject (rs, 8)); 
      returnObject1.setMethodStTpCd(getLongObject (rs, 9)); 
      returnObject1.setAttachAllowInd(getString (rs, 10)); 
      returnObject1.setTextOnlyInd(getString (rs, 11)); 
      returnObject1.setMessageSize(getString (rs, 12)); 
      returnObject1.setCommentDesc(getString (rs, 13)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 14)); 
      returnObject1.setLastUpdateUser(getString (rs, 15)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 16)); 
      returnObject.add (returnObject1);

      EObjLocationGroup returnObject2 = new EObjLocationGroup ();
      returnObject2.setHistoryIdPK(getLongObject (rs, 17)); 
      returnObject2.setHistActionCode(getString (rs, 18)); 
      returnObject2.setHistCreatedBy(getString (rs, 19)); 
      returnObject2.setHistCreateDt(getTimestamp (rs, 20)); 
      returnObject2.setHistEndDt(getTimestamp (rs, 21)); 
      returnObject2.setLocationGroupIdPK(getLongObject (rs, 22)); 
      returnObject2.setUndelReasonTpCd(getLongObject (rs, 23)); 
      returnObject2.setContId(getLongObject (rs, 24)); 
      returnObject2.setMemberInd(getString (rs, 25)); 
      returnObject2.setPreferredInd(getString (rs, 26)); 
      returnObject2.setSolicitInd(getString (rs, 27)); 
      returnObject2.setLocGroupTpCode(getString (rs, 28)); 
      returnObject2.setEffectStartMMDD(getIntObject (rs, 29)); 
      returnObject2.setEffectEndMMDD(getIntObject (rs, 30)); 
      returnObject2.setEffectStartTm(getIntObject (rs, 31)); 
      returnObject2.setEffectEndTm(getIntObject (rs, 32)); 
      returnObject2.setStartDt(getTimestamp (rs, 33)); 
      returnObject2.setEndDt(getTimestamp (rs, 34)); 
      returnObject2.setLastUpdateDt(getTimestamp (rs, 35)); 
      returnObject2.setLastUpdateUser(getString (rs, 36)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 37)); 
      returnObject2.setLastUsedDt(getTimestamp (rs, 38)); 
      returnObject2.setLastVerifiedDt(getTimestamp (rs, 39)); 
      returnObject2.setSourceIdentTpCd(getLongObject (rs, 40)); 
      returnObject.add (returnObject2);

      EObjXContactMethodGroupExt returnObject3 = new EObjXContactMethodGroupExt ();
      returnObject3.setHistActionCode(getString (rs, 2)); 
      returnObject3.setHistCreatedBy(getString (rs, 3)); 
      returnObject3.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject3.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject3.setLastUpdateDt(getTimestamp (rs, 14)); 
      returnObject3.setLastUpdateUser(getString (rs, 15)); 
      returnObject3.setLastUpdateTxId(getLongObject (rs, 16)); 
      returnObject3.setXVerified(getLongObject (rs, 41)); 
      returnObject3.setXRetailerId(getLongObject (rs, 42)); 
      returnObject3.setXLastModifiedSystemDate(getTimestamp (rs, 43)); 
      returnObject3.setXContactRetailerFlag(getString (rs, 44)); 
      returnObject3.setX_BPID(getString (rs, 45)); 
      returnObject.add (returnObject3);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT CONTACTMETHODGROUP.LOCATION_GROUP_ID, CONTACTMETHODGROUP.CONTACT_METHOD_ID, CONTACTMETHODGROUP.CONT_METH_TP_CD, CONTACTMETHODGROUP.METHOD_ST_TP_CD, CONTACTMETHODGROUP.ATTACH_ALLOW_IND, CONTACTMETHODGROUP.TEXT_ONLY_IND, CONTACTMETHODGROUP.MESSAGE_SIZE, CONTACTMETHODGROUP.COMMENT_DESC, CONTACTMETHODGROUP.LAST_UPDATE_DT, CONTACTMETHODGROUP.LAST_UPDATE_USER, CONTACTMETHODGROUP.LAST_UPDATE_TX_ID, LOCATIONGROUP.LOCATION_GROUP_ID, LOCATIONGROUP.UNDEL_REASON_TP_CD, LOCATIONGROUP.CONT_ID, LOCATIONGROUP.MEMBER_IND, LOCATIONGROUP.PREFERRED_IND, LOCATIONGROUP.SOLICIT_IND, LOCATIONGROUP.LOC_GROUP_TP_CODE, LOCATIONGROUP.EFFECT_START_MMDD, LOCATIONGROUP.EFFECT_END_MMDD, LOCATIONGROUP.EFFECT_START_TM, LOCATIONGROUP.EFFECT_END_TM, LOCATIONGROUP.START_DT, LOCATIONGROUP.END_DT, LOCATIONGROUP.LAST_UPDATE_DT, LOCATIONGROUP.LAST_UPDATE_USER, LOCATIONGROUP.LAST_UPDATE_TX_ID, LOCATIONGROUP.LAST_USED_DT, LOCATIONGROUP.LAST_VERIFIED_DT, LOCATIONGROUP.SOURCE_IDENT_TP_CD, CONTACTMETHODGROUP.XVERIFIED_TP_CD, CONTACTMETHODGROUP.XRETAILER_ID, CONTACTMETHODGROUP.XMODIFY_SYS_DT, CONTACTMETHODGROUP.XCONTACT_RETAILER_FLAG, CONTACTMETHODGROUP.X_BPID FROM CONTACTMETHODGROUP, LOCATIONGROUP WHERE CONTACTMETHODGROUP.LOCATION_GROUP_ID = LOCATIONGROUP.LOCATION_GROUP_ID AND LOCATIONGROUP.CONT_ID = ? AND ((LOCATIONGROUP.END_DT IS NULL) OR (LOCATIONGROUP.END_DT > ? ))", pattern="tableAlias (CONTACTMETHODGROUP => com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup, H_CONTACTMETHODGRO => com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup, LOCATIONGROUP => com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup, H_LOCATIONGROUP => com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup , CONTACTMETHODGROUP => com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt , H_CONTACTMETHODGRO => com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue3<EObjContactMethodGroup,EObjLocationGroup,EObjXContactMethodGroupExt>> getActivePartyContactMethods (Object[] parameters)
  {
    return queryIterator (getActivePartyContactMethodsStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getActivePartyContactMethodsStatementDescriptor = createStatementDescriptor (
    "getActivePartyContactMethods(Object[])",
    "SELECT CONTACTMETHODGROUP.LOCATION_GROUP_ID, CONTACTMETHODGROUP.CONTACT_METHOD_ID, CONTACTMETHODGROUP.CONT_METH_TP_CD, CONTACTMETHODGROUP.METHOD_ST_TP_CD, CONTACTMETHODGROUP.ATTACH_ALLOW_IND, CONTACTMETHODGROUP.TEXT_ONLY_IND, CONTACTMETHODGROUP.MESSAGE_SIZE, CONTACTMETHODGROUP.COMMENT_DESC, CONTACTMETHODGROUP.LAST_UPDATE_DT, CONTACTMETHODGROUP.LAST_UPDATE_USER, CONTACTMETHODGROUP.LAST_UPDATE_TX_ID, LOCATIONGROUP.LOCATION_GROUP_ID, LOCATIONGROUP.UNDEL_REASON_TP_CD, LOCATIONGROUP.CONT_ID, LOCATIONGROUP.MEMBER_IND, LOCATIONGROUP.PREFERRED_IND, LOCATIONGROUP.SOLICIT_IND, LOCATIONGROUP.LOC_GROUP_TP_CODE, LOCATIONGROUP.EFFECT_START_MMDD, LOCATIONGROUP.EFFECT_END_MMDD, LOCATIONGROUP.EFFECT_START_TM, LOCATIONGROUP.EFFECT_END_TM, LOCATIONGROUP.START_DT, LOCATIONGROUP.END_DT, LOCATIONGROUP.LAST_UPDATE_DT, LOCATIONGROUP.LAST_UPDATE_USER, LOCATIONGROUP.LAST_UPDATE_TX_ID, LOCATIONGROUP.LAST_USED_DT, LOCATIONGROUP.LAST_VERIFIED_DT, LOCATIONGROUP.SOURCE_IDENT_TP_CD, CONTACTMETHODGROUP.XVERIFIED_TP_CD, CONTACTMETHODGROUP.XRETAILER_ID, CONTACTMETHODGROUP.XMODIFY_SYS_DT, CONTACTMETHODGROUP.XCONTACT_RETAILER_FLAG, CONTACTMETHODGROUP.X_BPID FROM CONTACTMETHODGROUP, LOCATIONGROUP WHERE CONTACTMETHODGROUP.LOCATION_GROUP_ID = LOCATIONGROUP.LOCATION_GROUP_ID AND LOCATIONGROUP.CONT_ID = ? AND ((LOCATIONGROUP.END_DT IS NULL) OR (LOCATIONGROUP.END_DT > ? ))",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"location_group_id", "contact_method_id", "cont_meth_tp_cd", "method_st_tp_cd", "attach_allow_ind", "text_only_ind", "message_size", "comment_desc", "last_update_dt", "last_update_user", "last_update_tx_id", "location_group_id", "undel_reason_tp_cd", "cont_id", "member_ind", "preferred_ind", "solicit_ind", "loc_group_tp_code", "effect_start_mmdd", "effect_end_mmdd", "effect_start_tm", "effect_end_tm", "start_dt", "end_dt", "last_update_dt", "last_update_user", "last_update_tx_id", "last_used_dt", "last_verified_dt", "source_ident_tp_cd", "xverified_tp_cd", "xretailer_id", "xmodify_sys_dt", "xcontact_retailer_flag", "x_bpid"},
    new GetActivePartyContactMethodsParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP}, {19, 0}, {0, 0}, {1, 1}},
    null,
    new GetActivePartyContactMethodsRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.CHAR, Types.CHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR}, {19, 19, 19, 19, 1, 1, 20, 100, 0, 20, 19, 19, 19, 19, 0, 0, 0, 0, 10, 10, 10, 10, 0, 0, 0, 20, 19, 0, 0, 19, 19, 19, 0, 5, 50}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    2);

  /**
   * @generated
   */
  public static class GetActivePartyContactMethodsParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetActivePartyContactMethodsRowHandler extends BaseRowHandler<ResultQueue3<EObjContactMethodGroup,EObjLocationGroup,EObjXContactMethodGroupExt>>
  {
    /**
     * @generated
     */
    public ResultQueue3<EObjContactMethodGroup,EObjLocationGroup,EObjXContactMethodGroupExt> handle (java.sql.ResultSet rs, ResultQueue3<EObjContactMethodGroup,EObjLocationGroup,EObjXContactMethodGroupExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue3<EObjContactMethodGroup,EObjLocationGroup,EObjXContactMethodGroupExt> ();

      EObjContactMethodGroup returnObject1 = new EObjContactMethodGroup ();
      returnObject1.setLocationGroupIdPK(getLongObject (rs, 1)); 
      returnObject1.setContactMethodId(getLongObject (rs, 2)); 
      returnObject1.setContMethTpCd(getLongObject (rs, 3)); 
      returnObject1.setMethodStTpCd(getLongObject (rs, 4)); 
      returnObject1.setAttachAllowInd(getString (rs, 5)); 
      returnObject1.setTextOnlyInd(getString (rs, 6)); 
      returnObject1.setMessageSize(getString (rs, 7)); 
      returnObject1.setCommentDesc(getString (rs, 8)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 9)); 
      returnObject1.setLastUpdateUser(getString (rs, 10)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 11)); 
      returnObject.add (returnObject1);

      EObjLocationGroup returnObject2 = new EObjLocationGroup ();
      returnObject2.setLocationGroupIdPK(getLongObject (rs, 12)); 
      returnObject2.setUndelReasonTpCd(getLongObject (rs, 13)); 
      returnObject2.setContId(getLongObject (rs, 14)); 
      returnObject2.setMemberInd(getString (rs, 15)); 
      returnObject2.setPreferredInd(getString (rs, 16)); 
      returnObject2.setSolicitInd(getString (rs, 17)); 
      returnObject2.setLocGroupTpCode(getString (rs, 18)); 
      returnObject2.setEffectStartMMDD(getIntObject (rs, 19)); 
      returnObject2.setEffectEndMMDD(getIntObject (rs, 20)); 
      returnObject2.setEffectStartTm(getIntObject (rs, 21)); 
      returnObject2.setEffectEndTm(getIntObject (rs, 22)); 
      returnObject2.setStartDt(getTimestamp (rs, 23)); 
      returnObject2.setEndDt(getTimestamp (rs, 24)); 
      returnObject2.setLastUpdateDt(getTimestamp (rs, 25)); 
      returnObject2.setLastUpdateUser(getString (rs, 26)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 27)); 
      returnObject2.setLastUsedDt(getTimestamp (rs, 28)); 
      returnObject2.setLastVerifiedDt(getTimestamp (rs, 29)); 
      returnObject2.setSourceIdentTpCd(getLongObject (rs, 30)); 
      returnObject.add (returnObject2);

      EObjXContactMethodGroupExt returnObject3 = new EObjXContactMethodGroupExt ();
      returnObject3.setLastUpdateDt(getTimestamp (rs, 9)); 
      returnObject3.setLastUpdateUser(getString (rs, 10)); 
      returnObject3.setLastUpdateTxId(getLongObject (rs, 11)); 
      returnObject3.setXVerified(getLongObject (rs, 31)); 
      returnObject3.setXRetailerId(getLongObject (rs, 32)); 
      returnObject3.setXLastModifiedSystemDate(getTimestamp (rs, 33)); 
      returnObject3.setXContactRetailerFlag(getString (rs, 34)); 
      returnObject3.setX_BPID(getString (rs, 35)); 
      returnObject.add (returnObject3);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT CONTACTMETHODGROUP.LOCATION_GROUP_ID, CONTACTMETHODGROUP.CONTACT_METHOD_ID, CONTACTMETHODGROUP.CONT_METH_TP_CD, CONTACTMETHODGROUP.METHOD_ST_TP_CD, CONTACTMETHODGROUP.ATTACH_ALLOW_IND, CONTACTMETHODGROUP.TEXT_ONLY_IND, CONTACTMETHODGROUP.MESSAGE_SIZE , CONTACTMETHODGROUP.COMMENT_DESC, CONTACTMETHODGROUP.LAST_UPDATE_DT, CONTACTMETHODGROUP.LAST_UPDATE_USER, CONTACTMETHODGROUP.LAST_UPDATE_TX_ID, LOCATIONGROUP.LOCATION_GROUP_ID, LOCATIONGROUP.UNDEL_REASON_TP_CD, LOCATIONGROUP.CONT_ID, LOCATIONGROUP.MEMBER_IND, LOCATIONGROUP.PREFERRED_IND, LOCATIONGROUP.SOLICIT_IND, LOCATIONGROUP.LOC_GROUP_TP_CODE, LOCATIONGROUP.EFFECT_START_MMDD, LOCATIONGROUP.EFFECT_END_MMDD, LOCATIONGROUP.EFFECT_START_TM, LOCATIONGROUP.EFFECT_END_TM, LOCATIONGROUP.START_DT, LOCATIONGROUP.END_DT, LOCATIONGROUP.LAST_UPDATE_DT, LOCATIONGROUP.LAST_UPDATE_USER, LOCATIONGROUP.LAST_UPDATE_TX_ID, LOCATIONGROUP.LAST_USED_DT, LOCATIONGROUP.LAST_VERIFIED_DT, LOCATIONGROUP.SOURCE_IDENT_TP_CD, CONTACTMETHODGROUP.XVERIFIED_TP_CD, CONTACTMETHODGROUP.XRETAILER_ID, CONTACTMETHODGROUP.XMODIFY_SYS_DT, CONTACTMETHODGROUP.XCONTACT_RETAILER_FLAG, CONTACTMETHODGROUP.X_BPID FROM CONTACTMETHODGROUP,LOCATIONGROUP WHERE CONTACTMETHODGROUP.LOCATION_GROUP_ID = LOCATIONGROUP.LOCATION_GROUP_ID AND LOCATIONGROUP.CONT_ID = ? AND (LOCATIONGROUP.END_DT < ? )", pattern="tableAlias (CONTACTMETHODGROUP => com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup, H_CONTACTMETHODGRO => com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup, LOCATIONGROUP => com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup, H_LOCATIONGROUP => com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup , CONTACTMETHODGROUP => com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt , H_CONTACTMETHODGRO => com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue3<EObjContactMethodGroup,EObjLocationGroup,EObjXContactMethodGroupExt>> getInactivePartyContactMethods (Object[] parameters)
  {
    return queryIterator (getInactivePartyContactMethodsStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getInactivePartyContactMethodsStatementDescriptor = createStatementDescriptor (
    "getInactivePartyContactMethods(Object[])",
    "SELECT CONTACTMETHODGROUP.LOCATION_GROUP_ID, CONTACTMETHODGROUP.CONTACT_METHOD_ID, CONTACTMETHODGROUP.CONT_METH_TP_CD, CONTACTMETHODGROUP.METHOD_ST_TP_CD, CONTACTMETHODGROUP.ATTACH_ALLOW_IND, CONTACTMETHODGROUP.TEXT_ONLY_IND, CONTACTMETHODGROUP.MESSAGE_SIZE , CONTACTMETHODGROUP.COMMENT_DESC, CONTACTMETHODGROUP.LAST_UPDATE_DT, CONTACTMETHODGROUP.LAST_UPDATE_USER, CONTACTMETHODGROUP.LAST_UPDATE_TX_ID, LOCATIONGROUP.LOCATION_GROUP_ID, LOCATIONGROUP.UNDEL_REASON_TP_CD, LOCATIONGROUP.CONT_ID, LOCATIONGROUP.MEMBER_IND, LOCATIONGROUP.PREFERRED_IND, LOCATIONGROUP.SOLICIT_IND, LOCATIONGROUP.LOC_GROUP_TP_CODE, LOCATIONGROUP.EFFECT_START_MMDD, LOCATIONGROUP.EFFECT_END_MMDD, LOCATIONGROUP.EFFECT_START_TM, LOCATIONGROUP.EFFECT_END_TM, LOCATIONGROUP.START_DT, LOCATIONGROUP.END_DT, LOCATIONGROUP.LAST_UPDATE_DT, LOCATIONGROUP.LAST_UPDATE_USER, LOCATIONGROUP.LAST_UPDATE_TX_ID, LOCATIONGROUP.LAST_USED_DT, LOCATIONGROUP.LAST_VERIFIED_DT, LOCATIONGROUP.SOURCE_IDENT_TP_CD, CONTACTMETHODGROUP.XVERIFIED_TP_CD, CONTACTMETHODGROUP.XRETAILER_ID, CONTACTMETHODGROUP.XMODIFY_SYS_DT, CONTACTMETHODGROUP.XCONTACT_RETAILER_FLAG, CONTACTMETHODGROUP.X_BPID FROM CONTACTMETHODGROUP,LOCATIONGROUP WHERE CONTACTMETHODGROUP.LOCATION_GROUP_ID = LOCATIONGROUP.LOCATION_GROUP_ID AND LOCATIONGROUP.CONT_ID = ? AND (LOCATIONGROUP.END_DT < ? )",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"location_group_id", "contact_method_id", "cont_meth_tp_cd", "method_st_tp_cd", "attach_allow_ind", "text_only_ind", "message_size", "comment_desc", "last_update_dt", "last_update_user", "last_update_tx_id", "location_group_id", "undel_reason_tp_cd", "cont_id", "member_ind", "preferred_ind", "solicit_ind", "loc_group_tp_code", "effect_start_mmdd", "effect_end_mmdd", "effect_start_tm", "effect_end_tm", "start_dt", "end_dt", "last_update_dt", "last_update_user", "last_update_tx_id", "last_used_dt", "last_verified_dt", "source_ident_tp_cd", "xverified_tp_cd", "xretailer_id", "xmodify_sys_dt", "xcontact_retailer_flag", "x_bpid"},
    new GetInactivePartyContactMethodsParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP}, {19, 0}, {0, 0}, {1, 1}},
    null,
    new GetInactivePartyContactMethodsRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.CHAR, Types.CHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR}, {19, 19, 19, 19, 1, 1, 20, 100, 0, 20, 19, 19, 19, 19, 0, 0, 0, 0, 10, 10, 10, 10, 0, 0, 0, 20, 19, 0, 0, 19, 19, 19, 0, 5, 50}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    3);

  /**
   * @generated
   */
  public static class GetInactivePartyContactMethodsParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetInactivePartyContactMethodsRowHandler extends BaseRowHandler<ResultQueue3<EObjContactMethodGroup,EObjLocationGroup,EObjXContactMethodGroupExt>>
  {
    /**
     * @generated
     */
    public ResultQueue3<EObjContactMethodGroup,EObjLocationGroup,EObjXContactMethodGroupExt> handle (java.sql.ResultSet rs, ResultQueue3<EObjContactMethodGroup,EObjLocationGroup,EObjXContactMethodGroupExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue3<EObjContactMethodGroup,EObjLocationGroup,EObjXContactMethodGroupExt> ();

      EObjContactMethodGroup returnObject1 = new EObjContactMethodGroup ();
      returnObject1.setLocationGroupIdPK(getLongObject (rs, 1)); 
      returnObject1.setContactMethodId(getLongObject (rs, 2)); 
      returnObject1.setContMethTpCd(getLongObject (rs, 3)); 
      returnObject1.setMethodStTpCd(getLongObject (rs, 4)); 
      returnObject1.setAttachAllowInd(getString (rs, 5)); 
      returnObject1.setTextOnlyInd(getString (rs, 6)); 
      returnObject1.setMessageSize(getString (rs, 7)); 
      returnObject1.setCommentDesc(getString (rs, 8)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 9)); 
      returnObject1.setLastUpdateUser(getString (rs, 10)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 11)); 
      returnObject.add (returnObject1);

      EObjLocationGroup returnObject2 = new EObjLocationGroup ();
      returnObject2.setLocationGroupIdPK(getLongObject (rs, 12)); 
      returnObject2.setUndelReasonTpCd(getLongObject (rs, 13)); 
      returnObject2.setContId(getLongObject (rs, 14)); 
      returnObject2.setMemberInd(getString (rs, 15)); 
      returnObject2.setPreferredInd(getString (rs, 16)); 
      returnObject2.setSolicitInd(getString (rs, 17)); 
      returnObject2.setLocGroupTpCode(getString (rs, 18)); 
      returnObject2.setEffectStartMMDD(getIntObject (rs, 19)); 
      returnObject2.setEffectEndMMDD(getIntObject (rs, 20)); 
      returnObject2.setEffectStartTm(getIntObject (rs, 21)); 
      returnObject2.setEffectEndTm(getIntObject (rs, 22)); 
      returnObject2.setStartDt(getTimestamp (rs, 23)); 
      returnObject2.setEndDt(getTimestamp (rs, 24)); 
      returnObject2.setLastUpdateDt(getTimestamp (rs, 25)); 
      returnObject2.setLastUpdateUser(getString (rs, 26)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 27)); 
      returnObject2.setLastUsedDt(getTimestamp (rs, 28)); 
      returnObject2.setLastVerifiedDt(getTimestamp (rs, 29)); 
      returnObject2.setSourceIdentTpCd(getLongObject (rs, 30)); 
      returnObject.add (returnObject2);

      EObjXContactMethodGroupExt returnObject3 = new EObjXContactMethodGroupExt ();
      returnObject3.setLastUpdateDt(getTimestamp (rs, 9)); 
      returnObject3.setLastUpdateUser(getString (rs, 10)); 
      returnObject3.setLastUpdateTxId(getLongObject (rs, 11)); 
      returnObject3.setXVerified(getLongObject (rs, 31)); 
      returnObject3.setXRetailerId(getLongObject (rs, 32)); 
      returnObject3.setXLastModifiedSystemDate(getTimestamp (rs, 33)); 
      returnObject3.setXContactRetailerFlag(getString (rs, 34)); 
      returnObject3.setX_BPID(getString (rs, 35)); 
      returnObject.add (returnObject3);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT CONTACTMETHODGROUP.LOCATION_GROUP_ID, CONTACTMETHODGROUP.CONTACT_METHOD_ID, CONTACTMETHODGROUP.CONT_METH_TP_CD, CONTACTMETHODGROUP.METHOD_ST_TP_CD, CONTACTMETHODGROUP.ATTACH_ALLOW_IND, CONTACTMETHODGROUP.TEXT_ONLY_IND, CONTACTMETHODGROUP.MESSAGE_SIZE, CONTACTMETHODGROUP.COMMENT_DESC, CONTACTMETHODGROUP.LAST_UPDATE_DT, CONTACTMETHODGROUP.LAST_UPDATE_USER,CONTACTMETHODGROUP.LAST_UPDATE_TX_ID, LOCATIONGROUP.LOCATION_GROUP_ID, LOCATIONGROUP.UNDEL_REASON_TP_CD, LOCATIONGROUP.CONT_ID, LOCATIONGROUP.MEMBER_IND, LOCATIONGROUP.PREFERRED_IND, LOCATIONGROUP.SOLICIT_IND, LOCATIONGROUP.LOC_GROUP_TP_CODE, LOCATIONGROUP.EFFECT_START_MMDD, LOCATIONGROUP.EFFECT_END_MMDD, LOCATIONGROUP.EFFECT_START_TM, LOCATIONGROUP.EFFECT_END_TM, LOCATIONGROUP.START_DT, LOCATIONGROUP.END_DT, LOCATIONGROUP.LAST_UPDATE_DT, LOCATIONGROUP.LAST_UPDATE_USER, LOCATIONGROUP.LAST_UPDATE_TX_ID, LOCATIONGROUP.LAST_USED_DT, LOCATIONGROUP.LAST_VERIFIED_DT, LOCATIONGROUP.SOURCE_IDENT_TP_CD, CONTACTMETHODGROUP.XVERIFIED_TP_CD, CONTACTMETHODGROUP.XRETAILER_ID, CONTACTMETHODGROUP.XMODIFY_SYS_DT, CONTACTMETHODGROUP.XCONTACT_RETAILER_FLAG, CONTACTMETHODGROUP.X_BPID FROM CONTACTMETHODGROUP,LOCATIONGROUP WHERE CONTACTMETHODGROUP.LOCATION_GROUP_ID = LOCATIONGROUP.LOCATION_GROUP_ID AND LOCATIONGROUP.CONT_ID = ?", pattern="tableAlias (CONTACTMETHODGROUP => com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup, H_CONTACTMETHODGRO => com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup, LOCATIONGROUP => com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup, H_LOCATIONGROUP => com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup , CONTACTMETHODGROUP => com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt , H_CONTACTMETHODGRO => com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue3<EObjContactMethodGroup,EObjLocationGroup,EObjXContactMethodGroupExt>> getAllPartyContactMethods (Object[] parameters)
  {
    return queryIterator (getAllPartyContactMethodsStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getAllPartyContactMethodsStatementDescriptor = createStatementDescriptor (
    "getAllPartyContactMethods(Object[])",
    "SELECT CONTACTMETHODGROUP.LOCATION_GROUP_ID, CONTACTMETHODGROUP.CONTACT_METHOD_ID, CONTACTMETHODGROUP.CONT_METH_TP_CD, CONTACTMETHODGROUP.METHOD_ST_TP_CD, CONTACTMETHODGROUP.ATTACH_ALLOW_IND, CONTACTMETHODGROUP.TEXT_ONLY_IND, CONTACTMETHODGROUP.MESSAGE_SIZE, CONTACTMETHODGROUP.COMMENT_DESC, CONTACTMETHODGROUP.LAST_UPDATE_DT, CONTACTMETHODGROUP.LAST_UPDATE_USER,CONTACTMETHODGROUP.LAST_UPDATE_TX_ID, LOCATIONGROUP.LOCATION_GROUP_ID, LOCATIONGROUP.UNDEL_REASON_TP_CD, LOCATIONGROUP.CONT_ID, LOCATIONGROUP.MEMBER_IND, LOCATIONGROUP.PREFERRED_IND, LOCATIONGROUP.SOLICIT_IND, LOCATIONGROUP.LOC_GROUP_TP_CODE, LOCATIONGROUP.EFFECT_START_MMDD, LOCATIONGROUP.EFFECT_END_MMDD, LOCATIONGROUP.EFFECT_START_TM, LOCATIONGROUP.EFFECT_END_TM, LOCATIONGROUP.START_DT, LOCATIONGROUP.END_DT, LOCATIONGROUP.LAST_UPDATE_DT, LOCATIONGROUP.LAST_UPDATE_USER, LOCATIONGROUP.LAST_UPDATE_TX_ID, LOCATIONGROUP.LAST_USED_DT, LOCATIONGROUP.LAST_VERIFIED_DT, LOCATIONGROUP.SOURCE_IDENT_TP_CD, CONTACTMETHODGROUP.XVERIFIED_TP_CD, CONTACTMETHODGROUP.XRETAILER_ID, CONTACTMETHODGROUP.XMODIFY_SYS_DT, CONTACTMETHODGROUP.XCONTACT_RETAILER_FLAG, CONTACTMETHODGROUP.X_BPID FROM CONTACTMETHODGROUP,LOCATIONGROUP WHERE CONTACTMETHODGROUP.LOCATION_GROUP_ID = LOCATIONGROUP.LOCATION_GROUP_ID AND LOCATIONGROUP.CONT_ID = ?",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"location_group_id", "contact_method_id", "cont_meth_tp_cd", "method_st_tp_cd", "attach_allow_ind", "text_only_ind", "message_size", "comment_desc", "last_update_dt", "last_update_user", "last_update_tx_id", "location_group_id", "undel_reason_tp_cd", "cont_id", "member_ind", "preferred_ind", "solicit_ind", "loc_group_tp_code", "effect_start_mmdd", "effect_end_mmdd", "effect_start_tm", "effect_end_tm", "start_dt", "end_dt", "last_update_dt", "last_update_user", "last_update_tx_id", "last_used_dt", "last_verified_dt", "source_ident_tp_cd", "xverified_tp_cd", "xretailer_id", "xmodify_sys_dt", "xcontact_retailer_flag", "x_bpid"},
    new GetAllPartyContactMethodsParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetAllPartyContactMethodsRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.CHAR, Types.CHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR}, {19, 19, 19, 19, 1, 1, 20, 100, 0, 20, 19, 19, 19, 19, 0, 0, 0, 0, 10, 10, 10, 10, 0, 0, 0, 20, 19, 0, 0, 19, 19, 19, 0, 5, 50}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    4);

  /**
   * @generated
   */
  public static class GetAllPartyContactMethodsParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetAllPartyContactMethodsRowHandler extends BaseRowHandler<ResultQueue3<EObjContactMethodGroup,EObjLocationGroup,EObjXContactMethodGroupExt>>
  {
    /**
     * @generated
     */
    public ResultQueue3<EObjContactMethodGroup,EObjLocationGroup,EObjXContactMethodGroupExt> handle (java.sql.ResultSet rs, ResultQueue3<EObjContactMethodGroup,EObjLocationGroup,EObjXContactMethodGroupExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue3<EObjContactMethodGroup,EObjLocationGroup,EObjXContactMethodGroupExt> ();

      EObjContactMethodGroup returnObject1 = new EObjContactMethodGroup ();
      returnObject1.setLocationGroupIdPK(getLongObject (rs, 1)); 
      returnObject1.setContactMethodId(getLongObject (rs, 2)); 
      returnObject1.setContMethTpCd(getLongObject (rs, 3)); 
      returnObject1.setMethodStTpCd(getLongObject (rs, 4)); 
      returnObject1.setAttachAllowInd(getString (rs, 5)); 
      returnObject1.setTextOnlyInd(getString (rs, 6)); 
      returnObject1.setMessageSize(getString (rs, 7)); 
      returnObject1.setCommentDesc(getString (rs, 8)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 9)); 
      returnObject1.setLastUpdateUser(getString (rs, 10)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 11)); 
      returnObject.add (returnObject1);

      EObjLocationGroup returnObject2 = new EObjLocationGroup ();
      returnObject2.setLocationGroupIdPK(getLongObject (rs, 12)); 
      returnObject2.setUndelReasonTpCd(getLongObject (rs, 13)); 
      returnObject2.setContId(getLongObject (rs, 14)); 
      returnObject2.setMemberInd(getString (rs, 15)); 
      returnObject2.setPreferredInd(getString (rs, 16)); 
      returnObject2.setSolicitInd(getString (rs, 17)); 
      returnObject2.setLocGroupTpCode(getString (rs, 18)); 
      returnObject2.setEffectStartMMDD(getIntObject (rs, 19)); 
      returnObject2.setEffectEndMMDD(getIntObject (rs, 20)); 
      returnObject2.setEffectStartTm(getIntObject (rs, 21)); 
      returnObject2.setEffectEndTm(getIntObject (rs, 22)); 
      returnObject2.setStartDt(getTimestamp (rs, 23)); 
      returnObject2.setEndDt(getTimestamp (rs, 24)); 
      returnObject2.setLastUpdateDt(getTimestamp (rs, 25)); 
      returnObject2.setLastUpdateUser(getString (rs, 26)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 27)); 
      returnObject2.setLastUsedDt(getTimestamp (rs, 28)); 
      returnObject2.setLastVerifiedDt(getTimestamp (rs, 29)); 
      returnObject2.setSourceIdentTpCd(getLongObject (rs, 30)); 
      returnObject.add (returnObject2);

      EObjXContactMethodGroupExt returnObject3 = new EObjXContactMethodGroupExt ();
      returnObject3.setLastUpdateDt(getTimestamp (rs, 9)); 
      returnObject3.setLastUpdateUser(getString (rs, 10)); 
      returnObject3.setLastUpdateTxId(getLongObject (rs, 11)); 
      returnObject3.setXVerified(getLongObject (rs, 31)); 
      returnObject3.setXRetailerId(getLongObject (rs, 32)); 
      returnObject3.setXLastModifiedSystemDate(getTimestamp (rs, 33)); 
      returnObject3.setXContactRetailerFlag(getString (rs, 34)); 
      returnObject3.setX_BPID(getString (rs, 35)); 
      returnObject.add (returnObject3);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT DISTINCT B1.H_LOCATION_GROUP_I AS H_CONT_METHOD_GRP_ID,B1.H_ACTION_CODE,B1.H_CREATED_BY,B1.H_CREATE_DT, B1.H_END_DT,B1.LOCATION_GROUP_ID,B1.CONTACT_METHOD_ID,B1.CONT_METH_TP_CD,B1.METHOD_ST_TP_CD,B1.ATTACH_ALLOW_IND,B1.TEXT_ONLY_IND,B1.MESSAGE_SIZE,B1.COMMENT_DESC,B1.LAST_UPDATE_DT,B1.LAST_UPDATE_USER, B1.LAST_UPDATE_TX_ID,A1.H_LOCATION_GROUP_I AS H_LOCATION_GROUP_I,A1.H_ACTION_CODE,A1.H_CREATED_BY,A1.H_CREATE_DT,A1.H_END_DT,A1.LOCATION_GROUP_ID,A1.UNDEL_REASON_TP_CD,A1.CONT_ID, A1.MEMBER_IND, A1.PREFERRED_IND,A1.SOLICIT_IND,A1.LOC_GROUP_TP_CODE,A1.EFFECT_START_MMDD,A1.EFFECT_END_MMDD,A1.EFFECT_START_TM,A1.EFFECT_END_TM,A1.START_DT,A1.END_DT,A1.LAST_UPDATE_DT,A1.LAST_UPDATE_USER, A1.LAST_UPDATE_TX_ID, A1.LAST_USED_DT, A1.LAST_VERIFIED_DT, A1.SOURCE_IDENT_TP_CD, B1.XVERIFIED_TP_CD, B1.XRETAILER_ID, B1.XMODIFY_SYS_DT, B1.XCONTACT_RETAILER_FLAG, B1.X_BPID FROM H_CONTACTMETHODGRO B1, H_LOCATIONGROUP A1 WHERE B1.H_LOCATION_GROUP_I = A1.H_LOCATION_GROUP_I AND A1.CONT_ID = ? AND ( ? BETWEEN A1.H_CREATE_DT AND A1.H_END_DT OR (? >= A1.H_CREATE_DT AND A1.H_END_DT IS NULL)) AND B1.CONT_METH_TP_CD = ? AND ( ? BETWEEN B1.H_CREATE_DT AND B1.H_END_DT OR (? >= B1.H_CREATE_DT AND B1.H_END_DT IS NULL))", pattern="tableAlias (CONTACTMETHODGROUP => com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup, H_CONTACTMETHODGRO => com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup, LOCATIONGROUP => com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup, H_LOCATIONGROUP => com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup , CONTACTMETHODGROUP => com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt , H_CONTACTMETHODGRO => com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue3<EObjContactMethodGroup,EObjLocationGroup,EObjXContactMethodGroupExt>> getPartyContactMethodHistory (Object[] parameters)
  {
    return queryIterator (getPartyContactMethodHistoryStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getPartyContactMethodHistoryStatementDescriptor = createStatementDescriptor (
    "getPartyContactMethodHistory(Object[])",
    "SELECT DISTINCT B1.H_LOCATION_GROUP_I AS H_CONT_METHOD_GRP_ID,B1.H_ACTION_CODE,B1.H_CREATED_BY,B1.H_CREATE_DT, B1.H_END_DT,B1.LOCATION_GROUP_ID,B1.CONTACT_METHOD_ID,B1.CONT_METH_TP_CD,B1.METHOD_ST_TP_CD,B1.ATTACH_ALLOW_IND,B1.TEXT_ONLY_IND,B1.MESSAGE_SIZE,B1.COMMENT_DESC,B1.LAST_UPDATE_DT,B1.LAST_UPDATE_USER, B1.LAST_UPDATE_TX_ID,A1.H_LOCATION_GROUP_I AS H_LOCATION_GROUP_I,A1.H_ACTION_CODE,A1.H_CREATED_BY,A1.H_CREATE_DT,A1.H_END_DT,A1.LOCATION_GROUP_ID,A1.UNDEL_REASON_TP_CD,A1.CONT_ID, A1.MEMBER_IND, A1.PREFERRED_IND,A1.SOLICIT_IND,A1.LOC_GROUP_TP_CODE,A1.EFFECT_START_MMDD,A1.EFFECT_END_MMDD,A1.EFFECT_START_TM,A1.EFFECT_END_TM,A1.START_DT,A1.END_DT,A1.LAST_UPDATE_DT,A1.LAST_UPDATE_USER, A1.LAST_UPDATE_TX_ID, A1.LAST_USED_DT, A1.LAST_VERIFIED_DT, A1.SOURCE_IDENT_TP_CD, B1.XVERIFIED_TP_CD, B1.XRETAILER_ID, B1.XMODIFY_SYS_DT, B1.XCONTACT_RETAILER_FLAG, B1.X_BPID FROM H_CONTACTMETHODGRO B1, H_LOCATIONGROUP A1 WHERE B1.H_LOCATION_GROUP_I = A1.H_LOCATION_GROUP_I AND A1.CONT_ID = ? AND ( ? BETWEEN A1.H_CREATE_DT AND A1.H_END_DT OR (? >= A1.H_CREATE_DT AND A1.H_END_DT IS NULL)) AND B1.CONT_METH_TP_CD = ? AND ( ? BETWEEN B1.H_CREATE_DT AND B1.H_END_DT OR (? >= B1.H_CREATE_DT AND B1.H_END_DT IS NULL))",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"h_cont_method_grp_id", "h_action_code", "h_created_by", "h_create_dt", "h_end_dt", "location_group_id", "contact_method_id", "cont_meth_tp_cd", "method_st_tp_cd", "attach_allow_ind", "text_only_ind", "message_size", "comment_desc", "last_update_dt", "last_update_user", "last_update_tx_id", "h_location_group_i", "h_action_code", "h_created_by", "h_create_dt", "h_end_dt", "location_group_id", "undel_reason_tp_cd", "cont_id", "member_ind", "preferred_ind", "solicit_ind", "loc_group_tp_code", "effect_start_mmdd", "effect_end_mmdd", "effect_start_tm", "effect_end_tm", "start_dt", "end_dt", "last_update_dt", "last_update_user", "last_update_tx_id", "last_used_dt", "last_verified_dt", "source_ident_tp_cd", "xverified_tp_cd", "xretailer_id", "xmodify_sys_dt", "xcontact_retailer_flag", "x_bpid"},
    new GetPartyContactMethodHistoryParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP}, {19, 0, 0, 19, 0, 0}, {0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1}},
    null,
    new GetPartyContactMethodHistoryRowHandler (),
    new int[][]{ {Types.BIGINT, Types.CHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.CHAR, Types.CHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.CHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR}, {19, 1, 20, 0, 0, 19, 19, 19, 19, 1, 1, 20, 100, 0, 20, 19, 19, 1, 20, 0, 0, 19, 19, 19, 0, 0, 0, 0, 10, 10, 10, 10, 0, 0, 0, 20, 19, 0, 0, 19, 19, 19, 0, 5, 50}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    5);

  /**
   * @generated
   */
  public static class GetPartyContactMethodHistoryParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
      setObject (stmt, 4, Types.BIGINT, parameters[3], 0);
      setObject (stmt, 5, Types.TIMESTAMP, parameters[4], 0);
      setObject (stmt, 6, Types.TIMESTAMP, parameters[5], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetPartyContactMethodHistoryRowHandler extends BaseRowHandler<ResultQueue3<EObjContactMethodGroup,EObjLocationGroup,EObjXContactMethodGroupExt>>
  {
    /**
     * @generated
     */
    public ResultQueue3<EObjContactMethodGroup,EObjLocationGroup,EObjXContactMethodGroupExt> handle (java.sql.ResultSet rs, ResultQueue3<EObjContactMethodGroup,EObjLocationGroup,EObjXContactMethodGroupExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue3<EObjContactMethodGroup,EObjLocationGroup,EObjXContactMethodGroupExt> ();

      EObjContactMethodGroup returnObject1 = new EObjContactMethodGroup ();
      returnObject1.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject1.setHistActionCode(getString (rs, 2)); 
      returnObject1.setHistCreatedBy(getString (rs, 3)); 
      returnObject1.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject1.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject1.setLocationGroupIdPK(getLongObject (rs, 6)); 
      returnObject1.setContactMethodId(getLongObject (rs, 7)); 
      returnObject1.setContMethTpCd(getLongObject (rs, 8)); 
      returnObject1.setMethodStTpCd(getLongObject (rs, 9)); 
      returnObject1.setAttachAllowInd(getString (rs, 10)); 
      returnObject1.setTextOnlyInd(getString (rs, 11)); 
      returnObject1.setMessageSize(getString (rs, 12)); 
      returnObject1.setCommentDesc(getString (rs, 13)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 14)); 
      returnObject1.setLastUpdateUser(getString (rs, 15)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 16)); 
      returnObject.add (returnObject1);

      EObjLocationGroup returnObject2 = new EObjLocationGroup ();
      returnObject2.setHistoryIdPK(getLongObject (rs, 17)); 
      returnObject2.setHistActionCode(getString (rs, 18)); 
      returnObject2.setHistCreatedBy(getString (rs, 19)); 
      returnObject2.setHistCreateDt(getTimestamp (rs, 20)); 
      returnObject2.setHistEndDt(getTimestamp (rs, 21)); 
      returnObject2.setLocationGroupIdPK(getLongObject (rs, 22)); 
      returnObject2.setUndelReasonTpCd(getLongObject (rs, 23)); 
      returnObject2.setContId(getLongObject (rs, 24)); 
      returnObject2.setMemberInd(getString (rs, 25)); 
      returnObject2.setPreferredInd(getString (rs, 26)); 
      returnObject2.setSolicitInd(getString (rs, 27)); 
      returnObject2.setLocGroupTpCode(getString (rs, 28)); 
      returnObject2.setEffectStartMMDD(getIntObject (rs, 29)); 
      returnObject2.setEffectEndMMDD(getIntObject (rs, 30)); 
      returnObject2.setEffectStartTm(getIntObject (rs, 31)); 
      returnObject2.setEffectEndTm(getIntObject (rs, 32)); 
      returnObject2.setStartDt(getTimestamp (rs, 33)); 
      returnObject2.setEndDt(getTimestamp (rs, 34)); 
      returnObject2.setLastUpdateDt(getTimestamp (rs, 35)); 
      returnObject2.setLastUpdateUser(getString (rs, 36)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 37)); 
      returnObject2.setLastUsedDt(getTimestamp (rs, 38)); 
      returnObject2.setLastVerifiedDt(getTimestamp (rs, 39)); 
      returnObject2.setSourceIdentTpCd(getLongObject (rs, 40)); 
      returnObject.add (returnObject2);

      EObjXContactMethodGroupExt returnObject3 = new EObjXContactMethodGroupExt ();
      returnObject3.setHistActionCode(getString (rs, 2)); 
      returnObject3.setHistCreatedBy(getString (rs, 3)); 
      returnObject3.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject3.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject3.setLastUpdateDt(getTimestamp (rs, 14)); 
      returnObject3.setLastUpdateUser(getString (rs, 15)); 
      returnObject3.setLastUpdateTxId(getLongObject (rs, 16)); 
      returnObject3.setXVerified(getLongObject (rs, 41)); 
      returnObject3.setXRetailerId(getLongObject (rs, 42)); 
      returnObject3.setXLastModifiedSystemDate(getTimestamp (rs, 43)); 
      returnObject3.setXContactRetailerFlag(getString (rs, 44)); 
      returnObject3.setX_BPID(getString (rs, 45)); 
      returnObject.add (returnObject3);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT CONTACTMETHODGROUP.LOCATION_GROUP_ID, CONTACTMETHODGROUP.CONTACT_METHOD_ID, CONTACTMETHODGROUP.CONT_METH_TP_CD, CONTACTMETHODGROUP.METHOD_ST_TP_CD, CONTACTMETHODGROUP.ATTACH_ALLOW_IND, CONTACTMETHODGROUP.TEXT_ONLY_IND, CONTACTMETHODGROUP.MESSAGE_SIZE, CONTACTMETHODGROUP.COMMENT_DESC, CONTACTMETHODGROUP.LAST_UPDATE_DT, CONTACTMETHODGROUP.LAST_UPDATE_USER, CONTACTMETHODGROUP.LAST_UPDATE_TX_ID, LOCATIONGROUP.LOCATION_GROUP_ID, LOCATIONGROUP.UNDEL_REASON_TP_CD, LOCATIONGROUP.CONT_ID, LOCATIONGROUP.MEMBER_IND, LOCATIONGROUP.PREFERRED_IND, LOCATIONGROUP.SOLICIT_IND, LOCATIONGROUP.LOC_GROUP_TP_CODE, LOCATIONGROUP.EFFECT_START_MMDD, LOCATIONGROUP.EFFECT_END_MMDD, LOCATIONGROUP.EFFECT_START_TM, LOCATIONGROUP.EFFECT_END_TM, LOCATIONGROUP.START_DT, LOCATIONGROUP.END_DT, LOCATIONGROUP.LAST_UPDATE_DT, LOCATIONGROUP.LAST_UPDATE_USER, LOCATIONGROUP.LAST_UPDATE_TX_ID, LOCATIONGROUP.LAST_USED_DT, LOCATIONGROUP.LAST_VERIFIED_DT, LOCATIONGROUP.SOURCE_IDENT_TP_CD, CONTACTMETHODGROUP.XVERIFIED_TP_CD, CONTACTMETHODGROUP.XRETAILER_ID, CONTACTMETHODGROUP.XMODIFY_SYS_DT, CONTACTMETHODGROUP.XCONTACT_RETAILER_FLAG, CONTACTMETHODGROUP.X_BPID FROM CONTACTMETHODGROUP,LOCATIONGROUP WHERE CONTACTMETHODGROUP.LOCATION_GROUP_ID = LOCATIONGROUP.LOCATION_GROUP_ID AND LOCATIONGROUP.LOCATION_GROUP_ID = ?", pattern="tableAlias (CONTACTMETHODGROUP => com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup, H_CONTACTMETHODGRO => com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup, LOCATIONGROUP => com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup, H_LOCATIONGROUP => com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup , CONTACTMETHODGROUP => com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt , H_CONTACTMETHODGRO => com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue3<EObjContactMethodGroup,EObjLocationGroup,EObjXContactMethodGroupExt>> getPartyContactMethodByID (Object[] parameters)
  {
    return queryIterator (getPartyContactMethodByIDStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getPartyContactMethodByIDStatementDescriptor = createStatementDescriptor (
    "getPartyContactMethodByID(Object[])",
    "SELECT CONTACTMETHODGROUP.LOCATION_GROUP_ID, CONTACTMETHODGROUP.CONTACT_METHOD_ID, CONTACTMETHODGROUP.CONT_METH_TP_CD, CONTACTMETHODGROUP.METHOD_ST_TP_CD, CONTACTMETHODGROUP.ATTACH_ALLOW_IND, CONTACTMETHODGROUP.TEXT_ONLY_IND, CONTACTMETHODGROUP.MESSAGE_SIZE, CONTACTMETHODGROUP.COMMENT_DESC, CONTACTMETHODGROUP.LAST_UPDATE_DT, CONTACTMETHODGROUP.LAST_UPDATE_USER, CONTACTMETHODGROUP.LAST_UPDATE_TX_ID, LOCATIONGROUP.LOCATION_GROUP_ID, LOCATIONGROUP.UNDEL_REASON_TP_CD, LOCATIONGROUP.CONT_ID, LOCATIONGROUP.MEMBER_IND, LOCATIONGROUP.PREFERRED_IND, LOCATIONGROUP.SOLICIT_IND, LOCATIONGROUP.LOC_GROUP_TP_CODE, LOCATIONGROUP.EFFECT_START_MMDD, LOCATIONGROUP.EFFECT_END_MMDD, LOCATIONGROUP.EFFECT_START_TM, LOCATIONGROUP.EFFECT_END_TM, LOCATIONGROUP.START_DT, LOCATIONGROUP.END_DT, LOCATIONGROUP.LAST_UPDATE_DT, LOCATIONGROUP.LAST_UPDATE_USER, LOCATIONGROUP.LAST_UPDATE_TX_ID, LOCATIONGROUP.LAST_USED_DT, LOCATIONGROUP.LAST_VERIFIED_DT, LOCATIONGROUP.SOURCE_IDENT_TP_CD, CONTACTMETHODGROUP.XVERIFIED_TP_CD, CONTACTMETHODGROUP.XRETAILER_ID, CONTACTMETHODGROUP.XMODIFY_SYS_DT, CONTACTMETHODGROUP.XCONTACT_RETAILER_FLAG, CONTACTMETHODGROUP.X_BPID FROM CONTACTMETHODGROUP,LOCATIONGROUP WHERE CONTACTMETHODGROUP.LOCATION_GROUP_ID = LOCATIONGROUP.LOCATION_GROUP_ID AND LOCATIONGROUP.LOCATION_GROUP_ID = ?",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"location_group_id", "contact_method_id", "cont_meth_tp_cd", "method_st_tp_cd", "attach_allow_ind", "text_only_ind", "message_size", "comment_desc", "last_update_dt", "last_update_user", "last_update_tx_id", "location_group_id", "undel_reason_tp_cd", "cont_id", "member_ind", "preferred_ind", "solicit_ind", "loc_group_tp_code", "effect_start_mmdd", "effect_end_mmdd", "effect_start_tm", "effect_end_tm", "start_dt", "end_dt", "last_update_dt", "last_update_user", "last_update_tx_id", "last_used_dt", "last_verified_dt", "source_ident_tp_cd", "xverified_tp_cd", "xretailer_id", "xmodify_sys_dt", "xcontact_retailer_flag", "x_bpid"},
    new GetPartyContactMethodByIDParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetPartyContactMethodByIDRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.CHAR, Types.CHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR}, {19, 19, 19, 19, 1, 1, 20, 100, 0, 20, 19, 19, 19, 19, 0, 0, 0, 0, 10, 10, 10, 10, 0, 0, 0, 20, 19, 0, 0, 19, 19, 19, 0, 5, 50}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    6);

  /**
   * @generated
   */
  public static class GetPartyContactMethodByIDParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetPartyContactMethodByIDRowHandler extends BaseRowHandler<ResultQueue3<EObjContactMethodGroup,EObjLocationGroup,EObjXContactMethodGroupExt>>
  {
    /**
     * @generated
     */
    public ResultQueue3<EObjContactMethodGroup,EObjLocationGroup,EObjXContactMethodGroupExt> handle (java.sql.ResultSet rs, ResultQueue3<EObjContactMethodGroup,EObjLocationGroup,EObjXContactMethodGroupExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue3<EObjContactMethodGroup,EObjLocationGroup,EObjXContactMethodGroupExt> ();

      EObjContactMethodGroup returnObject1 = new EObjContactMethodGroup ();
      returnObject1.setLocationGroupIdPK(getLongObject (rs, 1)); 
      returnObject1.setContactMethodId(getLongObject (rs, 2)); 
      returnObject1.setContMethTpCd(getLongObject (rs, 3)); 
      returnObject1.setMethodStTpCd(getLongObject (rs, 4)); 
      returnObject1.setAttachAllowInd(getString (rs, 5)); 
      returnObject1.setTextOnlyInd(getString (rs, 6)); 
      returnObject1.setMessageSize(getString (rs, 7)); 
      returnObject1.setCommentDesc(getString (rs, 8)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 9)); 
      returnObject1.setLastUpdateUser(getString (rs, 10)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 11)); 
      returnObject.add (returnObject1);

      EObjLocationGroup returnObject2 = new EObjLocationGroup ();
      returnObject2.setLocationGroupIdPK(getLongObject (rs, 12)); 
      returnObject2.setUndelReasonTpCd(getLongObject (rs, 13)); 
      returnObject2.setContId(getLongObject (rs, 14)); 
      returnObject2.setMemberInd(getString (rs, 15)); 
      returnObject2.setPreferredInd(getString (rs, 16)); 
      returnObject2.setSolicitInd(getString (rs, 17)); 
      returnObject2.setLocGroupTpCode(getString (rs, 18)); 
      returnObject2.setEffectStartMMDD(getIntObject (rs, 19)); 
      returnObject2.setEffectEndMMDD(getIntObject (rs, 20)); 
      returnObject2.setEffectStartTm(getIntObject (rs, 21)); 
      returnObject2.setEffectEndTm(getIntObject (rs, 22)); 
      returnObject2.setStartDt(getTimestamp (rs, 23)); 
      returnObject2.setEndDt(getTimestamp (rs, 24)); 
      returnObject2.setLastUpdateDt(getTimestamp (rs, 25)); 
      returnObject2.setLastUpdateUser(getString (rs, 26)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 27)); 
      returnObject2.setLastUsedDt(getTimestamp (rs, 28)); 
      returnObject2.setLastVerifiedDt(getTimestamp (rs, 29)); 
      returnObject2.setSourceIdentTpCd(getLongObject (rs, 30)); 
      returnObject.add (returnObject2);

      EObjXContactMethodGroupExt returnObject3 = new EObjXContactMethodGroupExt ();
      returnObject3.setLastUpdateDt(getTimestamp (rs, 9)); 
      returnObject3.setLastUpdateUser(getString (rs, 10)); 
      returnObject3.setLastUpdateTxId(getLongObject (rs, 11)); 
      returnObject3.setXVerified(getLongObject (rs, 31)); 
      returnObject3.setXRetailerId(getLongObject (rs, 32)); 
      returnObject3.setXLastModifiedSystemDate(getTimestamp (rs, 33)); 
      returnObject3.setXContactRetailerFlag(getString (rs, 34)); 
      returnObject3.setX_BPID(getString (rs, 35)); 
      returnObject.add (returnObject3);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT DISTINCT A.H_LOCATION_GROUP_I AS H_CONT_METHOD_GRP_ID, A.H_ACTION_CODE, A.H_CREATED_BY, A.H_CREATE_DT, A.H_END_DT, A.LOCATION_GROUP_ID, A.CONTACT_METHOD_ID, A.CONT_METH_TP_CD, A.METHOD_ST_TP_CD, A.ATTACH_ALLOW_IND, A.TEXT_ONLY_IND, A.MESSAGE_SIZE, A.COMMENT_DESC, A.LAST_UPDATE_DT, A.LAST_UPDATE_USER, A.LAST_UPDATE_TX_ID, B.H_LOCATION_GROUP_I AS H_LOCATION_GROUP_I, B.H_ACTION_CODE, B.H_CREATED_BY, B.H_CREATE_DT, B.H_END_DT, B.LOCATION_GROUP_ID, B.UNDEL_REASON_TP_CD, B.CONT_ID, B.MEMBER_IND, B.PREFERRED_IND, B.SOLICIT_IND, B.LOC_GROUP_TP_CODE, B.EFFECT_START_MMDD, B.EFFECT_END_MMDD, B.EFFECT_START_TM, B.EFFECT_END_TM, B.START_DT, B.END_DT, B.LAST_UPDATE_DT, B.LAST_UPDATE_USER, B.LAST_UPDATE_TX_ID, B.LAST_USED_DT, B.LAST_VERIFIED_DT, B.SOURCE_IDENT_TP_CD, A.XVERIFIED_TP_CD, A.XRETAILER_ID, A.XMODIFY_SYS_DT, A.XCONTACT_RETAILER_FLAG, A.X_BPID FROM H_CONTACTMETHODGRO A, H_LOCATIONGROUP B WHERE B.CONT_ID = ? AND A.LOCATION_GROUP_ID = B.LOCATION_GROUP_ID AND A.LAST_UPDATE_TX_ID = B.LAST_UPDATE_TX_ID AND ( A.H_CREATE_DT BETWEEN ? AND ?) UNION SELECT DISTINCT A.H_LOCATION_GROUP_I AS H_CONT_METHOD_GRP_ID, A.H_ACTION_CODE, A.H_CREATED_BY, A.H_CREATE_DT, A.H_END_DT, A.LOCATION_GROUP_ID, A.CONTACT_METHOD_ID, A.CONT_METH_TP_CD, A.METHOD_ST_TP_CD, A.ATTACH_ALLOW_IND, A.TEXT_ONLY_IND, A.MESSAGE_SIZE, A.COMMENT_DESC, A.LAST_UPDATE_DT, A.LAST_UPDATE_USER, A.LAST_UPDATE_TX_ID, B.H_LOCATION_GROUP_I AS H_LOCATION_GROUP_I, B.H_ACTION_CODE, B.H_CREATED_BY, B.H_CREATE_DT, B.H_END_DT, B.LOCATION_GROUP_ID, B.UNDEL_REASON_TP_CD, B.CONT_ID, B.MEMBER_IND, B.PREFERRED_IND, B.SOLICIT_IND, B.LOC_GROUP_TP_CODE, B.EFFECT_START_MMDD , B.EFFECT_END_MMDD, B.EFFECT_START_TM, B.EFFECT_END_TM, B.START_DT, B.END_DT, B.LAST_UPDATE_DT, B.LAST_UPDATE_USER, B.LAST_UPDATE_TX_ID, B.LAST_USED_DT, B.LAST_VERIFIED_DT, B.SOURCE_IDENT_TP_CD, A.XVERIFIED_TP_CD, A.XRETAILER_ID, A.XMODIFY_SYS_DT, A.XCONTACT_RETAILER_FLAG, A.X_BPID FROM H_LOCATIONGROUP B LEFT JOIN H_CONTACTMETHODGRO A ON A.LOCATION_GROUP_ID = B.LOCATION_GROUP_ID AND A.LAST_UPDATE_TX_ID = B.LAST_UPDATE_TX_ID WHERE B.CONT_ID = ? AND ( B.H_CREATE_DT BETWEEN ? AND ?)", pattern="<rsm><col number='1' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup' property='historyIdPK'></col><col number='2' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup' property='histActionCode'></col><col number='3' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup' property='histCreatedBy'></col><col number='4' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup' property='histCreateDt'></col><col number='5' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup' property='histEndDt'></col><col number='6' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup' property='locationGroupIdPK'></col><col number='7' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup' property='contactMethodId'></col><col number='8' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup' property='contMethTpCd'></col><col number='9' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup' property='methodStTpCd'></col><col number='10' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup' property='attachAllowInd'></col><col number='11' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup' property='textOnlyInd'></col><col number='12' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup' property='messageSize'></col><col number='13' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup' property='commentDesc'></col><col number='14' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup' property='lastUpdateDt'></col><col number='15' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup' property='lastUpdateUser'></col><col number='16' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup' property='lastUpdateTxId'></col><col number='17' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='historyIdPK'></col><col number='18' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='histActionCode'></col><col number='19' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='histCreatedBy'></col><col number='20' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='histCreateDt'></col><col number='21' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='histEndDt'></col><col number='22' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='locationGroupIdPK'></col><col number='23' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='undelReasonTpCd'></col><col number='24' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='contId'></col><col number='25' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='memberInd'></col><col number='26' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='preferredInd'></col><col number='27' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='solicitInd'></col><col number='28' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='locGroupTpCode'></col><col number='29' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='effectStartMMDD'></col><col number='30' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='effectEndMMDD'></col><col number='31' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='effectStartTm'></col><col number='32' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='effectEndTm'></col><col number='33' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='startDt'></col><col number='34' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='endDt'></col><col number='35' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='lastUpdateDt'></col><col number='36' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='lastUpdateUser'></col><col number='37' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='lastUpdateTxId'></col><col number='38' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='lastUsedDt'></col><col number='39' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='lastVerifiedDt'></col><col number='40' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='sourceIdentTpCd'></col><col number='41' bean='com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt' property='XVerified'></col><col number='42' bean='com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt' property='XRetailerId'></col><col number='43' bean='com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt' property='XLastModifiedSystemDate'></col><col number='44' bean='com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt' property='XContactRetailerFlag'></col><col number='45' bean='com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt' property='X_BPID'></col></rsm>" )
   * 
   * @generated
   */
  public Iterator<ResultQueue3<EObjContactMethodGroup,EObjLocationGroup,EObjXContactMethodGroupExt>> getPartyContactMethodImages (Object[] parameters)
  {
    return queryIterator (getPartyContactMethodImagesStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getPartyContactMethodImagesStatementDescriptor = createStatementDescriptor (
    "getPartyContactMethodImages(Object[])",
    "SELECT DISTINCT A.H_LOCATION_GROUP_I AS H_CONT_METHOD_GRP_ID, A.H_ACTION_CODE, A.H_CREATED_BY, A.H_CREATE_DT, A.H_END_DT, A.LOCATION_GROUP_ID, A.CONTACT_METHOD_ID, A.CONT_METH_TP_CD, A.METHOD_ST_TP_CD, A.ATTACH_ALLOW_IND, A.TEXT_ONLY_IND, A.MESSAGE_SIZE, A.COMMENT_DESC, A.LAST_UPDATE_DT, A.LAST_UPDATE_USER, A.LAST_UPDATE_TX_ID, B.H_LOCATION_GROUP_I AS H_LOCATION_GROUP_I, B.H_ACTION_CODE, B.H_CREATED_BY, B.H_CREATE_DT, B.H_END_DT, B.LOCATION_GROUP_ID, B.UNDEL_REASON_TP_CD, B.CONT_ID, B.MEMBER_IND, B.PREFERRED_IND, B.SOLICIT_IND, B.LOC_GROUP_TP_CODE, B.EFFECT_START_MMDD, B.EFFECT_END_MMDD, B.EFFECT_START_TM, B.EFFECT_END_TM, B.START_DT, B.END_DT, B.LAST_UPDATE_DT, B.LAST_UPDATE_USER, B.LAST_UPDATE_TX_ID, B.LAST_USED_DT, B.LAST_VERIFIED_DT, B.SOURCE_IDENT_TP_CD, A.XVERIFIED_TP_CD, A.XRETAILER_ID, A.XMODIFY_SYS_DT, A.XCONTACT_RETAILER_FLAG, A.X_BPID FROM H_CONTACTMETHODGRO A, H_LOCATIONGROUP B WHERE B.CONT_ID = ? AND A.LOCATION_GROUP_ID = B.LOCATION_GROUP_ID AND A.LAST_UPDATE_TX_ID = B.LAST_UPDATE_TX_ID AND ( A.H_CREATE_DT BETWEEN ? AND ?) UNION SELECT DISTINCT A.H_LOCATION_GROUP_I AS H_CONT_METHOD_GRP_ID, A.H_ACTION_CODE, A.H_CREATED_BY, A.H_CREATE_DT, A.H_END_DT, A.LOCATION_GROUP_ID, A.CONTACT_METHOD_ID, A.CONT_METH_TP_CD, A.METHOD_ST_TP_CD, A.ATTACH_ALLOW_IND, A.TEXT_ONLY_IND, A.MESSAGE_SIZE, A.COMMENT_DESC, A.LAST_UPDATE_DT, A.LAST_UPDATE_USER, A.LAST_UPDATE_TX_ID, B.H_LOCATION_GROUP_I AS H_LOCATION_GROUP_I, B.H_ACTION_CODE, B.H_CREATED_BY, B.H_CREATE_DT, B.H_END_DT, B.LOCATION_GROUP_ID, B.UNDEL_REASON_TP_CD, B.CONT_ID, B.MEMBER_IND, B.PREFERRED_IND, B.SOLICIT_IND, B.LOC_GROUP_TP_CODE, B.EFFECT_START_MMDD , B.EFFECT_END_MMDD, B.EFFECT_START_TM, B.EFFECT_END_TM, B.START_DT, B.END_DT, B.LAST_UPDATE_DT, B.LAST_UPDATE_USER, B.LAST_UPDATE_TX_ID, B.LAST_USED_DT, B.LAST_VERIFIED_DT, B.SOURCE_IDENT_TP_CD, A.XVERIFIED_TP_CD, A.XRETAILER_ID, A.XMODIFY_SYS_DT, A.XCONTACT_RETAILER_FLAG, A.X_BPID FROM H_LOCATIONGROUP B LEFT JOIN H_CONTACTMETHODGRO A ON A.LOCATION_GROUP_ID = B.LOCATION_GROUP_ID AND A.LAST_UPDATE_TX_ID = B.LAST_UPDATE_TX_ID WHERE B.CONT_ID = ? AND ( B.H_CREATE_DT BETWEEN ? AND ?)",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"h_cont_method_grp_id", "h_action_code", "h_created_by", "h_create_dt", "h_end_dt", "location_group_id", "contact_method_id", "cont_meth_tp_cd", "method_st_tp_cd", "attach_allow_ind", "text_only_ind", "message_size", "comment_desc", "last_update_dt", "last_update_user", "last_update_tx_id", "h_location_group_i", "h_action_code", "h_created_by", "h_create_dt", "h_end_dt", "location_group_id", "undel_reason_tp_cd", "cont_id", "member_ind", "preferred_ind", "solicit_ind", "loc_group_tp_code", "effect_start_mmdd", "effect_end_mmdd", "effect_start_tm", "effect_end_tm", "start_dt", "end_dt", "last_update_dt", "last_update_user", "last_update_tx_id", "last_used_dt", "last_verified_dt", "source_ident_tp_cd", "xverified_tp_cd", "xretailer_id", "xmodify_sys_dt", "xcontact_retailer_flag", "x_bpid"},
    new GetPartyContactMethodImagesParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP}, {19, 0, 0, 19, 0, 0}, {0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1}},
    null,
    new GetPartyContactMethodImagesRowHandler (),
    new int[][]{ {Types.BIGINT, Types.CHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.CHAR, Types.CHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.CHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR}, {19, 1, 20, 0, 0, 19, 19, 19, 19, 1, 1, 20, 100, 0, 20, 19, 19, 1, 20, 0, 0, 19, 19, 19, 0, 0, 0, 0, 10, 10, 10, 10, 0, 0, 0, 20, 19, 0, 0, 19, 19, 19, 0, 5, 50}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    7);

  /**
   * @generated
   */
  public static class GetPartyContactMethodImagesParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
      setObject (stmt, 4, Types.BIGINT, parameters[3], 0);
      setObject (stmt, 5, Types.TIMESTAMP, parameters[4], 0);
      setObject (stmt, 6, Types.TIMESTAMP, parameters[5], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetPartyContactMethodImagesRowHandler extends BaseRowHandler<ResultQueue3<EObjContactMethodGroup,EObjLocationGroup,EObjXContactMethodGroupExt>>
  {
    /**
     * @generated
     */
    public ResultQueue3<EObjContactMethodGroup,EObjLocationGroup,EObjXContactMethodGroupExt> handle (java.sql.ResultSet rs, ResultQueue3<EObjContactMethodGroup,EObjLocationGroup,EObjXContactMethodGroupExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue3<EObjContactMethodGroup,EObjLocationGroup,EObjXContactMethodGroupExt> ();

      EObjContactMethodGroup returnObject1 = new EObjContactMethodGroup ();
      returnObject1.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject1.setHistActionCode(getString (rs, 2)); 
      returnObject1.setHistCreatedBy(getString (rs, 3)); 
      returnObject1.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject1.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject1.setLocationGroupIdPK(getLongObject (rs, 6)); 
      returnObject1.setContactMethodId(getLongObject (rs, 7)); 
      returnObject1.setContMethTpCd(getLongObject (rs, 8)); 
      returnObject1.setMethodStTpCd(getLongObject (rs, 9)); 
      returnObject1.setAttachAllowInd(getString (rs, 10)); 
      returnObject1.setTextOnlyInd(getString (rs, 11)); 
      returnObject1.setMessageSize(getString (rs, 12)); 
      returnObject1.setCommentDesc(getString (rs, 13)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 14)); 
      returnObject1.setLastUpdateUser(getString (rs, 15)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 16)); 
      returnObject.add (returnObject1);

      EObjLocationGroup returnObject2 = new EObjLocationGroup ();
      returnObject2.setHistoryIdPK(getLongObject (rs, 17)); 
      returnObject2.setHistActionCode(getString (rs, 18)); 
      returnObject2.setHistCreatedBy(getString (rs, 19)); 
      returnObject2.setHistCreateDt(getTimestamp (rs, 20)); 
      returnObject2.setHistEndDt(getTimestamp (rs, 21)); 
      returnObject2.setLocationGroupIdPK(getLongObject (rs, 22)); 
      returnObject2.setUndelReasonTpCd(getLongObject (rs, 23)); 
      returnObject2.setContId(getLongObject (rs, 24)); 
      returnObject2.setMemberInd(getString (rs, 25)); 
      returnObject2.setPreferredInd(getString (rs, 26)); 
      returnObject2.setSolicitInd(getString (rs, 27)); 
      returnObject2.setLocGroupTpCode(getString (rs, 28)); 
      returnObject2.setEffectStartMMDD(getIntObject (rs, 29)); 
      returnObject2.setEffectEndMMDD(getIntObject (rs, 30)); 
      returnObject2.setEffectStartTm(getIntObject (rs, 31)); 
      returnObject2.setEffectEndTm(getIntObject (rs, 32)); 
      returnObject2.setStartDt(getTimestamp (rs, 33)); 
      returnObject2.setEndDt(getTimestamp (rs, 34)); 
      returnObject2.setLastUpdateDt(getTimestamp (rs, 35)); 
      returnObject2.setLastUpdateUser(getString (rs, 36)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 37)); 
      returnObject2.setLastUsedDt(getTimestamp (rs, 38)); 
      returnObject2.setLastVerifiedDt(getTimestamp (rs, 39)); 
      returnObject2.setSourceIdentTpCd(getLongObject (rs, 40)); 
      returnObject.add (returnObject2);

      EObjXContactMethodGroupExt returnObject3 = new EObjXContactMethodGroupExt ();
      returnObject3.setXVerified(getLongObject (rs, 41)); 
      returnObject3.setXRetailerId(getLongObject (rs, 42)); 
      returnObject3.setXLastModifiedSystemDate(getTimestamp (rs, 43)); 
      returnObject3.setXContactRetailerFlag(getString (rs, 44)); 
      returnObject3.setX_BPID(getString (rs, 45)); 
      returnObject.add (returnObject3);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT DISTINCT A.LOCATION_GROUP_ID, A.CONTACT_METHOD_ID, A.LAST_UPDATE_DT, B.LOCATION_GROUP_ID, B.LAST_UPDATE_DT, A.XVERIFIED_TP_CD, A.XRETAILER_ID, A.XMODIFY_SYS_DT, A.XCONTACT_RETAILER_FLAG, A.X_BPID FROM H_CONTACTMETHODGRO A, H_LOCATIONGROUP B WHERE B.CONT_ID = ? AND A.LOCATION_GROUP_ID = B.LOCATION_GROUP_ID AND A.LAST_UPDATE_TX_ID = B.LAST_UPDATE_TX_ID AND (( A.LAST_UPDATE_DT BETWEEN ? AND ? ) OR ( B.H_CREATE_DT BETWEEN ? AND ?))", pattern="tableAlias (CONTACTMETHODGROUP => com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup, H_CONTACTMETHODGRO => com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup, LOCATIONGROUP => com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup, H_LOCATIONGROUP => com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup , CONTACTMETHODGROUP => com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt , H_CONTACTMETHODGRO => com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue3<EObjContactMethodGroup,EObjLocationGroup,EObjXContactMethodGroupExt>> getPartyContactMethodsLightImages (Object[] parameters)
  {
    return queryIterator (getPartyContactMethodsLightImagesStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getPartyContactMethodsLightImagesStatementDescriptor = createStatementDescriptor (
    "getPartyContactMethodsLightImages(Object[])",
    "SELECT DISTINCT A.LOCATION_GROUP_ID, A.CONTACT_METHOD_ID, A.LAST_UPDATE_DT, B.LOCATION_GROUP_ID, B.LAST_UPDATE_DT, A.XVERIFIED_TP_CD, A.XRETAILER_ID, A.XMODIFY_SYS_DT, A.XCONTACT_RETAILER_FLAG, A.X_BPID FROM H_CONTACTMETHODGRO A, H_LOCATIONGROUP B WHERE B.CONT_ID = ? AND A.LOCATION_GROUP_ID = B.LOCATION_GROUP_ID AND A.LAST_UPDATE_TX_ID = B.LAST_UPDATE_TX_ID AND (( A.LAST_UPDATE_DT BETWEEN ? AND ? ) OR ( B.H_CREATE_DT BETWEEN ? AND ?))",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"location_group_id", "contact_method_id", "last_update_dt", "location_group_id", "last_update_dt", "xverified_tp_cd", "xretailer_id", "xmodify_sys_dt", "xcontact_retailer_flag", "x_bpid"},
    new GetPartyContactMethodsLightImagesParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP}, {19, 0, 0, 0, 0}, {0, 0, 0, 0, 0}, {1, 1, 1, 1, 1}},
    null,
    new GetPartyContactMethodsLightImagesRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.BIGINT, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR}, {19, 19, 0, 19, 0, 19, 19, 0, 5, 50}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    8);

  /**
   * @generated
   */
  public static class GetPartyContactMethodsLightImagesParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
      setObject (stmt, 4, Types.TIMESTAMP, parameters[3], 0);
      setObject (stmt, 5, Types.TIMESTAMP, parameters[4], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetPartyContactMethodsLightImagesRowHandler extends BaseRowHandler<ResultQueue3<EObjContactMethodGroup,EObjLocationGroup,EObjXContactMethodGroupExt>>
  {
    /**
     * @generated
     */
    public ResultQueue3<EObjContactMethodGroup,EObjLocationGroup,EObjXContactMethodGroupExt> handle (java.sql.ResultSet rs, ResultQueue3<EObjContactMethodGroup,EObjLocationGroup,EObjXContactMethodGroupExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue3<EObjContactMethodGroup,EObjLocationGroup,EObjXContactMethodGroupExt> ();

      EObjContactMethodGroup returnObject1 = new EObjContactMethodGroup ();
      returnObject1.setLocationGroupIdPK(getLongObject (rs, 1)); 
      returnObject1.setContactMethodId(getLongObject (rs, 2)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 3)); 
      returnObject.add (returnObject1);

      EObjLocationGroup returnObject2 = new EObjLocationGroup ();
      returnObject2.setLocationGroupIdPK(getLongObject (rs, 4)); 
      returnObject2.setLastUpdateDt(getTimestamp (rs, 5)); 
      returnObject.add (returnObject2);

      EObjXContactMethodGroupExt returnObject3 = new EObjXContactMethodGroupExt ();
      returnObject3.setLastUpdateDt(getTimestamp (rs, 3)); 
      returnObject3.setXVerified(getLongObject (rs, 6)); 
      returnObject3.setXRetailerId(getLongObject (rs, 7)); 
      returnObject3.setXLastModifiedSystemDate(getTimestamp (rs, 8)); 
      returnObject3.setXContactRetailerFlag(getString (rs, 9)); 
      returnObject3.setX_BPID(getString (rs, 10)); 
      returnObject.add (returnObject3);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT DISTINCT A.H_LOCATION_GROUP_I AS H_CONT_METHOD_GRP_ID, A.H_ACTION_CODE, A.H_CREATED_BY, A.H_CREATE_DT, A.H_END_DT, A.LOCATION_GROUP_ID, A.CONTACT_METHOD_ID, A.CONT_METH_TP_CD, A.METHOD_ST_TP_CD, A.ATTACH_ALLOW_IND, A.TEXT_ONLY_IND, A.MESSAGE_SIZE, A.COMMENT_DESC, A.LAST_UPDATE_DT, A.LAST_UPDATE_USER, A.LAST_UPDATE_TX_ID, B.H_LOCATION_GROUP_I AS H_LOCATION_GROUP_I, B.H_ACTION_CODE, B.H_CREATED_BY, B.H_CREATE_DT, B.H_END_DT, B.LOCATION_GROUP_ID, B.UNDEL_REASON_TP_CD, B.CONT_ID, B.MEMBER_IND, B.PREFERRED_IND, B.SOLICIT_IND, B.LOC_GROUP_TP_CODE, B.EFFECT_START_MMDD, B.EFFECT_END_MMDD, B.EFFECT_START_TM, B.EFFECT_END_TM, B.START_DT, B.END_DT, B.LAST_UPDATE_DT, B.LAST_UPDATE_USER, B.LAST_UPDATE_TX_ID, B.LAST_USED_DT, B.LAST_VERIFIED_DT, B.SOURCE_IDENT_TP_CD, A.XVERIFIED_TP_CD, A.XRETAILER_ID, A.XMODIFY_SYS_DT, A.XCONTACT_RETAILER_FLAG, A.X_BPID FROM H_CONTACTMETHODGRO A,H_LOCATIONGROUP B WHERE A.H_LOCATION_GROUP_I = ? AND A.H_LOCATION_GROUP_I = B.H_LOCATION_GROUP_I AND (( ? BETWEEN A.H_CREATE_DT AND A.H_END_DT ) OR ( ? >= A.H_CREATE_DT AND A.H_END_DT IS NULL )) AND (( ? BETWEEN B.H_CREATE_DT AND B.H_END_DT ) OR ( ? >= B.H_CREATE_DT AND B.H_END_DT IS NULL ))", pattern="tableAlias (CONTACTMETHODGROUP => com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup, H_CONTACTMETHODGRO => com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup, LOCATIONGROUP => com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup, H_LOCATIONGROUP => com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup , CONTACTMETHODGROUP => com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt , H_CONTACTMETHODGRO => com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue3<EObjContactMethodGroup,EObjLocationGroup,EObjXContactMethodGroupExt>> getPartyContactMethodHistoryByID (Object[] parameters)
  {
    return queryIterator (getPartyContactMethodHistoryByIDStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getPartyContactMethodHistoryByIDStatementDescriptor = createStatementDescriptor (
    "getPartyContactMethodHistoryByID(Object[])",
    "SELECT DISTINCT A.H_LOCATION_GROUP_I AS H_CONT_METHOD_GRP_ID, A.H_ACTION_CODE, A.H_CREATED_BY, A.H_CREATE_DT, A.H_END_DT, A.LOCATION_GROUP_ID, A.CONTACT_METHOD_ID, A.CONT_METH_TP_CD, A.METHOD_ST_TP_CD, A.ATTACH_ALLOW_IND, A.TEXT_ONLY_IND, A.MESSAGE_SIZE, A.COMMENT_DESC, A.LAST_UPDATE_DT, A.LAST_UPDATE_USER, A.LAST_UPDATE_TX_ID, B.H_LOCATION_GROUP_I AS H_LOCATION_GROUP_I, B.H_ACTION_CODE, B.H_CREATED_BY, B.H_CREATE_DT, B.H_END_DT, B.LOCATION_GROUP_ID, B.UNDEL_REASON_TP_CD, B.CONT_ID, B.MEMBER_IND, B.PREFERRED_IND, B.SOLICIT_IND, B.LOC_GROUP_TP_CODE, B.EFFECT_START_MMDD, B.EFFECT_END_MMDD, B.EFFECT_START_TM, B.EFFECT_END_TM, B.START_DT, B.END_DT, B.LAST_UPDATE_DT, B.LAST_UPDATE_USER, B.LAST_UPDATE_TX_ID, B.LAST_USED_DT, B.LAST_VERIFIED_DT, B.SOURCE_IDENT_TP_CD, A.XVERIFIED_TP_CD, A.XRETAILER_ID, A.XMODIFY_SYS_DT, A.XCONTACT_RETAILER_FLAG, A.X_BPID FROM H_CONTACTMETHODGRO A,H_LOCATIONGROUP B WHERE A.H_LOCATION_GROUP_I = ? AND A.H_LOCATION_GROUP_I = B.H_LOCATION_GROUP_I AND (( ? BETWEEN A.H_CREATE_DT AND A.H_END_DT ) OR ( ? >= A.H_CREATE_DT AND A.H_END_DT IS NULL )) AND (( ? BETWEEN B.H_CREATE_DT AND B.H_END_DT ) OR ( ? >= B.H_CREATE_DT AND B.H_END_DT IS NULL ))",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"h_cont_method_grp_id", "h_action_code", "h_created_by", "h_create_dt", "h_end_dt", "location_group_id", "contact_method_id", "cont_meth_tp_cd", "method_st_tp_cd", "attach_allow_ind", "text_only_ind", "message_size", "comment_desc", "last_update_dt", "last_update_user", "last_update_tx_id", "h_location_group_i", "h_action_code", "h_created_by", "h_create_dt", "h_end_dt", "location_group_id", "undel_reason_tp_cd", "cont_id", "member_ind", "preferred_ind", "solicit_ind", "loc_group_tp_code", "effect_start_mmdd", "effect_end_mmdd", "effect_start_tm", "effect_end_tm", "start_dt", "end_dt", "last_update_dt", "last_update_user", "last_update_tx_id", "last_used_dt", "last_verified_dt", "source_ident_tp_cd", "xverified_tp_cd", "xretailer_id", "xmodify_sys_dt", "xcontact_retailer_flag", "x_bpid"},
    new GetPartyContactMethodHistoryByIDParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP}, {19, 0, 0, 0, 0}, {0, 0, 0, 0, 0}, {1, 1, 1, 1, 1}},
    null,
    new GetPartyContactMethodHistoryByIDRowHandler (),
    new int[][]{ {Types.BIGINT, Types.CHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.CHAR, Types.CHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.CHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR}, {19, 1, 20, 0, 0, 19, 19, 19, 19, 1, 1, 20, 100, 0, 20, 19, 19, 1, 20, 0, 0, 19, 19, 19, 0, 0, 0, 0, 10, 10, 10, 10, 0, 0, 0, 20, 19, 0, 0, 19, 19, 19, 0, 5, 50}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    9);

  /**
   * @generated
   */
  public static class GetPartyContactMethodHistoryByIDParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
      setObject (stmt, 4, Types.TIMESTAMP, parameters[3], 0);
      setObject (stmt, 5, Types.TIMESTAMP, parameters[4], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetPartyContactMethodHistoryByIDRowHandler extends BaseRowHandler<ResultQueue3<EObjContactMethodGroup,EObjLocationGroup,EObjXContactMethodGroupExt>>
  {
    /**
     * @generated
     */
    public ResultQueue3<EObjContactMethodGroup,EObjLocationGroup,EObjXContactMethodGroupExt> handle (java.sql.ResultSet rs, ResultQueue3<EObjContactMethodGroup,EObjLocationGroup,EObjXContactMethodGroupExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue3<EObjContactMethodGroup,EObjLocationGroup,EObjXContactMethodGroupExt> ();

      EObjContactMethodGroup returnObject1 = new EObjContactMethodGroup ();
      returnObject1.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject1.setHistActionCode(getString (rs, 2)); 
      returnObject1.setHistCreatedBy(getString (rs, 3)); 
      returnObject1.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject1.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject1.setLocationGroupIdPK(getLongObject (rs, 6)); 
      returnObject1.setContactMethodId(getLongObject (rs, 7)); 
      returnObject1.setContMethTpCd(getLongObject (rs, 8)); 
      returnObject1.setMethodStTpCd(getLongObject (rs, 9)); 
      returnObject1.setAttachAllowInd(getString (rs, 10)); 
      returnObject1.setTextOnlyInd(getString (rs, 11)); 
      returnObject1.setMessageSize(getString (rs, 12)); 
      returnObject1.setCommentDesc(getString (rs, 13)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 14)); 
      returnObject1.setLastUpdateUser(getString (rs, 15)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 16)); 
      returnObject.add (returnObject1);

      EObjLocationGroup returnObject2 = new EObjLocationGroup ();
      returnObject2.setHistoryIdPK(getLongObject (rs, 17)); 
      returnObject2.setHistActionCode(getString (rs, 18)); 
      returnObject2.setHistCreatedBy(getString (rs, 19)); 
      returnObject2.setHistCreateDt(getTimestamp (rs, 20)); 
      returnObject2.setHistEndDt(getTimestamp (rs, 21)); 
      returnObject2.setLocationGroupIdPK(getLongObject (rs, 22)); 
      returnObject2.setUndelReasonTpCd(getLongObject (rs, 23)); 
      returnObject2.setContId(getLongObject (rs, 24)); 
      returnObject2.setMemberInd(getString (rs, 25)); 
      returnObject2.setPreferredInd(getString (rs, 26)); 
      returnObject2.setSolicitInd(getString (rs, 27)); 
      returnObject2.setLocGroupTpCode(getString (rs, 28)); 
      returnObject2.setEffectStartMMDD(getIntObject (rs, 29)); 
      returnObject2.setEffectEndMMDD(getIntObject (rs, 30)); 
      returnObject2.setEffectStartTm(getIntObject (rs, 31)); 
      returnObject2.setEffectEndTm(getIntObject (rs, 32)); 
      returnObject2.setStartDt(getTimestamp (rs, 33)); 
      returnObject2.setEndDt(getTimestamp (rs, 34)); 
      returnObject2.setLastUpdateDt(getTimestamp (rs, 35)); 
      returnObject2.setLastUpdateUser(getString (rs, 36)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 37)); 
      returnObject2.setLastUsedDt(getTimestamp (rs, 38)); 
      returnObject2.setLastVerifiedDt(getTimestamp (rs, 39)); 
      returnObject2.setSourceIdentTpCd(getLongObject (rs, 40)); 
      returnObject.add (returnObject2);

      EObjXContactMethodGroupExt returnObject3 = new EObjXContactMethodGroupExt ();
      returnObject3.setHistActionCode(getString (rs, 2)); 
      returnObject3.setHistCreatedBy(getString (rs, 3)); 
      returnObject3.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject3.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject3.setLastUpdateDt(getTimestamp (rs, 14)); 
      returnObject3.setLastUpdateUser(getString (rs, 15)); 
      returnObject3.setLastUpdateTxId(getLongObject (rs, 16)); 
      returnObject3.setXVerified(getLongObject (rs, 41)); 
      returnObject3.setXRetailerId(getLongObject (rs, 42)); 
      returnObject3.setXLastModifiedSystemDate(getTimestamp (rs, 43)); 
      returnObject3.setXContactRetailerFlag(getString (rs, 44)); 
      returnObject3.setX_BPID(getString (rs, 45)); 
      returnObject.add (returnObject3);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT CONTACTMETHODGROUP.LOCATION_GROUP_ID, CONTACTMETHODGROUP.CONTACT_METHOD_ID, CONTACTMETHODGROUP.CONT_METH_TP_CD, CONTACTMETHODGROUP.METHOD_ST_TP_CD, CONTACTMETHODGROUP.ATTACH_ALLOW_IND, CONTACTMETHODGROUP.TEXT_ONLY_IND, CONTACTMETHODGROUP.MESSAGE_SIZE, CONTACTMETHODGROUP.COMMENT_DESC, CONTACTMETHODGROUP.LAST_UPDATE_DT, CONTACTMETHODGROUP.LAST_UPDATE_USER, CONTACTMETHODGROUP.LAST_UPDATE_TX_ID, LOCATIONGROUP.LOCATION_GROUP_ID, LOCATIONGROUP.UNDEL_REASON_TP_CD, LOCATIONGROUP.CONT_ID, LOCATIONGROUP.MEMBER_IND, LOCATIONGROUP.PREFERRED_IND, LOCATIONGROUP.SOLICIT_IND, LOCATIONGROUP.LOC_GROUP_TP_CODE, LOCATIONGROUP.EFFECT_START_MMDD, LOCATIONGROUP.EFFECT_END_MMDD, LOCATIONGROUP.EFFECT_START_TM, LOCATIONGROUP.EFFECT_END_TM, LOCATIONGROUP.START_DT, LOCATIONGROUP.END_DT, LOCATIONGROUP.LAST_UPDATE_DT, LOCATIONGROUP.LAST_UPDATE_USER, LOCATIONGROUP.LAST_UPDATE_TX_ID, LOCATIONGROUP.LAST_USED_DT, LOCATIONGROUP.LAST_VERIFIED_DT, LOCATIONGROUP.SOURCE_IDENT_TP_CD, CONTACTMETHODGROUP.XVERIFIED_TP_CD, CONTACTMETHODGROUP.XRETAILER_ID, CONTACTMETHODGROUP.XMODIFY_SYS_DT, CONTACTMETHODGROUP.XCONTACT_RETAILER_FLAG, CONTACTMETHODGROUP.X_BPID FROM CONTACTMETHODGROUP,LOCATIONGROUP WHERE CONTACTMETHODGROUP.LOCATION_GROUP_ID = LOCATIONGROUP.LOCATION_GROUP_ID AND LOCATIONGROUP.CONT_ID = ? AND CONTACTMETHODGROUP.CONT_METH_TP_CD = ? AND ((LOCATIONGROUP.END_DT IS NULL) OR (LOCATIONGROUP.END_DT > ? )) UNION ALL SELECT CONTACTMETHODGROUP.LOCATION_GROUP_ID, CONTACTMETHODGROUP.CONTACT_METHOD_ID, CONTACTMETHODGROUP.CONT_METH_TP_CD, CONTACTMETHODGROUP.METHOD_ST_TP_CD, CONTACTMETHODGROUP.ATTACH_ALLOW_IND, CONTACTMETHODGROUP.TEXT_ONLY_IND, CONTACTMETHODGROUP.MESSAGE_SIZE, CONTACTMETHODGROUP.COMMENT_DESC, CONTACTMETHODGROUP.LAST_UPDATE_DT, CONTACTMETHODGROUP.LAST_UPDATE_USER,CONTACTMETHODGROUP.LAST_UPDATE_TX_ID, LOCATIONGROUP.LOCATION_GROUP_ID, LOCATIONGROUP.UNDEL_REASON_TP_CD, LOCATIONGROUP.CONT_ID, LOCATIONGROUP.MEMBER_IND, LOCATIONGROUP.PREFERRED_IND, LOCATIONGROUP.SOLICIT_IND, LOCATIONGROUP.LOC_GROUP_TP_CODE, LOCATIONGROUP.EFFECT_START_MMDD, LOCATIONGROUP.EFFECT_END_MMDD, LOCATIONGROUP.EFFECT_START_TM, LOCATIONGROUP.EFFECT_END_TM, LOCATIONGROUP.START_DT, LOCATIONGROUP.END_DT, LOCATIONGROUP.LAST_UPDATE_DT, LOCATIONGROUP.LAST_UPDATE_USER, LOCATIONGROUP.LAST_UPDATE_TX_ID, LOCATIONGROUP.LAST_USED_DT, LOCATIONGROUP.LAST_VERIFIED_DT, LOCATIONGROUP.SOURCE_IDENT_TP_CD, CONTACTMETHODGROUP.XVERIFIED_TP_CD, CONTACTMETHODGROUP.XRETAILER_ID, CONTACTMETHODGROUP.XMODIFY_SYS_DT, CONTACTMETHODGROUP.XCONTACT_RETAILER_FLAG, CONTACTMETHODGROUP.X_BPID FROM CONTACTMETHODGROUP, LOCATIONGROUP WHERE CONTACTMETHODGROUP.LOCATION_GROUP_ID = LOCATIONGROUP.LOCATION_GROUP_ID AND LOCATIONGROUP.CONT_ID = ? AND CONTACTMETHODGROUP.CONT_METH_TP_CD = ? AND ((LOCATIONGROUP.END_DT IS NULL) OR (LOCATIONGROUP.END_DT > ?))", pattern="<rsm><col number='1' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup' property='locationGroupIdPK'></col><col number='2' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup' property='contactMethodId'></col><col number='3' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup' property='contMethTpCd'></col><col number='4' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup' property='methodStTpCd'></col><col number='5' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup' property='attachAllowInd'></col><col number='6' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup' property='textOnlyInd'></col><col number='7' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup' property='messageSize'></col><col number='8' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup' property='commentDesc'></col><col number='9' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup' property='lastUpdateDt'></col><col number='10' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup' property='lastUpdateUser'></col><col number='11' bean='com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup' property='lastUpdateTxId'></col><col number='12' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='locationGroupIdPK'></col><col number='13' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='undelReasonTpCd'></col><col number='14' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='contId'></col><col number='15' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='memberInd'></col><col number='16' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='preferredInd'></col><col number='17' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='solicitInd'></col><col number='18' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='locGroupTpCode'></col><col number='19' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='effectStartMMDD'></col><col number='20' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='effectEndMMDD'></col><col number='21' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='effectStartTm'></col><col number='22' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='effectEndTm'></col><col number='23' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='startDt'></col><col number='24' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='endDt'></col><col number='25' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='lastUpdateDt'></col><col number='26' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='lastUpdateUser'></col><col number='27' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='lastUpdateTxId'></col><col number='28' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='lastUsedDt'></col><col number='29' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='lastVerifiedDt'></col><col number='30' bean='com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup' property='sourceIdentTpCd'></col><col number='31' bean='com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt' property='XVerified'></col><col number='32' bean='com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt' property='XRetailerId'></col><col number='33' bean='com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt' property='XLastModifiedSystemDate'></col><col number='34' bean='com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt' property='XContactRetailerFlag'></col><col number='35' bean='com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt' property='X_BPID'></col></rsm>" )
   * 
   * @generated
   */
  public Iterator<ResultQueue3<EObjContactMethodGroup,EObjLocationGroup,EObjXContactMethodGroupExt>> getPartyContactMethod (Object[] parameters)
  {
    return queryIterator (getPartyContactMethodStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getPartyContactMethodStatementDescriptor = createStatementDescriptor (
    "getPartyContactMethod(Object[])",
    "SELECT CONTACTMETHODGROUP.LOCATION_GROUP_ID, CONTACTMETHODGROUP.CONTACT_METHOD_ID, CONTACTMETHODGROUP.CONT_METH_TP_CD, CONTACTMETHODGROUP.METHOD_ST_TP_CD, CONTACTMETHODGROUP.ATTACH_ALLOW_IND, CONTACTMETHODGROUP.TEXT_ONLY_IND, CONTACTMETHODGROUP.MESSAGE_SIZE, CONTACTMETHODGROUP.COMMENT_DESC, CONTACTMETHODGROUP.LAST_UPDATE_DT, CONTACTMETHODGROUP.LAST_UPDATE_USER, CONTACTMETHODGROUP.LAST_UPDATE_TX_ID, LOCATIONGROUP.LOCATION_GROUP_ID, LOCATIONGROUP.UNDEL_REASON_TP_CD, LOCATIONGROUP.CONT_ID, LOCATIONGROUP.MEMBER_IND, LOCATIONGROUP.PREFERRED_IND, LOCATIONGROUP.SOLICIT_IND, LOCATIONGROUP.LOC_GROUP_TP_CODE, LOCATIONGROUP.EFFECT_START_MMDD, LOCATIONGROUP.EFFECT_END_MMDD, LOCATIONGROUP.EFFECT_START_TM, LOCATIONGROUP.EFFECT_END_TM, LOCATIONGROUP.START_DT, LOCATIONGROUP.END_DT, LOCATIONGROUP.LAST_UPDATE_DT, LOCATIONGROUP.LAST_UPDATE_USER, LOCATIONGROUP.LAST_UPDATE_TX_ID, LOCATIONGROUP.LAST_USED_DT, LOCATIONGROUP.LAST_VERIFIED_DT, LOCATIONGROUP.SOURCE_IDENT_TP_CD, CONTACTMETHODGROUP.XVERIFIED_TP_CD, CONTACTMETHODGROUP.XRETAILER_ID, CONTACTMETHODGROUP.XMODIFY_SYS_DT, CONTACTMETHODGROUP.XCONTACT_RETAILER_FLAG, CONTACTMETHODGROUP.X_BPID FROM CONTACTMETHODGROUP,LOCATIONGROUP WHERE CONTACTMETHODGROUP.LOCATION_GROUP_ID = LOCATIONGROUP.LOCATION_GROUP_ID AND LOCATIONGROUP.CONT_ID = ? AND CONTACTMETHODGROUP.CONT_METH_TP_CD = ? AND ((LOCATIONGROUP.END_DT IS NULL) OR (LOCATIONGROUP.END_DT > ? )) UNION ALL SELECT CONTACTMETHODGROUP.LOCATION_GROUP_ID, CONTACTMETHODGROUP.CONTACT_METHOD_ID, CONTACTMETHODGROUP.CONT_METH_TP_CD, CONTACTMETHODGROUP.METHOD_ST_TP_CD, CONTACTMETHODGROUP.ATTACH_ALLOW_IND, CONTACTMETHODGROUP.TEXT_ONLY_IND, CONTACTMETHODGROUP.MESSAGE_SIZE, CONTACTMETHODGROUP.COMMENT_DESC, CONTACTMETHODGROUP.LAST_UPDATE_DT, CONTACTMETHODGROUP.LAST_UPDATE_USER,CONTACTMETHODGROUP.LAST_UPDATE_TX_ID, LOCATIONGROUP.LOCATION_GROUP_ID, LOCATIONGROUP.UNDEL_REASON_TP_CD, LOCATIONGROUP.CONT_ID, LOCATIONGROUP.MEMBER_IND, LOCATIONGROUP.PREFERRED_IND, LOCATIONGROUP.SOLICIT_IND, LOCATIONGROUP.LOC_GROUP_TP_CODE, LOCATIONGROUP.EFFECT_START_MMDD, LOCATIONGROUP.EFFECT_END_MMDD, LOCATIONGROUP.EFFECT_START_TM, LOCATIONGROUP.EFFECT_END_TM, LOCATIONGROUP.START_DT, LOCATIONGROUP.END_DT, LOCATIONGROUP.LAST_UPDATE_DT, LOCATIONGROUP.LAST_UPDATE_USER, LOCATIONGROUP.LAST_UPDATE_TX_ID, LOCATIONGROUP.LAST_USED_DT, LOCATIONGROUP.LAST_VERIFIED_DT, LOCATIONGROUP.SOURCE_IDENT_TP_CD, CONTACTMETHODGROUP.XVERIFIED_TP_CD, CONTACTMETHODGROUP.XRETAILER_ID, CONTACTMETHODGROUP.XMODIFY_SYS_DT, CONTACTMETHODGROUP.XCONTACT_RETAILER_FLAG, CONTACTMETHODGROUP.X_BPID FROM CONTACTMETHODGROUP, LOCATIONGROUP WHERE CONTACTMETHODGROUP.LOCATION_GROUP_ID = LOCATIONGROUP.LOCATION_GROUP_ID AND LOCATIONGROUP.CONT_ID = ? AND CONTACTMETHODGROUP.CONT_METH_TP_CD = ? AND ((LOCATIONGROUP.END_DT IS NULL) OR (LOCATIONGROUP.END_DT > ?))",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"location_group_id", "contact_method_id", "cont_meth_tp_cd", "method_st_tp_cd", "attach_allow_ind", "text_only_ind", "message_size", "comment_desc", "last_update_dt", "last_update_user", "last_update_tx_id", "location_group_id", "undel_reason_tp_cd", "cont_id", "member_ind", "preferred_ind", "solicit_ind", "loc_group_tp_code", "effect_start_mmdd", "effect_end_mmdd", "effect_start_tm", "effect_end_tm", "start_dt", "end_dt", "last_update_dt", "last_update_user", "last_update_tx_id", "last_used_dt", "last_verified_dt", "source_ident_tp_cd", "xverified_tp_cd", "xretailer_id", "xmodify_sys_dt", "xcontact_retailer_flag", "x_bpid"},
    new GetPartyContactMethodParameterHandler (),
    new int[][]{{Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP}, {19, 19, 0, 19, 19, 0}, {0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1}},
    null,
    new GetPartyContactMethodRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.CHAR, Types.CHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR}, {19, 19, 19, 19, 1, 1, 20, 100, 0, 20, 19, 19, 19, 19, 0, 0, 0, 0, 10, 10, 10, 10, 0, 0, 0, 20, 19, 0, 0, 19, 19, 19, 0, 5, 50}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    10);

  /**
   * @generated
   */
  public static class GetPartyContactMethodParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.BIGINT, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
      setObject (stmt, 4, Types.BIGINT, parameters[3], 0);
      setObject (stmt, 5, Types.BIGINT, parameters[4], 0);
      setObject (stmt, 6, Types.TIMESTAMP, parameters[5], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetPartyContactMethodRowHandler extends BaseRowHandler<ResultQueue3<EObjContactMethodGroup,EObjLocationGroup,EObjXContactMethodGroupExt>>
  {
    /**
     * @generated
     */
    public ResultQueue3<EObjContactMethodGroup,EObjLocationGroup,EObjXContactMethodGroupExt> handle (java.sql.ResultSet rs, ResultQueue3<EObjContactMethodGroup,EObjLocationGroup,EObjXContactMethodGroupExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue3<EObjContactMethodGroup,EObjLocationGroup,EObjXContactMethodGroupExt> ();

      EObjContactMethodGroup returnObject1 = new EObjContactMethodGroup ();
      returnObject1.setLocationGroupIdPK(getLongObject (rs, 1)); 
      returnObject1.setContactMethodId(getLongObject (rs, 2)); 
      returnObject1.setContMethTpCd(getLongObject (rs, 3)); 
      returnObject1.setMethodStTpCd(getLongObject (rs, 4)); 
      returnObject1.setAttachAllowInd(getString (rs, 5)); 
      returnObject1.setTextOnlyInd(getString (rs, 6)); 
      returnObject1.setMessageSize(getString (rs, 7)); 
      returnObject1.setCommentDesc(getString (rs, 8)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 9)); 
      returnObject1.setLastUpdateUser(getString (rs, 10)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 11)); 
      returnObject.add (returnObject1);

      EObjLocationGroup returnObject2 = new EObjLocationGroup ();
      returnObject2.setLocationGroupIdPK(getLongObject (rs, 12)); 
      returnObject2.setUndelReasonTpCd(getLongObject (rs, 13)); 
      returnObject2.setContId(getLongObject (rs, 14)); 
      returnObject2.setMemberInd(getString (rs, 15)); 
      returnObject2.setPreferredInd(getString (rs, 16)); 
      returnObject2.setSolicitInd(getString (rs, 17)); 
      returnObject2.setLocGroupTpCode(getString (rs, 18)); 
      returnObject2.setEffectStartMMDD(getIntObject (rs, 19)); 
      returnObject2.setEffectEndMMDD(getIntObject (rs, 20)); 
      returnObject2.setEffectStartTm(getIntObject (rs, 21)); 
      returnObject2.setEffectEndTm(getIntObject (rs, 22)); 
      returnObject2.setStartDt(getTimestamp (rs, 23)); 
      returnObject2.setEndDt(getTimestamp (rs, 24)); 
      returnObject2.setLastUpdateDt(getTimestamp (rs, 25)); 
      returnObject2.setLastUpdateUser(getString (rs, 26)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 27)); 
      returnObject2.setLastUsedDt(getTimestamp (rs, 28)); 
      returnObject2.setLastVerifiedDt(getTimestamp (rs, 29)); 
      returnObject2.setSourceIdentTpCd(getLongObject (rs, 30)); 
      returnObject.add (returnObject2);

      EObjXContactMethodGroupExt returnObject3 = new EObjXContactMethodGroupExt ();
      returnObject3.setXVerified(getLongObject (rs, 31)); 
      returnObject3.setXRetailerId(getLongObject (rs, 32)); 
      returnObject3.setXLastModifiedSystemDate(getTimestamp (rs, 33)); 
      returnObject3.setXContactRetailerFlag(getString (rs, 34)); 
      returnObject3.setX_BPID(getString (rs, 35)); 
      returnObject.add (returnObject3);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT CONTACTMETHODGROUP.LOCATION_GROUP_ID, CONTACTMETHODGROUP.CONTACT_METHOD_ID, CONTACTMETHODGROUP.CONT_METH_TP_CD, CONTACTMETHODGROUP.METHOD_ST_TP_CD, CONTACTMETHODGROUP.ATTACH_ALLOW_IND, CONTACTMETHODGROUP.TEXT_ONLY_IND, CONTACTMETHODGROUP.MESSAGE_SIZE, CONTACTMETHODGROUP.COMMENT_DESC, CONTACTMETHODGROUP.LAST_UPDATE_DT, CONTACTMETHODGROUP.LAST_UPDATE_USER, CONTACTMETHODGROUP.LAST_UPDATE_TX_ID, LOCATIONGROUP.LOCATION_GROUP_ID, LOCATIONGROUP.UNDEL_REASON_TP_CD, LOCATIONGROUP.CONT_ID, LOCATIONGROUP.MEMBER_IND, LOCATIONGROUP.PREFERRED_IND, LOCATIONGROUP.SOLICIT_IND, LOCATIONGROUP.LOC_GROUP_TP_CODE, LOCATIONGROUP.EFFECT_START_MMDD, LOCATIONGROUP.EFFECT_END_MMDD, LOCATIONGROUP.EFFECT_START_TM, LOCATIONGROUP.EFFECT_END_TM, LOCATIONGROUP.START_DT, LOCATIONGROUP.END_DT, LOCATIONGROUP.LAST_UPDATE_DT, LOCATIONGROUP.LAST_UPDATE_USER, LOCATIONGROUP.LAST_UPDATE_TX_ID, CONTACTMETHODGROUP.XVERIFIED_TP_CD, CONTACTMETHODGROUP.XRETAILER_ID, CONTACTMETHODGROUP.XMODIFY_SYS_DT, CONTACTMETHODGROUP.XCONTACT_RETAILER_FLAG, CONTACTMETHODGROUP.X_BPID FROM CONTACT, LOCATIONGROUP, CONTACTMETHODGROUP, CONTACTMETHOD WHERE CONTACT.CONT_ID = LOCATIONGROUP.CONT_ID AND LOCATIONGROUP.LOCATION_GROUP_ID=CONTACTMETHODGROUP.LOCATION_GROUP_ID AND CONTACTMETHODGROUP.CONTACT_METHOD_ID = CONTACTMETHOD.CONTACT_METHOD_ID AND CONTACTMETHOD.CONTACT_METHOD_ID = ?", pattern="tableAlias (CONTACTMETHODGROUP => com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup, H_CONTACTMETHODGRO => com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup, LOCATIONGROUP => com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup, H_LOCATIONGROUP => com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup , CONTACTMETHODGROUP => com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt , H_CONTACTMETHODGRO => com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue3<EObjContactMethodGroup,EObjLocationGroup,EObjXContactMethodGroupExt>> getAllPartyContactMethodByContMethodID (Object[] parameters)
  {
    return queryIterator (getAllPartyContactMethodByContMethodIDStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getAllPartyContactMethodByContMethodIDStatementDescriptor = createStatementDescriptor (
    "getAllPartyContactMethodByContMethodID(Object[])",
    "SELECT CONTACTMETHODGROUP.LOCATION_GROUP_ID, CONTACTMETHODGROUP.CONTACT_METHOD_ID, CONTACTMETHODGROUP.CONT_METH_TP_CD, CONTACTMETHODGROUP.METHOD_ST_TP_CD, CONTACTMETHODGROUP.ATTACH_ALLOW_IND, CONTACTMETHODGROUP.TEXT_ONLY_IND, CONTACTMETHODGROUP.MESSAGE_SIZE, CONTACTMETHODGROUP.COMMENT_DESC, CONTACTMETHODGROUP.LAST_UPDATE_DT, CONTACTMETHODGROUP.LAST_UPDATE_USER, CONTACTMETHODGROUP.LAST_UPDATE_TX_ID, LOCATIONGROUP.LOCATION_GROUP_ID, LOCATIONGROUP.UNDEL_REASON_TP_CD, LOCATIONGROUP.CONT_ID, LOCATIONGROUP.MEMBER_IND, LOCATIONGROUP.PREFERRED_IND, LOCATIONGROUP.SOLICIT_IND, LOCATIONGROUP.LOC_GROUP_TP_CODE, LOCATIONGROUP.EFFECT_START_MMDD, LOCATIONGROUP.EFFECT_END_MMDD, LOCATIONGROUP.EFFECT_START_TM, LOCATIONGROUP.EFFECT_END_TM, LOCATIONGROUP.START_DT, LOCATIONGROUP.END_DT, LOCATIONGROUP.LAST_UPDATE_DT, LOCATIONGROUP.LAST_UPDATE_USER, LOCATIONGROUP.LAST_UPDATE_TX_ID, CONTACTMETHODGROUP.XVERIFIED_TP_CD, CONTACTMETHODGROUP.XRETAILER_ID, CONTACTMETHODGROUP.XMODIFY_SYS_DT, CONTACTMETHODGROUP.XCONTACT_RETAILER_FLAG, CONTACTMETHODGROUP.X_BPID FROM CONTACT, LOCATIONGROUP, CONTACTMETHODGROUP, CONTACTMETHOD WHERE CONTACT.CONT_ID = LOCATIONGROUP.CONT_ID AND LOCATIONGROUP.LOCATION_GROUP_ID=CONTACTMETHODGROUP.LOCATION_GROUP_ID AND CONTACTMETHODGROUP.CONTACT_METHOD_ID = CONTACTMETHOD.CONTACT_METHOD_ID AND CONTACTMETHOD.CONTACT_METHOD_ID = ?",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"location_group_id", "contact_method_id", "cont_meth_tp_cd", "method_st_tp_cd", "attach_allow_ind", "text_only_ind", "message_size", "comment_desc", "last_update_dt", "last_update_user", "last_update_tx_id", "location_group_id", "undel_reason_tp_cd", "cont_id", "member_ind", "preferred_ind", "solicit_ind", "loc_group_tp_code", "effect_start_mmdd", "effect_end_mmdd", "effect_start_tm", "effect_end_tm", "start_dt", "end_dt", "last_update_dt", "last_update_user", "last_update_tx_id", "xverified_tp_cd", "xretailer_id", "xmodify_sys_dt", "xcontact_retailer_flag", "x_bpid"},
    new GetAllPartyContactMethodByContMethodIDParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetAllPartyContactMethodByContMethodIDRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.CHAR, Types.CHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR}, {19, 19, 19, 19, 1, 1, 20, 100, 0, 20, 19, 19, 19, 19, 0, 0, 0, 0, 10, 10, 10, 10, 0, 0, 0, 20, 19, 19, 19, 0, 5, 50}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    11);

  /**
   * @generated
   */
  public static class GetAllPartyContactMethodByContMethodIDParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetAllPartyContactMethodByContMethodIDRowHandler extends BaseRowHandler<ResultQueue3<EObjContactMethodGroup,EObjLocationGroup,EObjXContactMethodGroupExt>>
  {
    /**
     * @generated
     */
    public ResultQueue3<EObjContactMethodGroup,EObjLocationGroup,EObjXContactMethodGroupExt> handle (java.sql.ResultSet rs, ResultQueue3<EObjContactMethodGroup,EObjLocationGroup,EObjXContactMethodGroupExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue3<EObjContactMethodGroup,EObjLocationGroup,EObjXContactMethodGroupExt> ();

      EObjContactMethodGroup returnObject1 = new EObjContactMethodGroup ();
      returnObject1.setLocationGroupIdPK(getLongObject (rs, 1)); 
      returnObject1.setContactMethodId(getLongObject (rs, 2)); 
      returnObject1.setContMethTpCd(getLongObject (rs, 3)); 
      returnObject1.setMethodStTpCd(getLongObject (rs, 4)); 
      returnObject1.setAttachAllowInd(getString (rs, 5)); 
      returnObject1.setTextOnlyInd(getString (rs, 6)); 
      returnObject1.setMessageSize(getString (rs, 7)); 
      returnObject1.setCommentDesc(getString (rs, 8)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 9)); 
      returnObject1.setLastUpdateUser(getString (rs, 10)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 11)); 
      returnObject.add (returnObject1);

      EObjLocationGroup returnObject2 = new EObjLocationGroup ();
      returnObject2.setLocationGroupIdPK(getLongObject (rs, 12)); 
      returnObject2.setUndelReasonTpCd(getLongObject (rs, 13)); 
      returnObject2.setContId(getLongObject (rs, 14)); 
      returnObject2.setMemberInd(getString (rs, 15)); 
      returnObject2.setPreferredInd(getString (rs, 16)); 
      returnObject2.setSolicitInd(getString (rs, 17)); 
      returnObject2.setLocGroupTpCode(getString (rs, 18)); 
      returnObject2.setEffectStartMMDD(getIntObject (rs, 19)); 
      returnObject2.setEffectEndMMDD(getIntObject (rs, 20)); 
      returnObject2.setEffectStartTm(getIntObject (rs, 21)); 
      returnObject2.setEffectEndTm(getIntObject (rs, 22)); 
      returnObject2.setStartDt(getTimestamp (rs, 23)); 
      returnObject2.setEndDt(getTimestamp (rs, 24)); 
      returnObject2.setLastUpdateDt(getTimestamp (rs, 25)); 
      returnObject2.setLastUpdateUser(getString (rs, 26)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 27)); 
      returnObject.add (returnObject2);

      EObjXContactMethodGroupExt returnObject3 = new EObjXContactMethodGroupExt ();
      returnObject3.setLastUpdateDt(getTimestamp (rs, 9)); 
      returnObject3.setLastUpdateUser(getString (rs, 10)); 
      returnObject3.setLastUpdateTxId(getLongObject (rs, 11)); 
      returnObject3.setXVerified(getLongObject (rs, 28)); 
      returnObject3.setXRetailerId(getLongObject (rs, 29)); 
      returnObject3.setXLastModifiedSystemDate(getTimestamp (rs, 30)); 
      returnObject3.setXContactRetailerFlag(getString (rs, 31)); 
      returnObject3.setX_BPID(getString (rs, 32)); 
      returnObject.add (returnObject3);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT CONTACTMETHODGROUP.LOCATION_GROUP_ID, CONTACTMETHODGROUP.CONTACT_METHOD_ID, CONTACTMETHODGROUP.CONT_METH_TP_CD, CONTACTMETHODGROUP.METHOD_ST_TP_CD, CONTACTMETHODGROUP.ATTACH_ALLOW_IND, CONTACTMETHODGROUP.TEXT_ONLY_IND, CONTACTMETHODGROUP.MESSAGE_SIZE, CONTACTMETHODGROUP.COMMENT_DESC, CONTACTMETHODGROUP.LAST_UPDATE_DT, CONTACTMETHODGROUP.LAST_UPDATE_USER,CONTACTMETHODGROUP.LAST_UPDATE_TX_ID, LOCATIONGROUP.LOCATION_GROUP_ID, LOCATIONGROUP.UNDEL_REASON_TP_CD, LOCATIONGROUP.CONT_ID, LOCATIONGROUP.MEMBER_IND, LOCATIONGROUP.PREFERRED_IND, LOCATIONGROUP.SOLICIT_IND, LOCATIONGROUP.LOC_GROUP_TP_CODE, LOCATIONGROUP.EFFECT_START_MMDD, LOCATIONGROUP.EFFECT_END_MMDD, LOCATIONGROUP.EFFECT_START_TM, LOCATIONGROUP.EFFECT_END_TM, LOCATIONGROUP.START_DT, LOCATIONGROUP.END_DT, LOCATIONGROUP.LAST_UPDATE_DT, LOCATIONGROUP.LAST_UPDATE_USER, LOCATIONGROUP.LAST_UPDATE_TX_ID, CONTACTMETHODGROUP.XVERIFIED_TP_CD, CONTACTMETHODGROUP.XRETAILER_ID, CONTACTMETHODGROUP.XMODIFY_SYS_DT, CONTACTMETHODGROUP.XCONTACT_RETAILER_FLAG, CONTACTMETHODGROUP.X_BPID FROM CONTACT, LOCATIONGROUP, CONTACTMETHODGROUP, CONTACTMETHOD WHERE CONTACT.CONT_ID = LOCATIONGROUP.CONT_ID AND LOCATIONGROUP.LOCATION_GROUP_ID=CONTACTMETHODGROUP.LOCATION_GROUP_ID AND CONTACTMETHODGROUP.CONTACT_METHOD_ID = CONTACTMETHOD.CONTACT_METHOD_ID AND CONTACTMETHOD.ADDRESS_ID = ?", pattern="tableAlias (CONTACTMETHODGROUP => com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup, H_CONTACTMETHODGRO => com.dwl.tcrm.coreParty.entityObject.EObjContactMethodGroup, LOCATIONGROUP => com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup, H_LOCATIONGROUP => com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup , CONTACTMETHODGROUP => com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt , H_CONTACTMETHODGRO => com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue3<EObjContactMethodGroup,EObjLocationGroup,EObjXContactMethodGroupExt>> getAllPartyContactMethodByAddressdID (Object[] parameters)
  {
    return queryIterator (getAllPartyContactMethodByAddressdIDStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getAllPartyContactMethodByAddressdIDStatementDescriptor = createStatementDescriptor (
    "getAllPartyContactMethodByAddressdID(Object[])",
    "SELECT CONTACTMETHODGROUP.LOCATION_GROUP_ID, CONTACTMETHODGROUP.CONTACT_METHOD_ID, CONTACTMETHODGROUP.CONT_METH_TP_CD, CONTACTMETHODGROUP.METHOD_ST_TP_CD, CONTACTMETHODGROUP.ATTACH_ALLOW_IND, CONTACTMETHODGROUP.TEXT_ONLY_IND, CONTACTMETHODGROUP.MESSAGE_SIZE, CONTACTMETHODGROUP.COMMENT_DESC, CONTACTMETHODGROUP.LAST_UPDATE_DT, CONTACTMETHODGROUP.LAST_UPDATE_USER,CONTACTMETHODGROUP.LAST_UPDATE_TX_ID, LOCATIONGROUP.LOCATION_GROUP_ID, LOCATIONGROUP.UNDEL_REASON_TP_CD, LOCATIONGROUP.CONT_ID, LOCATIONGROUP.MEMBER_IND, LOCATIONGROUP.PREFERRED_IND, LOCATIONGROUP.SOLICIT_IND, LOCATIONGROUP.LOC_GROUP_TP_CODE, LOCATIONGROUP.EFFECT_START_MMDD, LOCATIONGROUP.EFFECT_END_MMDD, LOCATIONGROUP.EFFECT_START_TM, LOCATIONGROUP.EFFECT_END_TM, LOCATIONGROUP.START_DT, LOCATIONGROUP.END_DT, LOCATIONGROUP.LAST_UPDATE_DT, LOCATIONGROUP.LAST_UPDATE_USER, LOCATIONGROUP.LAST_UPDATE_TX_ID, CONTACTMETHODGROUP.XVERIFIED_TP_CD, CONTACTMETHODGROUP.XRETAILER_ID, CONTACTMETHODGROUP.XMODIFY_SYS_DT, CONTACTMETHODGROUP.XCONTACT_RETAILER_FLAG, CONTACTMETHODGROUP.X_BPID FROM CONTACT, LOCATIONGROUP, CONTACTMETHODGROUP, CONTACTMETHOD WHERE CONTACT.CONT_ID = LOCATIONGROUP.CONT_ID AND LOCATIONGROUP.LOCATION_GROUP_ID=CONTACTMETHODGROUP.LOCATION_GROUP_ID AND CONTACTMETHODGROUP.CONTACT_METHOD_ID = CONTACTMETHOD.CONTACT_METHOD_ID AND CONTACTMETHOD.ADDRESS_ID = ?",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"location_group_id", "contact_method_id", "cont_meth_tp_cd", "method_st_tp_cd", "attach_allow_ind", "text_only_ind", "message_size", "comment_desc", "last_update_dt", "last_update_user", "last_update_tx_id", "location_group_id", "undel_reason_tp_cd", "cont_id", "member_ind", "preferred_ind", "solicit_ind", "loc_group_tp_code", "effect_start_mmdd", "effect_end_mmdd", "effect_start_tm", "effect_end_tm", "start_dt", "end_dt", "last_update_dt", "last_update_user", "last_update_tx_id", "xverified_tp_cd", "xretailer_id", "xmodify_sys_dt", "xcontact_retailer_flag", "x_bpid"},
    new GetAllPartyContactMethodByAddressdIDParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetAllPartyContactMethodByAddressdIDRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.CHAR, Types.CHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR}, {19, 19, 19, 19, 1, 1, 20, 100, 0, 20, 19, 19, 19, 19, 0, 0, 0, 0, 10, 10, 10, 10, 0, 0, 0, 20, 19, 19, 19, 0, 5, 50}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    12);

  /**
   * @generated
   */
  public static class GetAllPartyContactMethodByAddressdIDParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetAllPartyContactMethodByAddressdIDRowHandler extends BaseRowHandler<ResultQueue3<EObjContactMethodGroup,EObjLocationGroup,EObjXContactMethodGroupExt>>
  {
    /**
     * @generated
     */
    public ResultQueue3<EObjContactMethodGroup,EObjLocationGroup,EObjXContactMethodGroupExt> handle (java.sql.ResultSet rs, ResultQueue3<EObjContactMethodGroup,EObjLocationGroup,EObjXContactMethodGroupExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue3<EObjContactMethodGroup,EObjLocationGroup,EObjXContactMethodGroupExt> ();

      EObjContactMethodGroup returnObject1 = new EObjContactMethodGroup ();
      returnObject1.setLocationGroupIdPK(getLongObject (rs, 1)); 
      returnObject1.setContactMethodId(getLongObject (rs, 2)); 
      returnObject1.setContMethTpCd(getLongObject (rs, 3)); 
      returnObject1.setMethodStTpCd(getLongObject (rs, 4)); 
      returnObject1.setAttachAllowInd(getString (rs, 5)); 
      returnObject1.setTextOnlyInd(getString (rs, 6)); 
      returnObject1.setMessageSize(getString (rs, 7)); 
      returnObject1.setCommentDesc(getString (rs, 8)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 9)); 
      returnObject1.setLastUpdateUser(getString (rs, 10)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 11)); 
      returnObject.add (returnObject1);

      EObjLocationGroup returnObject2 = new EObjLocationGroup ();
      returnObject2.setLocationGroupIdPK(getLongObject (rs, 12)); 
      returnObject2.setUndelReasonTpCd(getLongObject (rs, 13)); 
      returnObject2.setContId(getLongObject (rs, 14)); 
      returnObject2.setMemberInd(getString (rs, 15)); 
      returnObject2.setPreferredInd(getString (rs, 16)); 
      returnObject2.setSolicitInd(getString (rs, 17)); 
      returnObject2.setLocGroupTpCode(getString (rs, 18)); 
      returnObject2.setEffectStartMMDD(getIntObject (rs, 19)); 
      returnObject2.setEffectEndMMDD(getIntObject (rs, 20)); 
      returnObject2.setEffectStartTm(getIntObject (rs, 21)); 
      returnObject2.setEffectEndTm(getIntObject (rs, 22)); 
      returnObject2.setStartDt(getTimestamp (rs, 23)); 
      returnObject2.setEndDt(getTimestamp (rs, 24)); 
      returnObject2.setLastUpdateDt(getTimestamp (rs, 25)); 
      returnObject2.setLastUpdateUser(getString (rs, 26)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 27)); 
      returnObject.add (returnObject2);

      EObjXContactMethodGroupExt returnObject3 = new EObjXContactMethodGroupExt ();
      returnObject3.setLastUpdateDt(getTimestamp (rs, 9)); 
      returnObject3.setLastUpdateUser(getString (rs, 10)); 
      returnObject3.setLastUpdateTxId(getLongObject (rs, 11)); 
      returnObject3.setXVerified(getLongObject (rs, 28)); 
      returnObject3.setXRetailerId(getLongObject (rs, 29)); 
      returnObject3.setXLastModifiedSystemDate(getTimestamp (rs, 30)); 
      returnObject3.setXContactRetailerFlag(getString (rs, 31)); 
      returnObject3.setX_BPID(getString (rs, 32)); 
      returnObject.add (returnObject3);

    
      return returnObject;
    }
  }

}
