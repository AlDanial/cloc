/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[41ff1bb2862a4ac18547d5a37eaf10e1]
 */


package com.ibm.daimler.dsea.entityObject;

import java.util.Iterator;
import com.ibm.mdm.base.db.EntityMapping;
import com.ibm.pdq.annotation.Select;
import com.ibm.pdq.annotation.Update;

import com.ibm.daimler.dsea.entityObject.EObjXGurantorIndividual;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * @generated
 */
public interface EObjXGurantorIndividualData {


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjXGurantorIndividualSql = "select XGurantor_Individualpk_Id, CONTRACT_DETAILS_ID, BPID, ABN_NUMBER, PREFIX_NAME_TP_CD, GIVEN_NAME_ONE, LAST_NAME, GIVEN_NAME_ONE_LOCAL, LAST_NAME_LOCAL, BIRTH_DT, ADDR_USAGE_TP_CD, ADDR_LINE_ONE, ADDR_LINE_TWO, ADDR_LINE_THREE, POSTAL_CODE, CITY_NAME, RESIDENCE_NUMBER, COUNTRY_TP_CD, BUILDING_NAME, STREET_NAME, STREET_NUMBER, MOBILE_NUMBER, HOME_PHONE_NUMBER, WORK_PHONE_NUMBER, WORK_PHONE_NUMBER_EXT, FAX, EMAIL, SOURCE_IDENT_TP_CD, START_DT, END_DT, MODIFY_SYS_DT, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from XGURANTORINDIVIDUAL where XGurantor_Individualpk_Id = ? ";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String createEObjXGurantorIndividualSql = "insert into XGURANTORINDIVIDUAL (XGurantor_Individualpk_Id, CONTRACT_DETAILS_ID, BPID, ABN_NUMBER, PREFIX_NAME_TP_CD, GIVEN_NAME_ONE, LAST_NAME, GIVEN_NAME_ONE_LOCAL, LAST_NAME_LOCAL, BIRTH_DT, ADDR_USAGE_TP_CD, ADDR_LINE_ONE, ADDR_LINE_TWO, ADDR_LINE_THREE, POSTAL_CODE, CITY_NAME, RESIDENCE_NUMBER, COUNTRY_TP_CD, BUILDING_NAME, STREET_NAME, STREET_NUMBER, MOBILE_NUMBER, HOME_PHONE_NUMBER, WORK_PHONE_NUMBER, WORK_PHONE_NUMBER_EXT, FAX, EMAIL, SOURCE_IDENT_TP_CD, START_DT, END_DT, MODIFY_SYS_DT, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( :xGurantorIndividualpkId, :contractDetailsId, :bPID, :aBNNumber, :title, :givenNameOne, :lastName, :givenNameOneLocal, :lastNameLocal, :birthDate, :addressUsage, :addressLineOne, :addressLineTwo, :addressLineThree, :postalCode, :cityName, :residenceNumber, :country, :buildingName, :streetName, :streetNumber, :mobileNumber, :homePhoneNumber, :workPhoneNumber, :workPhoneNumberExtension, :fax, :email, :sourceIdentifier, :startDate, :endDate, :lastModifiedSystemDate, :lastUpdateDt, :lastUpdateUser, :lastUpdateTxId)";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String updateEObjXGurantorIndividualSql = "update XGURANTORINDIVIDUAL set CONTRACT_DETAILS_ID = :contractDetailsId, BPID = :bPID, ABN_NUMBER = :aBNNumber, PREFIX_NAME_TP_CD = :title, GIVEN_NAME_ONE = :givenNameOne, LAST_NAME = :lastName, GIVEN_NAME_ONE_LOCAL = :givenNameOneLocal, LAST_NAME_LOCAL = :lastNameLocal, BIRTH_DT = :birthDate, ADDR_USAGE_TP_CD = :addressUsage, ADDR_LINE_ONE = :addressLineOne, ADDR_LINE_TWO = :addressLineTwo, ADDR_LINE_THREE = :addressLineThree, POSTAL_CODE = :postalCode, CITY_NAME = :cityName, RESIDENCE_NUMBER = :residenceNumber, COUNTRY_TP_CD = :country, BUILDING_NAME = :buildingName, STREET_NAME = :streetName, STREET_NUMBER = :streetNumber, MOBILE_NUMBER = :mobileNumber, HOME_PHONE_NUMBER = :homePhoneNumber, WORK_PHONE_NUMBER = :workPhoneNumber, WORK_PHONE_NUMBER_EXT = :workPhoneNumberExtension, FAX = :fax, EMAIL = :email, SOURCE_IDENT_TP_CD = :sourceIdentifier, START_DT = :startDate, END_DT = :endDate, MODIFY_SYS_DT = :lastModifiedSystemDate, LAST_UPDATE_DT = :lastUpdateDt, LAST_UPDATE_USER = :lastUpdateUser, LAST_UPDATE_TX_ID = :lastUpdateTxId where XGurantor_Individualpk_Id = :xGurantorIndividualpkId and LAST_UPDATE_DT = :oldLastUpdateDt";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String deleteEObjXGurantorIndividualSql = "delete from XGURANTORINDIVIDUAL where XGurantor_Individualpk_Id = ?";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXGurantorIndividualKeyField = "EObjXGurantorIndividual.xGurantorIndividualpkId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXGurantorIndividualGetFields =
    "EObjXGurantorIndividual.xGurantorIndividualpkId," +
    "EObjXGurantorIndividual.contractDetailsId," +
    "EObjXGurantorIndividual.bPID," +
    "EObjXGurantorIndividual.aBNNumber," +
    "EObjXGurantorIndividual.title," +
    "EObjXGurantorIndividual.givenNameOne," +
    "EObjXGurantorIndividual.lastName," +
    "EObjXGurantorIndividual.givenNameOneLocal," +
    "EObjXGurantorIndividual.lastNameLocal," +
    "EObjXGurantorIndividual.birthDate," +
    "EObjXGurantorIndividual.addressUsage," +
    "EObjXGurantorIndividual.addressLineOne," +
    "EObjXGurantorIndividual.addressLineTwo," +
    "EObjXGurantorIndividual.addressLineThree," +
    "EObjXGurantorIndividual.postalCode," +
    "EObjXGurantorIndividual.cityName," +
    "EObjXGurantorIndividual.residenceNumber," +
    "EObjXGurantorIndividual.country," +
    "EObjXGurantorIndividual.buildingName," +
    "EObjXGurantorIndividual.streetName," +
    "EObjXGurantorIndividual.streetNumber," +
    "EObjXGurantorIndividual.mobileNumber," +
    "EObjXGurantorIndividual.homePhoneNumber," +
    "EObjXGurantorIndividual.workPhoneNumber," +
    "EObjXGurantorIndividual.workPhoneNumberExtension," +
    "EObjXGurantorIndividual.fax," +
    "EObjXGurantorIndividual.email," +
    "EObjXGurantorIndividual.sourceIdentifier," +
    "EObjXGurantorIndividual.startDate," +
    "EObjXGurantorIndividual.endDate," +
    "EObjXGurantorIndividual.lastModifiedSystemDate," +
    "EObjXGurantorIndividual.lastUpdateDt," +
    "EObjXGurantorIndividual.lastUpdateUser," +
    "EObjXGurantorIndividual.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXGurantorIndividualAllFields =
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorIndividual.xGurantorIndividualpkId," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorIndividual.contractDetailsId," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorIndividual.bPID," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorIndividual.aBNNumber," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorIndividual.title," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorIndividual.givenNameOne," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorIndividual.lastName," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorIndividual.givenNameOneLocal," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorIndividual.lastNameLocal," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorIndividual.birthDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorIndividual.addressUsage," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorIndividual.addressLineOne," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorIndividual.addressLineTwo," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorIndividual.addressLineThree," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorIndividual.postalCode," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorIndividual.cityName," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorIndividual.residenceNumber," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorIndividual.country," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorIndividual.buildingName," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorIndividual.streetName," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorIndividual.streetNumber," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorIndividual.mobileNumber," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorIndividual.homePhoneNumber," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorIndividual.workPhoneNumber," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorIndividual.workPhoneNumberExtension," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorIndividual.fax," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorIndividual.email," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorIndividual.sourceIdentifier," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorIndividual.startDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorIndividual.endDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorIndividual.lastModifiedSystemDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorIndividual.lastUpdateDt," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorIndividual.lastUpdateUser," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorIndividual.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjXGurantorIndividualUpdateFields =
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorIndividual.contractDetailsId," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorIndividual.bPID," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorIndividual.aBNNumber," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorIndividual.title," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorIndividual.givenNameOne," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorIndividual.lastName," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorIndividual.givenNameOneLocal," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorIndividual.lastNameLocal," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorIndividual.birthDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorIndividual.addressUsage," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorIndividual.addressLineOne," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorIndividual.addressLineTwo," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorIndividual.addressLineThree," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorIndividual.postalCode," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorIndividual.cityName," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorIndividual.residenceNumber," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorIndividual.country," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorIndividual.buildingName," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorIndividual.streetName," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorIndividual.streetNumber," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorIndividual.mobileNumber," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorIndividual.homePhoneNumber," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorIndividual.workPhoneNumber," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorIndividual.workPhoneNumberExtension," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorIndividual.fax," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorIndividual.email," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorIndividual.sourceIdentifier," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorIndividual.startDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorIndividual.endDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorIndividual.lastModifiedSystemDate," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorIndividual.lastUpdateDt," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorIndividual.lastUpdateUser," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorIndividual.lastUpdateTxId," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorIndividual.xGurantorIndividualpkId," +
    "com.ibm.daimler.dsea.entityObject.EObjXGurantorIndividual.oldLastUpdateDt";   

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Select XGurantorIndividual by parameters.
   * @generated
   */
  @Select(sql=getEObjXGurantorIndividualSql)
  @EntityMapping(parameters=EObjXGurantorIndividualKeyField, results=EObjXGurantorIndividualGetFields)
  Iterator<EObjXGurantorIndividual> getEObjXGurantorIndividual(Long xGurantorIndividualpkId);  
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Create XGurantorIndividual by EObjXGurantorIndividual Object.
   * @generated
   */
  @Update(sql=createEObjXGurantorIndividualSql)
  @EntityMapping(parameters=EObjXGurantorIndividualAllFields)
    int createEObjXGurantorIndividual(EObjXGurantorIndividual e); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Update one XGurantorIndividual by EObjXGurantorIndividual object.
   * @generated
   */
  @Update(sql=updateEObjXGurantorIndividualSql)
  @EntityMapping(parameters=EObjXGurantorIndividualUpdateFields)
    int updateEObjXGurantorIndividual(EObjXGurantorIndividual e); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Delete XGurantorIndividual by parameters.
   * @generated
   */
  @Update(sql=deleteEObjXGurantorIndividualSql)
  @EntityMapping(parameters=EObjXGurantorIndividualKeyField)
  int deleteEObjXGurantorIndividual(Long xGurantorIndividualpkId);

}

