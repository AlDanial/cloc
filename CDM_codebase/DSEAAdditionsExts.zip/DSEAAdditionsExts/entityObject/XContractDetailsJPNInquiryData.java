/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[c8472368f8eb6c593247569e3dc150bf]
 */

package com.ibm.daimler.dsea.entityObject;


import com.ibm.mdm.base.db.ResultQueue1;
import java.util.Iterator;
import com.ibm.mdm.base.db.EntityMapping;
import com.ibm.pdq.annotation.Select;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * @generated
 */
public interface XContractDetailsJPNInquiryData {
  
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String tableAliasString = "tableAlias (" + 
                                            "XCONTRACTDETAILSJPN => com.ibm.daimler.dsea.entityObject.EObjXContractDetailsJPN, " +
                                            "H_XCONTRACTDETAILSJPN => com.ibm.daimler.dsea.entityObject.EObjXContractDetailsJPN" +
                                            ")";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getXContractDetailsJPNSql = "SELECT r.XContract_JPNPK_ID XContract_JPNPK_ID, r.CONT_ID CONT_ID, r.FINANCE_PRODUCT FINANCE_PRODUCT, r.CONTRACT_NUMBER CONTRACT_NUMBER, r.CONTRACT_ST_TP_CD CONTRACT_ST_TP_CD, r.MARKET_NAME MARKET_NAME, r.GLOBAL_VIN GLOBAL_VIN, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.START_DT START_DT, r.END_DT END_DT, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.SFDC_ID SFDC_ID, r.BATCH_IND BATCH_IND, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XCONTRACTDETAILSJPN r WHERE r.XContract_JPNPK_ID = ? ";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXContractDetailsJPNParameters =
    "EObjXContractDetailsJPN.XContractJPNpkId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXContractDetailsJPNResults =
    "EObjXContractDetailsJPN.XContractJPNpkId," +
    "EObjXContractDetailsJPN.ContId," +
    "EObjXContractDetailsJPN.FinanceProduct," +
    "EObjXContractDetailsJPN.ContractNumber," +
    "EObjXContractDetailsJPN.ContractStatus," +
    "EObjXContractDetailsJPN.MarketName," +
    "EObjXContractDetailsJPN.GlobalVIN," +
    "EObjXContractDetailsJPN.SourceIdentifier," +
    "EObjXContractDetailsJPN.StartDate," +
    "EObjXContractDetailsJPN.EndDate," +
    "EObjXContractDetailsJPN.LastModifiedSystemDate," +
    "EObjXContractDetailsJPN.SFDCId," +
    "EObjXContractDetailsJPN.BatchInd," +
    "EObjXContractDetailsJPN.lastUpdateDt," +
    "EObjXContractDetailsJPN.lastUpdateUser," +
    "EObjXContractDetailsJPN.lastUpdateTxId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getXContractDetailsJPNHistorySql = "SELECT r.H_XContract_JPNPK_ID hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.XContract_JPNPK_ID XContract_JPNPK_ID, r.CONT_ID CONT_ID, r.FINANCE_PRODUCT FINANCE_PRODUCT, r.CONTRACT_NUMBER CONTRACT_NUMBER, r.CONTRACT_ST_TP_CD CONTRACT_ST_TP_CD, r.MARKET_NAME MARKET_NAME, r.GLOBAL_VIN GLOBAL_VIN, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.START_DT START_DT, r.END_DT END_DT, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.SFDC_ID SFDC_ID, r.BATCH_IND BATCH_IND, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XCONTRACTDETAILSJPN r WHERE r.H_XContract_JPNPK_ID = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXContractDetailsJPNHistoryParameters =
    "EObjXContractDetailsJPN.XContractJPNpkId," +
    "EObjXContractDetailsJPN.lastUpdateDt," +
    "EObjXContractDetailsJPN.lastUpdateDt";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getXContractDetailsJPNHistoryResults =
    "EObjXContractDetailsJPN.historyIdPK," +
    "EObjXContractDetailsJPN.histActionCode," +
    "EObjXContractDetailsJPN.histCreatedBy," +
    "EObjXContractDetailsJPN.histCreateDt," +
    "EObjXContractDetailsJPN.histEndDt," +
    "EObjXContractDetailsJPN.XContractJPNpkId," +
    "EObjXContractDetailsJPN.ContId," +
    "EObjXContractDetailsJPN.FinanceProduct," +
    "EObjXContractDetailsJPN.ContractNumber," +
    "EObjXContractDetailsJPN.ContractStatus," +
    "EObjXContractDetailsJPN.MarketName," +
    "EObjXContractDetailsJPN.GlobalVIN," +
    "EObjXContractDetailsJPN.SourceIdentifier," +
    "EObjXContractDetailsJPN.StartDate," +
    "EObjXContractDetailsJPN.EndDate," +
    "EObjXContractDetailsJPN.LastModifiedSystemDate," +
    "EObjXContractDetailsJPN.SFDCId," +
    "EObjXContractDetailsJPN.BatchInd," +
    "EObjXContractDetailsJPN.lastUpdateDt," +
    "EObjXContractDetailsJPN.lastUpdateUser," +
    "EObjXContractDetailsJPN.lastUpdateTxId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getAllXContractDetailsJPNByPartyIdSql = "SELECT r.XContract_JPNPK_ID XContract_JPNPK_ID, r.CONT_ID CONT_ID, r.FINANCE_PRODUCT FINANCE_PRODUCT, r.CONTRACT_NUMBER CONTRACT_NUMBER, r.CONTRACT_ST_TP_CD CONTRACT_ST_TP_CD, r.MARKET_NAME MARKET_NAME, r.GLOBAL_VIN GLOBAL_VIN, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.START_DT START_DT, r.END_DT END_DT, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.SFDC_ID SFDC_ID, r.BATCH_IND BATCH_IND, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM XCONTRACTDETAILSJPN r WHERE r.CONT_ID = ? ";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getAllXContractDetailsJPNByPartyIdParameters =
    "EObjXContractDetailsJPN.ContId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getAllXContractDetailsJPNByPartyIdResults =
    "EObjXContractDetailsJPN.XContractJPNpkId," +
    "EObjXContractDetailsJPN.ContId," +
    "EObjXContractDetailsJPN.FinanceProduct," +
    "EObjXContractDetailsJPN.ContractNumber," +
    "EObjXContractDetailsJPN.ContractStatus," +
    "EObjXContractDetailsJPN.MarketName," +
    "EObjXContractDetailsJPN.GlobalVIN," +
    "EObjXContractDetailsJPN.SourceIdentifier," +
    "EObjXContractDetailsJPN.StartDate," +
    "EObjXContractDetailsJPN.EndDate," +
    "EObjXContractDetailsJPN.LastModifiedSystemDate," +
    "EObjXContractDetailsJPN.SFDCId," +
    "EObjXContractDetailsJPN.BatchInd," +
    "EObjXContractDetailsJPN.lastUpdateDt," +
    "EObjXContractDetailsJPN.lastUpdateUser," +
    "EObjXContractDetailsJPN.lastUpdateTxId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getAllXContractDetailsJPNByPartyIdHistorySql = "SELECT r.H_XContract_JPNPK_ID hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.XContract_JPNPK_ID XContract_JPNPK_ID, r.CONT_ID CONT_ID, r.FINANCE_PRODUCT FINANCE_PRODUCT, r.CONTRACT_NUMBER CONTRACT_NUMBER, r.CONTRACT_ST_TP_CD CONTRACT_ST_TP_CD, r.MARKET_NAME MARKET_NAME, r.GLOBAL_VIN GLOBAL_VIN, r.SOURCE_IDENT_TP_CD SOURCE_IDENT_TP_CD, r.START_DT START_DT, r.END_DT END_DT, r.MODIFY_SYS_DT MODIFY_SYS_DT, r.SFDC_ID SFDC_ID, r.BATCH_IND BATCH_IND, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_XCONTRACTDETAILSJPN r WHERE r.CONT_ID = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getAllXContractDetailsJPNByPartyIdHistoryParameters =
    "EObjXContractDetailsJPN.ContId," +
    "EObjXContractDetailsJPN.lastUpdateDt," +
    "EObjXContractDetailsJPN.lastUpdateDt";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getAllXContractDetailsJPNByPartyIdHistoryResults =
    "EObjXContractDetailsJPN.historyIdPK," +
    "EObjXContractDetailsJPN.histActionCode," +
    "EObjXContractDetailsJPN.histCreatedBy," +
    "EObjXContractDetailsJPN.histCreateDt," +
    "EObjXContractDetailsJPN.histEndDt," +
    "EObjXContractDetailsJPN.XContractJPNpkId," +
    "EObjXContractDetailsJPN.ContId," +
    "EObjXContractDetailsJPN.FinanceProduct," +
    "EObjXContractDetailsJPN.ContractNumber," +
    "EObjXContractDetailsJPN.ContractStatus," +
    "EObjXContractDetailsJPN.MarketName," +
    "EObjXContractDetailsJPN.GlobalVIN," +
    "EObjXContractDetailsJPN.SourceIdentifier," +
    "EObjXContractDetailsJPN.StartDate," +
    "EObjXContractDetailsJPN.EndDate," +
    "EObjXContractDetailsJPN.LastModifiedSystemDate," +
    "EObjXContractDetailsJPN.SFDCId," +
    "EObjXContractDetailsJPN.BatchInd," +
    "EObjXContractDetailsJPN.lastUpdateDt," +
    "EObjXContractDetailsJPN.lastUpdateUser," +
    "EObjXContractDetailsJPN.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getXContractDetailsJPNSql, pattern=tableAliasString)
  @EntityMapping(parameters=getXContractDetailsJPNParameters, results=getXContractDetailsJPNResults)
  Iterator<ResultQueue1<EObjXContractDetailsJPN>> getXContractDetailsJPN(Object[] parameters);  


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getXContractDetailsJPNHistorySql, pattern=tableAliasString)
  @EntityMapping(parameters=getXContractDetailsJPNHistoryParameters, results=getXContractDetailsJPNHistoryResults)
  Iterator<ResultQueue1<EObjXContractDetailsJPN>> getXContractDetailsJPNHistory(Object[] parameters);  


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getAllXContractDetailsJPNByPartyIdSql, pattern=tableAliasString)
  @EntityMapping(parameters=getAllXContractDetailsJPNByPartyIdParameters, results=getAllXContractDetailsJPNByPartyIdResults)
  Iterator<ResultQueue1<EObjXContractDetailsJPN>> getAllXContractDetailsJPNByPartyId(Object[] parameters);  


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getAllXContractDetailsJPNByPartyIdHistorySql, pattern=tableAliasString)
  @EntityMapping(parameters=getAllXContractDetailsJPNByPartyIdHistoryParameters, results=getAllXContractDetailsJPNByPartyIdHistoryResults)
  Iterator<ResultQueue1<EObjXContractDetailsJPN>> getAllXContractDetailsJPNByPartyIdHistory(Object[] parameters);  


}


