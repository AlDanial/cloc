package com.ibm.daimler.dsea.entityObject;

import com.ibm.pdq.runtime.generator.BaseParameterHandler;
import java.util.Iterator;
import java.sql.PreparedStatement;
import com.ibm.pdq.runtime.statement.StatementDescriptor;
import com.dwl.tcrm.coreParty.entityObject.EObjContactMethod;
import com.ibm.pdq.runtime.generator.BaseData;
import java.sql.SQLException;
import com.ibm.pdq.annotation.Metadata;
import com.ibm.mdm.base.db.ResultQueue2;
import com.ibm.pdq.runtime.generator.BaseRowHandler;
import com.ibm.pdq.runtime.statement.SqlStatementType;
import com.ibm.daimler.dsea.entityObject.EObjXContactMethodExt;
import java.sql.Types;


@SuppressWarnings("unchecked")

/**
 * <!-- begin-user-doc -->
 * 
 * <!-- end-user-doc -->
 * 
 * @generated
 */
public class XContactMethodExtInquiryDataImpl  extends BaseData implements XContactMethodExtInquiryData
{

  /**
   * @generated
   */
  public static final String generatorVersion = "3.200.75";

  /**
   * @generated
   */
  public static final String identifier = "XContactMethodExtInquiryData";

  /**
   * @generated
   */
  public static final long generationTime = 0x00000161c413c4daL;

  /**
   * @generated
   */
  public static final String collection = "NULLID";

  /**
   * @generated
   */
  public static final String packageVersion = null;

  /**
   * @generated
   */
  public static final boolean forceSingleBindIsolation = false;

  /**
   * @generated
   */
  public XContactMethodExtInquiryDataImpl()
  {
    super();
  } 

  /**
   * @generated
   */
  public String getGeneratorVersion()
  {
    return generatorVersion;
  }

  /**
   * @Select( sql="SELECT DISTINCT A.H_CONTACT_METHOD_I AS HIST_ID_PK, A.H_ACTION_CODE, A.H_CREATED_BY, A.H_CREATE_DT, A.H_END_DT, A.CONTACT_METHOD_ID, A.REF_NUM, A.ADDRESS_ID, A.CONT_METH_CAT_CD, A.LAST_UPDATE_DT, A.LAST_UPDATE_USER, A.LAST_UPDATE_TX_ID, A.CONT_METH_STD_IND, A.PHONE_EXTENSION FROM H_CONTACTMETHOD A WHERE A.H_CONTACT_METHOD_I = ? AND (? BETWEEN A.H_CREATE_DT AND A.H_END_DT OR (? >= A.H_CREATE_DT AND A.H_END_DT IS NULL))", pattern="tableAlias (CONTACTMETHOD => com.dwl.tcrm.coreParty.entityObject.EObjContactMethod, H_CONTACTMETHOD => com.dwl.tcrm.coreParty.entityObject.EObjContactMethod , CONTACTMETHOD => com.ibm.daimler.dsea.entityObject.EObjXContactMethodExt , H_CONTACTMETHOD => com.ibm.daimler.dsea.entityObject.EObjXContactMethodExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue2<EObjContactMethod,EObjXContactMethodExt>> getConMethodHistory (Object[] parameters)
  {
    return queryIterator (getConMethodHistoryStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getConMethodHistoryStatementDescriptor = createStatementDescriptor (
    "getConMethodHistory(Object[])",
    "SELECT DISTINCT A.H_CONTACT_METHOD_I AS HIST_ID_PK, A.H_ACTION_CODE, A.H_CREATED_BY, A.H_CREATE_DT, A.H_END_DT, A.CONTACT_METHOD_ID, A.REF_NUM, A.ADDRESS_ID, A.CONT_METH_CAT_CD, A.LAST_UPDATE_DT, A.LAST_UPDATE_USER, A.LAST_UPDATE_TX_ID, A.CONT_METH_STD_IND, A.PHONE_EXTENSION FROM H_CONTACTMETHOD A WHERE A.H_CONTACT_METHOD_I = ? AND (? BETWEEN A.H_CREATE_DT AND A.H_END_DT OR (? >= A.H_CREATE_DT AND A.H_END_DT IS NULL))",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"hist_id_pk", "h_action_code", "h_created_by", "h_create_dt", "h_end_dt", "contact_method_id", "ref_num", "address_id", "cont_meth_cat_cd", "last_update_dt", "last_update_user", "last_update_tx_id", "cont_meth_std_ind", "phone_extension"},
    new GetConMethodHistoryParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP}, {19, 0, 0}, {0, 0, 0}, {1, 1, 1}},
    null,
    new GetConMethodHistoryRowHandler (),
    new int[][]{ {Types.BIGINT, Types.CHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.CHAR, Types.VARCHAR}, {19, 1, 20, 0, 0, 19, 255, 19, 19, 0, 20, 19, 1, 250}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    1);

  /**
   * @generated
   */
  public static class GetConMethodHistoryParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetConMethodHistoryRowHandler extends BaseRowHandler<ResultQueue2<EObjContactMethod,EObjXContactMethodExt>>
  {
    /**
     * @generated
     */
    public ResultQueue2<EObjContactMethod,EObjXContactMethodExt> handle (java.sql.ResultSet rs, ResultQueue2<EObjContactMethod,EObjXContactMethodExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue2<EObjContactMethod,EObjXContactMethodExt> ();

      EObjContactMethod returnObject1 = new EObjContactMethod ();
      returnObject1.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject1.setHistActionCode(getString (rs, 2)); 
      returnObject1.setHistCreatedBy(getString (rs, 3)); 
      returnObject1.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject1.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject1.setContactMethodIdPK(getLongObject (rs, 6)); 
      returnObject1.setRefNum(getString (rs, 7)); 
      returnObject1.setAddressId(getLongObject (rs, 8)); 
      returnObject1.setContMethCatCd(getLongObject (rs, 9)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 10)); 
      returnObject1.setLastUpdateUser(getString (rs, 11)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 12)); 
      returnObject1.setContMethStandardInd(getString (rs, 13)); 
      returnObject.add (returnObject1);

      EObjXContactMethodExt returnObject2 = new EObjXContactMethodExt ();
      returnObject2.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject2.setHistActionCode(getString (rs, 2)); 
      returnObject2.setHistCreatedBy(getString (rs, 3)); 
      returnObject2.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject2.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject2.setLastUpdateDt(getTimestamp (rs, 10)); 
      returnObject2.setLastUpdateUser(getString (rs, 11)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 12)); 
      returnObject2.setPhoneExtension(getString (rs, 14)); 
      returnObject.add (returnObject2);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT CONTACTMETHOD.CONTACT_METHOD_ID, CONTACTMETHOD.REF_NUM, CONTACTMETHOD.ADDRESS_ID, CONTACTMETHOD.CONT_METH_CAT_CD,CONTACTMETHOD.LAST_UPDATE_DT, CONTACTMETHOD.LAST_UPDATE_USER,CONTACTMETHOD.LAST_UPDATE_TX_ID,CONT_METH_STD_IND, CONTACTMETHOD.PHONE_EXTENSION FROM CONTACTMETHOD WHERE (CONTACTMETHOD.CONTACT_METHOD_ID =?)", pattern="tableAlias (CONTACTMETHOD => com.dwl.tcrm.coreParty.entityObject.EObjContactMethod, H_CONTACTMETHOD => com.dwl.tcrm.coreParty.entityObject.EObjContactMethod , CONTACTMETHOD => com.ibm.daimler.dsea.entityObject.EObjXContactMethodExt , H_CONTACTMETHOD => com.ibm.daimler.dsea.entityObject.EObjXContactMethodExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue2<EObjContactMethod,EObjXContactMethodExt>> getContactMethod (Object[] parameters)
  {
    return queryIterator (getContactMethodStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getContactMethodStatementDescriptor = createStatementDescriptor (
    "getContactMethod(Object[])",
    "SELECT CONTACTMETHOD.CONTACT_METHOD_ID, CONTACTMETHOD.REF_NUM, CONTACTMETHOD.ADDRESS_ID, CONTACTMETHOD.CONT_METH_CAT_CD,CONTACTMETHOD.LAST_UPDATE_DT, CONTACTMETHOD.LAST_UPDATE_USER,CONTACTMETHOD.LAST_UPDATE_TX_ID,CONT_METH_STD_IND, CONTACTMETHOD.PHONE_EXTENSION FROM CONTACTMETHOD WHERE (CONTACTMETHOD.CONTACT_METHOD_ID =?)",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"contact_method_id", "ref_num", "address_id", "cont_meth_cat_cd", "last_update_dt", "last_update_user", "last_update_tx_id", "cont_meth_std_ind", "phone_extension"},
    new GetContactMethodParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetContactMethodRowHandler (),
    new int[][]{ {Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.CHAR, Types.VARCHAR}, {19, 255, 19, 19, 0, 20, 19, 1, 250}, {0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    2);

  /**
   * @generated
   */
  public static class GetContactMethodParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetContactMethodRowHandler extends BaseRowHandler<ResultQueue2<EObjContactMethod,EObjXContactMethodExt>>
  {
    /**
     * @generated
     */
    public ResultQueue2<EObjContactMethod,EObjXContactMethodExt> handle (java.sql.ResultSet rs, ResultQueue2<EObjContactMethod,EObjXContactMethodExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue2<EObjContactMethod,EObjXContactMethodExt> ();

      EObjContactMethod returnObject1 = new EObjContactMethod ();
      returnObject1.setContactMethodIdPK(getLongObject (rs, 1)); 
      returnObject1.setRefNum(getString (rs, 2)); 
      returnObject1.setAddressId(getLongObject (rs, 3)); 
      returnObject1.setContMethCatCd(getLongObject (rs, 4)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 5)); 
      returnObject1.setLastUpdateUser(getString (rs, 6)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 7)); 
      returnObject1.setContMethStandardInd(getString (rs, 8)); 
      returnObject.add (returnObject1);

      EObjXContactMethodExt returnObject2 = new EObjXContactMethodExt ();
      returnObject2.setLastUpdateDt(getTimestamp (rs, 5)); 
      returnObject2.setLastUpdateUser(getString (rs, 6)); 
      returnObject2.setLastUpdateTxId(getLongObject (rs, 7)); 
      returnObject2.setPhoneExtension(getString (rs, 9)); 
      returnObject.add (returnObject2);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT DISTINCT A.CONTACT_METHOD_ID, A.LAST_UPDATE_DT, A.PHONE_EXTENSION FROM H_CONTACTMETHOD A WHERE A.CONTACT_METHOD_ID = ? AND ( A.H_CREATE_DT BETWEEN ? AND ? )", pattern="tableAlias (CONTACTMETHOD => com.dwl.tcrm.coreParty.entityObject.EObjContactMethod, H_CONTACTMETHOD => com.dwl.tcrm.coreParty.entityObject.EObjContactMethod , CONTACTMETHOD => com.ibm.daimler.dsea.entityObject.EObjXContactMethodExt , H_CONTACTMETHOD => com.ibm.daimler.dsea.entityObject.EObjXContactMethodExt)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue2<EObjContactMethod,EObjXContactMethodExt>> getConMethodLightImg (Object[] parameters)
  {
    return queryIterator (getConMethodLightImgStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getConMethodLightImgStatementDescriptor = createStatementDescriptor (
    "getConMethodLightImg(Object[])",
    "SELECT DISTINCT A.CONTACT_METHOD_ID, A.LAST_UPDATE_DT, A.PHONE_EXTENSION FROM H_CONTACTMETHOD A WHERE A.CONTACT_METHOD_ID = ? AND ( A.H_CREATE_DT BETWEEN ? AND ? )",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"contact_method_id", "last_update_dt", "phone_extension"},
    new GetConMethodLightImgParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP}, {19, 0, 0}, {0, 0, 0}, {1, 1, 1}},
    null,
    new GetConMethodLightImgRowHandler (),
    new int[][]{ {Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR}, {19, 0, 250}, {0, 0, 0}, {0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    3);

  /**
   * @generated
   */
  public static class GetConMethodLightImgParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetConMethodLightImgRowHandler extends BaseRowHandler<ResultQueue2<EObjContactMethod,EObjXContactMethodExt>>
  {
    /**
     * @generated
     */
    public ResultQueue2<EObjContactMethod,EObjXContactMethodExt> handle (java.sql.ResultSet rs, ResultQueue2<EObjContactMethod,EObjXContactMethodExt> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue2<EObjContactMethod,EObjXContactMethodExt> ();

      EObjContactMethod returnObject1 = new EObjContactMethod ();
      returnObject1.setContactMethodIdPK(getLongObject (rs, 1)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 2)); 
      returnObject.add (returnObject1);

      EObjXContactMethodExt returnObject2 = new EObjXContactMethodExt ();
      returnObject2.setLastUpdateDt(getTimestamp (rs, 2)); 
      returnObject2.setPhoneExtension(getString (rs, 3)); 
      returnObject.add (returnObject2);

    
      return returnObject;
    }
  }

}
