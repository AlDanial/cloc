package com.ibm.daimler.dsea.entityObject;

import com.ibm.pdq.runtime.generator.BaseParameterHandler;
import java.util.Iterator;
import java.sql.PreparedStatement;
import com.ibm.pdq.runtime.statement.StatementDescriptor;
import com.ibm.pdq.runtime.generator.BaseData;
import java.sql.SQLException;
import com.ibm.pdq.annotation.Metadata;
import com.ibm.pdq.runtime.generator.BaseRowHandler;
import com.ibm.pdq.runtime.statement.SqlStatementType;
import com.ibm.daimler.dsea.entityObject.EObjXVehicleJPN;
import java.sql.Types;


/**
 * <!-- begin-user-doc -->
 * 
 * <!-- end-user-doc -->
 * 
 * @generated
 */
public class EObjXVehicleJPNDataImpl  extends BaseData implements EObjXVehicleJPNData
{

  /**
   * @generated
   */
  public static final String generatorVersion = "3.200.75";

  /**
   * @generated
   */
  public static final String identifier = "EObjXVehicleJPNData";

  /**
   * @generated
   */
  public static final long generationTime = 0x0000016676bfefb3L;

  /**
   * @generated
   */
  public static final String collection = "NULLID";

  /**
   * @generated
   */
  public static final String packageVersion = null;

  /**
   * @generated
   */
  public static final boolean forceSingleBindIsolation = false;

  /**
   * @generated
   */
  public EObjXVehicleJPNDataImpl()
  {
    super();
  } 

  /**
   * @generated
   */
  public String getGeneratorVersion()
  {
    return generatorVersion;
  }

  /**
   * @Select( sql="select XVehicle_JPNPK_ID, GLOBAL_VIN, BAU_MUSTER, TYPE_ClASS, SUB_MUSTER, COLOR, TRIM, BATCH_IND, MARKET_NAME, SOURCE_IDENT_TP_CD, MODIFY_SYS_DT, CREATE_DT, CHANGED_DT, LAST_SERVICE_DT, SFDC_ID, VEHICLE_ADDRESS_TYPE, VEHICLE_TYPE, DELETE_FLAG, END_DT, ENGINE_NUM, MYCAR_ID, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from XVEHICLEJPN where XVehicle_JPNPK_ID = ? " )
   * 
   * @generated
   */
  public Iterator<EObjXVehicleJPN> getEObjXVehicleJPN (Long xVehicleJPNpkId)
  {
    return queryIterator (getEObjXVehicleJPNStatementDescriptor, xVehicleJPNpkId);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getEObjXVehicleJPNStatementDescriptor = createStatementDescriptor (
    "getEObjXVehicleJPN(Long)",
    "select XVehicle_JPNPK_ID, GLOBAL_VIN, BAU_MUSTER, TYPE_ClASS, SUB_MUSTER, COLOR, TRIM, BATCH_IND, MARKET_NAME, SOURCE_IDENT_TP_CD, MODIFY_SYS_DT, CREATE_DT, CHANGED_DT, LAST_SERVICE_DT, SFDC_ID, VEHICLE_ADDRESS_TYPE, VEHICLE_TYPE, DELETE_FLAG, END_DT, ENGINE_NUM, MYCAR_ID, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from XVEHICLEJPN where XVehicle_JPNPK_ID = ? ",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"xvehicle_jpnpk_id", "global_vin", "bau_muster", "type_class", "sub_muster", "color", "trim", "batch_ind", "market_name", "source_ident_tp_cd", "modify_sys_dt", "create_dt", "changed_dt", "last_service_dt", "sfdc_id", "vehicle_address_type", "vehicle_type", "delete_flag", "end_dt", "engine_num", "mycar_id", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetEObjXVehicleJPNParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetEObjXVehicleJPNRowHandler (),
    new int[][]{ {Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 50, 20, 255, 255, 255, 255, 5, 50, 19, 0, 0, 0, 0, 50, 255, 50, 10, 0, 20, 50, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    1);

  /**
   * @generated
   */
  public static class GetEObjXVehicleJPNParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setLong (stmt, 1, Types.BIGINT, (Long)parameters[0]);
    }
  }

  /**
   * @generated
   */
  public static class GetEObjXVehicleJPNRowHandler extends BaseRowHandler<EObjXVehicleJPN>
  {
    /**
     * @generated
     */
    public EObjXVehicleJPN handle (java.sql.ResultSet rs, EObjXVehicleJPN returnObject) throws java.sql.SQLException
    {
      returnObject = new EObjXVehicleJPN ();
      returnObject.setXVehicleJPNpkId(getLongObject (rs, 1)); 
      returnObject.setGlobalVIN(getString (rs, 2)); 
      returnObject.setBauMuster(getString (rs, 3)); 
      returnObject.setTypeClass(getString (rs, 4)); 
      returnObject.setSubMuster(getString (rs, 5)); 
      returnObject.setColor(getString (rs, 6)); 
      returnObject.setTrim(getString (rs, 7)); 
      returnObject.setBatchInd(getString (rs, 8)); 
      returnObject.setMarketName(getString (rs, 9)); 
      returnObject.setSourceIdentifier(getLongObject (rs, 10)); 
      returnObject.setLastModifiedSystemDate(getTimestamp (rs, 11)); 
      returnObject.setCreateDate(getTimestamp (rs, 12)); 
      returnObject.setChangedDate(getTimestamp (rs, 13)); 
      returnObject.setLastServiceDate(getTimestamp (rs, 14)); 
      returnObject.setSFDCId(getString (rs, 15)); 
      returnObject.setVehicleAddressType(getString (rs, 16)); 
      returnObject.setVehicleType(getString (rs, 17)); 
      returnObject.setDeleteFlag(getString (rs, 18)); 
      returnObject.setEndDate(getTimestamp (rs, 19)); 
      returnObject.setEngineNumber(getString (rs, 20)); 
      returnObject.setMyCarId(getString (rs, 21)); 
      returnObject.setLastUpdateDt(getTimestamp (rs, 22)); 
      returnObject.setLastUpdateUser(getString (rs, 23)); 
      returnObject.setLastUpdateTxId(getLongObject (rs, 24)); 
    
      return returnObject;
    }
  }

  /**
   * @Update( sql="insert into XVEHICLEJPN (XVehicle_JPNPK_ID, GLOBAL_VIN, BAU_MUSTER, TYPE_ClASS, SUB_MUSTER, COLOR, TRIM, BATCH_IND, MARKET_NAME, SOURCE_IDENT_TP_CD, MODIFY_SYS_DT, CREATE_DT, CHANGED_DT, LAST_SERVICE_DT, SFDC_ID, VEHICLE_ADDRESS_TYPE, VEHICLE_TYPE, DELETE_FLAG, END_DT, ENGINE_NUM, MYCAR_ID, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( :xVehicleJPNpkId, :globalVIN, :bauMuster, :typeClass, :subMuster, :color, :trim, :batchInd, :marketName, :sourceIdentifier, :lastModifiedSystemDate, :createDate, :changedDate, :lastServiceDate, :sFDCId, :vehicleAddressType, :vehicleType, :deleteFlag, :endDate, :engineNumber, :myCarId, :lastUpdateDt, :lastUpdateUser, :lastUpdateTxId)" )
   * 
   * @generated
   */
  public int createEObjXVehicleJPN (EObjXVehicleJPN e)
  {
    return update (createEObjXVehicleJPNStatementDescriptor, e);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor createEObjXVehicleJPNStatementDescriptor = createStatementDescriptor (
    "createEObjXVehicleJPN(com.ibm.daimler.dsea.entityObject.EObjXVehicleJPN)",
    "insert into XVEHICLEJPN (XVehicle_JPNPK_ID, GLOBAL_VIN, BAU_MUSTER, TYPE_ClASS, SUB_MUSTER, COLOR, TRIM, BATCH_IND, MARKET_NAME, SOURCE_IDENT_TP_CD, MODIFY_SYS_DT, CREATE_DT, CHANGED_DT, LAST_SERVICE_DT, SFDC_ID, VEHICLE_ADDRESS_TYPE, VEHICLE_TYPE, DELETE_FLAG, END_DT, ENGINE_NUM, MYCAR_ID, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values(  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? )",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.INSERT,
    null,
    new CreateEObjXVehicleJPNParameterHandler (),
    new int[][]{{Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 50, 20, 255, 255, 255, 255, 5, 50, 19, 0, 0, 0, 0, 50, 255, 50, 10, 0, 20, 50, 0, 0, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    2);

  /**
   * @generated
   */
  public static class CreateEObjXVehicleJPNParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      EObjXVehicleJPN bean0 = (EObjXVehicleJPN) parameters[0];
      setLong (stmt, 1, Types.BIGINT, (Long)bean0.getXVehicleJPNpkId());
      setString (stmt, 2, Types.VARCHAR, (String)bean0.getGlobalVIN());
      setString (stmt, 3, Types.VARCHAR, (String)bean0.getBauMuster());
      setString (stmt, 4, Types.VARCHAR, (String)bean0.getTypeClass());
      setString (stmt, 5, Types.VARCHAR, (String)bean0.getSubMuster());
      setString (stmt, 6, Types.VARCHAR, (String)bean0.getColor());
      setString (stmt, 7, Types.VARCHAR, (String)bean0.getTrim());
      setString (stmt, 8, Types.VARCHAR, (String)bean0.getBatchInd());
      setString (stmt, 9, Types.VARCHAR, (String)bean0.getMarketName());
      setLong (stmt, 10, Types.BIGINT, (Long)bean0.getSourceIdentifier());
      setTimestamp (stmt, 11, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastModifiedSystemDate());
      setTimestamp (stmt, 12, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getCreateDate());
      setTimestamp (stmt, 13, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getChangedDate());
      setTimestamp (stmt, 14, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastServiceDate());
      setString (stmt, 15, Types.VARCHAR, (String)bean0.getSFDCId());
      setString (stmt, 16, Types.VARCHAR, (String)bean0.getVehicleAddressType());
      setString (stmt, 17, Types.VARCHAR, (String)bean0.getVehicleType());
      setString (stmt, 18, Types.VARCHAR, (String)bean0.getDeleteFlag());
      setTimestamp (stmt, 19, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getEndDate());
      setString (stmt, 20, Types.VARCHAR, (String)bean0.getEngineNumber());
      setString (stmt, 21, Types.VARCHAR, (String)bean0.getMyCarId());
      setTimestamp (stmt, 22, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUpdateDt());
      setString (stmt, 23, Types.VARCHAR, (String)bean0.getLastUpdateUser());
      setLong (stmt, 24, Types.BIGINT, (Long)bean0.getLastUpdateTxId());
    }
  }

  /**
   * @Update( sql="update XVEHICLEJPN set GLOBAL_VIN = :globalVIN, BAU_MUSTER = :bauMuster, TYPE_ClASS = :typeClass, SUB_MUSTER = :subMuster, COLOR = :color, TRIM = :trim, BATCH_IND = :batchInd, MARKET_NAME = :marketName, SOURCE_IDENT_TP_CD = :sourceIdentifier, MODIFY_SYS_DT = :lastModifiedSystemDate, CREATE_DT = :createDate, CHANGED_DT = :changedDate, LAST_SERVICE_DT = :lastServiceDate, SFDC_ID = :sFDCId, VEHICLE_ADDRESS_TYPE = :vehicleAddressType, VEHICLE_TYPE = :vehicleType, DELETE_FLAG = :deleteFlag, END_DT = :endDate, ENGINE_NUM = :engineNumber, MYCAR_ID = :myCarId, LAST_UPDATE_DT = :lastUpdateDt, LAST_UPDATE_USER = :lastUpdateUser, LAST_UPDATE_TX_ID = :lastUpdateTxId where XVehicle_JPNPK_ID = :xVehicleJPNpkId and LAST_UPDATE_DT = :oldLastUpdateDt" )
   * 
   * @generated
   */
  public int updateEObjXVehicleJPN (EObjXVehicleJPN e)
  {
    return update (updateEObjXVehicleJPNStatementDescriptor, e);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor updateEObjXVehicleJPNStatementDescriptor = createStatementDescriptor (
    "updateEObjXVehicleJPN(com.ibm.daimler.dsea.entityObject.EObjXVehicleJPN)",
    "update XVEHICLEJPN set GLOBAL_VIN =  ? , BAU_MUSTER =  ? , TYPE_ClASS =  ? , SUB_MUSTER =  ? , COLOR =  ? , TRIM =  ? , BATCH_IND =  ? , MARKET_NAME =  ? , SOURCE_IDENT_TP_CD =  ? , MODIFY_SYS_DT =  ? , CREATE_DT =  ? , CHANGED_DT =  ? , LAST_SERVICE_DT =  ? , SFDC_ID =  ? , VEHICLE_ADDRESS_TYPE =  ? , VEHICLE_TYPE =  ? , DELETE_FLAG =  ? , END_DT =  ? , ENGINE_NUM =  ? , MYCAR_ID =  ? , LAST_UPDATE_DT =  ? , LAST_UPDATE_USER =  ? , LAST_UPDATE_TX_ID =  ?  where XVehicle_JPNPK_ID =  ?  and LAST_UPDATE_DT =  ? ",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.UPDATE,
    null,
    new UpdateEObjXVehicleJPNParameterHandler (),
    new int[][]{{Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP}, {50, 20, 255, 255, 255, 255, 5, 50, 19, 0, 0, 0, 0, 50, 255, 50, 10, 0, 20, 50, 0, 0, 19, 19, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    3);

  /**
   * @generated
   */
  public static class UpdateEObjXVehicleJPNParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      EObjXVehicleJPN bean0 = (EObjXVehicleJPN) parameters[0];
      setString (stmt, 1, Types.VARCHAR, (String)bean0.getGlobalVIN());
      setString (stmt, 2, Types.VARCHAR, (String)bean0.getBauMuster());
      setString (stmt, 3, Types.VARCHAR, (String)bean0.getTypeClass());
      setString (stmt, 4, Types.VARCHAR, (String)bean0.getSubMuster());
      setString (stmt, 5, Types.VARCHAR, (String)bean0.getColor());
      setString (stmt, 6, Types.VARCHAR, (String)bean0.getTrim());
      setString (stmt, 7, Types.VARCHAR, (String)bean0.getBatchInd());
      setString (stmt, 8, Types.VARCHAR, (String)bean0.getMarketName());
      setLong (stmt, 9, Types.BIGINT, (Long)bean0.getSourceIdentifier());
      setTimestamp (stmt, 10, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastModifiedSystemDate());
      setTimestamp (stmt, 11, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getCreateDate());
      setTimestamp (stmt, 12, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getChangedDate());
      setTimestamp (stmt, 13, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastServiceDate());
      setString (stmt, 14, Types.VARCHAR, (String)bean0.getSFDCId());
      setString (stmt, 15, Types.VARCHAR, (String)bean0.getVehicleAddressType());
      setString (stmt, 16, Types.VARCHAR, (String)bean0.getVehicleType());
      setString (stmt, 17, Types.VARCHAR, (String)bean0.getDeleteFlag());
      setTimestamp (stmt, 18, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getEndDate());
      setString (stmt, 19, Types.VARCHAR, (String)bean0.getEngineNumber());
      setString (stmt, 20, Types.VARCHAR, (String)bean0.getMyCarId());
      setTimestamp (stmt, 21, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUpdateDt());
      setString (stmt, 22, Types.VARCHAR, (String)bean0.getLastUpdateUser());
      setLong (stmt, 23, Types.BIGINT, (Long)bean0.getLastUpdateTxId());
      setLong (stmt, 24, Types.BIGINT, (Long)bean0.getXVehicleJPNpkId());
      setTimestamp (stmt, 25, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getOldLastUpdateDt());
    }
  }

  /**
   * @Update( sql="delete from XVEHICLEJPN where XVehicle_JPNPK_ID = ?" )
   * 
   * @generated
   */
  public int deleteEObjXVehicleJPN (Long xVehicleJPNpkId)
  {
    return update (deleteEObjXVehicleJPNStatementDescriptor, xVehicleJPNpkId);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor deleteEObjXVehicleJPNStatementDescriptor = createStatementDescriptor (
    "deleteEObjXVehicleJPN(Long)",
    "delete from XVEHICLEJPN where XVehicle_JPNPK_ID = ?",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.DELETE,
    null,
    new DeleteEObjXVehicleJPNParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    4);

  /**
   * @generated
   */
  public static class DeleteEObjXVehicleJPNParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setLong (stmt, 1, Types.BIGINT, (Long)parameters[0]);
    }
  }

}
