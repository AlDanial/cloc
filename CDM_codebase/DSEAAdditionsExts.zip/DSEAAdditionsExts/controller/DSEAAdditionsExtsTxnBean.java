	
/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[b37ca8ed560393eb56184c9929f5570a]
 */

package com.ibm.daimler.dsea.controller;

import com.dwl.base.requestHandler.DWLTransaction;
import com.dwl.base.requestHandler.DWLTransactionPersistent;
import com.dwl.tcrm.common.TCRMCommonComponent;
import com.dwl.tcrm.common.TCRMControlKeys;
import com.dwl.tcrm.common.TCRMErrorCode;
import com.dwl.tcrm.utilities.TCRMClassFactory;
import com.dwl.base.DWLResponse;
import com.dwl.base.exception.DWLBaseException;
import com.ibm.mdm.annotations.Controller;
import com.ibm.mdm.annotations.TxMetadata;


import com.ibm.daimler.dsea.component.XCompanyIdentificationBObj;
import com.ibm.daimler.dsea.component.XConsentBObj;
import com.ibm.daimler.dsea.component.XContractDetailsBObj;
import com.ibm.daimler.dsea.component.XContractDetailsJPNBObj;
import com.ibm.daimler.dsea.component.XContractRelBObj;
import com.ibm.daimler.dsea.component.XContractRelJPNBObj;
import com.ibm.daimler.dsea.component.XCustomerRetailerBObj;
import com.ibm.daimler.dsea.component.XCustomerRetailerJPNBObj;
import com.ibm.daimler.dsea.component.XCustomerRetailerRoleBObj;
import com.ibm.daimler.dsea.component.XCustomerVehicleAusBObj;
import com.ibm.daimler.dsea.component.XCustomerVehicleBObj;
import com.ibm.daimler.dsea.component.XCustomerVehicleJPNBObj;
import com.ibm.daimler.dsea.component.XCustomerVehicleKORBObj;
import com.ibm.daimler.dsea.component.XCustomerVehicleRoleAusBObj;
import com.ibm.daimler.dsea.component.XCustomerVehicleRoleBObj;
import com.ibm.daimler.dsea.component.XCustomerVehicleRoleJPNBObj;
import com.ibm.daimler.dsea.component.XCustomerVehicleRoleKORBObj;
import com.ibm.daimler.dsea.component.XDataSharingBObj;
import com.ibm.daimler.dsea.component.XDealerRetailerBObj;
import com.ibm.daimler.dsea.component.XDeleteAuditBObj;
import com.ibm.daimler.dsea.component.XEpucidTempBObj;
import com.ibm.daimler.dsea.component.XGurantorCompanyBObj;
import com.ibm.daimler.dsea.component.XGurantorIndividualBObj;
import com.ibm.daimler.dsea.component.XMagicRelBObj;
import com.ibm.daimler.dsea.component.XPreferenceBObj;
import com.ibm.daimler.dsea.component.XPrivacyAgreementBObj;
import com.ibm.daimler.dsea.component.XRetailerBObj;
import com.ibm.daimler.dsea.component.XVRCollapseBObj;
import com.ibm.daimler.dsea.component.XVehicleAusBObj;
import com.ibm.daimler.dsea.component.XVehicleAddressBObj;
import com.ibm.daimler.dsea.component.XVehicleBObj;

import com.ibm.daimler.dsea.component.XVehicleJPNBObj;
import com.ibm.daimler.dsea.component.XVehicleKORBObj;
import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsComponentID;
import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsErrorReasonCode;
import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsPropertyKeys;

import com.ibm.daimler.dsea.interfaces.DSEAAdditionsExts;
import com.ibm.daimler.dsea.interfaces.DSEAAdditionsExtsTxn;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * Controller implementation for all persistent DSEAAdditionsExts services.
 * @generated
 */
@Controller(errorComponentID = DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_CONTROLLER)
public class DSEAAdditionsExtsTxnBean  extends TCRMCommonComponent implements DSEAAdditionsExtsTxn {

	/**
    * <!-- begin-user-doc -->
	  * <!-- end-user-doc -->
    * @generated 
    */
	 private final static com.dwl.base.logging.IDWLLogger logger = com.dwl.base.logging.DWLLoggerManager.getLogger(DSEAAdditionsExtsTxnBean.class);
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction handleAddXPreference.
     *
     * @return DWLResponse containing the added 
     * @throws DWLBaseException
     * @see #handleaddXPreference
     *
     * @ejb.interface-method
     *    view-type="both"
     *
     * @generated
     */
     @TxMetadata(actionCategory=TCRMControlKeys.ADD_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.INSERT_RECORD_ERROR, 
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.ADDXPREFERENCE_FAILED)
    public DWLResponse addXPreference(XPreferenceBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER addXPreference(XPreferenceBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("addXPreference", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before transaction addXPreference execution";
      logger.finest("addXPreference(XPreferenceBObj theBObj) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After transaction addXPreference execution";
      logger.finest("addXPreference(XPreferenceBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN addXPreference(XPreferenceBObj theBObj) " + returnValue);
    }
        return retObj;
    }
    
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction addXPreference.
     * 
     * @return DWLResponse containing the added 
     * @throws Exception
     * @see #addXPreference
     *
     * @generated
     */
    public DWLResponse handleAddXPreference(XPreferenceBObj theBObj) throws Exception {
    logger.finest("ENTER handleAddXPreference(XPreferenceBObj theBObj)");
        DWLResponse response = new DWLResponse();
        DSEAAdditionsExts aDSEAAdditionsExtsComponent = (DSEAAdditionsExts) TCRMClassFactory
      .getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
        response = aDSEAAdditionsExtsComponent.addXPreference(theBObj);
    logger.finest("RETURN handleAddXPreference(XPreferenceBObj theBObj)");
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction handleUpdateXPreference.
     *
     * @return DWLResponse containing the added 
     * @throws DWLBaseException
     * @see #handleupdateXPreference
     *
     * @ejb.interface-method
     *    view-type="both"
     *
     * @generated
     */
     @TxMetadata(actionCategory=TCRMControlKeys.UPDATE_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.UPDATE_RECORD_ERROR, 
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.UPDATEXPREFERENCE_FAILED)
    public DWLResponse updateXPreference(XPreferenceBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER updateXPreference(XPreferenceBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("updateXPreference", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before transaction updateXPreference execution";
      logger.finest("updateXPreference(XPreferenceBObj theBObj) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After transaction updateXPreference execution";
      logger.finest("updateXPreference(XPreferenceBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN updateXPreference(XPreferenceBObj theBObj) " + returnValue);
    }
        return retObj;
    }
    
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction updateXPreference.
     * 
     * @return DWLResponse containing the added 
     * @throws Exception
     * @see #updateXPreference
     *
     * @generated
     */
    public DWLResponse handleUpdateXPreference(XPreferenceBObj theBObj) throws Exception {
    logger.finest("ENTER handleUpdateXPreference(XPreferenceBObj theBObj)");
        DWLResponse response = new DWLResponse();
        DSEAAdditionsExts aDSEAAdditionsExtsComponent = (DSEAAdditionsExts) TCRMClassFactory
      .getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
        response = aDSEAAdditionsExtsComponent.updateXPreference(theBObj);
    logger.finest("RETURN handleUpdateXPreference(XPreferenceBObj theBObj)");
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction handleAddXPrivacyAgreement.
     *
     * @return DWLResponse containing the added 
     * @throws DWLBaseException
     * @see #handleaddXPrivacyAgreement
     *
     * @ejb.interface-method
     *    view-type="both"
     *
     * @generated
     */
     @TxMetadata(actionCategory=TCRMControlKeys.ADD_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.INSERT_RECORD_ERROR, 
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.ADDXPRIVACYAGREEMENT_FAILED)
    public DWLResponse addXPrivacyAgreement(XPrivacyAgreementBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER addXPrivacyAgreement(XPrivacyAgreementBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("addXPrivacyAgreement", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before transaction addXPrivacyAgreement execution";
      logger.finest("addXPrivacyAgreement(XPrivacyAgreementBObj theBObj) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After transaction addXPrivacyAgreement execution";
      logger.finest("addXPrivacyAgreement(XPrivacyAgreementBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN addXPrivacyAgreement(XPrivacyAgreementBObj theBObj) " + returnValue);
    }
        return retObj;
    }
    
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction addXPrivacyAgreement.
     * 
     * @return DWLResponse containing the added 
     * @throws Exception
     * @see #addXPrivacyAgreement
     *
     * @generated
     */
    public DWLResponse handleAddXPrivacyAgreement(XPrivacyAgreementBObj theBObj) throws Exception {
    logger.finest("ENTER handleAddXPrivacyAgreement(XPrivacyAgreementBObj theBObj)");
        DWLResponse response = new DWLResponse();
        DSEAAdditionsExts aDSEAAdditionsExtsComponent = (DSEAAdditionsExts) TCRMClassFactory
      .getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
        response = aDSEAAdditionsExtsComponent.addXPrivacyAgreement(theBObj);
    logger.finest("RETURN handleAddXPrivacyAgreement(XPrivacyAgreementBObj theBObj)");
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction
     * handleUpdateXPrivacyAgreement.
     *
     * @return DWLResponse containing the added 
     * @throws DWLBaseException
     * @see #handleupdateXPrivacyAgreement
     *
     * @ejb.interface-method
     *    view-type="both"
     *
     * @generated
     */
     @TxMetadata(actionCategory=TCRMControlKeys.UPDATE_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.UPDATE_RECORD_ERROR, 
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.UPDATEXPRIVACYAGREEMENT_FAILED)
    public DWLResponse updateXPrivacyAgreement(XPrivacyAgreementBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER updateXPrivacyAgreement(XPrivacyAgreementBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("updateXPrivacyAgreement", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before transaction updateXPrivacyAgreement execution";
      logger.finest("updateXPrivacyAgreement(XPrivacyAgreementBObj theBObj) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After transaction updateXPrivacyAgreement execution";
      logger.finest("updateXPrivacyAgreement(XPrivacyAgreementBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN updateXPrivacyAgreement(XPrivacyAgreementBObj theBObj) " + returnValue);
    }
        return retObj;
    }
    
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction updateXPrivacyAgreement.
     * 
     * @return DWLResponse containing the added 
     * @throws Exception
     * @see #updateXPrivacyAgreement
     *
     * @generated
     */
    public DWLResponse handleUpdateXPrivacyAgreement(XPrivacyAgreementBObj theBObj) throws Exception {
    logger.finest("ENTER handleUpdateXPrivacyAgreement(XPrivacyAgreementBObj theBObj)");
        DWLResponse response = new DWLResponse();
        DSEAAdditionsExts aDSEAAdditionsExtsComponent = (DSEAAdditionsExts) TCRMClassFactory
      .getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
        response = aDSEAAdditionsExtsComponent.updateXPrivacyAgreement(theBObj);
    logger.finest("RETURN handleUpdateXPrivacyAgreement(XPrivacyAgreementBObj theBObj)");
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction handleAddXRetailer.
     *
     * @return DWLResponse containing the added 
     * @throws DWLBaseException
     * @see #handleaddXRetailer
     *
     * @ejb.interface-method
     *    view-type="both"
     *
     * @generated
     */
     @TxMetadata(actionCategory=TCRMControlKeys.ADD_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.INSERT_RECORD_ERROR, 
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.ADDXRETAILER_FAILED)
    public DWLResponse addXRetailer(XRetailerBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER addXRetailer(XRetailerBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("addXRetailer", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before transaction addXRetailer execution";
      logger.finest("addXRetailer(XRetailerBObj theBObj) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After transaction addXRetailer execution";
      logger.finest("addXRetailer(XRetailerBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN addXRetailer(XRetailerBObj theBObj) " + returnValue);
    }
        return retObj;
    }
    
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction addXRetailer.
     * 
     * @return DWLResponse containing the added 
     * @throws Exception
     * @see #addXRetailer
     *
     * @generated
     */
    public DWLResponse handleAddXRetailer(XRetailerBObj theBObj) throws Exception {
    logger.finest("ENTER handleAddXRetailer(XRetailerBObj theBObj)");
        DWLResponse response = new DWLResponse();
        DSEAAdditionsExts aDSEAAdditionsExtsComponent = (DSEAAdditionsExts) TCRMClassFactory
      .getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
        response = aDSEAAdditionsExtsComponent.addXRetailer(theBObj);
    logger.finest("RETURN handleAddXRetailer(XRetailerBObj theBObj)");
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction handleUpdateXRetailer.
     *
     * @return DWLResponse containing the added 
     * @throws DWLBaseException
     * @see #handleupdateXRetailer
     *
     * @ejb.interface-method
     *    view-type="both"
     *
     * @generated
     */
     @TxMetadata(actionCategory=TCRMControlKeys.UPDATE_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.UPDATE_RECORD_ERROR, 
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.UPDATEXRETAILER_FAILED)
    public DWLResponse updateXRetailer(XRetailerBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER updateXRetailer(XRetailerBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("updateXRetailer", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before transaction updateXRetailer execution";
      logger.finest("updateXRetailer(XRetailerBObj theBObj) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After transaction updateXRetailer execution";
      logger.finest("updateXRetailer(XRetailerBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN updateXRetailer(XRetailerBObj theBObj) " + returnValue);
    }
        return retObj;
    }
    
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction updateXRetailer.
     * 
     * @return DWLResponse containing the added 
     * @throws Exception
     * @see #updateXRetailer
     *
     * @generated
     */
    public DWLResponse handleUpdateXRetailer(XRetailerBObj theBObj) throws Exception {
    logger.finest("ENTER handleUpdateXRetailer(XRetailerBObj theBObj)");
        DWLResponse response = new DWLResponse();
        DSEAAdditionsExts aDSEAAdditionsExtsComponent = (DSEAAdditionsExts) TCRMClassFactory
      .getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
        response = aDSEAAdditionsExtsComponent.updateXRetailer(theBObj);
    logger.finest("RETURN handleUpdateXRetailer(XRetailerBObj theBObj)");
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction handleAddXCustomerRetailer.
     *
     * @return DWLResponse containing the added 
     * @throws DWLBaseException
     * @see #handleaddXCustomerRetailer
     *
     * @ejb.interface-method
     *    view-type="both"
     *
     * @generated
     */
     @TxMetadata(actionCategory=TCRMControlKeys.ADD_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.INSERT_RECORD_ERROR, 
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.ADDXCUSTOMERRETAILER_FAILED)
    public DWLResponse addXCustomerRetailer(XCustomerRetailerBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER addXCustomerRetailer(XCustomerRetailerBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("addXCustomerRetailer", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before transaction addXCustomerRetailer execution";
      logger.finest("addXCustomerRetailer(XCustomerRetailerBObj theBObj) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After transaction addXCustomerRetailer execution";
      logger.finest("addXCustomerRetailer(XCustomerRetailerBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN addXCustomerRetailer(XCustomerRetailerBObj theBObj) " + returnValue);
    }
        return retObj;
    }
    
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction addXCustomerRetailer.
     * 
     * @return DWLResponse containing the added 
     * @throws Exception
     * @see #addXCustomerRetailer
     *
     * @generated
     */
    public DWLResponse handleAddXCustomerRetailer(XCustomerRetailerBObj theBObj) throws Exception {
    logger.finest("ENTER handleAddXCustomerRetailer(XCustomerRetailerBObj theBObj)");
        DWLResponse response = new DWLResponse();
        DSEAAdditionsExts aDSEAAdditionsExtsComponent = (DSEAAdditionsExts) TCRMClassFactory
      .getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
        response = aDSEAAdditionsExtsComponent.addXCustomerRetailer(theBObj);
    logger.finest("RETURN handleAddXCustomerRetailer(XCustomerRetailerBObj theBObj)");
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction
     * handleUpdateXCustomerRetailer.
     *
     * @return DWLResponse containing the added 
     * @throws DWLBaseException
     * @see #handleupdateXCustomerRetailer
     *
     * @ejb.interface-method
     *    view-type="both"
     *
     * @generated
     */
     @TxMetadata(actionCategory=TCRMControlKeys.UPDATE_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.UPDATE_RECORD_ERROR, 
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.UPDATEXCUSTOMERRETAILER_FAILED)
    public DWLResponse updateXCustomerRetailer(XCustomerRetailerBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER updateXCustomerRetailer(XCustomerRetailerBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("updateXCustomerRetailer", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before transaction updateXCustomerRetailer execution";
      logger.finest("updateXCustomerRetailer(XCustomerRetailerBObj theBObj) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After transaction updateXCustomerRetailer execution";
      logger.finest("updateXCustomerRetailer(XCustomerRetailerBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN updateXCustomerRetailer(XCustomerRetailerBObj theBObj) " + returnValue);
    }
        return retObj;
    }
    
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction updateXCustomerRetailer.
     * 
     * @return DWLResponse containing the added 
     * @throws Exception
     * @see #updateXCustomerRetailer
     *
     * @generated
     */
    public DWLResponse handleUpdateXCustomerRetailer(XCustomerRetailerBObj theBObj) throws Exception {
    logger.finest("ENTER handleUpdateXCustomerRetailer(XCustomerRetailerBObj theBObj)");
        DWLResponse response = new DWLResponse();
        DSEAAdditionsExts aDSEAAdditionsExtsComponent = (DSEAAdditionsExts) TCRMClassFactory
      .getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
        response = aDSEAAdditionsExtsComponent.updateXCustomerRetailer(theBObj);
    logger.finest("RETURN handleUpdateXCustomerRetailer(XCustomerRetailerBObj theBObj)");
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction
     * handleAddXCustomerRetailerRole.
     *
     * @return DWLResponse containing the added 
     * @throws DWLBaseException
     * @see #handleaddXCustomerRetailerRole
     *
     * @ejb.interface-method
     *    view-type="both"
     *
     * @generated
     */
     @TxMetadata(actionCategory=TCRMControlKeys.ADD_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.INSERT_RECORD_ERROR, 
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.ADDXCUSTOMERRETAILERROLE_FAILED)
    public DWLResponse addXCustomerRetailerRole(XCustomerRetailerRoleBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER addXCustomerRetailerRole(XCustomerRetailerRoleBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("addXCustomerRetailerRole", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before transaction addXCustomerRetailerRole execution";
      logger.finest("addXCustomerRetailerRole(XCustomerRetailerRoleBObj theBObj) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After transaction addXCustomerRetailerRole execution";
      logger.finest("addXCustomerRetailerRole(XCustomerRetailerRoleBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN addXCustomerRetailerRole(XCustomerRetailerRoleBObj theBObj) " + returnValue);
    }
        return retObj;
    }
    
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction addXCustomerRetailerRole.
     * 
     * @return DWLResponse containing the added 
     * @throws Exception
     * @see #addXCustomerRetailerRole
     *
     * @generated
     */
    public DWLResponse handleAddXCustomerRetailerRole(XCustomerRetailerRoleBObj theBObj) throws Exception {
    logger.finest("ENTER handleAddXCustomerRetailerRole(XCustomerRetailerRoleBObj theBObj)");
        DWLResponse response = new DWLResponse();
        DSEAAdditionsExts aDSEAAdditionsExtsComponent = (DSEAAdditionsExts) TCRMClassFactory
      .getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
        response = aDSEAAdditionsExtsComponent.addXCustomerRetailerRole(theBObj);
    logger.finest("RETURN handleAddXCustomerRetailerRole(XCustomerRetailerRoleBObj theBObj)");
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction
     * handleUpdateXCustomerRetailerRole.
     *
     * @return DWLResponse containing the added 
     * @throws DWLBaseException
     * @see #handleupdateXCustomerRetailerRole
     *
     * @ejb.interface-method
     *    view-type="both"
     *
     * @generated
     */
     @TxMetadata(actionCategory=TCRMControlKeys.UPDATE_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.UPDATE_RECORD_ERROR, 
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.UPDATEXCUSTOMERRETAILERROLE_FAILED)
    public DWLResponse updateXCustomerRetailerRole(XCustomerRetailerRoleBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER updateXCustomerRetailerRole(XCustomerRetailerRoleBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("updateXCustomerRetailerRole", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before transaction updateXCustomerRetailerRole execution";
      logger.finest("updateXCustomerRetailerRole(XCustomerRetailerRoleBObj theBObj) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After transaction updateXCustomerRetailerRole execution";
      logger.finest("updateXCustomerRetailerRole(XCustomerRetailerRoleBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN updateXCustomerRetailerRole(XCustomerRetailerRoleBObj theBObj) " + returnValue);
    }
        return retObj;
    }
    
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction updateXCustomerRetailerRole.
     * 
     * @return DWLResponse containing the added 
     * @throws Exception
     * @see #updateXCustomerRetailerRole
     *
     * @generated
     */
    public DWLResponse handleUpdateXCustomerRetailerRole(XCustomerRetailerRoleBObj theBObj) throws Exception {
    logger.finest("ENTER handleUpdateXCustomerRetailerRole(XCustomerRetailerRoleBObj theBObj)");
        DWLResponse response = new DWLResponse();
        DSEAAdditionsExts aDSEAAdditionsExtsComponent = (DSEAAdditionsExts) TCRMClassFactory
      .getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
        response = aDSEAAdditionsExtsComponent.updateXCustomerRetailerRole(theBObj);
    logger.finest("RETURN handleUpdateXCustomerRetailerRole(XCustomerRetailerRoleBObj theBObj)");
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction handleAddXVehicle.
     *
     * @return DWLResponse containing the added 
     * @throws DWLBaseException
     * @see #handleaddXVehicle
     *
     * @ejb.interface-method
     *    view-type="both"
     *
     * @generated
     */
     @TxMetadata(actionCategory=TCRMControlKeys.ADD_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.INSERT_RECORD_ERROR, 
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.ADDXVEHICLE_FAILED)
    public DWLResponse addXVehicle(XVehicleBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER addXVehicle(XVehicleBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("addXVehicle", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before transaction addXVehicle execution";
      logger.finest("addXVehicle(XVehicleBObj theBObj) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After transaction addXVehicle execution";
      logger.finest("addXVehicle(XVehicleBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN addXVehicle(XVehicleBObj theBObj) " + returnValue);
    }
        return retObj;
    }
    
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction addXVehicle.
     * 
     * @return DWLResponse containing the added 
     * @throws Exception
     * @see #addXVehicle
     *
     * @generated
     */
    public DWLResponse handleAddXVehicle(XVehicleBObj theBObj) throws Exception {
    logger.finest("ENTER handleAddXVehicle(XVehicleBObj theBObj)");
        DWLResponse response = new DWLResponse();
        DSEAAdditionsExts aDSEAAdditionsExtsComponent = (DSEAAdditionsExts) TCRMClassFactory
      .getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
        response = aDSEAAdditionsExtsComponent.addXVehicle(theBObj);
    logger.finest("RETURN handleAddXVehicle(XVehicleBObj theBObj)");
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction handleUpdateXVehicle.
     *
     * @return DWLResponse containing the added 
     * @throws DWLBaseException
     * @see #handleupdateXVehicle
     *
     * @ejb.interface-method
     *    view-type="both"
     *
     * @generated
     */
     @TxMetadata(actionCategory=TCRMControlKeys.UPDATE_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.UPDATE_RECORD_ERROR, 
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.UPDATEXVEHICLE_FAILED)
    public DWLResponse updateXVehicle(XVehicleBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER updateXVehicle(XVehicleBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("updateXVehicle", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before transaction updateXVehicle execution";
      logger.finest("updateXVehicle(XVehicleBObj theBObj) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After transaction updateXVehicle execution";
      logger.finest("updateXVehicle(XVehicleBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN updateXVehicle(XVehicleBObj theBObj) " + returnValue);
    }
        return retObj;
    }
    
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction updateXVehicle.
     * 
     * @return DWLResponse containing the added 
     * @throws Exception
     * @see #updateXVehicle
     *
     * @generated
     */
    public DWLResponse handleUpdateXVehicle(XVehicleBObj theBObj) throws Exception {
    logger.finest("ENTER handleUpdateXVehicle(XVehicleBObj theBObj)");
        DWLResponse response = new DWLResponse();
        DSEAAdditionsExts aDSEAAdditionsExtsComponent = (DSEAAdditionsExts) TCRMClassFactory
      .getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
        response = aDSEAAdditionsExtsComponent.updateXVehicle(theBObj);
    logger.finest("RETURN handleUpdateXVehicle(XVehicleBObj theBObj)");
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction handleAddXCustomerVehicle.
     *
     * @return DWLResponse containing the added 
     * @throws DWLBaseException
     * @see #handleaddXCustomerVehicle
     *
     * @ejb.interface-method
     *    view-type="both"
     *
     * @generated
     */
     @TxMetadata(actionCategory=TCRMControlKeys.ADD_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.INSERT_RECORD_ERROR, 
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.ADDXCUSTOMERVEHICLE_FAILED)
    public DWLResponse addXCustomerVehicle(XCustomerVehicleBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER addXCustomerVehicle(XCustomerVehicleBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("addXCustomerVehicle", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before transaction addXCustomerVehicle execution";
      logger.finest("addXCustomerVehicle(XCustomerVehicleBObj theBObj) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After transaction addXCustomerVehicle execution";
      logger.finest("addXCustomerVehicle(XCustomerVehicleBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN addXCustomerVehicle(XCustomerVehicleBObj theBObj) " + returnValue);
    }
        return retObj;
    }
    
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction addXCustomerVehicle.
     * 
     * @return DWLResponse containing the added 
     * @throws Exception
     * @see #addXCustomerVehicle
     *
     * @generated
     */
    public DWLResponse handleAddXCustomerVehicle(XCustomerVehicleBObj theBObj) throws Exception {
    logger.finest("ENTER handleAddXCustomerVehicle(XCustomerVehicleBObj theBObj)");
        DWLResponse response = new DWLResponse();
        DSEAAdditionsExts aDSEAAdditionsExtsComponent = (DSEAAdditionsExts) TCRMClassFactory
      .getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
        response = aDSEAAdditionsExtsComponent.addXCustomerVehicle(theBObj);
    logger.finest("RETURN handleAddXCustomerVehicle(XCustomerVehicleBObj theBObj)");
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction handleUpdateXCustomerVehicle.
     *
     * @return DWLResponse containing the added 
     * @throws DWLBaseException
     * @see #handleupdateXCustomerVehicle
     *
     * @ejb.interface-method
     *    view-type="both"
     *
     * @generated
     */
     @TxMetadata(actionCategory=TCRMControlKeys.UPDATE_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.UPDATE_RECORD_ERROR, 
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.UPDATEXCUSTOMERVEHICLE_FAILED)
    public DWLResponse updateXCustomerVehicle(XCustomerVehicleBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER updateXCustomerVehicle(XCustomerVehicleBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("updateXCustomerVehicle", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before transaction updateXCustomerVehicle execution";
      logger.finest("updateXCustomerVehicle(XCustomerVehicleBObj theBObj) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After transaction updateXCustomerVehicle execution";
      logger.finest("updateXCustomerVehicle(XCustomerVehicleBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN updateXCustomerVehicle(XCustomerVehicleBObj theBObj) " + returnValue);
    }
        return retObj;
    }
    
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction updateXCustomerVehicle.
     * 
     * @return DWLResponse containing the added 
     * @throws Exception
     * @see #updateXCustomerVehicle
     *
     * @generated
     */
    public DWLResponse handleUpdateXCustomerVehicle(XCustomerVehicleBObj theBObj) throws Exception {
    logger.finest("ENTER handleUpdateXCustomerVehicle(XCustomerVehicleBObj theBObj)");
        DWLResponse response = new DWLResponse();
        DSEAAdditionsExts aDSEAAdditionsExtsComponent = (DSEAAdditionsExts) TCRMClassFactory
      .getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
        response = aDSEAAdditionsExtsComponent.updateXCustomerVehicle(theBObj);
    logger.finest("RETURN handleUpdateXCustomerVehicle(XCustomerVehicleBObj theBObj)");
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction
     * handleAddXCustomerVehicleRole.
     *
     * @return DWLResponse containing the added 
     * @throws DWLBaseException
     * @see #handleaddXCustomerVehicleRole
     *
     * @ejb.interface-method
     *    view-type="both"
     *
     * @generated
     */
     @TxMetadata(actionCategory=TCRMControlKeys.ADD_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.INSERT_RECORD_ERROR, 
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.ADDXCUSTOMERVEHICLEROLE_FAILED)
    public DWLResponse addXCustomerVehicleRole(XCustomerVehicleRoleBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER addXCustomerVehicleRole(XCustomerVehicleRoleBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("addXCustomerVehicleRole", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before transaction addXCustomerVehicleRole execution";
      logger.finest("addXCustomerVehicleRole(XCustomerVehicleRoleBObj theBObj) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After transaction addXCustomerVehicleRole execution";
      logger.finest("addXCustomerVehicleRole(XCustomerVehicleRoleBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN addXCustomerVehicleRole(XCustomerVehicleRoleBObj theBObj) " + returnValue);
    }
        return retObj;
    }
    
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction addXCustomerVehicleRole.
     * 
     * @return DWLResponse containing the added 
     * @throws Exception
     * @see #addXCustomerVehicleRole
     *
     * @generated
     */
    public DWLResponse handleAddXCustomerVehicleRole(XCustomerVehicleRoleBObj theBObj) throws Exception {
    logger.finest("ENTER handleAddXCustomerVehicleRole(XCustomerVehicleRoleBObj theBObj)");
        DWLResponse response = new DWLResponse();
        DSEAAdditionsExts aDSEAAdditionsExtsComponent = (DSEAAdditionsExts) TCRMClassFactory
      .getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
        response = aDSEAAdditionsExtsComponent.addXCustomerVehicleRole(theBObj);
    logger.finest("RETURN handleAddXCustomerVehicleRole(XCustomerVehicleRoleBObj theBObj)");
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction
     * handleUpdateXCustomerVehicleRole.
     *
     * @return DWLResponse containing the added 
     * @throws DWLBaseException
     * @see #handleupdateXCustomerVehicleRole
     *
     * @ejb.interface-method
     *    view-type="both"
     *
     * @generated
     */
     @TxMetadata(actionCategory=TCRMControlKeys.UPDATE_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.UPDATE_RECORD_ERROR, 
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.UPDATEXCUSTOMERVEHICLEROLE_FAILED)
    public DWLResponse updateXCustomerVehicleRole(XCustomerVehicleRoleBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER updateXCustomerVehicleRole(XCustomerVehicleRoleBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("updateXCustomerVehicleRole", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before transaction updateXCustomerVehicleRole execution";
      logger.finest("updateXCustomerVehicleRole(XCustomerVehicleRoleBObj theBObj) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After transaction updateXCustomerVehicleRole execution";
      logger.finest("updateXCustomerVehicleRole(XCustomerVehicleRoleBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN updateXCustomerVehicleRole(XCustomerVehicleRoleBObj theBObj) " + returnValue);
    }
        return retObj;
    }
    
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction updateXCustomerVehicleRole.
     * 
     * @return DWLResponse containing the added 
     * @throws Exception
     * @see #updateXCustomerVehicleRole
     *
     * @generated
     */
    public DWLResponse handleUpdateXCustomerVehicleRole(XCustomerVehicleRoleBObj theBObj) throws Exception {
    logger.finest("ENTER handleUpdateXCustomerVehicleRole(XCustomerVehicleRoleBObj theBObj)");
        DWLResponse response = new DWLResponse();
        DSEAAdditionsExts aDSEAAdditionsExtsComponent = (DSEAAdditionsExts) TCRMClassFactory
      .getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
        response = aDSEAAdditionsExtsComponent.updateXCustomerVehicleRole(theBObj);
    logger.finest("RETURN handleUpdateXCustomerVehicleRole(XCustomerVehicleRoleBObj theBObj)");
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction
     * handleAddXCompanyIdentification.
     *
     * @return DWLResponse containing the added 
     * @throws DWLBaseException
     * @see #handleaddXCompanyIdentification
     *
     * @ejb.interface-method
     *    view-type="both"
     *
     * @generated
     */
     @TxMetadata(actionCategory=TCRMControlKeys.ADD_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.INSERT_RECORD_ERROR, 
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.ADDXCOMPANYIDENTIFICATION_FAILED)
    public DWLResponse addXCompanyIdentification(XCompanyIdentificationBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER addXCompanyIdentification(XCompanyIdentificationBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("addXCompanyIdentification", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before transaction addXCompanyIdentification execution";
      logger.finest("addXCompanyIdentification(XCompanyIdentificationBObj theBObj) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After transaction addXCompanyIdentification execution";
      logger.finest("addXCompanyIdentification(XCompanyIdentificationBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN addXCompanyIdentification(XCompanyIdentificationBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction addXCompanyIdentification.
     * 
     * @return DWLResponse containing the added 
     * @throws Exception
     * @see #addXCompanyIdentification
     *
     * @generated
     */
    public DWLResponse handleAddXCompanyIdentification(XCompanyIdentificationBObj theBObj) throws Exception {
    logger.finest("ENTER handleAddXCompanyIdentification(XCompanyIdentificationBObj theBObj)");
        DWLResponse response = new DWLResponse();
        DSEAAdditionsExts aDSEAAdditionsExtsComponent = (DSEAAdditionsExts) TCRMClassFactory
      .getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
        response = aDSEAAdditionsExtsComponent.addXCompanyIdentification(theBObj);
    logger.finest("RETURN handleAddXCompanyIdentification(XCompanyIdentificationBObj theBObj)");
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction
     * handleUpdateXCompanyIdentification.
     *
     * @return DWLResponse containing the added 
     * @throws DWLBaseException
     * @see #handleupdateXCompanyIdentification
     *
     * @ejb.interface-method
     *    view-type="both"
     *
     * @generated
     */
     @TxMetadata(actionCategory=TCRMControlKeys.UPDATE_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.UPDATE_RECORD_ERROR, 
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.UPDATEXCOMPANYIDENTIFICATION_FAILED)
    public DWLResponse updateXCompanyIdentification(XCompanyIdentificationBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER updateXCompanyIdentification(XCompanyIdentificationBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("updateXCompanyIdentification", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before transaction updateXCompanyIdentification execution";
      logger.finest("updateXCompanyIdentification(XCompanyIdentificationBObj theBObj) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After transaction updateXCompanyIdentification execution";
      logger.finest("updateXCompanyIdentification(XCompanyIdentificationBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN updateXCompanyIdentification(XCompanyIdentificationBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction updateXCompanyIdentification.
     * 
     * @return DWLResponse containing the added 
     * @throws Exception
     * @see #updateXCompanyIdentification
     *
     * @generated
     */
    public DWLResponse handleUpdateXCompanyIdentification(XCompanyIdentificationBObj theBObj) throws Exception {
    logger.finest("ENTER handleUpdateXCompanyIdentification(XCompanyIdentificationBObj theBObj)");
        DWLResponse response = new DWLResponse();
        DSEAAdditionsExts aDSEAAdditionsExtsComponent = (DSEAAdditionsExts) TCRMClassFactory
      .getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
        response = aDSEAAdditionsExtsComponent.updateXCompanyIdentification(theBObj);
    logger.finest("RETURN handleUpdateXCompanyIdentification(XCompanyIdentificationBObj theBObj)");
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction handleAddXContractDetails.
     *
     * @return DWLResponse containing the added 
     * @throws DWLBaseException
     * @see #handleaddXContractDetails
     *
     * @ejb.interface-method
     *    view-type="both"
     *
     * @generated
     */
     @TxMetadata(actionCategory=TCRMControlKeys.ADD_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.INSERT_RECORD_ERROR, 
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.ADDXCONTRACTDETAILS_FAILED)
    public DWLResponse addXContractDetails(XContractDetailsBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER addXContractDetails(XContractDetailsBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("addXContractDetails", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before transaction addXContractDetails execution";
      logger.finest("addXContractDetails(XContractDetailsBObj theBObj) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After transaction addXContractDetails execution";
      logger.finest("addXContractDetails(XContractDetailsBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN addXContractDetails(XContractDetailsBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction addXContractDetails.
     * 
     * @return DWLResponse containing the added 
     * @throws Exception
     * @see #addXContractDetails
     *
     * @generated
     */
    public DWLResponse handleAddXContractDetails(XContractDetailsBObj theBObj) throws Exception {
    logger.finest("ENTER handleAddXContractDetails(XContractDetailsBObj theBObj)");
        DWLResponse response = new DWLResponse();
        DSEAAdditionsExts aDSEAAdditionsExtsComponent = (DSEAAdditionsExts) TCRMClassFactory
      .getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
        response = aDSEAAdditionsExtsComponent.addXContractDetails(theBObj);
    logger.finest("RETURN handleAddXContractDetails(XContractDetailsBObj theBObj)");
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction handleUpdateXContractDetails.
     *
     * @return DWLResponse containing the added 
     * @throws DWLBaseException
     * @see #handleupdateXContractDetails
     *
     * @ejb.interface-method
     *    view-type="both"
     *
     * @generated
     */
     @TxMetadata(actionCategory=TCRMControlKeys.UPDATE_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.UPDATE_RECORD_ERROR, 
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.UPDATEXCONTRACTDETAILS_FAILED)
    public DWLResponse updateXContractDetails(XContractDetailsBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER updateXContractDetails(XContractDetailsBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("updateXContractDetails", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before transaction updateXContractDetails execution";
      logger.finest("updateXContractDetails(XContractDetailsBObj theBObj) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After transaction updateXContractDetails execution";
      logger.finest("updateXContractDetails(XContractDetailsBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN updateXContractDetails(XContractDetailsBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction updateXContractDetails.
     * 
     * @return DWLResponse containing the added 
     * @throws Exception
     * @see #updateXContractDetails
     *
     * @generated
     */
    public DWLResponse handleUpdateXContractDetails(XContractDetailsBObj theBObj) throws Exception {
    logger.finest("ENTER handleUpdateXContractDetails(XContractDetailsBObj theBObj)");
        DWLResponse response = new DWLResponse();
        DSEAAdditionsExts aDSEAAdditionsExtsComponent = (DSEAAdditionsExts) TCRMClassFactory
      .getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
        response = aDSEAAdditionsExtsComponent.updateXContractDetails(theBObj);
    logger.finest("RETURN handleUpdateXContractDetails(XContractDetailsBObj theBObj)");
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction handleAddXGurantorIndividual.
     *
     * @return DWLResponse containing the added 
     * @throws DWLBaseException
     * @see #handleaddXGurantorIndividual
     *
     * @ejb.interface-method
     *    view-type="both"
     *
     * @generated
     */
     @TxMetadata(actionCategory=TCRMControlKeys.ADD_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.INSERT_RECORD_ERROR, 
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.ADDXGURANTORINDIVIDUAL_FAILED)
    public DWLResponse addXGurantorIndividual(XGurantorIndividualBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER addXGurantorIndividual(XGurantorIndividualBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("addXGurantorIndividual", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before transaction addXGurantorIndividual execution";
      logger.finest("addXGurantorIndividual(XGurantorIndividualBObj theBObj) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After transaction addXGurantorIndividual execution";
      logger.finest("addXGurantorIndividual(XGurantorIndividualBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN addXGurantorIndividual(XGurantorIndividualBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction addXGurantorIndividual.
     * 
     * @return DWLResponse containing the added 
     * @throws Exception
     * @see #addXGurantorIndividual
     *
     * @generated
     */
    public DWLResponse handleAddXGurantorIndividual(XGurantorIndividualBObj theBObj) throws Exception {
    logger.finest("ENTER handleAddXGurantorIndividual(XGurantorIndividualBObj theBObj)");
        DWLResponse response = new DWLResponse();
        DSEAAdditionsExts aDSEAAdditionsExtsComponent = (DSEAAdditionsExts) TCRMClassFactory
      .getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
        response = aDSEAAdditionsExtsComponent.addXGurantorIndividual(theBObj);
    logger.finest("RETURN handleAddXGurantorIndividual(XGurantorIndividualBObj theBObj)");
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction
     * handleUpdateXGurantorIndividual.
     *
     * @return DWLResponse containing the added 
     * @throws DWLBaseException
     * @see #handleupdateXGurantorIndividual
     *
     * @ejb.interface-method
     *    view-type="both"
     *
     * @generated
     */
     @TxMetadata(actionCategory=TCRMControlKeys.UPDATE_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.UPDATE_RECORD_ERROR, 
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.UPDATEXGURANTORINDIVIDUAL_FAILED)
    public DWLResponse updateXGurantorIndividual(XGurantorIndividualBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER updateXGurantorIndividual(XGurantorIndividualBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("updateXGurantorIndividual", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before transaction updateXGurantorIndividual execution";
      logger.finest("updateXGurantorIndividual(XGurantorIndividualBObj theBObj) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After transaction updateXGurantorIndividual execution";
      logger.finest("updateXGurantorIndividual(XGurantorIndividualBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN updateXGurantorIndividual(XGurantorIndividualBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction updateXGurantorIndividual.
     * 
     * @return DWLResponse containing the added 
     * @throws Exception
     * @see #updateXGurantorIndividual
     *
     * @generated
     */
    public DWLResponse handleUpdateXGurantorIndividual(XGurantorIndividualBObj theBObj) throws Exception {
    logger.finest("ENTER handleUpdateXGurantorIndividual(XGurantorIndividualBObj theBObj)");
        DWLResponse response = new DWLResponse();
        DSEAAdditionsExts aDSEAAdditionsExtsComponent = (DSEAAdditionsExts) TCRMClassFactory
      .getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
        response = aDSEAAdditionsExtsComponent.updateXGurantorIndividual(theBObj);
    logger.finest("RETURN handleUpdateXGurantorIndividual(XGurantorIndividualBObj theBObj)");
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction handleAddXGurantorCompany.
     *
     * @return DWLResponse containing the added 
     * @throws DWLBaseException
     * @see #handleaddXGurantorCompany
     *
     * @ejb.interface-method
     *    view-type="both"
     *
     * @generated
     */
     @TxMetadata(actionCategory=TCRMControlKeys.ADD_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.INSERT_RECORD_ERROR, 
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.ADDXGURANTORCOMPANY_FAILED)
    public DWLResponse addXGurantorCompany(XGurantorCompanyBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER addXGurantorCompany(XGurantorCompanyBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("addXGurantorCompany", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before transaction addXGurantorCompany execution";
      logger.finest("addXGurantorCompany(XGurantorCompanyBObj theBObj) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After transaction addXGurantorCompany execution";
      logger.finest("addXGurantorCompany(XGurantorCompanyBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN addXGurantorCompany(XGurantorCompanyBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction addXGurantorCompany.
     * 
     * @return DWLResponse containing the added 
     * @throws Exception
     * @see #addXGurantorCompany
     *
     * @generated
     */
    public DWLResponse handleAddXGurantorCompany(XGurantorCompanyBObj theBObj) throws Exception {
    logger.finest("ENTER handleAddXGurantorCompany(XGurantorCompanyBObj theBObj)");
        DWLResponse response = new DWLResponse();
        DSEAAdditionsExts aDSEAAdditionsExtsComponent = (DSEAAdditionsExts) TCRMClassFactory
      .getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
        response = aDSEAAdditionsExtsComponent.addXGurantorCompany(theBObj);
    logger.finest("RETURN handleAddXGurantorCompany(XGurantorCompanyBObj theBObj)");
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction handleUpdateXGurantorCompany.
     *
     * @return DWLResponse containing the added 
     * @throws DWLBaseException
     * @see #handleupdateXGurantorCompany
     *
     * @ejb.interface-method
     *    view-type="both"
     *
     * @generated
     */
     @TxMetadata(actionCategory=TCRMControlKeys.UPDATE_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.UPDATE_RECORD_ERROR, 
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.UPDATEXGURANTORCOMPANY_FAILED)
    public DWLResponse updateXGurantorCompany(XGurantorCompanyBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER updateXGurantorCompany(XGurantorCompanyBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("updateXGurantorCompany", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before transaction updateXGurantorCompany execution";
      logger.finest("updateXGurantorCompany(XGurantorCompanyBObj theBObj) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After transaction updateXGurantorCompany execution";
      logger.finest("updateXGurantorCompany(XGurantorCompanyBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN updateXGurantorCompany(XGurantorCompanyBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction updateXGurantorCompany.
     * 
     * @return DWLResponse containing the added 
     * @throws Exception
     * @see #updateXGurantorCompany
     *
     * @generated
     */
    public DWLResponse handleUpdateXGurantorCompany(XGurantorCompanyBObj theBObj) throws Exception {
    logger.finest("ENTER handleUpdateXGurantorCompany(XGurantorCompanyBObj theBObj)");
        DWLResponse response = new DWLResponse();
        DSEAAdditionsExts aDSEAAdditionsExtsComponent = (DSEAAdditionsExts) TCRMClassFactory
      .getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
        response = aDSEAAdditionsExtsComponent.updateXGurantorCompany(theBObj);
    logger.finest("RETURN handleUpdateXGurantorCompany(XGurantorCompanyBObj theBObj)");
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction handleAddXDealerRetailer.
     *
     * @return DWLResponse containing the added 
     * @throws DWLBaseException
     * @see #handleaddXDealerRetailer
     *
     * @ejb.interface-method
     *    view-type="both"
     *
     * @generated
     */
     @TxMetadata(actionCategory=TCRMControlKeys.ADD_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.INSERT_RECORD_ERROR, 
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.ADDXDEALERRETAILER_FAILED)
    public DWLResponse addXDealerRetailer(XDealerRetailerBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER addXDealerRetailer(XDealerRetailerBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("addXDealerRetailer", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before transaction addXDealerRetailer execution";
      logger.finest("addXDealerRetailer(XDealerRetailerBObj theBObj) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After transaction addXDealerRetailer execution";
      logger.finest("addXDealerRetailer(XDealerRetailerBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN addXDealerRetailer(XDealerRetailerBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction addXDealerRetailer.
     * 
     * @return DWLResponse containing the added 
     * @throws Exception
     * @see #addXDealerRetailer
     *
     * @generated
     */
    public DWLResponse handleAddXDealerRetailer(XDealerRetailerBObj theBObj) throws Exception {
    logger.finest("ENTER handleAddXDealerRetailer(XDealerRetailerBObj theBObj)");
        DWLResponse response = new DWLResponse();
        DSEAAdditionsExts aDSEAAdditionsExtsComponent = (DSEAAdditionsExts) TCRMClassFactory
      .getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
        response = aDSEAAdditionsExtsComponent.addXDealerRetailer(theBObj);
    logger.finest("RETURN handleAddXDealerRetailer(XDealerRetailerBObj theBObj)");
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction handleUpdateXDealerRetailer.
     *
     * @return DWLResponse containing the added 
     * @throws DWLBaseException
     * @see #handleupdateXDealerRetailer
     *
     * @ejb.interface-method
     *    view-type="both"
     *
     * @generated
     */
     @TxMetadata(actionCategory=TCRMControlKeys.UPDATE_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.UPDATE_RECORD_ERROR, 
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.UPDATEXDEALERRETAILER_FAILED)
    public DWLResponse updateXDealerRetailer(XDealerRetailerBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER updateXDealerRetailer(XDealerRetailerBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("updateXDealerRetailer", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before transaction updateXDealerRetailer execution";
      logger.finest("updateXDealerRetailer(XDealerRetailerBObj theBObj) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After transaction updateXDealerRetailer execution";
      logger.finest("updateXDealerRetailer(XDealerRetailerBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN updateXDealerRetailer(XDealerRetailerBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction updateXDealerRetailer.
     * 
     * @return DWLResponse containing the added 
     * @throws Exception
     * @see #updateXDealerRetailer
     *
     * @generated
     */
    public DWLResponse handleUpdateXDealerRetailer(XDealerRetailerBObj theBObj) throws Exception {
    logger.finest("ENTER handleUpdateXDealerRetailer(XDealerRetailerBObj theBObj)");
        DWLResponse response = new DWLResponse();
        DSEAAdditionsExts aDSEAAdditionsExtsComponent = (DSEAAdditionsExts) TCRMClassFactory
      .getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
        response = aDSEAAdditionsExtsComponent.updateXDealerRetailer(theBObj);
    logger.finest("RETURN handleUpdateXDealerRetailer(XDealerRetailerBObj theBObj)");
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction handleAddXMagicRel.
     *
     * @return DWLResponse containing the added 
     * @throws DWLBaseException
     * @see #handleaddXMagicRel
     *
     * @ejb.interface-method
     *    view-type="both"
     *
     * @generated
     */
     @TxMetadata(actionCategory=TCRMControlKeys.ADD_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.INSERT_RECORD_ERROR, 
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.ADDXMAGICREL_FAILED)
    public DWLResponse addXMagicRel(XMagicRelBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER addXMagicRel(XMagicRelBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("addXMagicRel", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before transaction addXMagicRel execution";
      logger.finest("addXMagicRel(XMagicRelBObj theBObj) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After transaction addXMagicRel execution";
      logger.finest("addXMagicRel(XMagicRelBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN addXMagicRel(XMagicRelBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction addXMagicRel.
     * 
     * @return DWLResponse containing the added 
     * @throws Exception
     * @see #addXMagicRel
     *
     * @generated
     */
    public DWLResponse handleAddXMagicRel(XMagicRelBObj theBObj) throws Exception {
    logger.finest("ENTER handleAddXMagicRel(XMagicRelBObj theBObj)");
        DWLResponse response = new DWLResponse();
        DSEAAdditionsExts aDSEAAdditionsExtsComponent = (DSEAAdditionsExts) TCRMClassFactory
      .getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
        response = aDSEAAdditionsExtsComponent.addXMagicRel(theBObj);
    logger.finest("RETURN handleAddXMagicRel(XMagicRelBObj theBObj)");
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction handleUpdateXMagicRel.
     *
     * @return DWLResponse containing the added 
     * @throws DWLBaseException
     * @see #handleupdateXMagicRel
     *
     * @ejb.interface-method
     *    view-type="both"
     *
     * @generated
     */
     @TxMetadata(actionCategory=TCRMControlKeys.UPDATE_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.UPDATE_RECORD_ERROR, 
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.UPDATEXMAGICREL_FAILED)
    public DWLResponse updateXMagicRel(XMagicRelBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER updateXMagicRel(XMagicRelBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("updateXMagicRel", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before transaction updateXMagicRel execution";
      logger.finest("updateXMagicRel(XMagicRelBObj theBObj) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After transaction updateXMagicRel execution";
      logger.finest("updateXMagicRel(XMagicRelBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN updateXMagicRel(XMagicRelBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction updateXMagicRel.
     * 
     * @return DWLResponse containing the added 
     * @throws Exception
     * @see #updateXMagicRel
     *
     * @generated
     */
    public DWLResponse handleUpdateXMagicRel(XMagicRelBObj theBObj) throws Exception {
    logger.finest("ENTER handleUpdateXMagicRel(XMagicRelBObj theBObj)");
        DWLResponse response = new DWLResponse();
        DSEAAdditionsExts aDSEAAdditionsExtsComponent = (DSEAAdditionsExts) TCRMClassFactory
      .getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
        response = aDSEAAdditionsExtsComponent.updateXMagicRel(theBObj);
    logger.finest("RETURN handleUpdateXMagicRel(XMagicRelBObj theBObj)");
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction handleAddXConsent.
     *
     * @return DWLResponse containing the added 
     * @throws DWLBaseException
     * @see #handleaddXConsent
     *
     * @ejb.interface-method
     *    view-type="both"
     *
     * @generated
     */
     @TxMetadata(actionCategory=TCRMControlKeys.ADD_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.INSERT_RECORD_ERROR, 
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.ADDXCONSENT_FAILED)
    public DWLResponse addXConsent(XConsentBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER addXConsent(XConsentBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("addXConsent", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before transaction addXConsent execution";
      logger.finest("addXConsent(XConsentBObj theBObj) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After transaction addXConsent execution";
      logger.finest("addXConsent(XConsentBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN addXConsent(XConsentBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction addXConsent.
     * 
     * @return DWLResponse containing the added 
     * @throws Exception
     * @see #addXConsent
     *
     * @generated
     */
    public DWLResponse handleAddXConsent(XConsentBObj theBObj) throws Exception {
    logger.finest("ENTER handleAddXConsent(XConsentBObj theBObj)");
        DWLResponse response = new DWLResponse();
        DSEAAdditionsExts aDSEAAdditionsExtsComponent = (DSEAAdditionsExts) TCRMClassFactory
      .getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
        response = aDSEAAdditionsExtsComponent.addXConsent(theBObj);
    logger.finest("RETURN handleAddXConsent(XConsentBObj theBObj)");
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction handleUpdateXConsent.
     *
     * @return DWLResponse containing the added 
     * @throws DWLBaseException
     * @see #handleupdateXConsent
     *
     * @ejb.interface-method
     *    view-type="both"
     *
     * @generated
     */
     @TxMetadata(actionCategory=TCRMControlKeys.UPDATE_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.UPDATE_RECORD_ERROR, 
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.UPDATEXCONSENT_FAILED)
    public DWLResponse updateXConsent(XConsentBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER updateXConsent(XConsentBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("updateXConsent", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before transaction updateXConsent execution";
      logger.finest("updateXConsent(XConsentBObj theBObj) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After transaction updateXConsent execution";
      logger.finest("updateXConsent(XConsentBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN updateXConsent(XConsentBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction updateXConsent.
     * 
     * @return DWLResponse containing the added 
     * @throws Exception
     * @see #updateXConsent
     *
     * @generated
     */
    public DWLResponse handleUpdateXConsent(XConsentBObj theBObj) throws Exception {
    logger.finest("ENTER handleUpdateXConsent(XConsentBObj theBObj)");
        DWLResponse response = new DWLResponse();
        DSEAAdditionsExts aDSEAAdditionsExtsComponent = (DSEAAdditionsExts) TCRMClassFactory
      .getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
        response = aDSEAAdditionsExtsComponent.updateXConsent(theBObj);
    logger.finest("RETURN handleUpdateXConsent(XConsentBObj theBObj)");
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction handleAddXContractRel.
     *
     * @return DWLResponse containing the added 
     * @throws DWLBaseException
     * @see #handleaddXContractRel
     *
     * @ejb.interface-method
     *    view-type="both"
     *
     * @generated
     */
     @TxMetadata(actionCategory=TCRMControlKeys.ADD_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.INSERT_RECORD_ERROR, 
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.ADDXCONTRACTREL_FAILED)
    public DWLResponse addXContractRel(XContractRelBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER addXContractRel(XContractRelBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("addXContractRel", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before transaction addXContractRel execution";
      logger.finest("addXContractRel(XContractRelBObj theBObj) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After transaction addXContractRel execution";
      logger.finest("addXContractRel(XContractRelBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN addXContractRel(XContractRelBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction addXContractRel.
     * 
     * @return DWLResponse containing the added 
     * @throws Exception
     * @see #addXContractRel
     *
     * @generated
     */
    public DWLResponse handleAddXContractRel(XContractRelBObj theBObj) throws Exception {
    logger.finest("ENTER handleAddXContractRel(XContractRelBObj theBObj)");
        DWLResponse response = new DWLResponse();
        DSEAAdditionsExts aDSEAAdditionsExtsComponent = (DSEAAdditionsExts) TCRMClassFactory
      .getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
        response = aDSEAAdditionsExtsComponent.addXContractRel(theBObj);
    logger.finest("RETURN handleAddXContractRel(XContractRelBObj theBObj)");
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction handleUpdateXContractRel.
     *
     * @return DWLResponse containing the added 
     * @throws DWLBaseException
     * @see #handleupdateXContractRel
     *
     * @ejb.interface-method
     *    view-type="both"
     *
     * @generated
     */
     @TxMetadata(actionCategory=TCRMControlKeys.UPDATE_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.UPDATE_RECORD_ERROR, 
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.UPDATEXCONTRACTREL_FAILED)
    public DWLResponse updateXContractRel(XContractRelBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER updateXContractRel(XContractRelBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("updateXContractRel", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before transaction updateXContractRel execution";
      logger.finest("updateXContractRel(XContractRelBObj theBObj) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After transaction updateXContractRel execution";
      logger.finest("updateXContractRel(XContractRelBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN updateXContractRel(XContractRelBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction updateXContractRel.
     * 
     * @return DWLResponse containing the added 
     * @throws Exception
     * @see #updateXContractRel
     *
     * @generated
     */
    public DWLResponse handleUpdateXContractRel(XContractRelBObj theBObj) throws Exception {
    logger.finest("ENTER handleUpdateXContractRel(XContractRelBObj theBObj)");
        DWLResponse response = new DWLResponse();
        DSEAAdditionsExts aDSEAAdditionsExtsComponent = (DSEAAdditionsExts) TCRMClassFactory
      .getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
        response = aDSEAAdditionsExtsComponent.updateXContractRel(theBObj);
    logger.finest("RETURN handleUpdateXContractRel(XContractRelBObj theBObj)");
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction
     * handleAddXCustomerRetailerJPN.
     *
     * @return DWLResponse containing the added 
     * @throws DWLBaseException
     * @see #handleaddXCustomerRetailerJPN
     *
     * @ejb.interface-method
     *    view-type="both"
     *
     * @generated
     */
     @TxMetadata(actionCategory=TCRMControlKeys.ADD_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.INSERT_RECORD_ERROR, 
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.ADDXCUSTOMERRETAILERJPN_FAILED)
    public DWLResponse addXCustomerRetailerJPN(XCustomerRetailerJPNBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER addXCustomerRetailerJPN(XCustomerRetailerJPNBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("addXCustomerRetailerJPN", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before transaction addXCustomerRetailerJPN execution";
      logger.finest("addXCustomerRetailerJPN(XCustomerRetailerJPNBObj theBObj) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After transaction addXCustomerRetailerJPN execution";
      logger.finest("addXCustomerRetailerJPN(XCustomerRetailerJPNBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN addXCustomerRetailerJPN(XCustomerRetailerJPNBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction addXCustomerRetailerJPN.
     * 
     * @return DWLResponse containing the added 
     * @throws Exception
     * @see #addXCustomerRetailerJPN
     *
     * @generated
     */
    public DWLResponse handleAddXCustomerRetailerJPN(XCustomerRetailerJPNBObj theBObj) throws Exception {
    logger.finest("ENTER handleAddXCustomerRetailerJPN(XCustomerRetailerJPNBObj theBObj)");
        DWLResponse response = new DWLResponse();
        DSEAAdditionsExts aDSEAAdditionsExtsComponent = (DSEAAdditionsExts) TCRMClassFactory
      .getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
        response = aDSEAAdditionsExtsComponent.addXCustomerRetailerJPN(theBObj);
    logger.finest("RETURN handleAddXCustomerRetailerJPN(XCustomerRetailerJPNBObj theBObj)");
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction
     * handleUpdateXCustomerRetailerJPN.
     *
     * @return DWLResponse containing the added 
     * @throws DWLBaseException
     * @see #handleupdateXCustomerRetailerJPN
     *
     * @ejb.interface-method
     *    view-type="both"
     *
     * @generated
     */
     @TxMetadata(actionCategory=TCRMControlKeys.UPDATE_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.UPDATE_RECORD_ERROR, 
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.UPDATEXCUSTOMERRETAILERJPN_FAILED)
    public DWLResponse updateXCustomerRetailerJPN(XCustomerRetailerJPNBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER updateXCustomerRetailerJPN(XCustomerRetailerJPNBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("updateXCustomerRetailerJPN", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before transaction updateXCustomerRetailerJPN execution";
      logger.finest("updateXCustomerRetailerJPN(XCustomerRetailerJPNBObj theBObj) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After transaction updateXCustomerRetailerJPN execution";
      logger.finest("updateXCustomerRetailerJPN(XCustomerRetailerJPNBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN updateXCustomerRetailerJPN(XCustomerRetailerJPNBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction updateXCustomerRetailerJPN.
     * 
     * @return DWLResponse containing the added 
     * @throws Exception
     * @see #updateXCustomerRetailerJPN
     *
     * @generated
     */
    public DWLResponse handleUpdateXCustomerRetailerJPN(XCustomerRetailerJPNBObj theBObj) throws Exception {
    logger.finest("ENTER handleUpdateXCustomerRetailerJPN(XCustomerRetailerJPNBObj theBObj)");
        DWLResponse response = new DWLResponse();
        DSEAAdditionsExts aDSEAAdditionsExtsComponent = (DSEAAdditionsExts) TCRMClassFactory
      .getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
        response = aDSEAAdditionsExtsComponent.updateXCustomerRetailerJPN(theBObj);
    logger.finest("RETURN handleUpdateXCustomerRetailerJPN(XCustomerRetailerJPNBObj theBObj)");
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction handleAddXVehicleJPN.
     *
     * @return DWLResponse containing the added 
     * @throws DWLBaseException
     * @see #handleaddXVehicleJPN
     *
     * @ejb.interface-method
     *    view-type="both"
     *
     * @generated
     */
     @TxMetadata(actionCategory=TCRMControlKeys.ADD_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.INSERT_RECORD_ERROR, 
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.ADDXVEHICLEJPN_FAILED)
    public DWLResponse addXVehicleJPN(XVehicleJPNBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER addXVehicleJPN(XVehicleJPNBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("addXVehicleJPN", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before transaction addXVehicleJPN execution";
      logger.finest("addXVehicleJPN(XVehicleJPNBObj theBObj) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After transaction addXVehicleJPN execution";
      logger.finest("addXVehicleJPN(XVehicleJPNBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN addXVehicleJPN(XVehicleJPNBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction addXVehicleJPN.
     * 
     * @return DWLResponse containing the added 
     * @throws Exception
     * @see #addXVehicleJPN
     *
     * @generated
     */
    public DWLResponse handleAddXVehicleJPN(XVehicleJPNBObj theBObj) throws Exception {
    logger.finest("ENTER handleAddXVehicleJPN(XVehicleJPNBObj theBObj)");
        DWLResponse response = new DWLResponse();
        DSEAAdditionsExts aDSEAAdditionsExtsComponent = (DSEAAdditionsExts) TCRMClassFactory
      .getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
        response = aDSEAAdditionsExtsComponent.addXVehicleJPN(theBObj);
    logger.finest("RETURN handleAddXVehicleJPN(XVehicleJPNBObj theBObj)");
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction handleUpdateXVehicleJPN.
     *
     * @return DWLResponse containing the added 
     * @throws DWLBaseException
     * @see #handleupdateXVehicleJPN
     *
     * @ejb.interface-method
     *    view-type="both"
     *
     * @generated
     */
     @TxMetadata(actionCategory=TCRMControlKeys.UPDATE_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.UPDATE_RECORD_ERROR, 
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.UPDATEXVEHICLEJPN_FAILED)
    public DWLResponse updateXVehicleJPN(XVehicleJPNBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER updateXVehicleJPN(XVehicleJPNBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("updateXVehicleJPN", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before transaction updateXVehicleJPN execution";
      logger.finest("updateXVehicleJPN(XVehicleJPNBObj theBObj) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After transaction updateXVehicleJPN execution";
      logger.finest("updateXVehicleJPN(XVehicleJPNBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN updateXVehicleJPN(XVehicleJPNBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction updateXVehicleJPN.
     * 
     * @return DWLResponse containing the added 
     * @throws Exception
     * @see #updateXVehicleJPN
     *
     * @generated
     */
    public DWLResponse handleUpdateXVehicleJPN(XVehicleJPNBObj theBObj) throws Exception {
    logger.finest("ENTER handleUpdateXVehicleJPN(XVehicleJPNBObj theBObj)");
        DWLResponse response = new DWLResponse();
        DSEAAdditionsExts aDSEAAdditionsExtsComponent = (DSEAAdditionsExts) TCRMClassFactory
      .getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
        response = aDSEAAdditionsExtsComponent.updateXVehicleJPN(theBObj);
    logger.finest("RETURN handleUpdateXVehicleJPN(XVehicleJPNBObj theBObj)");
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction handleAddXCustomerVehicleJPN.
     *
     * @return DWLResponse containing the added 
     * @throws DWLBaseException
     * @see #handleaddXCustomerVehicleJPN
     *
     * @ejb.interface-method
     *    view-type="both"
     *
     * @generated
     */
     @TxMetadata(actionCategory=TCRMControlKeys.ADD_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.INSERT_RECORD_ERROR, 
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.ADDXCUSTOMERVEHICLEJPN_FAILED)
    public DWLResponse addXCustomerVehicleJPN(XCustomerVehicleJPNBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER addXCustomerVehicleJPN(XCustomerVehicleJPNBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("addXCustomerVehicleJPN", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before transaction addXCustomerVehicleJPN execution";
      logger.finest("addXCustomerVehicleJPN(XCustomerVehicleJPNBObj theBObj) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After transaction addXCustomerVehicleJPN execution";
      logger.finest("addXCustomerVehicleJPN(XCustomerVehicleJPNBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN addXCustomerVehicleJPN(XCustomerVehicleJPNBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction addXCustomerVehicleJPN.
     * 
     * @return DWLResponse containing the added 
     * @throws Exception
     * @see #addXCustomerVehicleJPN
     *
     * @generated
     */
    public DWLResponse handleAddXCustomerVehicleJPN(XCustomerVehicleJPNBObj theBObj) throws Exception {
    logger.finest("ENTER handleAddXCustomerVehicleJPN(XCustomerVehicleJPNBObj theBObj)");
        DWLResponse response = new DWLResponse();
        DSEAAdditionsExts aDSEAAdditionsExtsComponent = (DSEAAdditionsExts) TCRMClassFactory
      .getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
        response = aDSEAAdditionsExtsComponent.addXCustomerVehicleJPN(theBObj);
    logger.finest("RETURN handleAddXCustomerVehicleJPN(XCustomerVehicleJPNBObj theBObj)");
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction
     * handleUpdateXCustomerVehicleJPN.
     *
     * @return DWLResponse containing the added 
     * @throws DWLBaseException
     * @see #handleupdateXCustomerVehicleJPN
     *
     * @ejb.interface-method
     *    view-type="both"
     *
     * @generated
     */
     @TxMetadata(actionCategory=TCRMControlKeys.UPDATE_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.UPDATE_RECORD_ERROR, 
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.UPDATEXCUSTOMERVEHICLEJPN_FAILED)
    public DWLResponse updateXCustomerVehicleJPN(XCustomerVehicleJPNBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER updateXCustomerVehicleJPN(XCustomerVehicleJPNBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("updateXCustomerVehicleJPN", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before transaction updateXCustomerVehicleJPN execution";
      logger.finest("updateXCustomerVehicleJPN(XCustomerVehicleJPNBObj theBObj) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After transaction updateXCustomerVehicleJPN execution";
      logger.finest("updateXCustomerVehicleJPN(XCustomerVehicleJPNBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN updateXCustomerVehicleJPN(XCustomerVehicleJPNBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction updateXCustomerVehicleJPN.
     * 
     * @return DWLResponse containing the added 
     * @throws Exception
     * @see #updateXCustomerVehicleJPN
     *
     * @generated
     */
    public DWLResponse handleUpdateXCustomerVehicleJPN(XCustomerVehicleJPNBObj theBObj) throws Exception {
    logger.finest("ENTER handleUpdateXCustomerVehicleJPN(XCustomerVehicleJPNBObj theBObj)");
        DWLResponse response = new DWLResponse();
        DSEAAdditionsExts aDSEAAdditionsExtsComponent = (DSEAAdditionsExts) TCRMClassFactory
      .getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
        response = aDSEAAdditionsExtsComponent.updateXCustomerVehicleJPN(theBObj);
    logger.finest("RETURN handleUpdateXCustomerVehicleJPN(XCustomerVehicleJPNBObj theBObj)");
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction
     * handleAddXCustomerVehicleRoleJPN.
     *
     * @return DWLResponse containing the added 
     * @throws DWLBaseException
     * @see #handleaddXCustomerVehicleRoleJPN
     *
     * @ejb.interface-method
     *    view-type="both"
     *
     * @generated
     */
     @TxMetadata(actionCategory=TCRMControlKeys.ADD_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.INSERT_RECORD_ERROR, 
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.ADDXCUSTOMERVEHICLEROLEJPN_FAILED)
    public DWLResponse addXCustomerVehicleRoleJPN(XCustomerVehicleRoleJPNBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER addXCustomerVehicleRoleJPN(XCustomerVehicleRoleJPNBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("addXCustomerVehicleRoleJPN", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before transaction addXCustomerVehicleRoleJPN execution";
      logger.finest("addXCustomerVehicleRoleJPN(XCustomerVehicleRoleJPNBObj theBObj) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After transaction addXCustomerVehicleRoleJPN execution";
      logger.finest("addXCustomerVehicleRoleJPN(XCustomerVehicleRoleJPNBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN addXCustomerVehicleRoleJPN(XCustomerVehicleRoleJPNBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction addXCustomerVehicleRoleJPN.
     * 
     * @return DWLResponse containing the added 
     * @throws Exception
     * @see #addXCustomerVehicleRoleJPN
     *
     * @generated
     */
    public DWLResponse handleAddXCustomerVehicleRoleJPN(XCustomerVehicleRoleJPNBObj theBObj) throws Exception {
    logger.finest("ENTER handleAddXCustomerVehicleRoleJPN(XCustomerVehicleRoleJPNBObj theBObj)");
        DWLResponse response = new DWLResponse();
        DSEAAdditionsExts aDSEAAdditionsExtsComponent = (DSEAAdditionsExts) TCRMClassFactory
      .getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
        response = aDSEAAdditionsExtsComponent.addXCustomerVehicleRoleJPN(theBObj);
    logger.finest("RETURN handleAddXCustomerVehicleRoleJPN(XCustomerVehicleRoleJPNBObj theBObj)");
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction
     * handleUpdateXCustomerVehicleRoleJPN.
     *
     * @return DWLResponse containing the added 
     * @throws DWLBaseException
     * @see #handleupdateXCustomerVehicleRoleJPN
     *
     * @ejb.interface-method
     *    view-type="both"
     *
     * @generated
     */
     @TxMetadata(actionCategory=TCRMControlKeys.UPDATE_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.UPDATE_RECORD_ERROR, 
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.UPDATEXCUSTOMERVEHICLEROLEJPN_FAILED)
    public DWLResponse updateXCustomerVehicleRoleJPN(XCustomerVehicleRoleJPNBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER updateXCustomerVehicleRoleJPN(XCustomerVehicleRoleJPNBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("updateXCustomerVehicleRoleJPN", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before transaction updateXCustomerVehicleRoleJPN execution";
      logger.finest("updateXCustomerVehicleRoleJPN(XCustomerVehicleRoleJPNBObj theBObj) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After transaction updateXCustomerVehicleRoleJPN execution";
      logger.finest("updateXCustomerVehicleRoleJPN(XCustomerVehicleRoleJPNBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN updateXCustomerVehicleRoleJPN(XCustomerVehicleRoleJPNBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction
     * updateXCustomerVehicleRoleJPN.
     * 
     * @return DWLResponse containing the added 
     * @throws Exception
     * @see #updateXCustomerVehicleRoleJPN
     *
     * @generated
     */
    public DWLResponse handleUpdateXCustomerVehicleRoleJPN(XCustomerVehicleRoleJPNBObj theBObj) throws Exception {
    logger.finest("ENTER handleUpdateXCustomerVehicleRoleJPN(XCustomerVehicleRoleJPNBObj theBObj)");
        DWLResponse response = new DWLResponse();
        DSEAAdditionsExts aDSEAAdditionsExtsComponent = (DSEAAdditionsExts) TCRMClassFactory
      .getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
        response = aDSEAAdditionsExtsComponent.updateXCustomerVehicleRoleJPN(theBObj);
    logger.finest("RETURN handleUpdateXCustomerVehicleRoleJPN(XCustomerVehicleRoleJPNBObj theBObj)");
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction handleAddXDataSharing.
     *
     * @return DWLResponse containing the added 
     * @throws DWLBaseException
     * @see #handleaddXDataSharing
     *
     * @ejb.interface-method
     *    view-type="both"
     *
     * @generated
     */
     @TxMetadata(actionCategory=TCRMControlKeys.ADD_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.INSERT_RECORD_ERROR, 
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.ADDXDATASHARING_FAILED)
    public DWLResponse addXDataSharing(XDataSharingBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER addXDataSharing(XDataSharingBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("addXDataSharing", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before transaction addXDataSharing execution";
      logger.finest("addXDataSharing(XDataSharingBObj theBObj) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After transaction addXDataSharing execution";
      logger.finest("addXDataSharing(XDataSharingBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN addXDataSharing(XDataSharingBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction addXDataSharing.
     * 
     * @return DWLResponse containing the added 
     * @throws Exception
     * @see #addXDataSharing
     *
     * @generated
     */
    public DWLResponse handleAddXDataSharing(XDataSharingBObj theBObj) throws Exception {
    logger.finest("ENTER handleAddXDataSharing(XDataSharingBObj theBObj)");
        DWLResponse response = new DWLResponse();
        DSEAAdditionsExts aDSEAAdditionsExtsComponent = (DSEAAdditionsExts) TCRMClassFactory
      .getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
        response = aDSEAAdditionsExtsComponent.addXDataSharing(theBObj);
    logger.finest("RETURN handleAddXDataSharing(XDataSharingBObj theBObj)");
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction handleUpdateXDataSharing.
     *
     * @return DWLResponse containing the added 
     * @throws DWLBaseException
     * @see #handleupdateXDataSharing
     *
     * @ejb.interface-method
     *    view-type="both"
     *
     * @generated
     */
     @TxMetadata(actionCategory=TCRMControlKeys.UPDATE_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.UPDATE_RECORD_ERROR, 
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.UPDATEXDATASHARING_FAILED)
    public DWLResponse updateXDataSharing(XDataSharingBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER updateXDataSharing(XDataSharingBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("updateXDataSharing", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before transaction updateXDataSharing execution";
      logger.finest("updateXDataSharing(XDataSharingBObj theBObj) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After transaction updateXDataSharing execution";
      logger.finest("updateXDataSharing(XDataSharingBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN updateXDataSharing(XDataSharingBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction updateXDataSharing.
     * 
     * @return DWLResponse containing the added 
     * @throws Exception
     * @see #updateXDataSharing
     *
     * @generated
     */
    public DWLResponse handleUpdateXDataSharing(XDataSharingBObj theBObj) throws Exception {
    logger.finest("ENTER handleUpdateXDataSharing(XDataSharingBObj theBObj)");
        DWLResponse response = new DWLResponse();
        DSEAAdditionsExts aDSEAAdditionsExtsComponent = (DSEAAdditionsExts) TCRMClassFactory
      .getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
        response = aDSEAAdditionsExtsComponent.updateXDataSharing(theBObj);
    logger.finest("RETURN handleUpdateXDataSharing(XDataSharingBObj theBObj)");
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction handleAddXVehicleKOR.
     *
     * @return DWLResponse containing the added 
     * @throws DWLBaseException
     * @see #handleaddXVehicleKOR
     *
     * @ejb.interface-method
     *    view-type="both"
     *
     * @generated
     */
     @TxMetadata(actionCategory=TCRMControlKeys.ADD_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.INSERT_RECORD_ERROR, 
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.ADDXVEHICLEKOR_FAILED)
    public DWLResponse addXVehicleKOR(XVehicleKORBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER addXVehicleKOR(XVehicleKORBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("addXVehicleKOR", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before transaction addXVehicleKOR execution";
      logger.finest("addXVehicleKOR(XVehicleKORBObj theBObj) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After transaction addXVehicleKOR execution";
      logger.finest("addXVehicleKOR(XVehicleKORBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN addXVehicleKOR(XVehicleKORBObj theBObj) " + returnValue);
    }
        return retObj;
    }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction addXVehicleKOR.
     * 
     * @return DWLResponse containing the added 
     * @throws Exception
     * @see #addXVehicleKOR
     *
     * @generated
     */
    public DWLResponse handleAddXVehicleKOR(XVehicleKORBObj theBObj) throws Exception {
    logger.finest("ENTER handleAddXVehicleKOR(XVehicleKORBObj theBObj)");
        DWLResponse response = new DWLResponse();
        DSEAAdditionsExts aDSEAAdditionsExtsComponent = (DSEAAdditionsExts) TCRMClassFactory
      .getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
        response = aDSEAAdditionsExtsComponent.addXVehicleKOR(theBObj);
    logger.finest("RETURN handleAddXVehicleKOR(XVehicleKORBObj theBObj)");
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction handleUpdateXVehicleKOR.
     *
     * @return DWLResponse containing the added 
     * @throws DWLBaseException
     * @see #handleupdateXVehicleKOR
     *
     * @ejb.interface-method
     *    view-type="both"
     *
     * @generated
     */
     @TxMetadata(actionCategory=TCRMControlKeys.UPDATE_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.UPDATE_RECORD_ERROR, 
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.UPDATEXVEHICLEKOR_FAILED)
    public DWLResponse updateXVehicleKOR(XVehicleKORBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER updateXVehicleKOR(XVehicleKORBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("updateXVehicleKOR", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before transaction updateXVehicleKOR execution";
      logger.finest("updateXVehicleKOR(XVehicleKORBObj theBObj) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After transaction updateXVehicleKOR execution";
      logger.finest("updateXVehicleKOR(XVehicleKORBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN updateXVehicleKOR(XVehicleKORBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction updateXVehicleKOR.
     * 
     * @return DWLResponse containing the added 
     * @throws Exception
     * @see #updateXVehicleKOR
     *
     * @generated
     */
    public DWLResponse handleUpdateXVehicleKOR(XVehicleKORBObj theBObj) throws Exception {
    logger.finest("ENTER handleUpdateXVehicleKOR(XVehicleKORBObj theBObj)");
        DWLResponse response = new DWLResponse();
        DSEAAdditionsExts aDSEAAdditionsExtsComponent = (DSEAAdditionsExts) TCRMClassFactory
      .getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
        response = aDSEAAdditionsExtsComponent.updateXVehicleKOR(theBObj);
    logger.finest("RETURN handleUpdateXVehicleKOR(XVehicleKORBObj theBObj)");
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction handleAddXCustomerVehicleKOR.
     *
     * @return DWLResponse containing the added 
     * @throws DWLBaseException
     * @see #handleaddXCustomerVehicleKOR
     *
     * @ejb.interface-method
     *    view-type="both"
     *
     * @generated
     */
     @TxMetadata(actionCategory=TCRMControlKeys.ADD_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.INSERT_RECORD_ERROR, 
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.ADDXCUSTOMERVEHICLEKOR_FAILED)
    public DWLResponse addXCustomerVehicleKOR(XCustomerVehicleKORBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER addXCustomerVehicleKOR(XCustomerVehicleKORBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("addXCustomerVehicleKOR", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before transaction addXCustomerVehicleKOR execution";
      logger.finest("addXCustomerVehicleKOR(XCustomerVehicleKORBObj theBObj) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After transaction addXCustomerVehicleKOR execution";
      logger.finest("addXCustomerVehicleKOR(XCustomerVehicleKORBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN addXCustomerVehicleKOR(XCustomerVehicleKORBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction addXCustomerVehicleKOR.
     * 
     * @return DWLResponse containing the added 
     * @throws Exception
     * @see #addXCustomerVehicleKOR
     *
     * @generated
     */
    public DWLResponse handleAddXCustomerVehicleKOR(XCustomerVehicleKORBObj theBObj) throws Exception {
    logger.finest("ENTER handleAddXCustomerVehicleKOR(XCustomerVehicleKORBObj theBObj)");
        DWLResponse response = new DWLResponse();
        DSEAAdditionsExts aDSEAAdditionsExtsComponent = (DSEAAdditionsExts) TCRMClassFactory
      .getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
        response = aDSEAAdditionsExtsComponent.addXCustomerVehicleKOR(theBObj);
    logger.finest("RETURN handleAddXCustomerVehicleKOR(XCustomerVehicleKORBObj theBObj)");
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction
     * handleUpdateXCustomerVehicleKOR.
     *
     * @return DWLResponse containing the added 
     * @throws DWLBaseException
     * @see #handleupdateXCustomerVehicleKOR
     *
     * @ejb.interface-method
     *    view-type="both"
     *
     * @generated
     */
     @TxMetadata(actionCategory=TCRMControlKeys.UPDATE_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.UPDATE_RECORD_ERROR, 
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.UPDATEXCUSTOMERVEHICLEKOR_FAILED)
    public DWLResponse updateXCustomerVehicleKOR(XCustomerVehicleKORBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER updateXCustomerVehicleKOR(XCustomerVehicleKORBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("updateXCustomerVehicleKOR", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before transaction updateXCustomerVehicleKOR execution";
      logger.finest("updateXCustomerVehicleKOR(XCustomerVehicleKORBObj theBObj) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After transaction updateXCustomerVehicleKOR execution";
      logger.finest("updateXCustomerVehicleKOR(XCustomerVehicleKORBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN updateXCustomerVehicleKOR(XCustomerVehicleKORBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction updateXCustomerVehicleKOR.
     * 
     * @return DWLResponse containing the added 
     * @throws Exception
     * @see #updateXCustomerVehicleKOR
     *
     * @generated
     */
    public DWLResponse handleUpdateXCustomerVehicleKOR(XCustomerVehicleKORBObj theBObj) throws Exception {
    logger.finest("ENTER handleUpdateXCustomerVehicleKOR(XCustomerVehicleKORBObj theBObj)");
        DWLResponse response = new DWLResponse();
        DSEAAdditionsExts aDSEAAdditionsExtsComponent = (DSEAAdditionsExts) TCRMClassFactory
      .getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
        response = aDSEAAdditionsExtsComponent.updateXCustomerVehicleKOR(theBObj);
    logger.finest("RETURN handleUpdateXCustomerVehicleKOR(XCustomerVehicleKORBObj theBObj)");
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction
     * handleAddXCustomerVehicleRoleKOR.
     *
     * @return DWLResponse containing the added 
     * @throws DWLBaseException
     * @see #handleaddXCustomerVehicleRoleKOR
     *
     * @ejb.interface-method
     *    view-type="both"
     *
     * @generated
     */
     @TxMetadata(actionCategory=TCRMControlKeys.ADD_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.INSERT_RECORD_ERROR, 
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.ADDXCUSTOMERVEHICLEROLEKOR_FAILED)
    public DWLResponse addXCustomerVehicleRoleKOR(XCustomerVehicleRoleKORBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER addXCustomerVehicleRoleKOR(XCustomerVehicleRoleKORBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("addXCustomerVehicleRoleKOR", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before transaction addXCustomerVehicleRoleKOR execution";
      logger.finest("addXCustomerVehicleRoleKOR(XCustomerVehicleRoleKORBObj theBObj) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After transaction addXCustomerVehicleRoleKOR execution";
      logger.finest("addXCustomerVehicleRoleKOR(XCustomerVehicleRoleKORBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN addXCustomerVehicleRoleKOR(XCustomerVehicleRoleKORBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction addXCustomerVehicleRoleKOR.
     * 
     * @return DWLResponse containing the added 
     * @throws Exception
     * @see #addXCustomerVehicleRoleKOR
     *
     * @generated
     */
    public DWLResponse handleAddXCustomerVehicleRoleKOR(XCustomerVehicleRoleKORBObj theBObj) throws Exception {
    logger.finest("ENTER handleAddXCustomerVehicleRoleKOR(XCustomerVehicleRoleKORBObj theBObj)");
        DWLResponse response = new DWLResponse();
        DSEAAdditionsExts aDSEAAdditionsExtsComponent = (DSEAAdditionsExts) TCRMClassFactory
      .getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
        response = aDSEAAdditionsExtsComponent.addXCustomerVehicleRoleKOR(theBObj);
    logger.finest("RETURN handleAddXCustomerVehicleRoleKOR(XCustomerVehicleRoleKORBObj theBObj)");
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction
     * handleUpdateXCustomerVehicleRoleKOR.
     *
     * @return DWLResponse containing the added 
     * @throws DWLBaseException
     * @see #handleupdateXCustomerVehicleRoleKOR
     *
     * @ejb.interface-method
     *    view-type="both"
     *
     * @generated
     */
     @TxMetadata(actionCategory=TCRMControlKeys.UPDATE_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.UPDATE_RECORD_ERROR, 
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.UPDATEXCUSTOMERVEHICLEROLEKOR_FAILED)
    public DWLResponse updateXCustomerVehicleRoleKOR(XCustomerVehicleRoleKORBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER updateXCustomerVehicleRoleKOR(XCustomerVehicleRoleKORBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("updateXCustomerVehicleRoleKOR", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before transaction updateXCustomerVehicleRoleKOR execution";
      logger.finest("updateXCustomerVehicleRoleKOR(XCustomerVehicleRoleKORBObj theBObj) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After transaction updateXCustomerVehicleRoleKOR execution";
      logger.finest("updateXCustomerVehicleRoleKOR(XCustomerVehicleRoleKORBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN updateXCustomerVehicleRoleKOR(XCustomerVehicleRoleKORBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction
     * updateXCustomerVehicleRoleKOR.
     * 
     * @return DWLResponse containing the added 
     * @throws Exception
     * @see #updateXCustomerVehicleRoleKOR
     *
     * @generated
     */
    public DWLResponse handleUpdateXCustomerVehicleRoleKOR(XCustomerVehicleRoleKORBObj theBObj) throws Exception {
    logger.finest("ENTER handleUpdateXCustomerVehicleRoleKOR(XCustomerVehicleRoleKORBObj theBObj)");
        DWLResponse response = new DWLResponse();
        DSEAAdditionsExts aDSEAAdditionsExtsComponent = (DSEAAdditionsExts) TCRMClassFactory
      .getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
        response = aDSEAAdditionsExtsComponent.updateXCustomerVehicleRoleKOR(theBObj);
    logger.finest("RETURN handleUpdateXCustomerVehicleRoleKOR(XCustomerVehicleRoleKORBObj theBObj)");
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction handleAddXEpucidTemp.
     *
     * @return DWLResponse containing the added 
     * @throws DWLBaseException
     * @see #handleaddXEpucidTemp
     *
     * @ejb.interface-method
     *    view-type="both"
     *
     * @generated
     */
     @TxMetadata(actionCategory=TCRMControlKeys.ADD_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.INSERT_RECORD_ERROR, 
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.ADDXEPUCIDTEMP_FAILED)
    public DWLResponse addXEpucidTemp(XEpucidTempBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER addXEpucidTemp(XEpucidTempBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("addXEpucidTemp", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before transaction addXEpucidTemp execution";
      logger.finest("addXEpucidTemp(XEpucidTempBObj theBObj) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After transaction addXEpucidTemp execution";
      logger.finest("addXEpucidTemp(XEpucidTempBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN addXEpucidTemp(XEpucidTempBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction addXEpucidTemp.
     * 
     * @return DWLResponse containing the added 
     * @throws Exception
     * @see #addXEpucidTemp
     *
     * @generated
     */
    public DWLResponse handleAddXEpucidTemp(XEpucidTempBObj theBObj) throws Exception {
    logger.finest("ENTER handleAddXEpucidTemp(XEpucidTempBObj theBObj)");
        DWLResponse response = new DWLResponse();
        DSEAAdditionsExts aDSEAAdditionsExtsComponent = (DSEAAdditionsExts) TCRMClassFactory
      .getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
        response = aDSEAAdditionsExtsComponent.addXEpucidTemp(theBObj);
    logger.finest("RETURN handleAddXEpucidTemp(XEpucidTempBObj theBObj)");
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction handleUpdateXEpucidTemp.
     *
     * @return DWLResponse containing the added 
     * @throws DWLBaseException
     * @see #handleupdateXEpucidTemp
     *
     * @ejb.interface-method
     *    view-type="both"
     *
     * @generated
     */
     @TxMetadata(actionCategory=TCRMControlKeys.UPDATE_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.UPDATE_RECORD_ERROR, 
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.UPDATEXEPUCIDTEMP_FAILED)
    public DWLResponse updateXEpucidTemp(XEpucidTempBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER updateXEpucidTemp(XEpucidTempBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("updateXEpucidTemp", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before transaction updateXEpucidTemp execution";
      logger.finest("updateXEpucidTemp(XEpucidTempBObj theBObj) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After transaction updateXEpucidTemp execution";
      logger.finest("updateXEpucidTemp(XEpucidTempBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN updateXEpucidTemp(XEpucidTempBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction updateXEpucidTemp.
     * 
     * @return DWLResponse containing the added 
     * @throws Exception
     * @see #updateXEpucidTemp
     *
     * @generated
     */
    public DWLResponse handleUpdateXEpucidTemp(XEpucidTempBObj theBObj) throws Exception {
    logger.finest("ENTER handleUpdateXEpucidTemp(XEpucidTempBObj theBObj)");
        DWLResponse response = new DWLResponse();
        DSEAAdditionsExts aDSEAAdditionsExtsComponent = (DSEAAdditionsExts) TCRMClassFactory
      .getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
        response = aDSEAAdditionsExtsComponent.updateXEpucidTemp(theBObj);
    logger.finest("RETURN handleUpdateXEpucidTemp(XEpucidTempBObj theBObj)");
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction handleAddXContractDetailsJPN.
     *
     * @return DWLResponse containing the added 
     * @throws DWLBaseException
     * @see #handleaddXContractDetailsJPN
     *
     * @ejb.interface-method
     *    view-type="both"
     *
     * @generated
     */
     @TxMetadata(actionCategory=TCRMControlKeys.ADD_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.INSERT_RECORD_ERROR, 
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.ADDXCONTRACTDETAILSJPN_FAILED)
    public DWLResponse addXContractDetailsJPN(XContractDetailsJPNBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER addXContractDetailsJPN(XContractDetailsJPNBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("addXContractDetailsJPN", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before transaction addXContractDetailsJPN execution";
      logger.finest("addXContractDetailsJPN(XContractDetailsJPNBObj theBObj) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After transaction addXContractDetailsJPN execution";
      logger.finest("addXContractDetailsJPN(XContractDetailsJPNBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN addXContractDetailsJPN(XContractDetailsJPNBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction addXContractDetailsJPN.
     * 
     * @return DWLResponse containing the added 
     * @throws Exception
     * @see #addXContractDetailsJPN
     *
     * @generated
     */
    public DWLResponse handleAddXContractDetailsJPN(XContractDetailsJPNBObj theBObj) throws Exception {
    logger.finest("ENTER handleAddXContractDetailsJPN(XContractDetailsJPNBObj theBObj)");
        DWLResponse response = new DWLResponse();
        DSEAAdditionsExts aDSEAAdditionsExtsComponent = (DSEAAdditionsExts) TCRMClassFactory
      .getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
        response = aDSEAAdditionsExtsComponent.addXContractDetailsJPN(theBObj);
    logger.finest("RETURN handleAddXContractDetailsJPN(XContractDetailsJPNBObj theBObj)");
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction
     * handleUpdateXContractDetailsJPN.
     *
     * @return DWLResponse containing the added 
     * @throws DWLBaseException
     * @see #handleupdateXContractDetailsJPN
     *
     * @ejb.interface-method
     *    view-type="both"
     *
     * @generated
     */
     @TxMetadata(actionCategory=TCRMControlKeys.UPDATE_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.UPDATE_RECORD_ERROR, 
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.UPDATEXCONTRACTDETAILSJPN_FAILED)
    public DWLResponse updateXContractDetailsJPN(XContractDetailsJPNBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER updateXContractDetailsJPN(XContractDetailsJPNBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("updateXContractDetailsJPN", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before transaction updateXContractDetailsJPN execution";
      logger.finest("updateXContractDetailsJPN(XContractDetailsJPNBObj theBObj) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After transaction updateXContractDetailsJPN execution";
      logger.finest("updateXContractDetailsJPN(XContractDetailsJPNBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN updateXContractDetailsJPN(XContractDetailsJPNBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction updateXContractDetailsJPN.
     * 
     * @return DWLResponse containing the added 
     * @throws Exception
     * @see #updateXContractDetailsJPN
     *
     * @generated
     */
    public DWLResponse handleUpdateXContractDetailsJPN(XContractDetailsJPNBObj theBObj) throws Exception {
    logger.finest("ENTER handleUpdateXContractDetailsJPN(XContractDetailsJPNBObj theBObj)");
        DWLResponse response = new DWLResponse();
        DSEAAdditionsExts aDSEAAdditionsExtsComponent = (DSEAAdditionsExts) TCRMClassFactory
      .getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
        response = aDSEAAdditionsExtsComponent.updateXContractDetailsJPN(theBObj);
    logger.finest("RETURN handleUpdateXContractDetailsJPN(XContractDetailsJPNBObj theBObj)");
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction handleAddXContractRelJPN.
     *
     * @return DWLResponse containing the added 
     * @throws DWLBaseException
     * @see #handleaddXContractRelJPN
     *
     * @ejb.interface-method
     *    view-type="both"
     *
     * @generated
     */
     @TxMetadata(actionCategory=TCRMControlKeys.ADD_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.INSERT_RECORD_ERROR, 
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.ADDXCONTRACTRELJPN_FAILED)
    public DWLResponse addXContractRelJPN(XContractRelJPNBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER addXContractRelJPN(XContractRelJPNBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("addXContractRelJPN", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before transaction addXContractRelJPN execution";
      logger.finest("addXContractRelJPN(XContractRelJPNBObj theBObj) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After transaction addXContractRelJPN execution";
      logger.finest("addXContractRelJPN(XContractRelJPNBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN addXContractRelJPN(XContractRelJPNBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction addXContractRelJPN.
     * 
     * @return DWLResponse containing the added 
     * @throws Exception
     * @see #addXContractRelJPN
     *
     * @generated
     */
    public DWLResponse handleAddXContractRelJPN(XContractRelJPNBObj theBObj) throws Exception {
    logger.finest("ENTER handleAddXContractRelJPN(XContractRelJPNBObj theBObj)");
        DWLResponse response = new DWLResponse();
        DSEAAdditionsExts aDSEAAdditionsExtsComponent = (DSEAAdditionsExts) TCRMClassFactory
      .getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
        response = aDSEAAdditionsExtsComponent.addXContractRelJPN(theBObj);
    logger.finest("RETURN handleAddXContractRelJPN(XContractRelJPNBObj theBObj)");
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction handleUpdateXContractRelJPN.
     *
     * @return DWLResponse containing the added 
     * @throws DWLBaseException
     * @see #handleupdateXContractRelJPN
     *
     * @ejb.interface-method
     *    view-type="both"
     *
     * @generated
     */
     @TxMetadata(actionCategory=TCRMControlKeys.UPDATE_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.UPDATE_RECORD_ERROR, 
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.UPDATEXCONTRACTRELJPN_FAILED)
    public DWLResponse updateXContractRelJPN(XContractRelJPNBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER updateXContractRelJPN(XContractRelJPNBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("updateXContractRelJPN", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before transaction updateXContractRelJPN execution";
      logger.finest("updateXContractRelJPN(XContractRelJPNBObj theBObj) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After transaction updateXContractRelJPN execution";
      logger.finest("updateXContractRelJPN(XContractRelJPNBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN updateXContractRelJPN(XContractRelJPNBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction updateXContractRelJPN.
     * 
     * @return DWLResponse containing the added 
     * @throws Exception
     * @see #updateXContractRelJPN
     *
     * @generated
     */
    public DWLResponse handleUpdateXContractRelJPN(XContractRelJPNBObj theBObj) throws Exception {
    logger.finest("ENTER handleUpdateXContractRelJPN(XContractRelJPNBObj theBObj)");
        DWLResponse response = new DWLResponse();
        DSEAAdditionsExts aDSEAAdditionsExtsComponent = (DSEAAdditionsExts) TCRMClassFactory
      .getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
        response = aDSEAAdditionsExtsComponent.updateXContractRelJPN(theBObj);
    logger.finest("RETURN handleUpdateXContractRelJPN(XContractRelJPNBObj theBObj)");
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction handleAddXVehicleAus.
     *
     * @return DWLResponse containing the added 
     * @throws DWLBaseException
     * @see #handleaddXVehicleAus
     *
     * @ejb.interface-method
     *    view-type="both"
     *
     * @generated
     */
     @TxMetadata(actionCategory=TCRMControlKeys.ADD_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.INSERT_RECORD_ERROR, 
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.ADDXVEHICLEAUS_FAILED)
    public DWLResponse addXVehicleAus(XVehicleAusBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER addXVehicleAus(XVehicleAusBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("addXVehicleAus", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before transaction addXVehicleAus execution";
      logger.finest("addXVehicleAus(XVehicleAusBObj theBObj) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After transaction addXVehicleAus execution";
      logger.finest("addXVehicleAus(XVehicleAusBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN addXVehicleAus(XVehicleAusBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction addXVehicleAus.
     * 
     * @return DWLResponse containing the added 
     * @throws Exception
     * @see #addXVehicleAus
     *
     * @generated
     */
    public DWLResponse handleAddXVehicleAus(XVehicleAusBObj theBObj) throws Exception {
    logger.finest("ENTER handleAddXVehicleAus(XVehicleAusBObj theBObj)");
        DWLResponse response = new DWLResponse();
        DSEAAdditionsExts aDSEAAdditionsExtsComponent = (DSEAAdditionsExts) TCRMClassFactory
      .getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
        response = aDSEAAdditionsExtsComponent.addXVehicleAus(theBObj);
    logger.finest("RETURN handleAddXVehicleAus(XVehicleAusBObj theBObj)");
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction handleUpdateXVehicleAus.
     *
     * @return DWLResponse containing the added 
     * @throws DWLBaseException
     * @see #handleupdateXVehicleAus
     *
     * @ejb.interface-method
     *    view-type="both"
     *
     * @generated
     */
     @TxMetadata(actionCategory=TCRMControlKeys.UPDATE_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.UPDATE_RECORD_ERROR, 
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.UPDATEXVEHICLEAUS_FAILED)
    public DWLResponse updateXVehicleAus(XVehicleAusBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER updateXVehicleAus(XVehicleAusBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("updateXVehicleAus", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before transaction updateXVehicleAus execution";
      logger.finest("updateXVehicleAus(XVehicleAusBObj theBObj) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After transaction updateXVehicleAus execution";
      logger.finest("updateXVehicleAus(XVehicleAusBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN updateXVehicleAus(XVehicleAusBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction updateXVehicleAus.
     * 
     * @return DWLResponse containing the added 
     * @throws Exception
     * @see #updateXVehicleAus
     *
     * @generated
     */
    public DWLResponse handleUpdateXVehicleAus(XVehicleAusBObj theBObj) throws Exception {
    logger.finest("ENTER handleUpdateXVehicleAus(XVehicleAusBObj theBObj)");
        DWLResponse response = new DWLResponse();
        DSEAAdditionsExts aDSEAAdditionsExtsComponent = (DSEAAdditionsExts) TCRMClassFactory
      .getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
        response = aDSEAAdditionsExtsComponent.updateXVehicleAus(theBObj);
    logger.finest("RETURN handleUpdateXVehicleAus(XVehicleAusBObj theBObj)");
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction handleAddXCustomerVehicleAus.
     *
     * @return DWLResponse containing the added 
     * @throws DWLBaseException
     * @see #handleaddXCustomerVehicleAus
     *
     * @ejb.interface-method
     *    view-type="both"
     *
     * @generated
     */
     @TxMetadata(actionCategory=TCRMControlKeys.ADD_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.INSERT_RECORD_ERROR, 
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.ADDXCUSTOMERVEHICLEAUS_FAILED)
    public DWLResponse addXCustomerVehicleAus(XCustomerVehicleAusBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER addXCustomerVehicleAus(XCustomerVehicleAusBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("addXCustomerVehicleAus", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before transaction addXCustomerVehicleAus execution";
      logger.finest("addXCustomerVehicleAus(XCustomerVehicleAusBObj theBObj) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After transaction addXCustomerVehicleAus execution";
      logger.finest("addXCustomerVehicleAus(XCustomerVehicleAusBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN addXCustomerVehicleAus(XCustomerVehicleAusBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction addXCustomerVehicleAus.
     * 
     * @return DWLResponse containing the added 
     * @throws Exception
     * @see #addXCustomerVehicleAus
     *
     * @generated
     */
    public DWLResponse handleAddXCustomerVehicleAus(XCustomerVehicleAusBObj theBObj) throws Exception {
    logger.finest("ENTER handleAddXCustomerVehicleAus(XCustomerVehicleAusBObj theBObj)");
        DWLResponse response = new DWLResponse();
        DSEAAdditionsExts aDSEAAdditionsExtsComponent = (DSEAAdditionsExts) TCRMClassFactory
      .getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
        response = aDSEAAdditionsExtsComponent.addXCustomerVehicleAus(theBObj);
    logger.finest("RETURN handleAddXCustomerVehicleAus(XCustomerVehicleAusBObj theBObj)");
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction
     * handleUpdateXCustomerVehicleAus.
     *
     * @return DWLResponse containing the added 
     * @throws DWLBaseException
     * @see #handleupdateXCustomerVehicleAus
     *
     * @ejb.interface-method
     *    view-type="both"
     *
     * @generated
     */
     @TxMetadata(actionCategory=TCRMControlKeys.UPDATE_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.UPDATE_RECORD_ERROR, 
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.UPDATEXCUSTOMERVEHICLEAUS_FAILED)
    public DWLResponse updateXCustomerVehicleAus(XCustomerVehicleAusBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER updateXCustomerVehicleAus(XCustomerVehicleAusBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("updateXCustomerVehicleAus", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before transaction updateXCustomerVehicleAus execution";
      logger.finest("updateXCustomerVehicleAus(XCustomerVehicleAusBObj theBObj) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After transaction updateXCustomerVehicleAus execution";
      logger.finest("updateXCustomerVehicleAus(XCustomerVehicleAusBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN updateXCustomerVehicleAus(XCustomerVehicleAusBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction updateXCustomerVehicleAus.
     * 
     * @return DWLResponse containing the added 
     * @throws Exception
     * @see #updateXCustomerVehicleAus
     *
     * @generated
     */
    public DWLResponse handleUpdateXCustomerVehicleAus(XCustomerVehicleAusBObj theBObj) throws Exception {
    logger.finest("ENTER handleUpdateXCustomerVehicleAus(XCustomerVehicleAusBObj theBObj)");
        DWLResponse response = new DWLResponse();
        DSEAAdditionsExts aDSEAAdditionsExtsComponent = (DSEAAdditionsExts) TCRMClassFactory
      .getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
        response = aDSEAAdditionsExtsComponent.updateXCustomerVehicleAus(theBObj);
    logger.finest("RETURN handleUpdateXCustomerVehicleAus(XCustomerVehicleAusBObj theBObj)");
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction
     * handleAddXCustomerVehicleRoleAus.
     *
     * @return DWLResponse containing the added 
     * @throws DWLBaseException
     * @see #handleaddXCustomerVehicleRoleAus
     *
     * @ejb.interface-method
     *    view-type="both"
     *
     * @generated
     */
     @TxMetadata(actionCategory=TCRMControlKeys.ADD_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.INSERT_RECORD_ERROR, 
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.ADDXCUSTOMERVEHICLEROLEAUS_FAILED)
    public DWLResponse addXCustomerVehicleRoleAus(XCustomerVehicleRoleAusBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER addXCustomerVehicleRoleAus(XCustomerVehicleRoleAusBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("addXCustomerVehicleRoleAus", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before transaction addXCustomerVehicleRoleAus execution";
      logger.finest("addXCustomerVehicleRoleAus(XCustomerVehicleRoleAusBObj theBObj) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After transaction addXCustomerVehicleRoleAus execution";
      logger.finest("addXCustomerVehicleRoleAus(XCustomerVehicleRoleAusBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN addXCustomerVehicleRoleAus(XCustomerVehicleRoleAusBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction addXCustomerVehicleRoleAus.
     * 
     * @return DWLResponse containing the added 
     * @throws Exception
     * @see #addXCustomerVehicleRoleAus
     *
     * @generated
     */
    public DWLResponse handleAddXCustomerVehicleRoleAus(XCustomerVehicleRoleAusBObj theBObj) throws Exception {
    logger.finest("ENTER handleAddXCustomerVehicleRoleAus(XCustomerVehicleRoleAusBObj theBObj)");
        DWLResponse response = new DWLResponse();
        DSEAAdditionsExts aDSEAAdditionsExtsComponent = (DSEAAdditionsExts) TCRMClassFactory
      .getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
        response = aDSEAAdditionsExtsComponent.addXCustomerVehicleRoleAus(theBObj);
    logger.finest("RETURN handleAddXCustomerVehicleRoleAus(XCustomerVehicleRoleAusBObj theBObj)");
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction
     * handleUpdateXCustomerVehicleRoleAus.
     *
     * @return DWLResponse containing the added 
     * @throws DWLBaseException
     * @see #handleupdateXCustomerVehicleRoleAus
     *
     * @ejb.interface-method
     *    view-type="both"
     *
     * @generated
     */
     @TxMetadata(actionCategory=TCRMControlKeys.UPDATE_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.UPDATE_RECORD_ERROR, 
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.UPDATEXCUSTOMERVEHICLEROLEAUS_FAILED)
    public DWLResponse updateXCustomerVehicleRoleAus(XCustomerVehicleRoleAusBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER updateXCustomerVehicleRoleAus(XCustomerVehicleRoleAusBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("updateXCustomerVehicleRoleAus", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before transaction updateXCustomerVehicleRoleAus execution";
      logger.finest("updateXCustomerVehicleRoleAus(XCustomerVehicleRoleAusBObj theBObj) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After transaction updateXCustomerVehicleRoleAus execution";
      logger.finest("updateXCustomerVehicleRoleAus(XCustomerVehicleRoleAusBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN updateXCustomerVehicleRoleAus(XCustomerVehicleRoleAusBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction
     * updateXCustomerVehicleRoleAus.
     * 
     * @return DWLResponse containing the added 
     * @throws Exception
     * @see #updateXCustomerVehicleRoleAus
     *
     * @generated
     */
    public DWLResponse handleUpdateXCustomerVehicleRoleAus(XCustomerVehicleRoleAusBObj theBObj) throws Exception {
    logger.finest("ENTER handleUpdateXCustomerVehicleRoleAus(XCustomerVehicleRoleAusBObj theBObj)");
        DWLResponse response = new DWLResponse();
        DSEAAdditionsExts aDSEAAdditionsExtsComponent = (DSEAAdditionsExts) TCRMClassFactory
      .getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
        response = aDSEAAdditionsExtsComponent.updateXCustomerVehicleRoleAus(theBObj);
    logger.finest("RETURN handleUpdateXCustomerVehicleRoleAus(XCustomerVehicleRoleAusBObj theBObj)");
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction handleAddXVRCollapse.
     *
     * @return DWLResponse containing the added 
     * @throws DWLBaseException
     * @see #handleaddXVRCollapse
     *
     * @ejb.interface-method
     *    view-type="both"
     *
     * @generated
     */
     @TxMetadata(actionCategory=TCRMControlKeys.ADD_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.INSERT_RECORD_ERROR, 
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.ADDXVRCOLLAPSE_FAILED)
    public DWLResponse addXVRCollapse(XVRCollapseBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER addXVRCollapse(XVRCollapseBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("addXVRCollapse", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before transaction addXVRCollapse execution";
      logger.finest("addXVRCollapse(XVRCollapseBObj theBObj) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After transaction addXVRCollapse execution";
      logger.finest("addXVRCollapse(XVRCollapseBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN addXVRCollapse(XVRCollapseBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction addXVRCollapse.
     * 
     * @return DWLResponse containing the added 
     * @throws Exception
     * @see #addXVRCollapse
     *
     * @generated
     */
    public DWLResponse handleAddXVRCollapse(XVRCollapseBObj theBObj) throws Exception {
    logger.finest("ENTER handleAddXVRCollapse(XVRCollapseBObj theBObj)");
        DWLResponse response = new DWLResponse();
        DSEAAdditionsExts aDSEAAdditionsExtsComponent = (DSEAAdditionsExts) TCRMClassFactory
      .getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
        response = aDSEAAdditionsExtsComponent.addXVRCollapse(theBObj);
    logger.finest("RETURN handleAddXVRCollapse(XVRCollapseBObj theBObj)");
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction handleUpdateXVRCollapse.
     *
     * @return DWLResponse containing the added 
     * @throws DWLBaseException
     * @see #handleupdateXVRCollapse
     *
     * @ejb.interface-method
     *    view-type="both"
     *
     * @generated
     */
     @TxMetadata(actionCategory=TCRMControlKeys.UPDATE_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.UPDATE_RECORD_ERROR, 
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.UPDATEXVRCOLLAPSE_FAILED)
    public DWLResponse updateXVRCollapse(XVRCollapseBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER updateXVRCollapse(XVRCollapseBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("updateXVRCollapse", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before transaction updateXVRCollapse execution";
      logger.finest("updateXVRCollapse(XVRCollapseBObj theBObj) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After transaction updateXVRCollapse execution";
      logger.finest("updateXVRCollapse(XVRCollapseBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN updateXVRCollapse(XVRCollapseBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction updateXVRCollapse.
     * 
     * @return DWLResponse containing the added 
     * @throws Exception
     * @see #updateXVRCollapse
     *
     * @generated
     */
    public DWLResponse handleUpdateXVRCollapse(XVRCollapseBObj theBObj) throws Exception {
    logger.finest("ENTER handleUpdateXVRCollapse(XVRCollapseBObj theBObj)");
        DWLResponse response = new DWLResponse();
        DSEAAdditionsExts aDSEAAdditionsExtsComponent = (DSEAAdditionsExts) TCRMClassFactory
      .getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
        response = aDSEAAdditionsExtsComponent.updateXVRCollapse(theBObj);
    logger.finest("RETURN handleUpdateXVRCollapse(XVRCollapseBObj theBObj)");
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction handleAddXDeleteAudit.
     *
     * @return DWLResponse containing the added 
     * @throws DWLBaseException
     * @see #handleaddXDeleteAudit
     *
     * @ejb.interface-method
     *    view-type="both"
     *
     * @generated
     */
     @TxMetadata(actionCategory=TCRMControlKeys.ADD_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.INSERT_RECORD_ERROR, 
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.ADDXDELETEAUDIT_FAILED)
    public DWLResponse addXDeleteAudit(XDeleteAuditBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER addXDeleteAudit(XDeleteAuditBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("addXDeleteAudit", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before transaction addXDeleteAudit execution";
      logger.finest("addXDeleteAudit(XDeleteAuditBObj theBObj) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After transaction addXDeleteAudit execution";
      logger.finest("addXDeleteAudit(XDeleteAuditBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN addXDeleteAudit(XDeleteAuditBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction addXDeleteAudit.
     * 
     * @return DWLResponse containing the added 
     * @throws Exception
     * @see #addXDeleteAudit
     *
     * @generated
     */
    public DWLResponse handleAddXDeleteAudit(XDeleteAuditBObj theBObj) throws Exception {
    logger.finest("ENTER handleAddXDeleteAudit(XDeleteAuditBObj theBObj)");
        DWLResponse response = new DWLResponse();
        DSEAAdditionsExts aDSEAAdditionsExtsComponent = (DSEAAdditionsExts) TCRMClassFactory
      .getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
        response = aDSEAAdditionsExtsComponent.addXDeleteAudit(theBObj);
    logger.finest("RETURN handleAddXDeleteAudit(XDeleteAuditBObj theBObj)");
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction handleUpdateXDeleteAudit.
     *
     * @return DWLResponse containing the added 
     * @throws DWLBaseException
     * @see #handleupdateXDeleteAudit
     *
     * @ejb.interface-method
     *    view-type="both"
     *
     * @generated
     */
     @TxMetadata(actionCategory=TCRMControlKeys.UPDATE_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.UPDATE_RECORD_ERROR, 
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.UPDATEXDELETEAUDIT_FAILED)
    public DWLResponse updateXDeleteAudit(XDeleteAuditBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER updateXDeleteAudit(XDeleteAuditBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("updateXDeleteAudit", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before transaction updateXDeleteAudit execution";
      logger.finest("updateXDeleteAudit(XDeleteAuditBObj theBObj) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After transaction updateXDeleteAudit execution";
      logger.finest("updateXDeleteAudit(XDeleteAuditBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN updateXDeleteAudit(XDeleteAuditBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction updateXDeleteAudit.
     * 
     * @return DWLResponse containing the added 
     * @throws Exception
     * @see #updateXDeleteAudit
     *
     * @generated
     */
    public DWLResponse handleUpdateXDeleteAudit(XDeleteAuditBObj theBObj) throws Exception {
    logger.finest("ENTER handleUpdateXDeleteAudit(XDeleteAuditBObj theBObj)");
        DWLResponse response = new DWLResponse();
        DSEAAdditionsExts aDSEAAdditionsExtsComponent = (DSEAAdditionsExts) TCRMClassFactory
      .getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
        response = aDSEAAdditionsExtsComponent.updateXDeleteAudit(theBObj);
    logger.finest("RETURN handleUpdateXDeleteAudit(XDeleteAuditBObj theBObj)");
        return response;
    }
}



