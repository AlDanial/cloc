/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[cd26ae59c884681c7c78773d6a77a418]
 */

package com.ibm.daimler.dsea.controller;


import com.dwl.base.DWLControl;
import com.dwl.base.IDWLErrorMessage;
import com.dwl.base.constant.DWLControlKeys;
import com.dwl.base.requestHandler.DWLTransaction;
import com.dwl.base.requestHandler.DWLTransactionInquiry;
import com.dwl.tcrm.common.TCRMCommonComponent;
import com.dwl.tcrm.common.TCRMErrorCode;
import com.dwl.base.DWLResponse;
import com.dwl.base.exception.DWLBaseException;
import com.dwl.tcrm.utilities.TCRMClassFactory;
import com.ibm.mdm.annotations.Controller;
import com.ibm.mdm.annotations.TxMetadata;


import com.dwl.base.error.DWLStatus;

import com.dwl.base.util.DWLExceptionUtils;

import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsComponentID;
import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsErrorReasonCode;
import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsPropertyKeys;

import com.ibm.daimler.dsea.interfaces.DSEAAdditionsExts;
import com.ibm.daimler.dsea.interfaces.DSEAAdditionsExtsFinder;

import java.util.Vector;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * Controller class to handle inquiry requests.
 * @generated
 */
 @Controller(errorComponentID = DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_CONTROLLER)
public class DSEAAdditionsExtsFinderImpl extends TCRMCommonComponent implements DSEAAdditionsExtsFinder {

    private IDWLErrorMessage errHandler;
	/**
    * <!-- begin-user-doc -->
	  * <!-- end-user-doc -->
    * @generated 
    */
	 private final static com.dwl.base.logging.IDWLLogger logger = com.dwl.base.logging.DWLLoggerManager.getLogger(DSEAAdditionsExtsFinderImpl.class);

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Default constructor.
     * @generated
     */
    public DSEAAdditionsExtsFinderImpl() {
        super();
        errHandler = TCRMClassFactory.getErrorHandler();
    }

	
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXPreference.
     *
     * @param PreferencepkId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetXPreference
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETXPREFERENCE_FAILED)
     public DWLResponse getXPreference(String PreferencepkId, DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getXPreference(String PreferencepkId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(PreferencepkId);
        DWLTransaction txObj = new DWLTransactionInquiry("getXPreference", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
      String infoForLogging="Before finder transaction execution for getXPreference";
      logger.finest("getXPreference(String PreferencepkId,  DWLControl control) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
       		String infoForLogging="After finder transaction execution for getXPreference";
      logger.finest("getXPreference(String PreferencepkId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getXPreference(String PreferencepkId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }
    
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction getXPreference.
     * 
     * @param PreferencepkId
     * @return com.dwl.base.DWLResponse
     * @exception Exception
     * @generated
     */
    public DWLResponse  handleGetXPreference(String PreferencepkId, DWLControl control) throws Exception {

        DWLResponse response = new DWLResponse();

    DSEAAdditionsExts comp = 
      (DSEAAdditionsExts)TCRMClassFactory.getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
      
        response = comp.getXPreference(PreferencepkId,  control);
        if (response.getData() == null) {
            String[] params = new String[] { PreferencepkId };
            DWLExceptionUtils.addErrorToStatus(response.getStatus(), DWLStatus.FATAL,
          DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_CONTROLLER,
          TCRMErrorCode.READ_RECORD_ERROR,
          DSEAAdditionsExtsErrorReasonCode.GETXPREFERENCE_FAILED,
          control, params, errHandler);					
        }
        return response;
    }
    
	
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXPreferenceByLocationGroupId.
     *
     * @param LocationGroupId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetXPreferenceByLocationGroupId
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETXPREFERENCEBYLOCATIONGROUPID_FAILED)
     public DWLResponse getXPreferenceByLocationGroupId(String LocationGroupId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getXPreferenceByLocationGroupId(String LocationGroupId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(LocationGroupId);
        DWLTransaction txObj = new DWLTransactionInquiry("getXPreferenceByLocationGroupId", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
      String infoForLogging="Before finder transaction execution for getXPreferenceByLocationGroupId";
      logger.finest("getXPreferenceByLocationGroupId(String LocationGroupId,  DWLControl control) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
       		String infoForLogging="After finder transaction execution for getXPreferenceByLocationGroupId";
      logger.finest("getXPreferenceByLocationGroupId(String LocationGroupId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getXPreferenceByLocationGroupId(String LocationGroupId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }
    
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction
     * getXPreferenceByLocationGroupId.
     * 
     * @param LocationGroupId
     * @return com.dwl.base.DWLResponse
     * @exception Exception
     * @generated
     */
    public DWLResponse  handleGetXPreferenceByLocationGroupId(String LocationGroupId,  DWLControl control) throws Exception {

        DWLResponse response = new DWLResponse();

    DSEAAdditionsExts comp = 
      (DSEAAdditionsExts)TCRMClassFactory.getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
      
        response = comp.getXPreferenceByLocationGroupId(LocationGroupId,  control);
        if (response.getData() == null) {
            String[] params = new String[] { LocationGroupId };
            DWLExceptionUtils.addErrorToStatus(response.getStatus(), DWLStatus.FATAL,
          DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_CONTROLLER,
          TCRMErrorCode.READ_RECORD_ERROR,
          DSEAAdditionsExtsErrorReasonCode.GETXPREFERENCEBYLOCATIONGROUPID_FAILED,
          control, params, errHandler);					
        }
        return response;
    }
    
	
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXPrivacyAgreement.
     *
     * @param PrivacyAgreementpkId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetXPrivacyAgreement
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETXPRIVACYAGREEMENT_FAILED)
     public DWLResponse getXPrivacyAgreement(String PrivacyAgreementpkId, DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getXPrivacyAgreement(String PrivacyAgreementpkId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(PrivacyAgreementpkId);
        DWLTransaction txObj = new DWLTransactionInquiry("getXPrivacyAgreement", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
      String infoForLogging="Before finder transaction execution for getXPrivacyAgreement";
      logger.finest("getXPrivacyAgreement(String PrivacyAgreementpkId,  DWLControl control) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
       		String infoForLogging="After finder transaction execution for getXPrivacyAgreement";
      logger.finest("getXPrivacyAgreement(String PrivacyAgreementpkId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getXPrivacyAgreement(String PrivacyAgreementpkId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }
    
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction getXPrivacyAgreement.
     * 
     * @param PrivacyAgreementpkId
     * @return com.dwl.base.DWLResponse
     * @exception Exception
     * @generated
     */
    public DWLResponse  handleGetXPrivacyAgreement(String PrivacyAgreementpkId, DWLControl control) throws Exception {

        DWLResponse response = new DWLResponse();

    DSEAAdditionsExts comp = 
      (DSEAAdditionsExts)TCRMClassFactory.getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
      
        response = comp.getXPrivacyAgreement(PrivacyAgreementpkId,  control);
        if (response.getData() == null) {
            String[] params = new String[] { PrivacyAgreementpkId };
            DWLExceptionUtils.addErrorToStatus(response.getStatus(), DWLStatus.FATAL,
          DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_CONTROLLER,
          TCRMErrorCode.READ_RECORD_ERROR,
          DSEAAdditionsExtsErrorReasonCode.GETXPRIVACYAGREEMENT_FAILED,
          control, params, errHandler);					
        }
        return response;
    }
    
	
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXPrivAgreementByLocationGroupId.
     *
     * @param LocationGroupId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetXPrivAgreementByLocationGroupId
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETXPRIVAGREEMENTBYLOCATIONGROUPID_FAILED)
     public DWLResponse getXPrivAgreementByLocationGroupId(String LocationGroupId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getXPrivAgreementByLocationGroupId(String LocationGroupId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(LocationGroupId);
        DWLTransaction txObj = new DWLTransactionInquiry("getXPrivAgreementByLocationGroupId", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
      String infoForLogging="Before finder transaction execution for getXPrivAgreementByLocationGroupId";
      logger.finest("getXPrivAgreementByLocationGroupId(String LocationGroupId,  DWLControl control) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
       		String infoForLogging="After finder transaction execution for getXPrivAgreementByLocationGroupId";
      logger.finest("getXPrivAgreementByLocationGroupId(String LocationGroupId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getXPrivAgreementByLocationGroupId(String LocationGroupId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }
    
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction
     * getXPrivAgreementByLocationGroupId.
     * 
     * @param LocationGroupId
     * @return com.dwl.base.DWLResponse
     * @exception Exception
     * @generated
     */
    public DWLResponse  handleGetXPrivAgreementByLocationGroupId(String LocationGroupId,  DWLControl control) throws Exception {

        DWLResponse response = new DWLResponse();

    DSEAAdditionsExts comp = 
      (DSEAAdditionsExts)TCRMClassFactory.getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
      
        response = comp.getXPrivAgreementByLocationGroupId(LocationGroupId,  control);
        if (response.getData() == null) {
            String[] params = new String[] { LocationGroupId };
            DWLExceptionUtils.addErrorToStatus(response.getStatus(), DWLStatus.FATAL,
          DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_CONTROLLER,
          TCRMErrorCode.READ_RECORD_ERROR,
          DSEAAdditionsExtsErrorReasonCode.GETXPRIVAGREEMENTBYLOCATIONGROUPID_FAILED,
          control, params, errHandler);					
        }
        return response;
    }
    
	
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXRetailer.
     *
     * @param RetailerpkId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetXRetailer
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETXRETAILER_FAILED)
     public DWLResponse getXRetailer(String RetailerpkId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getXRetailer(String RetailerpkId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(RetailerpkId);
        DWLTransaction txObj = new DWLTransactionInquiry("getXRetailer", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
      String infoForLogging="Before finder transaction execution for getXRetailer";
      logger.finest("getXRetailer(String RetailerpkId,  DWLControl control) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
       		String infoForLogging="After finder transaction execution for getXRetailer";
      logger.finest("getXRetailer(String RetailerpkId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getXRetailer(String RetailerpkId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }
    
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction getXRetailer.
     * 
     * @param RetailerpkId
     * @return com.dwl.base.DWLResponse
     * @exception Exception
     * @generated
     */
    public DWLResponse  handleGetXRetailer(String RetailerpkId,  DWLControl control) throws Exception {

        DWLResponse response = new DWLResponse();

    DSEAAdditionsExts comp = 
      (DSEAAdditionsExts)TCRMClassFactory.getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
      
        response = comp.getXRetailer(RetailerpkId,  control);
        if (response.getData() == null) {
            String[] params = new String[] { RetailerpkId };
            DWLExceptionUtils.addErrorToStatus(response.getStatus(), DWLStatus.FATAL,
          DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_CONTROLLER,
          TCRMErrorCode.READ_RECORD_ERROR,
          DSEAAdditionsExtsErrorReasonCode.GETXRETAILER_FAILED,
          control, params, errHandler);					
        }
        return response;
    }
    
	
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXRetailerByRetailerCode.
     *
     * @param RetailerCode
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetXRetailerByRetailerCode
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETXRETAILERBYRETAILERCODE_FAILED)
     public DWLResponse getXRetailerByRetailerCode(String RetailerCode,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getXRetailerByRetailerCode(String RetailerCode,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(RetailerCode);
        DWLTransaction txObj = new DWLTransactionInquiry("getXRetailerByRetailerCode", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
      String infoForLogging="Before finder transaction execution for getXRetailerByRetailerCode";
      logger.finest("getXRetailerByRetailerCode(String RetailerCode,  DWLControl control) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
       		String infoForLogging="After finder transaction execution for getXRetailerByRetailerCode";
      logger.finest("getXRetailerByRetailerCode(String RetailerCode,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getXRetailerByRetailerCode(String RetailerCode,  DWLControl control) " + returnValue);
    }
        return retObj;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction getXRetailerByRetailerCode.
     * 
     * @param RetailerCode
     * @return com.dwl.base.DWLResponse
     * @exception Exception
     * @generated
     */
    public DWLResponse  handleGetXRetailerByRetailerCode(String RetailerCode,  DWLControl control) throws Exception {

        DWLResponse response = new DWLResponse();

    DSEAAdditionsExts comp = 
      (DSEAAdditionsExts)TCRMClassFactory.getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
      
        response = comp.getXRetailerByRetailerCode(RetailerCode,  control);
        if (response.getData() == null) {
            String[] params = new String[] { RetailerCode };
            DWLExceptionUtils.addErrorToStatus(response.getStatus(), DWLStatus.FATAL,
          DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_CONTROLLER,
          TCRMErrorCode.READ_RECORD_ERROR,
          DSEAAdditionsExtsErrorReasonCode.GETXRETAILERBYRETAILERCODE_FAILED,
          control, params, errHandler);					
        }
        return response;
    }


  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXRetailerByNDCode.
     *
     * @param NDCode
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetXRetailerByNDCode
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETXRETAILERBYNDCODE_FAILED)
     public DWLResponse getXRetailerByNDCode(String NDCode,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getXRetailerByNDCode(String NDCode,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(NDCode);
        DWLTransaction txObj = new DWLTransactionInquiry("getXRetailerByNDCode", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
      String infoForLogging="Before finder transaction execution for getXRetailerByNDCode";
      logger.finest("getXRetailerByNDCode(String NDCode,  DWLControl control) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
       		String infoForLogging="After finder transaction execution for getXRetailerByNDCode";
      logger.finest("getXRetailerByNDCode(String NDCode,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getXRetailerByNDCode(String NDCode,  DWLControl control) " + returnValue);
    }
        return retObj;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction getXRetailerByNDCode.
     * 
     * @param NDCode
     * @return com.dwl.base.DWLResponse
     * @exception Exception
     * @generated
     */
    public DWLResponse  handleGetXRetailerByNDCode(String NDCode,  DWLControl control) throws Exception {

        DWLResponse response = new DWLResponse();

    DSEAAdditionsExts comp = 
      (DSEAAdditionsExts)TCRMClassFactory.getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
      
        response = comp.getXRetailerByNDCode(NDCode,  control);
        if (response.getData() == null) {
            String[] params = new String[] { NDCode };
            DWLExceptionUtils.addErrorToStatus(response.getStatus(), DWLStatus.FATAL,
          DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_CONTROLLER,
          TCRMErrorCode.READ_RECORD_ERROR,
          DSEAAdditionsExtsErrorReasonCode.GETXRETAILERBYNDCODE_FAILED,
          control, params, errHandler);					
        }
        return response;
    }


  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXRetailerByGSCode.
     *
     * @param GSCode
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetXRetailerByGSCode
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETXRETAILERBYGSCODE_FAILED)
     public DWLResponse getXRetailerByGSCode(String GSCode,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getXRetailerByGSCode(String GSCode,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(GSCode);
        DWLTransaction txObj = new DWLTransactionInquiry("getXRetailerByGSCode", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
      String infoForLogging="Before finder transaction execution for getXRetailerByGSCode";
      logger.finest("getXRetailerByGSCode(String GSCode,  DWLControl control) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
       		String infoForLogging="After finder transaction execution for getXRetailerByGSCode";
      logger.finest("getXRetailerByGSCode(String GSCode,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getXRetailerByGSCode(String GSCode,  DWLControl control) " + returnValue);
    }
        return retObj;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction getXRetailerByGSCode.
     * 
     * @param GSCode
     * @return com.dwl.base.DWLResponse
     * @exception Exception
     * @generated
     */
    public DWLResponse  handleGetXRetailerByGSCode(String GSCode,  DWLControl control) throws Exception {

        DWLResponse response = new DWLResponse();

    DSEAAdditionsExts comp = 
      (DSEAAdditionsExts)TCRMClassFactory.getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
      
        response = comp.getXRetailerByGSCode(GSCode,  control);
        if (response.getData() == null) {
            String[] params = new String[] { GSCode };
            DWLExceptionUtils.addErrorToStatus(response.getStatus(), DWLStatus.FATAL,
          DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_CONTROLLER,
          TCRMErrorCode.READ_RECORD_ERROR,
          DSEAAdditionsExtsErrorReasonCode.GETXRETAILERBYGSCODE_FAILED,
          control, params, errHandler);					
        }
        return response;
    }


  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXRetailerByGSCodeAndMarketName.
     *
     * @param GSCode
     * @param MarketName
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetXRetailerByGSCodeAndMarketName
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETXRETAILERBYGSCODEANDMARKETNAME_FAILED)
     public DWLResponse getXRetailerByGSCodeAndMarketName(String GSCode, String MarketName,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getXRetailerByGSCodeAndMarketName(String GSCode, String MarketName,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(GSCode);
        params.add(MarketName);
        DWLTransaction txObj = new DWLTransactionInquiry("getXRetailerByGSCodeAndMarketName", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
      String infoForLogging="Before finder transaction execution for getXRetailerByGSCodeAndMarketName";
      logger.finest("getXRetailerByGSCodeAndMarketName(String GSCode, String MarketName,  DWLControl control) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
       		String infoForLogging="After finder transaction execution for getXRetailerByGSCodeAndMarketName";
      logger.finest("getXRetailerByGSCodeAndMarketName(String GSCode, String MarketName,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getXRetailerByGSCodeAndMarketName(String GSCode, String MarketName,  DWLControl control) " + returnValue);
    }
        return retObj;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction
     * getXRetailerByGSCodeAndMarketName.
     * 
     * @param GSCode
     * @param MarketName
     * @return com.dwl.base.DWLResponse
     * @exception Exception
     * @generated
     */
    public DWLResponse  handleGetXRetailerByGSCodeAndMarketName(String GSCode, String MarketName,  DWLControl control) throws Exception {

        DWLResponse response = new DWLResponse();

    DSEAAdditionsExts comp = 
      (DSEAAdditionsExts)TCRMClassFactory.getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
      
        response = comp.getXRetailerByGSCodeAndMarketName(GSCode, MarketName,  control);
        if (response.getData() == null) {
            String[] params = new String[] { GSCode, MarketName };
            DWLExceptionUtils.addErrorToStatus(response.getStatus(), DWLStatus.FATAL,
          DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_CONTROLLER,
          TCRMErrorCode.READ_RECORD_ERROR,
          DSEAAdditionsExtsErrorReasonCode.GETXRETAILERBYGSCODEANDMARKETNAME_FAILED,
          control, params, errHandler);					
        }
        return response;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXRetailerByRetailerCodeAndMarketName.
     *
     * @param RetailerCode
     * @param MarketName
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetXRetailerByRetailerCodeAndMarketName
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETXRETAILERBYRETAILERCODEANDMARKETNAME_FAILED)
     public DWLResponse getXRetailerByRetailerCodeAndMarketName(String RetailerCode, String MarketName,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getXRetailerByRetailerCodeAndMarketName(String RetailerCode, String MarketName,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(RetailerCode);
        params.add(MarketName);
        DWLTransaction txObj = new DWLTransactionInquiry("getXRetailerByRetailerCodeAndMarketName", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
      String infoForLogging="Before finder transaction execution for getXRetailerByRetailerCodeAndMarketName";
      logger.finest("getXRetailerByRetailerCodeAndMarketName(String RetailerCode, String MarketName,  DWLControl control) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
       		String infoForLogging="After finder transaction execution for getXRetailerByRetailerCodeAndMarketName";
      logger.finest("getXRetailerByRetailerCodeAndMarketName(String RetailerCode, String MarketName,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getXRetailerByRetailerCodeAndMarketName(String RetailerCode, String MarketName,  DWLControl control) " + returnValue);
    }
        return retObj;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction
     * getXRetailerByRetailerCodeAndMarketName.
     * 
     * @param RetailerCode
     * @param MarketName
     * @return com.dwl.base.DWLResponse
     * @exception Exception
     * @generated
     */
    public DWLResponse  handleGetXRetailerByRetailerCodeAndMarketName(String RetailerCode, String MarketName,  DWLControl control) throws Exception {

        DWLResponse response = new DWLResponse();

    DSEAAdditionsExts comp = 
      (DSEAAdditionsExts)TCRMClassFactory.getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
      
        response = comp.getXRetailerByRetailerCodeAndMarketName(RetailerCode, MarketName,  control);
        if (response.getData() == null) {
            String[] params = new String[] { RetailerCode, MarketName };
            DWLExceptionUtils.addErrorToStatus(response.getStatus(), DWLStatus.FATAL,
          DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_CONTROLLER,
          TCRMErrorCode.READ_RECORD_ERROR,
          DSEAAdditionsExtsErrorReasonCode.GETXRETAILERBYRETAILERCODEANDMARKETNAME_FAILED,
          control, params, errHandler);					
        }
        return response;
    }


  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXRetailerByNDCodeAndMarketName.
     *
     * @param NDCode
     * @param MarketName
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetXRetailerByNDCodeAndMarketName
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETXRETAILERBYNDCODEANDMARKETNAME_FAILED)
     public DWLResponse getXRetailerByNDCodeAndMarketName(String NDCode, String MarketName,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getXRetailerByNDCodeAndMarketName(String NDCode, String MarketName,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(NDCode);
        params.add(MarketName);
        DWLTransaction txObj = new DWLTransactionInquiry("getXRetailerByNDCodeAndMarketName", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
      String infoForLogging="Before finder transaction execution for getXRetailerByNDCodeAndMarketName";
      logger.finest("getXRetailerByNDCodeAndMarketName(String NDCode, String MarketName,  DWLControl control) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
       		String infoForLogging="After finder transaction execution for getXRetailerByNDCodeAndMarketName";
      logger.finest("getXRetailerByNDCodeAndMarketName(String NDCode, String MarketName,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getXRetailerByNDCodeAndMarketName(String NDCode, String MarketName,  DWLControl control) " + returnValue);
    }
        return retObj;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction
     * getXRetailerByNDCodeAndMarketName.
     * 
     * @param NDCode
     * @param MarketName
     * @return com.dwl.base.DWLResponse
     * @exception Exception
     * @generated
     */
    public DWLResponse  handleGetXRetailerByNDCodeAndMarketName(String NDCode, String MarketName,  DWLControl control) throws Exception {

        DWLResponse response = new DWLResponse();

    DSEAAdditionsExts comp = 
      (DSEAAdditionsExts)TCRMClassFactory.getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
      
        response = comp.getXRetailerByNDCodeAndMarketName(NDCode, MarketName,  control);
        if (response.getData() == null) {
            String[] params = new String[] { NDCode, MarketName };
            DWLExceptionUtils.addErrorToStatus(response.getStatus(), DWLStatus.FATAL,
          DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_CONTROLLER,
          TCRMErrorCode.READ_RECORD_ERROR,
          DSEAAdditionsExtsErrorReasonCode.GETXRETAILERBYNDCODEANDMARKETNAME_FAILED,
          control, params, errHandler);					
        }
        return response;
    }


  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXCustomerRetailer.
     *
     * @param CustomerRetailerpkId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetXCustomerRetailer
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETXCUSTOMERRETAILER_FAILED)
     public DWLResponse getXCustomerRetailer(String CustomerRetailerpkId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getXCustomerRetailer(String CustomerRetailerpkId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(CustomerRetailerpkId);
        DWLTransaction txObj = new DWLTransactionInquiry("getXCustomerRetailer", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
      String infoForLogging="Before finder transaction execution for getXCustomerRetailer";
      logger.finest("getXCustomerRetailer(String CustomerRetailerpkId,  DWLControl control) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
       		String infoForLogging="After finder transaction execution for getXCustomerRetailer";
      logger.finest("getXCustomerRetailer(String CustomerRetailerpkId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getXCustomerRetailer(String CustomerRetailerpkId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }
    
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction getXCustomerRetailer.
     * 
     * @param CustomerRetailerpkId
     * @return com.dwl.base.DWLResponse
     * @exception Exception
     * @generated
     */
    public DWLResponse  handleGetXCustomerRetailer(String CustomerRetailerpkId,  DWLControl control) throws Exception {

        DWLResponse response = new DWLResponse();

    DSEAAdditionsExts comp = 
      (DSEAAdditionsExts)TCRMClassFactory.getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
      
        response = comp.getXCustomerRetailer(CustomerRetailerpkId,  control);
        if (response.getData() == null) {
            String[] params = new String[] { CustomerRetailerpkId };
            DWLExceptionUtils.addErrorToStatus(response.getStatus(), DWLStatus.FATAL,
          DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_CONTROLLER,
          TCRMErrorCode.READ_RECORD_ERROR,
          DSEAAdditionsExtsErrorReasonCode.GETXCUSTOMERRETAILER_FAILED,
          control, params, errHandler);					
        }
        return response;
    }
    
	
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getAllXCustomerRetailerByPartyId.
     *
     * @param ContId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetAllXCustomerRetailerByPartyId
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETALLXCUSTOMERRETAILERBYPARTYID_FAILED)
     public DWLResponse getAllXCustomerRetailerByPartyId(String ContId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getAllXCustomerRetailerByPartyId(String ContId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(ContId);
        DWLTransaction txObj = new DWLTransactionInquiry("getAllXCustomerRetailerByPartyId", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
      String infoForLogging="Before finder transaction execution for getAllXCustomerRetailerByPartyId";
      logger.finest("getAllXCustomerRetailerByPartyId(String ContId,  DWLControl control) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
       		String infoForLogging="After finder transaction execution for getAllXCustomerRetailerByPartyId";
      logger.finest("getAllXCustomerRetailerByPartyId(String ContId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getAllXCustomerRetailerByPartyId(String ContId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction
     * getAllXCustomerRetailerByPartyId.
     * 
     * @param ContId
     * @return com.dwl.base.DWLResponse
     * @exception Exception
     * @generated
     */
    public DWLResponse  handleGetAllXCustomerRetailerByPartyId(String ContId,  DWLControl control) throws Exception {

        DWLResponse response = new DWLResponse();

    DSEAAdditionsExts comp = 
      (DSEAAdditionsExts)TCRMClassFactory.getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
      
        response = comp.getAllXCustomerRetailerByPartyId(ContId,  control);
        if (response.getData() == null) {
            String[] params = new String[] { ContId };
            DWLExceptionUtils.addErrorToStatus(response.getStatus(), DWLStatus.FATAL,
          DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_CONTROLLER,
          TCRMErrorCode.READ_RECORD_ERROR,
          DSEAAdditionsExtsErrorReasonCode.GETALLXCUSTOMERRETAILERBYPARTYID_FAILED,
          control, params, errHandler);					
        }
        return response;
    }


  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXCustomerRetailerRole.
     *
     * @param CustomerRetailerRolepkId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetXCustomerRetailerRole
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETXCUSTOMERRETAILERROLE_FAILED)
     public DWLResponse getXCustomerRetailerRole(String CustomerRetailerRolepkId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getXCustomerRetailerRole(String CustomerRetailerRolepkId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(CustomerRetailerRolepkId);
        DWLTransaction txObj = new DWLTransactionInquiry("getXCustomerRetailerRole", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
      String infoForLogging="Before finder transaction execution for getXCustomerRetailerRole";
      logger.finest("getXCustomerRetailerRole(String CustomerRetailerRolepkId,  DWLControl control) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
       		String infoForLogging="After finder transaction execution for getXCustomerRetailerRole";
      logger.finest("getXCustomerRetailerRole(String CustomerRetailerRolepkId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getXCustomerRetailerRole(String CustomerRetailerRolepkId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }
    
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction getXCustomerRetailerRole.
     * 
     * @param CustomerRetailerRolepkId
     * @return com.dwl.base.DWLResponse
     * @exception Exception
     * @generated
     */
    public DWLResponse  handleGetXCustomerRetailerRole(String CustomerRetailerRolepkId,  DWLControl control) throws Exception {

        DWLResponse response = new DWLResponse();

    DSEAAdditionsExts comp = 
      (DSEAAdditionsExts)TCRMClassFactory.getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
      
        response = comp.getXCustomerRetailerRole(CustomerRetailerRolepkId,  control);
        if (response.getData() == null) {
            String[] params = new String[] { CustomerRetailerRolepkId };
            DWLExceptionUtils.addErrorToStatus(response.getStatus(), DWLStatus.FATAL,
          DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_CONTROLLER,
          TCRMErrorCode.READ_RECORD_ERROR,
          DSEAAdditionsExtsErrorReasonCode.GETXCUSTOMERRETAILERROLE_FAILED,
          control, params, errHandler);					
        }
        return response;
    }
    
	
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getAllRetailerRoleByCustomerRetailerId.
     *
     * @param CustomerRetailerId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetAllRetailerRoleByCustomerRetailerId
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETALLRETAILERROLEBYCUSTOMERRETAILERID_FAILED)
     public DWLResponse getAllRetailerRoleByCustomerRetailerId(String CustomerRetailerId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getAllRetailerRoleByCustomerRetailerId(String CustomerRetailerId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(CustomerRetailerId);
        DWLTransaction txObj = new DWLTransactionInquiry("getAllRetailerRoleByCustomerRetailerId", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
      String infoForLogging="Before finder transaction execution for getAllRetailerRoleByCustomerRetailerId";
      logger.finest("getAllRetailerRoleByCustomerRetailerId(String CustomerRetailerId,  DWLControl control) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
       		String infoForLogging="After finder transaction execution for getAllRetailerRoleByCustomerRetailerId";
      logger.finest("getAllRetailerRoleByCustomerRetailerId(String CustomerRetailerId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getAllRetailerRoleByCustomerRetailerId(String CustomerRetailerId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }
    
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction
     * getAllRetailerRoleByCustomerRetailerId.
     * 
     * @param CustomerRetailerId
     * @return com.dwl.base.DWLResponse
     * @exception Exception
     * @generated
     */
    public DWLResponse  handleGetAllRetailerRoleByCustomerRetailerId(String CustomerRetailerId,  DWLControl control) throws Exception {

        DWLResponse response = new DWLResponse();

    DSEAAdditionsExts comp = 
      (DSEAAdditionsExts)TCRMClassFactory.getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
      
        response = comp.getAllRetailerRoleByCustomerRetailerId(CustomerRetailerId,  control);
        if (response.getData() == null) {
            String[] params = new String[] { CustomerRetailerId };
            DWLExceptionUtils.addErrorToStatus(response.getStatus(), DWLStatus.FATAL,
          DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_CONTROLLER,
          TCRMErrorCode.READ_RECORD_ERROR,
          DSEAAdditionsExtsErrorReasonCode.GETALLRETAILERROLEBYCUSTOMERRETAILERID_FAILED,
          control, params, errHandler);					
        }
        return response;
    }
    
	
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXVehicle.
     *
     * @param VehiclepkId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetXVehicle
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETXVEHICLE_FAILED)
     public DWLResponse getXVehicle(String VehiclepkId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getXVehicle(String VehiclepkId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(VehiclepkId);
        DWLTransaction txObj = new DWLTransactionInquiry("getXVehicle", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
      String infoForLogging="Before finder transaction execution for getXVehicle";
      logger.finest("getXVehicle(String VehiclepkId,  DWLControl control) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
       		String infoForLogging="After finder transaction execution for getXVehicle";
      logger.finest("getXVehicle(String VehiclepkId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getXVehicle(String VehiclepkId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }
    
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction getXVehicle.
     * 
     * @param VehiclepkId
     * @return com.dwl.base.DWLResponse
     * @exception Exception
     * @generated
     */
    public DWLResponse  handleGetXVehicle(String VehiclepkId,  DWLControl control) throws Exception {

        DWLResponse response = new DWLResponse();

    DSEAAdditionsExts comp = 
      (DSEAAdditionsExts)TCRMClassFactory.getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
      
        response = comp.getXVehicle(VehiclepkId,  control);
        if (response.getData() == null) {
            String[] params = new String[] { VehiclepkId };
            DWLExceptionUtils.addErrorToStatus(response.getStatus(), DWLStatus.FATAL,
          DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_CONTROLLER,
          TCRMErrorCode.READ_RECORD_ERROR,
          DSEAAdditionsExtsErrorReasonCode.GETXVEHICLE_FAILED,
          control, params, errHandler);					
        }
        return response;
    }
    
	
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXCustomerVehicle.
     *
     * @param CustomerVehiclepkId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetXCustomerVehicle
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETXCUSTOMERVEHICLE_FAILED)
     public DWLResponse getXCustomerVehicle(String CustomerVehiclepkId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getXCustomerVehicle(String CustomerVehiclepkId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(CustomerVehiclepkId);
        DWLTransaction txObj = new DWLTransactionInquiry("getXCustomerVehicle", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
      String infoForLogging="Before finder transaction execution for getXCustomerVehicle";
      logger.finest("getXCustomerVehicle(String CustomerVehiclepkId,  DWLControl control) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
       		String infoForLogging="After finder transaction execution for getXCustomerVehicle";
      logger.finest("getXCustomerVehicle(String CustomerVehiclepkId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getXCustomerVehicle(String CustomerVehiclepkId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }
    
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction getXCustomerVehicle.
     * 
     * @param CustomerVehiclepkId
     * @return com.dwl.base.DWLResponse
     * @exception Exception
     * @generated
     */
    public DWLResponse  handleGetXCustomerVehicle(String CustomerVehiclepkId,  DWLControl control) throws Exception {

        DWLResponse response = new DWLResponse();

    DSEAAdditionsExts comp = 
      (DSEAAdditionsExts)TCRMClassFactory.getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
      
        response = comp.getXCustomerVehicle(CustomerVehiclepkId,  control);
        if (response.getData() == null) {
            String[] params = new String[] { CustomerVehiclepkId };
            DWLExceptionUtils.addErrorToStatus(response.getStatus(), DWLStatus.FATAL,
          DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_CONTROLLER,
          TCRMErrorCode.READ_RECORD_ERROR,
          DSEAAdditionsExtsErrorReasonCode.GETXCUSTOMERVEHICLE_FAILED,
          control, params, errHandler);					
        }
        return response;
    }
    
	
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getAllXCustomerVehicleByPartyId.
     *
     * @param ContId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetAllXCustomerVehicleByPartyId
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETALLXCUSTOMERVEHICLEBYPARTYID_FAILED)
     public DWLResponse getAllXCustomerVehicleByPartyId(String ContId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getAllXCustomerVehicleByPartyId(String ContId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(ContId);
        DWLTransaction txObj = new DWLTransactionInquiry("getAllXCustomerVehicleByPartyId", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
      String infoForLogging="Before finder transaction execution for getAllXCustomerVehicleByPartyId";
      logger.finest("getAllXCustomerVehicleByPartyId(String ContId,  DWLControl control) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
       		String infoForLogging="After finder transaction execution for getAllXCustomerVehicleByPartyId";
      logger.finest("getAllXCustomerVehicleByPartyId(String ContId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getAllXCustomerVehicleByPartyId(String ContId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction
     * getAllXCustomerVehicleByPartyId.
     * 
     * @param ContId
     * @return com.dwl.base.DWLResponse
     * @exception Exception
     * @generated
     */
    public DWLResponse  handleGetAllXCustomerVehicleByPartyId(String ContId,  DWLControl control) throws Exception {

        DWLResponse response = new DWLResponse();

    DSEAAdditionsExts comp = 
      (DSEAAdditionsExts)TCRMClassFactory.getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
      
        response = comp.getAllXCustomerVehicleByPartyId(ContId,  control);
        if (response.getData() == null) {
            String[] params = new String[] { ContId };
            DWLExceptionUtils.addErrorToStatus(response.getStatus(), DWLStatus.FATAL,
          DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_CONTROLLER,
          TCRMErrorCode.READ_RECORD_ERROR,
          DSEAAdditionsExtsErrorReasonCode.GETALLXCUSTOMERVEHICLEBYPARTYID_FAILED,
          control, params, errHandler);					
        }
        return response;
    }


  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXCustomerVehicleRole.
     *
     * @param CustomerVehicleRolepkId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetXCustomerVehicleRole
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETXCUSTOMERVEHICLEROLE_FAILED)
     public DWLResponse getXCustomerVehicleRole(String CustomerVehicleRolepkId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getXCustomerVehicleRole(String CustomerVehicleRolepkId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(CustomerVehicleRolepkId);
        DWLTransaction txObj = new DWLTransactionInquiry("getXCustomerVehicleRole", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
      String infoForLogging="Before finder transaction execution for getXCustomerVehicleRole";
      logger.finest("getXCustomerVehicleRole(String CustomerVehicleRolepkId,  DWLControl control) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
       		String infoForLogging="After finder transaction execution for getXCustomerVehicleRole";
      logger.finest("getXCustomerVehicleRole(String CustomerVehicleRolepkId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getXCustomerVehicleRole(String CustomerVehicleRolepkId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }
    
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction getXCustomerVehicleRole.
     * 
     * @param CustomerVehicleRolepkId
     * @return com.dwl.base.DWLResponse
     * @exception Exception
     * @generated
     */
    public DWLResponse  handleGetXCustomerVehicleRole(String CustomerVehicleRolepkId,  DWLControl control) throws Exception {

        DWLResponse response = new DWLResponse();

    DSEAAdditionsExts comp = 
      (DSEAAdditionsExts)TCRMClassFactory.getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
      
        response = comp.getXCustomerVehicleRole(CustomerVehicleRolepkId,  control);
        if (response.getData() == null) {
            String[] params = new String[] { CustomerVehicleRolepkId };
            DWLExceptionUtils.addErrorToStatus(response.getStatus(), DWLStatus.FATAL,
          DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_CONTROLLER,
          TCRMErrorCode.READ_RECORD_ERROR,
          DSEAAdditionsExtsErrorReasonCode.GETXCUSTOMERVEHICLEROLE_FAILED,
          control, params, errHandler);					
        }
        return response;
    }
    
	
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getAllVehicleRoleByCustomerVehicleId.
     *
     * @param CustomerVehicleId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetAllVehicleRoleByCustomerVehicleId
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETALLVEHICLEROLEBYCUSTOMERVEHICLEID_FAILED)
     public DWLResponse getAllVehicleRoleByCustomerVehicleId(String CustomerVehicleId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getAllVehicleRoleByCustomerVehicleId(String CustomerVehicleId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(CustomerVehicleId);
        DWLTransaction txObj = new DWLTransactionInquiry("getAllVehicleRoleByCustomerVehicleId", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
      String infoForLogging="Before finder transaction execution for getAllVehicleRoleByCustomerVehicleId";
      logger.finest("getAllVehicleRoleByCustomerVehicleId(String CustomerVehicleId,  DWLControl control) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
       		String infoForLogging="After finder transaction execution for getAllVehicleRoleByCustomerVehicleId";
      logger.finest("getAllVehicleRoleByCustomerVehicleId(String CustomerVehicleId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getAllVehicleRoleByCustomerVehicleId(String CustomerVehicleId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }
    
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction
     * getAllVehicleRoleByCustomerVehicleId.
     * 
     * @param CustomerVehicleId
     * @return com.dwl.base.DWLResponse
     * @exception Exception
     * @generated
     */
    public DWLResponse  handleGetAllVehicleRoleByCustomerVehicleId(String CustomerVehicleId,  DWLControl control) throws Exception {

        DWLResponse response = new DWLResponse();

    DSEAAdditionsExts comp = 
      (DSEAAdditionsExts)TCRMClassFactory.getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
      
        response = comp.getAllVehicleRoleByCustomerVehicleId(CustomerVehicleId,  control);
        if (response.getData() == null) {
            String[] params = new String[] { CustomerVehicleId };
            DWLExceptionUtils.addErrorToStatus(response.getStatus(), DWLStatus.FATAL,
          DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_CONTROLLER,
          TCRMErrorCode.READ_RECORD_ERROR,
          DSEAAdditionsExtsErrorReasonCode.GETALLVEHICLEROLEBYCUSTOMERVEHICLEID_FAILED,
          control, params, errHandler);					
        }
        return response;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXCompanyIdentification.
     *
     * @param CompanyIdentificationpkId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetXCompanyIdentification
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETXCOMPANYIDENTIFICATION_FAILED)
     public DWLResponse getXCompanyIdentification(String CompanyIdentificationpkId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getXCompanyIdentification(String CompanyIdentificationpkId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(CompanyIdentificationpkId);
        DWLTransaction txObj = new DWLTransactionInquiry("getXCompanyIdentification", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
      String infoForLogging="Before finder transaction execution for getXCompanyIdentification";
      logger.finest("getXCompanyIdentification(String CompanyIdentificationpkId,  DWLControl control) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
       		String infoForLogging="After finder transaction execution for getXCompanyIdentification";
      logger.finest("getXCompanyIdentification(String CompanyIdentificationpkId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getXCompanyIdentification(String CompanyIdentificationpkId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction getXCompanyIdentification.
     * 
     * @param CompanyIdentificationpkId
     * @return com.dwl.base.DWLResponse
     * @exception Exception
     * @generated
     */
    public DWLResponse  handleGetXCompanyIdentification(String CompanyIdentificationpkId,  DWLControl control) throws Exception {

        DWLResponse response = new DWLResponse();

    DSEAAdditionsExts comp = 
      (DSEAAdditionsExts)TCRMClassFactory.getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
      
        response = comp.getXCompanyIdentification(CompanyIdentificationpkId,  control);
        if (response.getData() == null) {
            String[] params = new String[] { CompanyIdentificationpkId };
            DWLExceptionUtils.addErrorToStatus(response.getStatus(), DWLStatus.FATAL,
          DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_CONTROLLER,
          TCRMErrorCode.READ_RECORD_ERROR,
          DSEAAdditionsExtsErrorReasonCode.GETXCOMPANYIDENTIFICATION_FAILED,
          control, params, errHandler);					
        }
        return response;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXContractDetails.
     *
     * @param ContractpkId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetXContractDetails
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETXCONTRACTDETAILS_FAILED)
     public DWLResponse getXContractDetails(String ContractpkId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getXContractDetails(String ContractpkId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(ContractpkId);
        DWLTransaction txObj = new DWLTransactionInquiry("getXContractDetails", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
      String infoForLogging="Before finder transaction execution for getXContractDetails";
      logger.finest("getXContractDetails(String ContractpkId,  DWLControl control) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
       		String infoForLogging="After finder transaction execution for getXContractDetails";
      logger.finest("getXContractDetails(String ContractpkId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getXContractDetails(String ContractpkId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction getXContractDetails.
     * 
     * @param ContractpkId
     * @return com.dwl.base.DWLResponse
     * @exception Exception
     * @generated
     */
    public DWLResponse  handleGetXContractDetails(String ContractpkId,  DWLControl control) throws Exception {

        DWLResponse response = new DWLResponse();

    DSEAAdditionsExts comp = 
      (DSEAAdditionsExts)TCRMClassFactory.getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
      
        response = comp.getXContractDetails(ContractpkId,  control);
        if (response.getData() == null) {
            String[] params = new String[] { ContractpkId };
            DWLExceptionUtils.addErrorToStatus(response.getStatus(), DWLStatus.FATAL,
          DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_CONTROLLER,
          TCRMErrorCode.READ_RECORD_ERROR,
          DSEAAdditionsExtsErrorReasonCode.GETXCONTRACTDETAILS_FAILED,
          control, params, errHandler);					
        }
        return response;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getAllXContractDetailsByPartyId.
     *
     * @param ContId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetAllXContractDetailsByPartyId
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETALLXCONTRACTDETAILSBYPARTYID_FAILED)
     public DWLResponse getAllXContractDetailsByPartyId(String ContId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getAllXContractDetailsByPartyId(String ContId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(ContId);
        DWLTransaction txObj = new DWLTransactionInquiry("getAllXContractDetailsByPartyId", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
      String infoForLogging="Before finder transaction execution for getAllXContractDetailsByPartyId";
      logger.finest("getAllXContractDetailsByPartyId(String ContId,  DWLControl control) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
       		String infoForLogging="After finder transaction execution for getAllXContractDetailsByPartyId";
      logger.finest("getAllXContractDetailsByPartyId(String ContId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getAllXContractDetailsByPartyId(String ContId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction
     * getAllXContractDetailsByPartyId.
     * 
     * @param ContId
     * @return com.dwl.base.DWLResponse
     * @exception Exception
     * @generated
     */
    public DWLResponse  handleGetAllXContractDetailsByPartyId(String ContId,  DWLControl control) throws Exception {

        DWLResponse response = new DWLResponse();

    DSEAAdditionsExts comp = 
      (DSEAAdditionsExts)TCRMClassFactory.getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
      
        response = comp.getAllXContractDetailsByPartyId(ContId,  control);
        if (response.getData() == null) {
            String[] params = new String[] { ContId };
            DWLExceptionUtils.addErrorToStatus(response.getStatus(), DWLStatus.FATAL,
          DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_CONTROLLER,
          TCRMErrorCode.READ_RECORD_ERROR,
          DSEAAdditionsExtsErrorReasonCode.GETALLXCONTRACTDETAILSBYPARTYID_FAILED,
          control, params, errHandler);					
        }
        return response;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXGurantorIndividual.
     *
     * @param XGurantorIndividualpkId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetXGurantorIndividual
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETXGURANTORINDIVIDUAL_FAILED)
     public DWLResponse getXGurantorIndividual(String XGurantorIndividualpkId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getXGurantorIndividual(String XGurantorIndividualpkId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(XGurantorIndividualpkId);
        DWLTransaction txObj = new DWLTransactionInquiry("getXGurantorIndividual", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
      String infoForLogging="Before finder transaction execution for getXGurantorIndividual";
      logger.finest("getXGurantorIndividual(String XGurantorIndividualpkId,  DWLControl control) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
       		String infoForLogging="After finder transaction execution for getXGurantorIndividual";
      logger.finest("getXGurantorIndividual(String XGurantorIndividualpkId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getXGurantorIndividual(String XGurantorIndividualpkId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction getXGurantorIndividual.
     * 
     * @param XGurantorIndividualpkId
     * @return com.dwl.base.DWLResponse
     * @exception Exception
     * @generated
     */
    public DWLResponse  handleGetXGurantorIndividual(String XGurantorIndividualpkId,  DWLControl control) throws Exception {

        DWLResponse response = new DWLResponse();

    DSEAAdditionsExts comp = 
      (DSEAAdditionsExts)TCRMClassFactory.getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
      
        response = comp.getXGurantorIndividual(XGurantorIndividualpkId,  control);
        if (response.getData() == null) {
            String[] params = new String[] { XGurantorIndividualpkId };
            DWLExceptionUtils.addErrorToStatus(response.getStatus(), DWLStatus.FATAL,
          DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_CONTROLLER,
          TCRMErrorCode.READ_RECORD_ERROR,
          DSEAAdditionsExtsErrorReasonCode.GETXGURANTORINDIVIDUAL_FAILED,
          control, params, errHandler);					
        }
        return response;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getAllXGurantorIndividualByContractDetailsId.
     *
     * @param ContractDetailsId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetAllXGurantorIndividualByContractDetailsId
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETALLXGURANTORINDIVIDUALBYCONTRACTDETAILSID_FAILED)
     public DWLResponse getAllXGurantorIndividualByContractDetailsId(String ContractDetailsId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getAllXGurantorIndividualByContractDetailsId(String ContractDetailsId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(ContractDetailsId);
        DWLTransaction txObj = new DWLTransactionInquiry("getAllXGurantorIndividualByContractDetailsId", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
      String infoForLogging="Before finder transaction execution for getAllXGurantorIndividualByContractDetailsId";
      logger.finest("getAllXGurantorIndividualByContractDetailsId(String ContractDetailsId,  DWLControl control) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
       		String infoForLogging="After finder transaction execution for getAllXGurantorIndividualByContractDetailsId";
      logger.finest("getAllXGurantorIndividualByContractDetailsId(String ContractDetailsId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getAllXGurantorIndividualByContractDetailsId(String ContractDetailsId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction
     * getAllXGurantorIndividualByContractDetailsId.
     * 
     * @param ContractDetailsId
     * @return com.dwl.base.DWLResponse
     * @exception Exception
     * @generated
     */
    public DWLResponse  handleGetAllXGurantorIndividualByContractDetailsId(String ContractDetailsId,  DWLControl control) throws Exception {

        DWLResponse response = new DWLResponse();

    DSEAAdditionsExts comp = 
      (DSEAAdditionsExts)TCRMClassFactory.getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
      
        response = comp.getAllXGurantorIndividualByContractDetailsId(ContractDetailsId,  control);
        if (response.getData() == null) {
            String[] params = new String[] { ContractDetailsId };
            DWLExceptionUtils.addErrorToStatus(response.getStatus(), DWLStatus.FATAL,
          DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_CONTROLLER,
          TCRMErrorCode.READ_RECORD_ERROR,
          DSEAAdditionsExtsErrorReasonCode.GETALLXGURANTORINDIVIDUALBYCONTRACTDETAILSID_FAILED,
          control, params, errHandler);					
        }
        return response;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXGurantorCompany.
     *
     * @param XGurantorCompanypkId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetXGurantorCompany
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETXGURANTORCOMPANY_FAILED)
     public DWLResponse getXGurantorCompany(String XGurantorCompanypkId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getXGurantorCompany(String XGurantorCompanypkId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(XGurantorCompanypkId);
        DWLTransaction txObj = new DWLTransactionInquiry("getXGurantorCompany", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
      String infoForLogging="Before finder transaction execution for getXGurantorCompany";
      logger.finest("getXGurantorCompany(String XGurantorCompanypkId,  DWLControl control) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
       		String infoForLogging="After finder transaction execution for getXGurantorCompany";
      logger.finest("getXGurantorCompany(String XGurantorCompanypkId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getXGurantorCompany(String XGurantorCompanypkId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction getXGurantorCompany.
     * 
     * @param XGurantorCompanypkId
     * @return com.dwl.base.DWLResponse
     * @exception Exception
     * @generated
     */
    public DWLResponse  handleGetXGurantorCompany(String XGurantorCompanypkId,  DWLControl control) throws Exception {

        DWLResponse response = new DWLResponse();

    DSEAAdditionsExts comp = 
      (DSEAAdditionsExts)TCRMClassFactory.getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
      
        response = comp.getXGurantorCompany(XGurantorCompanypkId,  control);
        if (response.getData() == null) {
            String[] params = new String[] { XGurantorCompanypkId };
            DWLExceptionUtils.addErrorToStatus(response.getStatus(), DWLStatus.FATAL,
          DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_CONTROLLER,
          TCRMErrorCode.READ_RECORD_ERROR,
          DSEAAdditionsExtsErrorReasonCode.GETXGURANTORCOMPANY_FAILED,
          control, params, errHandler);					
        }
        return response;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getAllXGurantorCompanyByContractDetailsId.
     *
     * @param ContractDetailsId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetAllXGurantorCompanyByContractDetailsId
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETALLXGURANTORCOMPANYBYCONTRACTDETAILSID_FAILED)
     public DWLResponse getAllXGurantorCompanyByContractDetailsId(String ContractDetailsId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getAllXGurantorCompanyByContractDetailsId(String ContractDetailsId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(ContractDetailsId);
        DWLTransaction txObj = new DWLTransactionInquiry("getAllXGurantorCompanyByContractDetailsId", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
      String infoForLogging="Before finder transaction execution for getAllXGurantorCompanyByContractDetailsId";
      logger.finest("getAllXGurantorCompanyByContractDetailsId(String ContractDetailsId,  DWLControl control) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
       		String infoForLogging="After finder transaction execution for getAllXGurantorCompanyByContractDetailsId";
      logger.finest("getAllXGurantorCompanyByContractDetailsId(String ContractDetailsId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getAllXGurantorCompanyByContractDetailsId(String ContractDetailsId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction
     * getAllXGurantorCompanyByContractDetailsId.
     * 
     * @param ContractDetailsId
     * @return com.dwl.base.DWLResponse
     * @exception Exception
     * @generated
     */
    public DWLResponse  handleGetAllXGurantorCompanyByContractDetailsId(String ContractDetailsId,  DWLControl control) throws Exception {

        DWLResponse response = new DWLResponse();

    DSEAAdditionsExts comp = 
      (DSEAAdditionsExts)TCRMClassFactory.getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
      
        response = comp.getAllXGurantorCompanyByContractDetailsId(ContractDetailsId,  control);
        if (response.getData() == null) {
            String[] params = new String[] { ContractDetailsId };
            DWLExceptionUtils.addErrorToStatus(response.getStatus(), DWLStatus.FATAL,
          DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_CONTROLLER,
          TCRMErrorCode.READ_RECORD_ERROR,
          DSEAAdditionsExtsErrorReasonCode.GETALLXGURANTORCOMPANYBYCONTRACTDETAILSID_FAILED,
          control, params, errHandler);					
        }
        return response;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXDealerRetailer.
     *
     * @param XDealerRetailerpkId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetXDealerRetailer
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETXDEALERRETAILER_FAILED)
     public DWLResponse getXDealerRetailer(String XDealerRetailerpkId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getXDealerRetailer(String XDealerRetailerpkId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(XDealerRetailerpkId);
        DWLTransaction txObj = new DWLTransactionInquiry("getXDealerRetailer", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
      String infoForLogging="Before finder transaction execution for getXDealerRetailer";
      logger.finest("getXDealerRetailer(String XDealerRetailerpkId,  DWLControl control) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
       		String infoForLogging="After finder transaction execution for getXDealerRetailer";
      logger.finest("getXDealerRetailer(String XDealerRetailerpkId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getXDealerRetailer(String XDealerRetailerpkId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction getXDealerRetailer.
     * 
     * @param XDealerRetailerpkId
     * @return com.dwl.base.DWLResponse
     * @exception Exception
     * @generated
     */
    public DWLResponse  handleGetXDealerRetailer(String XDealerRetailerpkId,  DWLControl control) throws Exception {

        DWLResponse response = new DWLResponse();

    DSEAAdditionsExts comp = 
      (DSEAAdditionsExts)TCRMClassFactory.getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
      
        response = comp.getXDealerRetailer(XDealerRetailerpkId,  control);
        if (response.getData() == null) {
            String[] params = new String[] { XDealerRetailerpkId };
            DWLExceptionUtils.addErrorToStatus(response.getStatus(), DWLStatus.FATAL,
          DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_CONTROLLER,
          TCRMErrorCode.READ_RECORD_ERROR,
          DSEAAdditionsExtsErrorReasonCode.GETXDEALERRETAILER_FAILED,
          control, params, errHandler);					
        }
        return response;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXMagicRel.
     *
     * @param XMagicRelpkId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetXMagicRel
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETXMAGICREL_FAILED)
     public DWLResponse getXMagicRel(String XMagicRelpkId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getXMagicRel(String XMagicRelpkId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(XMagicRelpkId);
        DWLTransaction txObj = new DWLTransactionInquiry("getXMagicRel", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
      String infoForLogging="Before finder transaction execution for getXMagicRel";
      logger.finest("getXMagicRel(String XMagicRelpkId,  DWLControl control) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
       		String infoForLogging="After finder transaction execution for getXMagicRel";
      logger.finest("getXMagicRel(String XMagicRelpkId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getXMagicRel(String XMagicRelpkId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction getXMagicRel.
     * 
     * @param XMagicRelpkId
     * @return com.dwl.base.DWLResponse
     * @exception Exception
     * @generated
     */
    public DWLResponse  handleGetXMagicRel(String XMagicRelpkId,  DWLControl control) throws Exception {

        DWLResponse response = new DWLResponse();

    DSEAAdditionsExts comp = 
      (DSEAAdditionsExts)TCRMClassFactory.getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
      
        response = comp.getXMagicRel(XMagicRelpkId,  control);
        if (response.getData() == null) {
            String[] params = new String[] { XMagicRelpkId };
            DWLExceptionUtils.addErrorToStatus(response.getStatus(), DWLStatus.FATAL,
          DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_CONTROLLER,
          TCRMErrorCode.READ_RECORD_ERROR,
          DSEAAdditionsExtsErrorReasonCode.GETXMAGICREL_FAILED,
          control, params, errHandler);					
        }
        return response;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXConsent.
     *
     * @param XConsentpkId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetXConsent
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETXCONSENT_FAILED)
     public DWLResponse getXConsent(String XConsentpkId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getXConsent(String XConsentpkId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(XConsentpkId);
        DWLTransaction txObj = new DWLTransactionInquiry("getXConsent", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
      String infoForLogging="Before finder transaction execution for getXConsent";
      logger.finest("getXConsent(String XConsentpkId,  DWLControl control) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
       		String infoForLogging="After finder transaction execution for getXConsent";
      logger.finest("getXConsent(String XConsentpkId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getXConsent(String XConsentpkId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction getXConsent.
     * 
     * @param XConsentpkId
     * @return com.dwl.base.DWLResponse
     * @exception Exception
     * @generated
     */
    public DWLResponse  handleGetXConsent(String XConsentpkId,  DWLControl control) throws Exception {

        DWLResponse response = new DWLResponse();

    DSEAAdditionsExts comp = 
      (DSEAAdditionsExts)TCRMClassFactory.getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
      
        response = comp.getXConsent(XConsentpkId,  control);
        if (response.getData() == null) {
            String[] params = new String[] { XConsentpkId };
            DWLExceptionUtils.addErrorToStatus(response.getStatus(), DWLStatus.FATAL,
          DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_CONTROLLER,
          TCRMErrorCode.READ_RECORD_ERROR,
          DSEAAdditionsExtsErrorReasonCode.GETXCONSENT_FAILED,
          control, params, errHandler);					
        }
        return response;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXConsentByContId.
     *
     * @param ContId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetXConsentByContId
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETXCONSENTBYCONTID_FAILED)
     public DWLResponse getXConsentByContId(String ContId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getXConsentByContId(String ContId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(ContId);
        DWLTransaction txObj = new DWLTransactionInquiry("getXConsentByContId", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
      String infoForLogging="Before finder transaction execution for getXConsentByContId";
      logger.finest("getXConsentByContId(String ContId,  DWLControl control) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
       		String infoForLogging="After finder transaction execution for getXConsentByContId";
      logger.finest("getXConsentByContId(String ContId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getXConsentByContId(String ContId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction getXConsentByContId.
     * 
     * @param ContId
     * @return com.dwl.base.DWLResponse
     * @exception Exception
     * @generated
     */
    public DWLResponse  handleGetXConsentByContId(String ContId,  DWLControl control) throws Exception {

        DWLResponse response = new DWLResponse();

    DSEAAdditionsExts comp = 
      (DSEAAdditionsExts)TCRMClassFactory.getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
      
        response = comp.getXConsentByContId(ContId,  control);
        if (response.getData() == null) {
            String[] params = new String[] { ContId };
            DWLExceptionUtils.addErrorToStatus(response.getStatus(), DWLStatus.FATAL,
          DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_CONTROLLER,
          TCRMErrorCode.READ_RECORD_ERROR,
          DSEAAdditionsExtsErrorReasonCode.GETXCONSENTBYCONTID_FAILED,
          control, params, errHandler);					
        }
        return response;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXContractRel.
     *
     * @param XContractRelpkId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetXContractRel
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETXCONTRACTREL_FAILED)
     public DWLResponse getXContractRel(String XContractRelpkId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getXContractRel(String XContractRelpkId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(XContractRelpkId);
        DWLTransaction txObj = new DWLTransactionInquiry("getXContractRel", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
      String infoForLogging="Before finder transaction execution for getXContractRel";
      logger.finest("getXContractRel(String XContractRelpkId,  DWLControl control) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
       		String infoForLogging="After finder transaction execution for getXContractRel";
      logger.finest("getXContractRel(String XContractRelpkId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getXContractRel(String XContractRelpkId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction getXContractRel.
     * 
     * @param XContractRelpkId
     * @return com.dwl.base.DWLResponse
     * @exception Exception
     * @generated
     */
    public DWLResponse  handleGetXContractRel(String XContractRelpkId,  DWLControl control) throws Exception {

        DWLResponse response = new DWLResponse();

    DSEAAdditionsExts comp = 
      (DSEAAdditionsExts)TCRMClassFactory.getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
      
        response = comp.getXContractRel(XContractRelpkId,  control);
        if (response.getData() == null) {
            String[] params = new String[] { XContractRelpkId };
            DWLExceptionUtils.addErrorToStatus(response.getStatus(), DWLStatus.FATAL,
          DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_CONTROLLER,
          TCRMErrorCode.READ_RECORD_ERROR,
          DSEAAdditionsExtsErrorReasonCode.GETXCONTRACTREL_FAILED,
          control, params, errHandler);					
        }
        return response;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXCustomerRetailerJPN.
     *
     * @param XCustomerRetailerJPNpkId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetXCustomerRetailerJPN
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETXCUSTOMERRETAILERJPN_FAILED)
     public DWLResponse getXCustomerRetailerJPN(String XCustomerRetailerJPNpkId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getXCustomerRetailerJPN(String XCustomerRetailerJPNpkId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(XCustomerRetailerJPNpkId);
        DWLTransaction txObj = new DWLTransactionInquiry("getXCustomerRetailerJPN", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
      String infoForLogging="Before finder transaction execution for getXCustomerRetailerJPN";
      logger.finest("getXCustomerRetailerJPN(String XCustomerRetailerJPNpkId,  DWLControl control) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
       		String infoForLogging="After finder transaction execution for getXCustomerRetailerJPN";
      logger.finest("getXCustomerRetailerJPN(String XCustomerRetailerJPNpkId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getXCustomerRetailerJPN(String XCustomerRetailerJPNpkId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction getXCustomerRetailerJPN.
     * 
     * @param XCustomerRetailerJPNpkId
     * @return com.dwl.base.DWLResponse
     * @exception Exception
     * @generated
     */
    public DWLResponse  handleGetXCustomerRetailerJPN(String XCustomerRetailerJPNpkId,  DWLControl control) throws Exception {

        DWLResponse response = new DWLResponse();

    DSEAAdditionsExts comp = 
      (DSEAAdditionsExts)TCRMClassFactory.getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
      
        response = comp.getXCustomerRetailerJPN(XCustomerRetailerJPNpkId,  control);
        if (response.getData() == null) {
            String[] params = new String[] { XCustomerRetailerJPNpkId };
            DWLExceptionUtils.addErrorToStatus(response.getStatus(), DWLStatus.FATAL,
          DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_CONTROLLER,
          TCRMErrorCode.READ_RECORD_ERROR,
          DSEAAdditionsExtsErrorReasonCode.GETXCUSTOMERRETAILERJPN_FAILED,
          control, params, errHandler);					
        }
        return response;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getAllXCustomerRetailerJPNByPartyId.
     *
     * @param ContId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetAllXCustomerRetailerJPNByPartyId
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETALLXCUSTOMERRETAILERJPNBYPARTYID_FAILED)
     public DWLResponse getAllXCustomerRetailerJPNByPartyId(String ContId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getAllXCustomerRetailerJPNByPartyId(String ContId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(ContId);
        DWLTransaction txObj = new DWLTransactionInquiry("getAllXCustomerRetailerJPNByPartyId", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
      String infoForLogging="Before finder transaction execution for getAllXCustomerRetailerJPNByPartyId";
      logger.finest("getAllXCustomerRetailerJPNByPartyId(String ContId,  DWLControl control) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
       		String infoForLogging="After finder transaction execution for getAllXCustomerRetailerJPNByPartyId";
      logger.finest("getAllXCustomerRetailerJPNByPartyId(String ContId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getAllXCustomerRetailerJPNByPartyId(String ContId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction
     * getAllXCustomerRetailerJPNByPartyId.
     * 
     * @param ContId
     * @return com.dwl.base.DWLResponse
     * @exception Exception
     * @generated
     */
    public DWLResponse  handleGetAllXCustomerRetailerJPNByPartyId(String ContId,  DWLControl control) throws Exception {

        DWLResponse response = new DWLResponse();

    DSEAAdditionsExts comp = 
      (DSEAAdditionsExts)TCRMClassFactory.getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
      
        response = comp.getAllXCustomerRetailerJPNByPartyId(ContId,  control);
        if (response.getData() == null) {
            String[] params = new String[] { ContId };
            DWLExceptionUtils.addErrorToStatus(response.getStatus(), DWLStatus.FATAL,
          DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_CONTROLLER,
          TCRMErrorCode.READ_RECORD_ERROR,
          DSEAAdditionsExtsErrorReasonCode.GETALLXCUSTOMERRETAILERJPNBYPARTYID_FAILED,
          control, params, errHandler);					
        }
        return response;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXVehicleJPN.
     *
     * @param XVehicleJPNpkId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetXVehicleJPN
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETXVEHICLEJPN_FAILED)
     public DWLResponse getXVehicleJPN(String XVehicleJPNpkId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getXVehicleJPN(String XVehicleJPNpkId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(XVehicleJPNpkId);
        DWLTransaction txObj = new DWLTransactionInquiry("getXVehicleJPN", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
      String infoForLogging="Before finder transaction execution for getXVehicleJPN";
      logger.finest("getXVehicleJPN(String XVehicleJPNpkId,  DWLControl control) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
       		String infoForLogging="After finder transaction execution for getXVehicleJPN";
      logger.finest("getXVehicleJPN(String XVehicleJPNpkId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getXVehicleJPN(String XVehicleJPNpkId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction getXVehicleJPN.
     * 
     * @param XVehicleJPNpkId
     * @return com.dwl.base.DWLResponse
     * @exception Exception
     * @generated
     */
    public DWLResponse  handleGetXVehicleJPN(String XVehicleJPNpkId,  DWLControl control) throws Exception {

        DWLResponse response = new DWLResponse();

    DSEAAdditionsExts comp = 
      (DSEAAdditionsExts)TCRMClassFactory.getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
      
        response = comp.getXVehicleJPN(XVehicleJPNpkId,  control);
        if (response.getData() == null) {
            String[] params = new String[] { XVehicleJPNpkId };
            DWLExceptionUtils.addErrorToStatus(response.getStatus(), DWLStatus.FATAL,
          DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_CONTROLLER,
          TCRMErrorCode.READ_RECORD_ERROR,
          DSEAAdditionsExtsErrorReasonCode.GETXVEHICLEJPN_FAILED,
          control, params, errHandler);					
        }
        return response;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXVehicleJPNByGlobalVIN.
     *
     * @param GlobalVIN
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetXVehicleJPNByGlobalVIN
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETXVEHICLEJPNBYGLOBALVIN_FAILED)
     public DWLResponse getXVehicleJPNByGlobalVIN(String GlobalVIN,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getXVehicleJPNByGlobalVIN(String GlobalVIN,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(GlobalVIN);
        DWLTransaction txObj = new DWLTransactionInquiry("getXVehicleJPNByGlobalVIN", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
      String infoForLogging="Before finder transaction execution for getXVehicleJPNByGlobalVIN";
      logger.finest("getXVehicleJPNByGlobalVIN(String GlobalVIN,  DWLControl control) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
       		String infoForLogging="After finder transaction execution for getXVehicleJPNByGlobalVIN";
      logger.finest("getXVehicleJPNByGlobalVIN(String GlobalVIN,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getXVehicleJPNByGlobalVIN(String GlobalVIN,  DWLControl control) " + returnValue);
    }
        return retObj;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction getXVehicleJPNByGlobalVIN.
     * 
     * @param GlobalVIN
     * @return com.dwl.base.DWLResponse
     * @exception Exception
     * @generated
     */
    public DWLResponse  handleGetXVehicleJPNByGlobalVIN(String GlobalVIN,  DWLControl control) throws Exception {

        DWLResponse response = new DWLResponse();

    DSEAAdditionsExts comp = 
      (DSEAAdditionsExts)TCRMClassFactory.getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
      
        response = comp.getXVehicleJPNByGlobalVIN(GlobalVIN,  control);
        if (response.getData() == null) {
            String[] params = new String[] { GlobalVIN };
            DWLExceptionUtils.addErrorToStatus(response.getStatus(), DWLStatus.FATAL,
          DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_CONTROLLER,
          TCRMErrorCode.READ_RECORD_ERROR,
          DSEAAdditionsExtsErrorReasonCode.GETXVEHICLEJPNBYGLOBALVIN_FAILED,
          control, params, errHandler);					
        }
        return response;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXCustomerVehicleJPN.
     *
     * @param XCustomerVehicleJPNpkId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetXCustomerVehicleJPN
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETXCUSTOMERVEHICLEJPN_FAILED)
     public DWLResponse getXCustomerVehicleJPN(String XCustomerVehicleJPNpkId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getXCustomerVehicleJPN(String XCustomerVehicleJPNpkId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(XCustomerVehicleJPNpkId);
        DWLTransaction txObj = new DWLTransactionInquiry("getXCustomerVehicleJPN", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
      String infoForLogging="Before finder transaction execution for getXCustomerVehicleJPN";
      logger.finest("getXCustomerVehicleJPN(String XCustomerVehicleJPNpkId,  DWLControl control) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
       		String infoForLogging="After finder transaction execution for getXCustomerVehicleJPN";
      logger.finest("getXCustomerVehicleJPN(String XCustomerVehicleJPNpkId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getXCustomerVehicleJPN(String XCustomerVehicleJPNpkId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction getXCustomerVehicleJPN.
     * 
     * @param XCustomerVehicleJPNpkId
     * @return com.dwl.base.DWLResponse
     * @exception Exception
     * @generated
     */
    public DWLResponse  handleGetXCustomerVehicleJPN(String XCustomerVehicleJPNpkId,  DWLControl control) throws Exception {

        DWLResponse response = new DWLResponse();

    DSEAAdditionsExts comp = 
      (DSEAAdditionsExts)TCRMClassFactory.getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
      
        response = comp.getXCustomerVehicleJPN(XCustomerVehicleJPNpkId,  control);
        if (response.getData() == null) {
            String[] params = new String[] { XCustomerVehicleJPNpkId };
            DWLExceptionUtils.addErrorToStatus(response.getStatus(), DWLStatus.FATAL,
          DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_CONTROLLER,
          TCRMErrorCode.READ_RECORD_ERROR,
          DSEAAdditionsExtsErrorReasonCode.GETXCUSTOMERVEHICLEJPN_FAILED,
          control, params, errHandler);					
        }
        return response;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getAllXCustomerVehicleJPNByPartyId.
     *
     * @param ContId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetAllXCustomerVehicleJPNByPartyId
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETALLXCUSTOMERVEHICLEJPNBYPARTYID_FAILED)
     public DWLResponse getAllXCustomerVehicleJPNByPartyId(String ContId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getAllXCustomerVehicleJPNByPartyId(String ContId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(ContId);
        DWLTransaction txObj = new DWLTransactionInquiry("getAllXCustomerVehicleJPNByPartyId", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
      String infoForLogging="Before finder transaction execution for getAllXCustomerVehicleJPNByPartyId";
      logger.finest("getAllXCustomerVehicleJPNByPartyId(String ContId,  DWLControl control) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
       		String infoForLogging="After finder transaction execution for getAllXCustomerVehicleJPNByPartyId";
      logger.finest("getAllXCustomerVehicleJPNByPartyId(String ContId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getAllXCustomerVehicleJPNByPartyId(String ContId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction
     * getAllXCustomerVehicleJPNByPartyId.
     * 
     * @param ContId
     * @return com.dwl.base.DWLResponse
     * @exception Exception
     * @generated
     */
    public DWLResponse  handleGetAllXCustomerVehicleJPNByPartyId(String ContId,  DWLControl control) throws Exception {

        DWLResponse response = new DWLResponse();

    DSEAAdditionsExts comp = 
      (DSEAAdditionsExts)TCRMClassFactory.getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
      
        response = comp.getAllXCustomerVehicleJPNByPartyId(ContId,  control);
        if (response.getData() == null) {
            String[] params = new String[] { ContId };
            DWLExceptionUtils.addErrorToStatus(response.getStatus(), DWLStatus.FATAL,
          DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_CONTROLLER,
          TCRMErrorCode.READ_RECORD_ERROR,
          DSEAAdditionsExtsErrorReasonCode.GETALLXCUSTOMERVEHICLEJPNBYPARTYID_FAILED,
          control, params, errHandler);					
        }
        return response;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getAllCVRByVehicleId.
     *
     * @param VehicleId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetAllCVRByVehicleId
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETALLCVRBYVEHICLEID_FAILED)
     public DWLResponse getAllCVRByVehicleId(String VehicleId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getAllCVRByVehicleId(String VehicleId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(VehicleId);
        DWLTransaction txObj = new DWLTransactionInquiry("getAllCVRByVehicleId", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
      String infoForLogging="Before finder transaction execution for getAllCVRByVehicleId";
      logger.finest("getAllCVRByVehicleId(String VehicleId,  DWLControl control) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
       		String infoForLogging="After finder transaction execution for getAllCVRByVehicleId";
      logger.finest("getAllCVRByVehicleId(String VehicleId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getAllCVRByVehicleId(String VehicleId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction getAllCVRByVehicleId.
     * 
     * @param VehicleId
     * @return com.dwl.base.DWLResponse
     * @exception Exception
     * @generated
     */
    public DWLResponse  handleGetAllCVRByVehicleId(String VehicleId,  DWLControl control) throws Exception {

        DWLResponse response = new DWLResponse();

    DSEAAdditionsExts comp = 
      (DSEAAdditionsExts)TCRMClassFactory.getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
      
        response = comp.getAllCVRByVehicleId(VehicleId,  control);
        if (response.getData() == null) {
            String[] params = new String[] { VehicleId };
            DWLExceptionUtils.addErrorToStatus(response.getStatus(), DWLStatus.FATAL,
          DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_CONTROLLER,
          TCRMErrorCode.READ_RECORD_ERROR,
          DSEAAdditionsExtsErrorReasonCode.GETALLCVRBYVEHICLEID_FAILED,
          control, params, errHandler);					
        }
        return response;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXCustomerVehicleRoleJPN.
     *
     * @param XCustomerVehicleRoleJPNpkId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetXCustomerVehicleRoleJPN
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETXCUSTOMERVEHICLEROLEJPN_FAILED)
     public DWLResponse getXCustomerVehicleRoleJPN(String XCustomerVehicleRoleJPNpkId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getXCustomerVehicleRoleJPN(String XCustomerVehicleRoleJPNpkId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(XCustomerVehicleRoleJPNpkId);
        DWLTransaction txObj = new DWLTransactionInquiry("getXCustomerVehicleRoleJPN", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
      String infoForLogging="Before finder transaction execution for getXCustomerVehicleRoleJPN";
      logger.finest("getXCustomerVehicleRoleJPN(String XCustomerVehicleRoleJPNpkId,  DWLControl control) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
       		String infoForLogging="After finder transaction execution for getXCustomerVehicleRoleJPN";
      logger.finest("getXCustomerVehicleRoleJPN(String XCustomerVehicleRoleJPNpkId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getXCustomerVehicleRoleJPN(String XCustomerVehicleRoleJPNpkId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction getXCustomerVehicleRoleJPN.
     * 
     * @param XCustomerVehicleRoleJPNpkId
     * @return com.dwl.base.DWLResponse
     * @exception Exception
     * @generated
     */
    public DWLResponse  handleGetXCustomerVehicleRoleJPN(String XCustomerVehicleRoleJPNpkId,  DWLControl control) throws Exception {

        DWLResponse response = new DWLResponse();

    DSEAAdditionsExts comp = 
      (DSEAAdditionsExts)TCRMClassFactory.getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
      
        response = comp.getXCustomerVehicleRoleJPN(XCustomerVehicleRoleJPNpkId,  control);
        if (response.getData() == null) {
            String[] params = new String[] { XCustomerVehicleRoleJPNpkId };
            DWLExceptionUtils.addErrorToStatus(response.getStatus(), DWLStatus.FATAL,
          DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_CONTROLLER,
          TCRMErrorCode.READ_RECORD_ERROR,
          DSEAAdditionsExtsErrorReasonCode.GETXCUSTOMERVEHICLEROLEJPN_FAILED,
          control, params, errHandler);					
        }
        return response;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getAllVehicleRoleByCustomerVehicleJPNId.
     *
     * @param CustomerVehicleId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetAllVehicleRoleByCustomerVehicleJPNId
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETALLVEHICLEROLEBYCUSTOMERVEHICLEJPNID_FAILED)
     public DWLResponse getAllVehicleRoleByCustomerVehicleJPNId(String CustomerVehicleId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getAllVehicleRoleByCustomerVehicleJPNId(String CustomerVehicleId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(CustomerVehicleId);
        DWLTransaction txObj = new DWLTransactionInquiry("getAllVehicleRoleByCustomerVehicleJPNId", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
      String infoForLogging="Before finder transaction execution for getAllVehicleRoleByCustomerVehicleJPNId";
      logger.finest("getAllVehicleRoleByCustomerVehicleJPNId(String CustomerVehicleId,  DWLControl control) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
       		String infoForLogging="After finder transaction execution for getAllVehicleRoleByCustomerVehicleJPNId";
      logger.finest("getAllVehicleRoleByCustomerVehicleJPNId(String CustomerVehicleId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getAllVehicleRoleByCustomerVehicleJPNId(String CustomerVehicleId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction
     * getAllVehicleRoleByCustomerVehicleJPNId.
     * 
     * @param CustomerVehicleId
     * @return com.dwl.base.DWLResponse
     * @exception Exception
     * @generated
     */
    public DWLResponse  handleGetAllVehicleRoleByCustomerVehicleJPNId(String CustomerVehicleId,  DWLControl control) throws Exception {

        DWLResponse response = new DWLResponse();

    DSEAAdditionsExts comp = 
      (DSEAAdditionsExts)TCRMClassFactory.getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
      
        response = comp.getAllVehicleRoleByCustomerVehicleJPNId(CustomerVehicleId,  control);
        if (response.getData() == null) {
            String[] params = new String[] { CustomerVehicleId };
            DWLExceptionUtils.addErrorToStatus(response.getStatus(), DWLStatus.FATAL,
          DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_CONTROLLER,
          TCRMErrorCode.READ_RECORD_ERROR,
          DSEAAdditionsExtsErrorReasonCode.GETALLVEHICLEROLEBYCUSTOMERVEHICLEJPNID_FAILED,
          control, params, errHandler);					
        }
        return response;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXDataSharing.
     *
     * @param DataSharingpkId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetXDataSharing
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETXDATASHARING_FAILED)
     public DWLResponse getXDataSharing(String DataSharingpkId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getXDataSharing(String DataSharingpkId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(DataSharingpkId);
        DWLTransaction txObj = new DWLTransactionInquiry("getXDataSharing", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
      String infoForLogging="Before finder transaction execution for getXDataSharing";
      logger.finest("getXDataSharing(String DataSharingpkId,  DWLControl control) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
       		String infoForLogging="After finder transaction execution for getXDataSharing";
      logger.finest("getXDataSharing(String DataSharingpkId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getXDataSharing(String DataSharingpkId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction getXDataSharing.
     * 
     * @param DataSharingpkId
     * @return com.dwl.base.DWLResponse
     * @exception Exception
     * @generated
     */
    public DWLResponse  handleGetXDataSharing(String DataSharingpkId,  DWLControl control) throws Exception {

        DWLResponse response = new DWLResponse();

    DSEAAdditionsExts comp = 
      (DSEAAdditionsExts)TCRMClassFactory.getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
      
        response = comp.getXDataSharing(DataSharingpkId,  control);
        if (response.getData() == null) {
            String[] params = new String[] { DataSharingpkId };
            DWLExceptionUtils.addErrorToStatus(response.getStatus(), DWLStatus.FATAL,
          DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_CONTROLLER,
          TCRMErrorCode.READ_RECORD_ERROR,
          DSEAAdditionsExtsErrorReasonCode.GETXDATASHARING_FAILED,
          control, params, errHandler);					
        }
        return response;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getDataSharingByPartyId.
     *
     * @param ContId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetDataSharingByPartyId
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETDATASHARINGBYPARTYID_FAILED)
     public DWLResponse getDataSharingByPartyId(String ContId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getDataSharingByPartyId(String ContId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(ContId);
        DWLTransaction txObj = new DWLTransactionInquiry("getDataSharingByPartyId", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
      String infoForLogging="Before finder transaction execution for getDataSharingByPartyId";
      logger.finest("getDataSharingByPartyId(String ContId,  DWLControl control) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
       		String infoForLogging="After finder transaction execution for getDataSharingByPartyId";
      logger.finest("getDataSharingByPartyId(String ContId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getDataSharingByPartyId(String ContId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction getDataSharingByPartyId.
     * 
     * @param ContId
     * @return com.dwl.base.DWLResponse
     * @exception Exception
     * @generated
     */
    public DWLResponse  handleGetDataSharingByPartyId(String ContId,  DWLControl control) throws Exception {

        DWLResponse response = new DWLResponse();

    DSEAAdditionsExts comp = 
      (DSEAAdditionsExts)TCRMClassFactory.getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
      
        response = comp.getDataSharingByPartyId(ContId,  control);
        if (response.getData() == null) {
            String[] params = new String[] { ContId };
            DWLExceptionUtils.addErrorToStatus(response.getStatus(), DWLStatus.FATAL,
          DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_CONTROLLER,
          TCRMErrorCode.READ_RECORD_ERROR,
          DSEAAdditionsExtsErrorReasonCode.GETDATASHARINGBYPARTYID_FAILED,
          control, params, errHandler);					
        }
        return response;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXVehicleKOR.
     *
     * @param XVehicleKORpkId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetXVehicleKOR
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETXVEHICLEKOR_FAILED)
     public DWLResponse getXVehicleKOR(String XVehicleKORpkId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getXVehicleKOR(String XVehicleKORpkId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(XVehicleKORpkId);
        DWLTransaction txObj = new DWLTransactionInquiry("getXVehicleKOR", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
      String infoForLogging="Before finder transaction execution for getXVehicleKOR";
      logger.finest("getXVehicleKOR(String XVehicleKORpkId,  DWLControl control) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
       		String infoForLogging="After finder transaction execution for getXVehicleKOR";
      logger.finest("getXVehicleKOR(String XVehicleKORpkId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getXVehicleKOR(String XVehicleKORpkId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction getXVehicleKOR.
     * 
     * @param XVehicleKORpkId
     * @return com.dwl.base.DWLResponse
     * @exception Exception
     * @generated
     */
    public DWLResponse  handleGetXVehicleKOR(String XVehicleKORpkId,  DWLControl control) throws Exception {

        DWLResponse response = new DWLResponse();

    DSEAAdditionsExts comp = 
      (DSEAAdditionsExts)TCRMClassFactory.getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
      
        response = comp.getXVehicleKOR(XVehicleKORpkId,  control);
        if (response.getData() == null) {
            String[] params = new String[] { XVehicleKORpkId };
            DWLExceptionUtils.addErrorToStatus(response.getStatus(), DWLStatus.FATAL,
          DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_CONTROLLER,
          TCRMErrorCode.READ_RECORD_ERROR,
          DSEAAdditionsExtsErrorReasonCode.GETXVEHICLEKOR_FAILED,
          control, params, errHandler);					
        }
        return response;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXVehicleKORByGlobalVIN.
     *
     * @param GlobalVIN
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetXVehicleKORByGlobalVIN
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETXVEHICLEKORBYGLOBALVIN_FAILED)
     public DWLResponse getXVehicleKORByGlobalVIN(String GlobalVIN,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getXVehicleKORByGlobalVIN(String GlobalVIN,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(GlobalVIN);
        DWLTransaction txObj = new DWLTransactionInquiry("getXVehicleKORByGlobalVIN", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
      String infoForLogging="Before finder transaction execution for getXVehicleKORByGlobalVIN";
      logger.finest("getXVehicleKORByGlobalVIN(String GlobalVIN,  DWLControl control) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
       		String infoForLogging="After finder transaction execution for getXVehicleKORByGlobalVIN";
      logger.finest("getXVehicleKORByGlobalVIN(String GlobalVIN,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getXVehicleKORByGlobalVIN(String GlobalVIN,  DWLControl control) " + returnValue);
    }
        return retObj;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction getXVehicleKORByGlobalVIN.
     * 
     * @param GlobalVIN
     * @return com.dwl.base.DWLResponse
     * @exception Exception
     * @generated
     */
    public DWLResponse  handleGetXVehicleKORByGlobalVIN(String GlobalVIN,  DWLControl control) throws Exception {

        DWLResponse response = new DWLResponse();

    DSEAAdditionsExts comp = 
      (DSEAAdditionsExts)TCRMClassFactory.getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
      
        response = comp.getXVehicleKORByGlobalVIN(GlobalVIN,  control);
        if (response.getData() == null) {
            String[] params = new String[] { GlobalVIN };
            DWLExceptionUtils.addErrorToStatus(response.getStatus(), DWLStatus.FATAL,
          DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_CONTROLLER,
          TCRMErrorCode.READ_RECORD_ERROR,
          DSEAAdditionsExtsErrorReasonCode.GETXVEHICLEKORBYGLOBALVIN_FAILED,
          control, params, errHandler);					
        }
        return response;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXCustomerVehicleKOR.
     *
     * @param XCustomerVehicleKORpkId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetXCustomerVehicleKOR
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETXCUSTOMERVEHICLEKOR_FAILED)
     public DWLResponse getXCustomerVehicleKOR(String XCustomerVehicleKORpkId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getXCustomerVehicleKOR(String XCustomerVehicleKORpkId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(XCustomerVehicleKORpkId);
        DWLTransaction txObj = new DWLTransactionInquiry("getXCustomerVehicleKOR", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
      String infoForLogging="Before finder transaction execution for getXCustomerVehicleKOR";
      logger.finest("getXCustomerVehicleKOR(String XCustomerVehicleKORpkId,  DWLControl control) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
       		String infoForLogging="After finder transaction execution for getXCustomerVehicleKOR";
      logger.finest("getXCustomerVehicleKOR(String XCustomerVehicleKORpkId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getXCustomerVehicleKOR(String XCustomerVehicleKORpkId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction getXCustomerVehicleKOR.
     * 
     * @param XCustomerVehicleKORpkId
     * @return com.dwl.base.DWLResponse
     * @exception Exception
     * @generated
     */
    public DWLResponse  handleGetXCustomerVehicleKOR(String XCustomerVehicleKORpkId,  DWLControl control) throws Exception {

        DWLResponse response = new DWLResponse();

    DSEAAdditionsExts comp = 
      (DSEAAdditionsExts)TCRMClassFactory.getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
      
        response = comp.getXCustomerVehicleKOR(XCustomerVehicleKORpkId,  control);
        if (response.getData() == null) {
            String[] params = new String[] { XCustomerVehicleKORpkId };
            DWLExceptionUtils.addErrorToStatus(response.getStatus(), DWLStatus.FATAL,
          DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_CONTROLLER,
          TCRMErrorCode.READ_RECORD_ERROR,
          DSEAAdditionsExtsErrorReasonCode.GETXCUSTOMERVEHICLEKOR_FAILED,
          control, params, errHandler);					
        }
        return response;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getAllXCustomerVehicleKORByPartyId.
     *
     * @param ContId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetAllXCustomerVehicleKORByPartyId
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETALLXCUSTOMERVEHICLEKORBYPARTYID_FAILED)
     public DWLResponse getAllXCustomerVehicleKORByPartyId(String ContId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getAllXCustomerVehicleKORByPartyId(String ContId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(ContId);
        DWLTransaction txObj = new DWLTransactionInquiry("getAllXCustomerVehicleKORByPartyId", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
      String infoForLogging="Before finder transaction execution for getAllXCustomerVehicleKORByPartyId";
      logger.finest("getAllXCustomerVehicleKORByPartyId(String ContId,  DWLControl control) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
       		String infoForLogging="After finder transaction execution for getAllXCustomerVehicleKORByPartyId";
      logger.finest("getAllXCustomerVehicleKORByPartyId(String ContId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getAllXCustomerVehicleKORByPartyId(String ContId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction
     * getAllXCustomerVehicleKORByPartyId.
     * 
     * @param ContId
     * @return com.dwl.base.DWLResponse
     * @exception Exception
     * @generated
     */
    public DWLResponse  handleGetAllXCustomerVehicleKORByPartyId(String ContId,  DWLControl control) throws Exception {

        DWLResponse response = new DWLResponse();

    DSEAAdditionsExts comp = 
      (DSEAAdditionsExts)TCRMClassFactory.getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
      
        response = comp.getAllXCustomerVehicleKORByPartyId(ContId,  control);
        if (response.getData() == null) {
            String[] params = new String[] { ContId };
            DWLExceptionUtils.addErrorToStatus(response.getStatus(), DWLStatus.FATAL,
          DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_CONTROLLER,
          TCRMErrorCode.READ_RECORD_ERROR,
          DSEAAdditionsExtsErrorReasonCode.GETALLXCUSTOMERVEHICLEKORBYPARTYID_FAILED,
          control, params, errHandler);					
        }
        return response;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getAllCVRByVehicle_ID.
     *
     * @param VehicleId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetAllCVRByVehicle_ID
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETALLCVRBYVEHICLE_ID_FAILED)
     public DWLResponse getAllCVRByVehicle_ID(String VehicleId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getAllCVRByVehicle_ID(String VehicleId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(VehicleId);
        DWLTransaction txObj = new DWLTransactionInquiry("getAllCVRByVehicle_ID", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
      String infoForLogging="Before finder transaction execution for getAllCVRByVehicle_ID";
      logger.finest("getAllCVRByVehicle_ID(String VehicleId,  DWLControl control) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
       		String infoForLogging="After finder transaction execution for getAllCVRByVehicle_ID";
      logger.finest("getAllCVRByVehicle_ID(String VehicleId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getAllCVRByVehicle_ID(String VehicleId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction getAllCVRByVehicle_ID.
     * 
     * @param VehicleId
     * @return com.dwl.base.DWLResponse
     * @exception Exception
     * @generated
     */
    public DWLResponse  handleGetAllCVRByVehicle_ID(String VehicleId,  DWLControl control) throws Exception {

        DWLResponse response = new DWLResponse();

    DSEAAdditionsExts comp = 
      (DSEAAdditionsExts)TCRMClassFactory.getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
      
        response = comp.getAllCVRByVehicle_ID(VehicleId,  control);
        if (response.getData() == null) {
            String[] params = new String[] { VehicleId };
            DWLExceptionUtils.addErrorToStatus(response.getStatus(), DWLStatus.FATAL,
          DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_CONTROLLER,
          TCRMErrorCode.READ_RECORD_ERROR,
          DSEAAdditionsExtsErrorReasonCode.GETALLCVRBYVEHICLE_ID_FAILED,
          control, params, errHandler);					
        }
        return response;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXCustomerVehicleRoleKOR.
     *
     * @param XCustomerVehicleRoleKORpkId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetXCustomerVehicleRoleKOR
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETXCUSTOMERVEHICLEROLEKOR_FAILED)
     public DWLResponse getXCustomerVehicleRoleKOR(String XCustomerVehicleRoleKORpkId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getXCustomerVehicleRoleKOR(String XCustomerVehicleRoleKORpkId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(XCustomerVehicleRoleKORpkId);
        DWLTransaction txObj = new DWLTransactionInquiry("getXCustomerVehicleRoleKOR", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
      String infoForLogging="Before finder transaction execution for getXCustomerVehicleRoleKOR";
      logger.finest("getXCustomerVehicleRoleKOR(String XCustomerVehicleRoleKORpkId,  DWLControl control) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
       		String infoForLogging="After finder transaction execution for getXCustomerVehicleRoleKOR";
      logger.finest("getXCustomerVehicleRoleKOR(String XCustomerVehicleRoleKORpkId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getXCustomerVehicleRoleKOR(String XCustomerVehicleRoleKORpkId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction getXCustomerVehicleRoleKOR.
     * 
     * @param XCustomerVehicleRoleKORpkId
     * @return com.dwl.base.DWLResponse
     * @exception Exception
     * @generated
     */
    public DWLResponse  handleGetXCustomerVehicleRoleKOR(String XCustomerVehicleRoleKORpkId,  DWLControl control) throws Exception {

        DWLResponse response = new DWLResponse();

    DSEAAdditionsExts comp = 
      (DSEAAdditionsExts)TCRMClassFactory.getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
      
        response = comp.getXCustomerVehicleRoleKOR(XCustomerVehicleRoleKORpkId,  control);
        if (response.getData() == null) {
            String[] params = new String[] { XCustomerVehicleRoleKORpkId };
            DWLExceptionUtils.addErrorToStatus(response.getStatus(), DWLStatus.FATAL,
          DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_CONTROLLER,
          TCRMErrorCode.READ_RECORD_ERROR,
          DSEAAdditionsExtsErrorReasonCode.GETXCUSTOMERVEHICLEROLEKOR_FAILED,
          control, params, errHandler);					
        }
        return response;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getAllVehicleRoleByCustomerVehicleKORId.
     *
     * @param CustomerVehicleId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetAllVehicleRoleByCustomerVehicleKORId
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETALLVEHICLEROLEBYCUSTOMERVEHICLEKORID_FAILED)
     public DWLResponse getAllVehicleRoleByCustomerVehicleKORId(String CustomerVehicleId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getAllVehicleRoleByCustomerVehicleKORId(String CustomerVehicleId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(CustomerVehicleId);
        DWLTransaction txObj = new DWLTransactionInquiry("getAllVehicleRoleByCustomerVehicleKORId", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
      String infoForLogging="Before finder transaction execution for getAllVehicleRoleByCustomerVehicleKORId";
      logger.finest("getAllVehicleRoleByCustomerVehicleKORId(String CustomerVehicleId,  DWLControl control) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
       		String infoForLogging="After finder transaction execution for getAllVehicleRoleByCustomerVehicleKORId";
      logger.finest("getAllVehicleRoleByCustomerVehicleKORId(String CustomerVehicleId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getAllVehicleRoleByCustomerVehicleKORId(String CustomerVehicleId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction
     * getAllVehicleRoleByCustomerVehicleKORId.
     * 
     * @param CustomerVehicleId
     * @return com.dwl.base.DWLResponse
     * @exception Exception
     * @generated
     */
    public DWLResponse  handleGetAllVehicleRoleByCustomerVehicleKORId(String CustomerVehicleId,  DWLControl control) throws Exception {

        DWLResponse response = new DWLResponse();

    DSEAAdditionsExts comp = 
      (DSEAAdditionsExts)TCRMClassFactory.getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
      
        response = comp.getAllVehicleRoleByCustomerVehicleKORId(CustomerVehicleId,  control);
        if (response.getData() == null) {
            String[] params = new String[] { CustomerVehicleId };
            DWLExceptionUtils.addErrorToStatus(response.getStatus(), DWLStatus.FATAL,
          DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_CONTROLLER,
          TCRMErrorCode.READ_RECORD_ERROR,
          DSEAAdditionsExtsErrorReasonCode.GETALLVEHICLEROLEBYCUSTOMERVEHICLEKORID_FAILED,
          control, params, errHandler);					
        }
        return response;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXEpucidTemp.
     *
     * @param XEpucidTemppkId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetXEpucidTemp
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETXEPUCIDTEMP_FAILED)
     public DWLResponse getXEpucidTemp(String XEpucidTemppkId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getXEpucidTemp(String XEpucidTemppkId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(XEpucidTemppkId);
        DWLTransaction txObj = new DWLTransactionInquiry("getXEpucidTemp", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
      String infoForLogging="Before finder transaction execution for getXEpucidTemp";
      logger.finest("getXEpucidTemp(String XEpucidTemppkId,  DWLControl control) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
       		String infoForLogging="After finder transaction execution for getXEpucidTemp";
      logger.finest("getXEpucidTemp(String XEpucidTemppkId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getXEpucidTemp(String XEpucidTemppkId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction getXEpucidTemp.
     * 
     * @param XEpucidTemppkId
     * @return com.dwl.base.DWLResponse
     * @exception Exception
     * @generated
     */
    public DWLResponse  handleGetXEpucidTemp(String XEpucidTemppkId,  DWLControl control) throws Exception {

        DWLResponse response = new DWLResponse();

    DSEAAdditionsExts comp = 
      (DSEAAdditionsExts)TCRMClassFactory.getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
      
        response = comp.getXEpucidTemp(XEpucidTemppkId,  control);
        if (response.getData() == null) {
            String[] params = new String[] { XEpucidTemppkId };
            DWLExceptionUtils.addErrorToStatus(response.getStatus(), DWLStatus.FATAL,
          DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_CONTROLLER,
          TCRMErrorCode.READ_RECORD_ERROR,
          DSEAAdditionsExtsErrorReasonCode.GETXEPUCIDTEMP_FAILED,
          control, params, errHandler);					
        }
        return response;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXContractDetailsJPN.
     *
     * @param XContractJPNpkId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetXContractDetailsJPN
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETXCONTRACTDETAILSJPN_FAILED)
     public DWLResponse getXContractDetailsJPN(String XContractJPNpkId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getXContractDetailsJPN(String XContractJPNpkId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(XContractJPNpkId);
        DWLTransaction txObj = new DWLTransactionInquiry("getXContractDetailsJPN", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
      String infoForLogging="Before finder transaction execution for getXContractDetailsJPN";
      logger.finest("getXContractDetailsJPN(String XContractJPNpkId,  DWLControl control) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
       		String infoForLogging="After finder transaction execution for getXContractDetailsJPN";
      logger.finest("getXContractDetailsJPN(String XContractJPNpkId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getXContractDetailsJPN(String XContractJPNpkId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction getXContractDetailsJPN.
     * 
     * @param XContractJPNpkId
     * @return com.dwl.base.DWLResponse
     * @exception Exception
     * @generated
     */
    public DWLResponse  handleGetXContractDetailsJPN(String XContractJPNpkId,  DWLControl control) throws Exception {

        DWLResponse response = new DWLResponse();

    DSEAAdditionsExts comp = 
      (DSEAAdditionsExts)TCRMClassFactory.getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
      
        response = comp.getXContractDetailsJPN(XContractJPNpkId,  control);
        if (response.getData() == null) {
            String[] params = new String[] { XContractJPNpkId };
            DWLExceptionUtils.addErrorToStatus(response.getStatus(), DWLStatus.FATAL,
          DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_CONTROLLER,
          TCRMErrorCode.READ_RECORD_ERROR,
          DSEAAdditionsExtsErrorReasonCode.GETXCONTRACTDETAILSJPN_FAILED,
          control, params, errHandler);					
        }
        return response;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getAllXContractDetailsJPNByPartyId.
     *
     * @param ContId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetAllXContractDetailsJPNByPartyId
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETALLXCONTRACTDETAILSJPNBYPARTYID_FAILED)
     public DWLResponse getAllXContractDetailsJPNByPartyId(String ContId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getAllXContractDetailsJPNByPartyId(String ContId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(ContId);
        DWLTransaction txObj = new DWLTransactionInquiry("getAllXContractDetailsJPNByPartyId", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
      String infoForLogging="Before finder transaction execution for getAllXContractDetailsJPNByPartyId";
      logger.finest("getAllXContractDetailsJPNByPartyId(String ContId,  DWLControl control) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
       		String infoForLogging="After finder transaction execution for getAllXContractDetailsJPNByPartyId";
      logger.finest("getAllXContractDetailsJPNByPartyId(String ContId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getAllXContractDetailsJPNByPartyId(String ContId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction
     * getAllXContractDetailsJPNByPartyId.
     * 
     * @param ContId
     * @return com.dwl.base.DWLResponse
     * @exception Exception
     * @generated
     */
    public DWLResponse  handleGetAllXContractDetailsJPNByPartyId(String ContId,  DWLControl control) throws Exception {

        DWLResponse response = new DWLResponse();

    DSEAAdditionsExts comp = 
      (DSEAAdditionsExts)TCRMClassFactory.getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
      
        response = comp.getAllXContractDetailsJPNByPartyId(ContId,  control);
        if (response.getData() == null) {
            String[] params = new String[] { ContId };
            DWLExceptionUtils.addErrorToStatus(response.getStatus(), DWLStatus.FATAL,
          DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_CONTROLLER,
          TCRMErrorCode.READ_RECORD_ERROR,
          DSEAAdditionsExtsErrorReasonCode.GETALLXCONTRACTDETAILSJPNBYPARTYID_FAILED,
          control, params, errHandler);					
        }
        return response;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXContractRelJPN.
     *
     * @param XContractRelJPNpkId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetXContractRelJPN
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETXCONTRACTRELJPN_FAILED)
     public DWLResponse getXContractRelJPN(String XContractRelJPNpkId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getXContractRelJPN(String XContractRelJPNpkId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(XContractRelJPNpkId);
        DWLTransaction txObj = new DWLTransactionInquiry("getXContractRelJPN", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
      String infoForLogging="Before finder transaction execution for getXContractRelJPN";
      logger.finest("getXContractRelJPN(String XContractRelJPNpkId,  DWLControl control) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
       		String infoForLogging="After finder transaction execution for getXContractRelJPN";
      logger.finest("getXContractRelJPN(String XContractRelJPNpkId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getXContractRelJPN(String XContractRelJPNpkId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction getXContractRelJPN.
     * 
     * @param XContractRelJPNpkId
     * @return com.dwl.base.DWLResponse
     * @exception Exception
     * @generated
     */
    public DWLResponse  handleGetXContractRelJPN(String XContractRelJPNpkId,  DWLControl control) throws Exception {

        DWLResponse response = new DWLResponse();

    DSEAAdditionsExts comp = 
      (DSEAAdditionsExts)TCRMClassFactory.getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
      
        response = comp.getXContractRelJPN(XContractRelJPNpkId,  control);
        if (response.getData() == null) {
            String[] params = new String[] { XContractRelJPNpkId };
            DWLExceptionUtils.addErrorToStatus(response.getStatus(), DWLStatus.FATAL,
          DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_CONTROLLER,
          TCRMErrorCode.READ_RECORD_ERROR,
          DSEAAdditionsExtsErrorReasonCode.GETXCONTRACTRELJPN_FAILED,
          control, params, errHandler);					
        }
        return response;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXVehicleAus.
     *
     * @param XVehicleAuspkId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetXVehicleAus
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETXVEHICLEAUS_FAILED)
     public DWLResponse getXVehicleAus(String XVehicleAuspkId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getXVehicleAus(String XVehicleAuspkId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(XVehicleAuspkId);
        DWLTransaction txObj = new DWLTransactionInquiry("getXVehicleAus", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
      String infoForLogging="Before finder transaction execution for getXVehicleAus";
      logger.finest("getXVehicleAus(String XVehicleAuspkId,  DWLControl control) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
       		String infoForLogging="After finder transaction execution for getXVehicleAus";
      logger.finest("getXVehicleAus(String XVehicleAuspkId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getXVehicleAus(String XVehicleAuspkId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction getXVehicleAus.
     * 
     * @param XVehicleAuspkId
     * @return com.dwl.base.DWLResponse
     * @exception Exception
     * @generated
     */
    public DWLResponse  handleGetXVehicleAus(String XVehicleAuspkId,  DWLControl control) throws Exception {

        DWLResponse response = new DWLResponse();

    DSEAAdditionsExts comp = 
      (DSEAAdditionsExts)TCRMClassFactory.getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
      
        response = comp.getXVehicleAus(XVehicleAuspkId,  control);
        if (response.getData() == null) {
            String[] params = new String[] { XVehicleAuspkId };
            DWLExceptionUtils.addErrorToStatus(response.getStatus(), DWLStatus.FATAL,
          DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_CONTROLLER,
          TCRMErrorCode.READ_RECORD_ERROR,
          DSEAAdditionsExtsErrorReasonCode.GETXVEHICLEAUS_FAILED,
          control, params, errHandler);					
        }
        return response;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXvehicleAusByGlobalVINAndMarketName.
     *
     * @param GlobalVIN
     * @param MarketName
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetXvehicleAusByGlobalVINAndMarketName
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETXVEHICLEAUSBYGLOBALVINANDMARKETNAME_FAILED)
     public DWLResponse getXvehicleAusByGlobalVINAndMarketName(String GlobalVIN, String MarketName,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getXvehicleAusByGlobalVINAndMarketName(String GlobalVIN, String MarketName,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(GlobalVIN);
        params.add(MarketName);
        DWLTransaction txObj = new DWLTransactionInquiry("getXvehicleAusByGlobalVINAndMarketName", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
      String infoForLogging="Before finder transaction execution for getXvehicleAusByGlobalVINAndMarketName";
      logger.finest("getXvehicleAusByGlobalVINAndMarketName(String GlobalVIN, String MarketName,  DWLControl control) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
       		String infoForLogging="After finder transaction execution for getXvehicleAusByGlobalVINAndMarketName";
      logger.finest("getXvehicleAusByGlobalVINAndMarketName(String GlobalVIN, String MarketName,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getXvehicleAusByGlobalVINAndMarketName(String GlobalVIN, String MarketName,  DWLControl control) " + returnValue);
    }
        return retObj;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction
     * getXvehicleAusByGlobalVINAndMarketName.
     * 
     * @param GlobalVIN
     * @param MarketName
     * @return com.dwl.base.DWLResponse
     * @exception Exception
     * @generated
     */
    public DWLResponse  handleGetXvehicleAusByGlobalVINAndMarketName(String GlobalVIN, String MarketName,  DWLControl control) throws Exception {

        DWLResponse response = new DWLResponse();

    DSEAAdditionsExts comp = 
      (DSEAAdditionsExts)TCRMClassFactory.getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
      
        response = comp.getXvehicleAusByGlobalVINAndMarketName(GlobalVIN, MarketName,  control);
        if (response.getData() == null) {
            String[] params = new String[] { GlobalVIN, MarketName };
            DWLExceptionUtils.addErrorToStatus(response.getStatus(), DWLStatus.FATAL,
          DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_CONTROLLER,
          TCRMErrorCode.READ_RECORD_ERROR,
          DSEAAdditionsExtsErrorReasonCode.GETXVEHICLEAUSBYGLOBALVINANDMARKETNAME_FAILED,
          control, params, errHandler);					
        }
        return response;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXCustomerVehicleAus.
     *
     * @param XCustomerVehicleAuspkId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetXCustomerVehicleAus
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETXCUSTOMERVEHICLEAUS_FAILED)
     public DWLResponse getXCustomerVehicleAus(String XCustomerVehicleAuspkId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getXCustomerVehicleAus(String XCustomerVehicleAuspkId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(XCustomerVehicleAuspkId);
        DWLTransaction txObj = new DWLTransactionInquiry("getXCustomerVehicleAus", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
      String infoForLogging="Before finder transaction execution for getXCustomerVehicleAus";
      logger.finest("getXCustomerVehicleAus(String XCustomerVehicleAuspkId,  DWLControl control) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
       		String infoForLogging="After finder transaction execution for getXCustomerVehicleAus";
      logger.finest("getXCustomerVehicleAus(String XCustomerVehicleAuspkId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getXCustomerVehicleAus(String XCustomerVehicleAuspkId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction getXCustomerVehicleAus.
     * 
     * @param XCustomerVehicleAuspkId
     * @return com.dwl.base.DWLResponse
     * @exception Exception
     * @generated
     */
    public DWLResponse  handleGetXCustomerVehicleAus(String XCustomerVehicleAuspkId,  DWLControl control) throws Exception {

        DWLResponse response = new DWLResponse();

    DSEAAdditionsExts comp = 
      (DSEAAdditionsExts)TCRMClassFactory.getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
      
        response = comp.getXCustomerVehicleAus(XCustomerVehicleAuspkId,  control);
        if (response.getData() == null) {
            String[] params = new String[] { XCustomerVehicleAuspkId };
            DWLExceptionUtils.addErrorToStatus(response.getStatus(), DWLStatus.FATAL,
          DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_CONTROLLER,
          TCRMErrorCode.READ_RECORD_ERROR,
          DSEAAdditionsExtsErrorReasonCode.GETXCUSTOMERVEHICLEAUS_FAILED,
          control, params, errHandler);					
        }
        return response;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getAllXCustomerVehicleAusByPartyId.
     *
     * @param ContId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetAllXCustomerVehicleAusByPartyId
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETALLXCUSTOMERVEHICLEAUSBYPARTYID_FAILED)
     public DWLResponse getAllXCustomerVehicleAusByPartyId(String ContId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getAllXCustomerVehicleAusByPartyId(String ContId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(ContId);
        DWLTransaction txObj = new DWLTransactionInquiry("getAllXCustomerVehicleAusByPartyId", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
      String infoForLogging="Before finder transaction execution for getAllXCustomerVehicleAusByPartyId";
      logger.finest("getAllXCustomerVehicleAusByPartyId(String ContId,  DWLControl control) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
       		String infoForLogging="After finder transaction execution for getAllXCustomerVehicleAusByPartyId";
      logger.finest("getAllXCustomerVehicleAusByPartyId(String ContId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getAllXCustomerVehicleAusByPartyId(String ContId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction
     * getAllXCustomerVehicleAusByPartyId.
     * 
     * @param ContId
     * @return com.dwl.base.DWLResponse
     * @exception Exception
     * @generated
     */
    public DWLResponse  handleGetAllXCustomerVehicleAusByPartyId(String ContId,  DWLControl control) throws Exception {

        DWLResponse response = new DWLResponse();

    DSEAAdditionsExts comp = 
      (DSEAAdditionsExts)TCRMClassFactory.getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
      
        response = comp.getAllXCustomerVehicleAusByPartyId(ContId,  control);
        if (response.getData() == null) {
            String[] params = new String[] { ContId };
            DWLExceptionUtils.addErrorToStatus(response.getStatus(), DWLStatus.FATAL,
          DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_CONTROLLER,
          TCRMErrorCode.READ_RECORD_ERROR,
          DSEAAdditionsExtsErrorReasonCode.GETALLXCUSTOMERVEHICLEAUSBYPARTYID_FAILED,
          control, params, errHandler);					
        }
        return response;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getAllXCustomerVehicleAusByVehicleId.
     *
     * @param VehicleId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetAllXCustomerVehicleAusByVehicleId
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETALLXCUSTOMERVEHICLEAUSBYVEHICLEID_FAILED)
     public DWLResponse getAllXCustomerVehicleAusByVehicleId(String VehicleId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getAllXCustomerVehicleAusByVehicleId(String VehicleId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(VehicleId);
        DWLTransaction txObj = new DWLTransactionInquiry("getAllXCustomerVehicleAusByVehicleId", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
      String infoForLogging="Before finder transaction execution for getAllXCustomerVehicleAusByVehicleId";
      logger.finest("getAllXCustomerVehicleAusByVehicleId(String VehicleId,  DWLControl control) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
       		String infoForLogging="After finder transaction execution for getAllXCustomerVehicleAusByVehicleId";
      logger.finest("getAllXCustomerVehicleAusByVehicleId(String VehicleId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getAllXCustomerVehicleAusByVehicleId(String VehicleId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction
     * getAllXCustomerVehicleAusByVehicleId.
     * 
     * @param VehicleId
     * @return com.dwl.base.DWLResponse
     * @exception Exception
     * @generated
     */
    public DWLResponse  handleGetAllXCustomerVehicleAusByVehicleId(String VehicleId,  DWLControl control) throws Exception {

        DWLResponse response = new DWLResponse();

    DSEAAdditionsExts comp = 
      (DSEAAdditionsExts)TCRMClassFactory.getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
      
        response = comp.getAllXCustomerVehicleAusByVehicleId(VehicleId,  control);
        if (response.getData() == null) {
            String[] params = new String[] { VehicleId };
            DWLExceptionUtils.addErrorToStatus(response.getStatus(), DWLStatus.FATAL,
          DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_CONTROLLER,
          TCRMErrorCode.READ_RECORD_ERROR,
          DSEAAdditionsExtsErrorReasonCode.GETALLXCUSTOMERVEHICLEAUSBYVEHICLEID_FAILED,
          control, params, errHandler);					
        }
        return response;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXCustomerVehicleRoleAus.
     *
     * @param XCustomerRoleAuspkId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetXCustomerVehicleRoleAus
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETXCUSTOMERVEHICLEROLEAUS_FAILED)
     public DWLResponse getXCustomerVehicleRoleAus(String XCustomerRoleAuspkId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getXCustomerVehicleRoleAus(String XCustomerRoleAuspkId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(XCustomerRoleAuspkId);
        DWLTransaction txObj = new DWLTransactionInquiry("getXCustomerVehicleRoleAus", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
      String infoForLogging="Before finder transaction execution for getXCustomerVehicleRoleAus";
      logger.finest("getXCustomerVehicleRoleAus(String XCustomerRoleAuspkId,  DWLControl control) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
       		String infoForLogging="After finder transaction execution for getXCustomerVehicleRoleAus";
      logger.finest("getXCustomerVehicleRoleAus(String XCustomerRoleAuspkId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getXCustomerVehicleRoleAus(String XCustomerRoleAuspkId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction getXCustomerVehicleRoleAus.
     * 
     * @param XCustomerRoleAuspkId
     * @return com.dwl.base.DWLResponse
     * @exception Exception
     * @generated
     */
    public DWLResponse  handleGetXCustomerVehicleRoleAus(String XCustomerRoleAuspkId,  DWLControl control) throws Exception {

        DWLResponse response = new DWLResponse();

    DSEAAdditionsExts comp = 
      (DSEAAdditionsExts)TCRMClassFactory.getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
      
        response = comp.getXCustomerVehicleRoleAus(XCustomerRoleAuspkId,  control);
        if (response.getData() == null) {
            String[] params = new String[] { XCustomerRoleAuspkId };
            DWLExceptionUtils.addErrorToStatus(response.getStatus(), DWLStatus.FATAL,
          DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_CONTROLLER,
          TCRMErrorCode.READ_RECORD_ERROR,
          DSEAAdditionsExtsErrorReasonCode.GETXCUSTOMERVEHICLEROLEAUS_FAILED,
          control, params, errHandler);					
        }
        return response;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getAllVehicleRoleAusByCustomerVehicleId.
     *
     * @param CustomerVehicleId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetAllVehicleRoleAusByCustomerVehicleId
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETALLVEHICLEROLEAUSBYCUSTOMERVEHICLEID_FAILED)
     public DWLResponse getAllVehicleRoleAusByCustomerVehicleId(String CustomerVehicleId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getAllVehicleRoleAusByCustomerVehicleId(String CustomerVehicleId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(CustomerVehicleId);
        DWLTransaction txObj = new DWLTransactionInquiry("getAllVehicleRoleAusByCustomerVehicleId", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
      String infoForLogging="Before finder transaction execution for getAllVehicleRoleAusByCustomerVehicleId";
      logger.finest("getAllVehicleRoleAusByCustomerVehicleId(String CustomerVehicleId,  DWLControl control) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
       		String infoForLogging="After finder transaction execution for getAllVehicleRoleAusByCustomerVehicleId";
      logger.finest("getAllVehicleRoleAusByCustomerVehicleId(String CustomerVehicleId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getAllVehicleRoleAusByCustomerVehicleId(String CustomerVehicleId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction
     * getAllVehicleRoleAusByCustomerVehicleId.
     * 
     * @param CustomerVehicleId
     * @return com.dwl.base.DWLResponse
     * @exception Exception
     * @generated
     */
    public DWLResponse  handleGetAllVehicleRoleAusByCustomerVehicleId(String CustomerVehicleId,  DWLControl control) throws Exception {

        DWLResponse response = new DWLResponse();

    DSEAAdditionsExts comp = 
      (DSEAAdditionsExts)TCRMClassFactory.getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
      
        response = comp.getAllVehicleRoleAusByCustomerVehicleId(CustomerVehicleId,  control);
        if (response.getData() == null) {
            String[] params = new String[] { CustomerVehicleId };
            DWLExceptionUtils.addErrorToStatus(response.getStatus(), DWLStatus.FATAL,
          DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_CONTROLLER,
          TCRMErrorCode.READ_RECORD_ERROR,
          DSEAAdditionsExtsErrorReasonCode.GETALLVEHICLEROLEAUSBYCUSTOMERVEHICLEID_FAILED,
          control, params, errHandler);					
        }
        return response;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction
     * getAllXCustomerVehicleRoleAusByXCustomerVehicleAus.
     *
     * @param XCustomerVehicleAusReference
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetAllXCustomerVehicleRoleAusByXCustomerVehicleAus
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETALLXCUSTOMERVEHICLEROLEAUSBYXCUSTOMERVEHICLEAUS_FAILED)
     public DWLResponse getAllXCustomerVehicleRoleAusByXCustomerVehicleAus(String XCustomerVehicleAusReference,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getAllXCustomerVehicleRoleAusByXCustomerVehicleAus(String XCustomerVehicleAusReference,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(XCustomerVehicleAusReference);
        DWLTransaction txObj = new DWLTransactionInquiry("getAllXCustomerVehicleRoleAusByXCustomerVehicleAus", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
      String infoForLogging="Before finder transaction execution for getAllXCustomerVehicleRoleAusByXCustomerVehicleAus";
      logger.finest("getAllXCustomerVehicleRoleAusByXCustomerVehicleAus(String XCustomerVehicleAusReference,  DWLControl control) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
       		String infoForLogging="After finder transaction execution for getAllXCustomerVehicleRoleAusByXCustomerVehicleAus";
      logger.finest("getAllXCustomerVehicleRoleAusByXCustomerVehicleAus(String XCustomerVehicleAusReference,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getAllXCustomerVehicleRoleAusByXCustomerVehicleAus(String XCustomerVehicleAusReference,  DWLControl control) " + returnValue);
    }
        return retObj;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction
     * getAllXCustomerVehicleRoleAusByXCustomerVehicleAus.
     * 
     * @param XCustomerVehicleAusReference
     * @return com.dwl.base.DWLResponse
     * @exception Exception
     * @generated
     */
    public DWLResponse  handleGetAllXCustomerVehicleRoleAusByXCustomerVehicleAus(String XCustomerVehicleAusReference,  DWLControl control) throws Exception {

        DWLResponse response = new DWLResponse();

    DSEAAdditionsExts comp = 
      (DSEAAdditionsExts)TCRMClassFactory.getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
      
        response = comp.getAllXCustomerVehicleRoleAusByXCustomerVehicleAus(XCustomerVehicleAusReference,  control);
        if (response.getData() == null) {
            String[] params = new String[] { XCustomerVehicleAusReference };
            DWLExceptionUtils.addErrorToStatus(response.getStatus(), DWLStatus.FATAL,
          DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_CONTROLLER,
          TCRMErrorCode.READ_RECORD_ERROR,
          DSEAAdditionsExtsErrorReasonCode.GETALLXCUSTOMERVEHICLEROLEAUSBYXCUSTOMERVEHICLEAUS_FAILED,
          control, params, errHandler);					
        }
        return response;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXVRCollapse.
     *
     * @param XVRCollapsepkId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetXVRCollapse
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETXVRCOLLAPSE_FAILED)
     public DWLResponse getXVRCollapse(String XVRCollapsepkId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getXVRCollapse(String XVRCollapsepkId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(XVRCollapsepkId);
        DWLTransaction txObj = new DWLTransactionInquiry("getXVRCollapse", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
      String infoForLogging="Before finder transaction execution for getXVRCollapse";
      logger.finest("getXVRCollapse(String XVRCollapsepkId,  DWLControl control) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
       		String infoForLogging="After finder transaction execution for getXVRCollapse";
      logger.finest("getXVRCollapse(String XVRCollapsepkId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getXVRCollapse(String XVRCollapsepkId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction getXVRCollapse.
     * 
     * @param XVRCollapsepkId
     * @return com.dwl.base.DWLResponse
     * @exception Exception
     * @generated
     */
    public DWLResponse  handleGetXVRCollapse(String XVRCollapsepkId,  DWLControl control) throws Exception {

        DWLResponse response = new DWLResponse();

    DSEAAdditionsExts comp = 
      (DSEAAdditionsExts)TCRMClassFactory.getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
      
        response = comp.getXVRCollapse(XVRCollapsepkId,  control);
        if (response.getData() == null) {
            String[] params = new String[] { XVRCollapsepkId };
            DWLExceptionUtils.addErrorToStatus(response.getStatus(), DWLStatus.FATAL,
          DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_CONTROLLER,
          TCRMErrorCode.READ_RECORD_ERROR,
          DSEAAdditionsExtsErrorReasonCode.GETXVRCOLLAPSE_FAILED,
          control, params, errHandler);					
        }
        return response;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXDeleteAudit.
     *
     * @param XDeleteAuditpkId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetXDeleteAudit
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETXDELETEAUDIT_FAILED)
     public DWLResponse getXDeleteAudit(String XDeleteAuditpkId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getXDeleteAudit(String XDeleteAuditpkId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(XDeleteAuditpkId);
        DWLTransaction txObj = new DWLTransactionInquiry("getXDeleteAudit", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
      String infoForLogging="Before finder transaction execution for getXDeleteAudit";
      logger.finest("getXDeleteAudit(String XDeleteAuditpkId,  DWLControl control) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
       		String infoForLogging="After finder transaction execution for getXDeleteAudit";
      logger.finest("getXDeleteAudit(String XDeleteAuditpkId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getXDeleteAudit(String XDeleteAuditpkId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction getXDeleteAudit.
     * 
     * @param XDeleteAuditpkId
     * @return com.dwl.base.DWLResponse
     * @exception Exception
     * @generated
     */
    public DWLResponse  handleGetXDeleteAudit(String XDeleteAuditpkId,  DWLControl control) throws Exception {

        DWLResponse response = new DWLResponse();

    DSEAAdditionsExts comp = 
      (DSEAAdditionsExts)TCRMClassFactory.getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
      
        response = comp.getXDeleteAudit(XDeleteAuditpkId,  control);
        if (response.getData() == null) {
            String[] params = new String[] { XDeleteAuditpkId };
            DWLExceptionUtils.addErrorToStatus(response.getStatus(), DWLStatus.FATAL,
          DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_CONTROLLER,
          TCRMErrorCode.READ_RECORD_ERROR,
          DSEAAdditionsExtsErrorReasonCode.GETXDELETEAUDIT_FAILED,
          control, params, errHandler);					
        }
        return response;
    }
    

}


