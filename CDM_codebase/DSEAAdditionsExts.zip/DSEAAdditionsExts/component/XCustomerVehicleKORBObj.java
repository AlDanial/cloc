
/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[0e693ec7b977a6e2005d53a0858157a4]
 */

package com.ibm.daimler.dsea.component;

import com.dwl.tcrm.common.TCRMCommon;



import com.dwl.base.DWLControl;

import com.dwl.base.constant.DWLControlKeys;
import com.dwl.base.constant.DWLUtilErrorReasonCode;

import com.dwl.base.error.DWLError;
import com.dwl.base.error.DWLErrorCode;
import com.dwl.base.error.DWLStatus;

import com.dwl.base.exception.DWLBaseException;
import com.dwl.base.exception.DWLUpdateException;

import com.dwl.base.util.DWLClassFactory;
import com.dwl.base.util.DWLExceptionUtils;
import com.dwl.base.util.DWLFunctionUtils;

import com.dwl.management.config.client.Configuration;

import com.dwl.tcrm.common.ITCRMValidation;

import com.dwl.tcrm.utilities.DateFormatter;
import com.dwl.tcrm.utilities.DateValidator;
import com.dwl.tcrm.utilities.TCRMClassFactory;

import com.ibm.daimler.dsea.component.XCustomerVehicleRoleKORBObj;
import com.ibm.daimler.dsea.component.XVehicleKORBObj;

import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsComponentID;
import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsErrorReasonCode;
import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsPropertyKeys;

import com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleKOR;

import com.ibm.daimler.dsea.interfaces.DSEAAdditionsExts;

import com.ibm.mdm.common.codetype.interfaces.CodeTypeComponentHelper;

import com.ibm.mdm.common.codetype.obj.CodeTypeBObj;

import java.util.Vector;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * This class provides the implementation of the business object
 * <code>XCustomerVehicleKORBObj</code>.
 * 
 * @see com.dwl.tcrm.common.TCRMCommon
 * @generated
 */
 

@SuppressWarnings("serial")
public class XCustomerVehicleKORBObj extends TCRMCommon  {

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected EObjXCustomerVehicleKOR eObjXCustomerVehicleKOR;
	/**
    * <!-- begin-user-doc -->
	  * <!-- end-user-doc -->
    * @generated 
    */
	 private final static com.dwl.base.logging.IDWLLogger logger = com.dwl.base.logging.DWLLoggerManager.getLogger(XCustomerVehicleKORBObj.class);
		
 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected String connectMeUsageValue;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected String vehicleSalesValue;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected String vehicleUsageValue;
	protected boolean isValidStartDate = true;
	
	protected boolean isValidEndDate = true;
	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected String sourceIdentifierValue;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected XVehicleKORBObj XVehicleKORBObj;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    @SuppressWarnings("rawtypes")
    protected Vector vecXCustomerVehicleRoleKORBObj;


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */     
    @SuppressWarnings("rawtypes")
    public XCustomerVehicleKORBObj() {
        super();
        init();
        eObjXCustomerVehicleKOR = new EObjXCustomerVehicleKOR();
        vecXCustomerVehicleRoleKORBObj = new Vector();
        setComponentID(DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_KORBOBJ);
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Initializes the fields required to populate the metaDataMap. Each key is
     * an element-level field of the business object.
     *
     * @generated
     */
    private void init() {
        metaDataMap.put("XCustomerVehicleKORpkId", null);
        metaDataMap.put("ContId", null);
        metaDataMap.put("VehicleId", null);
        metaDataMap.put("RetailerId", null);
        metaDataMap.put("ConnectMeUsageType", null);
        metaDataMap.put("ConnectMeUsageValue", null);
        metaDataMap.put("LicensePlate", null);
        metaDataMap.put("VehicleSalesType", null);
        metaDataMap.put("VehicleSalesValue", null);
        metaDataMap.put("VehicleUsageType", null);
        metaDataMap.put("VehicleUsageValue", null);
        metaDataMap.put("VehicleOwnerShip", null);
        metaDataMap.put("StartDate", null);
        metaDataMap.put("EndDate", null);
        metaDataMap.put("SourceIdentifierType", null);
        metaDataMap.put("SourceIdentifierValue", null);
        metaDataMap.put("CustVehRetFlag", null);
        metaDataMap.put("DeleteFlag", null);
        metaDataMap.put("SFDCId", null);
        metaDataMap.put("ServiceName", null);
        metaDataMap.put("XCustomerVehicleKORHistActionCode", null);
        metaDataMap.put("XCustomerVehicleKORHistCreateDate", null);
        metaDataMap.put("XCustomerVehicleKORHistCreatedBy", null);
        metaDataMap.put("XCustomerVehicleKORHistEndDate", null);
        metaDataMap.put("XCustomerVehicleKORHistoryIdPK", null);
        metaDataMap.put("XCustomerVehicleKORLastUpdateDate", null);
        metaDataMap.put("XCustomerVehicleKORLastUpdateTxId", null);
        metaDataMap.put("XCustomerVehicleKORLastUpdateUser", null);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Refreshes all the attributes this business object supports.
     *
     * @see com.dwl.base.DWLCommon#refreshMap()
     * @generated
     */
    public void refreshMap() {

        if (bRequireMapRefresh) {
            super.refreshMap();
            metaDataMap.put("XCustomerVehicleKORpkId", getXCustomerVehicleKORpkId());
            metaDataMap.put("ContId", getContId());
            metaDataMap.put("VehicleId", getVehicleId());
            metaDataMap.put("RetailerId", getRetailerId());
            metaDataMap.put("ConnectMeUsageType", getConnectMeUsageType());
            metaDataMap.put("ConnectMeUsageValue", getConnectMeUsageValue());
            metaDataMap.put("LicensePlate", getLicensePlate());
            metaDataMap.put("VehicleSalesType", getVehicleSalesType());
            metaDataMap.put("VehicleSalesValue", getVehicleSalesValue());
            metaDataMap.put("VehicleUsageType", getVehicleUsageType());
            metaDataMap.put("VehicleUsageValue", getVehicleUsageValue());
            metaDataMap.put("VehicleOwnerShip", getVehicleOwnerShip());
            metaDataMap.put("StartDate", getStartDate());
            metaDataMap.put("EndDate", getEndDate());
            metaDataMap.put("SourceIdentifierType", getSourceIdentifierType());
            metaDataMap.put("SourceIdentifierValue", getSourceIdentifierValue());
            metaDataMap.put("CustVehRetFlag", getCustVehRetFlag());
            metaDataMap.put("DeleteFlag", getDeleteFlag());
            metaDataMap.put("SFDCId", getSFDCId());
            metaDataMap.put("ServiceName", getServiceName());
            metaDataMap.put("XCustomerVehicleKORHistActionCode", getXCustomerVehicleKORHistActionCode());
            metaDataMap.put("XCustomerVehicleKORHistCreateDate", getXCustomerVehicleKORHistCreateDate());
            metaDataMap.put("XCustomerVehicleKORHistCreatedBy", getXCustomerVehicleKORHistCreatedBy());
            metaDataMap.put("XCustomerVehicleKORHistEndDate", getXCustomerVehicleKORHistEndDate());
            metaDataMap.put("XCustomerVehicleKORHistoryIdPK", getXCustomerVehicleKORHistoryIdPK());
            metaDataMap.put("XCustomerVehicleKORLastUpdateDate", getXCustomerVehicleKORLastUpdateDate());
            metaDataMap.put("XCustomerVehicleKORLastUpdateTxId", getXCustomerVehicleKORLastUpdateTxId());
            metaDataMap.put("XCustomerVehicleKORLastUpdateUser", getXCustomerVehicleKORLastUpdateUser());
            bRequireMapRefresh = false;
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the control object on this business object.
     *
     * @see com.dwl.base.DWLCommon#setControl(DWLControl)
     * @generated
     */
    public void setControl(DWLControl newDWLControl) {
        super.setControl(newDWLControl);

        if (eObjXCustomerVehicleKOR != null) {
            eObjXCustomerVehicleKOR.setControl(newDWLControl);
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the entity object associated with this business object.
     *
     * @generated
     */
    public EObjXCustomerVehicleKOR getEObjXCustomerVehicleKOR() {
        bRequireMapRefresh = true;
        return eObjXCustomerVehicleKOR;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the entity object associated with this business object.
     *
     * @param eObjXCustomerVehicleKOR
     *            The eObjXCustomerVehicleKOR to set.
     * @generated
     */
    public void setEObjXCustomerVehicleKOR(EObjXCustomerVehicleKOR eObjXCustomerVehicleKOR) {
        bRequireMapRefresh = true;
        this.eObjXCustomerVehicleKOR = eObjXCustomerVehicleKOR;
        if (this.eObjXCustomerVehicleKOR != null && this.eObjXCustomerVehicleKOR.getControl() == null) {
            DWLControl control = this.getControl();
            if (control != null) {
                this.eObjXCustomerVehicleKOR.setControl(control);
            }
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the groupName attribute.
     * 
     * @generated
     */
    /*public String getGroupName (){
   
        return eObjXCustomerVehicleKOR.getGroupName();
    }*/
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the groupName attribute.
     * 
     * @param newGroupName
     *     The new value of groupName.
     * @generated
     */
 /*   public void setGroupName( String newGroupName ) throws Exception {

        if (newGroupName == null || newGroupName.equals("")) {
            newGroupName = null;


        }
        eObjXCustomerVehicleKOR.setGroupName( newGroupName );
     }*/
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xCustomerVehicleKORpkId attribute.
     * 
     * @generated
     */
    public String getXCustomerVehicleKORpkId (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXCustomerVehicleKOR.getXCustomerVehicleKORpkId());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xCustomerVehicleKORpkId attribute.
     * 
     * @param newXCustomerVehicleKORpkId
     *     The new value of xCustomerVehicleKORpkId.
     * @generated
     */
    public void setXCustomerVehicleKORpkId( String newXCustomerVehicleKORpkId ) throws Exception {
        metaDataMap.put("XCustomerVehicleKORpkId", newXCustomerVehicleKORpkId);

        if (newXCustomerVehicleKORpkId == null || newXCustomerVehicleKORpkId.equals("")) {
            newXCustomerVehicleKORpkId = null;


        }
        eObjXCustomerVehicleKOR.setXCustomerVehicleKORpkId( DWLFunctionUtils.getLongFromString(newXCustomerVehicleKORpkId) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the contId attribute.
     * 
     * @generated
     */
    public String getContId (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXCustomerVehicleKOR.getContId());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the contId attribute.
     * 
     * @param newContId
     *     The new value of contId.
     * @generated
     */
    public void setContId( String newContId ) throws Exception {
        metaDataMap.put("ContId", newContId);

        if (newContId == null || newContId.equals("")) {
            newContId = null;


        }
        eObjXCustomerVehicleKOR.setContId( DWLFunctionUtils.getLongFromString(newContId) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the vehicleId attribute.
     * 
     * @generated
     */
    public String getVehicleId (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXCustomerVehicleKOR.getVehicleId());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the vehicleId attribute.
     * 
     * @param newVehicleId
     *     The new value of vehicleId.
     * @generated
     */
    public void setVehicleId( String newVehicleId ) throws Exception {
        metaDataMap.put("VehicleId", newVehicleId);

        if (newVehicleId == null || newVehicleId.equals("")) {
            newVehicleId = null;


        }
        eObjXCustomerVehicleKOR.setVehicleId( DWLFunctionUtils.getLongFromString(newVehicleId) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the retailerId attribute.
     * 
     * @generated
     */
    public String getRetailerId (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXCustomerVehicleKOR.getRetailerId());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the retailerId attribute.
     * 
     * @param newRetailerId
     *     The new value of retailerId.
     * @generated
     */
    public void setRetailerId( String newRetailerId ) throws Exception {
        metaDataMap.put("RetailerId", newRetailerId);

        if (newRetailerId == null || newRetailerId.equals("")) {
            newRetailerId = null;


        }
        eObjXCustomerVehicleKOR.setRetailerId( DWLFunctionUtils.getLongFromString(newRetailerId) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the connectMeUsageType attribute.
     * 
     * @generated
     */
    public String getConnectMeUsageType (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXCustomerVehicleKOR.getConnectMeUsage());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the connectMeUsageType attribute.
     * 
     * @param newConnectMeUsageType
     *     The new value of connectMeUsageType.
     * @generated
     */
    public void setConnectMeUsageType( String newConnectMeUsageType ) throws Exception {
        metaDataMap.put("ConnectMeUsageType", newConnectMeUsageType);

        if (newConnectMeUsageType == null || newConnectMeUsageType.equals("")) {
            newConnectMeUsageType = null;


        }
        eObjXCustomerVehicleKOR.setConnectMeUsage( DWLFunctionUtils.getLongFromString(newConnectMeUsageType) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the connectMeUsageValue attribute.
     * 
     * @generated
     */
    public String getConnectMeUsageValue (){
      return connectMeUsageValue;
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the connectMeUsageValue attribute.
     * 
     * @param newConnectMeUsageValue
     *     The new value of connectMeUsageValue.
     * @generated
     */
    public void setConnectMeUsageValue( String newConnectMeUsageValue ) throws Exception {
        metaDataMap.put("ConnectMeUsageValue", newConnectMeUsageValue);

        if (newConnectMeUsageValue == null || newConnectMeUsageValue.equals("")) {
            newConnectMeUsageValue = null;


        }
        connectMeUsageValue = newConnectMeUsageValue;
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the licensePlate attribute.
     * 
     * @generated
     */
    public String getLicensePlate (){
   
        return eObjXCustomerVehicleKOR.getLicensePlate();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the licensePlate attribute.
     * 
     * @param newLicensePlate
     *     The new value of licensePlate.
     * @generated
     */
    public void setLicensePlate( String newLicensePlate ) throws Exception {
        metaDataMap.put("LicensePlate", newLicensePlate);

        if (newLicensePlate == null || newLicensePlate.equals("")) {
            newLicensePlate = null;


        }
        eObjXCustomerVehicleKOR.setLicensePlate( newLicensePlate );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the vehicleSalesType attribute.
     * 
     * @generated
     */
    public String getVehicleSalesType (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXCustomerVehicleKOR.getVehicleSales());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the vehicleSalesType attribute.
     * 
     * @param newVehicleSalesType
     *     The new value of vehicleSalesType.
     * @generated
     */
    public void setVehicleSalesType( String newVehicleSalesType ) throws Exception {
        metaDataMap.put("VehicleSalesType", newVehicleSalesType);

        if (newVehicleSalesType == null || newVehicleSalesType.equals("")) {
            newVehicleSalesType = null;


        }
        eObjXCustomerVehicleKOR.setVehicleSales( DWLFunctionUtils.getLongFromString(newVehicleSalesType) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the vehicleSalesValue attribute.
     * 
     * @generated
     */
    public String getVehicleSalesValue (){
      return vehicleSalesValue;
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the vehicleSalesValue attribute.
     * 
     * @param newVehicleSalesValue
     *     The new value of vehicleSalesValue.
     * @generated
     */
    public void setVehicleSalesValue( String newVehicleSalesValue ) throws Exception {
        metaDataMap.put("VehicleSalesValue", newVehicleSalesValue);

        if (newVehicleSalesValue == null || newVehicleSalesValue.equals("")) {
            newVehicleSalesValue = null;


        }
        vehicleSalesValue = newVehicleSalesValue;
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the vehicleUsageType attribute.
     * 
     * @generated
     */
    public String getVehicleUsageType (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXCustomerVehicleKOR.getVehicleUsage());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the vehicleUsageType attribute.
     * 
     * @param newVehicleUsageType
     *     The new value of vehicleUsageType.
     * @generated
     */
    public void setVehicleUsageType( String newVehicleUsageType ) throws Exception {
        metaDataMap.put("VehicleUsageType", newVehicleUsageType);

        if (newVehicleUsageType == null || newVehicleUsageType.equals("")) {
            newVehicleUsageType = null;


        }
        eObjXCustomerVehicleKOR.setVehicleUsage( DWLFunctionUtils.getLongFromString(newVehicleUsageType) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the vehicleUsageValue attribute.
     * 
     * @generated
     */
    public String getVehicleUsageValue (){
      return vehicleUsageValue;
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the vehicleUsageValue attribute.
     * 
     * @param newVehicleUsageValue
     *     The new value of vehicleUsageValue.
     * @generated
     */
    public void setVehicleUsageValue( String newVehicleUsageValue ) throws Exception {
        metaDataMap.put("VehicleUsageValue", newVehicleUsageValue);

        if (newVehicleUsageValue == null || newVehicleUsageValue.equals("")) {
            newVehicleUsageValue = null;


        }
        vehicleUsageValue = newVehicleUsageValue;
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the vehicleOwnerShip attribute.
     * 
     * @generated
     */
    public String getVehicleOwnerShip (){
   
        return eObjXCustomerVehicleKOR.getVehicleOwnerShip();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the vehicleOwnerShip attribute.
     * 
     * @param newVehicleOwnerShip
     *     The new value of vehicleOwnerShip.
     * @generated
     */
    public void setVehicleOwnerShip( String newVehicleOwnerShip ) throws Exception {
        metaDataMap.put("VehicleOwnerShip", newVehicleOwnerShip);

        if (newVehicleOwnerShip == null || newVehicleOwnerShip.equals("")) {
            newVehicleOwnerShip = null;


        }
        eObjXCustomerVehicleKOR.setVehicleOwnerShip( newVehicleOwnerShip );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the startDate attribute.
     * 
     * @generated
     */
    public String getStartDate (){
   
        return DWLFunctionUtils.getStringFromTimestamp(eObjXCustomerVehicleKOR.getStartDate());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the startDate attribute.
     * 
     * @param newStartDate
     *     The new value of startDate.
     * @generated
     */
    public void setStartDate( String newStartDate ) throws Exception {
        metaDataMap.put("StartDate", newStartDate);
       	isValidStartDate = true;

        if (newStartDate == null || newStartDate.equals("")) {
            newStartDate = null;
            eObjXCustomerVehicleKOR.setStartDate(null);


        }
    else {
        	if (DateValidator.validates(newStartDate)) {
           		eObjXCustomerVehicleKOR.setStartDate(DateFormatter.getStartDateTimestamp(newStartDate));
            	metaDataMap.put("StartDate", getStartDate());
        	} else {
            	if (Configuration.getConfiguration().getConfigItem(
              "/IBM/DWLCommonServices/InternalValidation/enabled").getBooleanValue()) {
                	if (metaDataMap.get("StartDate") != null) {
                    	metaDataMap.put("StartDate", "");
                	}
                	isValidStartDate = false;
                	eObjXCustomerVehicleKOR.setStartDate(null);
            	}
        	}
        }
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the endDate attribute.
     * 
     * @generated
     */
    public String getEndDate (){
   
        return DWLFunctionUtils.getStringFromTimestamp(eObjXCustomerVehicleKOR.getEndDate());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the endDate attribute.
     * 
     * @param newEndDate
     *     The new value of endDate.
     * @generated
     */
    public void setEndDate( String newEndDate ) throws Exception {
        metaDataMap.put("EndDate", newEndDate);
       	isValidEndDate = true;

        if (newEndDate == null || newEndDate.equals("")) {
            newEndDate = null;
            eObjXCustomerVehicleKOR.setEndDate(null);


        }
    else {
        	if (DateValidator.validates(newEndDate)) {
           		eObjXCustomerVehicleKOR.setEndDate(DateFormatter.getStartDateTimestamp(newEndDate));
            	metaDataMap.put("EndDate", getEndDate());
        	} else {
            	if (Configuration.getConfiguration().getConfigItem(
              "/IBM/DWLCommonServices/InternalValidation/enabled").getBooleanValue()) {
                	if (metaDataMap.get("EndDate") != null) {
                    	metaDataMap.put("EndDate", "");
                	}
                	isValidEndDate = false;
                	eObjXCustomerVehicleKOR.setEndDate(null);
            	}
        	}
        }
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the sourceIdentifierType attribute.
     * 
     * @generated
     */
    public String getSourceIdentifierType (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXCustomerVehicleKOR.getSourceIdentifier());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the sourceIdentifierType attribute.
     * 
     * @param newSourceIdentifierType
     *     The new value of sourceIdentifierType.
     * @generated
     */
    public void setSourceIdentifierType( String newSourceIdentifierType ) throws Exception {
        metaDataMap.put("SourceIdentifierType", newSourceIdentifierType);

        if (newSourceIdentifierType == null || newSourceIdentifierType.equals("")) {
            newSourceIdentifierType = null;


        }
        eObjXCustomerVehicleKOR.setSourceIdentifier( DWLFunctionUtils.getLongFromString(newSourceIdentifierType) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the sourceIdentifierValue attribute.
     * 
     * @generated
     */
    public String getSourceIdentifierValue (){
      return sourceIdentifierValue;
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the sourceIdentifierValue attribute.
     * 
     * @param newSourceIdentifierValue
     *     The new value of sourceIdentifierValue.
     * @generated
     */
    public void setSourceIdentifierValue( String newSourceIdentifierValue ) throws Exception {
        metaDataMap.put("SourceIdentifierValue", newSourceIdentifierValue);

        if (newSourceIdentifierValue == null || newSourceIdentifierValue.equals("")) {
            newSourceIdentifierValue = null;


        }
        sourceIdentifierValue = newSourceIdentifierValue;
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the custVehRetFlag attribute.
     * 
     * @generated
     */
    public String getCustVehRetFlag (){
   
        return eObjXCustomerVehicleKOR.getCustVehRetFlag();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the custVehRetFlag attribute.
     * 
     * @param newCustVehRetFlag
     *     The new value of custVehRetFlag.
     * @generated
     */
    public void setCustVehRetFlag( String newCustVehRetFlag ) throws Exception {
        metaDataMap.put("CustVehRetFlag", newCustVehRetFlag);

        if (newCustVehRetFlag == null || newCustVehRetFlag.equals("")) {
            newCustVehRetFlag = null;


        }
        eObjXCustomerVehicleKOR.setCustVehRetFlag( newCustVehRetFlag );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the deleteFlag attribute.
     * 
     * @generated
     */
    public String getDeleteFlag (){
   
        return eObjXCustomerVehicleKOR.getDeleteFlag();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the deleteFlag attribute.
     * 
     * @param newDeleteFlag
     *     The new value of deleteFlag.
     * @generated
     */
    public void setDeleteFlag( String newDeleteFlag ) throws Exception {
        metaDataMap.put("DeleteFlag", newDeleteFlag);

        if (newDeleteFlag == null || newDeleteFlag.equals("")) {
            newDeleteFlag = null;


        }
        eObjXCustomerVehicleKOR.setDeleteFlag( newDeleteFlag );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the sFDCId attribute.
     * 
     * @generated
     */
    public String getSFDCId (){
   
        return eObjXCustomerVehicleKOR.getSFDCId();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the sFDCId attribute.
     * 
     * @param newSFDCId
     *     The new value of sFDCId.
     * @generated
     */
    public void setSFDCId( String newSFDCId ) throws Exception {
        metaDataMap.put("SFDCId", newSFDCId);

        if (newSFDCId == null || newSFDCId.equals("")) {
            newSFDCId = null;


        }
        eObjXCustomerVehicleKOR.setSFDCId( newSFDCId );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the serviceName attribute.
     * 
     * @generated
     */
    public String getServiceName (){
   
        return eObjXCustomerVehicleKOR.getServiceName();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the serviceName attribute.
     * 
     * @param newServiceName
     *     The new value of serviceName.
     * @generated
     */
    public void setServiceName( String newServiceName ) throws Exception {
        metaDataMap.put("ServiceName", newServiceName);

        if (newServiceName == null || newServiceName.equals("")) {
            newServiceName = null;


        }
        eObjXCustomerVehicleKOR.setServiceName( newServiceName );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XVehicleKORBObj attribute.
     * 
     * @generated
     */
    public XVehicleKORBObj getXVehicleKORBObj (){
      return XVehicleKORBObj;
    }
    
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public void setXVehicleKORBObj(XVehicleKORBObj newBObj ) {
    XVehicleKORBObj = newBObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XCustomerVehicleRoleKORBObj attribute.
     * 
     * @generated
     */
    @SuppressWarnings("rawtypes")
    public Vector getItemsXCustomerVehicleRoleKORBObj (){
      return vecXCustomerVehicleRoleKORBObj;
    }
    
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    @SuppressWarnings("unchecked")
    public void setXCustomerVehicleRoleKORBObj(XCustomerVehicleRoleKORBObj newBObj ) {
        vecXCustomerVehicleRoleKORBObj.addElement( newBObj );
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateTxId attribute.
     *
     * @generated
     */
    public String getXCustomerVehicleKORLastUpdateTxId() {
        return DWLFunctionUtils.getStringFromLong(eObjXCustomerVehicleKOR.getLastUpdateTxId());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateUser attribute.
     *
     * @generated
     */
    public String getXCustomerVehicleKORLastUpdateUser() {
        return eObjXCustomerVehicleKOR.getLastUpdateUser();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateDt attribute.
     *
     * @generated
     */
    public String getXCustomerVehicleKORLastUpdateDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXCustomerVehicleKOR.getLastUpdateDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateTxId attribute.
     *
     * @param newLastUpdateTxId
     *     The new value of LastUpdateTxId.
     * @generated
     */
    public void setXCustomerVehicleKORLastUpdateTxId(String newLastUpdateTxId) {
        metaDataMap.put("XCustomerVehicleKORLastUpdateTxId", newLastUpdateTxId);

        if ((newLastUpdateTxId == null) || newLastUpdateTxId.equals("")) {
            newLastUpdateTxId = null;
        }
        eObjXCustomerVehicleKOR.setLastUpdateTxId(DWLFunctionUtils.getLongFromString(newLastUpdateTxId));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateUser attribute.
     *
     * @param newLastUpdateUser
     *     The new value of LastUpdateUser.
     * @generated
     */
    public void setXCustomerVehicleKORLastUpdateUser(String newLastUpdateUser) {
        metaDataMap.put("XCustomerVehicleKORLastUpdateUser", newLastUpdateUser);

        if ((newLastUpdateUser == null) || newLastUpdateUser.equals("")) {
            newLastUpdateUser = null;
        }
        eObjXCustomerVehicleKOR.setLastUpdateUser(newLastUpdateUser);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateDt attribute.
     *
     * @param newLastUpdateDt
     *     The new value of LastUpdateDt.
     * @throws Exception
     * @generated
     */
    public void setXCustomerVehicleKORLastUpdateDate(String newLastUpdateDt) throws Exception {
        metaDataMap.put("XCustomerVehicleKORLastUpdateDate", newLastUpdateDt);

        if ((newLastUpdateDt == null) || newLastUpdateDt.equals("")) {
            newLastUpdateDt = null;
        }

        eObjXCustomerVehicleKOR.setLastUpdateDt(DWLFunctionUtils.getTimestampFromTimestampString(newLastUpdateDt));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XCustomerVehicleKORHistActionCode history attribute.
     *
     * @generated
     */
    public String getXCustomerVehicleKORHistActionCode() {
        return eObjXCustomerVehicleKOR.getHistActionCode();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XCustomerVehicleKORHistActionCode history attribute.
     *
     * @param aXCustomerVehicleKORHistActionCode
     *     The new value of XCustomerVehicleKORHistActionCode.
     * @generated
     */
    public void setXCustomerVehicleKORHistActionCode(String aXCustomerVehicleKORHistActionCode) {
        metaDataMap.put("XCustomerVehicleKORHistActionCode", aXCustomerVehicleKORHistActionCode);

        if ((aXCustomerVehicleKORHistActionCode == null) || aXCustomerVehicleKORHistActionCode.equals("")) {
            aXCustomerVehicleKORHistActionCode = null;
        }
        eObjXCustomerVehicleKOR.setHistActionCode(aXCustomerVehicleKORHistActionCode);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XCustomerVehicleKORHistCreateDate history attribute.
     *
     * @generated
     */
    public String getXCustomerVehicleKORHistCreateDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXCustomerVehicleKOR.getHistCreateDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XCustomerVehicleKORHistCreateDate history attribute.
     *
     * @param aXCustomerVehicleKORHistCreateDate
     *     The new value of XCustomerVehicleKORHistCreateDate.
     * @generated
     */
    public void setXCustomerVehicleKORHistCreateDate(String aXCustomerVehicleKORHistCreateDate) throws Exception{
        metaDataMap.put("XCustomerVehicleKORHistCreateDate", aXCustomerVehicleKORHistCreateDate);

        if ((aXCustomerVehicleKORHistCreateDate == null) || aXCustomerVehicleKORHistCreateDate.equals("")) {
            aXCustomerVehicleKORHistCreateDate = null;
        }

        eObjXCustomerVehicleKOR.setHistCreateDt(DWLFunctionUtils.getTimestampFromTimestampString(aXCustomerVehicleKORHistCreateDate));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XCustomerVehicleKORHistCreatedBy history attribute.
     *
     * @generated
     */
    public String getXCustomerVehicleKORHistCreatedBy() {
        return eObjXCustomerVehicleKOR.getHistCreatedBy();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XCustomerVehicleKORHistCreatedBy history attribute.
     *
     * @param aXCustomerVehicleKORHistCreatedBy
     *     The new value of XCustomerVehicleKORHistCreatedBy.
     * @generated
     */
    public void setXCustomerVehicleKORHistCreatedBy(String aXCustomerVehicleKORHistCreatedBy) {
        metaDataMap.put("XCustomerVehicleKORHistCreatedBy", aXCustomerVehicleKORHistCreatedBy);

        if ((aXCustomerVehicleKORHistCreatedBy == null) || aXCustomerVehicleKORHistCreatedBy.equals("")) {
            aXCustomerVehicleKORHistCreatedBy = null;
        }

        eObjXCustomerVehicleKOR.setHistCreatedBy(aXCustomerVehicleKORHistCreatedBy);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XCustomerVehicleKORHistEndDate history attribute.
     *
     * @generated
     */
    public String getXCustomerVehicleKORHistEndDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXCustomerVehicleKOR.getHistEndDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XCustomerVehicleKORHistEndDate history attribute.
     *
     * @param aXCustomerVehicleKORHistEndDate
     *     The new value of XCustomerVehicleKORHistEndDate.
     * @generated
     */
    public void setXCustomerVehicleKORHistEndDate(String aXCustomerVehicleKORHistEndDate) throws Exception{
        metaDataMap.put("XCustomerVehicleKORHistEndDate", aXCustomerVehicleKORHistEndDate);

        if ((aXCustomerVehicleKORHistEndDate == null) || aXCustomerVehicleKORHistEndDate.equals("")) {
            aXCustomerVehicleKORHistEndDate = null;
        }
        eObjXCustomerVehicleKOR.setHistEndDt(DWLFunctionUtils.getTimestampFromTimestampString(aXCustomerVehicleKORHistEndDate));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XCustomerVehicleKORHistoryIdPK history attribute.
     *
     * @generated
     */
    public String getXCustomerVehicleKORHistoryIdPK() {
        return DWLFunctionUtils.getStringFromLong(eObjXCustomerVehicleKOR.getHistoryIdPK());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XCustomerVehicleKORHistoryIdPK history attribute.
     *
     * @param aXCustomerVehicleKORHistoryIdPK
     *     The new value of XCustomerVehicleKORHistoryIdPK.
     * @generated
     */
    public void setXCustomerVehicleKORHistoryIdPK(String aXCustomerVehicleKORHistoryIdPK) {
        metaDataMap.put("XCustomerVehicleKORHistoryIdPK", aXCustomerVehicleKORHistoryIdPK);

        if ((aXCustomerVehicleKORHistoryIdPK == null) || aXCustomerVehicleKORHistoryIdPK.equals("")) {
            aXCustomerVehicleKORHistoryIdPK = null;
        }
        eObjXCustomerVehicleKOR.setHistoryIdPK(DWLFunctionUtils.getLongFromString(aXCustomerVehicleKORHistoryIdPK));
    }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation during an add transaction.
     *
     * @generated
     */
    public DWLStatus validateAdd(int level, DWLStatus status) throws Exception {

        status = super.validateAdd(level, status);
        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0038I Add any controller-level custom validation logic to be
            // executed for this object during an "add" transaction


            XVehicleKORBObj xVehicleKOR = getXVehicleKORBObj();
            if( xVehicleKOR != null ){
            	status = xVehicleKOR.validateAdd(level, status);
            }

            for (int i = 0; i < getItemsXCustomerVehicleRoleKORBObj().size(); i++) {
                XCustomerVehicleRoleKORBObj xCustomerVehicleRoleKOR = (XCustomerVehicleRoleKORBObj) getItemsXCustomerVehicleRoleKORBObj().elementAt(i);
                status = xCustomerVehicleRoleKOR.validateAdd(level, status);
            }
        }

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            // MDM_TODO0: CDKWB0039I Add any component-level custom validation logic to be
            // executed for this object during an "add" transaction
        }
        status = getValidationStatus(level, status);
        return status;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation during an update transaction.
     *
     * @generated
     */
    public DWLStatus validateUpdate(int level, DWLStatus status) throws Exception {
    logger.finest("ENTER validateUpdate(int level, DWLStatus status)");

        status = super.validateUpdate(level, status);
        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0040I Add any controller-level custom validation logic to be
            // executed for this object during an "update" transaction

            if (eObjXCustomerVehicleKOR.getXCustomerVehicleKORpkId() == null) {
                DWLError err = new DWLError();
                err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_KORBOBJ).longValue());
                err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.XCUSTOMERVEHICLEKOR_XCUSTOMERVEHICLEKORPKID_NULL).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                	String infoForLogging="Error: Validation error occured for update. No primary key for entity XCustomerVehicleKOR, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("validateUpdate(int level, DWLStatus status) " + infoForLogging);
                }
                status.addError(err);
            }
            if (eObjXCustomerVehicleKOR.getLastUpdateDt() == null) {
                DWLError err = new DWLError();
                err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_KORBOBJ).longValue());
                err.setReasonCode(new Long(DWLUtilErrorReasonCode.LAST_UPDATED_DATE_NULL).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
                if (logger.isFinestEnabled()) {
                	String infoForLogging="Error: Validation error occured for update. No last update date for entity XCustomerVehicleKOR, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("validateUpdate(int level, DWLStatus status) " + infoForLogging);
                }
                status.addError(err);
            }
           XVehicleKORBObj xVehicleKOR = (XVehicleKORBObj) getXVehicleKORBObj();
           if( xVehicleKOR != null ){
           		if (xVehicleKOR.getEObjXVehicleKOR().getPrimaryKey() == null) {
               		status = xVehicleKOR.validateAdd(level, status);
           		} else  {
               		status = xVehicleKOR.validateUpdate(level, status);
           		}
           }

            for (int i = 0; i < getItemsXCustomerVehicleRoleKORBObj().size(); i++) {
                XCustomerVehicleRoleKORBObj xCustomerVehicleRoleKOR = (XCustomerVehicleRoleKORBObj) getItemsXCustomerVehicleRoleKORBObj().elementAt(i);
                if (xCustomerVehicleRoleKOR.getEObjXCustomerVehicleRoleKOR().getPrimaryKey() == null) {
                    status = xCustomerVehicleRoleKOR.validateAdd(level, status);
                } else  {
                    status = xCustomerVehicleRoleKOR.validateUpdate(level, status);
                }
            }
        }

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            assignBeforeImageValues(metaDataMap);
            
            // MDM_TODO0: CDKWB0041I Add any component-level custom validation logic to be
            // executed for this object during an "update" transaction
        }
        status = getValidationStatus(level, status);
    if (logger.isFinestEnabled()) {
        	String returnValue = status.toString();
      logger.finest("RETURN validateUpdate(int level, DWLStatus status) " + returnValue);
    }
        return status;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Populate the before image of this business object.
     *
     * @see com.dwl.base.DWLCommon#populateBeforeImage()
     * @generated
     */
    public void populateBeforeImage() throws DWLBaseException {
    logger.finest("ENTER populateBeforeImage()");

        DSEAAdditionsExts comp = null;
        try {
        
      comp = (DSEAAdditionsExts)TCRMClassFactory.getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
        	
        } catch (Exception e) {
      if (logger.isFinestEnabled()) {
        String infoForLogging="Error: Fatal error while updating record " + e.getMessage();
      logger.finest("populateBeforeImage() " + infoForLogging);
      }
            DWLExceptionUtils.throwDWLBaseException(e, 
            									new DWLUpdateException(e.getMessage()), 
            									this.getStatus(), DWLStatus.FATAL,
                                  DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_KORBOBJ, 
                                  "DIERR",
                                  DSEAAdditionsExtsErrorReasonCode.XCUSTOMERVEHICLEKOR_BEFORE_IMAGE_NOT_POPULATED, 
                                  this.getControl());
        }
        
        comp.loadBeforeImage(this);
    logger.finest("RETURN populateBeforeImage()");
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation common to both add and update transactions.
     *
     * @generated
     */
     
    private DWLStatus getValidationStatus(int level, DWLStatus status) throws Exception {
    logger.finest("ENTER getValidationStatus(int level, DWLStatus status)");

        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0034I Add any common controller-level custom validation
            // logic to be executed for this object during either "add" or
            // "update" transactions
    		controllerValidation_ConnectMeUsage(status);
    		controllerValidation_VehicleSales(status);
    		controllerValidation_VehicleUsage(status);
    		controllerValidation_StartDate(status);
    		controllerValidation_EndDate(status);
    		controllerValidation_SourceIdentifier(status);
    	}

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            // MDM_TODO0: CDKWB0035I Add any common component-level custom validation logic
            // to be executed for this object during either "add" or "update"
            // transactions
    		componentValidation_ConnectMeUsage(status);
    		componentValidation_VehicleSales(status);
    		componentValidation_VehicleUsage(status);
    		componentValidation_StartDate(status);
    		componentValidation_EndDate(status);
    		componentValidation_SourceIdentifier(status);
        }
        
        if (logger.isFinestEnabled()) {
            String returnValue = status.toString();
      logger.finest("RETURN getValidationStatus(int level, DWLStatus status) " + returnValue);
        }
    
        return status;
    }

    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "ConnectMeUsage"
     *
     * @generated
     */
	private void componentValidation_ConnectMeUsage(DWLStatus status) {
  
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "VehicleSales"
     *
     * @generated
     */
	private void componentValidation_VehicleSales(DWLStatus status) {
  
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "VehicleUsage"
     *
     * @generated
     */
	private void componentValidation_VehicleUsage(DWLStatus status) {
  
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "StartDate"
     *
     * @generated
     */
	private void componentValidation_StartDate(DWLStatus status) {
  
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "EndDate"
     *
     * @generated
     */
	private void componentValidation_EndDate(DWLStatus status) {
  
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "SourceIdentifier"
     *
     * @generated
     */
	private void componentValidation_SourceIdentifier(DWLStatus status) {
  
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "ConnectMeUsage"
     *
     * @generated
     */
	private void controllerValidation_ConnectMeUsage(DWLStatus status) throws Exception {
  
      //persistent code type
            boolean isConnectMeUsageNull = false;
            if ((eObjXCustomerVehicleKOR.getConnectMeUsage() == null) &&
               ((getConnectMeUsageValue() == null) || 
                 getConnectMeUsageValue().trim().equals(""))) {
                isConnectMeUsageNull = true;
            }
            if (!isConnectMeUsageNull) {
                if (checkForInvalidXcustomervehiclekorConnectmeusage()) {
                    DWLError err = new DWLError();
                    err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_KORBOBJ).longValue());
                    err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XCUSTOMERVEHICLEKOR_CONNECTMEUSAGE).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                    String infoForLogging="Error: Custom validation error occured for entity XCustomerVehicleKOR, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("controllerValidation_ConnectMeUsage " + infoForLogging);
        }
                status.addError(err);
            }

             }
    			
    	}
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "VehicleSales"
     *
     * @generated
     */
	private void controllerValidation_VehicleSales(DWLStatus status) throws Exception {
  
      //persistent code type
            boolean isVehicleSalesNull = false;
            if ((eObjXCustomerVehicleKOR.getVehicleSales() == null) &&
               ((getVehicleSalesValue() == null) || 
                 getVehicleSalesValue().trim().equals(""))) {
                isVehicleSalesNull = true;
            }
            if (!isVehicleSalesNull) {
                if (checkForInvalidXcustomervehiclekorVehiclesales()) {
                    DWLError err = new DWLError();
                    err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_KORBOBJ).longValue());
                    err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XCUSTOMERVEHICLEKOR_VEHICLESALES).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                    String infoForLogging="Error: Custom validation error occured for entity XCustomerVehicleKOR, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("controllerValidation_VehicleSales " + infoForLogging);
        }
                status.addError(err);
            }

             }
    			
    	}
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "VehicleUsage"
     *
     * @generated
     */
	private void controllerValidation_VehicleUsage(DWLStatus status) throws Exception {
  
      //persistent code type
            boolean isVehicleUsageNull = false;
            if ((eObjXCustomerVehicleKOR.getVehicleUsage() == null) &&
               ((getVehicleUsageValue() == null) || 
                 getVehicleUsageValue().trim().equals(""))) {
                isVehicleUsageNull = true;
            }
            if (!isVehicleUsageNull) {
                if (checkForInvalidXcustomervehiclekorVehicleusage()) {
                    DWLError err = new DWLError();
                    err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_KORBOBJ).longValue());
                    err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XCUSTOMERVEHICLEKOR_VEHICLEUSAGE).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                    String infoForLogging="Error: Custom validation error occured for entity XCustomerVehicleKOR, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("controllerValidation_VehicleUsage " + infoForLogging);
        }
                status.addError(err);
            }

             }
    			
    	}
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "StartDate"
     *
     * @generated
     */
	private void controllerValidation_StartDate(DWLStatus status) throws Exception {
  
            boolean isStartDateNull = (eObjXCustomerVehicleKOR.getStartDate() == null);
            if (!isValidStartDate) {
              	DWLError err = new DWLError();
               	err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_KORBOBJ).longValue());
               	err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XCUSTOMERVEHICLEKOR_STARTDATE).longValue());
               	err.setErrorType(DWLErrorCode.DATA_INVALID_ERROR);
                String infoForLogging="Error: Validation error. Invalid time specified on property StartDate in entity XCustomerVehicleKOR, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode();
      logger.finest("controllerValidation_StartDate " + infoForLogging);
               	status.addError(err);
            } 
    	}
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "EndDate"
     *
     * @generated
     */
	private void controllerValidation_EndDate(DWLStatus status) throws Exception {
  
            boolean isEndDateNull = (eObjXCustomerVehicleKOR.getEndDate() == null);
            if (!isValidEndDate) {
              	DWLError err = new DWLError();
               	err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_KORBOBJ).longValue());
               	err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XCUSTOMERVEHICLEKOR_ENDDATE).longValue());
               	err.setErrorType(DWLErrorCode.DATA_INVALID_ERROR);
                String infoForLogging="Error: Validation error. Invalid time specified on property EndDate in entity XCustomerVehicleKOR, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode();
      logger.finest("controllerValidation_EndDate " + infoForLogging);
               	status.addError(err);
            } 
    	}
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "SourceIdentifier"
     *
     * @generated
     */
	private void controllerValidation_SourceIdentifier(DWLStatus status) throws Exception {
  
      //persistent code type
            boolean isSourceIdentifierNull = false;
            if ((eObjXCustomerVehicleKOR.getSourceIdentifier() == null) &&
               ((getSourceIdentifierValue() == null) || 
                 getSourceIdentifierValue().trim().equals(""))) {
                isSourceIdentifierNull = true;
            }
            if (!isSourceIdentifierNull) {
                if (checkForInvalidXcustomervehiclekorSourceidentifier()) {
                    DWLError err = new DWLError();
                    err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_KORBOBJ).longValue());
                    err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XCUSTOMERVEHICLEKOR_SOURCEIDENTIFIER).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                    String infoForLogging="Error: Custom validation error occured for entity XCustomerVehicleKOR, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("controllerValidation_SourceIdentifier " + infoForLogging);
        }
                status.addError(err);
            }

             }
    			
    	}
    private DWLError createDWLError(String entityName, String propertyName,String reasonCode){	
		DWLError err = new DWLError();
		err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_KORBOBJ).longValue());
		err.setReasonCode(new Long(reasonCode).longValue());
		err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
			String infoForLogging="Error: Validation error occured. Property " + propertyName + " is null, in entity " + entityName + ", component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
			logger.finest("createDWLError " + infoForLogging);
		}
		return err;
    }
    
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Check the value of the field ConnectMeUsage and return true if the error
     * reason INVALID_XCUSTOMERVEHICLEKOR_CONNECTMEUSAGE should be returned.
     *
     * @generated
  **/
	private boolean checkForInvalidXcustomervehiclekorConnectmeusage() throws Exception {
    logger.finest("ENTER checkForInvalidXcustomervehiclekorConnectmeusage()");
        boolean notValid = false;
      	String langId = (String) this.getControl().get(DWLControlKeys.LANG_ID);
      	CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
    Long codeType = DWLFunctionUtils.getLongFromString( getConnectMeUsageType() );
    String codeValue = getConnectMeUsageValue();
    if( codeValue != null && codeValue.trim().equals("")){
      codeValue = null;
    }
     
        if ( codeType != null && codeValue == null ){

             if( codeTypeCompHelper.isCodeValid("xcdconnectmeusagetp", langId, getConnectMeUsageType(),
                 CodeTypeComponentHelper.ACTIVE, getControl())) {
                 CodeTypeBObj ctBObj = codeTypeCompHelper
                 					.getCodeTypeByCode("xcdconnectmeusagetp", langId, getConnectMeUsageType(),
                         								getControl());
               	if (ctBObj != null) {
                   	setConnectMeUsageValue( ctBObj.getvalue() );
               	}
             }
             else{
             	if (logger.isFinestEnabled()) {
              	 	String infoForLogging="NotValid 1";
      logger.finest("checkForInvalidXcustomervehiclekorConnectmeusage() " + infoForLogging);
        }
                 notValid = true;
           }
        }
        else if (codeType == null && codeValue != null ){
          
             CodeTypeBObj ctBObj = codeTypeCompHelper
                      .getCodeTypeByValue("xcdconnectmeusagetp", langId, codeValue,
                                 getControl());

             if (ctBObj != null) {
                 setConnectMeUsageType(ctBObj.gettp_cd());
             } 
             else {
             	if (logger.isFinestEnabled()) {
              	  	String infoForLogging="NotValid 2";
      logger.finest("checkForInvalidXcustomervehiclekorConnectmeusage() " + infoForLogging);
        }
                  notValid = true;
             }
        }
        else if ( codeType != null && codeValue != null
             && !codeTypeCompHelper.isCodeValuePairValid("xcdconnectmeusagetp", langId, getConnectMeUsageType(), 
                     new String[] { codeValue }, CodeTypeComponentHelper.ACTIVE, getControl())) {	
       if (logger.isFinestEnabled()) {
       		String infoForLogging="NotValid 3";
      logger.finest("checkForInvalidXcustomervehiclekorConnectmeusage() " + infoForLogging);
       }
             notValid = true;
        }
        if (logger.isFinestEnabled()) {
      String returnValue ="" +notValid;
      logger.finest("RETURN checkForInvalidXcustomervehiclekorConnectmeusage() " + returnValue);
    }
    return notValid;
     } 
				 
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Check the value of the field VehicleSales and return true if the error
     * reason INVALID_XCUSTOMERVEHICLEKOR_VEHICLESALES should be returned.
     *
     * @generated
  **/
	private boolean checkForInvalidXcustomervehiclekorVehiclesales() throws Exception {
    logger.finest("ENTER checkForInvalidXcustomervehiclekorVehiclesales()");
        boolean notValid = false;
      	String langId = (String) this.getControl().get(DWLControlKeys.LANG_ID);
      	CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
    Long codeType = DWLFunctionUtils.getLongFromString( getVehicleSalesType() );
    String codeValue = getVehicleSalesValue();
    if( codeValue != null && codeValue.trim().equals("")){
      codeValue = null;
    }
     
        if ( codeType != null && codeValue == null ){

             if( codeTypeCompHelper.isCodeValid("xcdvehiclesalestp", langId, getVehicleSalesType(),
                 CodeTypeComponentHelper.ACTIVE, getControl())) {
                 CodeTypeBObj ctBObj = codeTypeCompHelper
                 					.getCodeTypeByCode("xcdvehiclesalestp", langId, getVehicleSalesType(),
                         								getControl());
               	if (ctBObj != null) {
                   	setVehicleSalesValue( ctBObj.getvalue() );
               	}
             }
             else{
             	if (logger.isFinestEnabled()) {
              	 	String infoForLogging="NotValid 1";
      logger.finest("checkForInvalidXcustomervehiclekorVehiclesales() " + infoForLogging);
        }
                 notValid = true;
           }
        }
        else if (codeType == null && codeValue != null ){
          
             CodeTypeBObj ctBObj = codeTypeCompHelper
                      .getCodeTypeByValue("xcdvehiclesalestp", langId, codeValue,
                                 getControl());

             if (ctBObj != null) {
                 setVehicleSalesType(ctBObj.gettp_cd());
             } 
             else {
             	if (logger.isFinestEnabled()) {
              	  	String infoForLogging="NotValid 2";
      logger.finest("checkForInvalidXcustomervehiclekorVehiclesales() " + infoForLogging);
        }
                  notValid = true;
             }
        }
        else if ( codeType != null && codeValue != null
             && !codeTypeCompHelper.isCodeValuePairValid("xcdvehiclesalestp", langId, getVehicleSalesType(), 
                     new String[] { codeValue }, CodeTypeComponentHelper.ACTIVE, getControl())) {	
       if (logger.isFinestEnabled()) {
       		String infoForLogging="NotValid 3";
      logger.finest("checkForInvalidXcustomervehiclekorVehiclesales() " + infoForLogging);
       }
             notValid = true;
        }
        if (logger.isFinestEnabled()) {
      String returnValue ="" +notValid;
      logger.finest("RETURN checkForInvalidXcustomervehiclekorVehiclesales() " + returnValue);
    }
    return notValid;
     } 
				 
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Check the value of the field VehicleUsage and return true if the error
     * reason INVALID_XCUSTOMERVEHICLEKOR_VEHICLEUSAGE should be returned.
     *
     * @generated
  **/
	private boolean checkForInvalidXcustomervehiclekorVehicleusage() throws Exception {
    logger.finest("ENTER checkForInvalidXcustomervehiclekorVehicleusage()");
        boolean notValid = false;
      	String langId = (String) this.getControl().get(DWLControlKeys.LANG_ID);
      	CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
    Long codeType = DWLFunctionUtils.getLongFromString( getVehicleUsageType() );
    String codeValue = getVehicleUsageValue();
    if( codeValue != null && codeValue.trim().equals("")){
      codeValue = null;
    }
     
        if ( codeType != null && codeValue == null ){

             if( codeTypeCompHelper.isCodeValid("xcdvehicleusagetp", langId, getVehicleUsageType(),
                 CodeTypeComponentHelper.ACTIVE, getControl())) {
                 CodeTypeBObj ctBObj = codeTypeCompHelper
                 					.getCodeTypeByCode("xcdvehicleusagetp", langId, getVehicleUsageType(),
                         								getControl());
               	if (ctBObj != null) {
                   	setVehicleUsageValue( ctBObj.getvalue() );
               	}
             }
             else{
             	if (logger.isFinestEnabled()) {
              	 	String infoForLogging="NotValid 1";
      logger.finest("checkForInvalidXcustomervehiclekorVehicleusage() " + infoForLogging);
        }
                 notValid = true;
           }
        }
        else if (codeType == null && codeValue != null ){
          
             CodeTypeBObj ctBObj = codeTypeCompHelper
                      .getCodeTypeByValue("xcdvehicleusagetp", langId, codeValue,
                                 getControl());

             if (ctBObj != null) {
                 setVehicleUsageType(ctBObj.gettp_cd());
             } 
             else {
             	if (logger.isFinestEnabled()) {
              	  	String infoForLogging="NotValid 2";
      logger.finest("checkForInvalidXcustomervehiclekorVehicleusage() " + infoForLogging);
        }
                  notValid = true;
             }
        }
        else if ( codeType != null && codeValue != null
             && !codeTypeCompHelper.isCodeValuePairValid("xcdvehicleusagetp", langId, getVehicleUsageType(), 
                     new String[] { codeValue }, CodeTypeComponentHelper.ACTIVE, getControl())) {	
       if (logger.isFinestEnabled()) {
       		String infoForLogging="NotValid 3";
      logger.finest("checkForInvalidXcustomervehiclekorVehicleusage() " + infoForLogging);
       }
             notValid = true;
        }
        if (logger.isFinestEnabled()) {
      String returnValue ="" +notValid;
      logger.finest("RETURN checkForInvalidXcustomervehiclekorVehicleusage() " + returnValue);
    }
    return notValid;
     } 
				 
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Check the value of the field SourceIdentifier and return true if the
     * error reason INVALID_XCUSTOMERVEHICLEKOR_SOURCEIDENTIFIER should be
     * returned.
     *
     * @generated
  **/
	private boolean checkForInvalidXcustomervehiclekorSourceidentifier() throws Exception {
    logger.finest("ENTER checkForInvalidXcustomervehiclekorSourceidentifier()");
        boolean notValid = false;
      	String langId = (String) this.getControl().get(DWLControlKeys.LANG_ID);
      	CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
    Long codeType = DWLFunctionUtils.getLongFromString( getSourceIdentifierType() );
    String codeValue = getSourceIdentifierValue();
    if( codeValue != null && codeValue.trim().equals("")){
      codeValue = null;
    }
     
        if ( codeType != null && codeValue == null ){

             if( codeTypeCompHelper.isCodeValid("cdsourceidenttp", langId, getSourceIdentifierType(),
                 CodeTypeComponentHelper.ACTIVE, getControl())) {
                 CodeTypeBObj ctBObj = codeTypeCompHelper
                 					.getCodeTypeByCode("cdsourceidenttp", langId, getSourceIdentifierType(),
                         								getControl());
               	if (ctBObj != null) {
                   	setSourceIdentifierValue( ctBObj.getvalue() );
               	}
             }
             else{
             	if (logger.isFinestEnabled()) {
              	 	String infoForLogging="NotValid 1";
      logger.finest("checkForInvalidXcustomervehiclekorSourceidentifier() " + infoForLogging);
        }
                 notValid = true;
           }
        }
        else if (codeType == null && codeValue != null ){
          
             CodeTypeBObj ctBObj = codeTypeCompHelper
                      .getCodeTypeByValue("cdsourceidenttp", langId, codeValue,
                                 getControl());

             if (ctBObj != null) {
                 setSourceIdentifierType(ctBObj.gettp_cd());
             } 
             else {
             	if (logger.isFinestEnabled()) {
              	  	String infoForLogging="NotValid 2";
      logger.finest("checkForInvalidXcustomervehiclekorSourceidentifier() " + infoForLogging);
        }
                  notValid = true;
             }
        }
        else if ( codeType != null && codeValue != null
             && !codeTypeCompHelper.isCodeValuePairValid("cdsourceidenttp", langId, getSourceIdentifierType(), 
                     new String[] { codeValue }, CodeTypeComponentHelper.ACTIVE, getControl())) {	
       if (logger.isFinestEnabled()) {
       		String infoForLogging="NotValid 3";
      logger.finest("checkForInvalidXcustomervehiclekorSourceidentifier() " + infoForLogging);
       }
             notValid = true;
        }
        if (logger.isFinestEnabled()) {
      String returnValue ="" +notValid;
      logger.finest("RETURN checkForInvalidXcustomervehiclekorSourceidentifier() " + returnValue);
    }
    return notValid;
     } 
				 



}

