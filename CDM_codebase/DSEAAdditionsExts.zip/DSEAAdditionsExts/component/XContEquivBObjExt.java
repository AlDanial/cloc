
/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[0407fd69a9a961e5aa43cf53c850ab98]
 */

package com.ibm.daimler.dsea.component;

import com.dwl.base.util.DWLClassFactory;
import com.dwl.tcrm.exception.TCRMReadException;



import com.dwl.base.DWLControl;
import com.dwl.base.IDWLErrorMessage;

import com.dwl.base.error.DWLError;
import com.dwl.base.error.DWLErrorCode;
import com.dwl.base.error.DWLStatus;

import com.dwl.base.exception.DWLBaseException;

import com.dwl.base.util.DWLExceptionUtils;
import com.dwl.base.util.DWLFunctionUtils;

import com.dwl.management.config.client.Configuration;
import com.dwl.tcrm.common.IExtension;
import com.dwl.tcrm.common.ITCRMValidation;
import com.dwl.tcrm.common.TCRMErrorCode;

import com.dwl.tcrm.coreParty.component.TCRMAdminContEquivBObj;

import com.dwl.tcrm.utilities.DateFormatter;
import com.dwl.tcrm.utilities.DateValidator;
import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsComponentID;
import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsErrorReasonCode;

import com.ibm.daimler.dsea.entityObject.EObjXContEquivExt;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * This class provides the implementation of the business object
 * <code>XContEquivBObjExt</code>.
 * 
 * @see com.dwl.tcrm.common.TCRMCommon
 * @generated
 */
 

@SuppressWarnings("serial")
public class XContEquivBObjExt extends TCRMAdminContEquivBObj implements IExtension {

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected EObjXContEquivExt eObjXContEquivExt;
	/**
    * <!-- begin-user-doc -->
	  * <!-- end-user-doc -->
    * @generated 
    */
	 private final static com.dwl.base.logging.IDWLLogger logger = com.dwl.base.logging.DWLLoggerManager.getLogger(XContEquivBObjExt.class);
		
 


    protected boolean isValidXLastModifiedSystemDate = true;




    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */     
    public XContEquivBObjExt() {
        super();
        init();
        eObjXContEquivExt = new EObjXContEquivExt(getEObjContEquiv());
        setComponentID(DSEAAdditionsExtsComponentID.XCONT_EQUIV_BOBJ_EXT);
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Initializes the fields required to populate the metaDataMap. Each key is
     * an element-level field of the business object.
     *
     * @generated
     */
    private void init() {
        metaDataMap.put("XRetailerId", null);
        metaDataMap.put("XSourceRetailerFlag", null);
        metaDataMap.put("XLastModifiedSystemDate", null);
        metaDataMap.put("XContEquivHistActionCode", null);
        metaDataMap.put("XContEquivHistCreateDate", null);
        metaDataMap.put("XContEquivHistCreatedBy", null);
        metaDataMap.put("XContEquivHistEndDate", null);
        metaDataMap.put("XContEquivHistoryIdPK", null);
        metaDataMap.put("XContEquivLastUpdateDate", null);
        metaDataMap.put("XContEquivLastUpdateTxId", null);
        metaDataMap.put("XContEquivLastUpdateUser", null);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Refreshes all the attributes this business object supports.
     *
     * @see com.dwl.base.DWLCommon#refreshMap()
     * @generated
     */
    public void refreshMap() {

        if (bRequireMapRefresh) {
            super.refreshMap();
            metaDataMap.put("XRetailerId", getXRetailerId());
            metaDataMap.put("XSourceRetailerFlag", getXSourceRetailerFlag());
            metaDataMap.put("XLastModifiedSystemDate", getXLastModifiedSystemDate());
            metaDataMap.put("XContEquivHistActionCode", getXContEquivHistActionCode());
            metaDataMap.put("XContEquivHistCreateDate", getXContEquivHistCreateDate());
            metaDataMap.put("XContEquivHistCreatedBy", getXContEquivHistCreatedBy());
            metaDataMap.put("XContEquivHistEndDate", getXContEquivHistEndDate());
            metaDataMap.put("XContEquivHistoryIdPK", getXContEquivHistoryIdPK());
            metaDataMap.put("XContEquivLastUpdateDate", getXContEquivLastUpdateDate());
            metaDataMap.put("XContEquivLastUpdateTxId", getXContEquivLastUpdateTxId());
            metaDataMap.put("XContEquivLastUpdateUser", getXContEquivLastUpdateUser());
            bRequireMapRefresh = false;
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the control object on this business object.
     *
     * @see com.dwl.base.DWLCommon#setControl(DWLControl)
     * @generated
     */
    public void setControl(DWLControl newDWLControl) {
        super.setControl(newDWLControl);

        if (eObjXContEquivExt != null) {
            eObjXContEquivExt.setControl(newDWLControl);
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the entity object associated with this business object.
     *
     * @generated
     */
    public EObjXContEquivExt getEObjXContEquivExt() {
        bRequireMapRefresh = true;
        return eObjXContEquivExt;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the entity object associated with this business object.
     *
     * @param eObjXContEquivExt
     *            The eObjXContEquivExt to set.
     * @generated
     */
    public void setEObjXContEquivExt(EObjXContEquivExt eObjXContEquivExt) {
        bRequireMapRefresh = true;
        this.eObjXContEquivExt = eObjXContEquivExt;
        this.eObjXContEquivExt.setBaseEntity(getEObjContEquiv());
        if (this.eObjXContEquivExt != null && this.eObjXContEquivExt.getControl() == null) {
            DWLControl control = this.getControl();
            if (control != null) {
                this.eObjXContEquivExt.setControl(control);
            }
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xRetailerId attribute.
     * 
     * @generated
     */
    public String getXRetailerId (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXContEquivExt.getXRetailerId());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xRetailerId attribute.
     * 
     * @param newXRetailerId
     *     The new value of xRetailerId.
     * @generated
     */
    public void setXRetailerId( String newXRetailerId ) throws Exception {
        metaDataMap.put("XRetailerId", newXRetailerId);

        if (newXRetailerId == null || newXRetailerId.equals("")) {
            newXRetailerId = null;


        }
        eObjXContEquivExt.setXRetailerId( DWLFunctionUtils.getLongFromString(newXRetailerId) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xSourceRetailerFlag attribute.
     * 
     * @generated
     */
    public String getXSourceRetailerFlag (){
   
        return eObjXContEquivExt.getXSourceRetailerFlag();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xSourceRetailerFlag attribute.
     * 
     * @param newXSourceRetailerFlag
     *     The new value of xSourceRetailerFlag.
     * @generated
     */
    public void setXSourceRetailerFlag( String newXSourceRetailerFlag ) throws Exception {
        metaDataMap.put("XSourceRetailerFlag", newXSourceRetailerFlag);

        if (newXSourceRetailerFlag == null || newXSourceRetailerFlag.equals("")) {
            newXSourceRetailerFlag = null;


        }
        eObjXContEquivExt.setXSourceRetailerFlag( newXSourceRetailerFlag );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xLastModifiedSystemDate attribute.
     * 
     * @generated
     */
    public String getXLastModifiedSystemDate (){
   
        return DWLFunctionUtils.getStringFromTimestamp(eObjXContEquivExt.getXLastModifiedSystemDate());
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xLastModifiedSystemDate attribute.
     * 
     * @param newXLastModifiedSystemDate
     *     The new value of xLastModifiedSystemDate.
     * @generated
     */
    public void setXLastModifiedSystemDate( String newXLastModifiedSystemDate ) throws Exception {
        metaDataMap.put("XLastModifiedSystemDate", newXLastModifiedSystemDate);
       	isValidXLastModifiedSystemDate = true;

        if (newXLastModifiedSystemDate == null || newXLastModifiedSystemDate.equals("")) {
            newXLastModifiedSystemDate = null;
            eObjXContEquivExt.setXLastModifiedSystemDate(null);


        }
    else {
        	if (DateValidator.validates(newXLastModifiedSystemDate)) {
           		eObjXContEquivExt.setXLastModifiedSystemDate(DateFormatter.getStartDateTimestamp(newXLastModifiedSystemDate));
            	metaDataMap.put("XLastModifiedSystemDate", getXLastModifiedSystemDate());
        	} else {
            	if (Configuration.getConfiguration().getConfigItem(
              "/IBM/DWLCommonServices/InternalValidation/enabled").getBooleanValue()) {
                	if (metaDataMap.get("XLastModifiedSystemDate") != null) {
                    	metaDataMap.put("XLastModifiedSystemDate", "");
                	}
                	isValidXLastModifiedSystemDate = false;
                	eObjXContEquivExt.setXLastModifiedSystemDate(null);
            	}
        	}
        }
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateTxId attribute.
     *
     * @generated
     */
    public String getXContEquivLastUpdateTxId() {
        return DWLFunctionUtils.getStringFromLong(eObjXContEquivExt.getLastUpdateTxId());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateUser attribute.
     *
     * @generated
     */
    public String getXContEquivLastUpdateUser() {
        return eObjXContEquivExt.getLastUpdateUser();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateDt attribute.
     *
     * @generated
     */
    public String getXContEquivLastUpdateDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXContEquivExt.getLastUpdateDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateTxId attribute.
     *
     * @param newLastUpdateTxId
     *     The new value of LastUpdateTxId.
     * @generated
     */
    public void setXContEquivLastUpdateTxId(String newLastUpdateTxId) {
        metaDataMap.put("XContEquivLastUpdateTxId", newLastUpdateTxId);

        if ((newLastUpdateTxId == null) || newLastUpdateTxId.equals("")) {
            newLastUpdateTxId = null;
        }
        eObjXContEquivExt.setLastUpdateTxId(DWLFunctionUtils.getLongFromString(newLastUpdateTxId));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateUser attribute.
     *
     * @param newLastUpdateUser
     *     The new value of LastUpdateUser.
     * @generated
     */
    public void setXContEquivLastUpdateUser(String newLastUpdateUser) {
        metaDataMap.put("XContEquivLastUpdateUser", newLastUpdateUser);

        if ((newLastUpdateUser == null) || newLastUpdateUser.equals("")) {
            newLastUpdateUser = null;
        }
        eObjXContEquivExt.setLastUpdateUser(newLastUpdateUser);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateDt attribute.
     *
     * @param newLastUpdateDt
     *     The new value of LastUpdateDt.
     * @throws Exception
     * @generated
     */
    public void setXContEquivLastUpdateDate(String newLastUpdateDt) throws Exception {
        metaDataMap.put("XContEquivLastUpdateDate", newLastUpdateDt);

        if ((newLastUpdateDt == null) || newLastUpdateDt.equals("")) {
            newLastUpdateDt = null;
        }

        eObjXContEquivExt.setLastUpdateDt(DWLFunctionUtils.getTimestampFromTimestampString(newLastUpdateDt));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XContEquivHistActionCode history attribute.
     *
     * @generated
     */
    public String getXContEquivHistActionCode() {
        return eObjXContEquivExt.getHistActionCode();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XContEquivHistActionCode history attribute.
     *
     * @param aXContEquivHistActionCode
     *     The new value of XContEquivHistActionCode.
     * @generated
     */
    public void setXContEquivHistActionCode(String aXContEquivHistActionCode) {
        metaDataMap.put("XContEquivHistActionCode", aXContEquivHistActionCode);

        if ((aXContEquivHistActionCode == null) || aXContEquivHistActionCode.equals("")) {
            aXContEquivHistActionCode = null;
        }
        eObjXContEquivExt.setHistActionCode(aXContEquivHistActionCode);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XContEquivHistCreateDate history attribute.
     *
     * @generated
     */
    public String getXContEquivHistCreateDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXContEquivExt.getHistCreateDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XContEquivHistCreateDate history attribute.
     *
     * @param aXContEquivHistCreateDate
     *     The new value of XContEquivHistCreateDate.
     * @generated
     */
    public void setXContEquivHistCreateDate(String aXContEquivHistCreateDate) throws Exception{
        metaDataMap.put("XContEquivHistCreateDate", aXContEquivHistCreateDate);

        if ((aXContEquivHistCreateDate == null) || aXContEquivHistCreateDate.equals("")) {
            aXContEquivHistCreateDate = null;
        }

        eObjXContEquivExt.setHistCreateDt(DWLFunctionUtils.getTimestampFromTimestampString(aXContEquivHistCreateDate));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XContEquivHistCreatedBy history attribute.
     *
     * @generated
     */
    public String getXContEquivHistCreatedBy() {
        return eObjXContEquivExt.getHistCreatedBy();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XContEquivHistCreatedBy history attribute.
     *
     * @param aXContEquivHistCreatedBy
     *     The new value of XContEquivHistCreatedBy.
     * @generated
     */
    public void setXContEquivHistCreatedBy(String aXContEquivHistCreatedBy) {
        metaDataMap.put("XContEquivHistCreatedBy", aXContEquivHistCreatedBy);

        if ((aXContEquivHistCreatedBy == null) || aXContEquivHistCreatedBy.equals("")) {
            aXContEquivHistCreatedBy = null;
        }

        eObjXContEquivExt.setHistCreatedBy(aXContEquivHistCreatedBy);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XContEquivHistEndDate history attribute.
     *
     * @generated
     */
    public String getXContEquivHistEndDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXContEquivExt.getHistEndDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XContEquivHistEndDate history attribute.
     *
     * @param aXContEquivHistEndDate
     *     The new value of XContEquivHistEndDate.
     * @generated
     */
    public void setXContEquivHistEndDate(String aXContEquivHistEndDate) throws Exception{
        metaDataMap.put("XContEquivHistEndDate", aXContEquivHistEndDate);

        if ((aXContEquivHistEndDate == null) || aXContEquivHistEndDate.equals("")) {
            aXContEquivHistEndDate = null;
        }
        eObjXContEquivExt.setHistEndDt(DWLFunctionUtils.getTimestampFromTimestampString(aXContEquivHistEndDate));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XContEquivHistoryIdPK history attribute.
     *
     * @generated
     */
    public String getXContEquivHistoryIdPK() {
        return DWLFunctionUtils.getStringFromLong(eObjXContEquivExt.getHistoryIdPK());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XContEquivHistoryIdPK history attribute.
     *
     * @param aXContEquivHistoryIdPK
     *     The new value of XContEquivHistoryIdPK.
     * @generated
     */
    public void setXContEquivHistoryIdPK(String aXContEquivHistoryIdPK) {
        metaDataMap.put("XContEquivHistoryIdPK", aXContEquivHistoryIdPK);

        if ((aXContEquivHistoryIdPK == null) || aXContEquivHistoryIdPK.equals("")) {
            aXContEquivHistoryIdPK = null;
        }
        eObjXContEquivExt.setHistoryIdPK(DWLFunctionUtils.getLongFromString(aXContEquivHistoryIdPK));
    }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation during an add transaction.
     *
     * @generated
     */
    public DWLStatus validateAdd(int level, DWLStatus status) throws Exception {

        status = super.validateAdd(level, status);
        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0038I Add any controller-level custom validation logic to be
            // executed for this object during an "add" transaction

        }

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            // MDM_TODO0: CDKWB0039I Add any component-level custom validation logic to be
            // executed for this object during an "add" transaction
        }
        status = getValidationStatus(level, status);
        return status;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation during an update transaction.
     *
     * @generated
     */
    public DWLStatus validateUpdate(int level, DWLStatus status) throws Exception {
    logger.finest("ENTER validateUpdate(int level, DWLStatus status)");

        status = super.validateUpdate(level, status);
        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0040I Add any controller-level custom validation logic to be
            // executed for this object during an "update" transaction

        }

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            assignBeforeImageValues(metaDataMap);
            
            // MDM_TODO0: CDKWB0041I Add any component-level custom validation logic to be
            // executed for this object during an "update" transaction
        }
        status = getValidationStatus(level, status);
    if (logger.isFinestEnabled()) {
        	String returnValue = status.toString();
      logger.finest("RETURN validateUpdate(int level, DWLStatus status) " + returnValue);
    }
        return status;
    }



    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation common to both add and update transactions.
     *
     * @generated
     */
     
    private DWLStatus getValidationStatus(int level, DWLStatus status) throws Exception {
    logger.finest("ENTER getValidationStatus(int level, DWLStatus status)");

        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0034I Add any common controller-level custom validation
            // logic to be executed for this object during either "add" or
            // "update" transactions
    		controllerValidation_XLastModifiedSystemDate(status);
    	}

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            // MDM_TODO0: CDKWB0035I Add any common component-level custom validation logic
            // to be executed for this object during either "add" or "update"
            // transactions
    		componentValidation_XLastModifiedSystemDate(status);
        }
        
        if (logger.isFinestEnabled()) {
            String returnValue = status.toString();
      logger.finest("RETURN getValidationStatus(int level, DWLStatus status) " + returnValue);
        }
    
        return status;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "XLastModifiedSystemDate"
     *
     * @generated
     */
  private void componentValidation_XLastModifiedSystemDate(DWLStatus status) {
  
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "XLastModifiedSystemDate"
     *
     * @generated
     */
  private void controllerValidation_XLastModifiedSystemDate(DWLStatus status) throws Exception {
  
            boolean isXLastModifiedSystemDateNull = (eObjXContEquivExt.getXLastModifiedSystemDate() == null);
            if (!isValidXLastModifiedSystemDate) {
              	DWLError err = new DWLError();
               	err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCONT_EQUIV_BOBJ_EXT).longValue());
               	err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XCONTEQUIV_XLASTMODIFIEDSYSTEMDATE).longValue());
               	err.setErrorType(DWLErrorCode.DATA_INVALID_ERROR);
                String infoForLogging="Error: Validation error. Invalid time specified on property XLastModifiedSystemDate in entity XContEquiv, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode();
      logger.finest("controllerValidation_XLastModifiedSystemDate " + infoForLogging);
               	status.addError(err);
            } 
    	}


    private DWLError createDWLError(String entityName, String propertyName,String reasonCode){	
		DWLError err = new DWLError();
		err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCONT_EQUIV_BOBJ_EXT).longValue());
		err.setReasonCode(new Long(reasonCode).longValue());
		err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
			String infoForLogging="Error: Validation error occured. Property " + propertyName + " is null, in entity " + entityName + ", component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
			logger.finest("createDWLError " + infoForLogging);
		}
		return err;
    }
    






	 /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets a record from the extension table.
     *
     * @throws DWLBaseException
     * @generated
     */
    public void getRecord() throws DWLBaseException {
    logger.finest("ENTER getRecord()");
    
    try {
         			
         }
         catch (Exception e) {
            DWLExceptionUtils.log(e);
            
            if (logger.isFinestEnabled()) {
        		String infoForLogging="Error: Error reading record " + e.getMessage(); 
      logger.finest("getRecord() " + infoForLogging);
      }
            status = new DWLStatus();

            TCRMReadException readEx = new TCRMReadException();
            IDWLErrorMessage  errHandler = DWLClassFactory.getErrorHandler();
            DWLError          error = errHandler.getErrorMessage(DSEAAdditionsExtsComponentID.XCONT_EQUIV_BOBJ_EXT,
                                                                 TCRMErrorCode.READ_RECORD_ERROR,
                                                                 DSEAAdditionsExtsErrorReasonCode.READ_EXTENSION_XCONTEQUIV_FAILED,
                                                                 getControl(), new String[0]);
            error.setThrowable(e);
            status.addError(error);
            status.setStatus(DWLStatus.FATAL);
            readEx.setStatus(status);
            throw readEx;
        }	    		
    logger.finest("RETURN getRecord()");
  }


}

