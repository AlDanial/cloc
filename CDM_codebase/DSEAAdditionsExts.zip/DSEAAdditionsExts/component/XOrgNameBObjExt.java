
/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[fa8c6fdbc56c705fd1f49406450deb08]
 */

package com.ibm.daimler.dsea.component;

import com.dwl.base.util.DWLClassFactory;
import com.dwl.tcrm.exception.TCRMReadException;



import com.dwl.base.DWLControl;
import com.dwl.base.IDWLErrorMessage;

import com.dwl.base.error.DWLError;
import com.dwl.base.error.DWLErrorCode;
import com.dwl.base.error.DWLStatus;

import com.dwl.base.exception.DWLBaseException;

import com.dwl.base.util.DWLExceptionUtils;
import com.dwl.base.util.DWLFunctionUtils;

import com.dwl.management.config.client.Configuration;

import com.dwl.tcrm.common.IExtension;
import com.dwl.tcrm.common.ITCRMValidation;
import com.dwl.tcrm.common.TCRMErrorCode;

import com.dwl.tcrm.coreParty.component.TCRMOrganizationNameBObj;

import com.dwl.tcrm.utilities.DateFormatter;
import com.dwl.tcrm.utilities.DateValidator;

import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsComponentID;
import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsErrorReasonCode;

import com.ibm.daimler.dsea.entityObject.EObjXOrgNameExt;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * This class provides the implementation of the business object
 * <code>XOrgNameBObjExt</code>.
 * 
 * @see com.dwl.tcrm.common.TCRMCommon
 * @generated
 */
 

@SuppressWarnings("serial")
public class XOrgNameBObjExt extends TCRMOrganizationNameBObj implements IExtension {

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected EObjXOrgNameExt eObjXOrgNameExt;
	/**
    * <!-- begin-user-doc -->
	  * <!-- end-user-doc -->
    * @generated 
    */
	 private final static com.dwl.base.logging.IDWLLogger logger = com.dwl.base.logging.DWLLoggerManager.getLogger(XOrgNameBObjExt.class);
		
 
	protected boolean isValidXLastModifiedSystemDate = true;
	


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */     
    public XOrgNameBObjExt() {
        super();
        init();
        eObjXOrgNameExt = new EObjXOrgNameExt(getEObjOrganizationName());
        setComponentID(DSEAAdditionsExtsComponentID.XORG_NAME_BOBJ_EXT);
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Initializes the fields required to populate the metaDataMap. Each key is
     * an element-level field of the business object.
     *
     * @generated
     */
    private void init() {
        metaDataMap.put("XLastModifiedSystemDate", null);
        metaDataMap.put("XOrganizationNameLocal", null);
        metaDataMap.put("XOrgNameRetailerFlag", null);
        metaDataMap.put("X_BPID", null);
        metaDataMap.put("XOrgNameHistActionCode", null);
        metaDataMap.put("XOrgNameHistCreateDate", null);
        metaDataMap.put("XOrgNameHistCreatedBy", null);
        metaDataMap.put("XOrgNameHistEndDate", null);
        metaDataMap.put("XOrgNameHistoryIdPK", null);
        metaDataMap.put("XOrgNameLastUpdateDate", null);
        metaDataMap.put("XOrgNameLastUpdateTxId", null);
        metaDataMap.put("XOrgNameLastUpdateUser", null);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Refreshes all the attributes this business object supports.
     *
     * @see com.dwl.base.DWLCommon#refreshMap()
     * @generated
     */
    public void refreshMap() {

        if (bRequireMapRefresh) {
            super.refreshMap();
            metaDataMap.put("XLastModifiedSystemDate", getXLastModifiedSystemDate());
            metaDataMap.put("XOrganizationNameLocal", getXOrganizationNameLocal());
            metaDataMap.put("XOrgNameRetailerFlag", getXOrgNameRetailerFlag());
            metaDataMap.put("X_BPID", getX_BPID());
            metaDataMap.put("XOrgNameHistActionCode", getXOrgNameHistActionCode());
            metaDataMap.put("XOrgNameHistCreateDate", getXOrgNameHistCreateDate());
            metaDataMap.put("XOrgNameHistCreatedBy", getXOrgNameHistCreatedBy());
            metaDataMap.put("XOrgNameHistEndDate", getXOrgNameHistEndDate());
            metaDataMap.put("XOrgNameHistoryIdPK", getXOrgNameHistoryIdPK());
            metaDataMap.put("XOrgNameLastUpdateDate", getXOrgNameLastUpdateDate());
            metaDataMap.put("XOrgNameLastUpdateTxId", getXOrgNameLastUpdateTxId());
            metaDataMap.put("XOrgNameLastUpdateUser", getXOrgNameLastUpdateUser());
            bRequireMapRefresh = false;
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the control object on this business object.
     *
     * @see com.dwl.base.DWLCommon#setControl(DWLControl)
     * @generated
     */
    public void setControl(DWLControl newDWLControl) {
        super.setControl(newDWLControl);

        if (eObjXOrgNameExt != null) {
            eObjXOrgNameExt.setControl(newDWLControl);
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the entity object associated with this business object.
     *
     * @generated
     */
    public EObjXOrgNameExt getEObjXOrgNameExt() {
        bRequireMapRefresh = true;
        return eObjXOrgNameExt;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the entity object associated with this business object.
     *
     * @param eObjXOrgNameExt
     *            The eObjXOrgNameExt to set.
     * @generated
     */
    public void setEObjXOrgNameExt(EObjXOrgNameExt eObjXOrgNameExt) {
        bRequireMapRefresh = true;
        this.eObjXOrgNameExt = eObjXOrgNameExt;
        this.eObjXOrgNameExt.setBaseEntity(getEObjOrganizationName());
        if (this.eObjXOrgNameExt != null && this.eObjXOrgNameExt.getControl() == null) {
            DWLControl control = this.getControl();
            if (control != null) {
                this.eObjXOrgNameExt.setControl(control);
            }
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xOrganizationNameLocal attribute.
     * 
     * @generated
     */
    public String getXOrganizationNameLocal (){
   
        return eObjXOrgNameExt.getXOrganizationNameLocal();
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xOrganizationNameLocal attribute.
     * 
     * @param newXOrganizationNameLocal
     *     The new value of xOrganizationNameLocal.
     * @generated
     */
    public void setXOrganizationNameLocal( String newXOrganizationNameLocal ) throws Exception {
        metaDataMap.put("XOrganizationNameLocal", newXOrganizationNameLocal);

        if (newXOrganizationNameLocal == null || newXOrganizationNameLocal.equals("")) {
            newXOrganizationNameLocal = null;


        }
        eObjXOrgNameExt.setXOrganizationNameLocal( newXOrganizationNameLocal );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xOrgNameRetailerFlag attribute.
     * 
     * @generated
     */
    public String getXOrgNameRetailerFlag (){
   
        return eObjXOrgNameExt.getXOrgNameRetailerFlag();
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xOrgNameRetailerFlag attribute.
     * 
     * @param newXOrgNameRetailerFlag
     *     The new value of xOrgNameRetailerFlag.
     * @generated
     */
    public void setXOrgNameRetailerFlag( String newXOrgNameRetailerFlag ) throws Exception {
        metaDataMap.put("XOrgNameRetailerFlag", newXOrgNameRetailerFlag);

        if (newXOrgNameRetailerFlag == null || newXOrgNameRetailerFlag.equals("")) {
            newXOrgNameRetailerFlag = null;


        }
        eObjXOrgNameExt.setXOrgNameRetailerFlag( newXOrgNameRetailerFlag );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the x_BPID attribute.
     * 
     * @generated
     */
    public String getX_BPID (){
   
        return eObjXOrgNameExt.getX_BPID();
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the x_BPID attribute.
     * 
     * @param newX_BPID
     *     The new value of x_BPID.
     * @generated
     */
    public void setX_BPID( String newX_BPID ) throws Exception {
        metaDataMap.put("X_BPID", newX_BPID);

        if (newX_BPID == null || newX_BPID.equals("")) {
            newX_BPID = null;


        }
        eObjXOrgNameExt.setX_BPID( newX_BPID );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xLastModifiedSystemDate attribute.
     * 
     * @generated
     */
    public String getXLastModifiedSystemDate (){
   
        return DWLFunctionUtils.getStringFromTimestamp(eObjXOrgNameExt.getXLastModifiedSystemDate());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xLastModifiedSystemDate attribute.
     * 
     * @param newXLastModifiedSystemDate
     *     The new value of xLastModifiedSystemDate.
     * @generated
     */
    public void setXLastModifiedSystemDate( String newXLastModifiedSystemDate ) throws Exception {
        metaDataMap.put("XLastModifiedSystemDate", newXLastModifiedSystemDate);
       	isValidXLastModifiedSystemDate = true;

        if (newXLastModifiedSystemDate == null || newXLastModifiedSystemDate.equals("")) {
            newXLastModifiedSystemDate = null;
            eObjXOrgNameExt.setXLastModifiedSystemDate(null);


        }
    else {
        	if (DateValidator.validates(newXLastModifiedSystemDate)) {
           		eObjXOrgNameExt.setXLastModifiedSystemDate(DateFormatter.getStartDateTimestamp(newXLastModifiedSystemDate));
            	metaDataMap.put("XLastModifiedSystemDate", getXLastModifiedSystemDate());
        	} else {
            	if (Configuration.getConfiguration().getConfigItem(
              "/IBM/DWLCommonServices/InternalValidation/enabled").getBooleanValue()) {
                	if (metaDataMap.get("XLastModifiedSystemDate") != null) {
                    	metaDataMap.put("XLastModifiedSystemDate", "");
                	}
                	isValidXLastModifiedSystemDate = false;
                	eObjXOrgNameExt.setXLastModifiedSystemDate(null);
            	}
        	}
        }
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateTxId attribute.
     *
     * @generated
     */
    public String getXOrgNameLastUpdateTxId() {
        return DWLFunctionUtils.getStringFromLong(eObjXOrgNameExt.getLastUpdateTxId());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateUser attribute.
     *
     * @generated
     */
    public String getXOrgNameLastUpdateUser() {
        return eObjXOrgNameExt.getLastUpdateUser();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateDt attribute.
     *
     * @generated
     */
    public String getXOrgNameLastUpdateDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXOrgNameExt.getLastUpdateDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateTxId attribute.
     *
     * @param newLastUpdateTxId
     *     The new value of LastUpdateTxId.
     * @generated
     */
    public void setXOrgNameLastUpdateTxId(String newLastUpdateTxId) {
        metaDataMap.put("XOrgNameLastUpdateTxId", newLastUpdateTxId);

        if ((newLastUpdateTxId == null) || newLastUpdateTxId.equals("")) {
            newLastUpdateTxId = null;
        }
        eObjXOrgNameExt.setLastUpdateTxId(DWLFunctionUtils.getLongFromString(newLastUpdateTxId));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateUser attribute.
     *
     * @param newLastUpdateUser
     *     The new value of LastUpdateUser.
     * @generated
     */
    public void setXOrgNameLastUpdateUser(String newLastUpdateUser) {
        metaDataMap.put("XOrgNameLastUpdateUser", newLastUpdateUser);

        if ((newLastUpdateUser == null) || newLastUpdateUser.equals("")) {
            newLastUpdateUser = null;
        }
        eObjXOrgNameExt.setLastUpdateUser(newLastUpdateUser);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateDt attribute.
     *
     * @param newLastUpdateDt
     *     The new value of LastUpdateDt.
     * @throws Exception
     * @generated
     */
    public void setXOrgNameLastUpdateDate(String newLastUpdateDt) throws Exception {
        metaDataMap.put("XOrgNameLastUpdateDate", newLastUpdateDt);

        if ((newLastUpdateDt == null) || newLastUpdateDt.equals("")) {
            newLastUpdateDt = null;
        }

        eObjXOrgNameExt.setLastUpdateDt(DWLFunctionUtils.getTimestampFromTimestampString(newLastUpdateDt));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XOrgNameHistActionCode history attribute.
     *
     * @generated
     */
    public String getXOrgNameHistActionCode() {
        return eObjXOrgNameExt.getHistActionCode();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XOrgNameHistActionCode history attribute.
     *
     * @param aXOrgNameHistActionCode
     *     The new value of XOrgNameHistActionCode.
     * @generated
     */
    public void setXOrgNameHistActionCode(String aXOrgNameHistActionCode) {
        metaDataMap.put("XOrgNameHistActionCode", aXOrgNameHistActionCode);

        if ((aXOrgNameHistActionCode == null) || aXOrgNameHistActionCode.equals("")) {
            aXOrgNameHistActionCode = null;
        }
        eObjXOrgNameExt.setHistActionCode(aXOrgNameHistActionCode);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XOrgNameHistCreateDate history attribute.
     *
     * @generated
     */
    public String getXOrgNameHistCreateDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXOrgNameExt.getHistCreateDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XOrgNameHistCreateDate history attribute.
     *
     * @param aXOrgNameHistCreateDate
     *     The new value of XOrgNameHistCreateDate.
     * @generated
     */
    public void setXOrgNameHistCreateDate(String aXOrgNameHistCreateDate) throws Exception{
        metaDataMap.put("XOrgNameHistCreateDate", aXOrgNameHistCreateDate);

        if ((aXOrgNameHistCreateDate == null) || aXOrgNameHistCreateDate.equals("")) {
            aXOrgNameHistCreateDate = null;
        }

        eObjXOrgNameExt.setHistCreateDt(DWLFunctionUtils.getTimestampFromTimestampString(aXOrgNameHistCreateDate));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XOrgNameHistCreatedBy history attribute.
     *
     * @generated
     */
    public String getXOrgNameHistCreatedBy() {
        return eObjXOrgNameExt.getHistCreatedBy();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XOrgNameHistCreatedBy history attribute.
     *
     * @param aXOrgNameHistCreatedBy
     *     The new value of XOrgNameHistCreatedBy.
     * @generated
     */
    public void setXOrgNameHistCreatedBy(String aXOrgNameHistCreatedBy) {
        metaDataMap.put("XOrgNameHistCreatedBy", aXOrgNameHistCreatedBy);

        if ((aXOrgNameHistCreatedBy == null) || aXOrgNameHistCreatedBy.equals("")) {
            aXOrgNameHistCreatedBy = null;
        }

        eObjXOrgNameExt.setHistCreatedBy(aXOrgNameHistCreatedBy);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XOrgNameHistEndDate history attribute.
     *
     * @generated
     */
    public String getXOrgNameHistEndDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXOrgNameExt.getHistEndDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XOrgNameHistEndDate history attribute.
     *
     * @param aXOrgNameHistEndDate
     *     The new value of XOrgNameHistEndDate.
     * @generated
     */
    public void setXOrgNameHistEndDate(String aXOrgNameHistEndDate) throws Exception{
        metaDataMap.put("XOrgNameHistEndDate", aXOrgNameHistEndDate);

        if ((aXOrgNameHistEndDate == null) || aXOrgNameHistEndDate.equals("")) {
            aXOrgNameHistEndDate = null;
        }
        eObjXOrgNameExt.setHistEndDt(DWLFunctionUtils.getTimestampFromTimestampString(aXOrgNameHistEndDate));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XOrgNameHistoryIdPK history attribute.
     *
     * @generated
     */
    public String getXOrgNameHistoryIdPK() {
        return DWLFunctionUtils.getStringFromLong(eObjXOrgNameExt.getHistoryIdPK());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XOrgNameHistoryIdPK history attribute.
     *
     * @param aXOrgNameHistoryIdPK
     *     The new value of XOrgNameHistoryIdPK.
     * @generated
     */
    public void setXOrgNameHistoryIdPK(String aXOrgNameHistoryIdPK) {
        metaDataMap.put("XOrgNameHistoryIdPK", aXOrgNameHistoryIdPK);

        if ((aXOrgNameHistoryIdPK == null) || aXOrgNameHistoryIdPK.equals("")) {
            aXOrgNameHistoryIdPK = null;
        }
        eObjXOrgNameExt.setHistoryIdPK(DWLFunctionUtils.getLongFromString(aXOrgNameHistoryIdPK));
    }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation during an add transaction.
     *
     * @generated
     */
    public DWLStatus validateAdd(int level, DWLStatus status) throws Exception {

        status = super.validateAdd(level, status);
        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0038I Add any controller-level custom validation logic to be
            // executed for this object during an "add" transaction

        }

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            // MDM_TODO0: CDKWB0039I Add any component-level custom validation logic to be
            // executed for this object during an "add" transaction
        }
        status = getValidationStatus(level, status);
        return status;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation during an update transaction.
     *
     * @generated
     */
    public DWLStatus validateUpdate(int level, DWLStatus status) throws Exception {
    logger.finest("ENTER validateUpdate(int level, DWLStatus status)");

        status = super.validateUpdate(level, status);
        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0040I Add any controller-level custom validation logic to be
            // executed for this object during an "update" transaction

        }

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            assignBeforeImageValues(metaDataMap);
            
            // MDM_TODO0: CDKWB0041I Add any component-level custom validation logic to be
            // executed for this object during an "update" transaction
        }
        status = getValidationStatus(level, status);
    if (logger.isFinestEnabled()) {
        	String returnValue = status.toString();
      logger.finest("RETURN validateUpdate(int level, DWLStatus status) " + returnValue);
    }
        return status;
    }



    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation common to both add and update transactions.
     *
     * @generated
     */
     
    private DWLStatus getValidationStatus(int level, DWLStatus status) throws Exception {
    logger.finest("ENTER getValidationStatus(int level, DWLStatus status)");

        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0034I Add any common controller-level custom validation
            // logic to be executed for this object during either "add" or
            // "update" transactions
    		controllerValidation_XLastModifiedSystemDate(status);
    	}

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            // MDM_TODO0: CDKWB0035I Add any common component-level custom validation logic
            // to be executed for this object during either "add" or "update"
            // transactions
    		componentValidation_XLastModifiedSystemDate(status);
        }
        
        if (logger.isFinestEnabled()) {
            String returnValue = status.toString();
      logger.finest("RETURN getValidationStatus(int level, DWLStatus status) " + returnValue);
        }
    
        return status;
    }

    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "XLastModifiedSystemDate"
     *
     * @generated
     */
	private void componentValidation_XLastModifiedSystemDate(DWLStatus status) {
  
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "XLastModifiedSystemDate"
     *
     * @generated
     */
	private void controllerValidation_XLastModifiedSystemDate(DWLStatus status) throws Exception {
  
            boolean isXLastModifiedSystemDateNull = (eObjXOrgNameExt.getXLastModifiedSystemDate() == null);
            if (!isValidXLastModifiedSystemDate) {
              	DWLError err = new DWLError();
               	err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XORG_NAME_BOBJ_EXT).longValue());
               	err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XORGNAME_XLASTMODIFIEDSYSTEMDATE).longValue());
               	err.setErrorType(DWLErrorCode.DATA_INVALID_ERROR);
                String infoForLogging="Error: Validation error. Invalid time specified on property XLastModifiedSystemDate in entity XOrgName, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode();
      logger.finest("controllerValidation_XLastModifiedSystemDate " + infoForLogging);
               	status.addError(err);
            } 
    	}
    private DWLError createDWLError(String entityName, String propertyName,String reasonCode){	
		DWLError err = new DWLError();
		err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XORG_NAME_BOBJ_EXT).longValue());
		err.setReasonCode(new Long(reasonCode).longValue());
		err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
			String infoForLogging="Error: Validation error occured. Property " + propertyName + " is null, in entity " + entityName + ", component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
			logger.finest("createDWLError " + infoForLogging);
		}
		return err;
    }
    






	 /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets a record from the extension table.
     *
     * @throws DWLBaseException
     * @generated
     */
    public void getRecord() throws DWLBaseException {
    logger.finest("ENTER getRecord()");
    
    try {
         			
         }
         catch (Exception e) {
            DWLExceptionUtils.log(e);
            
            if (logger.isFinestEnabled()) {
        		String infoForLogging="Error: Error reading record " + e.getMessage(); 
      logger.finest("getRecord() " + infoForLogging);
      }
            status = new DWLStatus();

            TCRMReadException readEx = new TCRMReadException();
            IDWLErrorMessage  errHandler = DWLClassFactory.getErrorHandler();
            DWLError          error = errHandler.getErrorMessage(DSEAAdditionsExtsComponentID.XORG_NAME_BOBJ_EXT,
                                                                 TCRMErrorCode.READ_RECORD_ERROR,
                                                                 DSEAAdditionsExtsErrorReasonCode.READ_EXTENSION_XORGNAME_FAILED,
                                                                 getControl(), new String[0]);
            error.setThrowable(e);
            status.addError(error);
            status.setStatus(DWLStatus.FATAL);
            readEx.setStatus(status);
            throw readEx;
        }	    		
    logger.finest("RETURN getRecord()");
  }


}

