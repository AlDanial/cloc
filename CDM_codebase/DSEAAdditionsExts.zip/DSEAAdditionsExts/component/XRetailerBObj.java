
/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[3359cad74168f01fe13dc6112651a5f4]
 */

package com.ibm.daimler.dsea.component;

import com.dwl.tcrm.common.TCRMCommon;



import com.dwl.base.DWLControl;

import com.dwl.base.constant.DWLControlKeys;
import com.dwl.base.constant.DWLUtilErrorReasonCode;

import com.dwl.base.error.DWLError;
import com.dwl.base.error.DWLErrorCode;
import com.dwl.base.error.DWLStatus;

import com.dwl.base.exception.DWLBaseException;
import com.dwl.base.exception.DWLUpdateException;

import com.dwl.base.util.DWLClassFactory;
import com.dwl.base.util.DWLExceptionUtils;
import com.dwl.base.util.DWLFunctionUtils;

import com.dwl.management.config.client.Configuration;
import com.dwl.tcrm.common.ITCRMValidation;

import com.dwl.tcrm.utilities.DateFormatter;
import com.dwl.tcrm.utilities.DateValidator;
import com.dwl.tcrm.utilities.TCRMClassFactory;

import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsComponentID;
import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsErrorReasonCode;
import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsPropertyKeys;

import com.ibm.daimler.dsea.entityObject.EObjXRetailer;

import com.ibm.daimler.dsea.interfaces.DSEAAdditionsExts;

import com.ibm.mdm.common.codetype.interfaces.CodeTypeComponentHelper;

import com.ibm.mdm.common.codetype.obj.CodeTypeBObj;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * This class provides the implementation of the business object
 * <code>XRetailerBObj</code>.
 * 
 * @see com.dwl.tcrm.common.TCRMCommon
 * @generated
 */
 

@SuppressWarnings("serial")
public class XRetailerBObj extends TCRMCommon  {

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected EObjXRetailer eObjXRetailer;
	/**
    * <!-- begin-user-doc -->
	  * <!-- end-user-doc -->
    * @generated 
    */
	 private final static com.dwl.base.logging.IDWLLogger logger = com.dwl.base.logging.DWLLoggerManager.getLogger(XRetailerBObj.class);
		
 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected String sourceIdentifierValue;


    protected boolean isValidLastModifiedSystemDate = true;


    protected boolean isValidCreateDate = true;


    protected boolean isValidChangedDate = true;


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */     
    public XRetailerBObj() {
        super();
        init();
        eObjXRetailer = new EObjXRetailer();
        setComponentID(DSEAAdditionsExtsComponentID.XRETAILER_BOBJ);
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Initializes the fields required to populate the metaDataMap. Each key is
     * an element-level field of the business object.
     *
     * @generated
     */
    private void init() {
        metaDataMap.put("RetailerpkId", null);
        metaDataMap.put("RetailerCode", null);
        metaDataMap.put("RetailerName", null);
        metaDataMap.put("BranchName", null);
        metaDataMap.put("SourceIdentifierType", null);
        metaDataMap.put("SourceIdentifierValue", null);
        metaDataMap.put("GSCode", null);
        metaDataMap.put("GCCode", null);
        metaDataMap.put("LastModifiedSystemDate", null);
        metaDataMap.put("NDCode", null);
        metaDataMap.put("MarketName", null);
        metaDataMap.put("DealerActiveFlag", null);
        metaDataMap.put("DealerGroup", null);
        metaDataMap.put("DealerRolloutFlag", null);
        metaDataMap.put("BatchInd", null);
        metaDataMap.put("CreateDate", null);
        metaDataMap.put("ChangedDate", null);
        metaDataMap.put("CRMCompanyCode", null);
        metaDataMap.put("XRetailerHistActionCode", null);
        metaDataMap.put("XRetailerHistCreateDate", null);
        metaDataMap.put("XRetailerHistCreatedBy", null);
        metaDataMap.put("XRetailerHistEndDate", null);
        metaDataMap.put("XRetailerHistoryIdPK", null);
        metaDataMap.put("XRetailerLastUpdateDate", null);
        metaDataMap.put("XRetailerLastUpdateTxId", null);
        metaDataMap.put("XRetailerLastUpdateUser", null);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Refreshes all the attributes this business object supports.
     *
     * @see com.dwl.base.DWLCommon#refreshMap()
     * @generated
     */
    public void refreshMap() {

        if (bRequireMapRefresh) {
            super.refreshMap();
            metaDataMap.put("RetailerpkId", getRetailerpkId());
            metaDataMap.put("RetailerCode", getRetailerCode());
            metaDataMap.put("RetailerName", getRetailerName());
            metaDataMap.put("BranchName", getBranchName());
            metaDataMap.put("SourceIdentifierType", getSourceIdentifierType());
            metaDataMap.put("SourceIdentifierValue", getSourceIdentifierValue());
            metaDataMap.put("GSCode", getGSCode());
            metaDataMap.put("GCCode", getGCCode());
            metaDataMap.put("LastModifiedSystemDate", getLastModifiedSystemDate());
            metaDataMap.put("NDCode", getNDCode());
            metaDataMap.put("MarketName", getMarketName());
            metaDataMap.put("DealerActiveFlag", getDealerActiveFlag());
            metaDataMap.put("DealerGroup", getDealerGroup());
            metaDataMap.put("DealerRolloutFlag", getDealerRolloutFlag());
            metaDataMap.put("BatchInd", getBatchInd());
            metaDataMap.put("CreateDate", getCreateDate());
            metaDataMap.put("ChangedDate", getChangedDate());
            metaDataMap.put("CRMCompanyCode", getCRMCompanyCode());
            metaDataMap.put("XRetailerHistActionCode", getXRetailerHistActionCode());
            metaDataMap.put("XRetailerHistCreateDate", getXRetailerHistCreateDate());
            metaDataMap.put("XRetailerHistCreatedBy", getXRetailerHistCreatedBy());
            metaDataMap.put("XRetailerHistEndDate", getXRetailerHistEndDate());
            metaDataMap.put("XRetailerHistoryIdPK", getXRetailerHistoryIdPK());
            metaDataMap.put("XRetailerLastUpdateDate", getXRetailerLastUpdateDate());
            metaDataMap.put("XRetailerLastUpdateTxId", getXRetailerLastUpdateTxId());
            metaDataMap.put("XRetailerLastUpdateUser", getXRetailerLastUpdateUser());
            bRequireMapRefresh = false;
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the control object on this business object.
     *
     * @see com.dwl.base.DWLCommon#setControl(DWLControl)
     * @generated
     */
    public void setControl(DWLControl newDWLControl) {
        super.setControl(newDWLControl);

        if (eObjXRetailer != null) {
            eObjXRetailer.setControl(newDWLControl);
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the entity object associated with this business object.
     *
     * @generated
     */
    public EObjXRetailer getEObjXRetailer() {
        bRequireMapRefresh = true;
        return eObjXRetailer;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the entity object associated with this business object.
     *
     * @param eObjXRetailer
     *            The eObjXRetailer to set.
     * @generated
     */
    public void setEObjXRetailer(EObjXRetailer eObjXRetailer) {
        bRequireMapRefresh = true;
        this.eObjXRetailer = eObjXRetailer;
        if (this.eObjXRetailer != null && this.eObjXRetailer.getControl() == null) {
            DWLControl control = this.getControl();
            if (control != null) {
                this.eObjXRetailer.setControl(control);
            }
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the retailerpkId attribute.
     * 
     * @generated
     */
    public String getRetailerpkId (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXRetailer.getRetailerpkId());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the retailerpkId attribute.
     * 
     * @param newRetailerpkId
     *     The new value of retailerpkId.
     * @generated
     */
    public void setRetailerpkId( String newRetailerpkId ) throws Exception {
        metaDataMap.put("RetailerpkId", newRetailerpkId);

        if (newRetailerpkId == null || newRetailerpkId.equals("")) {
            newRetailerpkId = null;


        }
        eObjXRetailer.setRetailerpkId( DWLFunctionUtils.getLongFromString(newRetailerpkId) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the retailerCode attribute.
     * 
     * @generated
     */
    public String getRetailerCode (){
   
        return eObjXRetailer.getRetailerCode();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the retailerCode attribute.
     * 
     * @param newRetailerCode
     *     The new value of retailerCode.
     * @generated
     */
    public void setRetailerCode( String newRetailerCode ) throws Exception {
        metaDataMap.put("RetailerCode", newRetailerCode);

        if (newRetailerCode == null || newRetailerCode.equals("")) {
            newRetailerCode = null;


        }
        eObjXRetailer.setRetailerCode( newRetailerCode );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the retailerName attribute.
     * 
     * @generated
     */
    public String getRetailerName (){
   
        return eObjXRetailer.getRetailerName();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the retailerName attribute.
     * 
     * @param newRetailerName
     *     The new value of retailerName.
     * @generated
     */
    public void setRetailerName( String newRetailerName ) throws Exception {
        metaDataMap.put("RetailerName", newRetailerName);

        if (newRetailerName == null || newRetailerName.equals("")) {
            newRetailerName = null;


        }
        eObjXRetailer.setRetailerName( newRetailerName );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the branchName attribute.
     * 
     * @generated
     */
    public String getBranchName (){
   
        return eObjXRetailer.getBranchName();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the branchName attribute.
     * 
     * @param newBranchName
     *     The new value of branchName.
     * @generated
     */
    public void setBranchName( String newBranchName ) throws Exception {
        metaDataMap.put("BranchName", newBranchName);

        if (newBranchName == null || newBranchName.equals("")) {
            newBranchName = null;


        }
        eObjXRetailer.setBranchName( newBranchName );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the sourceIdentifierType attribute.
     * 
     * @generated
     */
    public String getSourceIdentifierType (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXRetailer.getSourceIdentifier());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the sourceIdentifierType attribute.
     * 
     * @param newSourceIdentifierType
     *     The new value of sourceIdentifierType.
     * @generated
     */
    public void setSourceIdentifierType( String newSourceIdentifierType ) throws Exception {
        metaDataMap.put("SourceIdentifierType", newSourceIdentifierType);

        if (newSourceIdentifierType == null || newSourceIdentifierType.equals("")) {
            newSourceIdentifierType = null;


        }
        eObjXRetailer.setSourceIdentifier( DWLFunctionUtils.getLongFromString(newSourceIdentifierType) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the sourceIdentifierValue attribute.
     * 
     * @generated
     */
    public String getSourceIdentifierValue (){
      return sourceIdentifierValue;
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the sourceIdentifierValue attribute.
     * 
     * @param newSourceIdentifierValue
     *     The new value of sourceIdentifierValue.
     * @generated
     */
    public void setSourceIdentifierValue( String newSourceIdentifierValue ) throws Exception {
        metaDataMap.put("SourceIdentifierValue", newSourceIdentifierValue);

        if (newSourceIdentifierValue == null || newSourceIdentifierValue.equals("")) {
            newSourceIdentifierValue = null;


        }
        sourceIdentifierValue = newSourceIdentifierValue;
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the gSCode attribute.
     * 
     * @generated
     */
    public String getGSCode (){
   
        return eObjXRetailer.getGSCode();
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the gSCode attribute.
     * 
     * @param newGSCode
     *     The new value of gSCode.
     * @generated
     */
    public void setGSCode( String newGSCode ) throws Exception {
        metaDataMap.put("GSCode", newGSCode);

        if (newGSCode == null || newGSCode.equals("")) {
            newGSCode = null;


        }
        eObjXRetailer.setGSCode( newGSCode );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the gCCode attribute.
     * 
     * @generated
     */
    public String getGCCode (){
   
        return eObjXRetailer.getGCCode();
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the gCCode attribute.
     * 
     * @param newGCCode
     *     The new value of gCCode.
     * @generated
     */
    public void setGCCode( String newGCCode ) throws Exception {
        metaDataMap.put("GCCode", newGCCode);

        if (newGCCode == null || newGCCode.equals("")) {
            newGCCode = null;


        }
        eObjXRetailer.setGCCode( newGCCode );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the lastModifiedSystemDate attribute.
     * 
     * @generated
     */
    public String getLastModifiedSystemDate (){
   
        return DWLFunctionUtils.getStringFromTimestamp(eObjXRetailer.getLastModifiedSystemDate());
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the lastModifiedSystemDate attribute.
     * 
     * @param newLastModifiedSystemDate
     *     The new value of lastModifiedSystemDate.
     * @generated
     */
    public void setLastModifiedSystemDate( String newLastModifiedSystemDate ) throws Exception {
        metaDataMap.put("LastModifiedSystemDate", newLastModifiedSystemDate);
       	isValidLastModifiedSystemDate = true;

        if (newLastModifiedSystemDate == null || newLastModifiedSystemDate.equals("")) {
            newLastModifiedSystemDate = null;
            eObjXRetailer.setLastModifiedSystemDate(null);


        }
    else {
        	if (DateValidator.validates(newLastModifiedSystemDate)) {
           		eObjXRetailer.setLastModifiedSystemDate(DateFormatter.getStartDateTimestamp(newLastModifiedSystemDate));
            	metaDataMap.put("LastModifiedSystemDate", getLastModifiedSystemDate());
        	} else {
            	if (Configuration.getConfiguration().getConfigItem(
              "/IBM/DWLCommonServices/InternalValidation/enabled").getBooleanValue()) {
                	if (metaDataMap.get("LastModifiedSystemDate") != null) {
                    	metaDataMap.put("LastModifiedSystemDate", "");
                	}
                	isValidLastModifiedSystemDate = false;
                	eObjXRetailer.setLastModifiedSystemDate(null);
            	}
        	}
        }
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the nDCode attribute.
     * 
     * @generated
     */
    public String getNDCode (){
   
        return eObjXRetailer.getNDCode();
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the nDCode attribute.
     * 
     * @param newNDCode
     *     The new value of nDCode.
     * @generated
     */
    public void setNDCode( String newNDCode ) throws Exception {
        metaDataMap.put("NDCode", newNDCode);

        if (newNDCode == null || newNDCode.equals("")) {
            newNDCode = null;


        }
        eObjXRetailer.setNDCode( newNDCode );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the marketName attribute.
     * 
     * @generated
     */
    public String getMarketName (){
   
        return eObjXRetailer.getMarketName();
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the marketName attribute.
     * 
     * @param newMarketName
     *     The new value of marketName.
     * @generated
     */
    public void setMarketName( String newMarketName ) throws Exception {
        metaDataMap.put("MarketName", newMarketName);

        if (newMarketName == null || newMarketName.equals("")) {
            newMarketName = null;


        }
        eObjXRetailer.setMarketName( newMarketName );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the dealerActiveFlag attribute.
     * 
     * @generated
     */
    public String getDealerActiveFlag (){
   
        return eObjXRetailer.getDealerActiveFlag();
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the dealerActiveFlag attribute.
     * 
     * @param newDealerActiveFlag
     *     The new value of dealerActiveFlag.
     * @generated
     */
    public void setDealerActiveFlag( String newDealerActiveFlag ) throws Exception {
        metaDataMap.put("DealerActiveFlag", newDealerActiveFlag);

        if (newDealerActiveFlag == null || newDealerActiveFlag.equals("")) {
            newDealerActiveFlag = null;


        }
        eObjXRetailer.setDealerActiveFlag( newDealerActiveFlag );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the dealerGroup attribute.
     * 
     * @generated
     */
    public String getDealerGroup (){
   
        return eObjXRetailer.getDealerGroup();
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the dealerGroup attribute.
     * 
     * @param newDealerGroup
     *     The new value of dealerGroup.
     * @generated
     */
    public void setDealerGroup( String newDealerGroup ) throws Exception {
        metaDataMap.put("DealerGroup", newDealerGroup);

        if (newDealerGroup == null || newDealerGroup.equals("")) {
            newDealerGroup = null;


        }
        eObjXRetailer.setDealerGroup( newDealerGroup );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the dealerRolloutFlag attribute.
     * 
     * @generated
     */
    public String getDealerRolloutFlag (){
   
        return eObjXRetailer.getDealerRolloutFlag();
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the dealerRolloutFlag attribute.
     * 
     * @param newDealerRolloutFlag
     *     The new value of dealerRolloutFlag.
     * @generated
     */
    public void setDealerRolloutFlag( String newDealerRolloutFlag ) throws Exception {
        metaDataMap.put("DealerRolloutFlag", newDealerRolloutFlag);

        if (newDealerRolloutFlag == null || newDealerRolloutFlag.equals("")) {
            newDealerRolloutFlag = null;


        }
        eObjXRetailer.setDealerRolloutFlag( newDealerRolloutFlag );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the batchInd attribute.
     * 
     * @generated
     */
    public String getBatchInd (){
   
        return eObjXRetailer.getBatchInd();
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the batchInd attribute.
     * 
     * @param newBatchInd
     *     The new value of batchInd.
     * @generated
     */
    public void setBatchInd( String newBatchInd ) throws Exception {
        metaDataMap.put("BatchInd", newBatchInd);

        if (newBatchInd == null || newBatchInd.equals("")) {
            newBatchInd = null;


        }
        eObjXRetailer.setBatchInd( newBatchInd );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the createDate attribute.
     * 
     * @generated
     */
    public String getCreateDate (){
   
        return DWLFunctionUtils.getStringFromTimestamp(eObjXRetailer.getCreateDate());
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the createDate attribute.
     * 
     * @param newCreateDate
     *     The new value of createDate.
     * @generated
     */
    public void setCreateDate( String newCreateDate ) throws Exception {
        metaDataMap.put("CreateDate", newCreateDate);
       	isValidCreateDate = true;

        if (newCreateDate == null || newCreateDate.equals("")) {
            newCreateDate = null;
            eObjXRetailer.setCreateDate(null);


        }
    else {
        	if (DateValidator.validates(newCreateDate)) {
           		eObjXRetailer.setCreateDate(DateFormatter.getStartDateTimestamp(newCreateDate));
            	metaDataMap.put("CreateDate", getCreateDate());
        	} else {
            	if (Configuration.getConfiguration().getConfigItem(
              "/IBM/DWLCommonServices/InternalValidation/enabled").getBooleanValue()) {
                	if (metaDataMap.get("CreateDate") != null) {
                    	metaDataMap.put("CreateDate", "");
                	}
                	isValidCreateDate = false;
                	eObjXRetailer.setCreateDate(null);
            	}
        	}
        }
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the changedDate attribute.
     * 
     * @generated
     */
    public String getChangedDate (){
   
        return DWLFunctionUtils.getStringFromTimestamp(eObjXRetailer.getChangedDate());
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the changedDate attribute.
     * 
     * @param newChangedDate
     *     The new value of changedDate.
     * @generated
     */
    public void setChangedDate( String newChangedDate ) throws Exception {
        metaDataMap.put("ChangedDate", newChangedDate);
       	isValidChangedDate = true;

        if (newChangedDate == null || newChangedDate.equals("")) {
            newChangedDate = null;
            eObjXRetailer.setChangedDate(null);


        }
    else {
        	if (DateValidator.validates(newChangedDate)) {
           		eObjXRetailer.setChangedDate(DateFormatter.getStartDateTimestamp(newChangedDate));
            	metaDataMap.put("ChangedDate", getChangedDate());
        	} else {
            	if (Configuration.getConfiguration().getConfigItem(
              "/IBM/DWLCommonServices/InternalValidation/enabled").getBooleanValue()) {
                	if (metaDataMap.get("ChangedDate") != null) {
                    	metaDataMap.put("ChangedDate", "");
                	}
                	isValidChangedDate = false;
                	eObjXRetailer.setChangedDate(null);
            	}
        	}
        }
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the cRMCompanyCode attribute.
     * 
     * @generated
     */
    public String getCRMCompanyCode (){
   
        return eObjXRetailer.getCRMCompanyCode();
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the cRMCompanyCode attribute.
     * 
     * @param newCRMCompanyCode
     *     The new value of cRMCompanyCode.
     * @generated
     */
    public void setCRMCompanyCode( String newCRMCompanyCode ) throws Exception {
        metaDataMap.put("CRMCompanyCode", newCRMCompanyCode);

        if (newCRMCompanyCode == null || newCRMCompanyCode.equals("")) {
            newCRMCompanyCode = null;


        }
        eObjXRetailer.setCRMCompanyCode( newCRMCompanyCode );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateTxId attribute.
     *
     * @generated
     */
    public String getXRetailerLastUpdateTxId() {
        return DWLFunctionUtils.getStringFromLong(eObjXRetailer.getLastUpdateTxId());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateUser attribute.
     *
     * @generated
     */
    public String getXRetailerLastUpdateUser() {
        return eObjXRetailer.getLastUpdateUser();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateDt attribute.
     *
     * @generated
     */
    public String getXRetailerLastUpdateDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXRetailer.getLastUpdateDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateTxId attribute.
     *
     * @param newLastUpdateTxId
     *     The new value of LastUpdateTxId.
     * @generated
     */
    public void setXRetailerLastUpdateTxId(String newLastUpdateTxId) {
        metaDataMap.put("XRetailerLastUpdateTxId", newLastUpdateTxId);

        if ((newLastUpdateTxId == null) || newLastUpdateTxId.equals("")) {
            newLastUpdateTxId = null;
        }
        eObjXRetailer.setLastUpdateTxId(DWLFunctionUtils.getLongFromString(newLastUpdateTxId));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateUser attribute.
     *
     * @param newLastUpdateUser
     *     The new value of LastUpdateUser.
     * @generated
     */
    public void setXRetailerLastUpdateUser(String newLastUpdateUser) {
        metaDataMap.put("XRetailerLastUpdateUser", newLastUpdateUser);

        if ((newLastUpdateUser == null) || newLastUpdateUser.equals("")) {
            newLastUpdateUser = null;
        }
        eObjXRetailer.setLastUpdateUser(newLastUpdateUser);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateDt attribute.
     *
     * @param newLastUpdateDt
     *     The new value of LastUpdateDt.
     * @throws Exception
     * @generated
     */
    public void setXRetailerLastUpdateDate(String newLastUpdateDt) throws Exception {
        metaDataMap.put("XRetailerLastUpdateDate", newLastUpdateDt);

        if ((newLastUpdateDt == null) || newLastUpdateDt.equals("")) {
            newLastUpdateDt = null;
        }

        eObjXRetailer.setLastUpdateDt(DWLFunctionUtils.getTimestampFromTimestampString(newLastUpdateDt));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XRetailerHistActionCode history attribute.
     *
     * @generated
     */
    public String getXRetailerHistActionCode() {
        return eObjXRetailer.getHistActionCode();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XRetailerHistActionCode history attribute.
     *
     * @param aXRetailerHistActionCode
     *     The new value of XRetailerHistActionCode.
     * @generated
     */
    public void setXRetailerHistActionCode(String aXRetailerHistActionCode) {
        metaDataMap.put("XRetailerHistActionCode", aXRetailerHistActionCode);

        if ((aXRetailerHistActionCode == null) || aXRetailerHistActionCode.equals("")) {
            aXRetailerHistActionCode = null;
        }
        eObjXRetailer.setHistActionCode(aXRetailerHistActionCode);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XRetailerHistCreateDate history attribute.
     *
     * @generated
     */
    public String getXRetailerHistCreateDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXRetailer.getHistCreateDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XRetailerHistCreateDate history attribute.
     *
     * @param aXRetailerHistCreateDate
     *     The new value of XRetailerHistCreateDate.
     * @generated
     */
    public void setXRetailerHistCreateDate(String aXRetailerHistCreateDate) throws Exception{
        metaDataMap.put("XRetailerHistCreateDate", aXRetailerHistCreateDate);

        if ((aXRetailerHistCreateDate == null) || aXRetailerHistCreateDate.equals("")) {
            aXRetailerHistCreateDate = null;
        }

        eObjXRetailer.setHistCreateDt(DWLFunctionUtils.getTimestampFromTimestampString(aXRetailerHistCreateDate));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XRetailerHistCreatedBy history attribute.
     *
     * @generated
     */
    public String getXRetailerHistCreatedBy() {
        return eObjXRetailer.getHistCreatedBy();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XRetailerHistCreatedBy history attribute.
     *
     * @param aXRetailerHistCreatedBy
     *     The new value of XRetailerHistCreatedBy.
     * @generated
     */
    public void setXRetailerHistCreatedBy(String aXRetailerHistCreatedBy) {
        metaDataMap.put("XRetailerHistCreatedBy", aXRetailerHistCreatedBy);

        if ((aXRetailerHistCreatedBy == null) || aXRetailerHistCreatedBy.equals("")) {
            aXRetailerHistCreatedBy = null;
        }

        eObjXRetailer.setHistCreatedBy(aXRetailerHistCreatedBy);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XRetailerHistEndDate history attribute.
     *
     * @generated
     */
    public String getXRetailerHistEndDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXRetailer.getHistEndDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XRetailerHistEndDate history attribute.
     *
     * @param aXRetailerHistEndDate
     *     The new value of XRetailerHistEndDate.
     * @generated
     */
    public void setXRetailerHistEndDate(String aXRetailerHistEndDate) throws Exception{
        metaDataMap.put("XRetailerHistEndDate", aXRetailerHistEndDate);

        if ((aXRetailerHistEndDate == null) || aXRetailerHistEndDate.equals("")) {
            aXRetailerHistEndDate = null;
        }
        eObjXRetailer.setHistEndDt(DWLFunctionUtils.getTimestampFromTimestampString(aXRetailerHistEndDate));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XRetailerHistoryIdPK history attribute.
     *
     * @generated
     */
    public String getXRetailerHistoryIdPK() {
        return DWLFunctionUtils.getStringFromLong(eObjXRetailer.getHistoryIdPK());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XRetailerHistoryIdPK history attribute.
     *
     * @param aXRetailerHistoryIdPK
     *     The new value of XRetailerHistoryIdPK.
     * @generated
     */
    public void setXRetailerHistoryIdPK(String aXRetailerHistoryIdPK) {
        metaDataMap.put("XRetailerHistoryIdPK", aXRetailerHistoryIdPK);

        if ((aXRetailerHistoryIdPK == null) || aXRetailerHistoryIdPK.equals("")) {
            aXRetailerHistoryIdPK = null;
        }
        eObjXRetailer.setHistoryIdPK(DWLFunctionUtils.getLongFromString(aXRetailerHistoryIdPK));
    }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation during an add transaction.
     *
     * @generated
     */
    public DWLStatus validateAdd(int level, DWLStatus status) throws Exception {

        status = super.validateAdd(level, status);
        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0038I Add any controller-level custom validation logic to be
            // executed for this object during an "add" transaction

        }

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            // MDM_TODO0: CDKWB0039I Add any component-level custom validation logic to be
            // executed for this object during an "add" transaction
        }
        status = getValidationStatus(level, status);
        return status;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation during an update transaction.
     *
     * @generated
     */
    public DWLStatus validateUpdate(int level, DWLStatus status) throws Exception {
    logger.finest("ENTER validateUpdate(int level, DWLStatus status)");

        status = super.validateUpdate(level, status);
        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0040I Add any controller-level custom validation logic to be
            // executed for this object during an "update" transaction

            if (eObjXRetailer.getRetailerpkId() == null) {
                DWLError err = new DWLError();
                err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XRETAILER_BOBJ).longValue());
                err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.XRETAILER_RETAILERPKID_NULL).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                	String infoForLogging="Error: Validation error occured for update. No primary key for entity XRetailer, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("validateUpdate(int level, DWLStatus status) " + infoForLogging);
                }
                status.addError(err);
            }
            if (eObjXRetailer.getLastUpdateDt() == null) {
                DWLError err = new DWLError();
                err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XRETAILER_BOBJ).longValue());
                err.setReasonCode(new Long(DWLUtilErrorReasonCode.LAST_UPDATED_DATE_NULL).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
                if (logger.isFinestEnabled()) {
                	String infoForLogging="Error: Validation error occured for update. No last update date for entity XRetailer, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("validateUpdate(int level, DWLStatus status) " + infoForLogging);
                }
                status.addError(err);
            }
        }

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            assignBeforeImageValues(metaDataMap);
            
            // MDM_TODO0: CDKWB0041I Add any component-level custom validation logic to be
            // executed for this object during an "update" transaction
        }
        status = getValidationStatus(level, status);
    if (logger.isFinestEnabled()) {
        	String returnValue = status.toString();
      logger.finest("RETURN validateUpdate(int level, DWLStatus status) " + returnValue);
    }
        return status;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Populate the before image of this business object.
     *
     * @see com.dwl.base.DWLCommon#populateBeforeImage()
     * @generated
     */
    public void populateBeforeImage() throws DWLBaseException {
    logger.finest("ENTER populateBeforeImage()");

        DSEAAdditionsExts comp = null;
        try {
        
      comp = (DSEAAdditionsExts)TCRMClassFactory.getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
        	
        } catch (Exception e) {
      if (logger.isFinestEnabled()) {
        String infoForLogging="Error: Fatal error while updating record " + e.getMessage();
      logger.finest("populateBeforeImage() " + infoForLogging);
      }
            DWLExceptionUtils.throwDWLBaseException(e, 
            									new DWLUpdateException(e.getMessage()), 
            									this.getStatus(), DWLStatus.FATAL,
                                  DSEAAdditionsExtsComponentID.XRETAILER_BOBJ, 
                                  "DIERR",
                                  DSEAAdditionsExtsErrorReasonCode.XRETAILER_BEFORE_IMAGE_NOT_POPULATED, 
                                  this.getControl());
        }
        
        comp.loadBeforeImage(this);
    logger.finest("RETURN populateBeforeImage()");
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation common to both add and update transactions.
     *
     * @generated
     */
     
    private DWLStatus getValidationStatus(int level, DWLStatus status) throws Exception {
    logger.finest("ENTER getValidationStatus(int level, DWLStatus status)");

        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0034I Add any common controller-level custom validation
            // logic to be executed for this object during either "add" or
            // "update" transactions
    		controllerValidation_RetailerCode(status);
    		controllerValidation_SourceIdentifier(status);
    		controllerValidation_LastModifiedSystemDate(status);
    		controllerValidation_CreateDate(status);
    		controllerValidation_ChangedDate(status);
    	}

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            // MDM_TODO0: CDKWB0035I Add any common component-level custom validation logic
            // to be executed for this object during either "add" or "update"
            // transactions
    		componentValidation_RetailerCode(status);
    		componentValidation_SourceIdentifier(status);
    		componentValidation_LastModifiedSystemDate(status);
    		componentValidation_CreateDate(status);
    		componentValidation_ChangedDate(status);
        }
        
        if (logger.isFinestEnabled()) {
            String returnValue = status.toString();
      logger.finest("RETURN getValidationStatus(int level, DWLStatus status) " + returnValue);
        }
    
        return status;
    }

    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "RetailerCode"
     *
     * @generated
     */
	private void componentValidation_RetailerCode(DWLStatus status) {
  
            boolean isRetailerCodeNull = false;
            if (eObjXRetailer.getRetailerCode() == null || 
            	eObjXRetailer.getRetailerCode().trim().equals("")) {
                isRetailerCodeNull = true;
            }
            if (isRetailerCodeNull) {
                DWLError err = createDWLError("XRetailer", "RetailerCode", DSEAAdditionsExtsErrorReasonCode.XRETAILER_RETAILERCODE_NULL);
                status.addError(err); 
            }
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "SourceIdentifier"
     *
     * @generated
     */
	private void componentValidation_SourceIdentifier(DWLStatus status) {
  
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "LastModifiedSystemDate"
     *
     * @generated
     */
  private void componentValidation_LastModifiedSystemDate(DWLStatus status) {
  
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "CreateDate"
     *
     * @generated
     */
  private void componentValidation_CreateDate(DWLStatus status) {
  
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "ChangedDate"
     *
     * @generated
     */
  private void componentValidation_ChangedDate(DWLStatus status) {
  
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "RetailerCode"
     *
     * @generated
     */
	private void controllerValidation_RetailerCode(DWLStatus status) throws Exception {
  
            boolean isRetailerCodeNull = false;
            if (eObjXRetailer.getRetailerCode() == null || 
            	eObjXRetailer.getRetailerCode().trim().equals("")) {
                isRetailerCodeNull = true;
            }
            if (isRetailerCodeNull) {
                DWLError err = createDWLError("XRetailer", "RetailerCode", DSEAAdditionsExtsErrorReasonCode.XRETAILER_RETAILERCODE_NULL);
                status.addError(err); 
            }
    	}
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "SourceIdentifier"
     *
     * @generated
     */
	private void controllerValidation_SourceIdentifier(DWLStatus status) throws Exception {
  
      //persistent code type
            boolean isSourceIdentifierNull = false;
            if ((eObjXRetailer.getSourceIdentifier() == null) &&
               ((getSourceIdentifierValue() == null) || 
                 getSourceIdentifierValue().trim().equals(""))) {
                isSourceIdentifierNull = true;
            }
            if (!isSourceIdentifierNull) {
                if (checkForInvalidXretailerSourceidentifier()) {
                    DWLError err = new DWLError();
                    err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XRETAILER_BOBJ).longValue());
                    err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XRETAILER_SOURCEIDENTIFIER).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                    String infoForLogging="Error: Custom validation error occured for entity XRetailer, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("controllerValidation_SourceIdentifier " + infoForLogging);
        }
                status.addError(err);
            }

             }
    			
    	}
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "LastModifiedSystemDate"
     *
     * @generated
     */
  private void controllerValidation_LastModifiedSystemDate(DWLStatus status) throws Exception {
  
            boolean isLastModifiedSystemDateNull = (eObjXRetailer.getLastModifiedSystemDate() == null);
            if (!isValidLastModifiedSystemDate) {
              	DWLError err = new DWLError();
               	err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XRETAILER_BOBJ).longValue());
               	err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XRETAILER_LASTMODIFIEDSYSTEMDATE).longValue());
               	err.setErrorType(DWLErrorCode.DATA_INVALID_ERROR);
                String infoForLogging="Error: Validation error. Invalid time specified on property LastModifiedSystemDate in entity XRetailer, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode();
      logger.finest("controllerValidation_LastModifiedSystemDate " + infoForLogging);
               	status.addError(err);
            } 
    	}


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "CreateDate"
     *
     * @generated
     */
  private void controllerValidation_CreateDate(DWLStatus status) throws Exception {
  
            boolean isCreateDateNull = (eObjXRetailer.getCreateDate() == null);
            if (!isValidCreateDate) {
              	DWLError err = new DWLError();
               	err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XRETAILER_BOBJ).longValue());
               	err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XRETAILER_CREATEDATE).longValue());
               	err.setErrorType(DWLErrorCode.DATA_INVALID_ERROR);
                String infoForLogging="Error: Validation error. Invalid time specified on property CreateDate in entity XRetailer, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode();
      logger.finest("controllerValidation_CreateDate " + infoForLogging);
               	status.addError(err);
            } 
    	}


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "ChangedDate"
     *
     * @generated
     */
  private void controllerValidation_ChangedDate(DWLStatus status) throws Exception {
  
            boolean isChangedDateNull = (eObjXRetailer.getChangedDate() == null);
            if (!isValidChangedDate) {
              	DWLError err = new DWLError();
               	err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XRETAILER_BOBJ).longValue());
               	err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XRETAILER_CHANGEDDATE).longValue());
               	err.setErrorType(DWLErrorCode.DATA_INVALID_ERROR);
                String infoForLogging="Error: Validation error. Invalid time specified on property ChangedDate in entity XRetailer, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode();
      logger.finest("controllerValidation_ChangedDate " + infoForLogging);
               	status.addError(err);
            } 
    	}


    private DWLError createDWLError(String entityName, String propertyName,String reasonCode){	
		DWLError err = new DWLError();
		err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XRETAILER_BOBJ).longValue());
		err.setReasonCode(new Long(reasonCode).longValue());
		err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
			String infoForLogging="Error: Validation error occured. Property " + propertyName + " is null, in entity " + entityName + ", component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
			logger.finest("createDWLError " + infoForLogging);
		}
		return err;
    }
    
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Check the value of the field SourceIdentifier and return true if the
     * error reason INVALID_XRETAILER_SOURCEIDENTIFIER should be returned.
     *
     * @generated
  **/
	private boolean checkForInvalidXretailerSourceidentifier() throws Exception {
    logger.finest("ENTER checkForInvalidXretailerSourceidentifier()");
        boolean notValid = false;
      	String langId = (String) this.getControl().get(DWLControlKeys.LANG_ID);
      	CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
    Long codeType = DWLFunctionUtils.getLongFromString( getSourceIdentifierType() );
    String codeValue = getSourceIdentifierValue();
    if( codeValue != null && codeValue.trim().equals("")){
      codeValue = null;
    }
     
        if ( codeType != null && codeValue == null ){

             if( codeTypeCompHelper.isCodeValid("cdsourceidenttp", langId, getSourceIdentifierType(),
                 CodeTypeComponentHelper.ACTIVE, getControl())) {
                 CodeTypeBObj ctBObj = codeTypeCompHelper
                 					.getCodeTypeByCode("cdsourceidenttp", langId, getSourceIdentifierType(),
                         								getControl());
               	if (ctBObj != null) {
                   	setSourceIdentifierValue( ctBObj.getvalue() );
               	}
             }
             else{
             	if (logger.isFinestEnabled()) {
              	 	String infoForLogging="NotValid 1";
      logger.finest("checkForInvalidXretailerSourceidentifier() " + infoForLogging);
        }
                 notValid = true;
           }
        }
        else if (codeType == null && codeValue != null ){
          
             CodeTypeBObj ctBObj = codeTypeCompHelper
                      .getCodeTypeByValue("cdsourceidenttp", langId, codeValue,
                                 getControl());

             if (ctBObj != null) {
                 setSourceIdentifierType(ctBObj.gettp_cd());
             } 
             else {
             	if (logger.isFinestEnabled()) {
              	  	String infoForLogging="NotValid 2";
      logger.finest("checkForInvalidXretailerSourceidentifier() " + infoForLogging);
        }
                  notValid = true;
             }
        }
        else if ( codeType != null && codeValue != null
             && !codeTypeCompHelper.isCodeValuePairValid("cdsourceidenttp", langId, getSourceIdentifierType(), 
                     new String[] { codeValue }, CodeTypeComponentHelper.ACTIVE, getControl())) {	
       if (logger.isFinestEnabled()) {
       		String infoForLogging="NotValid 3";
      logger.finest("checkForInvalidXretailerSourceidentifier() " + infoForLogging);
       }
             notValid = true;
        }
        if (logger.isFinestEnabled()) {
      String returnValue ="" +notValid;
      logger.finest("RETURN checkForInvalidXretailerSourceidentifier() " + returnValue);
    }
    return notValid;
     } 
				 



}

