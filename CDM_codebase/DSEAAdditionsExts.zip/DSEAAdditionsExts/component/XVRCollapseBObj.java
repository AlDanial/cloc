
/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[b80c243e16b057dfc1d6a33b7833e5a3]
 */

package com.ibm.daimler.dsea.component;

import com.dwl.tcrm.common.TCRMCommon;



import com.dwl.base.DWLControl;

import com.dwl.base.constant.DWLUtilErrorReasonCode;

import com.dwl.base.error.DWLError;
import com.dwl.base.error.DWLErrorCode;
import com.dwl.base.error.DWLStatus;

import com.dwl.base.exception.DWLBaseException;
import com.dwl.base.exception.DWLUpdateException;

import com.dwl.base.util.DWLExceptionUtils;
import com.dwl.base.util.DWLFunctionUtils;

import com.dwl.management.config.client.Configuration;
import com.dwl.tcrm.common.ITCRMValidation;

import com.dwl.tcrm.utilities.DateFormatter;
import com.dwl.tcrm.utilities.DateValidator;
import com.dwl.tcrm.utilities.TCRMClassFactory;

import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsComponentID;
import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsErrorReasonCode;
import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsPropertyKeys;

import com.ibm.daimler.dsea.entityObject.EObjXVRCollapse;

import com.ibm.daimler.dsea.interfaces.DSEAAdditionsExts;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * This class provides the implementation of the business object
 * <code>XVRCollapseBObj</code>.
 * 
 * @see com.dwl.tcrm.common.TCRMCommon
 * @generated
 */
 

@SuppressWarnings("serial")
public class XVRCollapseBObj extends TCRMCommon  {

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected EObjXVRCollapse eObjXVRCollapse;
	/**
    * <!-- begin-user-doc -->
	  * <!-- end-user-doc -->
    * @generated 
    */
	 private final static com.dwl.base.logging.IDWLLogger logger = com.dwl.base.logging.DWLLoggerManager.getLogger(XVRCollapseBObj.class);
		
 


    protected boolean isValidCreateDate = true;




    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */     
    public XVRCollapseBObj() {
        super();
        init();
        eObjXVRCollapse = new EObjXVRCollapse();
        setComponentID(DSEAAdditionsExtsComponentID.XVRCOLLAPSE_BOBJ);
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Initializes the fields required to populate the metaDataMap. Each key is
     * an element-level field of the business object.
     *
     * @generated
     */
    private void init() {
        metaDataMap.put("XVRCollapsepkId", null);
        metaDataMap.put("SuspectIds", null);
        metaDataMap.put("GoldenContId", null);
        metaDataMap.put("Action", null);
        metaDataMap.put("Flag", null);
        metaDataMap.put("CreateDate", null);
        metaDataMap.put("MarketName", null);
        metaDataMap.put("XVRCollapseHistActionCode", null);
        metaDataMap.put("XVRCollapseHistCreateDate", null);
        metaDataMap.put("XVRCollapseHistCreatedBy", null);
        metaDataMap.put("XVRCollapseHistEndDate", null);
        metaDataMap.put("XVRCollapseHistoryIdPK", null);
        metaDataMap.put("XVRCollapseLastUpdateDate", null);
        metaDataMap.put("XVRCollapseLastUpdateTxId", null);
        metaDataMap.put("XVRCollapseLastUpdateUser", null);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Refreshes all the attributes this business object supports.
     *
     * @see com.dwl.base.DWLCommon#refreshMap()
     * @generated
     */
    public void refreshMap() {

        if (bRequireMapRefresh) {
            super.refreshMap();
            metaDataMap.put("XVRCollapsepkId", getXVRCollapsepkId());
            metaDataMap.put("SuspectIds", getSuspectIds());
            metaDataMap.put("GoldenContId", getGoldenContId());
            metaDataMap.put("Action", getAction());
            metaDataMap.put("Flag", getFlag());
            metaDataMap.put("CreateDate", getCreateDate());
            metaDataMap.put("MarketName", getMarketName());
            metaDataMap.put("XVRCollapseHistActionCode", getXVRCollapseHistActionCode());
            metaDataMap.put("XVRCollapseHistCreateDate", getXVRCollapseHistCreateDate());
            metaDataMap.put("XVRCollapseHistCreatedBy", getXVRCollapseHistCreatedBy());
            metaDataMap.put("XVRCollapseHistEndDate", getXVRCollapseHistEndDate());
            metaDataMap.put("XVRCollapseHistoryIdPK", getXVRCollapseHistoryIdPK());
            metaDataMap.put("XVRCollapseLastUpdateDate", getXVRCollapseLastUpdateDate());
            metaDataMap.put("XVRCollapseLastUpdateTxId", getXVRCollapseLastUpdateTxId());
            metaDataMap.put("XVRCollapseLastUpdateUser", getXVRCollapseLastUpdateUser());
            bRequireMapRefresh = false;
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the control object on this business object.
     *
     * @see com.dwl.base.DWLCommon#setControl(DWLControl)
     * @generated
     */
    public void setControl(DWLControl newDWLControl) {
        super.setControl(newDWLControl);

        if (eObjXVRCollapse != null) {
            eObjXVRCollapse.setControl(newDWLControl);
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the entity object associated with this business object.
     *
     * @generated
     */
    public EObjXVRCollapse getEObjXVRCollapse() {
        bRequireMapRefresh = true;
        return eObjXVRCollapse;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the entity object associated with this business object.
     *
     * @param eObjXVRCollapse
     *            The eObjXVRCollapse to set.
     * @generated
     */
    public void setEObjXVRCollapse(EObjXVRCollapse eObjXVRCollapse) {
        bRequireMapRefresh = true;
        this.eObjXVRCollapse = eObjXVRCollapse;
        if (this.eObjXVRCollapse != null && this.eObjXVRCollapse.getControl() == null) {
            DWLControl control = this.getControl();
            if (control != null) {
                this.eObjXVRCollapse.setControl(control);
            }
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xVRCollapsepkId attribute.
     * 
     * @generated
     */
    public String getXVRCollapsepkId (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXVRCollapse.getXVRCollapsepkId());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xVRCollapsepkId attribute.
     * 
     * @param newXVRCollapsepkId
     *     The new value of xVRCollapsepkId.
     * @generated
     */
    public void setXVRCollapsepkId( String newXVRCollapsepkId ) throws Exception {
        metaDataMap.put("XVRCollapsepkId", newXVRCollapsepkId);

        if (newXVRCollapsepkId == null || newXVRCollapsepkId.equals("")) {
            newXVRCollapsepkId = null;


        }
        eObjXVRCollapse.setXVRCollapsepkId( DWLFunctionUtils.getLongFromString(newXVRCollapsepkId) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the suspectIds attribute.
     * 
     * @generated
     */
    public String getSuspectIds (){
   
        return eObjXVRCollapse.getSuspectIds();
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the suspectIds attribute.
     * 
     * @param newSuspectIds
     *     The new value of suspectIds.
     * @generated
     */
    public void setSuspectIds( String newSuspectIds ) throws Exception {
        metaDataMap.put("SuspectIds", newSuspectIds);

        if (newSuspectIds == null || newSuspectIds.equals("")) {
            newSuspectIds = null;


        }
        eObjXVRCollapse.setSuspectIds( newSuspectIds );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the goldenContId attribute.
     * 
     * @generated
     */
    public String getGoldenContId (){
   
        return eObjXVRCollapse.getGoldenContId();
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the goldenContId attribute.
     * 
     * @param newGoldenContId
     *     The new value of goldenContId.
     * @generated
     */
    public void setGoldenContId( String newGoldenContId ) throws Exception {
        metaDataMap.put("GoldenContId", newGoldenContId);

        if (newGoldenContId == null || newGoldenContId.equals("")) {
            newGoldenContId = null;


        }
        eObjXVRCollapse.setGoldenContId( newGoldenContId );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the action attribute.
     * 
     * @generated
     */
    public String getAction (){
   
        return eObjXVRCollapse.getAction();
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the action attribute.
     * 
     * @param newAction
     *     The new value of action.
     * @generated
     */
    public void setAction( String newAction ) throws Exception {
        metaDataMap.put("Action", newAction);

        if (newAction == null || newAction.equals("")) {
            newAction = null;


        }
        eObjXVRCollapse.setAction( newAction );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the flag attribute.
     * 
     * @generated
     */
    public String getFlag (){
   
        return eObjXVRCollapse.getFlag();
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the flag attribute.
     * 
     * @param newFlag
     *     The new value of flag.
     * @generated
     */
    public void setFlag( String newFlag ) throws Exception {
        metaDataMap.put("Flag", newFlag);

        if (newFlag == null || newFlag.equals("")) {
            newFlag = null;


        }
        eObjXVRCollapse.setFlag( newFlag );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the createDate attribute.
     * 
     * @generated
     */
    public String getCreateDate (){
   
        return DWLFunctionUtils.getStringFromTimestamp(eObjXVRCollapse.getCreateDate());
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the createDate attribute.
     * 
     * @param newCreateDate
     *     The new value of createDate.
     * @generated
     */
    public void setCreateDate( String newCreateDate ) throws Exception {
        metaDataMap.put("CreateDate", newCreateDate);
       	isValidCreateDate = true;

        if (newCreateDate == null || newCreateDate.equals("")) {
            newCreateDate = null;
            eObjXVRCollapse.setCreateDate(null);


        }
    else {
        	if (DateValidator.validates(newCreateDate)) {
           		eObjXVRCollapse.setCreateDate(DateFormatter.getStartDateTimestamp(newCreateDate));
            	metaDataMap.put("CreateDate", getCreateDate());
        	} else {
            	if (Configuration.getConfiguration().getConfigItem(
              "/IBM/DWLCommonServices/InternalValidation/enabled").getBooleanValue()) {
                	if (metaDataMap.get("CreateDate") != null) {
                    	metaDataMap.put("CreateDate", "");
                	}
                	isValidCreateDate = false;
                	eObjXVRCollapse.setCreateDate(null);
            	}
        	}
        }
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the marketName attribute.
     * 
     * @generated
     */
    public String getMarketName (){
   
        return eObjXVRCollapse.getMarketName();
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the marketName attribute.
     * 
     * @param newMarketName
     *     The new value of marketName.
     * @generated
     */
    public void setMarketName( String newMarketName ) throws Exception {
        metaDataMap.put("MarketName", newMarketName);

        if (newMarketName == null || newMarketName.equals("")) {
            newMarketName = null;


        }
        eObjXVRCollapse.setMarketName( newMarketName );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateTxId attribute.
     *
     * @generated
     */
    public String getXVRCollapseLastUpdateTxId() {
        return DWLFunctionUtils.getStringFromLong(eObjXVRCollapse.getLastUpdateTxId());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateUser attribute.
     *
     * @generated
     */
    public String getXVRCollapseLastUpdateUser() {
        return eObjXVRCollapse.getLastUpdateUser();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateDt attribute.
     *
     * @generated
     */
    public String getXVRCollapseLastUpdateDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXVRCollapse.getLastUpdateDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateTxId attribute.
     *
     * @param newLastUpdateTxId
     *     The new value of LastUpdateTxId.
     * @generated
     */
    public void setXVRCollapseLastUpdateTxId(String newLastUpdateTxId) {
        metaDataMap.put("XVRCollapseLastUpdateTxId", newLastUpdateTxId);

        if ((newLastUpdateTxId == null) || newLastUpdateTxId.equals("")) {
            newLastUpdateTxId = null;
        }
        eObjXVRCollapse.setLastUpdateTxId(DWLFunctionUtils.getLongFromString(newLastUpdateTxId));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateUser attribute.
     *
     * @param newLastUpdateUser
     *     The new value of LastUpdateUser.
     * @generated
     */
    public void setXVRCollapseLastUpdateUser(String newLastUpdateUser) {
        metaDataMap.put("XVRCollapseLastUpdateUser", newLastUpdateUser);

        if ((newLastUpdateUser == null) || newLastUpdateUser.equals("")) {
            newLastUpdateUser = null;
        }
        eObjXVRCollapse.setLastUpdateUser(newLastUpdateUser);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateDt attribute.
     *
     * @param newLastUpdateDt
     *     The new value of LastUpdateDt.
     * @throws Exception
     * @generated
     */
    public void setXVRCollapseLastUpdateDate(String newLastUpdateDt) throws Exception {
        metaDataMap.put("XVRCollapseLastUpdateDate", newLastUpdateDt);

        if ((newLastUpdateDt == null) || newLastUpdateDt.equals("")) {
            newLastUpdateDt = null;
        }

        eObjXVRCollapse.setLastUpdateDt(DWLFunctionUtils.getTimestampFromTimestampString(newLastUpdateDt));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XVRCollapseHistActionCode history attribute.
     *
     * @generated
     */
    public String getXVRCollapseHistActionCode() {
        return eObjXVRCollapse.getHistActionCode();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XVRCollapseHistActionCode history attribute.
     *
     * @param aXVRCollapseHistActionCode
     *     The new value of XVRCollapseHistActionCode.
     * @generated
     */
    public void setXVRCollapseHistActionCode(String aXVRCollapseHistActionCode) {
        metaDataMap.put("XVRCollapseHistActionCode", aXVRCollapseHistActionCode);

        if ((aXVRCollapseHistActionCode == null) || aXVRCollapseHistActionCode.equals("")) {
            aXVRCollapseHistActionCode = null;
        }
        eObjXVRCollapse.setHistActionCode(aXVRCollapseHistActionCode);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XVRCollapseHistCreateDate history attribute.
     *
     * @generated
     */
    public String getXVRCollapseHistCreateDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXVRCollapse.getHistCreateDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XVRCollapseHistCreateDate history attribute.
     *
     * @param aXVRCollapseHistCreateDate
     *     The new value of XVRCollapseHistCreateDate.
     * @generated
     */
    public void setXVRCollapseHistCreateDate(String aXVRCollapseHistCreateDate) throws Exception{
        metaDataMap.put("XVRCollapseHistCreateDate", aXVRCollapseHistCreateDate);

        if ((aXVRCollapseHistCreateDate == null) || aXVRCollapseHistCreateDate.equals("")) {
            aXVRCollapseHistCreateDate = null;
        }

        eObjXVRCollapse.setHistCreateDt(DWLFunctionUtils.getTimestampFromTimestampString(aXVRCollapseHistCreateDate));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XVRCollapseHistCreatedBy history attribute.
     *
     * @generated
     */
    public String getXVRCollapseHistCreatedBy() {
        return eObjXVRCollapse.getHistCreatedBy();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XVRCollapseHistCreatedBy history attribute.
     *
     * @param aXVRCollapseHistCreatedBy
     *     The new value of XVRCollapseHistCreatedBy.
     * @generated
     */
    public void setXVRCollapseHistCreatedBy(String aXVRCollapseHistCreatedBy) {
        metaDataMap.put("XVRCollapseHistCreatedBy", aXVRCollapseHistCreatedBy);

        if ((aXVRCollapseHistCreatedBy == null) || aXVRCollapseHistCreatedBy.equals("")) {
            aXVRCollapseHistCreatedBy = null;
        }

        eObjXVRCollapse.setHistCreatedBy(aXVRCollapseHistCreatedBy);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XVRCollapseHistEndDate history attribute.
     *
     * @generated
     */
    public String getXVRCollapseHistEndDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXVRCollapse.getHistEndDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XVRCollapseHistEndDate history attribute.
     *
     * @param aXVRCollapseHistEndDate
     *     The new value of XVRCollapseHistEndDate.
     * @generated
     */
    public void setXVRCollapseHistEndDate(String aXVRCollapseHistEndDate) throws Exception{
        metaDataMap.put("XVRCollapseHistEndDate", aXVRCollapseHistEndDate);

        if ((aXVRCollapseHistEndDate == null) || aXVRCollapseHistEndDate.equals("")) {
            aXVRCollapseHistEndDate = null;
        }
        eObjXVRCollapse.setHistEndDt(DWLFunctionUtils.getTimestampFromTimestampString(aXVRCollapseHistEndDate));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XVRCollapseHistoryIdPK history attribute.
     *
     * @generated
     */
    public String getXVRCollapseHistoryIdPK() {
        return DWLFunctionUtils.getStringFromLong(eObjXVRCollapse.getHistoryIdPK());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XVRCollapseHistoryIdPK history attribute.
     *
     * @param aXVRCollapseHistoryIdPK
     *     The new value of XVRCollapseHistoryIdPK.
     * @generated
     */
    public void setXVRCollapseHistoryIdPK(String aXVRCollapseHistoryIdPK) {
        metaDataMap.put("XVRCollapseHistoryIdPK", aXVRCollapseHistoryIdPK);

        if ((aXVRCollapseHistoryIdPK == null) || aXVRCollapseHistoryIdPK.equals("")) {
            aXVRCollapseHistoryIdPK = null;
        }
        eObjXVRCollapse.setHistoryIdPK(DWLFunctionUtils.getLongFromString(aXVRCollapseHistoryIdPK));
    }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation during an add transaction.
     *
     * @generated
     */
    public DWLStatus validateAdd(int level, DWLStatus status) throws Exception {

        status = super.validateAdd(level, status);
        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0038I Add any controller-level custom validation logic to be
            // executed for this object during an "add" transaction

        }

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            // MDM_TODO0: CDKWB0039I Add any component-level custom validation logic to be
            // executed for this object during an "add" transaction
        }
        status = getValidationStatus(level, status);
        return status;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation during an update transaction.
     *
     * @generated
     */
    public DWLStatus validateUpdate(int level, DWLStatus status) throws Exception {
    logger.finest("ENTER validateUpdate(int level, DWLStatus status)");

        status = super.validateUpdate(level, status);
        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0040I Add any controller-level custom validation logic to be
            // executed for this object during an "update" transaction

            if (eObjXVRCollapse.getXVRCollapsepkId() == null) {
                DWLError err = new DWLError();
                err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XVRCOLLAPSE_BOBJ).longValue());
                err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.XVRCOLLAPSE_XVRCOLLAPSEPKID_NULL).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                	String infoForLogging="Error: Validation error occured for update. No primary key for entity XVRCollapse, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("validateUpdate(int level, DWLStatus status) " + infoForLogging);
                }
                status.addError(err);
            }
            if (eObjXVRCollapse.getLastUpdateDt() == null) {
                DWLError err = new DWLError();
                err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XVRCOLLAPSE_BOBJ).longValue());
                err.setReasonCode(new Long(DWLUtilErrorReasonCode.LAST_UPDATED_DATE_NULL).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
                if (logger.isFinestEnabled()) {
                	String infoForLogging="Error: Validation error occured for update. No last update date for entity XVRCollapse, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("validateUpdate(int level, DWLStatus status) " + infoForLogging);
                }
                status.addError(err);
            }
        }

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            assignBeforeImageValues(metaDataMap);
            
            // MDM_TODO0: CDKWB0041I Add any component-level custom validation logic to be
            // executed for this object during an "update" transaction
        }
        status = getValidationStatus(level, status);
    if (logger.isFinestEnabled()) {
        	String returnValue = status.toString();
      logger.finest("RETURN validateUpdate(int level, DWLStatus status) " + returnValue);
    }
        return status;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Populate the before image of this business object.
     *
     * @see com.dwl.base.DWLCommon#populateBeforeImage()
     * @generated
     */
    public void populateBeforeImage() throws DWLBaseException {
    logger.finest("ENTER populateBeforeImage()");

        DSEAAdditionsExts comp = null;
        try {
        
      comp = (DSEAAdditionsExts)TCRMClassFactory.getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
        	
        } catch (Exception e) {
      if (logger.isFinestEnabled()) {
        String infoForLogging="Error: Fatal error while updating record " + e.getMessage();
      logger.finest("populateBeforeImage() " + infoForLogging);
      }
            DWLExceptionUtils.throwDWLBaseException(e, 
            									new DWLUpdateException(e.getMessage()), 
            									this.getStatus(), DWLStatus.FATAL,
                                  DSEAAdditionsExtsComponentID.XVRCOLLAPSE_BOBJ, 
                                  "DIERR",
                                  DSEAAdditionsExtsErrorReasonCode.XVRCOLLAPSE_BEFORE_IMAGE_NOT_POPULATED, 
                                  this.getControl());
        }
        
        comp.loadBeforeImage(this);
    logger.finest("RETURN populateBeforeImage()");
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation common to both add and update transactions.
     *
     * @generated
     */
     
    private DWLStatus getValidationStatus(int level, DWLStatus status) throws Exception {
    logger.finest("ENTER getValidationStatus(int level, DWLStatus status)");

        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0034I Add any common controller-level custom validation
            // logic to be executed for this object during either "add" or
            // "update" transactions
    		controllerValidation_SuspectIds(status);
    		controllerValidation_CreateDate(status);
    		controllerValidation_MarketName(status);
    	}

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            // MDM_TODO0: CDKWB0035I Add any common component-level custom validation logic
            // to be executed for this object during either "add" or "update"
            // transactions
    		componentValidation_SuspectIds(status);
    		componentValidation_CreateDate(status);
    		componentValidation_MarketName(status);
        }
        
        if (logger.isFinestEnabled()) {
            String returnValue = status.toString();
      logger.finest("RETURN getValidationStatus(int level, DWLStatus status) " + returnValue);
        }
    
        return status;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "SuspectIds"
     *
     * @generated
     */
  private void componentValidation_SuspectIds(DWLStatus status) {
  
            boolean isSuspectIdsNull = false;
            if (eObjXVRCollapse.getSuspectIds() == null || 
            	eObjXVRCollapse.getSuspectIds().trim().equals("")) {
                isSuspectIdsNull = true;
            }
            if (isSuspectIdsNull) {
                DWLError err = createDWLError("XVRCollapse", "SuspectIds", DSEAAdditionsExtsErrorReasonCode.XVRCOLLAPSE_SUSPECTIDS_NULL);
                status.addError(err); 
            }
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "CreateDate"
     *
     * @generated
     */
  private void componentValidation_CreateDate(DWLStatus status) {
  
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "MarketName"
     *
     * @generated
     */
  private void componentValidation_MarketName(DWLStatus status) {
  
            boolean isMarketNameNull = false;
            if (eObjXVRCollapse.getMarketName() == null || 
            	eObjXVRCollapse.getMarketName().trim().equals("")) {
                isMarketNameNull = true;
            }
            if (isMarketNameNull) {
                DWLError err = createDWLError("XVRCollapse", "MarketName", DSEAAdditionsExtsErrorReasonCode.XVRCOLLAPSE_MARKETNAME_NULL);
                status.addError(err); 
            }
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "SuspectIds"
     *
     * @generated
     */
  private void controllerValidation_SuspectIds(DWLStatus status) throws Exception {
  
            boolean isSuspectIdsNull = false;
            if (eObjXVRCollapse.getSuspectIds() == null || 
            	eObjXVRCollapse.getSuspectIds().trim().equals("")) {
                isSuspectIdsNull = true;
            }
            if (isSuspectIdsNull) {
                DWLError err = createDWLError("XVRCollapse", "SuspectIds", DSEAAdditionsExtsErrorReasonCode.XVRCOLLAPSE_SUSPECTIDS_NULL);
                status.addError(err); 
            }
    	}


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "CreateDate"
     *
     * @generated
     */
  private void controllerValidation_CreateDate(DWLStatus status) throws Exception {
  
            boolean isCreateDateNull = (eObjXVRCollapse.getCreateDate() == null);
            if (!isValidCreateDate) {
              	DWLError err = new DWLError();
               	err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XVRCOLLAPSE_BOBJ).longValue());
               	err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XVRCOLLAPSE_CREATEDATE).longValue());
               	err.setErrorType(DWLErrorCode.DATA_INVALID_ERROR);
                String infoForLogging="Error: Validation error. Invalid time specified on property CreateDate in entity XVRCollapse, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode();
      logger.finest("controllerValidation_CreateDate " + infoForLogging);
               	status.addError(err);
            } 
    	}


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "MarketName"
     *
     * @generated
     */
  private void controllerValidation_MarketName(DWLStatus status) throws Exception {
  
            boolean isMarketNameNull = false;
            if (eObjXVRCollapse.getMarketName() == null || 
            	eObjXVRCollapse.getMarketName().trim().equals("")) {
                isMarketNameNull = true;
            }
            if (isMarketNameNull) {
                DWLError err = createDWLError("XVRCollapse", "MarketName", DSEAAdditionsExtsErrorReasonCode.XVRCOLLAPSE_MARKETNAME_NULL);
                status.addError(err); 
            }
    	}


    private DWLError createDWLError(String entityName, String propertyName,String reasonCode){	
		DWLError err = new DWLError();
		err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XVRCOLLAPSE_BOBJ).longValue());
		err.setReasonCode(new Long(reasonCode).longValue());
		err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
			String infoForLogging="Error: Validation error occured. Property " + propertyName + " is null, in entity " + entityName + ", component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
			logger.finest("createDWLError " + infoForLogging);
		}
		return err;
    }
    



}

