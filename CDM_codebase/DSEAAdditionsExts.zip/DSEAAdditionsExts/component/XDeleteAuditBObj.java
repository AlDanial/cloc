
/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[cd32bebfbcc56d7cc4c9a74d8a46767f]
 */

package com.ibm.daimler.dsea.component;

import com.dwl.tcrm.common.TCRMCommon;



import com.dwl.base.DWLControl;

import com.dwl.base.constant.DWLUtilErrorReasonCode;

import com.dwl.base.error.DWLError;
import com.dwl.base.error.DWLErrorCode;
import com.dwl.base.error.DWLStatus;

import com.dwl.base.exception.DWLBaseException;
import com.dwl.base.exception.DWLUpdateException;

import com.dwl.base.util.DWLExceptionUtils;
import com.dwl.base.util.DWLFunctionUtils;

import com.dwl.management.config.client.Configuration;

import com.dwl.tcrm.common.ITCRMValidation;

import com.dwl.tcrm.utilities.DateFormatter;
import com.dwl.tcrm.utilities.DateValidator;
import com.dwl.tcrm.utilities.TCRMClassFactory;

import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsComponentID;
import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsErrorReasonCode;
import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsPropertyKeys;

import com.ibm.daimler.dsea.entityObject.EObjXDeleteAudit;

import com.ibm.daimler.dsea.interfaces.DSEAAdditionsExts;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * This class provides the implementation of the business object
 * <code>XDeleteAuditBObj</code>.
 * 
 * @see com.dwl.tcrm.common.TCRMCommon
 * @generated
 */
 

@SuppressWarnings("serial")
public class XDeleteAuditBObj extends TCRMCommon  {

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected EObjXDeleteAudit eObjXDeleteAudit;
	/**
	  * <!-- begin-user-doc -->
	  * <!-- end-user-doc -->
	  * @generated 
	  */
	 private final static com.dwl.base.logging.IDWLLogger logger = com.dwl.base.logging.DWLLoggerManager.getLogger(XDeleteAuditBObj.class);
		
 
	protected boolean isValidDELETE_DATE = true;
	


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */     
    public XDeleteAuditBObj() {
        super();
        init();
        eObjXDeleteAudit = new EObjXDeleteAudit();
        setComponentID(DSEAAdditionsExtsComponentID.XDELETE_AUDIT_BOBJ);
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Initializes the fields required to populate the metaDataMap. Each key is
     * an element-level field of the business object.
     *
     * @generated
     */
    private void init() {
        metaDataMap.put("XDeleteAuditpkId", null);
        metaDataMap.put("CONT_ID", null);
        metaDataMap.put("ADMIN_CLIENT_ID", null);
        metaDataMap.put("ADMIN_SYSTEM_VALUE", null);
        metaDataMap.put("DESCRIPTION", null);
        metaDataMap.put("DELETE_DATE", null);
        metaDataMap.put("MARKET_NAME", null);
        metaDataMap.put("XDeleteAuditHistActionCode", null);
        metaDataMap.put("XDeleteAuditHistCreateDate", null);
        metaDataMap.put("XDeleteAuditHistCreatedBy", null);
        metaDataMap.put("XDeleteAuditHistEndDate", null);
        metaDataMap.put("XDeleteAuditHistoryIdPK", null);
        metaDataMap.put("XDeleteAuditLastUpdateDate", null);
        metaDataMap.put("XDeleteAuditLastUpdateTxId", null);
        metaDataMap.put("XDeleteAuditLastUpdateUser", null);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Refreshes all the attributes this business object supports.
     *
     * @see com.dwl.base.DWLCommon#refreshMap()
     * @generated
     */
    public void refreshMap() {

        if (bRequireMapRefresh) {
            super.refreshMap();
            metaDataMap.put("XDeleteAuditpkId", getXDeleteAuditpkId());
            metaDataMap.put("CONT_ID", getCONT_ID());
            metaDataMap.put("ADMIN_CLIENT_ID", getADMIN_CLIENT_ID());
            metaDataMap.put("ADMIN_SYSTEM_VALUE", getADMIN_SYSTEM_VALUE());
            metaDataMap.put("DESCRIPTION", getDESCRIPTION());
            metaDataMap.put("DELETE_DATE", getDELETE_DATE());
            metaDataMap.put("MARKET_NAME", getMARKET_NAME());
            metaDataMap.put("XDeleteAuditHistActionCode", getXDeleteAuditHistActionCode());
            metaDataMap.put("XDeleteAuditHistCreateDate", getXDeleteAuditHistCreateDate());
            metaDataMap.put("XDeleteAuditHistCreatedBy", getXDeleteAuditHistCreatedBy());
            metaDataMap.put("XDeleteAuditHistEndDate", getXDeleteAuditHistEndDate());
            metaDataMap.put("XDeleteAuditHistoryIdPK", getXDeleteAuditHistoryIdPK());
            metaDataMap.put("XDeleteAuditLastUpdateDate", getXDeleteAuditLastUpdateDate());
            metaDataMap.put("XDeleteAuditLastUpdateTxId", getXDeleteAuditLastUpdateTxId());
            metaDataMap.put("XDeleteAuditLastUpdateUser", getXDeleteAuditLastUpdateUser());
            bRequireMapRefresh = false;
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the control object on this business object.
     *
     * @see com.dwl.base.DWLCommon#setControl(DWLControl)
     * @generated
     */
    public void setControl(DWLControl newDWLControl) {
        super.setControl(newDWLControl);

        if (eObjXDeleteAudit != null) {
            eObjXDeleteAudit.setControl(newDWLControl);
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the entity object associated with this business object.
     *
     * @generated
     */
    public EObjXDeleteAudit getEObjXDeleteAudit() {
        bRequireMapRefresh = true;
        return eObjXDeleteAudit;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the entity object associated with this business object.
     *
     * @param eObjXDeleteAudit
     *            The eObjXDeleteAudit to set.
     * @generated
     */
    public void setEObjXDeleteAudit(EObjXDeleteAudit eObjXDeleteAudit) {
        bRequireMapRefresh = true;
        this.eObjXDeleteAudit = eObjXDeleteAudit;
        if (this.eObjXDeleteAudit != null && this.eObjXDeleteAudit.getControl() == null) {
            DWLControl control = this.getControl();
            if (control != null) {
                this.eObjXDeleteAudit.setControl(control);
            }
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xDeleteAuditpkId attribute.
     * 
     * @generated
     */
    public String getXDeleteAuditpkId (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXDeleteAudit.getXDeleteAuditpkId());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xDeleteAuditpkId attribute.
     * 
     * @param newXDeleteAuditpkId
     *     The new value of xDeleteAuditpkId.
     * @generated
     */
    public void setXDeleteAuditpkId( String newXDeleteAuditpkId ) throws Exception {
        metaDataMap.put("XDeleteAuditpkId", newXDeleteAuditpkId);

        if (newXDeleteAuditpkId == null || newXDeleteAuditpkId.equals("")) {
            newXDeleteAuditpkId = null;


        }
        eObjXDeleteAudit.setXDeleteAuditpkId( DWLFunctionUtils.getLongFromString(newXDeleteAuditpkId) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the cONT_ID attribute.
     * 
     * @generated
     */
    public String getCONT_ID (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXDeleteAudit.getCONT_ID());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the cONT_ID attribute.
     * 
     * @param newCONT_ID
     *     The new value of cONT_ID.
     * @generated
     */
    public void setCONT_ID( String newCONT_ID ) throws Exception {
        metaDataMap.put("CONT_ID", newCONT_ID);

        if (newCONT_ID == null || newCONT_ID.equals("")) {
            newCONT_ID = null;


        }
        eObjXDeleteAudit.setCONT_ID( DWLFunctionUtils.getLongFromString(newCONT_ID) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the aDMIN_CLIENT_ID attribute.
     * 
     * @generated
     */
    public String getADMIN_CLIENT_ID (){
   
        return eObjXDeleteAudit.getADMIN_CLIENT_ID();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the aDMIN_CLIENT_ID attribute.
     * 
     * @param newADMIN_CLIENT_ID
     *     The new value of aDMIN_CLIENT_ID.
     * @generated
     */
    public void setADMIN_CLIENT_ID( String newADMIN_CLIENT_ID ) throws Exception {
        metaDataMap.put("ADMIN_CLIENT_ID", newADMIN_CLIENT_ID);

        if (newADMIN_CLIENT_ID == null || newADMIN_CLIENT_ID.equals("")) {
            newADMIN_CLIENT_ID = null;


        }
        eObjXDeleteAudit.setADMIN_CLIENT_ID( newADMIN_CLIENT_ID );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the aDMIN_SYSTEM_VALUE attribute.
     * 
     * @generated
     */
    public String getADMIN_SYSTEM_VALUE (){
   
        return eObjXDeleteAudit.getADMIN_SYSTEM_VALUE();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the aDMIN_SYSTEM_VALUE attribute.
     * 
     * @param newADMIN_SYSTEM_VALUE
     *     The new value of aDMIN_SYSTEM_VALUE.
     * @generated
     */
    public void setADMIN_SYSTEM_VALUE( String newADMIN_SYSTEM_VALUE ) throws Exception {
        metaDataMap.put("ADMIN_SYSTEM_VALUE", newADMIN_SYSTEM_VALUE);

        if (newADMIN_SYSTEM_VALUE == null || newADMIN_SYSTEM_VALUE.equals("")) {
            newADMIN_SYSTEM_VALUE = null;


        }
        eObjXDeleteAudit.setADMIN_SYSTEM_VALUE( newADMIN_SYSTEM_VALUE );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the dESCRIPTION attribute.
     * 
     * @generated
     */
    public String getDESCRIPTION (){
   
        return eObjXDeleteAudit.getDESCRIPTION();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the dESCRIPTION attribute.
     * 
     * @param newDESCRIPTION
     *     The new value of dESCRIPTION.
     * @generated
     */
    public void setDESCRIPTION( String newDESCRIPTION ) throws Exception {
        metaDataMap.put("DESCRIPTION", newDESCRIPTION);

        if (newDESCRIPTION == null || newDESCRIPTION.equals("")) {
            newDESCRIPTION = null;


        }
        eObjXDeleteAudit.setDESCRIPTION( newDESCRIPTION );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the dELETE_DATE attribute.
     * 
     * @generated
     */
    public String getDELETE_DATE (){
   
        return DWLFunctionUtils.getStringFromTimestamp(eObjXDeleteAudit.getDELETE_DATE());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the dELETE_DATE attribute.
     * 
     * @param newDELETE_DATE
     *     The new value of dELETE_DATE.
     * @generated
     */
    public void setDELETE_DATE( String newDELETE_DATE ) throws Exception {
        metaDataMap.put("DELETE_DATE", newDELETE_DATE);
       	isValidDELETE_DATE = true;

        if (newDELETE_DATE == null || newDELETE_DATE.equals("")) {
            newDELETE_DATE = null;
            eObjXDeleteAudit.setDELETE_DATE(null);


        }
		else {
        	if (DateValidator.validates(newDELETE_DATE)) {
           		eObjXDeleteAudit.setDELETE_DATE(DateFormatter.getStartDateTimestamp(newDELETE_DATE));
            	metaDataMap.put("DELETE_DATE", getDELETE_DATE());
        	} else {
            	if (Configuration.getConfiguration().getConfigItem(
							"/IBM/DWLCommonServices/InternalValidation/enabled").getBooleanValue()) {
                	if (metaDataMap.get("DELETE_DATE") != null) {
                    	metaDataMap.put("DELETE_DATE", "");
                	}
                	isValidDELETE_DATE = false;
                	eObjXDeleteAudit.setDELETE_DATE(null);
            	}
        	}
        }
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the mARKET_NAME attribute.
     * 
     * @generated
     */
    public String getMARKET_NAME (){
   
        return eObjXDeleteAudit.getMARKET_NAME();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the mARKET_NAME attribute.
     * 
     * @param newMARKET_NAME
     *     The new value of mARKET_NAME.
     * @generated
     */
    public void setMARKET_NAME( String newMARKET_NAME ) throws Exception {
        metaDataMap.put("MARKET_NAME", newMARKET_NAME);

        if (newMARKET_NAME == null || newMARKET_NAME.equals("")) {
            newMARKET_NAME = null;


        }
        eObjXDeleteAudit.setMARKET_NAME( newMARKET_NAME );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateTxId attribute.
     *
     * @generated
     */
    public String getXDeleteAuditLastUpdateTxId() {
        return DWLFunctionUtils.getStringFromLong(eObjXDeleteAudit.getLastUpdateTxId());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateUser attribute.
     *
     * @generated
     */
    public String getXDeleteAuditLastUpdateUser() {
        return eObjXDeleteAudit.getLastUpdateUser();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateDt attribute.
     *
     * @generated
     */
    public String getXDeleteAuditLastUpdateDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXDeleteAudit.getLastUpdateDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateTxId attribute.
     *
     * @param newLastUpdateTxId
     *     The new value of LastUpdateTxId.
     * @generated
     */
    public void setXDeleteAuditLastUpdateTxId(String newLastUpdateTxId) {
        metaDataMap.put("XDeleteAuditLastUpdateTxId", newLastUpdateTxId);

        if ((newLastUpdateTxId == null) || newLastUpdateTxId.equals("")) {
            newLastUpdateTxId = null;
        }
        eObjXDeleteAudit.setLastUpdateTxId(DWLFunctionUtils.getLongFromString(newLastUpdateTxId));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateUser attribute.
     *
     * @param newLastUpdateUser
     *     The new value of LastUpdateUser.
     * @generated
     */
    public void setXDeleteAuditLastUpdateUser(String newLastUpdateUser) {
        metaDataMap.put("XDeleteAuditLastUpdateUser", newLastUpdateUser);

        if ((newLastUpdateUser == null) || newLastUpdateUser.equals("")) {
            newLastUpdateUser = null;
        }
        eObjXDeleteAudit.setLastUpdateUser(newLastUpdateUser);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateDt attribute.
     *
     * @param newLastUpdateDt
     *     The new value of LastUpdateDt.
     * @throws Exception
     * @generated
     */
    public void setXDeleteAuditLastUpdateDate(String newLastUpdateDt) throws Exception {
        metaDataMap.put("XDeleteAuditLastUpdateDate", newLastUpdateDt);

        if ((newLastUpdateDt == null) || newLastUpdateDt.equals("")) {
            newLastUpdateDt = null;
        }

        eObjXDeleteAudit.setLastUpdateDt(DWLFunctionUtils.getTimestampFromTimestampString(newLastUpdateDt));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XDeleteAuditHistActionCode history attribute.
     *
     * @generated
     */
    public String getXDeleteAuditHistActionCode() {
        return eObjXDeleteAudit.getHistActionCode();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XDeleteAuditHistActionCode history attribute.
     *
     * @param aXDeleteAuditHistActionCode
     *     The new value of XDeleteAuditHistActionCode.
     * @generated
     */
    public void setXDeleteAuditHistActionCode(String aXDeleteAuditHistActionCode) {
        metaDataMap.put("XDeleteAuditHistActionCode", aXDeleteAuditHistActionCode);

        if ((aXDeleteAuditHistActionCode == null) || aXDeleteAuditHistActionCode.equals("")) {
            aXDeleteAuditHistActionCode = null;
        }
        eObjXDeleteAudit.setHistActionCode(aXDeleteAuditHistActionCode);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XDeleteAuditHistCreateDate history attribute.
     *
     * @generated
     */
    public String getXDeleteAuditHistCreateDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXDeleteAudit.getHistCreateDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XDeleteAuditHistCreateDate history attribute.
     *
     * @param aXDeleteAuditHistCreateDate
     *     The new value of XDeleteAuditHistCreateDate.
     * @generated
     */
    public void setXDeleteAuditHistCreateDate(String aXDeleteAuditHistCreateDate) throws Exception{
        metaDataMap.put("XDeleteAuditHistCreateDate", aXDeleteAuditHistCreateDate);

        if ((aXDeleteAuditHistCreateDate == null) || aXDeleteAuditHistCreateDate.equals("")) {
            aXDeleteAuditHistCreateDate = null;
        }

        eObjXDeleteAudit.setHistCreateDt(DWLFunctionUtils.getTimestampFromTimestampString(aXDeleteAuditHistCreateDate));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XDeleteAuditHistCreatedBy history attribute.
     *
     * @generated
     */
    public String getXDeleteAuditHistCreatedBy() {
        return eObjXDeleteAudit.getHistCreatedBy();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XDeleteAuditHistCreatedBy history attribute.
     *
     * @param aXDeleteAuditHistCreatedBy
     *     The new value of XDeleteAuditHistCreatedBy.
     * @generated
     */
    public void setXDeleteAuditHistCreatedBy(String aXDeleteAuditHistCreatedBy) {
        metaDataMap.put("XDeleteAuditHistCreatedBy", aXDeleteAuditHistCreatedBy);

        if ((aXDeleteAuditHistCreatedBy == null) || aXDeleteAuditHistCreatedBy.equals("")) {
            aXDeleteAuditHistCreatedBy = null;
        }

        eObjXDeleteAudit.setHistCreatedBy(aXDeleteAuditHistCreatedBy);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XDeleteAuditHistEndDate history attribute.
     *
     * @generated
     */
    public String getXDeleteAuditHistEndDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXDeleteAudit.getHistEndDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XDeleteAuditHistEndDate history attribute.
     *
     * @param aXDeleteAuditHistEndDate
     *     The new value of XDeleteAuditHistEndDate.
     * @generated
     */
    public void setXDeleteAuditHistEndDate(String aXDeleteAuditHistEndDate) throws Exception{
        metaDataMap.put("XDeleteAuditHistEndDate", aXDeleteAuditHistEndDate);

        if ((aXDeleteAuditHistEndDate == null) || aXDeleteAuditHistEndDate.equals("")) {
            aXDeleteAuditHistEndDate = null;
        }
        eObjXDeleteAudit.setHistEndDt(DWLFunctionUtils.getTimestampFromTimestampString(aXDeleteAuditHistEndDate));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XDeleteAuditHistoryIdPK history attribute.
     *
     * @generated
     */
    public String getXDeleteAuditHistoryIdPK() {
        return DWLFunctionUtils.getStringFromLong(eObjXDeleteAudit.getHistoryIdPK());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XDeleteAuditHistoryIdPK history attribute.
     *
     * @param aXDeleteAuditHistoryIdPK
     *     The new value of XDeleteAuditHistoryIdPK.
     * @generated
     */
    public void setXDeleteAuditHistoryIdPK(String aXDeleteAuditHistoryIdPK) {
        metaDataMap.put("XDeleteAuditHistoryIdPK", aXDeleteAuditHistoryIdPK);

        if ((aXDeleteAuditHistoryIdPK == null) || aXDeleteAuditHistoryIdPK.equals("")) {
            aXDeleteAuditHistoryIdPK = null;
        }
        eObjXDeleteAudit.setHistoryIdPK(DWLFunctionUtils.getLongFromString(aXDeleteAuditHistoryIdPK));
    }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation during an add transaction.
     *
     * @generated
     */
    public DWLStatus validateAdd(int level, DWLStatus status) throws Exception {

        status = super.validateAdd(level, status);
        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0038I Add any controller-level custom validation logic to be
            // executed for this object during an "add" transaction

        }

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            // MDM_TODO0: CDKWB0039I Add any component-level custom validation logic to be
            // executed for this object during an "add" transaction
        }
        status = getValidationStatus(level, status);
        return status;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation during an update transaction.
     *
     * @generated
     */
    public DWLStatus validateUpdate(int level, DWLStatus status) throws Exception {
		logger.finest("ENTER validateUpdate(int level, DWLStatus status)");

        status = super.validateUpdate(level, status);
        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0040I Add any controller-level custom validation logic to be
            // executed for this object during an "update" transaction

            if (eObjXDeleteAudit.getXDeleteAuditpkId() == null) {
                DWLError err = new DWLError();
                err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XDELETE_AUDIT_BOBJ).longValue());
                err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.XDELETEAUDIT_XDELETEAUDITPKID_NULL).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
				if (logger.isFinestEnabled()) {
                	String infoForLogging="Error: Validation error occured for update. No primary key for entity XDeleteAudit, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
			logger.finest("validateUpdate(int level, DWLStatus status) " + infoForLogging);
                }
                status.addError(err);
            }
            if (eObjXDeleteAudit.getLastUpdateDt() == null) {
                DWLError err = new DWLError();
                err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XDELETE_AUDIT_BOBJ).longValue());
                err.setReasonCode(new Long(DWLUtilErrorReasonCode.LAST_UPDATED_DATE_NULL).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
                if (logger.isFinestEnabled()) {
                	String infoForLogging="Error: Validation error occured for update. No last update date for entity XDeleteAudit, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
			logger.finest("validateUpdate(int level, DWLStatus status) " + infoForLogging);
                }
                status.addError(err);
            }
        }

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            assignBeforeImageValues(metaDataMap);
            
            // MDM_TODO0: CDKWB0041I Add any component-level custom validation logic to be
            // executed for this object during an "update" transaction
        }
        status = getValidationStatus(level, status);
		if (logger.isFinestEnabled()) {
        	String returnValue = status.toString();
			logger.finest("RETURN validateUpdate(int level, DWLStatus status) " + returnValue);
		}
        return status;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Populate the before image of this business object.
     *
     * @see com.dwl.base.DWLCommon#populateBeforeImage()
     * @generated
     */
    public void populateBeforeImage() throws DWLBaseException {
		logger.finest("ENTER populateBeforeImage()");

        DSEAAdditionsExts comp = null;
        try {
        
			comp = (DSEAAdditionsExts)TCRMClassFactory.getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
        	
        } catch (Exception e) {
			if (logger.isFinestEnabled()) {
				String infoForLogging="Error: Fatal error while updating record " + e.getMessage();
			logger.finest("populateBeforeImage() " + infoForLogging);
			}
            DWLExceptionUtils.throwDWLBaseException(e, 
            									new DWLUpdateException(e.getMessage()), 
            									this.getStatus(), DWLStatus.FATAL,
							                    DSEAAdditionsExtsComponentID.XDELETE_AUDIT_BOBJ, 
							                    "DIERR",
							                    DSEAAdditionsExtsErrorReasonCode.XDELETEAUDIT_BEFORE_IMAGE_NOT_POPULATED, 
							                    this.getControl());
        }
        
        comp.loadBeforeImage(this);
		logger.finest("RETURN populateBeforeImage()");
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation common to both add and update transactions.
     *
     * @generated
     */
     
    private DWLStatus getValidationStatus(int level, DWLStatus status) throws Exception {
		logger.finest("ENTER getValidationStatus(int level, DWLStatus status)");

        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0034I Add any common controller-level custom validation
            // logic to be executed for this object during either "add" or
            // "update" transactions
    		controllerValidation_CONT_ID(status);
    		controllerValidation_ADMIN_CLIENT_ID(status);
    		controllerValidation_DELETE_DATE(status);
    	}

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            // MDM_TODO0: CDKWB0035I Add any common component-level custom validation logic
            // to be executed for this object during either "add" or "update"
            // transactions
    		componentValidation_CONT_ID(status);
    		componentValidation_ADMIN_CLIENT_ID(status);
    		componentValidation_DELETE_DATE(status);
        }
        
        if (logger.isFinestEnabled()) {
            String returnValue = status.toString();
			logger.finest("RETURN getValidationStatus(int level, DWLStatus status) " + returnValue);
        }
		
        return status;
    }

    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "CONT_ID"
     *
     * @generated
     */
	private void componentValidation_CONT_ID(DWLStatus status) {
	
            boolean isCONT_IDNull = (eObjXDeleteAudit.getCONT_ID() == null);
            if (isCONT_IDNull) {
                DWLError err = createDWLError("XDeleteAudit", "CONT_ID", DSEAAdditionsExtsErrorReasonCode.XDELETEAUDIT_CONT_ID_NULL);
                status.addError(err); 
            }
	}
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "ADMIN_CLIENT_ID"
     *
     * @generated
     */
	private void componentValidation_ADMIN_CLIENT_ID(DWLStatus status) {
	
            boolean isADMIN_CLIENT_IDNull = false;
            if (eObjXDeleteAudit.getADMIN_CLIENT_ID() == null || 
            	eObjXDeleteAudit.getADMIN_CLIENT_ID().trim().equals("")) {
                isADMIN_CLIENT_IDNull = true;
            }
            if (isADMIN_CLIENT_IDNull) {
                DWLError err = createDWLError("XDeleteAudit", "ADMIN_CLIENT_ID", DSEAAdditionsExtsErrorReasonCode.XDELETEAUDIT_ADMIN_CLIENT_ID_NULL);
                status.addError(err); 
            }
	}
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "DELETE_DATE"
     *
     * @generated
     */
	private void componentValidation_DELETE_DATE(DWLStatus status) {
	
	}
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "CONT_ID"
     *
     * @generated
     */
	private void controllerValidation_CONT_ID(DWLStatus status) throws Exception {
	
            boolean isCONT_IDNull = (eObjXDeleteAudit.getCONT_ID() == null);
            if (isCONT_IDNull) {
                DWLError err = createDWLError("XDeleteAudit", "CONT_ID", DSEAAdditionsExtsErrorReasonCode.XDELETEAUDIT_CONT_ID_NULL);
                status.addError(err); 
            }
    	}
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "ADMIN_CLIENT_ID"
     *
     * @generated
     */
	private void controllerValidation_ADMIN_CLIENT_ID(DWLStatus status) throws Exception {
	
            boolean isADMIN_CLIENT_IDNull = false;
            if (eObjXDeleteAudit.getADMIN_CLIENT_ID() == null || 
            	eObjXDeleteAudit.getADMIN_CLIENT_ID().trim().equals("")) {
                isADMIN_CLIENT_IDNull = true;
            }
            if (isADMIN_CLIENT_IDNull) {
                DWLError err = createDWLError("XDeleteAudit", "ADMIN_CLIENT_ID", DSEAAdditionsExtsErrorReasonCode.XDELETEAUDIT_ADMIN_CLIENT_ID_NULL);
                status.addError(err); 
            }
    	}
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "DELETE_DATE"
     *
     * @generated
     */
	private void controllerValidation_DELETE_DATE(DWLStatus status) throws Exception {
	
            boolean isDELETE_DATENull = (eObjXDeleteAudit.getDELETE_DATE() == null);
            if (!isValidDELETE_DATE) {
              	DWLError err = new DWLError();
               	err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XDELETE_AUDIT_BOBJ).longValue());
               	err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XDELETEAUDIT_DELETE_DATE).longValue());
               	err.setErrorType(DWLErrorCode.DATA_INVALID_ERROR);
                String infoForLogging="Error: Validation error. Invalid time specified on property DELETE_DATE in entity XDeleteAudit, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode();
			logger.finest("controllerValidation_DELETE_DATE " + infoForLogging);
               	status.addError(err);
            } 
    	}
    private DWLError createDWLError(String entityName, String propertyName,String reasonCode){	
		DWLError err = new DWLError();
		err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XDELETE_AUDIT_BOBJ).longValue());
		err.setReasonCode(new Long(reasonCode).longValue());
		err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
			String infoForLogging="Error: Validation error occured. Property " + propertyName + " is null, in entity " + entityName + ", component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
			logger.finest("createDWLError " + infoForLogging);
		}
		return err;
    }
    



}

