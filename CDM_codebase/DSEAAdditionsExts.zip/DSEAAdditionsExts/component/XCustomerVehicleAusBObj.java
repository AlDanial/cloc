
/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[422078e8a7830c952d26048addd3563d]
 */

package com.ibm.daimler.dsea.component;

import com.dwl.tcrm.common.TCRMCommon;



import com.dwl.base.DWLControl;

import com.dwl.base.constant.DWLControlKeys;
import com.dwl.base.constant.DWLUtilErrorReasonCode;

import com.dwl.base.error.DWLError;
import com.dwl.base.error.DWLErrorCode;
import com.dwl.base.error.DWLStatus;

import com.dwl.base.exception.DWLBaseException;
import com.dwl.base.exception.DWLUpdateException;

import com.dwl.base.util.DWLClassFactory;
import com.dwl.base.util.DWLExceptionUtils;
import com.dwl.base.util.DWLFunctionUtils;

import com.dwl.management.config.client.Configuration;

import com.dwl.tcrm.common.ITCRMValidation;

import com.dwl.tcrm.utilities.DateFormatter;
import com.dwl.tcrm.utilities.DateValidator;
import com.dwl.tcrm.utilities.TCRMClassFactory;

import com.ibm.daimler.dsea.component.XCustomerVehicleRoleAusBObj;
import com.ibm.daimler.dsea.component.XVehicleAusBObj;
import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsComponentID;
import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsErrorReasonCode;
import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsPropertyKeys;

import com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleAus;

import com.ibm.daimler.dsea.interfaces.DSEAAdditionsExts;

import com.ibm.mdm.common.codetype.interfaces.CodeTypeComponentHelper;

import com.ibm.mdm.common.codetype.obj.CodeTypeBObj;
import java.util.Vector;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * This class provides the implementation of the business object
 * <code>XCustomerVehicleAusBObj</code>.
 * 
 * @see com.dwl.tcrm.common.TCRMCommon
 * @generated
 */
 

@SuppressWarnings("serial")
public class XCustomerVehicleAusBObj extends TCRMCommon  {

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected EObjXCustomerVehicleAus eObjXCustomerVehicleAus;
	/**
    * <!-- begin-user-doc -->
	  * <!-- end-user-doc -->
    * @generated 
    */
	 private final static com.dwl.base.logging.IDWLLogger logger = com.dwl.base.logging.DWLLoggerManager.getLogger(XCustomerVehicleAusBObj.class);
		
 
	protected boolean isValidPurchaseDate = true;
	
	protected boolean isValidEndDate = true;
	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected String sourceIdentifierValue;
	protected boolean isValidLastModifiedSystemDate = true;
	


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected XVehicleAusBObj XVehicleAusBObj;
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    @SuppressWarnings("rawtypes")
    protected Vector vecXCustomerVehicleRoleAusBObj;



    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */     
    @SuppressWarnings("rawtypes")
    public XCustomerVehicleAusBObj() {
        super();
        init();
        eObjXCustomerVehicleAus = new EObjXCustomerVehicleAus();
        vecXCustomerVehicleRoleAusBObj = new Vector();
        setComponentID(DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_AUS_BOBJ);
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Initializes the fields required to populate the metaDataMap. Each key is
     * an element-level field of the business object.
     *
     * @generated
     */
    private void init() {
        metaDataMap.put("XCustomerVehicleAuspkId", null);
        metaDataMap.put("ContId", null);
        metaDataMap.put("VehicleId", null);
        metaDataMap.put("RetailerId", null);
        metaDataMap.put("PurchaseDate", null);
        metaDataMap.put("EndDate", null);
        metaDataMap.put("MarketName", null);
        metaDataMap.put("SourceIdentifierType", null);
        metaDataMap.put("SourceIdentifierValue", null);
        metaDataMap.put("LastModifiedSystemDate", null);
        metaDataMap.put("XCustomerVehicleAusHistActionCode", null);
        metaDataMap.put("XCustomerVehicleAusHistCreateDate", null);
        metaDataMap.put("XCustomerVehicleAusHistCreatedBy", null);
        metaDataMap.put("XCustomerVehicleAusHistEndDate", null);
        metaDataMap.put("XCustomerVehicleAusHistoryIdPK", null);
        metaDataMap.put("XCustomerVehicleAusLastUpdateDate", null);
        metaDataMap.put("XCustomerVehicleAusLastUpdateTxId", null);
        metaDataMap.put("XCustomerVehicleAusLastUpdateUser", null);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Refreshes all the attributes this business object supports.
     *
     * @see com.dwl.base.DWLCommon#refreshMap()
     * @generated
     */
    public void refreshMap() {

        if (bRequireMapRefresh) {
            super.refreshMap();
            metaDataMap.put("XCustomerVehicleAuspkId", getXCustomerVehicleAuspkId());
            metaDataMap.put("ContId", getContId());
            metaDataMap.put("VehicleId", getVehicleId());
            metaDataMap.put("RetailerId", getRetailerId());
            metaDataMap.put("PurchaseDate", getPurchaseDate());
            metaDataMap.put("EndDate", getEndDate());
            metaDataMap.put("MarketName", getMarketName());
            metaDataMap.put("SourceIdentifierType", getSourceIdentifierType());
            metaDataMap.put("SourceIdentifierValue", getSourceIdentifierValue());
            metaDataMap.put("LastModifiedSystemDate", getLastModifiedSystemDate());
            metaDataMap.put("XCustomerVehicleAusHistActionCode", getXCustomerVehicleAusHistActionCode());
            metaDataMap.put("XCustomerVehicleAusHistCreateDate", getXCustomerVehicleAusHistCreateDate());
            metaDataMap.put("XCustomerVehicleAusHistCreatedBy", getXCustomerVehicleAusHistCreatedBy());
            metaDataMap.put("XCustomerVehicleAusHistEndDate", getXCustomerVehicleAusHistEndDate());
            metaDataMap.put("XCustomerVehicleAusHistoryIdPK", getXCustomerVehicleAusHistoryIdPK());
            metaDataMap.put("XCustomerVehicleAusLastUpdateDate", getXCustomerVehicleAusLastUpdateDate());
            metaDataMap.put("XCustomerVehicleAusLastUpdateTxId", getXCustomerVehicleAusLastUpdateTxId());
            metaDataMap.put("XCustomerVehicleAusLastUpdateUser", getXCustomerVehicleAusLastUpdateUser());
            bRequireMapRefresh = false;
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the control object on this business object.
     *
     * @see com.dwl.base.DWLCommon#setControl(DWLControl)
     * @generated
     */
    public void setControl(DWLControl newDWLControl) {
        super.setControl(newDWLControl);

        if (eObjXCustomerVehicleAus != null) {
            eObjXCustomerVehicleAus.setControl(newDWLControl);
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the entity object associated with this business object.
     *
     * @generated
     */
    public EObjXCustomerVehicleAus getEObjXCustomerVehicleAus() {
        bRequireMapRefresh = true;
        return eObjXCustomerVehicleAus;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the entity object associated with this business object.
     *
     * @param eObjXCustomerVehicleAus
     *            The eObjXCustomerVehicleAus to set.
     * @generated
     */
    public void setEObjXCustomerVehicleAus(EObjXCustomerVehicleAus eObjXCustomerVehicleAus) {
        bRequireMapRefresh = true;
        this.eObjXCustomerVehicleAus = eObjXCustomerVehicleAus;
        if (this.eObjXCustomerVehicleAus != null && this.eObjXCustomerVehicleAus.getControl() == null) {
            DWLControl control = this.getControl();
            if (control != null) {
                this.eObjXCustomerVehicleAus.setControl(control);
            }
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xCustomerVehicleAuspkId attribute.
     * 
     * @generated
     */
    public String getXCustomerVehicleAuspkId (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXCustomerVehicleAus.getXCustomerVehicleAuspkId());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xCustomerVehicleAuspkId attribute.
     * 
     * @param newXCustomerVehicleAuspkId
     *     The new value of xCustomerVehicleAuspkId.
     * @generated
     */
    public void setXCustomerVehicleAuspkId( String newXCustomerVehicleAuspkId ) throws Exception {
        metaDataMap.put("XCustomerVehicleAuspkId", newXCustomerVehicleAuspkId);

        if (newXCustomerVehicleAuspkId == null || newXCustomerVehicleAuspkId.equals("")) {
            newXCustomerVehicleAuspkId = null;


        }
        eObjXCustomerVehicleAus.setXCustomerVehicleAuspkId( DWLFunctionUtils.getLongFromString(newXCustomerVehicleAuspkId) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the contId attribute.
     * 
     * @generated
     */
    public String getContId (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXCustomerVehicleAus.getContId());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the contId attribute.
     * 
     * @param newContId
     *     The new value of contId.
     * @generated
     */
    public void setContId( String newContId ) throws Exception {
        metaDataMap.put("ContId", newContId);

        if (newContId == null || newContId.equals("")) {
            newContId = null;


        }
        eObjXCustomerVehicleAus.setContId( DWLFunctionUtils.getLongFromString(newContId) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the vehicleId attribute.
     * 
     * @generated
     */
    public String getVehicleId (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXCustomerVehicleAus.getVehicleId());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the vehicleId attribute.
     * 
     * @param newVehicleId
     *     The new value of vehicleId.
     * @generated
     */
    public void setVehicleId( String newVehicleId ) throws Exception {
        metaDataMap.put("VehicleId", newVehicleId);

        if (newVehicleId == null || newVehicleId.equals("")) {
            newVehicleId = null;


        }
        eObjXCustomerVehicleAus.setVehicleId( DWLFunctionUtils.getLongFromString(newVehicleId) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the retailerId attribute.
     * 
     * @generated
     */
    public String getRetailerId (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXCustomerVehicleAus.getRetailerId());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the retailerId attribute.
     * 
     * @param newRetailerId
     *     The new value of retailerId.
     * @generated
     */
    public void setRetailerId( String newRetailerId ) throws Exception {
        metaDataMap.put("RetailerId", newRetailerId);

        if (newRetailerId == null || newRetailerId.equals("")) {
            newRetailerId = null;


        }
        eObjXCustomerVehicleAus.setRetailerId( DWLFunctionUtils.getLongFromString(newRetailerId) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the purchaseDate attribute.
     * 
     * @generated
     */
    public String getPurchaseDate (){
   
        return DWLFunctionUtils.getStringFromTimestamp(eObjXCustomerVehicleAus.getPurchaseDate());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the purchaseDate attribute.
     * 
     * @param newPurchaseDate
     *     The new value of purchaseDate.
     * @generated
     */
    public void setPurchaseDate( String newPurchaseDate ) throws Exception {
        metaDataMap.put("PurchaseDate", newPurchaseDate);
       	isValidPurchaseDate = true;

        if (newPurchaseDate == null || newPurchaseDate.equals("")) {
            newPurchaseDate = null;
            eObjXCustomerVehicleAus.setPurchaseDate(null);


        }
    else {
        	if (DateValidator.validates(newPurchaseDate)) {
           		eObjXCustomerVehicleAus.setPurchaseDate(DateFormatter.getStartDateTimestamp(newPurchaseDate));
            	metaDataMap.put("PurchaseDate", getPurchaseDate());
        	} else {
            	if (Configuration.getConfiguration().getConfigItem(
              "/IBM/DWLCommonServices/InternalValidation/enabled").getBooleanValue()) {
                	if (metaDataMap.get("PurchaseDate") != null) {
                    	metaDataMap.put("PurchaseDate", "");
                	}
                	isValidPurchaseDate = false;
                	eObjXCustomerVehicleAus.setPurchaseDate(null);
            	}
        	}
        }
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the endDate attribute.
     * 
     * @generated
     */
    public String getEndDate (){
   
        return DWLFunctionUtils.getStringFromTimestamp(eObjXCustomerVehicleAus.getEndDate());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the endDate attribute.
     * 
     * @param newEndDate
     *     The new value of endDate.
     * @generated
     */
    public void setEndDate( String newEndDate ) throws Exception {
        metaDataMap.put("EndDate", newEndDate);
       	isValidEndDate = true;

        if (newEndDate == null || newEndDate.equals("")) {
            newEndDate = null;
            eObjXCustomerVehicleAus.setEndDate(null);


        }
    else {
        	if (DateValidator.validates(newEndDate)) {
           		eObjXCustomerVehicleAus.setEndDate(DateFormatter.getStartDateTimestamp(newEndDate));
            	metaDataMap.put("EndDate", getEndDate());
        	} else {
            	if (Configuration.getConfiguration().getConfigItem(
              "/IBM/DWLCommonServices/InternalValidation/enabled").getBooleanValue()) {
                	if (metaDataMap.get("EndDate") != null) {
                    	metaDataMap.put("EndDate", "");
                	}
                	isValidEndDate = false;
                	eObjXCustomerVehicleAus.setEndDate(null);
            	}
        	}
        }
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the marketName attribute.
     * 
     * @generated
     */
    public String getMarketName (){
   
        return eObjXCustomerVehicleAus.getMarketName();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the marketName attribute.
     * 
     * @param newMarketName
     *     The new value of marketName.
     * @generated
     */
    public void setMarketName( String newMarketName ) throws Exception {
        metaDataMap.put("MarketName", newMarketName);

        if (newMarketName == null || newMarketName.equals("")) {
            newMarketName = null;


        }
        eObjXCustomerVehicleAus.setMarketName( newMarketName );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the sourceIdentifierType attribute.
     * 
     * @generated
     */
    public String getSourceIdentifierType (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXCustomerVehicleAus.getSourceIdentifier());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the sourceIdentifierType attribute.
     * 
     * @param newSourceIdentifierType
     *     The new value of sourceIdentifierType.
     * @generated
     */
    public void setSourceIdentifierType( String newSourceIdentifierType ) throws Exception {
        metaDataMap.put("SourceIdentifierType", newSourceIdentifierType);

        if (newSourceIdentifierType == null || newSourceIdentifierType.equals("")) {
            newSourceIdentifierType = null;


        }
        eObjXCustomerVehicleAus.setSourceIdentifier( DWLFunctionUtils.getLongFromString(newSourceIdentifierType) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the sourceIdentifierValue attribute.
     * 
     * @generated
     */
    public String getSourceIdentifierValue (){
      return sourceIdentifierValue;
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the sourceIdentifierValue attribute.
     * 
     * @param newSourceIdentifierValue
     *     The new value of sourceIdentifierValue.
     * @generated
     */
    public void setSourceIdentifierValue( String newSourceIdentifierValue ) throws Exception {
        metaDataMap.put("SourceIdentifierValue", newSourceIdentifierValue);

        if (newSourceIdentifierValue == null || newSourceIdentifierValue.equals("")) {
            newSourceIdentifierValue = null;


        }
        sourceIdentifierValue = newSourceIdentifierValue;
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the lastModifiedSystemDate attribute.
     * 
     * @generated
     */
    public String getLastModifiedSystemDate (){
   
        return DWLFunctionUtils.getStringFromTimestamp(eObjXCustomerVehicleAus.getLastModifiedSystemDate());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the lastModifiedSystemDate attribute.
     * 
     * @param newLastModifiedSystemDate
     *     The new value of lastModifiedSystemDate.
     * @generated
     */
    public void setLastModifiedSystemDate( String newLastModifiedSystemDate ) throws Exception {
        metaDataMap.put("LastModifiedSystemDate", newLastModifiedSystemDate);
       	isValidLastModifiedSystemDate = true;

        if (newLastModifiedSystemDate == null || newLastModifiedSystemDate.equals("")) {
            newLastModifiedSystemDate = null;
            eObjXCustomerVehicleAus.setLastModifiedSystemDate(null);


        }
    else {
        	if (DateValidator.validates(newLastModifiedSystemDate)) {
           		eObjXCustomerVehicleAus.setLastModifiedSystemDate(DateFormatter.getStartDateTimestamp(newLastModifiedSystemDate));
            	metaDataMap.put("LastModifiedSystemDate", getLastModifiedSystemDate());
        	} else {
            	if (Configuration.getConfiguration().getConfigItem(
              "/IBM/DWLCommonServices/InternalValidation/enabled").getBooleanValue()) {
                	if (metaDataMap.get("LastModifiedSystemDate") != null) {
                    	metaDataMap.put("LastModifiedSystemDate", "");
                	}
                	isValidLastModifiedSystemDate = false;
                	eObjXCustomerVehicleAus.setLastModifiedSystemDate(null);
            	}
        	}
        }
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XVehicleAusBObj attribute.
     * 
     * @generated
     */
    public XVehicleAusBObj getXVehicleAusBObj (){
      return XVehicleAusBObj;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public void setXVehicleAusBObj(XVehicleAusBObj newBObj ) {
    XVehicleAusBObj = newBObj;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XCustomerVehicleRoleAusBObj attribute.
     * 
     * @generated
     */
    @SuppressWarnings("rawtypes")
    public Vector getItemsXCustomerVehicleRoleAusBObj (){
      return vecXCustomerVehicleRoleAusBObj;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    @SuppressWarnings("unchecked")
    public void setXCustomerVehicleRoleAusBObj(XCustomerVehicleRoleAusBObj newBObj ) {
        vecXCustomerVehicleRoleAusBObj.addElement( newBObj );
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateTxId attribute.
     *
     * @generated
     */
    public String getXCustomerVehicleAusLastUpdateTxId() {
        return DWLFunctionUtils.getStringFromLong(eObjXCustomerVehicleAus.getLastUpdateTxId());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateUser attribute.
     *
     * @generated
     */
    public String getXCustomerVehicleAusLastUpdateUser() {
        return eObjXCustomerVehicleAus.getLastUpdateUser();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateDt attribute.
     *
     * @generated
     */
    public String getXCustomerVehicleAusLastUpdateDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXCustomerVehicleAus.getLastUpdateDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateTxId attribute.
     *
     * @param newLastUpdateTxId
     *     The new value of LastUpdateTxId.
     * @generated
     */
    public void setXCustomerVehicleAusLastUpdateTxId(String newLastUpdateTxId) {
        metaDataMap.put("XCustomerVehicleAusLastUpdateTxId", newLastUpdateTxId);

        if ((newLastUpdateTxId == null) || newLastUpdateTxId.equals("")) {
            newLastUpdateTxId = null;
        }
        eObjXCustomerVehicleAus.setLastUpdateTxId(DWLFunctionUtils.getLongFromString(newLastUpdateTxId));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateUser attribute.
     *
     * @param newLastUpdateUser
     *     The new value of LastUpdateUser.
     * @generated
     */
    public void setXCustomerVehicleAusLastUpdateUser(String newLastUpdateUser) {
        metaDataMap.put("XCustomerVehicleAusLastUpdateUser", newLastUpdateUser);

        if ((newLastUpdateUser == null) || newLastUpdateUser.equals("")) {
            newLastUpdateUser = null;
        }
        eObjXCustomerVehicleAus.setLastUpdateUser(newLastUpdateUser);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateDt attribute.
     *
     * @param newLastUpdateDt
     *     The new value of LastUpdateDt.
     * @throws Exception
     * @generated
     */
    public void setXCustomerVehicleAusLastUpdateDate(String newLastUpdateDt) throws Exception {
        metaDataMap.put("XCustomerVehicleAusLastUpdateDate", newLastUpdateDt);

        if ((newLastUpdateDt == null) || newLastUpdateDt.equals("")) {
            newLastUpdateDt = null;
        }

        eObjXCustomerVehicleAus.setLastUpdateDt(DWLFunctionUtils.getTimestampFromTimestampString(newLastUpdateDt));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XCustomerVehicleAusHistActionCode history attribute.
     *
     * @generated
     */
    public String getXCustomerVehicleAusHistActionCode() {
        return eObjXCustomerVehicleAus.getHistActionCode();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XCustomerVehicleAusHistActionCode history attribute.
     *
     * @param aXCustomerVehicleAusHistActionCode
     *     The new value of XCustomerVehicleAusHistActionCode.
     * @generated
     */
    public void setXCustomerVehicleAusHistActionCode(String aXCustomerVehicleAusHistActionCode) {
        metaDataMap.put("XCustomerVehicleAusHistActionCode", aXCustomerVehicleAusHistActionCode);

        if ((aXCustomerVehicleAusHistActionCode == null) || aXCustomerVehicleAusHistActionCode.equals("")) {
            aXCustomerVehicleAusHistActionCode = null;
        }
        eObjXCustomerVehicleAus.setHistActionCode(aXCustomerVehicleAusHistActionCode);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XCustomerVehicleAusHistCreateDate history attribute.
     *
     * @generated
     */
    public String getXCustomerVehicleAusHistCreateDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXCustomerVehicleAus.getHistCreateDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XCustomerVehicleAusHistCreateDate history attribute.
     *
     * @param aXCustomerVehicleAusHistCreateDate
     *     The new value of XCustomerVehicleAusHistCreateDate.
     * @generated
     */
    public void setXCustomerVehicleAusHistCreateDate(String aXCustomerVehicleAusHistCreateDate) throws Exception{
        metaDataMap.put("XCustomerVehicleAusHistCreateDate", aXCustomerVehicleAusHistCreateDate);

        if ((aXCustomerVehicleAusHistCreateDate == null) || aXCustomerVehicleAusHistCreateDate.equals("")) {
            aXCustomerVehicleAusHistCreateDate = null;
        }

        eObjXCustomerVehicleAus.setHistCreateDt(DWLFunctionUtils.getTimestampFromTimestampString(aXCustomerVehicleAusHistCreateDate));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XCustomerVehicleAusHistCreatedBy history attribute.
     *
     * @generated
     */
    public String getXCustomerVehicleAusHistCreatedBy() {
        return eObjXCustomerVehicleAus.getHistCreatedBy();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XCustomerVehicleAusHistCreatedBy history attribute.
     *
     * @param aXCustomerVehicleAusHistCreatedBy
     *     The new value of XCustomerVehicleAusHistCreatedBy.
     * @generated
     */
    public void setXCustomerVehicleAusHistCreatedBy(String aXCustomerVehicleAusHistCreatedBy) {
        metaDataMap.put("XCustomerVehicleAusHistCreatedBy", aXCustomerVehicleAusHistCreatedBy);

        if ((aXCustomerVehicleAusHistCreatedBy == null) || aXCustomerVehicleAusHistCreatedBy.equals("")) {
            aXCustomerVehicleAusHistCreatedBy = null;
        }

        eObjXCustomerVehicleAus.setHistCreatedBy(aXCustomerVehicleAusHistCreatedBy);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XCustomerVehicleAusHistEndDate history attribute.
     *
     * @generated
     */
    public String getXCustomerVehicleAusHistEndDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXCustomerVehicleAus.getHistEndDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XCustomerVehicleAusHistEndDate history attribute.
     *
     * @param aXCustomerVehicleAusHistEndDate
     *     The new value of XCustomerVehicleAusHistEndDate.
     * @generated
     */
    public void setXCustomerVehicleAusHistEndDate(String aXCustomerVehicleAusHistEndDate) throws Exception{
        metaDataMap.put("XCustomerVehicleAusHistEndDate", aXCustomerVehicleAusHistEndDate);

        if ((aXCustomerVehicleAusHistEndDate == null) || aXCustomerVehicleAusHistEndDate.equals("")) {
            aXCustomerVehicleAusHistEndDate = null;
        }
        eObjXCustomerVehicleAus.setHistEndDt(DWLFunctionUtils.getTimestampFromTimestampString(aXCustomerVehicleAusHistEndDate));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XCustomerVehicleAusHistoryIdPK history attribute.
     *
     * @generated
     */
    public String getXCustomerVehicleAusHistoryIdPK() {
        return DWLFunctionUtils.getStringFromLong(eObjXCustomerVehicleAus.getHistoryIdPK());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XCustomerVehicleAusHistoryIdPK history attribute.
     *
     * @param aXCustomerVehicleAusHistoryIdPK
     *     The new value of XCustomerVehicleAusHistoryIdPK.
     * @generated
     */
    public void setXCustomerVehicleAusHistoryIdPK(String aXCustomerVehicleAusHistoryIdPK) {
        metaDataMap.put("XCustomerVehicleAusHistoryIdPK", aXCustomerVehicleAusHistoryIdPK);

        if ((aXCustomerVehicleAusHistoryIdPK == null) || aXCustomerVehicleAusHistoryIdPK.equals("")) {
            aXCustomerVehicleAusHistoryIdPK = null;
        }
        eObjXCustomerVehicleAus.setHistoryIdPK(DWLFunctionUtils.getLongFromString(aXCustomerVehicleAusHistoryIdPK));
    }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation during an add transaction.
     *
     * @generated
     */
    public DWLStatus validateAdd(int level, DWLStatus status) throws Exception {

        status = super.validateAdd(level, status);
        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0038I Add any controller-level custom validation logic to be
            // executed for this object during an "add" transaction


            XVehicleAusBObj xVehicleAus = getXVehicleAusBObj();
            if( xVehicleAus != null ){
            	status = xVehicleAus.validateAdd(level, status);
            }

            for (int i = 0; i < getItemsXCustomerVehicleRoleAusBObj().size(); i++) {
                XCustomerVehicleRoleAusBObj xCustomerVehicleRoleAus = (XCustomerVehicleRoleAusBObj) getItemsXCustomerVehicleRoleAusBObj().elementAt(i);
                status = xCustomerVehicleRoleAus.validateAdd(level, status);
            }
        }

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            // MDM_TODO0: CDKWB0039I Add any component-level custom validation logic to be
            // executed for this object during an "add" transaction
        }
        status = getValidationStatus(level, status);
        return status;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation during an update transaction.
     *
     * @generated
     */
    public DWLStatus validateUpdate(int level, DWLStatus status) throws Exception {
    logger.finest("ENTER validateUpdate(int level, DWLStatus status)");

        status = super.validateUpdate(level, status);
        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0040I Add any controller-level custom validation logic to be
            // executed for this object during an "update" transaction

            if (eObjXCustomerVehicleAus.getXCustomerVehicleAuspkId() == null) {
                DWLError err = new DWLError();
                err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_AUS_BOBJ).longValue());
                err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.XCUSTOMERVEHICLEAUS_XCUSTOMERVEHICLEAUSPKID_NULL).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                	String infoForLogging="Error: Validation error occured for update. No primary key for entity XCustomerVehicleAus, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("validateUpdate(int level, DWLStatus status) " + infoForLogging);
                }
                status.addError(err);
            }
            if (eObjXCustomerVehicleAus.getLastUpdateDt() == null) {
                DWLError err = new DWLError();
                err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_AUS_BOBJ).longValue());
                err.setReasonCode(new Long(DWLUtilErrorReasonCode.LAST_UPDATED_DATE_NULL).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
                if (logger.isFinestEnabled()) {
                	String infoForLogging="Error: Validation error occured for update. No last update date for entity XCustomerVehicleAus, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("validateUpdate(int level, DWLStatus status) " + infoForLogging);
                }
                status.addError(err);
            }
           XVehicleAusBObj xVehicleAus = (XVehicleAusBObj) getXVehicleAusBObj();
           if( xVehicleAus != null ){
           		if (xVehicleAus.getEObjXVehicleAus().getPrimaryKey() == null) {
               		status = xVehicleAus.validateAdd(level, status);
           		} else  {
               		status = xVehicleAus.validateUpdate(level, status);
           		}
           }

            for (int i = 0; i < getItemsXCustomerVehicleRoleAusBObj().size(); i++) {
                XCustomerVehicleRoleAusBObj xCustomerVehicleRoleAus = (XCustomerVehicleRoleAusBObj) getItemsXCustomerVehicleRoleAusBObj().elementAt(i);
                if (xCustomerVehicleRoleAus.getEObjXCustomerVehicleRoleAus().getPrimaryKey() == null) {
                    status = xCustomerVehicleRoleAus.validateAdd(level, status);
                } else  {
                    status = xCustomerVehicleRoleAus.validateUpdate(level, status);
                }
            }
        }

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            assignBeforeImageValues(metaDataMap);
            
            // MDM_TODO0: CDKWB0041I Add any component-level custom validation logic to be
            // executed for this object during an "update" transaction
        }
        status = getValidationStatus(level, status);
    if (logger.isFinestEnabled()) {
        	String returnValue = status.toString();
      logger.finest("RETURN validateUpdate(int level, DWLStatus status) " + returnValue);
    }
        return status;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Populate the before image of this business object.
     *
     * @see com.dwl.base.DWLCommon#populateBeforeImage()
     * @generated
     */
    public void populateBeforeImage() throws DWLBaseException {
    logger.finest("ENTER populateBeforeImage()");

        DSEAAdditionsExts comp = null;
        try {
        
      comp = (DSEAAdditionsExts)TCRMClassFactory.getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
        	
        } catch (Exception e) {
      if (logger.isFinestEnabled()) {
        String infoForLogging="Error: Fatal error while updating record " + e.getMessage();
      logger.finest("populateBeforeImage() " + infoForLogging);
      }
            DWLExceptionUtils.throwDWLBaseException(e, 
            									new DWLUpdateException(e.getMessage()), 
            									this.getStatus(), DWLStatus.FATAL,
                                  DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_AUS_BOBJ, 
                                  "DIERR",
                                  DSEAAdditionsExtsErrorReasonCode.XCUSTOMERVEHICLEAUS_BEFORE_IMAGE_NOT_POPULATED, 
                                  this.getControl());
        }
        
        comp.loadBeforeImage(this);
    logger.finest("RETURN populateBeforeImage()");
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation common to both add and update transactions.
     *
     * @generated
     */
     
    private DWLStatus getValidationStatus(int level, DWLStatus status) throws Exception {
    logger.finest("ENTER getValidationStatus(int level, DWLStatus status)");

        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0034I Add any common controller-level custom validation
            // logic to be executed for this object during either "add" or
            // "update" transactions
    		controllerValidation_ContId(status);
    		controllerValidation_PurchaseDate(status);
    		controllerValidation_EndDate(status);
    		controllerValidation_SourceIdentifier(status);
    		controllerValidation_LastModifiedSystemDate(status);
    	}

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            // MDM_TODO0: CDKWB0035I Add any common component-level custom validation logic
            // to be executed for this object during either "add" or "update"
            // transactions
    		componentValidation_ContId(status);
    		componentValidation_PurchaseDate(status);
    		componentValidation_EndDate(status);
    		componentValidation_SourceIdentifier(status);
    		componentValidation_LastModifiedSystemDate(status);
        }
        
        if (logger.isFinestEnabled()) {
            String returnValue = status.toString();
      logger.finest("RETURN getValidationStatus(int level, DWLStatus status) " + returnValue);
        }
    
        return status;
    }

    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "ContId"
     *
     * @generated
     */
	private void componentValidation_ContId(DWLStatus status) {
  
            boolean isContIdNull = (eObjXCustomerVehicleAus.getContId() == null);
            if (isContIdNull) {
                DWLError err = createDWLError("XCustomerVehicleAus", "ContId", DSEAAdditionsExtsErrorReasonCode.XCUSTOMERVEHICLEAUS_CONTID_NULL);
                status.addError(err); 
            }
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "PurchaseDate"
     *
     * @generated
     */
	private void componentValidation_PurchaseDate(DWLStatus status) {
  
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "EndDate"
     *
     * @generated
     */
	private void componentValidation_EndDate(DWLStatus status) {
  
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "SourceIdentifier"
     *
     * @generated
     */
	private void componentValidation_SourceIdentifier(DWLStatus status) {
  
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "LastModifiedSystemDate"
     *
     * @generated
     */
	private void componentValidation_LastModifiedSystemDate(DWLStatus status) {
  
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "ContId"
     *
     * @generated
     */
	private void controllerValidation_ContId(DWLStatus status) throws Exception {
  
            boolean isContIdNull = (eObjXCustomerVehicleAus.getContId() == null);
            if (isContIdNull) {
                DWLError err = createDWLError("XCustomerVehicleAus", "ContId", DSEAAdditionsExtsErrorReasonCode.XCUSTOMERVEHICLEAUS_CONTID_NULL);
                status.addError(err); 
            }
    	}
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "PurchaseDate"
     *
     * @generated
     */
	private void controllerValidation_PurchaseDate(DWLStatus status) throws Exception {
  
            boolean isPurchaseDateNull = (eObjXCustomerVehicleAus.getPurchaseDate() == null);
            if (!isValidPurchaseDate) {
              	DWLError err = new DWLError();
               	err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_AUS_BOBJ).longValue());
               	err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XCUSTOMERVEHICLEAUS_PURCHASEDATE).longValue());
               	err.setErrorType(DWLErrorCode.DATA_INVALID_ERROR);
                String infoForLogging="Error: Validation error. Invalid time specified on property PurchaseDate in entity XCustomerVehicleAus, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode();
      logger.finest("controllerValidation_PurchaseDate " + infoForLogging);
               	status.addError(err);
            } 
    	}
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "EndDate"
     *
     * @generated
     */
	private void controllerValidation_EndDate(DWLStatus status) throws Exception {
  
            boolean isEndDateNull = (eObjXCustomerVehicleAus.getEndDate() == null);
            if (!isValidEndDate) {
              	DWLError err = new DWLError();
               	err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_AUS_BOBJ).longValue());
               	err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XCUSTOMERVEHICLEAUS_ENDDATE).longValue());
               	err.setErrorType(DWLErrorCode.DATA_INVALID_ERROR);
                String infoForLogging="Error: Validation error. Invalid time specified on property EndDate in entity XCustomerVehicleAus, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode();
      logger.finest("controllerValidation_EndDate " + infoForLogging);
               	status.addError(err);
            } 
    	}
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "SourceIdentifier"
     *
     * @generated
     */
	private void controllerValidation_SourceIdentifier(DWLStatus status) throws Exception {
  
      //persistent code type
            boolean isSourceIdentifierNull = false;
            if ((eObjXCustomerVehicleAus.getSourceIdentifier() == null) &&
               ((getSourceIdentifierValue() == null) || 
                 getSourceIdentifierValue().trim().equals(""))) {
                isSourceIdentifierNull = true;
            }
            if (!isSourceIdentifierNull) {
                if (checkForInvalidXcustomervehicleausSourceidentifier()) {
                    DWLError err = new DWLError();
                    err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_AUS_BOBJ).longValue());
                    err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XCUSTOMERVEHICLEAUS_SOURCEIDENTIFIER).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                    String infoForLogging="Error: Custom validation error occured for entity XCustomerVehicleAus, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("controllerValidation_SourceIdentifier " + infoForLogging);
        }
                status.addError(err);
            }

             }
    			
    	}
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "LastModifiedSystemDate"
     *
     * @generated
     */
	private void controllerValidation_LastModifiedSystemDate(DWLStatus status) throws Exception {
  
            boolean isLastModifiedSystemDateNull = (eObjXCustomerVehicleAus.getLastModifiedSystemDate() == null);
            if (!isValidLastModifiedSystemDate) {
              	DWLError err = new DWLError();
               	err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_AUS_BOBJ).longValue());
               	err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XCUSTOMERVEHICLEAUS_LASTMODIFIEDSYSTEMDATE).longValue());
               	err.setErrorType(DWLErrorCode.DATA_INVALID_ERROR);
                String infoForLogging="Error: Validation error. Invalid time specified on property LastModifiedSystemDate in entity XCustomerVehicleAus, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode();
      logger.finest("controllerValidation_LastModifiedSystemDate " + infoForLogging);
               	status.addError(err);
            } 
    	}
    private DWLError createDWLError(String entityName, String propertyName,String reasonCode){	
		DWLError err = new DWLError();
		err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_AUS_BOBJ).longValue());
		err.setReasonCode(new Long(reasonCode).longValue());
		err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
			String infoForLogging="Error: Validation error occured. Property " + propertyName + " is null, in entity " + entityName + ", component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
			logger.finest("createDWLError " + infoForLogging);
		}
		return err;
    }
    
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Check the value of the field SourceIdentifier and return true if the
     * error reason INVALID_XCUSTOMERVEHICLEAUS_SOURCEIDENTIFIER should be
     * returned.
     *
     * @generated
  **/
	private boolean checkForInvalidXcustomervehicleausSourceidentifier() throws Exception {
    logger.finest("ENTER checkForInvalidXcustomervehicleausSourceidentifier()");
        boolean notValid = false;
      	String langId = (String) this.getControl().get(DWLControlKeys.LANG_ID);
      	CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
    Long codeType = DWLFunctionUtils.getLongFromString( getSourceIdentifierType() );
    String codeValue = getSourceIdentifierValue();
    if( codeValue != null && codeValue.trim().equals("")){
      codeValue = null;
    }
     
        if ( codeType != null && codeValue == null ){

             if( codeTypeCompHelper.isCodeValid("cdsourceidenttp", langId, getSourceIdentifierType(),
                 CodeTypeComponentHelper.ACTIVE, getControl())) {
                 CodeTypeBObj ctBObj = codeTypeCompHelper
                 					.getCodeTypeByCode("cdsourceidenttp", langId, getSourceIdentifierType(),
                         								getControl());
               	if (ctBObj != null) {
                   	setSourceIdentifierValue( ctBObj.getvalue() );
               	}
             }
             else{
             	if (logger.isFinestEnabled()) {
              	 	String infoForLogging="NotValid 1";
      logger.finest("checkForInvalidXcustomervehicleausSourceidentifier() " + infoForLogging);
        }
                 notValid = true;
           }
        }
        else if (codeType == null && codeValue != null ){
          
             CodeTypeBObj ctBObj = codeTypeCompHelper
                      .getCodeTypeByValue("cdsourceidenttp", langId, codeValue,
                                 getControl());

             if (ctBObj != null) {
                 setSourceIdentifierType(ctBObj.gettp_cd());
             } 
             else {
             	if (logger.isFinestEnabled()) {
              	  	String infoForLogging="NotValid 2";
      logger.finest("checkForInvalidXcustomervehicleausSourceidentifier() " + infoForLogging);
        }
                  notValid = true;
             }
        }
        else if ( codeType != null && codeValue != null
             && !codeTypeCompHelper.isCodeValuePairValid("cdsourceidenttp", langId, getSourceIdentifierType(), 
                     new String[] { codeValue }, CodeTypeComponentHelper.ACTIVE, getControl())) {	
       if (logger.isFinestEnabled()) {
       		String infoForLogging="NotValid 3";
      logger.finest("checkForInvalidXcustomervehicleausSourceidentifier() " + infoForLogging);
       }
             notValid = true;
        }
        if (logger.isFinestEnabled()) {
      String returnValue ="" +notValid;
      logger.finest("RETURN checkForInvalidXcustomervehicleausSourceidentifier() " + returnValue);
    }
    return notValid;
     } 
				 



}

