
/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[755009b289e700e6041185630a48f72a]
 */

package com.ibm.daimler.dsea.component;

import com.dwl.tcrm.common.TCRMCommon;



import com.dwl.base.DWLControl;

import com.dwl.base.constant.DWLControlKeys;
import com.dwl.base.constant.DWLUtilErrorReasonCode;

import com.dwl.base.error.DWLError;
import com.dwl.base.error.DWLErrorCode;
import com.dwl.base.error.DWLStatus;

import com.dwl.base.exception.DWLBaseException;
import com.dwl.base.exception.DWLUpdateException;

import com.dwl.base.util.DWLClassFactory;
import com.dwl.base.util.DWLExceptionUtils;
import com.dwl.base.util.DWLFunctionUtils;

import com.dwl.management.config.client.Configuration;

import com.dwl.tcrm.common.ITCRMValidation;

import com.dwl.tcrm.utilities.DateFormatter;
import com.dwl.tcrm.utilities.DateValidator;
import com.dwl.tcrm.utilities.TCRMClassFactory;

import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsComponentID;
import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsErrorReasonCode;
import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsPropertyKeys;

import com.ibm.daimler.dsea.entityObject.EObjXGurantorIndividual;

import com.ibm.daimler.dsea.interfaces.DSEAAdditionsExts;

import com.ibm.mdm.common.codetype.interfaces.CodeTypeComponentHelper;

import com.ibm.mdm.common.codetype.obj.CodeTypeBObj;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * This class provides the implementation of the business object
 * <code>XGurantorIndividualBObj</code>.
 * 
 * @see com.dwl.tcrm.common.TCRMCommon
 * @generated
 */
 

@SuppressWarnings("serial")
public class XGurantorIndividualBObj extends TCRMCommon  {

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected EObjXGurantorIndividual eObjXGurantorIndividual;
	/**
    * <!-- begin-user-doc -->
	  * <!-- end-user-doc -->
    * @generated 
    */
	 private final static com.dwl.base.logging.IDWLLogger logger = com.dwl.base.logging.DWLLoggerManager.getLogger(XGurantorIndividualBObj.class);
		
 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected String titleValue;
	protected boolean isValidBirthDate = true;
	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected String addressUsageValue;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected String countryValue;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected String sourceIdentifierValue;
	protected boolean isValidStartDate = true;
	
	protected boolean isValidEndDate = true;
	


    protected boolean isValidLastModifiedSystemDate = true;



    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */     
    public XGurantorIndividualBObj() {
        super();
        init();
        eObjXGurantorIndividual = new EObjXGurantorIndividual();
        setComponentID(DSEAAdditionsExtsComponentID.XGURANTOR_INDIVIDUAL_BOBJ);
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Initializes the fields required to populate the metaDataMap. Each key is
     * an element-level field of the business object.
     *
     * @generated
     */
    private void init() {
        metaDataMap.put("XGurantorIndividualpkId", null);
        metaDataMap.put("ContractDetailsId", null);
        metaDataMap.put("BPID", null);
        metaDataMap.put("ABNNumber", null);
        metaDataMap.put("TitleType", null);
        metaDataMap.put("TitleValue", null);
        metaDataMap.put("GivenNameOne", null);
        metaDataMap.put("LastName", null);
        metaDataMap.put("GivenNameOneLocal", null);
        metaDataMap.put("LastNameLocal", null);
        metaDataMap.put("BirthDate", null);
        metaDataMap.put("AddressUsageType", null);
        metaDataMap.put("AddressUsageValue", null);
        metaDataMap.put("AddressLineOne", null);
        metaDataMap.put("AddressLineTwo", null);
        metaDataMap.put("AddressLineThree", null);
        metaDataMap.put("PostalCode", null);
        metaDataMap.put("CityName", null);
        metaDataMap.put("ResidenceNumber", null);
        metaDataMap.put("CountryType", null);
        metaDataMap.put("CountryValue", null);
        metaDataMap.put("BuildingName", null);
        metaDataMap.put("StreetName", null);
        metaDataMap.put("StreetNumber", null);
        metaDataMap.put("MobileNumber", null);
        metaDataMap.put("HomePhoneNumber", null);
        metaDataMap.put("WorkPhoneNumber", null);
        metaDataMap.put("WorkPhoneNumberExtension", null);
        metaDataMap.put("Fax", null);
        metaDataMap.put("Email", null);
        metaDataMap.put("SourceIdentifierType", null);
        metaDataMap.put("SourceIdentifierValue", null);
        metaDataMap.put("StartDate", null);
        metaDataMap.put("EndDate", null);
        metaDataMap.put("LastModifiedSystemDate", null);
        metaDataMap.put("XGurantorIndividualHistActionCode", null);
        metaDataMap.put("XGurantorIndividualHistCreateDate", null);
        metaDataMap.put("XGurantorIndividualHistCreatedBy", null);
        metaDataMap.put("XGurantorIndividualHistEndDate", null);
        metaDataMap.put("XGurantorIndividualHistoryIdPK", null);
        metaDataMap.put("XGurantorIndividualLastUpdateDate", null);
        metaDataMap.put("XGurantorIndividualLastUpdateTxId", null);
        metaDataMap.put("XGurantorIndividualLastUpdateUser", null);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Refreshes all the attributes this business object supports.
     *
     * @see com.dwl.base.DWLCommon#refreshMap()
     * @generated
     */
    public void refreshMap() {

        if (bRequireMapRefresh) {
            super.refreshMap();
            metaDataMap.put("XGurantorIndividualpkId", getXGurantorIndividualpkId());
            metaDataMap.put("ContractDetailsId", getContractDetailsId());
            metaDataMap.put("BPID", getBPID());
            metaDataMap.put("ABNNumber", getABNNumber());
            metaDataMap.put("TitleType", getTitleType());
            metaDataMap.put("TitleValue", getTitleValue());
            metaDataMap.put("GivenNameOne", getGivenNameOne());
            metaDataMap.put("LastName", getLastName());
            metaDataMap.put("GivenNameOneLocal", getGivenNameOneLocal());
            metaDataMap.put("LastNameLocal", getLastNameLocal());
            metaDataMap.put("BirthDate", getBirthDate());
            metaDataMap.put("AddressUsageType", getAddressUsageType());
            metaDataMap.put("AddressUsageValue", getAddressUsageValue());
            metaDataMap.put("AddressLineOne", getAddressLineOne());
            metaDataMap.put("AddressLineTwo", getAddressLineTwo());
            metaDataMap.put("AddressLineThree", getAddressLineThree());
            metaDataMap.put("PostalCode", getPostalCode());
            metaDataMap.put("CityName", getCityName());
            metaDataMap.put("ResidenceNumber", getResidenceNumber());
            metaDataMap.put("CountryType", getCountryType());
            metaDataMap.put("CountryValue", getCountryValue());
            metaDataMap.put("BuildingName", getBuildingName());
            metaDataMap.put("StreetName", getStreetName());
            metaDataMap.put("StreetNumber", getStreetNumber());
            metaDataMap.put("MobileNumber", getMobileNumber());
            metaDataMap.put("HomePhoneNumber", getHomePhoneNumber());
            metaDataMap.put("WorkPhoneNumber", getWorkPhoneNumber());
            metaDataMap.put("WorkPhoneNumberExtension", getWorkPhoneNumberExtension());
            metaDataMap.put("Fax", getFax());
            metaDataMap.put("Email", getEmail());
            metaDataMap.put("SourceIdentifierType", getSourceIdentifierType());
            metaDataMap.put("SourceIdentifierValue", getSourceIdentifierValue());
            metaDataMap.put("StartDate", getStartDate());
            metaDataMap.put("EndDate", getEndDate());
            metaDataMap.put("LastModifiedSystemDate", getLastModifiedSystemDate());
            metaDataMap.put("XGurantorIndividualHistActionCode", getXGurantorIndividualHistActionCode());
            metaDataMap.put("XGurantorIndividualHistCreateDate", getXGurantorIndividualHistCreateDate());
            metaDataMap.put("XGurantorIndividualHistCreatedBy", getXGurantorIndividualHistCreatedBy());
            metaDataMap.put("XGurantorIndividualHistEndDate", getXGurantorIndividualHistEndDate());
            metaDataMap.put("XGurantorIndividualHistoryIdPK", getXGurantorIndividualHistoryIdPK());
            metaDataMap.put("XGurantorIndividualLastUpdateDate", getXGurantorIndividualLastUpdateDate());
            metaDataMap.put("XGurantorIndividualLastUpdateTxId", getXGurantorIndividualLastUpdateTxId());
            metaDataMap.put("XGurantorIndividualLastUpdateUser", getXGurantorIndividualLastUpdateUser());
            bRequireMapRefresh = false;
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the control object on this business object.
     *
     * @see com.dwl.base.DWLCommon#setControl(DWLControl)
     * @generated
     */
    public void setControl(DWLControl newDWLControl) {
        super.setControl(newDWLControl);

        if (eObjXGurantorIndividual != null) {
            eObjXGurantorIndividual.setControl(newDWLControl);
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the entity object associated with this business object.
     *
     * @generated
     */
    public EObjXGurantorIndividual getEObjXGurantorIndividual() {
        bRequireMapRefresh = true;
        return eObjXGurantorIndividual;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the entity object associated with this business object.
     *
     * @param eObjXGurantorIndividual
     *            The eObjXGurantorIndividual to set.
     * @generated
     */
    public void setEObjXGurantorIndividual(EObjXGurantorIndividual eObjXGurantorIndividual) {
        bRequireMapRefresh = true;
        this.eObjXGurantorIndividual = eObjXGurantorIndividual;
        if (this.eObjXGurantorIndividual != null && this.eObjXGurantorIndividual.getControl() == null) {
            DWLControl control = this.getControl();
            if (control != null) {
                this.eObjXGurantorIndividual.setControl(control);
            }
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xGurantorIndividualpkId attribute.
     * 
     * @generated
     */
    public String getXGurantorIndividualpkId (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXGurantorIndividual.getXGurantorIndividualpkId());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xGurantorIndividualpkId attribute.
     * 
     * @param newXGurantorIndividualpkId
     *     The new value of xGurantorIndividualpkId.
     * @generated
     */
    public void setXGurantorIndividualpkId( String newXGurantorIndividualpkId ) throws Exception {
        metaDataMap.put("XGurantorIndividualpkId", newXGurantorIndividualpkId);

        if (newXGurantorIndividualpkId == null || newXGurantorIndividualpkId.equals("")) {
            newXGurantorIndividualpkId = null;


        }
        eObjXGurantorIndividual.setXGurantorIndividualpkId( DWLFunctionUtils.getLongFromString(newXGurantorIndividualpkId) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the contractDetailsId attribute.
     * 
     * @generated
     */
    public String getContractDetailsId (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXGurantorIndividual.getContractDetailsId());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the contractDetailsId attribute.
     * 
     * @param newContractDetailsId
     *     The new value of contractDetailsId.
     * @generated
     */
    public void setContractDetailsId( String newContractDetailsId ) throws Exception {
        metaDataMap.put("ContractDetailsId", newContractDetailsId);

        if (newContractDetailsId == null || newContractDetailsId.equals("")) {
            newContractDetailsId = null;


        }
        eObjXGurantorIndividual.setContractDetailsId( DWLFunctionUtils.getLongFromString(newContractDetailsId) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the bPID attribute.
     * 
     * @generated
     */
    public String getBPID (){
   
        return eObjXGurantorIndividual.getBPID();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the bPID attribute.
     * 
     * @param newBPID
     *     The new value of bPID.
     * @generated
     */
    public void setBPID( String newBPID ) throws Exception {
        metaDataMap.put("BPID", newBPID);

        if (newBPID == null || newBPID.equals("")) {
            newBPID = null;


        }
        eObjXGurantorIndividual.setBPID( newBPID );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the aBNNumber attribute.
     * 
     * @generated
     */
    public String getABNNumber (){
   
        return eObjXGurantorIndividual.getABNNumber();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the aBNNumber attribute.
     * 
     * @param newABNNumber
     *     The new value of aBNNumber.
     * @generated
     */
    public void setABNNumber( String newABNNumber ) throws Exception {
        metaDataMap.put("ABNNumber", newABNNumber);

        if (newABNNumber == null || newABNNumber.equals("")) {
            newABNNumber = null;


        }
        eObjXGurantorIndividual.setABNNumber( newABNNumber );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the titleType attribute.
     * 
     * @generated
     */
    public String getTitleType (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXGurantorIndividual.getTitle());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the titleType attribute.
     * 
     * @param newTitleType
     *     The new value of titleType.
     * @generated
     */
    public void setTitleType( String newTitleType ) throws Exception {
        metaDataMap.put("TitleType", newTitleType);

        if (newTitleType == null || newTitleType.equals("")) {
            newTitleType = null;


        }
        eObjXGurantorIndividual.setTitle( DWLFunctionUtils.getLongFromString(newTitleType) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the titleValue attribute.
     * 
     * @generated
     */
    public String getTitleValue (){
      return titleValue;
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the titleValue attribute.
     * 
     * @param newTitleValue
     *     The new value of titleValue.
     * @generated
     */
    public void setTitleValue( String newTitleValue ) throws Exception {
        metaDataMap.put("TitleValue", newTitleValue);

        if (newTitleValue == null || newTitleValue.equals("")) {
            newTitleValue = null;


        }
        titleValue = newTitleValue;
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the givenNameOne attribute.
     * 
     * @generated
     */
    public String getGivenNameOne (){
   
        return eObjXGurantorIndividual.getGivenNameOne();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the givenNameOne attribute.
     * 
     * @param newGivenNameOne
     *     The new value of givenNameOne.
     * @generated
     */
    public void setGivenNameOne( String newGivenNameOne ) throws Exception {
        metaDataMap.put("GivenNameOne", newGivenNameOne);

        if (newGivenNameOne == null || newGivenNameOne.equals("")) {
            newGivenNameOne = null;


        }
        eObjXGurantorIndividual.setGivenNameOne( newGivenNameOne );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the lastName attribute.
     * 
     * @generated
     */
    public String getLastName (){
   
        return eObjXGurantorIndividual.getLastName();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the lastName attribute.
     * 
     * @param newLastName
     *     The new value of lastName.
     * @generated
     */
    public void setLastName( String newLastName ) throws Exception {
        metaDataMap.put("LastName", newLastName);

        if (newLastName == null || newLastName.equals("")) {
            newLastName = null;


        }
        eObjXGurantorIndividual.setLastName( newLastName );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the givenNameOneLocal attribute.
     * 
     * @generated
     */
    public String getGivenNameOneLocal (){
   
        return eObjXGurantorIndividual.getGivenNameOneLocal();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the givenNameOneLocal attribute.
     * 
     * @param newGivenNameOneLocal
     *     The new value of givenNameOneLocal.
     * @generated
     */
    public void setGivenNameOneLocal( String newGivenNameOneLocal ) throws Exception {
        metaDataMap.put("GivenNameOneLocal", newGivenNameOneLocal);

        if (newGivenNameOneLocal == null || newGivenNameOneLocal.equals("")) {
            newGivenNameOneLocal = null;


        }
        eObjXGurantorIndividual.setGivenNameOneLocal( newGivenNameOneLocal );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the lastNameLocal attribute.
     * 
     * @generated
     */
    public String getLastNameLocal (){
   
        return eObjXGurantorIndividual.getLastNameLocal();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the lastNameLocal attribute.
     * 
     * @param newLastNameLocal
     *     The new value of lastNameLocal.
     * @generated
     */
    public void setLastNameLocal( String newLastNameLocal ) throws Exception {
        metaDataMap.put("LastNameLocal", newLastNameLocal);

        if (newLastNameLocal == null || newLastNameLocal.equals("")) {
            newLastNameLocal = null;


        }
        eObjXGurantorIndividual.setLastNameLocal( newLastNameLocal );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the birthDate attribute.
     * 
     * @generated
     */
    public String getBirthDate (){
   
        return DWLFunctionUtils.getStringFromTimestamp(eObjXGurantorIndividual.getBirthDate());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the birthDate attribute.
     * 
     * @param newBirthDate
     *     The new value of birthDate.
     * @generated
     */
    public void setBirthDate( String newBirthDate ) throws Exception {
        metaDataMap.put("BirthDate", newBirthDate);
       	isValidBirthDate = true;

        if (newBirthDate == null || newBirthDate.equals("")) {
            newBirthDate = null;
            eObjXGurantorIndividual.setBirthDate(null);


        }
    else {
        	if (DateValidator.validates(newBirthDate)) {
           		eObjXGurantorIndividual.setBirthDate(DateFormatter.getStartDateTimestamp(newBirthDate));
            	metaDataMap.put("BirthDate", getBirthDate());
        	} else {
            	if (Configuration.getConfiguration().getConfigItem(
              "/IBM/DWLCommonServices/InternalValidation/enabled").getBooleanValue()) {
                	if (metaDataMap.get("BirthDate") != null) {
                    	metaDataMap.put("BirthDate", "");
                	}
                	isValidBirthDate = false;
                	eObjXGurantorIndividual.setBirthDate(null);
            	}
        	}
        }
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the addressUsageType attribute.
     * 
     * @generated
     */
    public String getAddressUsageType (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXGurantorIndividual.getAddressUsage());
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the addressUsageType attribute.
     * 
     * @param newAddressUsageType
     *     The new value of addressUsageType.
     * @generated
     */
    public void setAddressUsageType( String newAddressUsageType ) throws Exception {
        metaDataMap.put("AddressUsageType", newAddressUsageType);

        if (newAddressUsageType == null || newAddressUsageType.equals("")) {
            newAddressUsageType = null;


        }
        eObjXGurantorIndividual.setAddressUsage( DWLFunctionUtils.getLongFromString(newAddressUsageType) );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the addressUsageValue attribute.
     * 
     * @generated
     */
    public String getAddressUsageValue (){
      return addressUsageValue;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the addressUsageValue attribute.
     * 
     * @param newAddressUsageValue
     *     The new value of addressUsageValue.
     * @generated
     */
    public void setAddressUsageValue( String newAddressUsageValue ) throws Exception {
        metaDataMap.put("AddressUsageValue", newAddressUsageValue);

        if (newAddressUsageValue == null || newAddressUsageValue.equals("")) {
            newAddressUsageValue = null;


        }
        addressUsageValue = newAddressUsageValue;
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the addressLineOne attribute.
     * 
     * @generated
     */
    public String getAddressLineOne (){
   
        return eObjXGurantorIndividual.getAddressLineOne();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the addressLineOne attribute.
     * 
     * @param newAddressLineOne
     *     The new value of addressLineOne.
     * @generated
     */
    public void setAddressLineOne( String newAddressLineOne ) throws Exception {
        metaDataMap.put("AddressLineOne", newAddressLineOne);

        if (newAddressLineOne == null || newAddressLineOne.equals("")) {
            newAddressLineOne = null;


        }
        eObjXGurantorIndividual.setAddressLineOne( newAddressLineOne );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the addressLineTwo attribute.
     * 
     * @generated
     */
    public String getAddressLineTwo (){
   
        return eObjXGurantorIndividual.getAddressLineTwo();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the addressLineTwo attribute.
     * 
     * @param newAddressLineTwo
     *     The new value of addressLineTwo.
     * @generated
     */
    public void setAddressLineTwo( String newAddressLineTwo ) throws Exception {
        metaDataMap.put("AddressLineTwo", newAddressLineTwo);

        if (newAddressLineTwo == null || newAddressLineTwo.equals("")) {
            newAddressLineTwo = null;


        }
        eObjXGurantorIndividual.setAddressLineTwo( newAddressLineTwo );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the addressLineThree attribute.
     * 
     * @generated
     */
    public String getAddressLineThree (){
   
        return eObjXGurantorIndividual.getAddressLineThree();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the addressLineThree attribute.
     * 
     * @param newAddressLineThree
     *     The new value of addressLineThree.
     * @generated
     */
    public void setAddressLineThree( String newAddressLineThree ) throws Exception {
        metaDataMap.put("AddressLineThree", newAddressLineThree);

        if (newAddressLineThree == null || newAddressLineThree.equals("")) {
            newAddressLineThree = null;


        }
        eObjXGurantorIndividual.setAddressLineThree( newAddressLineThree );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the postalCode attribute.
     * 
     * @generated
     */
    public String getPostalCode (){
   
        return eObjXGurantorIndividual.getPostalCode();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the postalCode attribute.
     * 
     * @param newPostalCode
     *     The new value of postalCode.
     * @generated
     */
    public void setPostalCode( String newPostalCode ) throws Exception {
        metaDataMap.put("PostalCode", newPostalCode);

        if (newPostalCode == null || newPostalCode.equals("")) {
            newPostalCode = null;


        }
        eObjXGurantorIndividual.setPostalCode( newPostalCode );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the cityName attribute.
     * 
     * @generated
     */
    public String getCityName (){
   
        return eObjXGurantorIndividual.getCityName();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the cityName attribute.
     * 
     * @param newCityName
     *     The new value of cityName.
     * @generated
     */
    public void setCityName( String newCityName ) throws Exception {
        metaDataMap.put("CityName", newCityName);

        if (newCityName == null || newCityName.equals("")) {
            newCityName = null;


        }
        eObjXGurantorIndividual.setCityName( newCityName );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the residenceNumber attribute.
     * 
     * @generated
     */
    public String getResidenceNumber (){
   
        return eObjXGurantorIndividual.getResidenceNumber();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the residenceNumber attribute.
     * 
     * @param newResidenceNumber
     *     The new value of residenceNumber.
     * @generated
     */
    public void setResidenceNumber( String newResidenceNumber ) throws Exception {
        metaDataMap.put("ResidenceNumber", newResidenceNumber);

        if (newResidenceNumber == null || newResidenceNumber.equals("")) {
            newResidenceNumber = null;


        }
        eObjXGurantorIndividual.setResidenceNumber( newResidenceNumber );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the countryType attribute.
     * 
     * @generated
     */
    public String getCountryType (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXGurantorIndividual.getCountry());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the countryType attribute.
     * 
     * @param newCountryType
     *     The new value of countryType.
     * @generated
     */
    public void setCountryType( String newCountryType ) throws Exception {
        metaDataMap.put("CountryType", newCountryType);

        if (newCountryType == null || newCountryType.equals("")) {
            newCountryType = null;


        }
        eObjXGurantorIndividual.setCountry( DWLFunctionUtils.getLongFromString(newCountryType) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the countryValue attribute.
     * 
     * @generated
     */
    public String getCountryValue (){
      return countryValue;
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the countryValue attribute.
     * 
     * @param newCountryValue
     *     The new value of countryValue.
     * @generated
     */
    public void setCountryValue( String newCountryValue ) throws Exception {
        metaDataMap.put("CountryValue", newCountryValue);

        if (newCountryValue == null || newCountryValue.equals("")) {
            newCountryValue = null;


        }
        countryValue = newCountryValue;
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the buildingName attribute.
     * 
     * @generated
     */
    public String getBuildingName (){
   
        return eObjXGurantorIndividual.getBuildingName();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the buildingName attribute.
     * 
     * @param newBuildingName
     *     The new value of buildingName.
     * @generated
     */
    public void setBuildingName( String newBuildingName ) throws Exception {
        metaDataMap.put("BuildingName", newBuildingName);

        if (newBuildingName == null || newBuildingName.equals("")) {
            newBuildingName = null;


        }
        eObjXGurantorIndividual.setBuildingName( newBuildingName );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the streetName attribute.
     * 
     * @generated
     */
    public String getStreetName (){
   
        return eObjXGurantorIndividual.getStreetName();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the streetName attribute.
     * 
     * @param newStreetName
     *     The new value of streetName.
     * @generated
     */
    public void setStreetName( String newStreetName ) throws Exception {
        metaDataMap.put("StreetName", newStreetName);

        if (newStreetName == null || newStreetName.equals("")) {
            newStreetName = null;


        }
        eObjXGurantorIndividual.setStreetName( newStreetName );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the streetNumber attribute.
     * 
     * @generated
     */
    public String getStreetNumber (){
   
        return eObjXGurantorIndividual.getStreetNumber();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the streetNumber attribute.
     * 
     * @param newStreetNumber
     *     The new value of streetNumber.
     * @generated
     */
    public void setStreetNumber( String newStreetNumber ) throws Exception {
        metaDataMap.put("StreetNumber", newStreetNumber);

        if (newStreetNumber == null || newStreetNumber.equals("")) {
            newStreetNumber = null;


        }
        eObjXGurantorIndividual.setStreetNumber( newStreetNumber );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the mobileNumber attribute.
     * 
     * @generated
     */
    public String getMobileNumber (){
   
        return eObjXGurantorIndividual.getMobileNumber();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the mobileNumber attribute.
     * 
     * @param newMobileNumber
     *     The new value of mobileNumber.
     * @generated
     */
    public void setMobileNumber( String newMobileNumber ) throws Exception {
        metaDataMap.put("MobileNumber", newMobileNumber);

        if (newMobileNumber == null || newMobileNumber.equals("")) {
            newMobileNumber = null;


        }
        eObjXGurantorIndividual.setMobileNumber( newMobileNumber );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the homePhoneNumber attribute.
     * 
     * @generated
     */
    public String getHomePhoneNumber (){
   
        return eObjXGurantorIndividual.getHomePhoneNumber();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the homePhoneNumber attribute.
     * 
     * @param newHomePhoneNumber
     *     The new value of homePhoneNumber.
     * @generated
     */
    public void setHomePhoneNumber( String newHomePhoneNumber ) throws Exception {
        metaDataMap.put("HomePhoneNumber", newHomePhoneNumber);

        if (newHomePhoneNumber == null || newHomePhoneNumber.equals("")) {
            newHomePhoneNumber = null;


        }
        eObjXGurantorIndividual.setHomePhoneNumber( newHomePhoneNumber );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the workPhoneNumber attribute.
     * 
     * @generated
     */
    public String getWorkPhoneNumber (){
   
        return eObjXGurantorIndividual.getWorkPhoneNumber();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the workPhoneNumber attribute.
     * 
     * @param newWorkPhoneNumber
     *     The new value of workPhoneNumber.
     * @generated
     */
    public void setWorkPhoneNumber( String newWorkPhoneNumber ) throws Exception {
        metaDataMap.put("WorkPhoneNumber", newWorkPhoneNumber);

        if (newWorkPhoneNumber == null || newWorkPhoneNumber.equals("")) {
            newWorkPhoneNumber = null;


        }
        eObjXGurantorIndividual.setWorkPhoneNumber( newWorkPhoneNumber );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the workPhoneNumberExtension attribute.
     * 
     * @generated
     */
    public String getWorkPhoneNumberExtension (){
   
        return eObjXGurantorIndividual.getWorkPhoneNumberExtension();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the workPhoneNumberExtension attribute.
     * 
     * @param newWorkPhoneNumberExtension
     *     The new value of workPhoneNumberExtension.
     * @generated
     */
    public void setWorkPhoneNumberExtension( String newWorkPhoneNumberExtension ) throws Exception {
        metaDataMap.put("WorkPhoneNumberExtension", newWorkPhoneNumberExtension);

        if (newWorkPhoneNumberExtension == null || newWorkPhoneNumberExtension.equals("")) {
            newWorkPhoneNumberExtension = null;


        }
        eObjXGurantorIndividual.setWorkPhoneNumberExtension( newWorkPhoneNumberExtension );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the fax attribute.
     * 
     * @generated
     */
    public String getFax (){
   
        return eObjXGurantorIndividual.getFax();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the fax attribute.
     * 
     * @param newFax
     *     The new value of fax.
     * @generated
     */
    public void setFax( String newFax ) throws Exception {
        metaDataMap.put("Fax", newFax);

        if (newFax == null || newFax.equals("")) {
            newFax = null;


        }
        eObjXGurantorIndividual.setFax( newFax );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the sourceIdentifierType attribute.
     * 
     * @generated
     */
    public String getSourceIdentifierType (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXGurantorIndividual.getSourceIdentifier());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the sourceIdentifierType attribute.
     * 
     * @param newSourceIdentifierType
     *     The new value of sourceIdentifierType.
     * @generated
     */
    public void setSourceIdentifierType( String newSourceIdentifierType ) throws Exception {
        metaDataMap.put("SourceIdentifierType", newSourceIdentifierType);

        if (newSourceIdentifierType == null || newSourceIdentifierType.equals("")) {
            newSourceIdentifierType = null;


        }
        eObjXGurantorIndividual.setSourceIdentifier( DWLFunctionUtils.getLongFromString(newSourceIdentifierType) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the sourceIdentifierValue attribute.
     * 
     * @generated
     */
    public String getSourceIdentifierValue (){
      return sourceIdentifierValue;
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the sourceIdentifierValue attribute.
     * 
     * @param newSourceIdentifierValue
     *     The new value of sourceIdentifierValue.
     * @generated
     */
    public void setSourceIdentifierValue( String newSourceIdentifierValue ) throws Exception {
        metaDataMap.put("SourceIdentifierValue", newSourceIdentifierValue);

        if (newSourceIdentifierValue == null || newSourceIdentifierValue.equals("")) {
            newSourceIdentifierValue = null;


        }
        sourceIdentifierValue = newSourceIdentifierValue;
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the email attribute.
     * 
     * @generated
     */
    public String getEmail (){
   
        return eObjXGurantorIndividual.getEmail();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the email attribute.
     * 
     * @param newEmail
     *     The new value of email.
     * @generated
     */
    public void setEmail( String newEmail ) throws Exception {
        metaDataMap.put("Email", newEmail);

        if (newEmail == null || newEmail.equals("")) {
            newEmail = null;


        }
        eObjXGurantorIndividual.setEmail( newEmail );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the startDate attribute.
     * 
     * @generated
     */
    public String getStartDate (){
   
        return DWLFunctionUtils.getStringFromTimestamp(eObjXGurantorIndividual.getStartDate());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the startDate attribute.
     * 
     * @param newStartDate
     *     The new value of startDate.
     * @generated
     */
    public void setStartDate( String newStartDate ) throws Exception {
        metaDataMap.put("StartDate", newStartDate);
       	isValidStartDate = true;

        if (newStartDate == null || newStartDate.equals("")) {
            newStartDate = null;
            eObjXGurantorIndividual.setStartDate(null);


        }
    else {
        	if (DateValidator.validates(newStartDate)) {
           		eObjXGurantorIndividual.setStartDate(DateFormatter.getStartDateTimestamp(newStartDate));
            	metaDataMap.put("StartDate", getStartDate());
        	} else {
            	if (Configuration.getConfiguration().getConfigItem(
              "/IBM/DWLCommonServices/InternalValidation/enabled").getBooleanValue()) {
                	if (metaDataMap.get("StartDate") != null) {
                    	metaDataMap.put("StartDate", "");
                	}
                	isValidStartDate = false;
                	eObjXGurantorIndividual.setStartDate(null);
            	}
        	}
        }
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the endDate attribute.
     * 
     * @generated
     */
    public String getEndDate (){
   
        return DWLFunctionUtils.getStringFromTimestamp(eObjXGurantorIndividual.getEndDate());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the endDate attribute.
     * 
     * @param newEndDate
     *     The new value of endDate.
     * @generated
     */
    public void setEndDate( String newEndDate ) throws Exception {
        metaDataMap.put("EndDate", newEndDate);
       	isValidEndDate = true;

        if (newEndDate == null || newEndDate.equals("")) {
            newEndDate = null;
            eObjXGurantorIndividual.setEndDate(null);


        }
    else {
        	if (DateValidator.validates(newEndDate)) {
           		eObjXGurantorIndividual.setEndDate(DateFormatter.getStartDateTimestamp(newEndDate));
            	metaDataMap.put("EndDate", getEndDate());
        	} else {
            	if (Configuration.getConfiguration().getConfigItem(
              "/IBM/DWLCommonServices/InternalValidation/enabled").getBooleanValue()) {
                	if (metaDataMap.get("EndDate") != null) {
                    	metaDataMap.put("EndDate", "");
                	}
                	isValidEndDate = false;
                	eObjXGurantorIndividual.setEndDate(null);
            	}
        	}
        }
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the lastModifiedSystemDate attribute.
     * 
     * @generated
     */
    public String getLastModifiedSystemDate (){
   
        return DWLFunctionUtils.getStringFromTimestamp(eObjXGurantorIndividual.getLastModifiedSystemDate());
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the lastModifiedSystemDate attribute.
     * 
     * @param newLastModifiedSystemDate
     *     The new value of lastModifiedSystemDate.
     * @generated
     */
    public void setLastModifiedSystemDate( String newLastModifiedSystemDate ) throws Exception {
        metaDataMap.put("LastModifiedSystemDate", newLastModifiedSystemDate);
       	isValidLastModifiedSystemDate = true;

        if (newLastModifiedSystemDate == null || newLastModifiedSystemDate.equals("")) {
            newLastModifiedSystemDate = null;
            eObjXGurantorIndividual.setLastModifiedSystemDate(null);


        }
    else {
        	if (DateValidator.validates(newLastModifiedSystemDate)) {
           		eObjXGurantorIndividual.setLastModifiedSystemDate(DateFormatter.getStartDateTimestamp(newLastModifiedSystemDate));
            	metaDataMap.put("LastModifiedSystemDate", getLastModifiedSystemDate());
        	} else {
            	if (Configuration.getConfiguration().getConfigItem(
              "/IBM/DWLCommonServices/InternalValidation/enabled").getBooleanValue()) {
                	if (metaDataMap.get("LastModifiedSystemDate") != null) {
                    	metaDataMap.put("LastModifiedSystemDate", "");
                	}
                	isValidLastModifiedSystemDate = false;
                	eObjXGurantorIndividual.setLastModifiedSystemDate(null);
            	}
        	}
        }
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateTxId attribute.
     *
     * @generated
     */
    public String getXGurantorIndividualLastUpdateTxId() {
        return DWLFunctionUtils.getStringFromLong(eObjXGurantorIndividual.getLastUpdateTxId());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateUser attribute.
     *
     * @generated
     */
    public String getXGurantorIndividualLastUpdateUser() {
        return eObjXGurantorIndividual.getLastUpdateUser();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateDt attribute.
     *
     * @generated
     */
    public String getXGurantorIndividualLastUpdateDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXGurantorIndividual.getLastUpdateDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateTxId attribute.
     *
     * @param newLastUpdateTxId
     *     The new value of LastUpdateTxId.
     * @generated
     */
    public void setXGurantorIndividualLastUpdateTxId(String newLastUpdateTxId) {
        metaDataMap.put("XGurantorIndividualLastUpdateTxId", newLastUpdateTxId);

        if ((newLastUpdateTxId == null) || newLastUpdateTxId.equals("")) {
            newLastUpdateTxId = null;
        }
        eObjXGurantorIndividual.setLastUpdateTxId(DWLFunctionUtils.getLongFromString(newLastUpdateTxId));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateUser attribute.
     *
     * @param newLastUpdateUser
     *     The new value of LastUpdateUser.
     * @generated
     */
    public void setXGurantorIndividualLastUpdateUser(String newLastUpdateUser) {
        metaDataMap.put("XGurantorIndividualLastUpdateUser", newLastUpdateUser);

        if ((newLastUpdateUser == null) || newLastUpdateUser.equals("")) {
            newLastUpdateUser = null;
        }
        eObjXGurantorIndividual.setLastUpdateUser(newLastUpdateUser);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateDt attribute.
     *
     * @param newLastUpdateDt
     *     The new value of LastUpdateDt.
     * @throws Exception
     * @generated
     */
    public void setXGurantorIndividualLastUpdateDate(String newLastUpdateDt) throws Exception {
        metaDataMap.put("XGurantorIndividualLastUpdateDate", newLastUpdateDt);

        if ((newLastUpdateDt == null) || newLastUpdateDt.equals("")) {
            newLastUpdateDt = null;
        }

        eObjXGurantorIndividual.setLastUpdateDt(DWLFunctionUtils.getTimestampFromTimestampString(newLastUpdateDt));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XGurantorIndividualHistActionCode history attribute.
     *
     * @generated
     */
    public String getXGurantorIndividualHistActionCode() {
        return eObjXGurantorIndividual.getHistActionCode();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XGurantorIndividualHistActionCode history attribute.
     *
     * @param aXGurantorIndividualHistActionCode
     *     The new value of XGurantorIndividualHistActionCode.
     * @generated
     */
    public void setXGurantorIndividualHistActionCode(String aXGurantorIndividualHistActionCode) {
        metaDataMap.put("XGurantorIndividualHistActionCode", aXGurantorIndividualHistActionCode);

        if ((aXGurantorIndividualHistActionCode == null) || aXGurantorIndividualHistActionCode.equals("")) {
            aXGurantorIndividualHistActionCode = null;
        }
        eObjXGurantorIndividual.setHistActionCode(aXGurantorIndividualHistActionCode);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XGurantorIndividualHistCreateDate history attribute.
     *
     * @generated
     */
    public String getXGurantorIndividualHistCreateDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXGurantorIndividual.getHistCreateDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XGurantorIndividualHistCreateDate history attribute.
     *
     * @param aXGurantorIndividualHistCreateDate
     *     The new value of XGurantorIndividualHistCreateDate.
     * @generated
     */
    public void setXGurantorIndividualHistCreateDate(String aXGurantorIndividualHistCreateDate) throws Exception{
        metaDataMap.put("XGurantorIndividualHistCreateDate", aXGurantorIndividualHistCreateDate);

        if ((aXGurantorIndividualHistCreateDate == null) || aXGurantorIndividualHistCreateDate.equals("")) {
            aXGurantorIndividualHistCreateDate = null;
        }

        eObjXGurantorIndividual.setHistCreateDt(DWLFunctionUtils.getTimestampFromTimestampString(aXGurantorIndividualHistCreateDate));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XGurantorIndividualHistCreatedBy history attribute.
     *
     * @generated
     */
    public String getXGurantorIndividualHistCreatedBy() {
        return eObjXGurantorIndividual.getHistCreatedBy();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XGurantorIndividualHistCreatedBy history attribute.
     *
     * @param aXGurantorIndividualHistCreatedBy
     *     The new value of XGurantorIndividualHistCreatedBy.
     * @generated
     */
    public void setXGurantorIndividualHistCreatedBy(String aXGurantorIndividualHistCreatedBy) {
        metaDataMap.put("XGurantorIndividualHistCreatedBy", aXGurantorIndividualHistCreatedBy);

        if ((aXGurantorIndividualHistCreatedBy == null) || aXGurantorIndividualHistCreatedBy.equals("")) {
            aXGurantorIndividualHistCreatedBy = null;
        }

        eObjXGurantorIndividual.setHistCreatedBy(aXGurantorIndividualHistCreatedBy);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XGurantorIndividualHistEndDate history attribute.
     *
     * @generated
     */
    public String getXGurantorIndividualHistEndDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXGurantorIndividual.getHistEndDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XGurantorIndividualHistEndDate history attribute.
     *
     * @param aXGurantorIndividualHistEndDate
     *     The new value of XGurantorIndividualHistEndDate.
     * @generated
     */
    public void setXGurantorIndividualHistEndDate(String aXGurantorIndividualHistEndDate) throws Exception{
        metaDataMap.put("XGurantorIndividualHistEndDate", aXGurantorIndividualHistEndDate);

        if ((aXGurantorIndividualHistEndDate == null) || aXGurantorIndividualHistEndDate.equals("")) {
            aXGurantorIndividualHistEndDate = null;
        }
        eObjXGurantorIndividual.setHistEndDt(DWLFunctionUtils.getTimestampFromTimestampString(aXGurantorIndividualHistEndDate));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XGurantorIndividualHistoryIdPK history attribute.
     *
     * @generated
     */
    public String getXGurantorIndividualHistoryIdPK() {
        return DWLFunctionUtils.getStringFromLong(eObjXGurantorIndividual.getHistoryIdPK());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XGurantorIndividualHistoryIdPK history attribute.
     *
     * @param aXGurantorIndividualHistoryIdPK
     *     The new value of XGurantorIndividualHistoryIdPK.
     * @generated
     */
    public void setXGurantorIndividualHistoryIdPK(String aXGurantorIndividualHistoryIdPK) {
        metaDataMap.put("XGurantorIndividualHistoryIdPK", aXGurantorIndividualHistoryIdPK);

        if ((aXGurantorIndividualHistoryIdPK == null) || aXGurantorIndividualHistoryIdPK.equals("")) {
            aXGurantorIndividualHistoryIdPK = null;
        }
        eObjXGurantorIndividual.setHistoryIdPK(DWLFunctionUtils.getLongFromString(aXGurantorIndividualHistoryIdPK));
    }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation during an add transaction.
     *
     * @generated
     */
    public DWLStatus validateAdd(int level, DWLStatus status) throws Exception {

        status = super.validateAdd(level, status);
        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0038I Add any controller-level custom validation logic to be
            // executed for this object during an "add" transaction

        }

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            // MDM_TODO0: CDKWB0039I Add any component-level custom validation logic to be
            // executed for this object during an "add" transaction
        }
        status = getValidationStatus(level, status);
        return status;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation during an update transaction.
     *
     * @generated
     */
    public DWLStatus validateUpdate(int level, DWLStatus status) throws Exception {
    logger.finest("ENTER validateUpdate(int level, DWLStatus status)");

        status = super.validateUpdate(level, status);
        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0040I Add any controller-level custom validation logic to be
            // executed for this object during an "update" transaction

            if (eObjXGurantorIndividual.getXGurantorIndividualpkId() == null) {
                DWLError err = new DWLError();
                err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XGURANTOR_INDIVIDUAL_BOBJ).longValue());
                err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.XGURANTORINDIVIDUAL_XGURANTORINDIVIDUALPKID_NULL).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                	String infoForLogging="Error: Validation error occured for update. No primary key for entity XGurantorIndividual, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("validateUpdate(int level, DWLStatus status) " + infoForLogging);
                }
                status.addError(err);
            }
            if (eObjXGurantorIndividual.getLastUpdateDt() == null) {
                DWLError err = new DWLError();
                err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XGURANTOR_INDIVIDUAL_BOBJ).longValue());
                err.setReasonCode(new Long(DWLUtilErrorReasonCode.LAST_UPDATED_DATE_NULL).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
                if (logger.isFinestEnabled()) {
                	String infoForLogging="Error: Validation error occured for update. No last update date for entity XGurantorIndividual, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("validateUpdate(int level, DWLStatus status) " + infoForLogging);
                }
                status.addError(err);
            }
        }

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            assignBeforeImageValues(metaDataMap);
            
            // MDM_TODO0: CDKWB0041I Add any component-level custom validation logic to be
            // executed for this object during an "update" transaction
        }
        status = getValidationStatus(level, status);
    if (logger.isFinestEnabled()) {
        	String returnValue = status.toString();
      logger.finest("RETURN validateUpdate(int level, DWLStatus status) " + returnValue);
    }
        return status;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Populate the before image of this business object.
     *
     * @see com.dwl.base.DWLCommon#populateBeforeImage()
     * @generated
     */
    public void populateBeforeImage() throws DWLBaseException {
    logger.finest("ENTER populateBeforeImage()");

        DSEAAdditionsExts comp = null;
        try {
        
      comp = (DSEAAdditionsExts)TCRMClassFactory.getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
        	
        } catch (Exception e) {
      if (logger.isFinestEnabled()) {
        String infoForLogging="Error: Fatal error while updating record " + e.getMessage();
      logger.finest("populateBeforeImage() " + infoForLogging);
      }
            DWLExceptionUtils.throwDWLBaseException(e, 
            									new DWLUpdateException(e.getMessage()), 
            									this.getStatus(), DWLStatus.FATAL,
                                  DSEAAdditionsExtsComponentID.XGURANTOR_INDIVIDUAL_BOBJ, 
                                  "DIERR",
                                  DSEAAdditionsExtsErrorReasonCode.XGURANTORINDIVIDUAL_BEFORE_IMAGE_NOT_POPULATED, 
                                  this.getControl());
        }
        
        comp.loadBeforeImage(this);
    logger.finest("RETURN populateBeforeImage()");
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation common to both add and update transactions.
     *
     * @generated
     */
     
    private DWLStatus getValidationStatus(int level, DWLStatus status) throws Exception {
    logger.finest("ENTER getValidationStatus(int level, DWLStatus status)");

        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0034I Add any common controller-level custom validation
            // logic to be executed for this object during either "add" or
            // "update" transactions
    		controllerValidation_Title(status);
    		controllerValidation_BirthDate(status);
    		controllerValidation_AddressUsage(status);
    		controllerValidation_Country(status);
    		controllerValidation_SourceIdentifier(status);
    		controllerValidation_StartDate(status);
    		controllerValidation_EndDate(status);
    		controllerValidation_LastModifiedSystemDate(status);
    	}

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            // MDM_TODO0: CDKWB0035I Add any common component-level custom validation logic
            // to be executed for this object during either "add" or "update"
            // transactions
    		componentValidation_Title(status);
    		componentValidation_BirthDate(status);
    		componentValidation_AddressUsage(status);
    		componentValidation_Country(status);
    		componentValidation_SourceIdentifier(status);
    		componentValidation_StartDate(status);
    		componentValidation_EndDate(status);
    		componentValidation_LastModifiedSystemDate(status);
        }
        
        if (logger.isFinestEnabled()) {
            String returnValue = status.toString();
      logger.finest("RETURN getValidationStatus(int level, DWLStatus status) " + returnValue);
        }
    
        return status;
    }

    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "Title"
     *
     * @generated
     */
	private void componentValidation_Title(DWLStatus status) {
  
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "BirthDate"
     *
     * @generated
     */
	private void componentValidation_BirthDate(DWLStatus status) {
  
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "AddressUsage"
     *
     * @generated
     */
  private void componentValidation_AddressUsage(DWLStatus status) {
  
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "Country"
     *
     * @generated
     */
	private void componentValidation_Country(DWLStatus status) {
  
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "SourceIdentifier"
     *
     * @generated
     */
	private void componentValidation_SourceIdentifier(DWLStatus status) {
  
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "StartDate"
     *
     * @generated
     */
	private void componentValidation_StartDate(DWLStatus status) {
  
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "EndDate"
     *
     * @generated
     */
	private void componentValidation_EndDate(DWLStatus status) {
  
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "LastModifiedSystemDate"
     *
     * @generated
     */
  private void componentValidation_LastModifiedSystemDate(DWLStatus status) {
  
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "Title"
     *
     * @generated
     */
	private void controllerValidation_Title(DWLStatus status) throws Exception {
  
      //persistent code type
            boolean isTitleNull = false;
            if ((eObjXGurantorIndividual.getTitle() == null) &&
               ((getTitleValue() == null) || 
                 getTitleValue().trim().equals(""))) {
                isTitleNull = true;
            }
            if (!isTitleNull) {
                if (checkForInvalidXgurantorindividualTitle()) {
                    DWLError err = new DWLError();
                    err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XGURANTOR_INDIVIDUAL_BOBJ).longValue());
                    err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XGURANTORINDIVIDUAL_TITLE).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                    String infoForLogging="Error: Custom validation error occured for entity XGurantorIndividual, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("controllerValidation_Title " + infoForLogging);
        }
                status.addError(err);
            }

             }
    			
    	}
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "BirthDate"
     *
     * @generated
     */
	private void controllerValidation_BirthDate(DWLStatus status) throws Exception {
  
            boolean isBirthDateNull = (eObjXGurantorIndividual.getBirthDate() == null);
            if (!isValidBirthDate) {
              	DWLError err = new DWLError();
               	err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XGURANTOR_INDIVIDUAL_BOBJ).longValue());
               	err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XGURANTORINDIVIDUAL_BIRTHDATE).longValue());
               	err.setErrorType(DWLErrorCode.DATA_INVALID_ERROR);
                String infoForLogging="Error: Validation error. Invalid time specified on property BirthDate in entity XGurantorIndividual, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode();
      logger.finest("controllerValidation_BirthDate " + infoForLogging);
               	status.addError(err);
            } 
    	}
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "AddressUsage"
     *
     * @generated
     */
  private void controllerValidation_AddressUsage(DWLStatus status) throws Exception {
  
      //persistent code type
            boolean isAddressUsageNull = false;
            if ((eObjXGurantorIndividual.getAddressUsage() == null) &&
               ((getAddressUsageValue() == null) || 
                 getAddressUsageValue().trim().equals(""))) {
                isAddressUsageNull = true;
            }
            if (!isAddressUsageNull) {
                if (checkForInvalidXgurantorindividualAddressusage()) {
                    DWLError err = new DWLError();
                    err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XGURANTOR_INDIVIDUAL_BOBJ).longValue());
                    err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XGURANTORINDIVIDUAL_ADDRESSUSAGE).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                    String infoForLogging="Error: Custom validation error occured for entity XGurantorIndividual, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("controllerValidation_AddressUsage " + infoForLogging);
        }
                status.addError(err);
            }

             }
    			
    	}


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "Country"
     *
     * @generated
     */
	private void controllerValidation_Country(DWLStatus status) throws Exception {
  
      //persistent code type
            boolean isCountryNull = false;
            if ((eObjXGurantorIndividual.getCountry() == null) &&
               ((getCountryValue() == null) || 
                 getCountryValue().trim().equals(""))) {
                isCountryNull = true;
            }
            if (!isCountryNull) {
                if (checkForInvalidXgurantorindividualCountry()) {
                    DWLError err = new DWLError();
                    err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XGURANTOR_INDIVIDUAL_BOBJ).longValue());
                    err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XGURANTORINDIVIDUAL_COUNTRY).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                    String infoForLogging="Error: Custom validation error occured for entity XGurantorIndividual, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("controllerValidation_Country " + infoForLogging);
        }
                status.addError(err);
            }

             }
    			
    	}
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "SourceIdentifier"
     *
     * @generated
     */
	private void controllerValidation_SourceIdentifier(DWLStatus status) throws Exception {
  
      //persistent code type
            boolean isSourceIdentifierNull = false;
            if ((eObjXGurantorIndividual.getSourceIdentifier() == null) &&
               ((getSourceIdentifierValue() == null) || 
                 getSourceIdentifierValue().trim().equals(""))) {
                isSourceIdentifierNull = true;
            }
            if (!isSourceIdentifierNull) {
                if (checkForInvalidXgurantorindividualSourceidentifier()) {
                    DWLError err = new DWLError();
                    err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XGURANTOR_INDIVIDUAL_BOBJ).longValue());
                    err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XGURANTORINDIVIDUAL_SOURCEIDENTIFIER).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                    String infoForLogging="Error: Custom validation error occured for entity XGurantorIndividual, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("controllerValidation_SourceIdentifier " + infoForLogging);
        }
                status.addError(err);
            }

             }
    			
    	}
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "StartDate"
     *
     * @generated
     */
	private void controllerValidation_StartDate(DWLStatus status) throws Exception {
  
            boolean isStartDateNull = (eObjXGurantorIndividual.getStartDate() == null);
            if (!isValidStartDate) {
              	DWLError err = new DWLError();
               	err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XGURANTOR_INDIVIDUAL_BOBJ).longValue());
               	err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XGURANTORINDIVIDUAL_STARTDATE).longValue());
               	err.setErrorType(DWLErrorCode.DATA_INVALID_ERROR);
                String infoForLogging="Error: Validation error. Invalid time specified on property StartDate in entity XGurantorIndividual, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode();
      logger.finest("controllerValidation_StartDate " + infoForLogging);
               	status.addError(err);
            } 
    	}
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "EndDate"
     *
     * @generated
     */
	private void controllerValidation_EndDate(DWLStatus status) throws Exception {
  
            boolean isEndDateNull = (eObjXGurantorIndividual.getEndDate() == null);
            if (!isValidEndDate) {
              	DWLError err = new DWLError();
               	err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XGURANTOR_INDIVIDUAL_BOBJ).longValue());
               	err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XGURANTORINDIVIDUAL_ENDDATE).longValue());
               	err.setErrorType(DWLErrorCode.DATA_INVALID_ERROR);
                String infoForLogging="Error: Validation error. Invalid time specified on property EndDate in entity XGurantorIndividual, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode();
      logger.finest("controllerValidation_EndDate " + infoForLogging);
               	status.addError(err);
            } 
    	}
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "LastModifiedSystemDate"
     *
     * @generated
     */
  private void controllerValidation_LastModifiedSystemDate(DWLStatus status) throws Exception {
  
            boolean isLastModifiedSystemDateNull = (eObjXGurantorIndividual.getLastModifiedSystemDate() == null);
            if (!isValidLastModifiedSystemDate) {
              	DWLError err = new DWLError();
               	err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XGURANTOR_INDIVIDUAL_BOBJ).longValue());
               	err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XGURANTORINDIVIDUAL_LASTMODIFIEDSYSTEMDATE).longValue());
               	err.setErrorType(DWLErrorCode.DATA_INVALID_ERROR);
                String infoForLogging="Error: Validation error. Invalid time specified on property LastModifiedSystemDate in entity XGurantorIndividual, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode();
      logger.finest("controllerValidation_LastModifiedSystemDate " + infoForLogging);
               	status.addError(err);
            } 
    	}


    private DWLError createDWLError(String entityName, String propertyName,String reasonCode){	
		DWLError err = new DWLError();
		err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XGURANTOR_INDIVIDUAL_BOBJ).longValue());
		err.setReasonCode(new Long(reasonCode).longValue());
		err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
			String infoForLogging="Error: Validation error occured. Property " + propertyName + " is null, in entity " + entityName + ", component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
			logger.finest("createDWLError " + infoForLogging);
		}
		return err;
    }
    
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Check the value of the field Title and return true if the error reason
     * INVALID_XGURANTORINDIVIDUAL_TITLE should be returned.
     *
     * @generated
  **/
	private boolean checkForInvalidXgurantorindividualTitle() throws Exception {
    logger.finest("ENTER checkForInvalidXgurantorindividualTitle()");
        boolean notValid = false;
      	String langId = (String) this.getControl().get(DWLControlKeys.LANG_ID);
      	CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
    Long codeType = DWLFunctionUtils.getLongFromString( getTitleType() );
    String codeValue = getTitleValue();
    if( codeValue != null && codeValue.trim().equals("")){
      codeValue = null;
    }
     
        if ( codeType != null && codeValue == null ){

             if( codeTypeCompHelper.isCodeValid("cdprefixnametp", langId, getTitleType(),
                 CodeTypeComponentHelper.ACTIVE, getControl())) {
                 CodeTypeBObj ctBObj = codeTypeCompHelper
                 					.getCodeTypeByCode("cdprefixnametp", langId, getTitleType(),
                         								getControl());
               	if (ctBObj != null) {
                   	setTitleValue( ctBObj.getvalue() );
               	}
             }
             else{
             	if (logger.isFinestEnabled()) {
              	 	String infoForLogging="NotValid 1";
      logger.finest("checkForInvalidXgurantorindividualTitle() " + infoForLogging);
        }
                 notValid = true;
           }
        }
        else if (codeType == null && codeValue != null ){
          
             CodeTypeBObj ctBObj = codeTypeCompHelper
                      .getCodeTypeByValue("cdprefixnametp", langId, codeValue,
                                 getControl());

             if (ctBObj != null) {
                 setTitleType(ctBObj.gettp_cd());
             } 
             else {
             	if (logger.isFinestEnabled()) {
              	  	String infoForLogging="NotValid 2";
      logger.finest("checkForInvalidXgurantorindividualTitle() " + infoForLogging);
        }
                  notValid = true;
             }
        }
        else if ( codeType != null && codeValue != null
             && !codeTypeCompHelper.isCodeValuePairValid("cdprefixnametp", langId, getTitleType(), 
                     new String[] { codeValue }, CodeTypeComponentHelper.ACTIVE, getControl())) {	
       if (logger.isFinestEnabled()) {
       		String infoForLogging="NotValid 3";
      logger.finest("checkForInvalidXgurantorindividualTitle() " + infoForLogging);
       }
             notValid = true;
        }
        if (logger.isFinestEnabled()) {
      String returnValue ="" +notValid;
      logger.finest("RETURN checkForInvalidXgurantorindividualTitle() " + returnValue);
    }
    return notValid;
     } 
				 
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Check the value of the field AddressUsage and return true if the error
     * reason INVALID_XGURANTORINDIVIDUAL_ADDRESSUSAGE should be returned.
     *
     * @generated
  **/
  private boolean checkForInvalidXgurantorindividualAddressusage() throws Exception {
    logger.finest("ENTER checkForInvalidXgurantorindividualAddressusage()");
        boolean notValid = false;
      	String langId = (String) this.getControl().get(DWLControlKeys.LANG_ID);
      	CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
    Long codeType = DWLFunctionUtils.getLongFromString( getAddressUsageType() );
    String codeValue = getAddressUsageValue();
    if( codeValue != null && codeValue.trim().equals("")){
      codeValue = null;
    }
     
        if ( codeType != null && codeValue == null ){

             if( codeTypeCompHelper.isCodeValid("cdaddrusagetp", langId, getAddressUsageType(),
                 CodeTypeComponentHelper.ACTIVE, getControl())) {
                 CodeTypeBObj ctBObj = codeTypeCompHelper
                 					.getCodeTypeByCode("cdaddrusagetp", langId, getAddressUsageType(),
                         								getControl());
               	if (ctBObj != null) {
                   	setAddressUsageValue( ctBObj.getvalue() );
               	}
             }
             else{
             	if (logger.isFinestEnabled()) {
              	 	String infoForLogging="NotValid 1";
      logger.finest("checkForInvalidXgurantorindividualAddressusage() " + infoForLogging);
        }
                 notValid = true;
           }
        }
        else if (codeType == null && codeValue != null ){
          
             CodeTypeBObj ctBObj = codeTypeCompHelper
                      .getCodeTypeByValue("cdaddrusagetp", langId, codeValue,
                                 getControl());

             if (ctBObj != null) {
                 setAddressUsageType(ctBObj.gettp_cd());
             } 
             else {
             	if (logger.isFinestEnabled()) {
              	  	String infoForLogging="NotValid 2";
      logger.finest("checkForInvalidXgurantorindividualAddressusage() " + infoForLogging);
        }
                  notValid = true;
             }
        }
        else if ( codeType != null && codeValue != null
             && !codeTypeCompHelper.isCodeValuePairValid("cdaddrusagetp", langId, getAddressUsageType(), 
                     new String[] { codeValue }, CodeTypeComponentHelper.ACTIVE, getControl())) {	
       if (logger.isFinestEnabled()) {
       		String infoForLogging="NotValid 3";
      logger.finest("checkForInvalidXgurantorindividualAddressusage() " + infoForLogging);
       }
             notValid = true;
        }
        if (logger.isFinestEnabled()) {
      String returnValue ="" +notValid;
      logger.finest("RETURN checkForInvalidXgurantorindividualAddressusage() " + returnValue);
    }
    return notValid;
     }


  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Check the value of the field Country and return true if the error reason
     * INVALID_XGURANTORINDIVIDUAL_COUNTRY should be returned.
     *
     * @generated
  **/
	private boolean checkForInvalidXgurantorindividualCountry() throws Exception {
    logger.finest("ENTER checkForInvalidXgurantorindividualCountry()");
        boolean notValid = false;
      	String langId = (String) this.getControl().get(DWLControlKeys.LANG_ID);
      	CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
    Long codeType = DWLFunctionUtils.getLongFromString( getCountryType() );
    String codeValue = getCountryValue();
    if( codeValue != null && codeValue.trim().equals("")){
      codeValue = null;
    }
     
        if ( codeType != null && codeValue == null ){

             if( codeTypeCompHelper.isCodeValid("cdcountrytp", langId, getCountryType(),
                 CodeTypeComponentHelper.ACTIVE, getControl())) {
                 CodeTypeBObj ctBObj = codeTypeCompHelper
                 					.getCodeTypeByCode("cdcountrytp", langId, getCountryType(),
                         								getControl());
               	if (ctBObj != null) {
                   	setCountryValue( ctBObj.getvalue() );
               	}
             }
             else{
             	if (logger.isFinestEnabled()) {
              	 	String infoForLogging="NotValid 1";
      logger.finest("checkForInvalidXgurantorindividualCountry() " + infoForLogging);
        }
                 notValid = true;
           }
        }
        else if (codeType == null && codeValue != null ){
          
             CodeTypeBObj ctBObj = codeTypeCompHelper
                      .getCodeTypeByValue("cdcountrytp", langId, codeValue,
                                 getControl());

             if (ctBObj != null) {
                 setCountryType(ctBObj.gettp_cd());
             } 
             else {
             	if (logger.isFinestEnabled()) {
              	  	String infoForLogging="NotValid 2";
      logger.finest("checkForInvalidXgurantorindividualCountry() " + infoForLogging);
        }
                  notValid = true;
             }
        }
        else if ( codeType != null && codeValue != null
             && !codeTypeCompHelper.isCodeValuePairValid("cdcountrytp", langId, getCountryType(), 
                     new String[] { codeValue }, CodeTypeComponentHelper.ACTIVE, getControl())) {	
       if (logger.isFinestEnabled()) {
       		String infoForLogging="NotValid 3";
      logger.finest("checkForInvalidXgurantorindividualCountry() " + infoForLogging);
       }
             notValid = true;
        }
        if (logger.isFinestEnabled()) {
      String returnValue ="" +notValid;
      logger.finest("RETURN checkForInvalidXgurantorindividualCountry() " + returnValue);
    }
    return notValid;
     } 
				 
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Check the value of the field SourceIdentifier and return true if the
     * error reason INVALID_XGURANTORINDIVIDUAL_SOURCEIDENTIFIER should be
     * returned.
     *
     * @generated
  **/
	private boolean checkForInvalidXgurantorindividualSourceidentifier() throws Exception {
    logger.finest("ENTER checkForInvalidXgurantorindividualSourceidentifier()");
        boolean notValid = false;
      	String langId = (String) this.getControl().get(DWLControlKeys.LANG_ID);
      	CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
    Long codeType = DWLFunctionUtils.getLongFromString( getSourceIdentifierType() );
    String codeValue = getSourceIdentifierValue();
    if( codeValue != null && codeValue.trim().equals("")){
      codeValue = null;
    }
     
        if ( codeType != null && codeValue == null ){

             if( codeTypeCompHelper.isCodeValid("cdsourceidenttp", langId, getSourceIdentifierType(),
                 CodeTypeComponentHelper.ACTIVE, getControl())) {
                 CodeTypeBObj ctBObj = codeTypeCompHelper
                 					.getCodeTypeByCode("cdsourceidenttp", langId, getSourceIdentifierType(),
                         								getControl());
               	if (ctBObj != null) {
                   	setSourceIdentifierValue( ctBObj.getvalue() );
               	}
             }
             else{
             	if (logger.isFinestEnabled()) {
              	 	String infoForLogging="NotValid 1";
      logger.finest("checkForInvalidXgurantorindividualSourceidentifier() " + infoForLogging);
        }
                 notValid = true;
           }
        }
        else if (codeType == null && codeValue != null ){
          
             CodeTypeBObj ctBObj = codeTypeCompHelper
                      .getCodeTypeByValue("cdsourceidenttp", langId, codeValue,
                                 getControl());

             if (ctBObj != null) {
                 setSourceIdentifierType(ctBObj.gettp_cd());
             } 
             else {
             	if (logger.isFinestEnabled()) {
              	  	String infoForLogging="NotValid 2";
      logger.finest("checkForInvalidXgurantorindividualSourceidentifier() " + infoForLogging);
        }
                  notValid = true;
             }
        }
        else if ( codeType != null && codeValue != null
             && !codeTypeCompHelper.isCodeValuePairValid("cdsourceidenttp", langId, getSourceIdentifierType(), 
                     new String[] { codeValue }, CodeTypeComponentHelper.ACTIVE, getControl())) {	
       if (logger.isFinestEnabled()) {
       		String infoForLogging="NotValid 3";
      logger.finest("checkForInvalidXgurantorindividualSourceidentifier() " + infoForLogging);
       }
             notValid = true;
        }
        if (logger.isFinestEnabled()) {
      String returnValue ="" +notValid;
      logger.finest("RETURN checkForInvalidXgurantorindividualSourceidentifier() " + returnValue);
    }
    return notValid;
     } 
				 



}

