
/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[cf1e87c85b76faa90eb1de5523fb1a51]
 */

package com.ibm.daimler.dsea.component;

import com.dwl.tcrm.common.TCRMCommon;



import com.dwl.base.DWLControl;

import com.dwl.base.constant.DWLControlKeys;
import com.dwl.base.constant.DWLUtilErrorReasonCode;

import com.dwl.base.error.DWLError;
import com.dwl.base.error.DWLErrorCode;
import com.dwl.base.error.DWLStatus;

import com.dwl.base.exception.DWLBaseException;
import com.dwl.base.exception.DWLUpdateException;

import com.dwl.base.util.DWLClassFactory;
import com.dwl.base.util.DWLExceptionUtils;
import com.dwl.base.util.DWLFunctionUtils;

import com.dwl.management.config.client.Configuration;

import com.dwl.tcrm.common.ITCRMValidation;

import com.dwl.tcrm.utilities.DateFormatter;
import com.dwl.tcrm.utilities.DateValidator;
import com.dwl.tcrm.utilities.TCRMClassFactory;

import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsComponentID;
import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsErrorReasonCode;
import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsPropertyKeys;

import com.ibm.daimler.dsea.entityObject.EObjXDataSharing;

import com.ibm.daimler.dsea.interfaces.DSEAAdditionsExts;

import com.ibm.mdm.common.codetype.interfaces.CodeTypeComponentHelper;

import com.ibm.mdm.common.codetype.obj.CodeTypeBObj;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * This class provides the implementation of the business object
 * <code>XDataSharingBObj</code>.
 * 
 * @see com.dwl.tcrm.common.TCRMCommon
 * @generated
 */
 

@SuppressWarnings("serial")
public class XDataSharingBObj extends TCRMCommon  {

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected EObjXDataSharing eObjXDataSharing;
	/**
    * <!-- begin-user-doc -->
	  * <!-- end-user-doc -->
    * @generated 
    */
	 private final static com.dwl.base.logging.IDWLLogger logger = com.dwl.base.logging.DWLLoggerManager.getLogger(XDataSharingBObj.class);
		
 
    protected boolean isValidGCUpdateDate = true;
  protected boolean isValidWSDataSharingUpdateDate = true;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected String sourceIdentifierValue;
	protected boolean isValidStartDate = true;
	
	protected boolean isValidLastModifiedSystemDate = true;
	


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */     
    public XDataSharingBObj() {
        super();
        init();
        eObjXDataSharing = new EObjXDataSharing();
        setComponentID(DSEAAdditionsExtsComponentID.XDATA_SHARING_BOBJ);
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Initializes the fields required to populate the metaDataMap. Each key is
     * an element-level field of the business object.
     *
     * @generated
     */
    private void init() {
        metaDataMap.put("DataSharingpkId", null);
        metaDataMap.put("DataSharingFlag", null);
        metaDataMap.put("ContId", null);
        metaDataMap.put("CustomerMergeInd", null);
        metaDataMap.put("GCUpdateDate", null);
        metaDataMap.put("DataSharingWholesale", null);
        metaDataMap.put("WSDataSharingUpdateDate", null);
        metaDataMap.put("RetailerId", null);
        metaDataMap.put("RetailerFlag", null);
        metaDataMap.put("SourceIdentifierType", null);
        metaDataMap.put("SourceIdentifierValue", null);
        metaDataMap.put("StartDate", null);
        metaDataMap.put("LastModifiedSystemDate", null);
        metaDataMap.put("XDataSharingHistActionCode", null);
        metaDataMap.put("XDataSharingHistCreateDate", null);
        metaDataMap.put("XDataSharingHistCreatedBy", null);
        metaDataMap.put("XDataSharingHistEndDate", null);
        metaDataMap.put("XDataSharingHistoryIdPK", null);
        metaDataMap.put("XDataSharingLastUpdateDate", null);
        metaDataMap.put("XDataSharingLastUpdateTxId", null);
        metaDataMap.put("XDataSharingLastUpdateUser", null);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Refreshes all the attributes this business object supports.
     *
     * @see com.dwl.base.DWLCommon#refreshMap()
     * @generated
     */
    public void refreshMap() {

        if (bRequireMapRefresh) {
            super.refreshMap();
            metaDataMap.put("DataSharingpkId", getDataSharingpkId());
            metaDataMap.put("DataSharingFlag", getDataSharingFlag());
            metaDataMap.put("ContId", getContId());
            metaDataMap.put("CustomerMergeInd", getCustomerMergeInd());
            metaDataMap.put("GCUpdateDate", getGCUpdateDate());
            metaDataMap.put("DataSharingWholesale", getDataSharingWholesale());
            metaDataMap.put("WSDataSharingUpdateDate", getWSDataSharingUpdateDate());
            metaDataMap.put("RetailerId", getRetailerId());
            metaDataMap.put("RetailerFlag", getRetailerFlag());
            metaDataMap.put("SourceIdentifierType", getSourceIdentifierType());
            metaDataMap.put("SourceIdentifierValue", getSourceIdentifierValue());
            metaDataMap.put("StartDate", getStartDate());
            metaDataMap.put("LastModifiedSystemDate", getLastModifiedSystemDate());
            metaDataMap.put("XDataSharingHistActionCode", getXDataSharingHistActionCode());
            metaDataMap.put("XDataSharingHistCreateDate", getXDataSharingHistCreateDate());
            metaDataMap.put("XDataSharingHistCreatedBy", getXDataSharingHistCreatedBy());
            metaDataMap.put("XDataSharingHistEndDate", getXDataSharingHistEndDate());
            metaDataMap.put("XDataSharingHistoryIdPK", getXDataSharingHistoryIdPK());
            metaDataMap.put("XDataSharingLastUpdateDate", getXDataSharingLastUpdateDate());
            metaDataMap.put("XDataSharingLastUpdateTxId", getXDataSharingLastUpdateTxId());
            metaDataMap.put("XDataSharingLastUpdateUser", getXDataSharingLastUpdateUser());
            bRequireMapRefresh = false;
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the control object on this business object.
     *
     * @see com.dwl.base.DWLCommon#setControl(DWLControl)
     * @generated
     */
    public void setControl(DWLControl newDWLControl) {
        super.setControl(newDWLControl);

        if (eObjXDataSharing != null) {
            eObjXDataSharing.setControl(newDWLControl);
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the entity object associated with this business object.
     *
     * @generated
     */
    public EObjXDataSharing getEObjXDataSharing() {
        bRequireMapRefresh = true;
        return eObjXDataSharing;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the entity object associated with this business object.
     *
     * @param eObjXDataSharing
     *            The eObjXDataSharing to set.
     * @generated
     */
    public void setEObjXDataSharing(EObjXDataSharing eObjXDataSharing) {
        bRequireMapRefresh = true;
        this.eObjXDataSharing = eObjXDataSharing;
        if (this.eObjXDataSharing != null && this.eObjXDataSharing.getControl() == null) {
            DWLControl control = this.getControl();
            if (control != null) {
                this.eObjXDataSharing.setControl(control);
            }
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the dataSharingpkId attribute.
     * 
     * @generated
     */
    public String getDataSharingpkId (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXDataSharing.getDataSharingpkId());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the dataSharingpkId attribute.
     * 
     * @param newDataSharingpkId
     *     The new value of dataSharingpkId.
     * @generated
     */
    public void setDataSharingpkId( String newDataSharingpkId ) throws Exception {
        metaDataMap.put("DataSharingpkId", newDataSharingpkId);

        if (newDataSharingpkId == null || newDataSharingpkId.equals("")) {
            newDataSharingpkId = null;


        }
        eObjXDataSharing.setDataSharingpkId( DWLFunctionUtils.getLongFromString(newDataSharingpkId) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the dataSharingFlag attribute.
     * 
     * @generated
     */
    public String getDataSharingFlag (){
   
        return eObjXDataSharing.getDataSharingFlag();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the dataSharingFlag attribute.
     * 
     * @param newDataSharingFlag
     *     The new value of dataSharingFlag.
     * @generated
     */
    public void setDataSharingFlag( String newDataSharingFlag ) throws Exception {
        metaDataMap.put("DataSharingFlag", newDataSharingFlag);

        if (newDataSharingFlag == null || newDataSharingFlag.equals("")) {
            newDataSharingFlag = null;


        }
        eObjXDataSharing.setDataSharingFlag( newDataSharingFlag );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the contId attribute.
     * 
     * @generated
     */
    public String getContId (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXDataSharing.getContId());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the contId attribute.
     * 
     * @param newContId
     *     The new value of contId.
     * @generated
     */
    public void setContId( String newContId ) throws Exception {
        metaDataMap.put("ContId", newContId);

        if (newContId == null || newContId.equals("")) {
            newContId = null;


        }
        eObjXDataSharing.setContId( DWLFunctionUtils.getLongFromString(newContId) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the customerMergeInd attribute.
     * 
     * @generated
     */
    public String getCustomerMergeInd (){
   
        return eObjXDataSharing.getCustomerMergeInd();
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the customerMergeInd attribute.
     * 
     * @param newCustomerMergeInd
     *     The new value of customerMergeInd.
     * @generated
     */
    public void setCustomerMergeInd( String newCustomerMergeInd ) throws Exception {
        metaDataMap.put("CustomerMergeInd", newCustomerMergeInd);

        if (newCustomerMergeInd == null || newCustomerMergeInd.equals("")) {
            newCustomerMergeInd = null;


        }
        eObjXDataSharing.setCustomerMergeInd( newCustomerMergeInd );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the gCUpdateDate attribute.
     * 
     * @generated
     */
    public String getGCUpdateDate (){
   
        return DWLFunctionUtils.getStringFromTimestamp(eObjXDataSharing.getGCUpdateDate());
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the gCUpdateDate attribute.
     * 
     * @param newGCUpdateDate
     *     The new value of gCUpdateDate.
     * @generated
     */
    public void setGCUpdateDate( String newGCUpdateDate ) throws Exception {
        metaDataMap.put("GCUpdateDate", newGCUpdateDate);
       	isValidGCUpdateDate = true;

        if (newGCUpdateDate == null || newGCUpdateDate.equals("")) {
            newGCUpdateDate = null;
            eObjXDataSharing.setGCUpdateDate(null);


        }
    else {
        	if (DateValidator.validates(newGCUpdateDate)) {
           		eObjXDataSharing.setGCUpdateDate(DateFormatter.getStartDateTimestamp(newGCUpdateDate));
            	metaDataMap.put("GCUpdateDate", getGCUpdateDate());
        	} else {
            	if (Configuration.getConfiguration().getConfigItem(
              "/IBM/DWLCommonServices/InternalValidation/enabled").getBooleanValue()) {
                	if (metaDataMap.get("GCUpdateDate") != null) {
                    	metaDataMap.put("GCUpdateDate", "");
                	}
                	isValidGCUpdateDate = false;
                	eObjXDataSharing.setGCUpdateDate(null);
            	}
        	}
        }
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the dataSharingWholesale attribute.
     * 
     * @generated
     */
    public String getDataSharingWholesale (){
   
        return eObjXDataSharing.getDataSharingWholesale();
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the dataSharingWholesale attribute.
     * 
     * @param newDataSharingWholesale
     *     The new value of dataSharingWholesale.
     * @generated
     */
    public void setDataSharingWholesale( String newDataSharingWholesale ) throws Exception {
        metaDataMap.put("DataSharingWholesale", newDataSharingWholesale);

        if (newDataSharingWholesale == null || newDataSharingWholesale.equals("")) {
            newDataSharingWholesale = null;


        }
        eObjXDataSharing.setDataSharingWholesale( newDataSharingWholesale );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the wSDataSharingUpdateDate attribute.
     * 
     * @generated
     */
    public String getWSDataSharingUpdateDate (){
   
        return DWLFunctionUtils.getStringFromTimestamp(eObjXDataSharing.getWSDataSharingUpdateDate());
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the wSDataSharingUpdateDate attribute.
     * 
     * @param newWSDataSharingUpdateDate
     *     The new value of wSDataSharingUpdateDate.
     * @generated
     */
    public void setWSDataSharingUpdateDate( String newWSDataSharingUpdateDate ) throws Exception {
        metaDataMap.put("WSDataSharingUpdateDate", newWSDataSharingUpdateDate);
       	isValidWSDataSharingUpdateDate = true;

        if (newWSDataSharingUpdateDate == null || newWSDataSharingUpdateDate.equals("")) {
            newWSDataSharingUpdateDate = null;
            eObjXDataSharing.setWSDataSharingUpdateDate(null);


        }
    else {
        	if (DateValidator.validates(newWSDataSharingUpdateDate)) {
           		eObjXDataSharing.setWSDataSharingUpdateDate(DateFormatter.getStartDateTimestamp(newWSDataSharingUpdateDate));
            	metaDataMap.put("WSDataSharingUpdateDate", getWSDataSharingUpdateDate());
        	} else {
            	if (Configuration.getConfiguration().getConfigItem(
              "/IBM/DWLCommonServices/InternalValidation/enabled").getBooleanValue()) {
                	if (metaDataMap.get("WSDataSharingUpdateDate") != null) {
                    	metaDataMap.put("WSDataSharingUpdateDate", "");
                	}
                	isValidWSDataSharingUpdateDate = false;
                	eObjXDataSharing.setWSDataSharingUpdateDate(null);
            	}
        	}
        }
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the retailerId attribute.
     * 
     * @generated
     */
    public String getRetailerId (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXDataSharing.getRetailerId());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the retailerId attribute.
     * 
     * @param newRetailerId
     *     The new value of retailerId.
     * @generated
     */
    public void setRetailerId( String newRetailerId ) throws Exception {
        metaDataMap.put("RetailerId", newRetailerId);

        if (newRetailerId == null || newRetailerId.equals("")) {
            newRetailerId = null;


        }
        eObjXDataSharing.setRetailerId( DWLFunctionUtils.getLongFromString(newRetailerId) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the retailerFlag attribute.
     * 
     * @generated
     */
    public String getRetailerFlag (){
   
        return eObjXDataSharing.getRetailerFlag();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the retailerFlag attribute.
     * 
     * @param newRetailerFlag
     *     The new value of retailerFlag.
     * @generated
     */
    public void setRetailerFlag( String newRetailerFlag ) throws Exception {
        metaDataMap.put("RetailerFlag", newRetailerFlag);

        if (newRetailerFlag == null || newRetailerFlag.equals("")) {
            newRetailerFlag = null;


        }
        eObjXDataSharing.setRetailerFlag( newRetailerFlag );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the sourceIdentifierType attribute.
     * 
     * @generated
     */
    public String getSourceIdentifierType (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXDataSharing.getSourceIdentifier());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the sourceIdentifierType attribute.
     * 
     * @param newSourceIdentifierType
     *     The new value of sourceIdentifierType.
     * @generated
     */
    public void setSourceIdentifierType( String newSourceIdentifierType ) throws Exception {
        metaDataMap.put("SourceIdentifierType", newSourceIdentifierType);

        if (newSourceIdentifierType == null || newSourceIdentifierType.equals("")) {
            newSourceIdentifierType = null;


        }
        eObjXDataSharing.setSourceIdentifier( DWLFunctionUtils.getLongFromString(newSourceIdentifierType) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the sourceIdentifierValue attribute.
     * 
     * @generated
     */
    public String getSourceIdentifierValue (){
      return sourceIdentifierValue;
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the sourceIdentifierValue attribute.
     * 
     * @param newSourceIdentifierValue
     *     The new value of sourceIdentifierValue.
     * @generated
     */
    public void setSourceIdentifierValue( String newSourceIdentifierValue ) throws Exception {
        metaDataMap.put("SourceIdentifierValue", newSourceIdentifierValue);

        if (newSourceIdentifierValue == null || newSourceIdentifierValue.equals("")) {
            newSourceIdentifierValue = null;


        }
        sourceIdentifierValue = newSourceIdentifierValue;
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the startDate attribute.
     * 
     * @generated
     */
    public String getStartDate (){
   
        return DWLFunctionUtils.getStringFromTimestamp(eObjXDataSharing.getStartDate());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the startDate attribute.
     * 
     * @param newStartDate
     *     The new value of startDate.
     * @generated
     */
    public void setStartDate( String newStartDate ) throws Exception {
        metaDataMap.put("StartDate", newStartDate);
       	isValidStartDate = true;

        if (newStartDate == null || newStartDate.equals("")) {
            newStartDate = null;
            eObjXDataSharing.setStartDate(null);


        }
    else {
        	if (DateValidator.validates(newStartDate)) {
           		eObjXDataSharing.setStartDate(DateFormatter.getStartDateTimestamp(newStartDate));
            	metaDataMap.put("StartDate", getStartDate());
        	} else {
            	if (Configuration.getConfiguration().getConfigItem(
              "/IBM/DWLCommonServices/InternalValidation/enabled").getBooleanValue()) {
                	if (metaDataMap.get("StartDate") != null) {
                    	metaDataMap.put("StartDate", "");
                	}
                	isValidStartDate = false;
                	eObjXDataSharing.setStartDate(null);
            	}
        	}
        }
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the lastModifiedSystemDate attribute.
     * 
     * @generated
     */
    public String getLastModifiedSystemDate (){
   
        return DWLFunctionUtils.getStringFromTimestamp(eObjXDataSharing.getLastModifiedSystemDate());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the lastModifiedSystemDate attribute.
     * 
     * @param newLastModifiedSystemDate
     *     The new value of lastModifiedSystemDate.
     * @generated
     */
    public void setLastModifiedSystemDate( String newLastModifiedSystemDate ) throws Exception {
        metaDataMap.put("LastModifiedSystemDate", newLastModifiedSystemDate);
       	isValidLastModifiedSystemDate = true;

        if (newLastModifiedSystemDate == null || newLastModifiedSystemDate.equals("")) {
            newLastModifiedSystemDate = null;
            eObjXDataSharing.setLastModifiedSystemDate(null);


        }
    else {
        	if (DateValidator.validates(newLastModifiedSystemDate)) {
           		eObjXDataSharing.setLastModifiedSystemDate(DateFormatter.getStartDateTimestamp(newLastModifiedSystemDate));
            	metaDataMap.put("LastModifiedSystemDate", getLastModifiedSystemDate());
        	} else {
            	if (Configuration.getConfiguration().getConfigItem(
              "/IBM/DWLCommonServices/InternalValidation/enabled").getBooleanValue()) {
                	if (metaDataMap.get("LastModifiedSystemDate") != null) {
                    	metaDataMap.put("LastModifiedSystemDate", "");
                	}
                	isValidLastModifiedSystemDate = false;
                	eObjXDataSharing.setLastModifiedSystemDate(null);
            	}
        	}
        }
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateTxId attribute.
     *
     * @generated
     */
    public String getXDataSharingLastUpdateTxId() {
        return DWLFunctionUtils.getStringFromLong(eObjXDataSharing.getLastUpdateTxId());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateUser attribute.
     *
     * @generated
     */
    public String getXDataSharingLastUpdateUser() {
        return eObjXDataSharing.getLastUpdateUser();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateDt attribute.
     *
     * @generated
     */
    public String getXDataSharingLastUpdateDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXDataSharing.getLastUpdateDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateTxId attribute.
     *
     * @param newLastUpdateTxId
     *     The new value of LastUpdateTxId.
     * @generated
     */
    public void setXDataSharingLastUpdateTxId(String newLastUpdateTxId) {
        metaDataMap.put("XDataSharingLastUpdateTxId", newLastUpdateTxId);

        if ((newLastUpdateTxId == null) || newLastUpdateTxId.equals("")) {
            newLastUpdateTxId = null;
        }
        eObjXDataSharing.setLastUpdateTxId(DWLFunctionUtils.getLongFromString(newLastUpdateTxId));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateUser attribute.
     *
     * @param newLastUpdateUser
     *     The new value of LastUpdateUser.
     * @generated
     */
    public void setXDataSharingLastUpdateUser(String newLastUpdateUser) {
        metaDataMap.put("XDataSharingLastUpdateUser", newLastUpdateUser);

        if ((newLastUpdateUser == null) || newLastUpdateUser.equals("")) {
            newLastUpdateUser = null;
        }
        eObjXDataSharing.setLastUpdateUser(newLastUpdateUser);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateDt attribute.
     *
     * @param newLastUpdateDt
     *     The new value of LastUpdateDt.
     * @throws Exception
     * @generated
     */
    public void setXDataSharingLastUpdateDate(String newLastUpdateDt) throws Exception {
        metaDataMap.put("XDataSharingLastUpdateDate", newLastUpdateDt);

        if ((newLastUpdateDt == null) || newLastUpdateDt.equals("")) {
            newLastUpdateDt = null;
        }

        eObjXDataSharing.setLastUpdateDt(DWLFunctionUtils.getTimestampFromTimestampString(newLastUpdateDt));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XDataSharingHistActionCode history attribute.
     *
     * @generated
     */
    public String getXDataSharingHistActionCode() {
        return eObjXDataSharing.getHistActionCode();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XDataSharingHistActionCode history attribute.
     *
     * @param aXDataSharingHistActionCode
     *     The new value of XDataSharingHistActionCode.
     * @generated
     */
    public void setXDataSharingHistActionCode(String aXDataSharingHistActionCode) {
        metaDataMap.put("XDataSharingHistActionCode", aXDataSharingHistActionCode);

        if ((aXDataSharingHistActionCode == null) || aXDataSharingHistActionCode.equals("")) {
            aXDataSharingHistActionCode = null;
        }
        eObjXDataSharing.setHistActionCode(aXDataSharingHistActionCode);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XDataSharingHistCreateDate history attribute.
     *
     * @generated
     */
    public String getXDataSharingHistCreateDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXDataSharing.getHistCreateDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XDataSharingHistCreateDate history attribute.
     *
     * @param aXDataSharingHistCreateDate
     *     The new value of XDataSharingHistCreateDate.
     * @generated
     */
    public void setXDataSharingHistCreateDate(String aXDataSharingHistCreateDate) throws Exception{
        metaDataMap.put("XDataSharingHistCreateDate", aXDataSharingHistCreateDate);

        if ((aXDataSharingHistCreateDate == null) || aXDataSharingHistCreateDate.equals("")) {
            aXDataSharingHistCreateDate = null;
        }

        eObjXDataSharing.setHistCreateDt(DWLFunctionUtils.getTimestampFromTimestampString(aXDataSharingHistCreateDate));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XDataSharingHistCreatedBy history attribute.
     *
     * @generated
     */
    public String getXDataSharingHistCreatedBy() {
        return eObjXDataSharing.getHistCreatedBy();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XDataSharingHistCreatedBy history attribute.
     *
     * @param aXDataSharingHistCreatedBy
     *     The new value of XDataSharingHistCreatedBy.
     * @generated
     */
    public void setXDataSharingHistCreatedBy(String aXDataSharingHistCreatedBy) {
        metaDataMap.put("XDataSharingHistCreatedBy", aXDataSharingHistCreatedBy);

        if ((aXDataSharingHistCreatedBy == null) || aXDataSharingHistCreatedBy.equals("")) {
            aXDataSharingHistCreatedBy = null;
        }

        eObjXDataSharing.setHistCreatedBy(aXDataSharingHistCreatedBy);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XDataSharingHistEndDate history attribute.
     *
     * @generated
     */
    public String getXDataSharingHistEndDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXDataSharing.getHistEndDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XDataSharingHistEndDate history attribute.
     *
     * @param aXDataSharingHistEndDate
     *     The new value of XDataSharingHistEndDate.
     * @generated
     */
    public void setXDataSharingHistEndDate(String aXDataSharingHistEndDate) throws Exception{
        metaDataMap.put("XDataSharingHistEndDate", aXDataSharingHistEndDate);

        if ((aXDataSharingHistEndDate == null) || aXDataSharingHistEndDate.equals("")) {
            aXDataSharingHistEndDate = null;
        }
        eObjXDataSharing.setHistEndDt(DWLFunctionUtils.getTimestampFromTimestampString(aXDataSharingHistEndDate));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XDataSharingHistoryIdPK history attribute.
     *
     * @generated
     */
    public String getXDataSharingHistoryIdPK() {
        return DWLFunctionUtils.getStringFromLong(eObjXDataSharing.getHistoryIdPK());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XDataSharingHistoryIdPK history attribute.
     *
     * @param aXDataSharingHistoryIdPK
     *     The new value of XDataSharingHistoryIdPK.
     * @generated
     */
    public void setXDataSharingHistoryIdPK(String aXDataSharingHistoryIdPK) {
        metaDataMap.put("XDataSharingHistoryIdPK", aXDataSharingHistoryIdPK);

        if ((aXDataSharingHistoryIdPK == null) || aXDataSharingHistoryIdPK.equals("")) {
            aXDataSharingHistoryIdPK = null;
        }
        eObjXDataSharing.setHistoryIdPK(DWLFunctionUtils.getLongFromString(aXDataSharingHistoryIdPK));
    }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation during an add transaction.
     *
     * @generated
     */
    public DWLStatus validateAdd(int level, DWLStatus status) throws Exception {

        status = super.validateAdd(level, status);
        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0038I Add any controller-level custom validation logic to be
            // executed for this object during an "add" transaction

        }

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            // MDM_TODO0: CDKWB0039I Add any component-level custom validation logic to be
            // executed for this object during an "add" transaction
        }
        status = getValidationStatus(level, status);
        return status;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation during an update transaction.
     *
     * @generated
     */
    public DWLStatus validateUpdate(int level, DWLStatus status) throws Exception {
    logger.finest("ENTER validateUpdate(int level, DWLStatus status)");

        status = super.validateUpdate(level, status);
        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0040I Add any controller-level custom validation logic to be
            // executed for this object during an "update" transaction

            if (eObjXDataSharing.getDataSharingpkId() == null) {
                DWLError err = new DWLError();
                err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XDATA_SHARING_BOBJ).longValue());
                err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.XDATASHARING_DATASHARINGPKID_NULL).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                	String infoForLogging="Error: Validation error occured for update. No primary key for entity XDataSharing, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("validateUpdate(int level, DWLStatus status) " + infoForLogging);
                }
                status.addError(err);
            }
            if (eObjXDataSharing.getLastUpdateDt() == null) {
                DWLError err = new DWLError();
                err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XDATA_SHARING_BOBJ).longValue());
                err.setReasonCode(new Long(DWLUtilErrorReasonCode.LAST_UPDATED_DATE_NULL).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
                if (logger.isFinestEnabled()) {
                	String infoForLogging="Error: Validation error occured for update. No last update date for entity XDataSharing, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("validateUpdate(int level, DWLStatus status) " + infoForLogging);
                }
                status.addError(err);
            }
        }

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            assignBeforeImageValues(metaDataMap);
            
            // MDM_TODO0: CDKWB0041I Add any component-level custom validation logic to be
            // executed for this object during an "update" transaction
        }
        status = getValidationStatus(level, status);
    if (logger.isFinestEnabled()) {
        	String returnValue = status.toString();
      logger.finest("RETURN validateUpdate(int level, DWLStatus status) " + returnValue);
    }
        return status;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Populate the before image of this business object.
     *
     * @see com.dwl.base.DWLCommon#populateBeforeImage()
     * @generated
     */
    public void populateBeforeImage() throws DWLBaseException {
    logger.finest("ENTER populateBeforeImage()");

        DSEAAdditionsExts comp = null;
        try {
        
      comp = (DSEAAdditionsExts)TCRMClassFactory.getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
        	
        } catch (Exception e) {
      if (logger.isFinestEnabled()) {
        String infoForLogging="Error: Fatal error while updating record " + e.getMessage();
      logger.finest("populateBeforeImage() " + infoForLogging);
      }
            DWLExceptionUtils.throwDWLBaseException(e, 
            									new DWLUpdateException(e.getMessage()), 
            									this.getStatus(), DWLStatus.FATAL,
                                  DSEAAdditionsExtsComponentID.XDATA_SHARING_BOBJ, 
                                  "DIERR",
                                  DSEAAdditionsExtsErrorReasonCode.XDATASHARING_BEFORE_IMAGE_NOT_POPULATED, 
                                  this.getControl());
        }
        
        comp.loadBeforeImage(this);
    logger.finest("RETURN populateBeforeImage()");
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation common to both add and update transactions.
     *
     * @generated
     */
     
    private DWLStatus getValidationStatus(int level, DWLStatus status) throws Exception {
    logger.finest("ENTER getValidationStatus(int level, DWLStatus status)");

        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0034I Add any common controller-level custom validation
            // logic to be executed for this object during either "add" or
            // "update" transactions
    		controllerValidation_GCUpdateDate(status);
    		controllerValidation_WSDataSharingUpdateDate(status);
    		controllerValidation_SourceIdentifier(status);
    		controllerValidation_StartDate(status);
    		controllerValidation_LastModifiedSystemDate(status);
    	}

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            // MDM_TODO0: CDKWB0035I Add any common component-level custom validation logic
            // to be executed for this object during either "add" or "update"
            // transactions
    		componentValidation_GCUpdateDate(status);
    		componentValidation_WSDataSharingUpdateDate(status);
    		componentValidation_SourceIdentifier(status);
    		componentValidation_StartDate(status);
    		componentValidation_LastModifiedSystemDate(status);
        }
        
        if (logger.isFinestEnabled()) {
            String returnValue = status.toString();
      logger.finest("RETURN getValidationStatus(int level, DWLStatus status) " + returnValue);
        }
    
        return status;
    }

    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "GCUpdateDate"
     *
     * @generated
     */
  private void componentValidation_GCUpdateDate(DWLStatus status) {
  
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "WSDataSharingUpdateDate"
     *
     * @generated
     */
  private void componentValidation_WSDataSharingUpdateDate(DWLStatus status) {
  
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "SourceIdentifier"
     *
     * @generated
     */
	private void componentValidation_SourceIdentifier(DWLStatus status) {
  
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "StartDate"
     *
     * @generated
     */
	private void componentValidation_StartDate(DWLStatus status) {
  
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "LastModifiedSystemDate"
     *
     * @generated
     */
	private void componentValidation_LastModifiedSystemDate(DWLStatus status) {
  
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "GCUpdateDate"
     *
     * @generated
     */
  private void controllerValidation_GCUpdateDate(DWLStatus status) throws Exception {
  
            boolean isGCUpdateDateNull = (eObjXDataSharing.getGCUpdateDate() == null);
            if (!isValidGCUpdateDate) {
              	DWLError err = new DWLError();
               	err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XDATA_SHARING_BOBJ).longValue());
               	err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XDATASHARING_GCUPDATEDATE).longValue());
               	err.setErrorType(DWLErrorCode.DATA_INVALID_ERROR);
                String infoForLogging="Error: Validation error. Invalid time specified on property GCUpdateDate in entity XDataSharing, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode();
      logger.finest("controllerValidation_GCUpdateDate " + infoForLogging);
               	status.addError(err);
            } 
    	}


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "WSDataSharingUpdateDate"
     *
     * @generated
     */
  private void controllerValidation_WSDataSharingUpdateDate(DWLStatus status) throws Exception {
  
            boolean isWSDataSharingUpdateDateNull = (eObjXDataSharing.getWSDataSharingUpdateDate() == null);
            if (!isValidWSDataSharingUpdateDate) {
              	DWLError err = new DWLError();
               	err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XDATA_SHARING_BOBJ).longValue());
               	err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XDATASHARING_WSDATASHARINGUPDATEDATE).longValue());
               	err.setErrorType(DWLErrorCode.DATA_INVALID_ERROR);
                String infoForLogging="Error: Validation error. Invalid time specified on property WSDataSharingUpdateDate in entity XDataSharing, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode();
      logger.finest("controllerValidation_WSDataSharingUpdateDate " + infoForLogging);
               	status.addError(err);
            } 
    	}


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "SourceIdentifier"
     *
     * @generated
     */
	private void controllerValidation_SourceIdentifier(DWLStatus status) throws Exception {
  
      //persistent code type
            boolean isSourceIdentifierNull = false;
            if ((eObjXDataSharing.getSourceIdentifier() == null) &&
               ((getSourceIdentifierValue() == null) || 
                 getSourceIdentifierValue().trim().equals(""))) {
                isSourceIdentifierNull = true;
            }
            if (!isSourceIdentifierNull) {
                if (checkForInvalidXdatasharingSourceidentifier()) {
                    DWLError err = new DWLError();
                    err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XDATA_SHARING_BOBJ).longValue());
                    err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XDATASHARING_SOURCEIDENTIFIER).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                    String infoForLogging="Error: Custom validation error occured for entity XDataSharing, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("controllerValidation_SourceIdentifier " + infoForLogging);
        }
                status.addError(err);
            }

             }
    			
    	}
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "StartDate"
     *
     * @generated
     */
	private void controllerValidation_StartDate(DWLStatus status) throws Exception {
  
            boolean isStartDateNull = (eObjXDataSharing.getStartDate() == null);
            if (!isValidStartDate) {
              	DWLError err = new DWLError();
               	err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XDATA_SHARING_BOBJ).longValue());
               	err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XDATASHARING_STARTDATE).longValue());
               	err.setErrorType(DWLErrorCode.DATA_INVALID_ERROR);
                String infoForLogging="Error: Validation error. Invalid time specified on property StartDate in entity XDataSharing, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode();
      logger.finest("controllerValidation_StartDate " + infoForLogging);
               	status.addError(err);
            } 
    	}
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "LastModifiedSystemDate"
     *
     * @generated
     */
	private void controllerValidation_LastModifiedSystemDate(DWLStatus status) throws Exception {
  
            boolean isLastModifiedSystemDateNull = (eObjXDataSharing.getLastModifiedSystemDate() == null);
            if (!isValidLastModifiedSystemDate) {
              	DWLError err = new DWLError();
               	err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XDATA_SHARING_BOBJ).longValue());
               	err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XDATASHARING_LASTMODIFIEDSYSTEMDATE).longValue());
               	err.setErrorType(DWLErrorCode.DATA_INVALID_ERROR);
                String infoForLogging="Error: Validation error. Invalid time specified on property LastModifiedSystemDate in entity XDataSharing, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode();
      logger.finest("controllerValidation_LastModifiedSystemDate " + infoForLogging);
               	status.addError(err);
            } 
    	}
    private DWLError createDWLError(String entityName, String propertyName,String reasonCode){	
		DWLError err = new DWLError();
		err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XDATA_SHARING_BOBJ).longValue());
		err.setReasonCode(new Long(reasonCode).longValue());
		err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
			String infoForLogging="Error: Validation error occured. Property " + propertyName + " is null, in entity " + entityName + ", component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
			logger.finest("createDWLError " + infoForLogging);
		}
		return err;
    }
    
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Check the value of the field SourceIdentifier and return true if the
     * error reason INVALID_XDATASHARING_SOURCEIDENTIFIER should be returned.
     *
     * @generated
  **/
	private boolean checkForInvalidXdatasharingSourceidentifier() throws Exception {
    logger.finest("ENTER checkForInvalidXdatasharingSourceidentifier()");
        boolean notValid = false;
      	String langId = (String) this.getControl().get(DWLControlKeys.LANG_ID);
      	CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
    Long codeType = DWLFunctionUtils.getLongFromString( getSourceIdentifierType() );
    String codeValue = getSourceIdentifierValue();
    if( codeValue != null && codeValue.trim().equals("")){
      codeValue = null;
    }
     
        if ( codeType != null && codeValue == null ){

             if( codeTypeCompHelper.isCodeValid("cdsourceidenttp", langId, getSourceIdentifierType(),
                 CodeTypeComponentHelper.ACTIVE, getControl())) {
                 CodeTypeBObj ctBObj = codeTypeCompHelper
                 					.getCodeTypeByCode("cdsourceidenttp", langId, getSourceIdentifierType(),
                         								getControl());
               	if (ctBObj != null) {
                   	setSourceIdentifierValue( ctBObj.getvalue() );
               	}
             }
             else{
             	if (logger.isFinestEnabled()) {
              	 	String infoForLogging="NotValid 1";
      logger.finest("checkForInvalidXdatasharingSourceidentifier() " + infoForLogging);
        }
                 notValid = true;
           }
        }
        else if (codeType == null && codeValue != null ){
          
             CodeTypeBObj ctBObj = codeTypeCompHelper
                      .getCodeTypeByValue("cdsourceidenttp", langId, codeValue,
                                 getControl());

             if (ctBObj != null) {
                 setSourceIdentifierType(ctBObj.gettp_cd());
             } 
             else {
             	if (logger.isFinestEnabled()) {
              	  	String infoForLogging="NotValid 2";
      logger.finest("checkForInvalidXdatasharingSourceidentifier() " + infoForLogging);
        }
                  notValid = true;
             }
        }
        else if ( codeType != null && codeValue != null
             && !codeTypeCompHelper.isCodeValuePairValid("cdsourceidenttp", langId, getSourceIdentifierType(), 
                     new String[] { codeValue }, CodeTypeComponentHelper.ACTIVE, getControl())) {	
       if (logger.isFinestEnabled()) {
       		String infoForLogging="NotValid 3";
      logger.finest("checkForInvalidXdatasharingSourceidentifier() " + infoForLogging);
       }
             notValid = true;
        }
        if (logger.isFinestEnabled()) {
      String returnValue ="" +notValid;
      logger.finest("RETURN checkForInvalidXdatasharingSourceidentifier() " + returnValue);
    }
    return notValid;
     } 
				 



}

