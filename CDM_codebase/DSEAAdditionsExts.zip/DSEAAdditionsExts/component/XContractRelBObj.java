
/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[4133144b614d8f053bce46698f8d7c02]
 */

package com.ibm.daimler.dsea.component;

import com.dwl.tcrm.common.TCRMCommon;



import com.dwl.base.DWLControl;

import com.dwl.base.constant.DWLUtilErrorReasonCode;

import com.dwl.base.error.DWLError;
import com.dwl.base.error.DWLErrorCode;
import com.dwl.base.error.DWLStatus;

import com.dwl.base.exception.DWLBaseException;
import com.dwl.base.exception.DWLUpdateException;

import com.dwl.base.util.DWLExceptionUtils;
import com.dwl.base.util.DWLFunctionUtils;

import com.dwl.management.config.client.Configuration;

import com.dwl.tcrm.common.ITCRMValidation;

import com.dwl.tcrm.utilities.DateFormatter;
import com.dwl.tcrm.utilities.DateValidator;
import com.dwl.tcrm.utilities.TCRMClassFactory;

import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsComponentID;
import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsErrorReasonCode;
import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsPropertyKeys;

import com.ibm.daimler.dsea.entityObject.EObjXContractRel;

import com.ibm.daimler.dsea.interfaces.DSEAAdditionsExts;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * This class provides the implementation of the business object
 * <code>XContractRelBObj</code>.
 * 
 * @see com.dwl.tcrm.common.TCRMCommon
 * @generated
 */
 

@SuppressWarnings("serial")
public class XContractRelBObj extends TCRMCommon  {

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected EObjXContractRel eObjXContractRel;
	/**
    * <!-- begin-user-doc -->
	  * <!-- end-user-doc -->
    * @generated 
    */
	 private final static com.dwl.base.logging.IDWLLogger logger = com.dwl.base.logging.DWLLoggerManager.getLogger(XContractRelBObj.class);
		
 
	protected boolean isValidStartDate = true;
	
	protected boolean isValidEndDate = true;
	


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */     
    public XContractRelBObj() {
        super();
        init();
        eObjXContractRel = new EObjXContractRel();
        setComponentID(DSEAAdditionsExtsComponentID.XCONTRACT_REL_BOBJ);
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Initializes the fields required to populate the metaDataMap. Each key is
     * an element-level field of the business object.
     *
     * @generated
     */
    private void init() {
        metaDataMap.put("XContractRelpkId", null);
        metaDataMap.put("ContractId", null);
        metaDataMap.put("ContId", null);
        metaDataMap.put("Market", null);
        metaDataMap.put("PersonOrgCode", null);
        metaDataMap.put("ContractRole", null);
        metaDataMap.put("StartDate", null);
        metaDataMap.put("EndDate", null);
        metaDataMap.put("X_BPID", null);
        metaDataMap.put("XContractRelHistActionCode", null);
        metaDataMap.put("XContractRelHistCreateDate", null);
        metaDataMap.put("XContractRelHistCreatedBy", null);
        metaDataMap.put("XContractRelHistEndDate", null);
        metaDataMap.put("XContractRelHistoryIdPK", null);
        metaDataMap.put("XContractRelLastUpdateDate", null);
        metaDataMap.put("XContractRelLastUpdateTxId", null);
        metaDataMap.put("XContractRelLastUpdateUser", null);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Refreshes all the attributes this business object supports.
     *
     * @see com.dwl.base.DWLCommon#refreshMap()
     * @generated
     */
    public void refreshMap() {

        if (bRequireMapRefresh) {
            super.refreshMap();
            metaDataMap.put("XContractRelpkId", getXContractRelpkId());
            metaDataMap.put("ContractId", getContractId());
            metaDataMap.put("ContId", getContId());
            metaDataMap.put("Market", getMarket());
            metaDataMap.put("PersonOrgCode", getPersonOrgCode());
            metaDataMap.put("ContractRole", getContractRole());
            metaDataMap.put("StartDate", getStartDate());
            metaDataMap.put("EndDate", getEndDate());
            metaDataMap.put("X_BPID", getX_BPID());
            metaDataMap.put("XContractRelHistActionCode", getXContractRelHistActionCode());
            metaDataMap.put("XContractRelHistCreateDate", getXContractRelHistCreateDate());
            metaDataMap.put("XContractRelHistCreatedBy", getXContractRelHistCreatedBy());
            metaDataMap.put("XContractRelHistEndDate", getXContractRelHistEndDate());
            metaDataMap.put("XContractRelHistoryIdPK", getXContractRelHistoryIdPK());
            metaDataMap.put("XContractRelLastUpdateDate", getXContractRelLastUpdateDate());
            metaDataMap.put("XContractRelLastUpdateTxId", getXContractRelLastUpdateTxId());
            metaDataMap.put("XContractRelLastUpdateUser", getXContractRelLastUpdateUser());
            bRequireMapRefresh = false;
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the control object on this business object.
     *
     * @see com.dwl.base.DWLCommon#setControl(DWLControl)
     * @generated
     */
    public void setControl(DWLControl newDWLControl) {
        super.setControl(newDWLControl);

        if (eObjXContractRel != null) {
            eObjXContractRel.setControl(newDWLControl);
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the entity object associated with this business object.
     *
     * @generated
     */
    public EObjXContractRel getEObjXContractRel() {
        bRequireMapRefresh = true;
        return eObjXContractRel;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the entity object associated with this business object.
     *
     * @param eObjXContractRel
     *            The eObjXContractRel to set.
     * @generated
     */
    public void setEObjXContractRel(EObjXContractRel eObjXContractRel) {
        bRequireMapRefresh = true;
        this.eObjXContractRel = eObjXContractRel;
        if (this.eObjXContractRel != null && this.eObjXContractRel.getControl() == null) {
            DWLControl control = this.getControl();
            if (control != null) {
                this.eObjXContractRel.setControl(control);
            }
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xContractRelpkId attribute.
     * 
     * @generated
     */
    public String getXContractRelpkId (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXContractRel.getXContractRelpkId());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xContractRelpkId attribute.
     * 
     * @param newXContractRelpkId
     *     The new value of xContractRelpkId.
     * @generated
     */
    public void setXContractRelpkId( String newXContractRelpkId ) throws Exception {
        metaDataMap.put("XContractRelpkId", newXContractRelpkId);

        if (newXContractRelpkId == null || newXContractRelpkId.equals("")) {
            newXContractRelpkId = null;


        }
        eObjXContractRel.setXContractRelpkId( DWLFunctionUtils.getLongFromString(newXContractRelpkId) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the contractId attribute.
     * 
     * @generated
     */
    public String getContractId (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXContractRel.getContractId());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the contractId attribute.
     * 
     * @param newContractId
     *     The new value of contractId.
     * @generated
     */
    public void setContractId( String newContractId ) throws Exception {
        metaDataMap.put("ContractId", newContractId);

        if (newContractId == null || newContractId.equals("")) {
            newContractId = null;


        }
        eObjXContractRel.setContractId( DWLFunctionUtils.getLongFromString(newContractId) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the contId attribute.
     * 
     * @generated
     */
    public String getContId (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXContractRel.getContId());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the contId attribute.
     * 
     * @param newContId
     *     The new value of contId.
     * @generated
     */
    public void setContId( String newContId ) throws Exception {
        metaDataMap.put("ContId", newContId);

        if (newContId == null || newContId.equals("")) {
            newContId = null;


        }
        eObjXContractRel.setContId( DWLFunctionUtils.getLongFromString(newContId) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the market attribute.
     * 
     * @generated
     */
    public String getMarket (){
   
        return eObjXContractRel.getMarket();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the market attribute.
     * 
     * @param newMarket
     *     The new value of market.
     * @generated
     */
    public void setMarket( String newMarket ) throws Exception {
        metaDataMap.put("Market", newMarket);

        if (newMarket == null || newMarket.equals("")) {
            newMarket = null;


        }
        eObjXContractRel.setMarket( newMarket );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the personOrgCode attribute.
     * 
     * @generated
     */
    public String getPersonOrgCode (){
   
        return eObjXContractRel.getPersonOrgCode();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the personOrgCode attribute.
     * 
     * @param newPersonOrgCode
     *     The new value of personOrgCode.
     * @generated
     */
    public void setPersonOrgCode( String newPersonOrgCode ) throws Exception {
        metaDataMap.put("PersonOrgCode", newPersonOrgCode);

        if (newPersonOrgCode == null || newPersonOrgCode.equals("")) {
            newPersonOrgCode = null;


        }
        eObjXContractRel.setPersonOrgCode( newPersonOrgCode );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the contractRole attribute.
     * 
     * @generated
     */
    public String getContractRole (){
   
        return eObjXContractRel.getContractRole();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the contractRole attribute.
     * 
     * @param newContractRole
     *     The new value of contractRole.
     * @generated
     */
    public void setContractRole( String newContractRole ) throws Exception {
        metaDataMap.put("ContractRole", newContractRole);

        if (newContractRole == null || newContractRole.equals("")) {
            newContractRole = null;


        }
        eObjXContractRel.setContractRole( newContractRole );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the startDate attribute.
     * 
     * @generated
     */
    public String getStartDate (){
   
        return DWLFunctionUtils.getStringFromTimestamp(eObjXContractRel.getStartDate());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the startDate attribute.
     * 
     * @param newStartDate
     *     The new value of startDate.
     * @generated
     */
    public void setStartDate( String newStartDate ) throws Exception {
        metaDataMap.put("StartDate", newStartDate);
       	isValidStartDate = true;

        if (newStartDate == null || newStartDate.equals("")) {
            newStartDate = null;
            eObjXContractRel.setStartDate(null);


        }
    else {
        	if (DateValidator.validates(newStartDate)) {
           		eObjXContractRel.setStartDate(DateFormatter.getStartDateTimestamp(newStartDate));
            	metaDataMap.put("StartDate", getStartDate());
        	} else {
            	if (Configuration.getConfiguration().getConfigItem(
              "/IBM/DWLCommonServices/InternalValidation/enabled").getBooleanValue()) {
                	if (metaDataMap.get("StartDate") != null) {
                    	metaDataMap.put("StartDate", "");
                	}
                	isValidStartDate = false;
                	eObjXContractRel.setStartDate(null);
            	}
        	}
        }
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the endDate attribute.
     * 
     * @generated
     */
    public String getEndDate (){
   
        return DWLFunctionUtils.getStringFromTimestamp(eObjXContractRel.getEndDate());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the endDate attribute.
     * 
     * @param newEndDate
     *     The new value of endDate.
     * @generated
     */
    public void setEndDate( String newEndDate ) throws Exception {
        metaDataMap.put("EndDate", newEndDate);
       	isValidEndDate = true;

        if (newEndDate == null || newEndDate.equals("")) {
            newEndDate = null;
            eObjXContractRel.setEndDate(null);


        }
    else {
        	if (DateValidator.validates(newEndDate)) {
           		eObjXContractRel.setEndDate(DateFormatter.getStartDateTimestamp(newEndDate));
            	metaDataMap.put("EndDate", getEndDate());
        	} else {
            	if (Configuration.getConfiguration().getConfigItem(
              "/IBM/DWLCommonServices/InternalValidation/enabled").getBooleanValue()) {
                	if (metaDataMap.get("EndDate") != null) {
                    	metaDataMap.put("EndDate", "");
                	}
                	isValidEndDate = false;
                	eObjXContractRel.setEndDate(null);
            	}
        	}
        }
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the x_BPID attribute.
     * 
     * @generated
     */
    public String getX_BPID (){
   
        return eObjXContractRel.getX_BPID();
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the x_BPID attribute.
     * 
     * @param newX_BPID
     *     The new value of x_BPID.
     * @generated
     */
    public void setX_BPID( String newX_BPID ) throws Exception {
        metaDataMap.put("X_BPID", newX_BPID);

        if (newX_BPID == null || newX_BPID.equals("")) {
            newX_BPID = null;


        }
        eObjXContractRel.setX_BPID( newX_BPID );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateTxId attribute.
     *
     * @generated
     */
    public String getXContractRelLastUpdateTxId() {
        return DWLFunctionUtils.getStringFromLong(eObjXContractRel.getLastUpdateTxId());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateUser attribute.
     *
     * @generated
     */
    public String getXContractRelLastUpdateUser() {
        return eObjXContractRel.getLastUpdateUser();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateDt attribute.
     *
     * @generated
     */
    public String getXContractRelLastUpdateDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXContractRel.getLastUpdateDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateTxId attribute.
     *
     * @param newLastUpdateTxId
     *     The new value of LastUpdateTxId.
     * @generated
     */
    public void setXContractRelLastUpdateTxId(String newLastUpdateTxId) {
        metaDataMap.put("XContractRelLastUpdateTxId", newLastUpdateTxId);

        if ((newLastUpdateTxId == null) || newLastUpdateTxId.equals("")) {
            newLastUpdateTxId = null;
        }
        eObjXContractRel.setLastUpdateTxId(DWLFunctionUtils.getLongFromString(newLastUpdateTxId));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateUser attribute.
     *
     * @param newLastUpdateUser
     *     The new value of LastUpdateUser.
     * @generated
     */
    public void setXContractRelLastUpdateUser(String newLastUpdateUser) {
        metaDataMap.put("XContractRelLastUpdateUser", newLastUpdateUser);

        if ((newLastUpdateUser == null) || newLastUpdateUser.equals("")) {
            newLastUpdateUser = null;
        }
        eObjXContractRel.setLastUpdateUser(newLastUpdateUser);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateDt attribute.
     *
     * @param newLastUpdateDt
     *     The new value of LastUpdateDt.
     * @throws Exception
     * @generated
     */
    public void setXContractRelLastUpdateDate(String newLastUpdateDt) throws Exception {
        metaDataMap.put("XContractRelLastUpdateDate", newLastUpdateDt);

        if ((newLastUpdateDt == null) || newLastUpdateDt.equals("")) {
            newLastUpdateDt = null;
        }

        eObjXContractRel.setLastUpdateDt(DWLFunctionUtils.getTimestampFromTimestampString(newLastUpdateDt));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XContractRelHistActionCode history attribute.
     *
     * @generated
     */
    public String getXContractRelHistActionCode() {
        return eObjXContractRel.getHistActionCode();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XContractRelHistActionCode history attribute.
     *
     * @param aXContractRelHistActionCode
     *     The new value of XContractRelHistActionCode.
     * @generated
     */
    public void setXContractRelHistActionCode(String aXContractRelHistActionCode) {
        metaDataMap.put("XContractRelHistActionCode", aXContractRelHistActionCode);

        if ((aXContractRelHistActionCode == null) || aXContractRelHistActionCode.equals("")) {
            aXContractRelHistActionCode = null;
        }
        eObjXContractRel.setHistActionCode(aXContractRelHistActionCode);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XContractRelHistCreateDate history attribute.
     *
     * @generated
     */
    public String getXContractRelHistCreateDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXContractRel.getHistCreateDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XContractRelHistCreateDate history attribute.
     *
     * @param aXContractRelHistCreateDate
     *     The new value of XContractRelHistCreateDate.
     * @generated
     */
    public void setXContractRelHistCreateDate(String aXContractRelHistCreateDate) throws Exception{
        metaDataMap.put("XContractRelHistCreateDate", aXContractRelHistCreateDate);

        if ((aXContractRelHistCreateDate == null) || aXContractRelHistCreateDate.equals("")) {
            aXContractRelHistCreateDate = null;
        }

        eObjXContractRel.setHistCreateDt(DWLFunctionUtils.getTimestampFromTimestampString(aXContractRelHistCreateDate));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XContractRelHistCreatedBy history attribute.
     *
     * @generated
     */
    public String getXContractRelHistCreatedBy() {
        return eObjXContractRel.getHistCreatedBy();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XContractRelHistCreatedBy history attribute.
     *
     * @param aXContractRelHistCreatedBy
     *     The new value of XContractRelHistCreatedBy.
     * @generated
     */
    public void setXContractRelHistCreatedBy(String aXContractRelHistCreatedBy) {
        metaDataMap.put("XContractRelHistCreatedBy", aXContractRelHistCreatedBy);

        if ((aXContractRelHistCreatedBy == null) || aXContractRelHistCreatedBy.equals("")) {
            aXContractRelHistCreatedBy = null;
        }

        eObjXContractRel.setHistCreatedBy(aXContractRelHistCreatedBy);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XContractRelHistEndDate history attribute.
     *
     * @generated
     */
    public String getXContractRelHistEndDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXContractRel.getHistEndDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XContractRelHistEndDate history attribute.
     *
     * @param aXContractRelHistEndDate
     *     The new value of XContractRelHistEndDate.
     * @generated
     */
    public void setXContractRelHistEndDate(String aXContractRelHistEndDate) throws Exception{
        metaDataMap.put("XContractRelHistEndDate", aXContractRelHistEndDate);

        if ((aXContractRelHistEndDate == null) || aXContractRelHistEndDate.equals("")) {
            aXContractRelHistEndDate = null;
        }
        eObjXContractRel.setHistEndDt(DWLFunctionUtils.getTimestampFromTimestampString(aXContractRelHistEndDate));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XContractRelHistoryIdPK history attribute.
     *
     * @generated
     */
    public String getXContractRelHistoryIdPK() {
        return DWLFunctionUtils.getStringFromLong(eObjXContractRel.getHistoryIdPK());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XContractRelHistoryIdPK history attribute.
     *
     * @param aXContractRelHistoryIdPK
     *     The new value of XContractRelHistoryIdPK.
     * @generated
     */
    public void setXContractRelHistoryIdPK(String aXContractRelHistoryIdPK) {
        metaDataMap.put("XContractRelHistoryIdPK", aXContractRelHistoryIdPK);

        if ((aXContractRelHistoryIdPK == null) || aXContractRelHistoryIdPK.equals("")) {
            aXContractRelHistoryIdPK = null;
        }
        eObjXContractRel.setHistoryIdPK(DWLFunctionUtils.getLongFromString(aXContractRelHistoryIdPK));
    }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation during an add transaction.
     *
     * @generated
     */
    public DWLStatus validateAdd(int level, DWLStatus status) throws Exception {

        status = super.validateAdd(level, status);
        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0038I Add any controller-level custom validation logic to be
            // executed for this object during an "add" transaction

        }

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            // MDM_TODO0: CDKWB0039I Add any component-level custom validation logic to be
            // executed for this object during an "add" transaction
        }
        status = getValidationStatus(level, status);
        return status;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation during an update transaction.
     *
     * @generated
     */
    public DWLStatus validateUpdate(int level, DWLStatus status) throws Exception {
    logger.finest("ENTER validateUpdate(int level, DWLStatus status)");

        status = super.validateUpdate(level, status);
        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0040I Add any controller-level custom validation logic to be
            // executed for this object during an "update" transaction

            if (eObjXContractRel.getXContractRelpkId() == null) {
                DWLError err = new DWLError();
                err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCONTRACT_REL_BOBJ).longValue());
                err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.XCONTRACTREL_XCONTRACTRELPKID_NULL).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                	String infoForLogging="Error: Validation error occured for update. No primary key for entity XContractRel, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("validateUpdate(int level, DWLStatus status) " + infoForLogging);
                }
                status.addError(err);
            }
            if (eObjXContractRel.getLastUpdateDt() == null) {
                DWLError err = new DWLError();
                err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCONTRACT_REL_BOBJ).longValue());
                err.setReasonCode(new Long(DWLUtilErrorReasonCode.LAST_UPDATED_DATE_NULL).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
                if (logger.isFinestEnabled()) {
                	String infoForLogging="Error: Validation error occured for update. No last update date for entity XContractRel, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("validateUpdate(int level, DWLStatus status) " + infoForLogging);
                }
                status.addError(err);
            }
        }

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            assignBeforeImageValues(metaDataMap);
            
            // MDM_TODO0: CDKWB0041I Add any component-level custom validation logic to be
            // executed for this object during an "update" transaction
        }
        status = getValidationStatus(level, status);
    if (logger.isFinestEnabled()) {
        	String returnValue = status.toString();
      logger.finest("RETURN validateUpdate(int level, DWLStatus status) " + returnValue);
    }
        return status;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Populate the before image of this business object.
     *
     * @see com.dwl.base.DWLCommon#populateBeforeImage()
     * @generated
     */
    public void populateBeforeImage() throws DWLBaseException {
    logger.finest("ENTER populateBeforeImage()");

        DSEAAdditionsExts comp = null;
        try {
        
      comp = (DSEAAdditionsExts)TCRMClassFactory.getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
        	
        } catch (Exception e) {
      if (logger.isFinestEnabled()) {
        String infoForLogging="Error: Fatal error while updating record " + e.getMessage();
      logger.finest("populateBeforeImage() " + infoForLogging);
      }
            DWLExceptionUtils.throwDWLBaseException(e, 
            									new DWLUpdateException(e.getMessage()), 
            									this.getStatus(), DWLStatus.FATAL,
                                  DSEAAdditionsExtsComponentID.XCONTRACT_REL_BOBJ, 
                                  "DIERR",
                                  DSEAAdditionsExtsErrorReasonCode.XCONTRACTREL_BEFORE_IMAGE_NOT_POPULATED, 
                                  this.getControl());
        }
        
        comp.loadBeforeImage(this);
    logger.finest("RETURN populateBeforeImage()");
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation common to both add and update transactions.
     *
     * @generated
     */
     
    private DWLStatus getValidationStatus(int level, DWLStatus status) throws Exception {
    logger.finest("ENTER getValidationStatus(int level, DWLStatus status)");

        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0034I Add any common controller-level custom validation
            // logic to be executed for this object during either "add" or
            // "update" transactions
    		controllerValidation_StartDate(status);
    		controllerValidation_EndDate(status);
    	}

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            // MDM_TODO0: CDKWB0035I Add any common component-level custom validation logic
            // to be executed for this object during either "add" or "update"
            // transactions
    		componentValidation_StartDate(status);
    		componentValidation_EndDate(status);
        }
        
        if (logger.isFinestEnabled()) {
            String returnValue = status.toString();
      logger.finest("RETURN getValidationStatus(int level, DWLStatus status) " + returnValue);
        }
    
        return status;
    }

    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "StartDate"
     *
     * @generated
     */
	private void componentValidation_StartDate(DWLStatus status) {
  
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "EndDate"
     *
     * @generated
     */
	private void componentValidation_EndDate(DWLStatus status) {
  
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "StartDate"
     *
     * @generated
     */
	private void controllerValidation_StartDate(DWLStatus status) throws Exception {
  
            boolean isStartDateNull = (eObjXContractRel.getStartDate() == null);
            if (!isValidStartDate) {
              	DWLError err = new DWLError();
               	err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCONTRACT_REL_BOBJ).longValue());
               	err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XCONTRACTREL_STARTDATE).longValue());
               	err.setErrorType(DWLErrorCode.DATA_INVALID_ERROR);
                String infoForLogging="Error: Validation error. Invalid time specified on property StartDate in entity XContractRel, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode();
      logger.finest("controllerValidation_StartDate " + infoForLogging);
               	status.addError(err);
            } 
    	}
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "EndDate"
     *
     * @generated
     */
	private void controllerValidation_EndDate(DWLStatus status) throws Exception {
  
            boolean isEndDateNull = (eObjXContractRel.getEndDate() == null);
            if (!isValidEndDate) {
              	DWLError err = new DWLError();
               	err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCONTRACT_REL_BOBJ).longValue());
               	err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XCONTRACTREL_ENDDATE).longValue());
               	err.setErrorType(DWLErrorCode.DATA_INVALID_ERROR);
                String infoForLogging="Error: Validation error. Invalid time specified on property EndDate in entity XContractRel, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode();
      logger.finest("controllerValidation_EndDate " + infoForLogging);
               	status.addError(err);
            } 
    	}
    private DWLError createDWLError(String entityName, String propertyName,String reasonCode){	
		DWLError err = new DWLError();
		err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCONTRACT_REL_BOBJ).longValue());
		err.setReasonCode(new Long(reasonCode).longValue());
		err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
			String infoForLogging="Error: Validation error occured. Property " + propertyName + " is null, in entity " + entityName + ", component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
			logger.finest("createDWLError " + infoForLogging);
		}
		return err;
    }
    



}

