
/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[c45c284b1dbea694e09fce0693759726]
 */

package com.ibm.daimler.dsea.component;

import com.dwl.base.util.DWLClassFactory;
import com.dwl.tcrm.exception.TCRMReadException;



import com.dwl.base.DWLControl;
import com.dwl.base.IDWLErrorMessage;

import com.dwl.base.constant.DWLControlKeys;

import com.dwl.base.error.DWLError;
import com.dwl.base.error.DWLErrorCode;
import com.dwl.base.error.DWLStatus;

import com.dwl.base.exception.DWLBaseException;

import com.dwl.base.util.DWLExceptionUtils;
import com.dwl.base.util.DWLFunctionUtils;

import com.dwl.management.config.client.Configuration;
import com.dwl.tcrm.common.IExtension;
import com.dwl.tcrm.common.ITCRMValidation;
import com.dwl.tcrm.common.TCRMErrorCode;

import com.dwl.tcrm.coreParty.component.TCRMPersonNameBObj;

import com.dwl.tcrm.utilities.DateFormatter;
import com.dwl.tcrm.utilities.DateValidator;
import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsComponentID;
import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsErrorReasonCode;

import com.ibm.daimler.dsea.entityObject.EObjXPersonNameExt;

import com.ibm.mdm.common.codetype.interfaces.CodeTypeComponentHelper;

import com.ibm.mdm.common.codetype.obj.CodeTypeBObj;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * This class provides the implementation of the business object
 * <code>XPersonNameBObjExt</code>.
 * 
 * @see com.dwl.tcrm.common.TCRMCommon
 * @generated
 */
 

@SuppressWarnings("serial")
public class XPersonNameBObjExt extends TCRMPersonNameBObj implements IExtension {

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected EObjXPersonNameExt eObjXPersonNameExt;
	/**
    * <!-- begin-user-doc -->
	  * <!-- end-user-doc -->
    * @generated 
    */
	 private final static com.dwl.base.logging.IDWLLogger logger = com.dwl.base.logging.DWLLoggerManager.getLogger(XPersonNameBObjExt.class);
		
 
    protected boolean isValidXLastModifiedSystemDate = true;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */     
    public XPersonNameBObjExt() {
        super();
        init();
        eObjXPersonNameExt = new EObjXPersonNameExt(getEObjPersonName());
        setComponentID(DSEAAdditionsExtsComponentID.XPERSON_NAME_BOBJ_EXT);
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Initializes the fields required to populate the metaDataMap. Each key is
     * an element-level field of the business object.
     *
     * @generated
     */
    private void init() {
        metaDataMap.put("XLastModifiedSystemDate", null);
        metaDataMap.put("XGivenNameOneLocal", null);
        metaDataMap.put("XGivenNameTwoLocal", null);
        metaDataMap.put("XLastNameLocal", null);
        metaDataMap.put("XPersonNameRetailerFlag", null);
        metaDataMap.put("X_BPID", null);
        metaDataMap.put("XPersonNameHistActionCode", null);
        metaDataMap.put("XPersonNameHistCreateDate", null);
        metaDataMap.put("XPersonNameHistCreatedBy", null);
        metaDataMap.put("XPersonNameHistEndDate", null);
        metaDataMap.put("XPersonNameHistoryIdPK", null);
        metaDataMap.put("XPersonNameLastUpdateDate", null);
        metaDataMap.put("XPersonNameLastUpdateTxId", null);
        metaDataMap.put("XPersonNameLastUpdateUser", null);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Refreshes all the attributes this business object supports.
     *
     * @see com.dwl.base.DWLCommon#refreshMap()
     * @generated
     */
    public void refreshMap() {

        if (bRequireMapRefresh) {
            super.refreshMap();
            metaDataMap.put("XLastModifiedSystemDate", getXLastModifiedSystemDate());
            metaDataMap.put("XGivenNameOneLocal", getXGivenNameOneLocal());
            metaDataMap.put("XGivenNameTwoLocal", getXGivenNameTwoLocal());
            metaDataMap.put("XLastNameLocal", getXLastNameLocal());
            metaDataMap.put("XPersonNameRetailerFlag", getXPersonNameRetailerFlag());
            metaDataMap.put("X_BPID", getX_BPID());
            metaDataMap.put("XPersonNameHistActionCode", getXPersonNameHistActionCode());
            metaDataMap.put("XPersonNameHistCreateDate", getXPersonNameHistCreateDate());
            metaDataMap.put("XPersonNameHistCreatedBy", getXPersonNameHistCreatedBy());
            metaDataMap.put("XPersonNameHistEndDate", getXPersonNameHistEndDate());
            metaDataMap.put("XPersonNameHistoryIdPK", getXPersonNameHistoryIdPK());
            metaDataMap.put("XPersonNameLastUpdateDate", getXPersonNameLastUpdateDate());
            metaDataMap.put("XPersonNameLastUpdateTxId", getXPersonNameLastUpdateTxId());
            metaDataMap.put("XPersonNameLastUpdateUser", getXPersonNameLastUpdateUser());
            bRequireMapRefresh = false;
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the control object on this business object.
     *
     * @see com.dwl.base.DWLCommon#setControl(DWLControl)
     * @generated
     */
    public void setControl(DWLControl newDWLControl) {
        super.setControl(newDWLControl);

        if (eObjXPersonNameExt != null) {
            eObjXPersonNameExt.setControl(newDWLControl);
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the entity object associated with this business object.
     *
     * @generated
     */
    public EObjXPersonNameExt getEObjXPersonNameExt() {
        bRequireMapRefresh = true;
        return eObjXPersonNameExt;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the entity object associated with this business object.
     *
     * @param eObjXPersonNameExt
     *            The eObjXPersonNameExt to set.
     * @generated
     */
    public void setEObjXPersonNameExt(EObjXPersonNameExt eObjXPersonNameExt) {
        bRequireMapRefresh = true;
        this.eObjXPersonNameExt = eObjXPersonNameExt;
        this.eObjXPersonNameExt.setBaseEntity(getEObjPersonName());
        if (this.eObjXPersonNameExt != null && this.eObjXPersonNameExt.getControl() == null) {
            DWLControl control = this.getControl();
            if (control != null) {
                this.eObjXPersonNameExt.setControl(control);
            }
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xGivenNameOneLocal attribute.
     * 
     * @generated
     */
    public String getXGivenNameOneLocal (){
   
        return eObjXPersonNameExt.getXGivenNameOneLocal();
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xGivenNameOneLocal attribute.
     * 
     * @param newXGivenNameOneLocal
     *     The new value of xGivenNameOneLocal.
     * @generated
     */
    public void setXGivenNameOneLocal( String newXGivenNameOneLocal ) throws Exception {
        metaDataMap.put("XGivenNameOneLocal", newXGivenNameOneLocal);

        if (newXGivenNameOneLocal == null || newXGivenNameOneLocal.equals("")) {
            newXGivenNameOneLocal = null;


        }
        eObjXPersonNameExt.setXGivenNameOneLocal( newXGivenNameOneLocal );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xGivenNameTwoLocal attribute.
     * 
     * @generated
     */
    public String getXGivenNameTwoLocal (){
   
        return eObjXPersonNameExt.getXGivenNameTwoLocal();
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xGivenNameTwoLocal attribute.
     * 
     * @param newXGivenNameTwoLocal
     *     The new value of xGivenNameTwoLocal.
     * @generated
     */
    public void setXGivenNameTwoLocal( String newXGivenNameTwoLocal ) throws Exception {
        metaDataMap.put("XGivenNameTwoLocal", newXGivenNameTwoLocal);

        if (newXGivenNameTwoLocal == null || newXGivenNameTwoLocal.equals("")) {
            newXGivenNameTwoLocal = null;


        }
        eObjXPersonNameExt.setXGivenNameTwoLocal( newXGivenNameTwoLocal );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xLastNameLocal attribute.
     * 
     * @generated
     */
    public String getXLastNameLocal (){
   
        return eObjXPersonNameExt.getXLastNameLocal();
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xLastNameLocal attribute.
     * 
     * @param newXLastNameLocal
     *     The new value of xLastNameLocal.
     * @generated
     */
    public void setXLastNameLocal( String newXLastNameLocal ) throws Exception {
        metaDataMap.put("XLastNameLocal", newXLastNameLocal);

        if (newXLastNameLocal == null || newXLastNameLocal.equals("")) {
            newXLastNameLocal = null;


        }
        eObjXPersonNameExt.setXLastNameLocal( newXLastNameLocal );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xPersonNameRetailerFlag attribute.
     * 
     * @generated
     */
    public String getXPersonNameRetailerFlag (){
   
        return eObjXPersonNameExt.getXPersonNameRetailerFlag();
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xPersonNameRetailerFlag attribute.
     * 
     * @param newXPersonNameRetailerFlag
     *     The new value of xPersonNameRetailerFlag.
     * @generated
     */
    public void setXPersonNameRetailerFlag( String newXPersonNameRetailerFlag ) throws Exception {
        metaDataMap.put("XPersonNameRetailerFlag", newXPersonNameRetailerFlag);

        if (newXPersonNameRetailerFlag == null || newXPersonNameRetailerFlag.equals("")) {
            newXPersonNameRetailerFlag = null;


        }
        eObjXPersonNameExt.setXPersonNameRetailerFlag( newXPersonNameRetailerFlag );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the x_BPID attribute.
     * 
     * @generated
     */
    public String getX_BPID (){
   
        return eObjXPersonNameExt.getX_BPID();
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the x_BPID attribute.
     * 
     * @param newX_BPID
     *     The new value of x_BPID.
     * @generated
     */
    public void setX_BPID( String newX_BPID ) throws Exception {
        metaDataMap.put("X_BPID", newX_BPID);

        if (newX_BPID == null || newX_BPID.equals("")) {
            newX_BPID = null;


        }
        eObjXPersonNameExt.setX_BPID( newX_BPID );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xLastModifiedSystemDate attribute.
     * 
     * @generated
     */
    public String getXLastModifiedSystemDate (){
   
        return DWLFunctionUtils.getStringFromTimestamp(eObjXPersonNameExt.getXLastModifiedSystemDate());
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xLastModifiedSystemDate attribute.
     * 
     * @param newXLastModifiedSystemDate
     *     The new value of xLastModifiedSystemDate.
     * @generated
     */
    public void setXLastModifiedSystemDate( String newXLastModifiedSystemDate ) throws Exception {
        metaDataMap.put("XLastModifiedSystemDate", newXLastModifiedSystemDate);
       	isValidXLastModifiedSystemDate = true;

        if (newXLastModifiedSystemDate == null || newXLastModifiedSystemDate.equals("")) {
            newXLastModifiedSystemDate = null;
            eObjXPersonNameExt.setXLastModifiedSystemDate(null);


        }
    else {
        	if (DateValidator.validates(newXLastModifiedSystemDate)) {
           		eObjXPersonNameExt.setXLastModifiedSystemDate(DateFormatter.getStartDateTimestamp(newXLastModifiedSystemDate));
            	metaDataMap.put("XLastModifiedSystemDate", getXLastModifiedSystemDate());
        	} else {
            	if (Configuration.getConfiguration().getConfigItem(
              "/IBM/DWLCommonServices/InternalValidation/enabled").getBooleanValue()) {
                	if (metaDataMap.get("XLastModifiedSystemDate") != null) {
                    	metaDataMap.put("XLastModifiedSystemDate", "");
                	}
                	isValidXLastModifiedSystemDate = false;
                	eObjXPersonNameExt.setXLastModifiedSystemDate(null);
            	}
        	}
        }
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateTxId attribute.
     *
     * @generated
     */
    public String getXPersonNameLastUpdateTxId() {
        return DWLFunctionUtils.getStringFromLong(eObjXPersonNameExt.getLastUpdateTxId());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateUser attribute.
     *
     * @generated
     */
    public String getXPersonNameLastUpdateUser() {
        return eObjXPersonNameExt.getLastUpdateUser();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateDt attribute.
     *
     * @generated
     */
    public String getXPersonNameLastUpdateDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXPersonNameExt.getLastUpdateDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateTxId attribute.
     *
     * @param newLastUpdateTxId
     *     The new value of LastUpdateTxId.
     * @generated
     */
    public void setXPersonNameLastUpdateTxId(String newLastUpdateTxId) {
        metaDataMap.put("XPersonNameLastUpdateTxId", newLastUpdateTxId);

        if ((newLastUpdateTxId == null) || newLastUpdateTxId.equals("")) {
            newLastUpdateTxId = null;
        }
        eObjXPersonNameExt.setLastUpdateTxId(DWLFunctionUtils.getLongFromString(newLastUpdateTxId));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateUser attribute.
     *
     * @param newLastUpdateUser
     *     The new value of LastUpdateUser.
     * @generated
     */
    public void setXPersonNameLastUpdateUser(String newLastUpdateUser) {
        metaDataMap.put("XPersonNameLastUpdateUser", newLastUpdateUser);

        if ((newLastUpdateUser == null) || newLastUpdateUser.equals("")) {
            newLastUpdateUser = null;
        }
        eObjXPersonNameExt.setLastUpdateUser(newLastUpdateUser);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateDt attribute.
     *
     * @param newLastUpdateDt
     *     The new value of LastUpdateDt.
     * @throws Exception
     * @generated
     */
    public void setXPersonNameLastUpdateDate(String newLastUpdateDt) throws Exception {
        metaDataMap.put("XPersonNameLastUpdateDate", newLastUpdateDt);

        if ((newLastUpdateDt == null) || newLastUpdateDt.equals("")) {
            newLastUpdateDt = null;
        }

        eObjXPersonNameExt.setLastUpdateDt(DWLFunctionUtils.getTimestampFromTimestampString(newLastUpdateDt));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XPersonNameHistActionCode history attribute.
     *
     * @generated
     */
    public String getXPersonNameHistActionCode() {
        return eObjXPersonNameExt.getHistActionCode();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XPersonNameHistActionCode history attribute.
     *
     * @param aXPersonNameHistActionCode
     *     The new value of XPersonNameHistActionCode.
     * @generated
     */
    public void setXPersonNameHistActionCode(String aXPersonNameHistActionCode) {
        metaDataMap.put("XPersonNameHistActionCode", aXPersonNameHistActionCode);

        if ((aXPersonNameHistActionCode == null) || aXPersonNameHistActionCode.equals("")) {
            aXPersonNameHistActionCode = null;
        }
        eObjXPersonNameExt.setHistActionCode(aXPersonNameHistActionCode);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XPersonNameHistCreateDate history attribute.
     *
     * @generated
     */
    public String getXPersonNameHistCreateDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXPersonNameExt.getHistCreateDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XPersonNameHistCreateDate history attribute.
     *
     * @param aXPersonNameHistCreateDate
     *     The new value of XPersonNameHistCreateDate.
     * @generated
     */
    public void setXPersonNameHistCreateDate(String aXPersonNameHistCreateDate) throws Exception{
        metaDataMap.put("XPersonNameHistCreateDate", aXPersonNameHistCreateDate);

        if ((aXPersonNameHistCreateDate == null) || aXPersonNameHistCreateDate.equals("")) {
            aXPersonNameHistCreateDate = null;
        }

        eObjXPersonNameExt.setHistCreateDt(DWLFunctionUtils.getTimestampFromTimestampString(aXPersonNameHistCreateDate));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XPersonNameHistCreatedBy history attribute.
     *
     * @generated
     */
    public String getXPersonNameHistCreatedBy() {
        return eObjXPersonNameExt.getHistCreatedBy();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XPersonNameHistCreatedBy history attribute.
     *
     * @param aXPersonNameHistCreatedBy
     *     The new value of XPersonNameHistCreatedBy.
     * @generated
     */
    public void setXPersonNameHistCreatedBy(String aXPersonNameHistCreatedBy) {
        metaDataMap.put("XPersonNameHistCreatedBy", aXPersonNameHistCreatedBy);

        if ((aXPersonNameHistCreatedBy == null) || aXPersonNameHistCreatedBy.equals("")) {
            aXPersonNameHistCreatedBy = null;
        }

        eObjXPersonNameExt.setHistCreatedBy(aXPersonNameHistCreatedBy);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XPersonNameHistEndDate history attribute.
     *
     * @generated
     */
    public String getXPersonNameHistEndDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXPersonNameExt.getHistEndDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XPersonNameHistEndDate history attribute.
     *
     * @param aXPersonNameHistEndDate
     *     The new value of XPersonNameHistEndDate.
     * @generated
     */
    public void setXPersonNameHistEndDate(String aXPersonNameHistEndDate) throws Exception{
        metaDataMap.put("XPersonNameHistEndDate", aXPersonNameHistEndDate);

        if ((aXPersonNameHistEndDate == null) || aXPersonNameHistEndDate.equals("")) {
            aXPersonNameHistEndDate = null;
        }
        eObjXPersonNameExt.setHistEndDt(DWLFunctionUtils.getTimestampFromTimestampString(aXPersonNameHistEndDate));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XPersonNameHistoryIdPK history attribute.
     *
     * @generated
     */
    public String getXPersonNameHistoryIdPK() {
        return DWLFunctionUtils.getStringFromLong(eObjXPersonNameExt.getHistoryIdPK());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XPersonNameHistoryIdPK history attribute.
     *
     * @param aXPersonNameHistoryIdPK
     *     The new value of XPersonNameHistoryIdPK.
     * @generated
     */
    public void setXPersonNameHistoryIdPK(String aXPersonNameHistoryIdPK) {
        metaDataMap.put("XPersonNameHistoryIdPK", aXPersonNameHistoryIdPK);

        if ((aXPersonNameHistoryIdPK == null) || aXPersonNameHistoryIdPK.equals("")) {
            aXPersonNameHistoryIdPK = null;
        }
        eObjXPersonNameExt.setHistoryIdPK(DWLFunctionUtils.getLongFromString(aXPersonNameHistoryIdPK));
    }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation during an add transaction.
     *
     * @generated
     */
    public DWLStatus validateAdd(int level, DWLStatus status) throws Exception {

        status = super.validateAdd(level, status);
        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0038I Add any controller-level custom validation logic to be
            // executed for this object during an "add" transaction

        }

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            // MDM_TODO0: CDKWB0039I Add any component-level custom validation logic to be
            // executed for this object during an "add" transaction
        }
        status = getValidationStatus(level, status);
        return status;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation during an update transaction.
     *
     * @generated
     */
    public DWLStatus validateUpdate(int level, DWLStatus status) throws Exception {
    logger.finest("ENTER validateUpdate(int level, DWLStatus status)");

        status = super.validateUpdate(level, status);
        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0040I Add any controller-level custom validation logic to be
            // executed for this object during an "update" transaction

        }

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            assignBeforeImageValues(metaDataMap);
            
            // MDM_TODO0: CDKWB0041I Add any component-level custom validation logic to be
            // executed for this object during an "update" transaction
        }
        status = getValidationStatus(level, status);
    if (logger.isFinestEnabled()) {
        	String returnValue = status.toString();
      logger.finest("RETURN validateUpdate(int level, DWLStatus status) " + returnValue);
    }
        return status;
    }



    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation common to both add and update transactions.
     *
     * @generated
     */
     
    private DWLStatus getValidationStatus(int level, DWLStatus status) throws Exception {
    logger.finest("ENTER getValidationStatus(int level, DWLStatus status)");

        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0034I Add any common controller-level custom validation
            // logic to be executed for this object during either "add" or
            // "update" transactions
    		controllerValidation_XLastModifiedSystemDate(status);
    	}

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            // MDM_TODO0: CDKWB0035I Add any common component-level custom validation logic
            // to be executed for this object during either "add" or "update"
            // transactions
    		componentValidation_XLastModifiedSystemDate(status);
        }
        
        if (logger.isFinestEnabled()) {
            String returnValue = status.toString();
      logger.finest("RETURN getValidationStatus(int level, DWLStatus status) " + returnValue);
        }
    
        return status;
    }

    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "XLastModifiedSystemDate"
     *
     * @generated
     */
  private void componentValidation_XLastModifiedSystemDate(DWLStatus status) {
  
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "XLastModifiedSystemDate"
     *
     * @generated
     */
  private void controllerValidation_XLastModifiedSystemDate(DWLStatus status) throws Exception {
  
            boolean isXLastModifiedSystemDateNull = (eObjXPersonNameExt.getXLastModifiedSystemDate() == null);
            if (!isValidXLastModifiedSystemDate) {
              	DWLError err = new DWLError();
               	err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XPERSON_NAME_BOBJ_EXT).longValue());
               	err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XPERSONNAME_XLASTMODIFIEDSYSTEMDATE).longValue());
               	err.setErrorType(DWLErrorCode.DATA_INVALID_ERROR);
                String infoForLogging="Error: Validation error. Invalid time specified on property XLastModifiedSystemDate in entity XPersonName, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode();
      logger.finest("controllerValidation_XLastModifiedSystemDate " + infoForLogging);
               	status.addError(err);
            } 
    	}


    private DWLError createDWLError(String entityName, String propertyName,String reasonCode){	
		DWLError err = new DWLError();
		err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XPERSON_NAME_BOBJ_EXT).longValue());
		err.setReasonCode(new Long(reasonCode).longValue());
		err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
			String infoForLogging="Error: Validation error occured. Property " + propertyName + " is null, in entity " + entityName + ", component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
			logger.finest("createDWLError " + infoForLogging);
		}
		return err;
    }
    
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets a record from the extension table.
     *
     * @throws DWLBaseException
     * @generated
     */
    public void getRecord() throws DWLBaseException {
    logger.finest("ENTER getRecord()");
    
    try {
         			
         }
         catch (Exception e) {
            DWLExceptionUtils.log(e);
            
            if (logger.isFinestEnabled()) {
        		String infoForLogging="Error: Error reading record " + e.getMessage(); 
      logger.finest("getRecord() " + infoForLogging);
      }
            status = new DWLStatus();

            TCRMReadException readEx = new TCRMReadException();
            IDWLErrorMessage  errHandler = DWLClassFactory.getErrorHandler();
            DWLError          error = errHandler.getErrorMessage(DSEAAdditionsExtsComponentID.XPERSON_NAME_BOBJ_EXT,
                                                                 TCRMErrorCode.READ_RECORD_ERROR,
                                                                 DSEAAdditionsExtsErrorReasonCode.READ_EXTENSION_XPERSONNAME_FAILED,
                                                                 getControl(), new String[0]);
            error.setThrowable(e);
            status.addError(error);
            status.setStatus(DWLStatus.FATAL);
            readEx.setStatus(status);
            throw readEx;
        }	    		
    logger.finest("RETURN getRecord()");
  }


}

