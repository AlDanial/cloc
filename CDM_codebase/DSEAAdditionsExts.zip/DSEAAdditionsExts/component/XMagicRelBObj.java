
/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[7ed15d166eb2e31ffd77b403d412cf1f]
 */

package com.ibm.daimler.dsea.component;

import com.dwl.tcrm.common.TCRMCommon;



import com.dwl.base.DWLControl;

import com.dwl.base.constant.DWLUtilErrorReasonCode;

import com.dwl.base.error.DWLError;
import com.dwl.base.error.DWLErrorCode;
import com.dwl.base.error.DWLStatus;

import com.dwl.base.exception.DWLBaseException;
import com.dwl.base.exception.DWLUpdateException;

import com.dwl.base.util.DWLExceptionUtils;
import com.dwl.base.util.DWLFunctionUtils;

import com.dwl.tcrm.common.ITCRMValidation;

import com.dwl.tcrm.utilities.TCRMClassFactory;

import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsComponentID;
import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsErrorReasonCode;
import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsPropertyKeys;

import com.ibm.daimler.dsea.entityObject.EObjXMagicRel;

import com.ibm.daimler.dsea.interfaces.DSEAAdditionsExts;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * This class provides the implementation of the business object
 * <code>XMagicRelBObj</code>.
 * 
 * @see com.dwl.tcrm.common.TCRMCommon
 * @generated
 */
 

@SuppressWarnings("serial")
public class XMagicRelBObj extends TCRMCommon  {

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected EObjXMagicRel eObjXMagicRel;
	/**
    * <!-- begin-user-doc -->
	  * <!-- end-user-doc -->
    * @generated 
    */
	 private final static com.dwl.base.logging.IDWLLogger logger = com.dwl.base.logging.DWLLoggerManager.getLogger(XMagicRelBObj.class);
		
 


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */     
    public XMagicRelBObj() {
        super();
        init();
        eObjXMagicRel = new EObjXMagicRel();
        setComponentID(DSEAAdditionsExtsComponentID.XMAGIC_REL_BOBJ);
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Initializes the fields required to populate the metaDataMap. Each key is
     * an element-level field of the business object.
     *
     * @generated
     */
    private void init() {
        metaDataMap.put("XMagicRelpkId", null);
        metaDataMap.put("UCID", null);
        metaDataMap.put("GoldenMagic", null);
        metaDataMap.put("OldMagic", null);
        metaDataMap.put("OldMagicRetailer", null);
        metaDataMap.put("XMagicRelHistActionCode", null);
        metaDataMap.put("XMagicRelHistCreateDate", null);
        metaDataMap.put("XMagicRelHistCreatedBy", null);
        metaDataMap.put("XMagicRelHistEndDate", null);
        metaDataMap.put("XMagicRelHistoryIdPK", null);
        metaDataMap.put("XMagicRelLastUpdateDate", null);
        metaDataMap.put("XMagicRelLastUpdateTxId", null);
        metaDataMap.put("XMagicRelLastUpdateUser", null);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Refreshes all the attributes this business object supports.
     *
     * @see com.dwl.base.DWLCommon#refreshMap()
     * @generated
     */
    public void refreshMap() {

        if (bRequireMapRefresh) {
            super.refreshMap();
            metaDataMap.put("XMagicRelpkId", getXMagicRelpkId());
            metaDataMap.put("UCID", getUCID());
            metaDataMap.put("GoldenMagic", getGoldenMagic());
            metaDataMap.put("OldMagic", getOldMagic());
            metaDataMap.put("OldMagicRetailer", getOldMagicRetailer());
            metaDataMap.put("XMagicRelHistActionCode", getXMagicRelHistActionCode());
            metaDataMap.put("XMagicRelHistCreateDate", getXMagicRelHistCreateDate());
            metaDataMap.put("XMagicRelHistCreatedBy", getXMagicRelHistCreatedBy());
            metaDataMap.put("XMagicRelHistEndDate", getXMagicRelHistEndDate());
            metaDataMap.put("XMagicRelHistoryIdPK", getXMagicRelHistoryIdPK());
            metaDataMap.put("XMagicRelLastUpdateDate", getXMagicRelLastUpdateDate());
            metaDataMap.put("XMagicRelLastUpdateTxId", getXMagicRelLastUpdateTxId());
            metaDataMap.put("XMagicRelLastUpdateUser", getXMagicRelLastUpdateUser());
            bRequireMapRefresh = false;
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the control object on this business object.
     *
     * @see com.dwl.base.DWLCommon#setControl(DWLControl)
     * @generated
     */
    public void setControl(DWLControl newDWLControl) {
        super.setControl(newDWLControl);

        if (eObjXMagicRel != null) {
            eObjXMagicRel.setControl(newDWLControl);
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the entity object associated with this business object.
     *
     * @generated
     */
    public EObjXMagicRel getEObjXMagicRel() {
        bRequireMapRefresh = true;
        return eObjXMagicRel;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the entity object associated with this business object.
     *
     * @param eObjXMagicRel
     *            The eObjXMagicRel to set.
     * @generated
     */
    public void setEObjXMagicRel(EObjXMagicRel eObjXMagicRel) {
        bRequireMapRefresh = true;
        this.eObjXMagicRel = eObjXMagicRel;
        if (this.eObjXMagicRel != null && this.eObjXMagicRel.getControl() == null) {
            DWLControl control = this.getControl();
            if (control != null) {
                this.eObjXMagicRel.setControl(control);
            }
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xMagicRelpkId attribute.
     * 
     * @generated
     */
    public String getXMagicRelpkId (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXMagicRel.getXMagicRelpkId());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xMagicRelpkId attribute.
     * 
     * @param newXMagicRelpkId
     *     The new value of xMagicRelpkId.
     * @generated
     */
    public void setXMagicRelpkId( String newXMagicRelpkId ) throws Exception {
        metaDataMap.put("XMagicRelpkId", newXMagicRelpkId);

        if (newXMagicRelpkId == null || newXMagicRelpkId.equals("")) {
            newXMagicRelpkId = null;


        }
        eObjXMagicRel.setXMagicRelpkId( DWLFunctionUtils.getLongFromString(newXMagicRelpkId) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the uCID attribute.
     * 
     * @generated
     */
    public String getUCID (){
   
        return eObjXMagicRel.getUCID();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the uCID attribute.
     * 
     * @param newUCID
     *     The new value of uCID.
     * @generated
     */
    public void setUCID( String newUCID ) throws Exception {
        metaDataMap.put("UCID", newUCID);

        if (newUCID == null || newUCID.equals("")) {
            newUCID = null;


        }
        eObjXMagicRel.setUCID( newUCID );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the goldenMagic attribute.
     * 
     * @generated
     */
    public String getGoldenMagic (){
   
        return eObjXMagicRel.getGoldenMagic();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the goldenMagic attribute.
     * 
     * @param newGoldenMagic
     *     The new value of goldenMagic.
     * @generated
     */
    public void setGoldenMagic( String newGoldenMagic ) throws Exception {
        metaDataMap.put("GoldenMagic", newGoldenMagic);

        if (newGoldenMagic == null || newGoldenMagic.equals("")) {
            newGoldenMagic = null;


        }
        eObjXMagicRel.setGoldenMagic( newGoldenMagic );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the oldMagic attribute.
     * 
     * @generated
     */
    public String getOldMagic (){
   
        return eObjXMagicRel.getOldMagic();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the oldMagic attribute.
     * 
     * @param newOldMagic
     *     The new value of oldMagic.
     * @generated
     */
    public void setOldMagic( String newOldMagic ) throws Exception {
        metaDataMap.put("OldMagic", newOldMagic);

        if (newOldMagic == null || newOldMagic.equals("")) {
            newOldMagic = null;


        }
        eObjXMagicRel.setOldMagic( newOldMagic );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the oldMagicRetailer attribute.
     * 
     * @generated
     */
    public String getOldMagicRetailer (){
   
        return eObjXMagicRel.getOldMagicRetailer();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the oldMagicRetailer attribute.
     * 
     * @param newOldMagicRetailer
     *     The new value of oldMagicRetailer.
     * @generated
     */
    public void setOldMagicRetailer( String newOldMagicRetailer ) throws Exception {
        metaDataMap.put("OldMagicRetailer", newOldMagicRetailer);

        if (newOldMagicRetailer == null || newOldMagicRetailer.equals("")) {
            newOldMagicRetailer = null;


        }
        eObjXMagicRel.setOldMagicRetailer( newOldMagicRetailer );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateTxId attribute.
     *
     * @generated
     */
    public String getXMagicRelLastUpdateTxId() {
        return DWLFunctionUtils.getStringFromLong(eObjXMagicRel.getLastUpdateTxId());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateUser attribute.
     *
     * @generated
     */
    public String getXMagicRelLastUpdateUser() {
        return eObjXMagicRel.getLastUpdateUser();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateDt attribute.
     *
     * @generated
     */
    public String getXMagicRelLastUpdateDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXMagicRel.getLastUpdateDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateTxId attribute.
     *
     * @param newLastUpdateTxId
     *     The new value of LastUpdateTxId.
     * @generated
     */
    public void setXMagicRelLastUpdateTxId(String newLastUpdateTxId) {
        metaDataMap.put("XMagicRelLastUpdateTxId", newLastUpdateTxId);

        if ((newLastUpdateTxId == null) || newLastUpdateTxId.equals("")) {
            newLastUpdateTxId = null;
        }
        eObjXMagicRel.setLastUpdateTxId(DWLFunctionUtils.getLongFromString(newLastUpdateTxId));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateUser attribute.
     *
     * @param newLastUpdateUser
     *     The new value of LastUpdateUser.
     * @generated
     */
    public void setXMagicRelLastUpdateUser(String newLastUpdateUser) {
        metaDataMap.put("XMagicRelLastUpdateUser", newLastUpdateUser);

        if ((newLastUpdateUser == null) || newLastUpdateUser.equals("")) {
            newLastUpdateUser = null;
        }
        eObjXMagicRel.setLastUpdateUser(newLastUpdateUser);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateDt attribute.
     *
     * @param newLastUpdateDt
     *     The new value of LastUpdateDt.
     * @throws Exception
     * @generated
     */
    public void setXMagicRelLastUpdateDate(String newLastUpdateDt) throws Exception {
        metaDataMap.put("XMagicRelLastUpdateDate", newLastUpdateDt);

        if ((newLastUpdateDt == null) || newLastUpdateDt.equals("")) {
            newLastUpdateDt = null;
        }

        eObjXMagicRel.setLastUpdateDt(DWLFunctionUtils.getTimestampFromTimestampString(newLastUpdateDt));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XMagicRelHistActionCode history attribute.
     *
     * @generated
     */
    public String getXMagicRelHistActionCode() {
        return eObjXMagicRel.getHistActionCode();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XMagicRelHistActionCode history attribute.
     *
     * @param aXMagicRelHistActionCode
     *     The new value of XMagicRelHistActionCode.
     * @generated
     */
    public void setXMagicRelHistActionCode(String aXMagicRelHistActionCode) {
        metaDataMap.put("XMagicRelHistActionCode", aXMagicRelHistActionCode);

        if ((aXMagicRelHistActionCode == null) || aXMagicRelHistActionCode.equals("")) {
            aXMagicRelHistActionCode = null;
        }
        eObjXMagicRel.setHistActionCode(aXMagicRelHistActionCode);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XMagicRelHistCreateDate history attribute.
     *
     * @generated
     */
    public String getXMagicRelHistCreateDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXMagicRel.getHistCreateDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XMagicRelHistCreateDate history attribute.
     *
     * @param aXMagicRelHistCreateDate
     *     The new value of XMagicRelHistCreateDate.
     * @generated
     */
    public void setXMagicRelHistCreateDate(String aXMagicRelHistCreateDate) throws Exception{
        metaDataMap.put("XMagicRelHistCreateDate", aXMagicRelHistCreateDate);

        if ((aXMagicRelHistCreateDate == null) || aXMagicRelHistCreateDate.equals("")) {
            aXMagicRelHistCreateDate = null;
        }

        eObjXMagicRel.setHistCreateDt(DWLFunctionUtils.getTimestampFromTimestampString(aXMagicRelHistCreateDate));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XMagicRelHistCreatedBy history attribute.
     *
     * @generated
     */
    public String getXMagicRelHistCreatedBy() {
        return eObjXMagicRel.getHistCreatedBy();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XMagicRelHistCreatedBy history attribute.
     *
     * @param aXMagicRelHistCreatedBy
     *     The new value of XMagicRelHistCreatedBy.
     * @generated
     */
    public void setXMagicRelHistCreatedBy(String aXMagicRelHistCreatedBy) {
        metaDataMap.put("XMagicRelHistCreatedBy", aXMagicRelHistCreatedBy);

        if ((aXMagicRelHistCreatedBy == null) || aXMagicRelHistCreatedBy.equals("")) {
            aXMagicRelHistCreatedBy = null;
        }

        eObjXMagicRel.setHistCreatedBy(aXMagicRelHistCreatedBy);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XMagicRelHistEndDate history attribute.
     *
     * @generated
     */
    public String getXMagicRelHistEndDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXMagicRel.getHistEndDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XMagicRelHistEndDate history attribute.
     *
     * @param aXMagicRelHistEndDate
     *     The new value of XMagicRelHistEndDate.
     * @generated
     */
    public void setXMagicRelHistEndDate(String aXMagicRelHistEndDate) throws Exception{
        metaDataMap.put("XMagicRelHistEndDate", aXMagicRelHistEndDate);

        if ((aXMagicRelHistEndDate == null) || aXMagicRelHistEndDate.equals("")) {
            aXMagicRelHistEndDate = null;
        }
        eObjXMagicRel.setHistEndDt(DWLFunctionUtils.getTimestampFromTimestampString(aXMagicRelHistEndDate));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XMagicRelHistoryIdPK history attribute.
     *
     * @generated
     */
    public String getXMagicRelHistoryIdPK() {
        return DWLFunctionUtils.getStringFromLong(eObjXMagicRel.getHistoryIdPK());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XMagicRelHistoryIdPK history attribute.
     *
     * @param aXMagicRelHistoryIdPK
     *     The new value of XMagicRelHistoryIdPK.
     * @generated
     */
    public void setXMagicRelHistoryIdPK(String aXMagicRelHistoryIdPK) {
        metaDataMap.put("XMagicRelHistoryIdPK", aXMagicRelHistoryIdPK);

        if ((aXMagicRelHistoryIdPK == null) || aXMagicRelHistoryIdPK.equals("")) {
            aXMagicRelHistoryIdPK = null;
        }
        eObjXMagicRel.setHistoryIdPK(DWLFunctionUtils.getLongFromString(aXMagicRelHistoryIdPK));
    }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation during an add transaction.
     *
     * @generated
     */
    public DWLStatus validateAdd(int level, DWLStatus status) throws Exception {

        status = super.validateAdd(level, status);
        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0038I Add any controller-level custom validation logic to be
            // executed for this object during an "add" transaction

        }

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            // MDM_TODO0: CDKWB0039I Add any component-level custom validation logic to be
            // executed for this object during an "add" transaction
        }
        status = getValidationStatus(level, status);
        return status;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation during an update transaction.
     *
     * @generated
     */
    public DWLStatus validateUpdate(int level, DWLStatus status) throws Exception {
    logger.finest("ENTER validateUpdate(int level, DWLStatus status)");

        status = super.validateUpdate(level, status);
        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0040I Add any controller-level custom validation logic to be
            // executed for this object during an "update" transaction

            if (eObjXMagicRel.getXMagicRelpkId() == null) {
                DWLError err = new DWLError();
                err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XMAGIC_REL_BOBJ).longValue());
                err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.XMAGICREL_XMAGICRELPKID_NULL).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                	String infoForLogging="Error: Validation error occured for update. No primary key for entity XMagicRel, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("validateUpdate(int level, DWLStatus status) " + infoForLogging);
                }
                status.addError(err);
            }
            if (eObjXMagicRel.getLastUpdateDt() == null) {
                DWLError err = new DWLError();
                err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XMAGIC_REL_BOBJ).longValue());
                err.setReasonCode(new Long(DWLUtilErrorReasonCode.LAST_UPDATED_DATE_NULL).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
                if (logger.isFinestEnabled()) {
                	String infoForLogging="Error: Validation error occured for update. No last update date for entity XMagicRel, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("validateUpdate(int level, DWLStatus status) " + infoForLogging);
                }
                status.addError(err);
            }
        }

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            assignBeforeImageValues(metaDataMap);
            
            // MDM_TODO0: CDKWB0041I Add any component-level custom validation logic to be
            // executed for this object during an "update" transaction
        }
        status = getValidationStatus(level, status);
    if (logger.isFinestEnabled()) {
        	String returnValue = status.toString();
      logger.finest("RETURN validateUpdate(int level, DWLStatus status) " + returnValue);
    }
        return status;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Populate the before image of this business object.
     *
     * @see com.dwl.base.DWLCommon#populateBeforeImage()
     * @generated
     */
    public void populateBeforeImage() throws DWLBaseException {
    logger.finest("ENTER populateBeforeImage()");

        DSEAAdditionsExts comp = null;
        try {
        
      comp = (DSEAAdditionsExts)TCRMClassFactory.getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
        	
        } catch (Exception e) {
      if (logger.isFinestEnabled()) {
        String infoForLogging="Error: Fatal error while updating record " + e.getMessage();
      logger.finest("populateBeforeImage() " + infoForLogging);
      }
            DWLExceptionUtils.throwDWLBaseException(e, 
            									new DWLUpdateException(e.getMessage()), 
            									this.getStatus(), DWLStatus.FATAL,
                                  DSEAAdditionsExtsComponentID.XMAGIC_REL_BOBJ, 
                                  "DIERR",
                                  DSEAAdditionsExtsErrorReasonCode.XMAGICREL_BEFORE_IMAGE_NOT_POPULATED, 
                                  this.getControl());
        }
        
        comp.loadBeforeImage(this);
    logger.finest("RETURN populateBeforeImage()");
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation common to both add and update transactions.
     *
     * @generated
     */
     
    private DWLStatus getValidationStatus(int level, DWLStatus status) throws Exception {
    logger.finest("ENTER getValidationStatus(int level, DWLStatus status)");

        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0034I Add any common controller-level custom validation
            // logic to be executed for this object during either "add" or
            // "update" transactions
    	}

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            // MDM_TODO0: CDKWB0035I Add any common component-level custom validation logic
            // to be executed for this object during either "add" or "update"
            // transactions
        }
        
        if (logger.isFinestEnabled()) {
            String returnValue = status.toString();
      logger.finest("RETURN getValidationStatus(int level, DWLStatus status) " + returnValue);
        }
    
        return status;
    }

    private DWLError createDWLError(String entityName, String propertyName,String reasonCode){	
		DWLError err = new DWLError();
		err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XMAGIC_REL_BOBJ).longValue());
		err.setReasonCode(new Long(reasonCode).longValue());
		err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
			String infoForLogging="Error: Validation error occured. Property " + propertyName + " is null, in entity " + entityName + ", component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
			logger.finest("createDWLError " + infoForLogging);
		}
		return err;
    }
    



}

