
/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[154785b1796ce298a720bbc1006a2dc9]
 */

package com.ibm.daimler.dsea.component;

import com.dwl.tcrm.common.TCRMCommon;



import com.dwl.base.DWLControl;

import com.dwl.base.constant.DWLControlKeys;
import com.dwl.base.constant.DWLUtilErrorReasonCode;

import com.dwl.base.error.DWLError;
import com.dwl.base.error.DWLErrorCode;
import com.dwl.base.error.DWLStatus;

import com.dwl.base.exception.DWLBaseException;
import com.dwl.base.exception.DWLUpdateException;

import com.dwl.base.util.DWLClassFactory;
import com.dwl.base.util.DWLExceptionUtils;
import com.dwl.base.util.DWLFunctionUtils;

import com.dwl.management.config.client.Configuration;

import com.dwl.tcrm.common.ITCRMValidation;

import com.dwl.tcrm.utilities.DateFormatter;
import com.dwl.tcrm.utilities.DateValidator;
import com.dwl.tcrm.utilities.TCRMClassFactory;

import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsComponentID;
import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsErrorReasonCode;
import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsPropertyKeys;

import com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRole;

import com.ibm.daimler.dsea.interfaces.DSEAAdditionsExts;

import com.ibm.mdm.common.codetype.interfaces.CodeTypeComponentHelper;

import com.ibm.mdm.common.codetype.obj.CodeTypeBObj;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * This class provides the implementation of the business object
 * <code>XCustomerVehicleRoleBObj</code>.
 * 
 * @see com.dwl.tcrm.common.TCRMCommon
 * @generated
 */
 

@SuppressWarnings("serial")
public class XCustomerVehicleRoleBObj extends TCRMCommon  {

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected EObjXCustomerVehicleRole eObjXCustomerVehicleRole;
	/**
    * <!-- begin-user-doc -->
	  * <!-- end-user-doc -->
    * @generated 
    */
	 private final static com.dwl.base.logging.IDWLLogger logger = com.dwl.base.logging.DWLLoggerManager.getLogger(XCustomerVehicleRoleBObj.class);
		
 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected String vehicleRoleValue;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected String sourceIdentifierValue;
	protected boolean isValidChangedDate = true;
  protected boolean isValidStartDate = true;
	
	protected boolean isValidEndDate = true;
	


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */     
    public XCustomerVehicleRoleBObj() {
        super();
        init();
        eObjXCustomerVehicleRole = new EObjXCustomerVehicleRole();
        setComponentID(DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_ROLE_BOBJ);
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Initializes the fields required to populate the metaDataMap. Each key is
     * an element-level field of the business object.
     *
     * @generated
     */
    private void init() {
        metaDataMap.put("CustomerVehicleRolepkId", null);
        metaDataMap.put("CustomerVehicleId", null);
        metaDataMap.put("VehicleRoleType", null);
        metaDataMap.put("VehicleRoleValue", null);
        metaDataMap.put("StartDate", null);
        metaDataMap.put("EndDate", null);
        metaDataMap.put("SourceIdentifierType", null);
        metaDataMap.put("SourceIdentifierValue", null);
        metaDataMap.put("ChangedDate", null);
        metaDataMap.put("XCustomerVehicleRoleHistActionCode", null);
        metaDataMap.put("XCustomerVehicleRoleHistCreateDate", null);
        metaDataMap.put("XCustomerVehicleRoleHistCreatedBy", null);
        metaDataMap.put("XCustomerVehicleRoleHistEndDate", null);
        metaDataMap.put("XCustomerVehicleRoleHistoryIdPK", null);
        metaDataMap.put("XCustomerVehicleRoleLastUpdateDate", null);
        metaDataMap.put("XCustomerVehicleRoleLastUpdateTxId", null);
        metaDataMap.put("XCustomerVehicleRoleLastUpdateUser", null);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Refreshes all the attributes this business object supports.
     *
     * @see com.dwl.base.DWLCommon#refreshMap()
     * @generated
     */
    public void refreshMap() {

        if (bRequireMapRefresh) {
            super.refreshMap();
            metaDataMap.put("CustomerVehicleRolepkId", getCustomerVehicleRolepkId());
            metaDataMap.put("CustomerVehicleId", getCustomerVehicleId());
            metaDataMap.put("VehicleRoleType", getVehicleRoleType());
            metaDataMap.put("VehicleRoleValue", getVehicleRoleValue());
            metaDataMap.put("StartDate", getStartDate());
            metaDataMap.put("EndDate", getEndDate());
            metaDataMap.put("SourceIdentifierType", getSourceIdentifierType());
            metaDataMap.put("SourceIdentifierValue", getSourceIdentifierValue());
            metaDataMap.put("ChangedDate", getChangedDate());
            metaDataMap.put("XCustomerVehicleRoleHistActionCode", getXCustomerVehicleRoleHistActionCode());
            metaDataMap.put("XCustomerVehicleRoleHistCreateDate", getXCustomerVehicleRoleHistCreateDate());
            metaDataMap.put("XCustomerVehicleRoleHistCreatedBy", getXCustomerVehicleRoleHistCreatedBy());
            metaDataMap.put("XCustomerVehicleRoleHistEndDate", getXCustomerVehicleRoleHistEndDate());
            metaDataMap.put("XCustomerVehicleRoleHistoryIdPK", getXCustomerVehicleRoleHistoryIdPK());
            metaDataMap.put("XCustomerVehicleRoleLastUpdateDate", getXCustomerVehicleRoleLastUpdateDate());
            metaDataMap.put("XCustomerVehicleRoleLastUpdateTxId", getXCustomerVehicleRoleLastUpdateTxId());
            metaDataMap.put("XCustomerVehicleRoleLastUpdateUser", getXCustomerVehicleRoleLastUpdateUser());
            bRequireMapRefresh = false;
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the control object on this business object.
     *
     * @see com.dwl.base.DWLCommon#setControl(DWLControl)
     * @generated
     */
    public void setControl(DWLControl newDWLControl) {
        super.setControl(newDWLControl);

        if (eObjXCustomerVehicleRole != null) {
            eObjXCustomerVehicleRole.setControl(newDWLControl);
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the entity object associated with this business object.
     *
     * @generated
     */
    public EObjXCustomerVehicleRole getEObjXCustomerVehicleRole() {
        bRequireMapRefresh = true;
        return eObjXCustomerVehicleRole;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the entity object associated with this business object.
     *
     * @param eObjXCustomerVehicleRole
     *            The eObjXCustomerVehicleRole to set.
     * @generated
     */
    public void setEObjXCustomerVehicleRole(EObjXCustomerVehicleRole eObjXCustomerVehicleRole) {
        bRequireMapRefresh = true;
        this.eObjXCustomerVehicleRole = eObjXCustomerVehicleRole;
        if (this.eObjXCustomerVehicleRole != null && this.eObjXCustomerVehicleRole.getControl() == null) {
            DWLControl control = this.getControl();
            if (control != null) {
                this.eObjXCustomerVehicleRole.setControl(control);
            }
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the customerVehicleRolepkId attribute.
     * 
     * @generated
     */
    public String getCustomerVehicleRolepkId (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXCustomerVehicleRole.getCustomerVehicleRolepkId());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the customerVehicleRolepkId attribute.
     * 
     * @param newCustomerVehicleRolepkId
     *     The new value of customerVehicleRolepkId.
     * @generated
     */
    public void setCustomerVehicleRolepkId( String newCustomerVehicleRolepkId ) throws Exception {
        metaDataMap.put("CustomerVehicleRolepkId", newCustomerVehicleRolepkId);

        if (newCustomerVehicleRolepkId == null || newCustomerVehicleRolepkId.equals("")) {
            newCustomerVehicleRolepkId = null;


        }
        eObjXCustomerVehicleRole.setCustomerVehicleRolepkId( DWLFunctionUtils.getLongFromString(newCustomerVehicleRolepkId) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the customerVehicleId attribute.
     * 
     * @generated
     */
    public String getCustomerVehicleId (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXCustomerVehicleRole.getCustomerVehicleId());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the customerVehicleId attribute.
     * 
     * @param newCustomerVehicleId
     *     The new value of customerVehicleId.
     * @generated
     */
    public void setCustomerVehicleId( String newCustomerVehicleId ) throws Exception {
        metaDataMap.put("CustomerVehicleId", newCustomerVehicleId);

        if (newCustomerVehicleId == null || newCustomerVehicleId.equals("")) {
            newCustomerVehicleId = null;


        }
        eObjXCustomerVehicleRole.setCustomerVehicleId( DWLFunctionUtils.getLongFromString(newCustomerVehicleId) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the vehicleRoleType attribute.
     * 
     * @generated
     */
    public String getVehicleRoleType (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXCustomerVehicleRole.getVehicleRole());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the vehicleRoleType attribute.
     * 
     * @param newVehicleRoleType
     *     The new value of vehicleRoleType.
     * @generated
     */
    public void setVehicleRoleType( String newVehicleRoleType ) throws Exception {
        metaDataMap.put("VehicleRoleType", newVehicleRoleType);

        if (newVehicleRoleType == null || newVehicleRoleType.equals("")) {
            newVehicleRoleType = null;


        }
        eObjXCustomerVehicleRole.setVehicleRole( DWLFunctionUtils.getLongFromString(newVehicleRoleType) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the vehicleRoleValue attribute.
     * 
     * @generated
     */
    public String getVehicleRoleValue (){
      return vehicleRoleValue;
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the vehicleRoleValue attribute.
     * 
     * @param newVehicleRoleValue
     *     The new value of vehicleRoleValue.
     * @generated
     */
    public void setVehicleRoleValue( String newVehicleRoleValue ) throws Exception {
        metaDataMap.put("VehicleRoleValue", newVehicleRoleValue);

        if (newVehicleRoleValue == null || newVehicleRoleValue.equals("")) {
            newVehicleRoleValue = null;


        }
        vehicleRoleValue = newVehicleRoleValue;
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the sourceIdentifierType attribute.
     * 
     * @generated
     */
    public String getSourceIdentifierType (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXCustomerVehicleRole.getSourceIdentifier());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the sourceIdentifierType attribute.
     * 
     * @param newSourceIdentifierType
     *     The new value of sourceIdentifierType.
     * @generated
     */
    public void setSourceIdentifierType( String newSourceIdentifierType ) throws Exception {
        metaDataMap.put("SourceIdentifierType", newSourceIdentifierType);

        if (newSourceIdentifierType == null || newSourceIdentifierType.equals("")) {
            newSourceIdentifierType = null;


        }
        eObjXCustomerVehicleRole.setSourceIdentifier( DWLFunctionUtils.getLongFromString(newSourceIdentifierType) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the sourceIdentifierValue attribute.
     * 
     * @generated
     */
    public String getSourceIdentifierValue (){
      return sourceIdentifierValue;
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the sourceIdentifierValue attribute.
     * 
     * @param newSourceIdentifierValue
     *     The new value of sourceIdentifierValue.
     * @generated
     */
    public void setSourceIdentifierValue( String newSourceIdentifierValue ) throws Exception {
        metaDataMap.put("SourceIdentifierValue", newSourceIdentifierValue);

        if (newSourceIdentifierValue == null || newSourceIdentifierValue.equals("")) {
            newSourceIdentifierValue = null;


        }
        sourceIdentifierValue = newSourceIdentifierValue;
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the changedDate attribute.
     * 
     * @generated
     */
    public String getChangedDate (){
   
        return DWLFunctionUtils.getStringFromTimestamp(eObjXCustomerVehicleRole.getChangedDate());
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the changedDate attribute.
     * 
     * @param newChangedDate
     *     The new value of changedDate.
     * @generated
     */
    public void setChangedDate( String newChangedDate ) throws Exception {
        metaDataMap.put("ChangedDate", newChangedDate);
       	isValidChangedDate = true;

        if (newChangedDate == null || newChangedDate.equals("")) {
            newChangedDate = null;
            eObjXCustomerVehicleRole.setChangedDate(null);


        }
    else {
        	if (DateValidator.validates(newChangedDate)) {
           		eObjXCustomerVehicleRole.setChangedDate(DateFormatter.getStartDateTimestamp(newChangedDate));
            	metaDataMap.put("ChangedDate", getChangedDate());
        	} else {
            	if (Configuration.getConfiguration().getConfigItem(
              "/IBM/DWLCommonServices/InternalValidation/enabled").getBooleanValue()) {
                	if (metaDataMap.get("ChangedDate") != null) {
                    	metaDataMap.put("ChangedDate", "");
                	}
                	isValidChangedDate = false;
                	eObjXCustomerVehicleRole.setChangedDate(null);
            	}
        	}
        }
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the startDate attribute.
     * 
     * @generated
     */
    public String getStartDate (){
   
        return DWLFunctionUtils.getStringFromTimestamp(eObjXCustomerVehicleRole.getStartDate());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the startDate attribute.
     * 
     * @param newStartDate
     *     The new value of startDate.
     * @generated
     */
    public void setStartDate( String newStartDate ) throws Exception {
        metaDataMap.put("StartDate", newStartDate);
       	isValidStartDate = true;

        if (newStartDate == null || newStartDate.equals("")) {
            newStartDate = null;
            eObjXCustomerVehicleRole.setStartDate(null);


        }
    else {
        	if (DateValidator.validates(newStartDate)) {
           		eObjXCustomerVehicleRole.setStartDate(DateFormatter.getStartDateTimestamp(newStartDate));
            	metaDataMap.put("StartDate", getStartDate());
        	} else {
            	if (Configuration.getConfiguration().getConfigItem(
              "/IBM/DWLCommonServices/InternalValidation/enabled").getBooleanValue()) {
                	if (metaDataMap.get("StartDate") != null) {
                    	metaDataMap.put("StartDate", "");
                	}
                	isValidStartDate = false;
                	eObjXCustomerVehicleRole.setStartDate(null);
            	}
        	}
        }
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the endDate attribute.
     * 
     * @generated
     */
    public String getEndDate (){
   
        return DWLFunctionUtils.getStringFromTimestamp(eObjXCustomerVehicleRole.getEndDate());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the endDate attribute.
     * 
     * @param newEndDate
     *     The new value of endDate.
     * @generated
     */
    public void setEndDate( String newEndDate ) throws Exception {
        metaDataMap.put("EndDate", newEndDate);
       	isValidEndDate = true;

        if (newEndDate == null || newEndDate.equals("")) {
            newEndDate = null;
            eObjXCustomerVehicleRole.setEndDate(null);


        }
    else {
        	if (DateValidator.validates(newEndDate)) {
           		eObjXCustomerVehicleRole.setEndDate(DateFormatter.getStartDateTimestamp(newEndDate));
            	metaDataMap.put("EndDate", getEndDate());
        	} else {
            	if (Configuration.getConfiguration().getConfigItem(
              "/IBM/DWLCommonServices/InternalValidation/enabled").getBooleanValue()) {
                	if (metaDataMap.get("EndDate") != null) {
                    	metaDataMap.put("EndDate", "");
                	}
                	isValidEndDate = false;
                	eObjXCustomerVehicleRole.setEndDate(null);
            	}
        	}
        }
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateTxId attribute.
     *
     * @generated
     */
    public String getXCustomerVehicleRoleLastUpdateTxId() {
        return DWLFunctionUtils.getStringFromLong(eObjXCustomerVehicleRole.getLastUpdateTxId());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateUser attribute.
     *
     * @generated
     */
    public String getXCustomerVehicleRoleLastUpdateUser() {
        return eObjXCustomerVehicleRole.getLastUpdateUser();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateDt attribute.
     *
     * @generated
     */
    public String getXCustomerVehicleRoleLastUpdateDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXCustomerVehicleRole.getLastUpdateDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateTxId attribute.
     *
     * @param newLastUpdateTxId
     *     The new value of LastUpdateTxId.
     * @generated
     */
    public void setXCustomerVehicleRoleLastUpdateTxId(String newLastUpdateTxId) {
        metaDataMap.put("XCustomerVehicleRoleLastUpdateTxId", newLastUpdateTxId);

        if ((newLastUpdateTxId == null) || newLastUpdateTxId.equals("")) {
            newLastUpdateTxId = null;
        }
        eObjXCustomerVehicleRole.setLastUpdateTxId(DWLFunctionUtils.getLongFromString(newLastUpdateTxId));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateUser attribute.
     *
     * @param newLastUpdateUser
     *     The new value of LastUpdateUser.
     * @generated
     */
    public void setXCustomerVehicleRoleLastUpdateUser(String newLastUpdateUser) {
        metaDataMap.put("XCustomerVehicleRoleLastUpdateUser", newLastUpdateUser);

        if ((newLastUpdateUser == null) || newLastUpdateUser.equals("")) {
            newLastUpdateUser = null;
        }
        eObjXCustomerVehicleRole.setLastUpdateUser(newLastUpdateUser);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateDt attribute.
     *
     * @param newLastUpdateDt
     *     The new value of LastUpdateDt.
     * @throws Exception
     * @generated
     */
    public void setXCustomerVehicleRoleLastUpdateDate(String newLastUpdateDt) throws Exception {
        metaDataMap.put("XCustomerVehicleRoleLastUpdateDate", newLastUpdateDt);

        if ((newLastUpdateDt == null) || newLastUpdateDt.equals("")) {
            newLastUpdateDt = null;
        }

        eObjXCustomerVehicleRole.setLastUpdateDt(DWLFunctionUtils.getTimestampFromTimestampString(newLastUpdateDt));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XCustomerVehicleRoleHistActionCode history attribute.
     *
     * @generated
     */
    public String getXCustomerVehicleRoleHistActionCode() {
        return eObjXCustomerVehicleRole.getHistActionCode();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XCustomerVehicleRoleHistActionCode history attribute.
     *
     * @param aXCustomerVehicleRoleHistActionCode
     *     The new value of XCustomerVehicleRoleHistActionCode.
     * @generated
     */
    public void setXCustomerVehicleRoleHistActionCode(String aXCustomerVehicleRoleHistActionCode) {
        metaDataMap.put("XCustomerVehicleRoleHistActionCode", aXCustomerVehicleRoleHistActionCode);

        if ((aXCustomerVehicleRoleHistActionCode == null) || aXCustomerVehicleRoleHistActionCode.equals("")) {
            aXCustomerVehicleRoleHistActionCode = null;
        }
        eObjXCustomerVehicleRole.setHistActionCode(aXCustomerVehicleRoleHistActionCode);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XCustomerVehicleRoleHistCreateDate history attribute.
     *
     * @generated
     */
    public String getXCustomerVehicleRoleHistCreateDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXCustomerVehicleRole.getHistCreateDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XCustomerVehicleRoleHistCreateDate history attribute.
     *
     * @param aXCustomerVehicleRoleHistCreateDate
     *     The new value of XCustomerVehicleRoleHistCreateDate.
     * @generated
     */
    public void setXCustomerVehicleRoleHistCreateDate(String aXCustomerVehicleRoleHistCreateDate) throws Exception{
        metaDataMap.put("XCustomerVehicleRoleHistCreateDate", aXCustomerVehicleRoleHistCreateDate);

        if ((aXCustomerVehicleRoleHistCreateDate == null) || aXCustomerVehicleRoleHistCreateDate.equals("")) {
            aXCustomerVehicleRoleHistCreateDate = null;
        }

        eObjXCustomerVehicleRole.setHistCreateDt(DWLFunctionUtils.getTimestampFromTimestampString(aXCustomerVehicleRoleHistCreateDate));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XCustomerVehicleRoleHistCreatedBy history attribute.
     *
     * @generated
     */
    public String getXCustomerVehicleRoleHistCreatedBy() {
        return eObjXCustomerVehicleRole.getHistCreatedBy();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XCustomerVehicleRoleHistCreatedBy history attribute.
     *
     * @param aXCustomerVehicleRoleHistCreatedBy
     *     The new value of XCustomerVehicleRoleHistCreatedBy.
     * @generated
     */
    public void setXCustomerVehicleRoleHistCreatedBy(String aXCustomerVehicleRoleHistCreatedBy) {
        metaDataMap.put("XCustomerVehicleRoleHistCreatedBy", aXCustomerVehicleRoleHistCreatedBy);

        if ((aXCustomerVehicleRoleHistCreatedBy == null) || aXCustomerVehicleRoleHistCreatedBy.equals("")) {
            aXCustomerVehicleRoleHistCreatedBy = null;
        }

        eObjXCustomerVehicleRole.setHistCreatedBy(aXCustomerVehicleRoleHistCreatedBy);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XCustomerVehicleRoleHistEndDate history attribute.
     *
     * @generated
     */
    public String getXCustomerVehicleRoleHistEndDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXCustomerVehicleRole.getHistEndDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XCustomerVehicleRoleHistEndDate history attribute.
     *
     * @param aXCustomerVehicleRoleHistEndDate
     *     The new value of XCustomerVehicleRoleHistEndDate.
     * @generated
     */
    public void setXCustomerVehicleRoleHistEndDate(String aXCustomerVehicleRoleHistEndDate) throws Exception{
        metaDataMap.put("XCustomerVehicleRoleHistEndDate", aXCustomerVehicleRoleHistEndDate);

        if ((aXCustomerVehicleRoleHistEndDate == null) || aXCustomerVehicleRoleHistEndDate.equals("")) {
            aXCustomerVehicleRoleHistEndDate = null;
        }
        eObjXCustomerVehicleRole.setHistEndDt(DWLFunctionUtils.getTimestampFromTimestampString(aXCustomerVehicleRoleHistEndDate));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XCustomerVehicleRoleHistoryIdPK history attribute.
     *
     * @generated
     */
    public String getXCustomerVehicleRoleHistoryIdPK() {
        return DWLFunctionUtils.getStringFromLong(eObjXCustomerVehicleRole.getHistoryIdPK());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XCustomerVehicleRoleHistoryIdPK history attribute.
     *
     * @param aXCustomerVehicleRoleHistoryIdPK
     *     The new value of XCustomerVehicleRoleHistoryIdPK.
     * @generated
     */
    public void setXCustomerVehicleRoleHistoryIdPK(String aXCustomerVehicleRoleHistoryIdPK) {
        metaDataMap.put("XCustomerVehicleRoleHistoryIdPK", aXCustomerVehicleRoleHistoryIdPK);

        if ((aXCustomerVehicleRoleHistoryIdPK == null) || aXCustomerVehicleRoleHistoryIdPK.equals("")) {
            aXCustomerVehicleRoleHistoryIdPK = null;
        }
        eObjXCustomerVehicleRole.setHistoryIdPK(DWLFunctionUtils.getLongFromString(aXCustomerVehicleRoleHistoryIdPK));
    }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation during an add transaction.
     *
     * @generated
     */
    public DWLStatus validateAdd(int level, DWLStatus status) throws Exception {

        status = super.validateAdd(level, status);
        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0038I Add any controller-level custom validation logic to be
            // executed for this object during an "add" transaction

        }

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            // MDM_TODO0: CDKWB0039I Add any component-level custom validation logic to be
            // executed for this object during an "add" transaction
        }
        status = getValidationStatus(level, status);
        return status;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation during an update transaction.
     *
     * @generated
     */
    public DWLStatus validateUpdate(int level, DWLStatus status) throws Exception {
    logger.finest("ENTER validateUpdate(int level, DWLStatus status)");

        status = super.validateUpdate(level, status);
        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0040I Add any controller-level custom validation logic to be
            // executed for this object during an "update" transaction

            if (eObjXCustomerVehicleRole.getCustomerVehicleRolepkId() == null) {
                DWLError err = new DWLError();
                err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_ROLE_BOBJ).longValue());
                err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.XCUSTOMERVEHICLEROLE_CUSTOMERVEHICLEROLEPKID_NULL).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                	String infoForLogging="Error: Validation error occured for update. No primary key for entity XCustomerVehicleRole, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("validateUpdate(int level, DWLStatus status) " + infoForLogging);
                }
                status.addError(err);
            }
            if (eObjXCustomerVehicleRole.getLastUpdateDt() == null) {
                DWLError err = new DWLError();
                err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_ROLE_BOBJ).longValue());
                err.setReasonCode(new Long(DWLUtilErrorReasonCode.LAST_UPDATED_DATE_NULL).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
                if (logger.isFinestEnabled()) {
                	String infoForLogging="Error: Validation error occured for update. No last update date for entity XCustomerVehicleRole, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("validateUpdate(int level, DWLStatus status) " + infoForLogging);
                }
                status.addError(err);
            }
        }

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            assignBeforeImageValues(metaDataMap);
            
            // MDM_TODO0: CDKWB0041I Add any component-level custom validation logic to be
            // executed for this object during an "update" transaction
        }
        status = getValidationStatus(level, status);
    if (logger.isFinestEnabled()) {
        	String returnValue = status.toString();
      logger.finest("RETURN validateUpdate(int level, DWLStatus status) " + returnValue);
    }
        return status;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Populate the before image of this business object.
     *
     * @see com.dwl.base.DWLCommon#populateBeforeImage()
     * @generated
     */
    public void populateBeforeImage() throws DWLBaseException {
    logger.finest("ENTER populateBeforeImage()");

        DSEAAdditionsExts comp = null;
        try {
        
      comp = (DSEAAdditionsExts)TCRMClassFactory.getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
        	
        } catch (Exception e) {
      if (logger.isFinestEnabled()) {
        String infoForLogging="Error: Fatal error while updating record " + e.getMessage();
      logger.finest("populateBeforeImage() " + infoForLogging);
      }
            DWLExceptionUtils.throwDWLBaseException(e, 
            									new DWLUpdateException(e.getMessage()), 
            									this.getStatus(), DWLStatus.FATAL,
                                  DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_ROLE_BOBJ, 
                                  "DIERR",
                                  DSEAAdditionsExtsErrorReasonCode.XCUSTOMERVEHICLEROLE_BEFORE_IMAGE_NOT_POPULATED, 
                                  this.getControl());
        }
        
        comp.loadBeforeImage(this);
    logger.finest("RETURN populateBeforeImage()");
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation common to both add and update transactions.
     *
     * @generated
     */
     
    private DWLStatus getValidationStatus(int level, DWLStatus status) throws Exception {
    logger.finest("ENTER getValidationStatus(int level, DWLStatus status)");

        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0034I Add any common controller-level custom validation
            // logic to be executed for this object during either "add" or
            // "update" transactions
    		controllerValidation_VehicleRole(status);
    		controllerValidation_StartDate(status);
    		controllerValidation_EndDate(status);
    		controllerValidation_SourceIdentifier(status);
    		controllerValidation_ChangedDate(status);
    	}

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            // MDM_TODO0: CDKWB0035I Add any common component-level custom validation logic
            // to be executed for this object during either "add" or "update"
            // transactions
    		componentValidation_VehicleRole(status);
    		componentValidation_StartDate(status);
    		componentValidation_EndDate(status);
    		componentValidation_SourceIdentifier(status);
    		componentValidation_ChangedDate(status);
        }
        
        if (logger.isFinestEnabled()) {
            String returnValue = status.toString();
      logger.finest("RETURN getValidationStatus(int level, DWLStatus status) " + returnValue);
        }
    
        return status;
    }

    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "VehicleRole"
     *
     * @generated
     */
	private void componentValidation_VehicleRole(DWLStatus status) {
  
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "SourceIdentifier"
     *
     * @generated
     */
	private void componentValidation_SourceIdentifier(DWLStatus status) {
  
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "ChangedDate"
     *
     * @generated
     */
  private void componentValidation_ChangedDate(DWLStatus status) {
  
  }	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "StartDate"
     *
     * @generated
     */
	private void componentValidation_StartDate(DWLStatus status) {
  
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "EndDate"
     *
     * @generated
     */
	private void componentValidation_EndDate(DWLStatus status) {
  
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "VehicleRole"
     *
     * @generated
     */
	private void controllerValidation_VehicleRole(DWLStatus status) throws Exception {
  
      //persistent code type
            boolean isVehicleRoleNull = false;
            if ((eObjXCustomerVehicleRole.getVehicleRole() == null) &&
               ((getVehicleRoleValue() == null) || 
                 getVehicleRoleValue().trim().equals(""))) {
                isVehicleRoleNull = true;
            }
            if (!isVehicleRoleNull) {
                if (checkForInvalidXcustomervehicleroleVehiclerole()) {
                    DWLError err = new DWLError();
                    err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_ROLE_BOBJ).longValue());
                    err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XCUSTOMERVEHICLEROLE_VEHICLEROLE).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                    String infoForLogging="Error: Custom validation error occured for entity XCustomerVehicleRole, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("controllerValidation_VehicleRole " + infoForLogging);
        }
                status.addError(err);
            }

             }
    			
    	}
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "SourceIdentifier"
     *
     * @generated
     */
	private void controllerValidation_SourceIdentifier(DWLStatus status) throws Exception {
  
      //persistent code type
            boolean isSourceIdentifierNull = false;
            if ((eObjXCustomerVehicleRole.getSourceIdentifier() == null) &&
               ((getSourceIdentifierValue() == null) || 
                 getSourceIdentifierValue().trim().equals(""))) {
                isSourceIdentifierNull = true;
            }
            if (!isSourceIdentifierNull) {
                if (checkForInvalidXcustomervehicleroleSourceidentifier()) {
                    DWLError err = new DWLError();
                    err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_ROLE_BOBJ).longValue());
                    err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XCUSTOMERVEHICLEROLE_SOURCEIDENTIFIER).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                    String infoForLogging="Error: Custom validation error occured for entity XCustomerVehicleRole, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("controllerValidation_SourceIdentifier " + infoForLogging);
        }
                status.addError(err);
            }

             }
    			
    	}
    	
	 /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "ChangedDate"
     *
     * @generated
     */
  private void controllerValidation_ChangedDate(DWLStatus status) throws Exception {
  
            boolean isChangedDateNull = (eObjXCustomerVehicleRole.getChangedDate() == null);
            if (!isValidChangedDate) {
              	DWLError err = new DWLError();
               	err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_ROLE_BOBJ).longValue());
               	err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XCUSTOMERVEHICLEROLE_CHANGEDDATE).longValue());
               	err.setErrorType(DWLErrorCode.DATA_INVALID_ERROR);
                String infoForLogging="Error: Validation error. Invalid time specified on property ChangedDate in entity XCustomerVehicleRole, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode();
      logger.finest("controllerValidation_ChangedDate " + infoForLogging);
               	status.addError(err);
            } 
    	}
	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "StartDate"
     *
     * @generated
     */
	private void controllerValidation_StartDate(DWLStatus status) throws Exception {
  
            boolean isStartDateNull = (eObjXCustomerVehicleRole.getStartDate() == null);
            if (!isValidStartDate) {
              	DWLError err = new DWLError();
               	err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_ROLE_BOBJ).longValue());
               	err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XCUSTOMERVEHICLEROLE_STARTDATE).longValue());
               	err.setErrorType(DWLErrorCode.DATA_INVALID_ERROR);
                String infoForLogging="Error: Validation error. Invalid time specified on property StartDate in entity XCustomerVehicleRole, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode();
      logger.finest("controllerValidation_StartDate " + infoForLogging);
               	status.addError(err);
            } 
    	}
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "EndDate"
     *
     * @generated
     */
	private void controllerValidation_EndDate(DWLStatus status) throws Exception {
  
            boolean isEndDateNull = (eObjXCustomerVehicleRole.getEndDate() == null);
            if (!isValidEndDate) {
              	DWLError err = new DWLError();
               	err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_ROLE_BOBJ).longValue());
               	err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XCUSTOMERVEHICLEROLE_ENDDATE).longValue());
               	err.setErrorType(DWLErrorCode.DATA_INVALID_ERROR);
                String infoForLogging="Error: Validation error. Invalid time specified on property EndDate in entity XCustomerVehicleRole, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode();
      logger.finest("controllerValidation_EndDate " + infoForLogging);
               	status.addError(err);
            } 
    	}
    private DWLError createDWLError(String entityName, String propertyName,String reasonCode){	
		DWLError err = new DWLError();
		err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_ROLE_BOBJ).longValue());
		err.setReasonCode(new Long(reasonCode).longValue());
		err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
			String infoForLogging="Error: Validation error occured. Property " + propertyName + " is null, in entity " + entityName + ", component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
			logger.finest("createDWLError " + infoForLogging);
		}
		return err;
    }
    
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Check the value of the field VehicleRole and return true if the error
     * reason INVALID_XCUSTOMERVEHICLEROLE_VEHICLEROLE should be returned.
     *
     * @generated
  **/
	private boolean checkForInvalidXcustomervehicleroleVehiclerole() throws Exception {
    logger.finest("ENTER checkForInvalidXcustomervehicleroleVehiclerole()");
        boolean notValid = false;
      	String langId = (String) this.getControl().get(DWLControlKeys.LANG_ID);
      	CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
    Long codeType = DWLFunctionUtils.getLongFromString( getVehicleRoleType() );
    String codeValue = getVehicleRoleValue();
    if( codeValue != null && codeValue.trim().equals("")){
      codeValue = null;
    }
     
        if ( codeType != null && codeValue == null ){

             if( codeTypeCompHelper.isCodeValid("xcdvehicleroletp", langId, getVehicleRoleType(),
                 CodeTypeComponentHelper.ACTIVE, getControl())) {
                 CodeTypeBObj ctBObj = codeTypeCompHelper
                 					.getCodeTypeByCode("xcdvehicleroletp", langId, getVehicleRoleType(),
                         								getControl());
               	if (ctBObj != null) {
                   	setVehicleRoleValue( ctBObj.getvalue() );
               	}
             }
             else{
             	if (logger.isFinestEnabled()) {
              	 	String infoForLogging="NotValid 1";
      logger.finest("checkForInvalidXcustomervehicleroleVehiclerole() " + infoForLogging);
        }
                 notValid = true;
           }
        }
        else if (codeType == null && codeValue != null ){
          
             CodeTypeBObj ctBObj = codeTypeCompHelper
                      .getCodeTypeByValue("xcdvehicleroletp", langId, codeValue,
                                 getControl());

             if (ctBObj != null) {
                 setVehicleRoleType(ctBObj.gettp_cd());
             } 
             else {
             	if (logger.isFinestEnabled()) {
              	  	String infoForLogging="NotValid 2";
      logger.finest("checkForInvalidXcustomervehicleroleVehiclerole() " + infoForLogging);
        }
                  notValid = true;
             }
        }
        else if ( codeType != null && codeValue != null
             && !codeTypeCompHelper.isCodeValuePairValid("xcdvehicleroletp", langId, getVehicleRoleType(), 
                     new String[] { codeValue }, CodeTypeComponentHelper.ACTIVE, getControl())) {	
       if (logger.isFinestEnabled()) {
       		String infoForLogging="NotValid 3";
      logger.finest("checkForInvalidXcustomervehicleroleVehiclerole() " + infoForLogging);
       }
             notValid = true;
        }
        if (logger.isFinestEnabled()) {
      String returnValue ="" +notValid;
      logger.finest("RETURN checkForInvalidXcustomervehicleroleVehiclerole() " + returnValue);
    }
    return notValid;
     } 
				 
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Check the value of the field SourceIdentifier and return true if the
     * error reason INVALID_XCUSTOMERVEHICLEROLE_SOURCEIDENTIFIER should be
     * returned.
     *
     * @generated
  **/
	private boolean checkForInvalidXcustomervehicleroleSourceidentifier() throws Exception {
    logger.finest("ENTER checkForInvalidXcustomervehicleroleSourceidentifier()");
        boolean notValid = false;
      	String langId = (String) this.getControl().get(DWLControlKeys.LANG_ID);
      	CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
    Long codeType = DWLFunctionUtils.getLongFromString( getSourceIdentifierType() );
    String codeValue = getSourceIdentifierValue();
    if( codeValue != null && codeValue.trim().equals("")){
      codeValue = null;
    }
     
        if ( codeType != null && codeValue == null ){

             if( codeTypeCompHelper.isCodeValid("cdsourceidenttp", langId, getSourceIdentifierType(),
                 CodeTypeComponentHelper.ACTIVE, getControl())) {
                 CodeTypeBObj ctBObj = codeTypeCompHelper
                 					.getCodeTypeByCode("cdsourceidenttp", langId, getSourceIdentifierType(),
                         								getControl());
               	if (ctBObj != null) {
                   	setSourceIdentifierValue( ctBObj.getvalue() );
               	}
             }
             else{
             	if (logger.isFinestEnabled()) {
              	 	String infoForLogging="NotValid 1";
      logger.finest("checkForInvalidXcustomervehicleroleSourceidentifier() " + infoForLogging);
        }
                 notValid = true;
           }
        }
        else if (codeType == null && codeValue != null ){
          
             CodeTypeBObj ctBObj = codeTypeCompHelper
                      .getCodeTypeByValue("cdsourceidenttp", langId, codeValue,
                                 getControl());

             if (ctBObj != null) {
                 setSourceIdentifierType(ctBObj.gettp_cd());
             } 
             else {
             	if (logger.isFinestEnabled()) {
              	  	String infoForLogging="NotValid 2";
      logger.finest("checkForInvalidXcustomervehicleroleSourceidentifier() " + infoForLogging);
        }
                  notValid = true;
             }
        }
        else if ( codeType != null && codeValue != null
             && !codeTypeCompHelper.isCodeValuePairValid("cdsourceidenttp", langId, getSourceIdentifierType(), 
                     new String[] { codeValue }, CodeTypeComponentHelper.ACTIVE, getControl())) {	
       if (logger.isFinestEnabled()) {
       		String infoForLogging="NotValid 3";
      logger.finest("checkForInvalidXcustomervehicleroleSourceidentifier() " + infoForLogging);
       }
             notValid = true;
        }
        if (logger.isFinestEnabled()) {
      String returnValue ="" +notValid;
      logger.finest("RETURN checkForInvalidXcustomervehicleroleSourceidentifier() " + returnValue);
    }
    return notValid;
     } 
				 



}

