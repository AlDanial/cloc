
/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[d69337dcbf9bd833417ed049d30e7fae]
 */

package com.ibm.daimler.dsea.component;

import java.util.Vector;

import com.dwl.base.util.DWLClassFactory;
import com.dwl.tcrm.exception.TCRMReadException;



import com.dwl.base.DWLControl;
import com.dwl.base.IDWLErrorMessage;
import com.dwl.base.constant.DWLControlKeys;
import com.dwl.base.error.DWLError;
import com.dwl.base.error.DWLErrorCode;
import com.dwl.base.error.DWLStatus;
import com.dwl.base.exception.DWLBaseException;
import com.dwl.base.util.DWLExceptionUtils;
import com.dwl.base.util.DWLFunctionUtils;
import com.dwl.management.config.client.Configuration;
import com.dwl.tcrm.common.IExtension;
import com.dwl.tcrm.common.ITCRMValidation;
import com.dwl.tcrm.common.TCRMErrorCode;
import com.dwl.tcrm.coreParty.component.TCRMOrganizationBObj;
import com.dwl.tcrm.utilities.DateFormatter;
import com.dwl.tcrm.utilities.DateValidator;
import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsComponentID;
import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsErrorReasonCode;
import com.ibm.daimler.dsea.entityObject.EObjXOrgExt;
import com.ibm.mdm.common.codetype.interfaces.CodeTypeComponentHelper;
import com.ibm.mdm.common.codetype.obj.CodeTypeBObj;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * This class provides the implementation of the business object
 * <code>XOrgBObjExt</code>.
 * 
 * @see com.dwl.tcrm.common.TCRMCommon
 * @generated
 */
 

@SuppressWarnings("serial")
public class XOrgBObjExt extends TCRMOrganizationBObj implements IExtension {

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected EObjXOrgExt eObjXOrgExt;
    protected Vector<XCustomerRetailerBObj> vecXCustomerRetailerBObj = new Vector<XCustomerRetailerBObj>();    
	/**
    * <!-- begin-user-doc -->
	  * <!-- end-user-doc -->
    * @generated 
    */
	 private final static com.dwl.base.logging.IDWLLogger logger = com.dwl.base.logging.DWLLoggerManager.getLogger(XOrgBObjExt.class);
		
 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected String xNumberOfEmployeesValue;


    protected boolean isValidXLastModifiedSystemDate = true;
    
    protected Vector<XDataSharingBObj> vecXDataSharingBObj;    
    protected Vector<XConsentBObj> vecXConsentBObj;


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected String xCorporateCategoryValue;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected String xCorporateGroupValue;


    protected boolean isValidLastActivityDate = true;


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated NOT
     */     
    public XOrgBObjExt() {
        super();
        init();
        eObjXOrgExt = new EObjXOrgExt(getEObjOrganization());
        vecXDataSharingBObj = new Vector<XDataSharingBObj>();
        vecXConsentBObj = new Vector<XConsentBObj>();
        setComponentID(DSEAAdditionsExtsComponentID.XORG_BOBJ_EXT);
    }
    
    public Vector<XDataSharingBObj> getItemsXDataSharingBObj() {
	      return this.vecXDataSharingBObj;
	}
	public void setXDataSharingBObj(XDataSharingBObj newXDataSharingBObj) {
		  this.vecXDataSharingBObj.addElement(newXDataSharingBObj);
	}
	  
	public Vector<XConsentBObj> getItemsXConsentBObj() {
		   return this.vecXConsentBObj;
	}
	public void setXConsentBObj(XConsentBObj newXConsentBObj) {
		   this.vecXConsentBObj.addElement(newXConsentBObj);
	}

    public Vector<XCustomerRetailerBObj> getItemsXCustomerRetailerBObj() {
		return this.vecXCustomerRetailerBObj;
	}


	public void setXCustomerRetailerBObj(
			XCustomerRetailerBObj newXCustomerRetailerBObj) {
		this.vecXCustomerRetailerBObj.addElement(newXCustomerRetailerBObj);
	}

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Initializes the fields required to populate the metaDataMap. Each key is
     * an element-level field of the business object.
     *
     * @generated
     */
    private void init() {
        metaDataMap.put("XDefunctInd", null);
        metaDataMap.put("XWebsite", null);
        metaDataMap.put("XMarketName", null);
        metaDataMap.put("XBatchInd", null);
        metaDataMap.put("XNumberOfEmployeesType", null);
        metaDataMap.put("XNumberOfEmployeesValue", null);
        metaDataMap.put("XLastModifiedSystemDate", null);
        metaDataMap.put("XSourceTypeFlag", null);
        metaDataMap.put("XGenerated_by", null);
        metaDataMap.put("XCorporateCategoryType", null);
        metaDataMap.put("XCorporateCategoryValue", null);
        metaDataMap.put("XCorporateGroupType", null);
        metaDataMap.put("XCorporateGroupValue", null);
        metaDataMap.put("XPersonalAgreement", null);
        metaDataMap.put("XDoNotMergeFlag", null);
        metaDataMap.put("DeleteFlag", null);
        metaDataMap.put("InfoRemoveFlag", null);
        metaDataMap.put("DedupHiddenFlag", null);
        metaDataMap.put("PrefCommunicationChannel", null);
        metaDataMap.put("YanaseFlag", null);
        metaDataMap.put("FinancePartyType", null);
        metaDataMap.put("ContractNumber", null);
        metaDataMap.put("XPrivacyAct", null);
        metaDataMap.put("XFleet", null);
        metaDataMap.put("XPC_Ind", null);
        metaDataMap.put("XVANS_Ind", null);
        metaDataMap.put("LastActivityDate", null);
        metaDataMap.put("X_CUST_TYPE", null);
        metaDataMap.put("XOrgHistActionCode", null);
        metaDataMap.put("XOrgHistCreateDate", null);
        metaDataMap.put("XOrgHistCreatedBy", null);
        metaDataMap.put("XOrgHistEndDate", null);
        metaDataMap.put("XOrgHistoryIdPK", null);
        metaDataMap.put("XOrgLastUpdateDate", null);
        metaDataMap.put("XOrgLastUpdateTxId", null);
        metaDataMap.put("XOrgLastUpdateUser", null);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Refreshes all the attributes this business object supports.
     *
     * @see com.dwl.base.DWLCommon#refreshMap()
     * @generated
     */
    public void refreshMap() {

        if (bRequireMapRefresh) {
            super.refreshMap();
            metaDataMap.put("XDefunctInd", getXDefunctInd());
            metaDataMap.put("XWebsite", getXWebsite());
            metaDataMap.put("XMarketName", getXMarketName());
            metaDataMap.put("XBatchInd", getXBatchInd());
            metaDataMap.put("XNumberOfEmployeesType", getXNumberOfEmployeesType());
            metaDataMap.put("XNumberOfEmployeesValue", getXNumberOfEmployeesValue());
            metaDataMap.put("XLastModifiedSystemDate", getXLastModifiedSystemDate());
            metaDataMap.put("XSourceTypeFlag", getXSourceTypeFlag());
            metaDataMap.put("XGenerated_by", getXGenerated_by());
            metaDataMap.put("XCorporateCategoryType", getXCorporateCategoryType());
            metaDataMap.put("XCorporateCategoryValue", getXCorporateCategoryValue());
            metaDataMap.put("XCorporateGroupType", getXCorporateGroupType());
            metaDataMap.put("XCorporateGroupValue", getXCorporateGroupValue());
            metaDataMap.put("XPersonalAgreement", getXPersonalAgreement());
            metaDataMap.put("XDoNotMergeFlag", getXDoNotMergeFlag());
            metaDataMap.put("DeleteFlag", getDeleteFlag());
            metaDataMap.put("InfoRemoveFlag", getInfoRemoveFlag());
            metaDataMap.put("DedupHiddenFlag", getDedupHiddenFlag());
            metaDataMap.put("PrefCommunicationChannel", getPrefCommunicationChannel());
            metaDataMap.put("YanaseFlag", getYanaseFlag());
            metaDataMap.put("FinancePartyType", getFinancePartyType());
            metaDataMap.put("ContractNumber", getContractNumber());
            metaDataMap.put("XPrivacyAct", getXPrivacyAct());
            metaDataMap.put("XFleet", getXFleet());
            metaDataMap.put("XPC_Ind", getXPC_Ind());
            metaDataMap.put("XVANS_Ind", getXVANS_Ind());
            metaDataMap.put("LastActivityDate", getLastActivityDate());
            metaDataMap.put("X_CUST_TYPE", getX_CUST_TYPE());
            metaDataMap.put("XOrgHistActionCode", getXOrgHistActionCode());
            metaDataMap.put("XOrgHistCreateDate", getXOrgHistCreateDate());
            metaDataMap.put("XOrgHistCreatedBy", getXOrgHistCreatedBy());
            metaDataMap.put("XOrgHistEndDate", getXOrgHistEndDate());
            metaDataMap.put("XOrgHistoryIdPK", getXOrgHistoryIdPK());
            metaDataMap.put("XOrgLastUpdateDate", getXOrgLastUpdateDate());
            metaDataMap.put("XOrgLastUpdateTxId", getXOrgLastUpdateTxId());
            metaDataMap.put("XOrgLastUpdateUser", getXOrgLastUpdateUser());
            bRequireMapRefresh = false;
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the control object on this business object.
     *
     * @see com.dwl.base.DWLCommon#setControl(DWLControl)
     * @generated
     */
    public void setControl(DWLControl newDWLControl) {
        super.setControl(newDWLControl);

        if (eObjXOrgExt != null) {
            eObjXOrgExt.setControl(newDWLControl);
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the entity object associated with this business object.
     *
     * @generated
     */
    public EObjXOrgExt getEObjXOrgExt() {
        bRequireMapRefresh = true;
        return eObjXOrgExt;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the entity object associated with this business object.
     *
     * @param eObjXOrgExt
     *            The eObjXOrgExt to set.
     * @generated
     */
    public void setEObjXOrgExt(EObjXOrgExt eObjXOrgExt) {
        bRequireMapRefresh = true;
        this.eObjXOrgExt = eObjXOrgExt;
        this.eObjXOrgExt.setBaseEntity(getEObjOrganization());
        if (this.eObjXOrgExt != null && this.eObjXOrgExt.getControl() == null) {
            DWLControl control = this.getControl();
            if (control != null) {
                this.eObjXOrgExt.setControl(control);
            }
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xDefunctInd attribute.
     * 
     * @generated
     */
    public String getXDefunctInd (){
   
        return eObjXOrgExt.getXDefunctInd();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xDefunctInd attribute.
     * 
     * @param newXDefunctInd
     *     The new value of xDefunctInd.
     * @generated
     */
    public void setXDefunctInd( String newXDefunctInd ) throws Exception {
        metaDataMap.put("XDefunctInd", newXDefunctInd);

        if (newXDefunctInd == null || newXDefunctInd.equals("")) {
            newXDefunctInd = null;


        }
        eObjXOrgExt.setXDefunctInd( newXDefunctInd );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xWebsite attribute.
     * 
     * @generated
     */
    public String getXWebsite (){
   
        return eObjXOrgExt.getXWebsite();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xWebsite attribute.
     * 
     * @param newXWebsite
     *     The new value of xWebsite.
     * @generated
     */
    public void setXWebsite( String newXWebsite ) throws Exception {
        metaDataMap.put("XWebsite", newXWebsite);

        if (newXWebsite == null || newXWebsite.equals("")) {
            newXWebsite = null;


        }
        eObjXOrgExt.setXWebsite( newXWebsite );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xMarketName attribute.
     * 
     * @generated
     */
    public String getXMarketName (){
   
        return eObjXOrgExt.getXMarketName();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xMarketName attribute.
     * 
     * @param newXMarketName
     *     The new value of xMarketName.
     * @generated
     */
    public void setXMarketName( String newXMarketName ) throws Exception {
        metaDataMap.put("XMarketName", newXMarketName);

        if (newXMarketName == null || newXMarketName.equals("")) {
            newXMarketName = null;


        }
        eObjXOrgExt.setXMarketName( newXMarketName );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xBatchInd attribute.
     * 
     * @generated
     */
    public String getXBatchInd (){
   
        return eObjXOrgExt.getXBatchInd();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xBatchInd attribute.
     * 
     * @param newXBatchInd
     *     The new value of xBatchInd.
     * @generated
     */
    public void setXBatchInd( String newXBatchInd ) throws Exception {
        metaDataMap.put("XBatchInd", newXBatchInd);

        if (newXBatchInd == null || newXBatchInd.equals("")) {
            newXBatchInd = null;


        }
        eObjXOrgExt.setXBatchInd( newXBatchInd );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xNumberOfEmployeesType attribute.
     * 
     * @generated
     */
    public String getXNumberOfEmployeesType (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXOrgExt.getXNumberOfEmployees());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xNumberOfEmployeesType attribute.
     * 
     * @param newXNumberOfEmployeesType
     *     The new value of xNumberOfEmployeesType.
     * @generated
     */
    public void setXNumberOfEmployeesType( String newXNumberOfEmployeesType ) throws Exception {
        metaDataMap.put("XNumberOfEmployeesType", newXNumberOfEmployeesType);

        if (newXNumberOfEmployeesType == null || newXNumberOfEmployeesType.equals("")) {
            newXNumberOfEmployeesType = null;


        }
        eObjXOrgExt.setXNumberOfEmployees( DWLFunctionUtils.getLongFromString(newXNumberOfEmployeesType) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xNumberOfEmployeesValue attribute.
     * 
     * @generated
     */
    public String getXNumberOfEmployeesValue (){
      return xNumberOfEmployeesValue;
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xNumberOfEmployeesValue attribute.
     * 
     * @param newXNumberOfEmployeesValue
     *     The new value of xNumberOfEmployeesValue.
     * @generated
     */
    public void setXNumberOfEmployeesValue( String newXNumberOfEmployeesValue ) throws Exception {
        metaDataMap.put("XNumberOfEmployeesValue", newXNumberOfEmployeesValue);

        if (newXNumberOfEmployeesValue == null || newXNumberOfEmployeesValue.equals("")) {
            newXNumberOfEmployeesValue = null;


        }
        xNumberOfEmployeesValue = newXNumberOfEmployeesValue;
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xSourceTypeFlag attribute.
     * 
     * @generated
     */
    public String getXSourceTypeFlag (){
   
        return eObjXOrgExt.getXSourceTypeFlag();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xSourceTypeFlag attribute.
     * 
     * @param newXSourceTypeFlag
     *     The new value of xSourceTypeFlag.
     * @generated
     */
    public void setXSourceTypeFlag( String newXSourceTypeFlag ) throws Exception {
        metaDataMap.put("XSourceTypeFlag", newXSourceTypeFlag);

        if (newXSourceTypeFlag == null || newXSourceTypeFlag.equals("")) {
            newXSourceTypeFlag = null;


        }
        eObjXOrgExt.setXSourceTypeFlag( newXSourceTypeFlag );
     }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xGenerated_by attribute.
     * 
     * @generated
     */
    public String getXGenerated_by (){
   
        return eObjXOrgExt.getXGenerated_by();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xGenerated_by attribute.
     * 
     * @param newXGenerated_by
     *     The new value of xGenerated_by.
     * @generated
     */
    public void setXGenerated_by( String newXGenerated_by ) throws Exception {
        metaDataMap.put("XGenerated_by", newXGenerated_by);

        if (newXGenerated_by == null || newXGenerated_by.equals("")) {
            newXGenerated_by = null;


        }
        eObjXOrgExt.setXGenerated_by( newXGenerated_by );
     }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xCorporateCategoryType attribute.
     * 
     * @generated
     */
    public String getXCorporateCategoryType (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXOrgExt.getXCorporateCategory());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xCorporateCategoryType attribute.
     * 
     * @param newXCorporateCategoryType
     *     The new value of xCorporateCategoryType.
     * @generated
     */
    public void setXCorporateCategoryType( String newXCorporateCategoryType ) throws Exception {
        metaDataMap.put("XCorporateCategoryType", newXCorporateCategoryType);

        if (newXCorporateCategoryType == null || newXCorporateCategoryType.equals("")) {
            newXCorporateCategoryType = null;


        }
        eObjXOrgExt.setXCorporateCategory( DWLFunctionUtils.getLongFromString(newXCorporateCategoryType) );
     }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xCorporateCategoryValue attribute.
     * 
     * @generated
     */
    public String getXCorporateCategoryValue (){
      return xCorporateCategoryValue;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xCorporateCategoryValue attribute.
     * 
     * @param newXCorporateCategoryValue
     *     The new value of xCorporateCategoryValue.
     * @generated
     */
    public void setXCorporateCategoryValue( String newXCorporateCategoryValue ) throws Exception {
        metaDataMap.put("XCorporateCategoryValue", newXCorporateCategoryValue);

        if (newXCorporateCategoryValue == null || newXCorporateCategoryValue.equals("")) {
            newXCorporateCategoryValue = null;


        }
        xCorporateCategoryValue = newXCorporateCategoryValue;
     }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xCorporateGroupType attribute.
     * 
     * @generated
     */
    public String getXCorporateGroupType (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXOrgExt.getXCorporateGroup());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xCorporateGroupType attribute.
     * 
     * @param newXCorporateGroupType
     *     The new value of xCorporateGroupType.
     * @generated
     */
    public void setXCorporateGroupType( String newXCorporateGroupType ) throws Exception {
        metaDataMap.put("XCorporateGroupType", newXCorporateGroupType);

        if (newXCorporateGroupType == null || newXCorporateGroupType.equals("")) {
            newXCorporateGroupType = null;


        }
        eObjXOrgExt.setXCorporateGroup( DWLFunctionUtils.getLongFromString(newXCorporateGroupType) );
     }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xCorporateGroupValue attribute.
     * 
     * @generated
     */
    public String getXCorporateGroupValue (){
      return xCorporateGroupValue;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xCorporateGroupValue attribute.
     * 
     * @param newXCorporateGroupValue
     *     The new value of xCorporateGroupValue.
     * @generated
     */
    public void setXCorporateGroupValue( String newXCorporateGroupValue ) throws Exception {
        metaDataMap.put("XCorporateGroupValue", newXCorporateGroupValue);

        if (newXCorporateGroupValue == null || newXCorporateGroupValue.equals("")) {
            newXCorporateGroupValue = null;


        }
        xCorporateGroupValue = newXCorporateGroupValue;
     }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xPersonalAgreement attribute.
     * 
     * @generated
     */
    public String getXPersonalAgreement (){
   
        return eObjXOrgExt.getXPersonalAgreement();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xPersonalAgreement attribute.
     * 
     * @param newXPersonalAgreement
     *     The new value of xPersonalAgreement.
     * @generated
     */
    public void setXPersonalAgreement( String newXPersonalAgreement ) throws Exception {
        metaDataMap.put("XPersonalAgreement", newXPersonalAgreement);

        if (newXPersonalAgreement == null || newXPersonalAgreement.equals("")) {
            newXPersonalAgreement = null;


        }
        eObjXOrgExt.setXPersonalAgreement( newXPersonalAgreement );
     }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xDoNotMergeFlag attribute.
     * 
     * @generated
     */
    public String getXDoNotMergeFlag (){
   
        return eObjXOrgExt.getXDoNotMergeFlag();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xDoNotMergeFlag attribute.
     * 
     * @param newXDoNotMergeFlag
     *     The new value of xDoNotMergeFlag.
     * @generated
     */
    public void setXDoNotMergeFlag( String newXDoNotMergeFlag ) throws Exception {
        metaDataMap.put("XDoNotMergeFlag", newXDoNotMergeFlag);

        if (newXDoNotMergeFlag == null || newXDoNotMergeFlag.equals("")) {
            newXDoNotMergeFlag = null;


        }
        eObjXOrgExt.setXDoNotMergeFlag( newXDoNotMergeFlag );
     }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the deleteFlag attribute.
     * 
     * @generated
     */
    public String getDeleteFlag (){
   
        return eObjXOrgExt.getDeleteFlag();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the deleteFlag attribute.
     * 
     * @param newDeleteFlag
     *     The new value of deleteFlag.
     * @generated
     */
    public void setDeleteFlag( String newDeleteFlag ) throws Exception {
        metaDataMap.put("DeleteFlag", newDeleteFlag);

        if (newDeleteFlag == null || newDeleteFlag.equals("")) {
            newDeleteFlag = null;


        }
        eObjXOrgExt.setDeleteFlag( newDeleteFlag );
     }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the infoRemoveFlag attribute.
     * 
     * @generated
     */
    public String getInfoRemoveFlag (){
   
        return eObjXOrgExt.getInfoRemoveFlag();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the infoRemoveFlag attribute.
     * 
     * @param newInfoRemoveFlag
     *     The new value of infoRemoveFlag.
     * @generated
     */
    public void setInfoRemoveFlag( String newInfoRemoveFlag ) throws Exception {
        metaDataMap.put("InfoRemoveFlag", newInfoRemoveFlag);

        if (newInfoRemoveFlag == null || newInfoRemoveFlag.equals("")) {
            newInfoRemoveFlag = null;


        }
        eObjXOrgExt.setInfoRemoveFlag( newInfoRemoveFlag );
     }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the dedupHiddenFlag attribute.
     * 
     * @generated
     */
    public String getDedupHiddenFlag (){
   
        return eObjXOrgExt.getDedupHiddenFlag();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the dedupHiddenFlag attribute.
     * 
     * @param newDedupHiddenFlag
     *     The new value of dedupHiddenFlag.
     * @generated
     */
    public void setDedupHiddenFlag( String newDedupHiddenFlag ) throws Exception {
        metaDataMap.put("DedupHiddenFlag", newDedupHiddenFlag);

        if (newDedupHiddenFlag == null || newDedupHiddenFlag.equals("")) {
            newDedupHiddenFlag = null;


        }
        eObjXOrgExt.setDedupHiddenFlag( newDedupHiddenFlag );
     }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the prefCommunicationChannel attribute.
     * 
     * @generated
     */
    public String getPrefCommunicationChannel (){
   
        return eObjXOrgExt.getPrefCommunicationChannel();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the prefCommunicationChannel attribute.
     * 
     * @param newPrefCommunicationChannel
     *     The new value of prefCommunicationChannel.
     * @generated
     */
    public void setPrefCommunicationChannel( String newPrefCommunicationChannel ) throws Exception {
        metaDataMap.put("PrefCommunicationChannel", newPrefCommunicationChannel);

        if (newPrefCommunicationChannel == null || newPrefCommunicationChannel.equals("")) {
            newPrefCommunicationChannel = null;


        }
        eObjXOrgExt.setPrefCommunicationChannel( newPrefCommunicationChannel );
     }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the yanaseFlag attribute.
     * 
     * @generated
     */
    public String getYanaseFlag (){
   
        return eObjXOrgExt.getYanaseFlag();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the yanaseFlag attribute.
     * 
     * @param newYanaseFlag
     *     The new value of yanaseFlag.
     * @generated
     */
    public void setYanaseFlag( String newYanaseFlag ) throws Exception {
        metaDataMap.put("YanaseFlag", newYanaseFlag);

        if (newYanaseFlag == null || newYanaseFlag.equals("")) {
            newYanaseFlag = null;


        }
        eObjXOrgExt.setYanaseFlag( newYanaseFlag );
     }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the financePartyType attribute.
     * 
     * @generated
     */
    public String getFinancePartyType (){
   
        return eObjXOrgExt.getFinancePartyType();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the financePartyType attribute.
     * 
     * @param newFinancePartyType
     *     The new value of financePartyType.
     * @generated
     */
    public void setFinancePartyType( String newFinancePartyType ) throws Exception {
        metaDataMap.put("FinancePartyType", newFinancePartyType);

        if (newFinancePartyType == null || newFinancePartyType.equals("")) {
            newFinancePartyType = null;


        }
        eObjXOrgExt.setFinancePartyType( newFinancePartyType );
     }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the contractNumber attribute.
     * 
     * @generated
     */
    public String getContractNumber (){
   
        return eObjXOrgExt.getContractNumber();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the contractNumber attribute.
     * 
     * @param newContractNumber
     *     The new value of contractNumber.
     * @generated
     */
    public void setContractNumber( String newContractNumber ) throws Exception {
        metaDataMap.put("ContractNumber", newContractNumber);

        if (newContractNumber == null || newContractNumber.equals("")) {
            newContractNumber = null;


        }
        eObjXOrgExt.setContractNumber( newContractNumber );
     }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xPrivacyAct attribute.
     * 
     * @generated
     */
    public String getXPrivacyAct (){
   
        return eObjXOrgExt.getXPrivacyAct();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xPrivacyAct attribute.
     * 
     * @param newXPrivacyAct
     *     The new value of xPrivacyAct.
     * @generated
     */
    public void setXPrivacyAct( String newXPrivacyAct ) throws Exception {
        metaDataMap.put("XPrivacyAct", newXPrivacyAct);

        if (newXPrivacyAct == null || newXPrivacyAct.equals("")) {
            newXPrivacyAct = null;


        }
        eObjXOrgExt.setXPrivacyAct( newXPrivacyAct );
     }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xFleet attribute.
     * 
     * @generated
     */
    public String getXFleet (){
   
        return eObjXOrgExt.getXFleet();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xFleet attribute.
     * 
     * @param newXFleet
     *     The new value of xFleet.
     * @generated
     */
    public void setXFleet( String newXFleet ) throws Exception {
        metaDataMap.put("XFleet", newXFleet);

        if (newXFleet == null || newXFleet.equals("")) {
            newXFleet = null;


        }
        eObjXOrgExt.setXFleet( newXFleet );
     }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the lastActivityDate attribute.
     * 
     * @generated
     */
    public String getLastActivityDate (){
   
        return DWLFunctionUtils.getStringFromTimestamp(eObjXOrgExt.getLastActivityDate());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the lastActivityDate attribute.
     * 
     * @param newLastActivityDate
     *     The new value of lastActivityDate.
     * @generated
     */
    public void setLastActivityDate( String newLastActivityDate ) throws Exception {
        metaDataMap.put("LastActivityDate", newLastActivityDate);
       	isValidLastActivityDate = true;

        if (newLastActivityDate == null || newLastActivityDate.equals("")) {
            newLastActivityDate = null;
            eObjXOrgExt.setLastActivityDate(null);


        }
    else {
        	if (DateValidator.validates(newLastActivityDate)) {
           		eObjXOrgExt.setLastActivityDate(DateFormatter.getStartDateTimestamp(newLastActivityDate));
            	metaDataMap.put("LastActivityDate", getLastActivityDate());
        	} else {
            	if (Configuration.getConfiguration().getConfigItem(
              "/IBM/DWLCommonServices/InternalValidation/enabled").getBooleanValue()) {
                	if (metaDataMap.get("LastActivityDate") != null) {
                    	metaDataMap.put("LastActivityDate", "");
                	}
                	isValidLastActivityDate = false;
                	eObjXOrgExt.setLastActivityDate(null);
            	}
        	}
        }
     }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the x_CUST_TYPE attribute.
     * 
     * @generated
     */
    public String getX_CUST_TYPE (){
   
        return eObjXOrgExt.getX_CUST_TYPE();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the x_CUST_TYPE attribute.
     * 
     * @param newX_CUST_TYPE
     *     The new value of x_CUST_TYPE.
     * @generated
     */
    public void setX_CUST_TYPE( String newX_CUST_TYPE ) throws Exception {
        metaDataMap.put("X_CUST_TYPE", newX_CUST_TYPE);

        if (newX_CUST_TYPE == null || newX_CUST_TYPE.equals("")) {
            newX_CUST_TYPE = null;


        }
        eObjXOrgExt.setX_CUST_TYPE( newX_CUST_TYPE );
     }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xPC_Ind attribute.
     * 
     * @generated
     */
    public String getXPC_Ind (){
   
        return eObjXOrgExt.getXPC_Ind();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xPC_Ind attribute.
     * 
     * @param newXPC_Ind
     *     The new value of xPC_Ind.
     * @generated
     */
    public void setXPC_Ind( String newXPC_Ind ) throws Exception {
        metaDataMap.put("XPC_Ind", newXPC_Ind);

        if (newXPC_Ind == null || newXPC_Ind.equals("")) {
            newXPC_Ind = null;


        }
        eObjXOrgExt.setXPC_Ind( newXPC_Ind );
     }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xVANS_Ind attribute.
     * 
     * @generated
     */
    public String getXVANS_Ind (){
   
        return eObjXOrgExt.getXVANS_Ind();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xVANS_Ind attribute.
     * 
     * @param newXVANS_Ind
     *     The new value of xVANS_Ind.
     * @generated
     */
    public void setXVANS_Ind( String newXVANS_Ind ) throws Exception {
        metaDataMap.put("XVANS_Ind", newXVANS_Ind);

        if (newXVANS_Ind == null || newXVANS_Ind.equals("")) {
            newXVANS_Ind = null;


        }
        eObjXOrgExt.setXVANS_Ind( newXVANS_Ind );
     }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xLastModifiedSystemDate attribute.
     * 
     * @generated
     */
    public String getXLastModifiedSystemDate (){
   
        return DWLFunctionUtils.getStringFromTimestamp(eObjXOrgExt.getXLastModifiedSystemDate());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xLastModifiedSystemDate attribute.
     * 
     * @param newXLastModifiedSystemDate
     *     The new value of xLastModifiedSystemDate.
     * @generated
     */
    public void setXLastModifiedSystemDate( String newXLastModifiedSystemDate ) throws Exception {
        metaDataMap.put("XLastModifiedSystemDate", newXLastModifiedSystemDate);
       	isValidXLastModifiedSystemDate = true;

        if (newXLastModifiedSystemDate == null || newXLastModifiedSystemDate.equals("")) {
            newXLastModifiedSystemDate = null;
            eObjXOrgExt.setXLastModifiedSystemDate(null);


        }
    else {
        	if (DateValidator.validates(newXLastModifiedSystemDate)) {
           		eObjXOrgExt.setXLastModifiedSystemDate(DateFormatter.getStartDateTimestamp(newXLastModifiedSystemDate));
            	metaDataMap.put("XLastModifiedSystemDate", getXLastModifiedSystemDate());
        	} else {
            	if (Configuration.getConfiguration().getConfigItem(
              "/IBM/DWLCommonServices/InternalValidation/enabled").getBooleanValue()) {
                	if (metaDataMap.get("XLastModifiedSystemDate") != null) {
                    	metaDataMap.put("XLastModifiedSystemDate", "");
                	}
                	isValidXLastModifiedSystemDate = false;
                	eObjXOrgExt.setXLastModifiedSystemDate(null);
            	}
        	}
        }
     }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateTxId attribute.
     *
     * @generated
     */
    public String getXOrgLastUpdateTxId() {
        return DWLFunctionUtils.getStringFromLong(eObjXOrgExt.getLastUpdateTxId());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateUser attribute.
     *
     * @generated
     */
    public String getXOrgLastUpdateUser() {
        return eObjXOrgExt.getLastUpdateUser();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateDt attribute.
     *
     * @generated
     */
    public String getXOrgLastUpdateDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXOrgExt.getLastUpdateDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateTxId attribute.
     *
     * @param newLastUpdateTxId
     *     The new value of LastUpdateTxId.
     * @generated
     */
    public void setXOrgLastUpdateTxId(String newLastUpdateTxId) {
        metaDataMap.put("XOrgLastUpdateTxId", newLastUpdateTxId);

        if ((newLastUpdateTxId == null) || newLastUpdateTxId.equals("")) {
            newLastUpdateTxId = null;
        }
        eObjXOrgExt.setLastUpdateTxId(DWLFunctionUtils.getLongFromString(newLastUpdateTxId));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateUser attribute.
     *
     * @param newLastUpdateUser
     *     The new value of LastUpdateUser.
     * @generated
     */
    public void setXOrgLastUpdateUser(String newLastUpdateUser) {
        metaDataMap.put("XOrgLastUpdateUser", newLastUpdateUser);

        if ((newLastUpdateUser == null) || newLastUpdateUser.equals("")) {
            newLastUpdateUser = null;
        }
        eObjXOrgExt.setLastUpdateUser(newLastUpdateUser);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateDt attribute.
     *
     * @param newLastUpdateDt
     *     The new value of LastUpdateDt.
     * @throws Exception
     * @generated
     */
    public void setXOrgLastUpdateDate(String newLastUpdateDt) throws Exception {
        metaDataMap.put("XOrgLastUpdateDate", newLastUpdateDt);

        if ((newLastUpdateDt == null) || newLastUpdateDt.equals("")) {
            newLastUpdateDt = null;
        }

        eObjXOrgExt.setLastUpdateDt(DWLFunctionUtils.getTimestampFromTimestampString(newLastUpdateDt));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XOrgHistActionCode history attribute.
     *
     * @generated
     */
    public String getXOrgHistActionCode() {
        return eObjXOrgExt.getHistActionCode();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XOrgHistActionCode history attribute.
     *
     * @param aXOrgHistActionCode
     *     The new value of XOrgHistActionCode.
     * @generated
     */
    public void setXOrgHistActionCode(String aXOrgHistActionCode) {
        metaDataMap.put("XOrgHistActionCode", aXOrgHistActionCode);

        if ((aXOrgHistActionCode == null) || aXOrgHistActionCode.equals("")) {
            aXOrgHistActionCode = null;
        }
        eObjXOrgExt.setHistActionCode(aXOrgHistActionCode);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XOrgHistCreateDate history attribute.
     *
     * @generated
     */
    public String getXOrgHistCreateDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXOrgExt.getHistCreateDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XOrgHistCreateDate history attribute.
     *
     * @param aXOrgHistCreateDate
     *     The new value of XOrgHistCreateDate.
     * @generated
     */
    public void setXOrgHistCreateDate(String aXOrgHistCreateDate) throws Exception{
        metaDataMap.put("XOrgHistCreateDate", aXOrgHistCreateDate);

        if ((aXOrgHistCreateDate == null) || aXOrgHistCreateDate.equals("")) {
            aXOrgHistCreateDate = null;
        }

        eObjXOrgExt.setHistCreateDt(DWLFunctionUtils.getTimestampFromTimestampString(aXOrgHistCreateDate));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XOrgHistCreatedBy history attribute.
     *
     * @generated
     */
    public String getXOrgHistCreatedBy() {
        return eObjXOrgExt.getHistCreatedBy();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XOrgHistCreatedBy history attribute.
     *
     * @param aXOrgHistCreatedBy
     *     The new value of XOrgHistCreatedBy.
     * @generated
     */
    public void setXOrgHistCreatedBy(String aXOrgHistCreatedBy) {
        metaDataMap.put("XOrgHistCreatedBy", aXOrgHistCreatedBy);

        if ((aXOrgHistCreatedBy == null) || aXOrgHistCreatedBy.equals("")) {
            aXOrgHistCreatedBy = null;
        }

        eObjXOrgExt.setHistCreatedBy(aXOrgHistCreatedBy);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XOrgHistEndDate history attribute.
     *
     * @generated
     */
    public String getXOrgHistEndDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXOrgExt.getHistEndDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XOrgHistEndDate history attribute.
     *
     * @param aXOrgHistEndDate
     *     The new value of XOrgHistEndDate.
     * @generated
     */
    public void setXOrgHistEndDate(String aXOrgHistEndDate) throws Exception{
        metaDataMap.put("XOrgHistEndDate", aXOrgHistEndDate);

        if ((aXOrgHistEndDate == null) || aXOrgHistEndDate.equals("")) {
            aXOrgHistEndDate = null;
        }
        eObjXOrgExt.setHistEndDt(DWLFunctionUtils.getTimestampFromTimestampString(aXOrgHistEndDate));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XOrgHistoryIdPK history attribute.
     *
     * @generated
     */
    public String getXOrgHistoryIdPK() {
        return DWLFunctionUtils.getStringFromLong(eObjXOrgExt.getHistoryIdPK());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XOrgHistoryIdPK history attribute.
     *
     * @param aXOrgHistoryIdPK
     *     The new value of XOrgHistoryIdPK.
     * @generated
     */
    public void setXOrgHistoryIdPK(String aXOrgHistoryIdPK) {
        metaDataMap.put("XOrgHistoryIdPK", aXOrgHistoryIdPK);

        if ((aXOrgHistoryIdPK == null) || aXOrgHistoryIdPK.equals("")) {
            aXOrgHistoryIdPK = null;
        }
        eObjXOrgExt.setHistoryIdPK(DWLFunctionUtils.getLongFromString(aXOrgHistoryIdPK));
    }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation during an add transaction.
     *
     * @generated
     */
    public DWLStatus validateAdd(int level, DWLStatus status) throws Exception {

        status = super.validateAdd(level, status);
        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0038I Add any controller-level custom validation logic to be
            // executed for this object during an "add" transaction

        }

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            // MDM_TODO0: CDKWB0039I Add any component-level custom validation logic to be
            // executed for this object during an "add" transaction
        }
        status = getValidationStatus(level, status);
        return status;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation during an update transaction.
     *
     * @generated
     */
    public DWLStatus validateUpdate(int level, DWLStatus status) throws Exception {
    logger.finest("ENTER validateUpdate(int level, DWLStatus status)");

        status = super.validateUpdate(level, status);
        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0040I Add any controller-level custom validation logic to be
            // executed for this object during an "update" transaction

        }

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            assignBeforeImageValues(metaDataMap);
            
            // MDM_TODO0: CDKWB0041I Add any component-level custom validation logic to be
            // executed for this object during an "update" transaction
        }
        status = getValidationStatus(level, status);
    if (logger.isFinestEnabled()) {
        	String returnValue = status.toString();
      logger.finest("RETURN validateUpdate(int level, DWLStatus status) " + returnValue);
    }
        return status;
    }



    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation common to both add and update transactions.
     *
     * @generated
     */
     
    private DWLStatus getValidationStatus(int level, DWLStatus status) throws Exception {
    logger.finest("ENTER getValidationStatus(int level, DWLStatus status)");

        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0034I Add any common controller-level custom validation
            // logic to be executed for this object during either "add" or
            // "update" transactions
    		controllerValidation_XMarketName(status);
    		controllerValidation_XBatchInd(status);
    		controllerValidation_XNumberOfEmployees(status);
    		controllerValidation_XLastModifiedSystemDate(status);
    		controllerValidation_XCorporateCategory(status);
    		controllerValidation_XCorporateGroup(status);
    		controllerValidation_LastActivityDate(status);
    	}

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            // MDM_TODO0: CDKWB0035I Add any common component-level custom validation logic
            // to be executed for this object during either "add" or "update"
            // transactions
    		componentValidation_XMarketName(status);
    		componentValidation_XBatchInd(status);
    		componentValidation_XNumberOfEmployees(status);
    		componentValidation_XLastModifiedSystemDate(status);
    		componentValidation_XCorporateCategory(status);
    		componentValidation_XCorporateGroup(status);
    		componentValidation_LastActivityDate(status);
        }
        
        if (logger.isFinestEnabled()) {
            String returnValue = status.toString();
      logger.finest("RETURN getValidationStatus(int level, DWLStatus status) " + returnValue);
        }
    
        return status;
    }

    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "XMarketName"
     *
     * @generated
     */
	private void componentValidation_XMarketName(DWLStatus status) {
  
            boolean isXMarketNameNull = false;
            if (eObjXOrgExt.getXMarketName() == null || 
            	eObjXOrgExt.getXMarketName().trim().equals("")) {
                isXMarketNameNull = true;
            }
            if (isXMarketNameNull) {
                DWLError err = createDWLError("XOrg", "XMarketName", DSEAAdditionsExtsErrorReasonCode.XORG_XMARKETNAME_NULL);
                status.addError(err); 
            }
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "XBatchInd"
     *
     * @generated
     */
	private void componentValidation_XBatchInd(DWLStatus status) {
  
            boolean isXBatchIndNull = false;
            if (eObjXOrgExt.getXBatchInd() == null || 
            	eObjXOrgExt.getXBatchInd().trim().equals("")) {
                isXBatchIndNull = true;
            }
            if (isXBatchIndNull) {
                DWLError err = createDWLError("XOrg", "XBatchInd", DSEAAdditionsExtsErrorReasonCode.XORG_XBATCHIND_NULL);
                status.addError(err); 
            }
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "XNumberOfEmployees"
     *
     * @generated
     */
	private void componentValidation_XNumberOfEmployees(DWLStatus status) {
  
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "XLastModifiedSystemDate"
     *
     * @generated
     */
  private void componentValidation_XLastModifiedSystemDate(DWLStatus status) {
  
  }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "XCorporateCategory"
     *
     * @generated
     */
  private void componentValidation_XCorporateCategory(DWLStatus status) {
  
  }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "XCorporateGroup"
     *
     * @generated
     */
  private void componentValidation_XCorporateGroup(DWLStatus status) {
  
  }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "LastActivityDate"
     *
     * @generated
     */
  private void componentValidation_LastActivityDate(DWLStatus status) {
  
  }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "XMarketName"
     *
     * @generated NOT
     */
	private void controllerValidation_XMarketName(DWLStatus status) throws Exception {
  
            boolean isXMarketNameNull = false;
            if (eObjXOrgExt.getXMarketName() == null || 
            	eObjXOrgExt.getXMarketName().trim().equals("")) {
                isXMarketNameNull = true;
            }
            /*if (isXMarketNameNull) {
                DWLError err = createDWLError("XOrg", "XMarketName", DSEAAdditionsExtsErrorReasonCode.XORG_XMARKETNAME_NULL);
                status.addError(err); 
            }*/
    	}
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "XBatchInd"
     *
     * @generated NOT
     */
	private void controllerValidation_XBatchInd(DWLStatus status) throws Exception {
  
            boolean isXBatchIndNull = false;
            if (eObjXOrgExt.getXBatchInd() == null || 
            	eObjXOrgExt.getXBatchInd().trim().equals("")) {
                isXBatchIndNull = true;
            }
           /* if (isXBatchIndNull) {
                DWLError err = createDWLError("XOrg", "XBatchInd", DSEAAdditionsExtsErrorReasonCode.XORG_XBATCHIND_NULL);
                status.addError(err); 
            }*/
    	}
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "XNumberOfEmployees"
     *
     * @generated
     */
	private void controllerValidation_XNumberOfEmployees(DWLStatus status) throws Exception {
  
      //persistent code type
            boolean isXNumberOfEmployeesNull = false;
            if ((eObjXOrgExt.getXNumberOfEmployees() == null) &&
               ((getXNumberOfEmployeesValue() == null) || 
                 getXNumberOfEmployeesValue().trim().equals(""))) {
                isXNumberOfEmployeesNull = true;
            }
            if (!isXNumberOfEmployeesNull) {
                if (checkForInvalidXorgXnumberofemployees()) {
                    DWLError err = new DWLError();
                    err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XORG_BOBJ_EXT).longValue());
                    err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XORG_XNUMBEROFEMPLOYEES).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                    String infoForLogging="Error: Custom validation error occured for entity XOrg, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("controllerValidation_XNumberOfEmployees " + infoForLogging);
        }
                status.addError(err);
            }

             }
    			
    	}
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "XLastModifiedSystemDate"
     *
     * @generated
     */
  private void controllerValidation_XLastModifiedSystemDate(DWLStatus status) throws Exception {
  
            boolean isXLastModifiedSystemDateNull = (eObjXOrgExt.getXLastModifiedSystemDate() == null);
            if (!isValidXLastModifiedSystemDate) {
              	DWLError err = new DWLError();
               	err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XORG_BOBJ_EXT).longValue());
               	err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XORG_XLASTMODIFIEDSYSTEMDATE).longValue());
               	err.setErrorType(DWLErrorCode.DATA_INVALID_ERROR);
                String infoForLogging="Error: Validation error. Invalid time specified on property XLastModifiedSystemDate in entity XOrg, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode();
      logger.finest("controllerValidation_XLastModifiedSystemDate " + infoForLogging);
               	status.addError(err);
            } 
    	}

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "XCorporateCategory"
     *
     * @generated
     */
  private void controllerValidation_XCorporateCategory(DWLStatus status) throws Exception {
  
      //persistent code type
            boolean isXCorporateCategoryNull = false;
            if ((eObjXOrgExt.getXCorporateCategory() == null) &&
               ((getXCorporateCategoryValue() == null) || 
                 getXCorporateCategoryValue().trim().equals(""))) {
                isXCorporateCategoryNull = true;
            }
            if (!isXCorporateCategoryNull) {
                if (checkForInvalidXorgXcorporatecategory()) {
                    DWLError err = new DWLError();
                    err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XORG_BOBJ_EXT).longValue());
                    err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XORG_XCORPORATECATEGORY).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                    String infoForLogging="Error: Custom validation error occured for entity XOrg, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("controllerValidation_XCorporateCategory " + infoForLogging);
        }
                status.addError(err);
            }

             }
    			
    	}

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "XCorporateGroup"
     *
     * @generated
     */
  private void controllerValidation_XCorporateGroup(DWLStatus status) throws Exception {
  
      //persistent code type
            boolean isXCorporateGroupNull = false;
            if ((eObjXOrgExt.getXCorporateGroup() == null) &&
               ((getXCorporateGroupValue() == null) || 
                 getXCorporateGroupValue().trim().equals(""))) {
                isXCorporateGroupNull = true;
            }
            if (!isXCorporateGroupNull) {
                if (checkForInvalidXorgXcorporategroup()) {
                    DWLError err = new DWLError();
                    err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XORG_BOBJ_EXT).longValue());
                    err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XORG_XCORPORATEGROUP).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                    String infoForLogging="Error: Custom validation error occured for entity XOrg, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("controllerValidation_XCorporateGroup " + infoForLogging);
        }
                status.addError(err);
            }

             }
    			
    	}

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "LastActivityDate"
     *
     * @generated
     */
  private void controllerValidation_LastActivityDate(DWLStatus status) throws Exception {
  
            boolean isLastActivityDateNull = (eObjXOrgExt.getLastActivityDate() == null);
            if (!isValidLastActivityDate) {
              	DWLError err = new DWLError();
               	err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XORG_BOBJ_EXT).longValue());
               	err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XORG_LASTACTIVITYDATE).longValue());
               	err.setErrorType(DWLErrorCode.DATA_INVALID_ERROR);
                String infoForLogging="Error: Validation error. Invalid time specified on property LastActivityDate in entity XOrg, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode();
      logger.finest("controllerValidation_LastActivityDate " + infoForLogging);
               	status.addError(err);
            } 
    	}

    private DWLError createDWLError(String entityName, String propertyName,String reasonCode){	
		DWLError err = new DWLError();
		err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XORG_BOBJ_EXT).longValue());
		err.setReasonCode(new Long(reasonCode).longValue());
		err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
			String infoForLogging="Error: Validation error occured. Property " + propertyName + " is null, in entity " + entityName + ", component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
			logger.finest("createDWLError " + infoForLogging);
		}
		return err;
    }
    
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Check the value of the field XNumberOfEmployees and return true if the
     * error reason INVALID_XORG_XNUMBEROFEMPLOYEES should be returned.
     *
     * @generated
  **/
	private boolean checkForInvalidXorgXnumberofemployees() throws Exception {
    logger.finest("ENTER checkForInvalidXorgXnumberofemployees()");
        boolean notValid = false;
      	String langId = (String) this.getControl().get(DWLControlKeys.LANG_ID);
      	CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
    Long codeType = DWLFunctionUtils.getLongFromString( getXNumberOfEmployeesType() );
    String codeValue = getXNumberOfEmployeesValue();
    if( codeValue != null && codeValue.trim().equals("")){
      codeValue = null;
    }
     
        if ( codeType != null && codeValue == null ){

             if( codeTypeCompHelper.isCodeValid("xcdnumofemptp", langId, getXNumberOfEmployeesType(),
                 CodeTypeComponentHelper.ACTIVE, getControl())) {
                 CodeTypeBObj ctBObj = codeTypeCompHelper
                 					.getCodeTypeByCode("xcdnumofemptp", langId, getXNumberOfEmployeesType(),
                         								getControl());
               	if (ctBObj != null) {
                   	setXNumberOfEmployeesValue( ctBObj.getvalue() );
               	}
             }
             else{
             	if (logger.isFinestEnabled()) {
              	 	String infoForLogging="NotValid 1";
      logger.finest("checkForInvalidXorgXnumberofemployees() " + infoForLogging);
        }
                 notValid = true;
           }
        }
        else if (codeType == null && codeValue != null ){
          
             CodeTypeBObj ctBObj = codeTypeCompHelper
                      .getCodeTypeByValue("xcdnumofemptp", langId, codeValue,
                                 getControl());

             if (ctBObj != null) {
                 setXNumberOfEmployeesType(ctBObj.gettp_cd());
             } 
             else {
             	if (logger.isFinestEnabled()) {
              	  	String infoForLogging="NotValid 2";
      logger.finest("checkForInvalidXorgXnumberofemployees() " + infoForLogging);
        }
                  notValid = true;
             }
        }
        else if ( codeType != null && codeValue != null
             && !codeTypeCompHelper.isCodeValuePairValid("xcdnumofemptp", langId, getXNumberOfEmployeesType(), 
                     new String[] { codeValue }, CodeTypeComponentHelper.ACTIVE, getControl())) {	
       if (logger.isFinestEnabled()) {
       		String infoForLogging="NotValid 3";
      logger.finest("checkForInvalidXorgXnumberofemployees() " + infoForLogging);
       }
             notValid = true;
        }
        if (logger.isFinestEnabled()) {
      String returnValue ="" +notValid;
      logger.finest("RETURN checkForInvalidXorgXnumberofemployees() " + returnValue);
    }
    return notValid;
     } 
				 






	 /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Check the value of the field XCorporateCategory and return true if the
     * error reason INVALID_XORG_XCORPORATECATEGORY should be returned.
     *
     * @generated
  **/
  private boolean checkForInvalidXorgXcorporatecategory() throws Exception {
    logger.finest("ENTER checkForInvalidXorgXcorporatecategory()");
        boolean notValid = false;
      	String langId = (String) this.getControl().get(DWLControlKeys.LANG_ID);
      	CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
    Long codeType = DWLFunctionUtils.getLongFromString( getXCorporateCategoryType() );
    String codeValue = getXCorporateCategoryValue();
    if( codeValue != null && codeValue.trim().equals("")){
      codeValue = null;
    }
     
        if ( codeType != null && codeValue == null ){

             if( codeTypeCompHelper.isCodeValid("xcdcorpcattp", langId, getXCorporateCategoryType(),
                 CodeTypeComponentHelper.ACTIVE, getControl())) {
                 CodeTypeBObj ctBObj = codeTypeCompHelper
                 					.getCodeTypeByCode("xcdcorpcattp", langId, getXCorporateCategoryType(),
                         								getControl());
               	if (ctBObj != null) {
                   	setXCorporateCategoryValue( ctBObj.getvalue() );
               	}
             }
             else{
             	if (logger.isFinestEnabled()) {
              	 	String infoForLogging="NotValid 1";
      logger.finest("checkForInvalidXorgXcorporatecategory() " + infoForLogging);
        }
                 notValid = true;
           }
        }
        else if (codeType == null && codeValue != null ){
          
             CodeTypeBObj ctBObj = codeTypeCompHelper
                      .getCodeTypeByValue("xcdcorpcattp", langId, codeValue,
                                 getControl());

             if (ctBObj != null) {
                 setXCorporateCategoryType(ctBObj.gettp_cd());
             } 
             else {
             	if (logger.isFinestEnabled()) {
              	  	String infoForLogging="NotValid 2";
      logger.finest("checkForInvalidXorgXcorporatecategory() " + infoForLogging);
        }
                  notValid = true;
             }
        }
        else if ( codeType != null && codeValue != null
             && !codeTypeCompHelper.isCodeValuePairValid("xcdcorpcattp", langId, getXCorporateCategoryType(), 
                     new String[] { codeValue }, CodeTypeComponentHelper.ACTIVE, getControl())) {	
       if (logger.isFinestEnabled()) {
       		String infoForLogging="NotValid 3";
      logger.finest("checkForInvalidXorgXcorporatecategory() " + infoForLogging);
       }
             notValid = true;
        }
        if (logger.isFinestEnabled()) {
      String returnValue ="" +notValid;
      logger.finest("RETURN checkForInvalidXorgXcorporatecategory() " + returnValue);
    }
    return notValid;
     }

  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Check the value of the field XCorporateGroup and return true if the error
     * reason INVALID_XORG_XCORPORATEGROUP should be returned.
     *
     * @generated
  **/
  private boolean checkForInvalidXorgXcorporategroup() throws Exception {
    logger.finest("ENTER checkForInvalidXorgXcorporategroup()");
        boolean notValid = false;
      	String langId = (String) this.getControl().get(DWLControlKeys.LANG_ID);
      	CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
    Long codeType = DWLFunctionUtils.getLongFromString( getXCorporateGroupType() );
    String codeValue = getXCorporateGroupValue();
    if( codeValue != null && codeValue.trim().equals("")){
      codeValue = null;
    }
     
        if ( codeType != null && codeValue == null ){

             if( codeTypeCompHelper.isCodeValid("xcdcorpgrouptp", langId, getXCorporateGroupType(),
                 CodeTypeComponentHelper.ACTIVE, getControl())) {
                 CodeTypeBObj ctBObj = codeTypeCompHelper
                 					.getCodeTypeByCode("xcdcorpgrouptp", langId, getXCorporateGroupType(),
                         								getControl());
               	if (ctBObj != null) {
                   	setXCorporateGroupValue( ctBObj.getvalue() );
               	}
             }
             else{
             	if (logger.isFinestEnabled()) {
              	 	String infoForLogging="NotValid 1";
      logger.finest("checkForInvalidXorgXcorporategroup() " + infoForLogging);
        }
                 notValid = true;
           }
        }
        else if (codeType == null && codeValue != null ){
          
             CodeTypeBObj ctBObj = codeTypeCompHelper
                      .getCodeTypeByValue("xcdcorpgrouptp", langId, codeValue,
                                 getControl());

             if (ctBObj != null) {
                 setXCorporateGroupType(ctBObj.gettp_cd());
             } 
             else {
             	if (logger.isFinestEnabled()) {
              	  	String infoForLogging="NotValid 2";
      logger.finest("checkForInvalidXorgXcorporategroup() " + infoForLogging);
        }
                  notValid = true;
             }
        }
        else if ( codeType != null && codeValue != null
             && !codeTypeCompHelper.isCodeValuePairValid("xcdcorpgrouptp", langId, getXCorporateGroupType(), 
                     new String[] { codeValue }, CodeTypeComponentHelper.ACTIVE, getControl())) {	
       if (logger.isFinestEnabled()) {
       		String infoForLogging="NotValid 3";
      logger.finest("checkForInvalidXorgXcorporategroup() " + infoForLogging);
       }
             notValid = true;
        }
        if (logger.isFinestEnabled()) {
      String returnValue ="" +notValid;
      logger.finest("RETURN checkForInvalidXorgXcorporategroup() " + returnValue);
    }
    return notValid;
     }

  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets a record from the extension table.
     *
     * @throws DWLBaseException
     * @generated
     */
    public void getRecord() throws DWLBaseException {
    logger.finest("ENTER getRecord()");
    
    try {
         			
          checkForInvalidXorgXnumberofemployees();
          checkForInvalidXorgXcorporatecategory();
          checkForInvalidXorgXcorporategroup();
         }
         catch (Exception e) {
            DWLExceptionUtils.log(e);
            
            if (logger.isFinestEnabled()) {
        		String infoForLogging="Error: Error reading record " + e.getMessage(); 
      logger.finest("getRecord() " + infoForLogging);
      }
            status = new DWLStatus();

            TCRMReadException readEx = new TCRMReadException();
            IDWLErrorMessage  errHandler = DWLClassFactory.getErrorHandler();
            DWLError          error = errHandler.getErrorMessage(DSEAAdditionsExtsComponentID.XORG_BOBJ_EXT,
                                                                 TCRMErrorCode.READ_RECORD_ERROR,
                                                                 DSEAAdditionsExtsErrorReasonCode.READ_EXTENSION_XORG_FAILED,
                                                                 getControl(), new String[0]);
            error.setThrowable(e);
            status.addError(error);
            status.setStatus(DWLStatus.FATAL);
            readEx.setStatus(status);
            throw readEx;
        }	    		
    logger.finest("RETURN getRecord()");
  }


}

