
/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[641eadf501ad1c2867065b70a924385f]
 */

package com.ibm.daimler.dsea.component;

import com.dwl.tcrm.common.TCRMCommon;



import com.dwl.base.DWLControl;

import com.dwl.base.constant.DWLUtilErrorReasonCode;

import com.dwl.base.error.DWLError;
import com.dwl.base.error.DWLErrorCode;
import com.dwl.base.error.DWLStatus;

import com.dwl.base.exception.DWLBaseException;
import com.dwl.base.exception.DWLUpdateException;

import com.dwl.base.util.DWLExceptionUtils;
import com.dwl.base.util.DWLFunctionUtils;

import com.dwl.tcrm.common.ITCRMValidation;

import com.dwl.tcrm.utilities.TCRMClassFactory;

import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsComponentID;
import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsErrorReasonCode;
import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsPropertyKeys;

import com.ibm.daimler.dsea.entityObject.EObjXCompanyIdentification;

import com.ibm.daimler.dsea.interfaces.DSEAAdditionsExts;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * This class provides the implementation of the business object
 * <code>XCompanyIdentificationBObj</code>.
 * 
 * @see com.dwl.tcrm.common.TCRMCommon
 * @generated
 */
 

@SuppressWarnings("serial")
public class XCompanyIdentificationBObj extends TCRMCommon  {

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected EObjXCompanyIdentification eObjXCompanyIdentification;
	/**
    * <!-- begin-user-doc -->
	  * <!-- end-user-doc -->
    * @generated 
    */
	 private final static com.dwl.base.logging.IDWLLogger logger = com.dwl.base.logging.DWLLoggerManager.getLogger(XCompanyIdentificationBObj.class);
		
 


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */     
    public XCompanyIdentificationBObj() {
        super();
        init();
        eObjXCompanyIdentification = new EObjXCompanyIdentification();
        setComponentID(DSEAAdditionsExtsComponentID.XCOMPANY_IDENTIFICATION_BOBJ);
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Initializes the fields required to populate the metaDataMap. Each key is
     * an element-level field of the business object.
     *
     * @generated
     */
    private void init() {
        metaDataMap.put("CompanyIdentificationpkId", null);
        metaDataMap.put("CompanyMagicNumber", null);
        metaDataMap.put("XCompanyIdentificationHistActionCode", null);
        metaDataMap.put("XCompanyIdentificationHistCreateDate", null);
        metaDataMap.put("XCompanyIdentificationHistCreatedBy", null);
        metaDataMap.put("XCompanyIdentificationHistEndDate", null);
        metaDataMap.put("XCompanyIdentificationHistoryIdPK", null);
        metaDataMap.put("XCompanyIdentificationLastUpdateDate", null);
        metaDataMap.put("XCompanyIdentificationLastUpdateTxId", null);
        metaDataMap.put("XCompanyIdentificationLastUpdateUser", null);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Refreshes all the attributes this business object supports.
     *
     * @see com.dwl.base.DWLCommon#refreshMap()
     * @generated
     */
    public void refreshMap() {

        if (bRequireMapRefresh) {
            super.refreshMap();
            metaDataMap.put("CompanyIdentificationpkId", getCompanyIdentificationpkId());
            metaDataMap.put("CompanyMagicNumber", getCompanyMagicNumber());
            metaDataMap.put("XCompanyIdentificationHistActionCode", getXCompanyIdentificationHistActionCode());
            metaDataMap.put("XCompanyIdentificationHistCreateDate", getXCompanyIdentificationHistCreateDate());
            metaDataMap.put("XCompanyIdentificationHistCreatedBy", getXCompanyIdentificationHistCreatedBy());
            metaDataMap.put("XCompanyIdentificationHistEndDate", getXCompanyIdentificationHistEndDate());
            metaDataMap.put("XCompanyIdentificationHistoryIdPK", getXCompanyIdentificationHistoryIdPK());
            metaDataMap.put("XCompanyIdentificationLastUpdateDate", getXCompanyIdentificationLastUpdateDate());
            metaDataMap.put("XCompanyIdentificationLastUpdateTxId", getXCompanyIdentificationLastUpdateTxId());
            metaDataMap.put("XCompanyIdentificationLastUpdateUser", getXCompanyIdentificationLastUpdateUser());
            bRequireMapRefresh = false;
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the control object on this business object.
     *
     * @see com.dwl.base.DWLCommon#setControl(DWLControl)
     * @generated
     */
    public void setControl(DWLControl newDWLControl) {
        super.setControl(newDWLControl);

        if (eObjXCompanyIdentification != null) {
            eObjXCompanyIdentification.setControl(newDWLControl);
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the entity object associated with this business object.
     *
     * @generated
     */
    public EObjXCompanyIdentification getEObjXCompanyIdentification() {
        bRequireMapRefresh = true;
        return eObjXCompanyIdentification;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the entity object associated with this business object.
     *
     * @param eObjXCompanyIdentification
     *            The eObjXCompanyIdentification to set.
     * @generated
     */
    public void setEObjXCompanyIdentification(EObjXCompanyIdentification eObjXCompanyIdentification) {
        bRequireMapRefresh = true;
        this.eObjXCompanyIdentification = eObjXCompanyIdentification;
        if (this.eObjXCompanyIdentification != null && this.eObjXCompanyIdentification.getControl() == null) {
            DWLControl control = this.getControl();
            if (control != null) {
                this.eObjXCompanyIdentification.setControl(control);
            }
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the companyIdentificationpkId attribute.
     * 
     * @generated
     */
    public String getCompanyIdentificationpkId (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXCompanyIdentification.getCompanyIdentificationpkId());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the companyIdentificationpkId attribute.
     * 
     * @param newCompanyIdentificationpkId
     *     The new value of companyIdentificationpkId.
     * @generated
     */
    public void setCompanyIdentificationpkId( String newCompanyIdentificationpkId ) throws Exception {
        metaDataMap.put("CompanyIdentificationpkId", newCompanyIdentificationpkId);

        if (newCompanyIdentificationpkId == null || newCompanyIdentificationpkId.equals("")) {
            newCompanyIdentificationpkId = null;


        }
        eObjXCompanyIdentification.setCompanyIdentificationpkId( DWLFunctionUtils.getLongFromString(newCompanyIdentificationpkId) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the companyMagicNumber attribute.
     * 
     * @generated
     */
    public String getCompanyMagicNumber (){
   
        return eObjXCompanyIdentification.getCompanyMagicNumber();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the companyMagicNumber attribute.
     * 
     * @param newCompanyMagicNumber
     *     The new value of companyMagicNumber.
     * @generated
     */
    public void setCompanyMagicNumber( String newCompanyMagicNumber ) throws Exception {
        metaDataMap.put("CompanyMagicNumber", newCompanyMagicNumber);

        if (newCompanyMagicNumber == null || newCompanyMagicNumber.equals("")) {
            newCompanyMagicNumber = null;


        }
        eObjXCompanyIdentification.setCompanyMagicNumber( newCompanyMagicNumber );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateTxId attribute.
     *
     * @generated
     */
    public String getXCompanyIdentificationLastUpdateTxId() {
        return DWLFunctionUtils.getStringFromLong(eObjXCompanyIdentification.getLastUpdateTxId());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateUser attribute.
     *
     * @generated
     */
    public String getXCompanyIdentificationLastUpdateUser() {
        return eObjXCompanyIdentification.getLastUpdateUser();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateDt attribute.
     *
     * @generated
     */
    public String getXCompanyIdentificationLastUpdateDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXCompanyIdentification.getLastUpdateDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateTxId attribute.
     *
     * @param newLastUpdateTxId
     *     The new value of LastUpdateTxId.
     * @generated
     */
    public void setXCompanyIdentificationLastUpdateTxId(String newLastUpdateTxId) {
        metaDataMap.put("XCompanyIdentificationLastUpdateTxId", newLastUpdateTxId);

        if ((newLastUpdateTxId == null) || newLastUpdateTxId.equals("")) {
            newLastUpdateTxId = null;
        }
        eObjXCompanyIdentification.setLastUpdateTxId(DWLFunctionUtils.getLongFromString(newLastUpdateTxId));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateUser attribute.
     *
     * @param newLastUpdateUser
     *     The new value of LastUpdateUser.
     * @generated
     */
    public void setXCompanyIdentificationLastUpdateUser(String newLastUpdateUser) {
        metaDataMap.put("XCompanyIdentificationLastUpdateUser", newLastUpdateUser);

        if ((newLastUpdateUser == null) || newLastUpdateUser.equals("")) {
            newLastUpdateUser = null;
        }
        eObjXCompanyIdentification.setLastUpdateUser(newLastUpdateUser);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateDt attribute.
     *
     * @param newLastUpdateDt
     *     The new value of LastUpdateDt.
     * @throws Exception
     * @generated
     */
    public void setXCompanyIdentificationLastUpdateDate(String newLastUpdateDt) throws Exception {
        metaDataMap.put("XCompanyIdentificationLastUpdateDate", newLastUpdateDt);

        if ((newLastUpdateDt == null) || newLastUpdateDt.equals("")) {
            newLastUpdateDt = null;
        }

        eObjXCompanyIdentification.setLastUpdateDt(DWLFunctionUtils.getTimestampFromTimestampString(newLastUpdateDt));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XCompanyIdentificationHistActionCode history attribute.
     *
     * @generated
     */
    public String getXCompanyIdentificationHistActionCode() {
        return eObjXCompanyIdentification.getHistActionCode();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XCompanyIdentificationHistActionCode history attribute.
     *
     * @param aXCompanyIdentificationHistActionCode
     *     The new value of XCompanyIdentificationHistActionCode.
     * @generated
     */
    public void setXCompanyIdentificationHistActionCode(String aXCompanyIdentificationHistActionCode) {
        metaDataMap.put("XCompanyIdentificationHistActionCode", aXCompanyIdentificationHistActionCode);

        if ((aXCompanyIdentificationHistActionCode == null) || aXCompanyIdentificationHistActionCode.equals("")) {
            aXCompanyIdentificationHistActionCode = null;
        }
        eObjXCompanyIdentification.setHistActionCode(aXCompanyIdentificationHistActionCode);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XCompanyIdentificationHistCreateDate history attribute.
     *
     * @generated
     */
    public String getXCompanyIdentificationHistCreateDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXCompanyIdentification.getHistCreateDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XCompanyIdentificationHistCreateDate history attribute.
     *
     * @param aXCompanyIdentificationHistCreateDate
     *     The new value of XCompanyIdentificationHistCreateDate.
     * @generated
     */
    public void setXCompanyIdentificationHistCreateDate(String aXCompanyIdentificationHistCreateDate) throws Exception{
        metaDataMap.put("XCompanyIdentificationHistCreateDate", aXCompanyIdentificationHistCreateDate);

        if ((aXCompanyIdentificationHistCreateDate == null) || aXCompanyIdentificationHistCreateDate.equals("")) {
            aXCompanyIdentificationHistCreateDate = null;
        }

        eObjXCompanyIdentification.setHistCreateDt(DWLFunctionUtils.getTimestampFromTimestampString(aXCompanyIdentificationHistCreateDate));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XCompanyIdentificationHistCreatedBy history attribute.
     *
     * @generated
     */
    public String getXCompanyIdentificationHistCreatedBy() {
        return eObjXCompanyIdentification.getHistCreatedBy();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XCompanyIdentificationHistCreatedBy history attribute.
     *
     * @param aXCompanyIdentificationHistCreatedBy
     *     The new value of XCompanyIdentificationHistCreatedBy.
     * @generated
     */
    public void setXCompanyIdentificationHistCreatedBy(String aXCompanyIdentificationHistCreatedBy) {
        metaDataMap.put("XCompanyIdentificationHistCreatedBy", aXCompanyIdentificationHistCreatedBy);

        if ((aXCompanyIdentificationHistCreatedBy == null) || aXCompanyIdentificationHistCreatedBy.equals("")) {
            aXCompanyIdentificationHistCreatedBy = null;
        }

        eObjXCompanyIdentification.setHistCreatedBy(aXCompanyIdentificationHistCreatedBy);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XCompanyIdentificationHistEndDate history attribute.
     *
     * @generated
     */
    public String getXCompanyIdentificationHistEndDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXCompanyIdentification.getHistEndDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XCompanyIdentificationHistEndDate history attribute.
     *
     * @param aXCompanyIdentificationHistEndDate
     *     The new value of XCompanyIdentificationHistEndDate.
     * @generated
     */
    public void setXCompanyIdentificationHistEndDate(String aXCompanyIdentificationHistEndDate) throws Exception{
        metaDataMap.put("XCompanyIdentificationHistEndDate", aXCompanyIdentificationHistEndDate);

        if ((aXCompanyIdentificationHistEndDate == null) || aXCompanyIdentificationHistEndDate.equals("")) {
            aXCompanyIdentificationHistEndDate = null;
        }
        eObjXCompanyIdentification.setHistEndDt(DWLFunctionUtils.getTimestampFromTimestampString(aXCompanyIdentificationHistEndDate));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XCompanyIdentificationHistoryIdPK history attribute.
     *
     * @generated
     */
    public String getXCompanyIdentificationHistoryIdPK() {
        return DWLFunctionUtils.getStringFromLong(eObjXCompanyIdentification.getHistoryIdPK());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XCompanyIdentificationHistoryIdPK history attribute.
     *
     * @param aXCompanyIdentificationHistoryIdPK
     *     The new value of XCompanyIdentificationHistoryIdPK.
     * @generated
     */
    public void setXCompanyIdentificationHistoryIdPK(String aXCompanyIdentificationHistoryIdPK) {
        metaDataMap.put("XCompanyIdentificationHistoryIdPK", aXCompanyIdentificationHistoryIdPK);

        if ((aXCompanyIdentificationHistoryIdPK == null) || aXCompanyIdentificationHistoryIdPK.equals("")) {
            aXCompanyIdentificationHistoryIdPK = null;
        }
        eObjXCompanyIdentification.setHistoryIdPK(DWLFunctionUtils.getLongFromString(aXCompanyIdentificationHistoryIdPK));
    }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation during an add transaction.
     *
     * @generated
     */
    public DWLStatus validateAdd(int level, DWLStatus status) throws Exception {

        status = super.validateAdd(level, status);
        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0038I Add any controller-level custom validation logic to be
            // executed for this object during an "add" transaction

        }

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            // MDM_TODO0: CDKWB0039I Add any component-level custom validation logic to be
            // executed for this object during an "add" transaction
        }
        status = getValidationStatus(level, status);
        return status;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation during an update transaction.
     *
     * @generated
     */
    public DWLStatus validateUpdate(int level, DWLStatus status) throws Exception {
    logger.finest("ENTER validateUpdate(int level, DWLStatus status)");

        status = super.validateUpdate(level, status);
        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0040I Add any controller-level custom validation logic to be
            // executed for this object during an "update" transaction

            if (eObjXCompanyIdentification.getCompanyIdentificationpkId() == null) {
                DWLError err = new DWLError();
                err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCOMPANY_IDENTIFICATION_BOBJ).longValue());
                err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.XCOMPANYIDENTIFICATION_COMPANYIDENTIFICATIONPKID_NULL).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                	String infoForLogging="Error: Validation error occured for update. No primary key for entity XCompanyIdentification, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("validateUpdate(int level, DWLStatus status) " + infoForLogging);
                }
                status.addError(err);
            }
            if (eObjXCompanyIdentification.getLastUpdateDt() == null) {
                DWLError err = new DWLError();
                err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCOMPANY_IDENTIFICATION_BOBJ).longValue());
                err.setReasonCode(new Long(DWLUtilErrorReasonCode.LAST_UPDATED_DATE_NULL).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
                if (logger.isFinestEnabled()) {
                	String infoForLogging="Error: Validation error occured for update. No last update date for entity XCompanyIdentification, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("validateUpdate(int level, DWLStatus status) " + infoForLogging);
                }
                status.addError(err);
            }
        }

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            assignBeforeImageValues(metaDataMap);
            
            // MDM_TODO0: CDKWB0041I Add any component-level custom validation logic to be
            // executed for this object during an "update" transaction
        }
        status = getValidationStatus(level, status);
    if (logger.isFinestEnabled()) {
        	String returnValue = status.toString();
      logger.finest("RETURN validateUpdate(int level, DWLStatus status) " + returnValue);
    }
        return status;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Populate the before image of this business object.
     *
     * @see com.dwl.base.DWLCommon#populateBeforeImage()
     * @generated
     */
    public void populateBeforeImage() throws DWLBaseException {
    logger.finest("ENTER populateBeforeImage()");

        DSEAAdditionsExts comp = null;
        try {
        
      comp = (DSEAAdditionsExts)TCRMClassFactory.getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
        	
        } catch (Exception e) {
      if (logger.isFinestEnabled()) {
        String infoForLogging="Error: Fatal error while updating record " + e.getMessage();
      logger.finest("populateBeforeImage() " + infoForLogging);
      }
            DWLExceptionUtils.throwDWLBaseException(e, 
            									new DWLUpdateException(e.getMessage()), 
            									this.getStatus(), DWLStatus.FATAL,
                                  DSEAAdditionsExtsComponentID.XCOMPANY_IDENTIFICATION_BOBJ, 
                                  "DIERR",
                                  DSEAAdditionsExtsErrorReasonCode.XCOMPANYIDENTIFICATION_BEFORE_IMAGE_NOT_POPULATED, 
                                  this.getControl());
        }
        
        comp.loadBeforeImage(this);
    logger.finest("RETURN populateBeforeImage()");
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation common to both add and update transactions.
     *
     * @generated
     */
     
    private DWLStatus getValidationStatus(int level, DWLStatus status) throws Exception {
    logger.finest("ENTER getValidationStatus(int level, DWLStatus status)");

        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0034I Add any common controller-level custom validation
            // logic to be executed for this object during either "add" or
            // "update" transactions
    	}

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            // MDM_TODO0: CDKWB0035I Add any common component-level custom validation logic
            // to be executed for this object during either "add" or "update"
            // transactions
        }
        
        if (logger.isFinestEnabled()) {
            String returnValue = status.toString();
      logger.finest("RETURN getValidationStatus(int level, DWLStatus status) " + returnValue);
        }
    
        return status;
    }

    private DWLError createDWLError(String entityName, String propertyName,String reasonCode){	
		DWLError err = new DWLError();
		err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCOMPANY_IDENTIFICATION_BOBJ).longValue());
		err.setReasonCode(new Long(reasonCode).longValue());
		err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
			String infoForLogging="Error: Validation error occured. Property " + propertyName + " is null, in entity " + entityName + ", component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
			logger.finest("createDWLError " + infoForLogging);
		}
		return err;
    }
    



}

