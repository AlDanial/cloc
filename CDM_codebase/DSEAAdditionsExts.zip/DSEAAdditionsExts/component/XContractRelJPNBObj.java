
/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[6d051e1df940679a5f7f0beb359a4f6c]
 */

package com.ibm.daimler.dsea.component;

import com.dwl.tcrm.common.TCRMCommon;



import com.dwl.base.DWLControl;

import com.dwl.base.constant.DWLUtilErrorReasonCode;

import com.dwl.base.error.DWLError;
import com.dwl.base.error.DWLErrorCode;
import com.dwl.base.error.DWLStatus;

import com.dwl.base.exception.DWLBaseException;
import com.dwl.base.exception.DWLUpdateException;

import com.dwl.base.util.DWLExceptionUtils;
import com.dwl.base.util.DWLFunctionUtils;

import com.dwl.management.config.client.Configuration;

import com.dwl.tcrm.common.ITCRMValidation;

import com.dwl.tcrm.utilities.DateFormatter;
import com.dwl.tcrm.utilities.DateValidator;
import com.dwl.tcrm.utilities.TCRMClassFactory;

import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsComponentID;
import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsErrorReasonCode;
import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsPropertyKeys;

import com.ibm.daimler.dsea.entityObject.EObjXContractRelJPN;

import com.ibm.daimler.dsea.interfaces.DSEAAdditionsExts;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * This class provides the implementation of the business object
 * <code>XContractRelJPNBObj</code>.
 * 
 * @see com.dwl.tcrm.common.TCRMCommon
 * @generated
 */
 

@SuppressWarnings("serial")
public class XContractRelJPNBObj extends TCRMCommon  {

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected EObjXContractRelJPN eObjXContractRelJPN;
	/**
    * <!-- begin-user-doc -->
	  * <!-- end-user-doc -->
    * @generated 
    */
	 private final static com.dwl.base.logging.IDWLLogger logger = com.dwl.base.logging.DWLLoggerManager.getLogger(XContractRelJPNBObj.class);
		
 
	protected boolean isValidStartDate = true;
	
	protected boolean isValidEndDate = true;
	


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */     
    public XContractRelJPNBObj() {
        super();
        init();
        eObjXContractRelJPN = new EObjXContractRelJPN();
        setComponentID(DSEAAdditionsExtsComponentID.XCONTRACT_REL_JPNBOBJ);
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Initializes the fields required to populate the metaDataMap. Each key is
     * an element-level field of the business object.
     *
     * @generated
     */
    private void init() {
        metaDataMap.put("XContractRelJPNpkId", null);
        metaDataMap.put("ContractId", null);
        metaDataMap.put("ContId", null);
        metaDataMap.put("MarketName", null);
        metaDataMap.put("PersonOrgCode", null);
        metaDataMap.put("ContractRole", null);
        metaDataMap.put("StartDate", null);
        metaDataMap.put("EndDate", null);
        metaDataMap.put("XContractRelJPNHistActionCode", null);
        metaDataMap.put("XContractRelJPNHistCreateDate", null);
        metaDataMap.put("XContractRelJPNHistCreatedBy", null);
        metaDataMap.put("XContractRelJPNHistEndDate", null);
        metaDataMap.put("XContractRelJPNHistoryIdPK", null);
        metaDataMap.put("XContractRelJPNLastUpdateDate", null);
        metaDataMap.put("XContractRelJPNLastUpdateTxId", null);
        metaDataMap.put("XContractRelJPNLastUpdateUser", null);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Refreshes all the attributes this business object supports.
     *
     * @see com.dwl.base.DWLCommon#refreshMap()
     * @generated
     */
    public void refreshMap() {

        if (bRequireMapRefresh) {
            super.refreshMap();
            metaDataMap.put("XContractRelJPNpkId", getXContractRelJPNpkId());
            metaDataMap.put("ContractId", getContractId());
            metaDataMap.put("ContId", getContId());
            metaDataMap.put("MarketName", getMarketName());
            metaDataMap.put("PersonOrgCode", getPersonOrgCode());
            metaDataMap.put("ContractRole", getContractRole());
            metaDataMap.put("StartDate", getStartDate());
            metaDataMap.put("EndDate", getEndDate());
            metaDataMap.put("XContractRelJPNHistActionCode", getXContractRelJPNHistActionCode());
            metaDataMap.put("XContractRelJPNHistCreateDate", getXContractRelJPNHistCreateDate());
            metaDataMap.put("XContractRelJPNHistCreatedBy", getXContractRelJPNHistCreatedBy());
            metaDataMap.put("XContractRelJPNHistEndDate", getXContractRelJPNHistEndDate());
            metaDataMap.put("XContractRelJPNHistoryIdPK", getXContractRelJPNHistoryIdPK());
            metaDataMap.put("XContractRelJPNLastUpdateDate", getXContractRelJPNLastUpdateDate());
            metaDataMap.put("XContractRelJPNLastUpdateTxId", getXContractRelJPNLastUpdateTxId());
            metaDataMap.put("XContractRelJPNLastUpdateUser", getXContractRelJPNLastUpdateUser());
            bRequireMapRefresh = false;
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the control object on this business object.
     *
     * @see com.dwl.base.DWLCommon#setControl(DWLControl)
     * @generated
     */
    public void setControl(DWLControl newDWLControl) {
        super.setControl(newDWLControl);

        if (eObjXContractRelJPN != null) {
            eObjXContractRelJPN.setControl(newDWLControl);
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the entity object associated with this business object.
     *
     * @generated
     */
    public EObjXContractRelJPN getEObjXContractRelJPN() {
        bRequireMapRefresh = true;
        return eObjXContractRelJPN;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the entity object associated with this business object.
     *
     * @param eObjXContractRelJPN
     *            The eObjXContractRelJPN to set.
     * @generated
     */
    public void setEObjXContractRelJPN(EObjXContractRelJPN eObjXContractRelJPN) {
        bRequireMapRefresh = true;
        this.eObjXContractRelJPN = eObjXContractRelJPN;
        if (this.eObjXContractRelJPN != null && this.eObjXContractRelJPN.getControl() == null) {
            DWLControl control = this.getControl();
            if (control != null) {
                this.eObjXContractRelJPN.setControl(control);
            }
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xContractRelJPNpkId attribute.
     * 
     * @generated
     */
    public String getXContractRelJPNpkId (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXContractRelJPN.getXContractRelJPNpkId());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xContractRelJPNpkId attribute.
     * 
     * @param newXContractRelJPNpkId
     *     The new value of xContractRelJPNpkId.
     * @generated
     */
    public void setXContractRelJPNpkId( String newXContractRelJPNpkId ) throws Exception {
        metaDataMap.put("XContractRelJPNpkId", newXContractRelJPNpkId);

        if (newXContractRelJPNpkId == null || newXContractRelJPNpkId.equals("")) {
            newXContractRelJPNpkId = null;


        }
        eObjXContractRelJPN.setXContractRelJPNpkId( DWLFunctionUtils.getLongFromString(newXContractRelJPNpkId) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the contractId attribute.
     * 
     * @generated
     */
    public String getContractId (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXContractRelJPN.getContractId());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the contractId attribute.
     * 
     * @param newContractId
     *     The new value of contractId.
     * @generated
     */
    public void setContractId( String newContractId ) throws Exception {
        metaDataMap.put("ContractId", newContractId);

        if (newContractId == null || newContractId.equals("")) {
            newContractId = null;


        }
        eObjXContractRelJPN.setContractId( DWLFunctionUtils.getLongFromString(newContractId) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the contId attribute.
     * 
     * @generated
     */
    public String getContId (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXContractRelJPN.getContId());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the contId attribute.
     * 
     * @param newContId
     *     The new value of contId.
     * @generated
     */
    public void setContId( String newContId ) throws Exception {
        metaDataMap.put("ContId", newContId);

        if (newContId == null || newContId.equals("")) {
            newContId = null;


        }
        eObjXContractRelJPN.setContId( DWLFunctionUtils.getLongFromString(newContId) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the marketName attribute.
     * 
     * @generated
     */
    public String getMarketName (){
   
        return eObjXContractRelJPN.getMarketName();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the marketName attribute.
     * 
     * @param newMarketName
     *     The new value of marketName.
     * @generated
     */
    public void setMarketName( String newMarketName ) throws Exception {
        metaDataMap.put("MarketName", newMarketName);

        if (newMarketName == null || newMarketName.equals("")) {
            newMarketName = null;


        }
        eObjXContractRelJPN.setMarketName( newMarketName );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the personOrgCode attribute.
     * 
     * @generated
     */
    public String getPersonOrgCode (){
   
        return eObjXContractRelJPN.getPersonOrgCode();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the personOrgCode attribute.
     * 
     * @param newPersonOrgCode
     *     The new value of personOrgCode.
     * @generated
     */
    public void setPersonOrgCode( String newPersonOrgCode ) throws Exception {
        metaDataMap.put("PersonOrgCode", newPersonOrgCode);

        if (newPersonOrgCode == null || newPersonOrgCode.equals("")) {
            newPersonOrgCode = null;


        }
        eObjXContractRelJPN.setPersonOrgCode( newPersonOrgCode );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the contractRole attribute.
     * 
     * @generated
     */
    public String getContractRole (){
   
        return eObjXContractRelJPN.getContractRole();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the contractRole attribute.
     * 
     * @param newContractRole
     *     The new value of contractRole.
     * @generated
     */
    public void setContractRole( String newContractRole ) throws Exception {
        metaDataMap.put("ContractRole", newContractRole);

        if (newContractRole == null || newContractRole.equals("")) {
            newContractRole = null;


        }
        eObjXContractRelJPN.setContractRole( newContractRole );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the startDate attribute.
     * 
     * @generated
     */
    public String getStartDate (){
   
        return DWLFunctionUtils.getStringFromTimestamp(eObjXContractRelJPN.getStartDate());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the startDate attribute.
     * 
     * @param newStartDate
     *     The new value of startDate.
     * @generated
     */
    public void setStartDate( String newStartDate ) throws Exception {
        metaDataMap.put("StartDate", newStartDate);
       	isValidStartDate = true;

        if (newStartDate == null || newStartDate.equals("")) {
            newStartDate = null;
            eObjXContractRelJPN.setStartDate(null);


        }
    else {
        	if (DateValidator.validates(newStartDate)) {
           		eObjXContractRelJPN.setStartDate(DateFormatter.getStartDateTimestamp(newStartDate));
            	metaDataMap.put("StartDate", getStartDate());
        	} else {
            	if (Configuration.getConfiguration().getConfigItem(
              "/IBM/DWLCommonServices/InternalValidation/enabled").getBooleanValue()) {
                	if (metaDataMap.get("StartDate") != null) {
                    	metaDataMap.put("StartDate", "");
                	}
                	isValidStartDate = false;
                	eObjXContractRelJPN.setStartDate(null);
            	}
        	}
        }
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the endDate attribute.
     * 
     * @generated
     */
    public String getEndDate (){
   
        return DWLFunctionUtils.getStringFromTimestamp(eObjXContractRelJPN.getEndDate());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the endDate attribute.
     * 
     * @param newEndDate
     *     The new value of endDate.
     * @generated
     */
    public void setEndDate( String newEndDate ) throws Exception {
        metaDataMap.put("EndDate", newEndDate);
       	isValidEndDate = true;

        if (newEndDate == null || newEndDate.equals("")) {
            newEndDate = null;
            eObjXContractRelJPN.setEndDate(null);


        }
    else {
        	if (DateValidator.validates(newEndDate)) {
           		eObjXContractRelJPN.setEndDate(DateFormatter.getStartDateTimestamp(newEndDate));
            	metaDataMap.put("EndDate", getEndDate());
        	} else {
            	if (Configuration.getConfiguration().getConfigItem(
              "/IBM/DWLCommonServices/InternalValidation/enabled").getBooleanValue()) {
                	if (metaDataMap.get("EndDate") != null) {
                    	metaDataMap.put("EndDate", "");
                	}
                	isValidEndDate = false;
                	eObjXContractRelJPN.setEndDate(null);
            	}
        	}
        }
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateTxId attribute.
     *
     * @generated
     */
    public String getXContractRelJPNLastUpdateTxId() {
        return DWLFunctionUtils.getStringFromLong(eObjXContractRelJPN.getLastUpdateTxId());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateUser attribute.
     *
     * @generated
     */
    public String getXContractRelJPNLastUpdateUser() {
        return eObjXContractRelJPN.getLastUpdateUser();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateDt attribute.
     *
     * @generated
     */
    public String getXContractRelJPNLastUpdateDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXContractRelJPN.getLastUpdateDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateTxId attribute.
     *
     * @param newLastUpdateTxId
     *     The new value of LastUpdateTxId.
     * @generated
     */
    public void setXContractRelJPNLastUpdateTxId(String newLastUpdateTxId) {
        metaDataMap.put("XContractRelJPNLastUpdateTxId", newLastUpdateTxId);

        if ((newLastUpdateTxId == null) || newLastUpdateTxId.equals("")) {
            newLastUpdateTxId = null;
        }
        eObjXContractRelJPN.setLastUpdateTxId(DWLFunctionUtils.getLongFromString(newLastUpdateTxId));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateUser attribute.
     *
     * @param newLastUpdateUser
     *     The new value of LastUpdateUser.
     * @generated
     */
    public void setXContractRelJPNLastUpdateUser(String newLastUpdateUser) {
        metaDataMap.put("XContractRelJPNLastUpdateUser", newLastUpdateUser);

        if ((newLastUpdateUser == null) || newLastUpdateUser.equals("")) {
            newLastUpdateUser = null;
        }
        eObjXContractRelJPN.setLastUpdateUser(newLastUpdateUser);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateDt attribute.
     *
     * @param newLastUpdateDt
     *     The new value of LastUpdateDt.
     * @throws Exception
     * @generated
     */
    public void setXContractRelJPNLastUpdateDate(String newLastUpdateDt) throws Exception {
        metaDataMap.put("XContractRelJPNLastUpdateDate", newLastUpdateDt);

        if ((newLastUpdateDt == null) || newLastUpdateDt.equals("")) {
            newLastUpdateDt = null;
        }

        eObjXContractRelJPN.setLastUpdateDt(DWLFunctionUtils.getTimestampFromTimestampString(newLastUpdateDt));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XContractRelJPNHistActionCode history attribute.
     *
     * @generated
     */
    public String getXContractRelJPNHistActionCode() {
        return eObjXContractRelJPN.getHistActionCode();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XContractRelJPNHistActionCode history attribute.
     *
     * @param aXContractRelJPNHistActionCode
     *     The new value of XContractRelJPNHistActionCode.
     * @generated
     */
    public void setXContractRelJPNHistActionCode(String aXContractRelJPNHistActionCode) {
        metaDataMap.put("XContractRelJPNHistActionCode", aXContractRelJPNHistActionCode);

        if ((aXContractRelJPNHistActionCode == null) || aXContractRelJPNHistActionCode.equals("")) {
            aXContractRelJPNHistActionCode = null;
        }
        eObjXContractRelJPN.setHistActionCode(aXContractRelJPNHistActionCode);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XContractRelJPNHistCreateDate history attribute.
     *
     * @generated
     */
    public String getXContractRelJPNHistCreateDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXContractRelJPN.getHistCreateDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XContractRelJPNHistCreateDate history attribute.
     *
     * @param aXContractRelJPNHistCreateDate
     *     The new value of XContractRelJPNHistCreateDate.
     * @generated
     */
    public void setXContractRelJPNHistCreateDate(String aXContractRelJPNHistCreateDate) throws Exception{
        metaDataMap.put("XContractRelJPNHistCreateDate", aXContractRelJPNHistCreateDate);

        if ((aXContractRelJPNHistCreateDate == null) || aXContractRelJPNHistCreateDate.equals("")) {
            aXContractRelJPNHistCreateDate = null;
        }

        eObjXContractRelJPN.setHistCreateDt(DWLFunctionUtils.getTimestampFromTimestampString(aXContractRelJPNHistCreateDate));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XContractRelJPNHistCreatedBy history attribute.
     *
     * @generated
     */
    public String getXContractRelJPNHistCreatedBy() {
        return eObjXContractRelJPN.getHistCreatedBy();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XContractRelJPNHistCreatedBy history attribute.
     *
     * @param aXContractRelJPNHistCreatedBy
     *     The new value of XContractRelJPNHistCreatedBy.
     * @generated
     */
    public void setXContractRelJPNHistCreatedBy(String aXContractRelJPNHistCreatedBy) {
        metaDataMap.put("XContractRelJPNHistCreatedBy", aXContractRelJPNHistCreatedBy);

        if ((aXContractRelJPNHistCreatedBy == null) || aXContractRelJPNHistCreatedBy.equals("")) {
            aXContractRelJPNHistCreatedBy = null;
        }

        eObjXContractRelJPN.setHistCreatedBy(aXContractRelJPNHistCreatedBy);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XContractRelJPNHistEndDate history attribute.
     *
     * @generated
     */
    public String getXContractRelJPNHistEndDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXContractRelJPN.getHistEndDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XContractRelJPNHistEndDate history attribute.
     *
     * @param aXContractRelJPNHistEndDate
     *     The new value of XContractRelJPNHistEndDate.
     * @generated
     */
    public void setXContractRelJPNHistEndDate(String aXContractRelJPNHistEndDate) throws Exception{
        metaDataMap.put("XContractRelJPNHistEndDate", aXContractRelJPNHistEndDate);

        if ((aXContractRelJPNHistEndDate == null) || aXContractRelJPNHistEndDate.equals("")) {
            aXContractRelJPNHistEndDate = null;
        }
        eObjXContractRelJPN.setHistEndDt(DWLFunctionUtils.getTimestampFromTimestampString(aXContractRelJPNHistEndDate));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XContractRelJPNHistoryIdPK history attribute.
     *
     * @generated
     */
    public String getXContractRelJPNHistoryIdPK() {
        return DWLFunctionUtils.getStringFromLong(eObjXContractRelJPN.getHistoryIdPK());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XContractRelJPNHistoryIdPK history attribute.
     *
     * @param aXContractRelJPNHistoryIdPK
     *     The new value of XContractRelJPNHistoryIdPK.
     * @generated
     */
    public void setXContractRelJPNHistoryIdPK(String aXContractRelJPNHistoryIdPK) {
        metaDataMap.put("XContractRelJPNHistoryIdPK", aXContractRelJPNHistoryIdPK);

        if ((aXContractRelJPNHistoryIdPK == null) || aXContractRelJPNHistoryIdPK.equals("")) {
            aXContractRelJPNHistoryIdPK = null;
        }
        eObjXContractRelJPN.setHistoryIdPK(DWLFunctionUtils.getLongFromString(aXContractRelJPNHistoryIdPK));
    }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation during an add transaction.
     *
     * @generated
     */
    public DWLStatus validateAdd(int level, DWLStatus status) throws Exception {

        status = super.validateAdd(level, status);
        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0038I Add any controller-level custom validation logic to be
            // executed for this object during an "add" transaction

        }

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            // MDM_TODO0: CDKWB0039I Add any component-level custom validation logic to be
            // executed for this object during an "add" transaction
        }
        status = getValidationStatus(level, status);
        return status;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation during an update transaction.
     *
     * @generated
     */
    public DWLStatus validateUpdate(int level, DWLStatus status) throws Exception {
    logger.finest("ENTER validateUpdate(int level, DWLStatus status)");

        status = super.validateUpdate(level, status);
        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0040I Add any controller-level custom validation logic to be
            // executed for this object during an "update" transaction

            if (eObjXContractRelJPN.getXContractRelJPNpkId() == null) {
                DWLError err = new DWLError();
                err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCONTRACT_REL_JPNBOBJ).longValue());
                err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.XCONTRACTRELJPN_XCONTRACTRELJPNPKID_NULL).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                	String infoForLogging="Error: Validation error occured for update. No primary key for entity XContractRelJPN, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("validateUpdate(int level, DWLStatus status) " + infoForLogging);
                }
                status.addError(err);
            }
            if (eObjXContractRelJPN.getLastUpdateDt() == null) {
                DWLError err = new DWLError();
                err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCONTRACT_REL_JPNBOBJ).longValue());
                err.setReasonCode(new Long(DWLUtilErrorReasonCode.LAST_UPDATED_DATE_NULL).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
                if (logger.isFinestEnabled()) {
                	String infoForLogging="Error: Validation error occured for update. No last update date for entity XContractRelJPN, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("validateUpdate(int level, DWLStatus status) " + infoForLogging);
                }
                status.addError(err);
            }
        }

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            assignBeforeImageValues(metaDataMap);
            
            // MDM_TODO0: CDKWB0041I Add any component-level custom validation logic to be
            // executed for this object during an "update" transaction
        }
        status = getValidationStatus(level, status);
    if (logger.isFinestEnabled()) {
        	String returnValue = status.toString();
      logger.finest("RETURN validateUpdate(int level, DWLStatus status) " + returnValue);
    }
        return status;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Populate the before image of this business object.
     *
     * @see com.dwl.base.DWLCommon#populateBeforeImage()
     * @generated
     */
    public void populateBeforeImage() throws DWLBaseException {
    logger.finest("ENTER populateBeforeImage()");

        DSEAAdditionsExts comp = null;
        try {
        
      comp = (DSEAAdditionsExts)TCRMClassFactory.getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
        	
        } catch (Exception e) {
      if (logger.isFinestEnabled()) {
        String infoForLogging="Error: Fatal error while updating record " + e.getMessage();
      logger.finest("populateBeforeImage() " + infoForLogging);
      }
            DWLExceptionUtils.throwDWLBaseException(e, 
            									new DWLUpdateException(e.getMessage()), 
            									this.getStatus(), DWLStatus.FATAL,
                                  DSEAAdditionsExtsComponentID.XCONTRACT_REL_JPNBOBJ, 
                                  "DIERR",
                                  DSEAAdditionsExtsErrorReasonCode.XCONTRACTRELJPN_BEFORE_IMAGE_NOT_POPULATED, 
                                  this.getControl());
        }
        
        comp.loadBeforeImage(this);
    logger.finest("RETURN populateBeforeImage()");
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation common to both add and update transactions.
     *
     * @generated
     */
     
    private DWLStatus getValidationStatus(int level, DWLStatus status) throws Exception {
    logger.finest("ENTER getValidationStatus(int level, DWLStatus status)");

        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0034I Add any common controller-level custom validation
            // logic to be executed for this object during either "add" or
            // "update" transactions
    		controllerValidation_StartDate(status);
    		controllerValidation_EndDate(status);
    	}

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            // MDM_TODO0: CDKWB0035I Add any common component-level custom validation logic
            // to be executed for this object during either "add" or "update"
            // transactions
    		componentValidation_StartDate(status);
    		componentValidation_EndDate(status);
        }
        
        if (logger.isFinestEnabled()) {
            String returnValue = status.toString();
      logger.finest("RETURN getValidationStatus(int level, DWLStatus status) " + returnValue);
        }
    
        return status;
    }

    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "StartDate"
     *
     * @generated
     */
	private void componentValidation_StartDate(DWLStatus status) {
  
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "EndDate"
     *
     * @generated
     */
	private void componentValidation_EndDate(DWLStatus status) {
  
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "StartDate"
     *
     * @generated
     */
	private void controllerValidation_StartDate(DWLStatus status) throws Exception {
  
            boolean isStartDateNull = (eObjXContractRelJPN.getStartDate() == null);
            if (!isValidStartDate) {
              	DWLError err = new DWLError();
               	err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCONTRACT_REL_JPNBOBJ).longValue());
               	err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XCONTRACTRELJPN_STARTDATE).longValue());
               	err.setErrorType(DWLErrorCode.DATA_INVALID_ERROR);
                String infoForLogging="Error: Validation error. Invalid time specified on property StartDate in entity XContractRelJPN, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode();
      logger.finest("controllerValidation_StartDate " + infoForLogging);
               	status.addError(err);
            } 
    	}
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "EndDate"
     *
     * @generated
     */
	private void controllerValidation_EndDate(DWLStatus status) throws Exception {
  
            boolean isEndDateNull = (eObjXContractRelJPN.getEndDate() == null);
            if (!isValidEndDate) {
              	DWLError err = new DWLError();
               	err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCONTRACT_REL_JPNBOBJ).longValue());
               	err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XCONTRACTRELJPN_ENDDATE).longValue());
               	err.setErrorType(DWLErrorCode.DATA_INVALID_ERROR);
                String infoForLogging="Error: Validation error. Invalid time specified on property EndDate in entity XContractRelJPN, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode();
      logger.finest("controllerValidation_EndDate " + infoForLogging);
               	status.addError(err);
            } 
    	}
    private DWLError createDWLError(String entityName, String propertyName,String reasonCode){	
		DWLError err = new DWLError();
		err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCONTRACT_REL_JPNBOBJ).longValue());
		err.setReasonCode(new Long(reasonCode).longValue());
		err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
			String infoForLogging="Error: Validation error occured. Property " + propertyName + " is null, in entity " + entityName + ", component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
			logger.finest("createDWLError " + infoForLogging);
		}
		return err;
    }
    



}

