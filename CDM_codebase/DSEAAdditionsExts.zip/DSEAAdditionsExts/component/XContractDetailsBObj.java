
/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[2b13d9369bcda513f1d68136dc77df2b]
 */

package com.ibm.daimler.dsea.component;

import com.dwl.tcrm.common.TCRMCommon;



import com.dwl.base.DWLControl;

import com.dwl.base.constant.DWLControlKeys;
import com.dwl.base.constant.DWLUtilErrorReasonCode;

import com.dwl.base.error.DWLError;
import com.dwl.base.error.DWLErrorCode;
import com.dwl.base.error.DWLStatus;

import com.dwl.base.exception.DWLBaseException;
import com.dwl.base.exception.DWLUpdateException;

import com.dwl.base.util.DWLClassFactory;
import com.dwl.base.util.DWLExceptionUtils;
import com.dwl.base.util.DWLFunctionUtils;

import com.dwl.management.config.client.Configuration;

import com.dwl.tcrm.common.ITCRMValidation;

import com.dwl.tcrm.utilities.DateFormatter;
import com.dwl.tcrm.utilities.DateValidator;
import com.dwl.tcrm.utilities.TCRMClassFactory;

import com.ibm.daimler.dsea.component.CoborrowerDetailsBObj;
import com.ibm.daimler.dsea.component.GuarantorDetailsBObj;
import com.ibm.daimler.dsea.component.XGurantorCompanyBObj;
import com.ibm.daimler.dsea.component.XGurantorIndividualBObj;

import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsComponentID;
import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsErrorReasonCode;
import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsPropertyKeys;

import com.ibm.daimler.dsea.entityObject.EObjXContractDetails;

import com.ibm.daimler.dsea.interfaces.DSEAAdditionsExts;

import com.ibm.mdm.common.codetype.interfaces.CodeTypeComponentHelper;

import com.ibm.mdm.common.codetype.obj.CodeTypeBObj;

import java.util.Vector;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * This class provides the implementation of the business object
 * <code>XContractDetailsBObj</code>.
 * 
 * @see com.dwl.tcrm.common.TCRMCommon
 * @generated
 */
 

@SuppressWarnings("serial")
public class XContractDetailsBObj extends TCRMCommon  {

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected EObjXContractDetails eObjXContractDetails;
	/**
    * <!-- begin-user-doc -->
	  * <!-- end-user-doc -->
    * @generated 
    */
	 private final static com.dwl.base.logging.IDWLLogger logger = com.dwl.base.logging.DWLLoggerManager.getLogger(XContractDetailsBObj.class);
		
 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected String contractStatusValue;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected String countryValue;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected String sourceIdentifierValue;
	protected boolean isValidStartDate = true;
	
	protected boolean isValidEndDate = true;
	
    protected boolean isValidLastModifiedSystemDate = true;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    @SuppressWarnings("rawtypes")
    protected Vector vecGuarantorDetailsBObj;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    @SuppressWarnings("rawtypes")
    protected Vector vecCoborrowerDetailsBObj;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */     
    @SuppressWarnings("rawtypes")
    public XContractDetailsBObj() {
        super();
        init();
        eObjXContractDetails = new EObjXContractDetails();
        vecGuarantorDetailsBObj = new Vector();
        vecCoborrowerDetailsBObj = new Vector();
        setComponentID(DSEAAdditionsExtsComponentID.XCONTRACT_DETAILS_BOBJ);
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Initializes the fields required to populate the metaDataMap. Each key is
     * an element-level field of the business object.
     *
     * @generated
     */
    private void init() {
        metaDataMap.put("ContractpkId", null);
        metaDataMap.put("ContId", null);
        metaDataMap.put("FinanceProduct", null);
        metaDataMap.put("ContractNumber", null);
        metaDataMap.put("ContractStatusType", null);
        metaDataMap.put("ContractStatusValue", null);
        metaDataMap.put("MarketName", null);
        metaDataMap.put("FinancialProductGroup", null);
        metaDataMap.put("AddressLineOne", null);
        metaDataMap.put("AddressLineTwo", null);
        metaDataMap.put("AddressLineThree", null);
        metaDataMap.put("PostalCode", null);
        metaDataMap.put("CityName", null);
        metaDataMap.put("ResidenceNumber", null);
        metaDataMap.put("CountryType", null);
        metaDataMap.put("CountryValue", null);
        metaDataMap.put("BuildingName", null);
        metaDataMap.put("StreetName", null);
        metaDataMap.put("StreetNumber", null);
        metaDataMap.put("SourceIdentifierType", null);
        metaDataMap.put("SourceIdentifierValue", null);
        metaDataMap.put("StartDate", null);
        metaDataMap.put("EndDate", null);
        metaDataMap.put("LastModifiedSystemDate", null);
        metaDataMap.put("ODDays", null);
        metaDataMap.put("XContractDetailsHistActionCode", null);
        metaDataMap.put("XContractDetailsHistCreateDate", null);
        metaDataMap.put("XContractDetailsHistCreatedBy", null);
        metaDataMap.put("XContractDetailsHistEndDate", null);
        metaDataMap.put("XContractDetailsHistoryIdPK", null);
        metaDataMap.put("XContractDetailsLastUpdateDate", null);
        metaDataMap.put("XContractDetailsLastUpdateTxId", null);
        metaDataMap.put("XContractDetailsLastUpdateUser", null);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Refreshes all the attributes this business object supports.
     *
     * @see com.dwl.base.DWLCommon#refreshMap()
     * @generated
     */
    public void refreshMap() {

        if (bRequireMapRefresh) {
            super.refreshMap();
            metaDataMap.put("ContractpkId", getContractpkId());
            metaDataMap.put("ContId", getContId());
            metaDataMap.put("FinanceProduct", getFinanceProduct());
            metaDataMap.put("ContractNumber", getContractNumber());
            metaDataMap.put("ContractStatusType", getContractStatusType());
            metaDataMap.put("ContractStatusValue", getContractStatusValue());
            metaDataMap.put("MarketName", getMarketName());
            metaDataMap.put("FinancialProductGroup", getFinancialProductGroup());
            metaDataMap.put("AddressLineOne", getAddressLineOne());
            metaDataMap.put("AddressLineTwo", getAddressLineTwo());
            metaDataMap.put("AddressLineThree", getAddressLineThree());
            metaDataMap.put("PostalCode", getPostalCode());
            metaDataMap.put("CityName", getCityName());
            metaDataMap.put("ResidenceNumber", getResidenceNumber());
            metaDataMap.put("CountryType", getCountryType());
            metaDataMap.put("CountryValue", getCountryValue());
            metaDataMap.put("BuildingName", getBuildingName());
            metaDataMap.put("StreetName", getStreetName());
            metaDataMap.put("StreetNumber", getStreetNumber());
            metaDataMap.put("SourceIdentifierType", getSourceIdentifierType());
            metaDataMap.put("SourceIdentifierValue", getSourceIdentifierValue());
            metaDataMap.put("StartDate", getStartDate());
            metaDataMap.put("EndDate", getEndDate());
            metaDataMap.put("LastModifiedSystemDate", getLastModifiedSystemDate());
            metaDataMap.put("ODDays", getODDays());
            metaDataMap.put("XContractDetailsHistActionCode", getXContractDetailsHistActionCode());
            metaDataMap.put("XContractDetailsHistCreateDate", getXContractDetailsHistCreateDate());
            metaDataMap.put("XContractDetailsHistCreatedBy", getXContractDetailsHistCreatedBy());
            metaDataMap.put("XContractDetailsHistEndDate", getXContractDetailsHistEndDate());
            metaDataMap.put("XContractDetailsHistoryIdPK", getXContractDetailsHistoryIdPK());
            metaDataMap.put("XContractDetailsLastUpdateDate", getXContractDetailsLastUpdateDate());
            metaDataMap.put("XContractDetailsLastUpdateTxId", getXContractDetailsLastUpdateTxId());
            metaDataMap.put("XContractDetailsLastUpdateUser", getXContractDetailsLastUpdateUser());
            bRequireMapRefresh = false;
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the control object on this business object.
     *
     * @see com.dwl.base.DWLCommon#setControl(DWLControl)
     * @generated
     */
    public void setControl(DWLControl newDWLControl) {
        super.setControl(newDWLControl);

        if (eObjXContractDetails != null) {
            eObjXContractDetails.setControl(newDWLControl);
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the entity object associated with this business object.
     *
     * @generated
     */
    public EObjXContractDetails getEObjXContractDetails() {
        bRequireMapRefresh = true;
        return eObjXContractDetails;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the entity object associated with this business object.
     *
     * @param eObjXContractDetails
     *            The eObjXContractDetails to set.
     * @generated
     */
    public void setEObjXContractDetails(EObjXContractDetails eObjXContractDetails) {
        bRequireMapRefresh = true;
        this.eObjXContractDetails = eObjXContractDetails;
        if (this.eObjXContractDetails != null && this.eObjXContractDetails.getControl() == null) {
            DWLControl control = this.getControl();
            if (control != null) {
                this.eObjXContractDetails.setControl(control);
            }
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the contractpkId attribute.
     * 
     * @generated
     */
    public String getContractpkId (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXContractDetails.getContractpkId());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the contractpkId attribute.
     * 
     * @param newContractpkId
     *     The new value of contractpkId.
     * @generated
     */
    public void setContractpkId( String newContractpkId ) throws Exception {
        metaDataMap.put("ContractpkId", newContractpkId);

        if (newContractpkId == null || newContractpkId.equals("")) {
            newContractpkId = null;


        }
        eObjXContractDetails.setContractpkId( DWLFunctionUtils.getLongFromString(newContractpkId) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the contId attribute.
     * 
     * @generated
     */
    public String getContId (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXContractDetails.getContId());
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the contId attribute.
     * 
     * @param newContId
     *     The new value of contId.
     * @generated
     */
    public void setContId( String newContId ) throws Exception {
        metaDataMap.put("ContId", newContId);

        if (newContId == null || newContId.equals("")) {
            newContId = null;


        }
        eObjXContractDetails.setContId( DWLFunctionUtils.getLongFromString(newContId) );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the financeProduct attribute.
     * 
     * @generated
     */
    public String getFinanceProduct (){
   
        return eObjXContractDetails.getFinanceProduct();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the financeProduct attribute.
     * 
     * @param newFinanceProduct
     *     The new value of financeProduct.
     * @generated
     */
    public void setFinanceProduct( String newFinanceProduct ) throws Exception {
        metaDataMap.put("FinanceProduct", newFinanceProduct);

        if (newFinanceProduct == null || newFinanceProduct.equals("")) {
            newFinanceProduct = null;


        }
        eObjXContractDetails.setFinanceProduct( newFinanceProduct );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the contractNumber attribute.
     * 
     * @generated
     */
    public String getContractNumber (){
   
        return eObjXContractDetails.getContractNumber();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the contractNumber attribute.
     * 
     * @param newContractNumber
     *     The new value of contractNumber.
     * @generated
     */
    public void setContractNumber( String newContractNumber ) throws Exception {
        metaDataMap.put("ContractNumber", newContractNumber);

        if (newContractNumber == null || newContractNumber.equals("")) {
            newContractNumber = null;


        }
        eObjXContractDetails.setContractNumber( newContractNumber );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the contractStatusType attribute.
     * 
     * @generated
     */
    public String getContractStatusType (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXContractDetails.getContractStatus());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the contractStatusType attribute.
     * 
     * @param newContractStatusType
     *     The new value of contractStatusType.
     * @generated
     */
    public void setContractStatusType( String newContractStatusType ) throws Exception {
        metaDataMap.put("ContractStatusType", newContractStatusType);

        if (newContractStatusType == null || newContractStatusType.equals("")) {
            newContractStatusType = null;


        }
        eObjXContractDetails.setContractStatus( DWLFunctionUtils.getLongFromString(newContractStatusType) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the contractStatusValue attribute.
     * 
     * @generated
     */
    public String getContractStatusValue (){
      return contractStatusValue;
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the contractStatusValue attribute.
     * 
     * @param newContractStatusValue
     *     The new value of contractStatusValue.
     * @generated
     */
    public void setContractStatusValue( String newContractStatusValue ) throws Exception {
        metaDataMap.put("ContractStatusValue", newContractStatusValue);

        if (newContractStatusValue == null || newContractStatusValue.equals("")) {
            newContractStatusValue = null;


        }
        contractStatusValue = newContractStatusValue;
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the marketName attribute.
     * 
     * @generated
     */
    public String getMarketName (){
   
        return eObjXContractDetails.getMarketName();
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the marketName attribute.
     * 
     * @param newMarketName
     *     The new value of marketName.
     * @generated
     */
    public void setMarketName( String newMarketName ) throws Exception {
        metaDataMap.put("MarketName", newMarketName);

        if (newMarketName == null || newMarketName.equals("")) {
            newMarketName = null;


        }
        eObjXContractDetails.setMarketName( newMarketName );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the financialProductGroup attribute.
     * 
     * @generated
     */
    public String getFinancialProductGroup (){
   
        return eObjXContractDetails.getFinancialProductGroup();
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the financialProductGroup attribute.
     * 
     * @param newFinancialProductGroup
     *     The new value of financialProductGroup.
     * @generated
     */
    public void setFinancialProductGroup( String newFinancialProductGroup ) throws Exception {
        metaDataMap.put("FinancialProductGroup", newFinancialProductGroup);

        if (newFinancialProductGroup == null || newFinancialProductGroup.equals("")) {
            newFinancialProductGroup = null;


        }
        eObjXContractDetails.setFinancialProductGroup( newFinancialProductGroup );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the addressLineOne attribute.
     * 
     * @generated
     */
    public String getAddressLineOne (){
   
        return eObjXContractDetails.getAddressLineOne();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the addressLineOne attribute.
     * 
     * @param newAddressLineOne
     *     The new value of addressLineOne.
     * @generated
     */
    public void setAddressLineOne( String newAddressLineOne ) throws Exception {
        metaDataMap.put("AddressLineOne", newAddressLineOne);

        if (newAddressLineOne == null || newAddressLineOne.equals("")) {
            newAddressLineOne = null;


        }
        eObjXContractDetails.setAddressLineOne( newAddressLineOne );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the addressLineTwo attribute.
     * 
     * @generated
     */
    public String getAddressLineTwo (){
   
        return eObjXContractDetails.getAddressLineTwo();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the addressLineTwo attribute.
     * 
     * @param newAddressLineTwo
     *     The new value of addressLineTwo.
     * @generated
     */
    public void setAddressLineTwo( String newAddressLineTwo ) throws Exception {
        metaDataMap.put("AddressLineTwo", newAddressLineTwo);

        if (newAddressLineTwo == null || newAddressLineTwo.equals("")) {
            newAddressLineTwo = null;


        }
        eObjXContractDetails.setAddressLineTwo( newAddressLineTwo );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the addressLineThree attribute.
     * 
     * @generated
     */
    public String getAddressLineThree (){
   
        return eObjXContractDetails.getAddressLineThree();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the addressLineThree attribute.
     * 
     * @param newAddressLineThree
     *     The new value of addressLineThree.
     * @generated
     */
    public void setAddressLineThree( String newAddressLineThree ) throws Exception {
        metaDataMap.put("AddressLineThree", newAddressLineThree);

        if (newAddressLineThree == null || newAddressLineThree.equals("")) {
            newAddressLineThree = null;


        }
        eObjXContractDetails.setAddressLineThree( newAddressLineThree );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the postalCode attribute.
     * 
     * @generated
     */
    public String getPostalCode (){
   
        return eObjXContractDetails.getPostalCode();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the postalCode attribute.
     * 
     * @param newPostalCode
     *     The new value of postalCode.
     * @generated
     */
    public void setPostalCode( String newPostalCode ) throws Exception {
        metaDataMap.put("PostalCode", newPostalCode);

        if (newPostalCode == null || newPostalCode.equals("")) {
            newPostalCode = null;


        }
        eObjXContractDetails.setPostalCode( newPostalCode );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the cityName attribute.
     * 
     * @generated
     */
    public String getCityName (){
   
        return eObjXContractDetails.getCityName();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the cityName attribute.
     * 
     * @param newCityName
     *     The new value of cityName.
     * @generated
     */
    public void setCityName( String newCityName ) throws Exception {
        metaDataMap.put("CityName", newCityName);

        if (newCityName == null || newCityName.equals("")) {
            newCityName = null;


        }
        eObjXContractDetails.setCityName( newCityName );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the residenceNumber attribute.
     * 
     * @generated
     */
    public String getResidenceNumber (){
   
        return eObjXContractDetails.getResidenceNumber();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the residenceNumber attribute.
     * 
     * @param newResidenceNumber
     *     The new value of residenceNumber.
     * @generated
     */
    public void setResidenceNumber( String newResidenceNumber ) throws Exception {
        metaDataMap.put("ResidenceNumber", newResidenceNumber);

        if (newResidenceNumber == null || newResidenceNumber.equals("")) {
            newResidenceNumber = null;


        }
        eObjXContractDetails.setResidenceNumber( newResidenceNumber );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the countryType attribute.
     * 
     * @generated
     */
    public String getCountryType (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXContractDetails.getCountry());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the countryType attribute.
     * 
     * @param newCountryType
     *     The new value of countryType.
     * @generated
     */
    public void setCountryType( String newCountryType ) throws Exception {
        metaDataMap.put("CountryType", newCountryType);

        if (newCountryType == null || newCountryType.equals("")) {
            newCountryType = null;


        }
        eObjXContractDetails.setCountry( DWLFunctionUtils.getLongFromString(newCountryType) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the countryValue attribute.
     * 
     * @generated
     */
    public String getCountryValue (){
      return countryValue;
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the countryValue attribute.
     * 
     * @param newCountryValue
     *     The new value of countryValue.
     * @generated
     */
    public void setCountryValue( String newCountryValue ) throws Exception {
        metaDataMap.put("CountryValue", newCountryValue);

        if (newCountryValue == null || newCountryValue.equals("")) {
            newCountryValue = null;


        }
        countryValue = newCountryValue;
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the buildingName attribute.
     * 
     * @generated
     */
    public String getBuildingName (){
   
        return eObjXContractDetails.getBuildingName();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the buildingName attribute.
     * 
     * @param newBuildingName
     *     The new value of buildingName.
     * @generated
     */
    public void setBuildingName( String newBuildingName ) throws Exception {
        metaDataMap.put("BuildingName", newBuildingName);

        if (newBuildingName == null || newBuildingName.equals("")) {
            newBuildingName = null;


        }
        eObjXContractDetails.setBuildingName( newBuildingName );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the streetName attribute.
     * 
     * @generated
     */
    public String getStreetName (){
   
        return eObjXContractDetails.getStreetName();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the streetName attribute.
     * 
     * @param newStreetName
     *     The new value of streetName.
     * @generated
     */
    public void setStreetName( String newStreetName ) throws Exception {
        metaDataMap.put("StreetName", newStreetName);

        if (newStreetName == null || newStreetName.equals("")) {
            newStreetName = null;


        }
        eObjXContractDetails.setStreetName( newStreetName );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the streetNumber attribute.
     * 
     * @generated
     */
    public String getStreetNumber (){
   
        return eObjXContractDetails.getStreetNumber();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the streetNumber attribute.
     * 
     * @param newStreetNumber
     *     The new value of streetNumber.
     * @generated
     */
    public void setStreetNumber( String newStreetNumber ) throws Exception {
        metaDataMap.put("StreetNumber", newStreetNumber);

        if (newStreetNumber == null || newStreetNumber.equals("")) {
            newStreetNumber = null;


        }
        eObjXContractDetails.setStreetNumber( newStreetNumber );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the sourceIdentifierType attribute.
     * 
     * @generated
     */
    public String getSourceIdentifierType (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXContractDetails.getSourceIdentifier());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the sourceIdentifierType attribute.
     * 
     * @param newSourceIdentifierType
     *     The new value of sourceIdentifierType.
     * @generated
     */
    public void setSourceIdentifierType( String newSourceIdentifierType ) throws Exception {
        metaDataMap.put("SourceIdentifierType", newSourceIdentifierType);

        if (newSourceIdentifierType == null || newSourceIdentifierType.equals("")) {
            newSourceIdentifierType = null;


        }
        eObjXContractDetails.setSourceIdentifier( DWLFunctionUtils.getLongFromString(newSourceIdentifierType) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the sourceIdentifierValue attribute.
     * 
     * @generated
     */
    public String getSourceIdentifierValue (){
      return sourceIdentifierValue;
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the sourceIdentifierValue attribute.
     * 
     * @param newSourceIdentifierValue
     *     The new value of sourceIdentifierValue.
     * @generated
     */
    public void setSourceIdentifierValue( String newSourceIdentifierValue ) throws Exception {
        metaDataMap.put("SourceIdentifierValue", newSourceIdentifierValue);

        if (newSourceIdentifierValue == null || newSourceIdentifierValue.equals("")) {
            newSourceIdentifierValue = null;


        }
        sourceIdentifierValue = newSourceIdentifierValue;
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the startDate attribute.
     * 
     * @generated
     */
    public String getStartDate (){
   
        return DWLFunctionUtils.getStringFromTimestamp(eObjXContractDetails.getStartDate());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the startDate attribute.
     * 
     * @param newStartDate
     *     The new value of startDate.
     * @generated
     */
    public void setStartDate( String newStartDate ) throws Exception {
        metaDataMap.put("StartDate", newStartDate);
       	isValidStartDate = true;

        if (newStartDate == null || newStartDate.equals("")) {
            newStartDate = null;
            eObjXContractDetails.setStartDate(null);


        }
    else {
        	if (DateValidator.validates(newStartDate)) {
           		eObjXContractDetails.setStartDate(DateFormatter.getStartDateTimestamp(newStartDate));
            	metaDataMap.put("StartDate", getStartDate());
        	} else {
            	if (Configuration.getConfiguration().getConfigItem(
              "/IBM/DWLCommonServices/InternalValidation/enabled").getBooleanValue()) {
                	if (metaDataMap.get("StartDate") != null) {
                    	metaDataMap.put("StartDate", "");
                	}
                	isValidStartDate = false;
                	eObjXContractDetails.setStartDate(null);
            	}
        	}
        }
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the endDate attribute.
     * 
     * @generated
     */
    public String getEndDate (){
   
        return DWLFunctionUtils.getStringFromTimestamp(eObjXContractDetails.getEndDate());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the endDate attribute.
     * 
     * @param newEndDate
     *     The new value of endDate.
     * @generated
     */
    public void setEndDate( String newEndDate ) throws Exception {
        metaDataMap.put("EndDate", newEndDate);
       	isValidEndDate = true;

        if (newEndDate == null || newEndDate.equals("")) {
            newEndDate = null;
            eObjXContractDetails.setEndDate(null);


        }
    else {
        	if (DateValidator.validates(newEndDate)) {
           		eObjXContractDetails.setEndDate(DateFormatter.getStartDateTimestamp(newEndDate));
            	metaDataMap.put("EndDate", getEndDate());
        	} else {
            	if (Configuration.getConfiguration().getConfigItem(
              "/IBM/DWLCommonServices/InternalValidation/enabled").getBooleanValue()) {
                	if (metaDataMap.get("EndDate") != null) {
                    	metaDataMap.put("EndDate", "");
                	}
                	isValidEndDate = false;
                	eObjXContractDetails.setEndDate(null);
            	}
        	}
        }
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the lastModifiedSystemDate attribute.
     * 
     * @generated
     */
    public String getLastModifiedSystemDate (){
   
        return DWLFunctionUtils.getStringFromTimestamp(eObjXContractDetails.getLastModifiedSystemDate());
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the lastModifiedSystemDate attribute.
     * 
     * @param newLastModifiedSystemDate
     *     The new value of lastModifiedSystemDate.
     * @generated
     */
    public void setLastModifiedSystemDate( String newLastModifiedSystemDate ) throws Exception {
        metaDataMap.put("LastModifiedSystemDate", newLastModifiedSystemDate);
       	isValidLastModifiedSystemDate = true;

        if (newLastModifiedSystemDate == null || newLastModifiedSystemDate.equals("")) {
            newLastModifiedSystemDate = null;
            eObjXContractDetails.setLastModifiedSystemDate(null);


        }
    else {
        	if (DateValidator.validates(newLastModifiedSystemDate)) {
           		eObjXContractDetails.setLastModifiedSystemDate(DateFormatter.getStartDateTimestamp(newLastModifiedSystemDate));
            	metaDataMap.put("LastModifiedSystemDate", getLastModifiedSystemDate());
        	} else {
            	if (Configuration.getConfiguration().getConfigItem(
              "/IBM/DWLCommonServices/InternalValidation/enabled").getBooleanValue()) {
                	if (metaDataMap.get("LastModifiedSystemDate") != null) {
                    	metaDataMap.put("LastModifiedSystemDate", "");
                	}
                	isValidLastModifiedSystemDate = false;
                	eObjXContractDetails.setLastModifiedSystemDate(null);
            	}
        	}
        }
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the oDDays attribute.
     * 
     * @generated
     */
    public String getODDays (){
   
        return DWLFunctionUtils.getStringFromInteger(eObjXContractDetails.getODDays());
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the oDDays attribute.
     * 
     * @param newODDays
     *     The new value of oDDays.
     * @generated
     */
    public void setODDays( String newODDays ) throws Exception {
        metaDataMap.put("ODDays", newODDays);

        if (newODDays == null || newODDays.equals("")) {
            newODDays = null;


        }
        eObjXContractDetails.setODDays( DWLFunctionUtils.getIntegerFromString(newODDays) );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the GuarantorDetailsBObj attribute.
     * 
     * @generated
     */
    @SuppressWarnings("rawtypes")
    public Vector getItemsGuarantorDetailsBObj (){
      return vecGuarantorDetailsBObj;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    @SuppressWarnings("unchecked")
    public void setGuarantorDetailsBObj(GuarantorDetailsBObj newBObj ) {
        vecGuarantorDetailsBObj.addElement( newBObj );
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the CoborrowerDetailsBObj attribute.
     * 
     * @generated
     */
    @SuppressWarnings("rawtypes")
    public Vector getItemsCoborrowerDetailsBObj (){
      return vecCoborrowerDetailsBObj;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    @SuppressWarnings("unchecked")
    public void setCoborrowerDetailsBObj(CoborrowerDetailsBObj newBObj ) {
        vecCoborrowerDetailsBObj.addElement( newBObj );
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateTxId attribute.
     *
     * @generated
     */
    public String getXContractDetailsLastUpdateTxId() {
        return DWLFunctionUtils.getStringFromLong(eObjXContractDetails.getLastUpdateTxId());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateUser attribute.
     *
     * @generated
     */
    public String getXContractDetailsLastUpdateUser() {
        return eObjXContractDetails.getLastUpdateUser();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateDt attribute.
     *
     * @generated
     */
    public String getXContractDetailsLastUpdateDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXContractDetails.getLastUpdateDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateTxId attribute.
     *
     * @param newLastUpdateTxId
     *     The new value of LastUpdateTxId.
     * @generated
     */
    public void setXContractDetailsLastUpdateTxId(String newLastUpdateTxId) {
        metaDataMap.put("XContractDetailsLastUpdateTxId", newLastUpdateTxId);

        if ((newLastUpdateTxId == null) || newLastUpdateTxId.equals("")) {
            newLastUpdateTxId = null;
        }
        eObjXContractDetails.setLastUpdateTxId(DWLFunctionUtils.getLongFromString(newLastUpdateTxId));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateUser attribute.
     *
     * @param newLastUpdateUser
     *     The new value of LastUpdateUser.
     * @generated
     */
    public void setXContractDetailsLastUpdateUser(String newLastUpdateUser) {
        metaDataMap.put("XContractDetailsLastUpdateUser", newLastUpdateUser);

        if ((newLastUpdateUser == null) || newLastUpdateUser.equals("")) {
            newLastUpdateUser = null;
        }
        eObjXContractDetails.setLastUpdateUser(newLastUpdateUser);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateDt attribute.
     *
     * @param newLastUpdateDt
     *     The new value of LastUpdateDt.
     * @throws Exception
     * @generated
     */
    public void setXContractDetailsLastUpdateDate(String newLastUpdateDt) throws Exception {
        metaDataMap.put("XContractDetailsLastUpdateDate", newLastUpdateDt);

        if ((newLastUpdateDt == null) || newLastUpdateDt.equals("")) {
            newLastUpdateDt = null;
        }

        eObjXContractDetails.setLastUpdateDt(DWLFunctionUtils.getTimestampFromTimestampString(newLastUpdateDt));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XContractDetailsHistActionCode history attribute.
     *
     * @generated
     */
    public String getXContractDetailsHistActionCode() {
        return eObjXContractDetails.getHistActionCode();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XContractDetailsHistActionCode history attribute.
     *
     * @param aXContractDetailsHistActionCode
     *     The new value of XContractDetailsHistActionCode.
     * @generated
     */
    public void setXContractDetailsHistActionCode(String aXContractDetailsHistActionCode) {
        metaDataMap.put("XContractDetailsHistActionCode", aXContractDetailsHistActionCode);

        if ((aXContractDetailsHistActionCode == null) || aXContractDetailsHistActionCode.equals("")) {
            aXContractDetailsHistActionCode = null;
        }
        eObjXContractDetails.setHistActionCode(aXContractDetailsHistActionCode);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XContractDetailsHistCreateDate history attribute.
     *
     * @generated
     */
    public String getXContractDetailsHistCreateDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXContractDetails.getHistCreateDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XContractDetailsHistCreateDate history attribute.
     *
     * @param aXContractDetailsHistCreateDate
     *     The new value of XContractDetailsHistCreateDate.
     * @generated
     */
    public void setXContractDetailsHistCreateDate(String aXContractDetailsHistCreateDate) throws Exception{
        metaDataMap.put("XContractDetailsHistCreateDate", aXContractDetailsHistCreateDate);

        if ((aXContractDetailsHistCreateDate == null) || aXContractDetailsHistCreateDate.equals("")) {
            aXContractDetailsHistCreateDate = null;
        }

        eObjXContractDetails.setHistCreateDt(DWLFunctionUtils.getTimestampFromTimestampString(aXContractDetailsHistCreateDate));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XContractDetailsHistCreatedBy history attribute.
     *
     * @generated
     */
    public String getXContractDetailsHistCreatedBy() {
        return eObjXContractDetails.getHistCreatedBy();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XContractDetailsHistCreatedBy history attribute.
     *
     * @param aXContractDetailsHistCreatedBy
     *     The new value of XContractDetailsHistCreatedBy.
     * @generated
     */
    public void setXContractDetailsHistCreatedBy(String aXContractDetailsHistCreatedBy) {
        metaDataMap.put("XContractDetailsHistCreatedBy", aXContractDetailsHistCreatedBy);

        if ((aXContractDetailsHistCreatedBy == null) || aXContractDetailsHistCreatedBy.equals("")) {
            aXContractDetailsHistCreatedBy = null;
        }

        eObjXContractDetails.setHistCreatedBy(aXContractDetailsHistCreatedBy);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XContractDetailsHistEndDate history attribute.
     *
     * @generated
     */
    public String getXContractDetailsHistEndDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXContractDetails.getHistEndDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XContractDetailsHistEndDate history attribute.
     *
     * @param aXContractDetailsHistEndDate
     *     The new value of XContractDetailsHistEndDate.
     * @generated
     */
    public void setXContractDetailsHistEndDate(String aXContractDetailsHistEndDate) throws Exception{
        metaDataMap.put("XContractDetailsHistEndDate", aXContractDetailsHistEndDate);

        if ((aXContractDetailsHistEndDate == null) || aXContractDetailsHistEndDate.equals("")) {
            aXContractDetailsHistEndDate = null;
        }
        eObjXContractDetails.setHistEndDt(DWLFunctionUtils.getTimestampFromTimestampString(aXContractDetailsHistEndDate));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XContractDetailsHistoryIdPK history attribute.
     *
     * @generated
     */
    public String getXContractDetailsHistoryIdPK() {
        return DWLFunctionUtils.getStringFromLong(eObjXContractDetails.getHistoryIdPK());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XContractDetailsHistoryIdPK history attribute.
     *
     * @param aXContractDetailsHistoryIdPK
     *     The new value of XContractDetailsHistoryIdPK.
     * @generated
     */
    public void setXContractDetailsHistoryIdPK(String aXContractDetailsHistoryIdPK) {
        metaDataMap.put("XContractDetailsHistoryIdPK", aXContractDetailsHistoryIdPK);

        if ((aXContractDetailsHistoryIdPK == null) || aXContractDetailsHistoryIdPK.equals("")) {
            aXContractDetailsHistoryIdPK = null;
        }
        eObjXContractDetails.setHistoryIdPK(DWLFunctionUtils.getLongFromString(aXContractDetailsHistoryIdPK));
    }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation during an add transaction.
     *
     * @generated
     */
    public DWLStatus validateAdd(int level, DWLStatus status) throws Exception {

        status = super.validateAdd(level, status);
        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0038I Add any controller-level custom validation logic to be
            // executed for this object during an "add" transaction


            for (int i = 0; i < getItemsGuarantorDetailsBObj().size(); i++) {
                GuarantorDetailsBObj guarantorDetails = (GuarantorDetailsBObj) getItemsGuarantorDetailsBObj().elementAt(i);
                status = guarantorDetails.validateAdd(level, status);
            }

            for (int i = 0; i < getItemsCoborrowerDetailsBObj().size(); i++) {
                CoborrowerDetailsBObj coborrowerDetails = (CoborrowerDetailsBObj) getItemsCoborrowerDetailsBObj().elementAt(i);
                status = coborrowerDetails.validateAdd(level, status);
            }
        }

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            // MDM_TODO0: CDKWB0039I Add any component-level custom validation logic to be
            // executed for this object during an "add" transaction
        }
        status = getValidationStatus(level, status);
        return status;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation during an update transaction.
     *
     * @generated
     */
    public DWLStatus validateUpdate(int level, DWLStatus status) throws Exception {
    logger.finest("ENTER validateUpdate(int level, DWLStatus status)");

        status = super.validateUpdate(level, status);
        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0040I Add any controller-level custom validation logic to be
            // executed for this object during an "update" transaction

            if (eObjXContractDetails.getContractpkId() == null) {
                DWLError err = new DWLError();
                err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCONTRACT_DETAILS_BOBJ).longValue());
                err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.XCONTRACTDETAILS_CONTRACTPKID_NULL).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                	String infoForLogging="Error: Validation error occured for update. No primary key for entity XContractDetails, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("validateUpdate(int level, DWLStatus status) " + infoForLogging);
                }
                status.addError(err);
            }
            if (eObjXContractDetails.getLastUpdateDt() == null) {
                DWLError err = new DWLError();
                err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCONTRACT_DETAILS_BOBJ).longValue());
                err.setReasonCode(new Long(DWLUtilErrorReasonCode.LAST_UPDATED_DATE_NULL).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
                if (logger.isFinestEnabled()) {
                	String infoForLogging="Error: Validation error occured for update. No last update date for entity XContractDetails, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("validateUpdate(int level, DWLStatus status) " + infoForLogging);
                }
                status.addError(err);
            }
        }

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            assignBeforeImageValues(metaDataMap);
            
            // MDM_TODO0: CDKWB0041I Add any component-level custom validation logic to be
            // executed for this object during an "update" transaction
        }
        status = getValidationStatus(level, status);
    if (logger.isFinestEnabled()) {
        	String returnValue = status.toString();
      logger.finest("RETURN validateUpdate(int level, DWLStatus status) " + returnValue);
    }
        return status;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Populate the before image of this business object.
     *
     * @see com.dwl.base.DWLCommon#populateBeforeImage()
     * @generated
     */
    public void populateBeforeImage() throws DWLBaseException {
    logger.finest("ENTER populateBeforeImage()");

        DSEAAdditionsExts comp = null;
        try {
        
      comp = (DSEAAdditionsExts)TCRMClassFactory.getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
        	
        } catch (Exception e) {
      if (logger.isFinestEnabled()) {
        String infoForLogging="Error: Fatal error while updating record " + e.getMessage();
      logger.finest("populateBeforeImage() " + infoForLogging);
      }
            DWLExceptionUtils.throwDWLBaseException(e, 
            									new DWLUpdateException(e.getMessage()), 
            									this.getStatus(), DWLStatus.FATAL,
                                  DSEAAdditionsExtsComponentID.XCONTRACT_DETAILS_BOBJ, 
                                  "DIERR",
                                  DSEAAdditionsExtsErrorReasonCode.XCONTRACTDETAILS_BEFORE_IMAGE_NOT_POPULATED, 
                                  this.getControl());
        }
        
        comp.loadBeforeImage(this);
    logger.finest("RETURN populateBeforeImage()");
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation common to both add and update transactions.
     *
     * @generated
     */
     
    private DWLStatus getValidationStatus(int level, DWLStatus status) throws Exception {
    logger.finest("ENTER getValidationStatus(int level, DWLStatus status)");

        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0034I Add any common controller-level custom validation
            // logic to be executed for this object during either "add" or
            // "update" transactions
    		controllerValidation_ContractStatus(status);
    		controllerValidation_Country(status);
    		controllerValidation_SourceIdentifier(status);
    		controllerValidation_StartDate(status);
    		controllerValidation_EndDate(status);
    		controllerValidation_LastModifiedSystemDate(status);
    	}

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            // MDM_TODO0: CDKWB0035I Add any common component-level custom validation logic
            // to be executed for this object during either "add" or "update"
            // transactions
    		componentValidation_ContractStatus(status);
    		componentValidation_Country(status);
    		componentValidation_SourceIdentifier(status);
    		componentValidation_StartDate(status);
    		componentValidation_EndDate(status);
    		componentValidation_LastModifiedSystemDate(status);
        }
        
        if (logger.isFinestEnabled()) {
            String returnValue = status.toString();
      logger.finest("RETURN getValidationStatus(int level, DWLStatus status) " + returnValue);
        }
    
        return status;
    }

    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "ContractStatus"
     *
     * @generated
     */
	private void componentValidation_ContractStatus(DWLStatus status) {
  
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "Country"
     *
     * @generated
     */
	private void componentValidation_Country(DWLStatus status) {
  
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "SourceIdentifier"
     *
     * @generated
     */
	private void componentValidation_SourceIdentifier(DWLStatus status) {
  
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "StartDate"
     *
     * @generated
     */
	private void componentValidation_StartDate(DWLStatus status) {
  
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "EndDate"
     *
     * @generated
     */
	private void componentValidation_EndDate(DWLStatus status) {
  
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "LastModifiedSystemDate"
     *
     * @generated
     */
  private void componentValidation_LastModifiedSystemDate(DWLStatus status) {
  
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "ContractStatus"
     *
     * @generated
     */
	private void controllerValidation_ContractStatus(DWLStatus status) throws Exception {
  
      //persistent code type
            boolean isContractStatusNull = false;
            if ((eObjXContractDetails.getContractStatus() == null) &&
               ((getContractStatusValue() == null) || 
                 getContractStatusValue().trim().equals(""))) {
                isContractStatusNull = true;
            }
            if (!isContractStatusNull) {
                if (checkForInvalidXcontractdetailsContractstatus()) {
                    DWLError err = new DWLError();
                    err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCONTRACT_DETAILS_BOBJ).longValue());
                    err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XCONTRACTDETAILS_CONTRACTSTATUS).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                    String infoForLogging="Error: Custom validation error occured for entity XContractDetails, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("controllerValidation_ContractStatus " + infoForLogging);
        }
                status.addError(err);
            }

             }
    			
    	}
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "Country"
     *
     * @generated
     */
	private void controllerValidation_Country(DWLStatus status) throws Exception {
  
      //persistent code type
            boolean isCountryNull = false;
            if ((eObjXContractDetails.getCountry() == null) &&
               ((getCountryValue() == null) || 
                 getCountryValue().trim().equals(""))) {
                isCountryNull = true;
            }
            if (!isCountryNull) {
                if (checkForInvalidXcontractdetailsCountry()) {
                    DWLError err = new DWLError();
                    err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCONTRACT_DETAILS_BOBJ).longValue());
                    err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XCONTRACTDETAILS_COUNTRY).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                    String infoForLogging="Error: Custom validation error occured for entity XContractDetails, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("controllerValidation_Country " + infoForLogging);
        }
                status.addError(err);
            }

             }
    			
    	}
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "SourceIdentifier"
     *
     * @generated
     */
	private void controllerValidation_SourceIdentifier(DWLStatus status) throws Exception {
  
      //persistent code type
            boolean isSourceIdentifierNull = false;
            if ((eObjXContractDetails.getSourceIdentifier() == null) &&
               ((getSourceIdentifierValue() == null) || 
                 getSourceIdentifierValue().trim().equals(""))) {
                isSourceIdentifierNull = true;
            }
            if (!isSourceIdentifierNull) {
                if (checkForInvalidXcontractdetailsSourceidentifier()) {
                    DWLError err = new DWLError();
                    err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCONTRACT_DETAILS_BOBJ).longValue());
                    err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XCONTRACTDETAILS_SOURCEIDENTIFIER).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                    String infoForLogging="Error: Custom validation error occured for entity XContractDetails, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("controllerValidation_SourceIdentifier " + infoForLogging);
        }
                status.addError(err);
            }

             }
    			
    	}
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "StartDate"
     *
     * @generated
     */
	private void controllerValidation_StartDate(DWLStatus status) throws Exception {
  
            boolean isStartDateNull = (eObjXContractDetails.getStartDate() == null);
            if (!isValidStartDate) {
              	DWLError err = new DWLError();
               	err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCONTRACT_DETAILS_BOBJ).longValue());
               	err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XCONTRACTDETAILS_STARTDATE).longValue());
               	err.setErrorType(DWLErrorCode.DATA_INVALID_ERROR);
                String infoForLogging="Error: Validation error. Invalid time specified on property StartDate in entity XContractDetails, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode();
      logger.finest("controllerValidation_StartDate " + infoForLogging);
               	status.addError(err);
            } 
    	}
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "EndDate"
     *
     * @generated
     */
	private void controllerValidation_EndDate(DWLStatus status) throws Exception {
  
            boolean isEndDateNull = (eObjXContractDetails.getEndDate() == null);
            if (!isValidEndDate) {
              	DWLError err = new DWLError();
               	err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCONTRACT_DETAILS_BOBJ).longValue());
               	err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XCONTRACTDETAILS_ENDDATE).longValue());
               	err.setErrorType(DWLErrorCode.DATA_INVALID_ERROR);
                String infoForLogging="Error: Validation error. Invalid time specified on property EndDate in entity XContractDetails, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode();
      logger.finest("controllerValidation_EndDate " + infoForLogging);
               	status.addError(err);
            } 
    	}
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "LastModifiedSystemDate"
     *
     * @generated
     */
  private void controllerValidation_LastModifiedSystemDate(DWLStatus status) throws Exception {
  
            boolean isLastModifiedSystemDateNull = (eObjXContractDetails.getLastModifiedSystemDate() == null);
            if (!isValidLastModifiedSystemDate) {
              	DWLError err = new DWLError();
               	err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCONTRACT_DETAILS_BOBJ).longValue());
               	err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XCONTRACTDETAILS_LASTMODIFIEDSYSTEMDATE).longValue());
               	err.setErrorType(DWLErrorCode.DATA_INVALID_ERROR);
                String infoForLogging="Error: Validation error. Invalid time specified on property LastModifiedSystemDate in entity XContractDetails, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode();
      logger.finest("controllerValidation_LastModifiedSystemDate " + infoForLogging);
               	status.addError(err);
            } 
    	}


    private DWLError createDWLError(String entityName, String propertyName,String reasonCode){	
		DWLError err = new DWLError();
		err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCONTRACT_DETAILS_BOBJ).longValue());
		err.setReasonCode(new Long(reasonCode).longValue());
		err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
			String infoForLogging="Error: Validation error occured. Property " + propertyName + " is null, in entity " + entityName + ", component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
			logger.finest("createDWLError " + infoForLogging);
		}
		return err;
    }
    
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Check the value of the field ContractStatus and return true if the error
     * reason INVALID_XCONTRACTDETAILS_CONTRACTSTATUS should be returned.
     *
     * @generated
  **/
	private boolean checkForInvalidXcontractdetailsContractstatus() throws Exception {
    logger.finest("ENTER checkForInvalidXcontractdetailsContractstatus()");
        boolean notValid = false;
      	String langId = (String) this.getControl().get(DWLControlKeys.LANG_ID);
      	CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
    Long codeType = DWLFunctionUtils.getLongFromString( getContractStatusType() );
    String codeValue = getContractStatusValue();
    if( codeValue != null && codeValue.trim().equals("")){
      codeValue = null;
    }
     
        if ( codeType != null && codeValue == null ){

             if( codeTypeCompHelper.isCodeValid("cdcontractsttp", langId, getContractStatusType(),
                 CodeTypeComponentHelper.ACTIVE, getControl())) {
                 CodeTypeBObj ctBObj = codeTypeCompHelper
                 					.getCodeTypeByCode("cdcontractsttp", langId, getContractStatusType(),
                         								getControl());
               	if (ctBObj != null) {
                   	setContractStatusValue( ctBObj.getvalue() );
               	}
             }
             else{
             	if (logger.isFinestEnabled()) {
              	 	String infoForLogging="NotValid 1";
      logger.finest("checkForInvalidXcontractdetailsContractstatus() " + infoForLogging);
        }
                 notValid = true;
           }
        }
        else if (codeType == null && codeValue != null ){
          
             CodeTypeBObj ctBObj = codeTypeCompHelper
                      .getCodeTypeByValue("cdcontractsttp", langId, codeValue,
                                 getControl());

             if (ctBObj != null) {
                 setContractStatusType(ctBObj.gettp_cd());
             } 
             else {
             	if (logger.isFinestEnabled()) {
              	  	String infoForLogging="NotValid 2";
      logger.finest("checkForInvalidXcontractdetailsContractstatus() " + infoForLogging);
        }
                  notValid = true;
             }
        }
        else if ( codeType != null && codeValue != null
             && !codeTypeCompHelper.isCodeValuePairValid("cdcontractsttp", langId, getContractStatusType(), 
                     new String[] { codeValue }, CodeTypeComponentHelper.ACTIVE, getControl())) {	
       if (logger.isFinestEnabled()) {
       		String infoForLogging="NotValid 3";
      logger.finest("checkForInvalidXcontractdetailsContractstatus() " + infoForLogging);
       }
             notValid = true;
        }
        if (logger.isFinestEnabled()) {
      String returnValue ="" +notValid;
      logger.finest("RETURN checkForInvalidXcontractdetailsContractstatus() " + returnValue);
    }
    return notValid;
     } 
				 
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Check the value of the field Country and return true if the error reason
     * INVALID_XCONTRACTDETAILS_COUNTRY should be returned.
     *
     * @generated
  **/
	private boolean checkForInvalidXcontractdetailsCountry() throws Exception {
    logger.finest("ENTER checkForInvalidXcontractdetailsCountry()");
        boolean notValid = false;
      	String langId = (String) this.getControl().get(DWLControlKeys.LANG_ID);
      	CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
    Long codeType = DWLFunctionUtils.getLongFromString( getCountryType() );
    String codeValue = getCountryValue();
    if( codeValue != null && codeValue.trim().equals("")){
      codeValue = null;
    }
     
        if ( codeType != null && codeValue == null ){

             if( codeTypeCompHelper.isCodeValid("cdcountrytp", langId, getCountryType(),
                 CodeTypeComponentHelper.ACTIVE, getControl())) {
                 CodeTypeBObj ctBObj = codeTypeCompHelper
                 					.getCodeTypeByCode("cdcountrytp", langId, getCountryType(),
                         								getControl());
               	if (ctBObj != null) {
                   	setCountryValue( ctBObj.getvalue() );
               	}
             }
             else{
             	if (logger.isFinestEnabled()) {
              	 	String infoForLogging="NotValid 1";
      logger.finest("checkForInvalidXcontractdetailsCountry() " + infoForLogging);
        }
                 notValid = true;
           }
        }
        else if (codeType == null && codeValue != null ){
          
             CodeTypeBObj ctBObj = codeTypeCompHelper
                      .getCodeTypeByValue("cdcountrytp", langId, codeValue,
                                 getControl());

             if (ctBObj != null) {
                 setCountryType(ctBObj.gettp_cd());
             } 
             else {
             	if (logger.isFinestEnabled()) {
              	  	String infoForLogging="NotValid 2";
      logger.finest("checkForInvalidXcontractdetailsCountry() " + infoForLogging);
        }
                  notValid = true;
             }
        }
        else if ( codeType != null && codeValue != null
             && !codeTypeCompHelper.isCodeValuePairValid("cdcountrytp", langId, getCountryType(), 
                     new String[] { codeValue }, CodeTypeComponentHelper.ACTIVE, getControl())) {	
       if (logger.isFinestEnabled()) {
       		String infoForLogging="NotValid 3";
      logger.finest("checkForInvalidXcontractdetailsCountry() " + infoForLogging);
       }
             notValid = true;
        }
        if (logger.isFinestEnabled()) {
      String returnValue ="" +notValid;
      logger.finest("RETURN checkForInvalidXcontractdetailsCountry() " + returnValue);
    }
    return notValid;
     } 
				 
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Check the value of the field SourceIdentifier and return true if the
     * error reason INVALID_XCONTRACTDETAILS_SOURCEIDENTIFIER should be
     * returned.
     *
     * @generated
  **/
	private boolean checkForInvalidXcontractdetailsSourceidentifier() throws Exception {
    logger.finest("ENTER checkForInvalidXcontractdetailsSourceidentifier()");
        boolean notValid = false;
      	String langId = (String) this.getControl().get(DWLControlKeys.LANG_ID);
      	CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
    Long codeType = DWLFunctionUtils.getLongFromString( getSourceIdentifierType() );
    String codeValue = getSourceIdentifierValue();
    if( codeValue != null && codeValue.trim().equals("")){
      codeValue = null;
    }
     
        if ( codeType != null && codeValue == null ){

             if( codeTypeCompHelper.isCodeValid("cdsourceidenttp", langId, getSourceIdentifierType(),
                 CodeTypeComponentHelper.ACTIVE, getControl())) {
                 CodeTypeBObj ctBObj = codeTypeCompHelper
                 					.getCodeTypeByCode("cdsourceidenttp", langId, getSourceIdentifierType(),
                         								getControl());
               	if (ctBObj != null) {
                   	setSourceIdentifierValue( ctBObj.getvalue() );
               	}
             }
             else{
             	if (logger.isFinestEnabled()) {
              	 	String infoForLogging="NotValid 1";
      logger.finest("checkForInvalidXcontractdetailsSourceidentifier() " + infoForLogging);
        }
                 notValid = true;
           }
        }
        else if (codeType == null && codeValue != null ){
          
             CodeTypeBObj ctBObj = codeTypeCompHelper
                      .getCodeTypeByValue("cdsourceidenttp", langId, codeValue,
                                 getControl());

             if (ctBObj != null) {
                 setSourceIdentifierType(ctBObj.gettp_cd());
             } 
             else {
             	if (logger.isFinestEnabled()) {
              	  	String infoForLogging="NotValid 2";
      logger.finest("checkForInvalidXcontractdetailsSourceidentifier() " + infoForLogging);
        }
                  notValid = true;
             }
        }
        else if ( codeType != null && codeValue != null
             && !codeTypeCompHelper.isCodeValuePairValid("cdsourceidenttp", langId, getSourceIdentifierType(), 
                     new String[] { codeValue }, CodeTypeComponentHelper.ACTIVE, getControl())) {	
       if (logger.isFinestEnabled()) {
       		String infoForLogging="NotValid 3";
      logger.finest("checkForInvalidXcontractdetailsSourceidentifier() " + infoForLogging);
       }
             notValid = true;
        }
        if (logger.isFinestEnabled()) {
      String returnValue ="" +notValid;
      logger.finest("RETURN checkForInvalidXcontractdetailsSourceidentifier() " + returnValue);
    }
    return notValid;
     } 
				 



}

