
/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[6026263a4ac2115667f976d0eb1f6b34]
 */

package com.ibm.daimler.dsea.component;

import com.dwl.tcrm.common.TCRMCommon;



import com.dwl.base.DWLControl;

import com.dwl.base.constant.DWLUtilErrorReasonCode;

import com.dwl.base.error.DWLError;
import com.dwl.base.error.DWLErrorCode;
import com.dwl.base.error.DWLStatus;

import com.dwl.base.exception.DWLBaseException;
import com.dwl.base.exception.DWLUpdateException;

import com.dwl.base.util.DWLExceptionUtils;
import com.dwl.base.util.DWLFunctionUtils;

import com.dwl.tcrm.common.ITCRMValidation;

import com.dwl.tcrm.utilities.TCRMClassFactory;

import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsComponentID;
import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsErrorReasonCode;
import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsPropertyKeys;

import com.ibm.daimler.dsea.entityObject.EObjXEpucidTemp;

import com.ibm.daimler.dsea.interfaces.DSEAAdditionsExts;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * This class provides the implementation of the business object
 * <code>XEpucidTempBObj</code>.
 * 
 * @see com.dwl.tcrm.common.TCRMCommon
 * @generated
 */
 

@SuppressWarnings("serial")
public class XEpucidTempBObj extends TCRMCommon  {

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected EObjXEpucidTemp eObjXEpucidTemp;
	/**
    * <!-- begin-user-doc -->
	  * <!-- end-user-doc -->
    * @generated 
    */
	 private final static com.dwl.base.logging.IDWLLogger logger = com.dwl.base.logging.DWLLoggerManager.getLogger(XEpucidTempBObj.class);
		
 


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */     
    public XEpucidTempBObj() {
        super();
        init();
        eObjXEpucidTemp = new EObjXEpucidTemp();
        setComponentID(DSEAAdditionsExtsComponentID.XEPUCID_TEMP_BOBJ);
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Initializes the fields required to populate the metaDataMap. Each key is
     * an element-level field of the business object.
     *
     * @generated
     */
    private void init() {
        metaDataMap.put("XEpucidTemppkId", null);
        metaDataMap.put("EPUCID", null);
        metaDataMap.put("UCID", null);
        metaDataMap.put("XEpucidTempHistActionCode", null);
        metaDataMap.put("XEpucidTempHistCreateDate", null);
        metaDataMap.put("XEpucidTempHistCreatedBy", null);
        metaDataMap.put("XEpucidTempHistEndDate", null);
        metaDataMap.put("XEpucidTempHistoryIdPK", null);
        metaDataMap.put("XEpucidTempLastUpdateDate", null);
        metaDataMap.put("XEpucidTempLastUpdateTxId", null);
        metaDataMap.put("XEpucidTempLastUpdateUser", null);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Refreshes all the attributes this business object supports.
     *
     * @see com.dwl.base.DWLCommon#refreshMap()
     * @generated
     */
    public void refreshMap() {

        if (bRequireMapRefresh) {
            super.refreshMap();
            metaDataMap.put("XEpucidTemppkId", getXEpucidTemppkId());
            metaDataMap.put("EPUCID", getEPUCID());
            metaDataMap.put("UCID", getUCID());
            metaDataMap.put("XEpucidTempHistActionCode", getXEpucidTempHistActionCode());
            metaDataMap.put("XEpucidTempHistCreateDate", getXEpucidTempHistCreateDate());
            metaDataMap.put("XEpucidTempHistCreatedBy", getXEpucidTempHistCreatedBy());
            metaDataMap.put("XEpucidTempHistEndDate", getXEpucidTempHistEndDate());
            metaDataMap.put("XEpucidTempHistoryIdPK", getXEpucidTempHistoryIdPK());
            metaDataMap.put("XEpucidTempLastUpdateDate", getXEpucidTempLastUpdateDate());
            metaDataMap.put("XEpucidTempLastUpdateTxId", getXEpucidTempLastUpdateTxId());
            metaDataMap.put("XEpucidTempLastUpdateUser", getXEpucidTempLastUpdateUser());
            bRequireMapRefresh = false;
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the control object on this business object.
     *
     * @see com.dwl.base.DWLCommon#setControl(DWLControl)
     * @generated
     */
    public void setControl(DWLControl newDWLControl) {
        super.setControl(newDWLControl);

        if (eObjXEpucidTemp != null) {
            eObjXEpucidTemp.setControl(newDWLControl);
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the entity object associated with this business object.
     *
     * @generated
     */
    public EObjXEpucidTemp getEObjXEpucidTemp() {
        bRequireMapRefresh = true;
        return eObjXEpucidTemp;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the entity object associated with this business object.
     *
     * @param eObjXEpucidTemp
     *            The eObjXEpucidTemp to set.
     * @generated
     */
    public void setEObjXEpucidTemp(EObjXEpucidTemp eObjXEpucidTemp) {
        bRequireMapRefresh = true;
        this.eObjXEpucidTemp = eObjXEpucidTemp;
        if (this.eObjXEpucidTemp != null && this.eObjXEpucidTemp.getControl() == null) {
            DWLControl control = this.getControl();
            if (control != null) {
                this.eObjXEpucidTemp.setControl(control);
            }
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xEpucidTemppkId attribute.
     * 
     * @generated
     */
    public String getXEpucidTemppkId (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXEpucidTemp.getXEpucidTemppkId());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xEpucidTemppkId attribute.
     * 
     * @param newXEpucidTemppkId
     *     The new value of xEpucidTemppkId.
     * @generated
     */
    public void setXEpucidTemppkId( String newXEpucidTemppkId ) throws Exception {
        metaDataMap.put("XEpucidTemppkId", newXEpucidTemppkId);

        if (newXEpucidTemppkId == null || newXEpucidTemppkId.equals("")) {
            newXEpucidTemppkId = null;


        }
        eObjXEpucidTemp.setXEpucidTemppkId( DWLFunctionUtils.getLongFromString(newXEpucidTemppkId) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the ePUCID attribute.
     * 
     * @generated
     */
    public String getEPUCID (){
   
        return eObjXEpucidTemp.getEPUCID();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the ePUCID attribute.
     * 
     * @param newEPUCID
     *     The new value of ePUCID.
     * @generated
     */
    public void setEPUCID( String newEPUCID ) throws Exception {
        metaDataMap.put("EPUCID", newEPUCID);

        if (newEPUCID == null || newEPUCID.equals("")) {
            newEPUCID = null;


        }
        eObjXEpucidTemp.setEPUCID( newEPUCID );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the uCID attribute.
     * 
     * @generated
     */
    public String getUCID (){
   
        return eObjXEpucidTemp.getUCID();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the uCID attribute.
     * 
     * @param newUCID
     *     The new value of uCID.
     * @generated
     */
    public void setUCID( String newUCID ) throws Exception {
        metaDataMap.put("UCID", newUCID);

        if (newUCID == null || newUCID.equals("")) {
            newUCID = null;


        }
        eObjXEpucidTemp.setUCID( newUCID );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateTxId attribute.
     *
     * @generated
     */
    public String getXEpucidTempLastUpdateTxId() {
        return DWLFunctionUtils.getStringFromLong(eObjXEpucidTemp.getLastUpdateTxId());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateUser attribute.
     *
     * @generated
     */
    public String getXEpucidTempLastUpdateUser() {
        return eObjXEpucidTemp.getLastUpdateUser();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateDt attribute.
     *
     * @generated
     */
    public String getXEpucidTempLastUpdateDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXEpucidTemp.getLastUpdateDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateTxId attribute.
     *
     * @param newLastUpdateTxId
     *     The new value of LastUpdateTxId.
     * @generated
     */
    public void setXEpucidTempLastUpdateTxId(String newLastUpdateTxId) {
        metaDataMap.put("XEpucidTempLastUpdateTxId", newLastUpdateTxId);

        if ((newLastUpdateTxId == null) || newLastUpdateTxId.equals("")) {
            newLastUpdateTxId = null;
        }
        eObjXEpucidTemp.setLastUpdateTxId(DWLFunctionUtils.getLongFromString(newLastUpdateTxId));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateUser attribute.
     *
     * @param newLastUpdateUser
     *     The new value of LastUpdateUser.
     * @generated
     */
    public void setXEpucidTempLastUpdateUser(String newLastUpdateUser) {
        metaDataMap.put("XEpucidTempLastUpdateUser", newLastUpdateUser);

        if ((newLastUpdateUser == null) || newLastUpdateUser.equals("")) {
            newLastUpdateUser = null;
        }
        eObjXEpucidTemp.setLastUpdateUser(newLastUpdateUser);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateDt attribute.
     *
     * @param newLastUpdateDt
     *     The new value of LastUpdateDt.
     * @throws Exception
     * @generated
     */
    public void setXEpucidTempLastUpdateDate(String newLastUpdateDt) throws Exception {
        metaDataMap.put("XEpucidTempLastUpdateDate", newLastUpdateDt);

        if ((newLastUpdateDt == null) || newLastUpdateDt.equals("")) {
            newLastUpdateDt = null;
        }

        eObjXEpucidTemp.setLastUpdateDt(DWLFunctionUtils.getTimestampFromTimestampString(newLastUpdateDt));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XEpucidTempHistActionCode history attribute.
     *
     * @generated
     */
    public String getXEpucidTempHistActionCode() {
        return eObjXEpucidTemp.getHistActionCode();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XEpucidTempHistActionCode history attribute.
     *
     * @param aXEpucidTempHistActionCode
     *     The new value of XEpucidTempHistActionCode.
     * @generated
     */
    public void setXEpucidTempHistActionCode(String aXEpucidTempHistActionCode) {
        metaDataMap.put("XEpucidTempHistActionCode", aXEpucidTempHistActionCode);

        if ((aXEpucidTempHistActionCode == null) || aXEpucidTempHistActionCode.equals("")) {
            aXEpucidTempHistActionCode = null;
        }
        eObjXEpucidTemp.setHistActionCode(aXEpucidTempHistActionCode);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XEpucidTempHistCreateDate history attribute.
     *
     * @generated
     */
    public String getXEpucidTempHistCreateDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXEpucidTemp.getHistCreateDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XEpucidTempHistCreateDate history attribute.
     *
     * @param aXEpucidTempHistCreateDate
     *     The new value of XEpucidTempHistCreateDate.
     * @generated
     */
    public void setXEpucidTempHistCreateDate(String aXEpucidTempHistCreateDate) throws Exception{
        metaDataMap.put("XEpucidTempHistCreateDate", aXEpucidTempHistCreateDate);

        if ((aXEpucidTempHistCreateDate == null) || aXEpucidTempHistCreateDate.equals("")) {
            aXEpucidTempHistCreateDate = null;
        }

        eObjXEpucidTemp.setHistCreateDt(DWLFunctionUtils.getTimestampFromTimestampString(aXEpucidTempHistCreateDate));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XEpucidTempHistCreatedBy history attribute.
     *
     * @generated
     */
    public String getXEpucidTempHistCreatedBy() {
        return eObjXEpucidTemp.getHistCreatedBy();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XEpucidTempHistCreatedBy history attribute.
     *
     * @param aXEpucidTempHistCreatedBy
     *     The new value of XEpucidTempHistCreatedBy.
     * @generated
     */
    public void setXEpucidTempHistCreatedBy(String aXEpucidTempHistCreatedBy) {
        metaDataMap.put("XEpucidTempHistCreatedBy", aXEpucidTempHistCreatedBy);

        if ((aXEpucidTempHistCreatedBy == null) || aXEpucidTempHistCreatedBy.equals("")) {
            aXEpucidTempHistCreatedBy = null;
        }

        eObjXEpucidTemp.setHistCreatedBy(aXEpucidTempHistCreatedBy);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XEpucidTempHistEndDate history attribute.
     *
     * @generated
     */
    public String getXEpucidTempHistEndDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXEpucidTemp.getHistEndDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XEpucidTempHistEndDate history attribute.
     *
     * @param aXEpucidTempHistEndDate
     *     The new value of XEpucidTempHistEndDate.
     * @generated
     */
    public void setXEpucidTempHistEndDate(String aXEpucidTempHistEndDate) throws Exception{
        metaDataMap.put("XEpucidTempHistEndDate", aXEpucidTempHistEndDate);

        if ((aXEpucidTempHistEndDate == null) || aXEpucidTempHistEndDate.equals("")) {
            aXEpucidTempHistEndDate = null;
        }
        eObjXEpucidTemp.setHistEndDt(DWLFunctionUtils.getTimestampFromTimestampString(aXEpucidTempHistEndDate));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XEpucidTempHistoryIdPK history attribute.
     *
     * @generated
     */
    public String getXEpucidTempHistoryIdPK() {
        return DWLFunctionUtils.getStringFromLong(eObjXEpucidTemp.getHistoryIdPK());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XEpucidTempHistoryIdPK history attribute.
     *
     * @param aXEpucidTempHistoryIdPK
     *     The new value of XEpucidTempHistoryIdPK.
     * @generated
     */
    public void setXEpucidTempHistoryIdPK(String aXEpucidTempHistoryIdPK) {
        metaDataMap.put("XEpucidTempHistoryIdPK", aXEpucidTempHistoryIdPK);

        if ((aXEpucidTempHistoryIdPK == null) || aXEpucidTempHistoryIdPK.equals("")) {
            aXEpucidTempHistoryIdPK = null;
        }
        eObjXEpucidTemp.setHistoryIdPK(DWLFunctionUtils.getLongFromString(aXEpucidTempHistoryIdPK));
    }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation during an add transaction.
     *
     * @generated
     */
    public DWLStatus validateAdd(int level, DWLStatus status) throws Exception {

        status = super.validateAdd(level, status);
        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0038I Add any controller-level custom validation logic to be
            // executed for this object during an "add" transaction

        }

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            // MDM_TODO0: CDKWB0039I Add any component-level custom validation logic to be
            // executed for this object during an "add" transaction
        }
        status = getValidationStatus(level, status);
        return status;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation during an update transaction.
     *
     * @generated
     */
    public DWLStatus validateUpdate(int level, DWLStatus status) throws Exception {
    logger.finest("ENTER validateUpdate(int level, DWLStatus status)");

        status = super.validateUpdate(level, status);
        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0040I Add any controller-level custom validation logic to be
            // executed for this object during an "update" transaction

            if (eObjXEpucidTemp.getXEpucidTemppkId() == null) {
                DWLError err = new DWLError();
                err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XEPUCID_TEMP_BOBJ).longValue());
                err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.XEPUCIDTEMP_XEPUCIDTEMPPKID_NULL).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                	String infoForLogging="Error: Validation error occured for update. No primary key for entity XEpucidTemp, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("validateUpdate(int level, DWLStatus status) " + infoForLogging);
                }
                status.addError(err);
            }
            if (eObjXEpucidTemp.getLastUpdateDt() == null) {
                DWLError err = new DWLError();
                err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XEPUCID_TEMP_BOBJ).longValue());
                err.setReasonCode(new Long(DWLUtilErrorReasonCode.LAST_UPDATED_DATE_NULL).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
                if (logger.isFinestEnabled()) {
                	String infoForLogging="Error: Validation error occured for update. No last update date for entity XEpucidTemp, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("validateUpdate(int level, DWLStatus status) " + infoForLogging);
                }
                status.addError(err);
            }
        }

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            assignBeforeImageValues(metaDataMap);
            
            // MDM_TODO0: CDKWB0041I Add any component-level custom validation logic to be
            // executed for this object during an "update" transaction
        }
        status = getValidationStatus(level, status);
    if (logger.isFinestEnabled()) {
        	String returnValue = status.toString();
      logger.finest("RETURN validateUpdate(int level, DWLStatus status) " + returnValue);
    }
        return status;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Populate the before image of this business object.
     *
     * @see com.dwl.base.DWLCommon#populateBeforeImage()
     * @generated
     */
    public void populateBeforeImage() throws DWLBaseException {
    logger.finest("ENTER populateBeforeImage()");

        DSEAAdditionsExts comp = null;
        try {
        
      comp = (DSEAAdditionsExts)TCRMClassFactory.getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
        	
        } catch (Exception e) {
      if (logger.isFinestEnabled()) {
        String infoForLogging="Error: Fatal error while updating record " + e.getMessage();
      logger.finest("populateBeforeImage() " + infoForLogging);
      }
            DWLExceptionUtils.throwDWLBaseException(e, 
            									new DWLUpdateException(e.getMessage()), 
            									this.getStatus(), DWLStatus.FATAL,
                                  DSEAAdditionsExtsComponentID.XEPUCID_TEMP_BOBJ, 
                                  "DIERR",
                                  DSEAAdditionsExtsErrorReasonCode.XEPUCIDTEMP_BEFORE_IMAGE_NOT_POPULATED, 
                                  this.getControl());
        }
        
        comp.loadBeforeImage(this);
    logger.finest("RETURN populateBeforeImage()");
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation common to both add and update transactions.
     *
     * @generated
     */
     
    private DWLStatus getValidationStatus(int level, DWLStatus status) throws Exception {
    logger.finest("ENTER getValidationStatus(int level, DWLStatus status)");

        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0034I Add any common controller-level custom validation
            // logic to be executed for this object during either "add" or
            // "update" transactions
    	}

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            // MDM_TODO0: CDKWB0035I Add any common component-level custom validation logic
            // to be executed for this object during either "add" or "update"
            // transactions
        }
        
        if (logger.isFinestEnabled()) {
            String returnValue = status.toString();
      logger.finest("RETURN getValidationStatus(int level, DWLStatus status) " + returnValue);
        }
    
        return status;
    }

    private DWLError createDWLError(String entityName, String propertyName,String reasonCode){	
		DWLError err = new DWLError();
		err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XEPUCID_TEMP_BOBJ).longValue());
		err.setReasonCode(new Long(reasonCode).longValue());
		err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
			String infoForLogging="Error: Validation error occured. Property " + propertyName + " is null, in entity " + entityName + ", component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
			logger.finest("createDWLError " + infoForLogging);
		}
		return err;
    }
    



}

