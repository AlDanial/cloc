
/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[66818a68ff86dd07da0fb98e7be006b5]
 */

package com.ibm.daimler.dsea.component;

import com.dwl.tcrm.common.TCRMCommon;



import com.dwl.base.DWLControl;

import com.dwl.base.constant.DWLControlKeys;
import com.dwl.base.constant.DWLUtilErrorReasonCode;

import com.dwl.base.error.DWLError;
import com.dwl.base.error.DWLErrorCode;
import com.dwl.base.error.DWLStatus;

import com.dwl.base.exception.DWLBaseException;
import com.dwl.base.exception.DWLUpdateException;

import com.dwl.base.util.DWLClassFactory;
import com.dwl.base.util.DWLExceptionUtils;
import com.dwl.base.util.DWLFunctionUtils;

import com.dwl.management.config.client.Configuration;

import com.dwl.tcrm.common.ITCRMValidation;

import com.dwl.tcrm.utilities.DateFormatter;
import com.dwl.tcrm.utilities.DateValidator;
import com.dwl.tcrm.utilities.TCRMClassFactory;

import com.ibm.daimler.dsea.component.XCustomerVehicleRoleBObj;
import com.ibm.daimler.dsea.component.XVehicleBObj;

import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsComponentID;
import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsErrorReasonCode;
import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsPropertyKeys;

import com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicle;

import com.ibm.daimler.dsea.interfaces.DSEAAdditionsExts;

import com.ibm.mdm.common.codetype.interfaces.CodeTypeComponentHelper;

import com.ibm.mdm.common.codetype.obj.CodeTypeBObj;

import java.util.Vector;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * This class provides the implementation of the business object
 * <code>XCustomerVehicleBObj</code>.
 * 
 * @see com.dwl.tcrm.common.TCRMCommon
 * @generated
 */
 

@SuppressWarnings("serial")
public class XCustomerVehicleBObj extends TCRMCommon  {

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected EObjXCustomerVehicle eObjXCustomerVehicle;
	/**
    * <!-- begin-user-doc -->
	  * <!-- end-user-doc -->
    * @generated 
    */
	 private final static com.dwl.base.logging.IDWLLogger logger = com.dwl.base.logging.DWLLoggerManager.getLogger(XCustomerVehicleBObj.class);
		
 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected String connectMeUsageValue;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected String sourceIdentifierValue;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected String vehicleSalesValue;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected String vehicleUsageValue;
    protected boolean isValidStartDate = true;
	
	protected boolean isValidEndDate = true;
	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected XVehicleBObj XVehicleBObj;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    @SuppressWarnings("rawtypes")
    protected Vector vecXCustomerVehicleRoleBObj;


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */     
    @SuppressWarnings("rawtypes")
    public XCustomerVehicleBObj() {
        super();
        init();
        eObjXCustomerVehicle = new EObjXCustomerVehicle();
        vecXCustomerVehicleRoleBObj = new Vector();
        setComponentID(DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_BOBJ);
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Initializes the fields required to populate the metaDataMap. Each key is
     * an element-level field of the business object.
     *
     * @generated
     */
    private void init() {
        metaDataMap.put("CustomerVehiclepkId", null);
        metaDataMap.put("ContId", null);
        metaDataMap.put("VehicleId", null);
        metaDataMap.put("RetailerId", null);
        metaDataMap.put("ConnectMeUsageType", null);
        metaDataMap.put("ConnectMeUsageValue", null);
        metaDataMap.put("LicensePlate", null);
        metaDataMap.put("VehicleSalesType", null);
        metaDataMap.put("VehicleSalesValue", null);
        metaDataMap.put("VehicleUsageType", null);
        metaDataMap.put("VehicleUsageValue", null);
        metaDataMap.put("VehicleOwnerShip", null);
        metaDataMap.put("StartDate", null);
        metaDataMap.put("EndDate", null);
        metaDataMap.put("SourceIdentifierType", null);
        metaDataMap.put("SourceIdentifierValue", null);
        metaDataMap.put("X_BPID", null);
        metaDataMap.put("XCustomerVehicleHistActionCode", null);
        metaDataMap.put("XCustomerVehicleHistCreateDate", null);
        metaDataMap.put("XCustomerVehicleHistCreatedBy", null);
        metaDataMap.put("XCustomerVehicleHistEndDate", null);
        metaDataMap.put("XCustomerVehicleHistoryIdPK", null);
        metaDataMap.put("XCustomerVehicleLastUpdateDate", null);
        metaDataMap.put("XCustomerVehicleLastUpdateTxId", null);
        metaDataMap.put("XCustomerVehicleLastUpdateUser", null);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Refreshes all the attributes this business object supports.
     *
     * @see com.dwl.base.DWLCommon#refreshMap()
     * @generated
     */
    public void refreshMap() {

        if (bRequireMapRefresh) {
            super.refreshMap();
            metaDataMap.put("CustomerVehiclepkId", getCustomerVehiclepkId());
            metaDataMap.put("ContId", getContId());
            metaDataMap.put("VehicleId", getVehicleId());
            metaDataMap.put("RetailerId", getRetailerId());
            metaDataMap.put("ConnectMeUsageType", getConnectMeUsageType());
            metaDataMap.put("ConnectMeUsageValue", getConnectMeUsageValue());
            metaDataMap.put("LicensePlate", getLicensePlate());
            metaDataMap.put("VehicleSalesType", getVehicleSalesType());
            metaDataMap.put("VehicleSalesValue", getVehicleSalesValue());
            metaDataMap.put("VehicleUsageType", getVehicleUsageType());
            metaDataMap.put("VehicleUsageValue", getVehicleUsageValue());
            metaDataMap.put("VehicleOwnerShip", getVehicleOwnerShip());
            metaDataMap.put("StartDate", getStartDate());
            metaDataMap.put("EndDate", getEndDate());
            metaDataMap.put("SourceIdentifierType", getSourceIdentifierType());
            metaDataMap.put("SourceIdentifierValue", getSourceIdentifierValue());
            metaDataMap.put("X_BPID", getX_BPID());
            metaDataMap.put("XCustomerVehicleHistActionCode", getXCustomerVehicleHistActionCode());
            metaDataMap.put("XCustomerVehicleHistCreateDate", getXCustomerVehicleHistCreateDate());
            metaDataMap.put("XCustomerVehicleHistCreatedBy", getXCustomerVehicleHistCreatedBy());
            metaDataMap.put("XCustomerVehicleHistEndDate", getXCustomerVehicleHistEndDate());
            metaDataMap.put("XCustomerVehicleHistoryIdPK", getXCustomerVehicleHistoryIdPK());
            metaDataMap.put("XCustomerVehicleLastUpdateDate", getXCustomerVehicleLastUpdateDate());
            metaDataMap.put("XCustomerVehicleLastUpdateTxId", getXCustomerVehicleLastUpdateTxId());
            metaDataMap.put("XCustomerVehicleLastUpdateUser", getXCustomerVehicleLastUpdateUser());
            bRequireMapRefresh = false;
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the control object on this business object.
     *
     * @see com.dwl.base.DWLCommon#setControl(DWLControl)
     * @generated
     */
    public void setControl(DWLControl newDWLControl) {
        super.setControl(newDWLControl);

        if (eObjXCustomerVehicle != null) {
            eObjXCustomerVehicle.setControl(newDWLControl);
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the entity object associated with this business object.
     *
     * @generated
     */
    public EObjXCustomerVehicle getEObjXCustomerVehicle() {
        bRequireMapRefresh = true;
        return eObjXCustomerVehicle;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the entity object associated with this business object.
     *
     * @param eObjXCustomerVehicle
     *            The eObjXCustomerVehicle to set.
     * @generated
     */
    public void setEObjXCustomerVehicle(EObjXCustomerVehicle eObjXCustomerVehicle) {
        bRequireMapRefresh = true;
        this.eObjXCustomerVehicle = eObjXCustomerVehicle;
        if (this.eObjXCustomerVehicle != null && this.eObjXCustomerVehicle.getControl() == null) {
            DWLControl control = this.getControl();
            if (control != null) {
                this.eObjXCustomerVehicle.setControl(control);
            }
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the customerVehiclepkId attribute.
     * 
     * @generated
     */
    public String getCustomerVehiclepkId (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXCustomerVehicle.getCustomerVehiclepkId());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the customerVehiclepkId attribute.
     * 
     * @param newCustomerVehiclepkId
     *     The new value of customerVehiclepkId.
     * @generated
     */
    public void setCustomerVehiclepkId( String newCustomerVehiclepkId ) throws Exception {
        metaDataMap.put("CustomerVehiclepkId", newCustomerVehiclepkId);

        if (newCustomerVehiclepkId == null || newCustomerVehiclepkId.equals("")) {
            newCustomerVehiclepkId = null;


        }
        eObjXCustomerVehicle.setCustomerVehiclepkId( DWLFunctionUtils.getLongFromString(newCustomerVehiclepkId) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the contId attribute.
     * 
     * @generated
     */
    public String getContId (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXCustomerVehicle.getContId());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the contId attribute.
     * 
     * @param newContId
     *     The new value of contId.
     * @generated
     */
    public void setContId( String newContId ) throws Exception {
        metaDataMap.put("ContId", newContId);

        if (newContId == null || newContId.equals("")) {
            newContId = null;


        }
        eObjXCustomerVehicle.setContId( DWLFunctionUtils.getLongFromString(newContId) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the vehicleId attribute.
     * 
     * @generated
     */
    public String getVehicleId (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXCustomerVehicle.getVehicleId());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the vehicleId attribute.
     * 
     * @param newVehicleId
     *     The new value of vehicleId.
     * @generated
     */
    public void setVehicleId( String newVehicleId ) throws Exception {
        metaDataMap.put("VehicleId", newVehicleId);

        if (newVehicleId == null || newVehicleId.equals("")) {
            newVehicleId = null;


        }
        eObjXCustomerVehicle.setVehicleId( DWLFunctionUtils.getLongFromString(newVehicleId) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the retailerId attribute.
     * 
     * @generated
     */
    public String getRetailerId (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXCustomerVehicle.getRetailerId());
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the retailerId attribute.
     * 
     * @param newRetailerId
     *     The new value of retailerId.
     * @generated
     */
    public void setRetailerId( String newRetailerId ) throws Exception {
        metaDataMap.put("RetailerId", newRetailerId);

        if (newRetailerId == null || newRetailerId.equals("")) {
            newRetailerId = null;


        }
        eObjXCustomerVehicle.setRetailerId( DWLFunctionUtils.getLongFromString(newRetailerId) );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the connectMeUsageType attribute.
     * 
     * @generated
     */
    public String getConnectMeUsageType (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXCustomerVehicle.getConnectMeUsage());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the connectMeUsageType attribute.
     * 
     * @param newConnectMeUsageType
     *     The new value of connectMeUsageType.
     * @generated
     */
    public void setConnectMeUsageType( String newConnectMeUsageType ) throws Exception {
        metaDataMap.put("ConnectMeUsageType", newConnectMeUsageType);

        if (newConnectMeUsageType == null || newConnectMeUsageType.equals("")) {
            newConnectMeUsageType = null;


        }
        eObjXCustomerVehicle.setConnectMeUsage( DWLFunctionUtils.getLongFromString(newConnectMeUsageType) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the connectMeUsageValue attribute.
     * 
     * @generated
     */
    public String getConnectMeUsageValue (){
      return connectMeUsageValue;
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the connectMeUsageValue attribute.
     * 
     * @param newConnectMeUsageValue
     *     The new value of connectMeUsageValue.
     * @generated
     */
    public void setConnectMeUsageValue( String newConnectMeUsageValue ) throws Exception {
        metaDataMap.put("ConnectMeUsageValue", newConnectMeUsageValue);

        if (newConnectMeUsageValue == null || newConnectMeUsageValue.equals("")) {
            newConnectMeUsageValue = null;


        }
        connectMeUsageValue = newConnectMeUsageValue;
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the licensePlate attribute.
     * 
     * @generated
     */
    public String getLicensePlate (){
   
        return eObjXCustomerVehicle.getLicensePlate();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the licensePlate attribute.
     * 
     * @param newLicensePlate
     *     The new value of licensePlate.
     * @generated
     */
    public void setLicensePlate( String newLicensePlate ) throws Exception {
        metaDataMap.put("LicensePlate", newLicensePlate);

        if (newLicensePlate == null || newLicensePlate.equals("")) {
            newLicensePlate = null;


        }
        eObjXCustomerVehicle.setLicensePlate( newLicensePlate );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the sourceIdentifierType attribute.
     * 
     * @generated
     */
    public String getSourceIdentifierType (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXCustomerVehicle.getSourceIdentifier());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the sourceIdentifierType attribute.
     * 
     * @param newSourceIdentifierType
     *     The new value of sourceIdentifierType.
     * @generated
     */
    public void setSourceIdentifierType( String newSourceIdentifierType ) throws Exception {
        metaDataMap.put("SourceIdentifierType", newSourceIdentifierType);

        if (newSourceIdentifierType == null || newSourceIdentifierType.equals("")) {
            newSourceIdentifierType = null;


        }
        eObjXCustomerVehicle.setSourceIdentifier( DWLFunctionUtils.getLongFromString(newSourceIdentifierType) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the sourceIdentifierValue attribute.
     * 
     * @generated
     */
    public String getSourceIdentifierValue (){
      return sourceIdentifierValue;
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the sourceIdentifierValue attribute.
     * 
     * @param newSourceIdentifierValue
     *     The new value of sourceIdentifierValue.
     * @generated
     */
    public void setSourceIdentifierValue( String newSourceIdentifierValue ) throws Exception {
        metaDataMap.put("SourceIdentifierValue", newSourceIdentifierValue);

        if (newSourceIdentifierValue == null || newSourceIdentifierValue.equals("")) {
            newSourceIdentifierValue = null;


        }
        sourceIdentifierValue = newSourceIdentifierValue;
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the x_BPID attribute.
     * 
     * @generated
     */
    public String getX_BPID (){
   
        return eObjXCustomerVehicle.getX_BPID();
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the x_BPID attribute.
     * 
     * @param newX_BPID
     *     The new value of x_BPID.
     * @generated
     */
    public void setX_BPID( String newX_BPID ) throws Exception {
        metaDataMap.put("X_BPID", newX_BPID);

        if (newX_BPID == null || newX_BPID.equals("")) {
            newX_BPID = null;


        }
        eObjXCustomerVehicle.setX_BPID( newX_BPID );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the vehicleSalesType attribute.
     * 
     * @generated
     */
    public String getVehicleSalesType (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXCustomerVehicle.getVehicleSales());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the vehicleSalesType attribute.
     * 
     * @param newVehicleSalesType
     *     The new value of vehicleSalesType.
     * @generated
     */
    public void setVehicleSalesType( String newVehicleSalesType ) throws Exception {
        metaDataMap.put("VehicleSalesType", newVehicleSalesType);

        if (newVehicleSalesType == null || newVehicleSalesType.equals("")) {
            newVehicleSalesType = null;


        }
        eObjXCustomerVehicle.setVehicleSales( DWLFunctionUtils.getLongFromString(newVehicleSalesType) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the vehicleSalesValue attribute.
     * 
     * @generated
     */
    public String getVehicleSalesValue (){
      return vehicleSalesValue;
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the vehicleSalesValue attribute.
     * 
     * @param newVehicleSalesValue
     *     The new value of vehicleSalesValue.
     * @generated
     */
    public void setVehicleSalesValue( String newVehicleSalesValue ) throws Exception {
        metaDataMap.put("VehicleSalesValue", newVehicleSalesValue);

        if (newVehicleSalesValue == null || newVehicleSalesValue.equals("")) {
            newVehicleSalesValue = null;


        }
        vehicleSalesValue = newVehicleSalesValue;
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the vehicleUsageType attribute.
     * 
     * @generated
     */
    public String getVehicleUsageType (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXCustomerVehicle.getVehicleUsage());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the vehicleUsageType attribute.
     * 
     * @param newVehicleUsageType
     *     The new value of vehicleUsageType.
     * @generated
     */
    public void setVehicleUsageType( String newVehicleUsageType ) throws Exception {
        metaDataMap.put("VehicleUsageType", newVehicleUsageType);

        if (newVehicleUsageType == null || newVehicleUsageType.equals("")) {
            newVehicleUsageType = null;


        }
        eObjXCustomerVehicle.setVehicleUsage( DWLFunctionUtils.getLongFromString(newVehicleUsageType) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the vehicleUsageValue attribute.
     * 
     * @generated
     */
    public String getVehicleUsageValue (){
      return vehicleUsageValue;
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the vehicleUsageValue attribute.
     * 
     * @param newVehicleUsageValue
     *     The new value of vehicleUsageValue.
     * @generated
     */
    public void setVehicleUsageValue( String newVehicleUsageValue ) throws Exception {
        metaDataMap.put("VehicleUsageValue", newVehicleUsageValue);

        if (newVehicleUsageValue == null || newVehicleUsageValue.equals("")) {
            newVehicleUsageValue = null;


        }
        vehicleUsageValue = newVehicleUsageValue;
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the vehicleOwnerShip attribute.
     * 
     * @generated
     */
    public String getVehicleOwnerShip (){
   
        return eObjXCustomerVehicle.getVehicleOwnerShip();
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the vehicleOwnerShip attribute.
     * 
     * @param newVehicleOwnerShip
     *     The new value of vehicleOwnerShip.
     * @generated
     */
    public void setVehicleOwnerShip( String newVehicleOwnerShip ) throws Exception {
        metaDataMap.put("VehicleOwnerShip", newVehicleOwnerShip);

        if (newVehicleOwnerShip == null || newVehicleOwnerShip.equals("")) {
            newVehicleOwnerShip = null;


        }
        eObjXCustomerVehicle.setVehicleOwnerShip( newVehicleOwnerShip );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the startDate attribute.
     * 
     * @generated
     */
    public String getStartDate (){
   
        return DWLFunctionUtils.getStringFromTimestamp(eObjXCustomerVehicle.getStartDate());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the startDate attribute.
     * 
     * @param newStartDate
     *     The new value of startDate.
     * @generated
     */
    public void setStartDate( String newStartDate ) throws Exception {
        metaDataMap.put("StartDate", newStartDate);
       	isValidStartDate = true;

        if (newStartDate == null || newStartDate.equals("")) {
            newStartDate = null;
            eObjXCustomerVehicle.setStartDate(null);


        }
    else {
        	if (DateValidator.validates(newStartDate)) {
           		eObjXCustomerVehicle.setStartDate(DateFormatter.getStartDateTimestamp(newStartDate));
            	metaDataMap.put("StartDate", getStartDate());
        	} else {
            	if (Configuration.getConfiguration().getConfigItem(
              "/IBM/DWLCommonServices/InternalValidation/enabled").getBooleanValue()) {
                	if (metaDataMap.get("StartDate") != null) {
                    	metaDataMap.put("StartDate", "");
                	}
                	isValidStartDate = false;
                	eObjXCustomerVehicle.setStartDate(null);
            	}
        	}
        }
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the endDate attribute.
     * 
     * @generated
     */
    public String getEndDate (){
   
        return DWLFunctionUtils.getStringFromTimestamp(eObjXCustomerVehicle.getEndDate());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the endDate attribute.
     * 
     * @param newEndDate
     *     The new value of endDate.
     * @generated
     */
    public void setEndDate( String newEndDate ) throws Exception {
        metaDataMap.put("EndDate", newEndDate);
       	isValidEndDate = true;

        if (newEndDate == null || newEndDate.equals("")) {
            newEndDate = null;
            eObjXCustomerVehicle.setEndDate(null);


        }
    else {
        	if (DateValidator.validates(newEndDate)) {
           		eObjXCustomerVehicle.setEndDate(DateFormatter.getStartDateTimestamp(newEndDate));
            	metaDataMap.put("EndDate", getEndDate());
        	} else {
            	if (Configuration.getConfiguration().getConfigItem(
              "/IBM/DWLCommonServices/InternalValidation/enabled").getBooleanValue()) {
                	if (metaDataMap.get("EndDate") != null) {
                    	metaDataMap.put("EndDate", "");
                	}
                	isValidEndDate = false;
                	eObjXCustomerVehicle.setEndDate(null);
            	}
        	}
        }
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XVehicleBObj attribute.
     * 
     * @generated
     */
    public XVehicleBObj getXVehicleBObj (){
      return XVehicleBObj;
    }
    
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public void setXVehicleBObj(XVehicleBObj newBObj ) {
    XVehicleBObj = newBObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XCustomerVehicleRoleBObj attribute.
     * 
     * @generated
     */
    @SuppressWarnings("rawtypes")
    public Vector getItemsXCustomerVehicleRoleBObj (){
      return vecXCustomerVehicleRoleBObj;
    }
    
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    @SuppressWarnings("unchecked")
    public void setXCustomerVehicleRoleBObj(XCustomerVehicleRoleBObj newBObj ) {
        vecXCustomerVehicleRoleBObj.addElement( newBObj );
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateTxId attribute.
     *
     * @generated
     */
    public String getXCustomerVehicleLastUpdateTxId() {
        return DWLFunctionUtils.getStringFromLong(eObjXCustomerVehicle.getLastUpdateTxId());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateUser attribute.
     *
     * @generated
     */
    public String getXCustomerVehicleLastUpdateUser() {
        return eObjXCustomerVehicle.getLastUpdateUser();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateDt attribute.
     *
     * @generated
     */
    public String getXCustomerVehicleLastUpdateDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXCustomerVehicle.getLastUpdateDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateTxId attribute.
     *
     * @param newLastUpdateTxId
     *     The new value of LastUpdateTxId.
     * @generated
     */
    public void setXCustomerVehicleLastUpdateTxId(String newLastUpdateTxId) {
        metaDataMap.put("XCustomerVehicleLastUpdateTxId", newLastUpdateTxId);

        if ((newLastUpdateTxId == null) || newLastUpdateTxId.equals("")) {
            newLastUpdateTxId = null;
        }
        eObjXCustomerVehicle.setLastUpdateTxId(DWLFunctionUtils.getLongFromString(newLastUpdateTxId));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateUser attribute.
     *
     * @param newLastUpdateUser
     *     The new value of LastUpdateUser.
     * @generated
     */
    public void setXCustomerVehicleLastUpdateUser(String newLastUpdateUser) {
        metaDataMap.put("XCustomerVehicleLastUpdateUser", newLastUpdateUser);

        if ((newLastUpdateUser == null) || newLastUpdateUser.equals("")) {
            newLastUpdateUser = null;
        }
        eObjXCustomerVehicle.setLastUpdateUser(newLastUpdateUser);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateDt attribute.
     *
     * @param newLastUpdateDt
     *     The new value of LastUpdateDt.
     * @throws Exception
     * @generated
     */
    public void setXCustomerVehicleLastUpdateDate(String newLastUpdateDt) throws Exception {
        metaDataMap.put("XCustomerVehicleLastUpdateDate", newLastUpdateDt);

        if ((newLastUpdateDt == null) || newLastUpdateDt.equals("")) {
            newLastUpdateDt = null;
        }

        eObjXCustomerVehicle.setLastUpdateDt(DWLFunctionUtils.getTimestampFromTimestampString(newLastUpdateDt));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XCustomerVehicleHistActionCode history attribute.
     *
     * @generated
     */
    public String getXCustomerVehicleHistActionCode() {
        return eObjXCustomerVehicle.getHistActionCode();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XCustomerVehicleHistActionCode history attribute.
     *
     * @param aXCustomerVehicleHistActionCode
     *     The new value of XCustomerVehicleHistActionCode.
     * @generated
     */
    public void setXCustomerVehicleHistActionCode(String aXCustomerVehicleHistActionCode) {
        metaDataMap.put("XCustomerVehicleHistActionCode", aXCustomerVehicleHistActionCode);

        if ((aXCustomerVehicleHistActionCode == null) || aXCustomerVehicleHistActionCode.equals("")) {
            aXCustomerVehicleHistActionCode = null;
        }
        eObjXCustomerVehicle.setHistActionCode(aXCustomerVehicleHistActionCode);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XCustomerVehicleHistCreateDate history attribute.
     *
     * @generated
     */
    public String getXCustomerVehicleHistCreateDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXCustomerVehicle.getHistCreateDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XCustomerVehicleHistCreateDate history attribute.
     *
     * @param aXCustomerVehicleHistCreateDate
     *     The new value of XCustomerVehicleHistCreateDate.
     * @generated
     */
    public void setXCustomerVehicleHistCreateDate(String aXCustomerVehicleHistCreateDate) throws Exception{
        metaDataMap.put("XCustomerVehicleHistCreateDate", aXCustomerVehicleHistCreateDate);

        if ((aXCustomerVehicleHistCreateDate == null) || aXCustomerVehicleHistCreateDate.equals("")) {
            aXCustomerVehicleHistCreateDate = null;
        }

        eObjXCustomerVehicle.setHistCreateDt(DWLFunctionUtils.getTimestampFromTimestampString(aXCustomerVehicleHistCreateDate));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XCustomerVehicleHistCreatedBy history attribute.
     *
     * @generated
     */
    public String getXCustomerVehicleHistCreatedBy() {
        return eObjXCustomerVehicle.getHistCreatedBy();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XCustomerVehicleHistCreatedBy history attribute.
     *
     * @param aXCustomerVehicleHistCreatedBy
     *     The new value of XCustomerVehicleHistCreatedBy.
     * @generated
     */
    public void setXCustomerVehicleHistCreatedBy(String aXCustomerVehicleHistCreatedBy) {
        metaDataMap.put("XCustomerVehicleHistCreatedBy", aXCustomerVehicleHistCreatedBy);

        if ((aXCustomerVehicleHistCreatedBy == null) || aXCustomerVehicleHistCreatedBy.equals("")) {
            aXCustomerVehicleHistCreatedBy = null;
        }

        eObjXCustomerVehicle.setHistCreatedBy(aXCustomerVehicleHistCreatedBy);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XCustomerVehicleHistEndDate history attribute.
     *
     * @generated
     */
    public String getXCustomerVehicleHistEndDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXCustomerVehicle.getHistEndDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XCustomerVehicleHistEndDate history attribute.
     *
     * @param aXCustomerVehicleHistEndDate
     *     The new value of XCustomerVehicleHistEndDate.
     * @generated
     */
    public void setXCustomerVehicleHistEndDate(String aXCustomerVehicleHistEndDate) throws Exception{
        metaDataMap.put("XCustomerVehicleHistEndDate", aXCustomerVehicleHistEndDate);

        if ((aXCustomerVehicleHistEndDate == null) || aXCustomerVehicleHistEndDate.equals("")) {
            aXCustomerVehicleHistEndDate = null;
        }
        eObjXCustomerVehicle.setHistEndDt(DWLFunctionUtils.getTimestampFromTimestampString(aXCustomerVehicleHistEndDate));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XCustomerVehicleHistoryIdPK history attribute.
     *
     * @generated
     */
    public String getXCustomerVehicleHistoryIdPK() {
        return DWLFunctionUtils.getStringFromLong(eObjXCustomerVehicle.getHistoryIdPK());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XCustomerVehicleHistoryIdPK history attribute.
     *
     * @param aXCustomerVehicleHistoryIdPK
     *     The new value of XCustomerVehicleHistoryIdPK.
     * @generated
     */
    public void setXCustomerVehicleHistoryIdPK(String aXCustomerVehicleHistoryIdPK) {
        metaDataMap.put("XCustomerVehicleHistoryIdPK", aXCustomerVehicleHistoryIdPK);

        if ((aXCustomerVehicleHistoryIdPK == null) || aXCustomerVehicleHistoryIdPK.equals("")) {
            aXCustomerVehicleHistoryIdPK = null;
        }
        eObjXCustomerVehicle.setHistoryIdPK(DWLFunctionUtils.getLongFromString(aXCustomerVehicleHistoryIdPK));
    }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation during an add transaction.
     *
     * @generated
     */
    public DWLStatus validateAdd(int level, DWLStatus status) throws Exception {

        status = super.validateAdd(level, status);
        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0038I Add any controller-level custom validation logic to be
            // executed for this object during an "add" transaction


            XVehicleBObj xVehicle = getXVehicleBObj();
            if( xVehicle != null ){
            	status = xVehicle.validateAdd(level, status);
            }

            for (int i = 0; i < getItemsXCustomerVehicleRoleBObj().size(); i++) {
                XCustomerVehicleRoleBObj xCustomerVehicleRole = (XCustomerVehicleRoleBObj) getItemsXCustomerVehicleRoleBObj().elementAt(i);
                status = xCustomerVehicleRole.validateAdd(level, status);
            }
        }

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            // MDM_TODO0: CDKWB0039I Add any component-level custom validation logic to be
            // executed for this object during an "add" transaction
        }
        status = getValidationStatus(level, status);
        return status;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation during an update transaction.
     *
     * @generated
     */
    public DWLStatus validateUpdate(int level, DWLStatus status) throws Exception {
    logger.finest("ENTER validateUpdate(int level, DWLStatus status)");

        status = super.validateUpdate(level, status);
        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0040I Add any controller-level custom validation logic to be
            // executed for this object during an "update" transaction

            if (eObjXCustomerVehicle.getCustomerVehiclepkId() == null) {
                DWLError err = new DWLError();
                err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_BOBJ).longValue());
                err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.XCUSTOMERVEHICLE_CUSTOMERVEHICLEPKID_NULL).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                	String infoForLogging="Error: Validation error occured for update. No primary key for entity XCustomerVehicle, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("validateUpdate(int level, DWLStatus status) " + infoForLogging);
                }
                status.addError(err);
            }
            if (eObjXCustomerVehicle.getLastUpdateDt() == null) {
                DWLError err = new DWLError();
                err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_BOBJ).longValue());
                err.setReasonCode(new Long(DWLUtilErrorReasonCode.LAST_UPDATED_DATE_NULL).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
                if (logger.isFinestEnabled()) {
                	String infoForLogging="Error: Validation error occured for update. No last update date for entity XCustomerVehicle, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("validateUpdate(int level, DWLStatus status) " + infoForLogging);
                }
                status.addError(err);
            }
           XVehicleBObj xVehicle = (XVehicleBObj) getXVehicleBObj();
           if( xVehicle != null ){
           		if (xVehicle.getEObjXVehicle().getPrimaryKey() == null) {
               		status = xVehicle.validateAdd(level, status);
           		} else  {
               		status = xVehicle.validateUpdate(level, status);
           		}
           }

            for (int i = 0; i < getItemsXCustomerVehicleRoleBObj().size(); i++) {
                XCustomerVehicleRoleBObj xCustomerVehicleRole = (XCustomerVehicleRoleBObj) getItemsXCustomerVehicleRoleBObj().elementAt(i);
                if (xCustomerVehicleRole.getEObjXCustomerVehicleRole().getPrimaryKey() == null) {
                    status = xCustomerVehicleRole.validateAdd(level, status);
                } else  {
                    status = xCustomerVehicleRole.validateUpdate(level, status);
                }
            }
        }

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            assignBeforeImageValues(metaDataMap);
            
            // MDM_TODO0: CDKWB0041I Add any component-level custom validation logic to be
            // executed for this object during an "update" transaction
        }
        status = getValidationStatus(level, status);
    if (logger.isFinestEnabled()) {
        	String returnValue = status.toString();
      logger.finest("RETURN validateUpdate(int level, DWLStatus status) " + returnValue);
    }
        return status;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Populate the before image of this business object.
     *
     * @see com.dwl.base.DWLCommon#populateBeforeImage()
     * @generated
     */
    public void populateBeforeImage() throws DWLBaseException {
    logger.finest("ENTER populateBeforeImage()");

        DSEAAdditionsExts comp = null;
        try {
        
      comp = (DSEAAdditionsExts)TCRMClassFactory.getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
        	
        } catch (Exception e) {
      if (logger.isFinestEnabled()) {
        String infoForLogging="Error: Fatal error while updating record " + e.getMessage();
      logger.finest("populateBeforeImage() " + infoForLogging);
      }
            DWLExceptionUtils.throwDWLBaseException(e, 
            									new DWLUpdateException(e.getMessage()), 
            									this.getStatus(), DWLStatus.FATAL,
                                  DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_BOBJ, 
                                  "DIERR",
                                  DSEAAdditionsExtsErrorReasonCode.XCUSTOMERVEHICLE_BEFORE_IMAGE_NOT_POPULATED, 
                                  this.getControl());
        }
        
        comp.loadBeforeImage(this);
    logger.finest("RETURN populateBeforeImage()");
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation common to both add and update transactions.
     *
     * @generated
     */
     
    private DWLStatus getValidationStatus(int level, DWLStatus status) throws Exception {
    logger.finest("ENTER getValidationStatus(int level, DWLStatus status)");

        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0034I Add any common controller-level custom validation
            // logic to be executed for this object during either "add" or
            // "update" transactions
    		controllerValidation_ConnectMeUsage(status);
    		controllerValidation_VehicleSales(status);
    		controllerValidation_VehicleUsage(status);
    		controllerValidation_StartDate(status);
    		controllerValidation_EndDate(status);
    		controllerValidation_SourceIdentifier(status);
    	}

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            // MDM_TODO0: CDKWB0035I Add any common component-level custom validation logic
            // to be executed for this object during either "add" or "update"
            // transactions
    		componentValidation_ConnectMeUsage(status);
    		componentValidation_VehicleSales(status);
    		componentValidation_VehicleUsage(status);
    		componentValidation_StartDate(status);
    		componentValidation_EndDate(status);
    		componentValidation_SourceIdentifier(status);
        }
        
        if (logger.isFinestEnabled()) {
            String returnValue = status.toString();
      logger.finest("RETURN getValidationStatus(int level, DWLStatus status) " + returnValue);
        }
    
        return status;
    }

    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "ConnectMeUsage"
     *
     * @generated
     */
	private void componentValidation_ConnectMeUsage(DWLStatus status) {
  
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "SourceIdentifier"
     *
     * @generated
     */
	private void componentValidation_SourceIdentifier(DWLStatus status) {
  
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "VehicleSales"
     *
     * @generated
     */
	private void componentValidation_VehicleSales(DWLStatus status) {
  
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "VehicleUsage"
     *
     * @generated
     */
	private void componentValidation_VehicleUsage(DWLStatus status) {
  
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "StartDate"
     *
     * @generated
     */
	private void componentValidation_StartDate(DWLStatus status) {
  
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "EndDate"
     *
     * @generated
     */
	private void componentValidation_EndDate(DWLStatus status) {
  
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "ConnectMeUsage"
     *
     * @generated
     */
	private void controllerValidation_ConnectMeUsage(DWLStatus status) throws Exception {
  
      //persistent code type
            boolean isConnectMeUsageNull = false;
            if ((eObjXCustomerVehicle.getConnectMeUsage() == null) &&
               ((getConnectMeUsageValue() == null) || 
                 getConnectMeUsageValue().trim().equals(""))) {
                isConnectMeUsageNull = true;
            }
            if (!isConnectMeUsageNull) {
                if (checkForInvalidXcustomervehicleConnectmeusage()) {
                    DWLError err = new DWLError();
                    err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_BOBJ).longValue());
                    err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XCUSTOMERVEHICLE_CONNECTMEUSAGE).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                    String infoForLogging="Error: Custom validation error occured for entity XCustomerVehicle, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("controllerValidation_ConnectMeUsage " + infoForLogging);
        }
                status.addError(err);
            }

             }
    			
    	}
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "SourceIdentifier"
     *
     * @generated
     */
	private void controllerValidation_SourceIdentifier(DWLStatus status) throws Exception {
  
      //persistent code type
            boolean isSourceIdentifierNull = false;
            if ((eObjXCustomerVehicle.getSourceIdentifier() == null) &&
               ((getSourceIdentifierValue() == null) || 
                 getSourceIdentifierValue().trim().equals(""))) {
                isSourceIdentifierNull = true;
            }
            if (!isSourceIdentifierNull) {
                if (checkForInvalidXcustomervehicleSourceidentifier()) {
                    DWLError err = new DWLError();
                    err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_BOBJ).longValue());
                    err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XCUSTOMERVEHICLE_SOURCEIDENTIFIER).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                    String infoForLogging="Error: Custom validation error occured for entity XCustomerVehicle, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("controllerValidation_SourceIdentifier " + infoForLogging);
        }
                status.addError(err);
            }

             }
    			
    	}
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "VehicleSales"
     *
     * @generated
     */
	private void controllerValidation_VehicleSales(DWLStatus status) throws Exception {
  
      //persistent code type
            boolean isVehicleSalesNull = false;
            if ((eObjXCustomerVehicle.getVehicleSales() == null) &&
               ((getVehicleSalesValue() == null) || 
                 getVehicleSalesValue().trim().equals(""))) {
                isVehicleSalesNull = true;
            }
            if (!isVehicleSalesNull) {
                if (checkForInvalidXcustomervehicleVehiclesales()) {
                    DWLError err = new DWLError();
                    err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_BOBJ).longValue());
                    err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XCUSTOMERVEHICLE_VEHICLESALES).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                    String infoForLogging="Error: Custom validation error occured for entity XCustomerVehicle, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("controllerValidation_VehicleSales " + infoForLogging);
        }
                status.addError(err);
            }

             }
    			
    	}
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "VehicleUsage"
     *
     * @generated
     */
	private void controllerValidation_VehicleUsage(DWLStatus status) throws Exception {
  
      //persistent code type
            boolean isVehicleUsageNull = false;
            if ((eObjXCustomerVehicle.getVehicleUsage() == null) &&
               ((getVehicleUsageValue() == null) || 
                 getVehicleUsageValue().trim().equals(""))) {
                isVehicleUsageNull = true;
            }
            if (!isVehicleUsageNull) {
                if (checkForInvalidXcustomervehicleVehicleusage()) {
                    DWLError err = new DWLError();
                    err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_BOBJ).longValue());
                    err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XCUSTOMERVEHICLE_VEHICLEUSAGE).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                    String infoForLogging="Error: Custom validation error occured for entity XCustomerVehicle, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("controllerValidation_VehicleUsage " + infoForLogging);
        }
                status.addError(err);
            }

             }
    			
    	}
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "StartDate"
     *
     * @generated
     */
	private void controllerValidation_StartDate(DWLStatus status) throws Exception {
  
            boolean isStartDateNull = (eObjXCustomerVehicle.getStartDate() == null);
            if (!isValidStartDate) {
              	DWLError err = new DWLError();
               	err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_BOBJ).longValue());
               	err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XCUSTOMERVEHICLE_STARTDATE).longValue());
               	err.setErrorType(DWLErrorCode.DATA_INVALID_ERROR);
                String infoForLogging="Error: Validation error. Invalid time specified on property StartDate in entity XCustomerVehicle, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode();
      logger.finest("controllerValidation_StartDate " + infoForLogging);
               	status.addError(err);
            } 
    	}
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "EndDate"
     *
     * @generated
     */
	private void controllerValidation_EndDate(DWLStatus status) throws Exception {
  
            boolean isEndDateNull = (eObjXCustomerVehicle.getEndDate() == null);
            if (!isValidEndDate) {
              	DWLError err = new DWLError();
               	err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_BOBJ).longValue());
               	err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XCUSTOMERVEHICLE_ENDDATE).longValue());
               	err.setErrorType(DWLErrorCode.DATA_INVALID_ERROR);
                String infoForLogging="Error: Validation error. Invalid time specified on property EndDate in entity XCustomerVehicle, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode();
      logger.finest("controllerValidation_EndDate " + infoForLogging);
               	status.addError(err);
            } 
    	}
    private DWLError createDWLError(String entityName, String propertyName,String reasonCode){	
		DWLError err = new DWLError();
		err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_BOBJ).longValue());
		err.setReasonCode(new Long(reasonCode).longValue());
		err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
			String infoForLogging="Error: Validation error occured. Property " + propertyName + " is null, in entity " + entityName + ", component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
			logger.finest("createDWLError " + infoForLogging);
		}
		return err;
    }
    
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Check the value of the field ConnectMeUsage and return true if the error
     * reason INVALID_XCUSTOMERVEHICLE_CONNECTMEUSAGE should be returned.
     *
     * @generated
  **/
	private boolean checkForInvalidXcustomervehicleConnectmeusage() throws Exception {
    logger.finest("ENTER checkForInvalidXcustomervehicleConnectmeusage()");
        boolean notValid = false;
      	String langId = (String) this.getControl().get(DWLControlKeys.LANG_ID);
      	CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
    Long codeType = DWLFunctionUtils.getLongFromString( getConnectMeUsageType() );
    String codeValue = getConnectMeUsageValue();
    if( codeValue != null && codeValue.trim().equals("")){
      codeValue = null;
    }
     
        if ( codeType != null && codeValue == null ){

             if( codeTypeCompHelper.isCodeValid("xcdconnectmeusagetp", langId, getConnectMeUsageType(),
                 CodeTypeComponentHelper.ACTIVE, getControl())) {
                 CodeTypeBObj ctBObj = codeTypeCompHelper
                 					.getCodeTypeByCode("xcdconnectmeusagetp", langId, getConnectMeUsageType(),
                         								getControl());
               	if (ctBObj != null) {
                   	setConnectMeUsageValue( ctBObj.getvalue() );
               	}
             }
             else{
             	if (logger.isFinestEnabled()) {
              	 	String infoForLogging="NotValid 1";
      logger.finest("checkForInvalidXcustomervehicleConnectmeusage() " + infoForLogging);
        }
                 notValid = true;
           }
        }
        else if (codeType == null && codeValue != null ){
          
             CodeTypeBObj ctBObj = codeTypeCompHelper
                      .getCodeTypeByValue("xcdconnectmeusagetp", langId, codeValue,
                                 getControl());

             if (ctBObj != null) {
                 setConnectMeUsageType(ctBObj.gettp_cd());
             } 
             else {
             	if (logger.isFinestEnabled()) {
              	  	String infoForLogging="NotValid 2";
      logger.finest("checkForInvalidXcustomervehicleConnectmeusage() " + infoForLogging);
        }
                  notValid = true;
             }
        }
        else if ( codeType != null && codeValue != null
             && !codeTypeCompHelper.isCodeValuePairValid("xcdconnectmeusagetp", langId, getConnectMeUsageType(), 
                     new String[] { codeValue }, CodeTypeComponentHelper.ACTIVE, getControl())) {	
       if (logger.isFinestEnabled()) {
       		String infoForLogging="NotValid 3";
      logger.finest("checkForInvalidXcustomervehicleConnectmeusage() " + infoForLogging);
       }
             notValid = true;
        }
        if (logger.isFinestEnabled()) {
      String returnValue ="" +notValid;
      logger.finest("RETURN checkForInvalidXcustomervehicleConnectmeusage() " + returnValue);
    }
    return notValid;
     } 
				 
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Check the value of the field SourceIdentifier and return true if the
     * error reason INVALID_XCUSTOMERVEHICLE_SOURCEIDENTIFIER should be
     * returned.
     *
     * @generated
  **/
	private boolean checkForInvalidXcustomervehicleSourceidentifier() throws Exception {
    logger.finest("ENTER checkForInvalidXcustomervehicleSourceidentifier()");
        boolean notValid = false;
      	String langId = (String) this.getControl().get(DWLControlKeys.LANG_ID);
      	CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
    Long codeType = DWLFunctionUtils.getLongFromString( getSourceIdentifierType() );
    String codeValue = getSourceIdentifierValue();
    if( codeValue != null && codeValue.trim().equals("")){
      codeValue = null;
    }
     
        if ( codeType != null && codeValue == null ){

             if( codeTypeCompHelper.isCodeValid("cdsourceidenttp", langId, getSourceIdentifierType(),
                 CodeTypeComponentHelper.ACTIVE, getControl())) {
                 CodeTypeBObj ctBObj = codeTypeCompHelper
                 					.getCodeTypeByCode("cdsourceidenttp", langId, getSourceIdentifierType(),
                         								getControl());
               	if (ctBObj != null) {
                   	setSourceIdentifierValue( ctBObj.getvalue() );
               	}
             }
             else{
             	if (logger.isFinestEnabled()) {
              	 	String infoForLogging="NotValid 1";
      logger.finest("checkForInvalidXcustomervehicleSourceidentifier() " + infoForLogging);
        }
                 notValid = true;
           }
        }
        else if (codeType == null && codeValue != null ){
          
             CodeTypeBObj ctBObj = codeTypeCompHelper
                      .getCodeTypeByValue("cdsourceidenttp", langId, codeValue,
                                 getControl());

             if (ctBObj != null) {
                 setSourceIdentifierType(ctBObj.gettp_cd());
             } 
             else {
             	if (logger.isFinestEnabled()) {
              	  	String infoForLogging="NotValid 2";
      logger.finest("checkForInvalidXcustomervehicleSourceidentifier() " + infoForLogging);
        }
                  notValid = true;
             }
        }
        else if ( codeType != null && codeValue != null
             && !codeTypeCompHelper.isCodeValuePairValid("cdsourceidenttp", langId, getSourceIdentifierType(), 
                     new String[] { codeValue }, CodeTypeComponentHelper.ACTIVE, getControl())) {	
       if (logger.isFinestEnabled()) {
       		String infoForLogging="NotValid 3";
      logger.finest("checkForInvalidXcustomervehicleSourceidentifier() " + infoForLogging);
       }
             notValid = true;
        }
        if (logger.isFinestEnabled()) {
      String returnValue ="" +notValid;
      logger.finest("RETURN checkForInvalidXcustomervehicleSourceidentifier() " + returnValue);
    }
    return notValid;
     } 
				 
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Check the value of the field VehicleSales and return true if the error
     * reason INVALID_XCUSTOMERVEHICLE_VEHICLESALES should be returned.
     *
     * @generated
  **/
	private boolean checkForInvalidXcustomervehicleVehiclesales() throws Exception {
    logger.finest("ENTER checkForInvalidXcustomervehicleVehiclesales()");
        boolean notValid = false;
      	String langId = (String) this.getControl().get(DWLControlKeys.LANG_ID);
      	CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
    Long codeType = DWLFunctionUtils.getLongFromString( getVehicleSalesType() );
    String codeValue = getVehicleSalesValue();
    if( codeValue != null && codeValue.trim().equals("")){
      codeValue = null;
    }
     
        if ( codeType != null && codeValue == null ){

             if( codeTypeCompHelper.isCodeValid("xcdvehiclesalestp", langId, getVehicleSalesType(),
                 CodeTypeComponentHelper.ACTIVE, getControl())) {
                 CodeTypeBObj ctBObj = codeTypeCompHelper
                 					.getCodeTypeByCode("xcdvehiclesalestp", langId, getVehicleSalesType(),
                         								getControl());
               	if (ctBObj != null) {
                   	setVehicleSalesValue( ctBObj.getvalue() );
               	}
             }
             else{
             	if (logger.isFinestEnabled()) {
              	 	String infoForLogging="NotValid 1";
      logger.finest("checkForInvalidXcustomervehicleVehiclesales() " + infoForLogging);
        }
                 notValid = true;
           }
        }
        else if (codeType == null && codeValue != null ){
          
             CodeTypeBObj ctBObj = codeTypeCompHelper
                      .getCodeTypeByValue("xcdvehiclesalestp", langId, codeValue,
                                 getControl());

             if (ctBObj != null) {
                 setVehicleSalesType(ctBObj.gettp_cd());
             } 
             else {
             	if (logger.isFinestEnabled()) {
              	  	String infoForLogging="NotValid 2";
      logger.finest("checkForInvalidXcustomervehicleVehiclesales() " + infoForLogging);
        }
                  notValid = true;
             }
        }
        else if ( codeType != null && codeValue != null
             && !codeTypeCompHelper.isCodeValuePairValid("xcdvehiclesalestp", langId, getVehicleSalesType(), 
                     new String[] { codeValue }, CodeTypeComponentHelper.ACTIVE, getControl())) {	
       if (logger.isFinestEnabled()) {
       		String infoForLogging="NotValid 3";
      logger.finest("checkForInvalidXcustomervehicleVehiclesales() " + infoForLogging);
       }
             notValid = true;
        }
        if (logger.isFinestEnabled()) {
      String returnValue ="" +notValid;
      logger.finest("RETURN checkForInvalidXcustomervehicleVehiclesales() " + returnValue);
    }
    return notValid;
     } 
				 
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Check the value of the field VehicleUsage and return true if the error
     * reason INVALID_XCUSTOMERVEHICLE_VEHICLEUSAGE should be returned.
     *
     * @generated
  **/
	private boolean checkForInvalidXcustomervehicleVehicleusage() throws Exception {
    logger.finest("ENTER checkForInvalidXcustomervehicleVehicleusage()");
        boolean notValid = false;
      	String langId = (String) this.getControl().get(DWLControlKeys.LANG_ID);
      	CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
    Long codeType = DWLFunctionUtils.getLongFromString( getVehicleUsageType() );
    String codeValue = getVehicleUsageValue();
    if( codeValue != null && codeValue.trim().equals("")){
      codeValue = null;
    }
     
        if ( codeType != null && codeValue == null ){

             if( codeTypeCompHelper.isCodeValid("xcdvehicleusagetp", langId, getVehicleUsageType(),
                 CodeTypeComponentHelper.ACTIVE, getControl())) {
                 CodeTypeBObj ctBObj = codeTypeCompHelper
                 					.getCodeTypeByCode("xcdvehicleusagetp", langId, getVehicleUsageType(),
                         								getControl());
               	if (ctBObj != null) {
                   	setVehicleUsageValue( ctBObj.getvalue() );
               	}
             }
             else{
             	if (logger.isFinestEnabled()) {
              	 	String infoForLogging="NotValid 1";
      logger.finest("checkForInvalidXcustomervehicleVehicleusage() " + infoForLogging);
        }
                 notValid = true;
           }
        }
        else if (codeType == null && codeValue != null ){
          
             CodeTypeBObj ctBObj = codeTypeCompHelper
                      .getCodeTypeByValue("xcdvehicleusagetp", langId, codeValue,
                                 getControl());

             if (ctBObj != null) {
                 setVehicleUsageType(ctBObj.gettp_cd());
             } 
             else {
             	if (logger.isFinestEnabled()) {
              	  	String infoForLogging="NotValid 2";
      logger.finest("checkForInvalidXcustomervehicleVehicleusage() " + infoForLogging);
        }
                  notValid = true;
             }
        }
        else if ( codeType != null && codeValue != null
             && !codeTypeCompHelper.isCodeValuePairValid("xcdvehicleusagetp", langId, getVehicleUsageType(), 
                     new String[] { codeValue }, CodeTypeComponentHelper.ACTIVE, getControl())) {	
       if (logger.isFinestEnabled()) {
       		String infoForLogging="NotValid 3";
      logger.finest("checkForInvalidXcustomervehicleVehicleusage() " + infoForLogging);
       }
             notValid = true;
        }
        if (logger.isFinestEnabled()) {
      String returnValue ="" +notValid;
      logger.finest("RETURN checkForInvalidXcustomervehicleVehicleusage() " + returnValue);
    }
    return notValid;
     } 
				 



}

