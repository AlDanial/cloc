
/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[a84458f825738aa4b08658e7666ccbe1]
 */

package com.ibm.daimler.dsea.component;

import com.dwl.tcrm.common.TCRMCommon;



import com.dwl.base.DWLControl;

import com.dwl.base.constant.DWLControlKeys;
import com.dwl.base.constant.DWLUtilErrorReasonCode;

import com.dwl.base.error.DWLError;
import com.dwl.base.error.DWLErrorCode;
import com.dwl.base.error.DWLStatus;

import com.dwl.base.exception.DWLBaseException;
import com.dwl.base.exception.DWLUpdateException;

import com.dwl.base.util.DWLClassFactory;
import com.dwl.base.util.DWLExceptionUtils;
import com.dwl.base.util.DWLFunctionUtils;

import com.dwl.management.config.client.Configuration;

import com.dwl.tcrm.common.ITCRMValidation;

import com.dwl.tcrm.utilities.DateFormatter;
import com.dwl.tcrm.utilities.DateValidator;
import com.dwl.tcrm.utilities.TCRMClassFactory;

import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsComponentID;
import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsErrorReasonCode;
import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsPropertyKeys;

import com.ibm.daimler.dsea.entityObject.EObjXVehicleAddress;

import com.ibm.daimler.dsea.interfaces.DSEAAdditionsExts;

import com.ibm.mdm.common.codetype.interfaces.CodeTypeComponentHelper;

import com.ibm.mdm.common.codetype.obj.CodeTypeBObj;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * This class provides the implementation of the business object
 * <code>XVehicleAddressBObj</code>.
 * 
 * @see com.dwl.tcrm.common.TCRMCommon
 * @generated
 */
 

@SuppressWarnings("serial")
public class XVehicleAddressBObj extends TCRMCommon  {

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected EObjXVehicleAddress eObjXVehicleAddress;
	/**
    * <!-- begin-user-doc -->
	  * <!-- end-user-doc -->
    * @generated 
    */
	 private final static com.dwl.base.logging.IDWLLogger logger = com.dwl.base.logging.DWLLoggerManager.getLogger(XVehicleAddressBObj.class);
		
 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected String sourceIdentifierValue;
	protected boolean isValidStartDate = true;
	
	protected boolean isValidLastModifiedSystemDate = true;
	


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */     
    public XVehicleAddressBObj() {
        super();
        init();
        eObjXVehicleAddress = new EObjXVehicleAddress();
       // setComponentID(DSEAAdditionsExtsComponentID.XVEHICLE_ADDRESS_BOBJ);
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Initializes the fields required to populate the metaDataMap. Each key is
     * an element-level field of the business object.
     *
     * @generated
     */
    private void init() {
        metaDataMap.put("VehicleAddresspkId", null);
        metaDataMap.put("AddressUsageType", null);
        metaDataMap.put("PreferredInd", null);
        metaDataMap.put("AddressLineOne", null);
        metaDataMap.put("AddressLineTwo", null);
        metaDataMap.put("AddressLineThree", null);
        metaDataMap.put("City", null);
        metaDataMap.put("ZipPostalCode", null);
        metaDataMap.put("ResidenceNumber", null);
        metaDataMap.put("Country", null);
        metaDataMap.put("ProvinceState", null);
        metaDataMap.put("VehicleId", null);
        metaDataMap.put("ContId", null);
        metaDataMap.put("SourceIdentifierType", null);
        metaDataMap.put("SourceIdentifierValue", null);
        metaDataMap.put("StartDate", null);
        metaDataMap.put("LastModifiedSystemDate", null);
        metaDataMap.put("XVehicleAddressHistActionCode", null);
        metaDataMap.put("XVehicleAddressHistCreateDate", null);
        metaDataMap.put("XVehicleAddressHistCreatedBy", null);
        metaDataMap.put("XVehicleAddressHistEndDate", null);
        metaDataMap.put("XVehicleAddressHistoryIdPK", null);
        metaDataMap.put("XVehicleAddressLastUpdateDate", null);
        metaDataMap.put("XVehicleAddressLastUpdateTxId", null);
        metaDataMap.put("XVehicleAddressLastUpdateUser", null);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Refreshes all the attributes this business object supports.
     *
     * @see com.dwl.base.DWLCommon#refreshMap()
     * @generated
     */
    public void refreshMap() {

        if (bRequireMapRefresh) {
            super.refreshMap();
            metaDataMap.put("VehicleAddresspkId", getVehicleAddresspkId());
            metaDataMap.put("AddressUsageType", getAddressUsageType());
            metaDataMap.put("PreferredInd", getPreferredInd());
            metaDataMap.put("AddressLineOne", getAddressLineOne());
            metaDataMap.put("AddressLineTwo", getAddressLineTwo());
            metaDataMap.put("AddressLineThree", getAddressLineThree());
            metaDataMap.put("City", getCity());
            metaDataMap.put("ZipPostalCode", getZipPostalCode());
            metaDataMap.put("ResidenceNumber", getResidenceNumber());
            metaDataMap.put("Country", getCountry());
            metaDataMap.put("ProvinceState", getProvinceState());
            metaDataMap.put("VehicleId", getVehicleId());
            metaDataMap.put("ContId", getContId());
            metaDataMap.put("SourceIdentifierType", getSourceIdentifierType());
            metaDataMap.put("SourceIdentifierValue", getSourceIdentifierValue());
            metaDataMap.put("StartDate", getStartDate());
            metaDataMap.put("LastModifiedSystemDate", getLastModifiedSystemDate());
            metaDataMap.put("XVehicleAddressHistActionCode", getXVehicleAddressHistActionCode());
            metaDataMap.put("XVehicleAddressHistCreateDate", getXVehicleAddressHistCreateDate());
            metaDataMap.put("XVehicleAddressHistCreatedBy", getXVehicleAddressHistCreatedBy());
            metaDataMap.put("XVehicleAddressHistEndDate", getXVehicleAddressHistEndDate());
            metaDataMap.put("XVehicleAddressHistoryIdPK", getXVehicleAddressHistoryIdPK());
            metaDataMap.put("XVehicleAddressLastUpdateDate", getXVehicleAddressLastUpdateDate());
            metaDataMap.put("XVehicleAddressLastUpdateTxId", getXVehicleAddressLastUpdateTxId());
            metaDataMap.put("XVehicleAddressLastUpdateUser", getXVehicleAddressLastUpdateUser());
            bRequireMapRefresh = false;
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the control object on this business object.
     *
     * @see com.dwl.base.DWLCommon#setControl(DWLControl)
     * @generated
     */
    public void setControl(DWLControl newDWLControl) {
        super.setControl(newDWLControl);

        if (eObjXVehicleAddress != null) {
            eObjXVehicleAddress.setControl(newDWLControl);
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the entity object associated with this business object.
     *
     * @generated
     */
    public EObjXVehicleAddress getEObjXVehicleAddress() {
        bRequireMapRefresh = true;
        return eObjXVehicleAddress;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the entity object associated with this business object.
     *
     * @param eObjXVehicleAddress
     *            The eObjXVehicleAddress to set.
     * @generated
     */
    public void setEObjXVehicleAddress(EObjXVehicleAddress eObjXVehicleAddress) {
        bRequireMapRefresh = true;
        this.eObjXVehicleAddress = eObjXVehicleAddress;
        if (this.eObjXVehicleAddress != null && this.eObjXVehicleAddress.getControl() == null) {
            DWLControl control = this.getControl();
            if (control != null) {
                this.eObjXVehicleAddress.setControl(control);
            }
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the vehicleAddresspkId attribute.
     * 
     * @generated
     */
    public String getVehicleAddresspkId (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXVehicleAddress.getVehicleAddresspkId());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the vehicleAddresspkId attribute.
     * 
     * @param newVehicleAddresspkId
     *     The new value of vehicleAddresspkId.
     * @generated
     */
    public void setVehicleAddresspkId( String newVehicleAddresspkId ) throws Exception {
        metaDataMap.put("VehicleAddresspkId", newVehicleAddresspkId);

        if (newVehicleAddresspkId == null || newVehicleAddresspkId.equals("")) {
            newVehicleAddresspkId = null;


        }
        eObjXVehicleAddress.setVehicleAddresspkId( DWLFunctionUtils.getLongFromString(newVehicleAddresspkId) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the addressUsageType attribute.
     * 
     * @generated
     */
    public String getAddressUsageType (){
   
        return eObjXVehicleAddress.getAddressUsageType();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the addressUsageType attribute.
     * 
     * @param newAddressUsageType
     *     The new value of addressUsageType.
     * @generated
     */
    public void setAddressUsageType( String newAddressUsageType ) throws Exception {
        metaDataMap.put("AddressUsageType", newAddressUsageType);

        if (newAddressUsageType == null || newAddressUsageType.equals("")) {
            newAddressUsageType = null;


        }
        eObjXVehicleAddress.setAddressUsageType( newAddressUsageType );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the preferredInd attribute.
     * 
     * @generated
     */
    public String getPreferredInd (){
   
        return eObjXVehicleAddress.getPreferredInd();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the preferredInd attribute.
     * 
     * @param newPreferredInd
     *     The new value of preferredInd.
     * @generated
     */
    public void setPreferredInd( String newPreferredInd ) throws Exception {
        metaDataMap.put("PreferredInd", newPreferredInd);

        if (newPreferredInd == null || newPreferredInd.equals("")) {
            newPreferredInd = null;


        }
        eObjXVehicleAddress.setPreferredInd( newPreferredInd );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the addressLineOne attribute.
     * 
     * @generated
     */
    public String getAddressLineOne (){
   
        return eObjXVehicleAddress.getAddressLineOne();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the addressLineOne attribute.
     * 
     * @param newAddressLineOne
     *     The new value of addressLineOne.
     * @generated
     */
    public void setAddressLineOne( String newAddressLineOne ) throws Exception {
        metaDataMap.put("AddressLineOne", newAddressLineOne);

        if (newAddressLineOne == null || newAddressLineOne.equals("")) {
            newAddressLineOne = null;


        }
        eObjXVehicleAddress.setAddressLineOne( newAddressLineOne );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the addressLineTwo attribute.
     * 
     * @generated
     */
    public String getAddressLineTwo (){
   
        return eObjXVehicleAddress.getAddressLineTwo();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the addressLineTwo attribute.
     * 
     * @param newAddressLineTwo
     *     The new value of addressLineTwo.
     * @generated
     */
    public void setAddressLineTwo( String newAddressLineTwo ) throws Exception {
        metaDataMap.put("AddressLineTwo", newAddressLineTwo);

        if (newAddressLineTwo == null || newAddressLineTwo.equals("")) {
            newAddressLineTwo = null;


        }
        eObjXVehicleAddress.setAddressLineTwo( newAddressLineTwo );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the addressLineThree attribute.
     * 
     * @generated
     */
    public String getAddressLineThree (){
   
        return eObjXVehicleAddress.getAddressLineThree();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the addressLineThree attribute.
     * 
     * @param newAddressLineThree
     *     The new value of addressLineThree.
     * @generated
     */
    public void setAddressLineThree( String newAddressLineThree ) throws Exception {
        metaDataMap.put("AddressLineThree", newAddressLineThree);

        if (newAddressLineThree == null || newAddressLineThree.equals("")) {
            newAddressLineThree = null;


        }
        eObjXVehicleAddress.setAddressLineThree( newAddressLineThree );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the city attribute.
     * 
     * @generated
     */
    public String getCity (){
   
        return eObjXVehicleAddress.getCity();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the city attribute.
     * 
     * @param newCity
     *     The new value of city.
     * @generated
     */
    public void setCity( String newCity ) throws Exception {
        metaDataMap.put("City", newCity);

        if (newCity == null || newCity.equals("")) {
            newCity = null;


        }
        eObjXVehicleAddress.setCity( newCity );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the zipPostalCode attribute.
     * 
     * @generated
     */
    public String getZipPostalCode (){
   
        return eObjXVehicleAddress.getZipPostalCode();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the zipPostalCode attribute.
     * 
     * @param newZipPostalCode
     *     The new value of zipPostalCode.
     * @generated
     */
    public void setZipPostalCode( String newZipPostalCode ) throws Exception {
        metaDataMap.put("ZipPostalCode", newZipPostalCode);

        if (newZipPostalCode == null || newZipPostalCode.equals("")) {
            newZipPostalCode = null;


        }
        eObjXVehicleAddress.setZipPostalCode( newZipPostalCode );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the residenceNumber attribute.
     * 
     * @generated
     */
    public String getResidenceNumber (){
   
        return eObjXVehicleAddress.getResidenceNumber();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the residenceNumber attribute.
     * 
     * @param newResidenceNumber
     *     The new value of residenceNumber.
     * @generated
     */
    public void setResidenceNumber( String newResidenceNumber ) throws Exception {
        metaDataMap.put("ResidenceNumber", newResidenceNumber);

        if (newResidenceNumber == null || newResidenceNumber.equals("")) {
            newResidenceNumber = null;


        }
        eObjXVehicleAddress.setResidenceNumber( newResidenceNumber );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the country attribute.
     * 
     * @generated
     */
    public String getCountry (){
   
        return eObjXVehicleAddress.getCountry();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the country attribute.
     * 
     * @param newCountry
     *     The new value of country.
     * @generated
     */
    public void setCountry( String newCountry ) throws Exception {
        metaDataMap.put("Country", newCountry);

        if (newCountry == null || newCountry.equals("")) {
            newCountry = null;


        }
        eObjXVehicleAddress.setCountry( newCountry );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the provinceState attribute.
     * 
     * @generated
     */
    public String getProvinceState (){
   
        return eObjXVehicleAddress.getProvinceState();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the provinceState attribute.
     * 
     * @param newProvinceState
     *     The new value of provinceState.
     * @generated
     */
    public void setProvinceState( String newProvinceState ) throws Exception {
        metaDataMap.put("ProvinceState", newProvinceState);

        if (newProvinceState == null || newProvinceState.equals("")) {
            newProvinceState = null;


        }
        eObjXVehicleAddress.setProvinceState( newProvinceState );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the vehicleId attribute.
     * 
     * @generated
     */
    public String getVehicleId (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXVehicleAddress.getVehicleId());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the vehicleId attribute.
     * 
     * @param newVehicleId
     *     The new value of vehicleId.
     * @generated
     */
    public void setVehicleId( String newVehicleId ) throws Exception {
        metaDataMap.put("VehicleId", newVehicleId);

        if (newVehicleId == null || newVehicleId.equals("")) {
            newVehicleId = null;


        }
        eObjXVehicleAddress.setVehicleId( DWLFunctionUtils.getLongFromString(newVehicleId) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the contId attribute.
     * 
     * @generated
     */
    public String getContId (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXVehicleAddress.getContId());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the contId attribute.
     * 
     * @param newContId
     *     The new value of contId.
     * @generated
     */
    public void setContId( String newContId ) throws Exception {
        metaDataMap.put("ContId", newContId);

        if (newContId == null || newContId.equals("")) {
            newContId = null;


        }
        eObjXVehicleAddress.setContId( DWLFunctionUtils.getLongFromString(newContId) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the sourceIdentifierType attribute.
     * 
     * @generated
     */
    public String getSourceIdentifierType (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXVehicleAddress.getSourceIdentifier());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the sourceIdentifierType attribute.
     * 
     * @param newSourceIdentifierType
     *     The new value of sourceIdentifierType.
     * @generated
     */
    public void setSourceIdentifierType( String newSourceIdentifierType ) throws Exception {
        metaDataMap.put("SourceIdentifierType", newSourceIdentifierType);

        if (newSourceIdentifierType == null || newSourceIdentifierType.equals("")) {
            newSourceIdentifierType = null;


        }
        eObjXVehicleAddress.setSourceIdentifier( DWLFunctionUtils.getLongFromString(newSourceIdentifierType) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the sourceIdentifierValue attribute.
     * 
     * @generated
     */
    public String getSourceIdentifierValue (){
      return sourceIdentifierValue;
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the sourceIdentifierValue attribute.
     * 
     * @param newSourceIdentifierValue
     *     The new value of sourceIdentifierValue.
     * @generated
     */
    public void setSourceIdentifierValue( String newSourceIdentifierValue ) throws Exception {
        metaDataMap.put("SourceIdentifierValue", newSourceIdentifierValue);

        if (newSourceIdentifierValue == null || newSourceIdentifierValue.equals("")) {
            newSourceIdentifierValue = null;


        }
        sourceIdentifierValue = newSourceIdentifierValue;
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the startDate attribute.
     * 
     * @generated
     */
    public String getStartDate (){
   
        return DWLFunctionUtils.getStringFromTimestamp(eObjXVehicleAddress.getStartDate());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the startDate attribute.
     * 
     * @param newStartDate
     *     The new value of startDate.
     * @generated
     */
    public void setStartDate( String newStartDate ) throws Exception {
        metaDataMap.put("StartDate", newStartDate);
       	isValidStartDate = true;

        if (newStartDate == null || newStartDate.equals("")) {
            newStartDate = null;
            eObjXVehicleAddress.setStartDate(null);


        }
    else {
        	if (DateValidator.validates(newStartDate)) {
           		eObjXVehicleAddress.setStartDate(DateFormatter.getStartDateTimestamp(newStartDate));
            	metaDataMap.put("StartDate", getStartDate());
        	} else {
            	if (Configuration.getConfiguration().getConfigItem(
              "/IBM/DWLCommonServices/InternalValidation/enabled").getBooleanValue()) {
                	if (metaDataMap.get("StartDate") != null) {
                    	metaDataMap.put("StartDate", "");
                	}
                	isValidStartDate = false;
                	eObjXVehicleAddress.setStartDate(null);
            	}
        	}
        }
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the lastModifiedSystemDate attribute.
     * 
     * @generated
     */
    public String getLastModifiedSystemDate (){
   
        return DWLFunctionUtils.getStringFromTimestamp(eObjXVehicleAddress.getLastModifiedSystemDate());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the lastModifiedSystemDate attribute.
     * 
     * @param newLastModifiedSystemDate
     *     The new value of lastModifiedSystemDate.
     * @generated
     */
    public void setLastModifiedSystemDate( String newLastModifiedSystemDate ) throws Exception {
        metaDataMap.put("LastModifiedSystemDate", newLastModifiedSystemDate);
       	isValidLastModifiedSystemDate = true;

        if (newLastModifiedSystemDate == null || newLastModifiedSystemDate.equals("")) {
            newLastModifiedSystemDate = null;
            eObjXVehicleAddress.setLastModifiedSystemDate(null);


        }
    else {
        	if (DateValidator.validates(newLastModifiedSystemDate)) {
           		eObjXVehicleAddress.setLastModifiedSystemDate(DateFormatter.getStartDateTimestamp(newLastModifiedSystemDate));
            	metaDataMap.put("LastModifiedSystemDate", getLastModifiedSystemDate());
        	} else {
            	if (Configuration.getConfiguration().getConfigItem(
              "/IBM/DWLCommonServices/InternalValidation/enabled").getBooleanValue()) {
                	if (metaDataMap.get("LastModifiedSystemDate") != null) {
                    	metaDataMap.put("LastModifiedSystemDate", "");
                	}
                	isValidLastModifiedSystemDate = false;
                	eObjXVehicleAddress.setLastModifiedSystemDate(null);
            	}
        	}
        }
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateTxId attribute.
     *
     * @generated
     */
    public String getXVehicleAddressLastUpdateTxId() {
        return DWLFunctionUtils.getStringFromLong(eObjXVehicleAddress.getLastUpdateTxId());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateUser attribute.
     *
     * @generated
     */
    public String getXVehicleAddressLastUpdateUser() {
        return eObjXVehicleAddress.getLastUpdateUser();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateDt attribute.
     *
     * @generated
     */
    public String getXVehicleAddressLastUpdateDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXVehicleAddress.getLastUpdateDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateTxId attribute.
     *
     * @param newLastUpdateTxId
     *     The new value of LastUpdateTxId.
     * @generated
     */
    public void setXVehicleAddressLastUpdateTxId(String newLastUpdateTxId) {
        metaDataMap.put("XVehicleAddressLastUpdateTxId", newLastUpdateTxId);

        if ((newLastUpdateTxId == null) || newLastUpdateTxId.equals("")) {
            newLastUpdateTxId = null;
        }
        eObjXVehicleAddress.setLastUpdateTxId(DWLFunctionUtils.getLongFromString(newLastUpdateTxId));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateUser attribute.
     *
     * @param newLastUpdateUser
     *     The new value of LastUpdateUser.
     * @generated
     */
    public void setXVehicleAddressLastUpdateUser(String newLastUpdateUser) {
        metaDataMap.put("XVehicleAddressLastUpdateUser", newLastUpdateUser);

        if ((newLastUpdateUser == null) || newLastUpdateUser.equals("")) {
            newLastUpdateUser = null;
        }
        eObjXVehicleAddress.setLastUpdateUser(newLastUpdateUser);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateDt attribute.
     *
     * @param newLastUpdateDt
     *     The new value of LastUpdateDt.
     * @throws Exception
     * @generated
     */
    public void setXVehicleAddressLastUpdateDate(String newLastUpdateDt) throws Exception {
        metaDataMap.put("XVehicleAddressLastUpdateDate", newLastUpdateDt);

        if ((newLastUpdateDt == null) || newLastUpdateDt.equals("")) {
            newLastUpdateDt = null;
        }

        eObjXVehicleAddress.setLastUpdateDt(DWLFunctionUtils.getTimestampFromTimestampString(newLastUpdateDt));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XVehicleAddressHistActionCode history attribute.
     *
     * @generated
     */
    public String getXVehicleAddressHistActionCode() {
        return eObjXVehicleAddress.getHistActionCode();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XVehicleAddressHistActionCode history attribute.
     *
     * @param aXVehicleAddressHistActionCode
     *     The new value of XVehicleAddressHistActionCode.
     * @generated
     */
    public void setXVehicleAddressHistActionCode(String aXVehicleAddressHistActionCode) {
        metaDataMap.put("XVehicleAddressHistActionCode", aXVehicleAddressHistActionCode);

        if ((aXVehicleAddressHistActionCode == null) || aXVehicleAddressHistActionCode.equals("")) {
            aXVehicleAddressHistActionCode = null;
        }
        eObjXVehicleAddress.setHistActionCode(aXVehicleAddressHistActionCode);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XVehicleAddressHistCreateDate history attribute.
     *
     * @generated
     */
    public String getXVehicleAddressHistCreateDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXVehicleAddress.getHistCreateDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XVehicleAddressHistCreateDate history attribute.
     *
     * @param aXVehicleAddressHistCreateDate
     *     The new value of XVehicleAddressHistCreateDate.
     * @generated
     */
    public void setXVehicleAddressHistCreateDate(String aXVehicleAddressHistCreateDate) throws Exception{
        metaDataMap.put("XVehicleAddressHistCreateDate", aXVehicleAddressHistCreateDate);

        if ((aXVehicleAddressHistCreateDate == null) || aXVehicleAddressHistCreateDate.equals("")) {
            aXVehicleAddressHistCreateDate = null;
        }

        eObjXVehicleAddress.setHistCreateDt(DWLFunctionUtils.getTimestampFromTimestampString(aXVehicleAddressHistCreateDate));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XVehicleAddressHistCreatedBy history attribute.
     *
     * @generated
     */
    public String getXVehicleAddressHistCreatedBy() {
        return eObjXVehicleAddress.getHistCreatedBy();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XVehicleAddressHistCreatedBy history attribute.
     *
     * @param aXVehicleAddressHistCreatedBy
     *     The new value of XVehicleAddressHistCreatedBy.
     * @generated
     */
    public void setXVehicleAddressHistCreatedBy(String aXVehicleAddressHistCreatedBy) {
        metaDataMap.put("XVehicleAddressHistCreatedBy", aXVehicleAddressHistCreatedBy);

        if ((aXVehicleAddressHistCreatedBy == null) || aXVehicleAddressHistCreatedBy.equals("")) {
            aXVehicleAddressHistCreatedBy = null;
        }

        eObjXVehicleAddress.setHistCreatedBy(aXVehicleAddressHistCreatedBy);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XVehicleAddressHistEndDate history attribute.
     *
     * @generated
     */
    public String getXVehicleAddressHistEndDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXVehicleAddress.getHistEndDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XVehicleAddressHistEndDate history attribute.
     *
     * @param aXVehicleAddressHistEndDate
     *     The new value of XVehicleAddressHistEndDate.
     * @generated
     */
    public void setXVehicleAddressHistEndDate(String aXVehicleAddressHistEndDate) throws Exception{
        metaDataMap.put("XVehicleAddressHistEndDate", aXVehicleAddressHistEndDate);

        if ((aXVehicleAddressHistEndDate == null) || aXVehicleAddressHistEndDate.equals("")) {
            aXVehicleAddressHistEndDate = null;
        }
        eObjXVehicleAddress.setHistEndDt(DWLFunctionUtils.getTimestampFromTimestampString(aXVehicleAddressHistEndDate));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XVehicleAddressHistoryIdPK history attribute.
     *
     * @generated
     */
    public String getXVehicleAddressHistoryIdPK() {
        return DWLFunctionUtils.getStringFromLong(eObjXVehicleAddress.getHistoryIdPK());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XVehicleAddressHistoryIdPK history attribute.
     *
     * @param aXVehicleAddressHistoryIdPK
     *     The new value of XVehicleAddressHistoryIdPK.
     * @generated
     */
    public void setXVehicleAddressHistoryIdPK(String aXVehicleAddressHistoryIdPK) {
        metaDataMap.put("XVehicleAddressHistoryIdPK", aXVehicleAddressHistoryIdPK);

        if ((aXVehicleAddressHistoryIdPK == null) || aXVehicleAddressHistoryIdPK.equals("")) {
            aXVehicleAddressHistoryIdPK = null;
        }
        eObjXVehicleAddress.setHistoryIdPK(DWLFunctionUtils.getLongFromString(aXVehicleAddressHistoryIdPK));
    }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation during an add transaction.
     *
     * @generated
     */
    public DWLStatus validateAdd(int level, DWLStatus status) throws Exception {

        status = super.validateAdd(level, status);
        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0038I Add any controller-level custom validation logic to be
            // executed for this object during an "add" transaction

        }

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            // MDM_TODO0: CDKWB0039I Add any component-level custom validation logic to be
            // executed for this object during an "add" transaction
        }
        status = getValidationStatus(level, status);
        return status;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation during an update transaction.
     *
     * @generated
     */
    public DWLStatus validateUpdate(int level, DWLStatus status) throws Exception {
    logger.finest("ENTER validateUpdate(int level, DWLStatus status)");

        status = super.validateUpdate(level, status);
        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0040I Add any controller-level custom validation logic to be
            // executed for this object during an "update" transaction

            if (eObjXVehicleAddress.getVehicleAddresspkId() == null) {
                DWLError err = new DWLError();
                //err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XVEHICLE_ADDRESS_BOBJ).longValue());
                //err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.XVEHICLEADDRESS_VEHICLEADDRESSPKID_NULL).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                	String infoForLogging="Error: Validation error occured for update. No primary key for entity XVehicleAddress, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("validateUpdate(int level, DWLStatus status) " + infoForLogging);
                }
                status.addError(err);
            }
            if (eObjXVehicleAddress.getLastUpdateDt() == null) {
                DWLError err = new DWLError();
                //err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XVEHICLE_ADDRESS_BOBJ).longValue());
                err.setReasonCode(new Long(DWLUtilErrorReasonCode.LAST_UPDATED_DATE_NULL).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
                if (logger.isFinestEnabled()) {
                	String infoForLogging="Error: Validation error occured for update. No last update date for entity XVehicleAddress, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("validateUpdate(int level, DWLStatus status) " + infoForLogging);
                }
                status.addError(err);
            }
        }

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            assignBeforeImageValues(metaDataMap);
            
            // MDM_TODO0: CDKWB0041I Add any component-level custom validation logic to be
            // executed for this object during an "update" transaction
        }
        status = getValidationStatus(level, status);
    if (logger.isFinestEnabled()) {
        	String returnValue = status.toString();
      logger.finest("RETURN validateUpdate(int level, DWLStatus status) " + returnValue);
    }
        return status;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Populate the before image of this business object.
     *
     * @see com.dwl.base.DWLCommon#populateBeforeImage()
     * @generated
     */
    public void populateBeforeImage() throws DWLBaseException {
    logger.finest("ENTER populateBeforeImage()");

        DSEAAdditionsExts comp = null;
        try {
        
      comp = (DSEAAdditionsExts)TCRMClassFactory.getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
        	
        } catch (Exception e) {
      if (logger.isFinestEnabled()) {
        String infoForLogging="Error: Fatal error while updating record " + e.getMessage();
      logger.finest("populateBeforeImage() " + infoForLogging);
      }
            /*DWLExceptionUtils.throwDWLBaseException(e, 
            									new DWLUpdateException(e.getMessage()), 
            									this.getStatus(), DWLStatus.FATAL,
                                  DSEAAdditionsExtsComponentID.XVEHICLE_ADDRESS_BOBJ, 
                                  "DIERR",
                                  DSEAAdditionsExtsErrorReasonCode.XVEHICLEADDRESS_BEFORE_IMAGE_NOT_POPULATED, 
                                  this.getControl());
                                  */
        }
        
        //comp.loadBeforeImage(this);
   // logger.finest("RETURN populateBeforeImage()");
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation common to both add and update transactions.
     *
     * @generated
     */
     
    private DWLStatus getValidationStatus(int level, DWLStatus status) throws Exception {
    logger.finest("ENTER getValidationStatus(int level, DWLStatus status)");

        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0034I Add any common controller-level custom validation
            // logic to be executed for this object during either "add" or
            // "update" transactions
    		controllerValidation_SourceIdentifier(status);
    		controllerValidation_StartDate(status);
    		controllerValidation_LastModifiedSystemDate(status);
    	}

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            // MDM_TODO0: CDKWB0035I Add any common component-level custom validation logic
            // to be executed for this object during either "add" or "update"
            // transactions
    		componentValidation_SourceIdentifier(status);
    		componentValidation_StartDate(status);
    		componentValidation_LastModifiedSystemDate(status);
        }
        
        if (logger.isFinestEnabled()) {
            String returnValue = status.toString();
      logger.finest("RETURN getValidationStatus(int level, DWLStatus status) " + returnValue);
        }
    
        return status;
    }

    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "SourceIdentifier"
     *
     * @generated
     */
	private void componentValidation_SourceIdentifier(DWLStatus status) {
  
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "StartDate"
     *
     * @generated
     */
	private void componentValidation_StartDate(DWLStatus status) {
  
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "LastModifiedSystemDate"
     *
     * @generated
     */
	private void componentValidation_LastModifiedSystemDate(DWLStatus status) {
  
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "SourceIdentifier"
     *
     * @generated
     */
	private void controllerValidation_SourceIdentifier(DWLStatus status) throws Exception {
  
      //persistent code type
            boolean isSourceIdentifierNull = false;
            if ((eObjXVehicleAddress.getSourceIdentifier() == null) &&
               ((getSourceIdentifierValue() == null) || 
                 getSourceIdentifierValue().trim().equals(""))) {
                isSourceIdentifierNull = true;
            }
            if (!isSourceIdentifierNull) {
                if (checkForInvalidXvehicleaddressSourceidentifier()) {
                    DWLError err = new DWLError();
                  //  err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XVEHICLE_ADDRESS_BOBJ).longValue());
                    //err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XVEHICLEADDRESS_SOURCEIDENTIFIER).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                    String infoForLogging="Error: Custom validation error occured for entity XVehicleAddress, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("controllerValidation_SourceIdentifier " + infoForLogging);
        }
                status.addError(err);
            }

             }
    			
    	}
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "StartDate"
     *
     * @generated
     */
	private void controllerValidation_StartDate(DWLStatus status) throws Exception {
  
            boolean isStartDateNull = (eObjXVehicleAddress.getStartDate() == null);
            if (!isValidStartDate) {
              	DWLError err = new DWLError();
               //	err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XVEHICLE_ADDRESS_BOBJ).longValue());
               	// err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XVEHICLEADDRESS_STARTDATE).longValue());
               	err.setErrorType(DWLErrorCode.DATA_INVALID_ERROR);
                String infoForLogging="Error: Validation error. Invalid time specified on property StartDate in entity XVehicleAddress, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode();
      logger.finest("controllerValidation_StartDate " + infoForLogging);
               	status.addError(err);
            } 
    	}
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "LastModifiedSystemDate"
     *
     * @generated
     */
	private void controllerValidation_LastModifiedSystemDate(DWLStatus status) throws Exception {
  
            boolean isLastModifiedSystemDateNull = (eObjXVehicleAddress.getLastModifiedSystemDate() == null);
            if (!isValidLastModifiedSystemDate) {
              	DWLError err = new DWLError();
               	//err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XVEHICLE_ADDRESS_BOBJ).longValue());
               	//err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XVEHICLEADDRESS_LASTMODIFIEDSYSTEMDATE).longValue());
               	err.setErrorType(DWLErrorCode.DATA_INVALID_ERROR);
                String infoForLogging="Error: Validation error. Invalid time specified on property LastModifiedSystemDate in entity XVehicleAddress, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode();
      logger.finest("controllerValidation_LastModifiedSystemDate " + infoForLogging);
               	status.addError(err);
            } 
    	}
    private DWLError createDWLError(String entityName, String propertyName,String reasonCode){	
		DWLError err = new DWLError();
		//err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XVEHICLE_ADDRESS_BOBJ).longValue());
		err.setReasonCode(new Long(reasonCode).longValue());
		err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
			String infoForLogging="Error: Validation error occured. Property " + propertyName + " is null, in entity " + entityName + ", component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
			logger.finest("createDWLError " + infoForLogging);
		}
		return err;
    }
    
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Check the value of the field SourceIdentifier and return true if the
     * error reason INVALID_XVEHICLEADDRESS_SOURCEIDENTIFIER should be returned.
     *
     * @generated
  **/
	private boolean checkForInvalidXvehicleaddressSourceidentifier() throws Exception {
    logger.finest("ENTER checkForInvalidXvehicleaddressSourceidentifier()");
        boolean notValid = false;
      	String langId = (String) this.getControl().get(DWLControlKeys.LANG_ID);
      	CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
    Long codeType = DWLFunctionUtils.getLongFromString( getSourceIdentifierType() );
    String codeValue = getSourceIdentifierValue();
    if( codeValue != null && codeValue.trim().equals("")){
      codeValue = null;
    }
     
        if ( codeType != null && codeValue == null ){

             if( codeTypeCompHelper.isCodeValid("cdsourceidenttp", langId, getSourceIdentifierType(),
                 CodeTypeComponentHelper.ACTIVE, getControl())) {
                 CodeTypeBObj ctBObj = codeTypeCompHelper
                 					.getCodeTypeByCode("cdsourceidenttp", langId, getSourceIdentifierType(),
                         								getControl());
               	if (ctBObj != null) {
                   	setSourceIdentifierValue( ctBObj.getvalue() );
               	}
             }
             else{
             	if (logger.isFinestEnabled()) {
              	 	String infoForLogging="NotValid 1";
      logger.finest("checkForInvalidXvehicleaddressSourceidentifier() " + infoForLogging);
        }
                 notValid = true;
           }
        }
        else if (codeType == null && codeValue != null ){
          
             CodeTypeBObj ctBObj = codeTypeCompHelper
                      .getCodeTypeByValue("cdsourceidenttp", langId, codeValue,
                                 getControl());

             if (ctBObj != null) {
                 setSourceIdentifierType(ctBObj.gettp_cd());
             } 
             else {
             	if (logger.isFinestEnabled()) {
              	  	String infoForLogging="NotValid 2";
      logger.finest("checkForInvalidXvehicleaddressSourceidentifier() " + infoForLogging);
        }
                  notValid = true;
             }
        }
        else if ( codeType != null && codeValue != null
             && !codeTypeCompHelper.isCodeValuePairValid("cdsourceidenttp", langId, getSourceIdentifierType(), 
                     new String[] { codeValue }, CodeTypeComponentHelper.ACTIVE, getControl())) {	
       if (logger.isFinestEnabled()) {
       		String infoForLogging="NotValid 3";
      logger.finest("checkForInvalidXvehicleaddressSourceidentifier() " + infoForLogging);
       }
             notValid = true;
        }
        if (logger.isFinestEnabled()) {
      String returnValue ="" +notValid;
      logger.finest("RETURN checkForInvalidXvehicleaddressSourceidentifier() " + returnValue);
    }
    return notValid;
     } 
				 



}

