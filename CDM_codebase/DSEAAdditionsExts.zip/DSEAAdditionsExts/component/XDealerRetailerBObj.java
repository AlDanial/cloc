
/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[3cdf62d0fe658c8c88594df2b69de8af]
 */

package com.ibm.daimler.dsea.component;

import com.dwl.tcrm.common.TCRMCommon;



import com.dwl.base.DWLControl;

import com.dwl.base.constant.DWLUtilErrorReasonCode;

import com.dwl.base.error.DWLError;
import com.dwl.base.error.DWLErrorCode;
import com.dwl.base.error.DWLStatus;

import com.dwl.base.exception.DWLBaseException;
import com.dwl.base.exception.DWLUpdateException;

import com.dwl.base.util.DWLExceptionUtils;
import com.dwl.base.util.DWLFunctionUtils;

import com.dwl.tcrm.common.ITCRMValidation;

import com.dwl.tcrm.utilities.TCRMClassFactory;

import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsComponentID;
import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsErrorReasonCode;
import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsPropertyKeys;

import com.ibm.daimler.dsea.entityObject.EObjXDealerRetailer;

import com.ibm.daimler.dsea.interfaces.DSEAAdditionsExts;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * This class provides the implementation of the business object
 * <code>XDealerRetailerBObj</code>.
 * 
 * @see com.dwl.tcrm.common.TCRMCommon
 * @generated
 */
 

@SuppressWarnings("serial")
public class XDealerRetailerBObj extends TCRMCommon  {

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected EObjXDealerRetailer eObjXDealerRetailer;
	/**
    * <!-- begin-user-doc -->
	  * <!-- end-user-doc -->
    * @generated 
    */
	 private final static com.dwl.base.logging.IDWLLogger logger = com.dwl.base.logging.DWLLoggerManager.getLogger(XDealerRetailerBObj.class);
		
 


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */     
    public XDealerRetailerBObj() {
        super();
        init();
        eObjXDealerRetailer = new EObjXDealerRetailer();
        setComponentID(DSEAAdditionsExtsComponentID.XDEALER_RETAILER_BOBJ);
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Initializes the fields required to populate the metaDataMap. Each key is
     * an element-level field of the business object.
     *
     * @generated
     */
    private void init() {
        metaDataMap.put("XDealerRetailerpkId", null);
        metaDataMap.put("DealerCode", null);
        metaDataMap.put("RetailerCode", null);
        metaDataMap.put("XDealerRetailerHistActionCode", null);
        metaDataMap.put("XDealerRetailerHistCreateDate", null);
        metaDataMap.put("XDealerRetailerHistCreatedBy", null);
        metaDataMap.put("XDealerRetailerHistEndDate", null);
        metaDataMap.put("XDealerRetailerHistoryIdPK", null);
        metaDataMap.put("XDealerRetailerLastUpdateDate", null);
        metaDataMap.put("XDealerRetailerLastUpdateTxId", null);
        metaDataMap.put("XDealerRetailerLastUpdateUser", null);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Refreshes all the attributes this business object supports.
     *
     * @see com.dwl.base.DWLCommon#refreshMap()
     * @generated
     */
    public void refreshMap() {

        if (bRequireMapRefresh) {
            super.refreshMap();
            metaDataMap.put("XDealerRetailerpkId", getXDealerRetailerpkId());
            metaDataMap.put("DealerCode", getDealerCode());
            metaDataMap.put("RetailerCode", getRetailerCode());
            metaDataMap.put("XDealerRetailerHistActionCode", getXDealerRetailerHistActionCode());
            metaDataMap.put("XDealerRetailerHistCreateDate", getXDealerRetailerHistCreateDate());
            metaDataMap.put("XDealerRetailerHistCreatedBy", getXDealerRetailerHistCreatedBy());
            metaDataMap.put("XDealerRetailerHistEndDate", getXDealerRetailerHistEndDate());
            metaDataMap.put("XDealerRetailerHistoryIdPK", getXDealerRetailerHistoryIdPK());
            metaDataMap.put("XDealerRetailerLastUpdateDate", getXDealerRetailerLastUpdateDate());
            metaDataMap.put("XDealerRetailerLastUpdateTxId", getXDealerRetailerLastUpdateTxId());
            metaDataMap.put("XDealerRetailerLastUpdateUser", getXDealerRetailerLastUpdateUser());
            bRequireMapRefresh = false;
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the control object on this business object.
     *
     * @see com.dwl.base.DWLCommon#setControl(DWLControl)
     * @generated
     */
    public void setControl(DWLControl newDWLControl) {
        super.setControl(newDWLControl);

        if (eObjXDealerRetailer != null) {
            eObjXDealerRetailer.setControl(newDWLControl);
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the entity object associated with this business object.
     *
     * @generated
     */
    public EObjXDealerRetailer getEObjXDealerRetailer() {
        bRequireMapRefresh = true;
        return eObjXDealerRetailer;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the entity object associated with this business object.
     *
     * @param eObjXDealerRetailer
     *            The eObjXDealerRetailer to set.
     * @generated
     */
    public void setEObjXDealerRetailer(EObjXDealerRetailer eObjXDealerRetailer) {
        bRequireMapRefresh = true;
        this.eObjXDealerRetailer = eObjXDealerRetailer;
        if (this.eObjXDealerRetailer != null && this.eObjXDealerRetailer.getControl() == null) {
            DWLControl control = this.getControl();
            if (control != null) {
                this.eObjXDealerRetailer.setControl(control);
            }
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xDealerRetailerpkId attribute.
     * 
     * @generated
     */
    public String getXDealerRetailerpkId (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXDealerRetailer.getXDealerRetailerpkId());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xDealerRetailerpkId attribute.
     * 
     * @param newXDealerRetailerpkId
     *     The new value of xDealerRetailerpkId.
     * @generated
     */
    public void setXDealerRetailerpkId( String newXDealerRetailerpkId ) throws Exception {
        metaDataMap.put("XDealerRetailerpkId", newXDealerRetailerpkId);

        if (newXDealerRetailerpkId == null || newXDealerRetailerpkId.equals("")) {
            newXDealerRetailerpkId = null;


        }
        eObjXDealerRetailer.setXDealerRetailerpkId( DWLFunctionUtils.getLongFromString(newXDealerRetailerpkId) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the dealerCode attribute.
     * 
     * @generated
     */
    public String getDealerCode (){
   
        return eObjXDealerRetailer.getDealerCode();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the dealerCode attribute.
     * 
     * @param newDealerCode
     *     The new value of dealerCode.
     * @generated
     */
    public void setDealerCode( String newDealerCode ) throws Exception {
        metaDataMap.put("DealerCode", newDealerCode);

        if (newDealerCode == null || newDealerCode.equals("")) {
            newDealerCode = null;


        }
        eObjXDealerRetailer.setDealerCode( newDealerCode );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the retailerCode attribute.
     * 
     * @generated
     */
    public String getRetailerCode (){
   
        return eObjXDealerRetailer.getRetailerCode();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the retailerCode attribute.
     * 
     * @param newRetailerCode
     *     The new value of retailerCode.
     * @generated
     */
    public void setRetailerCode( String newRetailerCode ) throws Exception {
        metaDataMap.put("RetailerCode", newRetailerCode);

        if (newRetailerCode == null || newRetailerCode.equals("")) {
            newRetailerCode = null;


        }
        eObjXDealerRetailer.setRetailerCode( newRetailerCode );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateTxId attribute.
     *
     * @generated
     */
    public String getXDealerRetailerLastUpdateTxId() {
        return DWLFunctionUtils.getStringFromLong(eObjXDealerRetailer.getLastUpdateTxId());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateUser attribute.
     *
     * @generated
     */
    public String getXDealerRetailerLastUpdateUser() {
        return eObjXDealerRetailer.getLastUpdateUser();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateDt attribute.
     *
     * @generated
     */
    public String getXDealerRetailerLastUpdateDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXDealerRetailer.getLastUpdateDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateTxId attribute.
     *
     * @param newLastUpdateTxId
     *     The new value of LastUpdateTxId.
     * @generated
     */
    public void setXDealerRetailerLastUpdateTxId(String newLastUpdateTxId) {
        metaDataMap.put("XDealerRetailerLastUpdateTxId", newLastUpdateTxId);

        if ((newLastUpdateTxId == null) || newLastUpdateTxId.equals("")) {
            newLastUpdateTxId = null;
        }
        eObjXDealerRetailer.setLastUpdateTxId(DWLFunctionUtils.getLongFromString(newLastUpdateTxId));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateUser attribute.
     *
     * @param newLastUpdateUser
     *     The new value of LastUpdateUser.
     * @generated
     */
    public void setXDealerRetailerLastUpdateUser(String newLastUpdateUser) {
        metaDataMap.put("XDealerRetailerLastUpdateUser", newLastUpdateUser);

        if ((newLastUpdateUser == null) || newLastUpdateUser.equals("")) {
            newLastUpdateUser = null;
        }
        eObjXDealerRetailer.setLastUpdateUser(newLastUpdateUser);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateDt attribute.
     *
     * @param newLastUpdateDt
     *     The new value of LastUpdateDt.
     * @throws Exception
     * @generated
     */
    public void setXDealerRetailerLastUpdateDate(String newLastUpdateDt) throws Exception {
        metaDataMap.put("XDealerRetailerLastUpdateDate", newLastUpdateDt);

        if ((newLastUpdateDt == null) || newLastUpdateDt.equals("")) {
            newLastUpdateDt = null;
        }

        eObjXDealerRetailer.setLastUpdateDt(DWLFunctionUtils.getTimestampFromTimestampString(newLastUpdateDt));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XDealerRetailerHistActionCode history attribute.
     *
     * @generated
     */
    public String getXDealerRetailerHistActionCode() {
        return eObjXDealerRetailer.getHistActionCode();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XDealerRetailerHistActionCode history attribute.
     *
     * @param aXDealerRetailerHistActionCode
     *     The new value of XDealerRetailerHistActionCode.
     * @generated
     */
    public void setXDealerRetailerHistActionCode(String aXDealerRetailerHistActionCode) {
        metaDataMap.put("XDealerRetailerHistActionCode", aXDealerRetailerHistActionCode);

        if ((aXDealerRetailerHistActionCode == null) || aXDealerRetailerHistActionCode.equals("")) {
            aXDealerRetailerHistActionCode = null;
        }
        eObjXDealerRetailer.setHistActionCode(aXDealerRetailerHistActionCode);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XDealerRetailerHistCreateDate history attribute.
     *
     * @generated
     */
    public String getXDealerRetailerHistCreateDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXDealerRetailer.getHistCreateDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XDealerRetailerHistCreateDate history attribute.
     *
     * @param aXDealerRetailerHistCreateDate
     *     The new value of XDealerRetailerHistCreateDate.
     * @generated
     */
    public void setXDealerRetailerHistCreateDate(String aXDealerRetailerHistCreateDate) throws Exception{
        metaDataMap.put("XDealerRetailerHistCreateDate", aXDealerRetailerHistCreateDate);

        if ((aXDealerRetailerHistCreateDate == null) || aXDealerRetailerHistCreateDate.equals("")) {
            aXDealerRetailerHistCreateDate = null;
        }

        eObjXDealerRetailer.setHistCreateDt(DWLFunctionUtils.getTimestampFromTimestampString(aXDealerRetailerHistCreateDate));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XDealerRetailerHistCreatedBy history attribute.
     *
     * @generated
     */
    public String getXDealerRetailerHistCreatedBy() {
        return eObjXDealerRetailer.getHistCreatedBy();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XDealerRetailerHistCreatedBy history attribute.
     *
     * @param aXDealerRetailerHistCreatedBy
     *     The new value of XDealerRetailerHistCreatedBy.
     * @generated
     */
    public void setXDealerRetailerHistCreatedBy(String aXDealerRetailerHistCreatedBy) {
        metaDataMap.put("XDealerRetailerHistCreatedBy", aXDealerRetailerHistCreatedBy);

        if ((aXDealerRetailerHistCreatedBy == null) || aXDealerRetailerHistCreatedBy.equals("")) {
            aXDealerRetailerHistCreatedBy = null;
        }

        eObjXDealerRetailer.setHistCreatedBy(aXDealerRetailerHistCreatedBy);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XDealerRetailerHistEndDate history attribute.
     *
     * @generated
     */
    public String getXDealerRetailerHistEndDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXDealerRetailer.getHistEndDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XDealerRetailerHistEndDate history attribute.
     *
     * @param aXDealerRetailerHistEndDate
     *     The new value of XDealerRetailerHistEndDate.
     * @generated
     */
    public void setXDealerRetailerHistEndDate(String aXDealerRetailerHistEndDate) throws Exception{
        metaDataMap.put("XDealerRetailerHistEndDate", aXDealerRetailerHistEndDate);

        if ((aXDealerRetailerHistEndDate == null) || aXDealerRetailerHistEndDate.equals("")) {
            aXDealerRetailerHistEndDate = null;
        }
        eObjXDealerRetailer.setHistEndDt(DWLFunctionUtils.getTimestampFromTimestampString(aXDealerRetailerHistEndDate));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XDealerRetailerHistoryIdPK history attribute.
     *
     * @generated
     */
    public String getXDealerRetailerHistoryIdPK() {
        return DWLFunctionUtils.getStringFromLong(eObjXDealerRetailer.getHistoryIdPK());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XDealerRetailerHistoryIdPK history attribute.
     *
     * @param aXDealerRetailerHistoryIdPK
     *     The new value of XDealerRetailerHistoryIdPK.
     * @generated
     */
    public void setXDealerRetailerHistoryIdPK(String aXDealerRetailerHistoryIdPK) {
        metaDataMap.put("XDealerRetailerHistoryIdPK", aXDealerRetailerHistoryIdPK);

        if ((aXDealerRetailerHistoryIdPK == null) || aXDealerRetailerHistoryIdPK.equals("")) {
            aXDealerRetailerHistoryIdPK = null;
        }
        eObjXDealerRetailer.setHistoryIdPK(DWLFunctionUtils.getLongFromString(aXDealerRetailerHistoryIdPK));
    }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation during an add transaction.
     *
     * @generated
     */
    public DWLStatus validateAdd(int level, DWLStatus status) throws Exception {

        status = super.validateAdd(level, status);
        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0038I Add any controller-level custom validation logic to be
            // executed for this object during an "add" transaction

        }

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            // MDM_TODO0: CDKWB0039I Add any component-level custom validation logic to be
            // executed for this object during an "add" transaction
        }
        status = getValidationStatus(level, status);
        return status;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation during an update transaction.
     *
     * @generated
     */
    public DWLStatus validateUpdate(int level, DWLStatus status) throws Exception {
    logger.finest("ENTER validateUpdate(int level, DWLStatus status)");

        status = super.validateUpdate(level, status);
        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0040I Add any controller-level custom validation logic to be
            // executed for this object during an "update" transaction

            if (eObjXDealerRetailer.getXDealerRetailerpkId() == null) {
                DWLError err = new DWLError();
                err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XDEALER_RETAILER_BOBJ).longValue());
                err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.XDEALERRETAILER_XDEALERRETAILERPKID_NULL).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                	String infoForLogging="Error: Validation error occured for update. No primary key for entity XDealerRetailer, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("validateUpdate(int level, DWLStatus status) " + infoForLogging);
                }
                status.addError(err);
            }
            if (eObjXDealerRetailer.getLastUpdateDt() == null) {
                DWLError err = new DWLError();
                err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XDEALER_RETAILER_BOBJ).longValue());
                err.setReasonCode(new Long(DWLUtilErrorReasonCode.LAST_UPDATED_DATE_NULL).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
                if (logger.isFinestEnabled()) {
                	String infoForLogging="Error: Validation error occured for update. No last update date for entity XDealerRetailer, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("validateUpdate(int level, DWLStatus status) " + infoForLogging);
                }
                status.addError(err);
            }
        }

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            assignBeforeImageValues(metaDataMap);
            
            // MDM_TODO0: CDKWB0041I Add any component-level custom validation logic to be
            // executed for this object during an "update" transaction
        }
        status = getValidationStatus(level, status);
    if (logger.isFinestEnabled()) {
        	String returnValue = status.toString();
      logger.finest("RETURN validateUpdate(int level, DWLStatus status) " + returnValue);
    }
        return status;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Populate the before image of this business object.
     *
     * @see com.dwl.base.DWLCommon#populateBeforeImage()
     * @generated
     */
    public void populateBeforeImage() throws DWLBaseException {
    logger.finest("ENTER populateBeforeImage()");

        DSEAAdditionsExts comp = null;
        try {
        
      comp = (DSEAAdditionsExts)TCRMClassFactory.getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
        	
        } catch (Exception e) {
      if (logger.isFinestEnabled()) {
        String infoForLogging="Error: Fatal error while updating record " + e.getMessage();
      logger.finest("populateBeforeImage() " + infoForLogging);
      }
            DWLExceptionUtils.throwDWLBaseException(e, 
            									new DWLUpdateException(e.getMessage()), 
            									this.getStatus(), DWLStatus.FATAL,
                                  DSEAAdditionsExtsComponentID.XDEALER_RETAILER_BOBJ, 
                                  "DIERR",
                                  DSEAAdditionsExtsErrorReasonCode.XDEALERRETAILER_BEFORE_IMAGE_NOT_POPULATED, 
                                  this.getControl());
        }
        
        comp.loadBeforeImage(this);
    logger.finest("RETURN populateBeforeImage()");
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation common to both add and update transactions.
     *
     * @generated
     */
     
    private DWLStatus getValidationStatus(int level, DWLStatus status) throws Exception {
    logger.finest("ENTER getValidationStatus(int level, DWLStatus status)");

        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0034I Add any common controller-level custom validation
            // logic to be executed for this object during either "add" or
            // "update" transactions
    	}

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            // MDM_TODO0: CDKWB0035I Add any common component-level custom validation logic
            // to be executed for this object during either "add" or "update"
            // transactions
        }
        
        if (logger.isFinestEnabled()) {
            String returnValue = status.toString();
      logger.finest("RETURN getValidationStatus(int level, DWLStatus status) " + returnValue);
        }
    
        return status;
    }

    private DWLError createDWLError(String entityName, String propertyName,String reasonCode){	
		DWLError err = new DWLError();
		err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XDEALER_RETAILER_BOBJ).longValue());
		err.setReasonCode(new Long(reasonCode).longValue());
		err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
			String infoForLogging="Error: Validation error occured. Property " + propertyName + " is null, in entity " + entityName + ", component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
			logger.finest("createDWLError " + infoForLogging);
		}
		return err;
    }
    



}

