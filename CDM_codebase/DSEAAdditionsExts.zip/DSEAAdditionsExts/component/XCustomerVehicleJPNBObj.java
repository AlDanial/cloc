
/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[dbde121ae86e06776f462289c755f99b]
 */

package com.ibm.daimler.dsea.component;

import com.dwl.tcrm.common.TCRMCommon;



import com.dwl.base.DWLControl;

import com.dwl.base.constant.DWLControlKeys;
import com.dwl.base.constant.DWLUtilErrorReasonCode;

import com.dwl.base.error.DWLError;
import com.dwl.base.error.DWLErrorCode;
import com.dwl.base.error.DWLStatus;

import com.dwl.base.exception.DWLBaseException;
import com.dwl.base.exception.DWLUpdateException;

import com.dwl.base.util.DWLClassFactory;
import com.dwl.base.util.DWLExceptionUtils;
import com.dwl.base.util.DWLFunctionUtils;

import com.dwl.management.config.client.Configuration;

import com.dwl.tcrm.common.ITCRMValidation;

import com.dwl.tcrm.utilities.DateFormatter;
import com.dwl.tcrm.utilities.DateValidator;
import com.dwl.tcrm.utilities.TCRMClassFactory;

import com.ibm.daimler.dsea.component.XCustomerVehicleRoleJPNBObj;
import com.ibm.daimler.dsea.component.XVehicleJPNBObj;

import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsComponentID;
import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsErrorReasonCode;
import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsPropertyKeys;

import com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleJPN;

import com.ibm.daimler.dsea.interfaces.DSEAAdditionsExts;

import com.ibm.mdm.common.codetype.interfaces.CodeTypeComponentHelper;

import com.ibm.mdm.common.codetype.obj.CodeTypeBObj;

import java.util.Vector;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * This class provides the implementation of the business object
 * <code>XCustomerVehicleJPNBObj</code>.
 * 
 * @see com.dwl.tcrm.common.TCRMCommon
 * @generated
 */
 

@SuppressWarnings("serial")
public class XCustomerVehicleJPNBObj extends TCRMCommon  {

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected EObjXCustomerVehicleJPN eObjXCustomerVehicleJPN;
	/**
    * <!-- begin-user-doc -->
	  * <!-- end-user-doc -->
    * @generated 
    */
	 private final static com.dwl.base.logging.IDWLLogger logger = com.dwl.base.logging.DWLLoggerManager.getLogger(XCustomerVehicleJPNBObj.class);
		
 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected String connectMeUsageValue;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected String vehicleSalesValue;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected String vehicleUsageValue;
	protected boolean isValidStartDate = true;
	
	protected boolean isValidEndDate = true;
	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected String sourceIdentifierValue;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected XVehicleJPNBObj XVehicleJPNBObj;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    @SuppressWarnings("rawtypes")
    protected Vector vecXCustomerVehicleRoleJPNBObj;


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */     
    @SuppressWarnings("rawtypes")
    public XCustomerVehicleJPNBObj() {
        super();
        init();
        eObjXCustomerVehicleJPN = new EObjXCustomerVehicleJPN();
        vecXCustomerVehicleRoleJPNBObj = new Vector();
        setComponentID(DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_JPNBOBJ);
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Initializes the fields required to populate the metaDataMap. Each key is
     * an element-level field of the business object.
     *
     * @generated
     */
    private void init() {
        metaDataMap.put("XCustomerVehicleJPNpkId", null);
        metaDataMap.put("ContId", null);
        metaDataMap.put("VehicleId", null);
        metaDataMap.put("RetailerId", null);
        metaDataMap.put("ConnectMeUsageType", null);
        metaDataMap.put("ConnectMeUsageValue", null);
        metaDataMap.put("LicensePlate", null);
        metaDataMap.put("VehicleSalesType", null);
        metaDataMap.put("VehicleSalesValue", null);
        metaDataMap.put("VehicleUsageType", null);
        metaDataMap.put("VehicleUsageValue", null);
        metaDataMap.put("VehicleOwnerShip", null);
        metaDataMap.put("StartDate", null);
        metaDataMap.put("EndDate", null);
        metaDataMap.put("SourceIdentifierType", null);
        metaDataMap.put("SourceIdentifierValue", null);
        metaDataMap.put("CustVehRetFlag", null);
        metaDataMap.put("DeleteFlag", null);
        metaDataMap.put("SFDCId", null);
        metaDataMap.put("ServiceName", null);
        metaDataMap.put("XCustomerVehicleJPNHistActionCode", null);
        metaDataMap.put("XCustomerVehicleJPNHistCreateDate", null);
        metaDataMap.put("XCustomerVehicleJPNHistCreatedBy", null);
        metaDataMap.put("XCustomerVehicleJPNHistEndDate", null);
        metaDataMap.put("XCustomerVehicleJPNHistoryIdPK", null);
        metaDataMap.put("XCustomerVehicleJPNLastUpdateDate", null);
        metaDataMap.put("XCustomerVehicleJPNLastUpdateTxId", null);
        metaDataMap.put("XCustomerVehicleJPNLastUpdateUser", null);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Refreshes all the attributes this business object supports.
     *
     * @see com.dwl.base.DWLCommon#refreshMap()
     * @generated
     */
    public void refreshMap() {

        if (bRequireMapRefresh) {
            super.refreshMap();
            metaDataMap.put("XCustomerVehicleJPNpkId", getXCustomerVehicleJPNpkId());
            metaDataMap.put("ContId", getContId());
            metaDataMap.put("VehicleId", getVehicleId());
            metaDataMap.put("RetailerId", getRetailerId());
            metaDataMap.put("ConnectMeUsageType", getConnectMeUsageType());
            metaDataMap.put("ConnectMeUsageValue", getConnectMeUsageValue());
            metaDataMap.put("LicensePlate", getLicensePlate());
            metaDataMap.put("VehicleSalesType", getVehicleSalesType());
            metaDataMap.put("VehicleSalesValue", getVehicleSalesValue());
            metaDataMap.put("VehicleUsageType", getVehicleUsageType());
            metaDataMap.put("VehicleUsageValue", getVehicleUsageValue());
            metaDataMap.put("VehicleOwnerShip", getVehicleOwnerShip());
            metaDataMap.put("StartDate", getStartDate());
            metaDataMap.put("EndDate", getEndDate());
            metaDataMap.put("SourceIdentifierType", getSourceIdentifierType());
            metaDataMap.put("SourceIdentifierValue", getSourceIdentifierValue());
            metaDataMap.put("CustVehRetFlag", getCustVehRetFlag());
            metaDataMap.put("DeleteFlag", getDeleteFlag());
            metaDataMap.put("SFDCId", getSFDCId());
            metaDataMap.put("ServiceName", getServiceName());
            metaDataMap.put("XCustomerVehicleJPNHistActionCode", getXCustomerVehicleJPNHistActionCode());
            metaDataMap.put("XCustomerVehicleJPNHistCreateDate", getXCustomerVehicleJPNHistCreateDate());
            metaDataMap.put("XCustomerVehicleJPNHistCreatedBy", getXCustomerVehicleJPNHistCreatedBy());
            metaDataMap.put("XCustomerVehicleJPNHistEndDate", getXCustomerVehicleJPNHistEndDate());
            metaDataMap.put("XCustomerVehicleJPNHistoryIdPK", getXCustomerVehicleJPNHistoryIdPK());
            metaDataMap.put("XCustomerVehicleJPNLastUpdateDate", getXCustomerVehicleJPNLastUpdateDate());
            metaDataMap.put("XCustomerVehicleJPNLastUpdateTxId", getXCustomerVehicleJPNLastUpdateTxId());
            metaDataMap.put("XCustomerVehicleJPNLastUpdateUser", getXCustomerVehicleJPNLastUpdateUser());
            bRequireMapRefresh = false;
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the control object on this business object.
     *
     * @see com.dwl.base.DWLCommon#setControl(DWLControl)
     * @generated
     */
    public void setControl(DWLControl newDWLControl) {
        super.setControl(newDWLControl);

        if (eObjXCustomerVehicleJPN != null) {
            eObjXCustomerVehicleJPN.setControl(newDWLControl);
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the entity object associated with this business object.
     *
     * @generated
     */
    public EObjXCustomerVehicleJPN getEObjXCustomerVehicleJPN() {
        bRequireMapRefresh = true;
        return eObjXCustomerVehicleJPN;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the entity object associated with this business object.
     *
     * @param eObjXCustomerVehicleJPN
     *            The eObjXCustomerVehicleJPN to set.
     * @generated
     */
    public void setEObjXCustomerVehicleJPN(EObjXCustomerVehicleJPN eObjXCustomerVehicleJPN) {
        bRequireMapRefresh = true;
        this.eObjXCustomerVehicleJPN = eObjXCustomerVehicleJPN;
        if (this.eObjXCustomerVehicleJPN != null && this.eObjXCustomerVehicleJPN.getControl() == null) {
            DWLControl control = this.getControl();
            if (control != null) {
                this.eObjXCustomerVehicleJPN.setControl(control);
            }
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xCustomerVehicleJPNpkId attribute.
     * 
     * @generated
     */
    public String getXCustomerVehicleJPNpkId (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXCustomerVehicleJPN.getXCustomerVehicleJPNpkId());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xCustomerVehicleJPNpkId attribute.
     * 
     * @param newXCustomerVehicleJPNpkId
     *     The new value of xCustomerVehicleJPNpkId.
     * @generated
     */
    public void setXCustomerVehicleJPNpkId( String newXCustomerVehicleJPNpkId ) throws Exception {
        metaDataMap.put("XCustomerVehicleJPNpkId", newXCustomerVehicleJPNpkId);

        if (newXCustomerVehicleJPNpkId == null || newXCustomerVehicleJPNpkId.equals("")) {
            newXCustomerVehicleJPNpkId = null;


        }
        eObjXCustomerVehicleJPN.setXCustomerVehicleJPNpkId( DWLFunctionUtils.getLongFromString(newXCustomerVehicleJPNpkId) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the contId attribute.
     * 
     * @generated
     */
    public String getContId (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXCustomerVehicleJPN.getContId());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the contId attribute.
     * 
     * @param newContId
     *     The new value of contId.
     * @generated
     */
    public void setContId( String newContId ) throws Exception {
        metaDataMap.put("ContId", newContId);

        if (newContId == null || newContId.equals("")) {
            newContId = null;


        }
        eObjXCustomerVehicleJPN.setContId( DWLFunctionUtils.getLongFromString(newContId) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the vehicleId attribute.
     * 
     * @generated
     */
    public String getVehicleId (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXCustomerVehicleJPN.getVehicleId());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the vehicleId attribute.
     * 
     * @param newVehicleId
     *     The new value of vehicleId.
     * @generated
     */
    public void setVehicleId( String newVehicleId ) throws Exception {
        metaDataMap.put("VehicleId", newVehicleId);

        if (newVehicleId == null || newVehicleId.equals("")) {
            newVehicleId = null;


        }
        eObjXCustomerVehicleJPN.setVehicleId( DWLFunctionUtils.getLongFromString(newVehicleId) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the retailerId attribute.
     * 
     * @generated
     */
    public String getRetailerId (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXCustomerVehicleJPN.getRetailerId());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the retailerId attribute.
     * 
     * @param newRetailerId
     *     The new value of retailerId.
     * @generated
     */
    public void setRetailerId( String newRetailerId ) throws Exception {
        metaDataMap.put("RetailerId", newRetailerId);

        if (newRetailerId == null || newRetailerId.equals("")) {
            newRetailerId = null;


        }
        eObjXCustomerVehicleJPN.setRetailerId( DWLFunctionUtils.getLongFromString(newRetailerId) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the connectMeUsageType attribute.
     * 
     * @generated
     */
    public String getConnectMeUsageType (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXCustomerVehicleJPN.getConnectMeUsage());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the connectMeUsageType attribute.
     * 
     * @param newConnectMeUsageType
     *     The new value of connectMeUsageType.
     * @generated
     */
    public void setConnectMeUsageType( String newConnectMeUsageType ) throws Exception {
        metaDataMap.put("ConnectMeUsageType", newConnectMeUsageType);

        if (newConnectMeUsageType == null || newConnectMeUsageType.equals("")) {
            newConnectMeUsageType = null;


        }
        eObjXCustomerVehicleJPN.setConnectMeUsage( DWLFunctionUtils.getLongFromString(newConnectMeUsageType) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the connectMeUsageValue attribute.
     * 
     * @generated
     */
    public String getConnectMeUsageValue (){
      return connectMeUsageValue;
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the connectMeUsageValue attribute.
     * 
     * @param newConnectMeUsageValue
     *     The new value of connectMeUsageValue.
     * @generated
     */
    public void setConnectMeUsageValue( String newConnectMeUsageValue ) throws Exception {
        metaDataMap.put("ConnectMeUsageValue", newConnectMeUsageValue);

        if (newConnectMeUsageValue == null || newConnectMeUsageValue.equals("")) {
            newConnectMeUsageValue = null;


        }
        connectMeUsageValue = newConnectMeUsageValue;
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the licensePlate attribute.
     * 
     * @generated
     */
    public String getLicensePlate (){
   
        return eObjXCustomerVehicleJPN.getLicensePlate();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the licensePlate attribute.
     * 
     * @param newLicensePlate
     *     The new value of licensePlate.
     * @generated
     */
    public void setLicensePlate( String newLicensePlate ) throws Exception {
        metaDataMap.put("LicensePlate", newLicensePlate);

        if (newLicensePlate == null || newLicensePlate.equals("")) {
            newLicensePlate = null;


        }
        eObjXCustomerVehicleJPN.setLicensePlate( newLicensePlate );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the vehicleSalesType attribute.
     * 
     * @generated
     */
    public String getVehicleSalesType (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXCustomerVehicleJPN.getVehicleSales());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the vehicleSalesType attribute.
     * 
     * @param newVehicleSalesType
     *     The new value of vehicleSalesType.
     * @generated
     */
    public void setVehicleSalesType( String newVehicleSalesType ) throws Exception {
        metaDataMap.put("VehicleSalesType", newVehicleSalesType);

        if (newVehicleSalesType == null || newVehicleSalesType.equals("")) {
            newVehicleSalesType = null;


        }
        eObjXCustomerVehicleJPN.setVehicleSales( DWLFunctionUtils.getLongFromString(newVehicleSalesType) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the vehicleSalesValue attribute.
     * 
     * @generated
     */
    public String getVehicleSalesValue (){
      return vehicleSalesValue;
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the vehicleSalesValue attribute.
     * 
     * @param newVehicleSalesValue
     *     The new value of vehicleSalesValue.
     * @generated
     */
    public void setVehicleSalesValue( String newVehicleSalesValue ) throws Exception {
        metaDataMap.put("VehicleSalesValue", newVehicleSalesValue);

        if (newVehicleSalesValue == null || newVehicleSalesValue.equals("")) {
            newVehicleSalesValue = null;


        }
        vehicleSalesValue = newVehicleSalesValue;
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the vehicleUsageType attribute.
     * 
     * @generated
     */
    public String getVehicleUsageType (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXCustomerVehicleJPN.getVehicleUsage());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the vehicleUsageType attribute.
     * 
     * @param newVehicleUsageType
     *     The new value of vehicleUsageType.
     * @generated
     */
    public void setVehicleUsageType( String newVehicleUsageType ) throws Exception {
        metaDataMap.put("VehicleUsageType", newVehicleUsageType);

        if (newVehicleUsageType == null || newVehicleUsageType.equals("")) {
            newVehicleUsageType = null;


        }
        eObjXCustomerVehicleJPN.setVehicleUsage( DWLFunctionUtils.getLongFromString(newVehicleUsageType) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the vehicleUsageValue attribute.
     * 
     * @generated
     */
    public String getVehicleUsageValue (){
      return vehicleUsageValue;
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the vehicleUsageValue attribute.
     * 
     * @param newVehicleUsageValue
     *     The new value of vehicleUsageValue.
     * @generated
     */
    public void setVehicleUsageValue( String newVehicleUsageValue ) throws Exception {
        metaDataMap.put("VehicleUsageValue", newVehicleUsageValue);

        if (newVehicleUsageValue == null || newVehicleUsageValue.equals("")) {
            newVehicleUsageValue = null;


        }
        vehicleUsageValue = newVehicleUsageValue;
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the vehicleOwnerShip attribute.
     * 
     * @generated
     */
    public String getVehicleOwnerShip (){
   
        return eObjXCustomerVehicleJPN.getVehicleOwnerShip();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the vehicleOwnerShip attribute.
     * 
     * @param newVehicleOwnerShip
     *     The new value of vehicleOwnerShip.
     * @generated
     */
    public void setVehicleOwnerShip( String newVehicleOwnerShip ) throws Exception {
        metaDataMap.put("VehicleOwnerShip", newVehicleOwnerShip);

        if (newVehicleOwnerShip == null || newVehicleOwnerShip.equals("")) {
            newVehicleOwnerShip = null;


        }
        eObjXCustomerVehicleJPN.setVehicleOwnerShip( newVehicleOwnerShip );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the startDate attribute.
     * 
     * @generated
     */
    public String getStartDate (){
   
        return DWLFunctionUtils.getStringFromTimestamp(eObjXCustomerVehicleJPN.getStartDate());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the startDate attribute.
     * 
     * @param newStartDate
     *     The new value of startDate.
     * @generated
     */
    public void setStartDate( String newStartDate ) throws Exception {
        metaDataMap.put("StartDate", newStartDate);
       	isValidStartDate = true;

        if (newStartDate == null || newStartDate.equals("")) {
            newStartDate = null;
            eObjXCustomerVehicleJPN.setStartDate(null);


        }
    else {
        	if (DateValidator.validates(newStartDate)) {
           		eObjXCustomerVehicleJPN.setStartDate(DateFormatter.getStartDateTimestamp(newStartDate));
            	metaDataMap.put("StartDate", getStartDate());
        	} else {
            	if (Configuration.getConfiguration().getConfigItem(
              "/IBM/DWLCommonServices/InternalValidation/enabled").getBooleanValue()) {
                	if (metaDataMap.get("StartDate") != null) {
                    	metaDataMap.put("StartDate", "");
                	}
                	isValidStartDate = false;
                	eObjXCustomerVehicleJPN.setStartDate(null);
            	}
        	}
        }
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the endDate attribute.
     * 
     * @generated
     */
    public String getEndDate (){
   
        return DWLFunctionUtils.getStringFromTimestamp(eObjXCustomerVehicleJPN.getEndDate());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the endDate attribute.
     * 
     * @param newEndDate
     *     The new value of endDate.
     * @generated
     */
    public void setEndDate( String newEndDate ) throws Exception {
        metaDataMap.put("EndDate", newEndDate);
       	isValidEndDate = true;

        if (newEndDate == null || newEndDate.equals("")) {
            newEndDate = null;
            eObjXCustomerVehicleJPN.setEndDate(null);


        }
    else {
        	if (DateValidator.validates(newEndDate)) {
           		eObjXCustomerVehicleJPN.setEndDate(DateFormatter.getStartDateTimestamp(newEndDate));
            	metaDataMap.put("EndDate", getEndDate());
        	} else {
            	if (Configuration.getConfiguration().getConfigItem(
              "/IBM/DWLCommonServices/InternalValidation/enabled").getBooleanValue()) {
                	if (metaDataMap.get("EndDate") != null) {
                    	metaDataMap.put("EndDate", "");
                	}
                	isValidEndDate = false;
                	eObjXCustomerVehicleJPN.setEndDate(null);
            	}
        	}
        }
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the sourceIdentifierType attribute.
     * 
     * @generated
     */
    public String getSourceIdentifierType (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXCustomerVehicleJPN.getSourceIdentifier());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the sourceIdentifierType attribute.
     * 
     * @param newSourceIdentifierType
     *     The new value of sourceIdentifierType.
     * @generated
     */
    public void setSourceIdentifierType( String newSourceIdentifierType ) throws Exception {
        metaDataMap.put("SourceIdentifierType", newSourceIdentifierType);

        if (newSourceIdentifierType == null || newSourceIdentifierType.equals("")) {
            newSourceIdentifierType = null;


        }
        eObjXCustomerVehicleJPN.setSourceIdentifier( DWLFunctionUtils.getLongFromString(newSourceIdentifierType) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the sourceIdentifierValue attribute.
     * 
     * @generated
     */
    public String getSourceIdentifierValue (){
      return sourceIdentifierValue;
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the sourceIdentifierValue attribute.
     * 
     * @param newSourceIdentifierValue
     *     The new value of sourceIdentifierValue.
     * @generated
     */
    public void setSourceIdentifierValue( String newSourceIdentifierValue ) throws Exception {
        metaDataMap.put("SourceIdentifierValue", newSourceIdentifierValue);

        if (newSourceIdentifierValue == null || newSourceIdentifierValue.equals("")) {
            newSourceIdentifierValue = null;


        }
        sourceIdentifierValue = newSourceIdentifierValue;
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the custVehRetFlag attribute.
     * 
     * @generated
     */
    public String getCustVehRetFlag (){
   
        return eObjXCustomerVehicleJPN.getCustVehRetFlag();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the custVehRetFlag attribute.
     * 
     * @param newCustVehRetFlag
     *     The new value of custVehRetFlag.
     * @generated
     */
    public void setCustVehRetFlag( String newCustVehRetFlag ) throws Exception {
        metaDataMap.put("CustVehRetFlag", newCustVehRetFlag);

        if (newCustVehRetFlag == null || newCustVehRetFlag.equals("")) {
            newCustVehRetFlag = null;


        }
        eObjXCustomerVehicleJPN.setCustVehRetFlag( newCustVehRetFlag );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the deleteFlag attribute.
     * 
     * @generated
     */
    public String getDeleteFlag (){
   
        return eObjXCustomerVehicleJPN.getDeleteFlag();
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the deleteFlag attribute.
     * 
     * @param newDeleteFlag
     *     The new value of deleteFlag.
     * @generated
     */
    public void setDeleteFlag( String newDeleteFlag ) throws Exception {
        metaDataMap.put("DeleteFlag", newDeleteFlag);

        if (newDeleteFlag == null || newDeleteFlag.equals("")) {
            newDeleteFlag = null;


        }
        eObjXCustomerVehicleJPN.setDeleteFlag( newDeleteFlag );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the sFDCId attribute.
     * 
     * @generated
     */
    public String getSFDCId (){
   
        return eObjXCustomerVehicleJPN.getSFDCId();
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the sFDCId attribute.
     * 
     * @param newSFDCId
     *     The new value of sFDCId.
     * @generated
     */
    public void setSFDCId( String newSFDCId ) throws Exception {
        metaDataMap.put("SFDCId", newSFDCId);

        if (newSFDCId == null || newSFDCId.equals("")) {
            newSFDCId = null;


        }
        eObjXCustomerVehicleJPN.setSFDCId( newSFDCId );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the serviceName attribute.
     * 
     * @generated
     */
    public String getServiceName (){
   
        return eObjXCustomerVehicleJPN.getServiceName();
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the serviceName attribute.
     * 
     * @param newServiceName
     *     The new value of serviceName.
     * @generated
     */
    public void setServiceName( String newServiceName ) throws Exception {
        metaDataMap.put("ServiceName", newServiceName);

        if (newServiceName == null || newServiceName.equals("")) {
            newServiceName = null;


        }
        eObjXCustomerVehicleJPN.setServiceName( newServiceName );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XVehicleJPNBObj attribute.
     * 
     * @generated
     */
    public XVehicleJPNBObj getXVehicleJPNBObj (){
      return XVehicleJPNBObj;
    }
    
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public void setXVehicleJPNBObj(XVehicleJPNBObj newBObj ) {
    XVehicleJPNBObj = newBObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XCustomerVehicleRoleJPNBObj attribute.
     * 
     * @generated
     */
    @SuppressWarnings("rawtypes")
    public Vector getItemsXCustomerVehicleRoleJPNBObj (){
      return vecXCustomerVehicleRoleJPNBObj;
    }
    
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    @SuppressWarnings("unchecked")
    public void setXCustomerVehicleRoleJPNBObj(XCustomerVehicleRoleJPNBObj newBObj ) {
        vecXCustomerVehicleRoleJPNBObj.addElement( newBObj );
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateTxId attribute.
     *
     * @generated
     */
    public String getXCustomerVehicleJPNLastUpdateTxId() {
        return DWLFunctionUtils.getStringFromLong(eObjXCustomerVehicleJPN.getLastUpdateTxId());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateUser attribute.
     *
     * @generated
     */
    public String getXCustomerVehicleJPNLastUpdateUser() {
        return eObjXCustomerVehicleJPN.getLastUpdateUser();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateDt attribute.
     *
     * @generated
     */
    public String getXCustomerVehicleJPNLastUpdateDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXCustomerVehicleJPN.getLastUpdateDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateTxId attribute.
     *
     * @param newLastUpdateTxId
     *     The new value of LastUpdateTxId.
     * @generated
     */
    public void setXCustomerVehicleJPNLastUpdateTxId(String newLastUpdateTxId) {
        metaDataMap.put("XCustomerVehicleJPNLastUpdateTxId", newLastUpdateTxId);

        if ((newLastUpdateTxId == null) || newLastUpdateTxId.equals("")) {
            newLastUpdateTxId = null;
        }
        eObjXCustomerVehicleJPN.setLastUpdateTxId(DWLFunctionUtils.getLongFromString(newLastUpdateTxId));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateUser attribute.
     *
     * @param newLastUpdateUser
     *     The new value of LastUpdateUser.
     * @generated
     */
    public void setXCustomerVehicleJPNLastUpdateUser(String newLastUpdateUser) {
        metaDataMap.put("XCustomerVehicleJPNLastUpdateUser", newLastUpdateUser);

        if ((newLastUpdateUser == null) || newLastUpdateUser.equals("")) {
            newLastUpdateUser = null;
        }
        eObjXCustomerVehicleJPN.setLastUpdateUser(newLastUpdateUser);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateDt attribute.
     *
     * @param newLastUpdateDt
     *     The new value of LastUpdateDt.
     * @throws Exception
     * @generated
     */
    public void setXCustomerVehicleJPNLastUpdateDate(String newLastUpdateDt) throws Exception {
        metaDataMap.put("XCustomerVehicleJPNLastUpdateDate", newLastUpdateDt);

        if ((newLastUpdateDt == null) || newLastUpdateDt.equals("")) {
            newLastUpdateDt = null;
        }

        eObjXCustomerVehicleJPN.setLastUpdateDt(DWLFunctionUtils.getTimestampFromTimestampString(newLastUpdateDt));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XCustomerVehicleJPNHistActionCode history attribute.
     *
     * @generated
     */
    public String getXCustomerVehicleJPNHistActionCode() {
        return eObjXCustomerVehicleJPN.getHistActionCode();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XCustomerVehicleJPNHistActionCode history attribute.
     *
     * @param aXCustomerVehicleJPNHistActionCode
     *     The new value of XCustomerVehicleJPNHistActionCode.
     * @generated
     */
    public void setXCustomerVehicleJPNHistActionCode(String aXCustomerVehicleJPNHistActionCode) {
        metaDataMap.put("XCustomerVehicleJPNHistActionCode", aXCustomerVehicleJPNHistActionCode);

        if ((aXCustomerVehicleJPNHistActionCode == null) || aXCustomerVehicleJPNHistActionCode.equals("")) {
            aXCustomerVehicleJPNHistActionCode = null;
        }
        eObjXCustomerVehicleJPN.setHistActionCode(aXCustomerVehicleJPNHistActionCode);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XCustomerVehicleJPNHistCreateDate history attribute.
     *
     * @generated
     */
    public String getXCustomerVehicleJPNHistCreateDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXCustomerVehicleJPN.getHistCreateDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XCustomerVehicleJPNHistCreateDate history attribute.
     *
     * @param aXCustomerVehicleJPNHistCreateDate
     *     The new value of XCustomerVehicleJPNHistCreateDate.
     * @generated
     */
    public void setXCustomerVehicleJPNHistCreateDate(String aXCustomerVehicleJPNHistCreateDate) throws Exception{
        metaDataMap.put("XCustomerVehicleJPNHistCreateDate", aXCustomerVehicleJPNHistCreateDate);

        if ((aXCustomerVehicleJPNHistCreateDate == null) || aXCustomerVehicleJPNHistCreateDate.equals("")) {
            aXCustomerVehicleJPNHistCreateDate = null;
        }

        eObjXCustomerVehicleJPN.setHistCreateDt(DWLFunctionUtils.getTimestampFromTimestampString(aXCustomerVehicleJPNHistCreateDate));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XCustomerVehicleJPNHistCreatedBy history attribute.
     *
     * @generated
     */
    public String getXCustomerVehicleJPNHistCreatedBy() {
        return eObjXCustomerVehicleJPN.getHistCreatedBy();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XCustomerVehicleJPNHistCreatedBy history attribute.
     *
     * @param aXCustomerVehicleJPNHistCreatedBy
     *     The new value of XCustomerVehicleJPNHistCreatedBy.
     * @generated
     */
    public void setXCustomerVehicleJPNHistCreatedBy(String aXCustomerVehicleJPNHistCreatedBy) {
        metaDataMap.put("XCustomerVehicleJPNHistCreatedBy", aXCustomerVehicleJPNHistCreatedBy);

        if ((aXCustomerVehicleJPNHistCreatedBy == null) || aXCustomerVehicleJPNHistCreatedBy.equals("")) {
            aXCustomerVehicleJPNHistCreatedBy = null;
        }

        eObjXCustomerVehicleJPN.setHistCreatedBy(aXCustomerVehicleJPNHistCreatedBy);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XCustomerVehicleJPNHistEndDate history attribute.
     *
     * @generated
     */
    public String getXCustomerVehicleJPNHistEndDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXCustomerVehicleJPN.getHistEndDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XCustomerVehicleJPNHistEndDate history attribute.
     *
     * @param aXCustomerVehicleJPNHistEndDate
     *     The new value of XCustomerVehicleJPNHistEndDate.
     * @generated
     */
    public void setXCustomerVehicleJPNHistEndDate(String aXCustomerVehicleJPNHistEndDate) throws Exception{
        metaDataMap.put("XCustomerVehicleJPNHistEndDate", aXCustomerVehicleJPNHistEndDate);

        if ((aXCustomerVehicleJPNHistEndDate == null) || aXCustomerVehicleJPNHistEndDate.equals("")) {
            aXCustomerVehicleJPNHistEndDate = null;
        }
        eObjXCustomerVehicleJPN.setHistEndDt(DWLFunctionUtils.getTimestampFromTimestampString(aXCustomerVehicleJPNHistEndDate));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XCustomerVehicleJPNHistoryIdPK history attribute.
     *
     * @generated
     */
    public String getXCustomerVehicleJPNHistoryIdPK() {
        return DWLFunctionUtils.getStringFromLong(eObjXCustomerVehicleJPN.getHistoryIdPK());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XCustomerVehicleJPNHistoryIdPK history attribute.
     *
     * @param aXCustomerVehicleJPNHistoryIdPK
     *     The new value of XCustomerVehicleJPNHistoryIdPK.
     * @generated
     */
    public void setXCustomerVehicleJPNHistoryIdPK(String aXCustomerVehicleJPNHistoryIdPK) {
        metaDataMap.put("XCustomerVehicleJPNHistoryIdPK", aXCustomerVehicleJPNHistoryIdPK);

        if ((aXCustomerVehicleJPNHistoryIdPK == null) || aXCustomerVehicleJPNHistoryIdPK.equals("")) {
            aXCustomerVehicleJPNHistoryIdPK = null;
        }
        eObjXCustomerVehicleJPN.setHistoryIdPK(DWLFunctionUtils.getLongFromString(aXCustomerVehicleJPNHistoryIdPK));
    }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation during an add transaction.
     *
     * @generated
     */
    public DWLStatus validateAdd(int level, DWLStatus status) throws Exception {

        status = super.validateAdd(level, status);
        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0038I Add any controller-level custom validation logic to be
            // executed for this object during an "add" transaction


            XVehicleJPNBObj xVehicleJPN = getXVehicleJPNBObj();
            if( xVehicleJPN != null ){
            	status = xVehicleJPN.validateAdd(level, status);
            }

            for (int i = 0; i < getItemsXCustomerVehicleRoleJPNBObj().size(); i++) {
                XCustomerVehicleRoleJPNBObj xCustomerVehicleRoleJPN = (XCustomerVehicleRoleJPNBObj) getItemsXCustomerVehicleRoleJPNBObj().elementAt(i);
                status = xCustomerVehicleRoleJPN.validateAdd(level, status);
            }
        }

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            // MDM_TODO0: CDKWB0039I Add any component-level custom validation logic to be
            // executed for this object during an "add" transaction
        }
        status = getValidationStatus(level, status);
        return status;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation during an update transaction.
     *
     * @generated
     */
    public DWLStatus validateUpdate(int level, DWLStatus status) throws Exception {
    logger.finest("ENTER validateUpdate(int level, DWLStatus status)");

        status = super.validateUpdate(level, status);
        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0040I Add any controller-level custom validation logic to be
            // executed for this object during an "update" transaction

            if (eObjXCustomerVehicleJPN.getXCustomerVehicleJPNpkId() == null) {
                DWLError err = new DWLError();
                err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_JPNBOBJ).longValue());
                err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.XCUSTOMERVEHICLEJPN_XCUSTOMERVEHICLEJPNPKID_NULL).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                	String infoForLogging="Error: Validation error occured for update. No primary key for entity XCustomerVehicleJPN, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("validateUpdate(int level, DWLStatus status) " + infoForLogging);
                }
                status.addError(err);
            }
            if (eObjXCustomerVehicleJPN.getLastUpdateDt() == null) {
                DWLError err = new DWLError();
                err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_JPNBOBJ).longValue());
                err.setReasonCode(new Long(DWLUtilErrorReasonCode.LAST_UPDATED_DATE_NULL).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
                if (logger.isFinestEnabled()) {
                	String infoForLogging="Error: Validation error occured for update. No last update date for entity XCustomerVehicleJPN, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("validateUpdate(int level, DWLStatus status) " + infoForLogging);
                }
                status.addError(err);
            }
           XVehicleJPNBObj xVehicleJPN = (XVehicleJPNBObj) getXVehicleJPNBObj();
           if( xVehicleJPN != null ){
           		if (xVehicleJPN.getEObjXVehicleJPN().getPrimaryKey() == null) {
               		status = xVehicleJPN.validateAdd(level, status);
           		} else  {
               		status = xVehicleJPN.validateUpdate(level, status);
           		}
           }

            for (int i = 0; i < getItemsXCustomerVehicleRoleJPNBObj().size(); i++) {
                XCustomerVehicleRoleJPNBObj xCustomerVehicleRoleJPN = (XCustomerVehicleRoleJPNBObj) getItemsXCustomerVehicleRoleJPNBObj().elementAt(i);
                if (xCustomerVehicleRoleJPN.getEObjXCustomerVehicleRoleJPN().getPrimaryKey() == null) {
                    status = xCustomerVehicleRoleJPN.validateAdd(level, status);
                } else  {
                    status = xCustomerVehicleRoleJPN.validateUpdate(level, status);
                }
            }
        }

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            assignBeforeImageValues(metaDataMap);
            
            // MDM_TODO0: CDKWB0041I Add any component-level custom validation logic to be
            // executed for this object during an "update" transaction
        }
        status = getValidationStatus(level, status);
    if (logger.isFinestEnabled()) {
        	String returnValue = status.toString();
      logger.finest("RETURN validateUpdate(int level, DWLStatus status) " + returnValue);
    }
        return status;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Populate the before image of this business object.
     *
     * @see com.dwl.base.DWLCommon#populateBeforeImage()
     * @generated
     */
    public void populateBeforeImage() throws DWLBaseException {
    logger.finest("ENTER populateBeforeImage()");

        DSEAAdditionsExts comp = null;
        try {
        
      comp = (DSEAAdditionsExts)TCRMClassFactory.getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
        	
        } catch (Exception e) {
      if (logger.isFinestEnabled()) {
        String infoForLogging="Error: Fatal error while updating record " + e.getMessage();
      logger.finest("populateBeforeImage() " + infoForLogging);
      }
            DWLExceptionUtils.throwDWLBaseException(e, 
            									new DWLUpdateException(e.getMessage()), 
            									this.getStatus(), DWLStatus.FATAL,
                                  DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_JPNBOBJ, 
                                  "DIERR",
                                  DSEAAdditionsExtsErrorReasonCode.XCUSTOMERVEHICLEJPN_BEFORE_IMAGE_NOT_POPULATED, 
                                  this.getControl());
        }
        
        comp.loadBeforeImage(this);
    logger.finest("RETURN populateBeforeImage()");
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation common to both add and update transactions.
     *
     * @generated
     */
     
    private DWLStatus getValidationStatus(int level, DWLStatus status) throws Exception {
    logger.finest("ENTER getValidationStatus(int level, DWLStatus status)");

        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0034I Add any common controller-level custom validation
            // logic to be executed for this object during either "add" or
            // "update" transactions
    		controllerValidation_ConnectMeUsage(status);
    		controllerValidation_VehicleSales(status);
    		controllerValidation_VehicleUsage(status);
    		controllerValidation_StartDate(status);
    		controllerValidation_EndDate(status);
    		controllerValidation_SourceIdentifier(status);
    	}

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            // MDM_TODO0: CDKWB0035I Add any common component-level custom validation logic
            // to be executed for this object during either "add" or "update"
            // transactions
    		componentValidation_ConnectMeUsage(status);
    		componentValidation_VehicleSales(status);
    		componentValidation_VehicleUsage(status);
    		componentValidation_StartDate(status);
    		componentValidation_EndDate(status);
    		componentValidation_SourceIdentifier(status);
        }
        
        if (logger.isFinestEnabled()) {
            String returnValue = status.toString();
      logger.finest("RETURN getValidationStatus(int level, DWLStatus status) " + returnValue);
        }
    
        return status;
    }

    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "ConnectMeUsage"
     *
     * @generated
     */
	private void componentValidation_ConnectMeUsage(DWLStatus status) {
  
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "VehicleSales"
     *
     * @generated
     */
	private void componentValidation_VehicleSales(DWLStatus status) {
  
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "VehicleUsage"
     *
     * @generated
     */
	private void componentValidation_VehicleUsage(DWLStatus status) {
  
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "StartDate"
     *
     * @generated
     */
	private void componentValidation_StartDate(DWLStatus status) {
  
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "EndDate"
     *
     * @generated
     */
	private void componentValidation_EndDate(DWLStatus status) {
  
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "SourceIdentifier"
     *
     * @generated
     */
	private void componentValidation_SourceIdentifier(DWLStatus status) {
  
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "ConnectMeUsage"
     *
     * @generated
     */
	private void controllerValidation_ConnectMeUsage(DWLStatus status) throws Exception {
  
      //persistent code type
            boolean isConnectMeUsageNull = false;
            if ((eObjXCustomerVehicleJPN.getConnectMeUsage() == null) &&
               ((getConnectMeUsageValue() == null) || 
                 getConnectMeUsageValue().trim().equals(""))) {
                isConnectMeUsageNull = true;
            }
            if (!isConnectMeUsageNull) {
                if (checkForInvalidXcustomervehiclejpnConnectmeusage()) {
                    DWLError err = new DWLError();
                    err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_JPNBOBJ).longValue());
                    err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XCUSTOMERVEHICLEJPN_CONNECTMEUSAGE).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                    String infoForLogging="Error: Custom validation error occured for entity XCustomerVehicleJPN, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("controllerValidation_ConnectMeUsage " + infoForLogging);
        }
                status.addError(err);
            }

             }
    			
    	}
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "VehicleSales"
     *
     * @generated
     */
	private void controllerValidation_VehicleSales(DWLStatus status) throws Exception {
  
      //persistent code type
            boolean isVehicleSalesNull = false;
            if ((eObjXCustomerVehicleJPN.getVehicleSales() == null) &&
               ((getVehicleSalesValue() == null) || 
                 getVehicleSalesValue().trim().equals(""))) {
                isVehicleSalesNull = true;
            }
            if (!isVehicleSalesNull) {
                if (checkForInvalidXcustomervehiclejpnVehiclesales()) {
                    DWLError err = new DWLError();
                    err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_JPNBOBJ).longValue());
                    err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XCUSTOMERVEHICLEJPN_VEHICLESALES).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                    String infoForLogging="Error: Custom validation error occured for entity XCustomerVehicleJPN, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("controllerValidation_VehicleSales " + infoForLogging);
        }
                status.addError(err);
            }

             }
    			
    	}
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "VehicleUsage"
     *
     * @generated
     */
	private void controllerValidation_VehicleUsage(DWLStatus status) throws Exception {
  
      //persistent code type
            boolean isVehicleUsageNull = false;
            if ((eObjXCustomerVehicleJPN.getVehicleUsage() == null) &&
               ((getVehicleUsageValue() == null) || 
                 getVehicleUsageValue().trim().equals(""))) {
                isVehicleUsageNull = true;
            }
            if (!isVehicleUsageNull) {
                if (checkForInvalidXcustomervehiclejpnVehicleusage()) {
                    DWLError err = new DWLError();
                    err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_JPNBOBJ).longValue());
                    err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XCUSTOMERVEHICLEJPN_VEHICLEUSAGE).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                    String infoForLogging="Error: Custom validation error occured for entity XCustomerVehicleJPN, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("controllerValidation_VehicleUsage " + infoForLogging);
        }
                status.addError(err);
            }

             }
    			
    	}
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "StartDate"
     *
     * @generated
     */
	private void controllerValidation_StartDate(DWLStatus status) throws Exception {
  
            boolean isStartDateNull = (eObjXCustomerVehicleJPN.getStartDate() == null);
            if (!isValidStartDate) {
              	DWLError err = new DWLError();
               	err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_JPNBOBJ).longValue());
               	err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XCUSTOMERVEHICLEJPN_STARTDATE).longValue());
               	err.setErrorType(DWLErrorCode.DATA_INVALID_ERROR);
                String infoForLogging="Error: Validation error. Invalid time specified on property StartDate in entity XCustomerVehicleJPN, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode();
      logger.finest("controllerValidation_StartDate " + infoForLogging);
               	status.addError(err);
            } 
    	}
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "EndDate"
     *
     * @generated
     */
	private void controllerValidation_EndDate(DWLStatus status) throws Exception {
  
            boolean isEndDateNull = (eObjXCustomerVehicleJPN.getEndDate() == null);
            if (!isValidEndDate) {
              	DWLError err = new DWLError();
               	err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_JPNBOBJ).longValue());
               	err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XCUSTOMERVEHICLEJPN_ENDDATE).longValue());
               	err.setErrorType(DWLErrorCode.DATA_INVALID_ERROR);
                String infoForLogging="Error: Validation error. Invalid time specified on property EndDate in entity XCustomerVehicleJPN, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode();
      logger.finest("controllerValidation_EndDate " + infoForLogging);
               	status.addError(err);
            } 
    	}
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "SourceIdentifier"
     *
     * @generated
     */
	private void controllerValidation_SourceIdentifier(DWLStatus status) throws Exception {
  
      //persistent code type
            boolean isSourceIdentifierNull = false;
            if ((eObjXCustomerVehicleJPN.getSourceIdentifier() == null) &&
               ((getSourceIdentifierValue() == null) || 
                 getSourceIdentifierValue().trim().equals(""))) {
                isSourceIdentifierNull = true;
            }
            if (!isSourceIdentifierNull) {
                if (checkForInvalidXcustomervehiclejpnSourceidentifier()) {
                    DWLError err = new DWLError();
                    err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_JPNBOBJ).longValue());
                    err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XCUSTOMERVEHICLEJPN_SOURCEIDENTIFIER).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                    String infoForLogging="Error: Custom validation error occured for entity XCustomerVehicleJPN, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("controllerValidation_SourceIdentifier " + infoForLogging);
        }
                status.addError(err);
            }

             }
    			
    	}
    private DWLError createDWLError(String entityName, String propertyName,String reasonCode){	
		DWLError err = new DWLError();
		err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_JPNBOBJ).longValue());
		err.setReasonCode(new Long(reasonCode).longValue());
		err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
			String infoForLogging="Error: Validation error occured. Property " + propertyName + " is null, in entity " + entityName + ", component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
			logger.finest("createDWLError " + infoForLogging);
		}
		return err;
    }
    
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Check the value of the field ConnectMeUsage and return true if the error
     * reason INVALID_XCUSTOMERVEHICLEJPN_CONNECTMEUSAGE should be returned.
     *
     * @generated
  **/
	private boolean checkForInvalidXcustomervehiclejpnConnectmeusage() throws Exception {
    logger.finest("ENTER checkForInvalidXcustomervehiclejpnConnectmeusage()");
        boolean notValid = false;
      	String langId = (String) this.getControl().get(DWLControlKeys.LANG_ID);
      	CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
    Long codeType = DWLFunctionUtils.getLongFromString( getConnectMeUsageType() );
    String codeValue = getConnectMeUsageValue();
    if( codeValue != null && codeValue.trim().equals("")){
      codeValue = null;
    }
     
        if ( codeType != null && codeValue == null ){

             if( codeTypeCompHelper.isCodeValid("xcdconnectmeusagetp", langId, getConnectMeUsageType(),
                 CodeTypeComponentHelper.ACTIVE, getControl())) {
                 CodeTypeBObj ctBObj = codeTypeCompHelper
                 					.getCodeTypeByCode("xcdconnectmeusagetp", langId, getConnectMeUsageType(),
                         								getControl());
               	if (ctBObj != null) {
                   	setConnectMeUsageValue( ctBObj.getvalue() );
               	}
             }
             else{
             	if (logger.isFinestEnabled()) {
              	 	String infoForLogging="NotValid 1";
      logger.finest("checkForInvalidXcustomervehiclejpnConnectmeusage() " + infoForLogging);
        }
                 notValid = true;
           }
        }
        else if (codeType == null && codeValue != null ){
          
             CodeTypeBObj ctBObj = codeTypeCompHelper
                      .getCodeTypeByValue("xcdconnectmeusagetp", langId, codeValue,
                                 getControl());

             if (ctBObj != null) {
                 setConnectMeUsageType(ctBObj.gettp_cd());
             } 
             else {
             	if (logger.isFinestEnabled()) {
              	  	String infoForLogging="NotValid 2";
      logger.finest("checkForInvalidXcustomervehiclejpnConnectmeusage() " + infoForLogging);
        }
                  notValid = true;
             }
        }
        else if ( codeType != null && codeValue != null
             && !codeTypeCompHelper.isCodeValuePairValid("xcdconnectmeusagetp", langId, getConnectMeUsageType(), 
                     new String[] { codeValue }, CodeTypeComponentHelper.ACTIVE, getControl())) {	
       if (logger.isFinestEnabled()) {
       		String infoForLogging="NotValid 3";
      logger.finest("checkForInvalidXcustomervehiclejpnConnectmeusage() " + infoForLogging);
       }
             notValid = true;
        }
        if (logger.isFinestEnabled()) {
      String returnValue ="" +notValid;
      logger.finest("RETURN checkForInvalidXcustomervehiclejpnConnectmeusage() " + returnValue);
    }
    return notValid;
     } 
				 
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Check the value of the field VehicleSales and return true if the error
     * reason INVALID_XCUSTOMERVEHICLEJPN_VEHICLESALES should be returned.
     *
     * @generated
  **/
	private boolean checkForInvalidXcustomervehiclejpnVehiclesales() throws Exception {
    logger.finest("ENTER checkForInvalidXcustomervehiclejpnVehiclesales()");
        boolean notValid = false;
      	String langId = (String) this.getControl().get(DWLControlKeys.LANG_ID);
      	CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
    Long codeType = DWLFunctionUtils.getLongFromString( getVehicleSalesType() );
    String codeValue = getVehicleSalesValue();
    if( codeValue != null && codeValue.trim().equals("")){
      codeValue = null;
    }
     
        if ( codeType != null && codeValue == null ){

             if( codeTypeCompHelper.isCodeValid("xcdvehiclesalestp", langId, getVehicleSalesType(),
                 CodeTypeComponentHelper.ACTIVE, getControl())) {
                 CodeTypeBObj ctBObj = codeTypeCompHelper
                 					.getCodeTypeByCode("xcdvehiclesalestp", langId, getVehicleSalesType(),
                         								getControl());
               	if (ctBObj != null) {
                   	setVehicleSalesValue( ctBObj.getvalue() );
               	}
             }
             else{
             	if (logger.isFinestEnabled()) {
              	 	String infoForLogging="NotValid 1";
      logger.finest("checkForInvalidXcustomervehiclejpnVehiclesales() " + infoForLogging);
        }
                 notValid = true;
           }
        }
        else if (codeType == null && codeValue != null ){
          
             CodeTypeBObj ctBObj = codeTypeCompHelper
                      .getCodeTypeByValue("xcdvehiclesalestp", langId, codeValue,
                                 getControl());

             if (ctBObj != null) {
                 setVehicleSalesType(ctBObj.gettp_cd());
             } 
             else {
             	if (logger.isFinestEnabled()) {
              	  	String infoForLogging="NotValid 2";
      logger.finest("checkForInvalidXcustomervehiclejpnVehiclesales() " + infoForLogging);
        }
                  notValid = true;
             }
        }
        else if ( codeType != null && codeValue != null
             && !codeTypeCompHelper.isCodeValuePairValid("xcdvehiclesalestp", langId, getVehicleSalesType(), 
                     new String[] { codeValue }, CodeTypeComponentHelper.ACTIVE, getControl())) {	
       if (logger.isFinestEnabled()) {
       		String infoForLogging="NotValid 3";
      logger.finest("checkForInvalidXcustomervehiclejpnVehiclesales() " + infoForLogging);
       }
             notValid = true;
        }
        if (logger.isFinestEnabled()) {
      String returnValue ="" +notValid;
      logger.finest("RETURN checkForInvalidXcustomervehiclejpnVehiclesales() " + returnValue);
    }
    return notValid;
     } 
				 
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Check the value of the field VehicleUsage and return true if the error
     * reason INVALID_XCUSTOMERVEHICLEJPN_VEHICLEUSAGE should be returned.
     *
     * @generated
  **/
	private boolean checkForInvalidXcustomervehiclejpnVehicleusage() throws Exception {
    logger.finest("ENTER checkForInvalidXcustomervehiclejpnVehicleusage()");
        boolean notValid = false;
      	String langId = (String) this.getControl().get(DWLControlKeys.LANG_ID);
      	CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
    Long codeType = DWLFunctionUtils.getLongFromString( getVehicleUsageType() );
    String codeValue = getVehicleUsageValue();
    if( codeValue != null && codeValue.trim().equals("")){
      codeValue = null;
    }
     
        if ( codeType != null && codeValue == null ){

             if( codeTypeCompHelper.isCodeValid("xcdvehicleusagetp", langId, getVehicleUsageType(),
                 CodeTypeComponentHelper.ACTIVE, getControl())) {
                 CodeTypeBObj ctBObj = codeTypeCompHelper
                 					.getCodeTypeByCode("xcdvehicleusagetp", langId, getVehicleUsageType(),
                         								getControl());
               	if (ctBObj != null) {
                   	setVehicleUsageValue( ctBObj.getvalue() );
               	}
             }
             else{
             	if (logger.isFinestEnabled()) {
              	 	String infoForLogging="NotValid 1";
      logger.finest("checkForInvalidXcustomervehiclejpnVehicleusage() " + infoForLogging);
        }
                 notValid = true;
           }
        }
        else if (codeType == null && codeValue != null ){
          
             CodeTypeBObj ctBObj = codeTypeCompHelper
                      .getCodeTypeByValue("xcdvehicleusagetp", langId, codeValue,
                                 getControl());

             if (ctBObj != null) {
                 setVehicleUsageType(ctBObj.gettp_cd());
             } 
             else {
             	if (logger.isFinestEnabled()) {
              	  	String infoForLogging="NotValid 2";
      logger.finest("checkForInvalidXcustomervehiclejpnVehicleusage() " + infoForLogging);
        }
                  notValid = true;
             }
        }
        else if ( codeType != null && codeValue != null
             && !codeTypeCompHelper.isCodeValuePairValid("xcdvehicleusagetp", langId, getVehicleUsageType(), 
                     new String[] { codeValue }, CodeTypeComponentHelper.ACTIVE, getControl())) {	
       if (logger.isFinestEnabled()) {
       		String infoForLogging="NotValid 3";
      logger.finest("checkForInvalidXcustomervehiclejpnVehicleusage() " + infoForLogging);
       }
             notValid = true;
        }
        if (logger.isFinestEnabled()) {
      String returnValue ="" +notValid;
      logger.finest("RETURN checkForInvalidXcustomervehiclejpnVehicleusage() " + returnValue);
    }
    return notValid;
     } 
				 
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Check the value of the field SourceIdentifier and return true if the
     * error reason INVALID_XCUSTOMERVEHICLEJPN_SOURCEIDENTIFIER should be
     * returned.
     *
     * @generated
  **/
	private boolean checkForInvalidXcustomervehiclejpnSourceidentifier() throws Exception {
    logger.finest("ENTER checkForInvalidXcustomervehiclejpnSourceidentifier()");
        boolean notValid = false;
      	String langId = (String) this.getControl().get(DWLControlKeys.LANG_ID);
      	CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
    Long codeType = DWLFunctionUtils.getLongFromString( getSourceIdentifierType() );
    String codeValue = getSourceIdentifierValue();
    if( codeValue != null && codeValue.trim().equals("")){
      codeValue = null;
    }
     
        if ( codeType != null && codeValue == null ){

             if( codeTypeCompHelper.isCodeValid("cdsourceidenttp", langId, getSourceIdentifierType(),
                 CodeTypeComponentHelper.ACTIVE, getControl())) {
                 CodeTypeBObj ctBObj = codeTypeCompHelper
                 					.getCodeTypeByCode("cdsourceidenttp", langId, getSourceIdentifierType(),
                         								getControl());
               	if (ctBObj != null) {
                   	setSourceIdentifierValue( ctBObj.getvalue() );
               	}
             }
             else{
             	if (logger.isFinestEnabled()) {
              	 	String infoForLogging="NotValid 1";
      logger.finest("checkForInvalidXcustomervehiclejpnSourceidentifier() " + infoForLogging);
        }
                 notValid = true;
           }
        }
        else if (codeType == null && codeValue != null ){
          
             CodeTypeBObj ctBObj = codeTypeCompHelper
                      .getCodeTypeByValue("cdsourceidenttp", langId, codeValue,
                                 getControl());

             if (ctBObj != null) {
                 setSourceIdentifierType(ctBObj.gettp_cd());
             } 
             else {
             	if (logger.isFinestEnabled()) {
              	  	String infoForLogging="NotValid 2";
      logger.finest("checkForInvalidXcustomervehiclejpnSourceidentifier() " + infoForLogging);
        }
                  notValid = true;
             }
        }
        else if ( codeType != null && codeValue != null
             && !codeTypeCompHelper.isCodeValuePairValid("cdsourceidenttp", langId, getSourceIdentifierType(), 
                     new String[] { codeValue }, CodeTypeComponentHelper.ACTIVE, getControl())) {	
       if (logger.isFinestEnabled()) {
       		String infoForLogging="NotValid 3";
      logger.finest("checkForInvalidXcustomervehiclejpnSourceidentifier() " + infoForLogging);
       }
             notValid = true;
        }
        if (logger.isFinestEnabled()) {
      String returnValue ="" +notValid;
      logger.finest("RETURN checkForInvalidXcustomervehiclejpnSourceidentifier() " + returnValue);
    }
    return notValid;
     } 
				 



}

