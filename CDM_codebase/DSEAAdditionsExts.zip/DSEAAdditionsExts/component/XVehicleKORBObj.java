
/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[744bd75caa04e7985229d48df76b4336]
 */

package com.ibm.daimler.dsea.component;

import com.dwl.tcrm.common.TCRMCommon;



import com.dwl.base.DWLControl;

import com.dwl.base.constant.DWLControlKeys;
import com.dwl.base.constant.DWLUtilErrorReasonCode;

import com.dwl.base.error.DWLError;
import com.dwl.base.error.DWLErrorCode;
import com.dwl.base.error.DWLStatus;

import com.dwl.base.exception.DWLBaseException;
import com.dwl.base.exception.DWLUpdateException;

import com.dwl.base.util.DWLClassFactory;
import com.dwl.base.util.DWLExceptionUtils;
import com.dwl.base.util.DWLFunctionUtils;

import com.dwl.management.config.client.Configuration;

import com.dwl.tcrm.common.ITCRMValidation;

import com.dwl.tcrm.utilities.DateFormatter;
import com.dwl.tcrm.utilities.DateValidator;
import com.dwl.tcrm.utilities.TCRMClassFactory;

import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsComponentID;
import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsErrorReasonCode;
import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsPropertyKeys;

import com.ibm.daimler.dsea.entityObject.EObjXVehicleKOR;

import com.ibm.daimler.dsea.interfaces.DSEAAdditionsExts;

import com.ibm.mdm.common.codetype.interfaces.CodeTypeComponentHelper;

import com.ibm.mdm.common.codetype.obj.CodeTypeBObj;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * This class provides the implementation of the business object
 * <code>XVehicleKORBObj</code>.
 * 
 * @see com.dwl.tcrm.common.TCRMCommon
 * @generated
 */
 

@SuppressWarnings("serial")
public class XVehicleKORBObj extends TCRMCommon  {

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected EObjXVehicleKOR eObjXVehicleKOR;
	/**
    * <!-- begin-user-doc -->
	  * <!-- end-user-doc -->
    * @generated 
    */
	 private final static com.dwl.base.logging.IDWLLogger logger = com.dwl.base.logging.DWLLoggerManager.getLogger(XVehicleKORBObj.class);
		
 
	protected boolean isValidLastModifiedSystemDate = true;
	
	protected boolean isValidCreateDate = true;
	
	protected boolean isValidChangedDate = true;
	
	protected boolean isValidLastServiceDate = true;
	
	protected boolean isValidEndDate = true;
	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected String sourceIdentifierValue;


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */     
    public XVehicleKORBObj() {
        super();
        init();
        eObjXVehicleKOR = new EObjXVehicleKOR();
        setComponentID(DSEAAdditionsExtsComponentID.XVEHICLE_KORBOBJ);
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Initializes the fields required to populate the metaDataMap. Each key is
     * an element-level field of the business object.
     *
     * @generated
     */
    private void init() {
        metaDataMap.put("XVehicleKORpkId", null);
        metaDataMap.put("GlobalVIN", null);
        metaDataMap.put("BauMuster", null);
        metaDataMap.put("TypeClass", null);
        metaDataMap.put("SubMuster", null);
        metaDataMap.put("Color", null);
        metaDataMap.put("Trim", null);
        metaDataMap.put("BatchInd", null);
        metaDataMap.put("MarketName", null);
        metaDataMap.put("LastModifiedSystemDate", null);
        metaDataMap.put("CreateDate", null);
        metaDataMap.put("ChangedDate", null);
        metaDataMap.put("LastServiceDate", null);
        metaDataMap.put("SFDCId", null);
        metaDataMap.put("VehicleAddressType", null);
        metaDataMap.put("VehicleType", null);
        metaDataMap.put("DeleteFlag", null);
        metaDataMap.put("EndDate", null);
        metaDataMap.put("EngineNumber", null);
        metaDataMap.put("SourceIdentifierType", null);
        metaDataMap.put("SourceIdentifierValue", null);
        metaDataMap.put("LocalVIN", null);
        metaDataMap.put("XVehicleKORHistActionCode", null);
        metaDataMap.put("XVehicleKORHistCreateDate", null);
        metaDataMap.put("XVehicleKORHistCreatedBy", null);
        metaDataMap.put("XVehicleKORHistEndDate", null);
        metaDataMap.put("XVehicleKORHistoryIdPK", null);
        metaDataMap.put("XVehicleKORLastUpdateDate", null);
        metaDataMap.put("XVehicleKORLastUpdateTxId", null);
        metaDataMap.put("XVehicleKORLastUpdateUser", null);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Refreshes all the attributes this business object supports.
     *
     * @see com.dwl.base.DWLCommon#refreshMap()
     * @generated
     */
    public void refreshMap() {

        if (bRequireMapRefresh) {
            super.refreshMap();
            metaDataMap.put("XVehicleKORpkId", getXVehicleKORpkId());
            metaDataMap.put("GlobalVIN", getGlobalVIN());
            metaDataMap.put("BauMuster", getBauMuster());
            metaDataMap.put("TypeClass", getTypeClass());
            metaDataMap.put("SubMuster", getSubMuster());
            metaDataMap.put("Color", getColor());
            metaDataMap.put("Trim", getTrim());
            metaDataMap.put("BatchInd", getBatchInd());
            metaDataMap.put("MarketName", getMarketName());
            metaDataMap.put("LastModifiedSystemDate", getLastModifiedSystemDate());
            metaDataMap.put("CreateDate", getCreateDate());
            metaDataMap.put("ChangedDate", getChangedDate());
            metaDataMap.put("LastServiceDate", getLastServiceDate());
            metaDataMap.put("SFDCId", getSFDCId());
            metaDataMap.put("VehicleAddressType", getVehicleAddressType());
            metaDataMap.put("VehicleType", getVehicleType());
            metaDataMap.put("DeleteFlag", getDeleteFlag());
            metaDataMap.put("EndDate", getEndDate());
            metaDataMap.put("EngineNumber", getEngineNumber());
            metaDataMap.put("SourceIdentifierType", getSourceIdentifierType());
            metaDataMap.put("SourceIdentifierValue", getSourceIdentifierValue());
            metaDataMap.put("LocalVIN", getLocalVIN());
            metaDataMap.put("XVehicleKORHistActionCode", getXVehicleKORHistActionCode());
            metaDataMap.put("XVehicleKORHistCreateDate", getXVehicleKORHistCreateDate());
            metaDataMap.put("XVehicleKORHistCreatedBy", getXVehicleKORHistCreatedBy());
            metaDataMap.put("XVehicleKORHistEndDate", getXVehicleKORHistEndDate());
            metaDataMap.put("XVehicleKORHistoryIdPK", getXVehicleKORHistoryIdPK());
            metaDataMap.put("XVehicleKORLastUpdateDate", getXVehicleKORLastUpdateDate());
            metaDataMap.put("XVehicleKORLastUpdateTxId", getXVehicleKORLastUpdateTxId());
            metaDataMap.put("XVehicleKORLastUpdateUser", getXVehicleKORLastUpdateUser());
            bRequireMapRefresh = false;
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the control object on this business object.
     *
     * @see com.dwl.base.DWLCommon#setControl(DWLControl)
     * @generated
     */
    public void setControl(DWLControl newDWLControl) {
        super.setControl(newDWLControl);

        if (eObjXVehicleKOR != null) {
            eObjXVehicleKOR.setControl(newDWLControl);
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the entity object associated with this business object.
     *
     * @generated
     */
    public EObjXVehicleKOR getEObjXVehicleKOR() {
        bRequireMapRefresh = true;
        return eObjXVehicleKOR;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the entity object associated with this business object.
     *
     * @param eObjXVehicleKOR
     *            The eObjXVehicleKOR to set.
     * @generated
     */
    public void setEObjXVehicleKOR(EObjXVehicleKOR eObjXVehicleKOR) {
        bRequireMapRefresh = true;
        this.eObjXVehicleKOR = eObjXVehicleKOR;
        if (this.eObjXVehicleKOR != null && this.eObjXVehicleKOR.getControl() == null) {
            DWLControl control = this.getControl();
            if (control != null) {
                this.eObjXVehicleKOR.setControl(control);
            }
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xVehicleKORpkId attribute.
     * 
     * @generated
     */
    public String getXVehicleKORpkId (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXVehicleKOR.getXVehicleKORpkId());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xVehicleKORpkId attribute.
     * 
     * @param newXVehicleKORpkId
     *     The new value of xVehicleKORpkId.
     * @generated
     */
    public void setXVehicleKORpkId( String newXVehicleKORpkId ) throws Exception {
        metaDataMap.put("XVehicleKORpkId", newXVehicleKORpkId);

        if (newXVehicleKORpkId == null || newXVehicleKORpkId.equals("")) {
            newXVehicleKORpkId = null;


        }
        eObjXVehicleKOR.setXVehicleKORpkId( DWLFunctionUtils.getLongFromString(newXVehicleKORpkId) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the globalVIN attribute.
     * 
     * @generated
     */
    public String getGlobalVIN (){
   
        return eObjXVehicleKOR.getGlobalVIN();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the globalVIN attribute.
     * 
     * @param newGlobalVIN
     *     The new value of globalVIN.
     * @generated
     */
    public void setGlobalVIN( String newGlobalVIN ) throws Exception {
        metaDataMap.put("GlobalVIN", newGlobalVIN);

        if (newGlobalVIN == null || newGlobalVIN.equals("")) {
            newGlobalVIN = null;


        }
        eObjXVehicleKOR.setGlobalVIN( newGlobalVIN );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the bauMuster attribute.
     * 
     * @generated
     */
    public String getBauMuster (){
   
        return eObjXVehicleKOR.getBauMuster();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the bauMuster attribute.
     * 
     * @param newBauMuster
     *     The new value of bauMuster.
     * @generated
     */
    public void setBauMuster( String newBauMuster ) throws Exception {
        metaDataMap.put("BauMuster", newBauMuster);

        if (newBauMuster == null || newBauMuster.equals("")) {
            newBauMuster = null;


        }
        eObjXVehicleKOR.setBauMuster( newBauMuster );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the typeClass attribute.
     * 
     * @generated
     */
    public String getTypeClass (){
   
        return eObjXVehicleKOR.getTypeClass();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the typeClass attribute.
     * 
     * @param newTypeClass
     *     The new value of typeClass.
     * @generated
     */
    public void setTypeClass( String newTypeClass ) throws Exception {
        metaDataMap.put("TypeClass", newTypeClass);

        if (newTypeClass == null || newTypeClass.equals("")) {
            newTypeClass = null;


        }
        eObjXVehicleKOR.setTypeClass( newTypeClass );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the subMuster attribute.
     * 
     * @generated
     */
    public String getSubMuster (){
   
        return eObjXVehicleKOR.getSubMuster();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the subMuster attribute.
     * 
     * @param newSubMuster
     *     The new value of subMuster.
     * @generated
     */
    public void setSubMuster( String newSubMuster ) throws Exception {
        metaDataMap.put("SubMuster", newSubMuster);

        if (newSubMuster == null || newSubMuster.equals("")) {
            newSubMuster = null;


        }
        eObjXVehicleKOR.setSubMuster( newSubMuster );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the color attribute.
     * 
     * @generated
     */
    public String getColor (){
   
        return eObjXVehicleKOR.getColor();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the color attribute.
     * 
     * @param newColor
     *     The new value of color.
     * @generated
     */
    public void setColor( String newColor ) throws Exception {
        metaDataMap.put("Color", newColor);

        if (newColor == null || newColor.equals("")) {
            newColor = null;


        }
        eObjXVehicleKOR.setColor( newColor );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the trim attribute.
     * 
     * @generated
     */
    public String getTrim (){
   
        return eObjXVehicleKOR.getTrim();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the trim attribute.
     * 
     * @param newTrim
     *     The new value of trim.
     * @generated
     */
    public void setTrim( String newTrim ) throws Exception {
        metaDataMap.put("Trim", newTrim);

        if (newTrim == null || newTrim.equals("")) {
            newTrim = null;


        }
        eObjXVehicleKOR.setTrim( newTrim );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the batchInd attribute.
     * 
     * @generated
     */
    public String getBatchInd (){
   
        return eObjXVehicleKOR.getBatchInd();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the batchInd attribute.
     * 
     * @param newBatchInd
     *     The new value of batchInd.
     * @generated
     */
    public void setBatchInd( String newBatchInd ) throws Exception {
        metaDataMap.put("BatchInd", newBatchInd);

        if (newBatchInd == null || newBatchInd.equals("")) {
            newBatchInd = null;


        }
        eObjXVehicleKOR.setBatchInd( newBatchInd );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the marketName attribute.
     * 
     * @generated
     */
    public String getMarketName (){
   
        return eObjXVehicleKOR.getMarketName();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the marketName attribute.
     * 
     * @param newMarketName
     *     The new value of marketName.
     * @generated
     */
    public void setMarketName( String newMarketName ) throws Exception {
        metaDataMap.put("MarketName", newMarketName);

        if (newMarketName == null || newMarketName.equals("")) {
            newMarketName = null;


        }
        eObjXVehicleKOR.setMarketName( newMarketName );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the lastModifiedSystemDate attribute.
     * 
     * @generated
     */
    public String getLastModifiedSystemDate (){
   
        return DWLFunctionUtils.getStringFromTimestamp(eObjXVehicleKOR.getLastModifiedSystemDate());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the lastModifiedSystemDate attribute.
     * 
     * @param newLastModifiedSystemDate
     *     The new value of lastModifiedSystemDate.
     * @generated
     */
    public void setLastModifiedSystemDate( String newLastModifiedSystemDate ) throws Exception {
        metaDataMap.put("LastModifiedSystemDate", newLastModifiedSystemDate);
       	isValidLastModifiedSystemDate = true;

        if (newLastModifiedSystemDate == null || newLastModifiedSystemDate.equals("")) {
            newLastModifiedSystemDate = null;
            eObjXVehicleKOR.setLastModifiedSystemDate(null);


        }
    else {
        	if (DateValidator.validates(newLastModifiedSystemDate)) {
           		eObjXVehicleKOR.setLastModifiedSystemDate(DateFormatter.getStartDateTimestamp(newLastModifiedSystemDate));
            	metaDataMap.put("LastModifiedSystemDate", getLastModifiedSystemDate());
        	} else {
            	if (Configuration.getConfiguration().getConfigItem(
              "/IBM/DWLCommonServices/InternalValidation/enabled").getBooleanValue()) {
                	if (metaDataMap.get("LastModifiedSystemDate") != null) {
                    	metaDataMap.put("LastModifiedSystemDate", "");
                	}
                	isValidLastModifiedSystemDate = false;
                	eObjXVehicleKOR.setLastModifiedSystemDate(null);
            	}
        	}
        }
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the createDate attribute.
     * 
     * @generated
     */
    public String getCreateDate (){
   
        return DWLFunctionUtils.getStringFromTimestamp(eObjXVehicleKOR.getCreateDate());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the createDate attribute.
     * 
     * @param newCreateDate
     *     The new value of createDate.
     * @generated
     */
    public void setCreateDate( String newCreateDate ) throws Exception {
        metaDataMap.put("CreateDate", newCreateDate);
       	isValidCreateDate = true;

        if (newCreateDate == null || newCreateDate.equals("")) {
            newCreateDate = null;
            eObjXVehicleKOR.setCreateDate(null);


        }
    else {
        	if (DateValidator.validates(newCreateDate)) {
           		eObjXVehicleKOR.setCreateDate(DateFormatter.getStartDateTimestamp(newCreateDate));
            	metaDataMap.put("CreateDate", getCreateDate());
        	} else {
            	if (Configuration.getConfiguration().getConfigItem(
              "/IBM/DWLCommonServices/InternalValidation/enabled").getBooleanValue()) {
                	if (metaDataMap.get("CreateDate") != null) {
                    	metaDataMap.put("CreateDate", "");
                	}
                	isValidCreateDate = false;
                	eObjXVehicleKOR.setCreateDate(null);
            	}
        	}
        }
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the changedDate attribute.
     * 
     * @generated
     */
    public String getChangedDate (){
   
        return DWLFunctionUtils.getStringFromTimestamp(eObjXVehicleKOR.getChangedDate());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the changedDate attribute.
     * 
     * @param newChangedDate
     *     The new value of changedDate.
     * @generated
     */
    public void setChangedDate( String newChangedDate ) throws Exception {
        metaDataMap.put("ChangedDate", newChangedDate);
       	isValidChangedDate = true;

        if (newChangedDate == null || newChangedDate.equals("")) {
            newChangedDate = null;
            eObjXVehicleKOR.setChangedDate(null);


        }
    else {
        	if (DateValidator.validates(newChangedDate)) {
           		eObjXVehicleKOR.setChangedDate(DateFormatter.getStartDateTimestamp(newChangedDate));
            	metaDataMap.put("ChangedDate", getChangedDate());
        	} else {
            	if (Configuration.getConfiguration().getConfigItem(
              "/IBM/DWLCommonServices/InternalValidation/enabled").getBooleanValue()) {
                	if (metaDataMap.get("ChangedDate") != null) {
                    	metaDataMap.put("ChangedDate", "");
                	}
                	isValidChangedDate = false;
                	eObjXVehicleKOR.setChangedDate(null);
            	}
        	}
        }
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the lastServiceDate attribute.
     * 
     * @generated
     */
    public String getLastServiceDate (){
   
        return DWLFunctionUtils.getStringFromTimestamp(eObjXVehicleKOR.getLastServiceDate());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the lastServiceDate attribute.
     * 
     * @param newLastServiceDate
     *     The new value of lastServiceDate.
     * @generated
     */
    public void setLastServiceDate( String newLastServiceDate ) throws Exception {
        metaDataMap.put("LastServiceDate", newLastServiceDate);
       	isValidLastServiceDate = true;

        if (newLastServiceDate == null || newLastServiceDate.equals("")) {
            newLastServiceDate = null;
            eObjXVehicleKOR.setLastServiceDate(null);


        }
    else {
        	if (DateValidator.validates(newLastServiceDate)) {
           		eObjXVehicleKOR.setLastServiceDate(DateFormatter.getStartDateTimestamp(newLastServiceDate));
            	metaDataMap.put("LastServiceDate", getLastServiceDate());
        	} else {
            	if (Configuration.getConfiguration().getConfigItem(
              "/IBM/DWLCommonServices/InternalValidation/enabled").getBooleanValue()) {
                	if (metaDataMap.get("LastServiceDate") != null) {
                    	metaDataMap.put("LastServiceDate", "");
                	}
                	isValidLastServiceDate = false;
                	eObjXVehicleKOR.setLastServiceDate(null);
            	}
        	}
        }
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the sFDCId attribute.
     * 
     * @generated
     */
    public String getSFDCId (){
   
        return eObjXVehicleKOR.getSFDCId();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the sFDCId attribute.
     * 
     * @param newSFDCId
     *     The new value of sFDCId.
     * @generated
     */
    public void setSFDCId( String newSFDCId ) throws Exception {
        metaDataMap.put("SFDCId", newSFDCId);

        if (newSFDCId == null || newSFDCId.equals("")) {
            newSFDCId = null;


        }
        eObjXVehicleKOR.setSFDCId( newSFDCId );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the vehicleAddressType attribute.
     * 
     * @generated
     */
    public String getVehicleAddressType (){
   
        return eObjXVehicleKOR.getVehicleAddressType();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the vehicleAddressType attribute.
     * 
     * @param newVehicleAddressType
     *     The new value of vehicleAddressType.
     * @generated
     */
    public void setVehicleAddressType( String newVehicleAddressType ) throws Exception {
        metaDataMap.put("VehicleAddressType", newVehicleAddressType);

        if (newVehicleAddressType == null || newVehicleAddressType.equals("")) {
            newVehicleAddressType = null;


        }
        eObjXVehicleKOR.setVehicleAddressType( newVehicleAddressType );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the vehicleType attribute.
     * 
     * @generated
     */
    public String getVehicleType (){
   
        return eObjXVehicleKOR.getVehicleType();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the vehicleType attribute.
     * 
     * @param newVehicleType
     *     The new value of vehicleType.
     * @generated
     */
    public void setVehicleType( String newVehicleType ) throws Exception {
        metaDataMap.put("VehicleType", newVehicleType);

        if (newVehicleType == null || newVehicleType.equals("")) {
            newVehicleType = null;


        }
        eObjXVehicleKOR.setVehicleType( newVehicleType );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the deleteFlag attribute.
     * 
     * @generated
     */
    public String getDeleteFlag (){
   
        return eObjXVehicleKOR.getDeleteFlag();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the deleteFlag attribute.
     * 
     * @param newDeleteFlag
     *     The new value of deleteFlag.
     * @generated
     */
    public void setDeleteFlag( String newDeleteFlag ) throws Exception {
        metaDataMap.put("DeleteFlag", newDeleteFlag);

        if (newDeleteFlag == null || newDeleteFlag.equals("")) {
            newDeleteFlag = null;


        }
        eObjXVehicleKOR.setDeleteFlag( newDeleteFlag );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the endDate attribute.
     * 
     * @generated
     */
    public String getEndDate (){
   
        return DWLFunctionUtils.getStringFromTimestamp(eObjXVehicleKOR.getEndDate());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the endDate attribute.
     * 
     * @param newEndDate
     *     The new value of endDate.
     * @generated
     */
    public void setEndDate( String newEndDate ) throws Exception {
        metaDataMap.put("EndDate", newEndDate);
       	isValidEndDate = true;

        if (newEndDate == null || newEndDate.equals("")) {
            newEndDate = null;
            eObjXVehicleKOR.setEndDate(null);


        }
    else {
        	if (DateValidator.validates(newEndDate)) {
           		eObjXVehicleKOR.setEndDate(DateFormatter.getStartDateTimestamp(newEndDate));
            	metaDataMap.put("EndDate", getEndDate());
        	} else {
            	if (Configuration.getConfiguration().getConfigItem(
              "/IBM/DWLCommonServices/InternalValidation/enabled").getBooleanValue()) {
                	if (metaDataMap.get("EndDate") != null) {
                    	metaDataMap.put("EndDate", "");
                	}
                	isValidEndDate = false;
                	eObjXVehicleKOR.setEndDate(null);
            	}
        	}
        }
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the engineNumber attribute.
     * 
     * @generated
     */
    public String getEngineNumber (){
   
        return eObjXVehicleKOR.getEngineNumber();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the engineNumber attribute.
     * 
     * @param newEngineNumber
     *     The new value of engineNumber.
     * @generated
     */
    public void setEngineNumber( String newEngineNumber ) throws Exception {
        metaDataMap.put("EngineNumber", newEngineNumber);

        if (newEngineNumber == null || newEngineNumber.equals("")) {
            newEngineNumber = null;


        }
        eObjXVehicleKOR.setEngineNumber( newEngineNumber );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the sourceIdentifierType attribute.
     * 
     * @generated
     */
    public String getSourceIdentifierType (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXVehicleKOR.getSourceIdentifier());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the sourceIdentifierType attribute.
     * 
     * @param newSourceIdentifierType
     *     The new value of sourceIdentifierType.
     * @generated
     */
    public void setSourceIdentifierType( String newSourceIdentifierType ) throws Exception {
        metaDataMap.put("SourceIdentifierType", newSourceIdentifierType);

        if (newSourceIdentifierType == null || newSourceIdentifierType.equals("")) {
            newSourceIdentifierType = null;


        }
        eObjXVehicleKOR.setSourceIdentifier( DWLFunctionUtils.getLongFromString(newSourceIdentifierType) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the sourceIdentifierValue attribute.
     * 
     * @generated
     */
    public String getSourceIdentifierValue (){
      return sourceIdentifierValue;
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the sourceIdentifierValue attribute.
     * 
     * @param newSourceIdentifierValue
     *     The new value of sourceIdentifierValue.
     * @generated
     */
    public void setSourceIdentifierValue( String newSourceIdentifierValue ) throws Exception {
        metaDataMap.put("SourceIdentifierValue", newSourceIdentifierValue);

        if (newSourceIdentifierValue == null || newSourceIdentifierValue.equals("")) {
            newSourceIdentifierValue = null;


        }
        sourceIdentifierValue = newSourceIdentifierValue;
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the localVIN attribute.
     * 
     * @generated
     */
    public String getLocalVIN (){
   
        return eObjXVehicleKOR.getLocalVIN();
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the localVIN attribute.
     * 
     * @param newLocalVIN
     *     The new value of localVIN.
     * @generated
     */
    public void setLocalVIN( String newLocalVIN ) throws Exception {
        metaDataMap.put("LocalVIN", newLocalVIN);

        if (newLocalVIN == null || newLocalVIN.equals("")) {
            newLocalVIN = null;


        }
        eObjXVehicleKOR.setLocalVIN( newLocalVIN );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateTxId attribute.
     *
     * @generated
     */
    public String getXVehicleKORLastUpdateTxId() {
        return DWLFunctionUtils.getStringFromLong(eObjXVehicleKOR.getLastUpdateTxId());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateUser attribute.
     *
     * @generated
     */
    public String getXVehicleKORLastUpdateUser() {
        return eObjXVehicleKOR.getLastUpdateUser();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateDt attribute.
     *
     * @generated
     */
    public String getXVehicleKORLastUpdateDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXVehicleKOR.getLastUpdateDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateTxId attribute.
     *
     * @param newLastUpdateTxId
     *     The new value of LastUpdateTxId.
     * @generated
     */
    public void setXVehicleKORLastUpdateTxId(String newLastUpdateTxId) {
        metaDataMap.put("XVehicleKORLastUpdateTxId", newLastUpdateTxId);

        if ((newLastUpdateTxId == null) || newLastUpdateTxId.equals("")) {
            newLastUpdateTxId = null;
        }
        eObjXVehicleKOR.setLastUpdateTxId(DWLFunctionUtils.getLongFromString(newLastUpdateTxId));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateUser attribute.
     *
     * @param newLastUpdateUser
     *     The new value of LastUpdateUser.
     * @generated
     */
    public void setXVehicleKORLastUpdateUser(String newLastUpdateUser) {
        metaDataMap.put("XVehicleKORLastUpdateUser", newLastUpdateUser);

        if ((newLastUpdateUser == null) || newLastUpdateUser.equals("")) {
            newLastUpdateUser = null;
        }
        eObjXVehicleKOR.setLastUpdateUser(newLastUpdateUser);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateDt attribute.
     *
     * @param newLastUpdateDt
     *     The new value of LastUpdateDt.
     * @throws Exception
     * @generated
     */
    public void setXVehicleKORLastUpdateDate(String newLastUpdateDt) throws Exception {
        metaDataMap.put("XVehicleKORLastUpdateDate", newLastUpdateDt);

        if ((newLastUpdateDt == null) || newLastUpdateDt.equals("")) {
            newLastUpdateDt = null;
        }

        eObjXVehicleKOR.setLastUpdateDt(DWLFunctionUtils.getTimestampFromTimestampString(newLastUpdateDt));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XVehicleKORHistActionCode history attribute.
     *
     * @generated
     */
    public String getXVehicleKORHistActionCode() {
        return eObjXVehicleKOR.getHistActionCode();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XVehicleKORHistActionCode history attribute.
     *
     * @param aXVehicleKORHistActionCode
     *     The new value of XVehicleKORHistActionCode.
     * @generated
     */
    public void setXVehicleKORHistActionCode(String aXVehicleKORHistActionCode) {
        metaDataMap.put("XVehicleKORHistActionCode", aXVehicleKORHistActionCode);

        if ((aXVehicleKORHistActionCode == null) || aXVehicleKORHistActionCode.equals("")) {
            aXVehicleKORHistActionCode = null;
        }
        eObjXVehicleKOR.setHistActionCode(aXVehicleKORHistActionCode);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XVehicleKORHistCreateDate history attribute.
     *
     * @generated
     */
    public String getXVehicleKORHistCreateDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXVehicleKOR.getHistCreateDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XVehicleKORHistCreateDate history attribute.
     *
     * @param aXVehicleKORHistCreateDate
     *     The new value of XVehicleKORHistCreateDate.
     * @generated
     */
    public void setXVehicleKORHistCreateDate(String aXVehicleKORHistCreateDate) throws Exception{
        metaDataMap.put("XVehicleKORHistCreateDate", aXVehicleKORHistCreateDate);

        if ((aXVehicleKORHistCreateDate == null) || aXVehicleKORHistCreateDate.equals("")) {
            aXVehicleKORHistCreateDate = null;
        }

        eObjXVehicleKOR.setHistCreateDt(DWLFunctionUtils.getTimestampFromTimestampString(aXVehicleKORHistCreateDate));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XVehicleKORHistCreatedBy history attribute.
     *
     * @generated
     */
    public String getXVehicleKORHistCreatedBy() {
        return eObjXVehicleKOR.getHistCreatedBy();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XVehicleKORHistCreatedBy history attribute.
     *
     * @param aXVehicleKORHistCreatedBy
     *     The new value of XVehicleKORHistCreatedBy.
     * @generated
     */
    public void setXVehicleKORHistCreatedBy(String aXVehicleKORHistCreatedBy) {
        metaDataMap.put("XVehicleKORHistCreatedBy", aXVehicleKORHistCreatedBy);

        if ((aXVehicleKORHistCreatedBy == null) || aXVehicleKORHistCreatedBy.equals("")) {
            aXVehicleKORHistCreatedBy = null;
        }

        eObjXVehicleKOR.setHistCreatedBy(aXVehicleKORHistCreatedBy);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XVehicleKORHistEndDate history attribute.
     *
     * @generated
     */
    public String getXVehicleKORHistEndDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXVehicleKOR.getHistEndDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XVehicleKORHistEndDate history attribute.
     *
     * @param aXVehicleKORHistEndDate
     *     The new value of XVehicleKORHistEndDate.
     * @generated
     */
    public void setXVehicleKORHistEndDate(String aXVehicleKORHistEndDate) throws Exception{
        metaDataMap.put("XVehicleKORHistEndDate", aXVehicleKORHistEndDate);

        if ((aXVehicleKORHistEndDate == null) || aXVehicleKORHistEndDate.equals("")) {
            aXVehicleKORHistEndDate = null;
        }
        eObjXVehicleKOR.setHistEndDt(DWLFunctionUtils.getTimestampFromTimestampString(aXVehicleKORHistEndDate));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XVehicleKORHistoryIdPK history attribute.
     *
     * @generated
     */
    public String getXVehicleKORHistoryIdPK() {
        return DWLFunctionUtils.getStringFromLong(eObjXVehicleKOR.getHistoryIdPK());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XVehicleKORHistoryIdPK history attribute.
     *
     * @param aXVehicleKORHistoryIdPK
     *     The new value of XVehicleKORHistoryIdPK.
     * @generated
     */
    public void setXVehicleKORHistoryIdPK(String aXVehicleKORHistoryIdPK) {
        metaDataMap.put("XVehicleKORHistoryIdPK", aXVehicleKORHistoryIdPK);

        if ((aXVehicleKORHistoryIdPK == null) || aXVehicleKORHistoryIdPK.equals("")) {
            aXVehicleKORHistoryIdPK = null;
        }
        eObjXVehicleKOR.setHistoryIdPK(DWLFunctionUtils.getLongFromString(aXVehicleKORHistoryIdPK));
    }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation during an add transaction.
     *
     * @generated
     */
    public DWLStatus validateAdd(int level, DWLStatus status) throws Exception {

        status = super.validateAdd(level, status);
        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0038I Add any controller-level custom validation logic to be
            // executed for this object during an "add" transaction

        }

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            // MDM_TODO0: CDKWB0039I Add any component-level custom validation logic to be
            // executed for this object during an "add" transaction
        }
        status = getValidationStatus(level, status);
        return status;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation during an update transaction.
     *
     * @generated
     */
    public DWLStatus validateUpdate(int level, DWLStatus status) throws Exception {
    logger.finest("ENTER validateUpdate(int level, DWLStatus status)");

        status = super.validateUpdate(level, status);
        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0040I Add any controller-level custom validation logic to be
            // executed for this object during an "update" transaction

            if (eObjXVehicleKOR.getXVehicleKORpkId() == null) {
                DWLError err = new DWLError();
                err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XVEHICLE_KORBOBJ).longValue());
                err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.XVEHICLEKOR_XVEHICLEKORPKID_NULL).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                	String infoForLogging="Error: Validation error occured for update. No primary key for entity XVehicleKOR, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("validateUpdate(int level, DWLStatus status) " + infoForLogging);
                }
                status.addError(err);
            }
            if (eObjXVehicleKOR.getLastUpdateDt() == null) {
                DWLError err = new DWLError();
                err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XVEHICLE_KORBOBJ).longValue());
                err.setReasonCode(new Long(DWLUtilErrorReasonCode.LAST_UPDATED_DATE_NULL).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
                if (logger.isFinestEnabled()) {
                	String infoForLogging="Error: Validation error occured for update. No last update date for entity XVehicleKOR, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("validateUpdate(int level, DWLStatus status) " + infoForLogging);
                }
                status.addError(err);
            }
        }

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            assignBeforeImageValues(metaDataMap);
            
            // MDM_TODO0: CDKWB0041I Add any component-level custom validation logic to be
            // executed for this object during an "update" transaction
        }
        status = getValidationStatus(level, status);
    if (logger.isFinestEnabled()) {
        	String returnValue = status.toString();
      logger.finest("RETURN validateUpdate(int level, DWLStatus status) " + returnValue);
    }
        return status;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Populate the before image of this business object.
     *
     * @see com.dwl.base.DWLCommon#populateBeforeImage()
     * @generated
     */
    public void populateBeforeImage() throws DWLBaseException {
    logger.finest("ENTER populateBeforeImage()");

        DSEAAdditionsExts comp = null;
        try {
        
      comp = (DSEAAdditionsExts)TCRMClassFactory.getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
        	
        } catch (Exception e) {
      if (logger.isFinestEnabled()) {
        String infoForLogging="Error: Fatal error while updating record " + e.getMessage();
      logger.finest("populateBeforeImage() " + infoForLogging);
      }
            DWLExceptionUtils.throwDWLBaseException(e, 
            									new DWLUpdateException(e.getMessage()), 
            									this.getStatus(), DWLStatus.FATAL,
                                  DSEAAdditionsExtsComponentID.XVEHICLE_KORBOBJ, 
                                  "DIERR",
                                  DSEAAdditionsExtsErrorReasonCode.XVEHICLEKOR_BEFORE_IMAGE_NOT_POPULATED, 
                                  this.getControl());
        }
        
        comp.loadBeforeImage(this);
    logger.finest("RETURN populateBeforeImage()");
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation common to both add and update transactions.
     *
     * @generated
     */
     
    private DWLStatus getValidationStatus(int level, DWLStatus status) throws Exception {
    logger.finest("ENTER getValidationStatus(int level, DWLStatus status)");

        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0034I Add any common controller-level custom validation
            // logic to be executed for this object during either "add" or
            // "update" transactions
    		controllerValidation_LastModifiedSystemDate(status);
    		controllerValidation_CreateDate(status);
    		controllerValidation_ChangedDate(status);
    		controllerValidation_LastServiceDate(status);
    		controllerValidation_EndDate(status);
    		controllerValidation_SourceIdentifier(status);
    	}

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            // MDM_TODO0: CDKWB0035I Add any common component-level custom validation logic
            // to be executed for this object during either "add" or "update"
            // transactions
    		componentValidation_LastModifiedSystemDate(status);
    		componentValidation_CreateDate(status);
    		componentValidation_ChangedDate(status);
    		componentValidation_LastServiceDate(status);
    		componentValidation_EndDate(status);
    		componentValidation_SourceIdentifier(status);
        }
        
        if (logger.isFinestEnabled()) {
            String returnValue = status.toString();
      logger.finest("RETURN getValidationStatus(int level, DWLStatus status) " + returnValue);
        }
    
        return status;
    }

    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "LastModifiedSystemDate"
     *
     * @generated
     */
	private void componentValidation_LastModifiedSystemDate(DWLStatus status) {
  
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "CreateDate"
     *
     * @generated
     */
	private void componentValidation_CreateDate(DWLStatus status) {
  
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "ChangedDate"
     *
     * @generated
     */
	private void componentValidation_ChangedDate(DWLStatus status) {
  
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "LastServiceDate"
     *
     * @generated
     */
	private void componentValidation_LastServiceDate(DWLStatus status) {
  
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "EndDate"
     *
     * @generated
     */
	private void componentValidation_EndDate(DWLStatus status) {
  
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "SourceIdentifier"
     *
     * @generated
     */
	private void componentValidation_SourceIdentifier(DWLStatus status) {
  
      //persistent code type
            boolean isSourceIdentifierNull = false;
            if ((eObjXVehicleKOR.getSourceIdentifier() == null) &&
               ((getSourceIdentifierValue() == null) || 
                 getSourceIdentifierValue().trim().equals(""))) {
                isSourceIdentifierNull = true;
            }
            if (isSourceIdentifierNull) {
                DWLError err = createDWLError("XVehicleKOR", "SourceIdentifier", DSEAAdditionsExtsErrorReasonCode.XVEHICLEKOR_SOURCEIDENTIFIER_NULL);
                status.addError(err); 
            }
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "LastModifiedSystemDate"
     *
     * @generated
     */
	private void controllerValidation_LastModifiedSystemDate(DWLStatus status) throws Exception {
  
            boolean isLastModifiedSystemDateNull = (eObjXVehicleKOR.getLastModifiedSystemDate() == null);
            if (!isValidLastModifiedSystemDate) {
              	DWLError err = new DWLError();
               	err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XVEHICLE_KORBOBJ).longValue());
               	err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XVEHICLEKOR_LASTMODIFIEDSYSTEMDATE).longValue());
               	err.setErrorType(DWLErrorCode.DATA_INVALID_ERROR);
                String infoForLogging="Error: Validation error. Invalid time specified on property LastModifiedSystemDate in entity XVehicleKOR, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode();
      logger.finest("controllerValidation_LastModifiedSystemDate " + infoForLogging);
               	status.addError(err);
            } 
    	}
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "CreateDate"
     *
     * @generated
     */
	private void controllerValidation_CreateDate(DWLStatus status) throws Exception {
  
            boolean isCreateDateNull = (eObjXVehicleKOR.getCreateDate() == null);
            if (!isValidCreateDate) {
              	DWLError err = new DWLError();
               	err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XVEHICLE_KORBOBJ).longValue());
               	err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XVEHICLEKOR_CREATEDATE).longValue());
               	err.setErrorType(DWLErrorCode.DATA_INVALID_ERROR);
                String infoForLogging="Error: Validation error. Invalid time specified on property CreateDate in entity XVehicleKOR, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode();
      logger.finest("controllerValidation_CreateDate " + infoForLogging);
               	status.addError(err);
            } 
    	}
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "ChangedDate"
     *
     * @generated
     */
	private void controllerValidation_ChangedDate(DWLStatus status) throws Exception {
  
            boolean isChangedDateNull = (eObjXVehicleKOR.getChangedDate() == null);
            if (!isValidChangedDate) {
              	DWLError err = new DWLError();
               	err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XVEHICLE_KORBOBJ).longValue());
               	err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XVEHICLEKOR_CHANGEDDATE).longValue());
               	err.setErrorType(DWLErrorCode.DATA_INVALID_ERROR);
                String infoForLogging="Error: Validation error. Invalid time specified on property ChangedDate in entity XVehicleKOR, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode();
      logger.finest("controllerValidation_ChangedDate " + infoForLogging);
               	status.addError(err);
            } 
    	}
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "LastServiceDate"
     *
     * @generated
     */
	private void controllerValidation_LastServiceDate(DWLStatus status) throws Exception {
  
            boolean isLastServiceDateNull = (eObjXVehicleKOR.getLastServiceDate() == null);
            if (!isValidLastServiceDate) {
              	DWLError err = new DWLError();
               	err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XVEHICLE_KORBOBJ).longValue());
               	err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XVEHICLEKOR_LASTSERVICEDATE).longValue());
               	err.setErrorType(DWLErrorCode.DATA_INVALID_ERROR);
                String infoForLogging="Error: Validation error. Invalid time specified on property LastServiceDate in entity XVehicleKOR, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode();
      logger.finest("controllerValidation_LastServiceDate " + infoForLogging);
               	status.addError(err);
            } 
    	}
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "EndDate"
     *
     * @generated
     */
	private void controllerValidation_EndDate(DWLStatus status) throws Exception {
  
            boolean isEndDateNull = (eObjXVehicleKOR.getEndDate() == null);
            if (!isValidEndDate) {
              	DWLError err = new DWLError();
               	err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XVEHICLE_KORBOBJ).longValue());
               	err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XVEHICLEKOR_ENDDATE).longValue());
               	err.setErrorType(DWLErrorCode.DATA_INVALID_ERROR);
                String infoForLogging="Error: Validation error. Invalid time specified on property EndDate in entity XVehicleKOR, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode();
      logger.finest("controllerValidation_EndDate " + infoForLogging);
               	status.addError(err);
            } 
    	}
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "SourceIdentifier"
     *
     * @generated
     */
	private void controllerValidation_SourceIdentifier(DWLStatus status) throws Exception {
  
      //persistent code type
            boolean isSourceIdentifierNull = false;
            if ((eObjXVehicleKOR.getSourceIdentifier() == null) &&
               ((getSourceIdentifierValue() == null) || 
                 getSourceIdentifierValue().trim().equals(""))) {
                isSourceIdentifierNull = true;
            }
            if (isSourceIdentifierNull) {
                DWLError err = createDWLError("XVehicleKOR", "SourceIdentifier", DSEAAdditionsExtsErrorReasonCode.XVEHICLEKOR_SOURCEIDENTIFIER_NULL);
                status.addError(err); 
            }
            if (!isSourceIdentifierNull) {
                if (checkForInvalidXvehiclekorSourceidentifier()) {
                    DWLError err = new DWLError();
                    err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XVEHICLE_KORBOBJ).longValue());
                    err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XVEHICLEKOR_SOURCEIDENTIFIER).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                    String infoForLogging="Error: Custom validation error occured for entity XVehicleKOR, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("controllerValidation_SourceIdentifier " + infoForLogging);
        }
                status.addError(err);
            }

             }
    			
    	}
    private DWLError createDWLError(String entityName, String propertyName,String reasonCode){	
		DWLError err = new DWLError();
		err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XVEHICLE_KORBOBJ).longValue());
		err.setReasonCode(new Long(reasonCode).longValue());
		err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
			String infoForLogging="Error: Validation error occured. Property " + propertyName + " is null, in entity " + entityName + ", component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
			logger.finest("createDWLError " + infoForLogging);
		}
		return err;
    }
    
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Check the value of the field SourceIdentifier and return true if the
     * error reason INVALID_XVEHICLEKOR_SOURCEIDENTIFIER should be returned.
     *
     * @generated
  **/
	private boolean checkForInvalidXvehiclekorSourceidentifier() throws Exception {
    logger.finest("ENTER checkForInvalidXvehiclekorSourceidentifier()");
        boolean notValid = false;
      	String langId = (String) this.getControl().get(DWLControlKeys.LANG_ID);
      	CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
    Long codeType = DWLFunctionUtils.getLongFromString( getSourceIdentifierType() );
    String codeValue = getSourceIdentifierValue();
    if( codeValue != null && codeValue.trim().equals("")){
      codeValue = null;
    }
     
        if ( codeType != null && codeValue == null ){

             if( codeTypeCompHelper.isCodeValid("cdsourceidenttp", langId, getSourceIdentifierType(),
                 CodeTypeComponentHelper.ACTIVE, getControl())) {
                 CodeTypeBObj ctBObj = codeTypeCompHelper
                 					.getCodeTypeByCode("cdsourceidenttp", langId, getSourceIdentifierType(),
                         								getControl());
               	if (ctBObj != null) {
                   	setSourceIdentifierValue( ctBObj.getvalue() );
               	}
             }
             else{
             	if (logger.isFinestEnabled()) {
              	 	String infoForLogging="NotValid 1";
      logger.finest("checkForInvalidXvehiclekorSourceidentifier() " + infoForLogging);
        }
                 notValid = true;
           }
        }
        else if (codeType == null && codeValue != null ){
          
             CodeTypeBObj ctBObj = codeTypeCompHelper
                      .getCodeTypeByValue("cdsourceidenttp", langId, codeValue,
                                 getControl());

             if (ctBObj != null) {
                 setSourceIdentifierType(ctBObj.gettp_cd());
             } 
             else {
             	if (logger.isFinestEnabled()) {
              	  	String infoForLogging="NotValid 2";
      logger.finest("checkForInvalidXvehiclekorSourceidentifier() " + infoForLogging);
        }
                  notValid = true;
             }
        }
        else if ( codeType != null && codeValue != null
             && !codeTypeCompHelper.isCodeValuePairValid("cdsourceidenttp", langId, getSourceIdentifierType(), 
                     new String[] { codeValue }, CodeTypeComponentHelper.ACTIVE, getControl())) {	
       if (logger.isFinestEnabled()) {
       		String infoForLogging="NotValid 3";
      logger.finest("checkForInvalidXvehiclekorSourceidentifier() " + infoForLogging);
       }
             notValid = true;
        }
        if (logger.isFinestEnabled()) {
      String returnValue ="" +notValid;
      logger.finest("RETURN checkForInvalidXvehiclekorSourceidentifier() " + returnValue);
    }
    return notValid;
     } 
				 



}

