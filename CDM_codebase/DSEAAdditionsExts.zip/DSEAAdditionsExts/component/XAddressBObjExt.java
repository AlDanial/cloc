
/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[95fc04bab59a0774c3af0b6928dde352]
 */

package com.ibm.daimler.dsea.component;

import com.dwl.base.util.DWLClassFactory;
import com.dwl.tcrm.exception.TCRMReadException;



import com.dwl.base.DWLControl;
import com.dwl.base.IDWLErrorMessage;

import com.dwl.base.constant.DWLControlKeys;

import com.dwl.base.error.DWLError;
import com.dwl.base.error.DWLErrorCode;
import com.dwl.base.error.DWLStatus;

import com.dwl.base.exception.DWLBaseException;

import com.dwl.base.util.DWLExceptionUtils;
import com.dwl.base.util.DWLFunctionUtils;

import com.dwl.management.config.client.Configuration;

import com.dwl.tcrm.common.IExtension;
import com.dwl.tcrm.common.ITCRMValidation;
import com.dwl.tcrm.common.TCRMErrorCode;

import com.dwl.tcrm.coreParty.component.TCRMAddressBObj;

import com.dwl.tcrm.utilities.DateFormatter;
import com.dwl.tcrm.utilities.DateValidator;

import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsComponentID;
import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsErrorReasonCode;

import com.ibm.daimler.dsea.entityObject.EObjXAddressExt;

import com.ibm.mdm.common.codetype.interfaces.CodeTypeComponentHelper;

import com.ibm.mdm.common.codetype.obj.CodeTypeBObj;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * This class provides the implementation of the business object
 * <code>XAddressBObjExt</code>.
 * 
 * @see com.dwl.tcrm.common.TCRMCommon
 * @generated
 */
 

@SuppressWarnings("serial")
public class XAddressBObjExt extends TCRMAddressBObj implements IExtension {

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected EObjXAddressExt eObjXAddressExt;
	/**
    * <!-- begin-user-doc -->
	  * <!-- end-user-doc -->
    * @generated 
    */
	 private final static com.dwl.base.logging.IDWLLogger logger = com.dwl.base.logging.DWLLoggerManager.getLogger(XAddressBObjExt.class);
		
 
	protected boolean isValidXAddressVerificationDate = true;
	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected String xSubcityValue;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected String xDistrictValue;


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */     
    public XAddressBObjExt() {
        super();
        init();
        eObjXAddressExt = new EObjXAddressExt(getEObjAddress());
        setComponentID(DSEAAdditionsExtsComponentID.XADDRESS_BOBJ_EXT);
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Initializes the fields required to populate the metaDataMap. Each key is
     * an element-level field of the business object.
     *
     * @generated
     */
    private void init() {
        metaDataMap.put("XAddressVerificationDate", null);
        metaDataMap.put("XSubcityType", null);
        metaDataMap.put("XSubcityValue", null);
        metaDataMap.put("XDistrictType", null);
        metaDataMap.put("XDistrictValue", null);
        metaDataMap.put("XBuildingName", null);
        metaDataMap.put("XStreetNumber", null);
        metaDataMap.put("XStreetName", null);
        metaDataMap.put("XSuburb", null);
        metaDataMap.put("XAddressHistActionCode", null);
        metaDataMap.put("XAddressHistCreateDate", null);
        metaDataMap.put("XAddressHistCreatedBy", null);
        metaDataMap.put("XAddressHistEndDate", null);
        metaDataMap.put("XAddressHistoryIdPK", null);
        metaDataMap.put("XAddressLastUpdateDate", null);
        metaDataMap.put("XAddressLastUpdateTxId", null);
        metaDataMap.put("XAddressLastUpdateUser", null);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Refreshes all the attributes this business object supports.
     *
     * @see com.dwl.base.DWLCommon#refreshMap()
     * @generated
     */
    public void refreshMap() {

        if (bRequireMapRefresh) {
            super.refreshMap();
            metaDataMap.put("XAddressVerificationDate", getXAddressVerificationDate());
            metaDataMap.put("XSubcityType", getXSubcityType());
            metaDataMap.put("XSubcityValue", getXSubcityValue());
            metaDataMap.put("XDistrictType", getXDistrictType());
            metaDataMap.put("XDistrictValue", getXDistrictValue());
            metaDataMap.put("XBuildingName", getXBuildingName());
            metaDataMap.put("XStreetNumber", getXStreetNumber());
            metaDataMap.put("XStreetName", getXStreetName());
            metaDataMap.put("XSuburb", getXSuburb());
            metaDataMap.put("XAddressHistActionCode", getXAddressHistActionCode());
            metaDataMap.put("XAddressHistCreateDate", getXAddressHistCreateDate());
            metaDataMap.put("XAddressHistCreatedBy", getXAddressHistCreatedBy());
            metaDataMap.put("XAddressHistEndDate", getXAddressHistEndDate());
            metaDataMap.put("XAddressHistoryIdPK", getXAddressHistoryIdPK());
            metaDataMap.put("XAddressLastUpdateDate", getXAddressLastUpdateDate());
            metaDataMap.put("XAddressLastUpdateTxId", getXAddressLastUpdateTxId());
            metaDataMap.put("XAddressLastUpdateUser", getXAddressLastUpdateUser());
            bRequireMapRefresh = false;
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the control object on this business object.
     *
     * @see com.dwl.base.DWLCommon#setControl(DWLControl)
     * @generated
     */
    public void setControl(DWLControl newDWLControl) {
        super.setControl(newDWLControl);

        if (eObjXAddressExt != null) {
            eObjXAddressExt.setControl(newDWLControl);
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the entity object associated with this business object.
     *
     * @generated
     */
    public EObjXAddressExt getEObjXAddressExt() {
        bRequireMapRefresh = true;
        return eObjXAddressExt;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the entity object associated with this business object.
     *
     * @param eObjXAddressExt
     *            The eObjXAddressExt to set.
     * @generated
     */
    public void setEObjXAddressExt(EObjXAddressExt eObjXAddressExt) {
        bRequireMapRefresh = true;
        this.eObjXAddressExt = eObjXAddressExt;
        this.eObjXAddressExt.setBaseEntity(getEObjAddress());
        if (this.eObjXAddressExt != null && this.eObjXAddressExt.getControl() == null) {
            DWLControl control = this.getControl();
            if (control != null) {
                this.eObjXAddressExt.setControl(control);
            }
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xAddressVerificationDate attribute.
     * 
     * @generated
     */
    public String getXAddressVerificationDate (){
   
        return DWLFunctionUtils.getStringFromTimestamp(eObjXAddressExt.getXAddressVerificationDate());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xAddressVerificationDate attribute.
     * 
     * @param newXAddressVerificationDate
     *     The new value of xAddressVerificationDate.
     * @generated
     */
    public void setXAddressVerificationDate( String newXAddressVerificationDate ) throws Exception {
        metaDataMap.put("XAddressVerificationDate", newXAddressVerificationDate);
       	isValidXAddressVerificationDate = true;

        if (newXAddressVerificationDate == null || newXAddressVerificationDate.equals("")) {
            newXAddressVerificationDate = null;
            eObjXAddressExt.setXAddressVerificationDate(null);


        }
    else {
        	if (DateValidator.validates(newXAddressVerificationDate)) {
           		eObjXAddressExt.setXAddressVerificationDate(DateFormatter.getStartDateTimestamp(newXAddressVerificationDate));
            	metaDataMap.put("XAddressVerificationDate", getXAddressVerificationDate());
        	} else {
            	if (Configuration.getConfiguration().getConfigItem(
              "/IBM/DWLCommonServices/InternalValidation/enabled").getBooleanValue()) {
                	if (metaDataMap.get("XAddressVerificationDate") != null) {
                    	metaDataMap.put("XAddressVerificationDate", "");
                	}
                	isValidXAddressVerificationDate = false;
                	eObjXAddressExt.setXAddressVerificationDate(null);
            	}
        	}
        }
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xSubcityType attribute.
     * 
     * @generated
     */
    public String getXSubcityType (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXAddressExt.getXSubcity());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xSubcityType attribute.
     * 
     * @param newXSubcityType
     *     The new value of xSubcityType.
     * @generated
     */
    public void setXSubcityType( String newXSubcityType ) throws Exception {
        metaDataMap.put("XSubcityType", newXSubcityType);

        if (newXSubcityType == null || newXSubcityType.equals("")) {
            newXSubcityType = null;


        }
        eObjXAddressExt.setXSubcity( DWLFunctionUtils.getLongFromString(newXSubcityType) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xSubcityValue attribute.
     * 
     * @generated
     */
    public String getXSubcityValue (){
      return xSubcityValue;
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xSubcityValue attribute.
     * 
     * @param newXSubcityValue
     *     The new value of xSubcityValue.
     * @generated
     */
    public void setXSubcityValue( String newXSubcityValue ) throws Exception {
        metaDataMap.put("XSubcityValue", newXSubcityValue);

        if (newXSubcityValue == null || newXSubcityValue.equals("")) {
            newXSubcityValue = null;


        }
        xSubcityValue = newXSubcityValue;
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xDistrictType attribute.
     * 
     * @generated
     */
    public String getXDistrictType (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXAddressExt.getXDistrict());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xDistrictType attribute.
     * 
     * @param newXDistrictType
     *     The new value of xDistrictType.
     * @generated
     */
    public void setXDistrictType( String newXDistrictType ) throws Exception {
        metaDataMap.put("XDistrictType", newXDistrictType);

        if (newXDistrictType == null || newXDistrictType.equals("")) {
            newXDistrictType = null;


        }
        eObjXAddressExt.setXDistrict( DWLFunctionUtils.getLongFromString(newXDistrictType) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xDistrictValue attribute.
     * 
     * @generated
     */
    public String getXDistrictValue (){
      return xDistrictValue;
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xDistrictValue attribute.
     * 
     * @param newXDistrictValue
     *     The new value of xDistrictValue.
     * @generated
     */
    public void setXDistrictValue( String newXDistrictValue ) throws Exception {
        metaDataMap.put("XDistrictValue", newXDistrictValue);

        if (newXDistrictValue == null || newXDistrictValue.equals("")) {
            newXDistrictValue = null;


        }
        xDistrictValue = newXDistrictValue;
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xBuildingName attribute.
     * 
     * @generated
     */
    public String getXBuildingName (){
   
        return eObjXAddressExt.getXBuildingName();
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xBuildingName attribute.
     * 
     * @param newXBuildingName
     *     The new value of xBuildingName.
     * @generated
     */
    public void setXBuildingName( String newXBuildingName ) throws Exception {
        metaDataMap.put("XBuildingName", newXBuildingName);

        if (newXBuildingName == null || newXBuildingName.equals("")) {
            newXBuildingName = null;


        }
        eObjXAddressExt.setXBuildingName( newXBuildingName );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xStreetNumber attribute.
     * 
     * @generated
     */
    public String getXStreetNumber (){
   
        return eObjXAddressExt.getXStreetNumber();
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xStreetNumber attribute.
     * 
     * @param newXStreetNumber
     *     The new value of xStreetNumber.
     * @generated
     */
    public void setXStreetNumber( String newXStreetNumber ) throws Exception {
        metaDataMap.put("XStreetNumber", newXStreetNumber);

        if (newXStreetNumber == null || newXStreetNumber.equals("")) {
            newXStreetNumber = null;


        }
        eObjXAddressExt.setXStreetNumber( newXStreetNumber );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xStreetName attribute.
     * 
     * @generated
     */
    public String getXStreetName (){
   
        return eObjXAddressExt.getXStreetName();
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xStreetName attribute.
     * 
     * @param newXStreetName
     *     The new value of xStreetName.
     * @generated
     */
    public void setXStreetName( String newXStreetName ) throws Exception {
        metaDataMap.put("XStreetName", newXStreetName);

        if (newXStreetName == null || newXStreetName.equals("")) {
            newXStreetName = null;


        }
        eObjXAddressExt.setXStreetName( newXStreetName );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xSuburb attribute.
     * 
     * @generated
     */
    public String getXSuburb (){
   
        return eObjXAddressExt.getXSuburb();
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xSuburb attribute.
     * 
     * @param newXSuburb
     *     The new value of xSuburb.
     * @generated
     */
    public void setXSuburb( String newXSuburb ) throws Exception {
        metaDataMap.put("XSuburb", newXSuburb);

        if (newXSuburb == null || newXSuburb.equals("")) {
            newXSuburb = null;


        }
        eObjXAddressExt.setXSuburb( newXSuburb );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateTxId attribute.
     *
     * @generated
     */
    public String getXAddressLastUpdateTxId() {
        return DWLFunctionUtils.getStringFromLong(eObjXAddressExt.getLastUpdateTxId());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateUser attribute.
     *
     * @generated
     */
    public String getXAddressLastUpdateUser() {
        return eObjXAddressExt.getLastUpdateUser();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateDt attribute.
     *
     * @generated
     */
    public String getXAddressLastUpdateDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXAddressExt.getLastUpdateDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateTxId attribute.
     *
     * @param newLastUpdateTxId
     *     The new value of LastUpdateTxId.
     * @generated
     */
    public void setXAddressLastUpdateTxId(String newLastUpdateTxId) {
        metaDataMap.put("XAddressLastUpdateTxId", newLastUpdateTxId);

        if ((newLastUpdateTxId == null) || newLastUpdateTxId.equals("")) {
            newLastUpdateTxId = null;
        }
        eObjXAddressExt.setLastUpdateTxId(DWLFunctionUtils.getLongFromString(newLastUpdateTxId));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateUser attribute.
     *
     * @param newLastUpdateUser
     *     The new value of LastUpdateUser.
     * @generated
     */
    public void setXAddressLastUpdateUser(String newLastUpdateUser) {
        metaDataMap.put("XAddressLastUpdateUser", newLastUpdateUser);

        if ((newLastUpdateUser == null) || newLastUpdateUser.equals("")) {
            newLastUpdateUser = null;
        }
        eObjXAddressExt.setLastUpdateUser(newLastUpdateUser);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateDt attribute.
     *
     * @param newLastUpdateDt
     *     The new value of LastUpdateDt.
     * @throws Exception
     * @generated
     */
    public void setXAddressLastUpdateDate(String newLastUpdateDt) throws Exception {
        metaDataMap.put("XAddressLastUpdateDate", newLastUpdateDt);

        if ((newLastUpdateDt == null) || newLastUpdateDt.equals("")) {
            newLastUpdateDt = null;
        }

        eObjXAddressExt.setLastUpdateDt(DWLFunctionUtils.getTimestampFromTimestampString(newLastUpdateDt));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XAddressHistActionCode history attribute.
     *
     * @generated
     */
    public String getXAddressHistActionCode() {
        return eObjXAddressExt.getHistActionCode();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XAddressHistActionCode history attribute.
     *
     * @param aXAddressHistActionCode
     *     The new value of XAddressHistActionCode.
     * @generated
     */
    public void setXAddressHistActionCode(String aXAddressHistActionCode) {
        metaDataMap.put("XAddressHistActionCode", aXAddressHistActionCode);

        if ((aXAddressHistActionCode == null) || aXAddressHistActionCode.equals("")) {
            aXAddressHistActionCode = null;
        }
        eObjXAddressExt.setHistActionCode(aXAddressHistActionCode);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XAddressHistCreateDate history attribute.
     *
     * @generated
     */
    public String getXAddressHistCreateDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXAddressExt.getHistCreateDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XAddressHistCreateDate history attribute.
     *
     * @param aXAddressHistCreateDate
     *     The new value of XAddressHistCreateDate.
     * @generated
     */
    public void setXAddressHistCreateDate(String aXAddressHistCreateDate) throws Exception{
        metaDataMap.put("XAddressHistCreateDate", aXAddressHistCreateDate);

        if ((aXAddressHistCreateDate == null) || aXAddressHistCreateDate.equals("")) {
            aXAddressHistCreateDate = null;
        }

        eObjXAddressExt.setHistCreateDt(DWLFunctionUtils.getTimestampFromTimestampString(aXAddressHistCreateDate));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XAddressHistCreatedBy history attribute.
     *
     * @generated
     */
    public String getXAddressHistCreatedBy() {
        return eObjXAddressExt.getHistCreatedBy();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XAddressHistCreatedBy history attribute.
     *
     * @param aXAddressHistCreatedBy
     *     The new value of XAddressHistCreatedBy.
     * @generated
     */
    public void setXAddressHistCreatedBy(String aXAddressHistCreatedBy) {
        metaDataMap.put("XAddressHistCreatedBy", aXAddressHistCreatedBy);

        if ((aXAddressHistCreatedBy == null) || aXAddressHistCreatedBy.equals("")) {
            aXAddressHistCreatedBy = null;
        }

        eObjXAddressExt.setHistCreatedBy(aXAddressHistCreatedBy);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XAddressHistEndDate history attribute.
     *
     * @generated
     */
    public String getXAddressHistEndDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXAddressExt.getHistEndDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XAddressHistEndDate history attribute.
     *
     * @param aXAddressHistEndDate
     *     The new value of XAddressHistEndDate.
     * @generated
     */
    public void setXAddressHistEndDate(String aXAddressHistEndDate) throws Exception{
        metaDataMap.put("XAddressHistEndDate", aXAddressHistEndDate);

        if ((aXAddressHistEndDate == null) || aXAddressHistEndDate.equals("")) {
            aXAddressHistEndDate = null;
        }
        eObjXAddressExt.setHistEndDt(DWLFunctionUtils.getTimestampFromTimestampString(aXAddressHistEndDate));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XAddressHistoryIdPK history attribute.
     *
     * @generated
     */
    public String getXAddressHistoryIdPK() {
        return DWLFunctionUtils.getStringFromLong(eObjXAddressExt.getHistoryIdPK());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XAddressHistoryIdPK history attribute.
     *
     * @param aXAddressHistoryIdPK
     *     The new value of XAddressHistoryIdPK.
     * @generated
     */
    public void setXAddressHistoryIdPK(String aXAddressHistoryIdPK) {
        metaDataMap.put("XAddressHistoryIdPK", aXAddressHistoryIdPK);

        if ((aXAddressHistoryIdPK == null) || aXAddressHistoryIdPK.equals("")) {
            aXAddressHistoryIdPK = null;
        }
        eObjXAddressExt.setHistoryIdPK(DWLFunctionUtils.getLongFromString(aXAddressHistoryIdPK));
    }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation during an add transaction.
     *
     * @generated
     */
    public DWLStatus validateAdd(int level, DWLStatus status) throws Exception {

        status = super.validateAdd(level, status);
        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0038I Add any controller-level custom validation logic to be
            // executed for this object during an "add" transaction

        }

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            // MDM_TODO0: CDKWB0039I Add any component-level custom validation logic to be
            // executed for this object during an "add" transaction
        }
        status = getValidationStatus(level, status);
        return status;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation during an update transaction.
     *
     * @generated
     */
    public DWLStatus validateUpdate(int level, DWLStatus status) throws Exception {
    logger.finest("ENTER validateUpdate(int level, DWLStatus status)");

        status = super.validateUpdate(level, status);
        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0040I Add any controller-level custom validation logic to be
            // executed for this object during an "update" transaction

        }

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            assignBeforeImageValues(metaDataMap);
            
            // MDM_TODO0: CDKWB0041I Add any component-level custom validation logic to be
            // executed for this object during an "update" transaction
        }
        status = getValidationStatus(level, status);
    if (logger.isFinestEnabled()) {
        	String returnValue = status.toString();
      logger.finest("RETURN validateUpdate(int level, DWLStatus status) " + returnValue);
    }
        return status;
    }



    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation common to both add and update transactions.
     *
     * @generated
     */
     
    private DWLStatus getValidationStatus(int level, DWLStatus status) throws Exception {
    logger.finest("ENTER getValidationStatus(int level, DWLStatus status)");

        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0034I Add any common controller-level custom validation
            // logic to be executed for this object during either "add" or
            // "update" transactions
    		controllerValidation_XAddressVerificationDate(status);
    		controllerValidation_XSubcity(status);
    		controllerValidation_XDistrict(status);
    	}

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            // MDM_TODO0: CDKWB0035I Add any common component-level custom validation logic
            // to be executed for this object during either "add" or "update"
            // transactions
    		componentValidation_XAddressVerificationDate(status);
    		componentValidation_XSubcity(status);
    		componentValidation_XDistrict(status);
        }
        
        if (logger.isFinestEnabled()) {
            String returnValue = status.toString();
      logger.finest("RETURN getValidationStatus(int level, DWLStatus status) " + returnValue);
        }
    
        return status;
    }

    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "XAddressVerificationDate"
     *
     * @generated
     */
	private void componentValidation_XAddressVerificationDate(DWLStatus status) {
  
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "XSubcity"
     *
     * @generated
     */
	private void componentValidation_XSubcity(DWLStatus status) {
  
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "XDistrict"
     *
     * @generated
     */
	private void componentValidation_XDistrict(DWLStatus status) {
  
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "XAddressVerificationDate"
     *
     * @generated
     */
	private void controllerValidation_XAddressVerificationDate(DWLStatus status) throws Exception {
  
            boolean isXAddressVerificationDateNull = (eObjXAddressExt.getXAddressVerificationDate() == null);
            if (!isValidXAddressVerificationDate) {
              	DWLError err = new DWLError();
               	err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XADDRESS_BOBJ_EXT).longValue());
               	err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XADDRESS_XADDRESSVERIFICATIONDATE).longValue());
               	err.setErrorType(DWLErrorCode.DATA_INVALID_ERROR);
                String infoForLogging="Error: Validation error. Invalid time specified on property XAddressVerificationDate in entity XAddress, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode();
      logger.finest("controllerValidation_XAddressVerificationDate " + infoForLogging);
               	status.addError(err);
            } 
    	}
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "XSubcity"
     *
     * @generated
     */
	private void controllerValidation_XSubcity(DWLStatus status) throws Exception {
  
      //persistent code type
            boolean isXSubcityNull = false;
            if ((eObjXAddressExt.getXSubcity() == null) &&
               ((getXSubcityValue() == null) || 
                 getXSubcityValue().trim().equals(""))) {
                isXSubcityNull = true;
            }
            if (!isXSubcityNull) {
                if (checkForInvalidXaddressXsubcity()) {
                    DWLError err = new DWLError();
                    err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XADDRESS_BOBJ_EXT).longValue());
                    err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XADDRESS_XSUBCITY).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                    String infoForLogging="Error: Custom validation error occured for entity XAddress, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("controllerValidation_XSubcity " + infoForLogging);
        }
                status.addError(err);
            }

             }
    			
    	}
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "XDistrict"
     *
     * @generated
     */
	private void controllerValidation_XDistrict(DWLStatus status) throws Exception {
  
      //persistent code type
            boolean isXDistrictNull = false;
            if ((eObjXAddressExt.getXDistrict() == null) &&
               ((getXDistrictValue() == null) || 
                 getXDistrictValue().trim().equals(""))) {
                isXDistrictNull = true;
            }
            if (!isXDistrictNull) {
                if (checkForInvalidXaddressXdistrict()) {
                    DWLError err = new DWLError();
                    err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XADDRESS_BOBJ_EXT).longValue());
                    err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XADDRESS_XDISTRICT).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                    String infoForLogging="Error: Custom validation error occured for entity XAddress, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("controllerValidation_XDistrict " + infoForLogging);
        }
                status.addError(err);
            }

             }
    			
    	}
    private DWLError createDWLError(String entityName, String propertyName,String reasonCode){	
		DWLError err = new DWLError();
		err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XADDRESS_BOBJ_EXT).longValue());
		err.setReasonCode(new Long(reasonCode).longValue());
		err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
			String infoForLogging="Error: Validation error occured. Property " + propertyName + " is null, in entity " + entityName + ", component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
			logger.finest("createDWLError " + infoForLogging);
		}
		return err;
    }
    
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Check the value of the field XSubcity and return true if the error reason
     * INVALID_XADDRESS_XSUBCITY should be returned.
     *
     * @generated
  **/
	private boolean checkForInvalidXaddressXsubcity() throws Exception {
    logger.finest("ENTER checkForInvalidXaddressXsubcity()");
        boolean notValid = false;
      	String langId = (String) this.getControl().get(DWLControlKeys.LANG_ID);
      	CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
    Long codeType = DWLFunctionUtils.getLongFromString( getXSubcityType() );
    String codeValue = getXSubcityValue();
    if( codeValue != null && codeValue.trim().equals("")){
      codeValue = null;
    }
     
        if ( codeType != null && codeValue == null ){

             if( codeTypeCompHelper.isCodeValid("xcdsubcitytp", langId, getXSubcityType(),
                 CodeTypeComponentHelper.ACTIVE, getControl())) {
                 CodeTypeBObj ctBObj = codeTypeCompHelper
                 					.getCodeTypeByCode("xcdsubcitytp", langId, getXSubcityType(),
                         								getControl());
               	if (ctBObj != null) {
                   	setXSubcityValue( ctBObj.getvalue() );
               	}
             }
             else{
             	if (logger.isFinestEnabled()) {
              	 	String infoForLogging="NotValid 1";
      logger.finest("checkForInvalidXaddressXsubcity() " + infoForLogging);
        }
                 notValid = true;
           }
        }
        else if (codeType == null && codeValue != null ){
          
             CodeTypeBObj ctBObj = codeTypeCompHelper
                      .getCodeTypeByValue("xcdsubcitytp", langId, codeValue,
                                 getControl());

             if (ctBObj != null) {
                 setXSubcityType(ctBObj.gettp_cd());
             } 
             else {
             	if (logger.isFinestEnabled()) {
              	  	String infoForLogging="NotValid 2";
      logger.finest("checkForInvalidXaddressXsubcity() " + infoForLogging);
        }
                  notValid = true;
             }
        }
        else if ( codeType != null && codeValue != null
             && !codeTypeCompHelper.isCodeValuePairValid("xcdsubcitytp", langId, getXSubcityType(), 
                     new String[] { codeValue }, CodeTypeComponentHelper.ACTIVE, getControl())) {	
       if (logger.isFinestEnabled()) {
       		String infoForLogging="NotValid 3";
      logger.finest("checkForInvalidXaddressXsubcity() " + infoForLogging);
       }
             notValid = true;
        }
        if (logger.isFinestEnabled()) {
      String returnValue ="" +notValid;
      logger.finest("RETURN checkForInvalidXaddressXsubcity() " + returnValue);
    }
    return notValid;
     } 
				 
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Check the value of the field XDistrict and return true if the error
     * reason INVALID_XADDRESS_XDISTRICT should be returned.
     *
     * @generated
  **/
	private boolean checkForInvalidXaddressXdistrict() throws Exception {
    logger.finest("ENTER checkForInvalidXaddressXdistrict()");
        boolean notValid = false;
      	String langId = (String) this.getControl().get(DWLControlKeys.LANG_ID);
      	CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
    Long codeType = DWLFunctionUtils.getLongFromString( getXDistrictType() );
    String codeValue = getXDistrictValue();
    if( codeValue != null && codeValue.trim().equals("")){
      codeValue = null;
    }
     
        if ( codeType != null && codeValue == null ){

             if( codeTypeCompHelper.isCodeValid("xcddistricttp", langId, getXDistrictType(),
                 CodeTypeComponentHelper.ACTIVE, getControl())) {
                 CodeTypeBObj ctBObj = codeTypeCompHelper
                 					.getCodeTypeByCode("xcddistricttp", langId, getXDistrictType(),
                         								getControl());
               	if (ctBObj != null) {
                   	setXDistrictValue( ctBObj.getvalue() );
               	}
             }
             else{
             	if (logger.isFinestEnabled()) {
              	 	String infoForLogging="NotValid 1";
      logger.finest("checkForInvalidXaddressXdistrict() " + infoForLogging);
        }
                 notValid = true;
           }
        }
        else if (codeType == null && codeValue != null ){
          
             CodeTypeBObj ctBObj = codeTypeCompHelper
                      .getCodeTypeByValue("xcddistricttp", langId, codeValue,
                                 getControl());

             if (ctBObj != null) {
                 setXDistrictType(ctBObj.gettp_cd());
             } 
             else {
             	if (logger.isFinestEnabled()) {
              	  	String infoForLogging="NotValid 2";
      logger.finest("checkForInvalidXaddressXdistrict() " + infoForLogging);
        }
                  notValid = true;
             }
        }
        else if ( codeType != null && codeValue != null
             && !codeTypeCompHelper.isCodeValuePairValid("xcddistricttp", langId, getXDistrictType(), 
                     new String[] { codeValue }, CodeTypeComponentHelper.ACTIVE, getControl())) {	
       if (logger.isFinestEnabled()) {
       		String infoForLogging="NotValid 3";
      logger.finest("checkForInvalidXaddressXdistrict() " + infoForLogging);
       }
             notValid = true;
        }
        if (logger.isFinestEnabled()) {
      String returnValue ="" +notValid;
      logger.finest("RETURN checkForInvalidXaddressXdistrict() " + returnValue);
    }
    return notValid;
     } 
				 






	 /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets a record from the extension table.
     *
     * @throws DWLBaseException
     * @generated
     */
    public void getRecord() throws DWLBaseException {
    logger.finest("ENTER getRecord()");
    
    try {
         			
          checkForInvalidXaddressXsubcity();
          checkForInvalidXaddressXdistrict();
         }
         catch (Exception e) {
            DWLExceptionUtils.log(e);
            
            if (logger.isFinestEnabled()) {
        		String infoForLogging="Error: Error reading record " + e.getMessage(); 
      logger.finest("getRecord() " + infoForLogging);
      }
            status = new DWLStatus();

            TCRMReadException readEx = new TCRMReadException();
            IDWLErrorMessage  errHandler = DWLClassFactory.getErrorHandler();
            DWLError          error = errHandler.getErrorMessage(DSEAAdditionsExtsComponentID.XADDRESS_BOBJ_EXT,
                                                                 TCRMErrorCode.READ_RECORD_ERROR,
                                                                 DSEAAdditionsExtsErrorReasonCode.READ_EXTENSION_XADDRESS_FAILED,
                                                                 getControl(), new String[0]);
            error.setThrowable(e);
            status.addError(error);
            status.setStatus(DWLStatus.FATAL);
            readEx.setStatus(status);
            throw readEx;
        }	    		
    logger.finest("RETURN getRecord()");
  }


}

