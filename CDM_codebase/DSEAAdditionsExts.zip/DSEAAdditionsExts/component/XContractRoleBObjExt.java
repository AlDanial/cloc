
/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[b06c259b1a5c932debd3ed0f94795f31]
 */

package com.ibm.daimler.dsea.component;

import com.dwl.base.util.DWLClassFactory;
import com.dwl.tcrm.exception.TCRMReadException;



import com.dwl.base.DWLControl;
import com.dwl.base.IDWLErrorMessage;

import com.dwl.base.constant.DWLControlKeys;

import com.dwl.base.error.DWLError;
import com.dwl.base.error.DWLErrorCode;
import com.dwl.base.error.DWLStatus;

import com.dwl.base.exception.DWLBaseException;

import com.dwl.base.util.DWLExceptionUtils;
import com.dwl.base.util.DWLFunctionUtils;

import com.dwl.tcrm.common.IExtension;
import com.dwl.tcrm.common.ITCRMValidation;
import com.dwl.tcrm.common.TCRMErrorCode;

import com.dwl.tcrm.financial.component.TCRMContractPartyRoleBObj;

import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsComponentID;
import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsErrorReasonCode;

import com.ibm.daimler.dsea.entityObject.EObjXContractRoleExt;

import com.ibm.mdm.common.codetype.interfaces.CodeTypeComponentHelper;

import com.ibm.mdm.common.codetype.obj.CodeTypeBObj;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * This class provides the implementation of the business object
 * <code>XContractRoleBObjExt</code>.
 * 
 * @see com.dwl.tcrm.common.TCRMCommon
 * @generated
 */
 

@SuppressWarnings("serial")
public class XContractRoleBObjExt extends TCRMContractPartyRoleBObj implements IExtension {

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected EObjXContractRoleExt eObjXContractRoleExt;
	/**
    * <!-- begin-user-doc -->
	  * <!-- end-user-doc -->
    * @generated 
    */
	 private final static com.dwl.base.logging.IDWLLogger logger = com.dwl.base.logging.DWLLoggerManager.getLogger(XContractRoleBObjExt.class);
		
 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected String xSourceIdentifierValue;


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */     
    public XContractRoleBObjExt() {
        super();
        init();
        eObjXContractRoleExt = new EObjXContractRoleExt(getEObjContractRole());
        setComponentID(DSEAAdditionsExtsComponentID.XCONTRACT_ROLE_BOBJ_EXT);
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Initializes the fields required to populate the metaDataMap. Each key is
     * an element-level field of the business object.
     *
     * @generated
     */
    private void init() {
        metaDataMap.put("XSourceIdentifierType", null);
        metaDataMap.put("XSourceIdentifierValue", null);
        metaDataMap.put("XContractRoleHistActionCode", null);
        metaDataMap.put("XContractRoleHistCreateDate", null);
        metaDataMap.put("XContractRoleHistCreatedBy", null);
        metaDataMap.put("XContractRoleHistEndDate", null);
        metaDataMap.put("XContractRoleHistoryIdPK", null);
        metaDataMap.put("XContractRoleLastUpdateDate", null);
        metaDataMap.put("XContractRoleLastUpdateTxId", null);
        metaDataMap.put("XContractRoleLastUpdateUser", null);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Refreshes all the attributes this business object supports.
     *
     * @see com.dwl.base.DWLCommon#refreshMap()
     * @generated
     */
    public void refreshMap() {

        if (bRequireMapRefresh) {
            super.refreshMap();
            metaDataMap.put("XSourceIdentifierType", getXSourceIdentifierType());
            metaDataMap.put("XSourceIdentifierValue", getXSourceIdentifierValue());
            metaDataMap.put("XContractRoleHistActionCode", getXContractRoleHistActionCode());
            metaDataMap.put("XContractRoleHistCreateDate", getXContractRoleHistCreateDate());
            metaDataMap.put("XContractRoleHistCreatedBy", getXContractRoleHistCreatedBy());
            metaDataMap.put("XContractRoleHistEndDate", getXContractRoleHistEndDate());
            metaDataMap.put("XContractRoleHistoryIdPK", getXContractRoleHistoryIdPK());
            metaDataMap.put("XContractRoleLastUpdateDate", getXContractRoleLastUpdateDate());
            metaDataMap.put("XContractRoleLastUpdateTxId", getXContractRoleLastUpdateTxId());
            metaDataMap.put("XContractRoleLastUpdateUser", getXContractRoleLastUpdateUser());
            bRequireMapRefresh = false;
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the control object on this business object.
     *
     * @see com.dwl.base.DWLCommon#setControl(DWLControl)
     * @generated
     */
    public void setControl(DWLControl newDWLControl) {
        super.setControl(newDWLControl);

        if (eObjXContractRoleExt != null) {
            eObjXContractRoleExt.setControl(newDWLControl);
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the entity object associated with this business object.
     *
     * @generated
     */
    public EObjXContractRoleExt getEObjXContractRoleExt() {
        bRequireMapRefresh = true;
        return eObjXContractRoleExt;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the entity object associated with this business object.
     *
     * @param eObjXContractRoleExt
     *            The eObjXContractRoleExt to set.
     * @generated
     */
    public void setEObjXContractRoleExt(EObjXContractRoleExt eObjXContractRoleExt) {
        bRequireMapRefresh = true;
        this.eObjXContractRoleExt = eObjXContractRoleExt;
        this.eObjXContractRoleExt.setBaseEntity(getEObjContractRole());
        if (this.eObjXContractRoleExt != null && this.eObjXContractRoleExt.getControl() == null) {
            DWLControl control = this.getControl();
            if (control != null) {
                this.eObjXContractRoleExt.setControl(control);
            }
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xSourceIdentifierType attribute.
     * 
     * @generated
     */
    public String getXSourceIdentifierType (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXContractRoleExt.getXSourceIdentifier());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xSourceIdentifierType attribute.
     * 
     * @param newXSourceIdentifierType
     *     The new value of xSourceIdentifierType.
     * @generated
     */
    public void setXSourceIdentifierType( String newXSourceIdentifierType ) throws Exception {
        metaDataMap.put("XSourceIdentifierType", newXSourceIdentifierType);

        if (newXSourceIdentifierType == null || newXSourceIdentifierType.equals("")) {
            newXSourceIdentifierType = null;


        }
        eObjXContractRoleExt.setXSourceIdentifier( DWLFunctionUtils.getLongFromString(newXSourceIdentifierType) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xSourceIdentifierValue attribute.
     * 
     * @generated
     */
    public String getXSourceIdentifierValue (){
      return xSourceIdentifierValue;
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xSourceIdentifierValue attribute.
     * 
     * @param newXSourceIdentifierValue
     *     The new value of xSourceIdentifierValue.
     * @generated
     */
    public void setXSourceIdentifierValue( String newXSourceIdentifierValue ) throws Exception {
        metaDataMap.put("XSourceIdentifierValue", newXSourceIdentifierValue);

        if (newXSourceIdentifierValue == null || newXSourceIdentifierValue.equals("")) {
            newXSourceIdentifierValue = null;


        }
        xSourceIdentifierValue = newXSourceIdentifierValue;
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateTxId attribute.
     *
     * @generated
     */
    public String getXContractRoleLastUpdateTxId() {
        return DWLFunctionUtils.getStringFromLong(eObjXContractRoleExt.getLastUpdateTxId());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateUser attribute.
     *
     * @generated
     */
    public String getXContractRoleLastUpdateUser() {
        return eObjXContractRoleExt.getLastUpdateUser();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateDt attribute.
     *
     * @generated
     */
    public String getXContractRoleLastUpdateDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXContractRoleExt.getLastUpdateDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateTxId attribute.
     *
     * @param newLastUpdateTxId
     *     The new value of LastUpdateTxId.
     * @generated
     */
    public void setXContractRoleLastUpdateTxId(String newLastUpdateTxId) {
        metaDataMap.put("XContractRoleLastUpdateTxId", newLastUpdateTxId);

        if ((newLastUpdateTxId == null) || newLastUpdateTxId.equals("")) {
            newLastUpdateTxId = null;
        }
        eObjXContractRoleExt.setLastUpdateTxId(DWLFunctionUtils.getLongFromString(newLastUpdateTxId));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateUser attribute.
     *
     * @param newLastUpdateUser
     *     The new value of LastUpdateUser.
     * @generated
     */
    public void setXContractRoleLastUpdateUser(String newLastUpdateUser) {
        metaDataMap.put("XContractRoleLastUpdateUser", newLastUpdateUser);

        if ((newLastUpdateUser == null) || newLastUpdateUser.equals("")) {
            newLastUpdateUser = null;
        }
        eObjXContractRoleExt.setLastUpdateUser(newLastUpdateUser);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateDt attribute.
     *
     * @param newLastUpdateDt
     *     The new value of LastUpdateDt.
     * @throws Exception
     * @generated
     */
    public void setXContractRoleLastUpdateDate(String newLastUpdateDt) throws Exception {
        metaDataMap.put("XContractRoleLastUpdateDate", newLastUpdateDt);

        if ((newLastUpdateDt == null) || newLastUpdateDt.equals("")) {
            newLastUpdateDt = null;
        }

        eObjXContractRoleExt.setLastUpdateDt(DWLFunctionUtils.getTimestampFromTimestampString(newLastUpdateDt));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XContractRoleHistActionCode history attribute.
     *
     * @generated
     */
    public String getXContractRoleHistActionCode() {
        return eObjXContractRoleExt.getHistActionCode();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XContractRoleHistActionCode history attribute.
     *
     * @param aXContractRoleHistActionCode
     *     The new value of XContractRoleHistActionCode.
     * @generated
     */
    public void setXContractRoleHistActionCode(String aXContractRoleHistActionCode) {
        metaDataMap.put("XContractRoleHistActionCode", aXContractRoleHistActionCode);

        if ((aXContractRoleHistActionCode == null) || aXContractRoleHistActionCode.equals("")) {
            aXContractRoleHistActionCode = null;
        }
        eObjXContractRoleExt.setHistActionCode(aXContractRoleHistActionCode);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XContractRoleHistCreateDate history attribute.
     *
     * @generated
     */
    public String getXContractRoleHistCreateDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXContractRoleExt.getHistCreateDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XContractRoleHistCreateDate history attribute.
     *
     * @param aXContractRoleHistCreateDate
     *     The new value of XContractRoleHistCreateDate.
     * @generated
     */
    public void setXContractRoleHistCreateDate(String aXContractRoleHistCreateDate) throws Exception{
        metaDataMap.put("XContractRoleHistCreateDate", aXContractRoleHistCreateDate);

        if ((aXContractRoleHistCreateDate == null) || aXContractRoleHistCreateDate.equals("")) {
            aXContractRoleHistCreateDate = null;
        }

        eObjXContractRoleExt.setHistCreateDt(DWLFunctionUtils.getTimestampFromTimestampString(aXContractRoleHistCreateDate));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XContractRoleHistCreatedBy history attribute.
     *
     * @generated
     */
    public String getXContractRoleHistCreatedBy() {
        return eObjXContractRoleExt.getHistCreatedBy();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XContractRoleHistCreatedBy history attribute.
     *
     * @param aXContractRoleHistCreatedBy
     *     The new value of XContractRoleHistCreatedBy.
     * @generated
     */
    public void setXContractRoleHistCreatedBy(String aXContractRoleHistCreatedBy) {
        metaDataMap.put("XContractRoleHistCreatedBy", aXContractRoleHistCreatedBy);

        if ((aXContractRoleHistCreatedBy == null) || aXContractRoleHistCreatedBy.equals("")) {
            aXContractRoleHistCreatedBy = null;
        }

        eObjXContractRoleExt.setHistCreatedBy(aXContractRoleHistCreatedBy);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XContractRoleHistEndDate history attribute.
     *
     * @generated
     */
    public String getXContractRoleHistEndDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXContractRoleExt.getHistEndDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XContractRoleHistEndDate history attribute.
     *
     * @param aXContractRoleHistEndDate
     *     The new value of XContractRoleHistEndDate.
     * @generated
     */
    public void setXContractRoleHistEndDate(String aXContractRoleHistEndDate) throws Exception{
        metaDataMap.put("XContractRoleHistEndDate", aXContractRoleHistEndDate);

        if ((aXContractRoleHistEndDate == null) || aXContractRoleHistEndDate.equals("")) {
            aXContractRoleHistEndDate = null;
        }
        eObjXContractRoleExt.setHistEndDt(DWLFunctionUtils.getTimestampFromTimestampString(aXContractRoleHistEndDate));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XContractRoleHistoryIdPK history attribute.
     *
     * @generated
     */
    public String getXContractRoleHistoryIdPK() {
        return DWLFunctionUtils.getStringFromLong(eObjXContractRoleExt.getHistoryIdPK());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XContractRoleHistoryIdPK history attribute.
     *
     * @param aXContractRoleHistoryIdPK
     *     The new value of XContractRoleHistoryIdPK.
     * @generated
     */
    public void setXContractRoleHistoryIdPK(String aXContractRoleHistoryIdPK) {
        metaDataMap.put("XContractRoleHistoryIdPK", aXContractRoleHistoryIdPK);

        if ((aXContractRoleHistoryIdPK == null) || aXContractRoleHistoryIdPK.equals("")) {
            aXContractRoleHistoryIdPK = null;
        }
        eObjXContractRoleExt.setHistoryIdPK(DWLFunctionUtils.getLongFromString(aXContractRoleHistoryIdPK));
    }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation during an add transaction.
     *
     * @generated
     */
    public DWLStatus validateAdd(int level, DWLStatus status) throws Exception {

        status = super.validateAdd(level, status);
        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0038I Add any controller-level custom validation logic to be
            // executed for this object during an "add" transaction

        }

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            // MDM_TODO0: CDKWB0039I Add any component-level custom validation logic to be
            // executed for this object during an "add" transaction
        }
        status = getValidationStatus(level, status);
        return status;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation during an update transaction.
     *
     * @generated
     */
    public DWLStatus validateUpdate(int level, DWLStatus status) throws Exception {
    logger.finest("ENTER validateUpdate(int level, DWLStatus status)");

        status = super.validateUpdate(level, status);
        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0040I Add any controller-level custom validation logic to be
            // executed for this object during an "update" transaction

        }

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            assignBeforeImageValues(metaDataMap);
            
            // MDM_TODO0: CDKWB0041I Add any component-level custom validation logic to be
            // executed for this object during an "update" transaction
        }
        status = getValidationStatus(level, status);
    if (logger.isFinestEnabled()) {
        	String returnValue = status.toString();
      logger.finest("RETURN validateUpdate(int level, DWLStatus status) " + returnValue);
    }
        return status;
    }



    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation common to both add and update transactions.
     *
     * @generated
     */
     
    private DWLStatus getValidationStatus(int level, DWLStatus status) throws Exception {
    logger.finest("ENTER getValidationStatus(int level, DWLStatus status)");

        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0034I Add any common controller-level custom validation
            // logic to be executed for this object during either "add" or
            // "update" transactions
    		controllerValidation_XSourceIdentifier(status);
    	}

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            // MDM_TODO0: CDKWB0035I Add any common component-level custom validation logic
            // to be executed for this object during either "add" or "update"
            // transactions
    		componentValidation_XSourceIdentifier(status);
        }
        
        if (logger.isFinestEnabled()) {
            String returnValue = status.toString();
      logger.finest("RETURN getValidationStatus(int level, DWLStatus status) " + returnValue);
        }
    
        return status;
    }

    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "XSourceIdentifier"
     *
     * @generated
     */
	private void componentValidation_XSourceIdentifier(DWLStatus status) {
  
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "XSourceIdentifier"
     *
     * @generated
     */
	private void controllerValidation_XSourceIdentifier(DWLStatus status) throws Exception {
  
      //persistent code type
            boolean isXSourceIdentifierNull = false;
            if ((eObjXContractRoleExt.getXSourceIdentifier() == null) &&
               ((getXSourceIdentifierValue() == null) || 
                 getXSourceIdentifierValue().trim().equals(""))) {
                isXSourceIdentifierNull = true;
            }
            if (!isXSourceIdentifierNull) {
                if (checkForInvalidXcontractroleXsourceidentifier()) {
                    DWLError err = new DWLError();
                    err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCONTRACT_ROLE_BOBJ_EXT).longValue());
                    err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XCONTRACTROLE_XSOURCEIDENTIFIER).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                    String infoForLogging="Error: Custom validation error occured for entity XContractRole, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("controllerValidation_XSourceIdentifier " + infoForLogging);
        }
                status.addError(err);
            }

             }
    			
    	}
    private DWLError createDWLError(String entityName, String propertyName,String reasonCode){	
		DWLError err = new DWLError();
		err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCONTRACT_ROLE_BOBJ_EXT).longValue());
		err.setReasonCode(new Long(reasonCode).longValue());
		err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
			String infoForLogging="Error: Validation error occured. Property " + propertyName + " is null, in entity " + entityName + ", component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
			logger.finest("createDWLError " + infoForLogging);
		}
		return err;
    }
    
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Check the value of the field XSourceIdentifier and return true if the
     * error reason INVALID_XCONTRACTROLE_XSOURCEIDENTIFIER should be returned.
     *
     * @generated
  **/
	private boolean checkForInvalidXcontractroleXsourceidentifier() throws Exception {
    logger.finest("ENTER checkForInvalidXcontractroleXsourceidentifier()");
        boolean notValid = false;
      	String langId = (String) this.getControl().get(DWLControlKeys.LANG_ID);
      	CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
    Long codeType = DWLFunctionUtils.getLongFromString( getXSourceIdentifierType() );
    String codeValue = getXSourceIdentifierValue();
    if( codeValue != null && codeValue.trim().equals("")){
      codeValue = null;
    }
     
        if ( codeType != null && codeValue == null ){

             if( codeTypeCompHelper.isCodeValid("cdsourceidenttp", langId, getXSourceIdentifierType(),
                 CodeTypeComponentHelper.ACTIVE, getControl())) {
                 CodeTypeBObj ctBObj = codeTypeCompHelper
                 					.getCodeTypeByCode("cdsourceidenttp", langId, getXSourceIdentifierType(),
                         								getControl());
               	if (ctBObj != null) {
                   	setXSourceIdentifierValue( ctBObj.getvalue() );
               	}
             }
             else{
             	if (logger.isFinestEnabled()) {
              	 	String infoForLogging="NotValid 1";
      logger.finest("checkForInvalidXcontractroleXsourceidentifier() " + infoForLogging);
        }
                 notValid = true;
           }
        }
        else if (codeType == null && codeValue != null ){
          
             CodeTypeBObj ctBObj = codeTypeCompHelper
                      .getCodeTypeByValue("cdsourceidenttp", langId, codeValue,
                                 getControl());

             if (ctBObj != null) {
                 setXSourceIdentifierType(ctBObj.gettp_cd());
             } 
             else {
             	if (logger.isFinestEnabled()) {
              	  	String infoForLogging="NotValid 2";
      logger.finest("checkForInvalidXcontractroleXsourceidentifier() " + infoForLogging);
        }
                  notValid = true;
             }
        }
        else if ( codeType != null && codeValue != null
             && !codeTypeCompHelper.isCodeValuePairValid("cdsourceidenttp", langId, getXSourceIdentifierType(), 
                     new String[] { codeValue }, CodeTypeComponentHelper.ACTIVE, getControl())) {	
       if (logger.isFinestEnabled()) {
       		String infoForLogging="NotValid 3";
      logger.finest("checkForInvalidXcontractroleXsourceidentifier() " + infoForLogging);
       }
             notValid = true;
        }
        if (logger.isFinestEnabled()) {
      String returnValue ="" +notValid;
      logger.finest("RETURN checkForInvalidXcontractroleXsourceidentifier() " + returnValue);
    }
    return notValid;
     } 
				 






	 /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets a record from the extension table.
     *
     * @throws DWLBaseException
     * @generated
     */
    public void getRecord() throws DWLBaseException {
    logger.finest("ENTER getRecord()");
    
    try {
         			
          checkForInvalidXcontractroleXsourceidentifier();
         }
         catch (Exception e) {
            DWLExceptionUtils.log(e);
            
            if (logger.isFinestEnabled()) {
        		String infoForLogging="Error: Error reading record " + e.getMessage(); 
      logger.finest("getRecord() " + infoForLogging);
      }
            status = new DWLStatus();

            TCRMReadException readEx = new TCRMReadException();
            IDWLErrorMessage  errHandler = DWLClassFactory.getErrorHandler();
            DWLError          error = errHandler.getErrorMessage(DSEAAdditionsExtsComponentID.XCONTRACT_ROLE_BOBJ_EXT,
                                                                 TCRMErrorCode.READ_RECORD_ERROR,
                                                                 DSEAAdditionsExtsErrorReasonCode.READ_EXTENSION_XCONTRACTROLE_FAILED,
                                                                 getControl(), new String[0]);
            error.setThrowable(e);
            status.addError(error);
            status.setStatus(DWLStatus.FATAL);
            readEx.setStatus(status);
            throw readEx;
        }	    		
    logger.finest("RETURN getRecord()");
  }


}

