
/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[cd060f631a4f06b51aa370fac585bd9d]
 */

package com.ibm.daimler.dsea.component;

import java.util.Vector;

import com.dwl.base.DWLControl;
import com.dwl.base.IDWLErrorMessage;
import com.dwl.base.constant.DWLControlKeys;
import com.dwl.base.error.DWLError;
import com.dwl.base.error.DWLErrorCode;
import com.dwl.base.error.DWLStatus;
import com.dwl.base.exception.DWLBaseException;
import com.dwl.base.util.DWLClassFactory;
import com.dwl.base.util.DWLExceptionUtils;
import com.dwl.base.util.DWLFunctionUtils;
import com.dwl.management.config.client.Configuration;
import com.dwl.tcrm.common.IExtension;
import com.dwl.tcrm.common.ITCRMValidation;
import com.dwl.tcrm.common.TCRMErrorCode;
import com.dwl.tcrm.coreParty.component.TCRMPersonBObj;
import com.dwl.tcrm.utilities.DateFormatter;
import com.dwl.tcrm.utilities.DateValidator;
import com.dwl.tcrm.exception.TCRMReadException;
import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsComponentID;
import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsErrorReasonCode;
import com.ibm.daimler.dsea.entityObject.EObjXPersonExt;
import com.ibm.mdm.common.codetype.interfaces.CodeTypeComponentHelper;
import com.ibm.mdm.common.codetype.obj.CodeTypeBObj;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * This class provides the implementation of the business object
 * <code>XPersonBObjExt</code>.
 * 
 * @see com.dwl.tcrm.common.TCRMCommon
 * @generated
 */
 

@SuppressWarnings("serial")
public class XPersonBObjExt extends TCRMPersonBObj implements IExtension {

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected EObjXPersonExt eObjXPersonExt;
    protected Vector<XCustomerRetailerBObj> vecXCustomerRetailerBObj = new Vector<XCustomerRetailerBObj>();  
	/**
    * <!-- begin-user-doc -->
	  * <!-- end-user-doc -->
    * @generated 
    */
	 private final static com.dwl.base.logging.IDWLLogger logger = com.dwl.base.logging.DWLLoggerManager.getLogger(XPersonBObjExt.class);
		
 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected String xOccupationValue;


    protected boolean isValidXBirthDateFS = true;
    protected boolean isValidLastActivityDate = true;
    protected boolean isValidXLastModifiedSystemDate = true;
    
    protected Vector<XDataSharingBObj> vecXDataSharingBObj;    
    protected Vector<XConsentBObj> vecXConsentBObj;


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated NOT
     */     
    public XPersonBObjExt() {
        super();
        init();
        eObjXPersonExt = new EObjXPersonExt(getEObjPerson());
        vecXDataSharingBObj = new Vector<XDataSharingBObj>();
        vecXConsentBObj = new Vector<XConsentBObj>();
        setComponentID(DSEAAdditionsExtsComponentID.XPERSON_BOBJ_EXT);
    }
	
	public Vector<XDataSharingBObj> getItemsXDataSharingBObj() {
	      return this.vecXDataSharingBObj;
    }
    public void setXDataSharingBObj(XDataSharingBObj newXDataSharingBObj) {
	      this.vecXDataSharingBObj.addElement(newXDataSharingBObj);
    }
    
    public Vector<XConsentBObj> getItemsXConsentBObj() {
	      return this.vecXConsentBObj;
    }
    public void setXConsentBObj(XConsentBObj newXConsentBObj) {
	      this.vecXConsentBObj.addElement(newXConsentBObj);
    }
    
    
    public Vector<XCustomerRetailerBObj> getItemsXCustomerRetailerBObj() {
		return this.vecXCustomerRetailerBObj;
	}


	public void setXCustomerRetailerBObj(
			XCustomerRetailerBObj newXCustomerRetailerBObj) {
		this.vecXCustomerRetailerBObj.addElement(newXCustomerRetailerBObj);
	}

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Initializes the fields required to populate the metaDataMap. Each key is
     * an element-level field of the business object.
     *
     * @generated
     */
    private void init() {
        metaDataMap.put("XDefunctInd", null);
        metaDataMap.put("XMarketName", null);
        metaDataMap.put("XBatchInd", null);
        metaDataMap.put("XEmployerName", null);
        metaDataMap.put("XOccupationType", null);
        metaDataMap.put("XOccupationValue", null);
        metaDataMap.put("XLastModifiedSystemDate", null);
        metaDataMap.put("XSourceTypeFlag", null);
        metaDataMap.put("XGenderFS", null);
        metaDataMap.put("XBirthDateFS", null);
        metaDataMap.put("XGeneratedBy", null);
        metaDataMap.put("XHobby", null);
        metaDataMap.put("XPersonalAgreement", null);
        metaDataMap.put("XDoNotMergeFlag", null);
        metaDataMap.put("DeleteFlag", null);
        metaDataMap.put("InfoRemoveFlag", null);
        metaDataMap.put("DedupHiddenFlag", null);
        metaDataMap.put("PrefCommunicationChannel", null);
        metaDataMap.put("YanaseFlag", null);
        metaDataMap.put("FinancePartyType", null);
        metaDataMap.put("ContractNumber", null);
        metaDataMap.put("XPrivacyAct", null);
        metaDataMap.put("XFleet", null);
        metaDataMap.put("XPC_Ind", null);
        metaDataMap.put("XVANS_Ind", null);
        metaDataMap.put("LastActivityDate", null);
        metaDataMap.put("X_CUST_TYPE", null);
        metaDataMap.put("X_ANONYMIZED", null);
        metaDataMap.put("XPersonHistActionCode", null);
        metaDataMap.put("XPersonHistCreateDate", null);
        metaDataMap.put("XPersonHistCreatedBy", null);
        metaDataMap.put("XPersonHistEndDate", null);
        metaDataMap.put("XPersonHistoryIdPK", null);
        metaDataMap.put("XPersonLastUpdateDate", null);
        metaDataMap.put("XPersonLastUpdateTxId", null);
        metaDataMap.put("XPersonLastUpdateUser", null);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Refreshes all the attributes this business object supports.
     *
     * @see com.dwl.base.DWLCommon#refreshMap()
     * @generated
     */
    public void refreshMap() {

        if (bRequireMapRefresh) {
            super.refreshMap();
            metaDataMap.put("XDefunctInd", getXDefunctInd());
            metaDataMap.put("XMarketName", getXMarketName());
            metaDataMap.put("XBatchInd", getXBatchInd());
            metaDataMap.put("XEmployerName", getXEmployerName());
            metaDataMap.put("XOccupationType", getXOccupationType());
            metaDataMap.put("XOccupationValue", getXOccupationValue());
            metaDataMap.put("XLastModifiedSystemDate", getXLastModifiedSystemDate());
            metaDataMap.put("XSourceTypeFlag", getXSourceTypeFlag());
            metaDataMap.put("XGenderFS", getXGenderFS());
            metaDataMap.put("XBirthDateFS", getXBirthDateFS());
            metaDataMap.put("XGeneratedBy", getXGeneratedBy());
            metaDataMap.put("XHobby", getXHobby());
            metaDataMap.put("XPersonalAgreement", getXPersonalAgreement());
            metaDataMap.put("XDoNotMergeFlag", getXDoNotMergeFlag());
            metaDataMap.put("DeleteFlag", getDeleteFlag());
            metaDataMap.put("InfoRemoveFlag", getInfoRemoveFlag());
            metaDataMap.put("DedupHiddenFlag", getDedupHiddenFlag());
            metaDataMap.put("PrefCommunicationChannel", getPrefCommunicationChannel());
            metaDataMap.put("YanaseFlag", getYanaseFlag());
            metaDataMap.put("FinancePartyType", getFinancePartyType());
            metaDataMap.put("ContractNumber", getContractNumber());
            metaDataMap.put("XPrivacyAct", getXPrivacyAct());
            metaDataMap.put("XFleet", getXFleet());
            metaDataMap.put("XPC_Ind", getXPC_Ind());
            metaDataMap.put("XVANS_Ind", getXVANS_Ind());
            metaDataMap.put("LastActivityDate", getLastActivityDate());
            metaDataMap.put("X_CUST_TYPE", getX_CUST_TYPE());
            metaDataMap.put("X_ANONYMIZED", getX_ANONYMIZED());
            metaDataMap.put("XPersonHistActionCode", getXPersonHistActionCode());
            metaDataMap.put("XPersonHistCreateDate", getXPersonHistCreateDate());
            metaDataMap.put("XPersonHistCreatedBy", getXPersonHistCreatedBy());
            metaDataMap.put("XPersonHistEndDate", getXPersonHistEndDate());
            metaDataMap.put("XPersonHistoryIdPK", getXPersonHistoryIdPK());
            metaDataMap.put("XPersonLastUpdateDate", getXPersonLastUpdateDate());
            metaDataMap.put("XPersonLastUpdateTxId", getXPersonLastUpdateTxId());
            metaDataMap.put("XPersonLastUpdateUser", getXPersonLastUpdateUser());
            bRequireMapRefresh = false;
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the control object on this business object.
     *
     * @see com.dwl.base.DWLCommon#setControl(DWLControl)
     * @generated
     */
    public void setControl(DWLControl newDWLControl) {
        super.setControl(newDWLControl);

        if (eObjXPersonExt != null) {
            eObjXPersonExt.setControl(newDWLControl);
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the entity object associated with this business object.
     *
     * @generated
     */
    public EObjXPersonExt getEObjXPersonExt() {
        bRequireMapRefresh = true;
        return eObjXPersonExt;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the entity object associated with this business object.
     *
     * @param eObjXPersonExt
     *            The eObjXPersonExt to set.
     * @generated
     */
    public void setEObjXPersonExt(EObjXPersonExt eObjXPersonExt) {
        bRequireMapRefresh = true;
        this.eObjXPersonExt = eObjXPersonExt;
        this.eObjXPersonExt.setBaseEntity(getEObjPerson());
        if (this.eObjXPersonExt != null && this.eObjXPersonExt.getControl() == null) {
            DWLControl control = this.getControl();
            if (control != null) {
                this.eObjXPersonExt.setControl(control);
            }
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xDefunctInd attribute.
     * 
     * @generated
     */
    public String getXDefunctInd (){
   
        return eObjXPersonExt.getXDefunctInd();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xDefunctInd attribute.
     * 
     * @param newXDefunctInd
     *     The new value of xDefunctInd.
     * @generated
     */
    public void setXDefunctInd( String newXDefunctInd ) throws Exception {
        metaDataMap.put("XDefunctInd", newXDefunctInd);

        if (newXDefunctInd == null || newXDefunctInd.equals("")) {
            newXDefunctInd = null;


        }
        eObjXPersonExt.setXDefunctInd( newXDefunctInd );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xMarketName attribute.
     * 
     * @generated
     */
    public String getXMarketName (){
   
        return eObjXPersonExt.getXMarketName();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xMarketName attribute.
     * 
     * @param newXMarketName
     *     The new value of xMarketName.
     * @generated
     */
    public void setXMarketName( String newXMarketName ) throws Exception {
        metaDataMap.put("XMarketName", newXMarketName);

        if (newXMarketName == null || newXMarketName.equals("")) {
            newXMarketName = null;


        }
        eObjXPersonExt.setXMarketName( newXMarketName );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xBatchInd attribute.
     * 
     * @generated
     */
    public String getXBatchInd (){
   
        return eObjXPersonExt.getXBatchInd();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xBatchInd attribute.
     * 
     * @param newXBatchInd
     *     The new value of xBatchInd.
     * @generated
     */
    public void setXBatchInd( String newXBatchInd ) throws Exception {
        metaDataMap.put("XBatchInd", newXBatchInd);

        if (newXBatchInd == null || newXBatchInd.equals("")) {
            newXBatchInd = null;


        }
        eObjXPersonExt.setXBatchInd( newXBatchInd );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xEmployerName attribute.
     * 
     * @generated
     */
    public String getXEmployerName (){
   
        return eObjXPersonExt.getXEmployerName();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xEmployerName attribute.
     * 
     * @param newXEmployerName
     *     The new value of xEmployerName.
     * @generated
     */
    public void setXEmployerName( String newXEmployerName ) throws Exception {
        metaDataMap.put("XEmployerName", newXEmployerName);

        if (newXEmployerName == null || newXEmployerName.equals("")) {
            newXEmployerName = null;


        }
        eObjXPersonExt.setXEmployerName( newXEmployerName );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xOccupationType attribute.
     * 
     * @generated
     */
    public String getXOccupationType (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXPersonExt.getXOccupation());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xOccupationType attribute.
     * 
     * @param newXOccupationType
     *     The new value of xOccupationType.
     * @generated
     */
    public void setXOccupationType( String newXOccupationType ) throws Exception {
        metaDataMap.put("XOccupationType", newXOccupationType);

        if (newXOccupationType == null || newXOccupationType.equals("")) {
            newXOccupationType = null;


        }
        eObjXPersonExt.setXOccupation( DWLFunctionUtils.getLongFromString(newXOccupationType) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xOccupationValue attribute.
     * 
     * @generated
     */
    public String getXOccupationValue (){
      return xOccupationValue;
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xOccupationValue attribute.
     * 
     * @param newXOccupationValue
     *     The new value of xOccupationValue.
     * @generated
     */
    public void setXOccupationValue( String newXOccupationValue ) throws Exception {
        metaDataMap.put("XOccupationValue", newXOccupationValue);

        if (newXOccupationValue == null || newXOccupationValue.equals("")) {
            newXOccupationValue = null;


        }
        xOccupationValue = newXOccupationValue;
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xSourceTypeFlag attribute.
     * 
     * Source type value is NULL means CDM copy.If values FS present then it will be
     * FS copy.
     * 
     * @generated
     */
    public String getXSourceTypeFlag (){
   
        return eObjXPersonExt.getXSourceTypeFlag();
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xSourceTypeFlag attribute.
     * 
     * Source type value is NULL means CDM copy.If values FS present then it will be
     * FS copy.
     * 
     * @param newXSourceTypeFlag
     *     The new value of xSourceTypeFlag.
     * @generated
     */
    public void setXSourceTypeFlag( String newXSourceTypeFlag ) throws Exception {
        metaDataMap.put("XSourceTypeFlag", newXSourceTypeFlag);

        if (newXSourceTypeFlag == null || newXSourceTypeFlag.equals("")) {
            newXSourceTypeFlag = null;


        }
        eObjXPersonExt.setXSourceTypeFlag( newXSourceTypeFlag );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xGenderFS attribute.
     * 
     * @generated
     */
    public String getXGenderFS (){
   
        return eObjXPersonExt.getXGenderFS();
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xGenderFS attribute.
     * 
     * @param newXGenderFS
     *     The new value of xGenderFS.
     * @generated
     */
    public void setXGenderFS( String newXGenderFS ) throws Exception {
        metaDataMap.put("XGenderFS", newXGenderFS);

        if (newXGenderFS == null || newXGenderFS.equals("")) {
            newXGenderFS = null;


        }
        eObjXPersonExt.setXGenderFS( newXGenderFS );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xBirthDateFS attribute.
     * 
     * @generated
     */
    public String getXBirthDateFS (){
   
        return DWLFunctionUtils.getStringFromTimestamp(eObjXPersonExt.getXBirthDateFS());
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xBirthDateFS attribute.
     * 
     * @param newXBirthDateFS
     *     The new value of xBirthDateFS.
     * @generated
     */
    public void setXBirthDateFS( String newXBirthDateFS ) throws Exception {
        metaDataMap.put("XBirthDateFS", newXBirthDateFS);
       	isValidXBirthDateFS = true;

        if (newXBirthDateFS == null || newXBirthDateFS.equals("")) {
            newXBirthDateFS = null;
            eObjXPersonExt.setXBirthDateFS(null);


        }
    else {
        	if (DateValidator.validates(newXBirthDateFS)) {
           		eObjXPersonExt.setXBirthDateFS(DateFormatter.getStartDateTimestamp(newXBirthDateFS));
            	metaDataMap.put("XBirthDateFS", getXBirthDateFS());
        	} else {
            	if (Configuration.getConfiguration().getConfigItem(
              "/IBM/DWLCommonServices/InternalValidation/enabled").getBooleanValue()) {
                	if (metaDataMap.get("XBirthDateFS") != null) {
                    	metaDataMap.put("XBirthDateFS", "");
                	}
                	isValidXBirthDateFS = false;
                	eObjXPersonExt.setXBirthDateFS(null);
            	}
        	}
        }
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xGeneratedBy attribute.
     * 
     * @generated
     */
    public String getXGeneratedBy (){
   
        return eObjXPersonExt.getXGeneratedBy();
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xGeneratedBy attribute.
     * 
     * @param newXGeneratedBy
     *     The new value of xGeneratedBy.
     * @generated
     */
    public void setXGeneratedBy( String newXGeneratedBy ) throws Exception {
        metaDataMap.put("XGeneratedBy", newXGeneratedBy);

        if (newXGeneratedBy == null || newXGeneratedBy.equals("")) {
            newXGeneratedBy = null;


        }
        eObjXPersonExt.setXGeneratedBy( newXGeneratedBy );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xHobby attribute.
     * 
     * @generated
     */
    public String getXHobby (){
   
        return eObjXPersonExt.getXHobby();
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xHobby attribute.
     * 
     * @param newXHobby
     *     The new value of xHobby.
     * @generated
     */
    public void setXHobby( String newXHobby ) throws Exception {
        metaDataMap.put("XHobby", newXHobby);

        if (newXHobby == null || newXHobby.equals("")) {
            newXHobby = null;


        }
        eObjXPersonExt.setXHobby( newXHobby );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xPersonalAgreement attribute.
     * 
     * @generated
     */
    public String getXPersonalAgreement (){
   
        return eObjXPersonExt.getXPersonalAgreement();
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xPersonalAgreement attribute.
     * 
     * @param newXPersonalAgreement
     *     The new value of xPersonalAgreement.
     * @generated
     */
    public void setXPersonalAgreement( String newXPersonalAgreement ) throws Exception {
        metaDataMap.put("XPersonalAgreement", newXPersonalAgreement);

        if (newXPersonalAgreement == null || newXPersonalAgreement.equals("")) {
            newXPersonalAgreement = null;


        }
        eObjXPersonExt.setXPersonalAgreement( newXPersonalAgreement );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xDoNotMergeFlag attribute.
     * 
     * @generated
     */
    public String getXDoNotMergeFlag (){
   
        return eObjXPersonExt.getXDoNotMergeFlag();
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xDoNotMergeFlag attribute.
     * 
     * @param newXDoNotMergeFlag
     *     The new value of xDoNotMergeFlag.
     * @generated
     */
    public void setXDoNotMergeFlag( String newXDoNotMergeFlag ) throws Exception {
        metaDataMap.put("XDoNotMergeFlag", newXDoNotMergeFlag);

        if (newXDoNotMergeFlag == null || newXDoNotMergeFlag.equals("")) {
            newXDoNotMergeFlag = null;


        }
        eObjXPersonExt.setXDoNotMergeFlag( newXDoNotMergeFlag );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the deleteFlag attribute.
     * 
     * @generated
     */
    public String getDeleteFlag (){
   
        return eObjXPersonExt.getDeleteFlag();
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the deleteFlag attribute.
     * 
     * @param newDeleteFlag
     *     The new value of deleteFlag.
     * @generated
     */
    public void setDeleteFlag( String newDeleteFlag ) throws Exception {
        metaDataMap.put("DeleteFlag", newDeleteFlag);

        if (newDeleteFlag == null || newDeleteFlag.equals("")) {
            newDeleteFlag = null;


        }
        eObjXPersonExt.setDeleteFlag( newDeleteFlag );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the infoRemoveFlag attribute.
     * 
     * @generated
     */
    public String getInfoRemoveFlag (){
   
        return eObjXPersonExt.getInfoRemoveFlag();
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the infoRemoveFlag attribute.
     * 
     * @param newInfoRemoveFlag
     *     The new value of infoRemoveFlag.
     * @generated
     */
    public void setInfoRemoveFlag( String newInfoRemoveFlag ) throws Exception {
        metaDataMap.put("InfoRemoveFlag", newInfoRemoveFlag);

        if (newInfoRemoveFlag == null || newInfoRemoveFlag.equals("")) {
            newInfoRemoveFlag = null;


        }
        eObjXPersonExt.setInfoRemoveFlag( newInfoRemoveFlag );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the dedupHiddenFlag attribute.
     * 
     * @generated
     */
    public String getDedupHiddenFlag (){
   
        return eObjXPersonExt.getDedupHiddenFlag();
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the dedupHiddenFlag attribute.
     * 
     * @param newDedupHiddenFlag
     *     The new value of dedupHiddenFlag.
     * @generated
     */
    public void setDedupHiddenFlag( String newDedupHiddenFlag ) throws Exception {
        metaDataMap.put("DedupHiddenFlag", newDedupHiddenFlag);

        if (newDedupHiddenFlag == null || newDedupHiddenFlag.equals("")) {
            newDedupHiddenFlag = null;


        }
        eObjXPersonExt.setDedupHiddenFlag( newDedupHiddenFlag );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the prefCommunicationChannel attribute.
     * 
     * @generated
     */
    public String getPrefCommunicationChannel (){
   
        return eObjXPersonExt.getPrefCommunicationChannel();
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the prefCommunicationChannel attribute.
     * 
     * @param newPrefCommunicationChannel
     *     The new value of prefCommunicationChannel.
     * @generated
     */
    public void setPrefCommunicationChannel( String newPrefCommunicationChannel ) throws Exception {
        metaDataMap.put("PrefCommunicationChannel", newPrefCommunicationChannel);

        if (newPrefCommunicationChannel == null || newPrefCommunicationChannel.equals("")) {
            newPrefCommunicationChannel = null;


        }
        eObjXPersonExt.setPrefCommunicationChannel( newPrefCommunicationChannel );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the yanaseFlag attribute.
     * 
     * @generated
     */
    public String getYanaseFlag (){
   
        return eObjXPersonExt.getYanaseFlag();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the yanaseFlag attribute.
     * 
     * @param newYanaseFlag
     *     The new value of yanaseFlag.
     * @generated
     */
    public void setYanaseFlag( String newYanaseFlag ) throws Exception {
        metaDataMap.put("YanaseFlag", newYanaseFlag);

        if (newYanaseFlag == null || newYanaseFlag.equals("")) {
            newYanaseFlag = null;


        }
        eObjXPersonExt.setYanaseFlag( newYanaseFlag );
     }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the financePartyType attribute.
     * 
     * @generated
     */
    public String getFinancePartyType (){
   
        return eObjXPersonExt.getFinancePartyType();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the financePartyType attribute.
     * 
     * @param newFinancePartyType
     *     The new value of financePartyType.
     * @generated
     */
    public void setFinancePartyType( String newFinancePartyType ) throws Exception {
        metaDataMap.put("FinancePartyType", newFinancePartyType);

        if (newFinancePartyType == null || newFinancePartyType.equals("")) {
            newFinancePartyType = null;


        }
        eObjXPersonExt.setFinancePartyType( newFinancePartyType );
     }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the contractNumber attribute.
     * 
     * @generated
     */
    public String getContractNumber (){
   
        return eObjXPersonExt.getContractNumber();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the contractNumber attribute.
     * 
     * @param newContractNumber
     *     The new value of contractNumber.
     * @generated
     */
    public void setContractNumber( String newContractNumber ) throws Exception {
        metaDataMap.put("ContractNumber", newContractNumber);

        if (newContractNumber == null || newContractNumber.equals("")) {
            newContractNumber = null;


        }
        eObjXPersonExt.setContractNumber( newContractNumber );
     }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xPrivacyAct attribute.
     * 
     * @generated
     */
    public String getXPrivacyAct (){
   
        return eObjXPersonExt.getXPrivacyAct();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xPrivacyAct attribute.
     * 
     * @param newXPrivacyAct
     *     The new value of xPrivacyAct.
     * @generated
     */
    public void setXPrivacyAct( String newXPrivacyAct ) throws Exception {
        metaDataMap.put("XPrivacyAct", newXPrivacyAct);

        if (newXPrivacyAct == null || newXPrivacyAct.equals("")) {
            newXPrivacyAct = null;


        }
        eObjXPersonExt.setXPrivacyAct( newXPrivacyAct );
     }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xFleet attribute.
     * 
     * @generated
     */
    public String getXFleet (){
   
        return eObjXPersonExt.getXFleet();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xFleet attribute.
     * 
     * @param newXFleet
     *     The new value of xFleet.
     * @generated
     */
    public void setXFleet( String newXFleet ) throws Exception {
        metaDataMap.put("XFleet", newXFleet);

        if (newXFleet == null || newXFleet.equals("")) {
            newXFleet = null;


        }
        eObjXPersonExt.setXFleet( newXFleet );
     }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the lastActivityDate attribute.
     * 
     * @generated
     */
    public String getLastActivityDate (){
   
        return DWLFunctionUtils.getStringFromTimestamp(eObjXPersonExt.getLastActivityDate());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the lastActivityDate attribute.
     * 
     * @param newLastActivityDate
     *     The new value of lastActivityDate.
     * @generated
     */
    public void setLastActivityDate( String newLastActivityDate ) throws Exception {
        metaDataMap.put("LastActivityDate", newLastActivityDate);
       	isValidLastActivityDate = true;

        if (newLastActivityDate == null || newLastActivityDate.equals("")) {
            newLastActivityDate = null;
            eObjXPersonExt.setLastActivityDate(null);


        }
    else {
        	if (DateValidator.validates(newLastActivityDate)) {
           		eObjXPersonExt.setLastActivityDate(DateFormatter.getStartDateTimestamp(newLastActivityDate));
            	metaDataMap.put("LastActivityDate", getLastActivityDate());
        	} else {
            	if (Configuration.getConfiguration().getConfigItem(
              "/IBM/DWLCommonServices/InternalValidation/enabled").getBooleanValue()) {
                	if (metaDataMap.get("LastActivityDate") != null) {
                    	metaDataMap.put("LastActivityDate", "");
                	}
                	isValidLastActivityDate = false;
                	eObjXPersonExt.setLastActivityDate(null);
            	}
        	}
        }
     }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the x_CUST_TYPE attribute.
     * 
     * @generated
     */
    public String getX_CUST_TYPE (){
   
        return eObjXPersonExt.getX_CUST_TYPE();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the x_CUST_TYPE attribute.
     * 
     * @param newX_CUST_TYPE
     *     The new value of x_CUST_TYPE.
     * @generated
     */
    public void setX_CUST_TYPE( String newX_CUST_TYPE ) throws Exception {
        metaDataMap.put("X_CUST_TYPE", newX_CUST_TYPE);

        if (newX_CUST_TYPE == null || newX_CUST_TYPE.equals("")) {
            newX_CUST_TYPE = null;


        }
        eObjXPersonExt.setX_CUST_TYPE( newX_CUST_TYPE );
     }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the x_ANONYMIZED attribute.
     * 
     * @generated
     */
    public String getX_ANONYMIZED (){
   
        return eObjXPersonExt.getX_ANONYMIZED();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the x_ANONYMIZED attribute.
     * 
     * @param newX_ANONYMIZED
     *     The new value of x_ANONYMIZED.
     * @generated
     */
    public void setX_ANONYMIZED( String newX_ANONYMIZED ) throws Exception {
        metaDataMap.put("X_ANONYMIZED", newX_ANONYMIZED);

        if (newX_ANONYMIZED == null || newX_ANONYMIZED.equals("")) {
            newX_ANONYMIZED = null;


        }
        eObjXPersonExt.setX_ANONYMIZED( newX_ANONYMIZED );
     }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xPC_Ind attribute.
     * 
     * @generated
     */
    public String getXPC_Ind (){
   
        return eObjXPersonExt.getXPC_Ind();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xPC_Ind attribute.
     * 
     * @param newXPC_Ind
     *     The new value of xPC_Ind.
     * @generated
     */
    public void setXPC_Ind( String newXPC_Ind ) throws Exception {
        metaDataMap.put("XPC_Ind", newXPC_Ind);

        if (newXPC_Ind == null || newXPC_Ind.equals("")) {
            newXPC_Ind = null;


        }
        eObjXPersonExt.setXPC_Ind( newXPC_Ind );
     }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xVANS_Ind attribute.
     * 
     * @generated
     */
    public String getXVANS_Ind (){
   
        return eObjXPersonExt.getXVANS_Ind();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xVANS_Ind attribute.
     * 
     * @param newXVANS_Ind
     *     The new value of xVANS_Ind.
     * @generated
     */
    public void setXVANS_Ind( String newXVANS_Ind ) throws Exception {
        metaDataMap.put("XVANS_Ind", newXVANS_Ind);

        if (newXVANS_Ind == null || newXVANS_Ind.equals("")) {
            newXVANS_Ind = null;


        }
        eObjXPersonExt.setXVANS_Ind( newXVANS_Ind );
     }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xLastModifiedSystemDate attribute.
     * 
     * @generated
     */
    public String getXLastModifiedSystemDate (){
   
        return DWLFunctionUtils.getStringFromTimestamp(eObjXPersonExt.getXLastModifiedSystemDate());
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xLastModifiedSystemDate attribute.
     * 
     * @param newXLastModifiedSystemDate
     *     The new value of xLastModifiedSystemDate.
     * @generated
     */
    public void setXLastModifiedSystemDate( String newXLastModifiedSystemDate ) throws Exception {
        metaDataMap.put("XLastModifiedSystemDate", newXLastModifiedSystemDate);
       	isValidXLastModifiedSystemDate = true;

        if (newXLastModifiedSystemDate == null || newXLastModifiedSystemDate.equals("")) {
            newXLastModifiedSystemDate = null;
            eObjXPersonExt.setXLastModifiedSystemDate(null);


        }
    else {
        	if (DateValidator.validates(newXLastModifiedSystemDate)) {
           		eObjXPersonExt.setXLastModifiedSystemDate(DateFormatter.getStartDateTimestamp(newXLastModifiedSystemDate));
            	metaDataMap.put("XLastModifiedSystemDate", getXLastModifiedSystemDate());
        	} else {
            	if (Configuration.getConfiguration().getConfigItem(
              "/IBM/DWLCommonServices/InternalValidation/enabled").getBooleanValue()) {
                	if (metaDataMap.get("XLastModifiedSystemDate") != null) {
                    	metaDataMap.put("XLastModifiedSystemDate", "");
                	}
                	isValidXLastModifiedSystemDate = false;
                	eObjXPersonExt.setXLastModifiedSystemDate(null);
            	}
        	}
        }
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateTxId attribute.
     *
     * @generated
     */
    public String getXPersonLastUpdateTxId() {
        return DWLFunctionUtils.getStringFromLong(eObjXPersonExt.getLastUpdateTxId());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateUser attribute.
     *
     * @generated
     */
    public String getXPersonLastUpdateUser() {
        return eObjXPersonExt.getLastUpdateUser();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateDt attribute.
     *
     * @generated
     */
    public String getXPersonLastUpdateDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXPersonExt.getLastUpdateDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateTxId attribute.
     *
     * @param newLastUpdateTxId
     *     The new value of LastUpdateTxId.
     * @generated
     */
    public void setXPersonLastUpdateTxId(String newLastUpdateTxId) {
        metaDataMap.put("XPersonLastUpdateTxId", newLastUpdateTxId);

        if ((newLastUpdateTxId == null) || newLastUpdateTxId.equals("")) {
            newLastUpdateTxId = null;
        }
        eObjXPersonExt.setLastUpdateTxId(DWLFunctionUtils.getLongFromString(newLastUpdateTxId));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateUser attribute.
     *
     * @param newLastUpdateUser
     *     The new value of LastUpdateUser.
     * @generated
     */
    public void setXPersonLastUpdateUser(String newLastUpdateUser) {
        metaDataMap.put("XPersonLastUpdateUser", newLastUpdateUser);

        if ((newLastUpdateUser == null) || newLastUpdateUser.equals("")) {
            newLastUpdateUser = null;
        }
        eObjXPersonExt.setLastUpdateUser(newLastUpdateUser);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateDt attribute.
     *
     * @param newLastUpdateDt
     *     The new value of LastUpdateDt.
     * @throws Exception
     * @generated
     */
    public void setXPersonLastUpdateDate(String newLastUpdateDt) throws Exception {
        metaDataMap.put("XPersonLastUpdateDate", newLastUpdateDt);

        if ((newLastUpdateDt == null) || newLastUpdateDt.equals("")) {
            newLastUpdateDt = null;
        }

        eObjXPersonExt.setLastUpdateDt(DWLFunctionUtils.getTimestampFromTimestampString(newLastUpdateDt));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XPersonHistActionCode history attribute.
     *
     * @generated
     */
    public String getXPersonHistActionCode() {
        return eObjXPersonExt.getHistActionCode();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XPersonHistActionCode history attribute.
     *
     * @param aXPersonHistActionCode
     *     The new value of XPersonHistActionCode.
     * @generated
     */
    public void setXPersonHistActionCode(String aXPersonHistActionCode) {
        metaDataMap.put("XPersonHistActionCode", aXPersonHistActionCode);

        if ((aXPersonHistActionCode == null) || aXPersonHistActionCode.equals("")) {
            aXPersonHistActionCode = null;
        }
        eObjXPersonExt.setHistActionCode(aXPersonHistActionCode);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XPersonHistCreateDate history attribute.
     *
     * @generated
     */
    public String getXPersonHistCreateDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXPersonExt.getHistCreateDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XPersonHistCreateDate history attribute.
     *
     * @param aXPersonHistCreateDate
     *     The new value of XPersonHistCreateDate.
     * @generated
     */
    public void setXPersonHistCreateDate(String aXPersonHistCreateDate) throws Exception{
        metaDataMap.put("XPersonHistCreateDate", aXPersonHistCreateDate);

        if ((aXPersonHistCreateDate == null) || aXPersonHistCreateDate.equals("")) {
            aXPersonHistCreateDate = null;
        }

        eObjXPersonExt.setHistCreateDt(DWLFunctionUtils.getTimestampFromTimestampString(aXPersonHistCreateDate));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XPersonHistCreatedBy history attribute.
     *
     * @generated
     */
    public String getXPersonHistCreatedBy() {
        return eObjXPersonExt.getHistCreatedBy();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XPersonHistCreatedBy history attribute.
     *
     * @param aXPersonHistCreatedBy
     *     The new value of XPersonHistCreatedBy.
     * @generated
     */
    public void setXPersonHistCreatedBy(String aXPersonHistCreatedBy) {
        metaDataMap.put("XPersonHistCreatedBy", aXPersonHistCreatedBy);

        if ((aXPersonHistCreatedBy == null) || aXPersonHistCreatedBy.equals("")) {
            aXPersonHistCreatedBy = null;
        }

        eObjXPersonExt.setHistCreatedBy(aXPersonHistCreatedBy);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XPersonHistEndDate history attribute.
     *
     * @generated
     */
    public String getXPersonHistEndDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXPersonExt.getHistEndDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XPersonHistEndDate history attribute.
     *
     * @param aXPersonHistEndDate
     *     The new value of XPersonHistEndDate.
     * @generated
     */
    public void setXPersonHistEndDate(String aXPersonHistEndDate) throws Exception{
        metaDataMap.put("XPersonHistEndDate", aXPersonHistEndDate);

        if ((aXPersonHistEndDate == null) || aXPersonHistEndDate.equals("")) {
            aXPersonHistEndDate = null;
        }
        eObjXPersonExt.setHistEndDt(DWLFunctionUtils.getTimestampFromTimestampString(aXPersonHistEndDate));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XPersonHistoryIdPK history attribute.
     *
     * @generated
     */
    public String getXPersonHistoryIdPK() {
        return DWLFunctionUtils.getStringFromLong(eObjXPersonExt.getHistoryIdPK());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XPersonHistoryIdPK history attribute.
     *
     * @param aXPersonHistoryIdPK
     *     The new value of XPersonHistoryIdPK.
     * @generated
     */
    public void setXPersonHistoryIdPK(String aXPersonHistoryIdPK) {
        metaDataMap.put("XPersonHistoryIdPK", aXPersonHistoryIdPK);

        if ((aXPersonHistoryIdPK == null) || aXPersonHistoryIdPK.equals("")) {
            aXPersonHistoryIdPK = null;
        }
        eObjXPersonExt.setHistoryIdPK(DWLFunctionUtils.getLongFromString(aXPersonHistoryIdPK));
    }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation during an add transaction.
     *
     * @generated
     */
    public DWLStatus validateAdd(int level, DWLStatus status) throws Exception {

        status = super.validateAdd(level, status);
        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0038I Add any controller-level custom validation logic to be
            // executed for this object during an "add" transaction

        }

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            // MDM_TODO0: CDKWB0039I Add any component-level custom validation logic to be
            // executed for this object during an "add" transaction
        }
        status = getValidationStatus(level, status);
        return status;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation during an update transaction.
     *
     * @generated
     */
    public DWLStatus validateUpdate(int level, DWLStatus status) throws Exception {
    logger.finest("ENTER validateUpdate(int level, DWLStatus status)");

        status = super.validateUpdate(level, status);
        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0040I Add any controller-level custom validation logic to be
            // executed for this object during an "update" transaction

        }

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            assignBeforeImageValues(metaDataMap);
            
            // MDM_TODO0: CDKWB0041I Add any component-level custom validation logic to be
            // executed for this object during an "update" transaction
        }
        status = getValidationStatus(level, status);
    if (logger.isFinestEnabled()) {
        	String returnValue = status.toString();
      logger.finest("RETURN validateUpdate(int level, DWLStatus status) " + returnValue);
    }
        return status;
    }



    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation common to both add and update transactions.
     *
     * @generated
     */
     
    private DWLStatus getValidationStatus(int level, DWLStatus status) throws Exception {
    logger.finest("ENTER getValidationStatus(int level, DWLStatus status)");

        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0034I Add any common controller-level custom validation
            // logic to be executed for this object during either "add" or
            // "update" transactions
    		controllerValidation_XMarketName(status);
    		controllerValidation_XBatchInd(status);
    		controllerValidation_XOccupation(status);
    		controllerValidation_XLastModifiedSystemDate(status);
    		controllerValidation_XBirthDateFS(status);
    		controllerValidation_LastActivityDate(status);
    	}

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            // MDM_TODO0: CDKWB0035I Add any common component-level custom validation logic
            // to be executed for this object during either "add" or "update"
            // transactions
    		componentValidation_XMarketName(status);
    		componentValidation_XBatchInd(status);
    		componentValidation_XOccupation(status);
    		componentValidation_XLastModifiedSystemDate(status);
    		componentValidation_XBirthDateFS(status);
    		componentValidation_LastActivityDate(status);
        }
        
        if (logger.isFinestEnabled()) {
            String returnValue = status.toString();
      logger.finest("RETURN getValidationStatus(int level, DWLStatus status) " + returnValue);
        }
    
        return status;
    }

    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "XMarketName"
     *
     * @generated
     */
	private void componentValidation_XMarketName(DWLStatus status) {
  
            boolean isXMarketNameNull = false;
            if (eObjXPersonExt.getXMarketName() == null || 
            	eObjXPersonExt.getXMarketName().trim().equals("")) {
                isXMarketNameNull = true;
            }
            if (isXMarketNameNull) {
                DWLError err = createDWLError("XPerson", "XMarketName", DSEAAdditionsExtsErrorReasonCode.XPERSON_XMARKETNAME_NULL);
                status.addError(err); 
            }
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "XBatchInd"
     *
     * @generated
     */
	private void componentValidation_XBatchInd(DWLStatus status) {
  
            boolean isXBatchIndNull = false;
            if (eObjXPersonExt.getXBatchInd() == null || 
            	eObjXPersonExt.getXBatchInd().trim().equals("")) {
                isXBatchIndNull = true;
            }
            if (isXBatchIndNull) {
                DWLError err = createDWLError("XPerson", "XBatchInd", DSEAAdditionsExtsErrorReasonCode.XPERSON_XBATCHIND_NULL);
                status.addError(err); 
            }
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "XOccupation"
     *
     * @generated
     */
	private void componentValidation_XOccupation(DWLStatus status) {
  
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "XBirthDateFS"
     *
     * @generated
     */
  private void componentValidation_XBirthDateFS(DWLStatus status) {
  
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "LastActivityDate"
     *
     * @generated
     */
  private void componentValidation_LastActivityDate(DWLStatus status) {
  
  }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "XLastModifiedSystemDate"
     *
     * @generated
     */
  private void componentValidation_XLastModifiedSystemDate(DWLStatus status) {
  
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "XMarketName"
     *
     * @generated NOT
     */
	private void controllerValidation_XMarketName(DWLStatus status) throws Exception {
  
            boolean isXMarketNameNull = false;
            if (eObjXPersonExt.getXMarketName() == null || 
            	eObjXPersonExt.getXMarketName().trim().equals("")) {
                isXMarketNameNull = true;
            }
            /*if (isXMarketNameNull) {
                DWLError err = createDWLError("XPerson", "XMarketName", DSEAAdditionsExtsErrorReasonCode.XPERSON_XMARKETNAME_NULL);
                status.addError(err); 
            }*/
    	}
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "XBatchInd"
     *
     * @generated NOT
     */
	private void controllerValidation_XBatchInd(DWLStatus status) throws Exception {
  
            boolean isXBatchIndNull = false;
            if (eObjXPersonExt.getXBatchInd() == null || 
            	eObjXPersonExt.getXBatchInd().trim().equals("")) {
                isXBatchIndNull = true;
            }
            /*if (isXBatchIndNull) {
                DWLError err = createDWLError("XPerson", "XBatchInd", DSEAAdditionsExtsErrorReasonCode.XPERSON_XBATCHIND_NULL);
                status.addError(err); 
            }*/
    	}
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "XOccupation"
     *
     * @generated
     */
	private void controllerValidation_XOccupation(DWLStatus status) throws Exception {
  
      //persistent code type
            boolean isXOccupationNull = false;
            if ((eObjXPersonExt.getXOccupation() == null) &&
               ((getXOccupationValue() == null) || 
                 getXOccupationValue().trim().equals(""))) {
                isXOccupationNull = true;
            }
            if (!isXOccupationNull) {
                if (checkForInvalidXpersonXoccupation()) {
                    DWLError err = new DWLError();
                    err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XPERSON_BOBJ_EXT).longValue());
                    err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XPERSON_XOCCUPATION).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                    String infoForLogging="Error: Custom validation error occured for entity XPerson, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("controllerValidation_XOccupation " + infoForLogging);
        }
                status.addError(err);
            }

             }
    			
    	}
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "XBirthDateFS"
     *
     * @generated
     */
  private void controllerValidation_XBirthDateFS(DWLStatus status) throws Exception {
  
            boolean isXBirthDateFSNull = (eObjXPersonExt.getXBirthDateFS() == null);
            if (!isValidXBirthDateFS) {
              	DWLError err = new DWLError();
               	err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XPERSON_BOBJ_EXT).longValue());
               	err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XPERSON_XBIRTHDATEFS).longValue());
               	err.setErrorType(DWLErrorCode.DATA_INVALID_ERROR);
                String infoForLogging="Error: Validation error. Invalid time specified on property XBirthDateFS in entity XPerson, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode();
      logger.finest("controllerValidation_XBirthDateFS " + infoForLogging);
               	status.addError(err);
            } 
    	}


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "LastActivityDate"
     *
     * @generated
     */
  private void controllerValidation_LastActivityDate(DWLStatus status) throws Exception {
  
            boolean isLastActivityDateNull = (eObjXPersonExt.getLastActivityDate() == null);
            if (!isValidLastActivityDate) {
              	DWLError err = new DWLError();
               	err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XPERSON_BOBJ_EXT).longValue());
               	err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XPERSON_LASTACTIVITYDATE).longValue());
               	err.setErrorType(DWLErrorCode.DATA_INVALID_ERROR);
                String infoForLogging="Error: Validation error. Invalid time specified on property LastActivityDate in entity XPerson, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode();
      logger.finest("controllerValidation_LastActivityDate " + infoForLogging);
               	status.addError(err);
            } 
    	}

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "XLastModifiedSystemDate"
     *
     * @generated
     */
  private void controllerValidation_XLastModifiedSystemDate(DWLStatus status) throws Exception {
  
            boolean isXLastModifiedSystemDateNull = (eObjXPersonExt.getXLastModifiedSystemDate() == null);
            if (!isValidXLastModifiedSystemDate) {
              	DWLError err = new DWLError();
               	err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XPERSON_BOBJ_EXT).longValue());
               	err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XPERSON_XLASTMODIFIEDSYSTEMDATE).longValue());
               	err.setErrorType(DWLErrorCode.DATA_INVALID_ERROR);
                String infoForLogging="Error: Validation error. Invalid time specified on property XLastModifiedSystemDate in entity XPerson, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode();
      logger.finest("controllerValidation_XLastModifiedSystemDate " + infoForLogging);
               	status.addError(err);
            } 
    	}


    private DWLError createDWLError(String entityName, String propertyName,String reasonCode){	
		DWLError err = new DWLError();
		err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XPERSON_BOBJ_EXT).longValue());
		err.setReasonCode(new Long(reasonCode).longValue());
		err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
			String infoForLogging="Error: Validation error occured. Property " + propertyName + " is null, in entity " + entityName + ", component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
			logger.finest("createDWLError " + infoForLogging);
		}
		return err;
    }
    
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Check the value of the field XOccupation and return true if the error
     * reason INVALID_XPERSON_XOCCUPATION should be returned.
     *
     * @generated
  **/
	private boolean checkForInvalidXpersonXoccupation() throws Exception {
    logger.finest("ENTER checkForInvalidXpersonXoccupation()");
        boolean notValid = false;
      	String langId = (String) this.getControl().get(DWLControlKeys.LANG_ID);
      	CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
    Long codeType = DWLFunctionUtils.getLongFromString( getXOccupationType() );
    String codeValue = getXOccupationValue();
    if( codeValue != null && codeValue.trim().equals("")){
      codeValue = null;
    }
     
        if ( codeType != null && codeValue == null ){

             if( codeTypeCompHelper.isCodeValid("xcdoccupationtp", langId, getXOccupationType(),
                 CodeTypeComponentHelper.ACTIVE, getControl())) {
                 CodeTypeBObj ctBObj = codeTypeCompHelper
                 					.getCodeTypeByCode("xcdoccupationtp", langId, getXOccupationType(),
                         								getControl());
               	if (ctBObj != null) {
                   	setXOccupationValue( ctBObj.getvalue() );
               	}
             }
             else{
             	if (logger.isFinestEnabled()) {
              	 	String infoForLogging="NotValid 1";
      logger.finest("checkForInvalidXpersonXoccupation() " + infoForLogging);
        }
                 notValid = true;
           }
        }
        else if (codeType == null && codeValue != null ){
          
             CodeTypeBObj ctBObj = codeTypeCompHelper
                      .getCodeTypeByValue("xcdoccupationtp", langId, codeValue,
                                 getControl());

             if (ctBObj != null) {
                 setXOccupationType(ctBObj.gettp_cd());
             } 
             else {
             	if (logger.isFinestEnabled()) {
              	  	String infoForLogging="NotValid 2";
      logger.finest("checkForInvalidXpersonXoccupation() " + infoForLogging);
        }
                  notValid = true;
             }
        }
        else if ( codeType != null && codeValue != null
             && !codeTypeCompHelper.isCodeValuePairValid("xcdoccupationtp", langId, getXOccupationType(), 
                     new String[] { codeValue }, CodeTypeComponentHelper.ACTIVE, getControl())) {	
       if (logger.isFinestEnabled()) {
       		String infoForLogging="NotValid 3";
      logger.finest("checkForInvalidXpersonXoccupation() " + infoForLogging);
       }
             notValid = true;
        }
        if (logger.isFinestEnabled()) {
      String returnValue ="" +notValid;
      logger.finest("RETURN checkForInvalidXpersonXoccupation() " + returnValue);
    }
    return notValid;
     } 
				 






	 /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets a record from the extension table.
     *
     * @throws DWLBaseException
     * @generated
     */
    public void getRecord() throws DWLBaseException {
    logger.finest("ENTER getRecord()");
    
    try {
         			
          checkForInvalidXpersonXoccupation();
         }
         catch (Exception e) {
            DWLExceptionUtils.log(e);
            
            if (logger.isFinestEnabled()) {
        		String infoForLogging="Error: Error reading record " + e.getMessage(); 
      logger.finest("getRecord() " + infoForLogging);
      }
            status = new DWLStatus();

            TCRMReadException readEx = new TCRMReadException();
            IDWLErrorMessage  errHandler = DWLClassFactory.getErrorHandler();
            DWLError          error = errHandler.getErrorMessage(DSEAAdditionsExtsComponentID.XPERSON_BOBJ_EXT,
                                                                 TCRMErrorCode.READ_RECORD_ERROR,
                                                                 DSEAAdditionsExtsErrorReasonCode.READ_EXTENSION_XPERSON_FAILED,
                                                                 getControl(), new String[0]);
            error.setThrowable(e);
            status.addError(error);
            status.setStatus(DWLStatus.FATAL);
            readEx.setStatus(status);
            throw readEx;
        }	    		
    logger.finest("RETURN getRecord()");
  }


}

