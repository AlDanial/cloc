
/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[ae51b06cc48fa6baf576e2769115abf2]
 */

package com.ibm.daimler.dsea.component;

import java.util.Vector;

import com.dwl.base.util.DWLClassFactory;
import com.dwl.tcrm.exception.TCRMReadException;



import com.dwl.base.DWLControl;
import com.dwl.base.IDWLErrorMessage;
import com.dwl.base.constant.DWLControlKeys;
import com.dwl.base.error.DWLError;
import com.dwl.base.error.DWLErrorCode;
import com.dwl.base.error.DWLStatus;
import com.dwl.base.exception.DWLBaseException;
import com.dwl.base.util.DWLExceptionUtils;
import com.dwl.base.util.DWLFunctionUtils;
import com.dwl.management.config.client.Configuration;
import com.dwl.tcrm.common.IExtension;
import com.dwl.tcrm.common.ITCRMValidation;
import com.dwl.tcrm.common.TCRMErrorCode;
import com.dwl.tcrm.coreParty.component.TCRMPartyContactMethodBObj;
import com.dwl.tcrm.utilities.DateFormatter;
import com.dwl.tcrm.utilities.DateValidator;
import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsComponentID;
import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsErrorReasonCode;
import com.ibm.daimler.dsea.entityObject.EObjXContactMethodGroupExt;
import com.ibm.mdm.common.codetype.interfaces.CodeTypeComponentHelper;
import com.ibm.mdm.common.codetype.obj.CodeTypeBObj;
import com.ibm.mdm.common.validator.BusinessKeyValidationContext;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * This class provides the implementation of the business object
 * <code>XContactMethodGroupBObjExt</code>.
 * 
 * @see com.dwl.tcrm.common.TCRMCommon
 * @generated
 */
 

@SuppressWarnings("serial")
public class XContactMethodGroupBObjExt extends TCRMPartyContactMethodBObj implements IExtension {

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected EObjXContactMethodGroupExt eObjXContactMethodGroupExt;

    protected XPreferenceBObj xPreferenceBObj;
    
    protected XPrivacyAgreementBObj xPrivacyAgreementBObj;
	/**
    * <!-- begin-user-doc -->
	  * <!-- end-user-doc -->
    * @generated 
    */
	 private final static com.dwl.base.logging.IDWLLogger logger = com.dwl.base.logging.DWLLoggerManager.getLogger(XContactMethodGroupBObjExt.class);
		
 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected String xVerifiedValue;


    protected boolean isValidXLastModifiedSystemDate = true;


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated NOT
     */     
    public XContactMethodGroupBObjExt() {
        super();
        init();
        eObjXContactMethodGroupExt = new EObjXContactMethodGroupExt(getEObjContactMethodGroup());
        //xPrivacyAgreementBObj = new XPrivacyAgreementBObj();
        // JPN added XPref
        xPreferenceBObj=new XPreferenceBObj();
        setComponentID(DSEAAdditionsExtsComponentID.XCONTACT_METHOD_GROUP_BOBJ_EXT);
    }

    public XPreferenceBObj getXPreferenceBObj() {
		return xPreferenceBObj;
	}


	public void setXPreferenceBObj(
			XPreferenceBObj xPreferenceBObj) {
		this.xPreferenceBObj = xPreferenceBObj;
	}
	
	public XPrivacyAgreementBObj getXPrivacyAgreementBObj() {
		return xPrivacyAgreementBObj;
	}


	public void setXPrivacyAgreementBObj(
			XPrivacyAgreementBObj xPrivacyAgreementBObj) {
		this.xPrivacyAgreementBObj = xPrivacyAgreementBObj;
	}

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Initializes the fields required to populate the metaDataMap. Each key is
     * an element-level field of the business object.
     *
     * @generated
     */
    private void init() {
        metaDataMap.put("XVerifiedType", null);
        metaDataMap.put("XVerifiedValue", null);
        metaDataMap.put("XRetailerId", null);
        metaDataMap.put("XLastModifiedSystemDate", null);
        metaDataMap.put("XContactRetailerFlag", null);
        metaDataMap.put("X_BPID", null);
        metaDataMap.put("XContactMethodGroupHistActionCode", null);
        metaDataMap.put("XContactMethodGroupHistCreateDate", null);
        metaDataMap.put("XContactMethodGroupHistCreatedBy", null);
        metaDataMap.put("XContactMethodGroupHistEndDate", null);
        metaDataMap.put("XContactMethodGroupHistoryIdPK", null);
        metaDataMap.put("XContactMethodGroupLastUpdateDate", null);
        metaDataMap.put("XContactMethodGroupLastUpdateTxId", null);
        metaDataMap.put("XContactMethodGroupLastUpdateUser", null);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Refreshes all the attributes this business object supports.
     *
     * @see com.dwl.base.DWLCommon#refreshMap()
     * @generated
     */
    public void refreshMap() {

        if (bRequireMapRefresh) {
            super.refreshMap();
            metaDataMap.put("XVerifiedType", getXVerifiedType());
            metaDataMap.put("XVerifiedValue", getXVerifiedValue());
            metaDataMap.put("XRetailerId", getXRetailerId());
            metaDataMap.put("XLastModifiedSystemDate", getXLastModifiedSystemDate());
            metaDataMap.put("XContactRetailerFlag", getXContactRetailerFlag());
            metaDataMap.put("X_BPID", getX_BPID());
            metaDataMap.put("XContactMethodGroupHistActionCode", getXContactMethodGroupHistActionCode());
            metaDataMap.put("XContactMethodGroupHistCreateDate", getXContactMethodGroupHistCreateDate());
            metaDataMap.put("XContactMethodGroupHistCreatedBy", getXContactMethodGroupHistCreatedBy());
            metaDataMap.put("XContactMethodGroupHistEndDate", getXContactMethodGroupHistEndDate());
            metaDataMap.put("XContactMethodGroupHistoryIdPK", getXContactMethodGroupHistoryIdPK());
            metaDataMap.put("XContactMethodGroupLastUpdateDate", getXContactMethodGroupLastUpdateDate());
            metaDataMap.put("XContactMethodGroupLastUpdateTxId", getXContactMethodGroupLastUpdateTxId());
            metaDataMap.put("XContactMethodGroupLastUpdateUser", getXContactMethodGroupLastUpdateUser());
            bRequireMapRefresh = false;
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the control object on this business object.
     *
     * @see com.dwl.base.DWLCommon#setControl(DWLControl)
     * @generated
     */
    public void setControl(DWLControl newDWLControl) {
        super.setControl(newDWLControl);

        if (eObjXContactMethodGroupExt != null) {
            eObjXContactMethodGroupExt.setControl(newDWLControl);
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the entity object associated with this business object.
     *
     * @generated
     */
    public EObjXContactMethodGroupExt getEObjXContactMethodGroupExt() {
        bRequireMapRefresh = true;
        return eObjXContactMethodGroupExt;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the entity object associated with this business object.
     *
     * @param eObjXContactMethodGroupExt
     *            The eObjXContactMethodGroupExt to set.
     * @generated
     */
    public void setEObjXContactMethodGroupExt(EObjXContactMethodGroupExt eObjXContactMethodGroupExt) {
        bRequireMapRefresh = true;
        this.eObjXContactMethodGroupExt = eObjXContactMethodGroupExt;
        this.eObjXContactMethodGroupExt.setBaseEntity(getEObjContactMethodGroup());
        if (this.eObjXContactMethodGroupExt != null && this.eObjXContactMethodGroupExt.getControl() == null) {
            DWLControl control = this.getControl();
            if (control != null) {
                this.eObjXContactMethodGroupExt.setControl(control);
            }
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xVerifiedType attribute.
     * 
     * @generated
     */
    public String getXVerifiedType (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXContactMethodGroupExt.getXVerified());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xVerifiedType attribute.
     * 
     * @param newXVerifiedType
     *     The new value of xVerifiedType.
     * @generated
     */
    public void setXVerifiedType( String newXVerifiedType ) throws Exception {
        metaDataMap.put("XVerifiedType", newXVerifiedType);

        if (newXVerifiedType == null || newXVerifiedType.equals("")) {
            newXVerifiedType = null;


        }
        eObjXContactMethodGroupExt.setXVerified( DWLFunctionUtils.getLongFromString(newXVerifiedType) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xVerifiedValue attribute.
     * 
     * @generated
     */
    public String getXVerifiedValue (){
      return xVerifiedValue;
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xVerifiedValue attribute.
     * 
     * @param newXVerifiedValue
     *     The new value of xVerifiedValue.
     * @generated
     */
    public void setXVerifiedValue( String newXVerifiedValue ) throws Exception {
        metaDataMap.put("XVerifiedValue", newXVerifiedValue);

        if (newXVerifiedValue == null || newXVerifiedValue.equals("")) {
            newXVerifiedValue = null;


        }
        xVerifiedValue = newXVerifiedValue;
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xRetailerId attribute.
     * 
     * @generated
     */
    public String getXRetailerId (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXContactMethodGroupExt.getXRetailerId());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xRetailerId attribute.
     * 
     * @param newXRetailerId
     *     The new value of xRetailerId.
     * @generated
     */
    public void setXRetailerId( String newXRetailerId ) throws Exception {
        metaDataMap.put("XRetailerId", newXRetailerId);

        if (newXRetailerId == null || newXRetailerId.equals("")) {
            newXRetailerId = null;


        }
        eObjXContactMethodGroupExt.setXRetailerId( DWLFunctionUtils.getLongFromString(newXRetailerId) );
     }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xLastModifiedSystemDate attribute.
     * 
     * @generated
     */
    public String getXLastModifiedSystemDate (){
   
        return DWLFunctionUtils.getStringFromTimestamp(eObjXContactMethodGroupExt.getXLastModifiedSystemDate());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xLastModifiedSystemDate attribute.
     * 
     * @param newXLastModifiedSystemDate
     *     The new value of xLastModifiedSystemDate.
     * @generated
     */
    public void setXLastModifiedSystemDate( String newXLastModifiedSystemDate ) throws Exception {
        metaDataMap.put("XLastModifiedSystemDate", newXLastModifiedSystemDate);
       	isValidXLastModifiedSystemDate = true;

        if (newXLastModifiedSystemDate == null || newXLastModifiedSystemDate.equals("")) {
            newXLastModifiedSystemDate = null;
            eObjXContactMethodGroupExt.setXLastModifiedSystemDate(null);


        }
    else {
        	if (DateValidator.validates(newXLastModifiedSystemDate)) {
           		eObjXContactMethodGroupExt.setXLastModifiedSystemDate(DateFormatter.getStartDateTimestamp(newXLastModifiedSystemDate));
            	metaDataMap.put("XLastModifiedSystemDate", getXLastModifiedSystemDate());
        	} else {
            	if (Configuration.getConfiguration().getConfigItem(
              "/IBM/DWLCommonServices/InternalValidation/enabled").getBooleanValue()) {
                	if (metaDataMap.get("XLastModifiedSystemDate") != null) {
                    	metaDataMap.put("XLastModifiedSystemDate", "");
                	}
                	isValidXLastModifiedSystemDate = false;
                	eObjXContactMethodGroupExt.setXLastModifiedSystemDate(null);
            	}
        	}
        }
     }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xContactRetailerFlag attribute.
     * 
     * @generated
     */
    public String getXContactRetailerFlag (){
   
        return eObjXContactMethodGroupExt.getXContactRetailerFlag();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xContactRetailerFlag attribute.
     * 
     * @param newXContactRetailerFlag
     *     The new value of xContactRetailerFlag.
     * @generated
     */
    public void setXContactRetailerFlag( String newXContactRetailerFlag ) throws Exception {
        metaDataMap.put("XContactRetailerFlag", newXContactRetailerFlag);

        if (newXContactRetailerFlag == null || newXContactRetailerFlag.equals("")) {
            newXContactRetailerFlag = null;


        }
        eObjXContactMethodGroupExt.setXContactRetailerFlag( newXContactRetailerFlag );
     }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the x_BPID attribute.
     * 
     * @generated
     */
    public String getX_BPID (){
   
        return eObjXContactMethodGroupExt.getX_BPID();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the x_BPID attribute.
     * 
     * @param newX_BPID
     *     The new value of x_BPID.
     * @generated
     */
    public void setX_BPID( String newX_BPID ) throws Exception {
        metaDataMap.put("X_BPID", newX_BPID);

        if (newX_BPID == null || newX_BPID.equals("")) {
            newX_BPID = null;


        }
        eObjXContactMethodGroupExt.setX_BPID( newX_BPID );
     }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateTxId attribute.
     *
     * @generated
     */
    public String getXContactMethodGroupLastUpdateTxId() {
        return DWLFunctionUtils.getStringFromLong(eObjXContactMethodGroupExt.getLastUpdateTxId());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateUser attribute.
     *
     * @generated
     */
    public String getXContactMethodGroupLastUpdateUser() {
        return eObjXContactMethodGroupExt.getLastUpdateUser();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateDt attribute.
     *
     * @generated
     */
    public String getXContactMethodGroupLastUpdateDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXContactMethodGroupExt.getLastUpdateDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateTxId attribute.
     *
     * @param newLastUpdateTxId
     *     The new value of LastUpdateTxId.
     * @generated
     */
    public void setXContactMethodGroupLastUpdateTxId(String newLastUpdateTxId) {
        metaDataMap.put("XContactMethodGroupLastUpdateTxId", newLastUpdateTxId);

        if ((newLastUpdateTxId == null) || newLastUpdateTxId.equals("")) {
            newLastUpdateTxId = null;
        }
        eObjXContactMethodGroupExt.setLastUpdateTxId(DWLFunctionUtils.getLongFromString(newLastUpdateTxId));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateUser attribute.
     *
     * @param newLastUpdateUser
     *     The new value of LastUpdateUser.
     * @generated
     */
    public void setXContactMethodGroupLastUpdateUser(String newLastUpdateUser) {
        metaDataMap.put("XContactMethodGroupLastUpdateUser", newLastUpdateUser);

        if ((newLastUpdateUser == null) || newLastUpdateUser.equals("")) {
            newLastUpdateUser = null;
        }
        eObjXContactMethodGroupExt.setLastUpdateUser(newLastUpdateUser);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateDt attribute.
     *
     * @param newLastUpdateDt
     *     The new value of LastUpdateDt.
     * @throws Exception
     * @generated
     */
    public void setXContactMethodGroupLastUpdateDate(String newLastUpdateDt) throws Exception {
        metaDataMap.put("XContactMethodGroupLastUpdateDate", newLastUpdateDt);

        if ((newLastUpdateDt == null) || newLastUpdateDt.equals("")) {
            newLastUpdateDt = null;
        }

        eObjXContactMethodGroupExt.setLastUpdateDt(DWLFunctionUtils.getTimestampFromTimestampString(newLastUpdateDt));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XContactMethodGroupHistActionCode history attribute.
     *
     * @generated
     */
    public String getXContactMethodGroupHistActionCode() {
        return eObjXContactMethodGroupExt.getHistActionCode();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XContactMethodGroupHistActionCode history attribute.
     *
     * @param aXContactMethodGroupHistActionCode
     *     The new value of XContactMethodGroupHistActionCode.
     * @generated
     */
    public void setXContactMethodGroupHistActionCode(String aXContactMethodGroupHistActionCode) {
        metaDataMap.put("XContactMethodGroupHistActionCode", aXContactMethodGroupHistActionCode);

        if ((aXContactMethodGroupHistActionCode == null) || aXContactMethodGroupHistActionCode.equals("")) {
            aXContactMethodGroupHistActionCode = null;
        }
        eObjXContactMethodGroupExt.setHistActionCode(aXContactMethodGroupHistActionCode);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XContactMethodGroupHistCreateDate history attribute.
     *
     * @generated
     */
    public String getXContactMethodGroupHistCreateDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXContactMethodGroupExt.getHistCreateDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XContactMethodGroupHistCreateDate history attribute.
     *
     * @param aXContactMethodGroupHistCreateDate
     *     The new value of XContactMethodGroupHistCreateDate.
     * @generated
     */
    public void setXContactMethodGroupHistCreateDate(String aXContactMethodGroupHistCreateDate) throws Exception{
        metaDataMap.put("XContactMethodGroupHistCreateDate", aXContactMethodGroupHistCreateDate);

        if ((aXContactMethodGroupHistCreateDate == null) || aXContactMethodGroupHistCreateDate.equals("")) {
            aXContactMethodGroupHistCreateDate = null;
        }

        eObjXContactMethodGroupExt.setHistCreateDt(DWLFunctionUtils.getTimestampFromTimestampString(aXContactMethodGroupHistCreateDate));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XContactMethodGroupHistCreatedBy history attribute.
     *
     * @generated
     */
    public String getXContactMethodGroupHistCreatedBy() {
        return eObjXContactMethodGroupExt.getHistCreatedBy();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XContactMethodGroupHistCreatedBy history attribute.
     *
     * @param aXContactMethodGroupHistCreatedBy
     *     The new value of XContactMethodGroupHistCreatedBy.
     * @generated
     */
    public void setXContactMethodGroupHistCreatedBy(String aXContactMethodGroupHistCreatedBy) {
        metaDataMap.put("XContactMethodGroupHistCreatedBy", aXContactMethodGroupHistCreatedBy);

        if ((aXContactMethodGroupHistCreatedBy == null) || aXContactMethodGroupHistCreatedBy.equals("")) {
            aXContactMethodGroupHistCreatedBy = null;
        }

        eObjXContactMethodGroupExt.setHistCreatedBy(aXContactMethodGroupHistCreatedBy);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XContactMethodGroupHistEndDate history attribute.
     *
     * @generated
     */
    public String getXContactMethodGroupHistEndDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXContactMethodGroupExt.getHistEndDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XContactMethodGroupHistEndDate history attribute.
     *
     * @param aXContactMethodGroupHistEndDate
     *     The new value of XContactMethodGroupHistEndDate.
     * @generated
     */
    public void setXContactMethodGroupHistEndDate(String aXContactMethodGroupHistEndDate) throws Exception{
        metaDataMap.put("XContactMethodGroupHistEndDate", aXContactMethodGroupHistEndDate);

        if ((aXContactMethodGroupHistEndDate == null) || aXContactMethodGroupHistEndDate.equals("")) {
            aXContactMethodGroupHistEndDate = null;
        }
        eObjXContactMethodGroupExt.setHistEndDt(DWLFunctionUtils.getTimestampFromTimestampString(aXContactMethodGroupHistEndDate));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XContactMethodGroupHistoryIdPK history attribute.
     *
     * @generated
     */
    public String getXContactMethodGroupHistoryIdPK() {
        return DWLFunctionUtils.getStringFromLong(eObjXContactMethodGroupExt.getHistoryIdPK());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XContactMethodGroupHistoryIdPK history attribute.
     *
     * @param aXContactMethodGroupHistoryIdPK
     *     The new value of XContactMethodGroupHistoryIdPK.
     * @generated
     */
    public void setXContactMethodGroupHistoryIdPK(String aXContactMethodGroupHistoryIdPK) {
        metaDataMap.put("XContactMethodGroupHistoryIdPK", aXContactMethodGroupHistoryIdPK);

        if ((aXContactMethodGroupHistoryIdPK == null) || aXContactMethodGroupHistoryIdPK.equals("")) {
            aXContactMethodGroupHistoryIdPK = null;
        }
        eObjXContactMethodGroupExt.setHistoryIdPK(DWLFunctionUtils.getLongFromString(aXContactMethodGroupHistoryIdPK));
    }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation during an add transaction.
     *
     * @generated
     */
    public DWLStatus validateAdd(int level, DWLStatus status) throws Exception {

        status = super.validateAdd(level, status);
        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0038I Add any controller-level custom validation logic to be
            // executed for this object during an "add" transaction

        }

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            // MDM_TODO0: CDKWB0039I Add any component-level custom validation logic to be
            // executed for this object during an "add" transaction
        }
        status = getValidationStatus(level, status);
        return status;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation during an update transaction.
     *
     * @generated
     */
    public DWLStatus validateUpdate(int level, DWLStatus status) throws Exception {
    logger.finest("ENTER validateUpdate(int level, DWLStatus status)");

        status = super.validateUpdate(level, status);
        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0040I Add any controller-level custom validation logic to be
            // executed for this object during an "update" transaction

        }

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            assignBeforeImageValues(metaDataMap);
            
            // MDM_TODO0: CDKWB0041I Add any component-level custom validation logic to be
            // executed for this object during an "update" transaction
        }
        status = getValidationStatus(level, status);
    if (logger.isFinestEnabled()) {
        	String returnValue = status.toString();
      logger.finest("RETURN validateUpdate(int level, DWLStatus status) " + returnValue);
    }
        return status;
    }



    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation common to both add and update transactions.
     *
     * @generated
     */
     
    private DWLStatus getValidationStatus(int level, DWLStatus status) throws Exception {
    logger.finest("ENTER getValidationStatus(int level, DWLStatus status)");

        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0034I Add any common controller-level custom validation
            // logic to be executed for this object during either "add" or
            // "update" transactions
    		controllerValidation_XVerified(status);
    		controllerValidation_XLastModifiedSystemDate(status);
    	}

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            // MDM_TODO0: CDKWB0035I Add any common component-level custom validation logic
            // to be executed for this object during either "add" or "update"
            // transactions
    		componentValidation_XVerified(status);
    		componentValidation_XLastModifiedSystemDate(status);
        }
        
        if (logger.isFinestEnabled()) {
            String returnValue = status.toString();
      logger.finest("RETURN getValidationStatus(int level, DWLStatus status) " + returnValue);
        }
    
        return status;
    }

    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "XVerified"
     *
     * @generated
     */
	private void componentValidation_XVerified(DWLStatus status) {
  
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "XLastModifiedSystemDate"
     *
     * @generated
     */
  private void componentValidation_XLastModifiedSystemDate(DWLStatus status) {
  
  }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "XVerified"
     *
     * @generated
     */
	private void controllerValidation_XVerified(DWLStatus status) throws Exception {
  
      //persistent code type
            boolean isXVerifiedNull = false;
            if ((eObjXContactMethodGroupExt.getXVerified() == null) &&
               ((getXVerifiedValue() == null) || 
                 getXVerifiedValue().trim().equals(""))) {
                isXVerifiedNull = true;
            }
            if (!isXVerifiedNull) {
                if (checkForInvalidXcontactmethodgroupXverified()) {
                    DWLError err = new DWLError();
                    err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCONTACT_METHOD_GROUP_BOBJ_EXT).longValue());
                    err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XCONTACTMETHODGROUP_XVERIFIED).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                    String infoForLogging="Error: Custom validation error occured for entity XContactMethodGroup, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("controllerValidation_XVerified " + infoForLogging);
        }
                status.addError(err);
            }

             }
    			
    	}
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "XLastModifiedSystemDate"
     *
     * @generated
     */
  private void controllerValidation_XLastModifiedSystemDate(DWLStatus status) throws Exception {
  
            boolean isXLastModifiedSystemDateNull = (eObjXContactMethodGroupExt.getXLastModifiedSystemDate() == null);
            if (!isValidXLastModifiedSystemDate) {
              	DWLError err = new DWLError();
               	err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCONTACT_METHOD_GROUP_BOBJ_EXT).longValue());
               	err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XCONTACTMETHODGROUP_XLASTMODIFIEDSYSTEMDATE).longValue());
               	err.setErrorType(DWLErrorCode.DATA_INVALID_ERROR);
                String infoForLogging="Error: Validation error. Invalid time specified on property XLastModifiedSystemDate in entity XContactMethodGroup, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode();
      logger.finest("controllerValidation_XLastModifiedSystemDate " + infoForLogging);
               	status.addError(err);
            } 
    	}

    private DWLError createDWLError(String entityName, String propertyName,String reasonCode){	
		DWLError err = new DWLError();
		err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCONTACT_METHOD_GROUP_BOBJ_EXT).longValue());
		err.setReasonCode(new Long(reasonCode).longValue());
		err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
			String infoForLogging="Error: Validation error occured. Property " + propertyName + " is null, in entity " + entityName + ", component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
			logger.finest("createDWLError " + infoForLogging);
		}
		return err;
    }
    
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Check the value of the field XVerified and return true if the error
     * reason INVALID_XCONTACTMETHODGROUP_XVERIFIED should be returned.
     *
     * @generated
  **/
	private boolean checkForInvalidXcontactmethodgroupXverified() throws Exception {
    logger.finest("ENTER checkForInvalidXcontactmethodgroupXverified()");
        boolean notValid = false;
      	String langId = (String) this.getControl().get(DWLControlKeys.LANG_ID);
      	CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
    Long codeType = DWLFunctionUtils.getLongFromString( getXVerifiedType() );
    String codeValue = getXVerifiedValue();
    if( codeValue != null && codeValue.trim().equals("")){
      codeValue = null;
    }
     
        if ( codeType != null && codeValue == null ){

             if( codeTypeCompHelper.isCodeValid("xcdverifiedtp", langId, getXVerifiedType(),
                 CodeTypeComponentHelper.ACTIVE, getControl())) {
                 CodeTypeBObj ctBObj = codeTypeCompHelper
                 					.getCodeTypeByCode("xcdverifiedtp", langId, getXVerifiedType(),
                         								getControl());
               	if (ctBObj != null) {
                   	setXVerifiedValue( ctBObj.getvalue() );
               	}
             }
             else{
             	if (logger.isFinestEnabled()) {
              	 	String infoForLogging="NotValid 1";
      logger.finest("checkForInvalidXcontactmethodgroupXverified() " + infoForLogging);
        }
                 notValid = true;
           }
        }
        else if (codeType == null && codeValue != null ){
          
             CodeTypeBObj ctBObj = codeTypeCompHelper
                      .getCodeTypeByValue("xcdverifiedtp", langId, codeValue,
                                 getControl());

             if (ctBObj != null) {
                 setXVerifiedType(ctBObj.gettp_cd());
             } 
             else {
             	if (logger.isFinestEnabled()) {
              	  	String infoForLogging="NotValid 2";
      logger.finest("checkForInvalidXcontactmethodgroupXverified() " + infoForLogging);
        }
                  notValid = true;
             }
        }
        else if ( codeType != null && codeValue != null
             && !codeTypeCompHelper.isCodeValuePairValid("xcdverifiedtp", langId, getXVerifiedType(), 
                     new String[] { codeValue }, CodeTypeComponentHelper.ACTIVE, getControl())) {	
       if (logger.isFinestEnabled()) {
       		String infoForLogging="NotValid 3";
      logger.finest("checkForInvalidXcontactmethodgroupXverified() " + infoForLogging);
       }
             notValid = true;
        }
        if (logger.isFinestEnabled()) {
      String returnValue ="" +notValid;
      logger.finest("RETURN checkForInvalidXcontactmethodgroupXverified() " + returnValue);
    }
    return notValid;
     } 
				 






	 /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets a record from the extension table.
     *
     * @throws DWLBaseException
     * @generated
     */
    public void getRecord() throws DWLBaseException {
    logger.finest("ENTER getRecord()");
    
    try {
         			
          checkForInvalidXcontactmethodgroupXverified();
         }
         catch (Exception e) {
            DWLExceptionUtils.log(e);
            
            if (logger.isFinestEnabled()) {
        		String infoForLogging="Error: Error reading record " + e.getMessage(); 
      logger.finest("getRecord() " + infoForLogging);
      }
            status = new DWLStatus();

            TCRMReadException readEx = new TCRMReadException();
            IDWLErrorMessage  errHandler = DWLClassFactory.getErrorHandler();
            DWLError          error = errHandler.getErrorMessage(DSEAAdditionsExtsComponentID.XCONTACT_METHOD_GROUP_BOBJ_EXT,
                                                                 TCRMErrorCode.READ_RECORD_ERROR,
                                                                 DSEAAdditionsExtsErrorReasonCode.READ_EXTENSION_XCONTACTMETHODGROUP_FAILED,
                                                                 getControl(), new String[0]);
            error.setThrowable(e);
            status.addError(error);
            status.setStatus(DWLStatus.FATAL);
            readEx.setStatus(status);
            throw readEx;
        }	    		
    logger.finest("RETURN getRecord()");
  }

    public DWLStatus validateBusinessKey(BusinessKeyValidationContext validationContext) throws DWLBaseException, Exception {
        validationContext.setProperty(BusinessKeyValidationContext.CUSTOM_VALIDATION, BusinessKeyValidationContext.CUSTOM_VALIDATION);
        super.validateBusinessKey(validationContext);
        return validationContext.getStatus();
    }
    

}

