
/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[a618c7d38d8177fac0fed1c7d2bb6586]
 */

package com.ibm.daimler.dsea.component;

import com.dwl.tcrm.common.TCRMCommon;



import com.dwl.base.DWLControl;

import com.dwl.base.constant.DWLControlKeys;
import com.dwl.base.constant.DWLUtilErrorReasonCode;

import com.dwl.base.error.DWLError;
import com.dwl.base.error.DWLErrorCode;
import com.dwl.base.error.DWLStatus;

import com.dwl.base.exception.DWLBaseException;
import com.dwl.base.exception.DWLUpdateException;

import com.dwl.base.util.DWLClassFactory;
import com.dwl.base.util.DWLExceptionUtils;
import com.dwl.base.util.DWLFunctionUtils;

import com.dwl.management.config.client.Configuration;
import com.dwl.tcrm.common.ITCRMValidation;

import com.dwl.tcrm.utilities.DateFormatter;
import com.dwl.tcrm.utilities.DateValidator;
import com.dwl.tcrm.utilities.TCRMClassFactory;

import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsComponentID;
import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsErrorReasonCode;
import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsPropertyKeys;

import com.ibm.daimler.dsea.entityObject.EObjXVehicle;

import com.ibm.daimler.dsea.interfaces.DSEAAdditionsExts;

import com.ibm.mdm.common.codetype.interfaces.CodeTypeComponentHelper;

import com.ibm.mdm.common.codetype.obj.CodeTypeBObj;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * This class provides the implementation of the business object
 * <code>XVehicleBObj</code>.
 * 
 * @see com.dwl.tcrm.common.TCRMCommon
 * @generated
 */
 

@SuppressWarnings("serial")
public class XVehicleBObj extends TCRMCommon  {

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected EObjXVehicle eObjXVehicle;
	/**
    * <!-- begin-user-doc -->
	  * <!-- end-user-doc -->
    * @generated 
    */
	 private final static com.dwl.base.logging.IDWLLogger logger = com.dwl.base.logging.DWLLoggerManager.getLogger(XVehicleBObj.class);
		
 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected String countryValue;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected String sourceIdentifierValue;


    protected boolean isValidLastModifiedSystemDate = true;


    protected boolean isValidCreateDate = true;
    protected boolean isValidChangedDate = true;


    protected boolean isValidLastServiceDate = true;


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */     
    public XVehicleBObj() {
        super();
        init();
        eObjXVehicle = new EObjXVehicle();
        setComponentID(DSEAAdditionsExtsComponentID.XVEHICLE_BOBJ);
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Initializes the fields required to populate the metaDataMap. Each key is
     * an element-level field of the business object.
     *
     * @generated
     */
    private void init() {
        metaDataMap.put("VehiclepkId", null);
        metaDataMap.put("Division", null);
        metaDataMap.put("BusinessUnit", null);
        metaDataMap.put("Activity", null);
        metaDataMap.put("TypeClass", null);
        metaDataMap.put("BauRelhe", null);
        metaDataMap.put("BauMuster", null);
        metaDataMap.put("SubMuster", null);
        metaDataMap.put("EngineNumber", null);
        metaDataMap.put("CountryType", null);
        metaDataMap.put("CountryValue", null);
        metaDataMap.put("Color", null);
        metaDataMap.put("Trim", null);
        metaDataMap.put("GlobalVIN", null);
        metaDataMap.put("LocalVIN", null);
        metaDataMap.put("LicensePlate", null);
        metaDataMap.put("SourceIdentifierType", null);
        metaDataMap.put("SourceIdentifierValue", null);
        metaDataMap.put("LastModifiedSystemDate", null);
        metaDataMap.put("CreateDate", null);
        metaDataMap.put("ChangedDate", null);
        metaDataMap.put("LastServiceDate", null);
        metaDataMap.put("MarketName", null);
        metaDataMap.put("XVehicleHistActionCode", null);
        metaDataMap.put("XVehicleHistCreateDate", null);
        metaDataMap.put("XVehicleHistCreatedBy", null);
        metaDataMap.put("XVehicleHistEndDate", null);
        metaDataMap.put("XVehicleHistoryIdPK", null);
        metaDataMap.put("XVehicleLastUpdateDate", null);
        metaDataMap.put("XVehicleLastUpdateTxId", null);
        metaDataMap.put("XVehicleLastUpdateUser", null);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Refreshes all the attributes this business object supports.
     *
     * @see com.dwl.base.DWLCommon#refreshMap()
     * @generated
     */
    public void refreshMap() {

        if (bRequireMapRefresh) {
            super.refreshMap();
            metaDataMap.put("VehiclepkId", getVehiclepkId());
            metaDataMap.put("Division", getDivision());
            metaDataMap.put("BusinessUnit", getBusinessUnit());
            metaDataMap.put("Activity", getActivity());
            metaDataMap.put("TypeClass", getTypeClass());
            metaDataMap.put("BauRelhe", getBauRelhe());
            metaDataMap.put("BauMuster", getBauMuster());
            metaDataMap.put("SubMuster", getSubMuster());
            metaDataMap.put("EngineNumber", getEngineNumber());
            metaDataMap.put("CountryType", getCountryType());
            metaDataMap.put("CountryValue", getCountryValue());
            metaDataMap.put("Color", getColor());
            metaDataMap.put("Trim", getTrim());
            metaDataMap.put("GlobalVIN", getGlobalVIN());
            metaDataMap.put("LocalVIN", getLocalVIN());
            metaDataMap.put("LicensePlate", getLicensePlate());
            metaDataMap.put("SourceIdentifierType", getSourceIdentifierType());
            metaDataMap.put("SourceIdentifierValue", getSourceIdentifierValue());
            metaDataMap.put("LastModifiedSystemDate", getLastModifiedSystemDate());
            metaDataMap.put("CreateDate", getCreateDate());
            metaDataMap.put("ChangedDate", getChangedDate());
            metaDataMap.put("LastServiceDate", getLastServiceDate());
            metaDataMap.put("MarketName", getMarketName());
            metaDataMap.put("XVehicleHistActionCode", getXVehicleHistActionCode());
            metaDataMap.put("XVehicleHistCreateDate", getXVehicleHistCreateDate());
            metaDataMap.put("XVehicleHistCreatedBy", getXVehicleHistCreatedBy());
            metaDataMap.put("XVehicleHistEndDate", getXVehicleHistEndDate());
            metaDataMap.put("XVehicleHistoryIdPK", getXVehicleHistoryIdPK());
            metaDataMap.put("XVehicleLastUpdateDate", getXVehicleLastUpdateDate());
            metaDataMap.put("XVehicleLastUpdateTxId", getXVehicleLastUpdateTxId());
            metaDataMap.put("XVehicleLastUpdateUser", getXVehicleLastUpdateUser());
            bRequireMapRefresh = false;
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the control object on this business object.
     *
     * @see com.dwl.base.DWLCommon#setControl(DWLControl)
     * @generated
     */
    public void setControl(DWLControl newDWLControl) {
        super.setControl(newDWLControl);

        if (eObjXVehicle != null) {
            eObjXVehicle.setControl(newDWLControl);
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the entity object associated with this business object.
     *
     * @generated
     */
    public EObjXVehicle getEObjXVehicle() {
        bRequireMapRefresh = true;
        return eObjXVehicle;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the entity object associated with this business object.
     *
     * @param eObjXVehicle
     *            The eObjXVehicle to set.
     * @generated
     */
    public void setEObjXVehicle(EObjXVehicle eObjXVehicle) {
        bRequireMapRefresh = true;
        this.eObjXVehicle = eObjXVehicle;
        if (this.eObjXVehicle != null && this.eObjXVehicle.getControl() == null) {
            DWLControl control = this.getControl();
            if (control != null) {
                this.eObjXVehicle.setControl(control);
            }
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the vehiclepkId attribute.
     * 
     * @generated
     */
    public String getVehiclepkId (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXVehicle.getVehiclepkId());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the vehiclepkId attribute.
     * 
     * @param newVehiclepkId
     *     The new value of vehiclepkId.
     * @generated
     */
    public void setVehiclepkId( String newVehiclepkId ) throws Exception {
        metaDataMap.put("VehiclepkId", newVehiclepkId);

        if (newVehiclepkId == null || newVehiclepkId.equals("")) {
            newVehiclepkId = null;


        }
        eObjXVehicle.setVehiclepkId( DWLFunctionUtils.getLongFromString(newVehiclepkId) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the division attribute.
     * 
     * @generated
     */
    public String getDivision (){
   
        return eObjXVehicle.getDivision();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the division attribute.
     * 
     * @param newDivision
     *     The new value of division.
     * @generated
     */
    public void setDivision( String newDivision ) throws Exception {
        metaDataMap.put("Division", newDivision);

        if (newDivision == null || newDivision.equals("")) {
            newDivision = null;


        }
        eObjXVehicle.setDivision( newDivision );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the businessUnit attribute.
     * 
     * @generated
     */
    public String getBusinessUnit (){
   
        return eObjXVehicle.getBusinessUnit();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the businessUnit attribute.
     * 
     * @param newBusinessUnit
     *     The new value of businessUnit.
     * @generated
     */
    public void setBusinessUnit( String newBusinessUnit ) throws Exception {
        metaDataMap.put("BusinessUnit", newBusinessUnit);

        if (newBusinessUnit == null || newBusinessUnit.equals("")) {
            newBusinessUnit = null;


        }
        eObjXVehicle.setBusinessUnit( newBusinessUnit );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the activity attribute.
     * 
     * @generated
     */
    public String getActivity (){
   
        return eObjXVehicle.getActivity();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the activity attribute.
     * 
     * @param newActivity
     *     The new value of activity.
     * @generated
     */
    public void setActivity( String newActivity ) throws Exception {
        metaDataMap.put("Activity", newActivity);

        if (newActivity == null || newActivity.equals("")) {
            newActivity = null;


        }
        eObjXVehicle.setActivity( newActivity );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the typeClass attribute.
     * 
     * @generated
     */
    public String getTypeClass (){
   
        return eObjXVehicle.getTypeClass();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the typeClass attribute.
     * 
     * @param newTypeClass
     *     The new value of typeClass.
     * @generated
     */
    public void setTypeClass( String newTypeClass ) throws Exception {
        metaDataMap.put("TypeClass", newTypeClass);

        if (newTypeClass == null || newTypeClass.equals("")) {
            newTypeClass = null;


        }
        eObjXVehicle.setTypeClass( newTypeClass );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the bauRelhe attribute.
     * 
     * @generated
     */
    public String getBauRelhe (){
   
        return eObjXVehicle.getBauRelhe();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the bauRelhe attribute.
     * 
     * @param newBauRelhe
     *     The new value of bauRelhe.
     * @generated
     */
    public void setBauRelhe( String newBauRelhe ) throws Exception {
        metaDataMap.put("BauRelhe", newBauRelhe);

        if (newBauRelhe == null || newBauRelhe.equals("")) {
            newBauRelhe = null;


        }
        eObjXVehicle.setBauRelhe( newBauRelhe );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the bauMuster attribute.
     * 
     * @generated
     */
    public String getBauMuster (){
   
        return eObjXVehicle.getBauMuster();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the bauMuster attribute.
     * 
     * @param newBauMuster
     *     The new value of bauMuster.
     * @generated
     */
    public void setBauMuster( String newBauMuster ) throws Exception {
        metaDataMap.put("BauMuster", newBauMuster);

        if (newBauMuster == null || newBauMuster.equals("")) {
            newBauMuster = null;


        }
        eObjXVehicle.setBauMuster( newBauMuster );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the subMuster attribute.
     * 
     * @generated
     */
    public String getSubMuster (){
   
        return eObjXVehicle.getSubMuster();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the subMuster attribute.
     * 
     * @param newSubMuster
     *     The new value of subMuster.
     * @generated
     */
    public void setSubMuster( String newSubMuster ) throws Exception {
        metaDataMap.put("SubMuster", newSubMuster);

        if (newSubMuster == null || newSubMuster.equals("")) {
            newSubMuster = null;


        }
        eObjXVehicle.setSubMuster( newSubMuster );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the engineNumber attribute.
     * 
     * @generated
     */
    public String getEngineNumber (){
   
        return eObjXVehicle.getEngineNumber();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the engineNumber attribute.
     * 
     * @param newEngineNumber
     *     The new value of engineNumber.
     * @generated
     */
    public void setEngineNumber( String newEngineNumber ) throws Exception {
        metaDataMap.put("EngineNumber", newEngineNumber);

        if (newEngineNumber == null || newEngineNumber.equals("")) {
            newEngineNumber = null;


        }
        eObjXVehicle.setEngineNumber( newEngineNumber );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the countryType attribute.
     * 
     * @generated
     */
    public String getCountryType (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXVehicle.getCountry());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the countryType attribute.
     * 
     * @param newCountryType
     *     The new value of countryType.
     * @generated
     */
    public void setCountryType( String newCountryType ) throws Exception {
        metaDataMap.put("CountryType", newCountryType);

        if (newCountryType == null || newCountryType.equals("")) {
            newCountryType = null;


        }
        eObjXVehicle.setCountry( DWLFunctionUtils.getLongFromString(newCountryType) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the countryValue attribute.
     * 
     * @generated
     */
    public String getCountryValue (){
      return countryValue;
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the countryValue attribute.
     * 
     * @param newCountryValue
     *     The new value of countryValue.
     * @generated
     */
    public void setCountryValue( String newCountryValue ) throws Exception {
        metaDataMap.put("CountryValue", newCountryValue);

        if (newCountryValue == null || newCountryValue.equals("")) {
            newCountryValue = null;


        }
        countryValue = newCountryValue;
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the color attribute.
     * 
     * @generated
     */
    public String getColor (){
   
        return eObjXVehicle.getColor();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the color attribute.
     * 
     * @param newColor
     *     The new value of color.
     * @generated
     */
    public void setColor( String newColor ) throws Exception {
        metaDataMap.put("Color", newColor);

        if (newColor == null || newColor.equals("")) {
            newColor = null;


        }
        eObjXVehicle.setColor( newColor );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the trim attribute.
     * 
     * @generated
     */
    public String getTrim (){
   
        return eObjXVehicle.getTrim();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the trim attribute.
     * 
     * @param newTrim
     *     The new value of trim.
     * @generated
     */
    public void setTrim( String newTrim ) throws Exception {
        metaDataMap.put("Trim", newTrim);

        if (newTrim == null || newTrim.equals("")) {
            newTrim = null;


        }
        eObjXVehicle.setTrim( newTrim );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the globalVIN attribute.
     * 
     * @generated
     */
    public String getGlobalVIN (){
   
        return eObjXVehicle.getGlobalVIN();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the globalVIN attribute.
     * 
     * @param newGlobalVIN
     *     The new value of globalVIN.
     * @generated
     */
    public void setGlobalVIN( String newGlobalVIN ) throws Exception {
        metaDataMap.put("GlobalVIN", newGlobalVIN);

        if (newGlobalVIN == null || newGlobalVIN.equals("")) {
            newGlobalVIN = null;


        }
        eObjXVehicle.setGlobalVIN( newGlobalVIN );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the localVIN attribute.
     * 
     * @generated
     */
    public String getLocalVIN (){
   
        return eObjXVehicle.getLocalVIN();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the localVIN attribute.
     * 
     * @param newLocalVIN
     *     The new value of localVIN.
     * @generated
     */
    public void setLocalVIN( String newLocalVIN ) throws Exception {
        metaDataMap.put("LocalVIN", newLocalVIN);

        if (newLocalVIN == null || newLocalVIN.equals("")) {
            newLocalVIN = null;


        }
        eObjXVehicle.setLocalVIN( newLocalVIN );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the licensePlate attribute.
     * 
     * @generated
     */
    public String getLicensePlate (){
   
        return eObjXVehicle.getLicensePlate();
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the licensePlate attribute.
     * 
     * @param newLicensePlate
     *     The new value of licensePlate.
     * @generated
     */
    public void setLicensePlate( String newLicensePlate ) throws Exception {
        metaDataMap.put("LicensePlate", newLicensePlate);

        if (newLicensePlate == null || newLicensePlate.equals("")) {
            newLicensePlate = null;


        }
        eObjXVehicle.setLicensePlate( newLicensePlate );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the sourceIdentifierType attribute.
     * 
     * @generated
     */
    public String getSourceIdentifierType (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXVehicle.getSourceIdentifier());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the sourceIdentifierType attribute.
     * 
     * @param newSourceIdentifierType
     *     The new value of sourceIdentifierType.
     * @generated
     */
    public void setSourceIdentifierType( String newSourceIdentifierType ) throws Exception {
        metaDataMap.put("SourceIdentifierType", newSourceIdentifierType);

        if (newSourceIdentifierType == null || newSourceIdentifierType.equals("")) {
            newSourceIdentifierType = null;


        }
        eObjXVehicle.setSourceIdentifier( DWLFunctionUtils.getLongFromString(newSourceIdentifierType) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the sourceIdentifierValue attribute.
     * 
     * @generated
     */
    public String getSourceIdentifierValue (){
      return sourceIdentifierValue;
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the sourceIdentifierValue attribute.
     * 
     * @param newSourceIdentifierValue
     *     The new value of sourceIdentifierValue.
     * @generated
     */
    public void setSourceIdentifierValue( String newSourceIdentifierValue ) throws Exception {
        metaDataMap.put("SourceIdentifierValue", newSourceIdentifierValue);

        if (newSourceIdentifierValue == null || newSourceIdentifierValue.equals("")) {
            newSourceIdentifierValue = null;


        }
        sourceIdentifierValue = newSourceIdentifierValue;
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the lastModifiedSystemDate attribute.
     * 
     * @generated
     */
    public String getLastModifiedSystemDate (){
   
        return DWLFunctionUtils.getStringFromTimestamp(eObjXVehicle.getLastModifiedSystemDate());
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the lastModifiedSystemDate attribute.
     * 
     * @param newLastModifiedSystemDate
     *     The new value of lastModifiedSystemDate.
     * @generated
     */
    public void setLastModifiedSystemDate( String newLastModifiedSystemDate ) throws Exception {
        metaDataMap.put("LastModifiedSystemDate", newLastModifiedSystemDate);
       	isValidLastModifiedSystemDate = true;

        if (newLastModifiedSystemDate == null || newLastModifiedSystemDate.equals("")) {
            newLastModifiedSystemDate = null;
            eObjXVehicle.setLastModifiedSystemDate(null);


        }
    else {
        	if (DateValidator.validates(newLastModifiedSystemDate)) {
           		eObjXVehicle.setLastModifiedSystemDate(DateFormatter.getStartDateTimestamp(newLastModifiedSystemDate));
            	metaDataMap.put("LastModifiedSystemDate", getLastModifiedSystemDate());
        	} else {
            	if (Configuration.getConfiguration().getConfigItem(
              "/IBM/DWLCommonServices/InternalValidation/enabled").getBooleanValue()) {
                	if (metaDataMap.get("LastModifiedSystemDate") != null) {
                    	metaDataMap.put("LastModifiedSystemDate", "");
                	}
                	isValidLastModifiedSystemDate = false;
                	eObjXVehicle.setLastModifiedSystemDate(null);
            	}
        	}
        }
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the createDate attribute.
     * 
     * @generated
     */
    public String getCreateDate (){
   
        return DWLFunctionUtils.getStringFromTimestamp(eObjXVehicle.getCreateDate());
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the createDate attribute.
     * 
     * @param newCreateDate
     *     The new value of createDate.
     * @generated
     */
    public void setCreateDate( String newCreateDate ) throws Exception {
        metaDataMap.put("CreateDate", newCreateDate);
       	isValidCreateDate = true;

        if (newCreateDate == null || newCreateDate.equals("")) {
            newCreateDate = null;
            eObjXVehicle.setCreateDate(null);


        }
    else {
        	if (DateValidator.validates(newCreateDate)) {
           		eObjXVehicle.setCreateDate(DateFormatter.getStartDateTimestamp(newCreateDate));
            	metaDataMap.put("CreateDate", getCreateDate());
        	} else {
            	if (Configuration.getConfiguration().getConfigItem(
              "/IBM/DWLCommonServices/InternalValidation/enabled").getBooleanValue()) {
                	if (metaDataMap.get("CreateDate") != null) {
                    	metaDataMap.put("CreateDate", "");
                	}
                	isValidCreateDate = false;
                	eObjXVehicle.setCreateDate(null);
            	}
        	}
        }
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the changedDate attribute.
     * 
     * @generated
     */
    public String getChangedDate (){
   
        return DWLFunctionUtils.getStringFromTimestamp(eObjXVehicle.getChangedDate());
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the changedDate attribute.
     * 
     * @param newChangedDate
     *     The new value of changedDate.
     * @generated
     */
    public void setChangedDate( String newChangedDate ) throws Exception {
        metaDataMap.put("ChangedDate", newChangedDate);
       	isValidChangedDate = true;

        if (newChangedDate == null || newChangedDate.equals("")) {
            newChangedDate = null;
            eObjXVehicle.setChangedDate(null);


        }
    else {
        	if (DateValidator.validates(newChangedDate)) {
           		eObjXVehicle.setChangedDate(DateFormatter.getStartDateTimestamp(newChangedDate));
            	metaDataMap.put("ChangedDate", getChangedDate());
        	} else {
            	if (Configuration.getConfiguration().getConfigItem(
              "/IBM/DWLCommonServices/InternalValidation/enabled").getBooleanValue()) {
                	if (metaDataMap.get("ChangedDate") != null) {
                    	metaDataMap.put("ChangedDate", "");
                	}
                	isValidChangedDate = false;
                	eObjXVehicle.setChangedDate(null);
            	}
        	}
        }
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the lastServiceDate attribute.
     * 
     * @generated
     */
    public String getLastServiceDate (){
   
        return DWLFunctionUtils.getStringFromTimestamp(eObjXVehicle.getLastServiceDate());
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the lastServiceDate attribute.
     * 
     * @param newLastServiceDate
     *     The new value of lastServiceDate.
     * @generated
     */
    public void setLastServiceDate( String newLastServiceDate ) throws Exception {
        metaDataMap.put("LastServiceDate", newLastServiceDate);
       	isValidLastServiceDate = true;

        if (newLastServiceDate == null || newLastServiceDate.equals("")) {
            newLastServiceDate = null;
            eObjXVehicle.setLastServiceDate(null);


        }
    else {
        	if (DateValidator.validates(newLastServiceDate)) {
           		eObjXVehicle.setLastServiceDate(DateFormatter.getStartDateTimestamp(newLastServiceDate));
            	metaDataMap.put("LastServiceDate", getLastServiceDate());
        	} else {
            	if (Configuration.getConfiguration().getConfigItem(
              "/IBM/DWLCommonServices/InternalValidation/enabled").getBooleanValue()) {
                	if (metaDataMap.get("LastServiceDate") != null) {
                    	metaDataMap.put("LastServiceDate", "");
                	}
                	isValidLastServiceDate = false;
                	eObjXVehicle.setLastServiceDate(null);
            	}
        	}
        }
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the marketName attribute.
     * 
     * @generated
     */
    public String getMarketName (){
   
        return eObjXVehicle.getMarketName();
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the marketName attribute.
     * 
     * @param newMarketName
     *     The new value of marketName.
     * @generated
     */
    public void setMarketName( String newMarketName ) throws Exception {
        metaDataMap.put("MarketName", newMarketName);

        if (newMarketName == null || newMarketName.equals("")) {
            newMarketName = null;


        }
        eObjXVehicle.setMarketName( newMarketName );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateTxId attribute.
     *
     * @generated
     */
    public String getXVehicleLastUpdateTxId() {
        return DWLFunctionUtils.getStringFromLong(eObjXVehicle.getLastUpdateTxId());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateUser attribute.
     *
     * @generated
     */
    public String getXVehicleLastUpdateUser() {
        return eObjXVehicle.getLastUpdateUser();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateDt attribute.
     *
     * @generated
     */
    public String getXVehicleLastUpdateDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXVehicle.getLastUpdateDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateTxId attribute.
     *
     * @param newLastUpdateTxId
     *     The new value of LastUpdateTxId.
     * @generated
     */
    public void setXVehicleLastUpdateTxId(String newLastUpdateTxId) {
        metaDataMap.put("XVehicleLastUpdateTxId", newLastUpdateTxId);

        if ((newLastUpdateTxId == null) || newLastUpdateTxId.equals("")) {
            newLastUpdateTxId = null;
        }
        eObjXVehicle.setLastUpdateTxId(DWLFunctionUtils.getLongFromString(newLastUpdateTxId));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateUser attribute.
     *
     * @param newLastUpdateUser
     *     The new value of LastUpdateUser.
     * @generated
     */
    public void setXVehicleLastUpdateUser(String newLastUpdateUser) {
        metaDataMap.put("XVehicleLastUpdateUser", newLastUpdateUser);

        if ((newLastUpdateUser == null) || newLastUpdateUser.equals("")) {
            newLastUpdateUser = null;
        }
        eObjXVehicle.setLastUpdateUser(newLastUpdateUser);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateDt attribute.
     *
     * @param newLastUpdateDt
     *     The new value of LastUpdateDt.
     * @throws Exception
     * @generated
     */
    public void setXVehicleLastUpdateDate(String newLastUpdateDt) throws Exception {
        metaDataMap.put("XVehicleLastUpdateDate", newLastUpdateDt);

        if ((newLastUpdateDt == null) || newLastUpdateDt.equals("")) {
            newLastUpdateDt = null;
        }

        eObjXVehicle.setLastUpdateDt(DWLFunctionUtils.getTimestampFromTimestampString(newLastUpdateDt));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XVehicleHistActionCode history attribute.
     *
     * @generated
     */
    public String getXVehicleHistActionCode() {
        return eObjXVehicle.getHistActionCode();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XVehicleHistActionCode history attribute.
     *
     * @param aXVehicleHistActionCode
     *     The new value of XVehicleHistActionCode.
     * @generated
     */
    public void setXVehicleHistActionCode(String aXVehicleHistActionCode) {
        metaDataMap.put("XVehicleHistActionCode", aXVehicleHistActionCode);

        if ((aXVehicleHistActionCode == null) || aXVehicleHistActionCode.equals("")) {
            aXVehicleHistActionCode = null;
        }
        eObjXVehicle.setHistActionCode(aXVehicleHistActionCode);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XVehicleHistCreateDate history attribute.
     *
     * @generated
     */
    public String getXVehicleHistCreateDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXVehicle.getHistCreateDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XVehicleHistCreateDate history attribute.
     *
     * @param aXVehicleHistCreateDate
     *     The new value of XVehicleHistCreateDate.
     * @generated
     */
    public void setXVehicleHistCreateDate(String aXVehicleHistCreateDate) throws Exception{
        metaDataMap.put("XVehicleHistCreateDate", aXVehicleHistCreateDate);

        if ((aXVehicleHistCreateDate == null) || aXVehicleHistCreateDate.equals("")) {
            aXVehicleHistCreateDate = null;
        }

        eObjXVehicle.setHistCreateDt(DWLFunctionUtils.getTimestampFromTimestampString(aXVehicleHistCreateDate));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XVehicleHistCreatedBy history attribute.
     *
     * @generated
     */
    public String getXVehicleHistCreatedBy() {
        return eObjXVehicle.getHistCreatedBy();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XVehicleHistCreatedBy history attribute.
     *
     * @param aXVehicleHistCreatedBy
     *     The new value of XVehicleHistCreatedBy.
     * @generated
     */
    public void setXVehicleHistCreatedBy(String aXVehicleHistCreatedBy) {
        metaDataMap.put("XVehicleHistCreatedBy", aXVehicleHistCreatedBy);

        if ((aXVehicleHistCreatedBy == null) || aXVehicleHistCreatedBy.equals("")) {
            aXVehicleHistCreatedBy = null;
        }

        eObjXVehicle.setHistCreatedBy(aXVehicleHistCreatedBy);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XVehicleHistEndDate history attribute.
     *
     * @generated
     */
    public String getXVehicleHistEndDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXVehicle.getHistEndDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XVehicleHistEndDate history attribute.
     *
     * @param aXVehicleHistEndDate
     *     The new value of XVehicleHistEndDate.
     * @generated
     */
    public void setXVehicleHistEndDate(String aXVehicleHistEndDate) throws Exception{
        metaDataMap.put("XVehicleHistEndDate", aXVehicleHistEndDate);

        if ((aXVehicleHistEndDate == null) || aXVehicleHistEndDate.equals("")) {
            aXVehicleHistEndDate = null;
        }
        eObjXVehicle.setHistEndDt(DWLFunctionUtils.getTimestampFromTimestampString(aXVehicleHistEndDate));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XVehicleHistoryIdPK history attribute.
     *
     * @generated
     */
    public String getXVehicleHistoryIdPK() {
        return DWLFunctionUtils.getStringFromLong(eObjXVehicle.getHistoryIdPK());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XVehicleHistoryIdPK history attribute.
     *
     * @param aXVehicleHistoryIdPK
     *     The new value of XVehicleHistoryIdPK.
     * @generated
     */
    public void setXVehicleHistoryIdPK(String aXVehicleHistoryIdPK) {
        metaDataMap.put("XVehicleHistoryIdPK", aXVehicleHistoryIdPK);

        if ((aXVehicleHistoryIdPK == null) || aXVehicleHistoryIdPK.equals("")) {
            aXVehicleHistoryIdPK = null;
        }
        eObjXVehicle.setHistoryIdPK(DWLFunctionUtils.getLongFromString(aXVehicleHistoryIdPK));
    }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation during an add transaction.
     *
     * @generated
     */
    public DWLStatus validateAdd(int level, DWLStatus status) throws Exception {

        status = super.validateAdd(level, status);
        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0038I Add any controller-level custom validation logic to be
            // executed for this object during an "add" transaction

        }

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            // MDM_TODO0: CDKWB0039I Add any component-level custom validation logic to be
            // executed for this object during an "add" transaction
        }
        status = getValidationStatus(level, status);
        return status;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation during an update transaction.
     *
     * @generated
     */
    public DWLStatus validateUpdate(int level, DWLStatus status) throws Exception {
    logger.finest("ENTER validateUpdate(int level, DWLStatus status)");

        status = super.validateUpdate(level, status);
        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0040I Add any controller-level custom validation logic to be
            // executed for this object during an "update" transaction

            if (eObjXVehicle.getVehiclepkId() == null) {
                DWLError err = new DWLError();
                err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XVEHICLE_BOBJ).longValue());
                err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.XVEHICLE_VEHICLEPKID_NULL).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                	String infoForLogging="Error: Validation error occured for update. No primary key for entity XVehicle, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("validateUpdate(int level, DWLStatus status) " + infoForLogging);
                }
                status.addError(err);
            }
            if (eObjXVehicle.getLastUpdateDt() == null) {
                DWLError err = new DWLError();
                err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XVEHICLE_BOBJ).longValue());
                err.setReasonCode(new Long(DWLUtilErrorReasonCode.LAST_UPDATED_DATE_NULL).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
                if (logger.isFinestEnabled()) {
                	String infoForLogging="Error: Validation error occured for update. No last update date for entity XVehicle, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("validateUpdate(int level, DWLStatus status) " + infoForLogging);
                }
                status.addError(err);
            }
        }

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            assignBeforeImageValues(metaDataMap);
            
            // MDM_TODO0: CDKWB0041I Add any component-level custom validation logic to be
            // executed for this object during an "update" transaction
        }
        status = getValidationStatus(level, status);
    if (logger.isFinestEnabled()) {
        	String returnValue = status.toString();
      logger.finest("RETURN validateUpdate(int level, DWLStatus status) " + returnValue);
    }
        return status;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Populate the before image of this business object.
     *
     * @see com.dwl.base.DWLCommon#populateBeforeImage()
     * @generated
     */
    public void populateBeforeImage() throws DWLBaseException {
    logger.finest("ENTER populateBeforeImage()");

        DSEAAdditionsExts comp = null;
        try {
        
      comp = (DSEAAdditionsExts)TCRMClassFactory.getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
        	
        } catch (Exception e) {
      if (logger.isFinestEnabled()) {
        String infoForLogging="Error: Fatal error while updating record " + e.getMessage();
      logger.finest("populateBeforeImage() " + infoForLogging);
      }
            DWLExceptionUtils.throwDWLBaseException(e, 
            									new DWLUpdateException(e.getMessage()), 
            									this.getStatus(), DWLStatus.FATAL,
                                  DSEAAdditionsExtsComponentID.XVEHICLE_BOBJ, 
                                  "DIERR",
                                  DSEAAdditionsExtsErrorReasonCode.XVEHICLE_BEFORE_IMAGE_NOT_POPULATED, 
                                  this.getControl());
        }
        
        comp.loadBeforeImage(this);
    logger.finest("RETURN populateBeforeImage()");
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation common to both add and update transactions.
     *
     * @generated
     */
     
    private DWLStatus getValidationStatus(int level, DWLStatus status) throws Exception {
    logger.finest("ENTER getValidationStatus(int level, DWLStatus status)");

        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0034I Add any common controller-level custom validation
            // logic to be executed for this object during either "add" or
            // "update" transactions
    		controllerValidation_Country(status);
    		controllerValidation_SourceIdentifier(status);
    		controllerValidation_LastModifiedSystemDate(status);
    		controllerValidation_CreateDate(status);
    		controllerValidation_ChangedDate(status);
    		controllerValidation_LastServiceDate(status);
    	}

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            // MDM_TODO0: CDKWB0035I Add any common component-level custom validation logic
            // to be executed for this object during either "add" or "update"
            // transactions
    		componentValidation_Country(status);
    		componentValidation_SourceIdentifier(status);
    		componentValidation_LastModifiedSystemDate(status);
    		componentValidation_CreateDate(status);
    		componentValidation_ChangedDate(status);
    		componentValidation_LastServiceDate(status);
        }
        
        if (logger.isFinestEnabled()) {
            String returnValue = status.toString();
      logger.finest("RETURN getValidationStatus(int level, DWLStatus status) " + returnValue);
        }
    
        return status;
    }

    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "Country"
     *
     * @generated
     */
	private void componentValidation_Country(DWLStatus status) {
  
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "SourceIdentifier"
     *
     * @generated
     */
	private void componentValidation_SourceIdentifier(DWLStatus status) {
  
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "LastModifiedSystemDate"
     *
     * @generated
     */
  private void componentValidation_LastModifiedSystemDate(DWLStatus status) {
  
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "CreateDate"
     *
     * @generated
     */
  private void componentValidation_CreateDate(DWLStatus status) {
  
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "ChangedDate"
     *
     * @generated
     */
  private void componentValidation_ChangedDate(DWLStatus status) {
  
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "LastServiceDate"
     *
     * @generated
     */
  private void componentValidation_LastServiceDate(DWLStatus status) {
  
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "Country"
     *
     * @generated
     */
	private void controllerValidation_Country(DWLStatus status) throws Exception {
  
      //persistent code type
            boolean isCountryNull = false;
            if ((eObjXVehicle.getCountry() == null) &&
               ((getCountryValue() == null) || 
                 getCountryValue().trim().equals(""))) {
                isCountryNull = true;
            }
            if (!isCountryNull) {
                if (checkForInvalidXvehicleCountry()) {
                    DWLError err = new DWLError();
                    err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XVEHICLE_BOBJ).longValue());
                    err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XVEHICLE_COUNTRY).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                    String infoForLogging="Error: Custom validation error occured for entity XVehicle, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("controllerValidation_Country " + infoForLogging);
        }
                status.addError(err);
            }

             }
    			
    	}
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "SourceIdentifier"
     *
     * @generated
     */
	private void controllerValidation_SourceIdentifier(DWLStatus status) throws Exception {
  
      //persistent code type
            boolean isSourceIdentifierNull = false;
            if ((eObjXVehicle.getSourceIdentifier() == null) &&
               ((getSourceIdentifierValue() == null) || 
                 getSourceIdentifierValue().trim().equals(""))) {
                isSourceIdentifierNull = true;
            }
            if (!isSourceIdentifierNull) {
                if (checkForInvalidXvehicleSourceidentifier()) {
                    DWLError err = new DWLError();
                    err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XVEHICLE_BOBJ).longValue());
                    err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XVEHICLE_SOURCEIDENTIFIER).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                    String infoForLogging="Error: Custom validation error occured for entity XVehicle, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("controllerValidation_SourceIdentifier " + infoForLogging);
        }
                status.addError(err);
            }

             }
    			
    	}
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "LastModifiedSystemDate"
     *
     * @generated
     */
  private void controllerValidation_LastModifiedSystemDate(DWLStatus status) throws Exception {
  
            boolean isLastModifiedSystemDateNull = (eObjXVehicle.getLastModifiedSystemDate() == null);
            if (!isValidLastModifiedSystemDate) {
              	DWLError err = new DWLError();
               	err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XVEHICLE_BOBJ).longValue());
               	err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XVEHICLE_LASTMODIFIEDSYSTEMDATE).longValue());
               	err.setErrorType(DWLErrorCode.DATA_INVALID_ERROR);
                String infoForLogging="Error: Validation error. Invalid time specified on property LastModifiedSystemDate in entity XVehicle, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode();
      logger.finest("controllerValidation_LastModifiedSystemDate " + infoForLogging);
               	status.addError(err);
            } 
    	}


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "CreateDate"
     *
     * @generated
     */
  private void controllerValidation_CreateDate(DWLStatus status) throws Exception {
  
            boolean isCreateDateNull = (eObjXVehicle.getCreateDate() == null);
            if (!isValidCreateDate) {
              	DWLError err = new DWLError();
               	err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XVEHICLE_BOBJ).longValue());
               	err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XVEHICLE_CREATEDATE).longValue());
               	err.setErrorType(DWLErrorCode.DATA_INVALID_ERROR);
                String infoForLogging="Error: Validation error. Invalid time specified on property CreateDate in entity XVehicle, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode();
      logger.finest("controllerValidation_CreateDate " + infoForLogging);
               	status.addError(err);
            } 
    	}


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "ChangedDate"
     *
     * @generated
     */
  private void controllerValidation_ChangedDate(DWLStatus status) throws Exception {
  
            boolean isChangedDateNull = (eObjXVehicle.getChangedDate() == null);
            if (!isValidChangedDate) {
              	DWLError err = new DWLError();
               	err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XVEHICLE_BOBJ).longValue());
               	err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XVEHICLE_CHANGEDDATE).longValue());
               	err.setErrorType(DWLErrorCode.DATA_INVALID_ERROR);
                String infoForLogging="Error: Validation error. Invalid time specified on property ChangedDate in entity XVehicle, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode();
      logger.finest("controllerValidation_ChangedDate " + infoForLogging);
               	status.addError(err);
            } 
    	}


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "LastServiceDate"
     *
     * @generated
     */
  private void controllerValidation_LastServiceDate(DWLStatus status) throws Exception {
  
            boolean isLastServiceDateNull = (eObjXVehicle.getLastServiceDate() == null);
            if (!isValidLastServiceDate) {
              	DWLError err = new DWLError();
               	err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XVEHICLE_BOBJ).longValue());
               	err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XVEHICLE_LASTSERVICEDATE).longValue());
               	err.setErrorType(DWLErrorCode.DATA_INVALID_ERROR);
                String infoForLogging="Error: Validation error. Invalid time specified on property LastServiceDate in entity XVehicle, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode();
      logger.finest("controllerValidation_LastServiceDate " + infoForLogging);
               	status.addError(err);
            } 
    	}


    private DWLError createDWLError(String entityName, String propertyName,String reasonCode){	
		DWLError err = new DWLError();
		err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XVEHICLE_BOBJ).longValue());
		err.setReasonCode(new Long(reasonCode).longValue());
		err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
			String infoForLogging="Error: Validation error occured. Property " + propertyName + " is null, in entity " + entityName + ", component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
			logger.finest("createDWLError " + infoForLogging);
		}
		return err;
    }
    
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Check the value of the field Country and return true if the error reason
     * INVALID_XVEHICLE_COUNTRY should be returned.
     *
     * @generated
  **/
	private boolean checkForInvalidXvehicleCountry() throws Exception {
    logger.finest("ENTER checkForInvalidXvehicleCountry()");
        boolean notValid = false;
      	String langId = (String) this.getControl().get(DWLControlKeys.LANG_ID);
      	CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
    Long codeType = DWLFunctionUtils.getLongFromString( getCountryType() );
    String codeValue = getCountryValue();
    if( codeValue != null && codeValue.trim().equals("")){
      codeValue = null;
    }
     
        if ( codeType != null && codeValue == null ){

             if( codeTypeCompHelper.isCodeValid("cdcountrytp", langId, getCountryType(),
                 CodeTypeComponentHelper.ACTIVE, getControl())) {
                 CodeTypeBObj ctBObj = codeTypeCompHelper
                 					.getCodeTypeByCode("cdcountrytp", langId, getCountryType(),
                         								getControl());
               	if (ctBObj != null) {
                   	setCountryValue( ctBObj.getvalue() );
               	}
             }
             else{
             	if (logger.isFinestEnabled()) {
              	 	String infoForLogging="NotValid 1";
      logger.finest("checkForInvalidXvehicleCountry() " + infoForLogging);
        }
                 notValid = true;
           }
        }
        else if (codeType == null && codeValue != null ){
          
             CodeTypeBObj ctBObj = codeTypeCompHelper
                      .getCodeTypeByValue("cdcountrytp", langId, codeValue,
                                 getControl());

             if (ctBObj != null) {
                 setCountryType(ctBObj.gettp_cd());
             } 
             else {
             	if (logger.isFinestEnabled()) {
              	  	String infoForLogging="NotValid 2";
      logger.finest("checkForInvalidXvehicleCountry() " + infoForLogging);
        }
                  notValid = true;
             }
        }
        else if ( codeType != null && codeValue != null
             && !codeTypeCompHelper.isCodeValuePairValid("cdcountrytp", langId, getCountryType(), 
                     new String[] { codeValue }, CodeTypeComponentHelper.ACTIVE, getControl())) {	
       if (logger.isFinestEnabled()) {
       		String infoForLogging="NotValid 3";
      logger.finest("checkForInvalidXvehicleCountry() " + infoForLogging);
       }
             notValid = true;
        }
        if (logger.isFinestEnabled()) {
      String returnValue ="" +notValid;
      logger.finest("RETURN checkForInvalidXvehicleCountry() " + returnValue);
    }
    return notValid;
     } 
				 
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Check the value of the field SourceIdentifier and return true if the
     * error reason INVALID_XVEHICLE_SOURCEIDENTIFIER should be returned.
     *
     * @generated
  **/
	private boolean checkForInvalidXvehicleSourceidentifier() throws Exception {
    logger.finest("ENTER checkForInvalidXvehicleSourceidentifier()");
        boolean notValid = false;
      	String langId = (String) this.getControl().get(DWLControlKeys.LANG_ID);
      	CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
    Long codeType = DWLFunctionUtils.getLongFromString( getSourceIdentifierType() );
    String codeValue = getSourceIdentifierValue();
    if( codeValue != null && codeValue.trim().equals("")){
      codeValue = null;
    }
     
        if ( codeType != null && codeValue == null ){

             if( codeTypeCompHelper.isCodeValid("cdsourceidenttp", langId, getSourceIdentifierType(),
                 CodeTypeComponentHelper.ACTIVE, getControl())) {
                 CodeTypeBObj ctBObj = codeTypeCompHelper
                 					.getCodeTypeByCode("cdsourceidenttp", langId, getSourceIdentifierType(),
                         								getControl());
               	if (ctBObj != null) {
                   	setSourceIdentifierValue( ctBObj.getvalue() );
               	}
             }
             else{
             	if (logger.isFinestEnabled()) {
              	 	String infoForLogging="NotValid 1";
      logger.finest("checkForInvalidXvehicleSourceidentifier() " + infoForLogging);
        }
                 notValid = true;
           }
        }
        else if (codeType == null && codeValue != null ){
          
             CodeTypeBObj ctBObj = codeTypeCompHelper
                      .getCodeTypeByValue("cdsourceidenttp", langId, codeValue,
                                 getControl());

             if (ctBObj != null) {
                 setSourceIdentifierType(ctBObj.gettp_cd());
             } 
             else {
             	if (logger.isFinestEnabled()) {
              	  	String infoForLogging="NotValid 2";
      logger.finest("checkForInvalidXvehicleSourceidentifier() " + infoForLogging);
        }
                  notValid = true;
             }
        }
        else if ( codeType != null && codeValue != null
             && !codeTypeCompHelper.isCodeValuePairValid("cdsourceidenttp", langId, getSourceIdentifierType(), 
                     new String[] { codeValue }, CodeTypeComponentHelper.ACTIVE, getControl())) {	
       if (logger.isFinestEnabled()) {
       		String infoForLogging="NotValid 3";
      logger.finest("checkForInvalidXvehicleSourceidentifier() " + infoForLogging);
       }
             notValid = true;
        }
        if (logger.isFinestEnabled()) {
      String returnValue ="" +notValid;
      logger.finest("RETURN checkForInvalidXvehicleSourceidentifier() " + returnValue);
    }
    return notValid;
     } 
				 



}

