
/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[602a7eb38b8861fd8d3429248216583d]
 */

package com.ibm.daimler.dsea.component;

import com.dwl.tcrm.common.TCRMCommon;



import com.dwl.base.DWLControl;

import com.dwl.base.constant.DWLControlKeys;
import com.dwl.base.constant.DWLUtilErrorReasonCode;

import com.dwl.base.error.DWLError;
import com.dwl.base.error.DWLErrorCode;
import com.dwl.base.error.DWLStatus;

import com.dwl.base.exception.DWLBaseException;
import com.dwl.base.exception.DWLUpdateException;

import com.dwl.base.util.DWLClassFactory;
import com.dwl.base.util.DWLExceptionUtils;
import com.dwl.base.util.DWLFunctionUtils;

import com.dwl.management.config.client.Configuration;

import com.dwl.tcrm.common.ITCRMValidation;

import com.dwl.tcrm.utilities.DateFormatter;
import com.dwl.tcrm.utilities.DateValidator;
import com.dwl.tcrm.utilities.TCRMClassFactory;

import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsComponentID;
import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsErrorReasonCode;
import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsPropertyKeys;

import com.ibm.daimler.dsea.entityObject.EObjXPreference;

import com.ibm.daimler.dsea.interfaces.DSEAAdditionsExts;

import com.ibm.mdm.common.codetype.interfaces.CodeTypeComponentHelper;

import com.ibm.mdm.common.codetype.obj.CodeTypeBObj;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * This class provides the implementation of the business object
 * <code>XPreferenceBObj</code>.
 * 
 * @see com.dwl.tcrm.common.TCRMCommon
 * @generated
 */
 

@SuppressWarnings("serial")
public class XPreferenceBObj extends TCRMCommon  {

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected EObjXPreference eObjXPreference;
	/**
    * <!-- begin-user-doc -->
	  * <!-- end-user-doc -->
    * @generated 
    */
	 private final static com.dwl.base.logging.IDWLLogger logger = com.dwl.base.logging.DWLLoggerManager.getLogger(XPreferenceBObj.class);
		
 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected String preferredValue;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected String sourceIdentifierValue;
	protected boolean isValidStartDate = true;
	
	protected boolean isValidEndDate = true;
	


    protected boolean isValidLastModifiedSystemDate = true;



    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */     
    public XPreferenceBObj() {
        super();
        init();
        eObjXPreference = new EObjXPreference();
        setComponentID(DSEAAdditionsExtsComponentID.XPREFERENCE_BOBJ);
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Initializes the fields required to populate the metaDataMap. Each key is
     * an element-level field of the business object.
     *
     * @generated
     */
    private void init() {
        metaDataMap.put("PreferencepkId", null);
        metaDataMap.put("LocationGroupId", null);
        metaDataMap.put("PreferredType", null);
        metaDataMap.put("PreferredValue", null);
        metaDataMap.put("SourceIdentifierType", null);
        metaDataMap.put("SourceIdentifierValue", null);
        metaDataMap.put("StartDate", null);
        metaDataMap.put("EndDate", null);
        metaDataMap.put("LastModifiedSystemDate", null);
        metaDataMap.put("XPreferenceHistActionCode", null);
        metaDataMap.put("XPreferenceHistCreateDate", null);
        metaDataMap.put("XPreferenceHistCreatedBy", null);
        metaDataMap.put("XPreferenceHistEndDate", null);
        metaDataMap.put("XPreferenceHistoryIdPK", null);
        metaDataMap.put("XPreferenceLastUpdateDate", null);
        metaDataMap.put("XPreferenceLastUpdateTxId", null);
        metaDataMap.put("XPreferenceLastUpdateUser", null);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Refreshes all the attributes this business object supports.
     *
     * @see com.dwl.base.DWLCommon#refreshMap()
     * @generated
     */
    public void refreshMap() {

        if (bRequireMapRefresh) {
            super.refreshMap();
            metaDataMap.put("PreferencepkId", getPreferencepkId());
            metaDataMap.put("LocationGroupId", getLocationGroupId());
            metaDataMap.put("PreferredType", getPreferredType());
            metaDataMap.put("PreferredValue", getPreferredValue());
            metaDataMap.put("SourceIdentifierType", getSourceIdentifierType());
            metaDataMap.put("SourceIdentifierValue", getSourceIdentifierValue());
            metaDataMap.put("StartDate", getStartDate());
            metaDataMap.put("EndDate", getEndDate());
            metaDataMap.put("LastModifiedSystemDate", getLastModifiedSystemDate());
            metaDataMap.put("XPreferenceHistActionCode", getXPreferenceHistActionCode());
            metaDataMap.put("XPreferenceHistCreateDate", getXPreferenceHistCreateDate());
            metaDataMap.put("XPreferenceHistCreatedBy", getXPreferenceHistCreatedBy());
            metaDataMap.put("XPreferenceHistEndDate", getXPreferenceHistEndDate());
            metaDataMap.put("XPreferenceHistoryIdPK", getXPreferenceHistoryIdPK());
            metaDataMap.put("XPreferenceLastUpdateDate", getXPreferenceLastUpdateDate());
            metaDataMap.put("XPreferenceLastUpdateTxId", getXPreferenceLastUpdateTxId());
            metaDataMap.put("XPreferenceLastUpdateUser", getXPreferenceLastUpdateUser());
            bRequireMapRefresh = false;
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the control object on this business object.
     *
     * @see com.dwl.base.DWLCommon#setControl(DWLControl)
     * @generated
     */
    public void setControl(DWLControl newDWLControl) {
        super.setControl(newDWLControl);

        if (eObjXPreference != null) {
            eObjXPreference.setControl(newDWLControl);
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the entity object associated with this business object.
     *
     * @generated
     */
    public EObjXPreference getEObjXPreference() {
        bRequireMapRefresh = true;
        return eObjXPreference;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the entity object associated with this business object.
     *
     * @param eObjXPreference
     *            The eObjXPreference to set.
     * @generated
     */
    public void setEObjXPreference(EObjXPreference eObjXPreference) {
        bRequireMapRefresh = true;
        this.eObjXPreference = eObjXPreference;
        if (this.eObjXPreference != null && this.eObjXPreference.getControl() == null) {
            DWLControl control = this.getControl();
            if (control != null) {
                this.eObjXPreference.setControl(control);
            }
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the preferencepkId attribute.
     * 
     * @generated
     */
    public String getPreferencepkId (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXPreference.getPreferencepkId());
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the preferencepkId attribute.
     * 
     * @param newPreferencepkId
     *     The new value of preferencepkId.
     * @generated
     */
    public void setPreferencepkId( String newPreferencepkId ) throws Exception {
        metaDataMap.put("PreferencepkId", newPreferencepkId);

        if (newPreferencepkId == null || newPreferencepkId.equals("")) {
            newPreferencepkId = null;


        }
        eObjXPreference.setPreferencepkId( DWLFunctionUtils.getLongFromString(newPreferencepkId) );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the locationGroupId attribute.
     * 
     * @generated
     */
    public String getLocationGroupId (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXPreference.getLocationGroupId());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the locationGroupId attribute.
     * 
     * @param newLocationGroupId
     *     The new value of locationGroupId.
     * @generated
     */
    public void setLocationGroupId( String newLocationGroupId ) throws Exception {
        metaDataMap.put("LocationGroupId", newLocationGroupId);

        if (newLocationGroupId == null || newLocationGroupId.equals("")) {
            newLocationGroupId = null;


        }
        eObjXPreference.setLocationGroupId( DWLFunctionUtils.getLongFromString(newLocationGroupId) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the preferredType attribute.
     * 
     * @generated
     */
    public String getPreferredType (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXPreference.getPreferred());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the preferredType attribute.
     * 
     * @param newPreferredType
     *     The new value of preferredType.
     * @generated
     */
    public void setPreferredType( String newPreferredType ) throws Exception {
        metaDataMap.put("PreferredType", newPreferredType);

        if (newPreferredType == null || newPreferredType.equals("")) {
            newPreferredType = null;


        }
        eObjXPreference.setPreferred( DWLFunctionUtils.getLongFromString(newPreferredType) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the preferredValue attribute.
     * 
     * @generated
     */
    public String getPreferredValue (){
      return preferredValue;
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the preferredValue attribute.
     * 
     * @param newPreferredValue
     *     The new value of preferredValue.
     * @generated
     */
    public void setPreferredValue( String newPreferredValue ) throws Exception {
        metaDataMap.put("PreferredValue", newPreferredValue);

        if (newPreferredValue == null || newPreferredValue.equals("")) {
            newPreferredValue = null;


        }
        preferredValue = newPreferredValue;
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the sourceIdentifierType attribute.
     * 
     * @generated
     */
    public String getSourceIdentifierType (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXPreference.getSourceIdentifier());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the sourceIdentifierType attribute.
     * 
     * @param newSourceIdentifierType
     *     The new value of sourceIdentifierType.
     * @generated
     */
    public void setSourceIdentifierType( String newSourceIdentifierType ) throws Exception {
        metaDataMap.put("SourceIdentifierType", newSourceIdentifierType);

        if (newSourceIdentifierType == null || newSourceIdentifierType.equals("")) {
            newSourceIdentifierType = null;


        }
        eObjXPreference.setSourceIdentifier( DWLFunctionUtils.getLongFromString(newSourceIdentifierType) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the sourceIdentifierValue attribute.
     * 
     * @generated
     */
    public String getSourceIdentifierValue (){
      return sourceIdentifierValue;
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the sourceIdentifierValue attribute.
     * 
     * @param newSourceIdentifierValue
     *     The new value of sourceIdentifierValue.
     * @generated
     */
    public void setSourceIdentifierValue( String newSourceIdentifierValue ) throws Exception {
        metaDataMap.put("SourceIdentifierValue", newSourceIdentifierValue);

        if (newSourceIdentifierValue == null || newSourceIdentifierValue.equals("")) {
            newSourceIdentifierValue = null;


        }
        sourceIdentifierValue = newSourceIdentifierValue;
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the startDate attribute.
     * 
     * @generated
     */
    public String getStartDate (){
   
        return DWLFunctionUtils.getStringFromTimestamp(eObjXPreference.getStartDate());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the startDate attribute.
     * 
     * @param newStartDate
     *     The new value of startDate.
     * @generated
     */
    public void setStartDate( String newStartDate ) throws Exception {
        metaDataMap.put("StartDate", newStartDate);
       	isValidStartDate = true;

        if (newStartDate == null || newStartDate.equals("")) {
            newStartDate = null;
            eObjXPreference.setStartDate(null);


        }
    else {
        	if (DateValidator.validates(newStartDate)) {
           		eObjXPreference.setStartDate(DateFormatter.getStartDateTimestamp(newStartDate));
            	metaDataMap.put("StartDate", getStartDate());
        	} else {
            	if (Configuration.getConfiguration().getConfigItem(
              "/IBM/DWLCommonServices/InternalValidation/enabled").getBooleanValue()) {
                	if (metaDataMap.get("StartDate") != null) {
                    	metaDataMap.put("StartDate", "");
                	}
                	isValidStartDate = false;
                	eObjXPreference.setStartDate(null);
            	}
        	}
        }
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the endDate attribute.
     * 
     * @generated
     */
    public String getEndDate (){
   
        return DWLFunctionUtils.getStringFromTimestamp(eObjXPreference.getEndDate());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the endDate attribute.
     * 
     * @param newEndDate
     *     The new value of endDate.
     * @generated
     */
    public void setEndDate( String newEndDate ) throws Exception {
        metaDataMap.put("EndDate", newEndDate);
       	isValidEndDate = true;

        if (newEndDate == null || newEndDate.equals("")) {
            newEndDate = null;
            eObjXPreference.setEndDate(null);


        }
    else {
        	if (DateValidator.validates(newEndDate)) {
           		eObjXPreference.setEndDate(DateFormatter.getStartDateTimestamp(newEndDate));
            	metaDataMap.put("EndDate", getEndDate());
        	} else {
            	if (Configuration.getConfiguration().getConfigItem(
              "/IBM/DWLCommonServices/InternalValidation/enabled").getBooleanValue()) {
                	if (metaDataMap.get("EndDate") != null) {
                    	metaDataMap.put("EndDate", "");
                	}
                	isValidEndDate = false;
                	eObjXPreference.setEndDate(null);
            	}
        	}
        }
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the lastModifiedSystemDate attribute.
     * 
     * @generated
     */
    public String getLastModifiedSystemDate (){
   
        return DWLFunctionUtils.getStringFromTimestamp(eObjXPreference.getLastModifiedSystemDate());
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the lastModifiedSystemDate attribute.
     * 
     * @param newLastModifiedSystemDate
     *     The new value of lastModifiedSystemDate.
     * @generated
     */
    public void setLastModifiedSystemDate( String newLastModifiedSystemDate ) throws Exception {
        metaDataMap.put("LastModifiedSystemDate", newLastModifiedSystemDate);
       	isValidLastModifiedSystemDate = true;

        if (newLastModifiedSystemDate == null || newLastModifiedSystemDate.equals("")) {
            newLastModifiedSystemDate = null;
            eObjXPreference.setLastModifiedSystemDate(null);


        }
    else {
        	if (DateValidator.validates(newLastModifiedSystemDate)) {
           		eObjXPreference.setLastModifiedSystemDate(DateFormatter.getStartDateTimestamp(newLastModifiedSystemDate));
            	metaDataMap.put("LastModifiedSystemDate", getLastModifiedSystemDate());
        	} else {
            	if (Configuration.getConfiguration().getConfigItem(
              "/IBM/DWLCommonServices/InternalValidation/enabled").getBooleanValue()) {
                	if (metaDataMap.get("LastModifiedSystemDate") != null) {
                    	metaDataMap.put("LastModifiedSystemDate", "");
                	}
                	isValidLastModifiedSystemDate = false;
                	eObjXPreference.setLastModifiedSystemDate(null);
            	}
        	}
        }
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateTxId attribute.
     *
     * @generated
     */
    public String getXPreferenceLastUpdateTxId() {
        return DWLFunctionUtils.getStringFromLong(eObjXPreference.getLastUpdateTxId());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateUser attribute.
     *
     * @generated
     */
    public String getXPreferenceLastUpdateUser() {
        return eObjXPreference.getLastUpdateUser();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateDt attribute.
     *
     * @generated
     */
    public String getXPreferenceLastUpdateDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXPreference.getLastUpdateDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateTxId attribute.
     *
     * @param newLastUpdateTxId
     *     The new value of LastUpdateTxId.
     * @generated
     */
    public void setXPreferenceLastUpdateTxId(String newLastUpdateTxId) {
        metaDataMap.put("XPreferenceLastUpdateTxId", newLastUpdateTxId);

        if ((newLastUpdateTxId == null) || newLastUpdateTxId.equals("")) {
            newLastUpdateTxId = null;
        }
        eObjXPreference.setLastUpdateTxId(DWLFunctionUtils.getLongFromString(newLastUpdateTxId));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateUser attribute.
     *
     * @param newLastUpdateUser
     *     The new value of LastUpdateUser.
     * @generated
     */
    public void setXPreferenceLastUpdateUser(String newLastUpdateUser) {
        metaDataMap.put("XPreferenceLastUpdateUser", newLastUpdateUser);

        if ((newLastUpdateUser == null) || newLastUpdateUser.equals("")) {
            newLastUpdateUser = null;
        }
        eObjXPreference.setLastUpdateUser(newLastUpdateUser);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateDt attribute.
     *
     * @param newLastUpdateDt
     *     The new value of LastUpdateDt.
     * @throws Exception
     * @generated
     */
    public void setXPreferenceLastUpdateDate(String newLastUpdateDt) throws Exception {
        metaDataMap.put("XPreferenceLastUpdateDate", newLastUpdateDt);

        if ((newLastUpdateDt == null) || newLastUpdateDt.equals("")) {
            newLastUpdateDt = null;
        }

        eObjXPreference.setLastUpdateDt(DWLFunctionUtils.getTimestampFromTimestampString(newLastUpdateDt));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XPreferenceHistActionCode history attribute.
     *
     * @generated
     */
    public String getXPreferenceHistActionCode() {
        return eObjXPreference.getHistActionCode();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XPreferenceHistActionCode history attribute.
     *
     * @param aXPreferenceHistActionCode
     *     The new value of XPreferenceHistActionCode.
     * @generated
     */
    public void setXPreferenceHistActionCode(String aXPreferenceHistActionCode) {
        metaDataMap.put("XPreferenceHistActionCode", aXPreferenceHistActionCode);

        if ((aXPreferenceHistActionCode == null) || aXPreferenceHistActionCode.equals("")) {
            aXPreferenceHistActionCode = null;
        }
        eObjXPreference.setHistActionCode(aXPreferenceHistActionCode);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XPreferenceHistCreateDate history attribute.
     *
     * @generated
     */
    public String getXPreferenceHistCreateDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXPreference.getHistCreateDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XPreferenceHistCreateDate history attribute.
     *
     * @param aXPreferenceHistCreateDate
     *     The new value of XPreferenceHistCreateDate.
     * @generated
     */
    public void setXPreferenceHistCreateDate(String aXPreferenceHistCreateDate) throws Exception{
        metaDataMap.put("XPreferenceHistCreateDate", aXPreferenceHistCreateDate);

        if ((aXPreferenceHistCreateDate == null) || aXPreferenceHistCreateDate.equals("")) {
            aXPreferenceHistCreateDate = null;
        }

        eObjXPreference.setHistCreateDt(DWLFunctionUtils.getTimestampFromTimestampString(aXPreferenceHistCreateDate));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XPreferenceHistCreatedBy history attribute.
     *
     * @generated
     */
    public String getXPreferenceHistCreatedBy() {
        return eObjXPreference.getHistCreatedBy();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XPreferenceHistCreatedBy history attribute.
     *
     * @param aXPreferenceHistCreatedBy
     *     The new value of XPreferenceHistCreatedBy.
     * @generated
     */
    public void setXPreferenceHistCreatedBy(String aXPreferenceHistCreatedBy) {
        metaDataMap.put("XPreferenceHistCreatedBy", aXPreferenceHistCreatedBy);

        if ((aXPreferenceHistCreatedBy == null) || aXPreferenceHistCreatedBy.equals("")) {
            aXPreferenceHistCreatedBy = null;
        }

        eObjXPreference.setHistCreatedBy(aXPreferenceHistCreatedBy);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XPreferenceHistEndDate history attribute.
     *
     * @generated
     */
    public String getXPreferenceHistEndDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXPreference.getHistEndDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XPreferenceHistEndDate history attribute.
     *
     * @param aXPreferenceHistEndDate
     *     The new value of XPreferenceHistEndDate.
     * @generated
     */
    public void setXPreferenceHistEndDate(String aXPreferenceHistEndDate) throws Exception{
        metaDataMap.put("XPreferenceHistEndDate", aXPreferenceHistEndDate);

        if ((aXPreferenceHistEndDate == null) || aXPreferenceHistEndDate.equals("")) {
            aXPreferenceHistEndDate = null;
        }
        eObjXPreference.setHistEndDt(DWLFunctionUtils.getTimestampFromTimestampString(aXPreferenceHistEndDate));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XPreferenceHistoryIdPK history attribute.
     *
     * @generated
     */
    public String getXPreferenceHistoryIdPK() {
        return DWLFunctionUtils.getStringFromLong(eObjXPreference.getHistoryIdPK());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XPreferenceHistoryIdPK history attribute.
     *
     * @param aXPreferenceHistoryIdPK
     *     The new value of XPreferenceHistoryIdPK.
     * @generated
     */
    public void setXPreferenceHistoryIdPK(String aXPreferenceHistoryIdPK) {
        metaDataMap.put("XPreferenceHistoryIdPK", aXPreferenceHistoryIdPK);

        if ((aXPreferenceHistoryIdPK == null) || aXPreferenceHistoryIdPK.equals("")) {
            aXPreferenceHistoryIdPK = null;
        }
        eObjXPreference.setHistoryIdPK(DWLFunctionUtils.getLongFromString(aXPreferenceHistoryIdPK));
    }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation during an add transaction.
     *
     * @generated
     */
    public DWLStatus validateAdd(int level, DWLStatus status) throws Exception {

        status = super.validateAdd(level, status);
        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0038I Add any controller-level custom validation logic to be
            // executed for this object during an "add" transaction

        }

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            // MDM_TODO0: CDKWB0039I Add any component-level custom validation logic to be
            // executed for this object during an "add" transaction
        }
        status = getValidationStatus(level, status);
        return status;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation during an update transaction.
     *
     * @generated
     */
    public DWLStatus validateUpdate(int level, DWLStatus status) throws Exception {
    logger.finest("ENTER validateUpdate(int level, DWLStatus status)");

        status = super.validateUpdate(level, status);
        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0040I Add any controller-level custom validation logic to be
            // executed for this object during an "update" transaction

            if (eObjXPreference.getPreferencepkId() == null) {
                DWLError err = new DWLError();
                err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XPREFERENCE_BOBJ).longValue());
                err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.XPREFERENCE_PREFERENCEPKID_NULL).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                	String infoForLogging="Error: Validation error occured for update. No primary key for entity XPreference, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("validateUpdate(int level, DWLStatus status) " + infoForLogging);
                }
                status.addError(err);
            }
            if (eObjXPreference.getLastUpdateDt() == null) {
                DWLError err = new DWLError();
                err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XPREFERENCE_BOBJ).longValue());
                err.setReasonCode(new Long(DWLUtilErrorReasonCode.LAST_UPDATED_DATE_NULL).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
                if (logger.isFinestEnabled()) {
                	String infoForLogging="Error: Validation error occured for update. No last update date for entity XPreference, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("validateUpdate(int level, DWLStatus status) " + infoForLogging);
                }
                status.addError(err);
            }
        }

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            assignBeforeImageValues(metaDataMap);
            
            // MDM_TODO0: CDKWB0041I Add any component-level custom validation logic to be
            // executed for this object during an "update" transaction
        }
        status = getValidationStatus(level, status);
    if (logger.isFinestEnabled()) {
        	String returnValue = status.toString();
      logger.finest("RETURN validateUpdate(int level, DWLStatus status) " + returnValue);
    }
        return status;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Populate the before image of this business object.
     *
     * @see com.dwl.base.DWLCommon#populateBeforeImage()
     * @generated
     */
    public void populateBeforeImage() throws DWLBaseException {
    logger.finest("ENTER populateBeforeImage()");

        DSEAAdditionsExts comp = null;
        try {
        
      comp = (DSEAAdditionsExts)TCRMClassFactory.getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
        	
        } catch (Exception e) {
      if (logger.isFinestEnabled()) {
        String infoForLogging="Error: Fatal error while updating record " + e.getMessage();
      logger.finest("populateBeforeImage() " + infoForLogging);
      }
            DWLExceptionUtils.throwDWLBaseException(e, 
            									new DWLUpdateException(e.getMessage()), 
            									this.getStatus(), DWLStatus.FATAL,
                                  DSEAAdditionsExtsComponentID.XPREFERENCE_BOBJ, 
                                  "DIERR",
                                  DSEAAdditionsExtsErrorReasonCode.XPREFERENCE_BEFORE_IMAGE_NOT_POPULATED, 
                                  this.getControl());
        }
        
        comp.loadBeforeImage(this);
    logger.finest("RETURN populateBeforeImage()");
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation common to both add and update transactions.
     *
     * @generated
     */
     
    private DWLStatus getValidationStatus(int level, DWLStatus status) throws Exception {
    logger.finest("ENTER getValidationStatus(int level, DWLStatus status)");

        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0034I Add any common controller-level custom validation
            // logic to be executed for this object during either "add" or
            // "update" transactions
    		controllerValidation_LocationGroupId(status);
    		controllerValidation_Preferred(status);
    		controllerValidation_SourceIdentifier(status);
    		controllerValidation_StartDate(status);
    		controllerValidation_EndDate(status);
    		controllerValidation_LastModifiedSystemDate(status);
    	}

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            // MDM_TODO0: CDKWB0035I Add any common component-level custom validation logic
            // to be executed for this object during either "add" or "update"
            // transactions
    		componentValidation_LocationGroupId(status);
    		componentValidation_Preferred(status);
    		componentValidation_SourceIdentifier(status);
    		componentValidation_StartDate(status);
    		componentValidation_EndDate(status);
    		componentValidation_LastModifiedSystemDate(status);
        }
        
        if (logger.isFinestEnabled()) {
            String returnValue = status.toString();
      logger.finest("RETURN getValidationStatus(int level, DWLStatus status) " + returnValue);
        }
    
        return status;
    }

    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "LocationGroupId"
     *
     * @generated
     */
	private void componentValidation_LocationGroupId(DWLStatus status) {
  
            boolean isLocationGroupIdNull = (eObjXPreference.getLocationGroupId() == null);
            if (isLocationGroupIdNull) {
                DWLError err = createDWLError("XPreference", "LocationGroupId", DSEAAdditionsExtsErrorReasonCode.XPREFERENCE_LOCATIONGROUPID_NULL);
                status.addError(err); 
            }
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "Preferred"
     *
     * @generated
     */
	private void componentValidation_Preferred(DWLStatus status) {
  
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "SourceIdentifier"
     *
     * @generated
     */
	private void componentValidation_SourceIdentifier(DWLStatus status) {
  
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "StartDate"
     *
     * @generated
     */
	private void componentValidation_StartDate(DWLStatus status) {
  
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "EndDate"
     *
     * @generated
     */
	private void componentValidation_EndDate(DWLStatus status) {
  
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "LastModifiedSystemDate"
     *
     * @generated
     */
  private void componentValidation_LastModifiedSystemDate(DWLStatus status) {
  
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "LocationGroupId"
     *
     * @generated
     */
	private void controllerValidation_LocationGroupId(DWLStatus status) throws Exception {
  
            boolean isLocationGroupIdNull = (eObjXPreference.getLocationGroupId() == null);
            if (isLocationGroupIdNull) {
                DWLError err = createDWLError("XPreference", "LocationGroupId", DSEAAdditionsExtsErrorReasonCode.XPREFERENCE_LOCATIONGROUPID_NULL);
                status.addError(err); 
            }
    	}
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "Preferred"
     *
     * @generated
     */
	private void controllerValidation_Preferred(DWLStatus status) throws Exception {
  
      //persistent code type
            boolean isPreferredNull = false;
            if ((eObjXPreference.getPreferred() == null) &&
               ((getPreferredValue() == null) || 
                 getPreferredValue().trim().equals(""))) {
                isPreferredNull = true;
            }
            if (!isPreferredNull) {
                if (checkForInvalidXpreferencePreferred()) {
                    DWLError err = new DWLError();
                    err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XPREFERENCE_BOBJ).longValue());
                    err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XPREFERENCE_PREFERRED).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                    String infoForLogging="Error: Custom validation error occured for entity XPreference, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("controllerValidation_Preferred " + infoForLogging);
        }
                status.addError(err);
            }

             }
    			
    	}
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "SourceIdentifier"
     *
     * @generated
     */
	private void controllerValidation_SourceIdentifier(DWLStatus status) throws Exception {
  
      //persistent code type
            boolean isSourceIdentifierNull = false;
            if ((eObjXPreference.getSourceIdentifier() == null) &&
               ((getSourceIdentifierValue() == null) || 
                 getSourceIdentifierValue().trim().equals(""))) {
                isSourceIdentifierNull = true;
            }
            if (!isSourceIdentifierNull) {
                if (checkForInvalidXpreferenceSourceidentifier()) {
                    DWLError err = new DWLError();
                    err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XPREFERENCE_BOBJ).longValue());
                    err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XPREFERENCE_SOURCEIDENTIFIER).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                    String infoForLogging="Error: Custom validation error occured for entity XPreference, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("controllerValidation_SourceIdentifier " + infoForLogging);
        }
                status.addError(err);
            }

             }
    			
    	}
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "StartDate"
     *
     * @generated
     */
	private void controllerValidation_StartDate(DWLStatus status) throws Exception {
  
            boolean isStartDateNull = (eObjXPreference.getStartDate() == null);
            if (!isValidStartDate) {
              	DWLError err = new DWLError();
               	err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XPREFERENCE_BOBJ).longValue());
               	err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XPREFERENCE_STARTDATE).longValue());
               	err.setErrorType(DWLErrorCode.DATA_INVALID_ERROR);
                String infoForLogging="Error: Validation error. Invalid time specified on property StartDate in entity XPreference, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode();
      logger.finest("controllerValidation_StartDate " + infoForLogging);
               	status.addError(err);
            } 
    	}
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "EndDate"
     *
     * @generated
     */
	private void controllerValidation_EndDate(DWLStatus status) throws Exception {
  
            boolean isEndDateNull = (eObjXPreference.getEndDate() == null);
            if (!isValidEndDate) {
              	DWLError err = new DWLError();
               	err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XPREFERENCE_BOBJ).longValue());
               	err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XPREFERENCE_ENDDATE).longValue());
               	err.setErrorType(DWLErrorCode.DATA_INVALID_ERROR);
                String infoForLogging="Error: Validation error. Invalid time specified on property EndDate in entity XPreference, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode();
      logger.finest("controllerValidation_EndDate " + infoForLogging);
               	status.addError(err);
            } 
    	}
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "LastModifiedSystemDate"
     *
     * @generated
     */
  private void controllerValidation_LastModifiedSystemDate(DWLStatus status) throws Exception {
  
            boolean isLastModifiedSystemDateNull = (eObjXPreference.getLastModifiedSystemDate() == null);
            if (!isValidLastModifiedSystemDate) {
              	DWLError err = new DWLError();
               	err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XPREFERENCE_BOBJ).longValue());
               	err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XPREFERENCE_LASTMODIFIEDSYSTEMDATE).longValue());
               	err.setErrorType(DWLErrorCode.DATA_INVALID_ERROR);
                String infoForLogging="Error: Validation error. Invalid time specified on property LastModifiedSystemDate in entity XPreference, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode();
      logger.finest("controllerValidation_LastModifiedSystemDate " + infoForLogging);
               	status.addError(err);
            } 
    	}


    private DWLError createDWLError(String entityName, String propertyName,String reasonCode){	
		DWLError err = new DWLError();
		err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XPREFERENCE_BOBJ).longValue());
		err.setReasonCode(new Long(reasonCode).longValue());
		err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
			String infoForLogging="Error: Validation error occured. Property " + propertyName + " is null, in entity " + entityName + ", component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
			logger.finest("createDWLError " + infoForLogging);
		}
		return err;
    }
    
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Check the value of the field Preferred and return true if the error
     * reason INVALID_XPREFERENCE_PREFERRED should be returned.
     *
     * @generated
  **/
	private boolean checkForInvalidXpreferencePreferred() throws Exception {
    logger.finest("ENTER checkForInvalidXpreferencePreferred()");
        boolean notValid = false;
      	String langId = (String) this.getControl().get(DWLControlKeys.LANG_ID);
      	CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
    Long codeType = DWLFunctionUtils.getLongFromString( getPreferredType() );
    String codeValue = getPreferredValue();
    if( codeValue != null && codeValue.trim().equals("")){
      codeValue = null;
    }
     
        if ( codeType != null && codeValue == null ){

             if( codeTypeCompHelper.isCodeValid("xcdpreferencetp", langId, getPreferredType(),
                 CodeTypeComponentHelper.ACTIVE, getControl())) {
                 CodeTypeBObj ctBObj = codeTypeCompHelper
                 					.getCodeTypeByCode("xcdpreferencetp", langId, getPreferredType(),
                         								getControl());
               	if (ctBObj != null) {
                   	setPreferredValue( ctBObj.getvalue() );
               	}
             }
             else{
             	if (logger.isFinestEnabled()) {
              	 	String infoForLogging="NotValid 1";
      logger.finest("checkForInvalidXpreferencePreferred() " + infoForLogging);
        }
                 notValid = true;
           }
        }
        else if (codeType == null && codeValue != null ){
          
             CodeTypeBObj ctBObj = codeTypeCompHelper
                      .getCodeTypeByValue("xcdpreferencetp", langId, codeValue,
                                 getControl());

             if (ctBObj != null) {
                 setPreferredType(ctBObj.gettp_cd());
             } 
             else {
             	if (logger.isFinestEnabled()) {
              	  	String infoForLogging="NotValid 2";
      logger.finest("checkForInvalidXpreferencePreferred() " + infoForLogging);
        }
                  notValid = true;
             }
        }
        else if ( codeType != null && codeValue != null
             && !codeTypeCompHelper.isCodeValuePairValid("xcdpreferencetp", langId, getPreferredType(), 
                     new String[] { codeValue }, CodeTypeComponentHelper.ACTIVE, getControl())) {	
       if (logger.isFinestEnabled()) {
       		String infoForLogging="NotValid 3";
      logger.finest("checkForInvalidXpreferencePreferred() " + infoForLogging);
       }
             notValid = true;
        }
        if (logger.isFinestEnabled()) {
      String returnValue ="" +notValid;
      logger.finest("RETURN checkForInvalidXpreferencePreferred() " + returnValue);
    }
    return notValid;
     } 
				 
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Check the value of the field SourceIdentifier and return true if the
     * error reason INVALID_XPREFERENCE_SOURCEIDENTIFIER should be returned.
     *
     * @generated
  **/
	private boolean checkForInvalidXpreferenceSourceidentifier() throws Exception {
    logger.finest("ENTER checkForInvalidXpreferenceSourceidentifier()");
        boolean notValid = false;
      	String langId = (String) this.getControl().get(DWLControlKeys.LANG_ID);
      	CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
    Long codeType = DWLFunctionUtils.getLongFromString( getSourceIdentifierType() );
    String codeValue = getSourceIdentifierValue();
    if( codeValue != null && codeValue.trim().equals("")){
      codeValue = null;
    }
     
        if ( codeType != null && codeValue == null ){

             if( codeTypeCompHelper.isCodeValid("cdsourceidenttp", langId, getSourceIdentifierType(),
                 CodeTypeComponentHelper.ACTIVE, getControl())) {
                 CodeTypeBObj ctBObj = codeTypeCompHelper
                 					.getCodeTypeByCode("cdsourceidenttp", langId, getSourceIdentifierType(),
                         								getControl());
               	if (ctBObj != null) {
                   	setSourceIdentifierValue( ctBObj.getvalue() );
               	}
             }
             else{
             	if (logger.isFinestEnabled()) {
              	 	String infoForLogging="NotValid 1";
      logger.finest("checkForInvalidXpreferenceSourceidentifier() " + infoForLogging);
        }
                 notValid = true;
           }
        }
        else if (codeType == null && codeValue != null ){
          
             CodeTypeBObj ctBObj = codeTypeCompHelper
                      .getCodeTypeByValue("cdsourceidenttp", langId, codeValue,
                                 getControl());

             if (ctBObj != null) {
                 setSourceIdentifierType(ctBObj.gettp_cd());
             } 
             else {
             	if (logger.isFinestEnabled()) {
              	  	String infoForLogging="NotValid 2";
      logger.finest("checkForInvalidXpreferenceSourceidentifier() " + infoForLogging);
        }
                  notValid = true;
             }
        }
        else if ( codeType != null && codeValue != null
             && !codeTypeCompHelper.isCodeValuePairValid("cdsourceidenttp", langId, getSourceIdentifierType(), 
                     new String[] { codeValue }, CodeTypeComponentHelper.ACTIVE, getControl())) {	
       if (logger.isFinestEnabled()) {
       		String infoForLogging="NotValid 3";
      logger.finest("checkForInvalidXpreferenceSourceidentifier() " + infoForLogging);
       }
             notValid = true;
        }
        if (logger.isFinestEnabled()) {
      String returnValue ="" +notValid;
      logger.finest("RETURN checkForInvalidXpreferenceSourceidentifier() " + returnValue);
    }
    return notValid;
     } 
				 



}

