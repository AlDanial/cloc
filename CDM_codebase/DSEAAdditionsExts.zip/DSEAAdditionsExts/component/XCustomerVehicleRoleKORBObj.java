
/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[3e5a01a8cf9e1e30636fee491259d32d]
 */

package com.ibm.daimler.dsea.component;

import com.dwl.tcrm.common.TCRMCommon;



import com.dwl.base.DWLControl;

import com.dwl.base.constant.DWLControlKeys;
import com.dwl.base.constant.DWLUtilErrorReasonCode;

import com.dwl.base.error.DWLError;
import com.dwl.base.error.DWLErrorCode;
import com.dwl.base.error.DWLStatus;

import com.dwl.base.exception.DWLBaseException;
import com.dwl.base.exception.DWLUpdateException;

import com.dwl.base.util.DWLClassFactory;
import com.dwl.base.util.DWLExceptionUtils;
import com.dwl.base.util.DWLFunctionUtils;

import com.dwl.management.config.client.Configuration;

import com.dwl.tcrm.common.ITCRMValidation;

import com.dwl.tcrm.utilities.DateFormatter;
import com.dwl.tcrm.utilities.DateValidator;
import com.dwl.tcrm.utilities.TCRMClassFactory;

import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsComponentID;
import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsErrorReasonCode;
import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsPropertyKeys;

import com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRoleKOR;

import com.ibm.daimler.dsea.interfaces.DSEAAdditionsExts;

import com.ibm.mdm.common.codetype.interfaces.CodeTypeComponentHelper;

import com.ibm.mdm.common.codetype.obj.CodeTypeBObj;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * This class provides the implementation of the business object
 * <code>XCustomerVehicleRoleKORBObj</code>.
 * 
 * @see com.dwl.tcrm.common.TCRMCommon
 * @generated
 */
 

@SuppressWarnings("serial")
public class XCustomerVehicleRoleKORBObj extends TCRMCommon  {

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected EObjXCustomerVehicleRoleKOR eObjXCustomerVehicleRoleKOR;
	/**
    * <!-- begin-user-doc -->
	  * <!-- end-user-doc -->
    * @generated 
    */
	 private final static com.dwl.base.logging.IDWLLogger logger = com.dwl.base.logging.DWLLoggerManager.getLogger(XCustomerVehicleRoleKORBObj.class);
		
 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected String vehicleRoleValue;
	protected boolean isValidStartDate = true;
	
	protected boolean isValidEndDate = true;
	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected String sourceIdentifierValue;
	protected boolean isValidChangedDate = true;
	


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */     
    public XCustomerVehicleRoleKORBObj() {
        super();
        init();
        eObjXCustomerVehicleRoleKOR = new EObjXCustomerVehicleRoleKOR();
        setComponentID(DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_ROLE_KORBOBJ);
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Initializes the fields required to populate the metaDataMap. Each key is
     * an element-level field of the business object.
     *
     * @generated
     */
    private void init() {
        metaDataMap.put("XCustomerVehicleRoleKORpkId", null);
        metaDataMap.put("CustomerVehicleId", null);
        metaDataMap.put("VehicleRoleType", null);
        metaDataMap.put("VehicleRoleValue", null);
        metaDataMap.put("StartDate", null);
        metaDataMap.put("EndDate", null);
        metaDataMap.put("SourceIdentifierType", null);
        metaDataMap.put("SourceIdentifierValue", null);
        metaDataMap.put("ChangedDate", null);
        metaDataMap.put("XCustomerVehicleRoleKORHistActionCode", null);
        metaDataMap.put("XCustomerVehicleRoleKORHistCreateDate", null);
        metaDataMap.put("XCustomerVehicleRoleKORHistCreatedBy", null);
        metaDataMap.put("XCustomerVehicleRoleKORHistEndDate", null);
        metaDataMap.put("XCustomerVehicleRoleKORHistoryIdPK", null);
        metaDataMap.put("XCustomerVehicleRoleKORLastUpdateDate", null);
        metaDataMap.put("XCustomerVehicleRoleKORLastUpdateTxId", null);
        metaDataMap.put("XCustomerVehicleRoleKORLastUpdateUser", null);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Refreshes all the attributes this business object supports.
     *
     * @see com.dwl.base.DWLCommon#refreshMap()
     * @generated
     */
    public void refreshMap() {

        if (bRequireMapRefresh) {
            super.refreshMap();
            metaDataMap.put("XCustomerVehicleRoleKORpkId", getXCustomerVehicleRoleKORpkId());
            metaDataMap.put("CustomerVehicleId", getCustomerVehicleId());
            metaDataMap.put("VehicleRoleType", getVehicleRoleType());
            metaDataMap.put("VehicleRoleValue", getVehicleRoleValue());
            metaDataMap.put("StartDate", getStartDate());
            metaDataMap.put("EndDate", getEndDate());
            metaDataMap.put("SourceIdentifierType", getSourceIdentifierType());
            metaDataMap.put("SourceIdentifierValue", getSourceIdentifierValue());
            metaDataMap.put("ChangedDate", getChangedDate());
            metaDataMap.put("XCustomerVehicleRoleKORHistActionCode", getXCustomerVehicleRoleKORHistActionCode());
            metaDataMap.put("XCustomerVehicleRoleKORHistCreateDate", getXCustomerVehicleRoleKORHistCreateDate());
            metaDataMap.put("XCustomerVehicleRoleKORHistCreatedBy", getXCustomerVehicleRoleKORHistCreatedBy());
            metaDataMap.put("XCustomerVehicleRoleKORHistEndDate", getXCustomerVehicleRoleKORHistEndDate());
            metaDataMap.put("XCustomerVehicleRoleKORHistoryIdPK", getXCustomerVehicleRoleKORHistoryIdPK());
            metaDataMap.put("XCustomerVehicleRoleKORLastUpdateDate", getXCustomerVehicleRoleKORLastUpdateDate());
            metaDataMap.put("XCustomerVehicleRoleKORLastUpdateTxId", getXCustomerVehicleRoleKORLastUpdateTxId());
            metaDataMap.put("XCustomerVehicleRoleKORLastUpdateUser", getXCustomerVehicleRoleKORLastUpdateUser());
            bRequireMapRefresh = false;
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the control object on this business object.
     *
     * @see com.dwl.base.DWLCommon#setControl(DWLControl)
     * @generated
     */
    public void setControl(DWLControl newDWLControl) {
        super.setControl(newDWLControl);

        if (eObjXCustomerVehicleRoleKOR != null) {
            eObjXCustomerVehicleRoleKOR.setControl(newDWLControl);
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the entity object associated with this business object.
     *
     * @generated
     */
    public EObjXCustomerVehicleRoleKOR getEObjXCustomerVehicleRoleKOR() {
        bRequireMapRefresh = true;
        return eObjXCustomerVehicleRoleKOR;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the entity object associated with this business object.
     *
     * @param eObjXCustomerVehicleRoleKOR
     *            The eObjXCustomerVehicleRoleKOR to set.
     * @generated
     */
    public void setEObjXCustomerVehicleRoleKOR(EObjXCustomerVehicleRoleKOR eObjXCustomerVehicleRoleKOR) {
        bRequireMapRefresh = true;
        this.eObjXCustomerVehicleRoleKOR = eObjXCustomerVehicleRoleKOR;
        if (this.eObjXCustomerVehicleRoleKOR != null && this.eObjXCustomerVehicleRoleKOR.getControl() == null) {
            DWLControl control = this.getControl();
            if (control != null) {
                this.eObjXCustomerVehicleRoleKOR.setControl(control);
            }
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xCustomerVehicleRoleKORpkId attribute.
     * 
     * @generated
     */
    public String getXCustomerVehicleRoleKORpkId (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXCustomerVehicleRoleKOR.getXCustomerVehicleRoleKORpkId());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xCustomerVehicleRoleKORpkId attribute.
     * 
     * @param newXCustomerVehicleRoleKORpkId
     *     The new value of xCustomerVehicleRoleKORpkId.
     * @generated
     */
    public void setXCustomerVehicleRoleKORpkId( String newXCustomerVehicleRoleKORpkId ) throws Exception {
        metaDataMap.put("XCustomerVehicleRoleKORpkId", newXCustomerVehicleRoleKORpkId);

        if (newXCustomerVehicleRoleKORpkId == null || newXCustomerVehicleRoleKORpkId.equals("")) {
            newXCustomerVehicleRoleKORpkId = null;


        }
        eObjXCustomerVehicleRoleKOR.setXCustomerVehicleRoleKORpkId( DWLFunctionUtils.getLongFromString(newXCustomerVehicleRoleKORpkId) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the customerVehicleId attribute.
     * 
     * @generated
     */
    public String getCustomerVehicleId (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXCustomerVehicleRoleKOR.getCustomerVehicleId());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the customerVehicleId attribute.
     * 
     * @param newCustomerVehicleId
     *     The new value of customerVehicleId.
     * @generated
     */
    public void setCustomerVehicleId( String newCustomerVehicleId ) throws Exception {
        metaDataMap.put("CustomerVehicleId", newCustomerVehicleId);

        if (newCustomerVehicleId == null || newCustomerVehicleId.equals("")) {
            newCustomerVehicleId = null;


        }
        eObjXCustomerVehicleRoleKOR.setCustomerVehicleId( DWLFunctionUtils.getLongFromString(newCustomerVehicleId) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the vehicleRoleType attribute.
     * 
     * @generated
     */
    public String getVehicleRoleType (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXCustomerVehicleRoleKOR.getVehicleRole());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the vehicleRoleType attribute.
     * 
     * @param newVehicleRoleType
     *     The new value of vehicleRoleType.
     * @generated
     */
    public void setVehicleRoleType( String newVehicleRoleType ) throws Exception {
        metaDataMap.put("VehicleRoleType", newVehicleRoleType);

        if (newVehicleRoleType == null || newVehicleRoleType.equals("")) {
            newVehicleRoleType = null;


        }
        eObjXCustomerVehicleRoleKOR.setVehicleRole( DWLFunctionUtils.getLongFromString(newVehicleRoleType) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the vehicleRoleValue attribute.
     * 
     * @generated
     */
    public String getVehicleRoleValue (){
      return vehicleRoleValue;
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the vehicleRoleValue attribute.
     * 
     * @param newVehicleRoleValue
     *     The new value of vehicleRoleValue.
     * @generated
     */
    public void setVehicleRoleValue( String newVehicleRoleValue ) throws Exception {
        metaDataMap.put("VehicleRoleValue", newVehicleRoleValue);

        if (newVehicleRoleValue == null || newVehicleRoleValue.equals("")) {
            newVehicleRoleValue = null;


        }
        vehicleRoleValue = newVehicleRoleValue;
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the startDate attribute.
     * 
     * @generated
     */
    public String getStartDate (){
   
        return DWLFunctionUtils.getStringFromTimestamp(eObjXCustomerVehicleRoleKOR.getStartDate());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the startDate attribute.
     * 
     * @param newStartDate
     *     The new value of startDate.
     * @generated
     */
    public void setStartDate( String newStartDate ) throws Exception {
        metaDataMap.put("StartDate", newStartDate);
       	isValidStartDate = true;

        if (newStartDate == null || newStartDate.equals("")) {
            newStartDate = null;
            eObjXCustomerVehicleRoleKOR.setStartDate(null);


        }
    else {
        	if (DateValidator.validates(newStartDate)) {
           		eObjXCustomerVehicleRoleKOR.setStartDate(DateFormatter.getStartDateTimestamp(newStartDate));
            	metaDataMap.put("StartDate", getStartDate());
        	} else {
            	if (Configuration.getConfiguration().getConfigItem(
              "/IBM/DWLCommonServices/InternalValidation/enabled").getBooleanValue()) {
                	if (metaDataMap.get("StartDate") != null) {
                    	metaDataMap.put("StartDate", "");
                	}
                	isValidStartDate = false;
                	eObjXCustomerVehicleRoleKOR.setStartDate(null);
            	}
        	}
        }
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the endDate attribute.
     * 
     * @generated
     */
    public String getEndDate (){
   
        return DWLFunctionUtils.getStringFromTimestamp(eObjXCustomerVehicleRoleKOR.getEndDate());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the endDate attribute.
     * 
     * @param newEndDate
     *     The new value of endDate.
     * @generated
     */
    public void setEndDate( String newEndDate ) throws Exception {
        metaDataMap.put("EndDate", newEndDate);
       	isValidEndDate = true;

        if (newEndDate == null || newEndDate.equals("")) {
            newEndDate = null;
            eObjXCustomerVehicleRoleKOR.setEndDate(null);


        }
    else {
        	if (DateValidator.validates(newEndDate)) {
           		eObjXCustomerVehicleRoleKOR.setEndDate(DateFormatter.getStartDateTimestamp(newEndDate));
            	metaDataMap.put("EndDate", getEndDate());
        	} else {
            	if (Configuration.getConfiguration().getConfigItem(
              "/IBM/DWLCommonServices/InternalValidation/enabled").getBooleanValue()) {
                	if (metaDataMap.get("EndDate") != null) {
                    	metaDataMap.put("EndDate", "");
                	}
                	isValidEndDate = false;
                	eObjXCustomerVehicleRoleKOR.setEndDate(null);
            	}
        	}
        }
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the sourceIdentifierType attribute.
     * 
     * @generated
     */
    public String getSourceIdentifierType (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXCustomerVehicleRoleKOR.getSourceIdentifier());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the sourceIdentifierType attribute.
     * 
     * @param newSourceIdentifierType
     *     The new value of sourceIdentifierType.
     * @generated
     */
    public void setSourceIdentifierType( String newSourceIdentifierType ) throws Exception {
        metaDataMap.put("SourceIdentifierType", newSourceIdentifierType);

        if (newSourceIdentifierType == null || newSourceIdentifierType.equals("")) {
            newSourceIdentifierType = null;


        }
        eObjXCustomerVehicleRoleKOR.setSourceIdentifier( DWLFunctionUtils.getLongFromString(newSourceIdentifierType) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the sourceIdentifierValue attribute.
     * 
     * @generated
     */
    public String getSourceIdentifierValue (){
      return sourceIdentifierValue;
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the sourceIdentifierValue attribute.
     * 
     * @param newSourceIdentifierValue
     *     The new value of sourceIdentifierValue.
     * @generated
     */
    public void setSourceIdentifierValue( String newSourceIdentifierValue ) throws Exception {
        metaDataMap.put("SourceIdentifierValue", newSourceIdentifierValue);

        if (newSourceIdentifierValue == null || newSourceIdentifierValue.equals("")) {
            newSourceIdentifierValue = null;


        }
        sourceIdentifierValue = newSourceIdentifierValue;
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the changedDate attribute.
     * 
     * @generated
     */
    public String getChangedDate (){
   
        return DWLFunctionUtils.getStringFromTimestamp(eObjXCustomerVehicleRoleKOR.getChangedDate());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the changedDate attribute.
     * 
     * @param newChangedDate
     *     The new value of changedDate.
     * @generated
     */
    public void setChangedDate( String newChangedDate ) throws Exception {
        metaDataMap.put("ChangedDate", newChangedDate);
       	isValidChangedDate = true;

        if (newChangedDate == null || newChangedDate.equals("")) {
            newChangedDate = null;
            eObjXCustomerVehicleRoleKOR.setChangedDate(null);


        }
    else {
        	if (DateValidator.validates(newChangedDate)) {
           		eObjXCustomerVehicleRoleKOR.setChangedDate(DateFormatter.getStartDateTimestamp(newChangedDate));
            	metaDataMap.put("ChangedDate", getChangedDate());
        	} else {
            	if (Configuration.getConfiguration().getConfigItem(
              "/IBM/DWLCommonServices/InternalValidation/enabled").getBooleanValue()) {
                	if (metaDataMap.get("ChangedDate") != null) {
                    	metaDataMap.put("ChangedDate", "");
                	}
                	isValidChangedDate = false;
                	eObjXCustomerVehicleRoleKOR.setChangedDate(null);
            	}
        	}
        }
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateTxId attribute.
     *
     * @generated
     */
    public String getXCustomerVehicleRoleKORLastUpdateTxId() {
        return DWLFunctionUtils.getStringFromLong(eObjXCustomerVehicleRoleKOR.getLastUpdateTxId());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateUser attribute.
     *
     * @generated
     */
    public String getXCustomerVehicleRoleKORLastUpdateUser() {
        return eObjXCustomerVehicleRoleKOR.getLastUpdateUser();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateDt attribute.
     *
     * @generated
     */
    public String getXCustomerVehicleRoleKORLastUpdateDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXCustomerVehicleRoleKOR.getLastUpdateDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateTxId attribute.
     *
     * @param newLastUpdateTxId
     *     The new value of LastUpdateTxId.
     * @generated
     */
    public void setXCustomerVehicleRoleKORLastUpdateTxId(String newLastUpdateTxId) {
        metaDataMap.put("XCustomerVehicleRoleKORLastUpdateTxId", newLastUpdateTxId);

        if ((newLastUpdateTxId == null) || newLastUpdateTxId.equals("")) {
            newLastUpdateTxId = null;
        }
        eObjXCustomerVehicleRoleKOR.setLastUpdateTxId(DWLFunctionUtils.getLongFromString(newLastUpdateTxId));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateUser attribute.
     *
     * @param newLastUpdateUser
     *     The new value of LastUpdateUser.
     * @generated
     */
    public void setXCustomerVehicleRoleKORLastUpdateUser(String newLastUpdateUser) {
        metaDataMap.put("XCustomerVehicleRoleKORLastUpdateUser", newLastUpdateUser);

        if ((newLastUpdateUser == null) || newLastUpdateUser.equals("")) {
            newLastUpdateUser = null;
        }
        eObjXCustomerVehicleRoleKOR.setLastUpdateUser(newLastUpdateUser);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateDt attribute.
     *
     * @param newLastUpdateDt
     *     The new value of LastUpdateDt.
     * @throws Exception
     * @generated
     */
    public void setXCustomerVehicleRoleKORLastUpdateDate(String newLastUpdateDt) throws Exception {
        metaDataMap.put("XCustomerVehicleRoleKORLastUpdateDate", newLastUpdateDt);

        if ((newLastUpdateDt == null) || newLastUpdateDt.equals("")) {
            newLastUpdateDt = null;
        }

        eObjXCustomerVehicleRoleKOR.setLastUpdateDt(DWLFunctionUtils.getTimestampFromTimestampString(newLastUpdateDt));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XCustomerVehicleRoleKORHistActionCode history attribute.
     *
     * @generated
     */
    public String getXCustomerVehicleRoleKORHistActionCode() {
        return eObjXCustomerVehicleRoleKOR.getHistActionCode();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XCustomerVehicleRoleKORHistActionCode history attribute.
     *
     * @param aXCustomerVehicleRoleKORHistActionCode
     *     The new value of XCustomerVehicleRoleKORHistActionCode.
     * @generated
     */
    public void setXCustomerVehicleRoleKORHistActionCode(String aXCustomerVehicleRoleKORHistActionCode) {
        metaDataMap.put("XCustomerVehicleRoleKORHistActionCode", aXCustomerVehicleRoleKORHistActionCode);

        if ((aXCustomerVehicleRoleKORHistActionCode == null) || aXCustomerVehicleRoleKORHistActionCode.equals("")) {
            aXCustomerVehicleRoleKORHistActionCode = null;
        }
        eObjXCustomerVehicleRoleKOR.setHistActionCode(aXCustomerVehicleRoleKORHistActionCode);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XCustomerVehicleRoleKORHistCreateDate history attribute.
     *
     * @generated
     */
    public String getXCustomerVehicleRoleKORHistCreateDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXCustomerVehicleRoleKOR.getHistCreateDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XCustomerVehicleRoleKORHistCreateDate history attribute.
     *
     * @param aXCustomerVehicleRoleKORHistCreateDate
     *     The new value of XCustomerVehicleRoleKORHistCreateDate.
     * @generated
     */
    public void setXCustomerVehicleRoleKORHistCreateDate(String aXCustomerVehicleRoleKORHistCreateDate) throws Exception{
        metaDataMap.put("XCustomerVehicleRoleKORHistCreateDate", aXCustomerVehicleRoleKORHistCreateDate);

        if ((aXCustomerVehicleRoleKORHistCreateDate == null) || aXCustomerVehicleRoleKORHistCreateDate.equals("")) {
            aXCustomerVehicleRoleKORHistCreateDate = null;
        }

        eObjXCustomerVehicleRoleKOR.setHistCreateDt(DWLFunctionUtils.getTimestampFromTimestampString(aXCustomerVehicleRoleKORHistCreateDate));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XCustomerVehicleRoleKORHistCreatedBy history attribute.
     *
     * @generated
     */
    public String getXCustomerVehicleRoleKORHistCreatedBy() {
        return eObjXCustomerVehicleRoleKOR.getHistCreatedBy();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XCustomerVehicleRoleKORHistCreatedBy history attribute.
     *
     * @param aXCustomerVehicleRoleKORHistCreatedBy
     *     The new value of XCustomerVehicleRoleKORHistCreatedBy.
     * @generated
     */
    public void setXCustomerVehicleRoleKORHistCreatedBy(String aXCustomerVehicleRoleKORHistCreatedBy) {
        metaDataMap.put("XCustomerVehicleRoleKORHistCreatedBy", aXCustomerVehicleRoleKORHistCreatedBy);

        if ((aXCustomerVehicleRoleKORHistCreatedBy == null) || aXCustomerVehicleRoleKORHistCreatedBy.equals("")) {
            aXCustomerVehicleRoleKORHistCreatedBy = null;
        }

        eObjXCustomerVehicleRoleKOR.setHistCreatedBy(aXCustomerVehicleRoleKORHistCreatedBy);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XCustomerVehicleRoleKORHistEndDate history attribute.
     *
     * @generated
     */
    public String getXCustomerVehicleRoleKORHistEndDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXCustomerVehicleRoleKOR.getHistEndDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XCustomerVehicleRoleKORHistEndDate history attribute.
     *
     * @param aXCustomerVehicleRoleKORHistEndDate
     *     The new value of XCustomerVehicleRoleKORHistEndDate.
     * @generated
     */
    public void setXCustomerVehicleRoleKORHistEndDate(String aXCustomerVehicleRoleKORHistEndDate) throws Exception{
        metaDataMap.put("XCustomerVehicleRoleKORHistEndDate", aXCustomerVehicleRoleKORHistEndDate);

        if ((aXCustomerVehicleRoleKORHistEndDate == null) || aXCustomerVehicleRoleKORHistEndDate.equals("")) {
            aXCustomerVehicleRoleKORHistEndDate = null;
        }
        eObjXCustomerVehicleRoleKOR.setHistEndDt(DWLFunctionUtils.getTimestampFromTimestampString(aXCustomerVehicleRoleKORHistEndDate));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XCustomerVehicleRoleKORHistoryIdPK history attribute.
     *
     * @generated
     */
    public String getXCustomerVehicleRoleKORHistoryIdPK() {
        return DWLFunctionUtils.getStringFromLong(eObjXCustomerVehicleRoleKOR.getHistoryIdPK());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XCustomerVehicleRoleKORHistoryIdPK history attribute.
     *
     * @param aXCustomerVehicleRoleKORHistoryIdPK
     *     The new value of XCustomerVehicleRoleKORHistoryIdPK.
     * @generated
     */
    public void setXCustomerVehicleRoleKORHistoryIdPK(String aXCustomerVehicleRoleKORHistoryIdPK) {
        metaDataMap.put("XCustomerVehicleRoleKORHistoryIdPK", aXCustomerVehicleRoleKORHistoryIdPK);

        if ((aXCustomerVehicleRoleKORHistoryIdPK == null) || aXCustomerVehicleRoleKORHistoryIdPK.equals("")) {
            aXCustomerVehicleRoleKORHistoryIdPK = null;
        }
        eObjXCustomerVehicleRoleKOR.setHistoryIdPK(DWLFunctionUtils.getLongFromString(aXCustomerVehicleRoleKORHistoryIdPK));
    }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation during an add transaction.
     *
     * @generated
     */
    public DWLStatus validateAdd(int level, DWLStatus status) throws Exception {

        status = super.validateAdd(level, status);
        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0038I Add any controller-level custom validation logic to be
            // executed for this object during an "add" transaction

        }

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            // MDM_TODO0: CDKWB0039I Add any component-level custom validation logic to be
            // executed for this object during an "add" transaction
        }
        status = getValidationStatus(level, status);
        return status;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation during an update transaction.
     *
     * @generated
     */
    public DWLStatus validateUpdate(int level, DWLStatus status) throws Exception {
    logger.finest("ENTER validateUpdate(int level, DWLStatus status)");

        status = super.validateUpdate(level, status);
        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0040I Add any controller-level custom validation logic to be
            // executed for this object during an "update" transaction

            if (eObjXCustomerVehicleRoleKOR.getXCustomerVehicleRoleKORpkId() == null) {
                DWLError err = new DWLError();
                err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_ROLE_KORBOBJ).longValue());
                err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.XCUSTOMERVEHICLEROLEKOR_XCUSTOMERVEHICLEROLEKORPKID_NULL).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                	String infoForLogging="Error: Validation error occured for update. No primary key for entity XCustomerVehicleRoleKOR, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("validateUpdate(int level, DWLStatus status) " + infoForLogging);
                }
                status.addError(err);
            }
            if (eObjXCustomerVehicleRoleKOR.getLastUpdateDt() == null) {
                DWLError err = new DWLError();
                err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_ROLE_KORBOBJ).longValue());
                err.setReasonCode(new Long(DWLUtilErrorReasonCode.LAST_UPDATED_DATE_NULL).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
                if (logger.isFinestEnabled()) {
                	String infoForLogging="Error: Validation error occured for update. No last update date for entity XCustomerVehicleRoleKOR, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("validateUpdate(int level, DWLStatus status) " + infoForLogging);
                }
                status.addError(err);
            }
        }

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            assignBeforeImageValues(metaDataMap);
            
            // MDM_TODO0: CDKWB0041I Add any component-level custom validation logic to be
            // executed for this object during an "update" transaction
        }
        status = getValidationStatus(level, status);
    if (logger.isFinestEnabled()) {
        	String returnValue = status.toString();
      logger.finest("RETURN validateUpdate(int level, DWLStatus status) " + returnValue);
    }
        return status;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Populate the before image of this business object.
     *
     * @see com.dwl.base.DWLCommon#populateBeforeImage()
     * @generated
     */
    public void populateBeforeImage() throws DWLBaseException {
    logger.finest("ENTER populateBeforeImage()");

        DSEAAdditionsExts comp = null;
        try {
        
      comp = (DSEAAdditionsExts)TCRMClassFactory.getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
        	
        } catch (Exception e) {
      if (logger.isFinestEnabled()) {
        String infoForLogging="Error: Fatal error while updating record " + e.getMessage();
      logger.finest("populateBeforeImage() " + infoForLogging);
      }
            DWLExceptionUtils.throwDWLBaseException(e, 
            									new DWLUpdateException(e.getMessage()), 
            									this.getStatus(), DWLStatus.FATAL,
                                  DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_ROLE_KORBOBJ, 
                                  "DIERR",
                                  DSEAAdditionsExtsErrorReasonCode.XCUSTOMERVEHICLEROLEKOR_BEFORE_IMAGE_NOT_POPULATED, 
                                  this.getControl());
        }
        
        comp.loadBeforeImage(this);
    logger.finest("RETURN populateBeforeImage()");
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation common to both add and update transactions.
     *
     * @generated
     */
     
    private DWLStatus getValidationStatus(int level, DWLStatus status) throws Exception {
    logger.finest("ENTER getValidationStatus(int level, DWLStatus status)");

        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0034I Add any common controller-level custom validation
            // logic to be executed for this object during either "add" or
            // "update" transactions
    		controllerValidation_VehicleRole(status);
    		controllerValidation_StartDate(status);
    		controllerValidation_EndDate(status);
    		controllerValidation_SourceIdentifier(status);
    		controllerValidation_ChangedDate(status);
    	}

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            // MDM_TODO0: CDKWB0035I Add any common component-level custom validation logic
            // to be executed for this object during either "add" or "update"
            // transactions
    		componentValidation_VehicleRole(status);
    		componentValidation_StartDate(status);
    		componentValidation_EndDate(status);
    		componentValidation_SourceIdentifier(status);
    		componentValidation_ChangedDate(status);
        }
        
        if (logger.isFinestEnabled()) {
            String returnValue = status.toString();
      logger.finest("RETURN getValidationStatus(int level, DWLStatus status) " + returnValue);
        }
    
        return status;
    }

    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "VehicleRole"
     *
     * @generated
     */
	private void componentValidation_VehicleRole(DWLStatus status) {
  
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "StartDate"
     *
     * @generated
     */
	private void componentValidation_StartDate(DWLStatus status) {
  
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "EndDate"
     *
     * @generated
     */
	private void componentValidation_EndDate(DWLStatus status) {
  
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "SourceIdentifier"
     *
     * @generated
     */
	private void componentValidation_SourceIdentifier(DWLStatus status) {
  
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "ChangedDate"
     *
     * @generated
     */
	private void componentValidation_ChangedDate(DWLStatus status) {
  
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "VehicleRole"
     *
     * @generated
     */
	private void controllerValidation_VehicleRole(DWLStatus status) throws Exception {
  
      //persistent code type
            boolean isVehicleRoleNull = false;
            if ((eObjXCustomerVehicleRoleKOR.getVehicleRole() == null) &&
               ((getVehicleRoleValue() == null) || 
                 getVehicleRoleValue().trim().equals(""))) {
                isVehicleRoleNull = true;
            }
            if (!isVehicleRoleNull) {
                if (checkForInvalidXcustomervehiclerolekorVehiclerole()) {
                    DWLError err = new DWLError();
                    err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_ROLE_KORBOBJ).longValue());
                    err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XCUSTOMERVEHICLEROLEKOR_VEHICLEROLE).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                    String infoForLogging="Error: Custom validation error occured for entity XCustomerVehicleRoleKOR, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("controllerValidation_VehicleRole " + infoForLogging);
        }
                status.addError(err);
            }

             }
    			
    	}
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "StartDate"
     *
     * @generated
     */
	private void controllerValidation_StartDate(DWLStatus status) throws Exception {
  
            boolean isStartDateNull = (eObjXCustomerVehicleRoleKOR.getStartDate() == null);
            if (!isValidStartDate) {
              	DWLError err = new DWLError();
               	err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_ROLE_KORBOBJ).longValue());
               	err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XCUSTOMERVEHICLEROLEKOR_STARTDATE).longValue());
               	err.setErrorType(DWLErrorCode.DATA_INVALID_ERROR);
                String infoForLogging="Error: Validation error. Invalid time specified on property StartDate in entity XCustomerVehicleRoleKOR, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode();
      logger.finest("controllerValidation_StartDate " + infoForLogging);
               	status.addError(err);
            } 
    	}
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "EndDate"
     *
     * @generated
     */
	private void controllerValidation_EndDate(DWLStatus status) throws Exception {
  
            boolean isEndDateNull = (eObjXCustomerVehicleRoleKOR.getEndDate() == null);
            if (!isValidEndDate) {
              	DWLError err = new DWLError();
               	err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_ROLE_KORBOBJ).longValue());
               	err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XCUSTOMERVEHICLEROLEKOR_ENDDATE).longValue());
               	err.setErrorType(DWLErrorCode.DATA_INVALID_ERROR);
                String infoForLogging="Error: Validation error. Invalid time specified on property EndDate in entity XCustomerVehicleRoleKOR, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode();
      logger.finest("controllerValidation_EndDate " + infoForLogging);
               	status.addError(err);
            } 
    	}
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "SourceIdentifier"
     *
     * @generated
     */
	private void controllerValidation_SourceIdentifier(DWLStatus status) throws Exception {
  
      //persistent code type
            boolean isSourceIdentifierNull = false;
            if ((eObjXCustomerVehicleRoleKOR.getSourceIdentifier() == null) &&
               ((getSourceIdentifierValue() == null) || 
                 getSourceIdentifierValue().trim().equals(""))) {
                isSourceIdentifierNull = true;
            }
            if (!isSourceIdentifierNull) {
                if (checkForInvalidXcustomervehiclerolekorSourceidentifier()) {
                    DWLError err = new DWLError();
                    err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_ROLE_KORBOBJ).longValue());
                    err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XCUSTOMERVEHICLEROLEKOR_SOURCEIDENTIFIER).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                    String infoForLogging="Error: Custom validation error occured for entity XCustomerVehicleRoleKOR, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("controllerValidation_SourceIdentifier " + infoForLogging);
        }
                status.addError(err);
            }

             }
    			
    	}
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "ChangedDate"
     *
     * @generated
     */
	private void controllerValidation_ChangedDate(DWLStatus status) throws Exception {
  
            boolean isChangedDateNull = (eObjXCustomerVehicleRoleKOR.getChangedDate() == null);
            if (!isValidChangedDate) {
              	DWLError err = new DWLError();
               	err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_ROLE_KORBOBJ).longValue());
               	err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XCUSTOMERVEHICLEROLEKOR_CHANGEDDATE).longValue());
               	err.setErrorType(DWLErrorCode.DATA_INVALID_ERROR);
                String infoForLogging="Error: Validation error. Invalid time specified on property ChangedDate in entity XCustomerVehicleRoleKOR, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode();
      logger.finest("controllerValidation_ChangedDate " + infoForLogging);
               	status.addError(err);
            } 
    	}
    private DWLError createDWLError(String entityName, String propertyName,String reasonCode){	
		DWLError err = new DWLError();
		err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_ROLE_KORBOBJ).longValue());
		err.setReasonCode(new Long(reasonCode).longValue());
		err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
			String infoForLogging="Error: Validation error occured. Property " + propertyName + " is null, in entity " + entityName + ", component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
			logger.finest("createDWLError " + infoForLogging);
		}
		return err;
    }
    
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Check the value of the field VehicleRole and return true if the error
     * reason INVALID_XCUSTOMERVEHICLEROLEKOR_VEHICLEROLE should be returned.
     *
     * @generated
  **/
	private boolean checkForInvalidXcustomervehiclerolekorVehiclerole() throws Exception {
    logger.finest("ENTER checkForInvalidXcustomervehiclerolekorVehiclerole()");
        boolean notValid = false;
      	String langId = (String) this.getControl().get(DWLControlKeys.LANG_ID);
      	CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
    Long codeType = DWLFunctionUtils.getLongFromString( getVehicleRoleType() );
    String codeValue = getVehicleRoleValue();
    if( codeValue != null && codeValue.trim().equals("")){
      codeValue = null;
    }
     
        if ( codeType != null && codeValue == null ){

             if( codeTypeCompHelper.isCodeValid("xcdvehicleroletp", langId, getVehicleRoleType(),
                 CodeTypeComponentHelper.ACTIVE, getControl())) {
                 CodeTypeBObj ctBObj = codeTypeCompHelper
                 					.getCodeTypeByCode("xcdvehicleroletp", langId, getVehicleRoleType(),
                         								getControl());
               	if (ctBObj != null) {
                   	setVehicleRoleValue( ctBObj.getvalue() );
               	}
             }
             else{
             	if (logger.isFinestEnabled()) {
              	 	String infoForLogging="NotValid 1";
      logger.finest("checkForInvalidXcustomervehiclerolekorVehiclerole() " + infoForLogging);
        }
                 notValid = true;
           }
        }
        else if (codeType == null && codeValue != null ){
          
             CodeTypeBObj ctBObj = codeTypeCompHelper
                      .getCodeTypeByValue("xcdvehicleroletp", langId, codeValue,
                                 getControl());

             if (ctBObj != null) {
                 setVehicleRoleType(ctBObj.gettp_cd());
             } 
             else {
             	if (logger.isFinestEnabled()) {
              	  	String infoForLogging="NotValid 2";
      logger.finest("checkForInvalidXcustomervehiclerolekorVehiclerole() " + infoForLogging);
        }
                  notValid = true;
             }
        }
        else if ( codeType != null && codeValue != null
             && !codeTypeCompHelper.isCodeValuePairValid("xcdvehicleroletp", langId, getVehicleRoleType(), 
                     new String[] { codeValue }, CodeTypeComponentHelper.ACTIVE, getControl())) {	
       if (logger.isFinestEnabled()) {
       		String infoForLogging="NotValid 3";
      logger.finest("checkForInvalidXcustomervehiclerolekorVehiclerole() " + infoForLogging);
       }
             notValid = true;
        }
        if (logger.isFinestEnabled()) {
      String returnValue ="" +notValid;
      logger.finest("RETURN checkForInvalidXcustomervehiclerolekorVehiclerole() " + returnValue);
    }
    return notValid;
     } 
				 
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Check the value of the field SourceIdentifier and return true if the
     * error reason INVALID_XCUSTOMERVEHICLEROLEKOR_SOURCEIDENTIFIER should be
     * returned.
     *
     * @generated
  **/
	private boolean checkForInvalidXcustomervehiclerolekorSourceidentifier() throws Exception {
    logger.finest("ENTER checkForInvalidXcustomervehiclerolekorSourceidentifier()");
        boolean notValid = false;
      	String langId = (String) this.getControl().get(DWLControlKeys.LANG_ID);
      	CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
    Long codeType = DWLFunctionUtils.getLongFromString( getSourceIdentifierType() );
    String codeValue = getSourceIdentifierValue();
    if( codeValue != null && codeValue.trim().equals("")){
      codeValue = null;
    }
     
        if ( codeType != null && codeValue == null ){

             if( codeTypeCompHelper.isCodeValid("cdsourceidenttp", langId, getSourceIdentifierType(),
                 CodeTypeComponentHelper.ACTIVE, getControl())) {
                 CodeTypeBObj ctBObj = codeTypeCompHelper
                 					.getCodeTypeByCode("cdsourceidenttp", langId, getSourceIdentifierType(),
                         								getControl());
               	if (ctBObj != null) {
                   	setSourceIdentifierValue( ctBObj.getvalue() );
               	}
             }
             else{
             	if (logger.isFinestEnabled()) {
              	 	String infoForLogging="NotValid 1";
      logger.finest("checkForInvalidXcustomervehiclerolekorSourceidentifier() " + infoForLogging);
        }
                 notValid = true;
           }
        }
        else if (codeType == null && codeValue != null ){
          
             CodeTypeBObj ctBObj = codeTypeCompHelper
                      .getCodeTypeByValue("cdsourceidenttp", langId, codeValue,
                                 getControl());

             if (ctBObj != null) {
                 setSourceIdentifierType(ctBObj.gettp_cd());
             } 
             else {
             	if (logger.isFinestEnabled()) {
              	  	String infoForLogging="NotValid 2";
      logger.finest("checkForInvalidXcustomervehiclerolekorSourceidentifier() " + infoForLogging);
        }
                  notValid = true;
             }
        }
        else if ( codeType != null && codeValue != null
             && !codeTypeCompHelper.isCodeValuePairValid("cdsourceidenttp", langId, getSourceIdentifierType(), 
                     new String[] { codeValue }, CodeTypeComponentHelper.ACTIVE, getControl())) {	
       if (logger.isFinestEnabled()) {
       		String infoForLogging="NotValid 3";
      logger.finest("checkForInvalidXcustomervehiclerolekorSourceidentifier() " + infoForLogging);
       }
             notValid = true;
        }
        if (logger.isFinestEnabled()) {
      String returnValue ="" +notValid;
      logger.finest("RETURN checkForInvalidXcustomervehiclerolekorSourceidentifier() " + returnValue);
    }
    return notValid;
     } 
				 



}

