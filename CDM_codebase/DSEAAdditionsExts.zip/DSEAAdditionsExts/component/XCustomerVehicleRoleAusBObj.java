
/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[c81a8a87770c69635bb06432b9594b3d]
 */

package com.ibm.daimler.dsea.component;

import com.dwl.tcrm.common.TCRMCommon;



import com.dwl.base.DWLControl;

import com.dwl.base.constant.DWLControlKeys;
import com.dwl.base.constant.DWLUtilErrorReasonCode;

import com.dwl.base.error.DWLError;
import com.dwl.base.error.DWLErrorCode;
import com.dwl.base.error.DWLStatus;

import com.dwl.base.exception.DWLBaseException;
import com.dwl.base.exception.DWLUpdateException;

import com.dwl.base.util.DWLClassFactory;
import com.dwl.base.util.DWLExceptionUtils;
import com.dwl.base.util.DWLFunctionUtils;

import com.dwl.management.config.client.Configuration;

import com.dwl.tcrm.common.ITCRMValidation;

import com.dwl.tcrm.utilities.DateFormatter;
import com.dwl.tcrm.utilities.DateValidator;
import com.dwl.tcrm.utilities.TCRMClassFactory;

import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsComponentID;
import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsErrorReasonCode;
import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsPropertyKeys;

import com.ibm.daimler.dsea.entityObject.EObjXCustomerVehicleRoleAus;

import com.ibm.daimler.dsea.interfaces.DSEAAdditionsExts;

import com.ibm.mdm.common.codetype.interfaces.CodeTypeComponentHelper;

import com.ibm.mdm.common.codetype.obj.CodeTypeBObj;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * This class provides the implementation of the business object
 * <code>XCustomerVehicleRoleAusBObj</code>.
 * 
 * @see com.dwl.tcrm.common.TCRMCommon
 * @generated
 */
 

@SuppressWarnings("serial")
public class XCustomerVehicleRoleAusBObj extends TCRMCommon  {

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected EObjXCustomerVehicleRoleAus eObjXCustomerVehicleRoleAus;
	/**
    * <!-- begin-user-doc -->
	  * <!-- end-user-doc -->
    * @generated 
    */
	 private final static com.dwl.base.logging.IDWLLogger logger = com.dwl.base.logging.DWLLoggerManager.getLogger(XCustomerVehicleRoleAusBObj.class);
		
 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected String vehicleRoleValue;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected String vehicleRelStatusValue;
	protected boolean isValidStartDate = true;
	
	protected boolean isValidEndDate = true;
	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected String sourceIdentifierValue;
	protected boolean isValidLastModifiedSystemDate = true;
	


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */     
    public XCustomerVehicleRoleAusBObj() {
        super();
        init();
        eObjXCustomerVehicleRoleAus = new EObjXCustomerVehicleRoleAus();
        setComponentID(DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_ROLE_AUS_BOBJ);
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Initializes the fields required to populate the metaDataMap. Each key is
     * an element-level field of the business object.
     *
     * @generated
     */
    private void init() {
        metaDataMap.put("XCustomerRoleAuspkId", null);
        metaDataMap.put("CustomerVehicleId", null);
        metaDataMap.put("VehicleRoleType", null);
        metaDataMap.put("VehicleRoleValue", null);
        metaDataMap.put("VehicleRelStatusType", null);
        metaDataMap.put("VehicleRelStatusValue", null);
        metaDataMap.put("StartDate", null);
        metaDataMap.put("EndDate", null);
        metaDataMap.put("SourceIdentifierType", null);
        metaDataMap.put("SourceIdentifierValue", null);
        metaDataMap.put("LastModifiedSystemDate", null);
        metaDataMap.put("XCustomerVehicleAusReference", null);
        metaDataMap.put("XCustomerVehicleRoleAusHistActionCode", null);
        metaDataMap.put("XCustomerVehicleRoleAusHistCreateDate", null);
        metaDataMap.put("XCustomerVehicleRoleAusHistCreatedBy", null);
        metaDataMap.put("XCustomerVehicleRoleAusHistEndDate", null);
        metaDataMap.put("XCustomerVehicleRoleAusHistoryIdPK", null);
        metaDataMap.put("XCustomerVehicleRoleAusLastUpdateDate", null);
        metaDataMap.put("XCustomerVehicleRoleAusLastUpdateTxId", null);
        metaDataMap.put("XCustomerVehicleRoleAusLastUpdateUser", null);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Refreshes all the attributes this business object supports.
     *
     * @see com.dwl.base.DWLCommon#refreshMap()
     * @generated
     */
    public void refreshMap() {

        if (bRequireMapRefresh) {
            super.refreshMap();
            metaDataMap.put("XCustomerRoleAuspkId", getXCustomerRoleAuspkId());
            metaDataMap.put("CustomerVehicleId", getCustomerVehicleId());
            metaDataMap.put("VehicleRoleType", getVehicleRoleType());
            metaDataMap.put("VehicleRoleValue", getVehicleRoleValue());
            metaDataMap.put("VehicleRelStatusType", getVehicleRelStatusType());
            metaDataMap.put("VehicleRelStatusValue", getVehicleRelStatusValue());
            metaDataMap.put("StartDate", getStartDate());
            metaDataMap.put("EndDate", getEndDate());
            metaDataMap.put("SourceIdentifierType", getSourceIdentifierType());
            metaDataMap.put("SourceIdentifierValue", getSourceIdentifierValue());
            metaDataMap.put("LastModifiedSystemDate", getLastModifiedSystemDate());
            metaDataMap.put("XCustomerVehicleAusReference", getXCustomerVehicleAusReference());
            metaDataMap.put("XCustomerVehicleRoleAusHistActionCode", getXCustomerVehicleRoleAusHistActionCode());
            metaDataMap.put("XCustomerVehicleRoleAusHistCreateDate", getXCustomerVehicleRoleAusHistCreateDate());
            metaDataMap.put("XCustomerVehicleRoleAusHistCreatedBy", getXCustomerVehicleRoleAusHistCreatedBy());
            metaDataMap.put("XCustomerVehicleRoleAusHistEndDate", getXCustomerVehicleRoleAusHistEndDate());
            metaDataMap.put("XCustomerVehicleRoleAusHistoryIdPK", getXCustomerVehicleRoleAusHistoryIdPK());
            metaDataMap.put("XCustomerVehicleRoleAusLastUpdateDate", getXCustomerVehicleRoleAusLastUpdateDate());
            metaDataMap.put("XCustomerVehicleRoleAusLastUpdateTxId", getXCustomerVehicleRoleAusLastUpdateTxId());
            metaDataMap.put("XCustomerVehicleRoleAusLastUpdateUser", getXCustomerVehicleRoleAusLastUpdateUser());
            bRequireMapRefresh = false;
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the control object on this business object.
     *
     * @see com.dwl.base.DWLCommon#setControl(DWLControl)
     * @generated
     */
    public void setControl(DWLControl newDWLControl) {
        super.setControl(newDWLControl);

        if (eObjXCustomerVehicleRoleAus != null) {
            eObjXCustomerVehicleRoleAus.setControl(newDWLControl);
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the entity object associated with this business object.
     *
     * @generated
     */
    public EObjXCustomerVehicleRoleAus getEObjXCustomerVehicleRoleAus() {
        bRequireMapRefresh = true;
        return eObjXCustomerVehicleRoleAus;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the entity object associated with this business object.
     *
     * @param eObjXCustomerVehicleRoleAus
     *            The eObjXCustomerVehicleRoleAus to set.
     * @generated
     */
    public void setEObjXCustomerVehicleRoleAus(EObjXCustomerVehicleRoleAus eObjXCustomerVehicleRoleAus) {
        bRequireMapRefresh = true;
        this.eObjXCustomerVehicleRoleAus = eObjXCustomerVehicleRoleAus;
        if (this.eObjXCustomerVehicleRoleAus != null && this.eObjXCustomerVehicleRoleAus.getControl() == null) {
            DWLControl control = this.getControl();
            if (control != null) {
                this.eObjXCustomerVehicleRoleAus.setControl(control);
            }
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xCustomerRoleAuspkId attribute.
     * 
     * @generated
     */
    public String getXCustomerRoleAuspkId (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXCustomerVehicleRoleAus.getXCustomerRoleAuspkId());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xCustomerRoleAuspkId attribute.
     * 
     * @param newXCustomerRoleAuspkId
     *     The new value of xCustomerRoleAuspkId.
     * @generated
     */
    public void setXCustomerRoleAuspkId( String newXCustomerRoleAuspkId ) throws Exception {
        metaDataMap.put("XCustomerRoleAuspkId", newXCustomerRoleAuspkId);

        if (newXCustomerRoleAuspkId == null || newXCustomerRoleAuspkId.equals("")) {
            newXCustomerRoleAuspkId = null;


        }
        eObjXCustomerVehicleRoleAus.setXCustomerRoleAuspkId( DWLFunctionUtils.getLongFromString(newXCustomerRoleAuspkId) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the customerVehicleId attribute.
     * 
     * @generated
     */
    public String getCustomerVehicleId (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXCustomerVehicleRoleAus.getCustomerVehicleId());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the customerVehicleId attribute.
     * 
     * @param newCustomerVehicleId
     *     The new value of customerVehicleId.
     * @generated
     */
    public void setCustomerVehicleId( String newCustomerVehicleId ) throws Exception {
        metaDataMap.put("CustomerVehicleId", newCustomerVehicleId);

        if (newCustomerVehicleId == null || newCustomerVehicleId.equals("")) {
            newCustomerVehicleId = null;


        }
        eObjXCustomerVehicleRoleAus.setCustomerVehicleId( DWLFunctionUtils.getLongFromString(newCustomerVehicleId) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the vehicleRoleType attribute.
     * 
     * @generated
     */
    public String getVehicleRoleType (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXCustomerVehicleRoleAus.getVehicleRole());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the vehicleRoleType attribute.
     * 
     * @param newVehicleRoleType
     *     The new value of vehicleRoleType.
     * @generated
     */
    public void setVehicleRoleType( String newVehicleRoleType ) throws Exception {
        metaDataMap.put("VehicleRoleType", newVehicleRoleType);

        if (newVehicleRoleType == null || newVehicleRoleType.equals("")) {
            newVehicleRoleType = null;


        }
        eObjXCustomerVehicleRoleAus.setVehicleRole( DWLFunctionUtils.getLongFromString(newVehicleRoleType) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the vehicleRoleValue attribute.
     * 
     * @generated
     */
    public String getVehicleRoleValue (){
      return vehicleRoleValue;
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the vehicleRoleValue attribute.
     * 
     * @param newVehicleRoleValue
     *     The new value of vehicleRoleValue.
     * @generated
     */
    public void setVehicleRoleValue( String newVehicleRoleValue ) throws Exception {
        metaDataMap.put("VehicleRoleValue", newVehicleRoleValue);

        if (newVehicleRoleValue == null || newVehicleRoleValue.equals("")) {
            newVehicleRoleValue = null;


        }
        vehicleRoleValue = newVehicleRoleValue;
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the vehicleRelStatusType attribute.
     * 
     * @generated
     */
    public String getVehicleRelStatusType (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXCustomerVehicleRoleAus.getVehicleRelStatus());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the vehicleRelStatusType attribute.
     * 
     * @param newVehicleRelStatusType
     *     The new value of vehicleRelStatusType.
     * @generated
     */
    public void setVehicleRelStatusType( String newVehicleRelStatusType ) throws Exception {
        metaDataMap.put("VehicleRelStatusType", newVehicleRelStatusType);

        if (newVehicleRelStatusType == null || newVehicleRelStatusType.equals("")) {
            newVehicleRelStatusType = null;


        }
        eObjXCustomerVehicleRoleAus.setVehicleRelStatus( DWLFunctionUtils.getLongFromString(newVehicleRelStatusType) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the vehicleRelStatusValue attribute.
     * 
     * @generated
     */
    public String getVehicleRelStatusValue (){
      return vehicleRelStatusValue;
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the vehicleRelStatusValue attribute.
     * 
     * @param newVehicleRelStatusValue
     *     The new value of vehicleRelStatusValue.
     * @generated
     */
    public void setVehicleRelStatusValue( String newVehicleRelStatusValue ) throws Exception {
        metaDataMap.put("VehicleRelStatusValue", newVehicleRelStatusValue);

        if (newVehicleRelStatusValue == null || newVehicleRelStatusValue.equals("")) {
            newVehicleRelStatusValue = null;


        }
        vehicleRelStatusValue = newVehicleRelStatusValue;
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the startDate attribute.
     * 
     * @generated
     */
    public String getStartDate (){
   
        return DWLFunctionUtils.getStringFromTimestamp(eObjXCustomerVehicleRoleAus.getStartDate());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the startDate attribute.
     * 
     * @param newStartDate
     *     The new value of startDate.
     * @generated
     */
    public void setStartDate( String newStartDate ) throws Exception {
        metaDataMap.put("StartDate", newStartDate);
       	isValidStartDate = true;

        if (newStartDate == null || newStartDate.equals("")) {
            newStartDate = null;
            eObjXCustomerVehicleRoleAus.setStartDate(null);


        }
    else {
        	if (DateValidator.validates(newStartDate)) {
           		eObjXCustomerVehicleRoleAus.setStartDate(DateFormatter.getStartDateTimestamp(newStartDate));
            	metaDataMap.put("StartDate", getStartDate());
        	} else {
            	if (Configuration.getConfiguration().getConfigItem(
              "/IBM/DWLCommonServices/InternalValidation/enabled").getBooleanValue()) {
                	if (metaDataMap.get("StartDate") != null) {
                    	metaDataMap.put("StartDate", "");
                	}
                	isValidStartDate = false;
                	eObjXCustomerVehicleRoleAus.setStartDate(null);
            	}
        	}
        }
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the endDate attribute.
     * 
     * @generated
     */
    public String getEndDate (){
   
        return DWLFunctionUtils.getStringFromTimestamp(eObjXCustomerVehicleRoleAus.getEndDate());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the endDate attribute.
     * 
     * @param newEndDate
     *     The new value of endDate.
     * @generated
     */
    public void setEndDate( String newEndDate ) throws Exception {
        metaDataMap.put("EndDate", newEndDate);
       	isValidEndDate = true;

        if (newEndDate == null || newEndDate.equals("")) {
            newEndDate = null;
            eObjXCustomerVehicleRoleAus.setEndDate(null);


        }
    else {
        	if (DateValidator.validates(newEndDate)) {
           		eObjXCustomerVehicleRoleAus.setEndDate(DateFormatter.getStartDateTimestamp(newEndDate));
            	metaDataMap.put("EndDate", getEndDate());
        	} else {
            	if (Configuration.getConfiguration().getConfigItem(
              "/IBM/DWLCommonServices/InternalValidation/enabled").getBooleanValue()) {
                	if (metaDataMap.get("EndDate") != null) {
                    	metaDataMap.put("EndDate", "");
                	}
                	isValidEndDate = false;
                	eObjXCustomerVehicleRoleAus.setEndDate(null);
            	}
        	}
        }
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the sourceIdentifierType attribute.
     * 
     * @generated
     */
    public String getSourceIdentifierType (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXCustomerVehicleRoleAus.getSourceIdentifier());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the sourceIdentifierType attribute.
     * 
     * @param newSourceIdentifierType
     *     The new value of sourceIdentifierType.
     * @generated
     */
    public void setSourceIdentifierType( String newSourceIdentifierType ) throws Exception {
        metaDataMap.put("SourceIdentifierType", newSourceIdentifierType);

        if (newSourceIdentifierType == null || newSourceIdentifierType.equals("")) {
            newSourceIdentifierType = null;


        }
        eObjXCustomerVehicleRoleAus.setSourceIdentifier( DWLFunctionUtils.getLongFromString(newSourceIdentifierType) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the sourceIdentifierValue attribute.
     * 
     * @generated
     */
    public String getSourceIdentifierValue (){
      return sourceIdentifierValue;
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the sourceIdentifierValue attribute.
     * 
     * @param newSourceIdentifierValue
     *     The new value of sourceIdentifierValue.
     * @generated
     */
    public void setSourceIdentifierValue( String newSourceIdentifierValue ) throws Exception {
        metaDataMap.put("SourceIdentifierValue", newSourceIdentifierValue);

        if (newSourceIdentifierValue == null || newSourceIdentifierValue.equals("")) {
            newSourceIdentifierValue = null;


        }
        sourceIdentifierValue = newSourceIdentifierValue;
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the lastModifiedSystemDate attribute.
     * 
     * @generated
     */
    public String getLastModifiedSystemDate (){
   
        return DWLFunctionUtils.getStringFromTimestamp(eObjXCustomerVehicleRoleAus.getLastModifiedSystemDate());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the lastModifiedSystemDate attribute.
     * 
     * @param newLastModifiedSystemDate
     *     The new value of lastModifiedSystemDate.
     * @generated
     */
    public void setLastModifiedSystemDate( String newLastModifiedSystemDate ) throws Exception {
        metaDataMap.put("LastModifiedSystemDate", newLastModifiedSystemDate);
       	isValidLastModifiedSystemDate = true;

        if (newLastModifiedSystemDate == null || newLastModifiedSystemDate.equals("")) {
            newLastModifiedSystemDate = null;
            eObjXCustomerVehicleRoleAus.setLastModifiedSystemDate(null);


        }
    else {
        	if (DateValidator.validates(newLastModifiedSystemDate)) {
           		eObjXCustomerVehicleRoleAus.setLastModifiedSystemDate(DateFormatter.getStartDateTimestamp(newLastModifiedSystemDate));
            	metaDataMap.put("LastModifiedSystemDate", getLastModifiedSystemDate());
        	} else {
            	if (Configuration.getConfiguration().getConfigItem(
              "/IBM/DWLCommonServices/InternalValidation/enabled").getBooleanValue()) {
                	if (metaDataMap.get("LastModifiedSystemDate") != null) {
                    	metaDataMap.put("LastModifiedSystemDate", "");
                	}
                	isValidLastModifiedSystemDate = false;
                	eObjXCustomerVehicleRoleAus.setLastModifiedSystemDate(null);
            	}
        	}
        }
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xCustomerVehicleAusReference attribute.
     * 
     * @generated
     */
    public String getXCustomerVehicleAusReference (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXCustomerVehicleRoleAus.getXCustomerVehicleAusReference());
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xCustomerVehicleAusReference attribute.
     * 
     * @param newXCustomerVehicleAusReference
     *     The new value of xCustomerVehicleAusReference.
     * @generated
     */
    public void setXCustomerVehicleAusReference( String newXCustomerVehicleAusReference ) throws Exception {
        metaDataMap.put("XCustomerVehicleAusReference", newXCustomerVehicleAusReference);

        if (newXCustomerVehicleAusReference == null || newXCustomerVehicleAusReference.equals("")) {
            newXCustomerVehicleAusReference = null;


        }
        eObjXCustomerVehicleRoleAus.setXCustomerVehicleAusReference( DWLFunctionUtils.getLongFromString(newXCustomerVehicleAusReference) );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateTxId attribute.
     *
     * @generated
     */
    public String getXCustomerVehicleRoleAusLastUpdateTxId() {
        return DWLFunctionUtils.getStringFromLong(eObjXCustomerVehicleRoleAus.getLastUpdateTxId());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateUser attribute.
     *
     * @generated
     */
    public String getXCustomerVehicleRoleAusLastUpdateUser() {
        return eObjXCustomerVehicleRoleAus.getLastUpdateUser();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateDt attribute.
     *
     * @generated
     */
    public String getXCustomerVehicleRoleAusLastUpdateDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXCustomerVehicleRoleAus.getLastUpdateDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateTxId attribute.
     *
     * @param newLastUpdateTxId
     *     The new value of LastUpdateTxId.
     * @generated
     */
    public void setXCustomerVehicleRoleAusLastUpdateTxId(String newLastUpdateTxId) {
        metaDataMap.put("XCustomerVehicleRoleAusLastUpdateTxId", newLastUpdateTxId);

        if ((newLastUpdateTxId == null) || newLastUpdateTxId.equals("")) {
            newLastUpdateTxId = null;
        }
        eObjXCustomerVehicleRoleAus.setLastUpdateTxId(DWLFunctionUtils.getLongFromString(newLastUpdateTxId));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateUser attribute.
     *
     * @param newLastUpdateUser
     *     The new value of LastUpdateUser.
     * @generated
     */
    public void setXCustomerVehicleRoleAusLastUpdateUser(String newLastUpdateUser) {
        metaDataMap.put("XCustomerVehicleRoleAusLastUpdateUser", newLastUpdateUser);

        if ((newLastUpdateUser == null) || newLastUpdateUser.equals("")) {
            newLastUpdateUser = null;
        }
        eObjXCustomerVehicleRoleAus.setLastUpdateUser(newLastUpdateUser);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateDt attribute.
     *
     * @param newLastUpdateDt
     *     The new value of LastUpdateDt.
     * @throws Exception
     * @generated
     */
    public void setXCustomerVehicleRoleAusLastUpdateDate(String newLastUpdateDt) throws Exception {
        metaDataMap.put("XCustomerVehicleRoleAusLastUpdateDate", newLastUpdateDt);

        if ((newLastUpdateDt == null) || newLastUpdateDt.equals("")) {
            newLastUpdateDt = null;
        }

        eObjXCustomerVehicleRoleAus.setLastUpdateDt(DWLFunctionUtils.getTimestampFromTimestampString(newLastUpdateDt));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XCustomerVehicleRoleAusHistActionCode history attribute.
     *
     * @generated
     */
    public String getXCustomerVehicleRoleAusHistActionCode() {
        return eObjXCustomerVehicleRoleAus.getHistActionCode();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XCustomerVehicleRoleAusHistActionCode history attribute.
     *
     * @param aXCustomerVehicleRoleAusHistActionCode
     *     The new value of XCustomerVehicleRoleAusHistActionCode.
     * @generated
     */
    public void setXCustomerVehicleRoleAusHistActionCode(String aXCustomerVehicleRoleAusHistActionCode) {
        metaDataMap.put("XCustomerVehicleRoleAusHistActionCode", aXCustomerVehicleRoleAusHistActionCode);

        if ((aXCustomerVehicleRoleAusHistActionCode == null) || aXCustomerVehicleRoleAusHistActionCode.equals("")) {
            aXCustomerVehicleRoleAusHistActionCode = null;
        }
        eObjXCustomerVehicleRoleAus.setHistActionCode(aXCustomerVehicleRoleAusHistActionCode);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XCustomerVehicleRoleAusHistCreateDate history attribute.
     *
     * @generated
     */
    public String getXCustomerVehicleRoleAusHistCreateDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXCustomerVehicleRoleAus.getHistCreateDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XCustomerVehicleRoleAusHistCreateDate history attribute.
     *
     * @param aXCustomerVehicleRoleAusHistCreateDate
     *     The new value of XCustomerVehicleRoleAusHistCreateDate.
     * @generated
     */
    public void setXCustomerVehicleRoleAusHistCreateDate(String aXCustomerVehicleRoleAusHistCreateDate) throws Exception{
        metaDataMap.put("XCustomerVehicleRoleAusHistCreateDate", aXCustomerVehicleRoleAusHistCreateDate);

        if ((aXCustomerVehicleRoleAusHistCreateDate == null) || aXCustomerVehicleRoleAusHistCreateDate.equals("")) {
            aXCustomerVehicleRoleAusHistCreateDate = null;
        }

        eObjXCustomerVehicleRoleAus.setHistCreateDt(DWLFunctionUtils.getTimestampFromTimestampString(aXCustomerVehicleRoleAusHistCreateDate));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XCustomerVehicleRoleAusHistCreatedBy history attribute.
     *
     * @generated
     */
    public String getXCustomerVehicleRoleAusHistCreatedBy() {
        return eObjXCustomerVehicleRoleAus.getHistCreatedBy();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XCustomerVehicleRoleAusHistCreatedBy history attribute.
     *
     * @param aXCustomerVehicleRoleAusHistCreatedBy
     *     The new value of XCustomerVehicleRoleAusHistCreatedBy.
     * @generated
     */
    public void setXCustomerVehicleRoleAusHistCreatedBy(String aXCustomerVehicleRoleAusHistCreatedBy) {
        metaDataMap.put("XCustomerVehicleRoleAusHistCreatedBy", aXCustomerVehicleRoleAusHistCreatedBy);

        if ((aXCustomerVehicleRoleAusHistCreatedBy == null) || aXCustomerVehicleRoleAusHistCreatedBy.equals("")) {
            aXCustomerVehicleRoleAusHistCreatedBy = null;
        }

        eObjXCustomerVehicleRoleAus.setHistCreatedBy(aXCustomerVehicleRoleAusHistCreatedBy);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XCustomerVehicleRoleAusHistEndDate history attribute.
     *
     * @generated
     */
    public String getXCustomerVehicleRoleAusHistEndDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXCustomerVehicleRoleAus.getHistEndDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XCustomerVehicleRoleAusHistEndDate history attribute.
     *
     * @param aXCustomerVehicleRoleAusHistEndDate
     *     The new value of XCustomerVehicleRoleAusHistEndDate.
     * @generated
     */
    public void setXCustomerVehicleRoleAusHistEndDate(String aXCustomerVehicleRoleAusHistEndDate) throws Exception{
        metaDataMap.put("XCustomerVehicleRoleAusHistEndDate", aXCustomerVehicleRoleAusHistEndDate);

        if ((aXCustomerVehicleRoleAusHistEndDate == null) || aXCustomerVehicleRoleAusHistEndDate.equals("")) {
            aXCustomerVehicleRoleAusHistEndDate = null;
        }
        eObjXCustomerVehicleRoleAus.setHistEndDt(DWLFunctionUtils.getTimestampFromTimestampString(aXCustomerVehicleRoleAusHistEndDate));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XCustomerVehicleRoleAusHistoryIdPK history attribute.
     *
     * @generated
     */
    public String getXCustomerVehicleRoleAusHistoryIdPK() {
        return DWLFunctionUtils.getStringFromLong(eObjXCustomerVehicleRoleAus.getHistoryIdPK());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XCustomerVehicleRoleAusHistoryIdPK history attribute.
     *
     * @param aXCustomerVehicleRoleAusHistoryIdPK
     *     The new value of XCustomerVehicleRoleAusHistoryIdPK.
     * @generated
     */
    public void setXCustomerVehicleRoleAusHistoryIdPK(String aXCustomerVehicleRoleAusHistoryIdPK) {
        metaDataMap.put("XCustomerVehicleRoleAusHistoryIdPK", aXCustomerVehicleRoleAusHistoryIdPK);

        if ((aXCustomerVehicleRoleAusHistoryIdPK == null) || aXCustomerVehicleRoleAusHistoryIdPK.equals("")) {
            aXCustomerVehicleRoleAusHistoryIdPK = null;
        }
        eObjXCustomerVehicleRoleAus.setHistoryIdPK(DWLFunctionUtils.getLongFromString(aXCustomerVehicleRoleAusHistoryIdPK));
    }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation during an add transaction.
     *
     * @generated
     */
    public DWLStatus validateAdd(int level, DWLStatus status) throws Exception {

        status = super.validateAdd(level, status);
        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0038I Add any controller-level custom validation logic to be
            // executed for this object during an "add" transaction

        }

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            // MDM_TODO0: CDKWB0039I Add any component-level custom validation logic to be
            // executed for this object during an "add" transaction
        }
        status = getValidationStatus(level, status);
        return status;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation during an update transaction.
     *
     * @generated
     */
    public DWLStatus validateUpdate(int level, DWLStatus status) throws Exception {
    logger.finest("ENTER validateUpdate(int level, DWLStatus status)");

        status = super.validateUpdate(level, status);
        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0040I Add any controller-level custom validation logic to be
            // executed for this object during an "update" transaction

            if (eObjXCustomerVehicleRoleAus.getXCustomerRoleAuspkId() == null) {
                DWLError err = new DWLError();
                err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_ROLE_AUS_BOBJ).longValue());
                err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.XCUSTOMERVEHICLEROLEAUS_XCUSTOMERROLEAUSPKID_NULL).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                	String infoForLogging="Error: Validation error occured for update. No primary key for entity XCustomerVehicleRoleAus, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("validateUpdate(int level, DWLStatus status) " + infoForLogging);
                }
                status.addError(err);
            }
            if (eObjXCustomerVehicleRoleAus.getLastUpdateDt() == null) {
                DWLError err = new DWLError();
                err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_ROLE_AUS_BOBJ).longValue());
                err.setReasonCode(new Long(DWLUtilErrorReasonCode.LAST_UPDATED_DATE_NULL).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
                if (logger.isFinestEnabled()) {
                	String infoForLogging="Error: Validation error occured for update. No last update date for entity XCustomerVehicleRoleAus, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("validateUpdate(int level, DWLStatus status) " + infoForLogging);
                }
                status.addError(err);
            }
        }

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            assignBeforeImageValues(metaDataMap);
            
            // MDM_TODO0: CDKWB0041I Add any component-level custom validation logic to be
            // executed for this object during an "update" transaction
        }
        status = getValidationStatus(level, status);
    if (logger.isFinestEnabled()) {
        	String returnValue = status.toString();
      logger.finest("RETURN validateUpdate(int level, DWLStatus status) " + returnValue);
    }
        return status;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Populate the before image of this business object.
     *
     * @see com.dwl.base.DWLCommon#populateBeforeImage()
     * @generated
     */
    public void populateBeforeImage() throws DWLBaseException {
    logger.finest("ENTER populateBeforeImage()");

        DSEAAdditionsExts comp = null;
        try {
        
      comp = (DSEAAdditionsExts)TCRMClassFactory.getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
        	
        } catch (Exception e) {
      if (logger.isFinestEnabled()) {
        String infoForLogging="Error: Fatal error while updating record " + e.getMessage();
      logger.finest("populateBeforeImage() " + infoForLogging);
      }
            DWLExceptionUtils.throwDWLBaseException(e, 
            									new DWLUpdateException(e.getMessage()), 
            									this.getStatus(), DWLStatus.FATAL,
                                  DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_ROLE_AUS_BOBJ, 
                                  "DIERR",
                                  DSEAAdditionsExtsErrorReasonCode.XCUSTOMERVEHICLEROLEAUS_BEFORE_IMAGE_NOT_POPULATED, 
                                  this.getControl());
        }
        
        comp.loadBeforeImage(this);
    logger.finest("RETURN populateBeforeImage()");
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation common to both add and update transactions.
     *
     * @generated
     */
     
    private DWLStatus getValidationStatus(int level, DWLStatus status) throws Exception {
    logger.finest("ENTER getValidationStatus(int level, DWLStatus status)");

        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0034I Add any common controller-level custom validation
            // logic to be executed for this object during either "add" or
            // "update" transactions
    		controllerValidation_VehicleRole(status);
    		controllerValidation_VehicleRelStatus(status);
    		controllerValidation_StartDate(status);
    		controllerValidation_EndDate(status);
    		controllerValidation_SourceIdentifier(status);
    		controllerValidation_LastModifiedSystemDate(status);
    	}

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            // MDM_TODO0: CDKWB0035I Add any common component-level custom validation logic
            // to be executed for this object during either "add" or "update"
            // transactions
    		componentValidation_VehicleRole(status);
    		componentValidation_VehicleRelStatus(status);
    		componentValidation_StartDate(status);
    		componentValidation_EndDate(status);
    		componentValidation_SourceIdentifier(status);
    		componentValidation_LastModifiedSystemDate(status);
        }
        
        if (logger.isFinestEnabled()) {
            String returnValue = status.toString();
      logger.finest("RETURN getValidationStatus(int level, DWLStatus status) " + returnValue);
        }
    
        return status;
    }

    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "VehicleRole"
     *
     * @generated
     */
	private void componentValidation_VehicleRole(DWLStatus status) {
  
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "VehicleRelStatus"
     *
     * @generated
     */
	private void componentValidation_VehicleRelStatus(DWLStatus status) {
  
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "StartDate"
     *
     * @generated
     */
	private void componentValidation_StartDate(DWLStatus status) {
  
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "EndDate"
     *
     * @generated
     */
	private void componentValidation_EndDate(DWLStatus status) {
  
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "SourceIdentifier"
     *
     * @generated
     */
	private void componentValidation_SourceIdentifier(DWLStatus status) {
  
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "LastModifiedSystemDate"
     *
     * @generated
     */
	private void componentValidation_LastModifiedSystemDate(DWLStatus status) {
  
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "VehicleRole"
     *
     * @generated
     */
	private void controllerValidation_VehicleRole(DWLStatus status) throws Exception {
  
      //persistent code type
            boolean isVehicleRoleNull = false;
            if ((eObjXCustomerVehicleRoleAus.getVehicleRole() == null) &&
               ((getVehicleRoleValue() == null) || 
                 getVehicleRoleValue().trim().equals(""))) {
                isVehicleRoleNull = true;
            }
            if (!isVehicleRoleNull) {
                if (checkForInvalidXcustomervehicleroleausVehiclerole()) {
                    DWLError err = new DWLError();
                    err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_ROLE_AUS_BOBJ).longValue());
                    err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XCUSTOMERVEHICLEROLEAUS_VEHICLEROLE).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                    String infoForLogging="Error: Custom validation error occured for entity XCustomerVehicleRoleAus, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("controllerValidation_VehicleRole " + infoForLogging);
        }
                status.addError(err);
            }

             }
    			
    	}
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "VehicleRelStatus"
     *
     * @generated
     */
	private void controllerValidation_VehicleRelStatus(DWLStatus status) throws Exception {
  
      //persistent code type
            boolean isVehicleRelStatusNull = false;
            if ((eObjXCustomerVehicleRoleAus.getVehicleRelStatus() == null) &&
               ((getVehicleRelStatusValue() == null) || 
                 getVehicleRelStatusValue().trim().equals(""))) {
                isVehicleRelStatusNull = true;
            }
            if (!isVehicleRelStatusNull) {
                if (checkForInvalidXcustomervehicleroleausVehiclerelstatus()) {
                    DWLError err = new DWLError();
                    err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_ROLE_AUS_BOBJ).longValue());
                    err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XCUSTOMERVEHICLEROLEAUS_VEHICLERELSTATUS).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                    String infoForLogging="Error: Custom validation error occured for entity XCustomerVehicleRoleAus, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("controllerValidation_VehicleRelStatus " + infoForLogging);
        }
                status.addError(err);
            }

             }
    			
    	}
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "StartDate"
     *
     * @generated
     */
	private void controllerValidation_StartDate(DWLStatus status) throws Exception {
  
            boolean isStartDateNull = (eObjXCustomerVehicleRoleAus.getStartDate() == null);
            if (!isValidStartDate) {
              	DWLError err = new DWLError();
               	err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_ROLE_AUS_BOBJ).longValue());
               	err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XCUSTOMERVEHICLEROLEAUS_STARTDATE).longValue());
               	err.setErrorType(DWLErrorCode.DATA_INVALID_ERROR);
                String infoForLogging="Error: Validation error. Invalid time specified on property StartDate in entity XCustomerVehicleRoleAus, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode();
      logger.finest("controllerValidation_StartDate " + infoForLogging);
               	status.addError(err);
            } 
    	}
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "EndDate"
     *
     * @generated
     */
	private void controllerValidation_EndDate(DWLStatus status) throws Exception {
  
            boolean isEndDateNull = (eObjXCustomerVehicleRoleAus.getEndDate() == null);
            if (!isValidEndDate) {
              	DWLError err = new DWLError();
               	err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_ROLE_AUS_BOBJ).longValue());
               	err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XCUSTOMERVEHICLEROLEAUS_ENDDATE).longValue());
               	err.setErrorType(DWLErrorCode.DATA_INVALID_ERROR);
                String infoForLogging="Error: Validation error. Invalid time specified on property EndDate in entity XCustomerVehicleRoleAus, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode();
      logger.finest("controllerValidation_EndDate " + infoForLogging);
               	status.addError(err);
            } 
    	}
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "SourceIdentifier"
     *
     * @generated
     */
	private void controllerValidation_SourceIdentifier(DWLStatus status) throws Exception {
  
      //persistent code type
            boolean isSourceIdentifierNull = false;
            if ((eObjXCustomerVehicleRoleAus.getSourceIdentifier() == null) &&
               ((getSourceIdentifierValue() == null) || 
                 getSourceIdentifierValue().trim().equals(""))) {
                isSourceIdentifierNull = true;
            }
            if (!isSourceIdentifierNull) {
                if (checkForInvalidXcustomervehicleroleausSourceidentifier()) {
                    DWLError err = new DWLError();
                    err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_ROLE_AUS_BOBJ).longValue());
                    err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XCUSTOMERVEHICLEROLEAUS_SOURCEIDENTIFIER).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                    String infoForLogging="Error: Custom validation error occured for entity XCustomerVehicleRoleAus, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("controllerValidation_SourceIdentifier " + infoForLogging);
        }
                status.addError(err);
            }

             }
    			
    	}
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "LastModifiedSystemDate"
     *
     * @generated
     */
	private void controllerValidation_LastModifiedSystemDate(DWLStatus status) throws Exception {
  
            boolean isLastModifiedSystemDateNull = (eObjXCustomerVehicleRoleAus.getLastModifiedSystemDate() == null);
            if (!isValidLastModifiedSystemDate) {
              	DWLError err = new DWLError();
               	err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_ROLE_AUS_BOBJ).longValue());
               	err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XCUSTOMERVEHICLEROLEAUS_LASTMODIFIEDSYSTEMDATE).longValue());
               	err.setErrorType(DWLErrorCode.DATA_INVALID_ERROR);
                String infoForLogging="Error: Validation error. Invalid time specified on property LastModifiedSystemDate in entity XCustomerVehicleRoleAus, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode();
      logger.finest("controllerValidation_LastModifiedSystemDate " + infoForLogging);
               	status.addError(err);
            } 
    	}
    private DWLError createDWLError(String entityName, String propertyName,String reasonCode){	
		DWLError err = new DWLError();
		err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_ROLE_AUS_BOBJ).longValue());
		err.setReasonCode(new Long(reasonCode).longValue());
		err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
			String infoForLogging="Error: Validation error occured. Property " + propertyName + " is null, in entity " + entityName + ", component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
			logger.finest("createDWLError " + infoForLogging);
		}
		return err;
    }
    
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Check the value of the field VehicleRole and return true if the error
     * reason INVALID_XCUSTOMERVEHICLEROLEAUS_VEHICLEROLE should be returned.
     *
     * @generated
  **/
	private boolean checkForInvalidXcustomervehicleroleausVehiclerole() throws Exception {
    logger.finest("ENTER checkForInvalidXcustomervehicleroleausVehiclerole()");
        boolean notValid = false;
      	String langId = (String) this.getControl().get(DWLControlKeys.LANG_ID);
      	CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
    Long codeType = DWLFunctionUtils.getLongFromString( getVehicleRoleType() );
    String codeValue = getVehicleRoleValue();
    if( codeValue != null && codeValue.trim().equals("")){
      codeValue = null;
    }
     
        if ( codeType != null && codeValue == null ){

             if( codeTypeCompHelper.isCodeValid("xcdvehicleroletp", langId, getVehicleRoleType(),
                 CodeTypeComponentHelper.ACTIVE, getControl())) {
                 CodeTypeBObj ctBObj = codeTypeCompHelper
                 					.getCodeTypeByCode("xcdvehicleroletp", langId, getVehicleRoleType(),
                         								getControl());
               	if (ctBObj != null) {
                   	setVehicleRoleValue( ctBObj.getvalue() );
               	}
             }
             else{
             	if (logger.isFinestEnabled()) {
              	 	String infoForLogging="NotValid 1";
      logger.finest("checkForInvalidXcustomervehicleroleausVehiclerole() " + infoForLogging);
        }
                 notValid = true;
           }
        }
        else if (codeType == null && codeValue != null ){
          
             CodeTypeBObj ctBObj = codeTypeCompHelper
                      .getCodeTypeByValue("xcdvehicleroletp", langId, codeValue,
                                 getControl());

             if (ctBObj != null) {
                 setVehicleRoleType(ctBObj.gettp_cd());
             } 
             else {
             	if (logger.isFinestEnabled()) {
              	  	String infoForLogging="NotValid 2";
      logger.finest("checkForInvalidXcustomervehicleroleausVehiclerole() " + infoForLogging);
        }
                  notValid = true;
             }
        }
        else if ( codeType != null && codeValue != null
             && !codeTypeCompHelper.isCodeValuePairValid("xcdvehicleroletp", langId, getVehicleRoleType(), 
                     new String[] { codeValue }, CodeTypeComponentHelper.ACTIVE, getControl())) {	
       if (logger.isFinestEnabled()) {
       		String infoForLogging="NotValid 3";
      logger.finest("checkForInvalidXcustomervehicleroleausVehiclerole() " + infoForLogging);
       }
             notValid = true;
        }
        if (logger.isFinestEnabled()) {
      String returnValue ="" +notValid;
      logger.finest("RETURN checkForInvalidXcustomervehicleroleausVehiclerole() " + returnValue);
    }
    return notValid;
     } 
				 
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Check the value of the field VehicleRelStatus and return true if the
     * error reason INVALID_XCUSTOMERVEHICLEROLEAUS_VEHICLERELSTATUS should be
     * returned.
     *
     * @generated
  **/
	private boolean checkForInvalidXcustomervehicleroleausVehiclerelstatus() throws Exception {
    logger.finest("ENTER checkForInvalidXcustomervehicleroleausVehiclerelstatus()");
        boolean notValid = false;
      	String langId = (String) this.getControl().get(DWLControlKeys.LANG_ID);
      	CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
    Long codeType = DWLFunctionUtils.getLongFromString( getVehicleRelStatusType() );
    String codeValue = getVehicleRelStatusValue();
    if( codeValue != null && codeValue.trim().equals("")){
      codeValue = null;
    }
     
        if ( codeType != null && codeValue == null ){

             if( codeTypeCompHelper.isCodeValid("xcdvehiclerelstatustp", langId, getVehicleRelStatusType(),
                 CodeTypeComponentHelper.ACTIVE, getControl())) {
                 CodeTypeBObj ctBObj = codeTypeCompHelper
                 					.getCodeTypeByCode("xcdvehiclerelstatustp", langId, getVehicleRelStatusType(),
                         								getControl());
               	if (ctBObj != null) {
                   	setVehicleRelStatusValue( ctBObj.getvalue() );
               	}
             }
             else{
             	if (logger.isFinestEnabled()) {
              	 	String infoForLogging="NotValid 1";
      logger.finest("checkForInvalidXcustomervehicleroleausVehiclerelstatus() " + infoForLogging);
        }
                 notValid = true;
           }
        }
        else if (codeType == null && codeValue != null ){
          
             CodeTypeBObj ctBObj = codeTypeCompHelper
                      .getCodeTypeByValue("xcdvehiclerelstatustp", langId, codeValue,
                                 getControl());

             if (ctBObj != null) {
                 setVehicleRelStatusType(ctBObj.gettp_cd());
             } 
             else {
             	if (logger.isFinestEnabled()) {
              	  	String infoForLogging="NotValid 2";
      logger.finest("checkForInvalidXcustomervehicleroleausVehiclerelstatus() " + infoForLogging);
        }
                  notValid = true;
             }
        }
        else if ( codeType != null && codeValue != null
             && !codeTypeCompHelper.isCodeValuePairValid("xcdvehiclerelstatustp", langId, getVehicleRelStatusType(), 
                     new String[] { codeValue }, CodeTypeComponentHelper.ACTIVE, getControl())) {	
       if (logger.isFinestEnabled()) {
       		String infoForLogging="NotValid 3";
      logger.finest("checkForInvalidXcustomervehicleroleausVehiclerelstatus() " + infoForLogging);
       }
             notValid = true;
        }
        if (logger.isFinestEnabled()) {
      String returnValue ="" +notValid;
      logger.finest("RETURN checkForInvalidXcustomervehicleroleausVehiclerelstatus() " + returnValue);
    }
    return notValid;
     } 
				 
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Check the value of the field SourceIdentifier and return true if the
     * error reason INVALID_XCUSTOMERVEHICLEROLEAUS_SOURCEIDENTIFIER should be
     * returned.
     *
     * @generated
  **/
	private boolean checkForInvalidXcustomervehicleroleausSourceidentifier() throws Exception {
    logger.finest("ENTER checkForInvalidXcustomervehicleroleausSourceidentifier()");
        boolean notValid = false;
      	String langId = (String) this.getControl().get(DWLControlKeys.LANG_ID);
      	CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
    Long codeType = DWLFunctionUtils.getLongFromString( getSourceIdentifierType() );
    String codeValue = getSourceIdentifierValue();
    if( codeValue != null && codeValue.trim().equals("")){
      codeValue = null;
    }
     
        if ( codeType != null && codeValue == null ){

             if( codeTypeCompHelper.isCodeValid("cdsourceidenttp", langId, getSourceIdentifierType(),
                 CodeTypeComponentHelper.ACTIVE, getControl())) {
                 CodeTypeBObj ctBObj = codeTypeCompHelper
                 					.getCodeTypeByCode("cdsourceidenttp", langId, getSourceIdentifierType(),
                         								getControl());
               	if (ctBObj != null) {
                   	setSourceIdentifierValue( ctBObj.getvalue() );
               	}
             }
             else{
             	if (logger.isFinestEnabled()) {
              	 	String infoForLogging="NotValid 1";
      logger.finest("checkForInvalidXcustomervehicleroleausSourceidentifier() " + infoForLogging);
        }
                 notValid = true;
           }
        }
        else if (codeType == null && codeValue != null ){
          
             CodeTypeBObj ctBObj = codeTypeCompHelper
                      .getCodeTypeByValue("cdsourceidenttp", langId, codeValue,
                                 getControl());

             if (ctBObj != null) {
                 setSourceIdentifierType(ctBObj.gettp_cd());
             } 
             else {
             	if (logger.isFinestEnabled()) {
              	  	String infoForLogging="NotValid 2";
      logger.finest("checkForInvalidXcustomervehicleroleausSourceidentifier() " + infoForLogging);
        }
                  notValid = true;
             }
        }
        else if ( codeType != null && codeValue != null
             && !codeTypeCompHelper.isCodeValuePairValid("cdsourceidenttp", langId, getSourceIdentifierType(), 
                     new String[] { codeValue }, CodeTypeComponentHelper.ACTIVE, getControl())) {	
       if (logger.isFinestEnabled()) {
       		String infoForLogging="NotValid 3";
      logger.finest("checkForInvalidXcustomervehicleroleausSourceidentifier() " + infoForLogging);
       }
             notValid = true;
        }
        if (logger.isFinestEnabled()) {
      String returnValue ="" +notValid;
      logger.finest("RETURN checkForInvalidXcustomervehicleroleausSourceidentifier() " + returnValue);
    }
    return notValid;
     } 
				 



}

