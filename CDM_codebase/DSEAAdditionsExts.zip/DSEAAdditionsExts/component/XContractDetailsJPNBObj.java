
/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[450d43e3ea0b95f0b36b5e3bcf6977a7]
 */

package com.ibm.daimler.dsea.component;

import com.dwl.tcrm.common.TCRMCommon;



import com.dwl.base.DWLControl;

import com.dwl.base.constant.DWLControlKeys;
import com.dwl.base.constant.DWLUtilErrorReasonCode;

import com.dwl.base.error.DWLError;
import com.dwl.base.error.DWLErrorCode;
import com.dwl.base.error.DWLStatus;

import com.dwl.base.exception.DWLBaseException;
import com.dwl.base.exception.DWLUpdateException;

import com.dwl.base.util.DWLClassFactory;
import com.dwl.base.util.DWLExceptionUtils;
import com.dwl.base.util.DWLFunctionUtils;

import com.dwl.management.config.client.Configuration;

import com.dwl.tcrm.common.ITCRMValidation;

import com.dwl.tcrm.utilities.DateFormatter;
import com.dwl.tcrm.utilities.DateValidator;
import com.dwl.tcrm.utilities.TCRMClassFactory;

import com.ibm.daimler.dsea.component.FinanceContractorDetailsJPNBObj;
import com.ibm.daimler.dsea.component.GuarantorDetailsJPNBObj;

import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsComponentID;
import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsErrorReasonCode;
import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsPropertyKeys;

import com.ibm.daimler.dsea.entityObject.EObjXContractDetailsJPN;

import com.ibm.daimler.dsea.interfaces.DSEAAdditionsExts;

import com.ibm.mdm.common.codetype.interfaces.CodeTypeComponentHelper;

import com.ibm.mdm.common.codetype.obj.CodeTypeBObj;

import java.util.Vector;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * This class provides the implementation of the business object
 * <code>XContractDetailsJPNBObj</code>.
 * 
 * @see com.dwl.tcrm.common.TCRMCommon
 * @generated
 */
 

@SuppressWarnings("serial")
public class XContractDetailsJPNBObj extends TCRMCommon  {

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected EObjXContractDetailsJPN eObjXContractDetailsJPN;
	/**
    * <!-- begin-user-doc -->
	  * <!-- end-user-doc -->
    * @generated 
    */
	 private final static com.dwl.base.logging.IDWLLogger logger = com.dwl.base.logging.DWLLoggerManager.getLogger(XContractDetailsJPNBObj.class);
		
 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected String contractStatusValue;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected String sourceIdentifierValue;
	protected boolean isValidStartDate = true;
	
	protected boolean isValidEndDate = true;
	
	protected boolean isValidLastModifiedSystemDate = true;
	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    @SuppressWarnings("rawtypes")
    protected Vector vecGuarantorDetailsJPNBObj;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected FinanceContractorDetailsJPNBObj FinanceContractorDetailsJPNBObj;


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */     
    @SuppressWarnings("rawtypes")
    public XContractDetailsJPNBObj() {
        super();
        init();
        eObjXContractDetailsJPN = new EObjXContractDetailsJPN();
        vecGuarantorDetailsJPNBObj = new Vector();
        setComponentID(DSEAAdditionsExtsComponentID.XCONTRACT_DETAILS_JPNBOBJ);
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Initializes the fields required to populate the metaDataMap. Each key is
     * an element-level field of the business object.
     *
     * @generated
     */
    private void init() {
        metaDataMap.put("XContractJPNpkId", null);
        metaDataMap.put("ContId", null);
        metaDataMap.put("FinanceProduct", null);
        metaDataMap.put("ContractNumber", null);
        metaDataMap.put("ContractStatusType", null);
        metaDataMap.put("ContractStatusValue", null);
        metaDataMap.put("MarketName", null);
        metaDataMap.put("GlobalVIN", null);
        metaDataMap.put("SourceIdentifierType", null);
        metaDataMap.put("SourceIdentifierValue", null);
        metaDataMap.put("StartDate", null);
        metaDataMap.put("EndDate", null);
        metaDataMap.put("LastModifiedSystemDate", null);
        metaDataMap.put("SFDCId", null);
        metaDataMap.put("BatchInd", null);
        metaDataMap.put("XContractDetailsJPNHistActionCode", null);
        metaDataMap.put("XContractDetailsJPNHistCreateDate", null);
        metaDataMap.put("XContractDetailsJPNHistCreatedBy", null);
        metaDataMap.put("XContractDetailsJPNHistEndDate", null);
        metaDataMap.put("XContractDetailsJPNHistoryIdPK", null);
        metaDataMap.put("XContractDetailsJPNLastUpdateDate", null);
        metaDataMap.put("XContractDetailsJPNLastUpdateTxId", null);
        metaDataMap.put("XContractDetailsJPNLastUpdateUser", null);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Refreshes all the attributes this business object supports.
     *
     * @see com.dwl.base.DWLCommon#refreshMap()
     * @generated
     */
    public void refreshMap() {

        if (bRequireMapRefresh) {
            super.refreshMap();
            metaDataMap.put("XContractJPNpkId", getXContractJPNpkId());
            metaDataMap.put("ContId", getContId());
            metaDataMap.put("FinanceProduct", getFinanceProduct());
            metaDataMap.put("ContractNumber", getContractNumber());
            metaDataMap.put("ContractStatusType", getContractStatusType());
            metaDataMap.put("ContractStatusValue", getContractStatusValue());
            metaDataMap.put("MarketName", getMarketName());
            metaDataMap.put("GlobalVIN", getGlobalVIN());
            metaDataMap.put("SourceIdentifierType", getSourceIdentifierType());
            metaDataMap.put("SourceIdentifierValue", getSourceIdentifierValue());
            metaDataMap.put("StartDate", getStartDate());
            metaDataMap.put("EndDate", getEndDate());
            metaDataMap.put("LastModifiedSystemDate", getLastModifiedSystemDate());
            metaDataMap.put("SFDCId", getSFDCId());
            metaDataMap.put("BatchInd", getBatchInd());
            metaDataMap.put("XContractDetailsJPNHistActionCode", getXContractDetailsJPNHistActionCode());
            metaDataMap.put("XContractDetailsJPNHistCreateDate", getXContractDetailsJPNHistCreateDate());
            metaDataMap.put("XContractDetailsJPNHistCreatedBy", getXContractDetailsJPNHistCreatedBy());
            metaDataMap.put("XContractDetailsJPNHistEndDate", getXContractDetailsJPNHistEndDate());
            metaDataMap.put("XContractDetailsJPNHistoryIdPK", getXContractDetailsJPNHistoryIdPK());
            metaDataMap.put("XContractDetailsJPNLastUpdateDate", getXContractDetailsJPNLastUpdateDate());
            metaDataMap.put("XContractDetailsJPNLastUpdateTxId", getXContractDetailsJPNLastUpdateTxId());
            metaDataMap.put("XContractDetailsJPNLastUpdateUser", getXContractDetailsJPNLastUpdateUser());
            bRequireMapRefresh = false;
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the control object on this business object.
     *
     * @see com.dwl.base.DWLCommon#setControl(DWLControl)
     * @generated
     */
    public void setControl(DWLControl newDWLControl) {
        super.setControl(newDWLControl);

        if (eObjXContractDetailsJPN != null) {
            eObjXContractDetailsJPN.setControl(newDWLControl);
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the entity object associated with this business object.
     *
     * @generated
     */
    public EObjXContractDetailsJPN getEObjXContractDetailsJPN() {
        bRequireMapRefresh = true;
        return eObjXContractDetailsJPN;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the entity object associated with this business object.
     *
     * @param eObjXContractDetailsJPN
     *            The eObjXContractDetailsJPN to set.
     * @generated
     */
    public void setEObjXContractDetailsJPN(EObjXContractDetailsJPN eObjXContractDetailsJPN) {
        bRequireMapRefresh = true;
        this.eObjXContractDetailsJPN = eObjXContractDetailsJPN;
        if (this.eObjXContractDetailsJPN != null && this.eObjXContractDetailsJPN.getControl() == null) {
            DWLControl control = this.getControl();
            if (control != null) {
                this.eObjXContractDetailsJPN.setControl(control);
            }
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xContractJPNpkId attribute.
     * 
     * ContractpkId
     * 
     * @generated
     */
    public String getXContractJPNpkId (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXContractDetailsJPN.getXContractJPNpkId());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xContractJPNpkId attribute.
     * 
     * ContractpkId
     * 
     * @param newXContractJPNpkId
     *     The new value of xContractJPNpkId.
     * @generated
     */
    public void setXContractJPNpkId( String newXContractJPNpkId ) throws Exception {
        metaDataMap.put("XContractJPNpkId", newXContractJPNpkId);

        if (newXContractJPNpkId == null || newXContractJPNpkId.equals("")) {
            newXContractJPNpkId = null;


        }
        eObjXContractDetailsJPN.setXContractJPNpkId( DWLFunctionUtils.getLongFromString(newXContractJPNpkId) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the contId attribute.
     * 
     * @generated
     */
    public String getContId (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXContractDetailsJPN.getContId());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the contId attribute.
     * 
     * @param newContId
     *     The new value of contId.
     * @generated
     */
    public void setContId( String newContId ) throws Exception {
        metaDataMap.put("ContId", newContId);

        if (newContId == null || newContId.equals("")) {
            newContId = null;


        }
        eObjXContractDetailsJPN.setContId( DWLFunctionUtils.getLongFromString(newContId) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the financeProduct attribute.
     * 
     * @generated
     */
    public String getFinanceProduct (){
   
        return eObjXContractDetailsJPN.getFinanceProduct();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the financeProduct attribute.
     * 
     * @param newFinanceProduct
     *     The new value of financeProduct.
     * @generated
     */
    public void setFinanceProduct( String newFinanceProduct ) throws Exception {
        metaDataMap.put("FinanceProduct", newFinanceProduct);

        if (newFinanceProduct == null || newFinanceProduct.equals("")) {
            newFinanceProduct = null;


        }
        eObjXContractDetailsJPN.setFinanceProduct( newFinanceProduct );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the contractNumber attribute.
     * 
     * @generated
     */
    public String getContractNumber (){
   
        return eObjXContractDetailsJPN.getContractNumber();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the contractNumber attribute.
     * 
     * @param newContractNumber
     *     The new value of contractNumber.
     * @generated
     */
    public void setContractNumber( String newContractNumber ) throws Exception {
        metaDataMap.put("ContractNumber", newContractNumber);

        if (newContractNumber == null || newContractNumber.equals("")) {
            newContractNumber = null;


        }
        eObjXContractDetailsJPN.setContractNumber( newContractNumber );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the contractStatusType attribute.
     * 
     * @generated
     */
    public String getContractStatusType (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXContractDetailsJPN.getContractStatus());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the contractStatusType attribute.
     * 
     * @param newContractStatusType
     *     The new value of contractStatusType.
     * @generated
     */
    public void setContractStatusType( String newContractStatusType ) throws Exception {
        metaDataMap.put("ContractStatusType", newContractStatusType);

        if (newContractStatusType == null || newContractStatusType.equals("")) {
            newContractStatusType = null;


        }
        eObjXContractDetailsJPN.setContractStatus( DWLFunctionUtils.getLongFromString(newContractStatusType) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the contractStatusValue attribute.
     * 
     * @generated
     */
    public String getContractStatusValue (){
      return contractStatusValue;
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the contractStatusValue attribute.
     * 
     * @param newContractStatusValue
     *     The new value of contractStatusValue.
     * @generated
     */
    public void setContractStatusValue( String newContractStatusValue ) throws Exception {
        metaDataMap.put("ContractStatusValue", newContractStatusValue);

        if (newContractStatusValue == null || newContractStatusValue.equals("")) {
            newContractStatusValue = null;


        }
        contractStatusValue = newContractStatusValue;
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the marketName attribute.
     * 
     * @generated
     */
    public String getMarketName (){
   
        return eObjXContractDetailsJPN.getMarketName();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the marketName attribute.
     * 
     * @param newMarketName
     *     The new value of marketName.
     * @generated
     */
    public void setMarketName( String newMarketName ) throws Exception {
        metaDataMap.put("MarketName", newMarketName);

        if (newMarketName == null || newMarketName.equals("")) {
            newMarketName = null;


        }
        eObjXContractDetailsJPN.setMarketName( newMarketName );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the globalVIN attribute.
     * 
     * @generated
     */
    public String getGlobalVIN (){
   
        return eObjXContractDetailsJPN.getGlobalVIN();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the globalVIN attribute.
     * 
     * @param newGlobalVIN
     *     The new value of globalVIN.
     * @generated
     */
    public void setGlobalVIN( String newGlobalVIN ) throws Exception {
        metaDataMap.put("GlobalVIN", newGlobalVIN);

        if (newGlobalVIN == null || newGlobalVIN.equals("")) {
            newGlobalVIN = null;


        }
        eObjXContractDetailsJPN.setGlobalVIN( newGlobalVIN );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the sourceIdentifierType attribute.
     * 
     * @generated
     */
    public String getSourceIdentifierType (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXContractDetailsJPN.getSourceIdentifier());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the sourceIdentifierType attribute.
     * 
     * @param newSourceIdentifierType
     *     The new value of sourceIdentifierType.
     * @generated
     */
    public void setSourceIdentifierType( String newSourceIdentifierType ) throws Exception {
        metaDataMap.put("SourceIdentifierType", newSourceIdentifierType);

        if (newSourceIdentifierType == null || newSourceIdentifierType.equals("")) {
            newSourceIdentifierType = null;


        }
        eObjXContractDetailsJPN.setSourceIdentifier( DWLFunctionUtils.getLongFromString(newSourceIdentifierType) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the sourceIdentifierValue attribute.
     * 
     * @generated
     */
    public String getSourceIdentifierValue (){
      return sourceIdentifierValue;
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the sourceIdentifierValue attribute.
     * 
     * @param newSourceIdentifierValue
     *     The new value of sourceIdentifierValue.
     * @generated
     */
    public void setSourceIdentifierValue( String newSourceIdentifierValue ) throws Exception {
        metaDataMap.put("SourceIdentifierValue", newSourceIdentifierValue);

        if (newSourceIdentifierValue == null || newSourceIdentifierValue.equals("")) {
            newSourceIdentifierValue = null;


        }
        sourceIdentifierValue = newSourceIdentifierValue;
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the startDate attribute.
     * 
     * @generated
     */
    public String getStartDate (){
   
        return DWLFunctionUtils.getStringFromTimestamp(eObjXContractDetailsJPN.getStartDate());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the startDate attribute.
     * 
     * @param newStartDate
     *     The new value of startDate.
     * @generated
     */
    public void setStartDate( String newStartDate ) throws Exception {
        metaDataMap.put("StartDate", newStartDate);
       	isValidStartDate = true;

        if (newStartDate == null || newStartDate.equals("")) {
            newStartDate = null;
            eObjXContractDetailsJPN.setStartDate(null);


        }
    else {
        	if (DateValidator.validates(newStartDate)) {
           		eObjXContractDetailsJPN.setStartDate(DateFormatter.getStartDateTimestamp(newStartDate));
            	metaDataMap.put("StartDate", getStartDate());
        	} else {
            	if (Configuration.getConfiguration().getConfigItem(
              "/IBM/DWLCommonServices/InternalValidation/enabled").getBooleanValue()) {
                	if (metaDataMap.get("StartDate") != null) {
                    	metaDataMap.put("StartDate", "");
                	}
                	isValidStartDate = false;
                	eObjXContractDetailsJPN.setStartDate(null);
            	}
        	}
        }
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the endDate attribute.
     * 
     * @generated
     */
    public String getEndDate (){
   
        return DWLFunctionUtils.getStringFromTimestamp(eObjXContractDetailsJPN.getEndDate());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the endDate attribute.
     * 
     * @param newEndDate
     *     The new value of endDate.
     * @generated
     */
    public void setEndDate( String newEndDate ) throws Exception {
        metaDataMap.put("EndDate", newEndDate);
       	isValidEndDate = true;

        if (newEndDate == null || newEndDate.equals("")) {
            newEndDate = null;
            eObjXContractDetailsJPN.setEndDate(null);


        }
    else {
        	if (DateValidator.validates(newEndDate)) {
           		eObjXContractDetailsJPN.setEndDate(DateFormatter.getStartDateTimestamp(newEndDate));
            	metaDataMap.put("EndDate", getEndDate());
        	} else {
            	if (Configuration.getConfiguration().getConfigItem(
              "/IBM/DWLCommonServices/InternalValidation/enabled").getBooleanValue()) {
                	if (metaDataMap.get("EndDate") != null) {
                    	metaDataMap.put("EndDate", "");
                	}
                	isValidEndDate = false;
                	eObjXContractDetailsJPN.setEndDate(null);
            	}
        	}
        }
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the lastModifiedSystemDate attribute.
     * 
     * @generated
     */
    public String getLastModifiedSystemDate (){
   
        return DWLFunctionUtils.getStringFromTimestamp(eObjXContractDetailsJPN.getLastModifiedSystemDate());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the lastModifiedSystemDate attribute.
     * 
     * @param newLastModifiedSystemDate
     *     The new value of lastModifiedSystemDate.
     * @generated
     */
    public void setLastModifiedSystemDate( String newLastModifiedSystemDate ) throws Exception {
        metaDataMap.put("LastModifiedSystemDate", newLastModifiedSystemDate);
       	isValidLastModifiedSystemDate = true;

        if (newLastModifiedSystemDate == null || newLastModifiedSystemDate.equals("")) {
            newLastModifiedSystemDate = null;
            eObjXContractDetailsJPN.setLastModifiedSystemDate(null);


        }
    else {
        	if (DateValidator.validates(newLastModifiedSystemDate)) {
           		eObjXContractDetailsJPN.setLastModifiedSystemDate(DateFormatter.getStartDateTimestamp(newLastModifiedSystemDate));
            	metaDataMap.put("LastModifiedSystemDate", getLastModifiedSystemDate());
        	} else {
            	if (Configuration.getConfiguration().getConfigItem(
              "/IBM/DWLCommonServices/InternalValidation/enabled").getBooleanValue()) {
                	if (metaDataMap.get("LastModifiedSystemDate") != null) {
                    	metaDataMap.put("LastModifiedSystemDate", "");
                	}
                	isValidLastModifiedSystemDate = false;
                	eObjXContractDetailsJPN.setLastModifiedSystemDate(null);
            	}
        	}
        }
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the sFDCId attribute.
     * 
     * @generated
     */
    public String getSFDCId (){
   
        return eObjXContractDetailsJPN.getSFDCId();
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the sFDCId attribute.
     * 
     * @param newSFDCId
     *     The new value of sFDCId.
     * @generated
     */
    public void setSFDCId( String newSFDCId ) throws Exception {
        metaDataMap.put("SFDCId", newSFDCId);

        if (newSFDCId == null || newSFDCId.equals("")) {
            newSFDCId = null;


        }
        eObjXContractDetailsJPN.setSFDCId( newSFDCId );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the batchInd attribute.
     * 
     * @generated
     */
    public String getBatchInd (){
   
        return eObjXContractDetailsJPN.getBatchInd();
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the batchInd attribute.
     * 
     * @param newBatchInd
     *     The new value of batchInd.
     * @generated
     */
    public void setBatchInd( String newBatchInd ) throws Exception {
        metaDataMap.put("BatchInd", newBatchInd);

        if (newBatchInd == null || newBatchInd.equals("")) {
            newBatchInd = null;


        }
        eObjXContractDetailsJPN.setBatchInd( newBatchInd );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the GuarantorDetailsJPNBObj attribute.
     * 
     * @generated
     */
    @SuppressWarnings("rawtypes")
    public Vector getItemsGuarantorDetailsJPNBObj (){
      return vecGuarantorDetailsJPNBObj;
    }
    
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    @SuppressWarnings("unchecked")
    public void setGuarantorDetailsJPNBObj(GuarantorDetailsJPNBObj newBObj ) {
        vecGuarantorDetailsJPNBObj.addElement( newBObj );
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the FinanceContractorDetailsJPNBObj attribute.
     * 
     * @generated
     */
    public FinanceContractorDetailsJPNBObj getFinanceContractorDetailsJPNBObj (){
      return FinanceContractorDetailsJPNBObj;
    }
    
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public void setFinanceContractorDetailsJPNBObj(FinanceContractorDetailsJPNBObj newBObj ) {
    FinanceContractorDetailsJPNBObj = newBObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateTxId attribute.
     *
     * @generated
     */
    public String getXContractDetailsJPNLastUpdateTxId() {
        return DWLFunctionUtils.getStringFromLong(eObjXContractDetailsJPN.getLastUpdateTxId());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateUser attribute.
     *
     * @generated
     */
    public String getXContractDetailsJPNLastUpdateUser() {
        return eObjXContractDetailsJPN.getLastUpdateUser();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateDt attribute.
     *
     * @generated
     */
    public String getXContractDetailsJPNLastUpdateDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXContractDetailsJPN.getLastUpdateDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateTxId attribute.
     *
     * @param newLastUpdateTxId
     *     The new value of LastUpdateTxId.
     * @generated
     */
    public void setXContractDetailsJPNLastUpdateTxId(String newLastUpdateTxId) {
        metaDataMap.put("XContractDetailsJPNLastUpdateTxId", newLastUpdateTxId);

        if ((newLastUpdateTxId == null) || newLastUpdateTxId.equals("")) {
            newLastUpdateTxId = null;
        }
        eObjXContractDetailsJPN.setLastUpdateTxId(DWLFunctionUtils.getLongFromString(newLastUpdateTxId));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateUser attribute.
     *
     * @param newLastUpdateUser
     *     The new value of LastUpdateUser.
     * @generated
     */
    public void setXContractDetailsJPNLastUpdateUser(String newLastUpdateUser) {
        metaDataMap.put("XContractDetailsJPNLastUpdateUser", newLastUpdateUser);

        if ((newLastUpdateUser == null) || newLastUpdateUser.equals("")) {
            newLastUpdateUser = null;
        }
        eObjXContractDetailsJPN.setLastUpdateUser(newLastUpdateUser);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateDt attribute.
     *
     * @param newLastUpdateDt
     *     The new value of LastUpdateDt.
     * @throws Exception
     * @generated
     */
    public void setXContractDetailsJPNLastUpdateDate(String newLastUpdateDt) throws Exception {
        metaDataMap.put("XContractDetailsJPNLastUpdateDate", newLastUpdateDt);

        if ((newLastUpdateDt == null) || newLastUpdateDt.equals("")) {
            newLastUpdateDt = null;
        }

        eObjXContractDetailsJPN.setLastUpdateDt(DWLFunctionUtils.getTimestampFromTimestampString(newLastUpdateDt));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XContractDetailsJPNHistActionCode history attribute.
     *
     * @generated
     */
    public String getXContractDetailsJPNHistActionCode() {
        return eObjXContractDetailsJPN.getHistActionCode();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XContractDetailsJPNHistActionCode history attribute.
     *
     * @param aXContractDetailsJPNHistActionCode
     *     The new value of XContractDetailsJPNHistActionCode.
     * @generated
     */
    public void setXContractDetailsJPNHistActionCode(String aXContractDetailsJPNHistActionCode) {
        metaDataMap.put("XContractDetailsJPNHistActionCode", aXContractDetailsJPNHistActionCode);

        if ((aXContractDetailsJPNHistActionCode == null) || aXContractDetailsJPNHistActionCode.equals("")) {
            aXContractDetailsJPNHistActionCode = null;
        }
        eObjXContractDetailsJPN.setHistActionCode(aXContractDetailsJPNHistActionCode);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XContractDetailsJPNHistCreateDate history attribute.
     *
     * @generated
     */
    public String getXContractDetailsJPNHistCreateDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXContractDetailsJPN.getHistCreateDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XContractDetailsJPNHistCreateDate history attribute.
     *
     * @param aXContractDetailsJPNHistCreateDate
     *     The new value of XContractDetailsJPNHistCreateDate.
     * @generated
     */
    public void setXContractDetailsJPNHistCreateDate(String aXContractDetailsJPNHistCreateDate) throws Exception{
        metaDataMap.put("XContractDetailsJPNHistCreateDate", aXContractDetailsJPNHistCreateDate);

        if ((aXContractDetailsJPNHistCreateDate == null) || aXContractDetailsJPNHistCreateDate.equals("")) {
            aXContractDetailsJPNHistCreateDate = null;
        }

        eObjXContractDetailsJPN.setHistCreateDt(DWLFunctionUtils.getTimestampFromTimestampString(aXContractDetailsJPNHistCreateDate));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XContractDetailsJPNHistCreatedBy history attribute.
     *
     * @generated
     */
    public String getXContractDetailsJPNHistCreatedBy() {
        return eObjXContractDetailsJPN.getHistCreatedBy();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XContractDetailsJPNHistCreatedBy history attribute.
     *
     * @param aXContractDetailsJPNHistCreatedBy
     *     The new value of XContractDetailsJPNHistCreatedBy.
     * @generated
     */
    public void setXContractDetailsJPNHistCreatedBy(String aXContractDetailsJPNHistCreatedBy) {
        metaDataMap.put("XContractDetailsJPNHistCreatedBy", aXContractDetailsJPNHistCreatedBy);

        if ((aXContractDetailsJPNHistCreatedBy == null) || aXContractDetailsJPNHistCreatedBy.equals("")) {
            aXContractDetailsJPNHistCreatedBy = null;
        }

        eObjXContractDetailsJPN.setHistCreatedBy(aXContractDetailsJPNHistCreatedBy);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XContractDetailsJPNHistEndDate history attribute.
     *
     * @generated
     */
    public String getXContractDetailsJPNHistEndDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXContractDetailsJPN.getHistEndDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XContractDetailsJPNHistEndDate history attribute.
     *
     * @param aXContractDetailsJPNHistEndDate
     *     The new value of XContractDetailsJPNHistEndDate.
     * @generated
     */
    public void setXContractDetailsJPNHistEndDate(String aXContractDetailsJPNHistEndDate) throws Exception{
        metaDataMap.put("XContractDetailsJPNHistEndDate", aXContractDetailsJPNHistEndDate);

        if ((aXContractDetailsJPNHistEndDate == null) || aXContractDetailsJPNHistEndDate.equals("")) {
            aXContractDetailsJPNHistEndDate = null;
        }
        eObjXContractDetailsJPN.setHistEndDt(DWLFunctionUtils.getTimestampFromTimestampString(aXContractDetailsJPNHistEndDate));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XContractDetailsJPNHistoryIdPK history attribute.
     *
     * @generated
     */
    public String getXContractDetailsJPNHistoryIdPK() {
        return DWLFunctionUtils.getStringFromLong(eObjXContractDetailsJPN.getHistoryIdPK());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XContractDetailsJPNHistoryIdPK history attribute.
     *
     * @param aXContractDetailsJPNHistoryIdPK
     *     The new value of XContractDetailsJPNHistoryIdPK.
     * @generated
     */
    public void setXContractDetailsJPNHistoryIdPK(String aXContractDetailsJPNHistoryIdPK) {
        metaDataMap.put("XContractDetailsJPNHistoryIdPK", aXContractDetailsJPNHistoryIdPK);

        if ((aXContractDetailsJPNHistoryIdPK == null) || aXContractDetailsJPNHistoryIdPK.equals("")) {
            aXContractDetailsJPNHistoryIdPK = null;
        }
        eObjXContractDetailsJPN.setHistoryIdPK(DWLFunctionUtils.getLongFromString(aXContractDetailsJPNHistoryIdPK));
    }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation during an add transaction.
     *
     * @generated
     */
    public DWLStatus validateAdd(int level, DWLStatus status) throws Exception {

        status = super.validateAdd(level, status);
        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0038I Add any controller-level custom validation logic to be
            // executed for this object during an "add" transaction


            for (int i = 0; i < getItemsGuarantorDetailsJPNBObj().size(); i++) {
                GuarantorDetailsJPNBObj guarantorDetailsJPN = (GuarantorDetailsJPNBObj) getItemsGuarantorDetailsJPNBObj().elementAt(i);
                status = guarantorDetailsJPN.validateAdd(level, status);
            }

            FinanceContractorDetailsJPNBObj financeContractorDetailsJPN = getFinanceContractorDetailsJPNBObj();
            if( financeContractorDetailsJPN != null ){
            	status = financeContractorDetailsJPN.validateAdd(level, status);
            }
        }

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            // MDM_TODO0: CDKWB0039I Add any component-level custom validation logic to be
            // executed for this object during an "add" transaction
        }
        status = getValidationStatus(level, status);
        return status;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation during an update transaction.
     *
     * @generated
     */
    public DWLStatus validateUpdate(int level, DWLStatus status) throws Exception {
    logger.finest("ENTER validateUpdate(int level, DWLStatus status)");

        status = super.validateUpdate(level, status);
        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0040I Add any controller-level custom validation logic to be
            // executed for this object during an "update" transaction

            if (eObjXContractDetailsJPN.getXContractJPNpkId() == null) {
                DWLError err = new DWLError();
                err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCONTRACT_DETAILS_JPNBOBJ).longValue());
                err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.XCONTRACTDETAILSJPN_XCONTRACTJPNPKID_NULL).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                	String infoForLogging="Error: Validation error occured for update. No primary key for entity XContractDetailsJPN, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("validateUpdate(int level, DWLStatus status) " + infoForLogging);
                }
                status.addError(err);
            }
            if (eObjXContractDetailsJPN.getLastUpdateDt() == null) {
                DWLError err = new DWLError();
                err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCONTRACT_DETAILS_JPNBOBJ).longValue());
                err.setReasonCode(new Long(DWLUtilErrorReasonCode.LAST_UPDATED_DATE_NULL).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
                if (logger.isFinestEnabled()) {
                	String infoForLogging="Error: Validation error occured for update. No last update date for entity XContractDetailsJPN, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("validateUpdate(int level, DWLStatus status) " + infoForLogging);
                }
                status.addError(err);
            }
        }

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            assignBeforeImageValues(metaDataMap);
            
            // MDM_TODO0: CDKWB0041I Add any component-level custom validation logic to be
            // executed for this object during an "update" transaction
        }
        status = getValidationStatus(level, status);
    if (logger.isFinestEnabled()) {
        	String returnValue = status.toString();
      logger.finest("RETURN validateUpdate(int level, DWLStatus status) " + returnValue);
    }
        return status;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Populate the before image of this business object.
     *
     * @see com.dwl.base.DWLCommon#populateBeforeImage()
     * @generated
     */
    public void populateBeforeImage() throws DWLBaseException {
    logger.finest("ENTER populateBeforeImage()");

        DSEAAdditionsExts comp = null;
        try {
        
      comp = (DSEAAdditionsExts)TCRMClassFactory.getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
        	
        } catch (Exception e) {
      if (logger.isFinestEnabled()) {
        String infoForLogging="Error: Fatal error while updating record " + e.getMessage();
      logger.finest("populateBeforeImage() " + infoForLogging);
      }
            DWLExceptionUtils.throwDWLBaseException(e, 
            									new DWLUpdateException(e.getMessage()), 
            									this.getStatus(), DWLStatus.FATAL,
                                  DSEAAdditionsExtsComponentID.XCONTRACT_DETAILS_JPNBOBJ, 
                                  "DIERR",
                                  DSEAAdditionsExtsErrorReasonCode.XCONTRACTDETAILSJPN_BEFORE_IMAGE_NOT_POPULATED, 
                                  this.getControl());
        }
        
        comp.loadBeforeImage(this);
    logger.finest("RETURN populateBeforeImage()");
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation common to both add and update transactions.
     *
     * @generated
     */
     
    private DWLStatus getValidationStatus(int level, DWLStatus status) throws Exception {
    logger.finest("ENTER getValidationStatus(int level, DWLStatus status)");

        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0034I Add any common controller-level custom validation
            // logic to be executed for this object during either "add" or
            // "update" transactions
    		controllerValidation_ContractStatus(status);
    		controllerValidation_SourceIdentifier(status);
    		controllerValidation_StartDate(status);
    		controllerValidation_EndDate(status);
    		controllerValidation_LastModifiedSystemDate(status);
    	}

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            // MDM_TODO0: CDKWB0035I Add any common component-level custom validation logic
            // to be executed for this object during either "add" or "update"
            // transactions
    		componentValidation_ContractStatus(status);
    		componentValidation_SourceIdentifier(status);
    		componentValidation_StartDate(status);
    		componentValidation_EndDate(status);
    		componentValidation_LastModifiedSystemDate(status);
        }
        
        if (logger.isFinestEnabled()) {
            String returnValue = status.toString();
      logger.finest("RETURN getValidationStatus(int level, DWLStatus status) " + returnValue);
        }
    
        return status;
    }

    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "ContractStatus"
     *
     * @generated
     */
	private void componentValidation_ContractStatus(DWLStatus status) {
  
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "SourceIdentifier"
     *
     * @generated
     */
	private void componentValidation_SourceIdentifier(DWLStatus status) {
  
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "StartDate"
     *
     * @generated
     */
	private void componentValidation_StartDate(DWLStatus status) {
  
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "EndDate"
     *
     * @generated
     */
	private void componentValidation_EndDate(DWLStatus status) {
  
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "LastModifiedSystemDate"
     *
     * @generated
     */
	private void componentValidation_LastModifiedSystemDate(DWLStatus status) {
  
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "ContractStatus"
     *
     * @generated
     */
	private void controllerValidation_ContractStatus(DWLStatus status) throws Exception {
  
      //persistent code type
            boolean isContractStatusNull = false;
            if ((eObjXContractDetailsJPN.getContractStatus() == null) &&
               ((getContractStatusValue() == null) || 
                 getContractStatusValue().trim().equals(""))) {
                isContractStatusNull = true;
            }
            if (!isContractStatusNull) {
                if (checkForInvalidXcontractdetailsjpnContractstatus()) {
                    DWLError err = new DWLError();
                    err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCONTRACT_DETAILS_JPNBOBJ).longValue());
                    err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XCONTRACTDETAILSJPN_CONTRACTSTATUS).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                    String infoForLogging="Error: Custom validation error occured for entity XContractDetailsJPN, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("controllerValidation_ContractStatus " + infoForLogging);
        }
                status.addError(err);
            }

             }
    			
    	}
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "SourceIdentifier"
     *
     * @generated
     */
	private void controllerValidation_SourceIdentifier(DWLStatus status) throws Exception {
  
      //persistent code type
            boolean isSourceIdentifierNull = false;
            if ((eObjXContractDetailsJPN.getSourceIdentifier() == null) &&
               ((getSourceIdentifierValue() == null) || 
                 getSourceIdentifierValue().trim().equals(""))) {
                isSourceIdentifierNull = true;
            }
            if (!isSourceIdentifierNull) {
                if (checkForInvalidXcontractdetailsjpnSourceidentifier()) {
                    DWLError err = new DWLError();
                    err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCONTRACT_DETAILS_JPNBOBJ).longValue());
                    err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XCONTRACTDETAILSJPN_SOURCEIDENTIFIER).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                    String infoForLogging="Error: Custom validation error occured for entity XContractDetailsJPN, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("controllerValidation_SourceIdentifier " + infoForLogging);
        }
                status.addError(err);
            }

             }
    			
    	}
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "StartDate"
     *
     * @generated
     */
	private void controllerValidation_StartDate(DWLStatus status) throws Exception {
  
            boolean isStartDateNull = (eObjXContractDetailsJPN.getStartDate() == null);
            if (!isValidStartDate) {
              	DWLError err = new DWLError();
               	err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCONTRACT_DETAILS_JPNBOBJ).longValue());
               	err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XCONTRACTDETAILSJPN_STARTDATE).longValue());
               	err.setErrorType(DWLErrorCode.DATA_INVALID_ERROR);
                String infoForLogging="Error: Validation error. Invalid time specified on property StartDate in entity XContractDetailsJPN, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode();
      logger.finest("controllerValidation_StartDate " + infoForLogging);
               	status.addError(err);
            } 
    	}
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "EndDate"
     *
     * @generated
     */
	private void controllerValidation_EndDate(DWLStatus status) throws Exception {
  
            boolean isEndDateNull = (eObjXContractDetailsJPN.getEndDate() == null);
            if (!isValidEndDate) {
              	DWLError err = new DWLError();
               	err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCONTRACT_DETAILS_JPNBOBJ).longValue());
               	err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XCONTRACTDETAILSJPN_ENDDATE).longValue());
               	err.setErrorType(DWLErrorCode.DATA_INVALID_ERROR);
                String infoForLogging="Error: Validation error. Invalid time specified on property EndDate in entity XContractDetailsJPN, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode();
      logger.finest("controllerValidation_EndDate " + infoForLogging);
               	status.addError(err);
            } 
    	}
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "LastModifiedSystemDate"
     *
     * @generated
     */
	private void controllerValidation_LastModifiedSystemDate(DWLStatus status) throws Exception {
  
            boolean isLastModifiedSystemDateNull = (eObjXContractDetailsJPN.getLastModifiedSystemDate() == null);
            if (!isValidLastModifiedSystemDate) {
              	DWLError err = new DWLError();
               	err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCONTRACT_DETAILS_JPNBOBJ).longValue());
               	err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XCONTRACTDETAILSJPN_LASTMODIFIEDSYSTEMDATE).longValue());
               	err.setErrorType(DWLErrorCode.DATA_INVALID_ERROR);
                String infoForLogging="Error: Validation error. Invalid time specified on property LastModifiedSystemDate in entity XContractDetailsJPN, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode();
      logger.finest("controllerValidation_LastModifiedSystemDate " + infoForLogging);
               	status.addError(err);
            } 
    	}
    private DWLError createDWLError(String entityName, String propertyName,String reasonCode){	
		DWLError err = new DWLError();
		err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCONTRACT_DETAILS_JPNBOBJ).longValue());
		err.setReasonCode(new Long(reasonCode).longValue());
		err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
			String infoForLogging="Error: Validation error occured. Property " + propertyName + " is null, in entity " + entityName + ", component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
			logger.finest("createDWLError " + infoForLogging);
		}
		return err;
    }
    
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Check the value of the field ContractStatus and return true if the error
     * reason INVALID_XCONTRACTDETAILSJPN_CONTRACTSTATUS should be returned.
     *
     * @generated
  **/
	private boolean checkForInvalidXcontractdetailsjpnContractstatus() throws Exception {
    logger.finest("ENTER checkForInvalidXcontractdetailsjpnContractstatus()");
        boolean notValid = false;
      	String langId = (String) this.getControl().get(DWLControlKeys.LANG_ID);
      	CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
    Long codeType = DWLFunctionUtils.getLongFromString( getContractStatusType() );
    String codeValue = getContractStatusValue();
    if( codeValue != null && codeValue.trim().equals("")){
      codeValue = null;
    }
     
        if ( codeType != null && codeValue == null ){

             if( codeTypeCompHelper.isCodeValid("cdcontractsttp", langId, getContractStatusType(),
                 CodeTypeComponentHelper.ACTIVE, getControl())) {
                 CodeTypeBObj ctBObj = codeTypeCompHelper
                 					.getCodeTypeByCode("cdcontractsttp", langId, getContractStatusType(),
                         								getControl());
               	if (ctBObj != null) {
                   	setContractStatusValue( ctBObj.getvalue() );
               	}
             }
             else{
             	if (logger.isFinestEnabled()) {
              	 	String infoForLogging="NotValid 1";
      logger.finest("checkForInvalidXcontractdetailsjpnContractstatus() " + infoForLogging);
        }
                 notValid = true;
           }
        }
        else if (codeType == null && codeValue != null ){
          
             CodeTypeBObj ctBObj = codeTypeCompHelper
                      .getCodeTypeByValue("cdcontractsttp", langId, codeValue,
                                 getControl());

             if (ctBObj != null) {
                 setContractStatusType(ctBObj.gettp_cd());
             } 
             else {
             	if (logger.isFinestEnabled()) {
              	  	String infoForLogging="NotValid 2";
      logger.finest("checkForInvalidXcontractdetailsjpnContractstatus() " + infoForLogging);
        }
                  notValid = true;
             }
        }
        else if ( codeType != null && codeValue != null
             && !codeTypeCompHelper.isCodeValuePairValid("cdcontractsttp", langId, getContractStatusType(), 
                     new String[] { codeValue }, CodeTypeComponentHelper.ACTIVE, getControl())) {	
       if (logger.isFinestEnabled()) {
       		String infoForLogging="NotValid 3";
      logger.finest("checkForInvalidXcontractdetailsjpnContractstatus() " + infoForLogging);
       }
             notValid = true;
        }
        if (logger.isFinestEnabled()) {
      String returnValue ="" +notValid;
      logger.finest("RETURN checkForInvalidXcontractdetailsjpnContractstatus() " + returnValue);
    }
    return notValid;
     } 
				 
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Check the value of the field SourceIdentifier and return true if the
     * error reason INVALID_XCONTRACTDETAILSJPN_SOURCEIDENTIFIER should be
     * returned.
     *
     * @generated
  **/
	private boolean checkForInvalidXcontractdetailsjpnSourceidentifier() throws Exception {
    logger.finest("ENTER checkForInvalidXcontractdetailsjpnSourceidentifier()");
        boolean notValid = false;
      	String langId = (String) this.getControl().get(DWLControlKeys.LANG_ID);
      	CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
    Long codeType = DWLFunctionUtils.getLongFromString( getSourceIdentifierType() );
    String codeValue = getSourceIdentifierValue();
    if( codeValue != null && codeValue.trim().equals("")){
      codeValue = null;
    }
     
        if ( codeType != null && codeValue == null ){

             if( codeTypeCompHelper.isCodeValid("cdsourceidenttp", langId, getSourceIdentifierType(),
                 CodeTypeComponentHelper.ACTIVE, getControl())) {
                 CodeTypeBObj ctBObj = codeTypeCompHelper
                 					.getCodeTypeByCode("cdsourceidenttp", langId, getSourceIdentifierType(),
                         								getControl());
               	if (ctBObj != null) {
                   	setSourceIdentifierValue( ctBObj.getvalue() );
               	}
             }
             else{
             	if (logger.isFinestEnabled()) {
              	 	String infoForLogging="NotValid 1";
      logger.finest("checkForInvalidXcontractdetailsjpnSourceidentifier() " + infoForLogging);
        }
                 notValid = true;
           }
        }
        else if (codeType == null && codeValue != null ){
          
             CodeTypeBObj ctBObj = codeTypeCompHelper
                      .getCodeTypeByValue("cdsourceidenttp", langId, codeValue,
                                 getControl());

             if (ctBObj != null) {
                 setSourceIdentifierType(ctBObj.gettp_cd());
             } 
             else {
             	if (logger.isFinestEnabled()) {
              	  	String infoForLogging="NotValid 2";
      logger.finest("checkForInvalidXcontractdetailsjpnSourceidentifier() " + infoForLogging);
        }
                  notValid = true;
             }
        }
        else if ( codeType != null && codeValue != null
             && !codeTypeCompHelper.isCodeValuePairValid("cdsourceidenttp", langId, getSourceIdentifierType(), 
                     new String[] { codeValue }, CodeTypeComponentHelper.ACTIVE, getControl())) {	
       if (logger.isFinestEnabled()) {
       		String infoForLogging="NotValid 3";
      logger.finest("checkForInvalidXcontractdetailsjpnSourceidentifier() " + infoForLogging);
       }
             notValid = true;
        }
        if (logger.isFinestEnabled()) {
      String returnValue ="" +notValid;
      logger.finest("RETURN checkForInvalidXcontractdetailsjpnSourceidentifier() " + returnValue);
    }
    return notValid;
     } 
				 



}

