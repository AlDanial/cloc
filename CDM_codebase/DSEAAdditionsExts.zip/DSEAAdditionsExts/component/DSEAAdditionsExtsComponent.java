	
/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[01f9280e1835bfa70ef40e7850c9d1e6]
 */

package com.ibm.daimler.dsea.component;

import java.sql.Timestamp;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;

import com.dwl.base.DWLControl;
import com.dwl.common.globalization.util.ResourceBundleHelper;
import com.dwl.base.DWLResponse;
import com.dwl.base.IDWLErrorMessage;
import com.dwl.base.constant.DWLControlKeys;
import com.dwl.base.error.DWLStatus;
import com.dwl.base.exception.DWLBaseException;
import com.dwl.base.requestHandler.DWLTransaction;
import com.dwl.base.util.DWLFunctionUtils;
import com.dwl.tcrm.common.TCRMErrorCode;
import com.dwl.tcrm.utilities.TCRMClassFactory;
import com.ibm.mdm.annotations.Component;
import com.ibm.mdm.annotations.TxMetadata;


import com.dwl.base.IDWLErrorMessage;
import com.dwl.base.exception.DWLUpdateException;
import com.dwl.base.groupelement.engine.Group;
import com.dwl.base.requestHandler.DWLTransaction;
import com.dwl.base.groupelement.engine.GroupElementServiceHelper;
import com.dwl.base.groupelement.engine.IGroupElementService;
import com.dwl.base.requestHandler.DWLTransactionInquiry;
import com.dwl.base.requestHandler.DWLTransactionPersistent;
import com.dwl.base.util.DWLClassFactory;
import com.dwl.base.util.DWLExceptionUtils;
import com.dwl.base.util.DWLFunctionUtils;
import com.dwl.base.util.PaginationUtils;
import com.dwl.bobj.query.BObjQuery;
import com.dwl.bobj.query.BObjQueryException;
import com.dwl.bobj.query.Persistence;
import com.dwl.common.globalization.util.ResourceBundleHelper;
import com.dwl.tcrm.common.TCRMCommonComponent;
import com.dwl.tcrm.common.TCRMControlKeys;
import com.dwl.tcrm.common.TCRMErrorCode;
import com.dwl.tcrm.exception.TCRMDataInvalidException;
import com.dwl.tcrm.exception.TCRMInsertException;
import com.dwl.tcrm.exception.TCRMReadException;
import com.dwl.tcrm.utilities.FunctionUtils;
import com.dwl.tcrm.utilities.StringUtils;
import com.dwl.tcrm.utilities.TCRMClassFactory;
import com.dwl.tcrm.utilities.TCRMExceptionUtils;
import com.ibm.daimler.dsea.bobj.query.DSEAAdditionsExtsModuleBObjPersistenceFactory;
import com.ibm.daimler.dsea.bobj.query.DSEAAdditionsExtsModuleBObjQueryFactory;
import com.ibm.daimler.dsea.bobj.query.XCompanyIdentificationBObjQuery;
import com.ibm.daimler.dsea.bobj.query.XConsentBObjQuery;
import com.ibm.daimler.dsea.bobj.query.XContractDetailsBObjQuery;
import com.ibm.daimler.dsea.bobj.query.XContractDetailsJPNBObjQuery;
import com.ibm.daimler.dsea.bobj.query.XContractRelBObjQuery;
import com.ibm.daimler.dsea.bobj.query.XContractRelJPNBObjQuery;
import com.ibm.daimler.dsea.bobj.query.XCustomerRetailerBObjQuery;
import com.ibm.daimler.dsea.bobj.query.XCustomerRetailerJPNBObjQuery;
import com.ibm.daimler.dsea.bobj.query.XCustomerRetailerRoleBObjQuery;
import com.ibm.daimler.dsea.bobj.query.XCustomerVehicleAusBObjQuery;
import com.ibm.daimler.dsea.bobj.query.XCustomerVehicleBObjQuery;
import com.ibm.daimler.dsea.bobj.query.XCustomerVehicleJPNBObjQuery;
import com.ibm.daimler.dsea.bobj.query.XCustomerVehicleKORBObjQuery;
import com.ibm.daimler.dsea.bobj.query.XCustomerVehicleRoleAusBObjQuery;
import com.ibm.daimler.dsea.bobj.query.XCustomerVehicleRoleBObjQuery;
import com.ibm.daimler.dsea.bobj.query.XCustomerVehicleRoleJPNBObjQuery;
import com.ibm.daimler.dsea.bobj.query.XCustomerVehicleRoleKORBObjQuery;
import com.ibm.daimler.dsea.bobj.query.XDataSharingBObjQuery;
import com.ibm.daimler.dsea.bobj.query.XDealerRetailerBObjQuery;
import com.ibm.daimler.dsea.bobj.query.XDeleteAuditBObjQuery;
import com.ibm.daimler.dsea.bobj.query.XEpucidTempBObjQuery;
import com.ibm.daimler.dsea.bobj.query.XGurantorCompanyBObjQuery;
import com.ibm.daimler.dsea.bobj.query.XGurantorIndividualBObjQuery;
import com.ibm.daimler.dsea.bobj.query.XMagicRelBObjQuery;
import com.ibm.daimler.dsea.bobj.query.XPreferenceBObjQuery;
import com.ibm.daimler.dsea.bobj.query.XPrivacyAgreementBObjQuery;
import com.ibm.daimler.dsea.bobj.query.XRetailerBObjQuery;
import com.ibm.daimler.dsea.bobj.query.XVRCollapseBObjQuery;
import com.ibm.daimler.dsea.bobj.query.XVehicleAddressBObjQuery;
import com.ibm.daimler.dsea.bobj.query.XVehicleAusBObjQuery;
import com.ibm.daimler.dsea.bobj.query.XVehicleBObjQuery;
import com.ibm.daimler.dsea.bobj.query.XVehicleJPNBObjQuery;
import com.ibm.daimler.dsea.bobj.query.XVehicleKORBObjQuery;
import com.ibm.daimler.dsea.component.XCompanyIdentificationBObj;
import com.ibm.daimler.dsea.component.XConsentBObj;
import com.ibm.daimler.dsea.component.XContractDetailsBObj;
import com.ibm.daimler.dsea.component.XContractDetailsJPNBObj;
import com.ibm.daimler.dsea.component.XContractRelBObj;
import com.ibm.daimler.dsea.component.XContractRelJPNBObj;
import com.ibm.daimler.dsea.component.XCustomerRetailerBObj;
import com.ibm.daimler.dsea.component.XCustomerRetailerJPNBObj;
import com.ibm.daimler.dsea.component.XCustomerRetailerRoleBObj;
import com.ibm.daimler.dsea.component.XCustomerVehicleAusBObj;
import com.ibm.daimler.dsea.component.XCustomerVehicleBObj;
import com.ibm.daimler.dsea.component.XCustomerVehicleJPNBObj;
import com.ibm.daimler.dsea.component.XCustomerVehicleKORBObj;
import com.ibm.daimler.dsea.component.XCustomerVehicleRoleAusBObj;
import com.ibm.daimler.dsea.component.XCustomerVehicleRoleBObj;
import com.ibm.daimler.dsea.component.XCustomerVehicleRoleJPNBObj;
import com.ibm.daimler.dsea.component.XCustomerVehicleRoleKORBObj;
import com.ibm.daimler.dsea.component.XDataSharingBObj;
import com.ibm.daimler.dsea.component.XDealerRetailerBObj;
import com.ibm.daimler.dsea.component.XDeleteAuditBObj;
import com.ibm.daimler.dsea.component.XEpucidTempBObj;
import com.ibm.daimler.dsea.component.XGurantorCompanyBObj;
import com.ibm.daimler.dsea.component.XGurantorIndividualBObj;
import com.ibm.daimler.dsea.component.XMagicRelBObj;
import com.ibm.daimler.dsea.component.XPreferenceBObj;
import com.ibm.daimler.dsea.component.XPrivacyAgreementBObj;
import com.ibm.daimler.dsea.component.XRetailerBObj;
import com.ibm.daimler.dsea.component.XVRCollapseBObj;
import com.ibm.daimler.dsea.component.XVehicleAusBObj;
import com.ibm.daimler.dsea.component.XVehicleAddressBObj;
import com.ibm.daimler.dsea.component.XVehicleBObj;
import com.ibm.daimler.dsea.component.XVehicleJPNBObj;
import com.ibm.daimler.dsea.component.XVehicleKORBObj;
import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsComponentID;
import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsErrorReasonCode;
import com.ibm.daimler.dsea.constant.ResourceBundleNames;
import com.ibm.daimler.dsea.interfaces.DSEAAdditionsExts;
import com.ibm.mdm.annotations.Component;
import com.ibm.mdm.annotations.TxMetadata;
import com.ibm.mdm.common.brokers.BObjPersistenceFactoryBroker;
import com.ibm.mdm.common.brokers.BObjQueryFactoryBroker;
import com.ibm.mdm.common.codetype.interfaces.CodeTypeComponentHelper;
import com.ibm.mdm.common.codetype.obj.CodeTypeBObj;

import java.sql.Timestamp;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * Business component class for handling DSEAAdditionsExts related transactions
 * and inquiries.
 * @generated
 */
 @Component(errorComponentID = DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_COMPONENT)
public class DSEAAdditionsExtsComponent extends TCRMCommonComponent implements DSEAAdditionsExts {
	
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
	private final static String EXCEPTION_DUPLICATE_KEY = "Exception_Shared_DuplicateKey";

	/**
    * <!-- begin-user-doc -->
	  * <!-- end-user-doc -->
    * @generated 
    */
	 private final static com.dwl.base.logging.IDWLLogger logger = com.dwl.base.logging.DWLLoggerManager.getLogger(DSEAAdditionsExtsComponent.class);
			
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private IDWLErrorMessage errHandler;
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Default constructor.
     *
     * @generated
     */
    public DSEAAdditionsExtsComponent() {
        super();
        errHandler = TCRMClassFactory.getErrorHandler();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the BObjQuery factory class from the configuration.
     * @generated
     **/
    private DSEAAdditionsExtsModuleBObjQueryFactory getBObjQueryFactory() throws BObjQueryException{
        return (DSEAAdditionsExtsModuleBObjQueryFactory) BObjQueryFactoryBroker.getBObjQueryFactory(DSEAAdditionsExtsModuleBObjQueryFactory.class.getName());
    }
    
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the BObjPersistenceFactory class from the configuration.
     * @generated
     **/
    private DSEAAdditionsExtsModuleBObjPersistenceFactory getBObjPersistenceFactory() throws BObjQueryException {
        return (DSEAAdditionsExtsModuleBObjPersistenceFactory) BObjPersistenceFactoryBroker.getBObjPersistenceFactory(DSEAAdditionsExtsModuleBObjPersistenceFactory.class.getName());
    }
    



	
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXPreference.
     *
     * @param PreferencepkId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetXPreference
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETXPREFERENCE_FAILED,
       beforePreExecuteMethod = "beforePreExecuteGetXPreference"
    )
     public DWLResponse getXPreference(String PreferencepkId, DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getXPreference(String PreferencepkId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(PreferencepkId);
        DWLTransaction txObj = new  DWLTransactionInquiry("getXPreference", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction getXPreference.";
      logger.finest("getXPreference(String PreferencepkId,  DWLControl control) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction getXPreference.";
      logger.finest("getXPreference(String PreferencepkId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getXPreference(String PreferencepkId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }
    
    
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets a XPreference from the database.
     * 
     * @generated
     */
    public DWLResponse handleGetXPreference(String PreferencepkId, DWLControl control) throws Exception {
        DWLStatus status = new DWLStatus();
        DWLResponse response = createDWLResponse();
        
        BObjQuery bObjQuery = null;
           
        String asOfDate = (String) control.get(DWLControl.INQUIRE_AS_OF_DATE);

        // History data inquiry: if inquireAsOfDate field has value in request xml 
        if (StringUtils.isNonBlank(asOfDate)) {
            Timestamp tsAsOfDate = getPITHistoryDate(asOfDate, DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_COMPONENT,
                                                     DSEAAdditionsExtsErrorReasonCode.GETXPREFERENCE_INVALID_INQUIRE_AS_OF_DATE_FORMAT,
                                                     status, control);

            bObjQuery = getBObjQueryFactory().createXPreferenceBObjQuery(XPreferenceBObjQuery.XPREFERENCE_HISTORY_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(PreferencepkId));
            bObjQuery.setParameter(1, tsAsOfDate);
            bObjQuery.setParameter(2, tsAsOfDate);
        } else {
            bObjQuery = getBObjQueryFactory().createXPreferenceBObjQuery(XPreferenceBObjQuery.XPREFERENCE_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(PreferencepkId));
        }


        XPreferenceBObj o = (XPreferenceBObj) bObjQuery.getSingleResult();
        if( o == null ){
        	return null;
        } 
        postRetrieveXPreferenceBObj(o, "0", "ALL", control); 
          
        if (o.getStatus()==null) {
            o.setStatus(status);
        }
        response.addStatus(o.getStatus());
        response.setData(o);

      return response;
    }
    
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public void beforePreExecuteGetXPreference(DWLTransaction transaction) throws DWLBaseException{
        // Check if the parameters are valid.
        Object[] arguments = getInquiryArgumentType((DWLTransactionInquiry)transaction);
        String pk = null;
        if (arguments!=null && arguments.length>0) {
            pk = (String)arguments[0];
        }
        // Check if the parameter passed in exists.
        if ((pk == null) || (pk.trim().length() == 0)) {
            TCRMExceptionUtils.throwTCRMException(null, new TCRMReadException(), transaction.getStatus(), DWLStatus.FATAL,
                DSEAAdditionsExtsComponentID.XPREFERENCE_BOBJ,
                TCRMErrorCode.FIELD_VALIDATION_ERROR,
                DSEAAdditionsExtsErrorReasonCode.XPREFERENCE_PREFERENCEPKID_NULL,
                transaction.getTxnControl(), errHandler);
        }
    }

	
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXPreferenceByLocationGroupId.
     *
     * @param LocationGroupId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetXPreferenceByLocationGroupId
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETXPREFERENCEBYLOCATIONGROUPID_FAILED,
       beforePreExecuteMethod = "beforePreExecuteGetXPreferenceByLocationGroupId"
    )
     public DWLResponse getXPreferenceByLocationGroupId(String LocationGroupId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getXPreferenceByLocationGroupId(String LocationGroupId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(LocationGroupId);
        DWLTransaction txObj = new  DWLTransactionInquiry("getXPreferenceByLocationGroupId", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction getXPreferenceByLocationGroupId.";
      logger.finest("getXPreferenceByLocationGroupId(String LocationGroupId,  DWLControl control) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction getXPreferenceByLocationGroupId.";
      logger.finest("getXPreferenceByLocationGroupId(String LocationGroupId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getXPreferenceByLocationGroupId(String LocationGroupId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }
    
    
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets a XPreference from the database.
     * 
     * @generated
     */
    public DWLResponse handleGetXPreferenceByLocationGroupId(String LocationGroupId,  DWLControl control) throws Exception {
        DWLStatus status = new DWLStatus();
        DWLResponse response = createDWLResponse();
        
        BObjQuery bObjQuery = null;
           
        String asOfDate = (String) control.get(DWLControl.INQUIRE_AS_OF_DATE);

        // History data inquiry: if inquireAsOfDate field has value in request xml 
        if (StringUtils.isNonBlank(asOfDate)) {
            Timestamp tsAsOfDate = getPITHistoryDate(asOfDate, DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_COMPONENT,
                                                     DSEAAdditionsExtsErrorReasonCode.GETXPREFERENCEBYLOCATIONGROUPID_INVALID_INQUIRE_AS_OF_DATE_FORMAT,
                                                     status, control);

            bObjQuery = getBObjQueryFactory().createXPreferenceBObjQuery(XPreferenceBObjQuery.XPREFERENCE_BY_LOCATION_GROUP_ID_HISTORY_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(LocationGroupId));
            bObjQuery.setParameter(1, tsAsOfDate);
            bObjQuery.setParameter(2, tsAsOfDate);
        } else {
            bObjQuery = getBObjQueryFactory().createXPreferenceBObjQuery(XPreferenceBObjQuery.XPREFERENCE_BY_LOCATION_GROUP_ID_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(LocationGroupId));
        }

        boolean considerForPagination = PaginationUtils
                            .considerForPagintion(XPreferenceBObj.class.getName(), control);
        control.setConsiderForPagintionFlag(considerForPagination);

        // set returned object
        List<?> list = bObjQuery.getResults();

        if (list.size() == 0) {
            return null;
        }
    Vector<XPreferenceBObj> vector = new Vector<XPreferenceBObj>();
        for (Iterator<?> it = list.iterator(); it.hasNext();) {
            XPreferenceBObj o = (XPreferenceBObj) it.next();
            postRetrieveXPreferenceBObj(o, "0", "ALL", control); 
            vector.add(o);
          
            if (o.getStatus()==null) {
                o.setStatus(status);
            }
            response.addStatus(o.getStatus());
        }
        response.setData(vector);

      return response;
    }
    
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public void beforePreExecuteGetXPreferenceByLocationGroupId(DWLTransaction transaction) throws DWLBaseException{
        // Check if the parameters are valid.
        Object[] arguments = getInquiryArgumentType((DWLTransactionInquiry)transaction);
    if (arguments!=null && arguments.length>0) {
            // MDM_TODO0: CDKWB0003I Add argument validation logic
    }
    }

	
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction addXPreference.
     *
     * @param theBObj
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleAddXPreference
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.ADD_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.INSERT_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.ADDXPREFERENCE_FAILED
    )
     public DWLResponse addXPreference(XPreferenceBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER addXPreference(XPreferenceBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("addXPreference", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction addXPreference.";
      logger.finest("addXPreference(XPreferenceBObj theBObj) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction addXPreference.";
      logger.finest("addXPreference(XPreferenceBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN addXPreference(XPreferenceBObj theBObj) " + returnValue);
    }
        return retObj;
    }
    
    
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Adds a XPreference to the database.
     *
     * @param theXPreferenceBObj
     *     The object that contains XPreference attribute values.
     * @return
     *     DWLResponse containing a XPreferenceBObj object.
     * @exception Exception
     * @generated
     */
    public DWLResponse handleAddXPreference(XPreferenceBObj theXPreferenceBObj) throws Exception {
        DWLResponse response = null;
        DWLStatus status = theXPreferenceBObj.getStatus();
        if (status == null) {
            status = new DWLStatus();
            theXPreferenceBObj.setStatus(status);
        }

        String strPluggableID = null;

        try {
            // Pluggable Key Structure implementation
            strPluggableID = getSuppliedIdPKFromBObj(theXPreferenceBObj);

            if ((strPluggableID != null) && (strPluggableID.length() > 0)) {
                theXPreferenceBObj.getEObjXPreference().setPreferencepkId(FunctionUtils.getLongFromString(strPluggableID));
            } else {
                strPluggableID = null;
                theXPreferenceBObj.getEObjXPreference().setPreferencepkId(null);
            }
         Persistence theXPreferenceBObjPersistence = getBObjPersistenceFactory().createXPreferenceBObjPersistence(XPreferenceBObjQuery.XPREFERENCE_ADD, theXPreferenceBObj);
         theXPreferenceBObjPersistence.persistAdd();

            response = new DWLResponse();
            response.setData(theXPreferenceBObj);
            response.setStatus(theXPreferenceBObj.getStatus());
    } catch (Exception ex) {
 				TCRMExceptionUtils.throwTCRMException(ex, new TCRMInsertException(ex.getMessage()), status,
                    DWLStatus.FATAL, DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_COMPONENT, TCRMErrorCode.INSERT_RECORD_ERROR,
                    DSEAAdditionsExtsErrorReasonCode.ADDXPREFERENCE_FAILED, theXPreferenceBObj.getControl(), errHandler);
        }
        
        return response;
    }
    

	
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction updateXPreference.
     *
     * @param theBObj
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleUpdateXPreference
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.UPDATE_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.UPDATE_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.UPDATEXPREFERENCE_FAILED
    )
     public DWLResponse updateXPreference(XPreferenceBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER updateXPreference(XPreferenceBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("updateXPreference", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction updateXPreference.";
      logger.finest("updateXPreference(XPreferenceBObj theBObj) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction updateXPreference.";
      logger.finest("updateXPreference(XPreferenceBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN updateXPreference(XPreferenceBObj theBObj) " + returnValue);
    }
        return retObj;
    }
    
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Updates the specified XPreference with new attribute values.
     *
     * @param theXPreferenceBObj
     *     The object that contains XPreference attribute values to be updated
     * @return
     *     DWLResponse containing a XPreferenceBObj of the updated object.
     * @exception Exception
     * @generated
     */
    public DWLResponse handleUpdateXPreference(XPreferenceBObj theXPreferenceBObj) throws Exception {

        DWLStatus status = theXPreferenceBObj.getStatus();

        if (status == null) {
            status = new DWLStatus();
            theXPreferenceBObj.setStatus(status);
        }
        
            // set lastupdatetxid with txnid from dwlcontrol
            theXPreferenceBObj.getEObjXPreference().setLastUpdateTxId(new Long(theXPreferenceBObj.getControl().getTxnId()));
         Persistence theXPreferenceBObjPersistence = getBObjPersistenceFactory().createXPreferenceBObjPersistence(XPreferenceBObjQuery.XPREFERENCE_UPDATE, theXPreferenceBObj);
         theXPreferenceBObjPersistence.persistUpdate();

        DWLResponse response = createDWLResponse();
        response.setData(theXPreferenceBObj);
        response.setStatus(theXPreferenceBObj.getStatus());

        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction deleteXPreference.
     *
     * @param theBObj
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handledeleteXPreference
     * @generated NOT
     */
     @TxMetadata(actionCategory=DWLControlKeys.DELETE_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.DELETE_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.DELETEXPREFERENCE_FAILED
    )
     public DWLResponse deleteXPreference(XPreferenceBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER deleteXPreference(XPreferenceBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("deleteXPreference", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction deleteXPreference.";
      logger.finest("deleteXPreference(XPreferenceBObj theBObj) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction deleteXPreference.";
      logger.finest("deleteXPreference(XPreferenceBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN deleteXPreference(XPreferenceBObj theBObj) " + returnValue);
    }
        return retObj;
    }

	
    
     /**
      * <!-- begin-user-doc -->
      * <!-- end-user-doc -->
      *
      * deletes the specified XPreference with new attribute values.
      *
      * @param theXPreferenceBObj
      *     The object that contains XPreference attribute values to be updated
      * @return
      *     DWLResponse containing a XPreferenceBObj of the updated object.
      * @exception Exception
      * @generated NOT
      */
     public DWLResponse handleDeleteXPreference(XPreferenceBObj theXPreferenceBObj) throws Exception {

         DWLStatus status = theXPreferenceBObj.getStatus();

         if (status == null) {
             status = new DWLStatus();
             theXPreferenceBObj.setStatus(status);
         }
         
             // set lastupdatetxid with txnid from dwlcontrol
             theXPreferenceBObj.getEObjXPreference().setLastUpdateTxId(new Long(theXPreferenceBObj.getControl().getTxnId()));
          Persistence theXPreferenceBObjPersistence = getBObjPersistenceFactory().createXPreferenceBObjPersistence(XPreferenceBObjQuery.XPREFERENCE_DELETE, theXPreferenceBObj);
          theXPreferenceBObjPersistence.persistDelete();

         DWLResponse response = createDWLResponse();
         response.setData(theXPreferenceBObj);
         response.setStatus(theXPreferenceBObj.getStatus());

         return response;
     }
    
    
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXPrivacyAgreement.
     *
     * @param PrivacyAgreementpkId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetXPrivacyAgreement
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETXPRIVACYAGREEMENT_FAILED,
       beforePreExecuteMethod = "beforePreExecuteGetXPrivacyAgreement"
    )
     public DWLResponse getXPrivacyAgreement(String PrivacyAgreementpkId, DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getXPrivacyAgreement(String PrivacyAgreementpkId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(PrivacyAgreementpkId);
        DWLTransaction txObj = new  DWLTransactionInquiry("getXPrivacyAgreement", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction getXPrivacyAgreement.";
      logger.finest("getXPrivacyAgreement(String PrivacyAgreementpkId,  DWLControl control) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction getXPrivacyAgreement.";
      logger.finest("getXPrivacyAgreement(String PrivacyAgreementpkId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getXPrivacyAgreement(String PrivacyAgreementpkId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }
    
    
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets a XPrivacyAgreement from the database.
     * 
     * @generated
     */
    public DWLResponse handleGetXPrivacyAgreement(String PrivacyAgreementpkId, DWLControl control) throws Exception {
        DWLStatus status = new DWLStatus();
        DWLResponse response = createDWLResponse();
        
        BObjQuery bObjQuery = null;
           
        String asOfDate = (String) control.get(DWLControl.INQUIRE_AS_OF_DATE);

        // History data inquiry: if inquireAsOfDate field has value in request xml 
        if (StringUtils.isNonBlank(asOfDate)) {
            Timestamp tsAsOfDate = getPITHistoryDate(asOfDate, DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_COMPONENT,
                                                     DSEAAdditionsExtsErrorReasonCode.GETXPRIVACYAGREEMENT_INVALID_INQUIRE_AS_OF_DATE_FORMAT,
                                                     status, control);

            bObjQuery = getBObjQueryFactory().createXPrivacyAgreementBObjQuery(XPrivacyAgreementBObjQuery.XPRIVACY_AGREEMENT_HISTORY_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(PrivacyAgreementpkId));
            bObjQuery.setParameter(1, tsAsOfDate);
            bObjQuery.setParameter(2, tsAsOfDate);
        } else {
            bObjQuery = getBObjQueryFactory().createXPrivacyAgreementBObjQuery(XPrivacyAgreementBObjQuery.XPRIVACY_AGREEMENT_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(PrivacyAgreementpkId));
        }


        XPrivacyAgreementBObj o = (XPrivacyAgreementBObj) bObjQuery.getSingleResult();
        if( o == null ){
        	return null;
        } 
        postRetrieveXPrivacyAgreementBObj(o, "0", "ALL", control); 
          
        if (o.getStatus()==null) {
            o.setStatus(status);
        }
        response.addStatus(o.getStatus());
        response.setData(o);

      return response;
    }
    
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public void beforePreExecuteGetXPrivacyAgreement(DWLTransaction transaction) throws DWLBaseException{
        // Check if the parameters are valid.
        Object[] arguments = getInquiryArgumentType((DWLTransactionInquiry)transaction);
        String pk = null;
        if (arguments!=null && arguments.length>0) {
            pk = (String)arguments[0];
        }
        // Check if the parameter passed in exists.
        if ((pk == null) || (pk.trim().length() == 0)) {
            TCRMExceptionUtils.throwTCRMException(null, new TCRMReadException(), transaction.getStatus(), DWLStatus.FATAL,
                DSEAAdditionsExtsComponentID.XPRIVACY_AGREEMENT_BOBJ,
                TCRMErrorCode.FIELD_VALIDATION_ERROR,
                DSEAAdditionsExtsErrorReasonCode.XPRIVACYAGREEMENT_PRIVACYAGREEMENTPKID_NULL,
                transaction.getTxnControl(), errHandler);
        }
    }

	
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXPrivAgreementByLocationGroupId.
     *
     * @param LocationGroupId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetXPrivAgreementByLocationGroupId
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETXPRIVAGREEMENTBYLOCATIONGROUPID_FAILED,
       beforePreExecuteMethod = "beforePreExecuteGetXPrivAgreementByLocationGroupId"
    )
     public DWLResponse getXPrivAgreementByLocationGroupId(String LocationGroupId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getXPrivAgreementByLocationGroupId(String LocationGroupId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(LocationGroupId);
        DWLTransaction txObj = new  DWLTransactionInquiry("getXPrivAgreementByLocationGroupId", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction getXPrivAgreementByLocationGroupId.";
      logger.finest("getXPrivAgreementByLocationGroupId(String LocationGroupId,  DWLControl control) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction getXPrivAgreementByLocationGroupId.";
      logger.finest("getXPrivAgreementByLocationGroupId(String LocationGroupId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getXPrivAgreementByLocationGroupId(String LocationGroupId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }
    
    
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets a XPrivacyAgreement from the database.
     * 
     * @generated
     */
    public DWLResponse handleGetXPrivAgreementByLocationGroupId(String LocationGroupId,  DWLControl control) throws Exception {
        DWLStatus status = new DWLStatus();
        DWLResponse response = createDWLResponse();
        
        BObjQuery bObjQuery = null;
           
        String asOfDate = (String) control.get(DWLControl.INQUIRE_AS_OF_DATE);

        // History data inquiry: if inquireAsOfDate field has value in request xml 
        if (StringUtils.isNonBlank(asOfDate)) {
            Timestamp tsAsOfDate = getPITHistoryDate(asOfDate, DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_COMPONENT,
                                                     DSEAAdditionsExtsErrorReasonCode.GETXPRIVAGREEMENTBYLOCATIONGROUPID_INVALID_INQUIRE_AS_OF_DATE_FORMAT,
                                                     status, control);

            bObjQuery = getBObjQueryFactory().createXPrivacyAgreementBObjQuery(XPrivacyAgreementBObjQuery.XPRIV_AGREEMENT_BY_LOCATION_GROUP_ID_HISTORY_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(LocationGroupId));
            bObjQuery.setParameter(1, tsAsOfDate);
            bObjQuery.setParameter(2, tsAsOfDate);
        } else {
            bObjQuery = getBObjQueryFactory().createXPrivacyAgreementBObjQuery(XPrivacyAgreementBObjQuery.XPRIV_AGREEMENT_BY_LOCATION_GROUP_ID_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(LocationGroupId));
        }

        boolean considerForPagination = PaginationUtils
                            .considerForPagintion(XPrivacyAgreementBObj.class.getName(), control);
        control.setConsiderForPagintionFlag(considerForPagination);

        // set returned object
        List<?> list = bObjQuery.getResults();

        if (list.size() == 0) {
            return null;
        }
    Vector<XPrivacyAgreementBObj> vector = new Vector<XPrivacyAgreementBObj>();
        for (Iterator<?> it = list.iterator(); it.hasNext();) {
            XPrivacyAgreementBObj o = (XPrivacyAgreementBObj) it.next();
            postRetrieveXPrivacyAgreementBObj(o, "0", "ALL", control); 
            vector.add(o);
          
            if (o.getStatus()==null) {
                o.setStatus(status);
            }
            response.addStatus(o.getStatus());
        }
        response.setData(vector);

      return response;
    }
    
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public void beforePreExecuteGetXPrivAgreementByLocationGroupId(DWLTransaction transaction) throws DWLBaseException{
        // Check if the parameters are valid.
        Object[] arguments = getInquiryArgumentType((DWLTransactionInquiry)transaction);
    if (arguments!=null && arguments.length>0) {
            // MDM_TODO0: CDKWB0003I Add argument validation logic
    }
    }

	
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction addXPrivacyAgreement.
     *
     * @param theBObj
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleAddXPrivacyAgreement
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.ADD_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.INSERT_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.ADDXPRIVACYAGREEMENT_FAILED
    )
     public DWLResponse addXPrivacyAgreement(XPrivacyAgreementBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER addXPrivacyAgreement(XPrivacyAgreementBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("addXPrivacyAgreement", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction addXPrivacyAgreement.";
      logger.finest("addXPrivacyAgreement(XPrivacyAgreementBObj theBObj) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction addXPrivacyAgreement.";
      logger.finest("addXPrivacyAgreement(XPrivacyAgreementBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN addXPrivacyAgreement(XPrivacyAgreementBObj theBObj) " + returnValue);
    }
        return retObj;
    }
    
    
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Adds a XPrivacyAgreement to the database.
     *
     * @param theXPrivacyAgreementBObj
     *     The object that contains XPrivacyAgreement attribute values.
     * @return
     *     DWLResponse containing a XPrivacyAgreementBObj object.
     * @exception Exception
     * @generated
     */
    public DWLResponse handleAddXPrivacyAgreement(XPrivacyAgreementBObj theXPrivacyAgreementBObj) throws Exception {
        DWLResponse response = null;
        DWLStatus status = theXPrivacyAgreementBObj.getStatus();
        if (status == null) {
            status = new DWLStatus();
            theXPrivacyAgreementBObj.setStatus(status);
        }

        String strPluggableID = null;

        try {
            // Pluggable Key Structure implementation
            strPluggableID = getSuppliedIdPKFromBObj(theXPrivacyAgreementBObj);

            if ((strPluggableID != null) && (strPluggableID.length() > 0)) {
                theXPrivacyAgreementBObj.getEObjXPrivacyAgreement().setPrivacyAgreementpkId(FunctionUtils.getLongFromString(strPluggableID));
            } else {
                strPluggableID = null;
                theXPrivacyAgreementBObj.getEObjXPrivacyAgreement().setPrivacyAgreementpkId(null);
            }
         Persistence theXPrivacyAgreementBObjPersistence = getBObjPersistenceFactory().createXPrivacyAgreementBObjPersistence(XPrivacyAgreementBObjQuery.XPRIVACY_AGREEMENT_ADD, theXPrivacyAgreementBObj);
         theXPrivacyAgreementBObjPersistence.persistAdd();

            response = new DWLResponse();
            response.setData(theXPrivacyAgreementBObj);
            response.setStatus(theXPrivacyAgreementBObj.getStatus());
    } catch (Exception ex) {
 				TCRMExceptionUtils.throwTCRMException(ex, new TCRMInsertException(ex.getMessage()), status,
                    DWLStatus.FATAL, DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_COMPONENT, TCRMErrorCode.INSERT_RECORD_ERROR,
                    DSEAAdditionsExtsErrorReasonCode.ADDXPRIVACYAGREEMENT_FAILED, theXPrivacyAgreementBObj.getControl(), errHandler);
        }
        
        return response;
    }
    

	
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction updateXPrivacyAgreement.
     *
     * @param theBObj
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleUpdateXPrivacyAgreement
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.UPDATE_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.UPDATE_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.UPDATEXPRIVACYAGREEMENT_FAILED
    )
     public DWLResponse updateXPrivacyAgreement(XPrivacyAgreementBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER updateXPrivacyAgreement(XPrivacyAgreementBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("updateXPrivacyAgreement", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction updateXPrivacyAgreement.";
      logger.finest("updateXPrivacyAgreement(XPrivacyAgreementBObj theBObj) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction updateXPrivacyAgreement.";
      logger.finest("updateXPrivacyAgreement(XPrivacyAgreementBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN updateXPrivacyAgreement(XPrivacyAgreementBObj theBObj) " + returnValue);
    }
        return retObj;
    }
    
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Updates the specified XPrivacyAgreement with new attribute values.
     *
     * @param theXPrivacyAgreementBObj
     *     The object that contains XPrivacyAgreement attribute values to be
     *     updated
     * @return
     *     DWLResponse containing a XPrivacyAgreementBObj of the updated object.
     * @exception Exception
     * @generated
     */
    public DWLResponse handleUpdateXPrivacyAgreement(XPrivacyAgreementBObj theXPrivacyAgreementBObj) throws Exception {

        DWLStatus status = theXPrivacyAgreementBObj.getStatus();

        if (status == null) {
            status = new DWLStatus();
            theXPrivacyAgreementBObj.setStatus(status);
        }
        
            // set lastupdatetxid with txnid from dwlcontrol
            theXPrivacyAgreementBObj.getEObjXPrivacyAgreement().setLastUpdateTxId(new Long(theXPrivacyAgreementBObj.getControl().getTxnId()));
         Persistence theXPrivacyAgreementBObjPersistence = getBObjPersistenceFactory().createXPrivacyAgreementBObjPersistence(XPrivacyAgreementBObjQuery.XPRIVACY_AGREEMENT_UPDATE, theXPrivacyAgreementBObj);
         theXPrivacyAgreementBObjPersistence.persistUpdate();

        DWLResponse response = createDWLResponse();
        response.setData(theXPrivacyAgreementBObj);
        response.setStatus(theXPrivacyAgreementBObj.getStatus());

        return response;
    }


	
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXRetailer.
     *
     * @param RetailerpkId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetXRetailer
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETXRETAILER_FAILED,
       beforePreExecuteMethod = "beforePreExecuteGetXRetailer"
    )
     public DWLResponse getXRetailer(String RetailerpkId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getXRetailer(String RetailerpkId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(RetailerpkId);
        DWLTransaction txObj = new  DWLTransactionInquiry("getXRetailer", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction getXRetailer.";
      logger.finest("getXRetailer(String RetailerpkId,  DWLControl control) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction getXRetailer.";
      logger.finest("getXRetailer(String RetailerpkId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getXRetailer(String RetailerpkId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }
    
    
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets a XRetailer from the database.
     * 
     * @generated
     */
    public DWLResponse handleGetXRetailer(String RetailerpkId,  DWLControl control) throws Exception {
        DWLStatus status = new DWLStatus();
        DWLResponse response = createDWLResponse();
        
        BObjQuery bObjQuery = null;
           
        String asOfDate = (String) control.get(DWLControl.INQUIRE_AS_OF_DATE);

        // History data inquiry: if inquireAsOfDate field has value in request xml 
        if (StringUtils.isNonBlank(asOfDate)) {
            Timestamp tsAsOfDate = getPITHistoryDate(asOfDate, DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_COMPONENT,
                                                     DSEAAdditionsExtsErrorReasonCode.GETXRETAILER_INVALID_INQUIRE_AS_OF_DATE_FORMAT,
                                                     status, control);

            bObjQuery = getBObjQueryFactory().createXRetailerBObjQuery(XRetailerBObjQuery.XRETAILER_HISTORY_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(RetailerpkId));
            bObjQuery.setParameter(1, tsAsOfDate);
            bObjQuery.setParameter(2, tsAsOfDate);
        } else {
            bObjQuery = getBObjQueryFactory().createXRetailerBObjQuery(XRetailerBObjQuery.XRETAILER_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(RetailerpkId));
        }


        XRetailerBObj o = (XRetailerBObj) bObjQuery.getSingleResult();
        if( o == null ){
        	return null;
        } 
        postRetrieveXRetailerBObj(o, "0", "ALL", control); 
          
        if (o.getStatus()==null) {
            o.setStatus(status);
        }
        response.addStatus(o.getStatus());
        response.setData(o);

      return response;
    }
    
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public void beforePreExecuteGetXRetailer(DWLTransaction transaction) throws DWLBaseException{
        // Check if the parameters are valid.
        Object[] arguments = getInquiryArgumentType((DWLTransactionInquiry)transaction);
        String pk = null;
        if (arguments!=null && arguments.length>0) {
            pk = (String)arguments[0];
        }
        // Check if the parameter passed in exists.
        if ((pk == null) || (pk.trim().length() == 0)) {
            TCRMExceptionUtils.throwTCRMException(null, new TCRMReadException(), transaction.getStatus(), DWLStatus.FATAL,
                DSEAAdditionsExtsComponentID.XRETAILER_BOBJ,
                TCRMErrorCode.FIELD_VALIDATION_ERROR,
                DSEAAdditionsExtsErrorReasonCode.XRETAILER_RETAILERPKID_NULL,
                transaction.getTxnControl(), errHandler);
        }
    }

	
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXRetailerByRetailerCode.
     *
     * @param RetailerCode
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetXRetailerByRetailerCode
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETXRETAILERBYRETAILERCODE_FAILED,
       beforePreExecuteMethod = "beforePreExecuteGetXRetailerByRetailerCode"
    )
     public DWLResponse getXRetailerByRetailerCode(String RetailerCode,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getXRetailerByRetailerCode(String RetailerCode,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(RetailerCode);
        DWLTransaction txObj = new  DWLTransactionInquiry("getXRetailerByRetailerCode", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction getXRetailerByRetailerCode.";
      logger.finest("getXRetailerByRetailerCode(String RetailerCode,  DWLControl control) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction getXRetailerByRetailerCode.";
      logger.finest("getXRetailerByRetailerCode(String RetailerCode,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getXRetailerByRetailerCode(String RetailerCode,  DWLControl control) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets a XRetailer from the database.
     * 
     * @generated
     */
    public DWLResponse handleGetXRetailerByRetailerCode(String RetailerCode,  DWLControl control) throws Exception {
        DWLStatus status = new DWLStatus();
        DWLResponse response = createDWLResponse();
        
        BObjQuery bObjQuery = null;
           
        String asOfDate = (String) control.get(DWLControl.INQUIRE_AS_OF_DATE);

        // History data inquiry: if inquireAsOfDate field has value in request xml 
        if (StringUtils.isNonBlank(asOfDate)) {
            Timestamp tsAsOfDate = getPITHistoryDate(asOfDate, DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_COMPONENT,
                                                     DSEAAdditionsExtsErrorReasonCode.GETXRETAILERBYRETAILERCODE_INVALID_INQUIRE_AS_OF_DATE_FORMAT,
                                                     status, control);

            bObjQuery = getBObjQueryFactory().createXRetailerBObjQuery(XRetailerBObjQuery.XRETAILER_BY_RETAILER_CODE_HISTORY_QUERY,
                		control);
            bObjQuery.setParameter(0, RetailerCode);
            bObjQuery.setParameter(1, tsAsOfDate);
            bObjQuery.setParameter(2, tsAsOfDate);
        } else {
            bObjQuery = getBObjQueryFactory().createXRetailerBObjQuery(XRetailerBObjQuery.XRETAILER_BY_RETAILER_CODE_QUERY,
                		control);
            bObjQuery.setParameter(0, RetailerCode);
        }


        XRetailerBObj o = (XRetailerBObj) bObjQuery.getSingleResult();
        if( o == null ){
        	return null;
        } 
        postRetrieveXRetailerBObj(o, "0", "ALL", control); 
          
        if (o.getStatus()==null) {
            o.setStatus(status);
        }
        response.addStatus(o.getStatus());
        response.setData(o);

      return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public void beforePreExecuteGetXRetailerByRetailerCode(DWLTransaction transaction) throws DWLBaseException{
        // Check if the parameters are valid.
        Object[] arguments = getInquiryArgumentType((DWLTransactionInquiry)transaction);
    if (arguments!=null && arguments.length>0) {
            // MDM_TODO0: CDKWB0003I Add argument validation logic
    }
    }

  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXRetailerByNDCode.
     *
     * @param NDCode
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetXRetailerByNDCode
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETXRETAILERBYNDCODE_FAILED,
       beforePreExecuteMethod = "beforePreExecuteGetXRetailerByNDCode"
    )
     public DWLResponse getXRetailerByNDCode(String NDCode,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getXRetailerByNDCode(String NDCode,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(NDCode);
        DWLTransaction txObj = new  DWLTransactionInquiry("getXRetailerByNDCode", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction getXRetailerByNDCode.";
      logger.finest("getXRetailerByNDCode(String NDCode,  DWLControl control) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction getXRetailerByNDCode.";
      logger.finest("getXRetailerByNDCode(String NDCode,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getXRetailerByNDCode(String NDCode,  DWLControl control) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets a XRetailer from the database.
     * 
     * @generated
     */
    public DWLResponse handleGetXRetailerByNDCode(String NDCode,  DWLControl control) throws Exception {
        DWLStatus status = new DWLStatus();
        DWLResponse response = createDWLResponse();
        
        BObjQuery bObjQuery = null;
           
        String asOfDate = (String) control.get(DWLControl.INQUIRE_AS_OF_DATE);

        // History data inquiry: if inquireAsOfDate field has value in request xml 
        if (StringUtils.isNonBlank(asOfDate)) {
            Timestamp tsAsOfDate = getPITHistoryDate(asOfDate, DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_COMPONENT,
                                                     DSEAAdditionsExtsErrorReasonCode.GETXRETAILERBYNDCODE_INVALID_INQUIRE_AS_OF_DATE_FORMAT,
                                                     status, control);

            bObjQuery = getBObjQueryFactory().createXRetailerBObjQuery(XRetailerBObjQuery.XRETAILER_BY_NDCODE_HISTORY_QUERY,
                		control);
            bObjQuery.setParameter(0, NDCode);
            bObjQuery.setParameter(1, tsAsOfDate);
            bObjQuery.setParameter(2, tsAsOfDate);
        } else {
            bObjQuery = getBObjQueryFactory().createXRetailerBObjQuery(XRetailerBObjQuery.XRETAILER_BY_NDCODE_QUERY,
                		control);
            bObjQuery.setParameter(0, NDCode);
        }


        XRetailerBObj o = (XRetailerBObj) bObjQuery.getSingleResult();
        if( o == null ){
        	return null;
        } 
        postRetrieveXRetailerBObj(o, "0", "ALL", control); 
          
        if (o.getStatus()==null) {
            o.setStatus(status);
        }
        response.addStatus(o.getStatus());
        response.setData(o);

      return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public void beforePreExecuteGetXRetailerByNDCode(DWLTransaction transaction) throws DWLBaseException{
        // Check if the parameters are valid.
        Object[] arguments = getInquiryArgumentType((DWLTransactionInquiry)transaction);
    if (arguments!=null && arguments.length>0) {
            // MDM_TODO0: CDKWB0003I Add argument validation logic
    }
    }

  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXRetailerByGSCode.
     *
     * @param GSCode
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetXRetailerByGSCode
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETXRETAILERBYGSCODE_FAILED,
       beforePreExecuteMethod = "beforePreExecuteGetXRetailerByGSCode"
    )
     public DWLResponse getXRetailerByGSCode(String GSCode,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getXRetailerByGSCode(String GSCode,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(GSCode);
        DWLTransaction txObj = new  DWLTransactionInquiry("getXRetailerByGSCode", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction getXRetailerByGSCode.";
      logger.finest("getXRetailerByGSCode(String GSCode,  DWLControl control) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction getXRetailerByGSCode.";
      logger.finest("getXRetailerByGSCode(String GSCode,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getXRetailerByGSCode(String GSCode,  DWLControl control) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets a XRetailer from the database.
     * 
     * @generated
     */
    public DWLResponse handleGetXRetailerByGSCode(String GSCode,  DWLControl control) throws Exception {
        DWLStatus status = new DWLStatus();
        DWLResponse response = createDWLResponse();
        
        BObjQuery bObjQuery = null;
           
        String asOfDate = (String) control.get(DWLControl.INQUIRE_AS_OF_DATE);

        // History data inquiry: if inquireAsOfDate field has value in request xml 
        if (StringUtils.isNonBlank(asOfDate)) {
            Timestamp tsAsOfDate = getPITHistoryDate(asOfDate, DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_COMPONENT,
                                                     DSEAAdditionsExtsErrorReasonCode.GETXRETAILERBYGSCODE_INVALID_INQUIRE_AS_OF_DATE_FORMAT,
                                                     status, control);

            bObjQuery = getBObjQueryFactory().createXRetailerBObjQuery(XRetailerBObjQuery.XRETAILER_BY_GSCODE_HISTORY_QUERY,
                		control);
            bObjQuery.setParameter(0, GSCode);
            bObjQuery.setParameter(1, tsAsOfDate);
            bObjQuery.setParameter(2, tsAsOfDate);
        } else {
            bObjQuery = getBObjQueryFactory().createXRetailerBObjQuery(XRetailerBObjQuery.XRETAILER_BY_GSCODE_QUERY,
                		control);
            bObjQuery.setParameter(0, GSCode);
        }


        XRetailerBObj o = (XRetailerBObj) bObjQuery.getSingleResult();
        if( o == null ){
        	return null;
        } 
        postRetrieveXRetailerBObj(o, "0", "ALL", control); 
          
        if (o.getStatus()==null) {
            o.setStatus(status);
        }
        response.addStatus(o.getStatus());
        response.setData(o);

      return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public void beforePreExecuteGetXRetailerByGSCode(DWLTransaction transaction) throws DWLBaseException{
        // Check if the parameters are valid.
        Object[] arguments = getInquiryArgumentType((DWLTransactionInquiry)transaction);
    if (arguments!=null && arguments.length>0) {
            // MDM_TODO0: CDKWB0003I Add argument validation logic
    }
    }

  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXRetailerByGSCodeAndMarketName.
     *
     * @param GSCode
     * @param MarketName
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetXRetailerByGSCodeAndMarketName
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETXRETAILERBYGSCODEANDMARKETNAME_FAILED,
       beforePreExecuteMethod = "beforePreExecuteGetXRetailerByGSCodeAndMarketName"
    )
     public DWLResponse getXRetailerByGSCodeAndMarketName(String GSCode, String MarketName,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getXRetailerByGSCodeAndMarketName(String GSCode, String MarketName,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(GSCode);
        params.add(MarketName);
        DWLTransaction txObj = new  DWLTransactionInquiry("getXRetailerByGSCodeAndMarketName", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction getXRetailerByGSCodeAndMarketName.";
      logger.finest("getXRetailerByGSCodeAndMarketName(String GSCode, String MarketName,  DWLControl control) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction getXRetailerByGSCodeAndMarketName.";
      logger.finest("getXRetailerByGSCodeAndMarketName(String GSCode, String MarketName,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getXRetailerByGSCodeAndMarketName(String GSCode, String MarketName,  DWLControl control) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets a XRetailer from the database.
     * 
     * @generated
     */
    public DWLResponse handleGetXRetailerByGSCodeAndMarketName(String GSCode, String MarketName,  DWLControl control) throws Exception {
        DWLStatus status = new DWLStatus();
        DWLResponse response = createDWLResponse();
        
        BObjQuery bObjQuery = null;
           
        String asOfDate = (String) control.get(DWLControl.INQUIRE_AS_OF_DATE);

        // History data inquiry: if inquireAsOfDate field has value in request xml 
        if (StringUtils.isNonBlank(asOfDate)) {
            Timestamp tsAsOfDate = getPITHistoryDate(asOfDate, DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_COMPONENT,
                                                     DSEAAdditionsExtsErrorReasonCode.GETXRETAILERBYGSCODEANDMARKETNAME_INVALID_INQUIRE_AS_OF_DATE_FORMAT,
                                                     status, control);

            bObjQuery = getBObjQueryFactory().createXRetailerBObjQuery(XRetailerBObjQuery.XRETAILER_BY_GSCODE_AND_MARKET_NAME_HISTORY_QUERY,
                		control);
            bObjQuery.setParameter(0, GSCode);
            bObjQuery.setParameter(1, MarketName);
            bObjQuery.setParameter(2, tsAsOfDate);
            bObjQuery.setParameter(3, tsAsOfDate);
        } else {
            bObjQuery = getBObjQueryFactory().createXRetailerBObjQuery(XRetailerBObjQuery.XRETAILER_BY_GSCODE_AND_MARKET_NAME_QUERY,
                		control);
            bObjQuery.setParameter(0, GSCode);
            bObjQuery.setParameter(1, MarketName);
        }


        XRetailerBObj o = (XRetailerBObj) bObjQuery.getSingleResult();
        if( o == null ){
        	return null;
        } 
        postRetrieveXRetailerBObj(o, "0", "ALL", control); 
          
        if (o.getStatus()==null) {
            o.setStatus(status);
        }
        response.addStatus(o.getStatus());
        response.setData(o);

      return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public void beforePreExecuteGetXRetailerByGSCodeAndMarketName(DWLTransaction transaction) throws DWLBaseException{
        // Check if the parameters are valid.
        Object[] arguments = getInquiryArgumentType((DWLTransactionInquiry)transaction);
    if (arguments!=null && arguments.length>0) {
            // MDM_TODO0: CDKWB0003I Add argument validation logic
    }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXRetailerByRetailerCodeAndMarketName.
     *
     * @param RetailerCode
     * @param MarketName
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetXRetailerByRetailerCodeAndMarketName
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETXRETAILERBYRETAILERCODEANDMARKETNAME_FAILED,
       beforePreExecuteMethod = "beforePreExecuteGetXRetailerByRetailerCodeAndMarketName"
    )
     public DWLResponse getXRetailerByRetailerCodeAndMarketName(String RetailerCode, String MarketName,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getXRetailerByRetailerCodeAndMarketName(String RetailerCode, String MarketName,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(RetailerCode);
        params.add(MarketName);
        DWLTransaction txObj = new  DWLTransactionInquiry("getXRetailerByRetailerCodeAndMarketName", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction getXRetailerByRetailerCodeAndMarketName.";
      logger.finest("getXRetailerByRetailerCodeAndMarketName(String RetailerCode, String MarketName,  DWLControl control) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction getXRetailerByRetailerCodeAndMarketName.";
      logger.finest("getXRetailerByRetailerCodeAndMarketName(String RetailerCode, String MarketName,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getXRetailerByRetailerCodeAndMarketName(String RetailerCode, String MarketName,  DWLControl control) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets a XRetailer from the database.
     * 
     * @generated
     */
    public DWLResponse handleGetXRetailerByRetailerCodeAndMarketName(String RetailerCode, String MarketName,  DWLControl control) throws Exception {
        DWLStatus status = new DWLStatus();
        DWLResponse response = createDWLResponse();
        
        BObjQuery bObjQuery = null;
           
        String asOfDate = (String) control.get(DWLControl.INQUIRE_AS_OF_DATE);

        // History data inquiry: if inquireAsOfDate field has value in request xml 
        if (StringUtils.isNonBlank(asOfDate)) {
            Timestamp tsAsOfDate = getPITHistoryDate(asOfDate, DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_COMPONENT,
                                                     DSEAAdditionsExtsErrorReasonCode.GETXRETAILERBYRETAILERCODEANDMARKETNAME_INVALID_INQUIRE_AS_OF_DATE_FORMAT,
                                                     status, control);

            bObjQuery = getBObjQueryFactory().createXRetailerBObjQuery(XRetailerBObjQuery.XRETAILER_BY_RETAILER_CODE_AND_MARKET_NAME_HISTORY_QUERY,
                		control);
            bObjQuery.setParameter(0, RetailerCode);
            bObjQuery.setParameter(1, MarketName);
            bObjQuery.setParameter(2, tsAsOfDate);
            bObjQuery.setParameter(3, tsAsOfDate);
        } else {
            bObjQuery = getBObjQueryFactory().createXRetailerBObjQuery(XRetailerBObjQuery.XRETAILER_BY_RETAILER_CODE_AND_MARKET_NAME_QUERY,
                		control);
            bObjQuery.setParameter(0, RetailerCode);
            bObjQuery.setParameter(1, MarketName);
        }


        XRetailerBObj o = (XRetailerBObj) bObjQuery.getSingleResult();
        if( o == null ){
        	return null;
        } 
        postRetrieveXRetailerBObj(o, "0", "ALL", control); 
          
        if (o.getStatus()==null) {
            o.setStatus(status);
        }
        response.addStatus(o.getStatus());
        response.setData(o);

      return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public void beforePreExecuteGetXRetailerByRetailerCodeAndMarketName(DWLTransaction transaction) throws DWLBaseException{
        // Check if the parameters are valid.
        Object[] arguments = getInquiryArgumentType((DWLTransactionInquiry)transaction);
    if (arguments!=null && arguments.length>0) {
            // MDM_TODO0: CDKWB0003I Add argument validation logic
    }
    }

  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXRetailerByNDCodeAndMarketName.
     *
     * @param NDCode
     * @param MarketName
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetXRetailerByNDCodeAndMarketName
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETXRETAILERBYNDCODEANDMARKETNAME_FAILED,
       beforePreExecuteMethod = "beforePreExecuteGetXRetailerByNDCodeAndMarketName"
    )
     public DWLResponse getXRetailerByNDCodeAndMarketName(String NDCode, String MarketName,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getXRetailerByNDCodeAndMarketName(String NDCode, String MarketName,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(NDCode);
        params.add(MarketName);
        DWLTransaction txObj = new  DWLTransactionInquiry("getXRetailerByNDCodeAndMarketName", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction getXRetailerByNDCodeAndMarketName.";
      logger.finest("getXRetailerByNDCodeAndMarketName(String NDCode, String MarketName,  DWLControl control) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction getXRetailerByNDCodeAndMarketName.";
      logger.finest("getXRetailerByNDCodeAndMarketName(String NDCode, String MarketName,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getXRetailerByNDCodeAndMarketName(String NDCode, String MarketName,  DWLControl control) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets a XRetailer from the database.
     * 
     * @generated
     */
    public DWLResponse handleGetXRetailerByNDCodeAndMarketName(String NDCode, String MarketName,  DWLControl control) throws Exception {
        DWLStatus status = new DWLStatus();
        DWLResponse response = createDWLResponse();
        
        BObjQuery bObjQuery = null;
           
        String asOfDate = (String) control.get(DWLControl.INQUIRE_AS_OF_DATE);

        // History data inquiry: if inquireAsOfDate field has value in request xml 
        if (StringUtils.isNonBlank(asOfDate)) {
            Timestamp tsAsOfDate = getPITHistoryDate(asOfDate, DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_COMPONENT,
                                                     DSEAAdditionsExtsErrorReasonCode.GETXRETAILERBYNDCODEANDMARKETNAME_INVALID_INQUIRE_AS_OF_DATE_FORMAT,
                                                     status, control);

            bObjQuery = getBObjQueryFactory().createXRetailerBObjQuery(XRetailerBObjQuery.XRETAILER_BY_NDCODE_AND_MARKET_NAME_HISTORY_QUERY,
                		control);
            bObjQuery.setParameter(0, NDCode);
            bObjQuery.setParameter(1, MarketName);
            bObjQuery.setParameter(2, tsAsOfDate);
            bObjQuery.setParameter(3, tsAsOfDate);
        } else {
            bObjQuery = getBObjQueryFactory().createXRetailerBObjQuery(XRetailerBObjQuery.XRETAILER_BY_NDCODE_AND_MARKET_NAME_QUERY,
                		control);
            bObjQuery.setParameter(0, NDCode);
            bObjQuery.setParameter(1, MarketName);
        }


        XRetailerBObj o = (XRetailerBObj) bObjQuery.getSingleResult();
        if( o == null ){
        	return null;
        } 
        postRetrieveXRetailerBObj(o, "0", "ALL", control); 
          
        if (o.getStatus()==null) {
            o.setStatus(status);
        }
        response.addStatus(o.getStatus());
        response.setData(o);

      return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public void beforePreExecuteGetXRetailerByNDCodeAndMarketName(DWLTransaction transaction) throws DWLBaseException{
        // Check if the parameters are valid.
        Object[] arguments = getInquiryArgumentType((DWLTransactionInquiry)transaction);
    if (arguments!=null && arguments.length>0) {
            // MDM_TODO0: CDKWB0003I Add argument validation logic
    }
    }

  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction addXRetailer.
     *
     * @param theBObj
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleAddXRetailer
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.ADD_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.INSERT_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.ADDXRETAILER_FAILED
    )
     public DWLResponse addXRetailer(XRetailerBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER addXRetailer(XRetailerBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("addXRetailer", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction addXRetailer.";
      logger.finest("addXRetailer(XRetailerBObj theBObj) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction addXRetailer.";
      logger.finest("addXRetailer(XRetailerBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN addXRetailer(XRetailerBObj theBObj) " + returnValue);
    }
        return retObj;
    }
    
    
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Adds a XRetailer to the database.
     *
     * @param theXRetailerBObj
     *     The object that contains XRetailer attribute values.
     * @return
     *     DWLResponse containing a XRetailerBObj object.
     * @exception Exception
     * @generated
     */
    public DWLResponse handleAddXRetailer(XRetailerBObj theXRetailerBObj) throws Exception {
        DWLResponse response = null;
        DWLStatus status = theXRetailerBObj.getStatus();
        if (status == null) {
            status = new DWLStatus();
            theXRetailerBObj.setStatus(status);
        }

        String strPluggableID = null;

        try {
            // Pluggable Key Structure implementation
            strPluggableID = getSuppliedIdPKFromBObj(theXRetailerBObj);

            if ((strPluggableID != null) && (strPluggableID.length() > 0)) {
                theXRetailerBObj.getEObjXRetailer().setRetailerpkId(FunctionUtils.getLongFromString(strPluggableID));
            } else {
                strPluggableID = null;
                theXRetailerBObj.getEObjXRetailer().setRetailerpkId(null);
            }
         Persistence theXRetailerBObjPersistence = getBObjPersistenceFactory().createXRetailerBObjPersistence(XRetailerBObjQuery.XRETAILER_ADD, theXRetailerBObj);
         theXRetailerBObjPersistence.persistAdd();

            response = new DWLResponse();
            response.setData(theXRetailerBObj);
            response.setStatus(theXRetailerBObj.getStatus());
    } catch (Exception ex) {
 				TCRMExceptionUtils.throwTCRMException(ex, new TCRMInsertException(ex.getMessage()), status,
                    DWLStatus.FATAL, DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_COMPONENT, TCRMErrorCode.INSERT_RECORD_ERROR,
                    DSEAAdditionsExtsErrorReasonCode.ADDXRETAILER_FAILED, theXRetailerBObj.getControl(), errHandler);
        }
        
        return response;
    }
    

	
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction updateXRetailer.
     *
     * @param theBObj
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleUpdateXRetailer
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.UPDATE_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.UPDATE_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.UPDATEXRETAILER_FAILED
    )
     public DWLResponse updateXRetailer(XRetailerBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER updateXRetailer(XRetailerBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("updateXRetailer", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction updateXRetailer.";
      logger.finest("updateXRetailer(XRetailerBObj theBObj) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction updateXRetailer.";
      logger.finest("updateXRetailer(XRetailerBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN updateXRetailer(XRetailerBObj theBObj) " + returnValue);
    }
        return retObj;
    }
    
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Updates the specified XRetailer with new attribute values.
     *
     * @param theXRetailerBObj
     *     The object that contains XRetailer attribute values to be updated
     * @return
     *     DWLResponse containing a XRetailerBObj of the updated object.
     * @exception Exception
     * @generated
     */
    public DWLResponse handleUpdateXRetailer(XRetailerBObj theXRetailerBObj) throws Exception {

        DWLStatus status = theXRetailerBObj.getStatus();

        if (status == null) {
            status = new DWLStatus();
            theXRetailerBObj.setStatus(status);
        }
        
            // set lastupdatetxid with txnid from dwlcontrol
            theXRetailerBObj.getEObjXRetailer().setLastUpdateTxId(new Long(theXRetailerBObj.getControl().getTxnId()));
         Persistence theXRetailerBObjPersistence = getBObjPersistenceFactory().createXRetailerBObjPersistence(XRetailerBObjQuery.XRETAILER_UPDATE, theXRetailerBObj);
         theXRetailerBObjPersistence.persistUpdate();

        DWLResponse response = createDWLResponse();
        response.setData(theXRetailerBObj);
        response.setStatus(theXRetailerBObj.getStatus());

        return response;
    }


	
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXCustomerRetailer.
     *
     * @param CustomerRetailerpkId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetXCustomerRetailer
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETXCUSTOMERRETAILER_FAILED,
       beforePreExecuteMethod = "beforePreExecuteGetXCustomerRetailer"
    )
     public DWLResponse getXCustomerRetailer(String CustomerRetailerpkId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getXCustomerRetailer(String CustomerRetailerpkId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(CustomerRetailerpkId);
        DWLTransaction txObj = new  DWLTransactionInquiry("getXCustomerRetailer", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction getXCustomerRetailer.";
      logger.finest("getXCustomerRetailer(String CustomerRetailerpkId,  DWLControl control) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction getXCustomerRetailer.";
      logger.finest("getXCustomerRetailer(String CustomerRetailerpkId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getXCustomerRetailer(String CustomerRetailerpkId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }
    
    
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets a XCustomerRetailer from the database.
     * 
     * @generated
     */
    public DWLResponse handleGetXCustomerRetailer(String CustomerRetailerpkId,  DWLControl control) throws Exception {
        DWLStatus status = new DWLStatus();
        DWLResponse response = createDWLResponse();
        
        BObjQuery bObjQuery = null;
           
        String asOfDate = (String) control.get(DWLControl.INQUIRE_AS_OF_DATE);

        // History data inquiry: if inquireAsOfDate field has value in request xml 
        if (StringUtils.isNonBlank(asOfDate)) {
            Timestamp tsAsOfDate = getPITHistoryDate(asOfDate, DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_COMPONENT,
                                                     DSEAAdditionsExtsErrorReasonCode.GETXCUSTOMERRETAILER_INVALID_INQUIRE_AS_OF_DATE_FORMAT,
                                                     status, control);

            bObjQuery = getBObjQueryFactory().createXCustomerRetailerBObjQuery(XCustomerRetailerBObjQuery.XCUSTOMER_RETAILER_HISTORY_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(CustomerRetailerpkId));
            bObjQuery.setParameter(1, tsAsOfDate);
            bObjQuery.setParameter(2, tsAsOfDate);
        } else {
            bObjQuery = getBObjQueryFactory().createXCustomerRetailerBObjQuery(XCustomerRetailerBObjQuery.XCUSTOMER_RETAILER_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(CustomerRetailerpkId));
        }


        XCustomerRetailerBObj o = (XCustomerRetailerBObj) bObjQuery.getSingleResult();
        if( o == null ){
        	return null;
        } 
        postRetrieveXCustomerRetailerBObj(o, "0", "ALL", control); 
          
        if (o.getStatus()==null) {
            o.setStatus(status);
        }
        response.addStatus(o.getStatus());
        response.setData(o);

      return response;
    }
    
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public void beforePreExecuteGetXCustomerRetailer(DWLTransaction transaction) throws DWLBaseException{
        // Check if the parameters are valid.
        Object[] arguments = getInquiryArgumentType((DWLTransactionInquiry)transaction);
        String pk = null;
        if (arguments!=null && arguments.length>0) {
            pk = (String)arguments[0];
        }
        // Check if the parameter passed in exists.
        if ((pk == null) || (pk.trim().length() == 0)) {
            TCRMExceptionUtils.throwTCRMException(null, new TCRMReadException(), transaction.getStatus(), DWLStatus.FATAL,
                DSEAAdditionsExtsComponentID.XCUSTOMER_RETAILER_BOBJ,
                TCRMErrorCode.FIELD_VALIDATION_ERROR,
                DSEAAdditionsExtsErrorReasonCode.XCUSTOMERRETAILER_CUSTOMERRETAILERPKID_NULL,
                transaction.getTxnControl(), errHandler);
        }
    }

	
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getAllXCustomerRetailerByPartyId.
     *
     * @param ContId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetAllXCustomerRetailerByPartyId
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETALLXCUSTOMERRETAILERBYPARTYID_FAILED,
       beforePreExecuteMethod = "beforePreExecuteGetAllXCustomerRetailerByPartyId"
    )
     public DWLResponse getAllXCustomerRetailerByPartyId(String ContId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getAllXCustomerRetailerByPartyId(String ContId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(ContId);
        DWLTransaction txObj = new  DWLTransactionInquiry("getAllXCustomerRetailerByPartyId", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction getAllXCustomerRetailerByPartyId.";
      logger.finest("getAllXCustomerRetailerByPartyId(String ContId,  DWLControl control) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction getAllXCustomerRetailerByPartyId.";
      logger.finest("getAllXCustomerRetailerByPartyId(String ContId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getAllXCustomerRetailerByPartyId(String ContId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets a XCustomerRetailer from the database.
     * 
     * @generated
     */
    public DWLResponse handleGetAllXCustomerRetailerByPartyId(String ContId,  DWLControl control) throws Exception {
        DWLStatus status = new DWLStatus();
        DWLResponse response = createDWLResponse();
        
        BObjQuery bObjQuery = null;
           
        String asOfDate = (String) control.get(DWLControl.INQUIRE_AS_OF_DATE);

        // History data inquiry: if inquireAsOfDate field has value in request xml 
        if (StringUtils.isNonBlank(asOfDate)) {
            Timestamp tsAsOfDate = getPITHistoryDate(asOfDate, DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_COMPONENT,
                                                     DSEAAdditionsExtsErrorReasonCode.GETALLXCUSTOMERRETAILERBYPARTYID_INVALID_INQUIRE_AS_OF_DATE_FORMAT,
                                                     status, control);

            bObjQuery = getBObjQueryFactory().createXCustomerRetailerBObjQuery(XCustomerRetailerBObjQuery.ALL_XCUSTOMER_RETAILER_BY_PARTY_ID_HISTORY_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(ContId));
            bObjQuery.setParameter(1, tsAsOfDate);
            bObjQuery.setParameter(2, tsAsOfDate);
        } else {
            bObjQuery = getBObjQueryFactory().createXCustomerRetailerBObjQuery(XCustomerRetailerBObjQuery.ALL_XCUSTOMER_RETAILER_BY_PARTY_ID_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(ContId));
        }

        boolean considerForPagination = PaginationUtils
                            .considerForPagintion(XCustomerRetailerBObj.class.getName(), control);
        control.setConsiderForPagintionFlag(considerForPagination);

        // set returned object
        List<?> list = bObjQuery.getResults();

        if (list.size() == 0) {
            return null;
        }
    Vector<XCustomerRetailerBObj> vector = new Vector<XCustomerRetailerBObj>();
        for (Iterator<?> it = list.iterator(); it.hasNext();) {
            XCustomerRetailerBObj o = (XCustomerRetailerBObj) it.next();
            postRetrieveXCustomerRetailerBObj(o, "0", "ALL", control); 
            vector.add(o);
          
            if (o.getStatus()==null) {
                o.setStatus(status);
            }
            response.addStatus(o.getStatus());
        }
        response.setData(vector);

      return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public void beforePreExecuteGetAllXCustomerRetailerByPartyId(DWLTransaction transaction) throws DWLBaseException{
        // Check if the parameters are valid.
        Object[] arguments = getInquiryArgumentType((DWLTransactionInquiry)transaction);
    if (arguments!=null && arguments.length>0) {
            // MDM_TODO0: CDKWB0003I Add argument validation logic
    }
    }

  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction addXCustomerRetailer.
     *
     * @param theBObj
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleAddXCustomerRetailer
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.ADD_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.INSERT_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.ADDXCUSTOMERRETAILER_FAILED
    )
     public DWLResponse addXCustomerRetailer(XCustomerRetailerBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER addXCustomerRetailer(XCustomerRetailerBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("addXCustomerRetailer", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction addXCustomerRetailer.";
      logger.finest("addXCustomerRetailer(XCustomerRetailerBObj theBObj) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction addXCustomerRetailer.";
      logger.finest("addXCustomerRetailer(XCustomerRetailerBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN addXCustomerRetailer(XCustomerRetailerBObj theBObj) " + returnValue);
    }
        return retObj;
    }
    
    
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Adds a XCustomerRetailer to the database.
     *
     * @param theXCustomerRetailerBObj
     *     The object that contains XCustomerRetailer attribute values.
     * @return
     *     DWLResponse containing a XCustomerRetailerBObj object.
     * @exception Exception
     * @generated NOT
     */
     public DWLResponse handleAddXCustomerRetailer(XCustomerRetailerBObj theXCustomerRetailerBObj) throws Exception {
         DWLResponse response = null;
         DWLStatus status = theXCustomerRetailerBObj.getStatus();
         if (status == null) {
             status = new DWLStatus();
             theXCustomerRetailerBObj.setStatus(status);
         }
         XRetailerBObj childXRetailerBObj = theXCustomerRetailerBObj.getXRetailerBObj();
        // need to changes to stop the add update retailer 
         
         
         String marketName = theXCustomerRetailerBObj.getObjectReferenceId();
		 String marketAU = "AU";
		 String marketNZ = "NZ";
		 String marketTUR = "TUR";
		 String marketKOR = "KOR";
		 
		 if (!marketAU.equalsIgnoreCase(marketName) && !marketNZ.equalsIgnoreCase(marketName) 
				 && !marketTUR.equalsIgnoreCase(marketName) 
				&& !marketKOR.equalsIgnoreCase(marketName)){
         String containedPk = null;
 		if( childXRetailerBObj != null && childXRetailerBObj.getRetailerpkId()==null){
         	
             addXRetailer(childXRetailerBObj);
             containedPk = childXRetailerBObj.getRetailerpkId ();
             theXCustomerRetailerBObj.setRetailerId( containedPk );
    	     	theXCustomerRetailerBObj.setXRetailerBObj(childXRetailerBObj);
			} /*else {
        updateXRetailer(childXRetailerBObj);
        containedPk = childXRetailerBObj.getRetailerpkId ();
        theXCustomerRetailerBObj.setXRetailerBObj(childXRetailerBObj);
      }*/
      }

        String strPluggableID = null;

        try {
            // Pluggable Key Structure implementation
            strPluggableID = getSuppliedIdPKFromBObj(theXCustomerRetailerBObj);

            if ((strPluggableID != null) && (strPluggableID.length() > 0)) {
                theXCustomerRetailerBObj.getEObjXCustomerRetailer().setCustomerRetailerpkId(FunctionUtils.getLongFromString(strPluggableID));
            } else {
                strPluggableID = null;
                theXCustomerRetailerBObj.getEObjXCustomerRetailer().setCustomerRetailerpkId(null);
            }
         Persistence theXCustomerRetailerBObjPersistence = getBObjPersistenceFactory().createXCustomerRetailerBObjPersistence(XCustomerRetailerBObjQuery.XCUSTOMER_RETAILER_ADD, theXCustomerRetailerBObj);
         theXCustomerRetailerBObjPersistence.persistAdd();

            String pkId = theXCustomerRetailerBObj.getCustomerRetailerpkId ();			

            @SuppressWarnings("rawtypes")
            Vector vecXCustomerRetailerRoleBObj = theXCustomerRetailerBObj.getItemsXCustomerRetailerRoleBObj();
            for (int i = 0; i < vecXCustomerRetailerRoleBObj.size(); i++) {
                XCustomerRetailerRoleBObj object = (XCustomerRetailerRoleBObj)vecXCustomerRetailerRoleBObj.elementAt(i);
                object.setCustomerRetailerId(pkId);
                addXCustomerRetailerRole(object);
            }
            response = new DWLResponse();
            response.setData(theXCustomerRetailerBObj);
            response.setStatus(theXCustomerRetailerBObj.getStatus());
    } catch (Exception ex) {
 				TCRMExceptionUtils.throwTCRMException(ex, new TCRMInsertException(ex.getMessage()), status,
                    DWLStatus.FATAL, DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_COMPONENT, TCRMErrorCode.INSERT_RECORD_ERROR,
                    DSEAAdditionsExtsErrorReasonCode.ADDXCUSTOMERRETAILER_FAILED, theXCustomerRetailerBObj.getControl(), errHandler);
        }
        
        return response;
    }
    

	
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction updateXCustomerRetailer.
     *
     * @param theBObj
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleUpdateXCustomerRetailer
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.UPDATE_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.UPDATE_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.UPDATEXCUSTOMERRETAILER_FAILED
    , manuallyHandleRedundantUpdateCheck="true"
    )
     public DWLResponse updateXCustomerRetailer(XCustomerRetailerBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER updateXCustomerRetailer(XCustomerRetailerBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("updateXCustomerRetailer", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction updateXCustomerRetailer.";
      logger.finest("updateXCustomerRetailer(XCustomerRetailerBObj theBObj) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction updateXCustomerRetailer.";
      logger.finest("updateXCustomerRetailer(XCustomerRetailerBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN updateXCustomerRetailer(XCustomerRetailerBObj theBObj) " + returnValue);
    }
        return retObj;
    }
    
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Updates the specified XCustomerRetailer with new attribute values.
     *
     * @param theXCustomerRetailerBObj
     *     The object that contains XCustomerRetailer attribute values to be
     *     updated
     * @return
     *     DWLResponse containing a XCustomerRetailerBObj of the updated object.
     * @exception Exception
     * @generated
     */
    public DWLResponse handleUpdateXCustomerRetailer(XCustomerRetailerBObj theXCustomerRetailerBObj) throws Exception {

        DWLStatus status = theXCustomerRetailerBObj.getStatus();

        if (status == null) {
            status = new DWLStatus();
            theXCustomerRetailerBObj.setStatus(status);
        }
        
    if( !theXCustomerRetailerBObj.isRedundantUpdate() ){
            // set lastupdatetxid with txnid from dwlcontrol
            theXCustomerRetailerBObj.getEObjXCustomerRetailer().setLastUpdateTxId(new Long(theXCustomerRetailerBObj.getControl().getTxnId()));
            Persistence theXCustomerRetailerBObjPersistence = getBObjPersistenceFactory().createXCustomerRetailerBObjPersistence(XCustomerRetailerBObjQuery.XCUSTOMER_RETAILER_UPDATE, theXCustomerRetailerBObj);
            theXCustomerRetailerBObjPersistence.persistUpdate();
        }

    String pkId = theXCustomerRetailerBObj.getCustomerRetailerpkId();			

    @SuppressWarnings("rawtypes")
    Vector vecXCustomerRetailerRoleBObj = theXCustomerRetailerBObj.getItemsXCustomerRetailerRoleBObj();
    for (int i = 0; i < vecXCustomerRetailerRoleBObj.size(); i++) {
      XCustomerRetailerRoleBObj object = (XCustomerRetailerRoleBObj)vecXCustomerRetailerRoleBObj.elementAt(i);
      
      String ref = object.getCustomerRetailerId();
      if (ref != null && !ref.equals(pkId)) {
        TCRMExceptionUtils.throwTCRMException(null, new TCRMDataInvalidException(),
          status,
          DWLStatus.FATAL,
          DSEAAdditionsExtsComponentID.XCUSTOMER_RETAILER_BOBJ,
          TCRMErrorCode.DATA_INVALID_ERROR,
          DSEAAdditionsExtsErrorReasonCode.XCUSTOMERRETAILER_XCUSTOMERRETAILERROLE_REFERENCE_INVALID,
          theXCustomerRetailerBObj.getControl(),
          errHandler);
      }
      
      object.setCustomerRetailerId(pkId);
      
      if (object.getEObjXCustomerRetailerRole().getPrimaryKey() == null){
        addXCustomerRetailerRole(object);
      } else {
        updateXCustomerRetailerRole(object);
      }
    }
        DWLResponse response = createDWLResponse();
        response.setData(theXCustomerRetailerBObj);
        response.setStatus(theXCustomerRetailerBObj.getStatus());

        return response;
    }


	
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXCustomerRetailerRole.
     *
     * @param CustomerRetailerRolepkId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetXCustomerRetailerRole
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETXCUSTOMERRETAILERROLE_FAILED,
       beforePreExecuteMethod = "beforePreExecuteGetXCustomerRetailerRole"
    )
     public DWLResponse getXCustomerRetailerRole(String CustomerRetailerRolepkId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getXCustomerRetailerRole(String CustomerRetailerRolepkId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(CustomerRetailerRolepkId);
        DWLTransaction txObj = new  DWLTransactionInquiry("getXCustomerRetailerRole", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction getXCustomerRetailerRole.";
      logger.finest("getXCustomerRetailerRole(String CustomerRetailerRolepkId,  DWLControl control) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction getXCustomerRetailerRole.";
      logger.finest("getXCustomerRetailerRole(String CustomerRetailerRolepkId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getXCustomerRetailerRole(String CustomerRetailerRolepkId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }
    
    
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets a XCustomerRetailerRole from the database.
     * 
     * @generated
     */
    public DWLResponse handleGetXCustomerRetailerRole(String CustomerRetailerRolepkId,  DWLControl control) throws Exception {
        DWLStatus status = new DWLStatus();
        DWLResponse response = createDWLResponse();
        
        BObjQuery bObjQuery = null;
           
        String asOfDate = (String) control.get(DWLControl.INQUIRE_AS_OF_DATE);

        // History data inquiry: if inquireAsOfDate field has value in request xml 
        if (StringUtils.isNonBlank(asOfDate)) {
            Timestamp tsAsOfDate = getPITHistoryDate(asOfDate, DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_COMPONENT,
                                                     DSEAAdditionsExtsErrorReasonCode.GETXCUSTOMERRETAILERROLE_INVALID_INQUIRE_AS_OF_DATE_FORMAT,
                                                     status, control);

            bObjQuery = getBObjQueryFactory().createXCustomerRetailerRoleBObjQuery(XCustomerRetailerRoleBObjQuery.XCUSTOMER_RETAILER_ROLE_HISTORY_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(CustomerRetailerRolepkId));
            bObjQuery.setParameter(1, tsAsOfDate);
            bObjQuery.setParameter(2, tsAsOfDate);
        } else {
            bObjQuery = getBObjQueryFactory().createXCustomerRetailerRoleBObjQuery(XCustomerRetailerRoleBObjQuery.XCUSTOMER_RETAILER_ROLE_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(CustomerRetailerRolepkId));
        }


        XCustomerRetailerRoleBObj o = (XCustomerRetailerRoleBObj) bObjQuery.getSingleResult();
        if( o == null ){
        	return null;
        } 
        postRetrieveXCustomerRetailerRoleBObj(o, "0", "ALL", control); 
          
        if (o.getStatus()==null) {
            o.setStatus(status);
        }
        response.addStatus(o.getStatus());
        response.setData(o);

      return response;
    }
    
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public void beforePreExecuteGetXCustomerRetailerRole(DWLTransaction transaction) throws DWLBaseException{
        // Check if the parameters are valid.
        Object[] arguments = getInquiryArgumentType((DWLTransactionInquiry)transaction);
        String pk = null;
        if (arguments!=null && arguments.length>0) {
            pk = (String)arguments[0];
        }
        // Check if the parameter passed in exists.
        if ((pk == null) || (pk.trim().length() == 0)) {
            TCRMExceptionUtils.throwTCRMException(null, new TCRMReadException(), transaction.getStatus(), DWLStatus.FATAL,
                DSEAAdditionsExtsComponentID.XCUSTOMER_RETAILER_ROLE_BOBJ,
                TCRMErrorCode.FIELD_VALIDATION_ERROR,
                DSEAAdditionsExtsErrorReasonCode.XCUSTOMERRETAILERROLE_CUSTOMERRETAILERROLEPKID_NULL,
                transaction.getTxnControl(), errHandler);
        }
    }

	
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getAllRetailerRoleByCustomerRetailerId.
     *
     * @param CustomerRetailerId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetAllRetailerRoleByCustomerRetailerId
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETALLRETAILERROLEBYCUSTOMERRETAILERID_FAILED,
       beforePreExecuteMethod = "beforePreExecuteGetAllRetailerRoleByCustomerRetailerId"
    )
     public DWLResponse getAllRetailerRoleByCustomerRetailerId(String CustomerRetailerId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getAllRetailerRoleByCustomerRetailerId(String CustomerRetailerId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(CustomerRetailerId);
        DWLTransaction txObj = new  DWLTransactionInquiry("getAllRetailerRoleByCustomerRetailerId", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction getAllRetailerRoleByCustomerRetailerId.";
      logger.finest("getAllRetailerRoleByCustomerRetailerId(String CustomerRetailerId,  DWLControl control) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction getAllRetailerRoleByCustomerRetailerId.";
      logger.finest("getAllRetailerRoleByCustomerRetailerId(String CustomerRetailerId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getAllRetailerRoleByCustomerRetailerId(String CustomerRetailerId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }
    
    
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets a XCustomerRetailerRole from the database.
     * 
     * @generated
     */
    public DWLResponse handleGetAllRetailerRoleByCustomerRetailerId(String CustomerRetailerId,  DWLControl control) throws Exception {
        DWLStatus status = new DWLStatus();
        DWLResponse response = createDWLResponse();
        
        BObjQuery bObjQuery = null;
           
        String asOfDate = (String) control.get(DWLControl.INQUIRE_AS_OF_DATE);

        // History data inquiry: if inquireAsOfDate field has value in request xml 
        if (StringUtils.isNonBlank(asOfDate)) {
            Timestamp tsAsOfDate = getPITHistoryDate(asOfDate, DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_COMPONENT,
                                                     DSEAAdditionsExtsErrorReasonCode.GETALLRETAILERROLEBYCUSTOMERRETAILERID_INVALID_INQUIRE_AS_OF_DATE_FORMAT,
                                                     status, control);

            bObjQuery = getBObjQueryFactory().createXCustomerRetailerRoleBObjQuery(XCustomerRetailerRoleBObjQuery.ALL_RETAILER_ROLE_BY_CUSTOMER_RETAILER_ID_HISTORY_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(CustomerRetailerId));
            bObjQuery.setParameter(1, tsAsOfDate);
            bObjQuery.setParameter(2, tsAsOfDate);
        } else {
            bObjQuery = getBObjQueryFactory().createXCustomerRetailerRoleBObjQuery(XCustomerRetailerRoleBObjQuery.ALL_RETAILER_ROLE_BY_CUSTOMER_RETAILER_ID_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(CustomerRetailerId));
        }

        boolean considerForPagination = PaginationUtils
                            .considerForPagintion(XCustomerRetailerRoleBObj.class.getName(), control);
        control.setConsiderForPagintionFlag(considerForPagination);

        // set returned object
        List<?> list = bObjQuery.getResults();

        if (list.size() == 0) {
            return null;
        }
    Vector<XCustomerRetailerRoleBObj> vector = new Vector<XCustomerRetailerRoleBObj>();
        for (Iterator<?> it = list.iterator(); it.hasNext();) {
            XCustomerRetailerRoleBObj o = (XCustomerRetailerRoleBObj) it.next();
            postRetrieveXCustomerRetailerRoleBObj(o, "0", "ALL", control); 
            vector.add(o);
          
            if (o.getStatus()==null) {
                o.setStatus(status);
            }
            response.addStatus(o.getStatus());
        }
        response.setData(vector);

      return response;
    }
    
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public void beforePreExecuteGetAllRetailerRoleByCustomerRetailerId(DWLTransaction transaction) throws DWLBaseException{
        // Check if the parameters are valid.
        Object[] arguments = getInquiryArgumentType((DWLTransactionInquiry)transaction);
    if (arguments!=null && arguments.length>0) {
            // MDM_TODO0: CDKWB0003I Add argument validation logic
    }
    }

	
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction addXCustomerRetailerRole.
     *
     * @param theBObj
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleAddXCustomerRetailerRole
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.ADD_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.INSERT_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.ADDXCUSTOMERRETAILERROLE_FAILED
    )
     public DWLResponse addXCustomerRetailerRole(XCustomerRetailerRoleBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER addXCustomerRetailerRole(XCustomerRetailerRoleBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("addXCustomerRetailerRole", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction addXCustomerRetailerRole.";
      logger.finest("addXCustomerRetailerRole(XCustomerRetailerRoleBObj theBObj) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction addXCustomerRetailerRole.";
      logger.finest("addXCustomerRetailerRole(XCustomerRetailerRoleBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN addXCustomerRetailerRole(XCustomerRetailerRoleBObj theBObj) " + returnValue);
    }
        return retObj;
    }
    
    
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Adds a XCustomerRetailerRole to the database.
     *
     * @param theXCustomerRetailerRoleBObj
     *     The object that contains XCustomerRetailerRole attribute values.
     * @return
     *     DWLResponse containing a XCustomerRetailerRoleBObj object.
     * @exception Exception
     * @generated
     */
    public DWLResponse handleAddXCustomerRetailerRole(XCustomerRetailerRoleBObj theXCustomerRetailerRoleBObj) throws Exception {
        DWLResponse response = null;
        DWLStatus status = theXCustomerRetailerRoleBObj.getStatus();
        if (status == null) {
            status = new DWLStatus();
            theXCustomerRetailerRoleBObj.setStatus(status);
        }

        String strPluggableID = null;

        try {
            // Pluggable Key Structure implementation
            strPluggableID = getSuppliedIdPKFromBObj(theXCustomerRetailerRoleBObj);

            if ((strPluggableID != null) && (strPluggableID.length() > 0)) {
                theXCustomerRetailerRoleBObj.getEObjXCustomerRetailerRole().setCustomerRetailerRolepkId(FunctionUtils.getLongFromString(strPluggableID));
            } else {
                strPluggableID = null;
                theXCustomerRetailerRoleBObj.getEObjXCustomerRetailerRole().setCustomerRetailerRolepkId(null);
            }
         Persistence theXCustomerRetailerRoleBObjPersistence = getBObjPersistenceFactory().createXCustomerRetailerRoleBObjPersistence(XCustomerRetailerRoleBObjQuery.XCUSTOMER_RETAILER_ROLE_ADD, theXCustomerRetailerRoleBObj);
         theXCustomerRetailerRoleBObjPersistence.persistAdd();

            response = new DWLResponse();
            response.setData(theXCustomerRetailerRoleBObj);
            response.setStatus(theXCustomerRetailerRoleBObj.getStatus());
    } catch (Exception ex) {
 				TCRMExceptionUtils.throwTCRMException(ex, new TCRMInsertException(ex.getMessage()), status,
                    DWLStatus.FATAL, DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_COMPONENT, TCRMErrorCode.INSERT_RECORD_ERROR,
                    DSEAAdditionsExtsErrorReasonCode.ADDXCUSTOMERRETAILERROLE_FAILED, theXCustomerRetailerRoleBObj.getControl(), errHandler);
        }
        
        return response;
    }
    

	
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction updateXCustomerRetailerRole.
     *
     * @param theBObj
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleUpdateXCustomerRetailerRole
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.UPDATE_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.UPDATE_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.UPDATEXCUSTOMERRETAILERROLE_FAILED
    )
     public DWLResponse updateXCustomerRetailerRole(XCustomerRetailerRoleBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER updateXCustomerRetailerRole(XCustomerRetailerRoleBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("updateXCustomerRetailerRole", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction updateXCustomerRetailerRole.";
      logger.finest("updateXCustomerRetailerRole(XCustomerRetailerRoleBObj theBObj) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction updateXCustomerRetailerRole.";
      logger.finest("updateXCustomerRetailerRole(XCustomerRetailerRoleBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN updateXCustomerRetailerRole(XCustomerRetailerRoleBObj theBObj) " + returnValue);
    }
        return retObj;
    }
    
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Updates the specified XCustomerRetailerRole with new attribute values.
     *
     * @param theXCustomerRetailerRoleBObj
     *     The object that contains XCustomerRetailerRole attribute values to be
     *     updated
     * @return
     *     DWLResponse containing a XCustomerRetailerRoleBObj of the updated
     *     object.
     * @exception Exception
     * @generated
     */
    public DWLResponse handleUpdateXCustomerRetailerRole(XCustomerRetailerRoleBObj theXCustomerRetailerRoleBObj) throws Exception {

        DWLStatus status = theXCustomerRetailerRoleBObj.getStatus();

        if (status == null) {
            status = new DWLStatus();
            theXCustomerRetailerRoleBObj.setStatus(status);
        }
        
            // set lastupdatetxid with txnid from dwlcontrol
            theXCustomerRetailerRoleBObj.getEObjXCustomerRetailerRole().setLastUpdateTxId(new Long(theXCustomerRetailerRoleBObj.getControl().getTxnId()));
         Persistence theXCustomerRetailerRoleBObjPersistence = getBObjPersistenceFactory().createXCustomerRetailerRoleBObjPersistence(XCustomerRetailerRoleBObjQuery.XCUSTOMER_RETAILER_ROLE_UPDATE, theXCustomerRetailerRoleBObj);
         theXCustomerRetailerRoleBObjPersistence.persistUpdate();

        DWLResponse response = createDWLResponse();
        response.setData(theXCustomerRetailerRoleBObj);
        response.setStatus(theXCustomerRetailerRoleBObj.getStatus());

        return response;
    }


	
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXVehicle.
     *
     * @param VehiclepkId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetXVehicle
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETXVEHICLE_FAILED,
       beforePreExecuteMethod = "beforePreExecuteGetXVehicle"
    )
     public DWLResponse getXVehicle(String VehiclepkId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getXVehicle(String VehiclepkId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(VehiclepkId);
        DWLTransaction txObj = new  DWLTransactionInquiry("getXVehicle", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction getXVehicle.";
      logger.finest("getXVehicle(String VehiclepkId,  DWLControl control) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction getXVehicle.";
      logger.finest("getXVehicle(String VehiclepkId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getXVehicle(String VehiclepkId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }
    
    
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets a XVehicle from the database.
     * 
     * @generated
     */
    public DWLResponse handleGetXVehicle(String VehiclepkId,  DWLControl control) throws Exception {
        DWLStatus status = new DWLStatus();
        DWLResponse response = createDWLResponse();
        
        BObjQuery bObjQuery = null;
           
        String asOfDate = (String) control.get(DWLControl.INQUIRE_AS_OF_DATE);

        // History data inquiry: if inquireAsOfDate field has value in request xml 
        if (StringUtils.isNonBlank(asOfDate)) {
            Timestamp tsAsOfDate = getPITHistoryDate(asOfDate, DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_COMPONENT,
                                                     DSEAAdditionsExtsErrorReasonCode.GETXVEHICLE_INVALID_INQUIRE_AS_OF_DATE_FORMAT,
                                                     status, control);

            bObjQuery = getBObjQueryFactory().createXVehicleBObjQuery(XVehicleBObjQuery.XVEHICLE_HISTORY_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(VehiclepkId));
            bObjQuery.setParameter(1, tsAsOfDate);
            bObjQuery.setParameter(2, tsAsOfDate);
        } else {
            bObjQuery = getBObjQueryFactory().createXVehicleBObjQuery(XVehicleBObjQuery.XVEHICLE_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(VehiclepkId));
        }


        XVehicleBObj o = (XVehicleBObj) bObjQuery.getSingleResult();
        if( o == null ){
        	return null;
        } 
        postRetrieveXVehicleBObj(o, "0", "ALL", control); 
          
        if (o.getStatus()==null) {
            o.setStatus(status);
        }
        response.addStatus(o.getStatus());
        response.setData(o);

      return response;
    }
    
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public void beforePreExecuteGetXVehicle(DWLTransaction transaction) throws DWLBaseException{
        // Check if the parameters are valid.
        Object[] arguments = getInquiryArgumentType((DWLTransactionInquiry)transaction);
        String pk = null;
        if (arguments!=null && arguments.length>0) {
            pk = (String)arguments[0];
        }
        // Check if the parameter passed in exists.
        if ((pk == null) || (pk.trim().length() == 0)) {
            TCRMExceptionUtils.throwTCRMException(null, new TCRMReadException(), transaction.getStatus(), DWLStatus.FATAL,
                DSEAAdditionsExtsComponentID.XVEHICLE_BOBJ,
                TCRMErrorCode.FIELD_VALIDATION_ERROR,
                DSEAAdditionsExtsErrorReasonCode.XVEHICLE_VEHICLEPKID_NULL,
                transaction.getTxnControl(), errHandler);
        }
    }

	
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction addXVehicle.
     *
     * @param theBObj
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleAddXVehicle
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.ADD_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.INSERT_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.ADDXVEHICLE_FAILED
    )
     public DWLResponse addXVehicle(XVehicleBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER addXVehicle(XVehicleBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("addXVehicle", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction addXVehicle.";
      logger.finest("addXVehicle(XVehicleBObj theBObj) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction addXVehicle.";
      logger.finest("addXVehicle(XVehicleBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN addXVehicle(XVehicleBObj theBObj) " + returnValue);
    }
        return retObj;
    }
    
    
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Adds a XVehicle to the database.
     *
     * @param theXVehicleBObj
     *     The object that contains XVehicle attribute values.
     * @return
     *     DWLResponse containing a XVehicleBObj object.
     * @exception Exception
     * @generated
     */
    public DWLResponse handleAddXVehicle(XVehicleBObj theXVehicleBObj) throws Exception {
        DWLResponse response = null;
        DWLStatus status = theXVehicleBObj.getStatus();
        if (status == null) {
            status = new DWLStatus();
            theXVehicleBObj.setStatus(status);
        }

        String strPluggableID = null;

        try {
            // Pluggable Key Structure implementation
            strPluggableID = getSuppliedIdPKFromBObj(theXVehicleBObj);

            if ((strPluggableID != null) && (strPluggableID.length() > 0)) {
                theXVehicleBObj.getEObjXVehicle().setVehiclepkId(FunctionUtils.getLongFromString(strPluggableID));
            } else {
                strPluggableID = null;
                theXVehicleBObj.getEObjXVehicle().setVehiclepkId(null);
            }
         Persistence theXVehicleBObjPersistence = getBObjPersistenceFactory().createXVehicleBObjPersistence(XVehicleBObjQuery.XVEHICLE_ADD, theXVehicleBObj);
         theXVehicleBObjPersistence.persistAdd();

            response = new DWLResponse();
            response.setData(theXVehicleBObj);
            response.setStatus(theXVehicleBObj.getStatus());
    } catch (Exception ex) {
 				TCRMExceptionUtils.throwTCRMException(ex, new TCRMInsertException(ex.getMessage()), status,
                    DWLStatus.FATAL, DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_COMPONENT, TCRMErrorCode.INSERT_RECORD_ERROR,
                    DSEAAdditionsExtsErrorReasonCode.ADDXVEHICLE_FAILED, theXVehicleBObj.getControl(), errHandler);
        }
        
        return response;
    }
    

	
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction updateXVehicle.
     *
     * @param theBObj
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleUpdateXVehicle
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.UPDATE_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.UPDATE_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.UPDATEXVEHICLE_FAILED
    )
     public DWLResponse updateXVehicle(XVehicleBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER updateXVehicle(XVehicleBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("updateXVehicle", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction updateXVehicle.";
      logger.finest("updateXVehicle(XVehicleBObj theBObj) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction updateXVehicle.";
      logger.finest("updateXVehicle(XVehicleBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN updateXVehicle(XVehicleBObj theBObj) " + returnValue);
    }
        return retObj;
    }
    
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Updates the specified XVehicle with new attribute values.
     *
     * @param theXVehicleBObj
     *     The object that contains XVehicle attribute values to be updated
     * @return
     *     DWLResponse containing a XVehicleBObj of the updated object.
     * @exception Exception
     * @generated
     */
    public DWLResponse handleUpdateXVehicle(XVehicleBObj theXVehicleBObj) throws Exception {

        DWLStatus status = theXVehicleBObj.getStatus();

        if (status == null) {
            status = new DWLStatus();
            theXVehicleBObj.setStatus(status);
        }
        
            // set lastupdatetxid with txnid from dwlcontrol
            theXVehicleBObj.getEObjXVehicle().setLastUpdateTxId(new Long(theXVehicleBObj.getControl().getTxnId()));
         Persistence theXVehicleBObjPersistence = getBObjPersistenceFactory().createXVehicleBObjPersistence(XVehicleBObjQuery.XVEHICLE_UPDATE, theXVehicleBObj);
         theXVehicleBObjPersistence.persistUpdate();

        DWLResponse response = createDWLResponse();
        response.setData(theXVehicleBObj);
        response.setStatus(theXVehicleBObj.getStatus());

        return response;
    }


	
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXCustomerVehicle.
     *
     * @param CustomerVehiclepkId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetXCustomerVehicle
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETXCUSTOMERVEHICLE_FAILED,
       beforePreExecuteMethod = "beforePreExecuteGetXCustomerVehicle"
    )
     public DWLResponse getXCustomerVehicle(String CustomerVehiclepkId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getXCustomerVehicle(String CustomerVehiclepkId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(CustomerVehiclepkId);
        DWLTransaction txObj = new  DWLTransactionInquiry("getXCustomerVehicle", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction getXCustomerVehicle.";
      logger.finest("getXCustomerVehicle(String CustomerVehiclepkId,  DWLControl control) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction getXCustomerVehicle.";
      logger.finest("getXCustomerVehicle(String CustomerVehiclepkId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getXCustomerVehicle(String CustomerVehiclepkId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }
    
    
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets a XCustomerVehicle from the database.
     * 
     * @generated
     */
    public DWLResponse handleGetXCustomerVehicle(String CustomerVehiclepkId,  DWLControl control) throws Exception {
        DWLStatus status = new DWLStatus();
        DWLResponse response = createDWLResponse();
        
        BObjQuery bObjQuery = null;
           
        String asOfDate = (String) control.get(DWLControl.INQUIRE_AS_OF_DATE);

        // History data inquiry: if inquireAsOfDate field has value in request xml 
        if (StringUtils.isNonBlank(asOfDate)) {
            Timestamp tsAsOfDate = getPITHistoryDate(asOfDate, DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_COMPONENT,
                                                     DSEAAdditionsExtsErrorReasonCode.GETXCUSTOMERVEHICLE_INVALID_INQUIRE_AS_OF_DATE_FORMAT,
                                                     status, control);

            bObjQuery = getBObjQueryFactory().createXCustomerVehicleBObjQuery(XCustomerVehicleBObjQuery.XCUSTOMER_VEHICLE_HISTORY_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(CustomerVehiclepkId));
            bObjQuery.setParameter(1, tsAsOfDate);
            bObjQuery.setParameter(2, tsAsOfDate);
        } else {
            bObjQuery = getBObjQueryFactory().createXCustomerVehicleBObjQuery(XCustomerVehicleBObjQuery.XCUSTOMER_VEHICLE_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(CustomerVehiclepkId));
        }


        XCustomerVehicleBObj o = (XCustomerVehicleBObj) bObjQuery.getSingleResult();
        if( o == null ){
        	return null;
        } 
        postRetrieveXCustomerVehicleBObj(o, "0", "ALL", control); 
          
        if (o.getStatus()==null) {
            o.setStatus(status);
        }
        response.addStatus(o.getStatus());
        response.setData(o);

      return response;
    }
    
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public void beforePreExecuteGetXCustomerVehicle(DWLTransaction transaction) throws DWLBaseException{
        // Check if the parameters are valid.
        Object[] arguments = getInquiryArgumentType((DWLTransactionInquiry)transaction);
        String pk = null;
        if (arguments!=null && arguments.length>0) {
            pk = (String)arguments[0];
        }
        // Check if the parameter passed in exists.
        if ((pk == null) || (pk.trim().length() == 0)) {
            TCRMExceptionUtils.throwTCRMException(null, new TCRMReadException(), transaction.getStatus(), DWLStatus.FATAL,
                DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_BOBJ,
                TCRMErrorCode.FIELD_VALIDATION_ERROR,
                DSEAAdditionsExtsErrorReasonCode.XCUSTOMERVEHICLE_CUSTOMERVEHICLEPKID_NULL,
                transaction.getTxnControl(), errHandler);
        }
    }

	
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getAllXCustomerVehicleByPartyId.
     *
     * @param ContId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetAllXCustomerVehicleByPartyId
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETALLXCUSTOMERVEHICLEBYPARTYID_FAILED,
       beforePreExecuteMethod = "beforePreExecuteGetAllXCustomerVehicleByPartyId"
    )
     public DWLResponse getAllXCustomerVehicleByPartyId(String ContId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getAllXCustomerVehicleByPartyId(String ContId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(ContId);
        DWLTransaction txObj = new  DWLTransactionInquiry("getAllXCustomerVehicleByPartyId", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction getAllXCustomerVehicleByPartyId.";
      logger.finest("getAllXCustomerVehicleByPartyId(String ContId,  DWLControl control) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction getAllXCustomerVehicleByPartyId.";
      logger.finest("getAllXCustomerVehicleByPartyId(String ContId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getAllXCustomerVehicleByPartyId(String ContId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets a XCustomerVehicle from the database.
     * 
     * @generated
     */
    public DWLResponse handleGetAllXCustomerVehicleByPartyId(String ContId,  DWLControl control) throws Exception {
        DWLStatus status = new DWLStatus();
        DWLResponse response = createDWLResponse();
        
        BObjQuery bObjQuery = null;
           
        String asOfDate = (String) control.get(DWLControl.INQUIRE_AS_OF_DATE);

        // History data inquiry: if inquireAsOfDate field has value in request xml 
        if (StringUtils.isNonBlank(asOfDate)) {
            Timestamp tsAsOfDate = getPITHistoryDate(asOfDate, DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_COMPONENT,
                                                     DSEAAdditionsExtsErrorReasonCode.GETALLXCUSTOMERVEHICLEBYPARTYID_INVALID_INQUIRE_AS_OF_DATE_FORMAT,
                                                     status, control);

            bObjQuery = getBObjQueryFactory().createXCustomerVehicleBObjQuery(XCustomerVehicleBObjQuery.ALL_XCUSTOMER_VEHICLE_BY_PARTY_ID_HISTORY_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(ContId));
            bObjQuery.setParameter(1, tsAsOfDate);
            bObjQuery.setParameter(2, tsAsOfDate);
        } else {
            bObjQuery = getBObjQueryFactory().createXCustomerVehicleBObjQuery(XCustomerVehicleBObjQuery.ALL_XCUSTOMER_VEHICLE_BY_PARTY_ID_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(ContId));
        }

        boolean considerForPagination = PaginationUtils
                            .considerForPagintion(XCustomerVehicleBObj.class.getName(), control);
        control.setConsiderForPagintionFlag(considerForPagination);

        // set returned object
        List<?> list = bObjQuery.getResults();

        if (list.size() == 0) {
            return null;
        }
    Vector<XCustomerVehicleBObj> vector = new Vector<XCustomerVehicleBObj>();
        for (Iterator<?> it = list.iterator(); it.hasNext();) {
            XCustomerVehicleBObj o = (XCustomerVehicleBObj) it.next();
            postRetrieveXCustomerVehicleBObj(o, "0", "ALL", control); 
            vector.add(o);
          
            if (o.getStatus()==null) {
                o.setStatus(status);
            }
            response.addStatus(o.getStatus());
        }
        response.setData(vector);

      return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public void beforePreExecuteGetAllXCustomerVehicleByPartyId(DWLTransaction transaction) throws DWLBaseException{
        // Check if the parameters are valid.
        Object[] arguments = getInquiryArgumentType((DWLTransactionInquiry)transaction);
    if (arguments!=null && arguments.length>0) {
            // MDM_TODO0: CDKWB0003I Add argument validation logic
    }
    }

  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction addXCustomerVehicle.
     *
     * @param theBObj
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleAddXCustomerVehicle
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.ADD_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.INSERT_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.ADDXCUSTOMERVEHICLE_FAILED
    )
     public DWLResponse addXCustomerVehicle(XCustomerVehicleBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER addXCustomerVehicle(XCustomerVehicleBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("addXCustomerVehicle", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction addXCustomerVehicle.";
      logger.finest("addXCustomerVehicle(XCustomerVehicleBObj theBObj) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction addXCustomerVehicle.";
      logger.finest("addXCustomerVehicle(XCustomerVehicleBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN addXCustomerVehicle(XCustomerVehicleBObj theBObj) " + returnValue);
    }
        return retObj;
    }
    
    
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Adds a XCustomerVehicle to the database.
     *
     * @param theXCustomerVehicleBObj
     *     The object that contains XCustomerVehicle attribute values.
     * @return
     *     DWLResponse containing a XCustomerVehicleBObj object.
     * @exception Exception
     * @generated
     */
    public DWLResponse handleAddXCustomerVehicle(XCustomerVehicleBObj theXCustomerVehicleBObj) throws Exception {
        DWLResponse response = null;
        DWLStatus status = theXCustomerVehicleBObj.getStatus();
        if (status == null) {
            status = new DWLStatus();
            theXCustomerVehicleBObj.setStatus(status);
        }
        XVehicleBObj childXVehicleBObj = theXCustomerVehicleBObj.getXVehicleBObj();
        	String containedPk = null;
        if( childXVehicleBObj != null &&  childXVehicleBObj.getVehiclepkId()==null){
        	
            addXVehicle(childXVehicleBObj);
            containedPk = childXVehicleBObj.getVehiclepkId ();
      theXCustomerVehicleBObj.setVehicleId( containedPk );
   	     	theXCustomerVehicleBObj.setXVehicleBObj(childXVehicleBObj);
    }else{
    }

        String strPluggableID = null;

        try {
            // Pluggable Key Structure implementation
            strPluggableID = getSuppliedIdPKFromBObj(theXCustomerVehicleBObj);

            if ((strPluggableID != null) && (strPluggableID.length() > 0)) {
                theXCustomerVehicleBObj.getEObjXCustomerVehicle().setCustomerVehiclepkId(FunctionUtils.getLongFromString(strPluggableID));
            } else {
                strPluggableID = null;
                theXCustomerVehicleBObj.getEObjXCustomerVehicle().setCustomerVehiclepkId(null);
            }
         Persistence theXCustomerVehicleBObjPersistence = getBObjPersistenceFactory().createXCustomerVehicleBObjPersistence(XCustomerVehicleBObjQuery.XCUSTOMER_VEHICLE_ADD, theXCustomerVehicleBObj);
         theXCustomerVehicleBObjPersistence.persistAdd();

            String pkId = theXCustomerVehicleBObj.getCustomerVehiclepkId ();			

            @SuppressWarnings("rawtypes")
            Vector vecXCustomerVehicleRoleBObj = theXCustomerVehicleBObj.getItemsXCustomerVehicleRoleBObj();
            for (int i = 0; i < vecXCustomerVehicleRoleBObj.size(); i++) {
                XCustomerVehicleRoleBObj object = (XCustomerVehicleRoleBObj)vecXCustomerVehicleRoleBObj.elementAt(i);
                object.setCustomerVehicleId(pkId);
                addXCustomerVehicleRole(object);
            }
            response = new DWLResponse();
            response.setData(theXCustomerVehicleBObj);
            response.setStatus(theXCustomerVehicleBObj.getStatus());
    } catch (Exception ex) {
 				TCRMExceptionUtils.throwTCRMException(ex, new TCRMInsertException(ex.getMessage()), status,
                    DWLStatus.FATAL, DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_COMPONENT, TCRMErrorCode.INSERT_RECORD_ERROR,
                    DSEAAdditionsExtsErrorReasonCode.ADDXCUSTOMERVEHICLE_FAILED, theXCustomerVehicleBObj.getControl(), errHandler);
        }
        
        return response;
    }
    

	
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction updateXCustomerVehicle.
     *
     * @param theBObj
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleUpdateXCustomerVehicle
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.UPDATE_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.UPDATE_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.UPDATEXCUSTOMERVEHICLE_FAILED
    , manuallyHandleRedundantUpdateCheck="true"
    )
     public DWLResponse updateXCustomerVehicle(XCustomerVehicleBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER updateXCustomerVehicle(XCustomerVehicleBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("updateXCustomerVehicle", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction updateXCustomerVehicle.";
      logger.finest("updateXCustomerVehicle(XCustomerVehicleBObj theBObj) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction updateXCustomerVehicle.";
      logger.finest("updateXCustomerVehicle(XCustomerVehicleBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN updateXCustomerVehicle(XCustomerVehicleBObj theBObj) " + returnValue);
    }
        return retObj;
    }
    
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Updates the specified XCustomerVehicle with new attribute values.
     *
     * @param theXCustomerVehicleBObj
     *     The object that contains XCustomerVehicle attribute values to be
     *     updated
     * @return
     *     DWLResponse containing a XCustomerVehicleBObj of the updated object.
     * @exception Exception
     * @generated
     */
    public DWLResponse handleUpdateXCustomerVehicle(XCustomerVehicleBObj theXCustomerVehicleBObj) throws Exception {

        DWLStatus status = theXCustomerVehicleBObj.getStatus();

        if (status == null) {
            status = new DWLStatus();
            theXCustomerVehicleBObj.setStatus(status);
        }
        
    if( !theXCustomerVehicleBObj.isRedundantUpdate() ){
            // set lastupdatetxid with txnid from dwlcontrol
            theXCustomerVehicleBObj.getEObjXCustomerVehicle().setLastUpdateTxId(new Long(theXCustomerVehicleBObj.getControl().getTxnId()));
            Persistence theXCustomerVehicleBObjPersistence = getBObjPersistenceFactory().createXCustomerVehicleBObjPersistence(XCustomerVehicleBObjQuery.XCUSTOMER_VEHICLE_UPDATE, theXCustomerVehicleBObj);
            theXCustomerVehicleBObjPersistence.persistUpdate();
        }

    String pkId = theXCustomerVehicleBObj.getCustomerVehiclepkId();			

    @SuppressWarnings("rawtypes")
    Vector vecXCustomerVehicleRoleBObj = theXCustomerVehicleBObj.getItemsXCustomerVehicleRoleBObj();
    for (int i = 0; i < vecXCustomerVehicleRoleBObj.size(); i++) {
      XCustomerVehicleRoleBObj object = (XCustomerVehicleRoleBObj)vecXCustomerVehicleRoleBObj.elementAt(i);
      
      String ref = object.getCustomerVehicleId();
      if (ref != null && !ref.equals(pkId)) {
        TCRMExceptionUtils.throwTCRMException(null, new TCRMDataInvalidException(),
          status,
          DWLStatus.FATAL,
          DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_BOBJ,
          TCRMErrorCode.DATA_INVALID_ERROR,
          DSEAAdditionsExtsErrorReasonCode.XCUSTOMERVEHICLE_XCUSTOMERVEHICLEROLE_REFERENCE_INVALID,
          theXCustomerVehicleBObj.getControl(),
          errHandler);
      }
      
      object.setCustomerVehicleId(pkId);
      
      if (object.getEObjXCustomerVehicleRole().getPrimaryKey() == null){
        addXCustomerVehicleRole(object);
      } else {
        updateXCustomerVehicleRole(object);
      }
    }
        DWLResponse response = createDWLResponse();
        response.setData(theXCustomerVehicleBObj);
        response.setStatus(theXCustomerVehicleBObj.getStatus());

        return response;
    }


	
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXCustomerVehicleRole.
     *
     * @param CustomerVehicleRolepkId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetXCustomerVehicleRole
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETXCUSTOMERVEHICLEROLE_FAILED,
       beforePreExecuteMethod = "beforePreExecuteGetXCustomerVehicleRole"
    )
     public DWLResponse getXCustomerVehicleRole(String CustomerVehicleRolepkId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getXCustomerVehicleRole(String CustomerVehicleRolepkId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(CustomerVehicleRolepkId);
        DWLTransaction txObj = new  DWLTransactionInquiry("getXCustomerVehicleRole", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction getXCustomerVehicleRole.";
      logger.finest("getXCustomerVehicleRole(String CustomerVehicleRolepkId,  DWLControl control) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction getXCustomerVehicleRole.";
      logger.finest("getXCustomerVehicleRole(String CustomerVehicleRolepkId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getXCustomerVehicleRole(String CustomerVehicleRolepkId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }
    
    
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets a XCustomerVehicleRole from the database.
     * 
     * @generated
     */
    public DWLResponse handleGetXCustomerVehicleRole(String CustomerVehicleRolepkId,  DWLControl control) throws Exception {
        DWLStatus status = new DWLStatus();
        DWLResponse response = createDWLResponse();
        
        BObjQuery bObjQuery = null;
           
        String asOfDate = (String) control.get(DWLControl.INQUIRE_AS_OF_DATE);

        // History data inquiry: if inquireAsOfDate field has value in request xml 
        if (StringUtils.isNonBlank(asOfDate)) {
            Timestamp tsAsOfDate = getPITHistoryDate(asOfDate, DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_COMPONENT,
                                                     DSEAAdditionsExtsErrorReasonCode.GETXCUSTOMERVEHICLEROLE_INVALID_INQUIRE_AS_OF_DATE_FORMAT,
                                                     status, control);

            bObjQuery = getBObjQueryFactory().createXCustomerVehicleRoleBObjQuery(XCustomerVehicleRoleBObjQuery.XCUSTOMER_VEHICLE_ROLE_HISTORY_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(CustomerVehicleRolepkId));
            bObjQuery.setParameter(1, tsAsOfDate);
            bObjQuery.setParameter(2, tsAsOfDate);
        } else {
            bObjQuery = getBObjQueryFactory().createXCustomerVehicleRoleBObjQuery(XCustomerVehicleRoleBObjQuery.XCUSTOMER_VEHICLE_ROLE_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(CustomerVehicleRolepkId));
        }


        XCustomerVehicleRoleBObj o = (XCustomerVehicleRoleBObj) bObjQuery.getSingleResult();
        if( o == null ){
        	return null;
        } 
        postRetrieveXCustomerVehicleRoleBObj(o, "0", "ALL", control); 
          
        if (o.getStatus()==null) {
            o.setStatus(status);
        }
        response.addStatus(o.getStatus());
        response.setData(o);

      return response;
    }
    
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public void beforePreExecuteGetXCustomerVehicleRole(DWLTransaction transaction) throws DWLBaseException{
        // Check if the parameters are valid.
        Object[] arguments = getInquiryArgumentType((DWLTransactionInquiry)transaction);
        String pk = null;
        if (arguments!=null && arguments.length>0) {
            pk = (String)arguments[0];
        }
        // Check if the parameter passed in exists.
        if ((pk == null) || (pk.trim().length() == 0)) {
            TCRMExceptionUtils.throwTCRMException(null, new TCRMReadException(), transaction.getStatus(), DWLStatus.FATAL,
                DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_ROLE_BOBJ,
                TCRMErrorCode.FIELD_VALIDATION_ERROR,
                DSEAAdditionsExtsErrorReasonCode.XCUSTOMERVEHICLEROLE_CUSTOMERVEHICLEROLEPKID_NULL,
                transaction.getTxnControl(), errHandler);
        }
    }

	
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getAllVehicleRoleByCustomerVehicleId.
     *
     * @param CustomerVehicleId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetAllVehicleRoleByCustomerVehicleId
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETALLVEHICLEROLEBYCUSTOMERVEHICLEID_FAILED,
       beforePreExecuteMethod = "beforePreExecuteGetAllVehicleRoleByCustomerVehicleId"
    )
     public DWLResponse getAllVehicleRoleByCustomerVehicleId(String CustomerVehicleId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getAllVehicleRoleByCustomerVehicleId(String CustomerVehicleId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(CustomerVehicleId);
        DWLTransaction txObj = new  DWLTransactionInquiry("getAllVehicleRoleByCustomerVehicleId", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction getAllVehicleRoleByCustomerVehicleId.";
      logger.finest("getAllVehicleRoleByCustomerVehicleId(String CustomerVehicleId,  DWLControl control) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction getAllVehicleRoleByCustomerVehicleId.";
      logger.finest("getAllVehicleRoleByCustomerVehicleId(String CustomerVehicleId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getAllVehicleRoleByCustomerVehicleId(String CustomerVehicleId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }
    
    
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets a XCustomerVehicleRole from the database.
     * 
     * @generated
     */
    public DWLResponse handleGetAllVehicleRoleByCustomerVehicleId(String CustomerVehicleId,  DWLControl control) throws Exception {
        DWLStatus status = new DWLStatus();
        DWLResponse response = createDWLResponse();
        
        BObjQuery bObjQuery = null;
           
        String asOfDate = (String) control.get(DWLControl.INQUIRE_AS_OF_DATE);

        // History data inquiry: if inquireAsOfDate field has value in request xml 
        if (StringUtils.isNonBlank(asOfDate)) {
            Timestamp tsAsOfDate = getPITHistoryDate(asOfDate, DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_COMPONENT,
                                                     DSEAAdditionsExtsErrorReasonCode.GETALLVEHICLEROLEBYCUSTOMERVEHICLEID_INVALID_INQUIRE_AS_OF_DATE_FORMAT,
                                                     status, control);

            bObjQuery = getBObjQueryFactory().createXCustomerVehicleRoleBObjQuery(XCustomerVehicleRoleBObjQuery.ALL_VEHICLE_ROLE_BY_CUSTOMER_VEHICLE_ID_HISTORY_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(CustomerVehicleId));
            bObjQuery.setParameter(1, tsAsOfDate);
            bObjQuery.setParameter(2, tsAsOfDate);
        } else {
            bObjQuery = getBObjQueryFactory().createXCustomerVehicleRoleBObjQuery(XCustomerVehicleRoleBObjQuery.ALL_VEHICLE_ROLE_BY_CUSTOMER_VEHICLE_ID_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(CustomerVehicleId));
        }

        boolean considerForPagination = PaginationUtils
                            .considerForPagintion(XCustomerVehicleRoleBObj.class.getName(), control);
        control.setConsiderForPagintionFlag(considerForPagination);

        // set returned object
        List<?> list = bObjQuery.getResults();

        if (list.size() == 0) {
            return null;
        }
    Vector<XCustomerVehicleRoleBObj> vector = new Vector<XCustomerVehicleRoleBObj>();
        for (Iterator<?> it = list.iterator(); it.hasNext();) {
            XCustomerVehicleRoleBObj o = (XCustomerVehicleRoleBObj) it.next();
            postRetrieveXCustomerVehicleRoleBObj(o, "0", "ALL", control); 
            vector.add(o);
          
            if (o.getStatus()==null) {
                o.setStatus(status);
            }
            response.addStatus(o.getStatus());
        }
        response.setData(vector);

      return response;
    }
    
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public void beforePreExecuteGetAllVehicleRoleByCustomerVehicleId(DWLTransaction transaction) throws DWLBaseException{
        // Check if the parameters are valid.
        Object[] arguments = getInquiryArgumentType((DWLTransactionInquiry)transaction);
    if (arguments!=null && arguments.length>0) {
            // MDM_TODO0: CDKWB0003I Add argument validation logic
    }
    }

	
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction addXCustomerVehicleRole.
     *
     * @param theBObj
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleAddXCustomerVehicleRole
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.ADD_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.INSERT_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.ADDXCUSTOMERVEHICLEROLE_FAILED
    )
     public DWLResponse addXCustomerVehicleRole(XCustomerVehicleRoleBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER addXCustomerVehicleRole(XCustomerVehicleRoleBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("addXCustomerVehicleRole", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction addXCustomerVehicleRole.";
      logger.finest("addXCustomerVehicleRole(XCustomerVehicleRoleBObj theBObj) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction addXCustomerVehicleRole.";
      logger.finest("addXCustomerVehicleRole(XCustomerVehicleRoleBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN addXCustomerVehicleRole(XCustomerVehicleRoleBObj theBObj) " + returnValue);
    }
        return retObj;
    }
    
    
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Adds a XCustomerVehicleRole to the database.
     *
     * @param theXCustomerVehicleRoleBObj
     *     The object that contains XCustomerVehicleRole attribute values.
     * @return
     *     DWLResponse containing a XCustomerVehicleRoleBObj object.
     * @exception Exception
     * @generated
     */
    public DWLResponse handleAddXCustomerVehicleRole(XCustomerVehicleRoleBObj theXCustomerVehicleRoleBObj) throws Exception {
        DWLResponse response = null;
        DWLStatus status = theXCustomerVehicleRoleBObj.getStatus();
        if (status == null) {
            status = new DWLStatus();
            theXCustomerVehicleRoleBObj.setStatus(status);
        }

        String strPluggableID = null;

        try {
            // Pluggable Key Structure implementation
            strPluggableID = getSuppliedIdPKFromBObj(theXCustomerVehicleRoleBObj);

            if ((strPluggableID != null) && (strPluggableID.length() > 0)) {
                theXCustomerVehicleRoleBObj.getEObjXCustomerVehicleRole().setCustomerVehicleRolepkId(FunctionUtils.getLongFromString(strPluggableID));
            } else {
                strPluggableID = null;
                theXCustomerVehicleRoleBObj.getEObjXCustomerVehicleRole().setCustomerVehicleRolepkId(null);
            }
         Persistence theXCustomerVehicleRoleBObjPersistence = getBObjPersistenceFactory().createXCustomerVehicleRoleBObjPersistence(XCustomerVehicleRoleBObjQuery.XCUSTOMER_VEHICLE_ROLE_ADD, theXCustomerVehicleRoleBObj);
         theXCustomerVehicleRoleBObjPersistence.persistAdd();

            response = new DWLResponse();
            response.setData(theXCustomerVehicleRoleBObj);
            response.setStatus(theXCustomerVehicleRoleBObj.getStatus());
    } catch (Exception ex) {
 				TCRMExceptionUtils.throwTCRMException(ex, new TCRMInsertException(ex.getMessage()), status,
                    DWLStatus.FATAL, DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_COMPONENT, TCRMErrorCode.INSERT_RECORD_ERROR,
                    DSEAAdditionsExtsErrorReasonCode.ADDXCUSTOMERVEHICLEROLE_FAILED, theXCustomerVehicleRoleBObj.getControl(), errHandler);
        }
        
        return response;
    }
    

	
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction updateXCustomerVehicleRole.
     *
     * @param theBObj
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleUpdateXCustomerVehicleRole
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.UPDATE_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.UPDATE_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.UPDATEXCUSTOMERVEHICLEROLE_FAILED
    )
     public DWLResponse updateXCustomerVehicleRole(XCustomerVehicleRoleBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER updateXCustomerVehicleRole(XCustomerVehicleRoleBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("updateXCustomerVehicleRole", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction updateXCustomerVehicleRole.";
      logger.finest("updateXCustomerVehicleRole(XCustomerVehicleRoleBObj theBObj) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction updateXCustomerVehicleRole.";
      logger.finest("updateXCustomerVehicleRole(XCustomerVehicleRoleBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN updateXCustomerVehicleRole(XCustomerVehicleRoleBObj theBObj) " + returnValue);
    }
        return retObj;
    }
    
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Updates the specified XCustomerVehicleRole with new attribute values.
     *
     * @param theXCustomerVehicleRoleBObj
     *     The object that contains XCustomerVehicleRole attribute values to be
     *     updated
     * @return
     *     DWLResponse containing a XCustomerVehicleRoleBObj of the updated
     *     object.
     * @exception Exception
     * @generated
     */
    public DWLResponse handleUpdateXCustomerVehicleRole(XCustomerVehicleRoleBObj theXCustomerVehicleRoleBObj) throws Exception {

        DWLStatus status = theXCustomerVehicleRoleBObj.getStatus();

        if (status == null) {
            status = new DWLStatus();
            theXCustomerVehicleRoleBObj.setStatus(status);
        }
        
            // set lastupdatetxid with txnid from dwlcontrol
            theXCustomerVehicleRoleBObj.getEObjXCustomerVehicleRole().setLastUpdateTxId(new Long(theXCustomerVehicleRoleBObj.getControl().getTxnId()));
         Persistence theXCustomerVehicleRoleBObjPersistence = getBObjPersistenceFactory().createXCustomerVehicleRoleBObjPersistence(XCustomerVehicleRoleBObjQuery.XCUSTOMER_VEHICLE_ROLE_UPDATE, theXCustomerVehicleRoleBObj);
         theXCustomerVehicleRoleBObjPersistence.persistUpdate();

        DWLResponse response = createDWLResponse();
        response.setData(theXCustomerVehicleRoleBObj);
        response.setStatus(theXCustomerVehicleRoleBObj.getStatus());

        return response;
    }



    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXCompanyIdentification.
     *
     * @param CompanyIdentificationpkId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetXCompanyIdentification
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETXCOMPANYIDENTIFICATION_FAILED,
       beforePreExecuteMethod = "beforePreExecuteGetXCompanyIdentification"
    )
     public DWLResponse getXCompanyIdentification(String CompanyIdentificationpkId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getXCompanyIdentification(String CompanyIdentificationpkId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(CompanyIdentificationpkId);
        DWLTransaction txObj = new  DWLTransactionInquiry("getXCompanyIdentification", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction getXCompanyIdentification.";
      logger.finest("getXCompanyIdentification(String CompanyIdentificationpkId,  DWLControl control) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction getXCompanyIdentification.";
      logger.finest("getXCompanyIdentification(String CompanyIdentificationpkId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getXCompanyIdentification(String CompanyIdentificationpkId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets a XCompanyIdentification from the database.
     * 
     * @generated
     */
    public DWLResponse handleGetXCompanyIdentification(String CompanyIdentificationpkId,  DWLControl control) throws Exception {
        DWLStatus status = new DWLStatus();
        DWLResponse response = createDWLResponse();
        
        BObjQuery bObjQuery = null;
           
        String asOfDate = (String) control.get(DWLControl.INQUIRE_AS_OF_DATE);

        // History data inquiry: if inquireAsOfDate field has value in request xml 
        if (StringUtils.isNonBlank(asOfDate)) {
            Timestamp tsAsOfDate = getPITHistoryDate(asOfDate, DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_COMPONENT,
                                                     DSEAAdditionsExtsErrorReasonCode.GETXCOMPANYIDENTIFICATION_INVALID_INQUIRE_AS_OF_DATE_FORMAT,
                                                     status, control);

            bObjQuery = getBObjQueryFactory().createXCompanyIdentificationBObjQuery(XCompanyIdentificationBObjQuery.XCOMPANY_IDENTIFICATION_HISTORY_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(CompanyIdentificationpkId));
            bObjQuery.setParameter(1, tsAsOfDate);
            bObjQuery.setParameter(2, tsAsOfDate);
        } else {
            bObjQuery = getBObjQueryFactory().createXCompanyIdentificationBObjQuery(XCompanyIdentificationBObjQuery.XCOMPANY_IDENTIFICATION_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(CompanyIdentificationpkId));
        }


        XCompanyIdentificationBObj o = (XCompanyIdentificationBObj) bObjQuery.getSingleResult();
        if( o == null ){
        	return null;
        } 
          
        if (o.getStatus()==null) {
            o.setStatus(status);
        }
        response.addStatus(o.getStatus());
        response.setData(o);

      return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public void beforePreExecuteGetXCompanyIdentification(DWLTransaction transaction) throws DWLBaseException{
        // Check if the parameters are valid.
        Object[] arguments = getInquiryArgumentType((DWLTransactionInquiry)transaction);
        String pk = null;
        if (arguments!=null && arguments.length>0) {
            pk = (String)arguments[0];
        }
        // Check if the parameter passed in exists.
        if ((pk == null) || (pk.trim().length() == 0)) {
            TCRMExceptionUtils.throwTCRMException(null, new TCRMReadException(), transaction.getStatus(), DWLStatus.FATAL,
                DSEAAdditionsExtsComponentID.XCOMPANY_IDENTIFICATION_BOBJ,
                TCRMErrorCode.FIELD_VALIDATION_ERROR,
                DSEAAdditionsExtsErrorReasonCode.XCOMPANYIDENTIFICATION_COMPANYIDENTIFICATIONPKID_NULL,
                transaction.getTxnControl(), errHandler);
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction addXCompanyIdentification.
     *
     * @param theBObj
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleAddXCompanyIdentification
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.ADD_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.INSERT_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.ADDXCOMPANYIDENTIFICATION_FAILED
    )
     public DWLResponse addXCompanyIdentification(XCompanyIdentificationBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER addXCompanyIdentification(XCompanyIdentificationBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("addXCompanyIdentification", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction addXCompanyIdentification.";
      logger.finest("addXCompanyIdentification(XCompanyIdentificationBObj theBObj) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction addXCompanyIdentification.";
      logger.finest("addXCompanyIdentification(XCompanyIdentificationBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN addXCompanyIdentification(XCompanyIdentificationBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Adds a XCompanyIdentification to the database.
     *
     * @param theXCompanyIdentificationBObj
     *     The object that contains XCompanyIdentification attribute values.
     * @return
     *     DWLResponse containing a XCompanyIdentificationBObj object.
     * @exception Exception
     * @generated
     */
    public DWLResponse handleAddXCompanyIdentification(XCompanyIdentificationBObj theXCompanyIdentificationBObj) throws Exception {
        DWLResponse response = null;
        DWLStatus status = theXCompanyIdentificationBObj.getStatus();
        if (status == null) {
            status = new DWLStatus();
            theXCompanyIdentificationBObj.setStatus(status);
        }

        String strPluggableID = null;

        try {
            // Pluggable Key Structure implementation
            strPluggableID = getSuppliedIdPKFromBObj(theXCompanyIdentificationBObj);

            if ((strPluggableID != null) && (strPluggableID.length() > 0)) {
                theXCompanyIdentificationBObj.getEObjXCompanyIdentification().setCompanyIdentificationpkId(FunctionUtils.getLongFromString(strPluggableID));
            } else {
                strPluggableID = null;
                theXCompanyIdentificationBObj.getEObjXCompanyIdentification().setCompanyIdentificationpkId(null);
            }
         Persistence theXCompanyIdentificationBObjPersistence = getBObjPersistenceFactory().createXCompanyIdentificationBObjPersistence(XCompanyIdentificationBObjQuery.XCOMPANY_IDENTIFICATION_ADD, theXCompanyIdentificationBObj);
         theXCompanyIdentificationBObjPersistence.persistAdd();

            response = new DWLResponse();
            response.setData(theXCompanyIdentificationBObj);
            response.setStatus(theXCompanyIdentificationBObj.getStatus());
    } catch (Exception ex) {
 				TCRMExceptionUtils.throwTCRMException(ex, new TCRMInsertException(ex.getMessage()), status,
                    DWLStatus.FATAL, DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_COMPONENT, TCRMErrorCode.INSERT_RECORD_ERROR,
                    DSEAAdditionsExtsErrorReasonCode.ADDXCOMPANYIDENTIFICATION_FAILED, theXCompanyIdentificationBObj.getControl(), errHandler);
        }
        
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction updateXCompanyIdentification.
     *
     * @param theBObj
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleUpdateXCompanyIdentification
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.UPDATE_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.UPDATE_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.UPDATEXCOMPANYIDENTIFICATION_FAILED
    )
     public DWLResponse updateXCompanyIdentification(XCompanyIdentificationBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER updateXCompanyIdentification(XCompanyIdentificationBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("updateXCompanyIdentification", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction updateXCompanyIdentification.";
      logger.finest("updateXCompanyIdentification(XCompanyIdentificationBObj theBObj) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction updateXCompanyIdentification.";
      logger.finest("updateXCompanyIdentification(XCompanyIdentificationBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN updateXCompanyIdentification(XCompanyIdentificationBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Updates the specified XCompanyIdentification with new attribute values.
     *
     * @param theXCompanyIdentificationBObj
     *     The object that contains XCompanyIdentification attribute values to
     *     be updated
     * @return
     *     DWLResponse containing a XCompanyIdentificationBObj of the updated
     *     object.
     * @exception Exception
     * @generated
     */
    public DWLResponse handleUpdateXCompanyIdentification(XCompanyIdentificationBObj theXCompanyIdentificationBObj) throws Exception {

        DWLStatus status = theXCompanyIdentificationBObj.getStatus();

        if (status == null) {
            status = new DWLStatus();
            theXCompanyIdentificationBObj.setStatus(status);
        }
        
            // set lastupdatetxid with txnid from dwlcontrol
            theXCompanyIdentificationBObj.getEObjXCompanyIdentification().setLastUpdateTxId(new Long(theXCompanyIdentificationBObj.getControl().getTxnId()));
         Persistence theXCompanyIdentificationBObjPersistence = getBObjPersistenceFactory().createXCompanyIdentificationBObjPersistence(XCompanyIdentificationBObjQuery.XCOMPANY_IDENTIFICATION_UPDATE, theXCompanyIdentificationBObj);
         theXCompanyIdentificationBObjPersistence.persistUpdate();

        DWLResponse response = createDWLResponse();
        response.setData(theXCompanyIdentificationBObj);
        response.setStatus(theXCompanyIdentificationBObj.getStatus());

        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXContractDetails.
     *
     * @param ContractpkId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetXContractDetails
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETXCONTRACTDETAILS_FAILED,
       beforePreExecuteMethod = "beforePreExecuteGetXContractDetails"
    )
     public DWLResponse getXContractDetails(String ContractpkId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getXContractDetails(String ContractpkId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(ContractpkId);
        DWLTransaction txObj = new  DWLTransactionInquiry("getXContractDetails", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction getXContractDetails.";
      logger.finest("getXContractDetails(String ContractpkId,  DWLControl control) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction getXContractDetails.";
      logger.finest("getXContractDetails(String ContractpkId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getXContractDetails(String ContractpkId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets a XContractDetails from the database.
     * 
     * @generated
     */
    public DWLResponse handleGetXContractDetails(String ContractpkId,  DWLControl control) throws Exception {
        DWLStatus status = new DWLStatus();
        DWLResponse response = createDWLResponse();
        
        BObjQuery bObjQuery = null;
           
        String asOfDate = (String) control.get(DWLControl.INQUIRE_AS_OF_DATE);

        // History data inquiry: if inquireAsOfDate field has value in request xml 
        if (StringUtils.isNonBlank(asOfDate)) {
            Timestamp tsAsOfDate = getPITHistoryDate(asOfDate, DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_COMPONENT,
                                                     DSEAAdditionsExtsErrorReasonCode.GETXCONTRACTDETAILS_INVALID_INQUIRE_AS_OF_DATE_FORMAT,
                                                     status, control);

            bObjQuery = getBObjQueryFactory().createXContractDetailsBObjQuery(XContractDetailsBObjQuery.XCONTRACT_DETAILS_HISTORY_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(ContractpkId));
            bObjQuery.setParameter(1, tsAsOfDate);
            bObjQuery.setParameter(2, tsAsOfDate);
        } else {
            bObjQuery = getBObjQueryFactory().createXContractDetailsBObjQuery(XContractDetailsBObjQuery.XCONTRACT_DETAILS_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(ContractpkId));
        }


        XContractDetailsBObj o = (XContractDetailsBObj) bObjQuery.getSingleResult();
        if( o == null ){
        	return null;
        } 
        postRetrieveXContractDetailsBObj(o, "0", "ALL", control); 
          
        if (o.getStatus()==null) {
            o.setStatus(status);
        }
        response.addStatus(o.getStatus());
        response.setData(o);

      return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public void beforePreExecuteGetXContractDetails(DWLTransaction transaction) throws DWLBaseException{
        // Check if the parameters are valid.
        Object[] arguments = getInquiryArgumentType((DWLTransactionInquiry)transaction);
        String pk = null;
        if (arguments!=null && arguments.length>0) {
            pk = (String)arguments[0];
        }
        // Check if the parameter passed in exists.
        if ((pk == null) || (pk.trim().length() == 0)) {
            TCRMExceptionUtils.throwTCRMException(null, new TCRMReadException(), transaction.getStatus(), DWLStatus.FATAL,
                DSEAAdditionsExtsComponentID.XCONTRACT_DETAILS_BOBJ,
                TCRMErrorCode.FIELD_VALIDATION_ERROR,
                DSEAAdditionsExtsErrorReasonCode.XCONTRACTDETAILS_CONTRACTPKID_NULL,
                transaction.getTxnControl(), errHandler);
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getAllXContractDetailsByPartyId.
     *
     * @param ContId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetAllXContractDetailsByPartyId
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETALLXCONTRACTDETAILSBYPARTYID_FAILED,
       beforePreExecuteMethod = "beforePreExecuteGetAllXContractDetailsByPartyId"
    )
     public DWLResponse getAllXContractDetailsByPartyId(String ContId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getAllXContractDetailsByPartyId(String ContId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(ContId);
        DWLTransaction txObj = new  DWLTransactionInquiry("getAllXContractDetailsByPartyId", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction getAllXContractDetailsByPartyId.";
      logger.finest("getAllXContractDetailsByPartyId(String ContId,  DWLControl control) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction getAllXContractDetailsByPartyId.";
      logger.finest("getAllXContractDetailsByPartyId(String ContId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getAllXContractDetailsByPartyId(String ContId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets a XContractDetails from the database.
     * 
     * @generated
     */
    public DWLResponse handleGetAllXContractDetailsByPartyId(String ContId,  DWLControl control) throws Exception {
        DWLStatus status = new DWLStatus();
        DWLResponse response = createDWLResponse();
        
        BObjQuery bObjQuery = null;
           
        String asOfDate = (String) control.get(DWLControl.INQUIRE_AS_OF_DATE);

        // History data inquiry: if inquireAsOfDate field has value in request xml 
        if (StringUtils.isNonBlank(asOfDate)) {
            Timestamp tsAsOfDate = getPITHistoryDate(asOfDate, DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_COMPONENT,
                                                     DSEAAdditionsExtsErrorReasonCode.GETALLXCONTRACTDETAILSBYPARTYID_INVALID_INQUIRE_AS_OF_DATE_FORMAT,
                                                     status, control);

            bObjQuery = getBObjQueryFactory().createXContractDetailsBObjQuery(XContractDetailsBObjQuery.ALL_XCONTRACT_DETAILS_BY_PARTY_ID_HISTORY_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(ContId));
            bObjQuery.setParameter(1, tsAsOfDate);
            bObjQuery.setParameter(2, tsAsOfDate);
        } else {
            bObjQuery = getBObjQueryFactory().createXContractDetailsBObjQuery(XContractDetailsBObjQuery.ALL_XCONTRACT_DETAILS_BY_PARTY_ID_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(ContId));
        }

        boolean considerForPagination = PaginationUtils
                            .considerForPagintion(XContractDetailsBObj.class.getName(), control);
        control.setConsiderForPagintionFlag(considerForPagination);

        // set returned object
        List<?> list = bObjQuery.getResults();

        if (list.size() == 0) {
            return null;
        }
    Vector<XContractDetailsBObj> vector = new Vector<XContractDetailsBObj>();
        for (Iterator<?> it = list.iterator(); it.hasNext();) {
            XContractDetailsBObj o = (XContractDetailsBObj) it.next();
            postRetrieveXContractDetailsBObj(o, "0", "ALL", control); 
            vector.add(o);
          
            if (o.getStatus()==null) {
                o.setStatus(status);
            }
            response.addStatus(o.getStatus());
        }
        response.setData(vector);

      return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public void beforePreExecuteGetAllXContractDetailsByPartyId(DWLTransaction transaction) throws DWLBaseException{
        // Check if the parameters are valid.
        Object[] arguments = getInquiryArgumentType((DWLTransactionInquiry)transaction);
    if (arguments!=null && arguments.length>0) {
            // MDM_TODO0: CDKWB0003I Add argument validation logic
    }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction addXContractDetails.
     *
     * @param theBObj
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleAddXContractDetails
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.ADD_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.INSERT_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.ADDXCONTRACTDETAILS_FAILED
    )
     public DWLResponse addXContractDetails(XContractDetailsBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER addXContractDetails(XContractDetailsBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("addXContractDetails", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction addXContractDetails.";
      logger.finest("addXContractDetails(XContractDetailsBObj theBObj) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction addXContractDetails.";
      logger.finest("addXContractDetails(XContractDetailsBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN addXContractDetails(XContractDetailsBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Adds a XContractDetails to the database.
     *
     * @param theXContractDetailsBObj
     *     The object that contains XContractDetails attribute values.
     * @return
     *     DWLResponse containing a XContractDetailsBObj object.
     * @exception Exception
     * @generated
     */
    public DWLResponse handleAddXContractDetails(XContractDetailsBObj theXContractDetailsBObj) throws Exception {
        DWLResponse response = null;
        DWLStatus status = theXContractDetailsBObj.getStatus();
        if (status == null) {
            status = new DWLStatus();
            theXContractDetailsBObj.setStatus(status);
        }

        String strPluggableID = null;

        try {
            // Pluggable Key Structure implementation
            strPluggableID = getSuppliedIdPKFromBObj(theXContractDetailsBObj);

            if ((strPluggableID != null) && (strPluggableID.length() > 0)) {
                theXContractDetailsBObj.getEObjXContractDetails().setContractpkId(FunctionUtils.getLongFromString(strPluggableID));
            } else {
                strPluggableID = null;
                theXContractDetailsBObj.getEObjXContractDetails().setContractpkId(null);
            }
         Persistence theXContractDetailsBObjPersistence = getBObjPersistenceFactory().createXContractDetailsBObjPersistence(XContractDetailsBObjQuery.XCONTRACT_DETAILS_ADD, theXContractDetailsBObj);
         theXContractDetailsBObjPersistence.persistAdd();

            response = new DWLResponse();
            response.setData(theXContractDetailsBObj);
            response.setStatus(theXContractDetailsBObj.getStatus());
    } catch (Exception ex) {
 				TCRMExceptionUtils.throwTCRMException(ex, new TCRMInsertException(ex.getMessage()), status,
                    DWLStatus.FATAL, DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_COMPONENT, TCRMErrorCode.INSERT_RECORD_ERROR,
                    DSEAAdditionsExtsErrorReasonCode.ADDXCONTRACTDETAILS_FAILED, theXContractDetailsBObj.getControl(), errHandler);
        }
        
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction updateXContractDetails.
     *
     * @param theBObj
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleUpdateXContractDetails
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.UPDATE_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.UPDATE_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.UPDATEXCONTRACTDETAILS_FAILED
    , manuallyHandleRedundantUpdateCheck="true"
    )
     public DWLResponse updateXContractDetails(XContractDetailsBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER updateXContractDetails(XContractDetailsBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("updateXContractDetails", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction updateXContractDetails.";
      logger.finest("updateXContractDetails(XContractDetailsBObj theBObj) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction updateXContractDetails.";
      logger.finest("updateXContractDetails(XContractDetailsBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN updateXContractDetails(XContractDetailsBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Updates the specified XContractDetails with new attribute values.
     *
     * @param theXContractDetailsBObj
     *     The object that contains XContractDetails attribute values to be
     *     updated
     * @return
     *     DWLResponse containing a XContractDetailsBObj of the updated object.
     * @exception Exception
     * @generated
     */
    public DWLResponse handleUpdateXContractDetails(XContractDetailsBObj theXContractDetailsBObj) throws Exception {

        DWLStatus status = theXContractDetailsBObj.getStatus();

        if (status == null) {
            status = new DWLStatus();
            theXContractDetailsBObj.setStatus(status);
        }
        
    if( !theXContractDetailsBObj.isRedundantUpdate() ){
            // set lastupdatetxid with txnid from dwlcontrol
            theXContractDetailsBObj.getEObjXContractDetails().setLastUpdateTxId(new Long(theXContractDetailsBObj.getControl().getTxnId()));
            Persistence theXContractDetailsBObjPersistence = getBObjPersistenceFactory().createXContractDetailsBObjPersistence(XContractDetailsBObjQuery.XCONTRACT_DETAILS_UPDATE, theXContractDetailsBObj);
            theXContractDetailsBObjPersistence.persistUpdate();
        }

        DWLResponse response = createDWLResponse();
        response.setData(theXContractDetailsBObj);
        response.setStatus(theXContractDetailsBObj.getStatus());

        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXGurantorIndividual.
     *
     * @param XGurantorIndividualpkId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetXGurantorIndividual
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETXGURANTORINDIVIDUAL_FAILED,
       beforePreExecuteMethod = "beforePreExecuteGetXGurantorIndividual"
    )
     public DWLResponse getXGurantorIndividual(String XGurantorIndividualpkId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getXGurantorIndividual(String XGurantorIndividualpkId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(XGurantorIndividualpkId);
        DWLTransaction txObj = new  DWLTransactionInquiry("getXGurantorIndividual", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction getXGurantorIndividual.";
      logger.finest("getXGurantorIndividual(String XGurantorIndividualpkId,  DWLControl control) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction getXGurantorIndividual.";
      logger.finest("getXGurantorIndividual(String XGurantorIndividualpkId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getXGurantorIndividual(String XGurantorIndividualpkId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets a XGurantorIndividual from the database.
     * 
     * @generated
     */
    public DWLResponse handleGetXGurantorIndividual(String XGurantorIndividualpkId,  DWLControl control) throws Exception {
        DWLStatus status = new DWLStatus();
        DWLResponse response = createDWLResponse();
        
        BObjQuery bObjQuery = null;
           
        String asOfDate = (String) control.get(DWLControl.INQUIRE_AS_OF_DATE);

        // History data inquiry: if inquireAsOfDate field has value in request xml 
        if (StringUtils.isNonBlank(asOfDate)) {
            Timestamp tsAsOfDate = getPITHistoryDate(asOfDate, DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_COMPONENT,
                                                     DSEAAdditionsExtsErrorReasonCode.GETXGURANTORINDIVIDUAL_INVALID_INQUIRE_AS_OF_DATE_FORMAT,
                                                     status, control);

            bObjQuery = getBObjQueryFactory().createXGurantorIndividualBObjQuery(XGurantorIndividualBObjQuery.XGURANTOR_INDIVIDUAL_HISTORY_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(XGurantorIndividualpkId));
            bObjQuery.setParameter(1, tsAsOfDate);
            bObjQuery.setParameter(2, tsAsOfDate);
        } else {
            bObjQuery = getBObjQueryFactory().createXGurantorIndividualBObjQuery(XGurantorIndividualBObjQuery.XGURANTOR_INDIVIDUAL_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(XGurantorIndividualpkId));
        }


        XGurantorIndividualBObj o = (XGurantorIndividualBObj) bObjQuery.getSingleResult();
        if( o == null ){
        	return null;
        } 
        postRetrieveXGurantorIndividualBObj(o, "0", "ALL", control); 
          
        if (o.getStatus()==null) {
            o.setStatus(status);
        }
        response.addStatus(o.getStatus());
        response.setData(o);

      return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public void beforePreExecuteGetXGurantorIndividual(DWLTransaction transaction) throws DWLBaseException{
        // Check if the parameters are valid.
        Object[] arguments = getInquiryArgumentType((DWLTransactionInquiry)transaction);
        String pk = null;
        if (arguments!=null && arguments.length>0) {
            pk = (String)arguments[0];
        }
        // Check if the parameter passed in exists.
        if ((pk == null) || (pk.trim().length() == 0)) {
            TCRMExceptionUtils.throwTCRMException(null, new TCRMReadException(), transaction.getStatus(), DWLStatus.FATAL,
                DSEAAdditionsExtsComponentID.XGURANTOR_INDIVIDUAL_BOBJ,
                TCRMErrorCode.FIELD_VALIDATION_ERROR,
                DSEAAdditionsExtsErrorReasonCode.XGURANTORINDIVIDUAL_XGURANTORINDIVIDUALPKID_NULL,
                transaction.getTxnControl(), errHandler);
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getAllXGurantorIndividualByContractDetailsId.
     *
     * @param ContractDetailsId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetAllXGurantorIndividualByContractDetailsId
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETALLXGURANTORINDIVIDUALBYCONTRACTDETAILSID_FAILED,
       beforePreExecuteMethod = "beforePreExecuteGetAllXGurantorIndividualByContractDetailsId"
    )
     public DWLResponse getAllXGurantorIndividualByContractDetailsId(String ContractDetailsId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getAllXGurantorIndividualByContractDetailsId(String ContractDetailsId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(ContractDetailsId);
        DWLTransaction txObj = new  DWLTransactionInquiry("getAllXGurantorIndividualByContractDetailsId", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction getAllXGurantorIndividualByContractDetailsId.";
      logger.finest("getAllXGurantorIndividualByContractDetailsId(String ContractDetailsId,  DWLControl control) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction getAllXGurantorIndividualByContractDetailsId.";
      logger.finest("getAllXGurantorIndividualByContractDetailsId(String ContractDetailsId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getAllXGurantorIndividualByContractDetailsId(String ContractDetailsId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets a XGurantorIndividual from the database.
     * 
     * @generated
     */
    public DWLResponse handleGetAllXGurantorIndividualByContractDetailsId(String ContractDetailsId,  DWLControl control) throws Exception {
        DWLStatus status = new DWLStatus();
        DWLResponse response = createDWLResponse();
        
        BObjQuery bObjQuery = null;
           
        String asOfDate = (String) control.get(DWLControl.INQUIRE_AS_OF_DATE);

        // History data inquiry: if inquireAsOfDate field has value in request xml 
        if (StringUtils.isNonBlank(asOfDate)) {
            Timestamp tsAsOfDate = getPITHistoryDate(asOfDate, DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_COMPONENT,
                                                     DSEAAdditionsExtsErrorReasonCode.GETALLXGURANTORINDIVIDUALBYCONTRACTDETAILSID_INVALID_INQUIRE_AS_OF_DATE_FORMAT,
                                                     status, control);

            bObjQuery = getBObjQueryFactory().createXGurantorIndividualBObjQuery(XGurantorIndividualBObjQuery.ALL_XGURANTOR_INDIVIDUAL_BY_CONTRACT_DETAILS_ID_HISTORY_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(ContractDetailsId));
            bObjQuery.setParameter(1, tsAsOfDate);
            bObjQuery.setParameter(2, tsAsOfDate);
        } else {
            bObjQuery = getBObjQueryFactory().createXGurantorIndividualBObjQuery(XGurantorIndividualBObjQuery.ALL_XGURANTOR_INDIVIDUAL_BY_CONTRACT_DETAILS_ID_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(ContractDetailsId));
        }

        boolean considerForPagination = PaginationUtils
                            .considerForPagintion(XGurantorIndividualBObj.class.getName(), control);
        control.setConsiderForPagintionFlag(considerForPagination);

        // set returned object
        List<?> list = bObjQuery.getResults();

        if (list.size() == 0) {
            return null;
        }
    Vector<XGurantorIndividualBObj> vector = new Vector<XGurantorIndividualBObj>();
        for (Iterator<?> it = list.iterator(); it.hasNext();) {
            XGurantorIndividualBObj o = (XGurantorIndividualBObj) it.next();
            postRetrieveXGurantorIndividualBObj(o, "0", "ALL", control); 
            vector.add(o);
          
            if (o.getStatus()==null) {
                o.setStatus(status);
            }
            response.addStatus(o.getStatus());
        }
        response.setData(vector);

      return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public void beforePreExecuteGetAllXGurantorIndividualByContractDetailsId(DWLTransaction transaction) throws DWLBaseException{
        // Check if the parameters are valid.
        Object[] arguments = getInquiryArgumentType((DWLTransactionInquiry)transaction);
    if (arguments!=null && arguments.length>0) {
            // MDM_TODO0: CDKWB0003I Add argument validation logic
    }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction addXGurantorIndividual.
     *
     * @param theBObj
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleAddXGurantorIndividual
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.ADD_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.INSERT_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.ADDXGURANTORINDIVIDUAL_FAILED
    )
     public DWLResponse addXGurantorIndividual(XGurantorIndividualBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER addXGurantorIndividual(XGurantorIndividualBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("addXGurantorIndividual", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction addXGurantorIndividual.";
      logger.finest("addXGurantorIndividual(XGurantorIndividualBObj theBObj) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction addXGurantorIndividual.";
      logger.finest("addXGurantorIndividual(XGurantorIndividualBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN addXGurantorIndividual(XGurantorIndividualBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Adds a XGurantorIndividual to the database.
     *
     * @param theXGurantorIndividualBObj
     *     The object that contains XGurantorIndividual attribute values.
     * @return
     *     DWLResponse containing a XGurantorIndividualBObj object.
     * @exception Exception
     * @generated
     */
    public DWLResponse handleAddXGurantorIndividual(XGurantorIndividualBObj theXGurantorIndividualBObj) throws Exception {
        DWLResponse response = null;
        DWLStatus status = theXGurantorIndividualBObj.getStatus();
        if (status == null) {
            status = new DWLStatus();
            theXGurantorIndividualBObj.setStatus(status);
        }

        String strPluggableID = null;

        try {
            // Pluggable Key Structure implementation
            strPluggableID = getSuppliedIdPKFromBObj(theXGurantorIndividualBObj);

            if ((strPluggableID != null) && (strPluggableID.length() > 0)) {
                theXGurantorIndividualBObj.getEObjXGurantorIndividual().setXGurantorIndividualpkId(FunctionUtils.getLongFromString(strPluggableID));
            } else {
                strPluggableID = null;
                theXGurantorIndividualBObj.getEObjXGurantorIndividual().setXGurantorIndividualpkId(null);
            }
         Persistence theXGurantorIndividualBObjPersistence = getBObjPersistenceFactory().createXGurantorIndividualBObjPersistence(XGurantorIndividualBObjQuery.XGURANTOR_INDIVIDUAL_ADD, theXGurantorIndividualBObj);
         theXGurantorIndividualBObjPersistence.persistAdd();

            response = new DWLResponse();
            response.setData(theXGurantorIndividualBObj);
            response.setStatus(theXGurantorIndividualBObj.getStatus());
    } catch (Exception ex) {
 				TCRMExceptionUtils.throwTCRMException(ex, new TCRMInsertException(ex.getMessage()), status,
                    DWLStatus.FATAL, DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_COMPONENT, TCRMErrorCode.INSERT_RECORD_ERROR,
                    DSEAAdditionsExtsErrorReasonCode.ADDXGURANTORINDIVIDUAL_FAILED, theXGurantorIndividualBObj.getControl(), errHandler);
        }
        
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction updateXGurantorIndividual.
     *
     * @param theBObj
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleUpdateXGurantorIndividual
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.UPDATE_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.UPDATE_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.UPDATEXGURANTORINDIVIDUAL_FAILED
    )
     public DWLResponse updateXGurantorIndividual(XGurantorIndividualBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER updateXGurantorIndividual(XGurantorIndividualBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("updateXGurantorIndividual", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction updateXGurantorIndividual.";
      logger.finest("updateXGurantorIndividual(XGurantorIndividualBObj theBObj) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction updateXGurantorIndividual.";
      logger.finest("updateXGurantorIndividual(XGurantorIndividualBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN updateXGurantorIndividual(XGurantorIndividualBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Updates the specified XGurantorIndividual with new attribute values.
     *
     * @param theXGurantorIndividualBObj
     *     The object that contains XGurantorIndividual attribute values to be
     *     updated
     * @return
     *     DWLResponse containing a XGurantorIndividualBObj of the updated
     *     object.
     * @exception Exception
     * @generated
     */
    public DWLResponse handleUpdateXGurantorIndividual(XGurantorIndividualBObj theXGurantorIndividualBObj) throws Exception {

        DWLStatus status = theXGurantorIndividualBObj.getStatus();

        if (status == null) {
            status = new DWLStatus();
            theXGurantorIndividualBObj.setStatus(status);
        }
        
            // set lastupdatetxid with txnid from dwlcontrol
            theXGurantorIndividualBObj.getEObjXGurantorIndividual().setLastUpdateTxId(new Long(theXGurantorIndividualBObj.getControl().getTxnId()));
         Persistence theXGurantorIndividualBObjPersistence = getBObjPersistenceFactory().createXGurantorIndividualBObjPersistence(XGurantorIndividualBObjQuery.XGURANTOR_INDIVIDUAL_UPDATE, theXGurantorIndividualBObj);
         theXGurantorIndividualBObjPersistence.persistUpdate();

        DWLResponse response = createDWLResponse();
        response.setData(theXGurantorIndividualBObj);
        response.setStatus(theXGurantorIndividualBObj.getStatus());

        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXGurantorCompany.
     *
     * @param XGurantorCompanypkId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetXGurantorCompany
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETXGURANTORCOMPANY_FAILED,
       beforePreExecuteMethod = "beforePreExecuteGetXGurantorCompany"
    )
     public DWLResponse getXGurantorCompany(String XGurantorCompanypkId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getXGurantorCompany(String XGurantorCompanypkId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(XGurantorCompanypkId);
        DWLTransaction txObj = new  DWLTransactionInquiry("getXGurantorCompany", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction getXGurantorCompany.";
      logger.finest("getXGurantorCompany(String XGurantorCompanypkId,  DWLControl control) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction getXGurantorCompany.";
      logger.finest("getXGurantorCompany(String XGurantorCompanypkId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getXGurantorCompany(String XGurantorCompanypkId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets a XGurantorCompany from the database.
     * 
     * @generated
     */
    public DWLResponse handleGetXGurantorCompany(String XGurantorCompanypkId,  DWLControl control) throws Exception {
        DWLStatus status = new DWLStatus();
        DWLResponse response = createDWLResponse();
        
        BObjQuery bObjQuery = null;
           
        String asOfDate = (String) control.get(DWLControl.INQUIRE_AS_OF_DATE);

        // History data inquiry: if inquireAsOfDate field has value in request xml 
        if (StringUtils.isNonBlank(asOfDate)) {
            Timestamp tsAsOfDate = getPITHistoryDate(asOfDate, DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_COMPONENT,
                                                     DSEAAdditionsExtsErrorReasonCode.GETXGURANTORCOMPANY_INVALID_INQUIRE_AS_OF_DATE_FORMAT,
                                                     status, control);

            bObjQuery = getBObjQueryFactory().createXGurantorCompanyBObjQuery(XGurantorCompanyBObjQuery.XGURANTOR_COMPANY_HISTORY_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(XGurantorCompanypkId));
            bObjQuery.setParameter(1, tsAsOfDate);
            bObjQuery.setParameter(2, tsAsOfDate);
        } else {
            bObjQuery = getBObjQueryFactory().createXGurantorCompanyBObjQuery(XGurantorCompanyBObjQuery.XGURANTOR_COMPANY_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(XGurantorCompanypkId));
        }


        XGurantorCompanyBObj o = (XGurantorCompanyBObj) bObjQuery.getSingleResult();
        if( o == null ){
        	return null;
        } 
        postRetrieveXGurantorCompanyBObj(o, "0", "ALL", control); 
          
        if (o.getStatus()==null) {
            o.setStatus(status);
        }
        response.addStatus(o.getStatus());
        response.setData(o);

      return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public void beforePreExecuteGetXGurantorCompany(DWLTransaction transaction) throws DWLBaseException{
        // Check if the parameters are valid.
        Object[] arguments = getInquiryArgumentType((DWLTransactionInquiry)transaction);
        String pk = null;
        if (arguments!=null && arguments.length>0) {
            pk = (String)arguments[0];
        }
        // Check if the parameter passed in exists.
        if ((pk == null) || (pk.trim().length() == 0)) {
            TCRMExceptionUtils.throwTCRMException(null, new TCRMReadException(), transaction.getStatus(), DWLStatus.FATAL,
                DSEAAdditionsExtsComponentID.XGURANTOR_COMPANY_BOBJ,
                TCRMErrorCode.FIELD_VALIDATION_ERROR,
                DSEAAdditionsExtsErrorReasonCode.XGURANTORCOMPANY_XGURANTORCOMPANYPKID_NULL,
                transaction.getTxnControl(), errHandler);
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getAllXGurantorCompanyByContractDetailsId.
     *
     * @param ContractDetailsId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetAllXGurantorCompanyByContractDetailsId
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETALLXGURANTORCOMPANYBYCONTRACTDETAILSID_FAILED,
       beforePreExecuteMethod = "beforePreExecuteGetAllXGurantorCompanyByContractDetailsId"
    )
     public DWLResponse getAllXGurantorCompanyByContractDetailsId(String ContractDetailsId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getAllXGurantorCompanyByContractDetailsId(String ContractDetailsId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(ContractDetailsId);
        DWLTransaction txObj = new  DWLTransactionInquiry("getAllXGurantorCompanyByContractDetailsId", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction getAllXGurantorCompanyByContractDetailsId.";
      logger.finest("getAllXGurantorCompanyByContractDetailsId(String ContractDetailsId,  DWLControl control) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction getAllXGurantorCompanyByContractDetailsId.";
      logger.finest("getAllXGurantorCompanyByContractDetailsId(String ContractDetailsId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getAllXGurantorCompanyByContractDetailsId(String ContractDetailsId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets a XGurantorCompany from the database.
     * 
     * @generated
     */
    public DWLResponse handleGetAllXGurantorCompanyByContractDetailsId(String ContractDetailsId,  DWLControl control) throws Exception {
        DWLStatus status = new DWLStatus();
        DWLResponse response = createDWLResponse();
        
        BObjQuery bObjQuery = null;
           
        String asOfDate = (String) control.get(DWLControl.INQUIRE_AS_OF_DATE);

        // History data inquiry: if inquireAsOfDate field has value in request xml 
        if (StringUtils.isNonBlank(asOfDate)) {
            Timestamp tsAsOfDate = getPITHistoryDate(asOfDate, DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_COMPONENT,
                                                     DSEAAdditionsExtsErrorReasonCode.GETALLXGURANTORCOMPANYBYCONTRACTDETAILSID_INVALID_INQUIRE_AS_OF_DATE_FORMAT,
                                                     status, control);

            bObjQuery = getBObjQueryFactory().createXGurantorCompanyBObjQuery(XGurantorCompanyBObjQuery.ALL_XGURANTOR_COMPANY_BY_CONTRACT_DETAILS_ID_HISTORY_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(ContractDetailsId));
            bObjQuery.setParameter(1, tsAsOfDate);
            bObjQuery.setParameter(2, tsAsOfDate);
        } else {
            bObjQuery = getBObjQueryFactory().createXGurantorCompanyBObjQuery(XGurantorCompanyBObjQuery.ALL_XGURANTOR_COMPANY_BY_CONTRACT_DETAILS_ID_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(ContractDetailsId));
        }

        boolean considerForPagination = PaginationUtils
                            .considerForPagintion(XGurantorCompanyBObj.class.getName(), control);
        control.setConsiderForPagintionFlag(considerForPagination);

        // set returned object
        List<?> list = bObjQuery.getResults();

        if (list.size() == 0) {
            return null;
        }
    Vector<XGurantorCompanyBObj> vector = new Vector<XGurantorCompanyBObj>();
        for (Iterator<?> it = list.iterator(); it.hasNext();) {
            XGurantorCompanyBObj o = (XGurantorCompanyBObj) it.next();
            postRetrieveXGurantorCompanyBObj(o, "0", "ALL", control); 
            vector.add(o);
          
            if (o.getStatus()==null) {
                o.setStatus(status);
            }
            response.addStatus(o.getStatus());
        }
        response.setData(vector);

      return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public void beforePreExecuteGetAllXGurantorCompanyByContractDetailsId(DWLTransaction transaction) throws DWLBaseException{
        // Check if the parameters are valid.
        Object[] arguments = getInquiryArgumentType((DWLTransactionInquiry)transaction);
    if (arguments!=null && arguments.length>0) {
            // MDM_TODO0: CDKWB0003I Add argument validation logic
    }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction addXGurantorCompany.
     *
     * @param theBObj
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleAddXGurantorCompany
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.ADD_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.INSERT_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.ADDXGURANTORCOMPANY_FAILED
    )
     public DWLResponse addXGurantorCompany(XGurantorCompanyBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER addXGurantorCompany(XGurantorCompanyBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("addXGurantorCompany", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction addXGurantorCompany.";
      logger.finest("addXGurantorCompany(XGurantorCompanyBObj theBObj) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction addXGurantorCompany.";
      logger.finest("addXGurantorCompany(XGurantorCompanyBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN addXGurantorCompany(XGurantorCompanyBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Adds a XGurantorCompany to the database.
     *
     * @param theXGurantorCompanyBObj
     *     The object that contains XGurantorCompany attribute values.
     * @return
     *     DWLResponse containing a XGurantorCompanyBObj object.
     * @exception Exception
     * @generated
     */
    public DWLResponse handleAddXGurantorCompany(XGurantorCompanyBObj theXGurantorCompanyBObj) throws Exception {
        DWLResponse response = null;
        DWLStatus status = theXGurantorCompanyBObj.getStatus();
        if (status == null) {
            status = new DWLStatus();
            theXGurantorCompanyBObj.setStatus(status);
        }

        String strPluggableID = null;

        try {
            // Pluggable Key Structure implementation
            strPluggableID = getSuppliedIdPKFromBObj(theXGurantorCompanyBObj);

            if ((strPluggableID != null) && (strPluggableID.length() > 0)) {
                theXGurantorCompanyBObj.getEObjXGurantorCompany().setXGurantorCompanypkId(FunctionUtils.getLongFromString(strPluggableID));
            } else {
                strPluggableID = null;
                theXGurantorCompanyBObj.getEObjXGurantorCompany().setXGurantorCompanypkId(null);
            }
         Persistence theXGurantorCompanyBObjPersistence = getBObjPersistenceFactory().createXGurantorCompanyBObjPersistence(XGurantorCompanyBObjQuery.XGURANTOR_COMPANY_ADD, theXGurantorCompanyBObj);
         theXGurantorCompanyBObjPersistence.persistAdd();

            response = new DWLResponse();
            response.setData(theXGurantorCompanyBObj);
            response.setStatus(theXGurantorCompanyBObj.getStatus());
    } catch (Exception ex) {
 				TCRMExceptionUtils.throwTCRMException(ex, new TCRMInsertException(ex.getMessage()), status,
                    DWLStatus.FATAL, DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_COMPONENT, TCRMErrorCode.INSERT_RECORD_ERROR,
                    DSEAAdditionsExtsErrorReasonCode.ADDXGURANTORCOMPANY_FAILED, theXGurantorCompanyBObj.getControl(), errHandler);
        }
        
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction updateXGurantorCompany.
     *
     * @param theBObj
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleUpdateXGurantorCompany
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.UPDATE_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.UPDATE_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.UPDATEXGURANTORCOMPANY_FAILED
    )
     public DWLResponse updateXGurantorCompany(XGurantorCompanyBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER updateXGurantorCompany(XGurantorCompanyBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("updateXGurantorCompany", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction updateXGurantorCompany.";
      logger.finest("updateXGurantorCompany(XGurantorCompanyBObj theBObj) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction updateXGurantorCompany.";
      logger.finest("updateXGurantorCompany(XGurantorCompanyBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN updateXGurantorCompany(XGurantorCompanyBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Updates the specified XGurantorCompany with new attribute values.
     *
     * @param theXGurantorCompanyBObj
     *     The object that contains XGurantorCompany attribute values to be
     *     updated
     * @return
     *     DWLResponse containing a XGurantorCompanyBObj of the updated object.
     * @exception Exception
     * @generated
     */
    public DWLResponse handleUpdateXGurantorCompany(XGurantorCompanyBObj theXGurantorCompanyBObj) throws Exception {

        DWLStatus status = theXGurantorCompanyBObj.getStatus();

        if (status == null) {
            status = new DWLStatus();
            theXGurantorCompanyBObj.setStatus(status);
        }
        
            // set lastupdatetxid with txnid from dwlcontrol
            theXGurantorCompanyBObj.getEObjXGurantorCompany().setLastUpdateTxId(new Long(theXGurantorCompanyBObj.getControl().getTxnId()));
         Persistence theXGurantorCompanyBObjPersistence = getBObjPersistenceFactory().createXGurantorCompanyBObjPersistence(XGurantorCompanyBObjQuery.XGURANTOR_COMPANY_UPDATE, theXGurantorCompanyBObj);
         theXGurantorCompanyBObjPersistence.persistUpdate();

        DWLResponse response = createDWLResponse();
        response.setData(theXGurantorCompanyBObj);
        response.setStatus(theXGurantorCompanyBObj.getStatus());

        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXDealerRetailer.
     *
     * @param XDealerRetailerpkId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetXDealerRetailer
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETXDEALERRETAILER_FAILED,
       beforePreExecuteMethod = "beforePreExecuteGetXDealerRetailer"
    )
     public DWLResponse getXDealerRetailer(String XDealerRetailerpkId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getXDealerRetailer(String XDealerRetailerpkId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(XDealerRetailerpkId);
        DWLTransaction txObj = new  DWLTransactionInquiry("getXDealerRetailer", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction getXDealerRetailer.";
      logger.finest("getXDealerRetailer(String XDealerRetailerpkId,  DWLControl control) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction getXDealerRetailer.";
      logger.finest("getXDealerRetailer(String XDealerRetailerpkId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getXDealerRetailer(String XDealerRetailerpkId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets a XDealerRetailer from the database.
     * 
     * @generated
     */
    public DWLResponse handleGetXDealerRetailer(String XDealerRetailerpkId,  DWLControl control) throws Exception {
        DWLStatus status = new DWLStatus();
        DWLResponse response = createDWLResponse();
        
        BObjQuery bObjQuery = null;
           
        String asOfDate = (String) control.get(DWLControl.INQUIRE_AS_OF_DATE);

        // History data inquiry: if inquireAsOfDate field has value in request xml 
        if (StringUtils.isNonBlank(asOfDate)) {
            Timestamp tsAsOfDate = getPITHistoryDate(asOfDate, DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_COMPONENT,
                                                     DSEAAdditionsExtsErrorReasonCode.GETXDEALERRETAILER_INVALID_INQUIRE_AS_OF_DATE_FORMAT,
                                                     status, control);

            bObjQuery = getBObjQueryFactory().createXDealerRetailerBObjQuery(XDealerRetailerBObjQuery.XDEALER_RETAILER_HISTORY_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(XDealerRetailerpkId));
            bObjQuery.setParameter(1, tsAsOfDate);
            bObjQuery.setParameter(2, tsAsOfDate);
        } else {
            bObjQuery = getBObjQueryFactory().createXDealerRetailerBObjQuery(XDealerRetailerBObjQuery.XDEALER_RETAILER_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(XDealerRetailerpkId));
        }


        XDealerRetailerBObj o = (XDealerRetailerBObj) bObjQuery.getSingleResult();
        if( o == null ){
        	return null;
        } 
          
        if (o.getStatus()==null) {
            o.setStatus(status);
        }
        response.addStatus(o.getStatus());
        response.setData(o);

      return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public void beforePreExecuteGetXDealerRetailer(DWLTransaction transaction) throws DWLBaseException{
        // Check if the parameters are valid.
        Object[] arguments = getInquiryArgumentType((DWLTransactionInquiry)transaction);
        String pk = null;
        if (arguments!=null && arguments.length>0) {
            pk = (String)arguments[0];
        }
        // Check if the parameter passed in exists.
        if ((pk == null) || (pk.trim().length() == 0)) {
            TCRMExceptionUtils.throwTCRMException(null, new TCRMReadException(), transaction.getStatus(), DWLStatus.FATAL,
                DSEAAdditionsExtsComponentID.XDEALER_RETAILER_BOBJ,
                TCRMErrorCode.FIELD_VALIDATION_ERROR,
                DSEAAdditionsExtsErrorReasonCode.XDEALERRETAILER_XDEALERRETAILERPKID_NULL,
                transaction.getTxnControl(), errHandler);
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction addXDealerRetailer.
     *
     * @param theBObj
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleAddXDealerRetailer
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.ADD_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.INSERT_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.ADDXDEALERRETAILER_FAILED
    )
     public DWLResponse addXDealerRetailer(XDealerRetailerBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER addXDealerRetailer(XDealerRetailerBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("addXDealerRetailer", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction addXDealerRetailer.";
      logger.finest("addXDealerRetailer(XDealerRetailerBObj theBObj) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction addXDealerRetailer.";
      logger.finest("addXDealerRetailer(XDealerRetailerBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN addXDealerRetailer(XDealerRetailerBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Adds a XDealerRetailer to the database.
     *
     * @param theXDealerRetailerBObj
     *     The object that contains XDealerRetailer attribute values.
     * @return
     *     DWLResponse containing a XDealerRetailerBObj object.
     * @exception Exception
     * @generated
     */
    public DWLResponse handleAddXDealerRetailer(XDealerRetailerBObj theXDealerRetailerBObj) throws Exception {
        DWLResponse response = null;
        DWLStatus status = theXDealerRetailerBObj.getStatus();
        if (status == null) {
            status = new DWLStatus();
            theXDealerRetailerBObj.setStatus(status);
        }

        String strPluggableID = null;

        try {
            // Pluggable Key Structure implementation
            strPluggableID = getSuppliedIdPKFromBObj(theXDealerRetailerBObj);

            if ((strPluggableID != null) && (strPluggableID.length() > 0)) {
                theXDealerRetailerBObj.getEObjXDealerRetailer().setXDealerRetailerpkId(FunctionUtils.getLongFromString(strPluggableID));
            } else {
                strPluggableID = null;
                theXDealerRetailerBObj.getEObjXDealerRetailer().setXDealerRetailerpkId(null);
            }
         Persistence theXDealerRetailerBObjPersistence = getBObjPersistenceFactory().createXDealerRetailerBObjPersistence(XDealerRetailerBObjQuery.XDEALER_RETAILER_ADD, theXDealerRetailerBObj);
         theXDealerRetailerBObjPersistence.persistAdd();

            response = new DWLResponse();
            response.setData(theXDealerRetailerBObj);
            response.setStatus(theXDealerRetailerBObj.getStatus());
    } catch (Exception ex) {
 				TCRMExceptionUtils.throwTCRMException(ex, new TCRMInsertException(ex.getMessage()), status,
                    DWLStatus.FATAL, DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_COMPONENT, TCRMErrorCode.INSERT_RECORD_ERROR,
                    DSEAAdditionsExtsErrorReasonCode.ADDXDEALERRETAILER_FAILED, theXDealerRetailerBObj.getControl(), errHandler);
        }
        
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction updateXDealerRetailer.
     *
     * @param theBObj
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleUpdateXDealerRetailer
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.UPDATE_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.UPDATE_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.UPDATEXDEALERRETAILER_FAILED
    )
     public DWLResponse updateXDealerRetailer(XDealerRetailerBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER updateXDealerRetailer(XDealerRetailerBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("updateXDealerRetailer", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction updateXDealerRetailer.";
      logger.finest("updateXDealerRetailer(XDealerRetailerBObj theBObj) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction updateXDealerRetailer.";
      logger.finest("updateXDealerRetailer(XDealerRetailerBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN updateXDealerRetailer(XDealerRetailerBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Updates the specified XDealerRetailer with new attribute values.
     *
     * @param theXDealerRetailerBObj
     *     The object that contains XDealerRetailer attribute values to be
     *     updated
     * @return
     *     DWLResponse containing a XDealerRetailerBObj of the updated object.
     * @exception Exception
     * @generated
     */
    public DWLResponse handleUpdateXDealerRetailer(XDealerRetailerBObj theXDealerRetailerBObj) throws Exception {

        DWLStatus status = theXDealerRetailerBObj.getStatus();

        if (status == null) {
            status = new DWLStatus();
            theXDealerRetailerBObj.setStatus(status);
        }
        
            // set lastupdatetxid with txnid from dwlcontrol
            theXDealerRetailerBObj.getEObjXDealerRetailer().setLastUpdateTxId(new Long(theXDealerRetailerBObj.getControl().getTxnId()));
         Persistence theXDealerRetailerBObjPersistence = getBObjPersistenceFactory().createXDealerRetailerBObjPersistence(XDealerRetailerBObjQuery.XDEALER_RETAILER_UPDATE, theXDealerRetailerBObj);
         theXDealerRetailerBObjPersistence.persistUpdate();

        DWLResponse response = createDWLResponse();
        response.setData(theXDealerRetailerBObj);
        response.setStatus(theXDealerRetailerBObj.getStatus());

        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXMagicRel.
     *
     * @param XMagicRelpkId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetXMagicRel
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETXMAGICREL_FAILED,
       beforePreExecuteMethod = "beforePreExecuteGetXMagicRel"
    )
     public DWLResponse getXMagicRel(String XMagicRelpkId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getXMagicRel(String XMagicRelpkId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(XMagicRelpkId);
        DWLTransaction txObj = new  DWLTransactionInquiry("getXMagicRel", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction getXMagicRel.";
      logger.finest("getXMagicRel(String XMagicRelpkId,  DWLControl control) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction getXMagicRel.";
      logger.finest("getXMagicRel(String XMagicRelpkId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getXMagicRel(String XMagicRelpkId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets a XMagicRel from the database.
     * 
     * @generated
     */
    public DWLResponse handleGetXMagicRel(String XMagicRelpkId,  DWLControl control) throws Exception {
        DWLStatus status = new DWLStatus();
        DWLResponse response = createDWLResponse();
        
        BObjQuery bObjQuery = null;
           
        String asOfDate = (String) control.get(DWLControl.INQUIRE_AS_OF_DATE);

        // History data inquiry: if inquireAsOfDate field has value in request xml 
        if (StringUtils.isNonBlank(asOfDate)) {
            Timestamp tsAsOfDate = getPITHistoryDate(asOfDate, DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_COMPONENT,
                                                     DSEAAdditionsExtsErrorReasonCode.GETXMAGICREL_INVALID_INQUIRE_AS_OF_DATE_FORMAT,
                                                     status, control);

            bObjQuery = getBObjQueryFactory().createXMagicRelBObjQuery(XMagicRelBObjQuery.XMAGIC_REL_HISTORY_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(XMagicRelpkId));
            bObjQuery.setParameter(1, tsAsOfDate);
            bObjQuery.setParameter(2, tsAsOfDate);
        } else {
            bObjQuery = getBObjQueryFactory().createXMagicRelBObjQuery(XMagicRelBObjQuery.XMAGIC_REL_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(XMagicRelpkId));
        }


        XMagicRelBObj o = (XMagicRelBObj) bObjQuery.getSingleResult();
        if( o == null ){
        	return null;
        } 
          
        if (o.getStatus()==null) {
            o.setStatus(status);
        }
        response.addStatus(o.getStatus());
        response.setData(o);

      return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public void beforePreExecuteGetXMagicRel(DWLTransaction transaction) throws DWLBaseException{
        // Check if the parameters are valid.
        Object[] arguments = getInquiryArgumentType((DWLTransactionInquiry)transaction);
        String pk = null;
        if (arguments!=null && arguments.length>0) {
            pk = (String)arguments[0];
        }
        // Check if the parameter passed in exists.
        if ((pk == null) || (pk.trim().length() == 0)) {
            TCRMExceptionUtils.throwTCRMException(null, new TCRMReadException(), transaction.getStatus(), DWLStatus.FATAL,
                DSEAAdditionsExtsComponentID.XMAGIC_REL_BOBJ,
                TCRMErrorCode.FIELD_VALIDATION_ERROR,
                DSEAAdditionsExtsErrorReasonCode.XMAGICREL_XMAGICRELPKID_NULL,
                transaction.getTxnControl(), errHandler);
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction addXMagicRel.
     *
     * @param theBObj
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleAddXMagicRel
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.ADD_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.INSERT_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.ADDXMAGICREL_FAILED
    )
     public DWLResponse addXMagicRel(XMagicRelBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER addXMagicRel(XMagicRelBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("addXMagicRel", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction addXMagicRel.";
      logger.finest("addXMagicRel(XMagicRelBObj theBObj) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction addXMagicRel.";
      logger.finest("addXMagicRel(XMagicRelBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN addXMagicRel(XMagicRelBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Adds a XMagicRel to the database.
     *
     * @param theXMagicRelBObj
     *     The object that contains XMagicRel attribute values.
     * @return
     *     DWLResponse containing a XMagicRelBObj object.
     * @exception Exception
     * @generated
     */
    public DWLResponse handleAddXMagicRel(XMagicRelBObj theXMagicRelBObj) throws Exception {
        DWLResponse response = null;
        DWLStatus status = theXMagicRelBObj.getStatus();
        if (status == null) {
            status = new DWLStatus();
            theXMagicRelBObj.setStatus(status);
        }

        String strPluggableID = null;

        try {
            // Pluggable Key Structure implementation
            strPluggableID = getSuppliedIdPKFromBObj(theXMagicRelBObj);

            if ((strPluggableID != null) && (strPluggableID.length() > 0)) {
                theXMagicRelBObj.getEObjXMagicRel().setXMagicRelpkId(FunctionUtils.getLongFromString(strPluggableID));
            } else {
                strPluggableID = null;
                theXMagicRelBObj.getEObjXMagicRel().setXMagicRelpkId(null);
            }
         Persistence theXMagicRelBObjPersistence = getBObjPersistenceFactory().createXMagicRelBObjPersistence(XMagicRelBObjQuery.XMAGIC_REL_ADD, theXMagicRelBObj);
         theXMagicRelBObjPersistence.persistAdd();

            response = new DWLResponse();
            response.setData(theXMagicRelBObj);
            response.setStatus(theXMagicRelBObj.getStatus());
    } catch (Exception ex) {
 				TCRMExceptionUtils.throwTCRMException(ex, new TCRMInsertException(ex.getMessage()), status,
                    DWLStatus.FATAL, DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_COMPONENT, TCRMErrorCode.INSERT_RECORD_ERROR,
                    DSEAAdditionsExtsErrorReasonCode.ADDXMAGICREL_FAILED, theXMagicRelBObj.getControl(), errHandler);
        }
        
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction updateXMagicRel.
     *
     * @param theBObj
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleUpdateXMagicRel
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.UPDATE_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.UPDATE_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.UPDATEXMAGICREL_FAILED
    )
     public DWLResponse updateXMagicRel(XMagicRelBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER updateXMagicRel(XMagicRelBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("updateXMagicRel", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction updateXMagicRel.";
      logger.finest("updateXMagicRel(XMagicRelBObj theBObj) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction updateXMagicRel.";
      logger.finest("updateXMagicRel(XMagicRelBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN updateXMagicRel(XMagicRelBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Updates the specified XMagicRel with new attribute values.
     *
     * @param theXMagicRelBObj
     *     The object that contains XMagicRel attribute values to be updated
     * @return
     *     DWLResponse containing a XMagicRelBObj of the updated object.
     * @exception Exception
     * @generated
     */
    public DWLResponse handleUpdateXMagicRel(XMagicRelBObj theXMagicRelBObj) throws Exception {

        DWLStatus status = theXMagicRelBObj.getStatus();

        if (status == null) {
            status = new DWLStatus();
            theXMagicRelBObj.setStatus(status);
        }
        
            // set lastupdatetxid with txnid from dwlcontrol
            theXMagicRelBObj.getEObjXMagicRel().setLastUpdateTxId(new Long(theXMagicRelBObj.getControl().getTxnId()));
         Persistence theXMagicRelBObjPersistence = getBObjPersistenceFactory().createXMagicRelBObjPersistence(XMagicRelBObjQuery.XMAGIC_REL_UPDATE, theXMagicRelBObj);
         theXMagicRelBObjPersistence.persistUpdate();

        DWLResponse response = createDWLResponse();
        response.setData(theXMagicRelBObj);
        response.setStatus(theXMagicRelBObj.getStatus());

        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXConsent.
     *
     * @param XConsentpkId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetXConsent
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETXCONSENT_FAILED,
       beforePreExecuteMethod = "beforePreExecuteGetXConsent"
    )
     public DWLResponse getXConsent(String XConsentpkId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getXConsent(String XConsentpkId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(XConsentpkId);
        DWLTransaction txObj = new  DWLTransactionInquiry("getXConsent", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction getXConsent.";
      logger.finest("getXConsent(String XConsentpkId,  DWLControl control) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction getXConsent.";
      logger.finest("getXConsent(String XConsentpkId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getXConsent(String XConsentpkId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets a XConsent from the database.
     * 
     * @generated
     */
    public DWLResponse handleGetXConsent(String XConsentpkId,  DWLControl control) throws Exception {
        DWLStatus status = new DWLStatus();
        DWLResponse response = createDWLResponse();
        
        BObjQuery bObjQuery = null;
           
        String asOfDate = (String) control.get(DWLControl.INQUIRE_AS_OF_DATE);

        // History data inquiry: if inquireAsOfDate field has value in request xml 
        if (StringUtils.isNonBlank(asOfDate)) {
            Timestamp tsAsOfDate = getPITHistoryDate(asOfDate, DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_COMPONENT,
                                                     DSEAAdditionsExtsErrorReasonCode.GETXCONSENT_INVALID_INQUIRE_AS_OF_DATE_FORMAT,
                                                     status, control);

            bObjQuery = getBObjQueryFactory().createXConsentBObjQuery(XConsentBObjQuery.XCONSENT_HISTORY_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(XConsentpkId));
            bObjQuery.setParameter(1, tsAsOfDate);
            bObjQuery.setParameter(2, tsAsOfDate);
        } else {
            bObjQuery = getBObjQueryFactory().createXConsentBObjQuery(XConsentBObjQuery.XCONSENT_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(XConsentpkId));
        }


        XConsentBObj o = (XConsentBObj) bObjQuery.getSingleResult();
        if( o == null ){
        	return null;
        } 
        postRetrieveXConsentBObj(o, "0", "ALL", control); 
          
        if (o.getStatus()==null) {
            o.setStatus(status);
        }
        response.addStatus(o.getStatus());
        response.setData(o);

      return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public void beforePreExecuteGetXConsent(DWLTransaction transaction) throws DWLBaseException{
        // Check if the parameters are valid.
        Object[] arguments = getInquiryArgumentType((DWLTransactionInquiry)transaction);
        String pk = null;
        if (arguments!=null && arguments.length>0) {
            pk = (String)arguments[0];
        }
        // Check if the parameter passed in exists.
        if ((pk == null) || (pk.trim().length() == 0)) {
            TCRMExceptionUtils.throwTCRMException(null, new TCRMReadException(), transaction.getStatus(), DWLStatus.FATAL,
                DSEAAdditionsExtsComponentID.XCONSENT_BOBJ,
                TCRMErrorCode.FIELD_VALIDATION_ERROR,
                DSEAAdditionsExtsErrorReasonCode.XCONSENT_XCONSENTPKID_NULL,
                transaction.getTxnControl(), errHandler);
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXConsentByContId.
     *
     * @param ContId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetXConsentByContId
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETXCONSENTBYCONTID_FAILED,
       beforePreExecuteMethod = "beforePreExecuteGetXConsentByContId"
    )
     public DWLResponse getXConsentByContId(String ContId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getXConsentByContId(String ContId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(ContId);
        DWLTransaction txObj = new  DWLTransactionInquiry("getXConsentByContId", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction getXConsentByContId.";
      logger.finest("getXConsentByContId(String ContId,  DWLControl control) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction getXConsentByContId.";
      logger.finest("getXConsentByContId(String ContId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getXConsentByContId(String ContId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets a XConsent from the database.
     * 
     * @generated
     */
    public DWLResponse handleGetXConsentByContId(String ContId,  DWLControl control) throws Exception {
        DWLStatus status = new DWLStatus();
        DWLResponse response = createDWLResponse();
        
        BObjQuery bObjQuery = null;
           
        String asOfDate = (String) control.get(DWLControl.INQUIRE_AS_OF_DATE);

        // History data inquiry: if inquireAsOfDate field has value in request xml 
        if (StringUtils.isNonBlank(asOfDate)) {
            Timestamp tsAsOfDate = getPITHistoryDate(asOfDate, DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_COMPONENT,
                                                     DSEAAdditionsExtsErrorReasonCode.GETXCONSENTBYCONTID_INVALID_INQUIRE_AS_OF_DATE_FORMAT,
                                                     status, control);

            bObjQuery = getBObjQueryFactory().createXConsentBObjQuery(XConsentBObjQuery.XCONSENT_BY_CONT_ID_HISTORY_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(ContId));
            bObjQuery.setParameter(1, tsAsOfDate);
            bObjQuery.setParameter(2, tsAsOfDate);
        } else {
            bObjQuery = getBObjQueryFactory().createXConsentBObjQuery(XConsentBObjQuery.XCONSENT_BY_CONT_ID_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(ContId));
        }

        boolean considerForPagination = PaginationUtils
                            .considerForPagintion(XConsentBObj.class.getName(), control);
        control.setConsiderForPagintionFlag(considerForPagination);

        // set returned object
        List<?> list = bObjQuery.getResults();

        if (list.size() == 0) {
            return null;
        }
    Vector<XConsentBObj> vector = new Vector<XConsentBObj>();
        for (Iterator<?> it = list.iterator(); it.hasNext();) {
            XConsentBObj o = (XConsentBObj) it.next();
            postRetrieveXConsentBObj(o, "0", "ALL", control); 
            vector.add(o);
          
            if (o.getStatus()==null) {
                o.setStatus(status);
            }
            response.addStatus(o.getStatus());
        }
        response.setData(vector);

      return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public void beforePreExecuteGetXConsentByContId(DWLTransaction transaction) throws DWLBaseException{
        // Check if the parameters are valid.
        Object[] arguments = getInquiryArgumentType((DWLTransactionInquiry)transaction);
    if (arguments!=null && arguments.length>0) {
            // MDM_TODO0: CDKWB0003I Add argument validation logic
    }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction addXConsent.
     *
     * @param theBObj
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleAddXConsent
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.ADD_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.INSERT_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.ADDXCONSENT_FAILED
    )
     public DWLResponse addXConsent(XConsentBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER addXConsent(XConsentBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("addXConsent", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction addXConsent.";
      logger.finest("addXConsent(XConsentBObj theBObj) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction addXConsent.";
      logger.finest("addXConsent(XConsentBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN addXConsent(XConsentBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Adds a XConsent to the database.
     *
     * @param theXConsentBObj
     *     The object that contains XConsent attribute values.
     * @return
     *     DWLResponse containing a XConsentBObj object.
     * @exception Exception
     * @generated
     */
    public DWLResponse handleAddXConsent(XConsentBObj theXConsentBObj) throws Exception {
        DWLResponse response = null;
        DWLStatus status = theXConsentBObj.getStatus();
        if (status == null) {
            status = new DWLStatus();
            theXConsentBObj.setStatus(status);
        }

        String strPluggableID = null;

        try {
            // Pluggable Key Structure implementation
            strPluggableID = getSuppliedIdPKFromBObj(theXConsentBObj);

            if ((strPluggableID != null) && (strPluggableID.length() > 0)) {
                theXConsentBObj.getEObjXConsent().setXConsentpkId(FunctionUtils.getLongFromString(strPluggableID));
            } else {
                strPluggableID = null;
                theXConsentBObj.getEObjXConsent().setXConsentpkId(null);
            }
         Persistence theXConsentBObjPersistence = getBObjPersistenceFactory().createXConsentBObjPersistence(XConsentBObjQuery.XCONSENT_ADD, theXConsentBObj);
         theXConsentBObjPersistence.persistAdd();

            response = new DWLResponse();
            response.setData(theXConsentBObj);
            response.setStatus(theXConsentBObj.getStatus());
    } catch (Exception ex) {
 				TCRMExceptionUtils.throwTCRMException(ex, new TCRMInsertException(ex.getMessage()), status,
                    DWLStatus.FATAL, DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_COMPONENT, TCRMErrorCode.INSERT_RECORD_ERROR,
                    DSEAAdditionsExtsErrorReasonCode.ADDXCONSENT_FAILED, theXConsentBObj.getControl(), errHandler);
        }
        
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction updateXConsent.
     *
     * @param theBObj
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleUpdateXConsent
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.UPDATE_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.UPDATE_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.UPDATEXCONSENT_FAILED
    )
     public DWLResponse updateXConsent(XConsentBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER updateXConsent(XConsentBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("updateXConsent", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction updateXConsent.";
      logger.finest("updateXConsent(XConsentBObj theBObj) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction updateXConsent.";
      logger.finest("updateXConsent(XConsentBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN updateXConsent(XConsentBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Updates the specified XConsent with new attribute values.
     *
     * @param theXConsentBObj
     *     The object that contains XConsent attribute values to be updated
     * @return
     *     DWLResponse containing a XConsentBObj of the updated object.
     * @exception Exception
     * @generated
     */
    public DWLResponse handleUpdateXConsent(XConsentBObj theXConsentBObj) throws Exception {

        DWLStatus status = theXConsentBObj.getStatus();

        if (status == null) {
            status = new DWLStatus();
            theXConsentBObj.setStatus(status);
        }
        
            // set lastupdatetxid with txnid from dwlcontrol
            theXConsentBObj.getEObjXConsent().setLastUpdateTxId(new Long(theXConsentBObj.getControl().getTxnId()));
         Persistence theXConsentBObjPersistence = getBObjPersistenceFactory().createXConsentBObjPersistence(XConsentBObjQuery.XCONSENT_UPDATE, theXConsentBObj);
         theXConsentBObjPersistence.persistUpdate();

        DWLResponse response = createDWLResponse();
        response.setData(theXConsentBObj);
        response.setStatus(theXConsentBObj.getStatus());

        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXContractRel.
     *
     * @param XContractRelpkId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetXContractRel
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETXCONTRACTREL_FAILED,
       beforePreExecuteMethod = "beforePreExecuteGetXContractRel"
    )
     public DWLResponse getXContractRel(String XContractRelpkId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getXContractRel(String XContractRelpkId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(XContractRelpkId);
        DWLTransaction txObj = new  DWLTransactionInquiry("getXContractRel", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction getXContractRel.";
      logger.finest("getXContractRel(String XContractRelpkId,  DWLControl control) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction getXContractRel.";
      logger.finest("getXContractRel(String XContractRelpkId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getXContractRel(String XContractRelpkId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets a XContractRel from the database.
     * 
     * @generated
     */
    public DWLResponse handleGetXContractRel(String XContractRelpkId,  DWLControl control) throws Exception {
        DWLStatus status = new DWLStatus();
        DWLResponse response = createDWLResponse();
        
        BObjQuery bObjQuery = null;
           
        String asOfDate = (String) control.get(DWLControl.INQUIRE_AS_OF_DATE);

        // History data inquiry: if inquireAsOfDate field has value in request xml 
        if (StringUtils.isNonBlank(asOfDate)) {
            Timestamp tsAsOfDate = getPITHistoryDate(asOfDate, DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_COMPONENT,
                                                     DSEAAdditionsExtsErrorReasonCode.GETXCONTRACTREL_INVALID_INQUIRE_AS_OF_DATE_FORMAT,
                                                     status, control);

            bObjQuery = getBObjQueryFactory().createXContractRelBObjQuery(XContractRelBObjQuery.XCONTRACT_REL_HISTORY_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(XContractRelpkId));
            bObjQuery.setParameter(1, tsAsOfDate);
            bObjQuery.setParameter(2, tsAsOfDate);
        } else {
            bObjQuery = getBObjQueryFactory().createXContractRelBObjQuery(XContractRelBObjQuery.XCONTRACT_REL_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(XContractRelpkId));
        }


        XContractRelBObj o = (XContractRelBObj) bObjQuery.getSingleResult();
        if( o == null ){
        	return null;
        } 
          
        if (o.getStatus()==null) {
            o.setStatus(status);
        }
        response.addStatus(o.getStatus());
        response.setData(o);

      return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public void beforePreExecuteGetXContractRel(DWLTransaction transaction) throws DWLBaseException{
        // Check if the parameters are valid.
        Object[] arguments = getInquiryArgumentType((DWLTransactionInquiry)transaction);
        String pk = null;
        if (arguments!=null && arguments.length>0) {
            pk = (String)arguments[0];
        }
        // Check if the parameter passed in exists.
        if ((pk == null) || (pk.trim().length() == 0)) {
            TCRMExceptionUtils.throwTCRMException(null, new TCRMReadException(), transaction.getStatus(), DWLStatus.FATAL,
                DSEAAdditionsExtsComponentID.XCONTRACT_REL_BOBJ,
                TCRMErrorCode.FIELD_VALIDATION_ERROR,
                DSEAAdditionsExtsErrorReasonCode.XCONTRACTREL_XCONTRACTRELPKID_NULL,
                transaction.getTxnControl(), errHandler);
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction addXContractRel.
     *
     * @param theBObj
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleAddXContractRel
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.ADD_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.INSERT_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.ADDXCONTRACTREL_FAILED
    )
     public DWLResponse addXContractRel(XContractRelBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER addXContractRel(XContractRelBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("addXContractRel", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction addXContractRel.";
      logger.finest("addXContractRel(XContractRelBObj theBObj) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction addXContractRel.";
      logger.finest("addXContractRel(XContractRelBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN addXContractRel(XContractRelBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Adds a XContractRel to the database.
     *
     * @param theXContractRelBObj
     *     The object that contains XContractRel attribute values.
     * @return
     *     DWLResponse containing a XContractRelBObj object.
     * @exception Exception
     * @generated
     */
    public DWLResponse handleAddXContractRel(XContractRelBObj theXContractRelBObj) throws Exception {
        DWLResponse response = null;
        DWLStatus status = theXContractRelBObj.getStatus();
        if (status == null) {
            status = new DWLStatus();
            theXContractRelBObj.setStatus(status);
        }

        String strPluggableID = null;

        try {
            // Pluggable Key Structure implementation
            strPluggableID = getSuppliedIdPKFromBObj(theXContractRelBObj);

            if ((strPluggableID != null) && (strPluggableID.length() > 0)) {
                theXContractRelBObj.getEObjXContractRel().setXContractRelpkId(FunctionUtils.getLongFromString(strPluggableID));
            } else {
                strPluggableID = null;
                theXContractRelBObj.getEObjXContractRel().setXContractRelpkId(null);
            }
         Persistence theXContractRelBObjPersistence = getBObjPersistenceFactory().createXContractRelBObjPersistence(XContractRelBObjQuery.XCONTRACT_REL_ADD, theXContractRelBObj);
         theXContractRelBObjPersistence.persistAdd();

            response = new DWLResponse();
            response.setData(theXContractRelBObj);
            response.setStatus(theXContractRelBObj.getStatus());
    } catch (Exception ex) {
 				TCRMExceptionUtils.throwTCRMException(ex, new TCRMInsertException(ex.getMessage()), status,
                    DWLStatus.FATAL, DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_COMPONENT, TCRMErrorCode.INSERT_RECORD_ERROR,
                    DSEAAdditionsExtsErrorReasonCode.ADDXCONTRACTREL_FAILED, theXContractRelBObj.getControl(), errHandler);
        }
        
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction updateXContractRel.
     *
     * @param theBObj
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleUpdateXContractRel
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.UPDATE_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.UPDATE_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.UPDATEXCONTRACTREL_FAILED
    )
     public DWLResponse updateXContractRel(XContractRelBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER updateXContractRel(XContractRelBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("updateXContractRel", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction updateXContractRel.";
      logger.finest("updateXContractRel(XContractRelBObj theBObj) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction updateXContractRel.";
      logger.finest("updateXContractRel(XContractRelBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN updateXContractRel(XContractRelBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Updates the specified XContractRel with new attribute values.
     *
     * @param theXContractRelBObj
     *     The object that contains XContractRel attribute values to be updated
     * @return
     *     DWLResponse containing a XContractRelBObj of the updated object.
     * @exception Exception
     * @generated
     */
    public DWLResponse handleUpdateXContractRel(XContractRelBObj theXContractRelBObj) throws Exception {

        DWLStatus status = theXContractRelBObj.getStatus();

        if (status == null) {
            status = new DWLStatus();
            theXContractRelBObj.setStatus(status);
        }
        
            // set lastupdatetxid with txnid from dwlcontrol
            theXContractRelBObj.getEObjXContractRel().setLastUpdateTxId(new Long(theXContractRelBObj.getControl().getTxnId()));
         Persistence theXContractRelBObjPersistence = getBObjPersistenceFactory().createXContractRelBObjPersistence(XContractRelBObjQuery.XCONTRACT_REL_UPDATE, theXContractRelBObj);
         theXContractRelBObjPersistence.persistUpdate();

        DWLResponse response = createDWLResponse();
        response.setData(theXContractRelBObj);
        response.setStatus(theXContractRelBObj.getStatus());

        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXCustomerRetailerJPN.
     *
     * @param XCustomerRetailerJPNpkId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetXCustomerRetailerJPN
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETXCUSTOMERRETAILERJPN_FAILED,
       beforePreExecuteMethod = "beforePreExecuteGetXCustomerRetailerJPN"
    )
     public DWLResponse getXCustomerRetailerJPN(String XCustomerRetailerJPNpkId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getXCustomerRetailerJPN(String XCustomerRetailerJPNpkId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(XCustomerRetailerJPNpkId);
        DWLTransaction txObj = new  DWLTransactionInquiry("getXCustomerRetailerJPN", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction getXCustomerRetailerJPN.";
      logger.finest("getXCustomerRetailerJPN(String XCustomerRetailerJPNpkId,  DWLControl control) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction getXCustomerRetailerJPN.";
      logger.finest("getXCustomerRetailerJPN(String XCustomerRetailerJPNpkId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getXCustomerRetailerJPN(String XCustomerRetailerJPNpkId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets a XCustomerRetailerJPN from the database.
     * 
     * @generated
     */
    public DWLResponse handleGetXCustomerRetailerJPN(String XCustomerRetailerJPNpkId,  DWLControl control) throws Exception {
        DWLStatus status = new DWLStatus();
        DWLResponse response = createDWLResponse();
        
        BObjQuery bObjQuery = null;
           
        String asOfDate = (String) control.get(DWLControl.INQUIRE_AS_OF_DATE);

        // History data inquiry: if inquireAsOfDate field has value in request xml 
        if (StringUtils.isNonBlank(asOfDate)) {
            Timestamp tsAsOfDate = getPITHistoryDate(asOfDate, DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_COMPONENT,
                                                     DSEAAdditionsExtsErrorReasonCode.GETXCUSTOMERRETAILERJPN_INVALID_INQUIRE_AS_OF_DATE_FORMAT,
                                                     status, control);

            bObjQuery = getBObjQueryFactory().createXCustomerRetailerJPNBObjQuery(XCustomerRetailerJPNBObjQuery.XCUSTOMER_RETAILER_JPN_HISTORY_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(XCustomerRetailerJPNpkId));
            bObjQuery.setParameter(1, tsAsOfDate);
            bObjQuery.setParameter(2, tsAsOfDate);
        } else {
            bObjQuery = getBObjQueryFactory().createXCustomerRetailerJPNBObjQuery(XCustomerRetailerJPNBObjQuery.XCUSTOMER_RETAILER_JPN_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(XCustomerRetailerJPNpkId));
        }


        XCustomerRetailerJPNBObj o = (XCustomerRetailerJPNBObj) bObjQuery.getSingleResult();
        if( o == null ){
        	return null;
        } 
        postRetrieveXCustomerRetailerJPNBObj(o, "0", "ALL", control); 
          
        if (o.getStatus()==null) {
            o.setStatus(status);
        }
        response.addStatus(o.getStatus());
        response.setData(o);

      return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public void beforePreExecuteGetXCustomerRetailerJPN(DWLTransaction transaction) throws DWLBaseException{
        // Check if the parameters are valid.
        Object[] arguments = getInquiryArgumentType((DWLTransactionInquiry)transaction);
        String pk = null;
        if (arguments!=null && arguments.length>0) {
            pk = (String)arguments[0];
        }
        // Check if the parameter passed in exists.
        if ((pk == null) || (pk.trim().length() == 0)) {
            TCRMExceptionUtils.throwTCRMException(null, new TCRMReadException(), transaction.getStatus(), DWLStatus.FATAL,
                DSEAAdditionsExtsComponentID.XCUSTOMER_RETAILER_JPNBOBJ,
                TCRMErrorCode.FIELD_VALIDATION_ERROR,
                DSEAAdditionsExtsErrorReasonCode.XCUSTOMERRETAILERJPN_XCUSTOMERRETAILERJPNPKID_NULL,
                transaction.getTxnControl(), errHandler);
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getAllXCustomerRetailerJPNByPartyId.
     *
     * @param ContId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetAllXCustomerRetailerJPNByPartyId
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETALLXCUSTOMERRETAILERJPNBYPARTYID_FAILED,
       beforePreExecuteMethod = "beforePreExecuteGetAllXCustomerRetailerJPNByPartyId"
    )
     public DWLResponse getAllXCustomerRetailerJPNByPartyId(String ContId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getAllXCustomerRetailerJPNByPartyId(String ContId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(ContId);
        DWLTransaction txObj = new  DWLTransactionInquiry("getAllXCustomerRetailerJPNByPartyId", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction getAllXCustomerRetailerJPNByPartyId.";
      logger.finest("getAllXCustomerRetailerJPNByPartyId(String ContId,  DWLControl control) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction getAllXCustomerRetailerJPNByPartyId.";
      logger.finest("getAllXCustomerRetailerJPNByPartyId(String ContId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getAllXCustomerRetailerJPNByPartyId(String ContId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets a XCustomerRetailerJPN from the database.
     * 
     * @generated
     */
    public DWLResponse handleGetAllXCustomerRetailerJPNByPartyId(String ContId,  DWLControl control) throws Exception {
        DWLStatus status = new DWLStatus();
        DWLResponse response = createDWLResponse();
        
        BObjQuery bObjQuery = null;
           
        String asOfDate = (String) control.get(DWLControl.INQUIRE_AS_OF_DATE);

        // History data inquiry: if inquireAsOfDate field has value in request xml 
        if (StringUtils.isNonBlank(asOfDate)) {
            Timestamp tsAsOfDate = getPITHistoryDate(asOfDate, DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_COMPONENT,
                                                     DSEAAdditionsExtsErrorReasonCode.GETALLXCUSTOMERRETAILERJPNBYPARTYID_INVALID_INQUIRE_AS_OF_DATE_FORMAT,
                                                     status, control);

            bObjQuery = getBObjQueryFactory().createXCustomerRetailerJPNBObjQuery(XCustomerRetailerJPNBObjQuery.ALL_XCUSTOMER_RETAILER_JPNBY_PARTY_ID_HISTORY_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(ContId));
            bObjQuery.setParameter(1, tsAsOfDate);
            bObjQuery.setParameter(2, tsAsOfDate);
        } else {
            bObjQuery = getBObjQueryFactory().createXCustomerRetailerJPNBObjQuery(XCustomerRetailerJPNBObjQuery.ALL_XCUSTOMER_RETAILER_JPNBY_PARTY_ID_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(ContId));
        }

        boolean considerForPagination = PaginationUtils
                            .considerForPagintion(XCustomerRetailerJPNBObj.class.getName(), control);
        control.setConsiderForPagintionFlag(considerForPagination);

        // set returned object
        List<?> list = bObjQuery.getResults();

        if (list.size() == 0) {
            return null;
        }
    Vector<XCustomerRetailerJPNBObj> vector = new Vector<XCustomerRetailerJPNBObj>();
        for (Iterator<?> it = list.iterator(); it.hasNext();) {
            XCustomerRetailerJPNBObj o = (XCustomerRetailerJPNBObj) it.next();
            postRetrieveXCustomerRetailerJPNBObj(o, "0", "ALL", control); 
            vector.add(o);
          
            if (o.getStatus()==null) {
                o.setStatus(status);
            }
            response.addStatus(o.getStatus());
        }
        response.setData(vector);

      return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public void beforePreExecuteGetAllXCustomerRetailerJPNByPartyId(DWLTransaction transaction) throws DWLBaseException{
        // Check if the parameters are valid.
        Object[] arguments = getInquiryArgumentType((DWLTransactionInquiry)transaction);
    if (arguments!=null && arguments.length>0) {
            // MDM_TODO0: CDKWB0003I Add argument validation logic
    }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction addXCustomerRetailerJPN.
     *
     * @param theBObj
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleAddXCustomerRetailerJPN
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.ADD_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.INSERT_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.ADDXCUSTOMERRETAILERJPN_FAILED
    )
     public DWLResponse addXCustomerRetailerJPN(XCustomerRetailerJPNBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER addXCustomerRetailerJPN(XCustomerRetailerJPNBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("addXCustomerRetailerJPN", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction addXCustomerRetailerJPN.";
      logger.finest("addXCustomerRetailerJPN(XCustomerRetailerJPNBObj theBObj) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction addXCustomerRetailerJPN.";
      logger.finest("addXCustomerRetailerJPN(XCustomerRetailerJPNBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN addXCustomerRetailerJPN(XCustomerRetailerJPNBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Adds a XCustomerRetailerJPN to the database.
     *
     * @param theXCustomerRetailerJPNBObj
     *     The object that contains XCustomerRetailerJPN attribute values.
     * @return
     *     DWLResponse containing a XCustomerRetailerJPNBObj object.
     * @exception Exception
     * @generated
     */
    public DWLResponse handleAddXCustomerRetailerJPN(XCustomerRetailerJPNBObj theXCustomerRetailerJPNBObj) throws Exception {
        DWLResponse response = null;
        DWLStatus status = theXCustomerRetailerJPNBObj.getStatus();
        if (status == null) {
            status = new DWLStatus();
            theXCustomerRetailerJPNBObj.setStatus(status);
        }
        XRetailerBObj childXRetailerBObj = theXCustomerRetailerJPNBObj.getXRetailerBObj();
        if( childXRetailerBObj != null ){
        	String containedPk = null;
            //addXRetailer(childXRetailerBObj);  // Commented For JPN Changes to Restrict Add for XRetailer
            containedPk = childXRetailerBObj.getRetailerpkId ();
      theXCustomerRetailerJPNBObj.setRetailerId( containedPk );
   	     	theXCustomerRetailerJPNBObj.setXRetailerBObj(childXRetailerBObj);
    }

        String strPluggableID = null;

        try {
            // Pluggable Key Structure implementation
            strPluggableID = getSuppliedIdPKFromBObj(theXCustomerRetailerJPNBObj);

            if ((strPluggableID != null) && (strPluggableID.length() > 0)) {
                theXCustomerRetailerJPNBObj.getEObjXCustomerRetailerJPN().setXCustomerRetailerJPNpkId(FunctionUtils.getLongFromString(strPluggableID));
            } else {
                strPluggableID = null;
                theXCustomerRetailerJPNBObj.getEObjXCustomerRetailerJPN().setXCustomerRetailerJPNpkId(null);
            }
         Persistence theXCustomerRetailerJPNBObjPersistence = getBObjPersistenceFactory().createXCustomerRetailerJPNBObjPersistence(XCustomerRetailerJPNBObjQuery.XCUSTOMER_RETAILER_JPN_ADD, theXCustomerRetailerJPNBObj);
         theXCustomerRetailerJPNBObjPersistence.persistAdd();

            response = new DWLResponse();
            response.setData(theXCustomerRetailerJPNBObj);
            response.setStatus(theXCustomerRetailerJPNBObj.getStatus());
    } catch (Exception ex) {
 				TCRMExceptionUtils.throwTCRMException(ex, new TCRMInsertException(ex.getMessage()), status,
                    DWLStatus.FATAL, DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_COMPONENT, TCRMErrorCode.INSERT_RECORD_ERROR,
                    DSEAAdditionsExtsErrorReasonCode.ADDXCUSTOMERRETAILERJPN_FAILED, theXCustomerRetailerJPNBObj.getControl(), errHandler);
        }
        
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction updateXCustomerRetailerJPN.
     *
     * @param theBObj
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleUpdateXCustomerRetailerJPN
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.UPDATE_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.UPDATE_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.UPDATEXCUSTOMERRETAILERJPN_FAILED
    , manuallyHandleRedundantUpdateCheck="true"
    )
     public DWLResponse updateXCustomerRetailerJPN(XCustomerRetailerJPNBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER updateXCustomerRetailerJPN(XCustomerRetailerJPNBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("updateXCustomerRetailerJPN", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction updateXCustomerRetailerJPN.";
      logger.finest("updateXCustomerRetailerJPN(XCustomerRetailerJPNBObj theBObj) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction updateXCustomerRetailerJPN.";
      logger.finest("updateXCustomerRetailerJPN(XCustomerRetailerJPNBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN updateXCustomerRetailerJPN(XCustomerRetailerJPNBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Updates the specified XCustomerRetailerJPN with new attribute values.
     *
     * @param theXCustomerRetailerJPNBObj
     *     The object that contains XCustomerRetailerJPN attribute values to be
     *     updated
     * @return
     *     DWLResponse containing a XCustomerRetailerJPNBObj of the updated
     *     object.
     * @exception Exception
     * @generated
     */
    public DWLResponse handleUpdateXCustomerRetailerJPN(XCustomerRetailerJPNBObj theXCustomerRetailerJPNBObj) throws Exception {

        DWLStatus status = theXCustomerRetailerJPNBObj.getStatus();

        if (status == null) {
            status = new DWLStatus();
            theXCustomerRetailerJPNBObj.setStatus(status);
        }
        
    if( !theXCustomerRetailerJPNBObj.isRedundantUpdate() ){
            // set lastupdatetxid with txnid from dwlcontrol
            theXCustomerRetailerJPNBObj.getEObjXCustomerRetailerJPN().setLastUpdateTxId(new Long(theXCustomerRetailerJPNBObj.getControl().getTxnId()));
            Persistence theXCustomerRetailerJPNBObjPersistence = getBObjPersistenceFactory().createXCustomerRetailerJPNBObjPersistence(XCustomerRetailerJPNBObjQuery.XCUSTOMER_RETAILER_JPN_UPDATE, theXCustomerRetailerJPNBObj);
            theXCustomerRetailerJPNBObjPersistence.persistUpdate();
        }

        DWLResponse response = createDWLResponse();
        response.setData(theXCustomerRetailerJPNBObj);
        response.setStatus(theXCustomerRetailerJPNBObj.getStatus());

        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXVehicleJPN.
     *
     * @param XVehicleJPNpkId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetXVehicleJPN
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETXVEHICLEJPN_FAILED,
       beforePreExecuteMethod = "beforePreExecuteGetXVehicleJPN"
    )
     public DWLResponse getXVehicleJPN(String XVehicleJPNpkId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getXVehicleJPN(String XVehicleJPNpkId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(XVehicleJPNpkId);
        DWLTransaction txObj = new  DWLTransactionInquiry("getXVehicleJPN", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction getXVehicleJPN.";
      logger.finest("getXVehicleJPN(String XVehicleJPNpkId,  DWLControl control) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction getXVehicleJPN.";
      logger.finest("getXVehicleJPN(String XVehicleJPNpkId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getXVehicleJPN(String XVehicleJPNpkId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets a XVehicleJPN from the database.
     * 
     * @generated
     */
    public DWLResponse handleGetXVehicleJPN(String XVehicleJPNpkId,  DWLControl control) throws Exception {
        DWLStatus status = new DWLStatus();
        DWLResponse response = createDWLResponse();
        
        BObjQuery bObjQuery = null;
           
        String asOfDate = (String) control.get(DWLControl.INQUIRE_AS_OF_DATE);

        // History data inquiry: if inquireAsOfDate field has value in request xml 
        if (StringUtils.isNonBlank(asOfDate)) {
            Timestamp tsAsOfDate = getPITHistoryDate(asOfDate, DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_COMPONENT,
                                                     DSEAAdditionsExtsErrorReasonCode.GETXVEHICLEJPN_INVALID_INQUIRE_AS_OF_DATE_FORMAT,
                                                     status, control);

            bObjQuery = getBObjQueryFactory().createXVehicleJPNBObjQuery(XVehicleJPNBObjQuery.XVEHICLE_JPN_HISTORY_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(XVehicleJPNpkId));
            bObjQuery.setParameter(1, tsAsOfDate);
            bObjQuery.setParameter(2, tsAsOfDate);
        } else {
            bObjQuery = getBObjQueryFactory().createXVehicleJPNBObjQuery(XVehicleJPNBObjQuery.XVEHICLE_JPN_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(XVehicleJPNpkId));
        }


        XVehicleJPNBObj o = (XVehicleJPNBObj) bObjQuery.getSingleResult();
        if( o == null ){
        	return null;
        } 
        postRetrieveXVehicleJPNBObj(o, "0", "ALL", control); 
          
        if (o.getStatus()==null) {
            o.setStatus(status);
        }
        response.addStatus(o.getStatus());
        response.setData(o);

      return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public void beforePreExecuteGetXVehicleJPN(DWLTransaction transaction) throws DWLBaseException{
        // Check if the parameters are valid.
        Object[] arguments = getInquiryArgumentType((DWLTransactionInquiry)transaction);
        String pk = null;
        if (arguments!=null && arguments.length>0) {
            pk = (String)arguments[0];
        }
        // Check if the parameter passed in exists.
        if ((pk == null) || (pk.trim().length() == 0)) {
            TCRMExceptionUtils.throwTCRMException(null, new TCRMReadException(), transaction.getStatus(), DWLStatus.FATAL,
                DSEAAdditionsExtsComponentID.XVEHICLE_JPNBOBJ,
                TCRMErrorCode.FIELD_VALIDATION_ERROR,
                DSEAAdditionsExtsErrorReasonCode.XVEHICLEJPN_XVEHICLEJPNPKID_NULL,
                transaction.getTxnControl(), errHandler);
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXVehicleJPNByGlobalVIN.
     *
     * @param GlobalVIN
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetXVehicleJPNByGlobalVIN
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETXVEHICLEJPNBYGLOBALVIN_FAILED,
       beforePreExecuteMethod = "beforePreExecuteGetXVehicleJPNByGlobalVIN"
    )
     public DWLResponse getXVehicleJPNByGlobalVIN(String GlobalVIN,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getXVehicleJPNByGlobalVIN(String GlobalVIN,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(GlobalVIN);
        DWLTransaction txObj = new  DWLTransactionInquiry("getXVehicleJPNByGlobalVIN", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction getXVehicleJPNByGlobalVIN.";
      logger.finest("getXVehicleJPNByGlobalVIN(String GlobalVIN,  DWLControl control) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction getXVehicleJPNByGlobalVIN.";
      logger.finest("getXVehicleJPNByGlobalVIN(String GlobalVIN,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getXVehicleJPNByGlobalVIN(String GlobalVIN,  DWLControl control) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets a XVehicleJPN from the database.
     * 
     * @generated
     */
    public DWLResponse handleGetXVehicleJPNByGlobalVIN(String GlobalVIN,  DWLControl control) throws Exception {
        DWLStatus status = new DWLStatus();
        DWLResponse response = createDWLResponse();
        
        BObjQuery bObjQuery = null;
           
        String asOfDate = (String) control.get(DWLControl.INQUIRE_AS_OF_DATE);

        // History data inquiry: if inquireAsOfDate field has value in request xml 
        if (StringUtils.isNonBlank(asOfDate)) {
            Timestamp tsAsOfDate = getPITHistoryDate(asOfDate, DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_COMPONENT,
                                                     DSEAAdditionsExtsErrorReasonCode.GETXVEHICLEJPNBYGLOBALVIN_INVALID_INQUIRE_AS_OF_DATE_FORMAT,
                                                     status, control);

            bObjQuery = getBObjQueryFactory().createXVehicleJPNBObjQuery(XVehicleJPNBObjQuery.XVEHICLE_JPNBY_GLOBAL_VIN_HISTORY_QUERY,
                		control);
            bObjQuery.setParameter(0, GlobalVIN);
            bObjQuery.setParameter(1, tsAsOfDate);
            bObjQuery.setParameter(2, tsAsOfDate);
        } else {
            bObjQuery = getBObjQueryFactory().createXVehicleJPNBObjQuery(XVehicleJPNBObjQuery.XVEHICLE_JPNBY_GLOBAL_VIN_QUERY,
                		control);
            bObjQuery.setParameter(0, GlobalVIN);
        }


        XVehicleJPNBObj o = (XVehicleJPNBObj) bObjQuery.getSingleResult();
        if( o == null ){
        	return null;
        } 
        postRetrieveXVehicleJPNBObj(o, "0", "ALL", control); 
          
        if (o.getStatus()==null) {
            o.setStatus(status);
        }
        response.addStatus(o.getStatus());
        response.setData(o);

      return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public void beforePreExecuteGetXVehicleJPNByGlobalVIN(DWLTransaction transaction) throws DWLBaseException{
        // Check if the parameters are valid.
        Object[] arguments = getInquiryArgumentType((DWLTransactionInquiry)transaction);
    if (arguments!=null && arguments.length>0) {
            // MDM_TODO0: CDKWB0003I Add argument validation logic
    }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction addXVehicleJPN.
     *
     * @param theBObj
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleAddXVehicleJPN
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.ADD_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.INSERT_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.ADDXVEHICLEJPN_FAILED
    )
     public DWLResponse addXVehicleJPN(XVehicleJPNBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER addXVehicleJPN(XVehicleJPNBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("addXVehicleJPN", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction addXVehicleJPN.";
      logger.finest("addXVehicleJPN(XVehicleJPNBObj theBObj) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction addXVehicleJPN.";
      logger.finest("addXVehicleJPN(XVehicleJPNBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN addXVehicleJPN(XVehicleJPNBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Adds a XVehicleJPN to the database.
     *
     * @param theXVehicleJPNBObj
     *     The object that contains XVehicleJPN attribute values.
     * @return
     *     DWLResponse containing a XVehicleJPNBObj object.
     * @exception Exception
     * @generated
     */
    public DWLResponse handleAddXVehicleJPN(XVehicleJPNBObj theXVehicleJPNBObj) throws Exception {
        DWLResponse response = null;
        DWLStatus status = theXVehicleJPNBObj.getStatus();
        if (status == null) {
            status = new DWLStatus();
            theXVehicleJPNBObj.setStatus(status);
        }

        String strPluggableID = null;

        try {
            // Pluggable Key Structure implementation
            strPluggableID = getSuppliedIdPKFromBObj(theXVehicleJPNBObj);

            if ((strPluggableID != null) && (strPluggableID.length() > 0)) {
                theXVehicleJPNBObj.getEObjXVehicleJPN().setXVehicleJPNpkId(FunctionUtils.getLongFromString(strPluggableID));
            } else {
                strPluggableID = null;
                theXVehicleJPNBObj.getEObjXVehicleJPN().setXVehicleJPNpkId(null);
            }
         Persistence theXVehicleJPNBObjPersistence = getBObjPersistenceFactory().createXVehicleJPNBObjPersistence(XVehicleJPNBObjQuery.XVEHICLE_JPN_ADD, theXVehicleJPNBObj);
         theXVehicleJPNBObjPersistence.persistAdd();

            response = new DWLResponse();
            response.setData(theXVehicleJPNBObj);
            response.setStatus(theXVehicleJPNBObj.getStatus());
    } catch (Exception ex) {
 				TCRMExceptionUtils.throwTCRMException(ex, new TCRMInsertException(ex.getMessage()), status,
                    DWLStatus.FATAL, DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_COMPONENT, TCRMErrorCode.INSERT_RECORD_ERROR,
                    DSEAAdditionsExtsErrorReasonCode.ADDXVEHICLEJPN_FAILED, theXVehicleJPNBObj.getControl(), errHandler);
        }
        
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction updateXVehicleJPN.
     *
     * @param theBObj
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleUpdateXVehicleJPN
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.UPDATE_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.UPDATE_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.UPDATEXVEHICLEJPN_FAILED
    )
     public DWLResponse updateXVehicleJPN(XVehicleJPNBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER updateXVehicleJPN(XVehicleJPNBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("updateXVehicleJPN", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction updateXVehicleJPN.";
      logger.finest("updateXVehicleJPN(XVehicleJPNBObj theBObj) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction updateXVehicleJPN.";
      logger.finest("updateXVehicleJPN(XVehicleJPNBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN updateXVehicleJPN(XVehicleJPNBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Updates the specified XVehicleJPN with new attribute values.
     *
     * @param theXVehicleJPNBObj
     *     The object that contains XVehicleJPN attribute values to be updated
     * @return
     *     DWLResponse containing a XVehicleJPNBObj of the updated object.
     * @exception Exception
     * @generated
     */
    public DWLResponse handleUpdateXVehicleJPN(XVehicleJPNBObj theXVehicleJPNBObj) throws Exception {

        DWLStatus status = theXVehicleJPNBObj.getStatus();

        if (status == null) {
            status = new DWLStatus();
            theXVehicleJPNBObj.setStatus(status);
        }
        
            // set lastupdatetxid with txnid from dwlcontrol
            theXVehicleJPNBObj.getEObjXVehicleJPN().setLastUpdateTxId(new Long(theXVehicleJPNBObj.getControl().getTxnId()));
         Persistence theXVehicleJPNBObjPersistence = getBObjPersistenceFactory().createXVehicleJPNBObjPersistence(XVehicleJPNBObjQuery.XVEHICLE_JPN_UPDATE, theXVehicleJPNBObj);
         theXVehicleJPNBObjPersistence.persistUpdate();

        DWLResponse response = createDWLResponse();
        response.setData(theXVehicleJPNBObj);
        response.setStatus(theXVehicleJPNBObj.getStatus());

        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXCustomerVehicleJPN.
     *
     * @param XCustomerVehicleJPNpkId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetXCustomerVehicleJPN
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETXCUSTOMERVEHICLEJPN_FAILED,
       beforePreExecuteMethod = "beforePreExecuteGetXCustomerVehicleJPN"
    )
     public DWLResponse getXCustomerVehicleJPN(String XCustomerVehicleJPNpkId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getXCustomerVehicleJPN(String XCustomerVehicleJPNpkId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(XCustomerVehicleJPNpkId);
        DWLTransaction txObj = new  DWLTransactionInquiry("getXCustomerVehicleJPN", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction getXCustomerVehicleJPN.";
      logger.finest("getXCustomerVehicleJPN(String XCustomerVehicleJPNpkId,  DWLControl control) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction getXCustomerVehicleJPN.";
      logger.finest("getXCustomerVehicleJPN(String XCustomerVehicleJPNpkId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getXCustomerVehicleJPN(String XCustomerVehicleJPNpkId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets a XCustomerVehicleJPN from the database.
     * 
     * @generated
     */
    public DWLResponse handleGetXCustomerVehicleJPN(String XCustomerVehicleJPNpkId,  DWLControl control) throws Exception {
        DWLStatus status = new DWLStatus();
        DWLResponse response = createDWLResponse();
        
        BObjQuery bObjQuery = null;
           
        String asOfDate = (String) control.get(DWLControl.INQUIRE_AS_OF_DATE);

        // History data inquiry: if inquireAsOfDate field has value in request xml 
        if (StringUtils.isNonBlank(asOfDate)) {
            Timestamp tsAsOfDate = getPITHistoryDate(asOfDate, DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_COMPONENT,
                                                     DSEAAdditionsExtsErrorReasonCode.GETXCUSTOMERVEHICLEJPN_INVALID_INQUIRE_AS_OF_DATE_FORMAT,
                                                     status, control);

            bObjQuery = getBObjQueryFactory().createXCustomerVehicleJPNBObjQuery(XCustomerVehicleJPNBObjQuery.XCUSTOMER_VEHICLE_JPN_HISTORY_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(XCustomerVehicleJPNpkId));
            bObjQuery.setParameter(1, tsAsOfDate);
            bObjQuery.setParameter(2, tsAsOfDate);
        } else {
            bObjQuery = getBObjQueryFactory().createXCustomerVehicleJPNBObjQuery(XCustomerVehicleJPNBObjQuery.XCUSTOMER_VEHICLE_JPN_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(XCustomerVehicleJPNpkId));
        }


        XCustomerVehicleJPNBObj o = (XCustomerVehicleJPNBObj) bObjQuery.getSingleResult();
        if( o == null ){
        	return null;
        } 
        postRetrieveXCustomerVehicleJPNBObj(o, "0", "ALL", control); 
          
        if (o.getStatus()==null) {
            o.setStatus(status);
        }
        response.addStatus(o.getStatus());
        response.setData(o);

      return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public void beforePreExecuteGetXCustomerVehicleJPN(DWLTransaction transaction) throws DWLBaseException{
        // Check if the parameters are valid.
        Object[] arguments = getInquiryArgumentType((DWLTransactionInquiry)transaction);
        String pk = null;
        if (arguments!=null && arguments.length>0) {
            pk = (String)arguments[0];
        }
        // Check if the parameter passed in exists.
        if ((pk == null) || (pk.trim().length() == 0)) {
            TCRMExceptionUtils.throwTCRMException(null, new TCRMReadException(), transaction.getStatus(), DWLStatus.FATAL,
                DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_JPNBOBJ,
                TCRMErrorCode.FIELD_VALIDATION_ERROR,
                DSEAAdditionsExtsErrorReasonCode.XCUSTOMERVEHICLEJPN_XCUSTOMERVEHICLEJPNPKID_NULL,
                transaction.getTxnControl(), errHandler);
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getAllXCustomerVehicleJPNByPartyId.
     *
     * @param ContId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetAllXCustomerVehicleJPNByPartyId
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETALLXCUSTOMERVEHICLEJPNBYPARTYID_FAILED,
       beforePreExecuteMethod = "beforePreExecuteGetAllXCustomerVehicleJPNByPartyId"
    )
     public DWLResponse getAllXCustomerVehicleJPNByPartyId(String ContId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getAllXCustomerVehicleJPNByPartyId(String ContId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(ContId);
        DWLTransaction txObj = new  DWLTransactionInquiry("getAllXCustomerVehicleJPNByPartyId", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction getAllXCustomerVehicleJPNByPartyId.";
      logger.finest("getAllXCustomerVehicleJPNByPartyId(String ContId,  DWLControl control) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction getAllXCustomerVehicleJPNByPartyId.";
      logger.finest("getAllXCustomerVehicleJPNByPartyId(String ContId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getAllXCustomerVehicleJPNByPartyId(String ContId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets a XCustomerVehicleJPN from the database.
     * 
     * @generated
     */
    public DWLResponse handleGetAllXCustomerVehicleJPNByPartyId(String ContId,  DWLControl control) throws Exception {
        DWLStatus status = new DWLStatus();
        DWLResponse response = createDWLResponse();
        
        BObjQuery bObjQuery = null;
           
        String asOfDate = (String) control.get(DWLControl.INQUIRE_AS_OF_DATE);

        // History data inquiry: if inquireAsOfDate field has value in request xml 
        if (StringUtils.isNonBlank(asOfDate)) {
            Timestamp tsAsOfDate = getPITHistoryDate(asOfDate, DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_COMPONENT,
                                                     DSEAAdditionsExtsErrorReasonCode.GETALLXCUSTOMERVEHICLEJPNBYPARTYID_INVALID_INQUIRE_AS_OF_DATE_FORMAT,
                                                     status, control);

            bObjQuery = getBObjQueryFactory().createXCustomerVehicleJPNBObjQuery(XCustomerVehicleJPNBObjQuery.ALL_XCUSTOMER_VEHICLE_JPNBY_PARTY_ID_HISTORY_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(ContId));
            bObjQuery.setParameter(1, tsAsOfDate);
            bObjQuery.setParameter(2, tsAsOfDate);
        } else {
            bObjQuery = getBObjQueryFactory().createXCustomerVehicleJPNBObjQuery(XCustomerVehicleJPNBObjQuery.ALL_XCUSTOMER_VEHICLE_JPNBY_PARTY_ID_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(ContId));
        }

        boolean considerForPagination = PaginationUtils
                            .considerForPagintion(XCustomerVehicleJPNBObj.class.getName(), control);
        control.setConsiderForPagintionFlag(considerForPagination);

        // set returned object
        List<?> list = bObjQuery.getResults();

        if (list.size() == 0) {
            return null;
        }
    Vector<XCustomerVehicleJPNBObj> vector = new Vector<XCustomerVehicleJPNBObj>();
        for (Iterator<?> it = list.iterator(); it.hasNext();) {
            XCustomerVehicleJPNBObj o = (XCustomerVehicleJPNBObj) it.next();
            postRetrieveXCustomerVehicleJPNBObj(o, "0", "ALL", control); 
            vector.add(o);
          
            if (o.getStatus()==null) {
                o.setStatus(status);
            }
            response.addStatus(o.getStatus());
        }
        response.setData(vector);

      return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public void beforePreExecuteGetAllXCustomerVehicleJPNByPartyId(DWLTransaction transaction) throws DWLBaseException{
        // Check if the parameters are valid.
        Object[] arguments = getInquiryArgumentType((DWLTransactionInquiry)transaction);
    if (arguments!=null && arguments.length>0) {
            // MDM_TODO0: CDKWB0003I Add argument validation logic
    }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getAllCVRByVehicleId.
     *
     * @param VehicleId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetAllCVRByVehicleId
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETALLCVRBYVEHICLEID_FAILED,
       beforePreExecuteMethod = "beforePreExecuteGetAllCVRByVehicleId"
    )
     public DWLResponse getAllCVRByVehicleId(String VehicleId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getAllCVRByVehicleId(String VehicleId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(VehicleId);
        DWLTransaction txObj = new  DWLTransactionInquiry("getAllCVRByVehicleId", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction getAllCVRByVehicleId.";
      logger.finest("getAllCVRByVehicleId(String VehicleId,  DWLControl control) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction getAllCVRByVehicleId.";
      logger.finest("getAllCVRByVehicleId(String VehicleId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getAllCVRByVehicleId(String VehicleId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets a XCustomerVehicleJPN from the database.
     * 
     * @generated
     */
    public DWLResponse handleGetAllCVRByVehicleId(String VehicleId,  DWLControl control) throws Exception {
        DWLStatus status = new DWLStatus();
        DWLResponse response = createDWLResponse();
        
        BObjQuery bObjQuery = null;
           
        String asOfDate = (String) control.get(DWLControl.INQUIRE_AS_OF_DATE);

        // History data inquiry: if inquireAsOfDate field has value in request xml 
        if (StringUtils.isNonBlank(asOfDate)) {
            Timestamp tsAsOfDate = getPITHistoryDate(asOfDate, DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_COMPONENT,
                                                     DSEAAdditionsExtsErrorReasonCode.GETALLCVRBYVEHICLEID_INVALID_INQUIRE_AS_OF_DATE_FORMAT,
                                                     status, control);

            bObjQuery = getBObjQueryFactory().createXCustomerVehicleJPNBObjQuery(XCustomerVehicleJPNBObjQuery.ALL_CVRBY_VEHICLE_ID_HISTORY_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(VehicleId));
            bObjQuery.setParameter(1, tsAsOfDate);
            bObjQuery.setParameter(2, tsAsOfDate);
        } else {
            bObjQuery = getBObjQueryFactory().createXCustomerVehicleJPNBObjQuery(XCustomerVehicleJPNBObjQuery.ALL_CVRBY_VEHICLE_ID_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(VehicleId));
        }

        boolean considerForPagination = PaginationUtils
                            .considerForPagintion(XCustomerVehicleJPNBObj.class.getName(), control);
        control.setConsiderForPagintionFlag(considerForPagination);

        // set returned object
        List<?> list = bObjQuery.getResults();

        if (list.size() == 0) {
            return null;
        }
    Vector<XCustomerVehicleJPNBObj> vector = new Vector<XCustomerVehicleJPNBObj>();
        for (Iterator<?> it = list.iterator(); it.hasNext();) {
            XCustomerVehicleJPNBObj o = (XCustomerVehicleJPNBObj) it.next();
            postRetrieveXCustomerVehicleJPNBObj(o, "0", "ALL", control); 
            vector.add(o);
          
            if (o.getStatus()==null) {
                o.setStatus(status);
            }
            response.addStatus(o.getStatus());
        }
        response.setData(vector);

      return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public void beforePreExecuteGetAllCVRByVehicleId(DWLTransaction transaction) throws DWLBaseException{
        // Check if the parameters are valid.
        Object[] arguments = getInquiryArgumentType((DWLTransactionInquiry)transaction);
    if (arguments!=null && arguments.length>0) {
            // MDM_TODO0: CDKWB0003I Add argument validation logic
    }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction addXCustomerVehicleJPN.
     *
     * @param theBObj
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleAddXCustomerVehicleJPN
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.ADD_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.INSERT_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.ADDXCUSTOMERVEHICLEJPN_FAILED
    )
     public DWLResponse addXCustomerVehicleJPN(XCustomerVehicleJPNBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER addXCustomerVehicleJPN(XCustomerVehicleJPNBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("addXCustomerVehicleJPN", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction addXCustomerVehicleJPN.";
      logger.finest("addXCustomerVehicleJPN(XCustomerVehicleJPNBObj theBObj) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction addXCustomerVehicleJPN.";
      logger.finest("addXCustomerVehicleJPN(XCustomerVehicleJPNBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN addXCustomerVehicleJPN(XCustomerVehicleJPNBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Adds a XCustomerVehicleJPN to the database.
     *
     * @param theXCustomerVehicleJPNBObj
     *     The object that contains XCustomerVehicleJPN attribute values.
     * @return
     *     DWLResponse containing a XCustomerVehicleJPNBObj object.
     * @exception Exception
     * @generated
     */
    public DWLResponse handleAddXCustomerVehicleJPN(XCustomerVehicleJPNBObj theXCustomerVehicleJPNBObj) throws Exception {
        DWLResponse response = null;
        DWLStatus status = theXCustomerVehicleJPNBObj.getStatus();
        if (status == null) {
            status = new DWLStatus();
            theXCustomerVehicleJPNBObj.setStatus(status);
        }
        XVehicleJPNBObj childXVehicleJPNBObj = theXCustomerVehicleJPNBObj.getXVehicleJPNBObj();
        if( childXVehicleJPNBObj != null ){
        	String containedPk = null;
        	
            addXVehicleJPN(childXVehicleJPNBObj);
            containedPk = childXVehicleJPNBObj.getXVehicleJPNpkId ();
      theXCustomerVehicleJPNBObj.setVehicleId( containedPk );
   	     	theXCustomerVehicleJPNBObj.setXVehicleJPNBObj(childXVehicleJPNBObj);
    }

        String strPluggableID = null;

        try {
            // Pluggable Key Structure implementation
            strPluggableID = getSuppliedIdPKFromBObj(theXCustomerVehicleJPNBObj);

            if ((strPluggableID != null) && (strPluggableID.length() > 0)) {
                theXCustomerVehicleJPNBObj.getEObjXCustomerVehicleJPN().setXCustomerVehicleJPNpkId(FunctionUtils.getLongFromString(strPluggableID));
            } else {
                strPluggableID = null;
                theXCustomerVehicleJPNBObj.getEObjXCustomerVehicleJPN().setXCustomerVehicleJPNpkId(null);
            }
         Persistence theXCustomerVehicleJPNBObjPersistence = getBObjPersistenceFactory().createXCustomerVehicleJPNBObjPersistence(XCustomerVehicleJPNBObjQuery.XCUSTOMER_VEHICLE_JPN_ADD, theXCustomerVehicleJPNBObj);
         theXCustomerVehicleJPNBObjPersistence.persistAdd();

            String pkId = theXCustomerVehicleJPNBObj.getXCustomerVehicleJPNpkId ();			

            @SuppressWarnings("rawtypes")
            Vector vecXCustomerVehicleRoleJPNBObj = theXCustomerVehicleJPNBObj.getItemsXCustomerVehicleRoleJPNBObj();
            for (int i = 0; i < vecXCustomerVehicleRoleJPNBObj.size(); i++) {
                XCustomerVehicleRoleJPNBObj object = (XCustomerVehicleRoleJPNBObj)vecXCustomerVehicleRoleJPNBObj.elementAt(i);
                object.setCustomerVehicleId(pkId);
                addXCustomerVehicleRoleJPN(object);
            }
            response = new DWLResponse();
            response.setData(theXCustomerVehicleJPNBObj);
            response.setStatus(theXCustomerVehicleJPNBObj.getStatus());
    } catch (Exception ex) {
 				TCRMExceptionUtils.throwTCRMException(ex, new TCRMInsertException(ex.getMessage()), status,
                    DWLStatus.FATAL, DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_COMPONENT, TCRMErrorCode.INSERT_RECORD_ERROR,
                    DSEAAdditionsExtsErrorReasonCode.ADDXCUSTOMERVEHICLEJPN_FAILED, theXCustomerVehicleJPNBObj.getControl(), errHandler);
        }
        
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction updateXCustomerVehicleJPN.
     *
     * @param theBObj
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleUpdateXCustomerVehicleJPN
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.UPDATE_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.UPDATE_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.UPDATEXCUSTOMERVEHICLEJPN_FAILED
    , manuallyHandleRedundantUpdateCheck="true"
    )
     public DWLResponse updateXCustomerVehicleJPN(XCustomerVehicleJPNBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER updateXCustomerVehicleJPN(XCustomerVehicleJPNBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("updateXCustomerVehicleJPN", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction updateXCustomerVehicleJPN.";
      logger.finest("updateXCustomerVehicleJPN(XCustomerVehicleJPNBObj theBObj) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction updateXCustomerVehicleJPN.";
      logger.finest("updateXCustomerVehicleJPN(XCustomerVehicleJPNBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN updateXCustomerVehicleJPN(XCustomerVehicleJPNBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Updates the specified XCustomerVehicleJPN with new attribute values.
     *
     * @param theXCustomerVehicleJPNBObj
     *     The object that contains XCustomerVehicleJPN attribute values to be
     *     updated
     * @return
     *     DWLResponse containing a XCustomerVehicleJPNBObj of the updated
     *     object.
     * @exception Exception
     * @generated
     */
    public DWLResponse handleUpdateXCustomerVehicleJPN(XCustomerVehicleJPNBObj theXCustomerVehicleJPNBObj) throws Exception {

        DWLStatus status = theXCustomerVehicleJPNBObj.getStatus();

        if (status == null) {
            status = new DWLStatus();
            theXCustomerVehicleJPNBObj.setStatus(status);
        }
        
    if( !theXCustomerVehicleJPNBObj.isRedundantUpdate() ){
            // set lastupdatetxid with txnid from dwlcontrol
            theXCustomerVehicleJPNBObj.getEObjXCustomerVehicleJPN().setLastUpdateTxId(new Long(theXCustomerVehicleJPNBObj.getControl().getTxnId()));
            Persistence theXCustomerVehicleJPNBObjPersistence = getBObjPersistenceFactory().createXCustomerVehicleJPNBObjPersistence(XCustomerVehicleJPNBObjQuery.XCUSTOMER_VEHICLE_JPN_UPDATE, theXCustomerVehicleJPNBObj);
            theXCustomerVehicleJPNBObjPersistence.persistUpdate();
        }

    String pkId = theXCustomerVehicleJPNBObj.getXCustomerVehicleJPNpkId();			

    @SuppressWarnings("rawtypes")
    Vector vecXCustomerVehicleRoleJPNBObj = theXCustomerVehicleJPNBObj.getItemsXCustomerVehicleRoleJPNBObj();
    for (int i = 0; i < vecXCustomerVehicleRoleJPNBObj.size(); i++) {
      XCustomerVehicleRoleJPNBObj object = (XCustomerVehicleRoleJPNBObj)vecXCustomerVehicleRoleJPNBObj.elementAt(i);
      
      String ref = object.getCustomerVehicleId();
      if (ref != null && !ref.equals(pkId)) {
        TCRMExceptionUtils.throwTCRMException(null, new TCRMDataInvalidException(),
          status,
          DWLStatus.FATAL,
          DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_JPNBOBJ,
          TCRMErrorCode.DATA_INVALID_ERROR,
          DSEAAdditionsExtsErrorReasonCode.XCUSTOMERVEHICLEJPN_XCUSTOMERVEHICLEROLEJPN_REFERENCE_INVALID,
          theXCustomerVehicleJPNBObj.getControl(),
          errHandler);
      }
      
      object.setCustomerVehicleId(pkId);
      
      if (object.getEObjXCustomerVehicleRoleJPN().getPrimaryKey() == null){
        addXCustomerVehicleRoleJPN(object);
      } else {
        updateXCustomerVehicleRoleJPN(object);
      }
    }
        DWLResponse response = createDWLResponse();
        response.setData(theXCustomerVehicleJPNBObj);
        response.setStatus(theXCustomerVehicleJPNBObj.getStatus());

        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXCustomerVehicleRoleJPN.
     *
     * @param XCustomerVehicleRoleJPNpkId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetXCustomerVehicleRoleJPN
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETXCUSTOMERVEHICLEROLEJPN_FAILED,
       beforePreExecuteMethod = "beforePreExecuteGetXCustomerVehicleRoleJPN"
    )
     public DWLResponse getXCustomerVehicleRoleJPN(String XCustomerVehicleRoleJPNpkId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getXCustomerVehicleRoleJPN(String XCustomerVehicleRoleJPNpkId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(XCustomerVehicleRoleJPNpkId);
        DWLTransaction txObj = new  DWLTransactionInquiry("getXCustomerVehicleRoleJPN", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction getXCustomerVehicleRoleJPN.";
      logger.finest("getXCustomerVehicleRoleJPN(String XCustomerVehicleRoleJPNpkId,  DWLControl control) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction getXCustomerVehicleRoleJPN.";
      logger.finest("getXCustomerVehicleRoleJPN(String XCustomerVehicleRoleJPNpkId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getXCustomerVehicleRoleJPN(String XCustomerVehicleRoleJPNpkId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets a XCustomerVehicleRoleJPN from the database.
     * 
     * @generated
     */
    public DWLResponse handleGetXCustomerVehicleRoleJPN(String XCustomerVehicleRoleJPNpkId,  DWLControl control) throws Exception {
        DWLStatus status = new DWLStatus();
        DWLResponse response = createDWLResponse();
        
        BObjQuery bObjQuery = null;
           
        String asOfDate = (String) control.get(DWLControl.INQUIRE_AS_OF_DATE);

        // History data inquiry: if inquireAsOfDate field has value in request xml 
        if (StringUtils.isNonBlank(asOfDate)) {
            Timestamp tsAsOfDate = getPITHistoryDate(asOfDate, DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_COMPONENT,
                                                     DSEAAdditionsExtsErrorReasonCode.GETXCUSTOMERVEHICLEROLEJPN_INVALID_INQUIRE_AS_OF_DATE_FORMAT,
                                                     status, control);

            bObjQuery = getBObjQueryFactory().createXCustomerVehicleRoleJPNBObjQuery(XCustomerVehicleRoleJPNBObjQuery.XCUSTOMER_VEHICLE_ROLE_JPN_HISTORY_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(XCustomerVehicleRoleJPNpkId));
            bObjQuery.setParameter(1, tsAsOfDate);
            bObjQuery.setParameter(2, tsAsOfDate);
        } else {
            bObjQuery = getBObjQueryFactory().createXCustomerVehicleRoleJPNBObjQuery(XCustomerVehicleRoleJPNBObjQuery.XCUSTOMER_VEHICLE_ROLE_JPN_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(XCustomerVehicleRoleJPNpkId));
        }


        XCustomerVehicleRoleJPNBObj o = (XCustomerVehicleRoleJPNBObj) bObjQuery.getSingleResult();
        if( o == null ){
        	return null;
        } 
        postRetrieveXCustomerVehicleRoleJPNBObj(o, "0", "ALL", control); 
          
        if (o.getStatus()==null) {
            o.setStatus(status);
        }
        response.addStatus(o.getStatus());
        response.setData(o);

      return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public void beforePreExecuteGetXCustomerVehicleRoleJPN(DWLTransaction transaction) throws DWLBaseException{
        // Check if the parameters are valid.
        Object[] arguments = getInquiryArgumentType((DWLTransactionInquiry)transaction);
        String pk = null;
        if (arguments!=null && arguments.length>0) {
            pk = (String)arguments[0];
        }
        // Check if the parameter passed in exists.
        if ((pk == null) || (pk.trim().length() == 0)) {
            TCRMExceptionUtils.throwTCRMException(null, new TCRMReadException(), transaction.getStatus(), DWLStatus.FATAL,
                DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_ROLE_JPNBOBJ,
                TCRMErrorCode.FIELD_VALIDATION_ERROR,
                DSEAAdditionsExtsErrorReasonCode.XCUSTOMERVEHICLEROLEJPN_XCUSTOMERVEHICLEROLEJPNPKID_NULL,
                transaction.getTxnControl(), errHandler);
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getAllVehicleRoleByCustomerVehicleJPNId.
     *
     * @param CustomerVehicleId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetAllVehicleRoleByCustomerVehicleJPNId
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETALLVEHICLEROLEBYCUSTOMERVEHICLEJPNID_FAILED,
       beforePreExecuteMethod = "beforePreExecuteGetAllVehicleRoleByCustomerVehicleJPNId"
    )
     public DWLResponse getAllVehicleRoleByCustomerVehicleJPNId(String CustomerVehicleId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getAllVehicleRoleByCustomerVehicleJPNId(String CustomerVehicleId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(CustomerVehicleId);
        DWLTransaction txObj = new  DWLTransactionInquiry("getAllVehicleRoleByCustomerVehicleJPNId", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction getAllVehicleRoleByCustomerVehicleJPNId.";
      logger.finest("getAllVehicleRoleByCustomerVehicleJPNId(String CustomerVehicleId,  DWLControl control) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction getAllVehicleRoleByCustomerVehicleJPNId.";
      logger.finest("getAllVehicleRoleByCustomerVehicleJPNId(String CustomerVehicleId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getAllVehicleRoleByCustomerVehicleJPNId(String CustomerVehicleId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets a XCustomerVehicleRoleJPN from the database.
     * 
     * @generated
     */
    public DWLResponse handleGetAllVehicleRoleByCustomerVehicleJPNId(String CustomerVehicleId,  DWLControl control) throws Exception {
        DWLStatus status = new DWLStatus();
        DWLResponse response = createDWLResponse();
        
        BObjQuery bObjQuery = null;
           
        String asOfDate = (String) control.get(DWLControl.INQUIRE_AS_OF_DATE);

        // History data inquiry: if inquireAsOfDate field has value in request xml 
        if (StringUtils.isNonBlank(asOfDate)) {
            Timestamp tsAsOfDate = getPITHistoryDate(asOfDate, DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_COMPONENT,
                                                     DSEAAdditionsExtsErrorReasonCode.GETALLVEHICLEROLEBYCUSTOMERVEHICLEJPNID_INVALID_INQUIRE_AS_OF_DATE_FORMAT,
                                                     status, control);

            bObjQuery = getBObjQueryFactory().createXCustomerVehicleRoleJPNBObjQuery(XCustomerVehicleRoleJPNBObjQuery.ALL_VEHICLE_ROLE_BY_CUSTOMER_VEHICLE_JPNID_HISTORY_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(CustomerVehicleId));
            bObjQuery.setParameter(1, tsAsOfDate);
            bObjQuery.setParameter(2, tsAsOfDate);
        } else {
            bObjQuery = getBObjQueryFactory().createXCustomerVehicleRoleJPNBObjQuery(XCustomerVehicleRoleJPNBObjQuery.ALL_VEHICLE_ROLE_BY_CUSTOMER_VEHICLE_JPNID_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(CustomerVehicleId));
        }

        boolean considerForPagination = PaginationUtils
                            .considerForPagintion(XCustomerVehicleRoleJPNBObj.class.getName(), control);
        control.setConsiderForPagintionFlag(considerForPagination);

        // set returned object
        List<?> list = bObjQuery.getResults();

        if (list.size() == 0) {
            return null;
        }
    Vector<XCustomerVehicleRoleJPNBObj> vector = new Vector<XCustomerVehicleRoleJPNBObj>();
        for (Iterator<?> it = list.iterator(); it.hasNext();) {
            XCustomerVehicleRoleJPNBObj o = (XCustomerVehicleRoleJPNBObj) it.next();
            postRetrieveXCustomerVehicleRoleJPNBObj(o, "0", "ALL", control); 
            vector.add(o);
          
            if (o.getStatus()==null) {
                o.setStatus(status);
            }
            response.addStatus(o.getStatus());
        }
        response.setData(vector);

      return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public void beforePreExecuteGetAllVehicleRoleByCustomerVehicleJPNId(DWLTransaction transaction) throws DWLBaseException{
        // Check if the parameters are valid.
        Object[] arguments = getInquiryArgumentType((DWLTransactionInquiry)transaction);
    if (arguments!=null && arguments.length>0) {
            // MDM_TODO0: CDKWB0003I Add argument validation logic
    }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction addXCustomerVehicleRoleJPN.
     *
     * @param theBObj
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleAddXCustomerVehicleRoleJPN
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.ADD_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.INSERT_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.ADDXCUSTOMERVEHICLEROLEJPN_FAILED
    )
     public DWLResponse addXCustomerVehicleRoleJPN(XCustomerVehicleRoleJPNBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER addXCustomerVehicleRoleJPN(XCustomerVehicleRoleJPNBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("addXCustomerVehicleRoleJPN", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction addXCustomerVehicleRoleJPN.";
      logger.finest("addXCustomerVehicleRoleJPN(XCustomerVehicleRoleJPNBObj theBObj) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction addXCustomerVehicleRoleJPN.";
      logger.finest("addXCustomerVehicleRoleJPN(XCustomerVehicleRoleJPNBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN addXCustomerVehicleRoleJPN(XCustomerVehicleRoleJPNBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Adds a XCustomerVehicleRoleJPN to the database.
     *
     * @param theXCustomerVehicleRoleJPNBObj
     *     The object that contains XCustomerVehicleRoleJPN attribute values.
     * @return
     *     DWLResponse containing a XCustomerVehicleRoleJPNBObj object.
     * @exception Exception
     * @generated
     */
    public DWLResponse handleAddXCustomerVehicleRoleJPN(XCustomerVehicleRoleJPNBObj theXCustomerVehicleRoleJPNBObj) throws Exception {
        DWLResponse response = null;
        DWLStatus status = theXCustomerVehicleRoleJPNBObj.getStatus();
        if (status == null) {
            status = new DWLStatus();
            theXCustomerVehicleRoleJPNBObj.setStatus(status);
        }

        String strPluggableID = null;

        try {
            // Pluggable Key Structure implementation
            strPluggableID = getSuppliedIdPKFromBObj(theXCustomerVehicleRoleJPNBObj);

            if ((strPluggableID != null) && (strPluggableID.length() > 0)) {
                theXCustomerVehicleRoleJPNBObj.getEObjXCustomerVehicleRoleJPN().setXCustomerVehicleRoleJPNpkId(FunctionUtils.getLongFromString(strPluggableID));
            } else {
                strPluggableID = null;
                theXCustomerVehicleRoleJPNBObj.getEObjXCustomerVehicleRoleJPN().setXCustomerVehicleRoleJPNpkId(null);
            }
         Persistence theXCustomerVehicleRoleJPNBObjPersistence = getBObjPersistenceFactory().createXCustomerVehicleRoleJPNBObjPersistence(XCustomerVehicleRoleJPNBObjQuery.XCUSTOMER_VEHICLE_ROLE_JPN_ADD, theXCustomerVehicleRoleJPNBObj);
         theXCustomerVehicleRoleJPNBObjPersistence.persistAdd();

            response = new DWLResponse();
            response.setData(theXCustomerVehicleRoleJPNBObj);
            response.setStatus(theXCustomerVehicleRoleJPNBObj.getStatus());
    } catch (Exception ex) {
 				TCRMExceptionUtils.throwTCRMException(ex, new TCRMInsertException(ex.getMessage()), status,
                    DWLStatus.FATAL, DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_COMPONENT, TCRMErrorCode.INSERT_RECORD_ERROR,
                    DSEAAdditionsExtsErrorReasonCode.ADDXCUSTOMERVEHICLEROLEJPN_FAILED, theXCustomerVehicleRoleJPNBObj.getControl(), errHandler);
        }
        
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction updateXCustomerVehicleRoleJPN.
     *
     * @param theBObj
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleUpdateXCustomerVehicleRoleJPN
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.UPDATE_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.UPDATE_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.UPDATEXCUSTOMERVEHICLEROLEJPN_FAILED
    )
     public DWLResponse updateXCustomerVehicleRoleJPN(XCustomerVehicleRoleJPNBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER updateXCustomerVehicleRoleJPN(XCustomerVehicleRoleJPNBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("updateXCustomerVehicleRoleJPN", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction updateXCustomerVehicleRoleJPN.";
      logger.finest("updateXCustomerVehicleRoleJPN(XCustomerVehicleRoleJPNBObj theBObj) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction updateXCustomerVehicleRoleJPN.";
      logger.finest("updateXCustomerVehicleRoleJPN(XCustomerVehicleRoleJPNBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN updateXCustomerVehicleRoleJPN(XCustomerVehicleRoleJPNBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Updates the specified XCustomerVehicleRoleJPN with new attribute values.
     *
     * @param theXCustomerVehicleRoleJPNBObj
     *     The object that contains XCustomerVehicleRoleJPN attribute values to
     *     be updated
     * @return
     *     DWLResponse containing a XCustomerVehicleRoleJPNBObj of the updated
     *     object.
     * @exception Exception
     * @generated
     */
    public DWLResponse handleUpdateXCustomerVehicleRoleJPN(XCustomerVehicleRoleJPNBObj theXCustomerVehicleRoleJPNBObj) throws Exception {

        DWLStatus status = theXCustomerVehicleRoleJPNBObj.getStatus();

        if (status == null) {
            status = new DWLStatus();
            theXCustomerVehicleRoleJPNBObj.setStatus(status);
        }
        
            // set lastupdatetxid with txnid from dwlcontrol
            theXCustomerVehicleRoleJPNBObj.getEObjXCustomerVehicleRoleJPN().setLastUpdateTxId(new Long(theXCustomerVehicleRoleJPNBObj.getControl().getTxnId()));
         Persistence theXCustomerVehicleRoleJPNBObjPersistence = getBObjPersistenceFactory().createXCustomerVehicleRoleJPNBObjPersistence(XCustomerVehicleRoleJPNBObjQuery.XCUSTOMER_VEHICLE_ROLE_JPN_UPDATE, theXCustomerVehicleRoleJPNBObj);
         theXCustomerVehicleRoleJPNBObjPersistence.persistUpdate();

        DWLResponse response = createDWLResponse();
        response.setData(theXCustomerVehicleRoleJPNBObj);
        response.setStatus(theXCustomerVehicleRoleJPNBObj.getStatus());

        return response;
    }
    
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXDataSharing.
     *
     * @param DataSharingpkId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetXDataSharing
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETXDATASHARING_FAILED,
       beforePreExecuteMethod = "beforePreExecuteGetXDataSharing"
    )
     public DWLResponse getXDataSharing(String DataSharingpkId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getXDataSharing(String DataSharingpkId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(DataSharingpkId);
        DWLTransaction txObj = new  DWLTransactionInquiry("getXDataSharing", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction getXDataSharing.";
      logger.finest("getXDataSharing(String DataSharingpkId,  DWLControl control) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction getXDataSharing.";
      logger.finest("getXDataSharing(String DataSharingpkId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getXDataSharing(String DataSharingpkId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets a XDataSharing from the database.
     * 
     * @generated
     */
    public DWLResponse handleGetXDataSharing(String DataSharingpkId,  DWLControl control) throws Exception {
        DWLStatus status = new DWLStatus();
        DWLResponse response = createDWLResponse();
        
        BObjQuery bObjQuery = null;
           
        String asOfDate = (String) control.get(DWLControl.INQUIRE_AS_OF_DATE);

        // History data inquiry: if inquireAsOfDate field has value in request xml 
        if (StringUtils.isNonBlank(asOfDate)) {
            Timestamp tsAsOfDate = getPITHistoryDate(asOfDate, DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_COMPONENT,
                                                     DSEAAdditionsExtsErrorReasonCode.GETXDATASHARING_INVALID_INQUIRE_AS_OF_DATE_FORMAT,
                                                     status, control);

            bObjQuery = getBObjQueryFactory().createXDataSharingBObjQuery(XDataSharingBObjQuery.XDATA_SHARING_HISTORY_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(DataSharingpkId));
            bObjQuery.setParameter(1, tsAsOfDate);
            bObjQuery.setParameter(2, tsAsOfDate);
        } else {
            bObjQuery = getBObjQueryFactory().createXDataSharingBObjQuery(XDataSharingBObjQuery.XDATA_SHARING_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(DataSharingpkId));
        }


        XDataSharingBObj o = (XDataSharingBObj) bObjQuery.getSingleResult();
        if( o == null ){
        	return null;
        } 
        postRetrieveXDataSharingBObj(o, "0", "ALL", control); 
          
        if (o.getStatus()==null) {
            o.setStatus(status);
        }
        response.addStatus(o.getStatus());
        response.setData(o);

      return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public void beforePreExecuteGetXDataSharing(DWLTransaction transaction) throws DWLBaseException{
        // Check if the parameters are valid.
        Object[] arguments = getInquiryArgumentType((DWLTransactionInquiry)transaction);
        String pk = null;
        if (arguments!=null && arguments.length>0) {
            pk = (String)arguments[0];
        }
        // Check if the parameter passed in exists.
        if ((pk == null) || (pk.trim().length() == 0)) {
            TCRMExceptionUtils.throwTCRMException(null, new TCRMReadException(), transaction.getStatus(), DWLStatus.FATAL,
                DSEAAdditionsExtsComponentID.XDATA_SHARING_BOBJ,
                TCRMErrorCode.FIELD_VALIDATION_ERROR,
                DSEAAdditionsExtsErrorReasonCode.XDATASHARING_DATASHARINGPKID_NULL,
                transaction.getTxnControl(), errHandler);
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getDataSharingByPartyId.
     *
     * @param ContId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetDataSharingByPartyId
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETDATASHARINGBYPARTYID_FAILED,
       beforePreExecuteMethod = "beforePreExecuteGetDataSharingByPartyId"
    )
     public DWLResponse getDataSharingByPartyId(String ContId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getDataSharingByPartyId(String ContId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(ContId);
        DWLTransaction txObj = new  DWLTransactionInquiry("getDataSharingByPartyId", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction getDataSharingByPartyId.";
      logger.finest("getDataSharingByPartyId(String ContId,  DWLControl control) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction getDataSharingByPartyId.";
      logger.finest("getDataSharingByPartyId(String ContId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getDataSharingByPartyId(String ContId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets a XDataSharing from the database.
     * 
     * @generated
     */
    public DWLResponse handleGetDataSharingByPartyId(String ContId,  DWLControl control) throws Exception {
        DWLStatus status = new DWLStatus();
        DWLResponse response = createDWLResponse();
        
        BObjQuery bObjQuery = null;
           
        String asOfDate = (String) control.get(DWLControl.INQUIRE_AS_OF_DATE);

        // History data inquiry: if inquireAsOfDate field has value in request xml 
        if (StringUtils.isNonBlank(asOfDate)) {
            Timestamp tsAsOfDate = getPITHistoryDate(asOfDate, DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_COMPONENT,
                                                     DSEAAdditionsExtsErrorReasonCode.GETDATASHARINGBYPARTYID_INVALID_INQUIRE_AS_OF_DATE_FORMAT,
                                                     status, control);

            bObjQuery = getBObjQueryFactory().createXDataSharingBObjQuery(XDataSharingBObjQuery.DATA_SHARING_BY_PARTY_ID_HISTORY_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(ContId));
            bObjQuery.setParameter(1, tsAsOfDate);
            bObjQuery.setParameter(2, tsAsOfDate);
        } else {
            bObjQuery = getBObjQueryFactory().createXDataSharingBObjQuery(XDataSharingBObjQuery.DATA_SHARING_BY_PARTY_ID_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(ContId));
        }

        boolean considerForPagination = PaginationUtils
                            .considerForPagintion(XDataSharingBObj.class.getName(), control);
        control.setConsiderForPagintionFlag(considerForPagination);

        // set returned object
        List<?> list = bObjQuery.getResults();

        if (list.size() == 0) {
            return null;
        }
    Vector<XDataSharingBObj> vector = new Vector<XDataSharingBObj>();
        for (Iterator<?> it = list.iterator(); it.hasNext();) {
            XDataSharingBObj o = (XDataSharingBObj) it.next();
            postRetrieveXDataSharingBObj(o, "0", "ALL", control); 
            vector.add(o);
          
            if (o.getStatus()==null) {
                o.setStatus(status);
            }
            response.addStatus(o.getStatus());
        }
        response.setData(vector);

      return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public void beforePreExecuteGetDataSharingByPartyId(DWLTransaction transaction) throws DWLBaseException{
        // Check if the parameters are valid.
        Object[] arguments = getInquiryArgumentType((DWLTransactionInquiry)transaction);
    if (arguments!=null && arguments.length>0) {
            // MDM_TODO0: CDKWB0003I Add argument validation logic
    }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction addXDataSharing.
     *
     * @param theBObj
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleAddXDataSharing
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.ADD_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.INSERT_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.ADDXDATASHARING_FAILED
    )
     public DWLResponse addXDataSharing(XDataSharingBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER addXDataSharing(XDataSharingBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("addXDataSharing", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction addXDataSharing.";
      logger.finest("addXDataSharing(XDataSharingBObj theBObj) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction addXDataSharing.";
      logger.finest("addXDataSharing(XDataSharingBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN addXDataSharing(XDataSharingBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Adds a XDataSharing to the database.
     *
     * @param theXDataSharingBObj
     *     The object that contains XDataSharing attribute values.
     * @return
     *     DWLResponse containing a XDataSharingBObj object.
     * @exception Exception
     * @generated
     */
    public DWLResponse handleAddXDataSharing(XDataSharingBObj theXDataSharingBObj) throws Exception {
        DWLResponse response = null;
        DWLStatus status = theXDataSharingBObj.getStatus();
        if (status == null) {
            status = new DWLStatus();
            theXDataSharingBObj.setStatus(status);
        }

        String strPluggableID = null;

        try {
            // Pluggable Key Structure implementation
            strPluggableID = getSuppliedIdPKFromBObj(theXDataSharingBObj);

            if ((strPluggableID != null) && (strPluggableID.length() > 0)) {
                theXDataSharingBObj.getEObjXDataSharing().setDataSharingpkId(FunctionUtils.getLongFromString(strPluggableID));
            } else {
                strPluggableID = null;
                theXDataSharingBObj.getEObjXDataSharing().setDataSharingpkId(null);
            }
         Persistence theXDataSharingBObjPersistence = getBObjPersistenceFactory().createXDataSharingBObjPersistence(XDataSharingBObjQuery.XDATA_SHARING_ADD, theXDataSharingBObj);
         theXDataSharingBObjPersistence.persistAdd();

            response = new DWLResponse();
            response.setData(theXDataSharingBObj);
            response.setStatus(theXDataSharingBObj.getStatus());
    } catch (Exception ex) {
 				TCRMExceptionUtils.throwTCRMException(ex, new TCRMInsertException(ex.getMessage()), status,
                    DWLStatus.FATAL, DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_COMPONENT, TCRMErrorCode.INSERT_RECORD_ERROR,
                    DSEAAdditionsExtsErrorReasonCode.ADDXDATASHARING_FAILED, theXDataSharingBObj.getControl(), errHandler);
        }
        
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction updateXDataSharing.
     *
     * @param theBObj
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleUpdateXDataSharing
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.UPDATE_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.UPDATE_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.UPDATEXDATASHARING_FAILED
    )
     public DWLResponse updateXDataSharing(XDataSharingBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER updateXDataSharing(XDataSharingBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("updateXDataSharing", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction updateXDataSharing.";
      logger.finest("updateXDataSharing(XDataSharingBObj theBObj) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction updateXDataSharing.";
      logger.finest("updateXDataSharing(XDataSharingBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN updateXDataSharing(XDataSharingBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Updates the specified XDataSharing with new attribute values.
     *
     * @param theXDataSharingBObj
     *     The object that contains XDataSharing attribute values to be updated
     * @return
     *     DWLResponse containing a XDataSharingBObj of the updated object.
     * @exception Exception
     * @generated
     */
    public DWLResponse handleUpdateXDataSharing(XDataSharingBObj theXDataSharingBObj) throws Exception {

        DWLStatus status = theXDataSharingBObj.getStatus();

        if (status == null) {
            status = new DWLStatus();
            theXDataSharingBObj.setStatus(status);
        }
        
            // set lastupdatetxid with txnid from dwlcontrol
            theXDataSharingBObj.getEObjXDataSharing().setLastUpdateTxId(new Long(theXDataSharingBObj.getControl().getTxnId()));
         Persistence theXDataSharingBObjPersistence = getBObjPersistenceFactory().createXDataSharingBObjPersistence(XDataSharingBObjQuery.XDATA_SHARING_UPDATE, theXDataSharingBObj);
         theXDataSharingBObjPersistence.persistUpdate();

        DWLResponse response = createDWLResponse();
        response.setData(theXDataSharingBObj);
        response.setStatus(theXDataSharingBObj.getStatus());

        return response;
    }

    
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction deleteXDataSharing.
     *
     * @param theBObj
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleDeleteXDataSharing
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.DELETE_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.DELETE_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.UPDATEXDATASHARING_FAILED
    )
     public DWLResponse deleteXDataSharing(XDataSharingBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER deleteXDataSharing(XDataSharingBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("deleteXDataSharing", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction deleteXDataSharing.";
      logger.finest("deleteXDataSharing(XDataSharingBObj theBObj) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction deleteXDataSharing.";
      logger.finest("deleteXDataSharing(XDataSharingBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN deleteXDataSharing(XDataSharingBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    
    
    
    
    /**
     * @param theXDataSharingBObj
     * @return
     * @throws Exception
     */
    public DWLResponse handleDeleteXDataSharing(XDataSharingBObj theXDataSharingBObj) throws Exception {

        DWLStatus status = theXDataSharingBObj.getStatus();

        if (status == null) {
            status = new DWLStatus();
            theXDataSharingBObj.setStatus(status);
        }
        
            // set lastupdatetxid with txnid from dwlcontrol
            theXDataSharingBObj.getEObjXDataSharing().setLastUpdateTxId(new Long(theXDataSharingBObj.getControl().getTxnId()));
         Persistence theXDataSharingBObjPersistence = getBObjPersistenceFactory().createXDataSharingBObjPersistence(XDataSharingBObjQuery.XDATA_SHARING_DELETE, theXDataSharingBObj);
         theXDataSharingBObjPersistence.persistDelete();

        DWLResponse response = createDWLResponse();
        response.setData(theXDataSharingBObj);
        response.setStatus(theXDataSharingBObj.getStatus());

        return response;
    }
    
    
    
    
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXVehicleKOR.
     *
     * @param XVehicleKORpkId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetXVehicleKOR
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETXVEHICLEKOR_FAILED,
       beforePreExecuteMethod = "beforePreExecuteGetXVehicleKOR"
    )
     public DWLResponse getXVehicleKOR(String XVehicleKORpkId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getXVehicleKOR(String XVehicleKORpkId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(XVehicleKORpkId);
        DWLTransaction txObj = new  DWLTransactionInquiry("getXVehicleKOR", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction getXVehicleKOR.";
      logger.finest("getXVehicleKOR(String XVehicleKORpkId,  DWLControl control) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction getXVehicleKOR.";
      logger.finest("getXVehicleKOR(String XVehicleKORpkId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getXVehicleKOR(String XVehicleKORpkId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets a XVehicleKOR from the database.
     * 
     * @generated
     */
    public DWLResponse handleGetXVehicleKOR(String XVehicleKORpkId,  DWLControl control) throws Exception {
        DWLStatus status = new DWLStatus();
        DWLResponse response = createDWLResponse();
        
        BObjQuery bObjQuery = null;
           
        String asOfDate = (String) control.get(DWLControl.INQUIRE_AS_OF_DATE);

        // History data inquiry: if inquireAsOfDate field has value in request xml 
        if (StringUtils.isNonBlank(asOfDate)) {
            Timestamp tsAsOfDate = getPITHistoryDate(asOfDate, DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_COMPONENT,
                                                     DSEAAdditionsExtsErrorReasonCode.GETXVEHICLEKOR_INVALID_INQUIRE_AS_OF_DATE_FORMAT,
                                                     status, control);

            bObjQuery = getBObjQueryFactory().createXVehicleKORBObjQuery(XVehicleKORBObjQuery.XVEHICLE_KOR_HISTORY_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(XVehicleKORpkId));
            bObjQuery.setParameter(1, tsAsOfDate);
            bObjQuery.setParameter(2, tsAsOfDate);
        } else {
            bObjQuery = getBObjQueryFactory().createXVehicleKORBObjQuery(XVehicleKORBObjQuery.XVEHICLE_KOR_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(XVehicleKORpkId));
        }


        XVehicleKORBObj o = (XVehicleKORBObj) bObjQuery.getSingleResult();
        if( o == null ){
        	return null;
        } 
        postRetrieveXVehicleKORBObj(o, "0", "ALL", control); 
          
        if (o.getStatus()==null) {
            o.setStatus(status);
        }
        response.addStatus(o.getStatus());
        response.setData(o);

      return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public void beforePreExecuteGetXVehicleKOR(DWLTransaction transaction) throws DWLBaseException{
        // Check if the parameters are valid.
        Object[] arguments = getInquiryArgumentType((DWLTransactionInquiry)transaction);
        String pk = null;
        if (arguments!=null && arguments.length>0) {
            pk = (String)arguments[0];
        }
        // Check if the parameter passed in exists.
        if ((pk == null) || (pk.trim().length() == 0)) {
            TCRMExceptionUtils.throwTCRMException(null, new TCRMReadException(), transaction.getStatus(), DWLStatus.FATAL,
                DSEAAdditionsExtsComponentID.XVEHICLE_KORBOBJ,
                TCRMErrorCode.FIELD_VALIDATION_ERROR,
                DSEAAdditionsExtsErrorReasonCode.XVEHICLEKOR_XVEHICLEKORPKID_NULL,
                transaction.getTxnControl(), errHandler);
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXVehicleKORByGlobalVIN.
     *
     * @param GlobalVIN
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetXVehicleKORByGlobalVIN
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETXVEHICLEKORBYGLOBALVIN_FAILED,
       beforePreExecuteMethod = "beforePreExecuteGetXVehicleKORByGlobalVIN"
    )
     public DWLResponse getXVehicleKORByGlobalVIN(String GlobalVIN,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getXVehicleKORByGlobalVIN(String GlobalVIN,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(GlobalVIN);
        DWLTransaction txObj = new  DWLTransactionInquiry("getXVehicleKORByGlobalVIN", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction getXVehicleKORByGlobalVIN.";
      logger.finest("getXVehicleKORByGlobalVIN(String GlobalVIN,  DWLControl control) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction getXVehicleKORByGlobalVIN.";
      logger.finest("getXVehicleKORByGlobalVIN(String GlobalVIN,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getXVehicleKORByGlobalVIN(String GlobalVIN,  DWLControl control) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets a XVehicleKOR from the database.
     * 
     * @generated
     */
    public DWLResponse handleGetXVehicleKORByGlobalVIN(String GlobalVIN,  DWLControl control) throws Exception {
        DWLStatus status = new DWLStatus();
        DWLResponse response = createDWLResponse();
        
        BObjQuery bObjQuery = null;
           
        String asOfDate = (String) control.get(DWLControl.INQUIRE_AS_OF_DATE);

        // History data inquiry: if inquireAsOfDate field has value in request xml 
        if (StringUtils.isNonBlank(asOfDate)) {
            Timestamp tsAsOfDate = getPITHistoryDate(asOfDate, DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_COMPONENT,
                                                     DSEAAdditionsExtsErrorReasonCode.GETXVEHICLEKORBYGLOBALVIN_INVALID_INQUIRE_AS_OF_DATE_FORMAT,
                                                     status, control);

            bObjQuery = getBObjQueryFactory().createXVehicleKORBObjQuery(XVehicleKORBObjQuery.XVEHICLE_KORBY_GLOBAL_VIN_HISTORY_QUERY,
                		control);
            bObjQuery.setParameter(0, GlobalVIN);
            bObjQuery.setParameter(1, tsAsOfDate);
            bObjQuery.setParameter(2, tsAsOfDate);
        } else {
            bObjQuery = getBObjQueryFactory().createXVehicleKORBObjQuery(XVehicleKORBObjQuery.XVEHICLE_KORBY_GLOBAL_VIN_QUERY,
                		control);
            bObjQuery.setParameter(0, GlobalVIN);
        }


        XVehicleKORBObj o = (XVehicleKORBObj) bObjQuery.getSingleResult();
        if( o == null ){
        	return null;
        } 
        postRetrieveXVehicleKORBObj(o, "0", "ALL", control); 
          
        if (o.getStatus()==null) {
            o.setStatus(status);
        }
        response.addStatus(o.getStatus());
        response.setData(o);

      return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public void beforePreExecuteGetXVehicleKORByGlobalVIN(DWLTransaction transaction) throws DWLBaseException{
        // Check if the parameters are valid.
        Object[] arguments = getInquiryArgumentType((DWLTransactionInquiry)transaction);
    if (arguments!=null && arguments.length>0) {
            // MDM_TODO0: CDKWB0003I Add argument validation logic
    }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction addXVehicleKOR.
     *
     * @param theBObj
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleAddXVehicleKOR
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.ADD_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.INSERT_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.ADDXVEHICLEKOR_FAILED
    )
     public DWLResponse addXVehicleKOR(XVehicleKORBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER addXVehicleKOR(XVehicleKORBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("addXVehicleKOR", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction addXVehicleKOR.";
      logger.finest("addXVehicleKOR(XVehicleKORBObj theBObj) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction addXVehicleKOR.";
      logger.finest("addXVehicleKOR(XVehicleKORBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN addXVehicleKOR(XVehicleKORBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Adds a XVehicleKOR to the database.
     *
     * @param theXVehicleKORBObj
     *     The object that contains XVehicleKOR attribute values.
     * @return
     *     DWLResponse containing a XVehicleKORBObj object.
     * @exception Exception
     * @generated
     */
    public DWLResponse handleAddXVehicleKOR(XVehicleKORBObj theXVehicleKORBObj) throws Exception {
        DWLResponse response = null;
        DWLStatus status = theXVehicleKORBObj.getStatus();
        if (status == null) {
            status = new DWLStatus();
            theXVehicleKORBObj.setStatus(status);
        }

        String strPluggableID = null;

        try {
            // Pluggable Key Structure implementation
            strPluggableID = getSuppliedIdPKFromBObj(theXVehicleKORBObj);

            if ((strPluggableID != null) && (strPluggableID.length() > 0)) {
                theXVehicleKORBObj.getEObjXVehicleKOR().setXVehicleKORpkId(FunctionUtils.getLongFromString(strPluggableID));
            } else {
                strPluggableID = null;
                theXVehicleKORBObj.getEObjXVehicleKOR().setXVehicleKORpkId(null);
            }
         Persistence theXVehicleKORBObjPersistence = getBObjPersistenceFactory().createXVehicleKORBObjPersistence(XVehicleKORBObjQuery.XVEHICLE_KOR_ADD, theXVehicleKORBObj);
         theXVehicleKORBObjPersistence.persistAdd();

            response = new DWLResponse();
            response.setData(theXVehicleKORBObj);
            response.setStatus(theXVehicleKORBObj.getStatus());
    } catch (Exception ex) {
 				TCRMExceptionUtils.throwTCRMException(ex, new TCRMInsertException(ex.getMessage()), status,
                    DWLStatus.FATAL, DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_COMPONENT, TCRMErrorCode.INSERT_RECORD_ERROR,
                    DSEAAdditionsExtsErrorReasonCode.ADDXVEHICLEKOR_FAILED, theXVehicleKORBObj.getControl(), errHandler);
        }
        
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction updateXVehicleKOR.
     *
     * @param theBObj
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleUpdateXVehicleKOR
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.UPDATE_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.UPDATE_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.UPDATEXVEHICLEKOR_FAILED
    )
     public DWLResponse updateXVehicleKOR(XVehicleKORBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER updateXVehicleKOR(XVehicleKORBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("updateXVehicleKOR", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction updateXVehicleKOR.";
      logger.finest("updateXVehicleKOR(XVehicleKORBObj theBObj) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction updateXVehicleKOR.";
      logger.finest("updateXVehicleKOR(XVehicleKORBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN updateXVehicleKOR(XVehicleKORBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Updates the specified XVehicleKOR with new attribute values.
     *
     * @param theXVehicleKORBObj
     *     The object that contains XVehicleKOR attribute values to be updated
     * @return
     *     DWLResponse containing a XVehicleKORBObj of the updated object.
     * @exception Exception
     * @generated
     */
    public DWLResponse handleUpdateXVehicleKOR(XVehicleKORBObj theXVehicleKORBObj) throws Exception {

        DWLStatus status = theXVehicleKORBObj.getStatus();

        if (status == null) {
            status = new DWLStatus();
            theXVehicleKORBObj.setStatus(status);
        }
        
            // set lastupdatetxid with txnid from dwlcontrol
            theXVehicleKORBObj.getEObjXVehicleKOR().setLastUpdateTxId(new Long(theXVehicleKORBObj.getControl().getTxnId()));
         Persistence theXVehicleKORBObjPersistence = getBObjPersistenceFactory().createXVehicleKORBObjPersistence(XVehicleKORBObjQuery.XVEHICLE_KOR_UPDATE, theXVehicleKORBObj);
         theXVehicleKORBObjPersistence.persistUpdate();

        DWLResponse response = createDWLResponse();
        response.setData(theXVehicleKORBObj);
        response.setStatus(theXVehicleKORBObj.getStatus());

        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXCustomerVehicleKOR.
     *
     * @param XCustomerVehicleKORpkId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetXCustomerVehicleKOR
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETXCUSTOMERVEHICLEKOR_FAILED,
       beforePreExecuteMethod = "beforePreExecuteGetXCustomerVehicleKOR"
    )
     public DWLResponse getXCustomerVehicleKOR(String XCustomerVehicleKORpkId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getXCustomerVehicleKOR(String XCustomerVehicleKORpkId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(XCustomerVehicleKORpkId);
        DWLTransaction txObj = new  DWLTransactionInquiry("getXCustomerVehicleKOR", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction getXCustomerVehicleKOR.";
      logger.finest("getXCustomerVehicleKOR(String XCustomerVehicleKORpkId,  DWLControl control) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction getXCustomerVehicleKOR.";
      logger.finest("getXCustomerVehicleKOR(String XCustomerVehicleKORpkId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getXCustomerVehicleKOR(String XCustomerVehicleKORpkId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets a XCustomerVehicleKOR from the database.
     * 
     * @generated
     */
    public DWLResponse handleGetXCustomerVehicleKOR(String XCustomerVehicleKORpkId,  DWLControl control) throws Exception {
        DWLStatus status = new DWLStatus();
        DWLResponse response = createDWLResponse();
        
        BObjQuery bObjQuery = null;
           
        String asOfDate = (String) control.get(DWLControl.INQUIRE_AS_OF_DATE);

        // History data inquiry: if inquireAsOfDate field has value in request xml 
        if (StringUtils.isNonBlank(asOfDate)) {
            Timestamp tsAsOfDate = getPITHistoryDate(asOfDate, DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_COMPONENT,
                                                     DSEAAdditionsExtsErrorReasonCode.GETXCUSTOMERVEHICLEKOR_INVALID_INQUIRE_AS_OF_DATE_FORMAT,
                                                     status, control);

            bObjQuery = getBObjQueryFactory().createXCustomerVehicleKORBObjQuery(XCustomerVehicleKORBObjQuery.XCUSTOMER_VEHICLE_KOR_HISTORY_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(XCustomerVehicleKORpkId));
            bObjQuery.setParameter(1, tsAsOfDate);
            bObjQuery.setParameter(2, tsAsOfDate);
        } else {
            bObjQuery = getBObjQueryFactory().createXCustomerVehicleKORBObjQuery(XCustomerVehicleKORBObjQuery.XCUSTOMER_VEHICLE_KOR_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(XCustomerVehicleKORpkId));
        }


        XCustomerVehicleKORBObj o = (XCustomerVehicleKORBObj) bObjQuery.getSingleResult();
        if( o == null ){
        	return null;
        } 
        postRetrieveXCustomerVehicleKORBObj(o, "0", "ALL", control); 
          
        if (o.getStatus()==null) {
            o.setStatus(status);
        }
        response.addStatus(o.getStatus());
        response.setData(o);

      return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public void beforePreExecuteGetXCustomerVehicleKOR(DWLTransaction transaction) throws DWLBaseException{
        // Check if the parameters are valid.
        Object[] arguments = getInquiryArgumentType((DWLTransactionInquiry)transaction);
        String pk = null;
        if (arguments!=null && arguments.length>0) {
            pk = (String)arguments[0];
        }
        // Check if the parameter passed in exists.
        if ((pk == null) || (pk.trim().length() == 0)) {
            TCRMExceptionUtils.throwTCRMException(null, new TCRMReadException(), transaction.getStatus(), DWLStatus.FATAL,
                DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_KORBOBJ,
                TCRMErrorCode.FIELD_VALIDATION_ERROR,
                DSEAAdditionsExtsErrorReasonCode.XCUSTOMERVEHICLEKOR_XCUSTOMERVEHICLEKORPKID_NULL,
                transaction.getTxnControl(), errHandler);
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getAllXCustomerVehicleKORByPartyId.
     *
     * @param ContId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetAllXCustomerVehicleKORByPartyId
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETALLXCUSTOMERVEHICLEKORBYPARTYID_FAILED,
       beforePreExecuteMethod = "beforePreExecuteGetAllXCustomerVehicleKORByPartyId"
    )
     public DWLResponse getAllXCustomerVehicleKORByPartyId(String ContId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getAllXCustomerVehicleKORByPartyId(String ContId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(ContId);
        DWLTransaction txObj = new  DWLTransactionInquiry("getAllXCustomerVehicleKORByPartyId", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction getAllXCustomerVehicleKORByPartyId.";
      logger.finest("getAllXCustomerVehicleKORByPartyId(String ContId,  DWLControl control) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction getAllXCustomerVehicleKORByPartyId.";
      logger.finest("getAllXCustomerVehicleKORByPartyId(String ContId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getAllXCustomerVehicleKORByPartyId(String ContId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets a XCustomerVehicleKOR from the database.
     * 
     * @generated
     */
    public DWLResponse handleGetAllXCustomerVehicleKORByPartyId(String ContId,  DWLControl control) throws Exception {
        DWLStatus status = new DWLStatus();
        DWLResponse response = createDWLResponse();
        
        BObjQuery bObjQuery = null;
           
        String asOfDate = (String) control.get(DWLControl.INQUIRE_AS_OF_DATE);

        // History data inquiry: if inquireAsOfDate field has value in request xml 
        if (StringUtils.isNonBlank(asOfDate)) {
            Timestamp tsAsOfDate = getPITHistoryDate(asOfDate, DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_COMPONENT,
                                                     DSEAAdditionsExtsErrorReasonCode.GETALLXCUSTOMERVEHICLEKORBYPARTYID_INVALID_INQUIRE_AS_OF_DATE_FORMAT,
                                                     status, control);

            bObjQuery = getBObjQueryFactory().createXCustomerVehicleKORBObjQuery(XCustomerVehicleKORBObjQuery.ALL_XCUSTOMER_VEHICLE_KORBY_PARTY_ID_HISTORY_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(ContId));
            bObjQuery.setParameter(1, tsAsOfDate);
            bObjQuery.setParameter(2, tsAsOfDate);
        } else {
            bObjQuery = getBObjQueryFactory().createXCustomerVehicleKORBObjQuery(XCustomerVehicleKORBObjQuery.ALL_XCUSTOMER_VEHICLE_KORBY_PARTY_ID_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(ContId));
        }

        boolean considerForPagination = PaginationUtils
                            .considerForPagintion(XCustomerVehicleKORBObj.class.getName(), control);
        control.setConsiderForPagintionFlag(considerForPagination);

        // set returned object
        List<?> list = bObjQuery.getResults();

        if (list.size() == 0) {
            return null;
        }
    Vector<XCustomerVehicleKORBObj> vector = new Vector<XCustomerVehicleKORBObj>();
        for (Iterator<?> it = list.iterator(); it.hasNext();) {
            XCustomerVehicleKORBObj o = (XCustomerVehicleKORBObj) it.next();
            postRetrieveXCustomerVehicleKORBObj(o, "0", "ALL", control); 
            vector.add(o);
          
            if (o.getStatus()==null) {
                o.setStatus(status);
            }
            response.addStatus(o.getStatus());
        }
        response.setData(vector);

      return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public void beforePreExecuteGetAllXCustomerVehicleKORByPartyId(DWLTransaction transaction) throws DWLBaseException{
        // Check if the parameters are valid.
        Object[] arguments = getInquiryArgumentType((DWLTransactionInquiry)transaction);
    if (arguments!=null && arguments.length>0) {
            // MDM_TODO0: CDKWB0003I Add argument validation logic
    }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getAllCVRByVehicle_ID.
     *
     * @param VehicleId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetAllCVRByVehicle_ID
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETALLCVRBYVEHICLE_ID_FAILED,
       beforePreExecuteMethod = "beforePreExecuteGetAllCVRByVehicle_ID"
    )
     public DWLResponse getAllCVRByVehicle_ID(String VehicleId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getAllCVRByVehicle_ID(String VehicleId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(VehicleId);
        DWLTransaction txObj = new  DWLTransactionInquiry("getAllCVRByVehicle_ID", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction getAllCVRByVehicle_ID.";
      logger.finest("getAllCVRByVehicle_ID(String VehicleId,  DWLControl control) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction getAllCVRByVehicle_ID.";
      logger.finest("getAllCVRByVehicle_ID(String VehicleId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getAllCVRByVehicle_ID(String VehicleId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets a XCustomerVehicleKOR from the database.
     * 
     * @generated
     */
    public DWLResponse handleGetAllCVRByVehicle_ID(String VehicleId,  DWLControl control) throws Exception {
        DWLStatus status = new DWLStatus();
        DWLResponse response = createDWLResponse();
        
        BObjQuery bObjQuery = null;
           
        String asOfDate = (String) control.get(DWLControl.INQUIRE_AS_OF_DATE);

        // History data inquiry: if inquireAsOfDate field has value in request xml 
        if (StringUtils.isNonBlank(asOfDate)) {
            Timestamp tsAsOfDate = getPITHistoryDate(asOfDate, DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_COMPONENT,
                                                     DSEAAdditionsExtsErrorReasonCode.GETALLCVRBYVEHICLE_ID_INVALID_INQUIRE_AS_OF_DATE_FORMAT,
                                                     status, control);

            bObjQuery = getBObjQueryFactory().createXCustomerVehicleKORBObjQuery(XCustomerVehicleKORBObjQuery.ALL_CVRBY_VEHICLE_ID_HISTORY_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(VehicleId));
            bObjQuery.setParameter(1, tsAsOfDate);
            bObjQuery.setParameter(2, tsAsOfDate);
        } else {
            bObjQuery = getBObjQueryFactory().createXCustomerVehicleKORBObjQuery(XCustomerVehicleKORBObjQuery.ALL_CVRBY_VEHICLE_ID_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(VehicleId));
        }

        boolean considerForPagination = PaginationUtils
                            .considerForPagintion(XCustomerVehicleKORBObj.class.getName(), control);
        control.setConsiderForPagintionFlag(considerForPagination);

        // set returned object
        List<?> list = bObjQuery.getResults();

        if (list.size() == 0) {
            return null;
        }
    Vector<XCustomerVehicleKORBObj> vector = new Vector<XCustomerVehicleKORBObj>();
        for (Iterator<?> it = list.iterator(); it.hasNext();) {
            XCustomerVehicleKORBObj o = (XCustomerVehicleKORBObj) it.next();
            postRetrieveXCustomerVehicleKORBObj(o, "0", "ALL", control); 
            vector.add(o);
          
            if (o.getStatus()==null) {
                o.setStatus(status);
            }
            response.addStatus(o.getStatus());
        }
        response.setData(vector);

      return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public void beforePreExecuteGetAllCVRByVehicle_ID(DWLTransaction transaction) throws DWLBaseException{
        // Check if the parameters are valid.
        Object[] arguments = getInquiryArgumentType((DWLTransactionInquiry)transaction);
    if (arguments!=null && arguments.length>0) {
            // MDM_TODO0: CDKWB0003I Add argument validation logic
    }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction addXCustomerVehicleKOR.
     *
     * @param theBObj
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleAddXCustomerVehicleKOR
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.ADD_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.INSERT_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.ADDXCUSTOMERVEHICLEKOR_FAILED
    )
     public DWLResponse addXCustomerVehicleKOR(XCustomerVehicleKORBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER addXCustomerVehicleKOR(XCustomerVehicleKORBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("addXCustomerVehicleKOR", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction addXCustomerVehicleKOR.";
      logger.finest("addXCustomerVehicleKOR(XCustomerVehicleKORBObj theBObj) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction addXCustomerVehicleKOR.";
      logger.finest("addXCustomerVehicleKOR(XCustomerVehicleKORBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN addXCustomerVehicleKOR(XCustomerVehicleKORBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Adds a XCustomerVehicleKOR to the database.
     *
     * @param theXCustomerVehicleKORBObj
     *     The object that contains XCustomerVehicleKOR attribute values.
     * @return
     *     DWLResponse containing a XCustomerVehicleKORBObj object.
     * @exception Exception
     * @generated NOT
     */
    public DWLResponse handleAddXCustomerVehicleKOR(XCustomerVehicleKORBObj theXCustomerVehicleKORBObj) throws Exception {
        DWLResponse response = null;
        DWLStatus status = theXCustomerVehicleKORBObj.getStatus();
        if (status == null) {
            status = new DWLStatus();
            theXCustomerVehicleKORBObj.setStatus(status);
        }
        XVehicleKORBObj childXVehicleKORBObj = theXCustomerVehicleKORBObj.getXVehicleKORBObj();
    	String containedPk = null;

        if( childXVehicleKORBObj != null &&  childXVehicleKORBObj.getXVehicleKORpkId()==null){
        	
            addXVehicleKOR(childXVehicleKORBObj);
            containedPk = childXVehicleKORBObj.getXVehicleKORpkId ();
            theXCustomerVehicleKORBObj.setVehicleId( containedPk );
   	     	theXCustomerVehicleKORBObj.setXVehicleKORBObj(childXVehicleKORBObj);
        }else{
        	
        }

        /*IGroupElementService theGroupElementService = GroupElementServiceHelper.getGroupElementService();
        Group group = theGroupElementService.getGroup(theXCustomerVehicleKORBObj.getClass().getName());
        theXCustomerVehicleKORBObj.setGroupName(group.getGroupName());
*/
        String strPluggableID = null;

        try {
            // Pluggable Key Structure implementation
            strPluggableID = getSuppliedIdPKFromBObj(theXCustomerVehicleKORBObj);

            if ((strPluggableID != null) && (strPluggableID.length() > 0)) {
                theXCustomerVehicleKORBObj.getEObjXCustomerVehicleKOR().setXCustomerVehicleKORpkId(FunctionUtils.getLongFromString(strPluggableID));
            } else {
                strPluggableID = null;
                theXCustomerVehicleKORBObj.getEObjXCustomerVehicleKOR().setXCustomerVehicleKORpkId(null);
            }
         Persistence theXCustomerVehicleKORBObjPersistence = getBObjPersistenceFactory().createXCustomerVehicleKORBObjPersistence(XCustomerVehicleKORBObjQuery.XCUSTOMER_VEHICLE_KOR_ADD, theXCustomerVehicleKORBObj);
         theXCustomerVehicleKORBObjPersistence.persistAdd();

            String pkId = DWLFunctionUtils.getStringFromLong(theXCustomerVehicleKORBObj.getEObjXCustomerVehicleKOR().getXCustomerVehicleKORpkId());

            @SuppressWarnings("rawtypes")
            Vector vecXCustomerVehicleRoleKORBObj = theXCustomerVehicleKORBObj.getItemsXCustomerVehicleRoleKORBObj();
            for (int i = 0; i < vecXCustomerVehicleRoleKORBObj.size(); i++) {
                XCustomerVehicleRoleKORBObj object = (XCustomerVehicleRoleKORBObj)vecXCustomerVehicleRoleKORBObj.elementAt(i);
                object.setCustomerVehicleId(pkId);
                addXCustomerVehicleRoleKOR(object);
            }
            response = new DWLResponse();
            response.setData(theXCustomerVehicleKORBObj);
            response.setStatus(theXCustomerVehicleKORBObj.getStatus());
    } catch (Exception ex) {
 				TCRMExceptionUtils.throwTCRMException(ex, new TCRMInsertException(ex.getMessage()), status,
                    DWLStatus.FATAL, DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_COMPONENT, TCRMErrorCode.INSERT_RECORD_ERROR,
                    DSEAAdditionsExtsErrorReasonCode.ADDXCUSTOMERVEHICLEKOR_FAILED, theXCustomerVehicleKORBObj.getControl(), errHandler);
        }
        
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction updateXCustomerVehicleKOR.
     *
     * @param theBObj
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleUpdateXCustomerVehicleKOR
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.UPDATE_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.UPDATE_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.UPDATEXCUSTOMERVEHICLEKOR_FAILED
    , manuallyHandleRedundantUpdateCheck="true"
    )
     public DWLResponse updateXCustomerVehicleKOR(XCustomerVehicleKORBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER updateXCustomerVehicleKOR(XCustomerVehicleKORBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("updateXCustomerVehicleKOR", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction updateXCustomerVehicleKOR.";
      logger.finest("updateXCustomerVehicleKOR(XCustomerVehicleKORBObj theBObj) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction updateXCustomerVehicleKOR.";
      logger.finest("updateXCustomerVehicleKOR(XCustomerVehicleKORBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN updateXCustomerVehicleKOR(XCustomerVehicleKORBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Updates the specified XCustomerVehicleKOR with new attribute values.
     *
     * @param theXCustomerVehicleKORBObj
     *     The object that contains XCustomerVehicleKOR attribute values to be
     *     updated
     * @return
     *     DWLResponse containing a XCustomerVehicleKORBObj of the updated
     *     object.
     * @exception Exception
     * @generated
     */
    public DWLResponse handleUpdateXCustomerVehicleKOR(XCustomerVehicleKORBObj theXCustomerVehicleKORBObj) throws Exception {

        DWLStatus status = theXCustomerVehicleKORBObj.getStatus();

        if (status == null) {
            status = new DWLStatus();
            theXCustomerVehicleKORBObj.setStatus(status);
        }
        
    if( !theXCustomerVehicleKORBObj.isRedundantUpdate() ){
            // set lastupdatetxid with txnid from dwlcontrol
            theXCustomerVehicleKORBObj.getEObjXCustomerVehicleKOR().setLastUpdateTxId(new Long(theXCustomerVehicleKORBObj.getControl().getTxnId()));
            Persistence theXCustomerVehicleKORBObjPersistence = getBObjPersistenceFactory().createXCustomerVehicleKORBObjPersistence(XCustomerVehicleKORBObjQuery.XCUSTOMER_VEHICLE_KOR_UPDATE, theXCustomerVehicleKORBObj);
            theXCustomerVehicleKORBObjPersistence.persistUpdate();
        }

    String pkId = theXCustomerVehicleKORBObj.getXCustomerVehicleKORpkId();			

    @SuppressWarnings("rawtypes")
    Vector vecXCustomerVehicleRoleKORBObj = theXCustomerVehicleKORBObj.getItemsXCustomerVehicleRoleKORBObj();
    for (int i = 0; i < vecXCustomerVehicleRoleKORBObj.size(); i++) {
      XCustomerVehicleRoleKORBObj object = (XCustomerVehicleRoleKORBObj)vecXCustomerVehicleRoleKORBObj.elementAt(i);
      
      String ref = object.getCustomerVehicleId();
      if (ref != null && !ref.equals(pkId)) {
        TCRMExceptionUtils.throwTCRMException(null, new TCRMDataInvalidException(),
          status,
          DWLStatus.FATAL,
          DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_KORBOBJ,
          TCRMErrorCode.DATA_INVALID_ERROR,
          DSEAAdditionsExtsErrorReasonCode.XCUSTOMERVEHICLEKOR_XCUSTOMERVEHICLEROLEKOR_REFERENCE_INVALID,
          theXCustomerVehicleKORBObj.getControl(),
          errHandler);
      }
      
      object.setCustomerVehicleId(pkId);
      
      if (object.getEObjXCustomerVehicleRoleKOR().getPrimaryKey() == null){
        addXCustomerVehicleRoleKOR(object);
      } else {
        updateXCustomerVehicleRoleKOR(object);
      }
    }
        DWLResponse response = createDWLResponse();
        response.setData(theXCustomerVehicleKORBObj);
        response.setStatus(theXCustomerVehicleKORBObj.getStatus());

        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXCustomerVehicleRoleKOR.
     *
     * @param XCustomerVehicleRoleKORpkId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetXCustomerVehicleRoleKOR
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETXCUSTOMERVEHICLEROLEKOR_FAILED,
       beforePreExecuteMethod = "beforePreExecuteGetXCustomerVehicleRoleKOR"
    )
     public DWLResponse getXCustomerVehicleRoleKOR(String XCustomerVehicleRoleKORpkId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getXCustomerVehicleRoleKOR(String XCustomerVehicleRoleKORpkId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(XCustomerVehicleRoleKORpkId);
        DWLTransaction txObj = new  DWLTransactionInquiry("getXCustomerVehicleRoleKOR", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction getXCustomerVehicleRoleKOR.";
      logger.finest("getXCustomerVehicleRoleKOR(String XCustomerVehicleRoleKORpkId,  DWLControl control) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction getXCustomerVehicleRoleKOR.";
      logger.finest("getXCustomerVehicleRoleKOR(String XCustomerVehicleRoleKORpkId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getXCustomerVehicleRoleKOR(String XCustomerVehicleRoleKORpkId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets a XCustomerVehicleRoleKOR from the database.
     * 
     * @generated
     */
    public DWLResponse handleGetXCustomerVehicleRoleKOR(String XCustomerVehicleRoleKORpkId,  DWLControl control) throws Exception {
        DWLStatus status = new DWLStatus();
        DWLResponse response = createDWLResponse();
        
        BObjQuery bObjQuery = null;
           
        String asOfDate = (String) control.get(DWLControl.INQUIRE_AS_OF_DATE);

        // History data inquiry: if inquireAsOfDate field has value in request xml 
        if (StringUtils.isNonBlank(asOfDate)) {
            Timestamp tsAsOfDate = getPITHistoryDate(asOfDate, DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_COMPONENT,
                                                     DSEAAdditionsExtsErrorReasonCode.GETXCUSTOMERVEHICLEROLEKOR_INVALID_INQUIRE_AS_OF_DATE_FORMAT,
                                                     status, control);

            bObjQuery = getBObjQueryFactory().createXCustomerVehicleRoleKORBObjQuery(XCustomerVehicleRoleKORBObjQuery.XCUSTOMER_VEHICLE_ROLE_KOR_HISTORY_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(XCustomerVehicleRoleKORpkId));
            bObjQuery.setParameter(1, tsAsOfDate);
            bObjQuery.setParameter(2, tsAsOfDate);
        } else {
            bObjQuery = getBObjQueryFactory().createXCustomerVehicleRoleKORBObjQuery(XCustomerVehicleRoleKORBObjQuery.XCUSTOMER_VEHICLE_ROLE_KOR_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(XCustomerVehicleRoleKORpkId));
        }


        XCustomerVehicleRoleKORBObj o = (XCustomerVehicleRoleKORBObj) bObjQuery.getSingleResult();
        if( o == null ){
        	return null;
        } 
        postRetrieveXCustomerVehicleRoleKORBObj(o, "0", "ALL", control); 
          
        if (o.getStatus()==null) {
            o.setStatus(status);
        }
        response.addStatus(o.getStatus());
        response.setData(o);

      return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public void beforePreExecuteGetXCustomerVehicleRoleKOR(DWLTransaction transaction) throws DWLBaseException{
        // Check if the parameters are valid.
        Object[] arguments = getInquiryArgumentType((DWLTransactionInquiry)transaction);
        String pk = null;
        if (arguments!=null && arguments.length>0) {
            pk = (String)arguments[0];
        }
        // Check if the parameter passed in exists.
        if ((pk == null) || (pk.trim().length() == 0)) {
            TCRMExceptionUtils.throwTCRMException(null, new TCRMReadException(), transaction.getStatus(), DWLStatus.FATAL,
                DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_ROLE_KORBOBJ,
                TCRMErrorCode.FIELD_VALIDATION_ERROR,
                DSEAAdditionsExtsErrorReasonCode.XCUSTOMERVEHICLEROLEKOR_XCUSTOMERVEHICLEROLEKORPKID_NULL,
                transaction.getTxnControl(), errHandler);
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getAllVehicleRoleByCustomerVehicleKORId.
     *
     * @param CustomerVehicleId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetAllVehicleRoleByCustomerVehicleKORId
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETALLVEHICLEROLEBYCUSTOMERVEHICLEKORID_FAILED,
       beforePreExecuteMethod = "beforePreExecuteGetAllVehicleRoleByCustomerVehicleKORId"
    )
     public DWLResponse getAllVehicleRoleByCustomerVehicleKORId(String CustomerVehicleId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getAllVehicleRoleByCustomerVehicleKORId(String CustomerVehicleId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(CustomerVehicleId);
        DWLTransaction txObj = new  DWLTransactionInquiry("getAllVehicleRoleByCustomerVehicleKORId", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction getAllVehicleRoleByCustomerVehicleKORId.";
      logger.finest("getAllVehicleRoleByCustomerVehicleKORId(String CustomerVehicleId,  DWLControl control) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction getAllVehicleRoleByCustomerVehicleKORId.";
      logger.finest("getAllVehicleRoleByCustomerVehicleKORId(String CustomerVehicleId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getAllVehicleRoleByCustomerVehicleKORId(String CustomerVehicleId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets a XCustomerVehicleRoleKOR from the database.
     * 
     * @generated
     */
    public DWLResponse handleGetAllVehicleRoleByCustomerVehicleKORId(String CustomerVehicleId,  DWLControl control) throws Exception {
        DWLStatus status = new DWLStatus();
        DWLResponse response = createDWLResponse();
        
        BObjQuery bObjQuery = null;
           
        String asOfDate = (String) control.get(DWLControl.INQUIRE_AS_OF_DATE);

        // History data inquiry: if inquireAsOfDate field has value in request xml 
        if (StringUtils.isNonBlank(asOfDate)) {
            Timestamp tsAsOfDate = getPITHistoryDate(asOfDate, DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_COMPONENT,
                                                     DSEAAdditionsExtsErrorReasonCode.GETALLVEHICLEROLEBYCUSTOMERVEHICLEKORID_INVALID_INQUIRE_AS_OF_DATE_FORMAT,
                                                     status, control);

            bObjQuery = getBObjQueryFactory().createXCustomerVehicleRoleKORBObjQuery(XCustomerVehicleRoleKORBObjQuery.ALL_VEHICLE_ROLE_BY_CUSTOMER_VEHICLE_KORID_HISTORY_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(CustomerVehicleId));
            bObjQuery.setParameter(1, tsAsOfDate);
            bObjQuery.setParameter(2, tsAsOfDate);
        } else {
            bObjQuery = getBObjQueryFactory().createXCustomerVehicleRoleKORBObjQuery(XCustomerVehicleRoleKORBObjQuery.ALL_VEHICLE_ROLE_BY_CUSTOMER_VEHICLE_KORID_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(CustomerVehicleId));
        }

        boolean considerForPagination = PaginationUtils
                            .considerForPagintion(XCustomerVehicleRoleKORBObj.class.getName(), control);
        control.setConsiderForPagintionFlag(considerForPagination);

        // set returned object
        List<?> list = bObjQuery.getResults();

        if (list.size() == 0) {
            return null;
        }
    Vector<XCustomerVehicleRoleKORBObj> vector = new Vector<XCustomerVehicleRoleKORBObj>();
        for (Iterator<?> it = list.iterator(); it.hasNext();) {
            XCustomerVehicleRoleKORBObj o = (XCustomerVehicleRoleKORBObj) it.next();
            postRetrieveXCustomerVehicleRoleKORBObj(o, "0", "ALL", control); 
            vector.add(o);
          
            if (o.getStatus()==null) {
                o.setStatus(status);
            }
            response.addStatus(o.getStatus());
        }
        response.setData(vector);

      return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public void beforePreExecuteGetAllVehicleRoleByCustomerVehicleKORId(DWLTransaction transaction) throws DWLBaseException{
        // Check if the parameters are valid.
        Object[] arguments = getInquiryArgumentType((DWLTransactionInquiry)transaction);
    if (arguments!=null && arguments.length>0) {
            // MDM_TODO0: CDKWB0003I Add argument validation logic
    }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction addXCustomerVehicleRoleKOR.
     *
     * @param theBObj
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleAddXCustomerVehicleRoleKOR
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.ADD_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.INSERT_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.ADDXCUSTOMERVEHICLEROLEKOR_FAILED
    )
     public DWLResponse addXCustomerVehicleRoleKOR(XCustomerVehicleRoleKORBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER addXCustomerVehicleRoleKOR(XCustomerVehicleRoleKORBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("addXCustomerVehicleRoleKOR", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction addXCustomerVehicleRoleKOR.";
      logger.finest("addXCustomerVehicleRoleKOR(XCustomerVehicleRoleKORBObj theBObj) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction addXCustomerVehicleRoleKOR.";
      logger.finest("addXCustomerVehicleRoleKOR(XCustomerVehicleRoleKORBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN addXCustomerVehicleRoleKOR(XCustomerVehicleRoleKORBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Adds a XCustomerVehicleRoleKOR to the database.
     *
     * @param theXCustomerVehicleRoleKORBObj
     *     The object that contains XCustomerVehicleRoleKOR attribute values.
     * @return
     *     DWLResponse containing a XCustomerVehicleRoleKORBObj object.
     * @exception Exception
     * @generated
     */
    public DWLResponse handleAddXCustomerVehicleRoleKOR(XCustomerVehicleRoleKORBObj theXCustomerVehicleRoleKORBObj) throws Exception {
        DWLResponse response = null;
        DWLStatus status = theXCustomerVehicleRoleKORBObj.getStatus();
        if (status == null) {
            status = new DWLStatus();
            theXCustomerVehicleRoleKORBObj.setStatus(status);
        }

        String strPluggableID = null;

        try {
            // Pluggable Key Structure implementation
            strPluggableID = getSuppliedIdPKFromBObj(theXCustomerVehicleRoleKORBObj);

            if ((strPluggableID != null) && (strPluggableID.length() > 0)) {
                theXCustomerVehicleRoleKORBObj.getEObjXCustomerVehicleRoleKOR().setXCustomerVehicleRoleKORpkId(FunctionUtils.getLongFromString(strPluggableID));
            } else {
                strPluggableID = null;
                theXCustomerVehicleRoleKORBObj.getEObjXCustomerVehicleRoleKOR().setXCustomerVehicleRoleKORpkId(null);
            }
         Persistence theXCustomerVehicleRoleKORBObjPersistence = getBObjPersistenceFactory().createXCustomerVehicleRoleKORBObjPersistence(XCustomerVehicleRoleKORBObjQuery.XCUSTOMER_VEHICLE_ROLE_KOR_ADD, theXCustomerVehicleRoleKORBObj);
         theXCustomerVehicleRoleKORBObjPersistence.persistAdd();

            response = new DWLResponse();
            response.setData(theXCustomerVehicleRoleKORBObj);
            response.setStatus(theXCustomerVehicleRoleKORBObj.getStatus());
    } catch (Exception ex) {
 				TCRMExceptionUtils.throwTCRMException(ex, new TCRMInsertException(ex.getMessage()), status,
                    DWLStatus.FATAL, DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_COMPONENT, TCRMErrorCode.INSERT_RECORD_ERROR,
                    DSEAAdditionsExtsErrorReasonCode.ADDXCUSTOMERVEHICLEROLEKOR_FAILED, theXCustomerVehicleRoleKORBObj.getControl(), errHandler);
        }
        
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction updateXCustomerVehicleRoleKOR.
     *
     * @param theBObj
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleUpdateXCustomerVehicleRoleKOR
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.UPDATE_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.UPDATE_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.UPDATEXCUSTOMERVEHICLEROLEKOR_FAILED
    )
     public DWLResponse updateXCustomerVehicleRoleKOR(XCustomerVehicleRoleKORBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER updateXCustomerVehicleRoleKOR(XCustomerVehicleRoleKORBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("updateXCustomerVehicleRoleKOR", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction updateXCustomerVehicleRoleKOR.";
      logger.finest("updateXCustomerVehicleRoleKOR(XCustomerVehicleRoleKORBObj theBObj) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction updateXCustomerVehicleRoleKOR.";
      logger.finest("updateXCustomerVehicleRoleKOR(XCustomerVehicleRoleKORBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN updateXCustomerVehicleRoleKOR(XCustomerVehicleRoleKORBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Updates the specified XCustomerVehicleRoleKOR with new attribute values.
     *
     * @param theXCustomerVehicleRoleKORBObj
     *     The object that contains XCustomerVehicleRoleKOR attribute values to
     *     be updated
     * @return
     *     DWLResponse containing a XCustomerVehicleRoleKORBObj of the updated
     *     object.
     * @exception Exception
     * @generated
     */
    public DWLResponse handleUpdateXCustomerVehicleRoleKOR(XCustomerVehicleRoleKORBObj theXCustomerVehicleRoleKORBObj) throws Exception {

        DWLStatus status = theXCustomerVehicleRoleKORBObj.getStatus();

        if (status == null) {
            status = new DWLStatus();
            theXCustomerVehicleRoleKORBObj.setStatus(status);
        }
        
            // set lastupdatetxid with txnid from dwlcontrol
            theXCustomerVehicleRoleKORBObj.getEObjXCustomerVehicleRoleKOR().setLastUpdateTxId(new Long(theXCustomerVehicleRoleKORBObj.getControl().getTxnId()));
         Persistence theXCustomerVehicleRoleKORBObjPersistence = getBObjPersistenceFactory().createXCustomerVehicleRoleKORBObjPersistence(XCustomerVehicleRoleKORBObjQuery.XCUSTOMER_VEHICLE_ROLE_KOR_UPDATE, theXCustomerVehicleRoleKORBObj);
         theXCustomerVehicleRoleKORBObjPersistence.persistUpdate();

        DWLResponse response = createDWLResponse();
        response.setData(theXCustomerVehicleRoleKORBObj);
        response.setStatus(theXCustomerVehicleRoleKORBObj.getStatus());

        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXEpucidTemp.
     *
     * @param XEpucidTemppkId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetXEpucidTemp
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETXEPUCIDTEMP_FAILED,
       beforePreExecuteMethod = "beforePreExecuteGetXEpucidTemp"
    )
     public DWLResponse getXEpucidTemp(String XEpucidTemppkId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getXEpucidTemp(String XEpucidTemppkId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(XEpucidTemppkId);
        DWLTransaction txObj = new  DWLTransactionInquiry("getXEpucidTemp", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction getXEpucidTemp.";
      logger.finest("getXEpucidTemp(String XEpucidTemppkId,  DWLControl control) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction getXEpucidTemp.";
      logger.finest("getXEpucidTemp(String XEpucidTemppkId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getXEpucidTemp(String XEpucidTemppkId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets a XEpucidTemp from the database.
     * 
     * @generated
     */
    public DWLResponse handleGetXEpucidTemp(String XEpucidTemppkId,  DWLControl control) throws Exception {
        DWLStatus status = new DWLStatus();
        DWLResponse response = createDWLResponse();
        
        BObjQuery bObjQuery = null;
           
        String asOfDate = (String) control.get(DWLControl.INQUIRE_AS_OF_DATE);

        // History data inquiry: if inquireAsOfDate field has value in request xml 
        if (StringUtils.isNonBlank(asOfDate)) {
            Timestamp tsAsOfDate = getPITHistoryDate(asOfDate, DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_COMPONENT,
                                                     DSEAAdditionsExtsErrorReasonCode.GETXEPUCIDTEMP_INVALID_INQUIRE_AS_OF_DATE_FORMAT,
                                                     status, control);

            bObjQuery = getBObjQueryFactory().createXEpucidTempBObjQuery(XEpucidTempBObjQuery.XEPUCID_TEMP_HISTORY_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(XEpucidTemppkId));
            bObjQuery.setParameter(1, tsAsOfDate);
            bObjQuery.setParameter(2, tsAsOfDate);
        } else {
            bObjQuery = getBObjQueryFactory().createXEpucidTempBObjQuery(XEpucidTempBObjQuery.XEPUCID_TEMP_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(XEpucidTemppkId));
        }


        XEpucidTempBObj o = (XEpucidTempBObj) bObjQuery.getSingleResult();
        if( o == null ){
        	return null;
        } 
          
        if (o.getStatus()==null) {
            o.setStatus(status);
        }
        response.addStatus(o.getStatus());
        response.setData(o);

      return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public void beforePreExecuteGetXEpucidTemp(DWLTransaction transaction) throws DWLBaseException{
        // Check if the parameters are valid.
        Object[] arguments = getInquiryArgumentType((DWLTransactionInquiry)transaction);
        String pk = null;
        if (arguments!=null && arguments.length>0) {
            pk = (String)arguments[0];
        }
        // Check if the parameter passed in exists.
        if ((pk == null) || (pk.trim().length() == 0)) {
            TCRMExceptionUtils.throwTCRMException(null, new TCRMReadException(), transaction.getStatus(), DWLStatus.FATAL,
                DSEAAdditionsExtsComponentID.XEPUCID_TEMP_BOBJ,
                TCRMErrorCode.FIELD_VALIDATION_ERROR,
                DSEAAdditionsExtsErrorReasonCode.XEPUCIDTEMP_XEPUCIDTEMPPKID_NULL,
                transaction.getTxnControl(), errHandler);
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction addXEpucidTemp.
     *
     * @param theBObj
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleAddXEpucidTemp
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.ADD_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.INSERT_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.ADDXEPUCIDTEMP_FAILED
    )
     public DWLResponse addXEpucidTemp(XEpucidTempBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER addXEpucidTemp(XEpucidTempBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("addXEpucidTemp", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction addXEpucidTemp.";
      logger.finest("addXEpucidTemp(XEpucidTempBObj theBObj) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction addXEpucidTemp.";
      logger.finest("addXEpucidTemp(XEpucidTempBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN addXEpucidTemp(XEpucidTempBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Adds a XEpucidTemp to the database.
     *
     * @param theXEpucidTempBObj
     *     The object that contains XEpucidTemp attribute values.
     * @return
     *     DWLResponse containing a XEpucidTempBObj object.
     * @exception Exception
     * @generated
     */
    public DWLResponse handleAddXEpucidTemp(XEpucidTempBObj theXEpucidTempBObj) throws Exception {
        DWLResponse response = null;
        DWLStatus status = theXEpucidTempBObj.getStatus();
        if (status == null) {
            status = new DWLStatus();
            theXEpucidTempBObj.setStatus(status);
        }

        String strPluggableID = null;

        try {
            // Pluggable Key Structure implementation
            strPluggableID = getSuppliedIdPKFromBObj(theXEpucidTempBObj);

            if ((strPluggableID != null) && (strPluggableID.length() > 0)) {
                theXEpucidTempBObj.getEObjXEpucidTemp().setXEpucidTemppkId(FunctionUtils.getLongFromString(strPluggableID));
            } else {
                strPluggableID = null;
                theXEpucidTempBObj.getEObjXEpucidTemp().setXEpucidTemppkId(null);
            }
         Persistence theXEpucidTempBObjPersistence = getBObjPersistenceFactory().createXEpucidTempBObjPersistence(XEpucidTempBObjQuery.XEPUCID_TEMP_ADD, theXEpucidTempBObj);
         theXEpucidTempBObjPersistence.persistAdd();

            response = new DWLResponse();
            response.setData(theXEpucidTempBObj);
            response.setStatus(theXEpucidTempBObj.getStatus());
    } catch (Exception ex) {
 				TCRMExceptionUtils.throwTCRMException(ex, new TCRMInsertException(ex.getMessage()), status,
                    DWLStatus.FATAL, DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_COMPONENT, TCRMErrorCode.INSERT_RECORD_ERROR,
                    DSEAAdditionsExtsErrorReasonCode.ADDXEPUCIDTEMP_FAILED, theXEpucidTempBObj.getControl(), errHandler);
        }
        
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction updateXEpucidTemp.
     *
     * @param theBObj
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleUpdateXEpucidTemp
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.UPDATE_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.UPDATE_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.UPDATEXEPUCIDTEMP_FAILED
    )
     public DWLResponse updateXEpucidTemp(XEpucidTempBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER updateXEpucidTemp(XEpucidTempBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("updateXEpucidTemp", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction updateXEpucidTemp.";
      logger.finest("updateXEpucidTemp(XEpucidTempBObj theBObj) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction updateXEpucidTemp.";
      logger.finest("updateXEpucidTemp(XEpucidTempBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN updateXEpucidTemp(XEpucidTempBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Updates the specified XEpucidTemp with new attribute values.
     *
     * @param theXEpucidTempBObj
     *     The object that contains XEpucidTemp attribute values to be updated
     * @return
     *     DWLResponse containing a XEpucidTempBObj of the updated object.
     * @exception Exception
     * @generated
     */
    public DWLResponse handleUpdateXEpucidTemp(XEpucidTempBObj theXEpucidTempBObj) throws Exception {

        DWLStatus status = theXEpucidTempBObj.getStatus();

        if (status == null) {
            status = new DWLStatus();
            theXEpucidTempBObj.setStatus(status);
        }
        
            // set lastupdatetxid with txnid from dwlcontrol
            theXEpucidTempBObj.getEObjXEpucidTemp().setLastUpdateTxId(new Long(theXEpucidTempBObj.getControl().getTxnId()));
         Persistence theXEpucidTempBObjPersistence = getBObjPersistenceFactory().createXEpucidTempBObjPersistence(XEpucidTempBObjQuery.XEPUCID_TEMP_UPDATE, theXEpucidTempBObj);
         theXEpucidTempBObjPersistence.persistUpdate();

        DWLResponse response = createDWLResponse();
        response.setData(theXEpucidTempBObj);
        response.setStatus(theXEpucidTempBObj.getStatus());

        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXContractDetailsJPN.
     *
     * @param XContractJPNpkId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetXContractDetailsJPN
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETXCONTRACTDETAILSJPN_FAILED,
       beforePreExecuteMethod = "beforePreExecuteGetXContractDetailsJPN"
    )
     public DWLResponse getXContractDetailsJPN(String XContractJPNpkId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getXContractDetailsJPN(String XContractJPNpkId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(XContractJPNpkId);
        DWLTransaction txObj = new  DWLTransactionInquiry("getXContractDetailsJPN", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction getXContractDetailsJPN.";
      logger.finest("getXContractDetailsJPN(String XContractJPNpkId,  DWLControl control) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction getXContractDetailsJPN.";
      logger.finest("getXContractDetailsJPN(String XContractJPNpkId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getXContractDetailsJPN(String XContractJPNpkId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets a XContractDetailsJPN from the database.
     * 
     * @generated
     */
    public DWLResponse handleGetXContractDetailsJPN(String XContractJPNpkId,  DWLControl control) throws Exception {
        DWLStatus status = new DWLStatus();
        DWLResponse response = createDWLResponse();
        
        BObjQuery bObjQuery = null;
           
        String asOfDate = (String) control.get(DWLControl.INQUIRE_AS_OF_DATE);

        // History data inquiry: if inquireAsOfDate field has value in request xml 
        if (StringUtils.isNonBlank(asOfDate)) {
            Timestamp tsAsOfDate = getPITHistoryDate(asOfDate, DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_COMPONENT,
                                                     DSEAAdditionsExtsErrorReasonCode.GETXCONTRACTDETAILSJPN_INVALID_INQUIRE_AS_OF_DATE_FORMAT,
                                                     status, control);

            bObjQuery = getBObjQueryFactory().createXContractDetailsJPNBObjQuery(XContractDetailsJPNBObjQuery.XCONTRACT_DETAILS_JPN_HISTORY_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(XContractJPNpkId));
            bObjQuery.setParameter(1, tsAsOfDate);
            bObjQuery.setParameter(2, tsAsOfDate);
        } else {
            bObjQuery = getBObjQueryFactory().createXContractDetailsJPNBObjQuery(XContractDetailsJPNBObjQuery.XCONTRACT_DETAILS_JPN_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(XContractJPNpkId));
        }


        XContractDetailsJPNBObj o = (XContractDetailsJPNBObj) bObjQuery.getSingleResult();
        if( o == null ){
        	return null;
        } 
        postRetrieveXContractDetailsJPNBObj(o, "0", "ALL", control); 
          
        if (o.getStatus()==null) {
            o.setStatus(status);
        }
        response.addStatus(o.getStatus());
        response.setData(o);

      return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public void beforePreExecuteGetXContractDetailsJPN(DWLTransaction transaction) throws DWLBaseException{
        // Check if the parameters are valid.
        Object[] arguments = getInquiryArgumentType((DWLTransactionInquiry)transaction);
        String pk = null;
        if (arguments!=null && arguments.length>0) {
            pk = (String)arguments[0];
        }
        // Check if the parameter passed in exists.
        if ((pk == null) || (pk.trim().length() == 0)) {
            TCRMExceptionUtils.throwTCRMException(null, new TCRMReadException(), transaction.getStatus(), DWLStatus.FATAL,
                DSEAAdditionsExtsComponentID.XCONTRACT_DETAILS_JPNBOBJ,
                TCRMErrorCode.FIELD_VALIDATION_ERROR,
                DSEAAdditionsExtsErrorReasonCode.XCONTRACTDETAILSJPN_XCONTRACTJPNPKID_NULL,
                transaction.getTxnControl(), errHandler);
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getAllXContractDetailsJPNByPartyId.
     *
     * @param ContId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetAllXContractDetailsJPNByPartyId
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETALLXCONTRACTDETAILSJPNBYPARTYID_FAILED,
       beforePreExecuteMethod = "beforePreExecuteGetAllXContractDetailsJPNByPartyId"
    )
     public DWLResponse getAllXContractDetailsJPNByPartyId(String ContId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getAllXContractDetailsJPNByPartyId(String ContId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(ContId);
        DWLTransaction txObj = new  DWLTransactionInquiry("getAllXContractDetailsJPNByPartyId", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction getAllXContractDetailsJPNByPartyId.";
      logger.finest("getAllXContractDetailsJPNByPartyId(String ContId,  DWLControl control) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction getAllXContractDetailsJPNByPartyId.";
      logger.finest("getAllXContractDetailsJPNByPartyId(String ContId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getAllXContractDetailsJPNByPartyId(String ContId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets a XContractDetailsJPN from the database.
     * 
     * @generated
     */
    public DWLResponse handleGetAllXContractDetailsJPNByPartyId(String ContId,  DWLControl control) throws Exception {
        DWLStatus status = new DWLStatus();
        DWLResponse response = createDWLResponse();
        
        BObjQuery bObjQuery = null;
           
        String asOfDate = (String) control.get(DWLControl.INQUIRE_AS_OF_DATE);

        // History data inquiry: if inquireAsOfDate field has value in request xml 
        if (StringUtils.isNonBlank(asOfDate)) {
            Timestamp tsAsOfDate = getPITHistoryDate(asOfDate, DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_COMPONENT,
                                                     DSEAAdditionsExtsErrorReasonCode.GETALLXCONTRACTDETAILSJPNBYPARTYID_INVALID_INQUIRE_AS_OF_DATE_FORMAT,
                                                     status, control);

            bObjQuery = getBObjQueryFactory().createXContractDetailsJPNBObjQuery(XContractDetailsJPNBObjQuery.ALL_XCONTRACT_DETAILS_JPNBY_PARTY_ID_HISTORY_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(ContId));
            bObjQuery.setParameter(1, tsAsOfDate);
            bObjQuery.setParameter(2, tsAsOfDate);
        } else {
            bObjQuery = getBObjQueryFactory().createXContractDetailsJPNBObjQuery(XContractDetailsJPNBObjQuery.ALL_XCONTRACT_DETAILS_JPNBY_PARTY_ID_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(ContId));
        }

        boolean considerForPagination = PaginationUtils
                            .considerForPagintion(XContractDetailsJPNBObj.class.getName(), control);
        control.setConsiderForPagintionFlag(considerForPagination);

        // set returned object
        List<?> list = bObjQuery.getResults();

        if (list.size() == 0) {
            return null;
        }
    Vector<XContractDetailsJPNBObj> vector = new Vector<XContractDetailsJPNBObj>();
        for (Iterator<?> it = list.iterator(); it.hasNext();) {
            XContractDetailsJPNBObj o = (XContractDetailsJPNBObj) it.next();
            postRetrieveXContractDetailsJPNBObj(o, "0", "ALL", control); 
            vector.add(o);
          
            if (o.getStatus()==null) {
                o.setStatus(status);
            }
            response.addStatus(o.getStatus());
        }
        response.setData(vector);

      return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public void beforePreExecuteGetAllXContractDetailsJPNByPartyId(DWLTransaction transaction) throws DWLBaseException{
        // Check if the parameters are valid.
        Object[] arguments = getInquiryArgumentType((DWLTransactionInquiry)transaction);
    if (arguments!=null && arguments.length>0) {
            // MDM_TODO0: CDKWB0003I Add argument validation logic
    }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction addXContractDetailsJPN.
     *
     * @param theBObj
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleAddXContractDetailsJPN
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.ADD_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.INSERT_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.ADDXCONTRACTDETAILSJPN_FAILED
    )
     public DWLResponse addXContractDetailsJPN(XContractDetailsJPNBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER addXContractDetailsJPN(XContractDetailsJPNBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("addXContractDetailsJPN", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction addXContractDetailsJPN.";
      logger.finest("addXContractDetailsJPN(XContractDetailsJPNBObj theBObj) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction addXContractDetailsJPN.";
      logger.finest("addXContractDetailsJPN(XContractDetailsJPNBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN addXContractDetailsJPN(XContractDetailsJPNBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Adds a XContractDetailsJPN to the database.
     *
     * @param theXContractDetailsJPNBObj
     *     The object that contains XContractDetailsJPN attribute values.
     * @return
     *     DWLResponse containing a XContractDetailsJPNBObj object.
     * @exception Exception
     * @generated
     */
    public DWLResponse handleAddXContractDetailsJPN(XContractDetailsJPNBObj theXContractDetailsJPNBObj) throws Exception {
        DWLResponse response = null;
        DWLStatus status = theXContractDetailsJPNBObj.getStatus();
        if (status == null) {
            status = new DWLStatus();
            theXContractDetailsJPNBObj.setStatus(status);
        }

        String strPluggableID = null;

        try {
            // Pluggable Key Structure implementation
            strPluggableID = getSuppliedIdPKFromBObj(theXContractDetailsJPNBObj);

            if ((strPluggableID != null) && (strPluggableID.length() > 0)) {
                theXContractDetailsJPNBObj.getEObjXContractDetailsJPN().setXContractJPNpkId(FunctionUtils.getLongFromString(strPluggableID));
            } else {
                strPluggableID = null;
                theXContractDetailsJPNBObj.getEObjXContractDetailsJPN().setXContractJPNpkId(null);
            }
         Persistence theXContractDetailsJPNBObjPersistence = getBObjPersistenceFactory().createXContractDetailsJPNBObjPersistence(XContractDetailsJPNBObjQuery.XCONTRACT_DETAILS_JPN_ADD, theXContractDetailsJPNBObj);
         theXContractDetailsJPNBObjPersistence.persistAdd();

            response = new DWLResponse();
            response.setData(theXContractDetailsJPNBObj);
            response.setStatus(theXContractDetailsJPNBObj.getStatus());
    } catch (Exception ex) {
 				TCRMExceptionUtils.throwTCRMException(ex, new TCRMInsertException(ex.getMessage()), status,
                    DWLStatus.FATAL, DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_COMPONENT, TCRMErrorCode.INSERT_RECORD_ERROR,
                    DSEAAdditionsExtsErrorReasonCode.ADDXCONTRACTDETAILSJPN_FAILED, theXContractDetailsJPNBObj.getControl(), errHandler);
        }
        
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction updateXContractDetailsJPN.
     *
     * @param theBObj
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleUpdateXContractDetailsJPN
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.UPDATE_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.UPDATE_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.UPDATEXCONTRACTDETAILSJPN_FAILED
    , manuallyHandleRedundantUpdateCheck="true"
    )
     public DWLResponse updateXContractDetailsJPN(XContractDetailsJPNBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER updateXContractDetailsJPN(XContractDetailsJPNBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("updateXContractDetailsJPN", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction updateXContractDetailsJPN.";
      logger.finest("updateXContractDetailsJPN(XContractDetailsJPNBObj theBObj) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction updateXContractDetailsJPN.";
      logger.finest("updateXContractDetailsJPN(XContractDetailsJPNBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN updateXContractDetailsJPN(XContractDetailsJPNBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Updates the specified XContractDetailsJPN with new attribute values.
     *
     * @param theXContractDetailsJPNBObj
     *     The object that contains XContractDetailsJPN attribute values to be
     *     updated
     * @return
     *     DWLResponse containing a XContractDetailsJPNBObj of the updated
     *     object.
     * @exception Exception
     * @generated
     */
    public DWLResponse handleUpdateXContractDetailsJPN(XContractDetailsJPNBObj theXContractDetailsJPNBObj) throws Exception {

        DWLStatus status = theXContractDetailsJPNBObj.getStatus();

        if (status == null) {
            status = new DWLStatus();
            theXContractDetailsJPNBObj.setStatus(status);
        }
        
    if( !theXContractDetailsJPNBObj.isRedundantUpdate() ){
            // set lastupdatetxid with txnid from dwlcontrol
            theXContractDetailsJPNBObj.getEObjXContractDetailsJPN().setLastUpdateTxId(new Long(theXContractDetailsJPNBObj.getControl().getTxnId()));
            Persistence theXContractDetailsJPNBObjPersistence = getBObjPersistenceFactory().createXContractDetailsJPNBObjPersistence(XContractDetailsJPNBObjQuery.XCONTRACT_DETAILS_JPN_UPDATE, theXContractDetailsJPNBObj);
            theXContractDetailsJPNBObjPersistence.persistUpdate();
        }

        DWLResponse response = createDWLResponse();
        response.setData(theXContractDetailsJPNBObj);
        response.setStatus(theXContractDetailsJPNBObj.getStatus());

        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXContractRelJPN.
     *
     * @param XContractRelJPNpkId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetXContractRelJPN
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETXCONTRACTRELJPN_FAILED,
       beforePreExecuteMethod = "beforePreExecuteGetXContractRelJPN"
    )
     public DWLResponse getXContractRelJPN(String XContractRelJPNpkId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getXContractRelJPN(String XContractRelJPNpkId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(XContractRelJPNpkId);
        DWLTransaction txObj = new  DWLTransactionInquiry("getXContractRelJPN", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction getXContractRelJPN.";
      logger.finest("getXContractRelJPN(String XContractRelJPNpkId,  DWLControl control) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction getXContractRelJPN.";
      logger.finest("getXContractRelJPN(String XContractRelJPNpkId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getXContractRelJPN(String XContractRelJPNpkId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets a XContractRelJPN from the database.
     * 
     * @generated
     */
    public DWLResponse handleGetXContractRelJPN(String XContractRelJPNpkId,  DWLControl control) throws Exception {
        DWLStatus status = new DWLStatus();
        DWLResponse response = createDWLResponse();
        
        BObjQuery bObjQuery = null;
           
        String asOfDate = (String) control.get(DWLControl.INQUIRE_AS_OF_DATE);

        // History data inquiry: if inquireAsOfDate field has value in request xml 
        if (StringUtils.isNonBlank(asOfDate)) {
            Timestamp tsAsOfDate = getPITHistoryDate(asOfDate, DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_COMPONENT,
                                                     DSEAAdditionsExtsErrorReasonCode.GETXCONTRACTRELJPN_INVALID_INQUIRE_AS_OF_DATE_FORMAT,
                                                     status, control);

            bObjQuery = getBObjQueryFactory().createXContractRelJPNBObjQuery(XContractRelJPNBObjQuery.XCONTRACT_REL_JPN_HISTORY_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(XContractRelJPNpkId));
            bObjQuery.setParameter(1, tsAsOfDate);
            bObjQuery.setParameter(2, tsAsOfDate);
        } else {
            bObjQuery = getBObjQueryFactory().createXContractRelJPNBObjQuery(XContractRelJPNBObjQuery.XCONTRACT_REL_JPN_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(XContractRelJPNpkId));
        }


        XContractRelJPNBObj o = (XContractRelJPNBObj) bObjQuery.getSingleResult();
        if( o == null ){
        	return null;
        } 
          
        if (o.getStatus()==null) {
            o.setStatus(status);
        }
        response.addStatus(o.getStatus());
        response.setData(o);

      return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public void beforePreExecuteGetXContractRelJPN(DWLTransaction transaction) throws DWLBaseException{
        // Check if the parameters are valid.
        Object[] arguments = getInquiryArgumentType((DWLTransactionInquiry)transaction);
        String pk = null;
        if (arguments!=null && arguments.length>0) {
            pk = (String)arguments[0];
        }
        // Check if the parameter passed in exists.
        if ((pk == null) || (pk.trim().length() == 0)) {
            TCRMExceptionUtils.throwTCRMException(null, new TCRMReadException(), transaction.getStatus(), DWLStatus.FATAL,
                DSEAAdditionsExtsComponentID.XCONTRACT_REL_JPNBOBJ,
                TCRMErrorCode.FIELD_VALIDATION_ERROR,
                DSEAAdditionsExtsErrorReasonCode.XCONTRACTRELJPN_XCONTRACTRELJPNPKID_NULL,
                transaction.getTxnControl(), errHandler);
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction addXContractRelJPN.
     *
     * @param theBObj
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleAddXContractRelJPN
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.ADD_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.INSERT_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.ADDXCONTRACTRELJPN_FAILED
    )
     public DWLResponse addXContractRelJPN(XContractRelJPNBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER addXContractRelJPN(XContractRelJPNBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("addXContractRelJPN", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction addXContractRelJPN.";
      logger.finest("addXContractRelJPN(XContractRelJPNBObj theBObj) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction addXContractRelJPN.";
      logger.finest("addXContractRelJPN(XContractRelJPNBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN addXContractRelJPN(XContractRelJPNBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Adds a XContractRelJPN to the database.
     *
     * @param theXContractRelJPNBObj
     *     The object that contains XContractRelJPN attribute values.
     * @return
     *     DWLResponse containing a XContractRelJPNBObj object.
     * @exception Exception
     * @generated
     */
    public DWLResponse handleAddXContractRelJPN(XContractRelJPNBObj theXContractRelJPNBObj) throws Exception {
        DWLResponse response = null;
        DWLStatus status = theXContractRelJPNBObj.getStatus();
        if (status == null) {
            status = new DWLStatus();
            theXContractRelJPNBObj.setStatus(status);
        }

        String strPluggableID = null;

        try {
            // Pluggable Key Structure implementation
            strPluggableID = getSuppliedIdPKFromBObj(theXContractRelJPNBObj);

            if ((strPluggableID != null) && (strPluggableID.length() > 0)) {
                theXContractRelJPNBObj.getEObjXContractRelJPN().setXContractRelJPNpkId(FunctionUtils.getLongFromString(strPluggableID));
            } else {
                strPluggableID = null;
                theXContractRelJPNBObj.getEObjXContractRelJPN().setXContractRelJPNpkId(null);
            }
         Persistence theXContractRelJPNBObjPersistence = getBObjPersistenceFactory().createXContractRelJPNBObjPersistence(XContractRelJPNBObjQuery.XCONTRACT_REL_JPN_ADD, theXContractRelJPNBObj);
         theXContractRelJPNBObjPersistence.persistAdd();

            response = new DWLResponse();
            response.setData(theXContractRelJPNBObj);
            response.setStatus(theXContractRelJPNBObj.getStatus());
    } catch (Exception ex) {
 				TCRMExceptionUtils.throwTCRMException(ex, new TCRMInsertException(ex.getMessage()), status,
                    DWLStatus.FATAL, DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_COMPONENT, TCRMErrorCode.INSERT_RECORD_ERROR,
                    DSEAAdditionsExtsErrorReasonCode.ADDXCONTRACTRELJPN_FAILED, theXContractRelJPNBObj.getControl(), errHandler);
        }
        
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction updateXContractRelJPN.
     *
     * @param theBObj
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleUpdateXContractRelJPN
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.UPDATE_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.UPDATE_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.UPDATEXCONTRACTRELJPN_FAILED
    )
     public DWLResponse updateXContractRelJPN(XContractRelJPNBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER updateXContractRelJPN(XContractRelJPNBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("updateXContractRelJPN", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction updateXContractRelJPN.";
      logger.finest("updateXContractRelJPN(XContractRelJPNBObj theBObj) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction updateXContractRelJPN.";
      logger.finest("updateXContractRelJPN(XContractRelJPNBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN updateXContractRelJPN(XContractRelJPNBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Updates the specified XContractRelJPN with new attribute values.
     *
     * @param theXContractRelJPNBObj
     *     The object that contains XContractRelJPN attribute values to be
     *     updated
     * @return
     *     DWLResponse containing a XContractRelJPNBObj of the updated object.
     * @exception Exception
     * @generated
     */
    public DWLResponse handleUpdateXContractRelJPN(XContractRelJPNBObj theXContractRelJPNBObj) throws Exception {

        DWLStatus status = theXContractRelJPNBObj.getStatus();

        if (status == null) {
            status = new DWLStatus();
            theXContractRelJPNBObj.setStatus(status);
        }
        
            // set lastupdatetxid with txnid from dwlcontrol
            theXContractRelJPNBObj.getEObjXContractRelJPN().setLastUpdateTxId(new Long(theXContractRelJPNBObj.getControl().getTxnId()));
         Persistence theXContractRelJPNBObjPersistence = getBObjPersistenceFactory().createXContractRelJPNBObjPersistence(XContractRelJPNBObjQuery.XCONTRACT_REL_JPN_UPDATE, theXContractRelJPNBObj);
         theXContractRelJPNBObjPersistence.persistUpdate();

        DWLResponse response = createDWLResponse();
        response.setData(theXContractRelJPNBObj);
        response.setStatus(theXContractRelJPNBObj.getStatus());

        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXVehicleAus.
     *
     * @param XVehicleAuspkId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetXVehicleAus
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETXVEHICLEAUS_FAILED,
       beforePreExecuteMethod = "beforePreExecuteGetXVehicleAus"
    )
     public DWLResponse getXVehicleAus(String XVehicleAuspkId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getXVehicleAus(String XVehicleAuspkId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(XVehicleAuspkId);
        DWLTransaction txObj = new  DWLTransactionInquiry("getXVehicleAus", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction getXVehicleAus.";
      logger.finest("getXVehicleAus(String XVehicleAuspkId,  DWLControl control) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction getXVehicleAus.";
      logger.finest("getXVehicleAus(String XVehicleAuspkId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getXVehicleAus(String XVehicleAuspkId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets a XVehicleAus from the database.
     * 
     * @generated
     */
    public DWLResponse handleGetXVehicleAus(String XVehicleAuspkId,  DWLControl control) throws Exception {
        DWLStatus status = new DWLStatus();
        DWLResponse response = createDWLResponse();
        
        BObjQuery bObjQuery = null;
           
        String asOfDate = (String) control.get(DWLControl.INQUIRE_AS_OF_DATE);

        // History data inquiry: if inquireAsOfDate field has value in request xml 
        if (StringUtils.isNonBlank(asOfDate)) {
            Timestamp tsAsOfDate = getPITHistoryDate(asOfDate, DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_COMPONENT,
                                                     DSEAAdditionsExtsErrorReasonCode.GETXVEHICLEAUS_INVALID_INQUIRE_AS_OF_DATE_FORMAT,
                                                     status, control);

            bObjQuery = getBObjQueryFactory().createXVehicleAusBObjQuery(XVehicleAusBObjQuery.XVEHICLE_AUS_HISTORY_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(XVehicleAuspkId));
            bObjQuery.setParameter(1, tsAsOfDate);
            bObjQuery.setParameter(2, tsAsOfDate);
        } else {
            bObjQuery = getBObjQueryFactory().createXVehicleAusBObjQuery(XVehicleAusBObjQuery.XVEHICLE_AUS_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(XVehicleAuspkId));
        }


        XVehicleAusBObj o = (XVehicleAusBObj) bObjQuery.getSingleResult();
        if( o == null ){
        	return null;
        } 
        postRetrieveXVehicleAusBObj(o, "0", "ALL", control); 
          
        if (o.getStatus()==null) {
            o.setStatus(status);
        }
        response.addStatus(o.getStatus());
        response.setData(o);

      return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public void beforePreExecuteGetXVehicleAus(DWLTransaction transaction) throws DWLBaseException{
        // Check if the parameters are valid.
        Object[] arguments = getInquiryArgumentType((DWLTransactionInquiry)transaction);
        String pk = null;
        if (arguments!=null && arguments.length>0) {
            pk = (String)arguments[0];
        }
        // Check if the parameter passed in exists.
        if ((pk == null) || (pk.trim().length() == 0)) {
            TCRMExceptionUtils.throwTCRMException(null, new TCRMReadException(), transaction.getStatus(), DWLStatus.FATAL,
                DSEAAdditionsExtsComponentID.XVEHICLE_AUS_BOBJ,
                TCRMErrorCode.FIELD_VALIDATION_ERROR,
                DSEAAdditionsExtsErrorReasonCode.XVEHICLEAUS_XVEHICLEAUSPKID_NULL,
                transaction.getTxnControl(), errHandler);
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXvehicleAusByGlobalVINAndMarketName.
     *
     * @param GlobalVIN
     * @param MarketName
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetXvehicleAusByGlobalVINAndMarketName
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETXVEHICLEAUSBYGLOBALVINANDMARKETNAME_FAILED,
       beforePreExecuteMethod = "beforePreExecuteGetXvehicleAusByGlobalVINAndMarketName"
    )
     public DWLResponse getXvehicleAusByGlobalVINAndMarketName(String GlobalVIN, String MarketName,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getXvehicleAusByGlobalVINAndMarketName(String GlobalVIN, String MarketName,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(GlobalVIN);
        params.add(MarketName);
        DWLTransaction txObj = new  DWLTransactionInquiry("getXvehicleAusByGlobalVINAndMarketName", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction getXvehicleAusByGlobalVINAndMarketName.";
      logger.finest("getXvehicleAusByGlobalVINAndMarketName(String GlobalVIN, String MarketName,  DWLControl control) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction getXvehicleAusByGlobalVINAndMarketName.";
      logger.finest("getXvehicleAusByGlobalVINAndMarketName(String GlobalVIN, String MarketName,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getXvehicleAusByGlobalVINAndMarketName(String GlobalVIN, String MarketName,  DWLControl control) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets a XVehicleAus from the database.
     * 
     * @generated
     */
    public DWLResponse handleGetXvehicleAusByGlobalVINAndMarketName(String GlobalVIN, String MarketName,  DWLControl control) throws Exception {
        DWLStatus status = new DWLStatus();
        DWLResponse response = createDWLResponse();
        
        BObjQuery bObjQuery = null;
           
        String asOfDate = (String) control.get(DWLControl.INQUIRE_AS_OF_DATE);

        // History data inquiry: if inquireAsOfDate field has value in request xml 
        if (StringUtils.isNonBlank(asOfDate)) {
            Timestamp tsAsOfDate = getPITHistoryDate(asOfDate, DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_COMPONENT,
                                                     DSEAAdditionsExtsErrorReasonCode.GETXVEHICLEAUSBYGLOBALVINANDMARKETNAME_INVALID_INQUIRE_AS_OF_DATE_FORMAT,
                                                     status, control);

            bObjQuery = getBObjQueryFactory().createXVehicleAusBObjQuery(XVehicleAusBObjQuery.XVEHICLE_AUS_BY_GLOBAL_VINAND_MARKET_NAME_HISTORY_QUERY,
                		control);
            bObjQuery.setParameter(0, GlobalVIN);
            bObjQuery.setParameter(1, MarketName);
            bObjQuery.setParameter(2, tsAsOfDate);
            bObjQuery.setParameter(3, tsAsOfDate);
        } else {
            bObjQuery = getBObjQueryFactory().createXVehicleAusBObjQuery(XVehicleAusBObjQuery.XVEHICLE_AUS_BY_GLOBAL_VINAND_MARKET_NAME_QUERY,
                		control);
            bObjQuery.setParameter(0, GlobalVIN);
            bObjQuery.setParameter(1, MarketName);
        }


        XVehicleAusBObj o = (XVehicleAusBObj) bObjQuery.getSingleResult();
        if( o == null ){
        	return null;
        } 
        postRetrieveXVehicleAusBObj(o, "0", "ALL", control); 
          
        if (o.getStatus()==null) {
            o.setStatus(status);
        }
        response.addStatus(o.getStatus());
        response.setData(o);

      return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public void beforePreExecuteGetXvehicleAusByGlobalVINAndMarketName(DWLTransaction transaction) throws DWLBaseException{
        // Check if the parameters are valid.
        Object[] arguments = getInquiryArgumentType((DWLTransactionInquiry)transaction);
    if (arguments!=null && arguments.length>0) {
            // MDM_TODO0: CDKWB0003I Add argument validation logic
    }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction addXVehicleAus.
     *
     * @param theBObj
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleAddXVehicleAus
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.ADD_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.INSERT_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.ADDXVEHICLEAUS_FAILED
    )
     public DWLResponse addXVehicleAus(XVehicleAusBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER addXVehicleAus(XVehicleAusBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("addXVehicleAus", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction addXVehicleAus.";
      logger.finest("addXVehicleAus(XVehicleAusBObj theBObj) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction addXVehicleAus.";
      logger.finest("addXVehicleAus(XVehicleAusBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN addXVehicleAus(XVehicleAusBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Adds a XVehicleAus to the database.
     *
     * @param theXVehicleAusBObj
     *     The object that contains XVehicleAus attribute values.
     * @return
     *     DWLResponse containing a XVehicleAusBObj object.
     * @exception Exception
     * @generated
     */
    public DWLResponse handleAddXVehicleAus(XVehicleAusBObj theXVehicleAusBObj) throws Exception {
        DWLResponse response = null;
        DWLStatus status = theXVehicleAusBObj.getStatus();
        if (status == null) {
            status = new DWLStatus();
            theXVehicleAusBObj.setStatus(status);
        }

        String strPluggableID = null;

        try {
            // Pluggable Key Structure implementation
            strPluggableID = getSuppliedIdPKFromBObj(theXVehicleAusBObj);

            if ((strPluggableID != null) && (strPluggableID.length() > 0)) {
                theXVehicleAusBObj.getEObjXVehicleAus().setXVehicleAuspkId(FunctionUtils.getLongFromString(strPluggableID));
            } else {
                strPluggableID = null;
                theXVehicleAusBObj.getEObjXVehicleAus().setXVehicleAuspkId(null);
            }
         Persistence theXVehicleAusBObjPersistence = getBObjPersistenceFactory().createXVehicleAusBObjPersistence(XVehicleAusBObjQuery.XVEHICLE_AUS_ADD, theXVehicleAusBObj);
         theXVehicleAusBObjPersistence.persistAdd();

            response = new DWLResponse();
            response.setData(theXVehicleAusBObj);
            response.setStatus(theXVehicleAusBObj.getStatus());
    } catch (Exception ex) {
 				TCRMExceptionUtils.throwTCRMException(ex, new TCRMInsertException(ex.getMessage()), status,
                    DWLStatus.FATAL, DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_COMPONENT, TCRMErrorCode.INSERT_RECORD_ERROR,
                    DSEAAdditionsExtsErrorReasonCode.ADDXVEHICLEAUS_FAILED, theXVehicleAusBObj.getControl(), errHandler);
        }
        
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction updateXVehicleAus.
     *
     * @param theBObj
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleUpdateXVehicleAus
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.UPDATE_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.UPDATE_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.UPDATEXVEHICLEAUS_FAILED
    )
     public DWLResponse updateXVehicleAus(XVehicleAusBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER updateXVehicleAus(XVehicleAusBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("updateXVehicleAus", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction updateXVehicleAus.";
      logger.finest("updateXVehicleAus(XVehicleAusBObj theBObj) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction updateXVehicleAus.";
      logger.finest("updateXVehicleAus(XVehicleAusBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN updateXVehicleAus(XVehicleAusBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Updates the specified XVehicleAus with new attribute values.
     *
     * @param theXVehicleAusBObj
     *     The object that contains XVehicleAus attribute values to be updated
     * @return
     *     DWLResponse containing a XVehicleAusBObj of the updated object.
     * @exception Exception
     * @generated
     */
    public DWLResponse handleUpdateXVehicleAus(XVehicleAusBObj theXVehicleAusBObj) throws Exception {

        DWLStatus status = theXVehicleAusBObj.getStatus();

        if (status == null) {
            status = new DWLStatus();
            theXVehicleAusBObj.setStatus(status);
        }
        
            // set lastupdatetxid with txnid from dwlcontrol
            theXVehicleAusBObj.getEObjXVehicleAus().setLastUpdateTxId(new Long(theXVehicleAusBObj.getControl().getTxnId()));
         Persistence theXVehicleAusBObjPersistence = getBObjPersistenceFactory().createXVehicleAusBObjPersistence(XVehicleAusBObjQuery.XVEHICLE_AUS_UPDATE, theXVehicleAusBObj);
         theXVehicleAusBObjPersistence.persistUpdate();

        DWLResponse response = createDWLResponse();
        response.setData(theXVehicleAusBObj);
        response.setStatus(theXVehicleAusBObj.getStatus());

        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXCustomerVehicleAus.
     *
     * @param XCustomerVehicleAuspkId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetXCustomerVehicleAus
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETXCUSTOMERVEHICLEAUS_FAILED,
       beforePreExecuteMethod = "beforePreExecuteGetXCustomerVehicleAus"
    )
     public DWLResponse getXCustomerVehicleAus(String XCustomerVehicleAuspkId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getXCustomerVehicleAus(String XCustomerVehicleAuspkId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(XCustomerVehicleAuspkId);
        DWLTransaction txObj = new  DWLTransactionInquiry("getXCustomerVehicleAus", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction getXCustomerVehicleAus.";
      logger.finest("getXCustomerVehicleAus(String XCustomerVehicleAuspkId,  DWLControl control) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction getXCustomerVehicleAus.";
      logger.finest("getXCustomerVehicleAus(String XCustomerVehicleAuspkId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getXCustomerVehicleAus(String XCustomerVehicleAuspkId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets a XCustomerVehicleAus from the database.
     * 
     * @generated
     */
    public DWLResponse handleGetXCustomerVehicleAus(String XCustomerVehicleAuspkId,  DWLControl control) throws Exception {
        DWLStatus status = new DWLStatus();
        DWLResponse response = createDWLResponse();
        
        BObjQuery bObjQuery = null;
           
        String asOfDate = (String) control.get(DWLControl.INQUIRE_AS_OF_DATE);

        // History data inquiry: if inquireAsOfDate field has value in request xml 
        if (StringUtils.isNonBlank(asOfDate)) {
            Timestamp tsAsOfDate = getPITHistoryDate(asOfDate, DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_COMPONENT,
                                                     DSEAAdditionsExtsErrorReasonCode.GETXCUSTOMERVEHICLEAUS_INVALID_INQUIRE_AS_OF_DATE_FORMAT,
                                                     status, control);

            bObjQuery = getBObjQueryFactory().createXCustomerVehicleAusBObjQuery(XCustomerVehicleAusBObjQuery.XCUSTOMER_VEHICLE_AUS_HISTORY_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(XCustomerVehicleAuspkId));
            bObjQuery.setParameter(1, tsAsOfDate);
            bObjQuery.setParameter(2, tsAsOfDate);
        } else {
            bObjQuery = getBObjQueryFactory().createXCustomerVehicleAusBObjQuery(XCustomerVehicleAusBObjQuery.XCUSTOMER_VEHICLE_AUS_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(XCustomerVehicleAuspkId));
        }


        XCustomerVehicleAusBObj o = (XCustomerVehicleAusBObj) bObjQuery.getSingleResult();
        if( o == null ){
        	return null;
        } 
        postRetrieveXCustomerVehicleAusBObj(o, "0", "ALL", control); 
          
        if (o.getStatus()==null) {
            o.setStatus(status);
        }
        response.addStatus(o.getStatus());
        response.setData(o);

      return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public void beforePreExecuteGetXCustomerVehicleAus(DWLTransaction transaction) throws DWLBaseException{
        // Check if the parameters are valid.
        Object[] arguments = getInquiryArgumentType((DWLTransactionInquiry)transaction);
        String pk = null;
        if (arguments!=null && arguments.length>0) {
            pk = (String)arguments[0];
        }
        // Check if the parameter passed in exists.
        if ((pk == null) || (pk.trim().length() == 0)) {
            TCRMExceptionUtils.throwTCRMException(null, new TCRMReadException(), transaction.getStatus(), DWLStatus.FATAL,
                DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_AUS_BOBJ,
                TCRMErrorCode.FIELD_VALIDATION_ERROR,
                DSEAAdditionsExtsErrorReasonCode.XCUSTOMERVEHICLEAUS_XCUSTOMERVEHICLEAUSPKID_NULL,
                transaction.getTxnControl(), errHandler);
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getAllXCustomerVehicleAusByPartyId.
     *
     * @param ContId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetAllXCustomerVehicleAusByPartyId
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETALLXCUSTOMERVEHICLEAUSBYPARTYID_FAILED,
       beforePreExecuteMethod = "beforePreExecuteGetAllXCustomerVehicleAusByPartyId"
    )
     public DWLResponse getAllXCustomerVehicleAusByPartyId(String ContId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getAllXCustomerVehicleAusByPartyId(String ContId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(ContId);
        DWLTransaction txObj = new  DWLTransactionInquiry("getAllXCustomerVehicleAusByPartyId", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction getAllXCustomerVehicleAusByPartyId.";
      logger.finest("getAllXCustomerVehicleAusByPartyId(String ContId,  DWLControl control) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction getAllXCustomerVehicleAusByPartyId.";
      logger.finest("getAllXCustomerVehicleAusByPartyId(String ContId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getAllXCustomerVehicleAusByPartyId(String ContId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets a XCustomerVehicleAus from the database.
     * 
     * @generated
     */
    public DWLResponse handleGetAllXCustomerVehicleAusByPartyId(String ContId,  DWLControl control) throws Exception {
        DWLStatus status = new DWLStatus();
        DWLResponse response = createDWLResponse();
        
        BObjQuery bObjQuery = null;
           
        String asOfDate = (String) control.get(DWLControl.INQUIRE_AS_OF_DATE);

        // History data inquiry: if inquireAsOfDate field has value in request xml 
        if (StringUtils.isNonBlank(asOfDate)) {
            Timestamp tsAsOfDate = getPITHistoryDate(asOfDate, DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_COMPONENT,
                                                     DSEAAdditionsExtsErrorReasonCode.GETALLXCUSTOMERVEHICLEAUSBYPARTYID_INVALID_INQUIRE_AS_OF_DATE_FORMAT,
                                                     status, control);

            bObjQuery = getBObjQueryFactory().createXCustomerVehicleAusBObjQuery(XCustomerVehicleAusBObjQuery.ALL_XCUSTOMER_VEHICLE_AUS_BY_PARTY_ID_HISTORY_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(ContId));
            bObjQuery.setParameter(1, tsAsOfDate);
            bObjQuery.setParameter(2, tsAsOfDate);
        } else {
            bObjQuery = getBObjQueryFactory().createXCustomerVehicleAusBObjQuery(XCustomerVehicleAusBObjQuery.ALL_XCUSTOMER_VEHICLE_AUS_BY_PARTY_ID_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(ContId));
        }

        boolean considerForPagination = PaginationUtils
                            .considerForPagintion(XCustomerVehicleAusBObj.class.getName(), control);
        control.setConsiderForPagintionFlag(considerForPagination);

        // set returned object
        List<?> list = bObjQuery.getResults();

        if (list.size() == 0) {
            return null;
        }
    Vector<XCustomerVehicleAusBObj> vector = new Vector<XCustomerVehicleAusBObj>();
        for (Iterator<?> it = list.iterator(); it.hasNext();) {
            XCustomerVehicleAusBObj o = (XCustomerVehicleAusBObj) it.next();
            postRetrieveXCustomerVehicleAusBObj(o, "0", "ALL", control); 
            vector.add(o);
          
            if (o.getStatus()==null) {
                o.setStatus(status);
            }
            response.addStatus(o.getStatus());
        }
        response.setData(vector);

      return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public void beforePreExecuteGetAllXCustomerVehicleAusByPartyId(DWLTransaction transaction) throws DWLBaseException{
        // Check if the parameters are valid.
        Object[] arguments = getInquiryArgumentType((DWLTransactionInquiry)transaction);
    if (arguments!=null && arguments.length>0) {
            // MDM_TODO0: CDKWB0003I Add argument validation logic
    }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getAllXCustomerVehicleAusByVehicleId.
     *
     * @param VehicleId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetAllXCustomerVehicleAusByVehicleId
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETALLXCUSTOMERVEHICLEAUSBYVEHICLEID_FAILED,
       beforePreExecuteMethod = "beforePreExecuteGetAllXCustomerVehicleAusByVehicleId"
    )
     public DWLResponse getAllXCustomerVehicleAusByVehicleId(String VehicleId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getAllXCustomerVehicleAusByVehicleId(String VehicleId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(VehicleId);
        DWLTransaction txObj = new  DWLTransactionInquiry("getAllXCustomerVehicleAusByVehicleId", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction getAllXCustomerVehicleAusByVehicleId.";
      logger.finest("getAllXCustomerVehicleAusByVehicleId(String VehicleId,  DWLControl control) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction getAllXCustomerVehicleAusByVehicleId.";
      logger.finest("getAllXCustomerVehicleAusByVehicleId(String VehicleId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getAllXCustomerVehicleAusByVehicleId(String VehicleId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets a XCustomerVehicleAus from the database.
     * 
     * @generated
     */
    public DWLResponse handleGetAllXCustomerVehicleAusByVehicleId(String VehicleId,  DWLControl control) throws Exception {
        DWLStatus status = new DWLStatus();
        DWLResponse response = createDWLResponse();
        
        BObjQuery bObjQuery = null;
           
        String asOfDate = (String) control.get(DWLControl.INQUIRE_AS_OF_DATE);

        // History data inquiry: if inquireAsOfDate field has value in request xml 
        if (StringUtils.isNonBlank(asOfDate)) {
            Timestamp tsAsOfDate = getPITHistoryDate(asOfDate, DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_COMPONENT,
                                                     DSEAAdditionsExtsErrorReasonCode.GETALLXCUSTOMERVEHICLEAUSBYVEHICLEID_INVALID_INQUIRE_AS_OF_DATE_FORMAT,
                                                     status, control);

            bObjQuery = getBObjQueryFactory().createXCustomerVehicleAusBObjQuery(XCustomerVehicleAusBObjQuery.ALL_XCUSTOMER_VEHICLE_AUS_BY_VEHICLE_ID_HISTORY_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(VehicleId));
            bObjQuery.setParameter(1, tsAsOfDate);
            bObjQuery.setParameter(2, tsAsOfDate);
        } else {
            bObjQuery = getBObjQueryFactory().createXCustomerVehicleAusBObjQuery(XCustomerVehicleAusBObjQuery.ALL_XCUSTOMER_VEHICLE_AUS_BY_VEHICLE_ID_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(VehicleId));
        }

        boolean considerForPagination = PaginationUtils
                            .considerForPagintion(XCustomerVehicleAusBObj.class.getName(), control);
        control.setConsiderForPagintionFlag(considerForPagination);

        // set returned object
        List<?> list = bObjQuery.getResults();

        if (list.size() == 0) {
            return null;
        }
    Vector<XCustomerVehicleAusBObj> vector = new Vector<XCustomerVehicleAusBObj>();
        for (Iterator<?> it = list.iterator(); it.hasNext();) {
            XCustomerVehicleAusBObj o = (XCustomerVehicleAusBObj) it.next();
            postRetrieveXCustomerVehicleAusBObj(o, "0", "ALL", control); 
            vector.add(o);
          
            if (o.getStatus()==null) {
                o.setStatus(status);
            }
            response.addStatus(o.getStatus());
        }
        response.setData(vector);

      return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public void beforePreExecuteGetAllXCustomerVehicleAusByVehicleId(DWLTransaction transaction) throws DWLBaseException{
        // Check if the parameters are valid.
        Object[] arguments = getInquiryArgumentType((DWLTransactionInquiry)transaction);
    if (arguments!=null && arguments.length>0) {
            // MDM_TODO0: CDKWB0003I Add argument validation logic
    }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction addXCustomerVehicleAus.
     *
     * @param theBObj
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleAddXCustomerVehicleAus
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.ADD_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.INSERT_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.ADDXCUSTOMERVEHICLEAUS_FAILED
    )
     public DWLResponse addXCustomerVehicleAus(XCustomerVehicleAusBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER addXCustomerVehicleAus(XCustomerVehicleAusBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("addXCustomerVehicleAus", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction addXCustomerVehicleAus.";
      logger.finest("addXCustomerVehicleAus(XCustomerVehicleAusBObj theBObj) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction addXCustomerVehicleAus.";
      logger.finest("addXCustomerVehicleAus(XCustomerVehicleAusBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN addXCustomerVehicleAus(XCustomerVehicleAusBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Adds a XCustomerVehicleAus to the database.
     *
     * @param theXCustomerVehicleAusBObj
     *     The object that contains XCustomerVehicleAus attribute values.
     * @return
     *     DWLResponse containing a XCustomerVehicleAusBObj object.
     * @exception Exception
     * @generated NOT
     */
     public DWLResponse handleAddXCustomerVehicleAus(XCustomerVehicleAusBObj theXCustomerVehicleAusBObj) throws Exception {
    	 DWLResponse response = null;
    	 DWLStatus status = theXCustomerVehicleAusBObj.getStatus();
    	 if (status == null) {
    		 status = new DWLStatus();
    		 theXCustomerVehicleAusBObj.setStatus(status);
    	 }
    	 XVehicleAusBObj childXVehicleAusBObj = theXCustomerVehicleAusBObj.getXVehicleAusBObj();
    	 
    	 //Changes for AUNZ: added check as vehicle will not added in specific case
    	 if( childXVehicleAusBObj != null && (null == theXCustomerVehicleAusBObj.getVehicleId() || StringUtils.isBlank(theXCustomerVehicleAusBObj.getVehicleId()))){
    		 String containedPk = null;

    		 addXVehicleAus(childXVehicleAusBObj);
    		 containedPk = childXVehicleAusBObj.getXVehicleAuspkId ();
    		 theXCustomerVehicleAusBObj.setVehicleId( containedPk );
    		 theXCustomerVehicleAusBObj.setXVehicleAusBObj(childXVehicleAusBObj);
    	 }

    	 String strPluggableID = null;

    	 try {
    		 // Pluggable Key Structure implementation
    		 strPluggableID = getSuppliedIdPKFromBObj(theXCustomerVehicleAusBObj);

    		 if ((strPluggableID != null) && (strPluggableID.length() > 0)) {
    			 theXCustomerVehicleAusBObj.getEObjXCustomerVehicleAus().setXCustomerVehicleAuspkId(FunctionUtils.getLongFromString(strPluggableID));
    		 } else {
    			 strPluggableID = null;
    			 theXCustomerVehicleAusBObj.getEObjXCustomerVehicleAus().setXCustomerVehicleAuspkId(null);
    		 }
    		 Persistence theXCustomerVehicleAusBObjPersistence = getBObjPersistenceFactory().createXCustomerVehicleAusBObjPersistence(XCustomerVehicleAusBObjQuery.XCUSTOMER_VEHICLE_AUS_ADD, theXCustomerVehicleAusBObj);
    		 theXCustomerVehicleAusBObjPersistence.persistAdd();

    		 String pkId = theXCustomerVehicleAusBObj.getXCustomerVehicleAuspkId ();			

    		 @SuppressWarnings("rawtypes")
    		 Vector vecXCustomerVehicleRoleAusBObj = theXCustomerVehicleAusBObj.getItemsXCustomerVehicleRoleAusBObj();
    		 for (int i = 0; i < vecXCustomerVehicleRoleAusBObj.size(); i++) {
    			 XCustomerVehicleRoleAusBObj object = (XCustomerVehicleRoleAusBObj)vecXCustomerVehicleRoleAusBObj.elementAt(i);
    			 object.setCustomerVehicleId(pkId);
    			 addXCustomerVehicleRoleAus(object);
    		 }
    		 response = new DWLResponse();
    		 response.setData(theXCustomerVehicleAusBObj);
    		 response.setStatus(theXCustomerVehicleAusBObj.getStatus());
    	 } catch (Exception ex) {
    		 TCRMExceptionUtils.throwTCRMException(ex, new TCRMInsertException(ex.getMessage()), status,
    				 DWLStatus.FATAL, DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_COMPONENT, TCRMErrorCode.INSERT_RECORD_ERROR,
    				 DSEAAdditionsExtsErrorReasonCode.ADDXCUSTOMERVEHICLEAUS_FAILED, theXCustomerVehicleAusBObj.getControl(), errHandler);
    	 }

    	 return response;
     }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction updateXCustomerVehicleAus.
     *
     * @param theBObj
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleUpdateXCustomerVehicleAus
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.UPDATE_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.UPDATE_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.UPDATEXCUSTOMERVEHICLEAUS_FAILED
    , manuallyHandleRedundantUpdateCheck="true"
    )
     public DWLResponse updateXCustomerVehicleAus(XCustomerVehicleAusBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER updateXCustomerVehicleAus(XCustomerVehicleAusBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("updateXCustomerVehicleAus", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction updateXCustomerVehicleAus.";
      logger.finest("updateXCustomerVehicleAus(XCustomerVehicleAusBObj theBObj) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction updateXCustomerVehicleAus.";
      logger.finest("updateXCustomerVehicleAus(XCustomerVehicleAusBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN updateXCustomerVehicleAus(XCustomerVehicleAusBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Updates the specified XCustomerVehicleAus with new attribute values.
     *
     * @param theXCustomerVehicleAusBObj
     *     The object that contains XCustomerVehicleAus attribute values to be
     *     updated
     * @return
     *     DWLResponse containing a XCustomerVehicleAusBObj of the updated
     *     object.
     * @exception Exception
     * @generated
     */
    public DWLResponse handleUpdateXCustomerVehicleAus(XCustomerVehicleAusBObj theXCustomerVehicleAusBObj) throws Exception {

        DWLStatus status = theXCustomerVehicleAusBObj.getStatus();

        if (status == null) {
            status = new DWLStatus();
            theXCustomerVehicleAusBObj.setStatus(status);
        }
        
    if( !theXCustomerVehicleAusBObj.isRedundantUpdate() ){
            // set lastupdatetxid with txnid from dwlcontrol
            theXCustomerVehicleAusBObj.getEObjXCustomerVehicleAus().setLastUpdateTxId(new Long(theXCustomerVehicleAusBObj.getControl().getTxnId()));
            Persistence theXCustomerVehicleAusBObjPersistence = getBObjPersistenceFactory().createXCustomerVehicleAusBObjPersistence(XCustomerVehicleAusBObjQuery.XCUSTOMER_VEHICLE_AUS_UPDATE, theXCustomerVehicleAusBObj);
            theXCustomerVehicleAusBObjPersistence.persistUpdate();
        }

    String pkId = theXCustomerVehicleAusBObj.getXCustomerVehicleAuspkId();			

    @SuppressWarnings("rawtypes")
    Vector vecXCustomerVehicleRoleAusBObj = theXCustomerVehicleAusBObj.getItemsXCustomerVehicleRoleAusBObj();
    for (int i = 0; i < vecXCustomerVehicleRoleAusBObj.size(); i++) {
      XCustomerVehicleRoleAusBObj object = (XCustomerVehicleRoleAusBObj)vecXCustomerVehicleRoleAusBObj.elementAt(i);
      
      String ref = object.getCustomerVehicleId();
      if (ref != null && !ref.equals(pkId)) {
        TCRMExceptionUtils.throwTCRMException(null, new TCRMDataInvalidException(),
          status,
          DWLStatus.FATAL,
          DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_AUS_BOBJ,
          TCRMErrorCode.DATA_INVALID_ERROR,
          DSEAAdditionsExtsErrorReasonCode.XCUSTOMERVEHICLEAUS_XCUSTOMERVEHICLEROLEAUS_REFERENCE_INVALID,
          theXCustomerVehicleAusBObj.getControl(),
          errHandler);
      }
      
      object.setCustomerVehicleId(pkId);
      
      if (object.getEObjXCustomerVehicleRoleAus().getPrimaryKey() == null){
        addXCustomerVehicleRoleAus(object);
      } else {
        updateXCustomerVehicleRoleAus(object);
      }
    }
        DWLResponse response = createDWLResponse();
        response.setData(theXCustomerVehicleAusBObj);
        response.setStatus(theXCustomerVehicleAusBObj.getStatus());

        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXCustomerVehicleRoleAus.
     *
     * @param XCustomerRoleAuspkId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetXCustomerVehicleRoleAus
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETXCUSTOMERVEHICLEROLEAUS_FAILED,
       beforePreExecuteMethod = "beforePreExecuteGetXCustomerVehicleRoleAus"
    )
     public DWLResponse getXCustomerVehicleRoleAus(String XCustomerRoleAuspkId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getXCustomerVehicleRoleAus(String XCustomerRoleAuspkId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(XCustomerRoleAuspkId);
        DWLTransaction txObj = new  DWLTransactionInquiry("getXCustomerVehicleRoleAus", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction getXCustomerVehicleRoleAus.";
      logger.finest("getXCustomerVehicleRoleAus(String XCustomerRoleAuspkId,  DWLControl control) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction getXCustomerVehicleRoleAus.";
      logger.finest("getXCustomerVehicleRoleAus(String XCustomerRoleAuspkId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getXCustomerVehicleRoleAus(String XCustomerRoleAuspkId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets a XCustomerVehicleRoleAus from the database.
     * 
     * @generated
     */
    public DWLResponse handleGetXCustomerVehicleRoleAus(String XCustomerRoleAuspkId,  DWLControl control) throws Exception {
        DWLStatus status = new DWLStatus();
        DWLResponse response = createDWLResponse();
        
        BObjQuery bObjQuery = null;
           
        String asOfDate = (String) control.get(DWLControl.INQUIRE_AS_OF_DATE);

        // History data inquiry: if inquireAsOfDate field has value in request xml 
        if (StringUtils.isNonBlank(asOfDate)) {
            Timestamp tsAsOfDate = getPITHistoryDate(asOfDate, DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_COMPONENT,
                                                     DSEAAdditionsExtsErrorReasonCode.GETXCUSTOMERVEHICLEROLEAUS_INVALID_INQUIRE_AS_OF_DATE_FORMAT,
                                                     status, control);

            bObjQuery = getBObjQueryFactory().createXCustomerVehicleRoleAusBObjQuery(XCustomerVehicleRoleAusBObjQuery.XCUSTOMER_VEHICLE_ROLE_AUS_HISTORY_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(XCustomerRoleAuspkId));
            bObjQuery.setParameter(1, tsAsOfDate);
            bObjQuery.setParameter(2, tsAsOfDate);
        } else {
            bObjQuery = getBObjQueryFactory().createXCustomerVehicleRoleAusBObjQuery(XCustomerVehicleRoleAusBObjQuery.XCUSTOMER_VEHICLE_ROLE_AUS_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(XCustomerRoleAuspkId));
        }


        XCustomerVehicleRoleAusBObj o = (XCustomerVehicleRoleAusBObj) bObjQuery.getSingleResult();
        if( o == null ){
        	return null;
        } 
        postRetrieveXCustomerVehicleRoleAusBObj(o, "0", "ALL", control); 
          
        if (o.getStatus()==null) {
            o.setStatus(status);
        }
        response.addStatus(o.getStatus());
        response.setData(o);

      return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public void beforePreExecuteGetXCustomerVehicleRoleAus(DWLTransaction transaction) throws DWLBaseException{
        // Check if the parameters are valid.
        Object[] arguments = getInquiryArgumentType((DWLTransactionInquiry)transaction);
        String pk = null;
        if (arguments!=null && arguments.length>0) {
            pk = (String)arguments[0];
        }
        // Check if the parameter passed in exists.
        if ((pk == null) || (pk.trim().length() == 0)) {
            TCRMExceptionUtils.throwTCRMException(null, new TCRMReadException(), transaction.getStatus(), DWLStatus.FATAL,
                DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_ROLE_AUS_BOBJ,
                TCRMErrorCode.FIELD_VALIDATION_ERROR,
                DSEAAdditionsExtsErrorReasonCode.XCUSTOMERVEHICLEROLEAUS_XCUSTOMERROLEAUSPKID_NULL,
                transaction.getTxnControl(), errHandler);
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getAllVehicleRoleAusByCustomerVehicleId.
     *
     * @param CustomerVehicleId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetAllVehicleRoleAusByCustomerVehicleId
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETALLVEHICLEROLEAUSBYCUSTOMERVEHICLEID_FAILED,
       beforePreExecuteMethod = "beforePreExecuteGetAllVehicleRoleAusByCustomerVehicleId"
    )
     public DWLResponse getAllVehicleRoleAusByCustomerVehicleId(String CustomerVehicleId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getAllVehicleRoleAusByCustomerVehicleId(String CustomerVehicleId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(CustomerVehicleId);
        DWLTransaction txObj = new  DWLTransactionInquiry("getAllVehicleRoleAusByCustomerVehicleId", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction getAllVehicleRoleAusByCustomerVehicleId.";
      logger.finest("getAllVehicleRoleAusByCustomerVehicleId(String CustomerVehicleId,  DWLControl control) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction getAllVehicleRoleAusByCustomerVehicleId.";
      logger.finest("getAllVehicleRoleAusByCustomerVehicleId(String CustomerVehicleId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getAllVehicleRoleAusByCustomerVehicleId(String CustomerVehicleId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets a XCustomerVehicleRoleAus from the database.
     * 
     * @generated
     */
    public DWLResponse handleGetAllVehicleRoleAusByCustomerVehicleId(String CustomerVehicleId,  DWLControl control) throws Exception {
        DWLStatus status = new DWLStatus();
        DWLResponse response = createDWLResponse();
        
        BObjQuery bObjQuery = null;
           
        String asOfDate = (String) control.get(DWLControl.INQUIRE_AS_OF_DATE);

        // History data inquiry: if inquireAsOfDate field has value in request xml 
        if (StringUtils.isNonBlank(asOfDate)) {
            Timestamp tsAsOfDate = getPITHistoryDate(asOfDate, DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_COMPONENT,
                                                     DSEAAdditionsExtsErrorReasonCode.GETALLVEHICLEROLEAUSBYCUSTOMERVEHICLEID_INVALID_INQUIRE_AS_OF_DATE_FORMAT,
                                                     status, control);

            bObjQuery = getBObjQueryFactory().createXCustomerVehicleRoleAusBObjQuery(XCustomerVehicleRoleAusBObjQuery.ALL_VEHICLE_ROLE_AUS_BY_CUSTOMER_VEHICLE_ID_HISTORY_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(CustomerVehicleId));
            bObjQuery.setParameter(1, tsAsOfDate);
            bObjQuery.setParameter(2, tsAsOfDate);
        } else {
            bObjQuery = getBObjQueryFactory().createXCustomerVehicleRoleAusBObjQuery(XCustomerVehicleRoleAusBObjQuery.ALL_VEHICLE_ROLE_AUS_BY_CUSTOMER_VEHICLE_ID_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(CustomerVehicleId));
        }

        boolean considerForPagination = PaginationUtils
                            .considerForPagintion(XCustomerVehicleRoleAusBObj.class.getName(), control);
        control.setConsiderForPagintionFlag(considerForPagination);

        // set returned object
        List<?> list = bObjQuery.getResults();

        if (list.size() == 0) {
            return null;
        }
    Vector<XCustomerVehicleRoleAusBObj> vector = new Vector<XCustomerVehicleRoleAusBObj>();
        for (Iterator<?> it = list.iterator(); it.hasNext();) {
            XCustomerVehicleRoleAusBObj o = (XCustomerVehicleRoleAusBObj) it.next();
            postRetrieveXCustomerVehicleRoleAusBObj(o, "0", "ALL", control); 
            vector.add(o);
          
            if (o.getStatus()==null) {
                o.setStatus(status);
            }
            response.addStatus(o.getStatus());
        }
        response.setData(vector);

      return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public void beforePreExecuteGetAllVehicleRoleAusByCustomerVehicleId(DWLTransaction transaction) throws DWLBaseException{
        // Check if the parameters are valid.
        Object[] arguments = getInquiryArgumentType((DWLTransactionInquiry)transaction);
    if (arguments!=null && arguments.length>0) {
            // MDM_TODO0: CDKWB0003I Add argument validation logic
    }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction
     * getAllXCustomerVehicleRoleAusByXCustomerVehicleAus.
     *
     * @param XCustomerVehicleAusReference
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetAllXCustomerVehicleRoleAusByXCustomerVehicleAus
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETALLXCUSTOMERVEHICLEROLEAUSBYXCUSTOMERVEHICLEAUS_FAILED,
       beforePreExecuteMethod = "beforePreExecuteGetAllXCustomerVehicleRoleAusByXCustomerVehicleAus"
    )
     public DWLResponse getAllXCustomerVehicleRoleAusByXCustomerVehicleAus(String XCustomerVehicleAusReference,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getAllXCustomerVehicleRoleAusByXCustomerVehicleAus(String XCustomerVehicleAusReference,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(XCustomerVehicleAusReference);
        DWLTransaction txObj = new  DWLTransactionInquiry("getAllXCustomerVehicleRoleAusByXCustomerVehicleAus", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction getAllXCustomerVehicleRoleAusByXCustomerVehicleAus.";
      logger.finest("getAllXCustomerVehicleRoleAusByXCustomerVehicleAus(String XCustomerVehicleAusReference,  DWLControl control) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction getAllXCustomerVehicleRoleAusByXCustomerVehicleAus.";
      logger.finest("getAllXCustomerVehicleRoleAusByXCustomerVehicleAus(String XCustomerVehicleAusReference,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getAllXCustomerVehicleRoleAusByXCustomerVehicleAus(String XCustomerVehicleAusReference,  DWLControl control) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets a XCustomerVehicleRoleAus from the database.
     * 
     * @generated
     */
    public DWLResponse handleGetAllXCustomerVehicleRoleAusByXCustomerVehicleAus(String XCustomerVehicleAusReference,  DWLControl control) throws Exception {
        DWLStatus status = new DWLStatus();
        DWLResponse response = createDWLResponse();
        
        BObjQuery bObjQuery = null;
           
        String asOfDate = (String) control.get(DWLControl.INQUIRE_AS_OF_DATE);

        // History data inquiry: if inquireAsOfDate field has value in request xml 
        if (StringUtils.isNonBlank(asOfDate)) {
            Timestamp tsAsOfDate = getPITHistoryDate(asOfDate, DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_COMPONENT,
                                                     DSEAAdditionsExtsErrorReasonCode.GETALLXCUSTOMERVEHICLEROLEAUSBYXCUSTOMERVEHICLEAUS_INVALID_INQUIRE_AS_OF_DATE_FORMAT,
                                                     status, control);

            bObjQuery = getBObjQueryFactory().createXCustomerVehicleRoleAusBObjQuery(XCustomerVehicleRoleAusBObjQuery.ALL_XCUSTOMER_VEHICLE_ROLE_AUS_BY_XCUSTOMER_VEHICLE_AUS_HISTORY_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(XCustomerVehicleAusReference));
            bObjQuery.setParameter(1, tsAsOfDate);
            bObjQuery.setParameter(2, tsAsOfDate);
        } else {
            bObjQuery = getBObjQueryFactory().createXCustomerVehicleRoleAusBObjQuery(XCustomerVehicleRoleAusBObjQuery.ALL_XCUSTOMER_VEHICLE_ROLE_AUS_BY_XCUSTOMER_VEHICLE_AUS_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(XCustomerVehicleAusReference));
        }

        boolean considerForPagination = PaginationUtils
                            .considerForPagintion(XCustomerVehicleRoleAusBObj.class.getName(), control);
        control.setConsiderForPagintionFlag(considerForPagination);

        // set returned object
        List<?> list = bObjQuery.getResults();

        if (list.size() == 0) {
            return null;
        }
    Vector<XCustomerVehicleRoleAusBObj> vector = new Vector<XCustomerVehicleRoleAusBObj>();
        for (Iterator<?> it = list.iterator(); it.hasNext();) {
            XCustomerVehicleRoleAusBObj o = (XCustomerVehicleRoleAusBObj) it.next();
            postRetrieveXCustomerVehicleRoleAusBObj(o, "0", "ALL", control); 
            vector.add(o);
          
            if (o.getStatus()==null) {
                o.setStatus(status);
            }
            response.addStatus(o.getStatus());
        }
        response.setData(vector);

      return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public void beforePreExecuteGetAllXCustomerVehicleRoleAusByXCustomerVehicleAus(DWLTransaction transaction) throws DWLBaseException{
        // Check if the parameters are valid.
        Object[] arguments = getInquiryArgumentType((DWLTransactionInquiry)transaction);
    if (arguments!=null && arguments.length>0) {
            // MDM_TODO0: CDKWB0003I Add argument validation logic
    }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction addXCustomerVehicleRoleAus.
     *
     * @param theBObj
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleAddXCustomerVehicleRoleAus
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.ADD_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.INSERT_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.ADDXCUSTOMERVEHICLEROLEAUS_FAILED
    )
     public DWLResponse addXCustomerVehicleRoleAus(XCustomerVehicleRoleAusBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER addXCustomerVehicleRoleAus(XCustomerVehicleRoleAusBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("addXCustomerVehicleRoleAus", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction addXCustomerVehicleRoleAus.";
      logger.finest("addXCustomerVehicleRoleAus(XCustomerVehicleRoleAusBObj theBObj) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction addXCustomerVehicleRoleAus.";
      logger.finest("addXCustomerVehicleRoleAus(XCustomerVehicleRoleAusBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN addXCustomerVehicleRoleAus(XCustomerVehicleRoleAusBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Adds a XCustomerVehicleRoleAus to the database.
     *
     * @param theXCustomerVehicleRoleAusBObj
     *     The object that contains XCustomerVehicleRoleAus attribute values.
     * @return
     *     DWLResponse containing a XCustomerVehicleRoleAusBObj object.
     * @exception Exception
     * @generated
     */
    public DWLResponse handleAddXCustomerVehicleRoleAus(XCustomerVehicleRoleAusBObj theXCustomerVehicleRoleAusBObj) throws Exception {
        DWLResponse response = null;
        DWLStatus status = theXCustomerVehicleRoleAusBObj.getStatus();
        if (status == null) {
            status = new DWLStatus();
            theXCustomerVehicleRoleAusBObj.setStatus(status);
        }

        String strPluggableID = null;

        try {
            // Pluggable Key Structure implementation
            strPluggableID = getSuppliedIdPKFromBObj(theXCustomerVehicleRoleAusBObj);

            if ((strPluggableID != null) && (strPluggableID.length() > 0)) {
                theXCustomerVehicleRoleAusBObj.getEObjXCustomerVehicleRoleAus().setXCustomerRoleAuspkId(FunctionUtils.getLongFromString(strPluggableID));
            } else {
                strPluggableID = null;
                theXCustomerVehicleRoleAusBObj.getEObjXCustomerVehicleRoleAus().setXCustomerRoleAuspkId(null);
            }
         Persistence theXCustomerVehicleRoleAusBObjPersistence = getBObjPersistenceFactory().createXCustomerVehicleRoleAusBObjPersistence(XCustomerVehicleRoleAusBObjQuery.XCUSTOMER_VEHICLE_ROLE_AUS_ADD, theXCustomerVehicleRoleAusBObj);
         theXCustomerVehicleRoleAusBObjPersistence.persistAdd();

            response = new DWLResponse();
            response.setData(theXCustomerVehicleRoleAusBObj);
            response.setStatus(theXCustomerVehicleRoleAusBObj.getStatus());
    } catch (Exception ex) {
 				TCRMExceptionUtils.throwTCRMException(ex, new TCRMInsertException(ex.getMessage()), status,
                    DWLStatus.FATAL, DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_COMPONENT, TCRMErrorCode.INSERT_RECORD_ERROR,
                    DSEAAdditionsExtsErrorReasonCode.ADDXCUSTOMERVEHICLEROLEAUS_FAILED, theXCustomerVehicleRoleAusBObj.getControl(), errHandler);
        }
        
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction updateXCustomerVehicleRoleAus.
     *
     * @param theBObj
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleUpdateXCustomerVehicleRoleAus
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.UPDATE_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.UPDATE_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.UPDATEXCUSTOMERVEHICLEROLEAUS_FAILED
    )
     public DWLResponse updateXCustomerVehicleRoleAus(XCustomerVehicleRoleAusBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER updateXCustomerVehicleRoleAus(XCustomerVehicleRoleAusBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("updateXCustomerVehicleRoleAus", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction updateXCustomerVehicleRoleAus.";
      logger.finest("updateXCustomerVehicleRoleAus(XCustomerVehicleRoleAusBObj theBObj) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction updateXCustomerVehicleRoleAus.";
      logger.finest("updateXCustomerVehicleRoleAus(XCustomerVehicleRoleAusBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN updateXCustomerVehicleRoleAus(XCustomerVehicleRoleAusBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Updates the specified XCustomerVehicleRoleAus with new attribute values.
     *
     * @param theXCustomerVehicleRoleAusBObj
     *     The object that contains XCustomerVehicleRoleAus attribute values to
     *     be updated
     * @return
     *     DWLResponse containing a XCustomerVehicleRoleAusBObj of the updated
     *     object.
     * @exception Exception
     * @generated
     */
    public DWLResponse handleUpdateXCustomerVehicleRoleAus(XCustomerVehicleRoleAusBObj theXCustomerVehicleRoleAusBObj) throws Exception {

        DWLStatus status = theXCustomerVehicleRoleAusBObj.getStatus();

        if (status == null) {
            status = new DWLStatus();
            theXCustomerVehicleRoleAusBObj.setStatus(status);
        }
        
            // set lastupdatetxid with txnid from dwlcontrol
            theXCustomerVehicleRoleAusBObj.getEObjXCustomerVehicleRoleAus().setLastUpdateTxId(new Long(theXCustomerVehicleRoleAusBObj.getControl().getTxnId()));
         Persistence theXCustomerVehicleRoleAusBObjPersistence = getBObjPersistenceFactory().createXCustomerVehicleRoleAusBObjPersistence(XCustomerVehicleRoleAusBObjQuery.XCUSTOMER_VEHICLE_ROLE_AUS_UPDATE, theXCustomerVehicleRoleAusBObj);
         theXCustomerVehicleRoleAusBObjPersistence.persistUpdate();

        DWLResponse response = createDWLResponse();
        response.setData(theXCustomerVehicleRoleAusBObj);
        response.setStatus(theXCustomerVehicleRoleAusBObj.getStatus());

        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXVRCollapse.
     *
     * @param XVRCollapsepkId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetXVRCollapse
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETXVRCOLLAPSE_FAILED,
       beforePreExecuteMethod = "beforePreExecuteGetXVRCollapse"
    )
     public DWLResponse getXVRCollapse(String XVRCollapsepkId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getXVRCollapse(String XVRCollapsepkId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(XVRCollapsepkId);
        DWLTransaction txObj = new  DWLTransactionInquiry("getXVRCollapse", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction getXVRCollapse.";
      logger.finest("getXVRCollapse(String XVRCollapsepkId,  DWLControl control) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction getXVRCollapse.";
      logger.finest("getXVRCollapse(String XVRCollapsepkId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getXVRCollapse(String XVRCollapsepkId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets a XVRCollapse from the database.
     * 
     * @generated
     */
    public DWLResponse handleGetXVRCollapse(String XVRCollapsepkId,  DWLControl control) throws Exception {
        DWLStatus status = new DWLStatus();
        DWLResponse response = createDWLResponse();
        
        BObjQuery bObjQuery = null;
           
        String asOfDate = (String) control.get(DWLControl.INQUIRE_AS_OF_DATE);

        // History data inquiry: if inquireAsOfDate field has value in request xml 
        if (StringUtils.isNonBlank(asOfDate)) {
            Timestamp tsAsOfDate = getPITHistoryDate(asOfDate, DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_COMPONENT,
                                                     DSEAAdditionsExtsErrorReasonCode.GETXVRCOLLAPSE_INVALID_INQUIRE_AS_OF_DATE_FORMAT,
                                                     status, control);

            bObjQuery = getBObjQueryFactory().createXVRCollapseBObjQuery(XVRCollapseBObjQuery.XVRCOLLAPSE_HISTORY_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(XVRCollapsepkId));
            bObjQuery.setParameter(1, tsAsOfDate);
            bObjQuery.setParameter(2, tsAsOfDate);
        } else {
            bObjQuery = getBObjQueryFactory().createXVRCollapseBObjQuery(XVRCollapseBObjQuery.XVRCOLLAPSE_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(XVRCollapsepkId));
        }


        XVRCollapseBObj o = (XVRCollapseBObj) bObjQuery.getSingleResult();
        if( o == null ){
        	return null;
        } 
          
        if (o.getStatus()==null) {
            o.setStatus(status);
        }
        response.addStatus(o.getStatus());
        response.setData(o);

      return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public void beforePreExecuteGetXVRCollapse(DWLTransaction transaction) throws DWLBaseException{
        // Check if the parameters are valid.
        Object[] arguments = getInquiryArgumentType((DWLTransactionInquiry)transaction);
        String pk = null;
        if (arguments!=null && arguments.length>0) {
            pk = (String)arguments[0];
        }
        // Check if the parameter passed in exists.
        if ((pk == null) || (pk.trim().length() == 0)) {
            TCRMExceptionUtils.throwTCRMException(null, new TCRMReadException(), transaction.getStatus(), DWLStatus.FATAL,
                DSEAAdditionsExtsComponentID.XVRCOLLAPSE_BOBJ,
                TCRMErrorCode.FIELD_VALIDATION_ERROR,
                DSEAAdditionsExtsErrorReasonCode.XVRCOLLAPSE_XVRCOLLAPSEPKID_NULL,
                transaction.getTxnControl(), errHandler);
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction addXVRCollapse.
     *
     * @param theBObj
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleAddXVRCollapse
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.ADD_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.INSERT_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.ADDXVRCOLLAPSE_FAILED
    )
     public DWLResponse addXVRCollapse(XVRCollapseBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER addXVRCollapse(XVRCollapseBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("addXVRCollapse", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction addXVRCollapse.";
      logger.finest("addXVRCollapse(XVRCollapseBObj theBObj) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction addXVRCollapse.";
      logger.finest("addXVRCollapse(XVRCollapseBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN addXVRCollapse(XVRCollapseBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Adds a XVRCollapse to the database.
     *
     * @param theXVRCollapseBObj
     *     The object that contains XVRCollapse attribute values.
     * @return
     *     DWLResponse containing a XVRCollapseBObj object.
     * @exception Exception
     * @generated
     */
    public DWLResponse handleAddXVRCollapse(XVRCollapseBObj theXVRCollapseBObj) throws Exception {
        DWLResponse response = null;
        DWLStatus status = theXVRCollapseBObj.getStatus();
        if (status == null) {
            status = new DWLStatus();
            theXVRCollapseBObj.setStatus(status);
        }

        String strPluggableID = null;

        try {
            // Pluggable Key Structure implementation
            strPluggableID = getSuppliedIdPKFromBObj(theXVRCollapseBObj);

            if ((strPluggableID != null) && (strPluggableID.length() > 0)) {
                theXVRCollapseBObj.getEObjXVRCollapse().setXVRCollapsepkId(FunctionUtils.getLongFromString(strPluggableID));
            } else {
                strPluggableID = null;
                theXVRCollapseBObj.getEObjXVRCollapse().setXVRCollapsepkId(null);
            }
         Persistence theXVRCollapseBObjPersistence = getBObjPersistenceFactory().createXVRCollapseBObjPersistence(XVRCollapseBObjQuery.XVRCOLLAPSE_ADD, theXVRCollapseBObj);
         theXVRCollapseBObjPersistence.persistAdd();

            response = new DWLResponse();
            response.setData(theXVRCollapseBObj);
            response.setStatus(theXVRCollapseBObj.getStatus());
    } catch (Exception ex) {
 				TCRMExceptionUtils.throwTCRMException(ex, new TCRMInsertException(ex.getMessage()), status,
                    DWLStatus.FATAL, DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_COMPONENT, TCRMErrorCode.INSERT_RECORD_ERROR,
                    DSEAAdditionsExtsErrorReasonCode.ADDXVRCOLLAPSE_FAILED, theXVRCollapseBObj.getControl(), errHandler);
        }
        
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction updateXVRCollapse.
     *
     * @param theBObj
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleUpdateXVRCollapse
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.UPDATE_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.UPDATE_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.UPDATEXVRCOLLAPSE_FAILED
    )
     public DWLResponse updateXVRCollapse(XVRCollapseBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER updateXVRCollapse(XVRCollapseBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("updateXVRCollapse", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction updateXVRCollapse.";
      logger.finest("updateXVRCollapse(XVRCollapseBObj theBObj) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction updateXVRCollapse.";
      logger.finest("updateXVRCollapse(XVRCollapseBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN updateXVRCollapse(XVRCollapseBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Updates the specified XVRCollapse with new attribute values.
     *
     * @param theXVRCollapseBObj
     *     The object that contains XVRCollapse attribute values to be updated
     * @return
     *     DWLResponse containing a XVRCollapseBObj of the updated object.
     * @exception Exception
     * @generated
     */
    public DWLResponse handleUpdateXVRCollapse(XVRCollapseBObj theXVRCollapseBObj) throws Exception {

        DWLStatus status = theXVRCollapseBObj.getStatus();

        if (status == null) {
            status = new DWLStatus();
            theXVRCollapseBObj.setStatus(status);
        }
        
            // set lastupdatetxid with txnid from dwlcontrol
            theXVRCollapseBObj.getEObjXVRCollapse().setLastUpdateTxId(new Long(theXVRCollapseBObj.getControl().getTxnId()));
         Persistence theXVRCollapseBObjPersistence = getBObjPersistenceFactory().createXVRCollapseBObjPersistence(XVRCollapseBObjQuery.XVRCOLLAPSE_UPDATE, theXVRCollapseBObj);
         theXVRCollapseBObjPersistence.persistUpdate();

        DWLResponse response = createDWLResponse();
        response.setData(theXVRCollapseBObj);
        response.setStatus(theXVRCollapseBObj.getStatus());

        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXDeleteAudit.
     *
     * @param XDeleteAuditpkId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetXDeleteAudit
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.GETXDELETEAUDIT_FAILED,
       beforePreExecuteMethod = "beforePreExecuteGetXDeleteAudit"
    )
     public DWLResponse getXDeleteAudit(String XDeleteAuditpkId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getXDeleteAudit(String XDeleteAuditpkId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(XDeleteAuditpkId);
        DWLTransaction txObj = new  DWLTransactionInquiry("getXDeleteAudit", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction getXDeleteAudit.";
      logger.finest("getXDeleteAudit(String XDeleteAuditpkId,  DWLControl control) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction getXDeleteAudit.";
      logger.finest("getXDeleteAudit(String XDeleteAuditpkId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getXDeleteAudit(String XDeleteAuditpkId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets a XDeleteAudit from the database.
     * 
     * @generated
     */
    public DWLResponse handleGetXDeleteAudit(String XDeleteAuditpkId,  DWLControl control) throws Exception {
        DWLStatus status = new DWLStatus();
        DWLResponse response = createDWLResponse();
        
        BObjQuery bObjQuery = null;
           
        String asOfDate = (String) control.get(DWLControl.INQUIRE_AS_OF_DATE);

        // History data inquiry: if inquireAsOfDate field has value in request xml 
        if (StringUtils.isNonBlank(asOfDate)) {
            Timestamp tsAsOfDate = getPITHistoryDate(asOfDate, DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_COMPONENT,
                                                     DSEAAdditionsExtsErrorReasonCode.GETXDELETEAUDIT_INVALID_INQUIRE_AS_OF_DATE_FORMAT,
                                                     status, control);

            bObjQuery = getBObjQueryFactory().createXDeleteAuditBObjQuery(XDeleteAuditBObjQuery.XDELETE_AUDIT_HISTORY_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(XDeleteAuditpkId));
            bObjQuery.setParameter(1, tsAsOfDate);
            bObjQuery.setParameter(2, tsAsOfDate);
        } else {
            bObjQuery = getBObjQueryFactory().createXDeleteAuditBObjQuery(XDeleteAuditBObjQuery.XDELETE_AUDIT_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(XDeleteAuditpkId));
        }


        XDeleteAuditBObj o = (XDeleteAuditBObj) bObjQuery.getSingleResult();
        if( o == null ){
        	return null;
        } 
          
        if (o.getStatus()==null) {
            o.setStatus(status);
        }
        response.addStatus(o.getStatus());
        response.setData(o);

      return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public void beforePreExecuteGetXDeleteAudit(DWLTransaction transaction) throws DWLBaseException{
        // Check if the parameters are valid.
        Object[] arguments = getInquiryArgumentType((DWLTransactionInquiry)transaction);
        String pk = null;
        if (arguments!=null && arguments.length>0) {
            pk = (String)arguments[0];
        }
        // Check if the parameter passed in exists.
        if ((pk == null) || (pk.trim().length() == 0)) {
            TCRMExceptionUtils.throwTCRMException(null, new TCRMReadException(), transaction.getStatus(), DWLStatus.FATAL,
                DSEAAdditionsExtsComponentID.XDELETE_AUDIT_BOBJ,
                TCRMErrorCode.FIELD_VALIDATION_ERROR,
                DSEAAdditionsExtsErrorReasonCode.XDELETEAUDIT_XDELETEAUDITPKID_NULL,
                transaction.getTxnControl(), errHandler);
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction addXDeleteAudit.
     *
     * @param theBObj
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleAddXDeleteAudit
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.ADD_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.INSERT_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.ADDXDELETEAUDIT_FAILED
    )
     public DWLResponse addXDeleteAudit(XDeleteAuditBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER addXDeleteAudit(XDeleteAuditBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("addXDeleteAudit", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction addXDeleteAudit.";
      logger.finest("addXDeleteAudit(XDeleteAuditBObj theBObj) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction addXDeleteAudit.";
      logger.finest("addXDeleteAudit(XDeleteAuditBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN addXDeleteAudit(XDeleteAuditBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Adds a XDeleteAudit to the database.
     *
     * @param theXDeleteAuditBObj
     *     The object that contains XDeleteAudit attribute values.
     * @return
     *     DWLResponse containing a XDeleteAuditBObj object.
     * @exception Exception
     * @generated
     */
    public DWLResponse handleAddXDeleteAudit(XDeleteAuditBObj theXDeleteAuditBObj) throws Exception {
        DWLResponse response = null;
        DWLStatus status = theXDeleteAuditBObj.getStatus();
        if (status == null) {
            status = new DWLStatus();
            theXDeleteAuditBObj.setStatus(status);
        }

        String strPluggableID = null;

        try {
            // Pluggable Key Structure implementation
            strPluggableID = getSuppliedIdPKFromBObj(theXDeleteAuditBObj);

            if ((strPluggableID != null) && (strPluggableID.length() > 0)) {
                theXDeleteAuditBObj.getEObjXDeleteAudit().setXDeleteAuditpkId(FunctionUtils.getLongFromString(strPluggableID));
            } else {
                strPluggableID = null;
                theXDeleteAuditBObj.getEObjXDeleteAudit().setXDeleteAuditpkId(null);
            }
         Persistence theXDeleteAuditBObjPersistence = getBObjPersistenceFactory().createXDeleteAuditBObjPersistence(XDeleteAuditBObjQuery.XDELETE_AUDIT_ADD, theXDeleteAuditBObj);
         theXDeleteAuditBObjPersistence.persistAdd();

            response = new DWLResponse();
            response.setData(theXDeleteAuditBObj);
            response.setStatus(theXDeleteAuditBObj.getStatus());
    } catch (Exception ex) {
 				TCRMExceptionUtils.throwTCRMException(ex, new TCRMInsertException(ex.getMessage()), status,
                    DWLStatus.FATAL, DSEAAdditionsExtsComponentID.DSEAADDITIONS_EXTS_COMPONENT, TCRMErrorCode.INSERT_RECORD_ERROR,
                    DSEAAdditionsExtsErrorReasonCode.ADDXDELETEAUDIT_FAILED, theXDeleteAuditBObj.getControl(), errHandler);
        }
        
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction updateXDeleteAudit.
     *
     * @param theBObj
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleUpdateXDeleteAudit
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.UPDATE_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.UPDATE_RECORD_ERROR,
       txErrorReasonCode = DSEAAdditionsExtsErrorReasonCode.UPDATEXDELETEAUDIT_FAILED
    )
     public DWLResponse updateXDeleteAudit(XDeleteAuditBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER updateXDeleteAudit(XDeleteAuditBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("updateXDeleteAudit", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction updateXDeleteAudit.";
      logger.finest("updateXDeleteAudit(XDeleteAuditBObj theBObj) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction updateXDeleteAudit.";
      logger.finest("updateXDeleteAudit(XDeleteAuditBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN updateXDeleteAudit(XDeleteAuditBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Updates the specified XDeleteAudit with new attribute values.
     *
     * @param theXDeleteAuditBObj
     *     The object that contains XDeleteAudit attribute values to be updated
     * @return
     *     DWLResponse containing a XDeleteAuditBObj of the updated object.
     * @exception Exception
     * @generated
     */
    public DWLResponse handleUpdateXDeleteAudit(XDeleteAuditBObj theXDeleteAuditBObj) throws Exception {

        DWLStatus status = theXDeleteAuditBObj.getStatus();

        if (status == null) {
            status = new DWLStatus();
            theXDeleteAuditBObj.setStatus(status);
        }
        
            // set lastupdatetxid with txnid from dwlcontrol
            theXDeleteAuditBObj.getEObjXDeleteAudit().setLastUpdateTxId(new Long(theXDeleteAuditBObj.getControl().getTxnId()));
         Persistence theXDeleteAuditBObjPersistence = getBObjPersistenceFactory().createXDeleteAuditBObjPersistence(XDeleteAuditBObjQuery.XDELETE_AUDIT_UPDATE, theXDeleteAuditBObj);
         theXDeleteAuditBObjPersistence.persistUpdate();

        DWLResponse response = createDWLResponse();
        response.setData(theXDeleteAuditBObj);
        response.setStatus(theXDeleteAuditBObj.getStatus());

        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     **/
    public void loadBeforeImage(XPreferenceBObj bObj) throws DWLBaseException {
    logger.finest("ENTER loadBeforeImage(XPreferenceBObj bObj)");
    	if( bObj.BeforeImage() == null ){
    	
    		XPreferenceBObj beforeImage = null;
    		DWLResponse response = null;
    		
    		try {
    			response = getXPreference( bObj.getPreferencepkId(), bObj.getControl());
    			beforeImage = (XPreferenceBObj)response.getData();
    			
    		} catch( Exception e){
        if (logger.isFinestEnabled()) {
    				String infoForLogging="Error: Exception " + e.getMessage() + " while updating a record ";
      logger.finest("loadBeforeImage(XPreferenceBObj bObj) " + infoForLogging);
        }
              DWLExceptionUtils.throwDWLBaseException(e, 
            									new DWLUpdateException(e.getMessage()), 
            									bObj.getStatus(), DWLStatus.FATAL,
                                  DSEAAdditionsExtsComponentID.XPREFERENCE_BOBJ, 
                                  "DIERR",
                                  DSEAAdditionsExtsErrorReasonCode.XPREFERENCE_BEFORE_IMAGE_NOT_POPULATED, 
                                  bObj.getControl(), errHandler);
    		}
    		
    		if( beforeImage == null ){
        if (logger.isFinestEnabled()) {
    		    	String infoForLogging="Error: Before image for updating a record is null ";
      logger.finest("loadBeforeImage(XPreferenceBObj bObj) " + infoForLogging);
        }
              DWLExceptionUtils.throwDWLBaseException( new DWLUpdateException(), 
            									bObj.getStatus(), DWLStatus.FATAL,
                                  DSEAAdditionsExtsComponentID.XPREFERENCE_BOBJ, 
                                  "DIERR",
                                  DSEAAdditionsExtsErrorReasonCode.XPREFERENCE_BEFORE_IMAGE_NOT_POPULATED, 
                                  bObj.getControl(), errHandler);
    		}
    		
    		bObj.setBeforeImage(beforeImage);
    		
    	}
    logger.finest("RETURN loadBeforeImage(XPreferenceBObj bObj)");
    }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Populates the parent XPreferenceBObj with all contained BObjs and Type
     * Codes.
     * @generated
    **/
    public void postRetrieveXPreferenceBObj(XPreferenceBObj theBObj, String inquiryLevel, String filter, DWLControl control) throws Exception {
    logger.finest("ENTER postRetrieveXPreferenceBObj(XPreferenceBObj theBObj, String inquiryLevel, String filter, DWLControl control)");
        // processing code types  
        String langId = (String) theBObj.getControl().get(TCRMControlKeys.LANG_ID);
        CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
  
        String PreferredTp = theBObj.getPreferredType();
        if( PreferredTp != null && !PreferredTp.equals("")){
            CodeTypeBObj PreferredBObj = codeTypeCompHelper
                    .getCodeTypeByCode("xcdpreferencetp", langId, PreferredTp,
                          theBObj.getControl());

            if (PreferredBObj != null) {
                theBObj.setPreferredValue(PreferredBObj.getvalue());
            }

    }
        String SourceIdentifierTp = theBObj.getSourceIdentifierType();
        if( SourceIdentifierTp != null && !SourceIdentifierTp.equals("")){
            CodeTypeBObj SourceIdentifierBObj = codeTypeCompHelper
                    .getCodeTypeByCode("cdsourceidenttp", langId, SourceIdentifierTp,
                          theBObj.getControl());

            if (SourceIdentifierBObj != null) {
                theBObj.setSourceIdentifierValue(SourceIdentifierBObj.getvalue());
            }

    }
    logger.finest("RETURN postRetrieveXPreferenceBObj(XPreferenceBObj theBObj, String inquiryLevel, String filter, DWLControl control)");
  }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     **/
    public void loadBeforeImage(XPrivacyAgreementBObj bObj) throws DWLBaseException {
    logger.finest("ENTER loadBeforeImage(XPrivacyAgreementBObj bObj)");
    	if( bObj.BeforeImage() == null ){
    	
    		XPrivacyAgreementBObj beforeImage = null;
    		DWLResponse response = null;
    		
    		try {
    			response = getXPrivacyAgreement( bObj.getPrivacyAgreementpkId(), bObj.getControl());
    			beforeImage = (XPrivacyAgreementBObj)response.getData();
    			
    		} catch( Exception e){
        if (logger.isFinestEnabled()) {
    				String infoForLogging="Error: Exception " + e.getMessage() + " while updating a record ";
      logger.finest("loadBeforeImage(XPrivacyAgreementBObj bObj) " + infoForLogging);
        }
              DWLExceptionUtils.throwDWLBaseException(e, 
            									new DWLUpdateException(e.getMessage()), 
            									bObj.getStatus(), DWLStatus.FATAL,
                                  DSEAAdditionsExtsComponentID.XPRIVACY_AGREEMENT_BOBJ, 
                                  "DIERR",
                                  DSEAAdditionsExtsErrorReasonCode.XPRIVACYAGREEMENT_BEFORE_IMAGE_NOT_POPULATED, 
                                  bObj.getControl(), errHandler);
    		}
    		
    		if( beforeImage == null ){
        if (logger.isFinestEnabled()) {
    		    	String infoForLogging="Error: Before image for updating a record is null ";
      logger.finest("loadBeforeImage(XPrivacyAgreementBObj bObj) " + infoForLogging);
        }
              DWLExceptionUtils.throwDWLBaseException( new DWLUpdateException(), 
            									bObj.getStatus(), DWLStatus.FATAL,
                                  DSEAAdditionsExtsComponentID.XPRIVACY_AGREEMENT_BOBJ, 
                                  "DIERR",
                                  DSEAAdditionsExtsErrorReasonCode.XPRIVACYAGREEMENT_BEFORE_IMAGE_NOT_POPULATED, 
                                  bObj.getControl(), errHandler);
    		}
    		
    		bObj.setBeforeImage(beforeImage);
    		
    	}
    logger.finest("RETURN loadBeforeImage(XPrivacyAgreementBObj bObj)");
    }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Populates the parent XPrivacyAgreementBObj with all contained BObjs and
     * Type Codes.
     * @generated
    **/
    public void postRetrieveXPrivacyAgreementBObj(XPrivacyAgreementBObj theBObj, String inquiryLevel, String filter, DWLControl control) throws Exception {
    logger.finest("ENTER postRetrieveXPrivacyAgreementBObj(XPrivacyAgreementBObj theBObj, String inquiryLevel, String filter, DWLControl control)");
        // processing code types  
        String langId = (String) theBObj.getControl().get(TCRMControlKeys.LANG_ID);
        CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
  
        String ActionTp = theBObj.getActionType();
        if( ActionTp != null && !ActionTp.equals("")){
            CodeTypeBObj ActionBObj = codeTypeCompHelper
                    .getCodeTypeByCode("xcdactiontp", langId, ActionTp,
                          theBObj.getControl());

            if (ActionBObj != null) {
                theBObj.setActionValue(ActionBObj.getvalue());
            }

    }
        String SourceIdentifierTp = theBObj.getSourceIdentifierType();
        if( SourceIdentifierTp != null && !SourceIdentifierTp.equals("")){
            CodeTypeBObj SourceIdentifierBObj = codeTypeCompHelper
                    .getCodeTypeByCode("cdsourceidenttp", langId, SourceIdentifierTp,
                          theBObj.getControl());

            if (SourceIdentifierBObj != null) {
                theBObj.setSourceIdentifierValue(SourceIdentifierBObj.getvalue());
            }

    }
    logger.finest("RETURN postRetrieveXPrivacyAgreementBObj(XPrivacyAgreementBObj theBObj, String inquiryLevel, String filter, DWLControl control)");
  }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     **/
    public void loadBeforeImage(XRetailerBObj bObj) throws DWLBaseException {
    logger.finest("ENTER loadBeforeImage(XRetailerBObj bObj)");
    	if( bObj.BeforeImage() == null ){
    	
    		XRetailerBObj beforeImage = null;
    		DWLResponse response = null;
    		
    		try {
    			response = getXRetailer( bObj.getRetailerpkId(), bObj.getControl());
    			beforeImage = (XRetailerBObj)response.getData();
    			
    		} catch( Exception e){
        if (logger.isFinestEnabled()) {
    				String infoForLogging="Error: Exception " + e.getMessage() + " while updating a record ";
      logger.finest("loadBeforeImage(XRetailerBObj bObj) " + infoForLogging);
        }
              DWLExceptionUtils.throwDWLBaseException(e, 
            									new DWLUpdateException(e.getMessage()), 
            									bObj.getStatus(), DWLStatus.FATAL,
                                  DSEAAdditionsExtsComponentID.XRETAILER_BOBJ, 
                                  "DIERR",
                                  DSEAAdditionsExtsErrorReasonCode.XRETAILER_BEFORE_IMAGE_NOT_POPULATED, 
                                  bObj.getControl(), errHandler);
    		}
    		
    		if( beforeImage == null ){
        if (logger.isFinestEnabled()) {
    		    	String infoForLogging="Error: Before image for updating a record is null ";
      logger.finest("loadBeforeImage(XRetailerBObj bObj) " + infoForLogging);
        }
              DWLExceptionUtils.throwDWLBaseException( new DWLUpdateException(), 
            									bObj.getStatus(), DWLStatus.FATAL,
                                  DSEAAdditionsExtsComponentID.XRETAILER_BOBJ, 
                                  "DIERR",
                                  DSEAAdditionsExtsErrorReasonCode.XRETAILER_BEFORE_IMAGE_NOT_POPULATED, 
                                  bObj.getControl(), errHandler);
    		}
    		
    		bObj.setBeforeImage(beforeImage);
    		
    	}
    logger.finest("RETURN loadBeforeImage(XRetailerBObj bObj)");
    }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Populates the parent XRetailerBObj with all contained BObjs and Type
     * Codes.
     * @generated
    **/
    public void postRetrieveXRetailerBObj(XRetailerBObj theBObj, String inquiryLevel, String filter, DWLControl control) throws Exception {
    logger.finest("ENTER postRetrieveXRetailerBObj(XRetailerBObj theBObj, String inquiryLevel, String filter, DWLControl control)");
        // processing code types  
        String langId = (String) theBObj.getControl().get(TCRMControlKeys.LANG_ID);
        CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
  
        String SourceIdentifierTp = theBObj.getSourceIdentifierType();
        if( SourceIdentifierTp != null && !SourceIdentifierTp.equals("")){
            CodeTypeBObj SourceIdentifierBObj = codeTypeCompHelper
                    .getCodeTypeByCode("cdsourceidenttp", langId, SourceIdentifierTp,
                          theBObj.getControl());

            if (SourceIdentifierBObj != null) {
                theBObj.setSourceIdentifierValue(SourceIdentifierBObj.getvalue());
            }

    }
    logger.finest("RETURN postRetrieveXRetailerBObj(XRetailerBObj theBObj, String inquiryLevel, String filter, DWLControl control)");
  }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     **/
    public void loadBeforeImage(XCustomerRetailerBObj bObj) throws DWLBaseException {
    logger.finest("ENTER loadBeforeImage(XCustomerRetailerBObj bObj)");
    	if( bObj.BeforeImage() == null ){
    	
    		XCustomerRetailerBObj beforeImage = null;
    		DWLResponse response = null;
    		
    		try {
    			response = getXCustomerRetailer( bObj.getCustomerRetailerpkId(), bObj.getControl());
    			beforeImage = (XCustomerRetailerBObj)response.getData();
    			
    		} catch( Exception e){
        if (logger.isFinestEnabled()) {
    				String infoForLogging="Error: Exception " + e.getMessage() + " while updating a record ";
      logger.finest("loadBeforeImage(XCustomerRetailerBObj bObj) " + infoForLogging);
        }
              DWLExceptionUtils.throwDWLBaseException(e, 
            									new DWLUpdateException(e.getMessage()), 
            									bObj.getStatus(), DWLStatus.FATAL,
                                  DSEAAdditionsExtsComponentID.XCUSTOMER_RETAILER_BOBJ, 
                                  "DIERR",
                                  DSEAAdditionsExtsErrorReasonCode.XCUSTOMERRETAILER_BEFORE_IMAGE_NOT_POPULATED, 
                                  bObj.getControl(), errHandler);
    		}
    		
    		if( beforeImage == null ){
        if (logger.isFinestEnabled()) {
    		    	String infoForLogging="Error: Before image for updating a record is null ";
      logger.finest("loadBeforeImage(XCustomerRetailerBObj bObj) " + infoForLogging);
        }
              DWLExceptionUtils.throwDWLBaseException( new DWLUpdateException(), 
            									bObj.getStatus(), DWLStatus.FATAL,
                                  DSEAAdditionsExtsComponentID.XCUSTOMER_RETAILER_BOBJ, 
                                  "DIERR",
                                  DSEAAdditionsExtsErrorReasonCode.XCUSTOMERRETAILER_BEFORE_IMAGE_NOT_POPULATED, 
                                  bObj.getControl(), errHandler);
    		}
    		
    		bObj.setBeforeImage(beforeImage);
    		
    	}
    if( bObj.getXRetailerBObj() != null ){
      XRetailerBObj childBObj = bObj.getXRetailerBObj();
      if( childBObj.getEObjXRetailer().getRetailerpkId() != null ){
        childBObj.populateBeforeImage( );
      }
    }
    Vector<?> vecXCustomerRetailerRoleBObj = bObj.getItemsXCustomerRetailerRoleBObj();
    Vector<XCustomerRetailerRoleBObj> updXCustomerRetailerRoleBObj = new Vector<XCustomerRetailerRoleBObj>();
    for (int idx0 = 0; idx0 < vecXCustomerRetailerRoleBObj.size(); idx0++) {
      XCustomerRetailerRoleBObj childBObj = (XCustomerRetailerRoleBObj) vecXCustomerRetailerRoleBObj
          .elementAt(idx0);

      String pkId = childBObj.getCustomerRetailerRolepkId();

      if (StringUtils.isNonBlank(pkId)) {
        updXCustomerRetailerRoleBObj.add(childBObj);
      }
    }
    if( updXCustomerRetailerRoleBObj.size() > 1){
      try {
        DWLResponse containedResponse = getAllRetailerRoleByCustomerRetailerId( bObj.getCustomerRetailerpkId(),  bObj.getControl() );
        Vector<?> listAllChildrenBeforeImage = (Vector<?>)containedResponse.getData();
        if( listAllChildrenBeforeImage != null ){
          for (int idx = 0; idx < updXCustomerRetailerRoleBObj.size(); idx++) {

            XCustomerRetailerRoleBObj childBObj = (XCustomerRetailerRoleBObj) updXCustomerRetailerRoleBObj
              .elementAt(idx);
            String pkId = childBObj.getCustomerRetailerRolepkId();

            for (int idxBeforeImage = 0; idxBeforeImage < listAllChildrenBeforeImage
              .size(); idxBeforeImage++) {

              XCustomerRetailerRoleBObj bobjBeforeImage = (XCustomerRetailerRoleBObj) listAllChildrenBeforeImage
                .elementAt(idxBeforeImage);

              String idBeforeImage = bobjBeforeImage.getCustomerRetailerRolepkId();

              if (pkId.equalsIgnoreCase(idBeforeImage)) {
                childBObj.setBeforeImage(bobjBeforeImage);
                childBObj.populateBeforeImage();

                break;
              }
            }
          }
        }
    		} catch( Exception e){
    			if (logger.isFinestEnabled()) {	
    		   		String infoForLogging="Error: Exception " + e.getMessage() + " while updating a record ";
      logger.finest("loadBeforeImage(XCustomerRetailerBObj bObj) " + infoForLogging);
        }
             	DWLExceptionUtils.throwDWLBaseException(e, 
            									new DWLUpdateException(e.getMessage()), 
            									bObj.getStatus(), DWLStatus.FATAL,
                                  DSEAAdditionsExtsComponentID.XCUSTOMER_RETAILER_BOBJ, 
                                  "DIERR",
                                  DSEAAdditionsExtsErrorReasonCode.XCUSTOMERRETAILER_BEFORE_IMAGE_NOT_POPULATED, 
                                  bObj.getControl(), errHandler);
    		}
    }
    else if( updXCustomerRetailerRoleBObj.size() == 1){
      XCustomerRetailerRoleBObj childBObj = (XCustomerRetailerRoleBObj) updXCustomerRetailerRoleBObj.elementAt(0);
      childBObj.populateBeforeImage();
    }
    
    logger.finest("RETURN loadBeforeImage(XCustomerRetailerBObj bObj)");
    }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Populates the parent XCustomerRetailerBObj with all contained BObjs and
     * Type Codes.
     * @generated
    **/
	@SuppressWarnings("rawtypes")
    public void postRetrieveXCustomerRetailerBObj(XCustomerRetailerBObj theBObj, String inquiryLevel, String filter, DWLControl control) throws Exception {
    logger.finest("ENTER postRetrieveXCustomerRetailerBObj(XCustomerRetailerBObj theBObj, String inquiryLevel, String filter, DWLControl control)");
        DWLResponse containedResponse = null;
         // processing single valued reference XRetailerBObj
  
        if( theBObj.getXRetailerBObj() == null ){
            XRetailerBObj containedBObj = null;
            // processing an entity 
            String containedPk = theBObj.getRetailerId();
            if (containedPk!=null) {
            	if (logger.isFinestEnabled()) {	
    		   		String infoForLogging="Single Value reference - before containedResponse for XRetailerBObj, containedPk = " +containedPk;
      logger.finest("postRetrieveXCustomerRetailerBObj(XCustomerRetailerBObj theBObj, String inquiryLevel, String filter, DWLControl control) " + infoForLogging);
        }
            	containedResponse = getXRetailer( containedPk, control);
        if (logger.isFinestEnabled()) {	
    		   		String infoForLogging="Single Value reference - after containedResponse for XRetailerBObj, containedPk = " +containedPk;
      logger.finest("postRetrieveXCustomerRetailerBObj(XCustomerRetailerBObj theBObj, String inquiryLevel, String filter, DWLControl control) " + infoForLogging);
        }
            	containedBObj = (XRetailerBObj)containedResponse.getData();
            } else {	
            	if (logger.isFinestEnabled()) {
    		   		String infoForLogging="The contained pk is null";
      logger.finest("postRetrieveXCustomerRetailerBObj(XCustomerRetailerBObj theBObj, String inquiryLevel, String filter, DWLControl control) " + infoForLogging);
            	}
            }	
 // end else key is persisted in this object
            if( containedBObj != null ){
                containedBObj.setControl(control);
                theBObj.setXRetailerBObj(containedBObj);
            }
        }
        // processing multi valued reference 
    if (theBObj.getCustomerRetailerpkId()==null) {
      if (logger.isFinestEnabled()) {	
        String infoForLogging="theBObj.getCustomerRetailerpkId() == null";
      logger.finest("postRetrieveXCustomerRetailerBObj(XCustomerRetailerBObj theBObj, String inquiryLevel, String filter, DWLControl control) " + infoForLogging);
      	}
      }
      
        containedResponse = getAllRetailerRoleByCustomerRetailerId( theBObj.getCustomerRetailerpkId(), control);
    if (logger.isFinestEnabled()) {	
    		String infoForLogging="Successfully obtained the containedResponse for multi reference";
      logger.finest("postRetrieveXCustomerRetailerBObj(XCustomerRetailerBObj theBObj, String inquiryLevel, String filter, DWLControl control) " + infoForLogging);
    }
        Vector vec = null;
        vec = (Vector) containedResponse.getData();
        if( vec != null ){
        	for (int i = 0; i < vec.size(); i++) {
            	XCustomerRetailerRoleBObj object = (XCustomerRetailerRoleBObj) vec.elementAt(i);
            	object.setControl(control);
            	theBObj.setXCustomerRetailerRoleBObj(object);
        	}
        }
        // processing code types  
        String langId = (String) theBObj.getControl().get(TCRMControlKeys.LANG_ID);
        CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
  
        String SourceIdentifierTp = theBObj.getSourceIdentifierType();
        if( SourceIdentifierTp != null && !SourceIdentifierTp.equals("")){
            CodeTypeBObj SourceIdentifierBObj = codeTypeCompHelper
                    .getCodeTypeByCode("cdsourceidenttp", langId, SourceIdentifierTp,
                          theBObj.getControl());

            if (SourceIdentifierBObj != null) {
                theBObj.setSourceIdentifierValue(SourceIdentifierBObj.getvalue());
            }

    }
    logger.finest("RETURN postRetrieveXCustomerRetailerBObj(XCustomerRetailerBObj theBObj, String inquiryLevel, String filter, DWLControl control)");
  }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     **/
    public void loadBeforeImage(XCustomerRetailerRoleBObj bObj) throws DWLBaseException {
    logger.finest("ENTER loadBeforeImage(XCustomerRetailerRoleBObj bObj)");
    	if( bObj.BeforeImage() == null ){
    	
    		XCustomerRetailerRoleBObj beforeImage = null;
    		DWLResponse response = null;
    		
    		try {
    			response = getXCustomerRetailerRole( bObj.getCustomerRetailerRolepkId(), bObj.getControl());
    			beforeImage = (XCustomerRetailerRoleBObj)response.getData();
    			
    		} catch( Exception e){
        if (logger.isFinestEnabled()) {
    				String infoForLogging="Error: Exception " + e.getMessage() + " while updating a record ";
      logger.finest("loadBeforeImage(XCustomerRetailerRoleBObj bObj) " + infoForLogging);
        }
              DWLExceptionUtils.throwDWLBaseException(e, 
            									new DWLUpdateException(e.getMessage()), 
            									bObj.getStatus(), DWLStatus.FATAL,
                                  DSEAAdditionsExtsComponentID.XCUSTOMER_RETAILER_ROLE_BOBJ, 
                                  "DIERR",
                                  DSEAAdditionsExtsErrorReasonCode.XCUSTOMERRETAILERROLE_BEFORE_IMAGE_NOT_POPULATED, 
                                  bObj.getControl(), errHandler);
    		}
    		
    		if( beforeImage == null ){
        if (logger.isFinestEnabled()) {
    		    	String infoForLogging="Error: Before image for updating a record is null ";
      logger.finest("loadBeforeImage(XCustomerRetailerRoleBObj bObj) " + infoForLogging);
        }
              DWLExceptionUtils.throwDWLBaseException( new DWLUpdateException(), 
            									bObj.getStatus(), DWLStatus.FATAL,
                                  DSEAAdditionsExtsComponentID.XCUSTOMER_RETAILER_ROLE_BOBJ, 
                                  "DIERR",
                                  DSEAAdditionsExtsErrorReasonCode.XCUSTOMERRETAILERROLE_BEFORE_IMAGE_NOT_POPULATED, 
                                  bObj.getControl(), errHandler);
    		}
    		
    		bObj.setBeforeImage(beforeImage);
    		
    	}
    logger.finest("RETURN loadBeforeImage(XCustomerRetailerRoleBObj bObj)");
    }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Populates the parent XCustomerRetailerRoleBObj with all contained BObjs
     * and Type Codes.
     * @generated
    **/
    public void postRetrieveXCustomerRetailerRoleBObj(XCustomerRetailerRoleBObj theBObj, String inquiryLevel, String filter, DWLControl control) throws Exception {
    logger.finest("ENTER postRetrieveXCustomerRetailerRoleBObj(XCustomerRetailerRoleBObj theBObj, String inquiryLevel, String filter, DWLControl control)");
        // processing code types  
        String langId = (String) theBObj.getControl().get(TCRMControlKeys.LANG_ID);
        CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
  
        String RetailerRoleTp = theBObj.getRetailerRoleType();
        if( RetailerRoleTp != null && !RetailerRoleTp.equals("")){
            CodeTypeBObj RetailerRoleBObj = codeTypeCompHelper
                    .getCodeTypeByCode("xcdretailerroletp", langId, RetailerRoleTp,
                          theBObj.getControl());

            if (RetailerRoleBObj != null) {
                theBObj.setRetailerRoleValue(RetailerRoleBObj.getvalue());
            }

    }
        String SourceIdentifierTp = theBObj.getSourceIdentifierType();
        if( SourceIdentifierTp != null && !SourceIdentifierTp.equals("")){
            CodeTypeBObj SourceIdentifierBObj = codeTypeCompHelper
                    .getCodeTypeByCode("cdsourceidenttp", langId, SourceIdentifierTp,
                          theBObj.getControl());

            if (SourceIdentifierBObj != null) {
                theBObj.setSourceIdentifierValue(SourceIdentifierBObj.getvalue());
            }

    }
    logger.finest("RETURN postRetrieveXCustomerRetailerRoleBObj(XCustomerRetailerRoleBObj theBObj, String inquiryLevel, String filter, DWLControl control)");
  }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     **/
    public void loadBeforeImage(XVehicleBObj bObj) throws DWLBaseException {
    logger.finest("ENTER loadBeforeImage(XVehicleBObj bObj)");
    	if( bObj.BeforeImage() == null ){
    	
    		XVehicleBObj beforeImage = null;
    		DWLResponse response = null;
    		
    		try {
    			response = getXVehicle( bObj.getVehiclepkId(), bObj.getControl());
    			beforeImage = (XVehicleBObj)response.getData();
    			
    		} catch( Exception e){
        if (logger.isFinestEnabled()) {
    				String infoForLogging="Error: Exception " + e.getMessage() + " while updating a record ";
      logger.finest("loadBeforeImage(XVehicleBObj bObj) " + infoForLogging);
        }
              DWLExceptionUtils.throwDWLBaseException(e, 
            									new DWLUpdateException(e.getMessage()), 
            									bObj.getStatus(), DWLStatus.FATAL,
                                  DSEAAdditionsExtsComponentID.XVEHICLE_BOBJ, 
                                  "DIERR",
                                  DSEAAdditionsExtsErrorReasonCode.XVEHICLE_BEFORE_IMAGE_NOT_POPULATED, 
                                  bObj.getControl(), errHandler);
    		}
    		
    		if( beforeImage == null ){
        if (logger.isFinestEnabled()) {
    		    	String infoForLogging="Error: Before image for updating a record is null ";
      logger.finest("loadBeforeImage(XVehicleBObj bObj) " + infoForLogging);
        }
              DWLExceptionUtils.throwDWLBaseException( new DWLUpdateException(), 
            									bObj.getStatus(), DWLStatus.FATAL,
                                  DSEAAdditionsExtsComponentID.XVEHICLE_BOBJ, 
                                  "DIERR",
                                  DSEAAdditionsExtsErrorReasonCode.XVEHICLE_BEFORE_IMAGE_NOT_POPULATED, 
                                  bObj.getControl(), errHandler);
    		}
    		
    		bObj.setBeforeImage(beforeImage);
    		
    	}
    logger.finest("RETURN loadBeforeImage(XVehicleBObj bObj)");
    }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Populates the parent XVehicleBObj with all contained BObjs and Type
     * Codes.
     * @generated
    **/
    public void postRetrieveXVehicleBObj(XVehicleBObj theBObj, String inquiryLevel, String filter, DWLControl control) throws Exception {
    logger.finest("ENTER postRetrieveXVehicleBObj(XVehicleBObj theBObj, String inquiryLevel, String filter, DWLControl control)");
        // processing code types  
        String langId = (String) theBObj.getControl().get(TCRMControlKeys.LANG_ID);
        CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
  
        String CountryTp = theBObj.getCountryType();
        if( CountryTp != null && !CountryTp.equals("")){
            CodeTypeBObj CountryBObj = codeTypeCompHelper
                    .getCodeTypeByCode("cdcountrytp", langId, CountryTp,
                          theBObj.getControl());

            if (CountryBObj != null) {
                theBObj.setCountryValue(CountryBObj.getvalue());
            }

    }
        String SourceIdentifierTp = theBObj.getSourceIdentifierType();
        if( SourceIdentifierTp != null && !SourceIdentifierTp.equals("")){
            CodeTypeBObj SourceIdentifierBObj = codeTypeCompHelper
                    .getCodeTypeByCode("cdsourceidenttp", langId, SourceIdentifierTp,
                          theBObj.getControl());

            if (SourceIdentifierBObj != null) {
                theBObj.setSourceIdentifierValue(SourceIdentifierBObj.getvalue());
            }

    }
    logger.finest("RETURN postRetrieveXVehicleBObj(XVehicleBObj theBObj, String inquiryLevel, String filter, DWLControl control)");
  }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     **/
    public void loadBeforeImage(XCustomerVehicleBObj bObj) throws DWLBaseException {
    logger.finest("ENTER loadBeforeImage(XCustomerVehicleBObj bObj)");
    	if( bObj.BeforeImage() == null ){
    	
    		XCustomerVehicleBObj beforeImage = null;
    		DWLResponse response = null;
    		
    		try {
    			response = getXCustomerVehicle( bObj.getCustomerVehiclepkId(), bObj.getControl());
    			beforeImage = (XCustomerVehicleBObj)response.getData();
    			
    		} catch( Exception e){
        if (logger.isFinestEnabled()) {
    				String infoForLogging="Error: Exception " + e.getMessage() + " while updating a record ";
      logger.finest("loadBeforeImage(XCustomerVehicleBObj bObj) " + infoForLogging);
        }
              DWLExceptionUtils.throwDWLBaseException(e, 
            									new DWLUpdateException(e.getMessage()), 
            									bObj.getStatus(), DWLStatus.FATAL,
                                  DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_BOBJ, 
                                  "DIERR",
                                  DSEAAdditionsExtsErrorReasonCode.XCUSTOMERVEHICLE_BEFORE_IMAGE_NOT_POPULATED, 
                                  bObj.getControl(), errHandler);
    		}
    		
    		if( beforeImage == null ){
        if (logger.isFinestEnabled()) {
    		    	String infoForLogging="Error: Before image for updating a record is null ";
      logger.finest("loadBeforeImage(XCustomerVehicleBObj bObj) " + infoForLogging);
        }
              DWLExceptionUtils.throwDWLBaseException( new DWLUpdateException(), 
            									bObj.getStatus(), DWLStatus.FATAL,
                                  DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_BOBJ, 
                                  "DIERR",
                                  DSEAAdditionsExtsErrorReasonCode.XCUSTOMERVEHICLE_BEFORE_IMAGE_NOT_POPULATED, 
                                  bObj.getControl(), errHandler);
    		}
    		
    		bObj.setBeforeImage(beforeImage);
    		
    	}
    if( bObj.getXVehicleBObj() != null ){
      XVehicleBObj childBObj = bObj.getXVehicleBObj();
      if( childBObj.getEObjXVehicle().getVehiclepkId() != null ){
        childBObj.populateBeforeImage( );
      }
    }
    Vector<?> vecXCustomerVehicleRoleBObj = bObj.getItemsXCustomerVehicleRoleBObj();
    Vector<XCustomerVehicleRoleBObj> updXCustomerVehicleRoleBObj = new Vector<XCustomerVehicleRoleBObj>();
    for (int idx0 = 0; idx0 < vecXCustomerVehicleRoleBObj.size(); idx0++) {
      XCustomerVehicleRoleBObj childBObj = (XCustomerVehicleRoleBObj) vecXCustomerVehicleRoleBObj
          .elementAt(idx0);

      String pkId = childBObj.getCustomerVehicleRolepkId();

      if (StringUtils.isNonBlank(pkId)) {
        updXCustomerVehicleRoleBObj.add(childBObj);
      }
    }
    if( updXCustomerVehicleRoleBObj.size() > 1){
      try {
        DWLResponse containedResponse = getAllVehicleRoleByCustomerVehicleId( bObj.getCustomerVehiclepkId(),  bObj.getControl() );
        Vector<?> listAllChildrenBeforeImage = (Vector<?>)containedResponse.getData();
        if( listAllChildrenBeforeImage != null ){
          for (int idx = 0; idx < updXCustomerVehicleRoleBObj.size(); idx++) {

            XCustomerVehicleRoleBObj childBObj = (XCustomerVehicleRoleBObj) updXCustomerVehicleRoleBObj
              .elementAt(idx);
            String pkId = childBObj.getCustomerVehicleRolepkId();

            for (int idxBeforeImage = 0; idxBeforeImage < listAllChildrenBeforeImage
              .size(); idxBeforeImage++) {

              XCustomerVehicleRoleBObj bobjBeforeImage = (XCustomerVehicleRoleBObj) listAllChildrenBeforeImage
                .elementAt(idxBeforeImage);

              String idBeforeImage = bobjBeforeImage.getCustomerVehicleRolepkId();

              if (pkId.equalsIgnoreCase(idBeforeImage)) {
                childBObj.setBeforeImage(bobjBeforeImage);
                childBObj.populateBeforeImage();

                break;
              }
            }
          }
        }
    		} catch( Exception e){
    			if (logger.isFinestEnabled()) {	
    		   		String infoForLogging="Error: Exception " + e.getMessage() + " while updating a record ";
      logger.finest("loadBeforeImage(XCustomerVehicleBObj bObj) " + infoForLogging);
        }
             	DWLExceptionUtils.throwDWLBaseException(e, 
            									new DWLUpdateException(e.getMessage()), 
            									bObj.getStatus(), DWLStatus.FATAL,
                                  DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_BOBJ, 
                                  "DIERR",
                                  DSEAAdditionsExtsErrorReasonCode.XCUSTOMERVEHICLE_BEFORE_IMAGE_NOT_POPULATED, 
                                  bObj.getControl(), errHandler);
    		}
    }
    else if( updXCustomerVehicleRoleBObj.size() == 1){
      XCustomerVehicleRoleBObj childBObj = (XCustomerVehicleRoleBObj) updXCustomerVehicleRoleBObj.elementAt(0);
      childBObj.populateBeforeImage();
    }
    
    logger.finest("RETURN loadBeforeImage(XCustomerVehicleBObj bObj)");
    }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Populates the parent XCustomerVehicleBObj with all contained BObjs and
     * Type Codes.
     * @generated
    **/
	@SuppressWarnings("rawtypes")
    public void postRetrieveXCustomerVehicleBObj(XCustomerVehicleBObj theBObj, String inquiryLevel, String filter, DWLControl control) throws Exception {
    logger.finest("ENTER postRetrieveXCustomerVehicleBObj(XCustomerVehicleBObj theBObj, String inquiryLevel, String filter, DWLControl control)");
        DWLResponse containedResponse = null;
         // processing single valued reference XVehicleBObj
  
        if( theBObj.getXVehicleBObj() == null ){
            XVehicleBObj containedBObj = null;
            // processing an entity 
            String containedPk = theBObj.getVehicleId();
            if (containedPk!=null) {
            	if (logger.isFinestEnabled()) {	
    		   		String infoForLogging="Single Value reference - before containedResponse for XVehicleBObj, containedPk = " +containedPk;
      logger.finest("postRetrieveXCustomerVehicleBObj(XCustomerVehicleBObj theBObj, String inquiryLevel, String filter, DWLControl control) " + infoForLogging);
        }
            	containedResponse = getXVehicle( containedPk, control);
        if (logger.isFinestEnabled()) {	
    		   		String infoForLogging="Single Value reference - after containedResponse for XVehicleBObj, containedPk = " +containedPk;
      logger.finest("postRetrieveXCustomerVehicleBObj(XCustomerVehicleBObj theBObj, String inquiryLevel, String filter, DWLControl control) " + infoForLogging);
        }
            	containedBObj = (XVehicleBObj)containedResponse.getData();
            } else {	
            	if (logger.isFinestEnabled()) {
    		   		String infoForLogging="The contained pk is null";
      logger.finest("postRetrieveXCustomerVehicleBObj(XCustomerVehicleBObj theBObj, String inquiryLevel, String filter, DWLControl control) " + infoForLogging);
            	}
            }	
 // end else key is persisted in this object
            if( containedBObj != null ){
                containedBObj.setControl(control);
                theBObj.setXVehicleBObj(containedBObj);
            }
        }
        // processing multi valued reference 
    if (theBObj.getCustomerVehiclepkId()==null) {
      if (logger.isFinestEnabled()) {	
        String infoForLogging="theBObj.getCustomerVehiclepkId() == null";
      logger.finest("postRetrieveXCustomerVehicleBObj(XCustomerVehicleBObj theBObj, String inquiryLevel, String filter, DWLControl control) " + infoForLogging);
      	}
      }
      
        containedResponse = getAllVehicleRoleByCustomerVehicleId( theBObj.getCustomerVehiclepkId(), control);
    if (logger.isFinestEnabled()) {	
    		String infoForLogging="Successfully obtained the containedResponse for multi reference";
      logger.finest("postRetrieveXCustomerVehicleBObj(XCustomerVehicleBObj theBObj, String inquiryLevel, String filter, DWLControl control) " + infoForLogging);
    }
        Vector vec = null;
        vec = (Vector) containedResponse.getData();
        if( vec != null ){
        	for (int i = 0; i < vec.size(); i++) {
            	XCustomerVehicleRoleBObj object = (XCustomerVehicleRoleBObj) vec.elementAt(i);
            	object.setControl(control);
            	theBObj.setXCustomerVehicleRoleBObj(object);
        	}
        }
        // processing code types  
        String langId = (String) theBObj.getControl().get(TCRMControlKeys.LANG_ID);
        CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
  
        String ConnectMeUsageTp = theBObj.getConnectMeUsageType();
        if( ConnectMeUsageTp != null && !ConnectMeUsageTp.equals("")){
            CodeTypeBObj ConnectMeUsageBObj = codeTypeCompHelper
                    .getCodeTypeByCode("xcdconnectmeusagetp", langId, ConnectMeUsageTp,
                          theBObj.getControl());

            if (ConnectMeUsageBObj != null) {
                theBObj.setConnectMeUsageValue(ConnectMeUsageBObj.getvalue());
            }

    }
        String VehicleSalesTp = theBObj.getVehicleSalesType();
        if( VehicleSalesTp != null && !VehicleSalesTp.equals("")){
            CodeTypeBObj VehicleSalesBObj = codeTypeCompHelper
                    .getCodeTypeByCode("xcdvehiclesalestp", langId, VehicleSalesTp,
                          theBObj.getControl());

            if (VehicleSalesBObj != null) {
                theBObj.setVehicleSalesValue(VehicleSalesBObj.getvalue());
            }

    }
        String VehicleUsageTp = theBObj.getVehicleUsageType();
        if( VehicleUsageTp != null && !VehicleUsageTp.equals("")){
            CodeTypeBObj VehicleUsageBObj = codeTypeCompHelper
                    .getCodeTypeByCode("xcdvehicleusagetp", langId, VehicleUsageTp,
                          theBObj.getControl());

            if (VehicleUsageBObj != null) {
                theBObj.setVehicleUsageValue(VehicleUsageBObj.getvalue());
            }

    }
        String SourceIdentifierTp = theBObj.getSourceIdentifierType();
        if( SourceIdentifierTp != null && !SourceIdentifierTp.equals("")){
            CodeTypeBObj SourceIdentifierBObj = codeTypeCompHelper
                    .getCodeTypeByCode("cdsourceidenttp", langId, SourceIdentifierTp,
                          theBObj.getControl());

            if (SourceIdentifierBObj != null) {
                theBObj.setSourceIdentifierValue(SourceIdentifierBObj.getvalue());
            }

    }
    logger.finest("RETURN postRetrieveXCustomerVehicleBObj(XCustomerVehicleBObj theBObj, String inquiryLevel, String filter, DWLControl control)");
  }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     **/
    public void loadBeforeImage(XCustomerVehicleRoleBObj bObj) throws DWLBaseException {
    logger.finest("ENTER loadBeforeImage(XCustomerVehicleRoleBObj bObj)");
    	if( bObj.BeforeImage() == null ){
    	
    		XCustomerVehicleRoleBObj beforeImage = null;
    		DWLResponse response = null;
    		
    		try {
    			response = getXCustomerVehicleRole( bObj.getCustomerVehicleRolepkId(), bObj.getControl());
    			beforeImage = (XCustomerVehicleRoleBObj)response.getData();
    			
    		} catch( Exception e){
        if (logger.isFinestEnabled()) {
    				String infoForLogging="Error: Exception " + e.getMessage() + " while updating a record ";
      logger.finest("loadBeforeImage(XCustomerVehicleRoleBObj bObj) " + infoForLogging);
        }
              DWLExceptionUtils.throwDWLBaseException(e, 
            									new DWLUpdateException(e.getMessage()), 
            									bObj.getStatus(), DWLStatus.FATAL,
                                  DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_ROLE_BOBJ, 
                                  "DIERR",
                                  DSEAAdditionsExtsErrorReasonCode.XCUSTOMERVEHICLEROLE_BEFORE_IMAGE_NOT_POPULATED, 
                                  bObj.getControl(), errHandler);
    		}
    		
    		if( beforeImage == null ){
        if (logger.isFinestEnabled()) {
    		    	String infoForLogging="Error: Before image for updating a record is null ";
      logger.finest("loadBeforeImage(XCustomerVehicleRoleBObj bObj) " + infoForLogging);
        }
              DWLExceptionUtils.throwDWLBaseException( new DWLUpdateException(), 
            									bObj.getStatus(), DWLStatus.FATAL,
                                  DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_ROLE_BOBJ, 
                                  "DIERR",
                                  DSEAAdditionsExtsErrorReasonCode.XCUSTOMERVEHICLEROLE_BEFORE_IMAGE_NOT_POPULATED, 
                                  bObj.getControl(), errHandler);
    		}
    		
    		bObj.setBeforeImage(beforeImage);
    		
    	}
    logger.finest("RETURN loadBeforeImage(XCustomerVehicleRoleBObj bObj)");
    }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Populates the parent XCustomerVehicleRoleBObj with all contained BObjs
     * and Type Codes.
     * @generated
    **/
    public void postRetrieveXCustomerVehicleRoleBObj(XCustomerVehicleRoleBObj theBObj, String inquiryLevel, String filter, DWLControl control) throws Exception {
    logger.finest("ENTER postRetrieveXCustomerVehicleRoleBObj(XCustomerVehicleRoleBObj theBObj, String inquiryLevel, String filter, DWLControl control)");
        // processing code types  
        String langId = (String) theBObj.getControl().get(TCRMControlKeys.LANG_ID);
        CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
  
        String VehicleRoleTp = theBObj.getVehicleRoleType();
        if( VehicleRoleTp != null && !VehicleRoleTp.equals("")){
            CodeTypeBObj VehicleRoleBObj = codeTypeCompHelper
                    .getCodeTypeByCode("xcdvehicleroletp", langId, VehicleRoleTp,
                          theBObj.getControl());

            if (VehicleRoleBObj != null) {
                theBObj.setVehicleRoleValue(VehicleRoleBObj.getvalue());
            }

    }
        String SourceIdentifierTp = theBObj.getSourceIdentifierType();
        if( SourceIdentifierTp != null && !SourceIdentifierTp.equals("")){
            CodeTypeBObj SourceIdentifierBObj = codeTypeCompHelper
                    .getCodeTypeByCode("cdsourceidenttp", langId, SourceIdentifierTp,
                          theBObj.getControl());

            if (SourceIdentifierBObj != null) {
                theBObj.setSourceIdentifierValue(SourceIdentifierBObj.getvalue());
            }

    }
    logger.finest("RETURN postRetrieveXCustomerVehicleRoleBObj(XCustomerVehicleRoleBObj theBObj, String inquiryLevel, String filter, DWLControl control)");
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     **/
    public void loadBeforeImage(XCompanyIdentificationBObj bObj) throws DWLBaseException {
    logger.finest("ENTER loadBeforeImage(XCompanyIdentificationBObj bObj)");
    	if( bObj.BeforeImage() == null ){
    	
    		XCompanyIdentificationBObj beforeImage = null;
    		DWLResponse response = null;
    		
    		try {
    			response = getXCompanyIdentification( bObj.getCompanyIdentificationpkId(), bObj.getControl());
    			beforeImage = (XCompanyIdentificationBObj)response.getData();
    			
    		} catch( Exception e){
        if (logger.isFinestEnabled()) {
    				String infoForLogging="Error: Exception " + e.getMessage() + " while updating a record ";
      logger.finest("loadBeforeImage(XCompanyIdentificationBObj bObj) " + infoForLogging);
        }
              DWLExceptionUtils.throwDWLBaseException(e, 
            									new DWLUpdateException(e.getMessage()), 
            									bObj.getStatus(), DWLStatus.FATAL,
                                  DSEAAdditionsExtsComponentID.XCOMPANY_IDENTIFICATION_BOBJ, 
                                  "DIERR",
                                  DSEAAdditionsExtsErrorReasonCode.XCOMPANYIDENTIFICATION_BEFORE_IMAGE_NOT_POPULATED, 
                                  bObj.getControl(), errHandler);
    		}
    		
    		if( beforeImage == null ){
        if (logger.isFinestEnabled()) {
    		    	String infoForLogging="Error: Before image for updating a record is null ";
      logger.finest("loadBeforeImage(XCompanyIdentificationBObj bObj) " + infoForLogging);
        }
              DWLExceptionUtils.throwDWLBaseException( new DWLUpdateException(), 
            									bObj.getStatus(), DWLStatus.FATAL,
                                  DSEAAdditionsExtsComponentID.XCOMPANY_IDENTIFICATION_BOBJ, 
                                  "DIERR",
                                  DSEAAdditionsExtsErrorReasonCode.XCOMPANYIDENTIFICATION_BEFORE_IMAGE_NOT_POPULATED, 
                                  bObj.getControl(), errHandler);
    		}
    		
    		bObj.setBeforeImage(beforeImage);
    		
    	}
    logger.finest("RETURN loadBeforeImage(XCompanyIdentificationBObj bObj)");
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     **/
    public void loadBeforeImage(XContractDetailsBObj bObj) throws DWLBaseException {
    logger.finest("ENTER loadBeforeImage(XContractDetailsBObj bObj)");
    	if( bObj.BeforeImage() == null ){
    	
    		XContractDetailsBObj beforeImage = null;
    		DWLResponse response = null;
    		
    		try {
    			response = getXContractDetails( bObj.getContractpkId(), bObj.getControl());
    			beforeImage = (XContractDetailsBObj)response.getData();
    			
    		} catch( Exception e){
        if (logger.isFinestEnabled()) {
    				String infoForLogging="Error: Exception " + e.getMessage() + " while updating a record ";
      logger.finest("loadBeforeImage(XContractDetailsBObj bObj) " + infoForLogging);
        }
              DWLExceptionUtils.throwDWLBaseException(e, 
            									new DWLUpdateException(e.getMessage()), 
            									bObj.getStatus(), DWLStatus.FATAL,
                                  DSEAAdditionsExtsComponentID.XCONTRACT_DETAILS_BOBJ, 
                                  "DIERR",
                                  DSEAAdditionsExtsErrorReasonCode.XCONTRACTDETAILS_BEFORE_IMAGE_NOT_POPULATED, 
                                  bObj.getControl(), errHandler);
    		}
    		
    		if( beforeImage == null ){
        if (logger.isFinestEnabled()) {
    		    	String infoForLogging="Error: Before image for updating a record is null ";
      logger.finest("loadBeforeImage(XContractDetailsBObj bObj) " + infoForLogging);
        }
              DWLExceptionUtils.throwDWLBaseException( new DWLUpdateException(), 
            									bObj.getStatus(), DWLStatus.FATAL,
                                  DSEAAdditionsExtsComponentID.XCONTRACT_DETAILS_BOBJ, 
                                  "DIERR",
                                  DSEAAdditionsExtsErrorReasonCode.XCONTRACTDETAILS_BEFORE_IMAGE_NOT_POPULATED, 
                                  bObj.getControl(), errHandler);
    		}
    		
    		bObj.setBeforeImage(beforeImage);
    		
    	}
    logger.finest("RETURN loadBeforeImage(XContractDetailsBObj bObj)");
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Populates the parent XContractDetailsBObj with all contained BObjs and
     * Type Codes.
     * @generated
    **/
  @SuppressWarnings("rawtypes")
    public void postRetrieveXContractDetailsBObj(XContractDetailsBObj theBObj, String inquiryLevel, String filter, DWLControl control) throws Exception {
    logger.finest("ENTER postRetrieveXContractDetailsBObj(XContractDetailsBObj theBObj, String inquiryLevel, String filter, DWLControl control)");
     // MDM_TODO: CDKWB0004I Obtain a GuarantorDetails instance and call the method setGuarantorDetailsBObj to populate the business object.
     // MDM_TODO: CDKWB0004I Obtain a CoborrowerDetails instance and call the method setCoborrowerDetailsBObj to populate the business object.
        // processing code types  
        String langId = (String) theBObj.getControl().get(TCRMControlKeys.LANG_ID);
        CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
  
        String ContractStatusTp = theBObj.getContractStatusType();
        if( ContractStatusTp != null && !ContractStatusTp.equals("")){
            CodeTypeBObj ContractStatusBObj = codeTypeCompHelper
                    .getCodeTypeByCode("cdcontractsttp", langId, ContractStatusTp,
                          theBObj.getControl());

            if (ContractStatusBObj != null) {
                theBObj.setContractStatusValue(ContractStatusBObj.getvalue());
            }

    }
        String CountryTp = theBObj.getCountryType();
        if( CountryTp != null && !CountryTp.equals("")){
            CodeTypeBObj CountryBObj = codeTypeCompHelper
                    .getCodeTypeByCode("cdcountrytp", langId, CountryTp,
                          theBObj.getControl());

            if (CountryBObj != null) {
                theBObj.setCountryValue(CountryBObj.getvalue());
            }

    }
        String SourceIdentifierTp = theBObj.getSourceIdentifierType();
        if( SourceIdentifierTp != null && !SourceIdentifierTp.equals("")){
            CodeTypeBObj SourceIdentifierBObj = codeTypeCompHelper
                    .getCodeTypeByCode("cdsourceidenttp", langId, SourceIdentifierTp,
                          theBObj.getControl());

            if (SourceIdentifierBObj != null) {
                theBObj.setSourceIdentifierValue(SourceIdentifierBObj.getvalue());
            }

    }
    logger.finest("RETURN postRetrieveXContractDetailsBObj(XContractDetailsBObj theBObj, String inquiryLevel, String filter, DWLControl control)");
  }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     **/
    public void loadBeforeImage(XGurantorIndividualBObj bObj) throws DWLBaseException {
    logger.finest("ENTER loadBeforeImage(XGurantorIndividualBObj bObj)");
    	if( bObj.BeforeImage() == null ){
    	
    		XGurantorIndividualBObj beforeImage = null;
    		DWLResponse response = null;
    		
    		try {
    			response = getXGurantorIndividual( bObj.getXGurantorIndividualpkId(), bObj.getControl());
    			beforeImage = (XGurantorIndividualBObj)response.getData();
    			
    		} catch( Exception e){
        if (logger.isFinestEnabled()) {
    				String infoForLogging="Error: Exception " + e.getMessage() + " while updating a record ";
      logger.finest("loadBeforeImage(XGurantorIndividualBObj bObj) " + infoForLogging);
        }
              DWLExceptionUtils.throwDWLBaseException(e, 
            									new DWLUpdateException(e.getMessage()), 
            									bObj.getStatus(), DWLStatus.FATAL,
                                  DSEAAdditionsExtsComponentID.XGURANTOR_INDIVIDUAL_BOBJ, 
                                  "DIERR",
                                  DSEAAdditionsExtsErrorReasonCode.XGURANTORINDIVIDUAL_BEFORE_IMAGE_NOT_POPULATED, 
                                  bObj.getControl(), errHandler);
    		}
    		
    		if( beforeImage == null ){
        if (logger.isFinestEnabled()) {
    		    	String infoForLogging="Error: Before image for updating a record is null ";
      logger.finest("loadBeforeImage(XGurantorIndividualBObj bObj) " + infoForLogging);
        }
              DWLExceptionUtils.throwDWLBaseException( new DWLUpdateException(), 
            									bObj.getStatus(), DWLStatus.FATAL,
                                  DSEAAdditionsExtsComponentID.XGURANTOR_INDIVIDUAL_BOBJ, 
                                  "DIERR",
                                  DSEAAdditionsExtsErrorReasonCode.XGURANTORINDIVIDUAL_BEFORE_IMAGE_NOT_POPULATED, 
                                  bObj.getControl(), errHandler);
    		}
    		
    		bObj.setBeforeImage(beforeImage);
    		
    	}
    logger.finest("RETURN loadBeforeImage(XGurantorIndividualBObj bObj)");
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Populates the parent XGurantorIndividualBObj with all contained BObjs and
     * Type Codes.
     * @generated
    **/
    public void postRetrieveXGurantorIndividualBObj(XGurantorIndividualBObj theBObj, String inquiryLevel, String filter, DWLControl control) throws Exception {
    logger.finest("ENTER postRetrieveXGurantorIndividualBObj(XGurantorIndividualBObj theBObj, String inquiryLevel, String filter, DWLControl control)");
        // processing code types  
        String langId = (String) theBObj.getControl().get(TCRMControlKeys.LANG_ID);
        CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
  
        String TitleTp = theBObj.getTitleType();
        if( TitleTp != null && !TitleTp.equals("")){
            CodeTypeBObj TitleBObj = codeTypeCompHelper
                    .getCodeTypeByCode("cdprefixnametp", langId, TitleTp,
                          theBObj.getControl());

            if (TitleBObj != null) {
                theBObj.setTitleValue(TitleBObj.getvalue());
            }

    }
        String AddressUsageTp = theBObj.getAddressUsageType();
        if( AddressUsageTp != null && !AddressUsageTp.equals("")){
            CodeTypeBObj AddressUsageBObj = codeTypeCompHelper
                    .getCodeTypeByCode("cdaddrusagetp", langId, AddressUsageTp,
                          theBObj.getControl());

            if (AddressUsageBObj != null) {
                theBObj.setAddressUsageValue(AddressUsageBObj.getvalue());
            }

    }
        String CountryTp = theBObj.getCountryType();
        if( CountryTp != null && !CountryTp.equals("")){
            CodeTypeBObj CountryBObj = codeTypeCompHelper
                    .getCodeTypeByCode("cdcountrytp", langId, CountryTp,
                          theBObj.getControl());

            if (CountryBObj != null) {
                theBObj.setCountryValue(CountryBObj.getvalue());
            }

    }
        String SourceIdentifierTp = theBObj.getSourceIdentifierType();
        if( SourceIdentifierTp != null && !SourceIdentifierTp.equals("")){
            CodeTypeBObj SourceIdentifierBObj = codeTypeCompHelper
                    .getCodeTypeByCode("cdsourceidenttp", langId, SourceIdentifierTp,
                          theBObj.getControl());

            if (SourceIdentifierBObj != null) {
                theBObj.setSourceIdentifierValue(SourceIdentifierBObj.getvalue());
            }

    }
    logger.finest("RETURN postRetrieveXGurantorIndividualBObj(XGurantorIndividualBObj theBObj, String inquiryLevel, String filter, DWLControl control)");
  }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     **/
    public void loadBeforeImage(XGurantorCompanyBObj bObj) throws DWLBaseException {
    logger.finest("ENTER loadBeforeImage(XGurantorCompanyBObj bObj)");
    	if( bObj.BeforeImage() == null ){
    	
    		XGurantorCompanyBObj beforeImage = null;
    		DWLResponse response = null;
    		
    		try {
    			response = getXGurantorCompany( bObj.getXGurantorCompanypkId(), bObj.getControl());
    			beforeImage = (XGurantorCompanyBObj)response.getData();
    			
    		} catch( Exception e){
        if (logger.isFinestEnabled()) {
    				String infoForLogging="Error: Exception " + e.getMessage() + " while updating a record ";
      logger.finest("loadBeforeImage(XGurantorCompanyBObj bObj) " + infoForLogging);
        }
              DWLExceptionUtils.throwDWLBaseException(e, 
            									new DWLUpdateException(e.getMessage()), 
            									bObj.getStatus(), DWLStatus.FATAL,
                                  DSEAAdditionsExtsComponentID.XGURANTOR_COMPANY_BOBJ, 
                                  "DIERR",
                                  DSEAAdditionsExtsErrorReasonCode.XGURANTORCOMPANY_BEFORE_IMAGE_NOT_POPULATED, 
                                  bObj.getControl(), errHandler);
    		}
    		
    		if( beforeImage == null ){
        if (logger.isFinestEnabled()) {
    		    	String infoForLogging="Error: Before image for updating a record is null ";
      logger.finest("loadBeforeImage(XGurantorCompanyBObj bObj) " + infoForLogging);
        }
              DWLExceptionUtils.throwDWLBaseException( new DWLUpdateException(), 
            									bObj.getStatus(), DWLStatus.FATAL,
                                  DSEAAdditionsExtsComponentID.XGURANTOR_COMPANY_BOBJ, 
                                  "DIERR",
                                  DSEAAdditionsExtsErrorReasonCode.XGURANTORCOMPANY_BEFORE_IMAGE_NOT_POPULATED, 
                                  bObj.getControl(), errHandler);
    		}
    		
    		bObj.setBeforeImage(beforeImage);
    		
    	}
    logger.finest("RETURN loadBeforeImage(XGurantorCompanyBObj bObj)");
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Populates the parent XGurantorCompanyBObj with all contained BObjs and
     * Type Codes.
     * @generated
    **/
    public void postRetrieveXGurantorCompanyBObj(XGurantorCompanyBObj theBObj, String inquiryLevel, String filter, DWLControl control) throws Exception {
    logger.finest("ENTER postRetrieveXGurantorCompanyBObj(XGurantorCompanyBObj theBObj, String inquiryLevel, String filter, DWLControl control)");
        // processing code types  
        String langId = (String) theBObj.getControl().get(TCRMControlKeys.LANG_ID);
        CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
  
        String IndustryTp = theBObj.getIndustryType();
        if( IndustryTp != null && !IndustryTp.equals("")){
            CodeTypeBObj IndustryBObj = codeTypeCompHelper
                    .getCodeTypeByCode("cdindustrytp", langId, IndustryTp,
                          theBObj.getControl());

            if (IndustryBObj != null) {
                theBObj.setIndustryValue(IndustryBObj.getvalue());
            }

    }
        String AddressUsageTp = theBObj.getAddressUsageType();
        if( AddressUsageTp != null && !AddressUsageTp.equals("")){
            CodeTypeBObj AddressUsageBObj = codeTypeCompHelper
                    .getCodeTypeByCode("cdaddrusagetp", langId, AddressUsageTp,
                          theBObj.getControl());

            if (AddressUsageBObj != null) {
                theBObj.setAddressUsageValue(AddressUsageBObj.getvalue());
            }

    }
        String CountryTp = theBObj.getCountryType();
        if( CountryTp != null && !CountryTp.equals("")){
            CodeTypeBObj CountryBObj = codeTypeCompHelper
                    .getCodeTypeByCode("cdcountrytp", langId, CountryTp,
                          theBObj.getControl());

            if (CountryBObj != null) {
                theBObj.setCountryValue(CountryBObj.getvalue());
            }

    }
        String SourceIdentifierTp = theBObj.getSourceIdentifierType();
        if( SourceIdentifierTp != null && !SourceIdentifierTp.equals("")){
            CodeTypeBObj SourceIdentifierBObj = codeTypeCompHelper
                    .getCodeTypeByCode("cdsourceidenttp", langId, SourceIdentifierTp,
                          theBObj.getControl());

            if (SourceIdentifierBObj != null) {
                theBObj.setSourceIdentifierValue(SourceIdentifierBObj.getvalue());
            }

    }
    logger.finest("RETURN postRetrieveXGurantorCompanyBObj(XGurantorCompanyBObj theBObj, String inquiryLevel, String filter, DWLControl control)");
  }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     **/
    public void loadBeforeImage(XDealerRetailerBObj bObj) throws DWLBaseException {
    logger.finest("ENTER loadBeforeImage(XDealerRetailerBObj bObj)");
    	if( bObj.BeforeImage() == null ){
    	
    		XDealerRetailerBObj beforeImage = null;
    		DWLResponse response = null;
    		
    		try {
    			response = getXDealerRetailer( bObj.getXDealerRetailerpkId(), bObj.getControl());
    			beforeImage = (XDealerRetailerBObj)response.getData();
    			
    		} catch( Exception e){
        if (logger.isFinestEnabled()) {
    				String infoForLogging="Error: Exception " + e.getMessage() + " while updating a record ";
      logger.finest("loadBeforeImage(XDealerRetailerBObj bObj) " + infoForLogging);
        }
              DWLExceptionUtils.throwDWLBaseException(e, 
            									new DWLUpdateException(e.getMessage()), 
            									bObj.getStatus(), DWLStatus.FATAL,
                                  DSEAAdditionsExtsComponentID.XDEALER_RETAILER_BOBJ, 
                                  "DIERR",
                                  DSEAAdditionsExtsErrorReasonCode.XDEALERRETAILER_BEFORE_IMAGE_NOT_POPULATED, 
                                  bObj.getControl(), errHandler);
    		}
    		
    		if( beforeImage == null ){
        if (logger.isFinestEnabled()) {
    		    	String infoForLogging="Error: Before image for updating a record is null ";
      logger.finest("loadBeforeImage(XDealerRetailerBObj bObj) " + infoForLogging);
        }
              DWLExceptionUtils.throwDWLBaseException( new DWLUpdateException(), 
            									bObj.getStatus(), DWLStatus.FATAL,
                                  DSEAAdditionsExtsComponentID.XDEALER_RETAILER_BOBJ, 
                                  "DIERR",
                                  DSEAAdditionsExtsErrorReasonCode.XDEALERRETAILER_BEFORE_IMAGE_NOT_POPULATED, 
                                  bObj.getControl(), errHandler);
    		}
    		
    		bObj.setBeforeImage(beforeImage);
    		
    	}
    logger.finest("RETURN loadBeforeImage(XDealerRetailerBObj bObj)");
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     **/
    public void loadBeforeImage(XMagicRelBObj bObj) throws DWLBaseException {
    logger.finest("ENTER loadBeforeImage(XMagicRelBObj bObj)");
    	if( bObj.BeforeImage() == null ){
    	
    		XMagicRelBObj beforeImage = null;
    		DWLResponse response = null;
    		
    		try {
    			response = getXMagicRel( bObj.getXMagicRelpkId(), bObj.getControl());
    			beforeImage = (XMagicRelBObj)response.getData();
    			
    		} catch( Exception e){
        if (logger.isFinestEnabled()) {
    				String infoForLogging="Error: Exception " + e.getMessage() + " while updating a record ";
      logger.finest("loadBeforeImage(XMagicRelBObj bObj) " + infoForLogging);
        }
              DWLExceptionUtils.throwDWLBaseException(e, 
            									new DWLUpdateException(e.getMessage()), 
            									bObj.getStatus(), DWLStatus.FATAL,
                                  DSEAAdditionsExtsComponentID.XMAGIC_REL_BOBJ, 
                                  "DIERR",
                                  DSEAAdditionsExtsErrorReasonCode.XMAGICREL_BEFORE_IMAGE_NOT_POPULATED, 
                                  bObj.getControl(), errHandler);
    		}
    		
    		if( beforeImage == null ){
        if (logger.isFinestEnabled()) {
    		    	String infoForLogging="Error: Before image for updating a record is null ";
      logger.finest("loadBeforeImage(XMagicRelBObj bObj) " + infoForLogging);
        }
              DWLExceptionUtils.throwDWLBaseException( new DWLUpdateException(), 
            									bObj.getStatus(), DWLStatus.FATAL,
                                  DSEAAdditionsExtsComponentID.XMAGIC_REL_BOBJ, 
                                  "DIERR",
                                  DSEAAdditionsExtsErrorReasonCode.XMAGICREL_BEFORE_IMAGE_NOT_POPULATED, 
                                  bObj.getControl(), errHandler);
    		}
    		
    		bObj.setBeforeImage(beforeImage);
    		
    	}
    logger.finest("RETURN loadBeforeImage(XMagicRelBObj bObj)");
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     **/
    public void loadBeforeImage(XConsentBObj bObj) throws DWLBaseException {
    logger.finest("ENTER loadBeforeImage(XConsentBObj bObj)");
    	if( bObj.BeforeImage() == null ){
    	
    		XConsentBObj beforeImage = null;
    		DWLResponse response = null;
    		
    		try {
    			response = getXConsent( bObj.getXConsentpkId(), bObj.getControl());
    			beforeImage = (XConsentBObj)response.getData();
    			
    		} catch( Exception e){
        if (logger.isFinestEnabled()) {
    				String infoForLogging="Error: Exception " + e.getMessage() + " while updating a record ";
      logger.finest("loadBeforeImage(XConsentBObj bObj) " + infoForLogging);
        }
              DWLExceptionUtils.throwDWLBaseException(e, 
            									new DWLUpdateException(e.getMessage()), 
            									bObj.getStatus(), DWLStatus.FATAL,
                                  DSEAAdditionsExtsComponentID.XCONSENT_BOBJ, 
                                  "DIERR",
                                  DSEAAdditionsExtsErrorReasonCode.XCONSENT_BEFORE_IMAGE_NOT_POPULATED, 
                                  bObj.getControl(), errHandler);
    		}
    		
    		if( beforeImage == null ){
        if (logger.isFinestEnabled()) {
    		    	String infoForLogging="Error: Before image for updating a record is null ";
      logger.finest("loadBeforeImage(XConsentBObj bObj) " + infoForLogging);
        }
              DWLExceptionUtils.throwDWLBaseException( new DWLUpdateException(), 
            									bObj.getStatus(), DWLStatus.FATAL,
                                  DSEAAdditionsExtsComponentID.XCONSENT_BOBJ, 
                                  "DIERR",
                                  DSEAAdditionsExtsErrorReasonCode.XCONSENT_BEFORE_IMAGE_NOT_POPULATED, 
                                  bObj.getControl(), errHandler);
    		}
    		
    		bObj.setBeforeImage(beforeImage);
    		
    	}
    logger.finest("RETURN loadBeforeImage(XConsentBObj bObj)");
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Populates the parent XConsentBObj with all contained BObjs and Type
     * Codes.
     * @generated
    **/
    public void postRetrieveXConsentBObj(XConsentBObj theBObj, String inquiryLevel, String filter, DWLControl control) throws Exception {
    logger.finest("ENTER postRetrieveXConsentBObj(XConsentBObj theBObj, String inquiryLevel, String filter, DWLControl control)");
        // processing code types  
        String langId = (String) theBObj.getControl().get(TCRMControlKeys.LANG_ID);
        CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
  
        String ConsentActionTp = theBObj.getConsentActionType();
        if( ConsentActionTp != null && !ConsentActionTp.equals("")){
            CodeTypeBObj ConsentActionBObj = codeTypeCompHelper
                    .getCodeTypeByCode("xcdactiontp", langId, ConsentActionTp,
                          theBObj.getControl());

            if (ConsentActionBObj != null) {
                theBObj.setConsentActionValue(ConsentActionBObj.getvalue());
            }

    }
        String SourceIdentifierTp = theBObj.getSourceIdentifierType();
        if( SourceIdentifierTp != null && !SourceIdentifierTp.equals("")){
            CodeTypeBObj SourceIdentifierBObj = codeTypeCompHelper
                    .getCodeTypeByCode("cdsourceidenttp", langId, SourceIdentifierTp,
                          theBObj.getControl());

            if (SourceIdentifierBObj != null) {
                theBObj.setSourceIdentifierValue(SourceIdentifierBObj.getvalue());
            }

    }
    logger.finest("RETURN postRetrieveXConsentBObj(XConsentBObj theBObj, String inquiryLevel, String filter, DWLControl control)");
  }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     **/
    public void loadBeforeImage(XContractRelBObj bObj) throws DWLBaseException {
    logger.finest("ENTER loadBeforeImage(XContractRelBObj bObj)");
    	if( bObj.BeforeImage() == null ){
    	
    		XContractRelBObj beforeImage = null;
    		DWLResponse response = null;
    		
    		try {
    			response = getXContractRel( bObj.getXContractRelpkId(), bObj.getControl());
    			beforeImage = (XContractRelBObj)response.getData();
    			
    		} catch( Exception e){
        if (logger.isFinestEnabled()) {
    				String infoForLogging="Error: Exception " + e.getMessage() + " while updating a record ";
      logger.finest("loadBeforeImage(XContractRelBObj bObj) " + infoForLogging);
        }
              DWLExceptionUtils.throwDWLBaseException(e, 
            									new DWLUpdateException(e.getMessage()), 
            									bObj.getStatus(), DWLStatus.FATAL,
                                  DSEAAdditionsExtsComponentID.XCONTRACT_REL_BOBJ, 
                                  "DIERR",
                                  DSEAAdditionsExtsErrorReasonCode.XCONTRACTREL_BEFORE_IMAGE_NOT_POPULATED, 
                                  bObj.getControl(), errHandler);
    		}
    		
    		if( beforeImage == null ){
        if (logger.isFinestEnabled()) {
    		    	String infoForLogging="Error: Before image for updating a record is null ";
      logger.finest("loadBeforeImage(XContractRelBObj bObj) " + infoForLogging);
        }
              DWLExceptionUtils.throwDWLBaseException( new DWLUpdateException(), 
            									bObj.getStatus(), DWLStatus.FATAL,
                                  DSEAAdditionsExtsComponentID.XCONTRACT_REL_BOBJ, 
                                  "DIERR",
                                  DSEAAdditionsExtsErrorReasonCode.XCONTRACTREL_BEFORE_IMAGE_NOT_POPULATED, 
                                  bObj.getControl(), errHandler);
    		}
    		
    		bObj.setBeforeImage(beforeImage);
    		
    	}
    logger.finest("RETURN loadBeforeImage(XContractRelBObj bObj)");
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     **/
    public void loadBeforeImage(XCustomerRetailerJPNBObj bObj) throws DWLBaseException {
    logger.finest("ENTER loadBeforeImage(XCustomerRetailerJPNBObj bObj)");
    	if( bObj.BeforeImage() == null ){
    	
    		XCustomerRetailerJPNBObj beforeImage = null;
    		DWLResponse response = null;
    		
    		try {
    			response = getXCustomerRetailerJPN( bObj.getXCustomerRetailerJPNpkId(), bObj.getControl());
    			beforeImage = (XCustomerRetailerJPNBObj)response.getData();
    			
    		} catch( Exception e){
        if (logger.isFinestEnabled()) {
    				String infoForLogging="Error: Exception " + e.getMessage() + " while updating a record ";
      logger.finest("loadBeforeImage(XCustomerRetailerJPNBObj bObj) " + infoForLogging);
        }
              DWLExceptionUtils.throwDWLBaseException(e, 
            									new DWLUpdateException(e.getMessage()), 
            									bObj.getStatus(), DWLStatus.FATAL,
                                  DSEAAdditionsExtsComponentID.XCUSTOMER_RETAILER_JPNBOBJ, 
                                  "DIERR",
                                  DSEAAdditionsExtsErrorReasonCode.XCUSTOMERRETAILERJPN_BEFORE_IMAGE_NOT_POPULATED, 
                                  bObj.getControl(), errHandler);
    		}
    		
    		if( beforeImage == null ){
        if (logger.isFinestEnabled()) {
    		    	String infoForLogging="Error: Before image for updating a record is null ";
      logger.finest("loadBeforeImage(XCustomerRetailerJPNBObj bObj) " + infoForLogging);
        }
              DWLExceptionUtils.throwDWLBaseException( new DWLUpdateException(), 
            									bObj.getStatus(), DWLStatus.FATAL,
                                  DSEAAdditionsExtsComponentID.XCUSTOMER_RETAILER_JPNBOBJ, 
                                  "DIERR",
                                  DSEAAdditionsExtsErrorReasonCode.XCUSTOMERRETAILERJPN_BEFORE_IMAGE_NOT_POPULATED, 
                                  bObj.getControl(), errHandler);
    		}
    		
    		bObj.setBeforeImage(beforeImage);
    		
    	}
    if( bObj.getXRetailerBObj() != null ){
      XRetailerBObj childBObj = bObj.getXRetailerBObj();
      if( childBObj.getEObjXRetailer().getRetailerpkId() != null ){
        childBObj.populateBeforeImage( );
      }
    }
    logger.finest("RETURN loadBeforeImage(XCustomerRetailerJPNBObj bObj)");
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Populates the parent XCustomerRetailerJPNBObj with all contained BObjs
     * and Type Codes.
     * @generated
    **/
    public void postRetrieveXCustomerRetailerJPNBObj(XCustomerRetailerJPNBObj theBObj, String inquiryLevel, String filter, DWLControl control) throws Exception {
    logger.finest("ENTER postRetrieveXCustomerRetailerJPNBObj(XCustomerRetailerJPNBObj theBObj, String inquiryLevel, String filter, DWLControl control)");
        DWLResponse containedResponse = null;
         // processing single valued reference XRetailerBObj
  
        if( theBObj.getXRetailerBObj() == null ){
            XRetailerBObj containedBObj = null;
            // processing an entity 
            String containedPk = theBObj.getRetailerId();
            if (containedPk!=null) {
            	if (logger.isFinestEnabled()) {	
    		   		String infoForLogging="Single Value reference - before containedResponse for XRetailerBObj, containedPk = " +containedPk;
      logger.finest("postRetrieveXCustomerRetailerJPNBObj(XCustomerRetailerJPNBObj theBObj, String inquiryLevel, String filter, DWLControl control) " + infoForLogging);
        }
            	containedResponse = getXRetailer( containedPk, control);
        if (logger.isFinestEnabled()) {	
    		   		String infoForLogging="Single Value reference - after containedResponse for XRetailerBObj, containedPk = " +containedPk;
      logger.finest("postRetrieveXCustomerRetailerJPNBObj(XCustomerRetailerJPNBObj theBObj, String inquiryLevel, String filter, DWLControl control) " + infoForLogging);
        }
            	containedBObj = (XRetailerBObj)containedResponse.getData();
            } else {	
            	if (logger.isFinestEnabled()) {
    		   		String infoForLogging="The contained pk is null";
      logger.finest("postRetrieveXCustomerRetailerJPNBObj(XCustomerRetailerJPNBObj theBObj, String inquiryLevel, String filter, DWLControl control) " + infoForLogging);
            	}
            }	
 // end else key is persisted in this object
            if( containedBObj != null ){
                containedBObj.setControl(control);
                theBObj.setXRetailerBObj(containedBObj);
            }
        }
        // processing code types  
        String langId = (String) theBObj.getControl().get(TCRMControlKeys.LANG_ID);
        CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
  
        String SourceIdentifierTp = theBObj.getSourceIdentifierType();
        if( SourceIdentifierTp != null && !SourceIdentifierTp.equals("")){
            CodeTypeBObj SourceIdentifierBObj = codeTypeCompHelper
                    .getCodeTypeByCode("cdsourceidenttp", langId, SourceIdentifierTp,
                          theBObj.getControl());

            if (SourceIdentifierBObj != null) {
                theBObj.setSourceIdentifierValue(SourceIdentifierBObj.getvalue());
            }

    }
    logger.finest("RETURN postRetrieveXCustomerRetailerJPNBObj(XCustomerRetailerJPNBObj theBObj, String inquiryLevel, String filter, DWLControl control)");
  }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     **/
    public void loadBeforeImage(XVehicleJPNBObj bObj) throws DWLBaseException {
    logger.finest("ENTER loadBeforeImage(XVehicleJPNBObj bObj)");
    	if( bObj.BeforeImage() == null ){
    	
    		XVehicleJPNBObj beforeImage = null;
    		DWLResponse response = null;
    		
    		try {
    			response = getXVehicleJPN( bObj.getXVehicleJPNpkId(), bObj.getControl());
    			beforeImage = (XVehicleJPNBObj)response.getData();
    			
    		} catch( Exception e){
        if (logger.isFinestEnabled()) {
    				String infoForLogging="Error: Exception " + e.getMessage() + " while updating a record ";
      logger.finest("loadBeforeImage(XVehicleJPNBObj bObj) " + infoForLogging);
        }
              DWLExceptionUtils.throwDWLBaseException(e, 
            									new DWLUpdateException(e.getMessage()), 
            									bObj.getStatus(), DWLStatus.FATAL,
                                  DSEAAdditionsExtsComponentID.XVEHICLE_JPNBOBJ, 
                                  "DIERR",
                                  DSEAAdditionsExtsErrorReasonCode.XVEHICLEJPN_BEFORE_IMAGE_NOT_POPULATED, 
                                  bObj.getControl(), errHandler);
    		}
    		
    		if( beforeImage == null ){
        if (logger.isFinestEnabled()) {
    		    	String infoForLogging="Error: Before image for updating a record is null ";
      logger.finest("loadBeforeImage(XVehicleJPNBObj bObj) " + infoForLogging);
        }
              DWLExceptionUtils.throwDWLBaseException( new DWLUpdateException(), 
            									bObj.getStatus(), DWLStatus.FATAL,
                                  DSEAAdditionsExtsComponentID.XVEHICLE_JPNBOBJ, 
                                  "DIERR",
                                  DSEAAdditionsExtsErrorReasonCode.XVEHICLEJPN_BEFORE_IMAGE_NOT_POPULATED, 
                                  bObj.getControl(), errHandler);
    		}
    		
    		bObj.setBeforeImage(beforeImage);
    		
    	}
    logger.finest("RETURN loadBeforeImage(XVehicleJPNBObj bObj)");
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Populates the parent XVehicleJPNBObj with all contained BObjs and Type
     * Codes.
     * @generated
    **/
    public void postRetrieveXVehicleJPNBObj(XVehicleJPNBObj theBObj, String inquiryLevel, String filter, DWLControl control) throws Exception {
    logger.finest("ENTER postRetrieveXVehicleJPNBObj(XVehicleJPNBObj theBObj, String inquiryLevel, String filter, DWLControl control)");
        // processing code types  
        String langId = (String) theBObj.getControl().get(TCRMControlKeys.LANG_ID);
        CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
  
        String SourceIdentifierTp = theBObj.getSourceIdentifierType();
        if( SourceIdentifierTp != null && !SourceIdentifierTp.equals("")){
            CodeTypeBObj SourceIdentifierBObj = codeTypeCompHelper
                    .getCodeTypeByCode("cdsourceidenttp", langId, SourceIdentifierTp,
                          theBObj.getControl());

            if (SourceIdentifierBObj != null) {
                theBObj.setSourceIdentifierValue(SourceIdentifierBObj.getvalue());
            }

    }
    logger.finest("RETURN postRetrieveXVehicleJPNBObj(XVehicleJPNBObj theBObj, String inquiryLevel, String filter, DWLControl control)");
  }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     **/
    public void loadBeforeImage(XCustomerVehicleJPNBObj bObj) throws DWLBaseException {
    logger.finest("ENTER loadBeforeImage(XCustomerVehicleJPNBObj bObj)");
    	if( bObj.BeforeImage() == null ){
    	
    		XCustomerVehicleJPNBObj beforeImage = null;
    		DWLResponse response = null;
    		
    		try {
    			response = getXCustomerVehicleJPN( bObj.getXCustomerVehicleJPNpkId(), bObj.getControl());
    			beforeImage = (XCustomerVehicleJPNBObj)response.getData();
    			
    		} catch( Exception e){
        if (logger.isFinestEnabled()) {
    				String infoForLogging="Error: Exception " + e.getMessage() + " while updating a record ";
      logger.finest("loadBeforeImage(XCustomerVehicleJPNBObj bObj) " + infoForLogging);
        }
              DWLExceptionUtils.throwDWLBaseException(e, 
            									new DWLUpdateException(e.getMessage()), 
            									bObj.getStatus(), DWLStatus.FATAL,
                                  DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_JPNBOBJ, 
                                  "DIERR",
                                  DSEAAdditionsExtsErrorReasonCode.XCUSTOMERVEHICLEJPN_BEFORE_IMAGE_NOT_POPULATED, 
                                  bObj.getControl(), errHandler);
    		}
    		
    		if( beforeImage == null ){
        if (logger.isFinestEnabled()) {
    		    	String infoForLogging="Error: Before image for updating a record is null ";
      logger.finest("loadBeforeImage(XCustomerVehicleJPNBObj bObj) " + infoForLogging);
        }
              DWLExceptionUtils.throwDWLBaseException( new DWLUpdateException(), 
            									bObj.getStatus(), DWLStatus.FATAL,
                                  DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_JPNBOBJ, 
                                  "DIERR",
                                  DSEAAdditionsExtsErrorReasonCode.XCUSTOMERVEHICLEJPN_BEFORE_IMAGE_NOT_POPULATED, 
                                  bObj.getControl(), errHandler);
    		}
    		
    		bObj.setBeforeImage(beforeImage);
    		
    	}
    if( bObj.getXVehicleJPNBObj() != null ){
      XVehicleJPNBObj childBObj = bObj.getXVehicleJPNBObj();
      if( childBObj.getEObjXVehicleJPN().getXVehicleJPNpkId() != null ){
        childBObj.populateBeforeImage( );
      }
    }
    Vector<?> vecXCustomerVehicleRoleJPNBObj = bObj.getItemsXCustomerVehicleRoleJPNBObj();
    Vector<XCustomerVehicleRoleJPNBObj> updXCustomerVehicleRoleJPNBObj = new Vector<XCustomerVehicleRoleJPNBObj>();
    for (int idx0 = 0; idx0 < vecXCustomerVehicleRoleJPNBObj.size(); idx0++) {
      XCustomerVehicleRoleJPNBObj childBObj = (XCustomerVehicleRoleJPNBObj) vecXCustomerVehicleRoleJPNBObj
          .elementAt(idx0);

      String pkId = childBObj.getXCustomerVehicleRoleJPNpkId();

      if (StringUtils.isNonBlank(pkId)) {
        updXCustomerVehicleRoleJPNBObj.add(childBObj);
      }
    }
    if( updXCustomerVehicleRoleJPNBObj.size() > 1){
      try {
        DWLResponse containedResponse = getAllVehicleRoleByCustomerVehicleJPNId( bObj.getXCustomerVehicleJPNpkId(),  bObj.getControl() );
        Vector<?> listAllChildrenBeforeImage = (Vector<?>)containedResponse.getData();
        if( listAllChildrenBeforeImage != null ){
          for (int idx = 0; idx < updXCustomerVehicleRoleJPNBObj.size(); idx++) {

            XCustomerVehicleRoleJPNBObj childBObj = (XCustomerVehicleRoleJPNBObj) updXCustomerVehicleRoleJPNBObj
              .elementAt(idx);
            String pkId = childBObj.getXCustomerVehicleRoleJPNpkId();

            for (int idxBeforeImage = 0; idxBeforeImage < listAllChildrenBeforeImage
              .size(); idxBeforeImage++) {

              XCustomerVehicleRoleJPNBObj bobjBeforeImage = (XCustomerVehicleRoleJPNBObj) listAllChildrenBeforeImage
                .elementAt(idxBeforeImage);

              String idBeforeImage = bobjBeforeImage.getXCustomerVehicleRoleJPNpkId();

              if (pkId.equalsIgnoreCase(idBeforeImage)) {
                childBObj.setBeforeImage(bobjBeforeImage);
                childBObj.populateBeforeImage();

                break;
              }
            }
          }
        }
    		} catch( Exception e){
    			if (logger.isFinestEnabled()) {	
    		   		String infoForLogging="Error: Exception " + e.getMessage() + " while updating a record ";
      logger.finest("loadBeforeImage(XCustomerVehicleJPNBObj bObj) " + infoForLogging);
        }
             	DWLExceptionUtils.throwDWLBaseException(e, 
            									new DWLUpdateException(e.getMessage()), 
            									bObj.getStatus(), DWLStatus.FATAL,
                                  DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_JPNBOBJ, 
                                  "DIERR",
                                  DSEAAdditionsExtsErrorReasonCode.XCUSTOMERVEHICLEJPN_BEFORE_IMAGE_NOT_POPULATED, 
                                  bObj.getControl(), errHandler);
    		}
    }
    else if( updXCustomerVehicleRoleJPNBObj.size() == 1){
      XCustomerVehicleRoleJPNBObj childBObj = (XCustomerVehicleRoleJPNBObj) updXCustomerVehicleRoleJPNBObj.elementAt(0);
      childBObj.populateBeforeImage();
    }
    
    logger.finest("RETURN loadBeforeImage(XCustomerVehicleJPNBObj bObj)");
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Populates the parent XCustomerVehicleJPNBObj with all contained BObjs and
     * Type Codes.
     * @generated
    **/
  @SuppressWarnings("rawtypes")
    public void postRetrieveXCustomerVehicleJPNBObj(XCustomerVehicleJPNBObj theBObj, String inquiryLevel, String filter, DWLControl control) throws Exception {
    logger.finest("ENTER postRetrieveXCustomerVehicleJPNBObj(XCustomerVehicleJPNBObj theBObj, String inquiryLevel, String filter, DWLControl control)");
        DWLResponse containedResponse = null;
         // processing single valued reference XVehicleJPNBObj
  
        if( theBObj.getXVehicleJPNBObj() == null ){
            XVehicleJPNBObj containedBObj = null;
            // processing an entity 
            String containedPk = theBObj.getVehicleId();
            if (containedPk!=null) {
            	if (logger.isFinestEnabled()) {	
    		   		String infoForLogging="Single Value reference - before containedResponse for XVehicleJPNBObj, containedPk = " +containedPk;
      logger.finest("postRetrieveXCustomerVehicleJPNBObj(XCustomerVehicleJPNBObj theBObj, String inquiryLevel, String filter, DWLControl control) " + infoForLogging);
        }
            	containedResponse = getXVehicleJPN( containedPk, control);
        if (logger.isFinestEnabled()) {	
    		   		String infoForLogging="Single Value reference - after containedResponse for XVehicleJPNBObj, containedPk = " +containedPk;
      logger.finest("postRetrieveXCustomerVehicleJPNBObj(XCustomerVehicleJPNBObj theBObj, String inquiryLevel, String filter, DWLControl control) " + infoForLogging);
        }
            	containedBObj = (XVehicleJPNBObj)containedResponse.getData();
            } else {	
            	if (logger.isFinestEnabled()) {
    		   		String infoForLogging="The contained pk is null";
      logger.finest("postRetrieveXCustomerVehicleJPNBObj(XCustomerVehicleJPNBObj theBObj, String inquiryLevel, String filter, DWLControl control) " + infoForLogging);
            	}
            }	
 // end else key is persisted in this object
            if( containedBObj != null ){
                containedBObj.setControl(control);
                theBObj.setXVehicleJPNBObj(containedBObj);
            }
        }
        // processing multi valued reference 
    if (theBObj.getXCustomerVehicleJPNpkId()==null) {
      if (logger.isFinestEnabled()) {	
        String infoForLogging="theBObj.getXCustomerVehicleJPNpkId() == null";
      logger.finest("postRetrieveXCustomerVehicleJPNBObj(XCustomerVehicleJPNBObj theBObj, String inquiryLevel, String filter, DWLControl control) " + infoForLogging);
      	}
      }
      
        containedResponse = getAllVehicleRoleByCustomerVehicleJPNId( theBObj.getXCustomerVehicleJPNpkId(), control);
    if (logger.isFinestEnabled()) {	
    		String infoForLogging="Successfully obtained the containedResponse for multi reference";
      logger.finest("postRetrieveXCustomerVehicleJPNBObj(XCustomerVehicleJPNBObj theBObj, String inquiryLevel, String filter, DWLControl control) " + infoForLogging);
    }
        Vector vec = null;
        vec = (Vector) containedResponse.getData();
        if( vec != null ){
        	for (int i = 0; i < vec.size(); i++) {
            	XCustomerVehicleRoleJPNBObj object = (XCustomerVehicleRoleJPNBObj) vec.elementAt(i);
            	object.setControl(control);
            	theBObj.setXCustomerVehicleRoleJPNBObj(object);
        	}
        }
        // processing code types  
        String langId = (String) theBObj.getControl().get(TCRMControlKeys.LANG_ID);
        CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
  
        String ConnectMeUsageTp = theBObj.getConnectMeUsageType();
        if( ConnectMeUsageTp != null && !ConnectMeUsageTp.equals("")){
            CodeTypeBObj ConnectMeUsageBObj = codeTypeCompHelper
                    .getCodeTypeByCode("xcdconnectmeusagetp", langId, ConnectMeUsageTp,
                          theBObj.getControl());

            if (ConnectMeUsageBObj != null) {
                theBObj.setConnectMeUsageValue(ConnectMeUsageBObj.getvalue());
            }

    }
        String VehicleSalesTp = theBObj.getVehicleSalesType();
        if( VehicleSalesTp != null && !VehicleSalesTp.equals("")){
            CodeTypeBObj VehicleSalesBObj = codeTypeCompHelper
                    .getCodeTypeByCode("xcdvehiclesalestp", langId, VehicleSalesTp,
                          theBObj.getControl());

            if (VehicleSalesBObj != null) {
                theBObj.setVehicleSalesValue(VehicleSalesBObj.getvalue());
            }

    }
        String VehicleUsageTp = theBObj.getVehicleUsageType();
        if( VehicleUsageTp != null && !VehicleUsageTp.equals("")){
            CodeTypeBObj VehicleUsageBObj = codeTypeCompHelper
                    .getCodeTypeByCode("xcdvehicleusagetp", langId, VehicleUsageTp,
                          theBObj.getControl());

            if (VehicleUsageBObj != null) {
                theBObj.setVehicleUsageValue(VehicleUsageBObj.getvalue());
            }

    }
        String SourceIdentifierTp = theBObj.getSourceIdentifierType();
        if( SourceIdentifierTp != null && !SourceIdentifierTp.equals("")){
            CodeTypeBObj SourceIdentifierBObj = codeTypeCompHelper
                    .getCodeTypeByCode("cdsourceidenttp", langId, SourceIdentifierTp,
                          theBObj.getControl());

            if (SourceIdentifierBObj != null) {
                theBObj.setSourceIdentifierValue(SourceIdentifierBObj.getvalue());
            }

    }
    logger.finest("RETURN postRetrieveXCustomerVehicleJPNBObj(XCustomerVehicleJPNBObj theBObj, String inquiryLevel, String filter, DWLControl control)");
  }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     **/
    public void loadBeforeImage(XCustomerVehicleRoleJPNBObj bObj) throws DWLBaseException {
    logger.finest("ENTER loadBeforeImage(XCustomerVehicleRoleJPNBObj bObj)");
    	if( bObj.BeforeImage() == null ){
    	
    		XCustomerVehicleRoleJPNBObj beforeImage = null;
    		DWLResponse response = null;
    		
    		try {
    			response = getXCustomerVehicleRoleJPN( bObj.getXCustomerVehicleRoleJPNpkId(), bObj.getControl());
    			beforeImage = (XCustomerVehicleRoleJPNBObj)response.getData();
    			
    		} catch( Exception e){
        if (logger.isFinestEnabled()) {
    				String infoForLogging="Error: Exception " + e.getMessage() + " while updating a record ";
      logger.finest("loadBeforeImage(XCustomerVehicleRoleJPNBObj bObj) " + infoForLogging);
        }
              DWLExceptionUtils.throwDWLBaseException(e, 
            									new DWLUpdateException(e.getMessage()), 
            									bObj.getStatus(), DWLStatus.FATAL,
                                  DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_ROLE_JPNBOBJ, 
                                  "DIERR",
                                  DSEAAdditionsExtsErrorReasonCode.XCUSTOMERVEHICLEROLEJPN_BEFORE_IMAGE_NOT_POPULATED, 
                                  bObj.getControl(), errHandler);
    		}
    		
    		if( beforeImage == null ){
        if (logger.isFinestEnabled()) {
    		    	String infoForLogging="Error: Before image for updating a record is null ";
      logger.finest("loadBeforeImage(XCustomerVehicleRoleJPNBObj bObj) " + infoForLogging);
        }
              DWLExceptionUtils.throwDWLBaseException( new DWLUpdateException(), 
            									bObj.getStatus(), DWLStatus.FATAL,
                                  DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_ROLE_JPNBOBJ, 
                                  "DIERR",
                                  DSEAAdditionsExtsErrorReasonCode.XCUSTOMERVEHICLEROLEJPN_BEFORE_IMAGE_NOT_POPULATED, 
                                  bObj.getControl(), errHandler);
    		}
    		
    		bObj.setBeforeImage(beforeImage);
    		
    	}
    logger.finest("RETURN loadBeforeImage(XCustomerVehicleRoleJPNBObj bObj)");
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Populates the parent XCustomerVehicleRoleJPNBObj with all contained BObjs
     * and Type Codes.
     * @generated
    **/
    public void postRetrieveXCustomerVehicleRoleJPNBObj(XCustomerVehicleRoleJPNBObj theBObj, String inquiryLevel, String filter, DWLControl control) throws Exception {
    logger.finest("ENTER postRetrieveXCustomerVehicleRoleJPNBObj(XCustomerVehicleRoleJPNBObj theBObj, String inquiryLevel, String filter, DWLControl control)");
        // processing code types  
        String langId = (String) theBObj.getControl().get(TCRMControlKeys.LANG_ID);
        CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
  
        String VehicleRoleTp = theBObj.getVehicleRoleType();
        if( VehicleRoleTp != null && !VehicleRoleTp.equals("")){
            CodeTypeBObj VehicleRoleBObj = codeTypeCompHelper
                    .getCodeTypeByCode("xcdvehicleroletp", langId, VehicleRoleTp,
                          theBObj.getControl());

            if (VehicleRoleBObj != null) {
                theBObj.setVehicleRoleValue(VehicleRoleBObj.getvalue());
            }

    }
        String SourceIdentifierTp = theBObj.getSourceIdentifierType();
        if( SourceIdentifierTp != null && !SourceIdentifierTp.equals("")){
            CodeTypeBObj SourceIdentifierBObj = codeTypeCompHelper
                    .getCodeTypeByCode("cdsourceidenttp", langId, SourceIdentifierTp,
                          theBObj.getControl());

            if (SourceIdentifierBObj != null) {
                theBObj.setSourceIdentifierValue(SourceIdentifierBObj.getvalue());
            }

    }
    logger.finest("RETURN postRetrieveXCustomerVehicleRoleJPNBObj(XCustomerVehicleRoleJPNBObj theBObj, String inquiryLevel, String filter, DWLControl control)");
  }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     **/
    public void loadBeforeImage(XDataSharingBObj bObj) throws DWLBaseException {
    logger.finest("ENTER loadBeforeImage(XDataSharingBObj bObj)");
    	if( bObj.BeforeImage() == null ){
    	
    		XDataSharingBObj beforeImage = null;
    		DWLResponse response = null;
    		
    		try {
    			response = getXDataSharing( bObj.getDataSharingpkId(), bObj.getControl());
    			beforeImage = (XDataSharingBObj)response.getData();
    			
    		} catch( Exception e){
        if (logger.isFinestEnabled()) {
    				String infoForLogging="Error: Exception " + e.getMessage() + " while updating a record ";
      logger.finest("loadBeforeImage(XDataSharingBObj bObj) " + infoForLogging);
        }
              DWLExceptionUtils.throwDWLBaseException(e, 
            									new DWLUpdateException(e.getMessage()), 
            									bObj.getStatus(), DWLStatus.FATAL,
                                  DSEAAdditionsExtsComponentID.XDATA_SHARING_BOBJ, 
                                  "DIERR",
                                  DSEAAdditionsExtsErrorReasonCode.XDATASHARING_BEFORE_IMAGE_NOT_POPULATED, 
                                  bObj.getControl(), errHandler);
    		}
    		
    		if( beforeImage == null ){
        if (logger.isFinestEnabled()) {
    		    	String infoForLogging="Error: Before image for updating a record is null ";
      logger.finest("loadBeforeImage(XDataSharingBObj bObj) " + infoForLogging);
        }
              DWLExceptionUtils.throwDWLBaseException( new DWLUpdateException(), 
            									bObj.getStatus(), DWLStatus.FATAL,
                                  DSEAAdditionsExtsComponentID.XDATA_SHARING_BOBJ, 
                                  "DIERR",
                                  DSEAAdditionsExtsErrorReasonCode.XDATASHARING_BEFORE_IMAGE_NOT_POPULATED, 
                                  bObj.getControl(), errHandler);
    		}
    		
    		bObj.setBeforeImage(beforeImage);
    		
    	}
    logger.finest("RETURN loadBeforeImage(XDataSharingBObj bObj)");
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Populates the parent XDataSharingBObj with all contained BObjs and Type
     * Codes.
     * @generated
    **/
    public void postRetrieveXDataSharingBObj(XDataSharingBObj theBObj, String inquiryLevel, String filter, DWLControl control) throws Exception {
    logger.finest("ENTER postRetrieveXDataSharingBObj(XDataSharingBObj theBObj, String inquiryLevel, String filter, DWLControl control)");
        // processing code types  
        String langId = (String) theBObj.getControl().get(TCRMControlKeys.LANG_ID);
        CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
  
        String SourceIdentifierTp = theBObj.getSourceIdentifierType();
        if( SourceIdentifierTp != null && !SourceIdentifierTp.equals("")){
            CodeTypeBObj SourceIdentifierBObj = codeTypeCompHelper
                    .getCodeTypeByCode("cdsourceidenttp", langId, SourceIdentifierTp,
                          theBObj.getControl());

            if (SourceIdentifierBObj != null) {
                theBObj.setSourceIdentifierValue(SourceIdentifierBObj.getvalue());
            }

    }
    logger.finest("RETURN postRetrieveXDataSharingBObj(XDataSharingBObj theBObj, String inquiryLevel, String filter, DWLControl control)");
  }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     **/
    public void loadBeforeImage(XVehicleKORBObj bObj) throws DWLBaseException {
    logger.finest("ENTER loadBeforeImage(XVehicleKORBObj bObj)");
    	if( bObj.BeforeImage() == null ){
    	
    		XVehicleKORBObj beforeImage = null;
    		DWLResponse response = null;
    		
    		try {
    			response = getXVehicleKOR( bObj.getXVehicleKORpkId(), bObj.getControl());
    			beforeImage = (XVehicleKORBObj)response.getData();
    			
    		} catch( Exception e){
        if (logger.isFinestEnabled()) {
    				String infoForLogging="Error: Exception " + e.getMessage() + " while updating a record ";
      logger.finest("loadBeforeImage(XVehicleKORBObj bObj) " + infoForLogging);
        }
              DWLExceptionUtils.throwDWLBaseException(e, 
            									new DWLUpdateException(e.getMessage()), 
            									bObj.getStatus(), DWLStatus.FATAL,
                                  DSEAAdditionsExtsComponentID.XVEHICLE_KORBOBJ, 
                                  "DIERR",
                                  DSEAAdditionsExtsErrorReasonCode.XVEHICLEKOR_BEFORE_IMAGE_NOT_POPULATED, 
                                  bObj.getControl(), errHandler);
    		}
    		
    		if( beforeImage == null ){
        if (logger.isFinestEnabled()) {
    		    	String infoForLogging="Error: Before image for updating a record is null ";
      logger.finest("loadBeforeImage(XVehicleKORBObj bObj) " + infoForLogging);
        }
              DWLExceptionUtils.throwDWLBaseException( new DWLUpdateException(), 
            									bObj.getStatus(), DWLStatus.FATAL,
                                  DSEAAdditionsExtsComponentID.XVEHICLE_KORBOBJ, 
                                  "DIERR",
                                  DSEAAdditionsExtsErrorReasonCode.XVEHICLEKOR_BEFORE_IMAGE_NOT_POPULATED, 
                                  bObj.getControl(), errHandler);
    		}
    		
    		bObj.setBeforeImage(beforeImage);
    		
    	}
    logger.finest("RETURN loadBeforeImage(XVehicleKORBObj bObj)");
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Populates the parent XVehicleKORBObj with all contained BObjs and Type
     * Codes.
     * @generated
    **/
    public void postRetrieveXVehicleKORBObj(XVehicleKORBObj theBObj, String inquiryLevel, String filter, DWLControl control) throws Exception {
    logger.finest("ENTER postRetrieveXVehicleKORBObj(XVehicleKORBObj theBObj, String inquiryLevel, String filter, DWLControl control)");
        // processing code types  
        String langId = (String) theBObj.getControl().get(TCRMControlKeys.LANG_ID);
        CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
  
        String SourceIdentifierTp = theBObj.getSourceIdentifierType();
        if( SourceIdentifierTp != null && !SourceIdentifierTp.equals("")){
            CodeTypeBObj SourceIdentifierBObj = codeTypeCompHelper
                    .getCodeTypeByCode("cdsourceidenttp", langId, SourceIdentifierTp,
                          theBObj.getControl());

            if (SourceIdentifierBObj != null) {
                theBObj.setSourceIdentifierValue(SourceIdentifierBObj.getvalue());
            }

    }
    logger.finest("RETURN postRetrieveXVehicleKORBObj(XVehicleKORBObj theBObj, String inquiryLevel, String filter, DWLControl control)");
  }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     **/
    public void loadBeforeImage(XCustomerVehicleKORBObj bObj) throws DWLBaseException {
    logger.finest("ENTER loadBeforeImage(XCustomerVehicleKORBObj bObj)");
    	if( bObj.BeforeImage() == null ){
    	
    		XCustomerVehicleKORBObj beforeImage = null;
    		DWLResponse response = null;
    		
    		try {
    			response = getXCustomerVehicleKOR( bObj.getXCustomerVehicleKORpkId(), bObj.getControl());
    			beforeImage = (XCustomerVehicleKORBObj)response.getData();
    			
    		} catch( Exception e){
        if (logger.isFinestEnabled()) {
    				String infoForLogging="Error: Exception " + e.getMessage() + " while updating a record ";
      logger.finest("loadBeforeImage(XCustomerVehicleKORBObj bObj) " + infoForLogging);
        }
              DWLExceptionUtils.throwDWLBaseException(e, 
            									new DWLUpdateException(e.getMessage()), 
            									bObj.getStatus(), DWLStatus.FATAL,
                                  DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_KORBOBJ, 
                                  "DIERR",
                                  DSEAAdditionsExtsErrorReasonCode.XCUSTOMERVEHICLEKOR_BEFORE_IMAGE_NOT_POPULATED, 
                                  bObj.getControl(), errHandler);
    		}
    		
    		if( beforeImage == null ){
        if (logger.isFinestEnabled()) {
    		    	String infoForLogging="Error: Before image for updating a record is null ";
      logger.finest("loadBeforeImage(XCustomerVehicleKORBObj bObj) " + infoForLogging);
        }
              DWLExceptionUtils.throwDWLBaseException( new DWLUpdateException(), 
            									bObj.getStatus(), DWLStatus.FATAL,
                                  DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_KORBOBJ, 
                                  "DIERR",
                                  DSEAAdditionsExtsErrorReasonCode.XCUSTOMERVEHICLEKOR_BEFORE_IMAGE_NOT_POPULATED, 
                                  bObj.getControl(), errHandler);
    		}
    		
    		bObj.setBeforeImage(beforeImage);
    		
    	}
    if( bObj.getXVehicleKORBObj() != null ){
      XVehicleKORBObj childBObj = bObj.getXVehicleKORBObj();
      if( childBObj.getEObjXVehicleKOR().getXVehicleKORpkId() != null ){
        childBObj.populateBeforeImage( );
      }
    }
    Vector<?> vecXCustomerVehicleRoleKORBObj = bObj.getItemsXCustomerVehicleRoleKORBObj();
    Vector<XCustomerVehicleRoleKORBObj> updXCustomerVehicleRoleKORBObj = new Vector<XCustomerVehicleRoleKORBObj>();
    for (int idx0 = 0; idx0 < vecXCustomerVehicleRoleKORBObj.size(); idx0++) {
      XCustomerVehicleRoleKORBObj childBObj = (XCustomerVehicleRoleKORBObj) vecXCustomerVehicleRoleKORBObj
          .elementAt(idx0);

      String pkId = childBObj.getXCustomerVehicleRoleKORpkId();

      if (StringUtils.isNonBlank(pkId)) {
        updXCustomerVehicleRoleKORBObj.add(childBObj);
      }
    }
    if( updXCustomerVehicleRoleKORBObj.size() > 1){
      try {
        DWLResponse containedResponse = getAllVehicleRoleByCustomerVehicleKORId( bObj.getXCustomerVehicleKORpkId(),  bObj.getControl() );
        Vector<?> listAllChildrenBeforeImage = (Vector<?>)containedResponse.getData();
        if( listAllChildrenBeforeImage != null ){
          for (int idx = 0; idx < updXCustomerVehicleRoleKORBObj.size(); idx++) {

            XCustomerVehicleRoleKORBObj childBObj = (XCustomerVehicleRoleKORBObj) updXCustomerVehicleRoleKORBObj
              .elementAt(idx);
            String pkId = childBObj.getXCustomerVehicleRoleKORpkId();

            for (int idxBeforeImage = 0; idxBeforeImage < listAllChildrenBeforeImage
              .size(); idxBeforeImage++) {

              XCustomerVehicleRoleKORBObj bobjBeforeImage = (XCustomerVehicleRoleKORBObj) listAllChildrenBeforeImage
                .elementAt(idxBeforeImage);

              String idBeforeImage = bobjBeforeImage.getXCustomerVehicleRoleKORpkId();

              if (pkId.equalsIgnoreCase(idBeforeImage)) {
                childBObj.setBeforeImage(bobjBeforeImage);
                childBObj.populateBeforeImage();

                break;
              }
            }
          }
        }
    		} catch( Exception e){
    			if (logger.isFinestEnabled()) {	
    		   		String infoForLogging="Error: Exception " + e.getMessage() + " while updating a record ";
      logger.finest("loadBeforeImage(XCustomerVehicleKORBObj bObj) " + infoForLogging);
        }
             	DWLExceptionUtils.throwDWLBaseException(e, 
            									new DWLUpdateException(e.getMessage()), 
            									bObj.getStatus(), DWLStatus.FATAL,
                                  DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_KORBOBJ, 
                                  "DIERR",
                                  DSEAAdditionsExtsErrorReasonCode.XCUSTOMERVEHICLEKOR_BEFORE_IMAGE_NOT_POPULATED, 
                                  bObj.getControl(), errHandler);
    		}
    }
    else if( updXCustomerVehicleRoleKORBObj.size() == 1){
      XCustomerVehicleRoleKORBObj childBObj = (XCustomerVehicleRoleKORBObj) updXCustomerVehicleRoleKORBObj.elementAt(0);
      childBObj.populateBeforeImage();
    }
    
    logger.finest("RETURN loadBeforeImage(XCustomerVehicleKORBObj bObj)");
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Populates the parent XCustomerVehicleKORBObj with all contained BObjs and
     * Type Codes.
     * @generated
    **/
  @SuppressWarnings("rawtypes")
    public void postRetrieveXCustomerVehicleKORBObj(XCustomerVehicleKORBObj theBObj, String inquiryLevel, String filter, DWLControl control) throws Exception {
    logger.finest("ENTER postRetrieveXCustomerVehicleKORBObj(XCustomerVehicleKORBObj theBObj, String inquiryLevel, String filter, DWLControl control)");
        DWLResponse containedResponse = null;
         // processing single valued reference XVehicleKORBObj
  
        if( theBObj.getXVehicleKORBObj() == null ){
            XVehicleKORBObj containedBObj = null;
            // processing an entity 
            String containedPk = theBObj.getVehicleId();
            if (containedPk!=null) {
            	if (logger.isFinestEnabled()) {	
    		   		String infoForLogging="Single Value reference - before containedResponse for XVehicleKORBObj, containedPk = " +containedPk;
      logger.finest("postRetrieveXCustomerVehicleKORBObj(XCustomerVehicleKORBObj theBObj, String inquiryLevel, String filter, DWLControl control) " + infoForLogging);
        }
            	containedResponse = getXVehicleKOR( containedPk, control);
        if (logger.isFinestEnabled()) {	
    		   		String infoForLogging="Single Value reference - after containedResponse for XVehicleKORBObj, containedPk = " +containedPk;
      logger.finest("postRetrieveXCustomerVehicleKORBObj(XCustomerVehicleKORBObj theBObj, String inquiryLevel, String filter, DWLControl control) " + infoForLogging);
        }
            	containedBObj = (XVehicleKORBObj)containedResponse.getData();
            } else {	
            	if (logger.isFinestEnabled()) {
    		   		String infoForLogging="The contained pk is null";
      logger.finest("postRetrieveXCustomerVehicleKORBObj(XCustomerVehicleKORBObj theBObj, String inquiryLevel, String filter, DWLControl control) " + infoForLogging);
            	}
            }	
 // end else key is persisted in this object
            if( containedBObj != null ){
                containedBObj.setControl(control);
                theBObj.setXVehicleKORBObj(containedBObj);
            }
        }
        // processing multi valued reference 
    if (theBObj.getXCustomerVehicleKORpkId()==null) {
      if (logger.isFinestEnabled()) {	
        String infoForLogging="theBObj.getXCustomerVehicleKORpkId() == null";
      logger.finest("postRetrieveXCustomerVehicleKORBObj(XCustomerVehicleKORBObj theBObj, String inquiryLevel, String filter, DWLControl control) " + infoForLogging);
      	}
      }
      
        containedResponse = getAllVehicleRoleByCustomerVehicleKORId( theBObj.getXCustomerVehicleKORpkId(), control);
    if (logger.isFinestEnabled()) {	
    		String infoForLogging="Successfully obtained the containedResponse for multi reference";
      logger.finest("postRetrieveXCustomerVehicleKORBObj(XCustomerVehicleKORBObj theBObj, String inquiryLevel, String filter, DWLControl control) " + infoForLogging);
    }
        Vector vec = null;
        vec = (Vector) containedResponse.getData();
        if( vec != null ){
        	for (int i = 0; i < vec.size(); i++) {
            	XCustomerVehicleRoleKORBObj object = (XCustomerVehicleRoleKORBObj) vec.elementAt(i);
            	object.setControl(control);
            	theBObj.setXCustomerVehicleRoleKORBObj(object);
        	}
        }
        // processing code types  
        String langId = (String) theBObj.getControl().get(TCRMControlKeys.LANG_ID);
        CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
  
        String ConnectMeUsageTp = theBObj.getConnectMeUsageType();
        if( ConnectMeUsageTp != null && !ConnectMeUsageTp.equals("")){
            CodeTypeBObj ConnectMeUsageBObj = codeTypeCompHelper
                    .getCodeTypeByCode("xcdconnectmeusagetp", langId, ConnectMeUsageTp,
                          theBObj.getControl());

            if (ConnectMeUsageBObj != null) {
                theBObj.setConnectMeUsageValue(ConnectMeUsageBObj.getvalue());
            }

    }
        String VehicleSalesTp = theBObj.getVehicleSalesType();
        if( VehicleSalesTp != null && !VehicleSalesTp.equals("")){
            CodeTypeBObj VehicleSalesBObj = codeTypeCompHelper
                    .getCodeTypeByCode("xcdvehiclesalestp", langId, VehicleSalesTp,
                          theBObj.getControl());

            if (VehicleSalesBObj != null) {
                theBObj.setVehicleSalesValue(VehicleSalesBObj.getvalue());
            }

    }
        String VehicleUsageTp = theBObj.getVehicleUsageType();
        if( VehicleUsageTp != null && !VehicleUsageTp.equals("")){
            CodeTypeBObj VehicleUsageBObj = codeTypeCompHelper
                    .getCodeTypeByCode("xcdvehicleusagetp", langId, VehicleUsageTp,
                          theBObj.getControl());

            if (VehicleUsageBObj != null) {
                theBObj.setVehicleUsageValue(VehicleUsageBObj.getvalue());
            }

    }
        String SourceIdentifierTp = theBObj.getSourceIdentifierType();
        if( SourceIdentifierTp != null && !SourceIdentifierTp.equals("")){
            CodeTypeBObj SourceIdentifierBObj = codeTypeCompHelper
                    .getCodeTypeByCode("cdsourceidenttp", langId, SourceIdentifierTp,
                          theBObj.getControl());

            if (SourceIdentifierBObj != null) {
                theBObj.setSourceIdentifierValue(SourceIdentifierBObj.getvalue());
            }

    }
    logger.finest("RETURN postRetrieveXCustomerVehicleKORBObj(XCustomerVehicleKORBObj theBObj, String inquiryLevel, String filter, DWLControl control)");
  }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     **/
    public void loadBeforeImage(XCustomerVehicleRoleKORBObj bObj) throws DWLBaseException {
    logger.finest("ENTER loadBeforeImage(XCustomerVehicleRoleKORBObj bObj)");
    	if( bObj.BeforeImage() == null ){
    	
    		XCustomerVehicleRoleKORBObj beforeImage = null;
    		DWLResponse response = null;
    		
    		try {
    			response = getXCustomerVehicleRoleKOR( bObj.getXCustomerVehicleRoleKORpkId(), bObj.getControl());
    			beforeImage = (XCustomerVehicleRoleKORBObj)response.getData();
    			
    		} catch( Exception e){
        if (logger.isFinestEnabled()) {
    				String infoForLogging="Error: Exception " + e.getMessage() + " while updating a record ";
      logger.finest("loadBeforeImage(XCustomerVehicleRoleKORBObj bObj) " + infoForLogging);
        }
              DWLExceptionUtils.throwDWLBaseException(e, 
            									new DWLUpdateException(e.getMessage()), 
            									bObj.getStatus(), DWLStatus.FATAL,
                                  DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_ROLE_KORBOBJ, 
                                  "DIERR",
                                  DSEAAdditionsExtsErrorReasonCode.XCUSTOMERVEHICLEROLEKOR_BEFORE_IMAGE_NOT_POPULATED, 
                                  bObj.getControl(), errHandler);
    		}
    		
    		if( beforeImage == null ){
        if (logger.isFinestEnabled()) {
    		    	String infoForLogging="Error: Before image for updating a record is null ";
      logger.finest("loadBeforeImage(XCustomerVehicleRoleKORBObj bObj) " + infoForLogging);
        }
              DWLExceptionUtils.throwDWLBaseException( new DWLUpdateException(), 
            									bObj.getStatus(), DWLStatus.FATAL,
                                  DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_ROLE_KORBOBJ, 
                                  "DIERR",
                                  DSEAAdditionsExtsErrorReasonCode.XCUSTOMERVEHICLEROLEKOR_BEFORE_IMAGE_NOT_POPULATED, 
                                  bObj.getControl(), errHandler);
    		}
    		
    		bObj.setBeforeImage(beforeImage);
    		
    	}
    logger.finest("RETURN loadBeforeImage(XCustomerVehicleRoleKORBObj bObj)");
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Populates the parent XCustomerVehicleRoleKORBObj with all contained BObjs
     * and Type Codes.
     * @generated
    **/
    public void postRetrieveXCustomerVehicleRoleKORBObj(XCustomerVehicleRoleKORBObj theBObj, String inquiryLevel, String filter, DWLControl control) throws Exception {
    logger.finest("ENTER postRetrieveXCustomerVehicleRoleKORBObj(XCustomerVehicleRoleKORBObj theBObj, String inquiryLevel, String filter, DWLControl control)");
        // processing code types  
        String langId = (String) theBObj.getControl().get(TCRMControlKeys.LANG_ID);
        CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
  
        String VehicleRoleTp = theBObj.getVehicleRoleType();
        if( VehicleRoleTp != null && !VehicleRoleTp.equals("")){
            CodeTypeBObj VehicleRoleBObj = codeTypeCompHelper
                    .getCodeTypeByCode("xcdvehicleroletp", langId, VehicleRoleTp,
                          theBObj.getControl());

            if (VehicleRoleBObj != null) {
                theBObj.setVehicleRoleValue(VehicleRoleBObj.getvalue());
            }

    }
        String SourceIdentifierTp = theBObj.getSourceIdentifierType();
        if( SourceIdentifierTp != null && !SourceIdentifierTp.equals("")){
            CodeTypeBObj SourceIdentifierBObj = codeTypeCompHelper
                    .getCodeTypeByCode("cdsourceidenttp", langId, SourceIdentifierTp,
                          theBObj.getControl());

            if (SourceIdentifierBObj != null) {
                theBObj.setSourceIdentifierValue(SourceIdentifierBObj.getvalue());
            }

    }
    logger.finest("RETURN postRetrieveXCustomerVehicleRoleKORBObj(XCustomerVehicleRoleKORBObj theBObj, String inquiryLevel, String filter, DWLControl control)");
  }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     **/
    public void loadBeforeImage(XEpucidTempBObj bObj) throws DWLBaseException {
    logger.finest("ENTER loadBeforeImage(XEpucidTempBObj bObj)");
    	if( bObj.BeforeImage() == null ){
    	
    		XEpucidTempBObj beforeImage = null;
    		DWLResponse response = null;
    		
    		try {
    			response = getXEpucidTemp( bObj.getXEpucidTemppkId(), bObj.getControl());
    			beforeImage = (XEpucidTempBObj)response.getData();
    			
    		} catch( Exception e){
        if (logger.isFinestEnabled()) {
    				String infoForLogging="Error: Exception " + e.getMessage() + " while updating a record ";
      logger.finest("loadBeforeImage(XEpucidTempBObj bObj) " + infoForLogging);
        }
              DWLExceptionUtils.throwDWLBaseException(e, 
            									new DWLUpdateException(e.getMessage()), 
            									bObj.getStatus(), DWLStatus.FATAL,
                                  DSEAAdditionsExtsComponentID.XEPUCID_TEMP_BOBJ, 
                                  "DIERR",
                                  DSEAAdditionsExtsErrorReasonCode.XEPUCIDTEMP_BEFORE_IMAGE_NOT_POPULATED, 
                                  bObj.getControl(), errHandler);
    		}
    		
    		if( beforeImage == null ){
        if (logger.isFinestEnabled()) {
    		    	String infoForLogging="Error: Before image for updating a record is null ";
      logger.finest("loadBeforeImage(XEpucidTempBObj bObj) " + infoForLogging);
        }
              DWLExceptionUtils.throwDWLBaseException( new DWLUpdateException(), 
            									bObj.getStatus(), DWLStatus.FATAL,
                                  DSEAAdditionsExtsComponentID.XEPUCID_TEMP_BOBJ, 
                                  "DIERR",
                                  DSEAAdditionsExtsErrorReasonCode.XEPUCIDTEMP_BEFORE_IMAGE_NOT_POPULATED, 
                                  bObj.getControl(), errHandler);
    		}
    		
    		bObj.setBeforeImage(beforeImage);
    		
    	}
    logger.finest("RETURN loadBeforeImage(XEpucidTempBObj bObj)");
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     **/
    public void loadBeforeImage(XContractDetailsJPNBObj bObj) throws DWLBaseException {
    logger.finest("ENTER loadBeforeImage(XContractDetailsJPNBObj bObj)");
    	if( bObj.BeforeImage() == null ){
    	
    		XContractDetailsJPNBObj beforeImage = null;
    		DWLResponse response = null;
    		
    		try {
    			response = getXContractDetailsJPN( bObj.getXContractJPNpkId(), bObj.getControl());
    			beforeImage = (XContractDetailsJPNBObj)response.getData();
    			
    		} catch( Exception e){
        if (logger.isFinestEnabled()) {
    				String infoForLogging="Error: Exception " + e.getMessage() + " while updating a record ";
      logger.finest("loadBeforeImage(XContractDetailsJPNBObj bObj) " + infoForLogging);
        }
              DWLExceptionUtils.throwDWLBaseException(e, 
            									new DWLUpdateException(e.getMessage()), 
            									bObj.getStatus(), DWLStatus.FATAL,
                                  DSEAAdditionsExtsComponentID.XCONTRACT_DETAILS_JPNBOBJ, 
                                  "DIERR",
                                  DSEAAdditionsExtsErrorReasonCode.XCONTRACTDETAILSJPN_BEFORE_IMAGE_NOT_POPULATED, 
                                  bObj.getControl(), errHandler);
    		}
    		
    		if( beforeImage == null ){
        if (logger.isFinestEnabled()) {
    		    	String infoForLogging="Error: Before image for updating a record is null ";
      logger.finest("loadBeforeImage(XContractDetailsJPNBObj bObj) " + infoForLogging);
        }
              DWLExceptionUtils.throwDWLBaseException( new DWLUpdateException(), 
            									bObj.getStatus(), DWLStatus.FATAL,
                                  DSEAAdditionsExtsComponentID.XCONTRACT_DETAILS_JPNBOBJ, 
                                  "DIERR",
                                  DSEAAdditionsExtsErrorReasonCode.XCONTRACTDETAILSJPN_BEFORE_IMAGE_NOT_POPULATED, 
                                  bObj.getControl(), errHandler);
    		}
    		
    		bObj.setBeforeImage(beforeImage);
    		
    	}
    logger.finest("RETURN loadBeforeImage(XContractDetailsJPNBObj bObj)");
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Populates the parent XContractDetailsJPNBObj with all contained BObjs and
     * Type Codes.
     * @generated
    **/
  @SuppressWarnings("rawtypes")
    public void postRetrieveXContractDetailsJPNBObj(XContractDetailsJPNBObj theBObj, String inquiryLevel, String filter, DWLControl control) throws Exception {
    logger.finest("ENTER postRetrieveXContractDetailsJPNBObj(XContractDetailsJPNBObj theBObj, String inquiryLevel, String filter, DWLControl control)");
     // MDM_TODO: CDKWB0004I Obtain a GuarantorDetailsJPN instance and call the method setGuarantorDetailsJPNBObj to populate the business object.
     // MDM_TODO: CDKWB0004I Obtain a FinanceContractorDetailsJPN instance and call the method setFinanceContractorDetailsJPNBObj to populate the business object.
        // processing code types  
        String langId = (String) theBObj.getControl().get(TCRMControlKeys.LANG_ID);
        CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
  
        String ContractStatusTp = theBObj.getContractStatusType();
        if( ContractStatusTp != null && !ContractStatusTp.equals("")){
            CodeTypeBObj ContractStatusBObj = codeTypeCompHelper
                    .getCodeTypeByCode("cdcontractsttp", langId, ContractStatusTp,
                          theBObj.getControl());

            if (ContractStatusBObj != null) {
                theBObj.setContractStatusValue(ContractStatusBObj.getvalue());
            }

    }
        String SourceIdentifierTp = theBObj.getSourceIdentifierType();
        if( SourceIdentifierTp != null && !SourceIdentifierTp.equals("")){
            CodeTypeBObj SourceIdentifierBObj = codeTypeCompHelper
                    .getCodeTypeByCode("cdsourceidenttp", langId, SourceIdentifierTp,
                          theBObj.getControl());

            if (SourceIdentifierBObj != null) {
                theBObj.setSourceIdentifierValue(SourceIdentifierBObj.getvalue());
            }

    }
    logger.finest("RETURN postRetrieveXContractDetailsJPNBObj(XContractDetailsJPNBObj theBObj, String inquiryLevel, String filter, DWLControl control)");
  }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     **/
    public void loadBeforeImage(XContractRelJPNBObj bObj) throws DWLBaseException {
    logger.finest("ENTER loadBeforeImage(XContractRelJPNBObj bObj)");
    	if( bObj.BeforeImage() == null ){
    	
    		XContractRelJPNBObj beforeImage = null;
    		DWLResponse response = null;
    		
    		try {
    			response = getXContractRelJPN( bObj.getXContractRelJPNpkId(), bObj.getControl());
    			beforeImage = (XContractRelJPNBObj)response.getData();
    			
    		} catch( Exception e){
        if (logger.isFinestEnabled()) {
    				String infoForLogging="Error: Exception " + e.getMessage() + " while updating a record ";
      logger.finest("loadBeforeImage(XContractRelJPNBObj bObj) " + infoForLogging);
        }
              DWLExceptionUtils.throwDWLBaseException(e, 
            									new DWLUpdateException(e.getMessage()), 
            									bObj.getStatus(), DWLStatus.FATAL,
                                  DSEAAdditionsExtsComponentID.XCONTRACT_REL_JPNBOBJ, 
                                  "DIERR",
                                  DSEAAdditionsExtsErrorReasonCode.XCONTRACTRELJPN_BEFORE_IMAGE_NOT_POPULATED, 
                                  bObj.getControl(), errHandler);
    		}
    		
    		if( beforeImage == null ){
        if (logger.isFinestEnabled()) {
    		    	String infoForLogging="Error: Before image for updating a record is null ";
      logger.finest("loadBeforeImage(XContractRelJPNBObj bObj) " + infoForLogging);
        }
              DWLExceptionUtils.throwDWLBaseException( new DWLUpdateException(), 
            									bObj.getStatus(), DWLStatus.FATAL,
                                  DSEAAdditionsExtsComponentID.XCONTRACT_REL_JPNBOBJ, 
                                  "DIERR",
                                  DSEAAdditionsExtsErrorReasonCode.XCONTRACTRELJPN_BEFORE_IMAGE_NOT_POPULATED, 
                                  bObj.getControl(), errHandler);
    		}
    		
    		bObj.setBeforeImage(beforeImage);
    		
    	}
    logger.finest("RETURN loadBeforeImage(XContractRelJPNBObj bObj)");
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     **/
    public void loadBeforeImage(XVehicleAusBObj bObj) throws DWLBaseException {
    logger.finest("ENTER loadBeforeImage(XVehicleAusBObj bObj)");
    	if( bObj.BeforeImage() == null ){
    	
    		XVehicleAusBObj beforeImage = null;
    		DWLResponse response = null;
    		
    		try {
    			response = getXVehicleAus( bObj.getXVehicleAuspkId(), bObj.getControl());
    			beforeImage = (XVehicleAusBObj)response.getData();
    			
    		} catch( Exception e){
        if (logger.isFinestEnabled()) {
    				String infoForLogging="Error: Exception " + e.getMessage() + " while updating a record ";
      logger.finest("loadBeforeImage(XVehicleAusBObj bObj) " + infoForLogging);
        }
              DWLExceptionUtils.throwDWLBaseException(e, 
            									new DWLUpdateException(e.getMessage()), 
            									bObj.getStatus(), DWLStatus.FATAL,
                                  DSEAAdditionsExtsComponentID.XVEHICLE_AUS_BOBJ, 
                                  "DIERR",
                                  DSEAAdditionsExtsErrorReasonCode.XVEHICLEAUS_BEFORE_IMAGE_NOT_POPULATED, 
                                  bObj.getControl(), errHandler);
    		}
    		
    		if( beforeImage == null ){
        if (logger.isFinestEnabled()) {
    		    	String infoForLogging="Error: Before image for updating a record is null ";
      logger.finest("loadBeforeImage(XVehicleAusBObj bObj) " + infoForLogging);
        }
              DWLExceptionUtils.throwDWLBaseException( new DWLUpdateException(), 
            									bObj.getStatus(), DWLStatus.FATAL,
                                  DSEAAdditionsExtsComponentID.XVEHICLE_AUS_BOBJ, 
                                  "DIERR",
                                  DSEAAdditionsExtsErrorReasonCode.XVEHICLEAUS_BEFORE_IMAGE_NOT_POPULATED, 
                                  bObj.getControl(), errHandler);
    		}
    		
    		bObj.setBeforeImage(beforeImage);
    		
    	}
    logger.finest("RETURN loadBeforeImage(XVehicleAusBObj bObj)");
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Populates the parent XVehicleAusBObj with all contained BObjs and Type
     * Codes.
     * @generated
    **/
    public void postRetrieveXVehicleAusBObj(XVehicleAusBObj theBObj, String inquiryLevel, String filter, DWLControl control) throws Exception {
    logger.finest("ENTER postRetrieveXVehicleAusBObj(XVehicleAusBObj theBObj, String inquiryLevel, String filter, DWLControl control)");
        // processing code types  
        String langId = (String) theBObj.getControl().get(TCRMControlKeys.LANG_ID);
        CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
  
        String SourceIdentifierTp = theBObj.getSourceIdentifierType();
        if( SourceIdentifierTp != null && !SourceIdentifierTp.equals("")){
            CodeTypeBObj SourceIdentifierBObj = codeTypeCompHelper
                    .getCodeTypeByCode("cdsourceidenttp", langId, SourceIdentifierTp,
                          theBObj.getControl());

            if (SourceIdentifierBObj != null) {
                theBObj.setSourceIdentifierValue(SourceIdentifierBObj.getvalue());
            }

    }
    logger.finest("RETURN postRetrieveXVehicleAusBObj(XVehicleAusBObj theBObj, String inquiryLevel, String filter, DWLControl control)");
  }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     **/
    public void loadBeforeImage(XCustomerVehicleAusBObj bObj) throws DWLBaseException {
    logger.finest("ENTER loadBeforeImage(XCustomerVehicleAusBObj bObj)");
    	if( bObj.BeforeImage() == null ){
    	
    		XCustomerVehicleAusBObj beforeImage = null;
    		DWLResponse response = null;
    		
    		try {
    			response = getXCustomerVehicleAus( bObj.getXCustomerVehicleAuspkId(), bObj.getControl());
    			beforeImage = (XCustomerVehicleAusBObj)response.getData();
    			
    		} catch( Exception e){
        if (logger.isFinestEnabled()) {
    				String infoForLogging="Error: Exception " + e.getMessage() + " while updating a record ";
      logger.finest("loadBeforeImage(XCustomerVehicleAusBObj bObj) " + infoForLogging);
        }
              DWLExceptionUtils.throwDWLBaseException(e, 
            									new DWLUpdateException(e.getMessage()), 
            									bObj.getStatus(), DWLStatus.FATAL,
                                  DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_AUS_BOBJ, 
                                  "DIERR",
                                  DSEAAdditionsExtsErrorReasonCode.XCUSTOMERVEHICLEAUS_BEFORE_IMAGE_NOT_POPULATED, 
                                  bObj.getControl(), errHandler);
    		}
    		
    		if( beforeImage == null ){
        if (logger.isFinestEnabled()) {
    		    	String infoForLogging="Error: Before image for updating a record is null ";
      logger.finest("loadBeforeImage(XCustomerVehicleAusBObj bObj) " + infoForLogging);
        }
              DWLExceptionUtils.throwDWLBaseException( new DWLUpdateException(), 
            									bObj.getStatus(), DWLStatus.FATAL,
                                  DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_AUS_BOBJ, 
                                  "DIERR",
                                  DSEAAdditionsExtsErrorReasonCode.XCUSTOMERVEHICLEAUS_BEFORE_IMAGE_NOT_POPULATED, 
                                  bObj.getControl(), errHandler);
    		}
    		
    		bObj.setBeforeImage(beforeImage);
    		
    	}
    if( bObj.getXVehicleAusBObj() != null ){
      XVehicleAusBObj childBObj = bObj.getXVehicleAusBObj();
      if( childBObj.getEObjXVehicleAus().getXVehicleAuspkId() != null ){
        childBObj.populateBeforeImage( );
      }
    }
    Vector<?> vecXCustomerVehicleRoleAusBObj = bObj.getItemsXCustomerVehicleRoleAusBObj();
    Vector<XCustomerVehicleRoleAusBObj> updXCustomerVehicleRoleAusBObj = new Vector<XCustomerVehicleRoleAusBObj>();
    for (int idx0 = 0; idx0 < vecXCustomerVehicleRoleAusBObj.size(); idx0++) {
      XCustomerVehicleRoleAusBObj childBObj = (XCustomerVehicleRoleAusBObj) vecXCustomerVehicleRoleAusBObj
          .elementAt(idx0);

      String pkId = childBObj.getXCustomerRoleAuspkId();

      if (StringUtils.isNonBlank(pkId)) {
        updXCustomerVehicleRoleAusBObj.add(childBObj);
      }
    }
    if( updXCustomerVehicleRoleAusBObj.size() > 1){
      try {
        DWLResponse containedResponse = getAllVehicleRoleAusByCustomerVehicleId( bObj.getXCustomerVehicleAuspkId(),  bObj.getControl() );
        Vector<?> listAllChildrenBeforeImage = (Vector<?>)containedResponse.getData();
        if( listAllChildrenBeforeImage != null ){
          for (int idx = 0; idx < updXCustomerVehicleRoleAusBObj.size(); idx++) {

            XCustomerVehicleRoleAusBObj childBObj = (XCustomerVehicleRoleAusBObj) updXCustomerVehicleRoleAusBObj
              .elementAt(idx);
            String pkId = childBObj.getXCustomerRoleAuspkId();

            for (int idxBeforeImage = 0; idxBeforeImage < listAllChildrenBeforeImage
              .size(); idxBeforeImage++) {

              XCustomerVehicleRoleAusBObj bobjBeforeImage = (XCustomerVehicleRoleAusBObj) listAllChildrenBeforeImage
                .elementAt(idxBeforeImage);

              String idBeforeImage = bobjBeforeImage.getXCustomerRoleAuspkId();

              if (pkId.equalsIgnoreCase(idBeforeImage)) {
                childBObj.setBeforeImage(bobjBeforeImage);
                childBObj.populateBeforeImage();

                break;
              }
            }
          }
        }
    		} catch( Exception e){
    			if (logger.isFinestEnabled()) {	
    		   		String infoForLogging="Error: Exception " + e.getMessage() + " while updating a record ";
      logger.finest("loadBeforeImage(XCustomerVehicleAusBObj bObj) " + infoForLogging);
        }
             	DWLExceptionUtils.throwDWLBaseException(e, 
            									new DWLUpdateException(e.getMessage()), 
            									bObj.getStatus(), DWLStatus.FATAL,
                                  DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_AUS_BOBJ, 
                                  "DIERR",
                                  DSEAAdditionsExtsErrorReasonCode.XCUSTOMERVEHICLEAUS_BEFORE_IMAGE_NOT_POPULATED, 
                                  bObj.getControl(), errHandler);
    		}
    }
    else if( updXCustomerVehicleRoleAusBObj.size() == 1){
      XCustomerVehicleRoleAusBObj childBObj = (XCustomerVehicleRoleAusBObj) updXCustomerVehicleRoleAusBObj.elementAt(0);
      childBObj.populateBeforeImage();
    }
    
    logger.finest("RETURN loadBeforeImage(XCustomerVehicleAusBObj bObj)");
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Populates the parent XCustomerVehicleAusBObj with all contained BObjs and
     * Type Codes.
     * @generated
    **/
    @SuppressWarnings("rawtypes")
    public void postRetrieveXCustomerVehicleAusBObj(XCustomerVehicleAusBObj theBObj, String inquiryLevel, String filter, DWLControl control) throws Exception {
    logger.finest("ENTER postRetrieveXCustomerVehicleAusBObj(XCustomerVehicleAusBObj theBObj, String inquiryLevel, String filter, DWLControl control)");
        DWLResponse containedResponse = null;
         // processing single valued reference XVehicleAusBObj
  
        if( theBObj.getXVehicleAusBObj() == null ){
            XVehicleAusBObj containedBObj = null;
            // processing an entity 
            String containedPk = theBObj.getVehicleId();
            if (containedPk!=null) {
            	if (logger.isFinestEnabled()) {	
    		   		String infoForLogging="Single Value reference - before containedResponse for XVehicleAusBObj, containedPk = " +containedPk;
      logger.finest("postRetrieveXCustomerVehicleAusBObj(XCustomerVehicleAusBObj theBObj, String inquiryLevel, String filter, DWLControl control) " + infoForLogging);
        }
            	containedResponse = getXVehicleAus( containedPk, control);
        if (logger.isFinestEnabled()) {	
    		   		String infoForLogging="Single Value reference - after containedResponse for XVehicleAusBObj, containedPk = " +containedPk;
      logger.finest("postRetrieveXCustomerVehicleAusBObj(XCustomerVehicleAusBObj theBObj, String inquiryLevel, String filter, DWLControl control) " + infoForLogging);
        }
            	containedBObj = (XVehicleAusBObj)containedResponse.getData();
            } else {	
            	if (logger.isFinestEnabled()) {
    		   		String infoForLogging="The contained pk is null";
      logger.finest("postRetrieveXCustomerVehicleAusBObj(XCustomerVehicleAusBObj theBObj, String inquiryLevel, String filter, DWLControl control) " + infoForLogging);
            	}
            }	
 // end else key is persisted in this object
            if( containedBObj != null ){
                containedBObj.setControl(control);
                theBObj.setXVehicleAusBObj(containedBObj);
            }
        }
        // processing multi valued reference 
    if (theBObj.getXCustomerVehicleAuspkId()==null) {
      if (logger.isFinestEnabled()) {	
        String infoForLogging="theBObj.getXCustomerVehicleAuspkId() == null";
      logger.finest("postRetrieveXCustomerVehicleAusBObj(XCustomerVehicleAusBObj theBObj, String inquiryLevel, String filter, DWLControl control) " + infoForLogging);
      	}
      }
      
        containedResponse = getAllVehicleRoleAusByCustomerVehicleId( theBObj.getXCustomerVehicleAuspkId(), control);
    if (logger.isFinestEnabled()) {	
    		String infoForLogging="Successfully obtained the containedResponse for multi reference";
      logger.finest("postRetrieveXCustomerVehicleAusBObj(XCustomerVehicleAusBObj theBObj, String inquiryLevel, String filter, DWLControl control) " + infoForLogging);
    }
        Vector vec = null;
        vec = (Vector) containedResponse.getData();
        if( vec != null ){
        	for (int i = 0; i < vec.size(); i++) {
            	XCustomerVehicleRoleAusBObj object = (XCustomerVehicleRoleAusBObj) vec.elementAt(i);
            	object.setControl(control);
            	theBObj.setXCustomerVehicleRoleAusBObj(object);
        	}
        }
        // processing code types  
        String langId = (String) theBObj.getControl().get(TCRMControlKeys.LANG_ID);
        CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
  
        String SourceIdentifierTp = theBObj.getSourceIdentifierType();
        if( SourceIdentifierTp != null && !SourceIdentifierTp.equals("")){
            CodeTypeBObj SourceIdentifierBObj = codeTypeCompHelper
                    .getCodeTypeByCode("cdsourceidenttp", langId, SourceIdentifierTp,
                          theBObj.getControl());

            if (SourceIdentifierBObj != null) {
                theBObj.setSourceIdentifierValue(SourceIdentifierBObj.getvalue());
            }

    }
    logger.finest("RETURN postRetrieveXCustomerVehicleAusBObj(XCustomerVehicleAusBObj theBObj, String inquiryLevel, String filter, DWLControl control)");
  }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     **/
    public void loadBeforeImage(XCustomerVehicleRoleAusBObj bObj) throws DWLBaseException {
    logger.finest("ENTER loadBeforeImage(XCustomerVehicleRoleAusBObj bObj)");
    	if( bObj.BeforeImage() == null ){
    	
    		XCustomerVehicleRoleAusBObj beforeImage = null;
    		DWLResponse response = null;
    		
    		try {
    			response = getXCustomerVehicleRoleAus( bObj.getXCustomerRoleAuspkId(), bObj.getControl());
    			beforeImage = (XCustomerVehicleRoleAusBObj)response.getData();
    			
    		} catch( Exception e){
        if (logger.isFinestEnabled()) {
    				String infoForLogging="Error: Exception " + e.getMessage() + " while updating a record ";
      logger.finest("loadBeforeImage(XCustomerVehicleRoleAusBObj bObj) " + infoForLogging);
        }
              DWLExceptionUtils.throwDWLBaseException(e, 
            									new DWLUpdateException(e.getMessage()), 
            									bObj.getStatus(), DWLStatus.FATAL,
                                  DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_ROLE_AUS_BOBJ, 
                                  "DIERR",
                                  DSEAAdditionsExtsErrorReasonCode.XCUSTOMERVEHICLEROLEAUS_BEFORE_IMAGE_NOT_POPULATED, 
                                  bObj.getControl(), errHandler);
    		}
    		
    		if( beforeImage == null ){
        if (logger.isFinestEnabled()) {
    		    	String infoForLogging="Error: Before image for updating a record is null ";
      logger.finest("loadBeforeImage(XCustomerVehicleRoleAusBObj bObj) " + infoForLogging);
        }
              DWLExceptionUtils.throwDWLBaseException( new DWLUpdateException(), 
            									bObj.getStatus(), DWLStatus.FATAL,
                                  DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_ROLE_AUS_BOBJ, 
                                  "DIERR",
                                  DSEAAdditionsExtsErrorReasonCode.XCUSTOMERVEHICLEROLEAUS_BEFORE_IMAGE_NOT_POPULATED, 
                                  bObj.getControl(), errHandler);
    		}
    		
    		bObj.setBeforeImage(beforeImage);
    		
    	}
    logger.finest("RETURN loadBeforeImage(XCustomerVehicleRoleAusBObj bObj)");
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Populates the parent XCustomerVehicleRoleAusBObj with all contained BObjs
     * and Type Codes.
     * @generated
    **/
    public void postRetrieveXCustomerVehicleRoleAusBObj(XCustomerVehicleRoleAusBObj theBObj, String inquiryLevel, String filter, DWLControl control) throws Exception {
    logger.finest("ENTER postRetrieveXCustomerVehicleRoleAusBObj(XCustomerVehicleRoleAusBObj theBObj, String inquiryLevel, String filter, DWLControl control)");
        // processing code types  
        String langId = (String) theBObj.getControl().get(TCRMControlKeys.LANG_ID);
        CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
  
        String VehicleRoleTp = theBObj.getVehicleRoleType();
        if( VehicleRoleTp != null && !VehicleRoleTp.equals("")){
            CodeTypeBObj VehicleRoleBObj = codeTypeCompHelper
                    .getCodeTypeByCode("xcdvehicleroletp", langId, VehicleRoleTp,
                          theBObj.getControl());

            if (VehicleRoleBObj != null) {
                theBObj.setVehicleRoleValue(VehicleRoleBObj.getvalue());
            }

    }
        String VehicleRelStatusTp = theBObj.getVehicleRelStatusType();
        if( VehicleRelStatusTp != null && !VehicleRelStatusTp.equals("")){
            CodeTypeBObj VehicleRelStatusBObj = codeTypeCompHelper
                    .getCodeTypeByCode("xcdvehiclerelstatustp", langId, VehicleRelStatusTp,
                          theBObj.getControl());

            if (VehicleRelStatusBObj != null) {
                theBObj.setVehicleRelStatusValue(VehicleRelStatusBObj.getvalue());
            }

    }
        String SourceIdentifierTp = theBObj.getSourceIdentifierType();
        if( SourceIdentifierTp != null && !SourceIdentifierTp.equals("")){
            CodeTypeBObj SourceIdentifierBObj = codeTypeCompHelper
                    .getCodeTypeByCode("cdsourceidenttp", langId, SourceIdentifierTp,
                          theBObj.getControl());

            if (SourceIdentifierBObj != null) {
                theBObj.setSourceIdentifierValue(SourceIdentifierBObj.getvalue());
            }

    }
    logger.finest("RETURN postRetrieveXCustomerVehicleRoleAusBObj(XCustomerVehicleRoleAusBObj theBObj, String inquiryLevel, String filter, DWLControl control)");
  }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     **/
    public void loadBeforeImage(XVRCollapseBObj bObj) throws DWLBaseException {
    logger.finest("ENTER loadBeforeImage(XVRCollapseBObj bObj)");
    	if( bObj.BeforeImage() == null ){
    	
    		XVRCollapseBObj beforeImage = null;
    		DWLResponse response = null;
    		
    		try {
    			response = getXVRCollapse( bObj.getXVRCollapsepkId(), bObj.getControl());
    			beforeImage = (XVRCollapseBObj)response.getData();
    			
    		} catch( Exception e){
        if (logger.isFinestEnabled()) {
    				String infoForLogging="Error: Exception " + e.getMessage() + " while updating a record ";
      logger.finest("loadBeforeImage(XVRCollapseBObj bObj) " + infoForLogging);
        }
              DWLExceptionUtils.throwDWLBaseException(e, 
            									new DWLUpdateException(e.getMessage()), 
            									bObj.getStatus(), DWLStatus.FATAL,
                                  DSEAAdditionsExtsComponentID.XVRCOLLAPSE_BOBJ, 
                                  "DIERR",
                                  DSEAAdditionsExtsErrorReasonCode.XVRCOLLAPSE_BEFORE_IMAGE_NOT_POPULATED, 
                                  bObj.getControl(), errHandler);
    		}
    		
    		if( beforeImage == null ){
        if (logger.isFinestEnabled()) {
    		    	String infoForLogging="Error: Before image for updating a record is null ";
      logger.finest("loadBeforeImage(XVRCollapseBObj bObj) " + infoForLogging);
        }
              DWLExceptionUtils.throwDWLBaseException( new DWLUpdateException(), 
            									bObj.getStatus(), DWLStatus.FATAL,
                                  DSEAAdditionsExtsComponentID.XVRCOLLAPSE_BOBJ, 
                                  "DIERR",
                                  DSEAAdditionsExtsErrorReasonCode.XVRCOLLAPSE_BEFORE_IMAGE_NOT_POPULATED, 
                                  bObj.getControl(), errHandler);
    		}
    		
    		bObj.setBeforeImage(beforeImage);
    		
    	}
    logger.finest("RETURN loadBeforeImage(XVRCollapseBObj bObj)");
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     **/
    public void loadBeforeImage(XDeleteAuditBObj bObj) throws DWLBaseException {
    logger.finest("ENTER loadBeforeImage(XDeleteAuditBObj bObj)");
    	if( bObj.BeforeImage() == null ){
    	
    		XDeleteAuditBObj beforeImage = null;
    		DWLResponse response = null;
    		
    		try {
    			response = getXDeleteAudit( bObj.getXDeleteAuditpkId(), bObj.getControl());
    			beforeImage = (XDeleteAuditBObj)response.getData();
    			
    		} catch( Exception e){
        if (logger.isFinestEnabled()) {
    				String infoForLogging="Error: Exception " + e.getMessage() + " while updating a record ";
      logger.finest("loadBeforeImage(XDeleteAuditBObj bObj) " + infoForLogging);
        }
              DWLExceptionUtils.throwDWLBaseException(e, 
            									new DWLUpdateException(e.getMessage()), 
            									bObj.getStatus(), DWLStatus.FATAL,
                                  DSEAAdditionsExtsComponentID.XDELETE_AUDIT_BOBJ, 
                                  "DIERR",
                                  DSEAAdditionsExtsErrorReasonCode.XDELETEAUDIT_BEFORE_IMAGE_NOT_POPULATED, 
                                  bObj.getControl(), errHandler);
    		}
    		
    		if( beforeImage == null ){
        if (logger.isFinestEnabled()) {
    		    	String infoForLogging="Error: Before image for updating a record is null ";
      logger.finest("loadBeforeImage(XDeleteAuditBObj bObj) " + infoForLogging);
        }
              DWLExceptionUtils.throwDWLBaseException( new DWLUpdateException(), 
            									bObj.getStatus(), DWLStatus.FATAL,
                                  DSEAAdditionsExtsComponentID.XDELETE_AUDIT_BOBJ, 
                                  "DIERR",
                                  DSEAAdditionsExtsErrorReasonCode.XDELETEAUDIT_BEFORE_IMAGE_NOT_POPULATED, 
                                  bObj.getControl(), errHandler);
    		}
    		
    		bObj.setBeforeImage(beforeImage);
    		
    	}
    logger.finest("RETURN loadBeforeImage(XDeleteAuditBObj bObj)");
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Builds duplicated key throwable message. There are only two elements in
     * the vector, one is the primary key, and the other is the class name.
     * @generated
     **/
    @SuppressWarnings("unused")
    private String buildDupThrowableMessage(String[] errParams) {
    return ResourceBundleHelper.resolve(
        ResourceBundleNames.COMMON_SERVICES_STRINGS,
        EXCEPTION_DUPLICATE_KEY, errParams);

    }
  

}


