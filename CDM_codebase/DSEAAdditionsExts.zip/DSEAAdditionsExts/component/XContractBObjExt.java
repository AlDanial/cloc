
/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[4d10ad2f5116b78f71324ff0213ab5e4]
 */

package com.ibm.daimler.dsea.component;

import com.dwl.base.util.DWLClassFactory;
import com.dwl.tcrm.exception.TCRMReadException;



import com.dwl.base.DWLControl;
import com.dwl.base.IDWLErrorMessage;

import com.dwl.base.error.DWLError;
import com.dwl.base.error.DWLErrorCode;
import com.dwl.base.error.DWLStatus;

import com.dwl.base.exception.DWLBaseException;

import com.dwl.base.util.DWLExceptionUtils;
import com.dwl.base.util.DWLFunctionUtils;

import com.dwl.tcrm.common.IExtension;
import com.dwl.tcrm.common.ITCRMValidation;
import com.dwl.tcrm.common.TCRMErrorCode;

import com.dwl.tcrm.financial.component.TCRMContractBObj;

import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsComponentID;
import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsErrorReasonCode;

import com.ibm.daimler.dsea.entityObject.EObjXContractExt;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * This class provides the implementation of the business object
 * <code>XContractBObjExt</code>.
 * 
 * @see com.dwl.tcrm.common.TCRMCommon
 * @generated
 */
 

@SuppressWarnings("serial")
public class XContractBObjExt extends TCRMContractBObj implements IExtension {

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected EObjXContractExt eObjXContractExt;
	/**
    * <!-- begin-user-doc -->
	  * <!-- end-user-doc -->
    * @generated 
    */
	 private final static com.dwl.base.logging.IDWLLogger logger = com.dwl.base.logging.DWLLoggerManager.getLogger(XContractBObjExt.class);
		
 


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */     
    public XContractBObjExt() {
        super();
        init();
        eObjXContractExt = new EObjXContractExt(getEObjContract());
        setComponentID(DSEAAdditionsExtsComponentID.XCONTRACT_BOBJ_EXT);
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Initializes the fields required to populate the metaDataMap. Each key is
     * an element-level field of the business object.
     *
     * @generated
     */
    private void init() {
        metaDataMap.put("XContractNum", null);
        metaDataMap.put("XContractHistActionCode", null);
        metaDataMap.put("XContractHistCreateDate", null);
        metaDataMap.put("XContractHistCreatedBy", null);
        metaDataMap.put("XContractHistEndDate", null);
        metaDataMap.put("XContractHistoryIdPK", null);
        metaDataMap.put("XContractLastUpdateDate", null);
        metaDataMap.put("XContractLastUpdateTxId", null);
        metaDataMap.put("XContractLastUpdateUser", null);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Refreshes all the attributes this business object supports.
     *
     * @see com.dwl.base.DWLCommon#refreshMap()
     * @generated
     */
    public void refreshMap() {

        if (bRequireMapRefresh) {
            super.refreshMap();
            metaDataMap.put("XContractNum", getXContractNum());
            metaDataMap.put("XContractHistActionCode", getXContractHistActionCode());
            metaDataMap.put("XContractHistCreateDate", getXContractHistCreateDate());
            metaDataMap.put("XContractHistCreatedBy", getXContractHistCreatedBy());
            metaDataMap.put("XContractHistEndDate", getXContractHistEndDate());
            metaDataMap.put("XContractHistoryIdPK", getXContractHistoryIdPK());
            metaDataMap.put("XContractLastUpdateDate", getXContractLastUpdateDate());
            metaDataMap.put("XContractLastUpdateTxId", getXContractLastUpdateTxId());
            metaDataMap.put("XContractLastUpdateUser", getXContractLastUpdateUser());
            bRequireMapRefresh = false;
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the control object on this business object.
     *
     * @see com.dwl.base.DWLCommon#setControl(DWLControl)
     * @generated
     */
    public void setControl(DWLControl newDWLControl) {
        super.setControl(newDWLControl);

        if (eObjXContractExt != null) {
            eObjXContractExt.setControl(newDWLControl);
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the entity object associated with this business object.
     *
     * @generated
     */
    public EObjXContractExt getEObjXContractExt() {
        bRequireMapRefresh = true;
        return eObjXContractExt;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the entity object associated with this business object.
     *
     * @param eObjXContractExt
     *            The eObjXContractExt to set.
     * @generated
     */
    public void setEObjXContractExt(EObjXContractExt eObjXContractExt) {
        bRequireMapRefresh = true;
        this.eObjXContractExt = eObjXContractExt;
        this.eObjXContractExt.setBaseEntity(getEObjContract());
        if (this.eObjXContractExt != null && this.eObjXContractExt.getControl() == null) {
            DWLControl control = this.getControl();
            if (control != null) {
                this.eObjXContractExt.setControl(control);
            }
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xContractNum attribute.
     * 
     * @generated
     */
    public String getXContractNum (){
   
        return eObjXContractExt.getXContractNum();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xContractNum attribute.
     * 
     * @param newXContractNum
     *     The new value of xContractNum.
     * @generated
     */
    public void setXContractNum( String newXContractNum ) throws Exception {
        metaDataMap.put("XContractNum", newXContractNum);

        if (newXContractNum == null || newXContractNum.equals("")) {
            newXContractNum = null;


        }
        eObjXContractExt.setXContractNum( newXContractNum );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateTxId attribute.
     *
     * @generated
     */
    public String getXContractLastUpdateTxId() {
        return DWLFunctionUtils.getStringFromLong(eObjXContractExt.getLastUpdateTxId());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateUser attribute.
     *
     * @generated
     */
    public String getXContractLastUpdateUser() {
        return eObjXContractExt.getLastUpdateUser();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateDt attribute.
     *
     * @generated
     */
    public String getXContractLastUpdateDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXContractExt.getLastUpdateDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateTxId attribute.
     *
     * @param newLastUpdateTxId
     *     The new value of LastUpdateTxId.
     * @generated
     */
    public void setXContractLastUpdateTxId(String newLastUpdateTxId) {
        metaDataMap.put("XContractLastUpdateTxId", newLastUpdateTxId);

        if ((newLastUpdateTxId == null) || newLastUpdateTxId.equals("")) {
            newLastUpdateTxId = null;
        }
        eObjXContractExt.setLastUpdateTxId(DWLFunctionUtils.getLongFromString(newLastUpdateTxId));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateUser attribute.
     *
     * @param newLastUpdateUser
     *     The new value of LastUpdateUser.
     * @generated
     */
    public void setXContractLastUpdateUser(String newLastUpdateUser) {
        metaDataMap.put("XContractLastUpdateUser", newLastUpdateUser);

        if ((newLastUpdateUser == null) || newLastUpdateUser.equals("")) {
            newLastUpdateUser = null;
        }
        eObjXContractExt.setLastUpdateUser(newLastUpdateUser);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateDt attribute.
     *
     * @param newLastUpdateDt
     *     The new value of LastUpdateDt.
     * @throws Exception
     * @generated
     */
    public void setXContractLastUpdateDate(String newLastUpdateDt) throws Exception {
        metaDataMap.put("XContractLastUpdateDate", newLastUpdateDt);

        if ((newLastUpdateDt == null) || newLastUpdateDt.equals("")) {
            newLastUpdateDt = null;
        }

        eObjXContractExt.setLastUpdateDt(DWLFunctionUtils.getTimestampFromTimestampString(newLastUpdateDt));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XContractHistActionCode history attribute.
     *
     * @generated
     */
    public String getXContractHistActionCode() {
        return eObjXContractExt.getHistActionCode();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XContractHistActionCode history attribute.
     *
     * @param aXContractHistActionCode
     *     The new value of XContractHistActionCode.
     * @generated
     */
    public void setXContractHistActionCode(String aXContractHistActionCode) {
        metaDataMap.put("XContractHistActionCode", aXContractHistActionCode);

        if ((aXContractHistActionCode == null) || aXContractHistActionCode.equals("")) {
            aXContractHistActionCode = null;
        }
        eObjXContractExt.setHistActionCode(aXContractHistActionCode);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XContractHistCreateDate history attribute.
     *
     * @generated
     */
    public String getXContractHistCreateDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXContractExt.getHistCreateDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XContractHistCreateDate history attribute.
     *
     * @param aXContractHistCreateDate
     *     The new value of XContractHistCreateDate.
     * @generated
     */
    public void setXContractHistCreateDate(String aXContractHistCreateDate) throws Exception{
        metaDataMap.put("XContractHistCreateDate", aXContractHistCreateDate);

        if ((aXContractHistCreateDate == null) || aXContractHistCreateDate.equals("")) {
            aXContractHistCreateDate = null;
        }

        eObjXContractExt.setHistCreateDt(DWLFunctionUtils.getTimestampFromTimestampString(aXContractHistCreateDate));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XContractHistCreatedBy history attribute.
     *
     * @generated
     */
    public String getXContractHistCreatedBy() {
        return eObjXContractExt.getHistCreatedBy();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XContractHistCreatedBy history attribute.
     *
     * @param aXContractHistCreatedBy
     *     The new value of XContractHistCreatedBy.
     * @generated
     */
    public void setXContractHistCreatedBy(String aXContractHistCreatedBy) {
        metaDataMap.put("XContractHistCreatedBy", aXContractHistCreatedBy);

        if ((aXContractHistCreatedBy == null) || aXContractHistCreatedBy.equals("")) {
            aXContractHistCreatedBy = null;
        }

        eObjXContractExt.setHistCreatedBy(aXContractHistCreatedBy);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XContractHistEndDate history attribute.
     *
     * @generated
     */
    public String getXContractHistEndDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXContractExt.getHistEndDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XContractHistEndDate history attribute.
     *
     * @param aXContractHistEndDate
     *     The new value of XContractHistEndDate.
     * @generated
     */
    public void setXContractHistEndDate(String aXContractHistEndDate) throws Exception{
        metaDataMap.put("XContractHistEndDate", aXContractHistEndDate);

        if ((aXContractHistEndDate == null) || aXContractHistEndDate.equals("")) {
            aXContractHistEndDate = null;
        }
        eObjXContractExt.setHistEndDt(DWLFunctionUtils.getTimestampFromTimestampString(aXContractHistEndDate));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XContractHistoryIdPK history attribute.
     *
     * @generated
     */
    public String getXContractHistoryIdPK() {
        return DWLFunctionUtils.getStringFromLong(eObjXContractExt.getHistoryIdPK());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XContractHistoryIdPK history attribute.
     *
     * @param aXContractHistoryIdPK
     *     The new value of XContractHistoryIdPK.
     * @generated
     */
    public void setXContractHistoryIdPK(String aXContractHistoryIdPK) {
        metaDataMap.put("XContractHistoryIdPK", aXContractHistoryIdPK);

        if ((aXContractHistoryIdPK == null) || aXContractHistoryIdPK.equals("")) {
            aXContractHistoryIdPK = null;
        }
        eObjXContractExt.setHistoryIdPK(DWLFunctionUtils.getLongFromString(aXContractHistoryIdPK));
    }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation during an add transaction.
     *
     * @generated
     */
    public DWLStatus validateAdd(int level, DWLStatus status) throws Exception {

        status = super.validateAdd(level, status);
        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0038I Add any controller-level custom validation logic to be
            // executed for this object during an "add" transaction

        }

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            // MDM_TODO0: CDKWB0039I Add any component-level custom validation logic to be
            // executed for this object during an "add" transaction
        }
        status = getValidationStatus(level, status);
        return status;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation during an update transaction.
     *
     * @generated
     */
    public DWLStatus validateUpdate(int level, DWLStatus status) throws Exception {
    logger.finest("ENTER validateUpdate(int level, DWLStatus status)");

        status = super.validateUpdate(level, status);
        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0040I Add any controller-level custom validation logic to be
            // executed for this object during an "update" transaction

        }

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            assignBeforeImageValues(metaDataMap);
            
            // MDM_TODO0: CDKWB0041I Add any component-level custom validation logic to be
            // executed for this object during an "update" transaction
        }
        status = getValidationStatus(level, status);
    if (logger.isFinestEnabled()) {
        	String returnValue = status.toString();
      logger.finest("RETURN validateUpdate(int level, DWLStatus status) " + returnValue);
    }
        return status;
    }



    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation common to both add and update transactions.
     *
     * @generated
     */
     
    private DWLStatus getValidationStatus(int level, DWLStatus status) throws Exception {
    logger.finest("ENTER getValidationStatus(int level, DWLStatus status)");

        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0034I Add any common controller-level custom validation
            // logic to be executed for this object during either "add" or
            // "update" transactions
    	}

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            // MDM_TODO0: CDKWB0035I Add any common component-level custom validation logic
            // to be executed for this object during either "add" or "update"
            // transactions
        }
        
        if (logger.isFinestEnabled()) {
            String returnValue = status.toString();
      logger.finest("RETURN getValidationStatus(int level, DWLStatus status) " + returnValue);
        }
    
        return status;
    }

    private DWLError createDWLError(String entityName, String propertyName,String reasonCode){	
		DWLError err = new DWLError();
		err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCONTRACT_BOBJ_EXT).longValue());
		err.setReasonCode(new Long(reasonCode).longValue());
		err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
			String infoForLogging="Error: Validation error occured. Property " + propertyName + " is null, in entity " + entityName + ", component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
			logger.finest("createDWLError " + infoForLogging);
		}
		return err;
    }
    






	 /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets a record from the extension table.
     *
     * @throws DWLBaseException
     * @generated
     */
    public void getRecord() throws DWLBaseException {
    logger.finest("ENTER getRecord()");
    
    try {
         			
         }
         catch (Exception e) {
            DWLExceptionUtils.log(e);
            
            if (logger.isFinestEnabled()) {
        		String infoForLogging="Error: Error reading record " + e.getMessage(); 
      logger.finest("getRecord() " + infoForLogging);
      }
            status = new DWLStatus();

            TCRMReadException readEx = new TCRMReadException();
            IDWLErrorMessage  errHandler = DWLClassFactory.getErrorHandler();
            DWLError          error = errHandler.getErrorMessage(DSEAAdditionsExtsComponentID.XCONTRACT_BOBJ_EXT,
                                                                 TCRMErrorCode.READ_RECORD_ERROR,
                                                                 DSEAAdditionsExtsErrorReasonCode.READ_EXTENSION_XCONTRACT_FAILED,
                                                                 getControl(), new String[0]);
            error.setThrowable(e);
            status.addError(error);
            status.setStatus(DWLStatus.FATAL);
            readEx.setStatus(status);
            throw readEx;
        }	    		
    logger.finest("RETURN getRecord()");
  }


}

