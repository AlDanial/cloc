
/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[3978227169283f2419d3f40a7b0eae5a]
 */

package com.ibm.daimler.dsea.component;

import com.dwl.tcrm.common.TCRMCommon;



import com.dwl.base.DWLControl;

import com.dwl.base.constant.DWLControlKeys;
import com.dwl.base.constant.DWLUtilErrorReasonCode;

import com.dwl.base.error.DWLError;
import com.dwl.base.error.DWLErrorCode;
import com.dwl.base.error.DWLStatus;

import com.dwl.base.exception.DWLBaseException;
import com.dwl.base.exception.DWLUpdateException;

import com.dwl.base.util.DWLClassFactory;
import com.dwl.base.util.DWLExceptionUtils;
import com.dwl.base.util.DWLFunctionUtils;

import com.dwl.management.config.client.Configuration;

import com.dwl.tcrm.common.ITCRMValidation;

import com.dwl.tcrm.utilities.DateFormatter;
import com.dwl.tcrm.utilities.DateValidator;
import com.dwl.tcrm.utilities.TCRMClassFactory;

import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsComponentID;
import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsErrorReasonCode;
import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsPropertyKeys;

import com.ibm.daimler.dsea.entityObject.EObjXGurantorCompany;

import com.ibm.daimler.dsea.interfaces.DSEAAdditionsExts;

import com.ibm.mdm.common.codetype.interfaces.CodeTypeComponentHelper;

import com.ibm.mdm.common.codetype.obj.CodeTypeBObj;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * This class provides the implementation of the business object
 * <code>XGurantorCompanyBObj</code>.
 * 
 * @see com.dwl.tcrm.common.TCRMCommon
 * @generated
 */
 

@SuppressWarnings("serial")
public class XGurantorCompanyBObj extends TCRMCommon  {

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected EObjXGurantorCompany eObjXGurantorCompany;
	/**
    * <!-- begin-user-doc -->
	  * <!-- end-user-doc -->
    * @generated 
    */
	 private final static com.dwl.base.logging.IDWLLogger logger = com.dwl.base.logging.DWLLoggerManager.getLogger(XGurantorCompanyBObj.class);
		
 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected String industryValue;
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected String addressUsageValue;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected String countryValue;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected String sourceIdentifierValue;
	protected boolean isValidStartDate = true;
	
	protected boolean isValidEndDate = true;
	


    protected boolean isValidLastModifiedSystemDate = true;



    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */     
    public XGurantorCompanyBObj() {
        super();
        init();
        eObjXGurantorCompany = new EObjXGurantorCompany();
        setComponentID(DSEAAdditionsExtsComponentID.XGURANTOR_COMPANY_BOBJ);
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Initializes the fields required to populate the metaDataMap. Each key is
     * an element-level field of the business object.
     *
     * @generated
     */
    private void init() {
        metaDataMap.put("XGurantorCompanypkId", null);
        metaDataMap.put("ContractDetailsId", null);
        metaDataMap.put("BPID", null);
        metaDataMap.put("CANNumber", null);
        metaDataMap.put("IndustryType", null);
        metaDataMap.put("IndustryValue", null);
        metaDataMap.put("CompanyName", null);
        metaDataMap.put("CompanyNameLocal", null);
        metaDataMap.put("AddressUsageType", null);
        metaDataMap.put("AddressUsageValue", null);
        metaDataMap.put("AddressLineOne", null);
        metaDataMap.put("AddressLineTwo", null);
        metaDataMap.put("AddressLineThree", null);
        metaDataMap.put("PostalCode", null);
        metaDataMap.put("CityName", null);
        metaDataMap.put("ResidenceNumber", null);
        metaDataMap.put("CountryType", null);
        metaDataMap.put("CountryValue", null);
        metaDataMap.put("BuildingName", null);
        metaDataMap.put("StreetName", null);
        metaDataMap.put("StreetNumber", null);
        metaDataMap.put("MobileNumber", null);
        metaDataMap.put("HomePhoneNumber", null);
        metaDataMap.put("WorkPhoneNumber", null);
        metaDataMap.put("WorkPhoneNumberExtension", null);
        metaDataMap.put("Fax", null);
        metaDataMap.put("Email", null);
        metaDataMap.put("SourceIdentifierType", null);
        metaDataMap.put("SourceIdentifierValue", null);
        metaDataMap.put("StartDate", null);
        metaDataMap.put("EndDate", null);
        metaDataMap.put("LastModifiedSystemDate", null);
        metaDataMap.put("XGurantorCompanyHistActionCode", null);
        metaDataMap.put("XGurantorCompanyHistCreateDate", null);
        metaDataMap.put("XGurantorCompanyHistCreatedBy", null);
        metaDataMap.put("XGurantorCompanyHistEndDate", null);
        metaDataMap.put("XGurantorCompanyHistoryIdPK", null);
        metaDataMap.put("XGurantorCompanyLastUpdateDate", null);
        metaDataMap.put("XGurantorCompanyLastUpdateTxId", null);
        metaDataMap.put("XGurantorCompanyLastUpdateUser", null);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Refreshes all the attributes this business object supports.
     *
     * @see com.dwl.base.DWLCommon#refreshMap()
     * @generated
     */
    public void refreshMap() {

        if (bRequireMapRefresh) {
            super.refreshMap();
            metaDataMap.put("XGurantorCompanypkId", getXGurantorCompanypkId());
            metaDataMap.put("ContractDetailsId", getContractDetailsId());
            metaDataMap.put("BPID", getBPID());
            metaDataMap.put("CANNumber", getCANNumber());
            metaDataMap.put("IndustryType", getIndustryType());
            metaDataMap.put("IndustryValue", getIndustryValue());
            metaDataMap.put("CompanyName", getCompanyName());
            metaDataMap.put("CompanyNameLocal", getCompanyNameLocal());
            metaDataMap.put("AddressUsageType", getAddressUsageType());
            metaDataMap.put("AddressUsageValue", getAddressUsageValue());
            metaDataMap.put("AddressLineOne", getAddressLineOne());
            metaDataMap.put("AddressLineTwo", getAddressLineTwo());
            metaDataMap.put("AddressLineThree", getAddressLineThree());
            metaDataMap.put("PostalCode", getPostalCode());
            metaDataMap.put("CityName", getCityName());
            metaDataMap.put("ResidenceNumber", getResidenceNumber());
            metaDataMap.put("CountryType", getCountryType());
            metaDataMap.put("CountryValue", getCountryValue());
            metaDataMap.put("BuildingName", getBuildingName());
            metaDataMap.put("StreetName", getStreetName());
            metaDataMap.put("StreetNumber", getStreetNumber());
            metaDataMap.put("MobileNumber", getMobileNumber());
            metaDataMap.put("HomePhoneNumber", getHomePhoneNumber());
            metaDataMap.put("WorkPhoneNumber", getWorkPhoneNumber());
            metaDataMap.put("WorkPhoneNumberExtension", getWorkPhoneNumberExtension());
            metaDataMap.put("Fax", getFax());
            metaDataMap.put("Email", getEmail());
            metaDataMap.put("SourceIdentifierType", getSourceIdentifierType());
            metaDataMap.put("SourceIdentifierValue", getSourceIdentifierValue());
            metaDataMap.put("StartDate", getStartDate());
            metaDataMap.put("EndDate", getEndDate());
            metaDataMap.put("LastModifiedSystemDate", getLastModifiedSystemDate());
            metaDataMap.put("XGurantorCompanyHistActionCode", getXGurantorCompanyHistActionCode());
            metaDataMap.put("XGurantorCompanyHistCreateDate", getXGurantorCompanyHistCreateDate());
            metaDataMap.put("XGurantorCompanyHistCreatedBy", getXGurantorCompanyHistCreatedBy());
            metaDataMap.put("XGurantorCompanyHistEndDate", getXGurantorCompanyHistEndDate());
            metaDataMap.put("XGurantorCompanyHistoryIdPK", getXGurantorCompanyHistoryIdPK());
            metaDataMap.put("XGurantorCompanyLastUpdateDate", getXGurantorCompanyLastUpdateDate());
            metaDataMap.put("XGurantorCompanyLastUpdateTxId", getXGurantorCompanyLastUpdateTxId());
            metaDataMap.put("XGurantorCompanyLastUpdateUser", getXGurantorCompanyLastUpdateUser());
            bRequireMapRefresh = false;
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the control object on this business object.
     *
     * @see com.dwl.base.DWLCommon#setControl(DWLControl)
     * @generated
     */
    public void setControl(DWLControl newDWLControl) {
        super.setControl(newDWLControl);

        if (eObjXGurantorCompany != null) {
            eObjXGurantorCompany.setControl(newDWLControl);
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the entity object associated with this business object.
     *
     * @generated
     */
    public EObjXGurantorCompany getEObjXGurantorCompany() {
        bRequireMapRefresh = true;
        return eObjXGurantorCompany;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the entity object associated with this business object.
     *
     * @param eObjXGurantorCompany
     *            The eObjXGurantorCompany to set.
     * @generated
     */
    public void setEObjXGurantorCompany(EObjXGurantorCompany eObjXGurantorCompany) {
        bRequireMapRefresh = true;
        this.eObjXGurantorCompany = eObjXGurantorCompany;
        if (this.eObjXGurantorCompany != null && this.eObjXGurantorCompany.getControl() == null) {
            DWLControl control = this.getControl();
            if (control != null) {
                this.eObjXGurantorCompany.setControl(control);
            }
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xGurantorCompanypkId attribute.
     * 
     * @generated
     */
    public String getXGurantorCompanypkId (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXGurantorCompany.getXGurantorCompanypkId());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xGurantorCompanypkId attribute.
     * 
     * @param newXGurantorCompanypkId
     *     The new value of xGurantorCompanypkId.
     * @generated
     */
    public void setXGurantorCompanypkId( String newXGurantorCompanypkId ) throws Exception {
        metaDataMap.put("XGurantorCompanypkId", newXGurantorCompanypkId);

        if (newXGurantorCompanypkId == null || newXGurantorCompanypkId.equals("")) {
            newXGurantorCompanypkId = null;


        }
        eObjXGurantorCompany.setXGurantorCompanypkId( DWLFunctionUtils.getLongFromString(newXGurantorCompanypkId) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the contractDetailsId attribute.
     * 
     * @generated
     */
    public String getContractDetailsId (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXGurantorCompany.getContractDetailsId());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the contractDetailsId attribute.
     * 
     * @param newContractDetailsId
     *     The new value of contractDetailsId.
     * @generated
     */
    public void setContractDetailsId( String newContractDetailsId ) throws Exception {
        metaDataMap.put("ContractDetailsId", newContractDetailsId);

        if (newContractDetailsId == null || newContractDetailsId.equals("")) {
            newContractDetailsId = null;


        }
        eObjXGurantorCompany.setContractDetailsId( DWLFunctionUtils.getLongFromString(newContractDetailsId) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the bPID attribute.
     * 
     * @generated
     */
    public String getBPID (){
   
        return eObjXGurantorCompany.getBPID();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the bPID attribute.
     * 
     * @param newBPID
     *     The new value of bPID.
     * @generated
     */
    public void setBPID( String newBPID ) throws Exception {
        metaDataMap.put("BPID", newBPID);

        if (newBPID == null || newBPID.equals("")) {
            newBPID = null;


        }
        eObjXGurantorCompany.setBPID( newBPID );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the cANNumber attribute.
     * 
     * @generated
     */
    public String getCANNumber (){
   
        return eObjXGurantorCompany.getCANNumber();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the cANNumber attribute.
     * 
     * @param newCANNumber
     *     The new value of cANNumber.
     * @generated
     */
    public void setCANNumber( String newCANNumber ) throws Exception {
        metaDataMap.put("CANNumber", newCANNumber);

        if (newCANNumber == null || newCANNumber.equals("")) {
            newCANNumber = null;


        }
        eObjXGurantorCompany.setCANNumber( newCANNumber );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the industryType attribute.
     * 
     * @generated
     */
    public String getIndustryType (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXGurantorCompany.getIndustry());
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the industryType attribute.
     * 
     * @param newIndustryType
     *     The new value of industryType.
     * @generated
     */
    public void setIndustryType( String newIndustryType ) throws Exception {
        metaDataMap.put("IndustryType", newIndustryType);

        if (newIndustryType == null || newIndustryType.equals("")) {
            newIndustryType = null;


        }
        eObjXGurantorCompany.setIndustry( DWLFunctionUtils.getLongFromString(newIndustryType) );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the industryValue attribute.
     * 
     * @generated
     */
    public String getIndustryValue (){
      return industryValue;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the industryValue attribute.
     * 
     * @param newIndustryValue
     *     The new value of industryValue.
     * @generated
     */
    public void setIndustryValue( String newIndustryValue ) throws Exception {
        metaDataMap.put("IndustryValue", newIndustryValue);

        if (newIndustryValue == null || newIndustryValue.equals("")) {
            newIndustryValue = null;


        }
        industryValue = newIndustryValue;
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the companyName attribute.
     * 
     * @generated
     */
    public String getCompanyName (){
   
        return eObjXGurantorCompany.getCompanyName();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the companyName attribute.
     * 
     * @param newCompanyName
     *     The new value of companyName.
     * @generated
     */
    public void setCompanyName( String newCompanyName ) throws Exception {
        metaDataMap.put("CompanyName", newCompanyName);

        if (newCompanyName == null || newCompanyName.equals("")) {
            newCompanyName = null;


        }
        eObjXGurantorCompany.setCompanyName( newCompanyName );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the companyNameLocal attribute.
     * 
     * @generated
     */
    public String getCompanyNameLocal (){
   
        return eObjXGurantorCompany.getCompanyNameLocal();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the companyNameLocal attribute.
     * 
     * @param newCompanyNameLocal
     *     The new value of companyNameLocal.
     * @generated
     */
    public void setCompanyNameLocal( String newCompanyNameLocal ) throws Exception {
        metaDataMap.put("CompanyNameLocal", newCompanyNameLocal);

        if (newCompanyNameLocal == null || newCompanyNameLocal.equals("")) {
            newCompanyNameLocal = null;


        }
        eObjXGurantorCompany.setCompanyNameLocal( newCompanyNameLocal );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the addressUsageType attribute.
     * 
     * @generated
     */
    public String getAddressUsageType (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXGurantorCompany.getAddressUsage());
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the addressUsageType attribute.
     * 
     * @param newAddressUsageType
     *     The new value of addressUsageType.
     * @generated
     */
    public void setAddressUsageType( String newAddressUsageType ) throws Exception {
        metaDataMap.put("AddressUsageType", newAddressUsageType);

        if (newAddressUsageType == null || newAddressUsageType.equals("")) {
            newAddressUsageType = null;


        }
        eObjXGurantorCompany.setAddressUsage( DWLFunctionUtils.getLongFromString(newAddressUsageType) );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the addressUsageValue attribute.
     * 
     * @generated
     */
    public String getAddressUsageValue (){
      return addressUsageValue;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the addressUsageValue attribute.
     * 
     * @param newAddressUsageValue
     *     The new value of addressUsageValue.
     * @generated
     */
    public void setAddressUsageValue( String newAddressUsageValue ) throws Exception {
        metaDataMap.put("AddressUsageValue", newAddressUsageValue);

        if (newAddressUsageValue == null || newAddressUsageValue.equals("")) {
            newAddressUsageValue = null;


        }
        addressUsageValue = newAddressUsageValue;
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the addressLineOne attribute.
     * 
     * @generated
     */
    public String getAddressLineOne (){
   
        return eObjXGurantorCompany.getAddressLineOne();
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the addressLineOne attribute.
     * 
     * @param newAddressLineOne
     *     The new value of addressLineOne.
     * @generated
     */
    public void setAddressLineOne( String newAddressLineOne ) throws Exception {
        metaDataMap.put("AddressLineOne", newAddressLineOne);

        if (newAddressLineOne == null || newAddressLineOne.equals("")) {
            newAddressLineOne = null;


        }
        eObjXGurantorCompany.setAddressLineOne( newAddressLineOne );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the addressLineTwo attribute.
     * 
     * @generated
     */
    public String getAddressLineTwo (){
   
        return eObjXGurantorCompany.getAddressLineTwo();
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the addressLineTwo attribute.
     * 
     * @param newAddressLineTwo
     *     The new value of addressLineTwo.
     * @generated
     */
    public void setAddressLineTwo( String newAddressLineTwo ) throws Exception {
        metaDataMap.put("AddressLineTwo", newAddressLineTwo);

        if (newAddressLineTwo == null || newAddressLineTwo.equals("")) {
            newAddressLineTwo = null;


        }
        eObjXGurantorCompany.setAddressLineTwo( newAddressLineTwo );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the addressLineThree attribute.
     * 
     * @generated
     */
    public String getAddressLineThree (){
   
        return eObjXGurantorCompany.getAddressLineThree();
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the addressLineThree attribute.
     * 
     * @param newAddressLineThree
     *     The new value of addressLineThree.
     * @generated
     */
    public void setAddressLineThree( String newAddressLineThree ) throws Exception {
        metaDataMap.put("AddressLineThree", newAddressLineThree);

        if (newAddressLineThree == null || newAddressLineThree.equals("")) {
            newAddressLineThree = null;


        }
        eObjXGurantorCompany.setAddressLineThree( newAddressLineThree );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the postalCode attribute.
     * 
     * @generated
     */
    public String getPostalCode (){
   
        return eObjXGurantorCompany.getPostalCode();
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the postalCode attribute.
     * 
     * @param newPostalCode
     *     The new value of postalCode.
     * @generated
     */
    public void setPostalCode( String newPostalCode ) throws Exception {
        metaDataMap.put("PostalCode", newPostalCode);

        if (newPostalCode == null || newPostalCode.equals("")) {
            newPostalCode = null;


        }
        eObjXGurantorCompany.setPostalCode( newPostalCode );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the cityName attribute.
     * 
     * @generated
     */
    public String getCityName (){
   
        return eObjXGurantorCompany.getCityName();
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the cityName attribute.
     * 
     * @param newCityName
     *     The new value of cityName.
     * @generated
     */
    public void setCityName( String newCityName ) throws Exception {
        metaDataMap.put("CityName", newCityName);

        if (newCityName == null || newCityName.equals("")) {
            newCityName = null;


        }
        eObjXGurantorCompany.setCityName( newCityName );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the residenceNumber attribute.
     * 
     * @generated
     */
    public String getResidenceNumber (){
   
        return eObjXGurantorCompany.getResidenceNumber();
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the residenceNumber attribute.
     * 
     * @param newResidenceNumber
     *     The new value of residenceNumber.
     * @generated
     */
    public void setResidenceNumber( String newResidenceNumber ) throws Exception {
        metaDataMap.put("ResidenceNumber", newResidenceNumber);

        if (newResidenceNumber == null || newResidenceNumber.equals("")) {
            newResidenceNumber = null;


        }
        eObjXGurantorCompany.setResidenceNumber( newResidenceNumber );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the countryType attribute.
     * 
     * @generated
     */
    public String getCountryType (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXGurantorCompany.getCountry());
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the countryType attribute.
     * 
     * @param newCountryType
     *     The new value of countryType.
     * @generated
     */
    public void setCountryType( String newCountryType ) throws Exception {
        metaDataMap.put("CountryType", newCountryType);

        if (newCountryType == null || newCountryType.equals("")) {
            newCountryType = null;


        }
        eObjXGurantorCompany.setCountry( DWLFunctionUtils.getLongFromString(newCountryType) );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the countryValue attribute.
     * 
     * @generated
     */
    public String getCountryValue (){
      return countryValue;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the countryValue attribute.
     * 
     * @param newCountryValue
     *     The new value of countryValue.
     * @generated
     */
    public void setCountryValue( String newCountryValue ) throws Exception {
        metaDataMap.put("CountryValue", newCountryValue);

        if (newCountryValue == null || newCountryValue.equals("")) {
            newCountryValue = null;


        }
        countryValue = newCountryValue;
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the buildingName attribute.
     * 
     * @generated
     */
    public String getBuildingName (){
   
        return eObjXGurantorCompany.getBuildingName();
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the buildingName attribute.
     * 
     * @param newBuildingName
     *     The new value of buildingName.
     * @generated
     */
    public void setBuildingName( String newBuildingName ) throws Exception {
        metaDataMap.put("BuildingName", newBuildingName);

        if (newBuildingName == null || newBuildingName.equals("")) {
            newBuildingName = null;


        }
        eObjXGurantorCompany.setBuildingName( newBuildingName );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the streetName attribute.
     * 
     * @generated
     */
    public String getStreetName (){
   
        return eObjXGurantorCompany.getStreetName();
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the streetName attribute.
     * 
     * @param newStreetName
     *     The new value of streetName.
     * @generated
     */
    public void setStreetName( String newStreetName ) throws Exception {
        metaDataMap.put("StreetName", newStreetName);

        if (newStreetName == null || newStreetName.equals("")) {
            newStreetName = null;


        }
        eObjXGurantorCompany.setStreetName( newStreetName );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the streetNumber attribute.
     * 
     * @generated
     */
    public String getStreetNumber (){
   
        return eObjXGurantorCompany.getStreetNumber();
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the streetNumber attribute.
     * 
     * @param newStreetNumber
     *     The new value of streetNumber.
     * @generated
     */
    public void setStreetNumber( String newStreetNumber ) throws Exception {
        metaDataMap.put("StreetNumber", newStreetNumber);

        if (newStreetNumber == null || newStreetNumber.equals("")) {
            newStreetNumber = null;


        }
        eObjXGurantorCompany.setStreetNumber( newStreetNumber );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the mobileNumber attribute.
     * 
     * @generated
     */
    public String getMobileNumber (){
   
        return eObjXGurantorCompany.getMobileNumber();
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the mobileNumber attribute.
     * 
     * @param newMobileNumber
     *     The new value of mobileNumber.
     * @generated
     */
    public void setMobileNumber( String newMobileNumber ) throws Exception {
        metaDataMap.put("MobileNumber", newMobileNumber);

        if (newMobileNumber == null || newMobileNumber.equals("")) {
            newMobileNumber = null;


        }
        eObjXGurantorCompany.setMobileNumber( newMobileNumber );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the homePhoneNumber attribute.
     * 
     * @generated
     */
    public String getHomePhoneNumber (){
   
        return eObjXGurantorCompany.getHomePhoneNumber();
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the homePhoneNumber attribute.
     * 
     * @param newHomePhoneNumber
     *     The new value of homePhoneNumber.
     * @generated
     */
    public void setHomePhoneNumber( String newHomePhoneNumber ) throws Exception {
        metaDataMap.put("HomePhoneNumber", newHomePhoneNumber);

        if (newHomePhoneNumber == null || newHomePhoneNumber.equals("")) {
            newHomePhoneNumber = null;


        }
        eObjXGurantorCompany.setHomePhoneNumber( newHomePhoneNumber );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the workPhoneNumber attribute.
     * 
     * @generated
     */
    public String getWorkPhoneNumber (){
   
        return eObjXGurantorCompany.getWorkPhoneNumber();
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the workPhoneNumber attribute.
     * 
     * @param newWorkPhoneNumber
     *     The new value of workPhoneNumber.
     * @generated
     */
    public void setWorkPhoneNumber( String newWorkPhoneNumber ) throws Exception {
        metaDataMap.put("WorkPhoneNumber", newWorkPhoneNumber);

        if (newWorkPhoneNumber == null || newWorkPhoneNumber.equals("")) {
            newWorkPhoneNumber = null;


        }
        eObjXGurantorCompany.setWorkPhoneNumber( newWorkPhoneNumber );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the workPhoneNumberExtension attribute.
     * 
     * @generated
     */
    public String getWorkPhoneNumberExtension (){
   
        return eObjXGurantorCompany.getWorkPhoneNumberExtension();
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the workPhoneNumberExtension attribute.
     * 
     * @param newWorkPhoneNumberExtension
     *     The new value of workPhoneNumberExtension.
     * @generated
     */
    public void setWorkPhoneNumberExtension( String newWorkPhoneNumberExtension ) throws Exception {
        metaDataMap.put("WorkPhoneNumberExtension", newWorkPhoneNumberExtension);

        if (newWorkPhoneNumberExtension == null || newWorkPhoneNumberExtension.equals("")) {
            newWorkPhoneNumberExtension = null;


        }
        eObjXGurantorCompany.setWorkPhoneNumberExtension( newWorkPhoneNumberExtension );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the fax attribute.
     * 
     * @generated
     */
    public String getFax (){
   
        return eObjXGurantorCompany.getFax();
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the fax attribute.
     * 
     * @param newFax
     *     The new value of fax.
     * @generated
     */
    public void setFax( String newFax ) throws Exception {
        metaDataMap.put("Fax", newFax);

        if (newFax == null || newFax.equals("")) {
            newFax = null;


        }
        eObjXGurantorCompany.setFax( newFax );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the email attribute.
     * 
     * @generated
     */
    public String getEmail (){
   
        return eObjXGurantorCompany.getEmail();
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the email attribute.
     * 
     * @param newEmail
     *     The new value of email.
     * @generated
     */
    public void setEmail( String newEmail ) throws Exception {
        metaDataMap.put("Email", newEmail);

        if (newEmail == null || newEmail.equals("")) {
            newEmail = null;


        }
        eObjXGurantorCompany.setEmail( newEmail );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the sourceIdentifierType attribute.
     * 
     * @generated
     */
    public String getSourceIdentifierType (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXGurantorCompany.getSourceIdentifier());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the sourceIdentifierType attribute.
     * 
     * @param newSourceIdentifierType
     *     The new value of sourceIdentifierType.
     * @generated
     */
    public void setSourceIdentifierType( String newSourceIdentifierType ) throws Exception {
        metaDataMap.put("SourceIdentifierType", newSourceIdentifierType);

        if (newSourceIdentifierType == null || newSourceIdentifierType.equals("")) {
            newSourceIdentifierType = null;


        }
        eObjXGurantorCompany.setSourceIdentifier( DWLFunctionUtils.getLongFromString(newSourceIdentifierType) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the sourceIdentifierValue attribute.
     * 
     * @generated
     */
    public String getSourceIdentifierValue (){
      return sourceIdentifierValue;
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the sourceIdentifierValue attribute.
     * 
     * @param newSourceIdentifierValue
     *     The new value of sourceIdentifierValue.
     * @generated
     */
    public void setSourceIdentifierValue( String newSourceIdentifierValue ) throws Exception {
        metaDataMap.put("SourceIdentifierValue", newSourceIdentifierValue);

        if (newSourceIdentifierValue == null || newSourceIdentifierValue.equals("")) {
            newSourceIdentifierValue = null;


        }
        sourceIdentifierValue = newSourceIdentifierValue;
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the startDate attribute.
     * 
     * @generated
     */
    public String getStartDate (){
   
        return DWLFunctionUtils.getStringFromTimestamp(eObjXGurantorCompany.getStartDate());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the startDate attribute.
     * 
     * @param newStartDate
     *     The new value of startDate.
     * @generated
     */
    public void setStartDate( String newStartDate ) throws Exception {
        metaDataMap.put("StartDate", newStartDate);
       	isValidStartDate = true;

        if (newStartDate == null || newStartDate.equals("")) {
            newStartDate = null;
            eObjXGurantorCompany.setStartDate(null);


        }
    else {
        	if (DateValidator.validates(newStartDate)) {
           		eObjXGurantorCompany.setStartDate(DateFormatter.getStartDateTimestamp(newStartDate));
            	metaDataMap.put("StartDate", getStartDate());
        	} else {
            	if (Configuration.getConfiguration().getConfigItem(
              "/IBM/DWLCommonServices/InternalValidation/enabled").getBooleanValue()) {
                	if (metaDataMap.get("StartDate") != null) {
                    	metaDataMap.put("StartDate", "");
                	}
                	isValidStartDate = false;
                	eObjXGurantorCompany.setStartDate(null);
            	}
        	}
        }
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the endDate attribute.
     * 
     * @generated
     */
    public String getEndDate (){
   
        return DWLFunctionUtils.getStringFromTimestamp(eObjXGurantorCompany.getEndDate());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the endDate attribute.
     * 
     * @param newEndDate
     *     The new value of endDate.
     * @generated
     */
    public void setEndDate( String newEndDate ) throws Exception {
        metaDataMap.put("EndDate", newEndDate);
       	isValidEndDate = true;

        if (newEndDate == null || newEndDate.equals("")) {
            newEndDate = null;
            eObjXGurantorCompany.setEndDate(null);


        }
    else {
        	if (DateValidator.validates(newEndDate)) {
           		eObjXGurantorCompany.setEndDate(DateFormatter.getStartDateTimestamp(newEndDate));
            	metaDataMap.put("EndDate", getEndDate());
        	} else {
            	if (Configuration.getConfiguration().getConfigItem(
              "/IBM/DWLCommonServices/InternalValidation/enabled").getBooleanValue()) {
                	if (metaDataMap.get("EndDate") != null) {
                    	metaDataMap.put("EndDate", "");
                	}
                	isValidEndDate = false;
                	eObjXGurantorCompany.setEndDate(null);
            	}
        	}
        }
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the lastModifiedSystemDate attribute.
     * 
     * @generated
     */
    public String getLastModifiedSystemDate (){
   
        return DWLFunctionUtils.getStringFromTimestamp(eObjXGurantorCompany.getLastModifiedSystemDate());
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the lastModifiedSystemDate attribute.
     * 
     * @param newLastModifiedSystemDate
     *     The new value of lastModifiedSystemDate.
     * @generated
     */
    public void setLastModifiedSystemDate( String newLastModifiedSystemDate ) throws Exception {
        metaDataMap.put("LastModifiedSystemDate", newLastModifiedSystemDate);
       	isValidLastModifiedSystemDate = true;

        if (newLastModifiedSystemDate == null || newLastModifiedSystemDate.equals("")) {
            newLastModifiedSystemDate = null;
            eObjXGurantorCompany.setLastModifiedSystemDate(null);


        }
    else {
        	if (DateValidator.validates(newLastModifiedSystemDate)) {
           		eObjXGurantorCompany.setLastModifiedSystemDate(DateFormatter.getStartDateTimestamp(newLastModifiedSystemDate));
            	metaDataMap.put("LastModifiedSystemDate", getLastModifiedSystemDate());
        	} else {
            	if (Configuration.getConfiguration().getConfigItem(
              "/IBM/DWLCommonServices/InternalValidation/enabled").getBooleanValue()) {
                	if (metaDataMap.get("LastModifiedSystemDate") != null) {
                    	metaDataMap.put("LastModifiedSystemDate", "");
                	}
                	isValidLastModifiedSystemDate = false;
                	eObjXGurantorCompany.setLastModifiedSystemDate(null);
            	}
        	}
        }
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateTxId attribute.
     *
     * @generated
     */
    public String getXGurantorCompanyLastUpdateTxId() {
        return DWLFunctionUtils.getStringFromLong(eObjXGurantorCompany.getLastUpdateTxId());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateUser attribute.
     *
     * @generated
     */
    public String getXGurantorCompanyLastUpdateUser() {
        return eObjXGurantorCompany.getLastUpdateUser();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateDt attribute.
     *
     * @generated
     */
    public String getXGurantorCompanyLastUpdateDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXGurantorCompany.getLastUpdateDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateTxId attribute.
     *
     * @param newLastUpdateTxId
     *     The new value of LastUpdateTxId.
     * @generated
     */
    public void setXGurantorCompanyLastUpdateTxId(String newLastUpdateTxId) {
        metaDataMap.put("XGurantorCompanyLastUpdateTxId", newLastUpdateTxId);

        if ((newLastUpdateTxId == null) || newLastUpdateTxId.equals("")) {
            newLastUpdateTxId = null;
        }
        eObjXGurantorCompany.setLastUpdateTxId(DWLFunctionUtils.getLongFromString(newLastUpdateTxId));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateUser attribute.
     *
     * @param newLastUpdateUser
     *     The new value of LastUpdateUser.
     * @generated
     */
    public void setXGurantorCompanyLastUpdateUser(String newLastUpdateUser) {
        metaDataMap.put("XGurantorCompanyLastUpdateUser", newLastUpdateUser);

        if ((newLastUpdateUser == null) || newLastUpdateUser.equals("")) {
            newLastUpdateUser = null;
        }
        eObjXGurantorCompany.setLastUpdateUser(newLastUpdateUser);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateDt attribute.
     *
     * @param newLastUpdateDt
     *     The new value of LastUpdateDt.
     * @throws Exception
     * @generated
     */
    public void setXGurantorCompanyLastUpdateDate(String newLastUpdateDt) throws Exception {
        metaDataMap.put("XGurantorCompanyLastUpdateDate", newLastUpdateDt);

        if ((newLastUpdateDt == null) || newLastUpdateDt.equals("")) {
            newLastUpdateDt = null;
        }

        eObjXGurantorCompany.setLastUpdateDt(DWLFunctionUtils.getTimestampFromTimestampString(newLastUpdateDt));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XGurantorCompanyHistActionCode history attribute.
     *
     * @generated
     */
    public String getXGurantorCompanyHistActionCode() {
        return eObjXGurantorCompany.getHistActionCode();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XGurantorCompanyHistActionCode history attribute.
     *
     * @param aXGurantorCompanyHistActionCode
     *     The new value of XGurantorCompanyHistActionCode.
     * @generated
     */
    public void setXGurantorCompanyHistActionCode(String aXGurantorCompanyHistActionCode) {
        metaDataMap.put("XGurantorCompanyHistActionCode", aXGurantorCompanyHistActionCode);

        if ((aXGurantorCompanyHistActionCode == null) || aXGurantorCompanyHistActionCode.equals("")) {
            aXGurantorCompanyHistActionCode = null;
        }
        eObjXGurantorCompany.setHistActionCode(aXGurantorCompanyHistActionCode);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XGurantorCompanyHistCreateDate history attribute.
     *
     * @generated
     */
    public String getXGurantorCompanyHistCreateDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXGurantorCompany.getHistCreateDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XGurantorCompanyHistCreateDate history attribute.
     *
     * @param aXGurantorCompanyHistCreateDate
     *     The new value of XGurantorCompanyHistCreateDate.
     * @generated
     */
    public void setXGurantorCompanyHistCreateDate(String aXGurantorCompanyHistCreateDate) throws Exception{
        metaDataMap.put("XGurantorCompanyHistCreateDate", aXGurantorCompanyHistCreateDate);

        if ((aXGurantorCompanyHistCreateDate == null) || aXGurantorCompanyHistCreateDate.equals("")) {
            aXGurantorCompanyHistCreateDate = null;
        }

        eObjXGurantorCompany.setHistCreateDt(DWLFunctionUtils.getTimestampFromTimestampString(aXGurantorCompanyHistCreateDate));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XGurantorCompanyHistCreatedBy history attribute.
     *
     * @generated
     */
    public String getXGurantorCompanyHistCreatedBy() {
        return eObjXGurantorCompany.getHistCreatedBy();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XGurantorCompanyHistCreatedBy history attribute.
     *
     * @param aXGurantorCompanyHistCreatedBy
     *     The new value of XGurantorCompanyHistCreatedBy.
     * @generated
     */
    public void setXGurantorCompanyHistCreatedBy(String aXGurantorCompanyHistCreatedBy) {
        metaDataMap.put("XGurantorCompanyHistCreatedBy", aXGurantorCompanyHistCreatedBy);

        if ((aXGurantorCompanyHistCreatedBy == null) || aXGurantorCompanyHistCreatedBy.equals("")) {
            aXGurantorCompanyHistCreatedBy = null;
        }

        eObjXGurantorCompany.setHistCreatedBy(aXGurantorCompanyHistCreatedBy);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XGurantorCompanyHistEndDate history attribute.
     *
     * @generated
     */
    public String getXGurantorCompanyHistEndDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXGurantorCompany.getHistEndDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XGurantorCompanyHistEndDate history attribute.
     *
     * @param aXGurantorCompanyHistEndDate
     *     The new value of XGurantorCompanyHistEndDate.
     * @generated
     */
    public void setXGurantorCompanyHistEndDate(String aXGurantorCompanyHistEndDate) throws Exception{
        metaDataMap.put("XGurantorCompanyHistEndDate", aXGurantorCompanyHistEndDate);

        if ((aXGurantorCompanyHistEndDate == null) || aXGurantorCompanyHistEndDate.equals("")) {
            aXGurantorCompanyHistEndDate = null;
        }
        eObjXGurantorCompany.setHistEndDt(DWLFunctionUtils.getTimestampFromTimestampString(aXGurantorCompanyHistEndDate));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XGurantorCompanyHistoryIdPK history attribute.
     *
     * @generated
     */
    public String getXGurantorCompanyHistoryIdPK() {
        return DWLFunctionUtils.getStringFromLong(eObjXGurantorCompany.getHistoryIdPK());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XGurantorCompanyHistoryIdPK history attribute.
     *
     * @param aXGurantorCompanyHistoryIdPK
     *     The new value of XGurantorCompanyHistoryIdPK.
     * @generated
     */
    public void setXGurantorCompanyHistoryIdPK(String aXGurantorCompanyHistoryIdPK) {
        metaDataMap.put("XGurantorCompanyHistoryIdPK", aXGurantorCompanyHistoryIdPK);

        if ((aXGurantorCompanyHistoryIdPK == null) || aXGurantorCompanyHistoryIdPK.equals("")) {
            aXGurantorCompanyHistoryIdPK = null;
        }
        eObjXGurantorCompany.setHistoryIdPK(DWLFunctionUtils.getLongFromString(aXGurantorCompanyHistoryIdPK));
    }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation during an add transaction.
     *
     * @generated
     */
    public DWLStatus validateAdd(int level, DWLStatus status) throws Exception {

        status = super.validateAdd(level, status);
        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0038I Add any controller-level custom validation logic to be
            // executed for this object during an "add" transaction

        }

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            // MDM_TODO0: CDKWB0039I Add any component-level custom validation logic to be
            // executed for this object during an "add" transaction
        }
        status = getValidationStatus(level, status);
        return status;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation during an update transaction.
     *
     * @generated
     */
    public DWLStatus validateUpdate(int level, DWLStatus status) throws Exception {
    logger.finest("ENTER validateUpdate(int level, DWLStatus status)");

        status = super.validateUpdate(level, status);
        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0040I Add any controller-level custom validation logic to be
            // executed for this object during an "update" transaction

            if (eObjXGurantorCompany.getXGurantorCompanypkId() == null) {
                DWLError err = new DWLError();
                err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XGURANTOR_COMPANY_BOBJ).longValue());
                err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.XGURANTORCOMPANY_XGURANTORCOMPANYPKID_NULL).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                	String infoForLogging="Error: Validation error occured for update. No primary key for entity XGurantorCompany, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("validateUpdate(int level, DWLStatus status) " + infoForLogging);
                }
                status.addError(err);
            }
            if (eObjXGurantorCompany.getLastUpdateDt() == null) {
                DWLError err = new DWLError();
                err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XGURANTOR_COMPANY_BOBJ).longValue());
                err.setReasonCode(new Long(DWLUtilErrorReasonCode.LAST_UPDATED_DATE_NULL).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
                if (logger.isFinestEnabled()) {
                	String infoForLogging="Error: Validation error occured for update. No last update date for entity XGurantorCompany, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("validateUpdate(int level, DWLStatus status) " + infoForLogging);
                }
                status.addError(err);
            }
        }

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            assignBeforeImageValues(metaDataMap);
            
            // MDM_TODO0: CDKWB0041I Add any component-level custom validation logic to be
            // executed for this object during an "update" transaction
        }
        status = getValidationStatus(level, status);
    if (logger.isFinestEnabled()) {
        	String returnValue = status.toString();
      logger.finest("RETURN validateUpdate(int level, DWLStatus status) " + returnValue);
    }
        return status;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Populate the before image of this business object.
     *
     * @see com.dwl.base.DWLCommon#populateBeforeImage()
     * @generated
     */
    public void populateBeforeImage() throws DWLBaseException {
    logger.finest("ENTER populateBeforeImage()");

        DSEAAdditionsExts comp = null;
        try {
        
      comp = (DSEAAdditionsExts)TCRMClassFactory.getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
        	
        } catch (Exception e) {
      if (logger.isFinestEnabled()) {
        String infoForLogging="Error: Fatal error while updating record " + e.getMessage();
      logger.finest("populateBeforeImage() " + infoForLogging);
      }
            DWLExceptionUtils.throwDWLBaseException(e, 
            									new DWLUpdateException(e.getMessage()), 
            									this.getStatus(), DWLStatus.FATAL,
                                  DSEAAdditionsExtsComponentID.XGURANTOR_COMPANY_BOBJ, 
                                  "DIERR",
                                  DSEAAdditionsExtsErrorReasonCode.XGURANTORCOMPANY_BEFORE_IMAGE_NOT_POPULATED, 
                                  this.getControl());
        }
        
        comp.loadBeforeImage(this);
    logger.finest("RETURN populateBeforeImage()");
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation common to both add and update transactions.
     *
     * @generated
     */
     
    private DWLStatus getValidationStatus(int level, DWLStatus status) throws Exception {
    logger.finest("ENTER getValidationStatus(int level, DWLStatus status)");

        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0034I Add any common controller-level custom validation
            // logic to be executed for this object during either "add" or
            // "update" transactions
    		controllerValidation_Industry(status);
    		controllerValidation_AddressUsage(status);
    		controllerValidation_Country(status);
    		controllerValidation_SourceIdentifier(status);
    		controllerValidation_StartDate(status);
    		controllerValidation_EndDate(status);
    		controllerValidation_LastModifiedSystemDate(status);
    	}

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            // MDM_TODO0: CDKWB0035I Add any common component-level custom validation logic
            // to be executed for this object during either "add" or "update"
            // transactions
    		componentValidation_Industry(status);
    		componentValidation_AddressUsage(status);
    		componentValidation_Country(status);
    		componentValidation_SourceIdentifier(status);
    		componentValidation_StartDate(status);
    		componentValidation_EndDate(status);
    		componentValidation_LastModifiedSystemDate(status);
        }
        
        if (logger.isFinestEnabled()) {
            String returnValue = status.toString();
      logger.finest("RETURN getValidationStatus(int level, DWLStatus status) " + returnValue);
        }
    
        return status;
    }

    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "Industry"
     *
     * @generated
     */
  private void componentValidation_Industry(DWLStatus status) {
  
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "AddressUsage"
     *
     * @generated
     */
  private void componentValidation_AddressUsage(DWLStatus status) {
  
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "Country"
     *
     * @generated
     */
  private void componentValidation_Country(DWLStatus status) {
  
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "SourceIdentifier"
     *
     * @generated
     */
	private void componentValidation_SourceIdentifier(DWLStatus status) {
  
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "StartDate"
     *
     * @generated
     */
	private void componentValidation_StartDate(DWLStatus status) {
  
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "EndDate"
     *
     * @generated
     */
	private void componentValidation_EndDate(DWLStatus status) {
  
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "LastModifiedSystemDate"
     *
     * @generated
     */
  private void componentValidation_LastModifiedSystemDate(DWLStatus status) {
  
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "Industry"
     *
     * @generated
     */
  private void controllerValidation_Industry(DWLStatus status) throws Exception {
  
      //persistent code type
            boolean isIndustryNull = false;
            if ((eObjXGurantorCompany.getIndustry() == null) &&
               ((getIndustryValue() == null) || 
                 getIndustryValue().trim().equals(""))) {
                isIndustryNull = true;
            }
            if (!isIndustryNull) {
                if (checkForInvalidXgurantorcompanyIndustry()) {
                    DWLError err = new DWLError();
                    err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XGURANTOR_COMPANY_BOBJ).longValue());
                    err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XGURANTORCOMPANY_INDUSTRY).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                    String infoForLogging="Error: Custom validation error occured for entity XGurantorCompany, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("controllerValidation_Industry " + infoForLogging);
        }
                status.addError(err);
            }

             }
    			
    	}


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "AddressUsage"
     *
     * @generated
     */
  private void controllerValidation_AddressUsage(DWLStatus status) throws Exception {
  
      //persistent code type
            boolean isAddressUsageNull = false;
            if ((eObjXGurantorCompany.getAddressUsage() == null) &&
               ((getAddressUsageValue() == null) || 
                 getAddressUsageValue().trim().equals(""))) {
                isAddressUsageNull = true;
            }
            if (!isAddressUsageNull) {
                if (checkForInvalidXgurantorcompanyAddressusage()) {
                    DWLError err = new DWLError();
                    err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XGURANTOR_COMPANY_BOBJ).longValue());
                    err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XGURANTORCOMPANY_ADDRESSUSAGE).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                    String infoForLogging="Error: Custom validation error occured for entity XGurantorCompany, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("controllerValidation_AddressUsage " + infoForLogging);
        }
                status.addError(err);
            }

             }
    			
    	}


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "Country"
     *
     * @generated
     */
  private void controllerValidation_Country(DWLStatus status) throws Exception {
  
      //persistent code type
            boolean isCountryNull = false;
            if ((eObjXGurantorCompany.getCountry() == null) &&
               ((getCountryValue() == null) || 
                 getCountryValue().trim().equals(""))) {
                isCountryNull = true;
            }
            if (!isCountryNull) {
                if (checkForInvalidXgurantorcompanyCountry()) {
                    DWLError err = new DWLError();
                    err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XGURANTOR_COMPANY_BOBJ).longValue());
                    err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XGURANTORCOMPANY_COUNTRY).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                    String infoForLogging="Error: Custom validation error occured for entity XGurantorCompany, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("controllerValidation_Country " + infoForLogging);
        }
                status.addError(err);
            }

             }
    			
    	}


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "SourceIdentifier"
     *
     * @generated
     */
	private void controllerValidation_SourceIdentifier(DWLStatus status) throws Exception {
  
      //persistent code type
            boolean isSourceIdentifierNull = false;
            if ((eObjXGurantorCompany.getSourceIdentifier() == null) &&
               ((getSourceIdentifierValue() == null) || 
                 getSourceIdentifierValue().trim().equals(""))) {
                isSourceIdentifierNull = true;
            }
            if (!isSourceIdentifierNull) {
                if (checkForInvalidXgurantorcompanySourceidentifier()) {
                    DWLError err = new DWLError();
                    err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XGURANTOR_COMPANY_BOBJ).longValue());
                    err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XGURANTORCOMPANY_SOURCEIDENTIFIER).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                    String infoForLogging="Error: Custom validation error occured for entity XGurantorCompany, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("controllerValidation_SourceIdentifier " + infoForLogging);
        }
                status.addError(err);
            }

             }
    			
    	}
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "StartDate"
     *
     * @generated
     */
	private void controllerValidation_StartDate(DWLStatus status) throws Exception {
  
            boolean isStartDateNull = (eObjXGurantorCompany.getStartDate() == null);
            if (!isValidStartDate) {
              	DWLError err = new DWLError();
               	err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XGURANTOR_COMPANY_BOBJ).longValue());
               	err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XGURANTORCOMPANY_STARTDATE).longValue());
               	err.setErrorType(DWLErrorCode.DATA_INVALID_ERROR);
                String infoForLogging="Error: Validation error. Invalid time specified on property StartDate in entity XGurantorCompany, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode();
      logger.finest("controllerValidation_StartDate " + infoForLogging);
               	status.addError(err);
            } 
    	}
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "EndDate"
     *
     * @generated
     */
	private void controllerValidation_EndDate(DWLStatus status) throws Exception {
  
            boolean isEndDateNull = (eObjXGurantorCompany.getEndDate() == null);
            if (!isValidEndDate) {
              	DWLError err = new DWLError();
               	err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XGURANTOR_COMPANY_BOBJ).longValue());
               	err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XGURANTORCOMPANY_ENDDATE).longValue());
               	err.setErrorType(DWLErrorCode.DATA_INVALID_ERROR);
                String infoForLogging="Error: Validation error. Invalid time specified on property EndDate in entity XGurantorCompany, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode();
      logger.finest("controllerValidation_EndDate " + infoForLogging);
               	status.addError(err);
            } 
    	}
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "LastModifiedSystemDate"
     *
     * @generated
     */
  private void controllerValidation_LastModifiedSystemDate(DWLStatus status) throws Exception {
  
            boolean isLastModifiedSystemDateNull = (eObjXGurantorCompany.getLastModifiedSystemDate() == null);
            if (!isValidLastModifiedSystemDate) {
              	DWLError err = new DWLError();
               	err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XGURANTOR_COMPANY_BOBJ).longValue());
               	err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XGURANTORCOMPANY_LASTMODIFIEDSYSTEMDATE).longValue());
               	err.setErrorType(DWLErrorCode.DATA_INVALID_ERROR);
                String infoForLogging="Error: Validation error. Invalid time specified on property LastModifiedSystemDate in entity XGurantorCompany, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode();
      logger.finest("controllerValidation_LastModifiedSystemDate " + infoForLogging);
               	status.addError(err);
            } 
    	}


    private DWLError createDWLError(String entityName, String propertyName,String reasonCode){	
		DWLError err = new DWLError();
		err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XGURANTOR_COMPANY_BOBJ).longValue());
		err.setReasonCode(new Long(reasonCode).longValue());
		err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
			String infoForLogging="Error: Validation error occured. Property " + propertyName + " is null, in entity " + entityName + ", component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
			logger.finest("createDWLError " + infoForLogging);
		}
		return err;
    }
    
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Check the value of the field Industry and return true if the error reason
     * INVALID_XGURANTORCOMPANY_INDUSTRY should be returned.
     *
     * @generated
  **/
  private boolean checkForInvalidXgurantorcompanyIndustry() throws Exception {
    logger.finest("ENTER checkForInvalidXgurantorcompanyIndustry()");
        boolean notValid = false;
      	String langId = (String) this.getControl().get(DWLControlKeys.LANG_ID);
      	CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
    Long codeType = DWLFunctionUtils.getLongFromString( getIndustryType() );
    String codeValue = getIndustryValue();
    if( codeValue != null && codeValue.trim().equals("")){
      codeValue = null;
    }
     
        if ( codeType != null && codeValue == null ){

             if( codeTypeCompHelper.isCodeValid("cdindustrytp", langId, getIndustryType(),
                 CodeTypeComponentHelper.ACTIVE, getControl())) {
                 CodeTypeBObj ctBObj = codeTypeCompHelper
                 					.getCodeTypeByCode("cdindustrytp", langId, getIndustryType(),
                         								getControl());
               	if (ctBObj != null) {
                   	setIndustryValue( ctBObj.getvalue() );
               	}
             }
             else{
             	if (logger.isFinestEnabled()) {
              	 	String infoForLogging="NotValid 1";
      logger.finest("checkForInvalidXgurantorcompanyIndustry() " + infoForLogging);
        }
                 notValid = true;
           }
        }
        else if (codeType == null && codeValue != null ){
          
             CodeTypeBObj ctBObj = codeTypeCompHelper
                      .getCodeTypeByValue("cdindustrytp", langId, codeValue,
                                 getControl());

             if (ctBObj != null) {
                 setIndustryType(ctBObj.gettp_cd());
             } 
             else {
             	if (logger.isFinestEnabled()) {
              	  	String infoForLogging="NotValid 2";
      logger.finest("checkForInvalidXgurantorcompanyIndustry() " + infoForLogging);
        }
                  notValid = true;
             }
        }
        else if ( codeType != null && codeValue != null
             && !codeTypeCompHelper.isCodeValuePairValid("cdindustrytp", langId, getIndustryType(), 
                     new String[] { codeValue }, CodeTypeComponentHelper.ACTIVE, getControl())) {	
       if (logger.isFinestEnabled()) {
       		String infoForLogging="NotValid 3";
      logger.finest("checkForInvalidXgurantorcompanyIndustry() " + infoForLogging);
       }
             notValid = true;
        }
        if (logger.isFinestEnabled()) {
      String returnValue ="" +notValid;
      logger.finest("RETURN checkForInvalidXgurantorcompanyIndustry() " + returnValue);
    }
    return notValid;
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Check the value of the field AddressUsage and return true if the error
     * reason INVALID_XGURANTORCOMPANY_ADDRESSUSAGE should be returned.
     *
     * @generated
  **/
  private boolean checkForInvalidXgurantorcompanyAddressusage() throws Exception {
    logger.finest("ENTER checkForInvalidXgurantorcompanyAddressusage()");
        boolean notValid = false;
      	String langId = (String) this.getControl().get(DWLControlKeys.LANG_ID);
      	CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
    Long codeType = DWLFunctionUtils.getLongFromString( getAddressUsageType() );
    String codeValue = getAddressUsageValue();
    if( codeValue != null && codeValue.trim().equals("")){
      codeValue = null;
    }
     
        if ( codeType != null && codeValue == null ){

             if( codeTypeCompHelper.isCodeValid("cdaddrusagetp", langId, getAddressUsageType(),
                 CodeTypeComponentHelper.ACTIVE, getControl())) {
                 CodeTypeBObj ctBObj = codeTypeCompHelper
                 					.getCodeTypeByCode("cdaddrusagetp", langId, getAddressUsageType(),
                         								getControl());
               	if (ctBObj != null) {
                   	setAddressUsageValue( ctBObj.getvalue() );
               	}
             }
             else{
             	if (logger.isFinestEnabled()) {
              	 	String infoForLogging="NotValid 1";
      logger.finest("checkForInvalidXgurantorcompanyAddressusage() " + infoForLogging);
        }
                 notValid = true;
           }
        }
        else if (codeType == null && codeValue != null ){
          
             CodeTypeBObj ctBObj = codeTypeCompHelper
                      .getCodeTypeByValue("cdaddrusagetp", langId, codeValue,
                                 getControl());

             if (ctBObj != null) {
                 setAddressUsageType(ctBObj.gettp_cd());
             } 
             else {
             	if (logger.isFinestEnabled()) {
              	  	String infoForLogging="NotValid 2";
      logger.finest("checkForInvalidXgurantorcompanyAddressusage() " + infoForLogging);
        }
                  notValid = true;
             }
        }
        else if ( codeType != null && codeValue != null
             && !codeTypeCompHelper.isCodeValuePairValid("cdaddrusagetp", langId, getAddressUsageType(), 
                     new String[] { codeValue }, CodeTypeComponentHelper.ACTIVE, getControl())) {	
       if (logger.isFinestEnabled()) {
       		String infoForLogging="NotValid 3";
      logger.finest("checkForInvalidXgurantorcompanyAddressusage() " + infoForLogging);
       }
             notValid = true;
        }
        if (logger.isFinestEnabled()) {
      String returnValue ="" +notValid;
      logger.finest("RETURN checkForInvalidXgurantorcompanyAddressusage() " + returnValue);
    }
    return notValid;
     }


  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Check the value of the field Country and return true if the error reason
     * INVALID_XGURANTORCOMPANY_COUNTRY should be returned.
     *
     * @generated
  **/
  private boolean checkForInvalidXgurantorcompanyCountry() throws Exception {
    logger.finest("ENTER checkForInvalidXgurantorcompanyCountry()");
        boolean notValid = false;
      	String langId = (String) this.getControl().get(DWLControlKeys.LANG_ID);
      	CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
    Long codeType = DWLFunctionUtils.getLongFromString( getCountryType() );
    String codeValue = getCountryValue();
    if( codeValue != null && codeValue.trim().equals("")){
      codeValue = null;
    }
     
        if ( codeType != null && codeValue == null ){

             if( codeTypeCompHelper.isCodeValid("cdcountrytp", langId, getCountryType(),
                 CodeTypeComponentHelper.ACTIVE, getControl())) {
                 CodeTypeBObj ctBObj = codeTypeCompHelper
                 					.getCodeTypeByCode("cdcountrytp", langId, getCountryType(),
                         								getControl());
               	if (ctBObj != null) {
                   	setCountryValue( ctBObj.getvalue() );
               	}
             }
             else{
             	if (logger.isFinestEnabled()) {
              	 	String infoForLogging="NotValid 1";
      logger.finest("checkForInvalidXgurantorcompanyCountry() " + infoForLogging);
        }
                 notValid = true;
           }
        }
        else if (codeType == null && codeValue != null ){
          
             CodeTypeBObj ctBObj = codeTypeCompHelper
                      .getCodeTypeByValue("cdcountrytp", langId, codeValue,
                                 getControl());

             if (ctBObj != null) {
                 setCountryType(ctBObj.gettp_cd());
             } 
             else {
             	if (logger.isFinestEnabled()) {
              	  	String infoForLogging="NotValid 2";
      logger.finest("checkForInvalidXgurantorcompanyCountry() " + infoForLogging);
        }
                  notValid = true;
             }
        }
        else if ( codeType != null && codeValue != null
             && !codeTypeCompHelper.isCodeValuePairValid("cdcountrytp", langId, getCountryType(), 
                     new String[] { codeValue }, CodeTypeComponentHelper.ACTIVE, getControl())) {	
       if (logger.isFinestEnabled()) {
       		String infoForLogging="NotValid 3";
      logger.finest("checkForInvalidXgurantorcompanyCountry() " + infoForLogging);
       }
             notValid = true;
        }
        if (logger.isFinestEnabled()) {
      String returnValue ="" +notValid;
      logger.finest("RETURN checkForInvalidXgurantorcompanyCountry() " + returnValue);
    }
    return notValid;
     }


  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Check the value of the field SourceIdentifier and return true if the
     * error reason INVALID_XGURANTORCOMPANY_SOURCEIDENTIFIER should be
     * returned.
     *
     * @generated
  **/
	private boolean checkForInvalidXgurantorcompanySourceidentifier() throws Exception {
    logger.finest("ENTER checkForInvalidXgurantorcompanySourceidentifier()");
        boolean notValid = false;
      	String langId = (String) this.getControl().get(DWLControlKeys.LANG_ID);
      	CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
    Long codeType = DWLFunctionUtils.getLongFromString( getSourceIdentifierType() );
    String codeValue = getSourceIdentifierValue();
    if( codeValue != null && codeValue.trim().equals("")){
      codeValue = null;
    }
     
        if ( codeType != null && codeValue == null ){

             if( codeTypeCompHelper.isCodeValid("cdsourceidenttp", langId, getSourceIdentifierType(),
                 CodeTypeComponentHelper.ACTIVE, getControl())) {
                 CodeTypeBObj ctBObj = codeTypeCompHelper
                 					.getCodeTypeByCode("cdsourceidenttp", langId, getSourceIdentifierType(),
                         								getControl());
               	if (ctBObj != null) {
                   	setSourceIdentifierValue( ctBObj.getvalue() );
               	}
             }
             else{
             	if (logger.isFinestEnabled()) {
              	 	String infoForLogging="NotValid 1";
      logger.finest("checkForInvalidXgurantorcompanySourceidentifier() " + infoForLogging);
        }
                 notValid = true;
           }
        }
        else if (codeType == null && codeValue != null ){
          
             CodeTypeBObj ctBObj = codeTypeCompHelper
                      .getCodeTypeByValue("cdsourceidenttp", langId, codeValue,
                                 getControl());

             if (ctBObj != null) {
                 setSourceIdentifierType(ctBObj.gettp_cd());
             } 
             else {
             	if (logger.isFinestEnabled()) {
              	  	String infoForLogging="NotValid 2";
      logger.finest("checkForInvalidXgurantorcompanySourceidentifier() " + infoForLogging);
        }
                  notValid = true;
             }
        }
        else if ( codeType != null && codeValue != null
             && !codeTypeCompHelper.isCodeValuePairValid("cdsourceidenttp", langId, getSourceIdentifierType(), 
                     new String[] { codeValue }, CodeTypeComponentHelper.ACTIVE, getControl())) {	
       if (logger.isFinestEnabled()) {
       		String infoForLogging="NotValid 3";
      logger.finest("checkForInvalidXgurantorcompanySourceidentifier() " + infoForLogging);
       }
             notValid = true;
        }
        if (logger.isFinestEnabled()) {
      String returnValue ="" +notValid;
      logger.finest("RETURN checkForInvalidXgurantorcompanySourceidentifier() " + returnValue);
    }
    return notValid;
     } 
				 



}

