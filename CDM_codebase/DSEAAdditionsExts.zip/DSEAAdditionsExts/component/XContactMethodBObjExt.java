
/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[e4a5e20b6ebed8ebcf0dd3377b125c06]
 */

package com.ibm.daimler.dsea.component;

import com.dwl.base.util.DWLClassFactory;
import com.dwl.tcrm.exception.TCRMReadException;



import com.dwl.base.DWLControl;
import com.dwl.base.IDWLErrorMessage;

import com.dwl.base.error.DWLError;
import com.dwl.base.error.DWLErrorCode;
import com.dwl.base.error.DWLStatus;

import com.dwl.base.exception.DWLBaseException;

import com.dwl.base.util.DWLExceptionUtils;
import com.dwl.base.util.DWLFunctionUtils;

import com.dwl.tcrm.common.IExtension;
import com.dwl.tcrm.common.ITCRMValidation;
import com.dwl.tcrm.common.TCRMErrorCode;

import com.dwl.tcrm.coreParty.component.TCRMContactMethodBObj;

import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsComponentID;
import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsErrorReasonCode;

import com.ibm.daimler.dsea.entityObject.EObjXContactMethodExt;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * This class provides the implementation of the business object
 * <code>XContactMethodBObjExt</code>.
 * 
 * @see com.dwl.tcrm.common.TCRMCommon
 * @generated
 */
 

@SuppressWarnings("serial")
public class XContactMethodBObjExt extends TCRMContactMethodBObj implements IExtension {

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected EObjXContactMethodExt eObjXContactMethodExt;
	/**
    * <!-- begin-user-doc -->
	  * <!-- end-user-doc -->
    * @generated 
    */
	 private final static com.dwl.base.logging.IDWLLogger logger = com.dwl.base.logging.DWLLoggerManager.getLogger(XContactMethodBObjExt.class);
		
 


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */     
    public XContactMethodBObjExt() {
        super();
        init();
        eObjXContactMethodExt = new EObjXContactMethodExt(getEObjContactMethod());
        setComponentID(DSEAAdditionsExtsComponentID.XCONTACT_METHOD_BOBJ_EXT);
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Initializes the fields required to populate the metaDataMap. Each key is
     * an element-level field of the business object.
     *
     * @generated
     */
    private void init() {
        metaDataMap.put("PhoneExtension", null);
        metaDataMap.put("XContactMethodHistActionCode", null);
        metaDataMap.put("XContactMethodHistCreateDate", null);
        metaDataMap.put("XContactMethodHistCreatedBy", null);
        metaDataMap.put("XContactMethodHistEndDate", null);
        metaDataMap.put("XContactMethodHistoryIdPK", null);
        metaDataMap.put("XContactMethodLastUpdateDate", null);
        metaDataMap.put("XContactMethodLastUpdateTxId", null);
        metaDataMap.put("XContactMethodLastUpdateUser", null);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Refreshes all the attributes this business object supports.
     *
     * @see com.dwl.base.DWLCommon#refreshMap()
     * @generated
     */
    public void refreshMap() {

        if (bRequireMapRefresh) {
            super.refreshMap();
            metaDataMap.put("PhoneExtension", getPhoneExtension());
            metaDataMap.put("XContactMethodHistActionCode", getXContactMethodHistActionCode());
            metaDataMap.put("XContactMethodHistCreateDate", getXContactMethodHistCreateDate());
            metaDataMap.put("XContactMethodHistCreatedBy", getXContactMethodHistCreatedBy());
            metaDataMap.put("XContactMethodHistEndDate", getXContactMethodHistEndDate());
            metaDataMap.put("XContactMethodHistoryIdPK", getXContactMethodHistoryIdPK());
            metaDataMap.put("XContactMethodLastUpdateDate", getXContactMethodLastUpdateDate());
            metaDataMap.put("XContactMethodLastUpdateTxId", getXContactMethodLastUpdateTxId());
            metaDataMap.put("XContactMethodLastUpdateUser", getXContactMethodLastUpdateUser());
            bRequireMapRefresh = false;
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the control object on this business object.
     *
     * @see com.dwl.base.DWLCommon#setControl(DWLControl)
     * @generated
     */
    public void setControl(DWLControl newDWLControl) {
        super.setControl(newDWLControl);

        if (eObjXContactMethodExt != null) {
            eObjXContactMethodExt.setControl(newDWLControl);
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the entity object associated with this business object.
     *
     * @generated
     */
    public EObjXContactMethodExt getEObjXContactMethodExt() {
        bRequireMapRefresh = true;
        return eObjXContactMethodExt;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the entity object associated with this business object.
     *
     * @param eObjXContactMethodExt
     *            The eObjXContactMethodExt to set.
     * @generated
     */
    public void setEObjXContactMethodExt(EObjXContactMethodExt eObjXContactMethodExt) {
        bRequireMapRefresh = true;
        this.eObjXContactMethodExt = eObjXContactMethodExt;
        this.eObjXContactMethodExt.setBaseEntity(getEObjContactMethod());
        if (this.eObjXContactMethodExt != null && this.eObjXContactMethodExt.getControl() == null) {
            DWLControl control = this.getControl();
            if (control != null) {
                this.eObjXContactMethodExt.setControl(control);
            }
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the phoneExtension attribute.
     * 
     * @generated
     */
    public String getPhoneExtension (){
   
        return eObjXContactMethodExt.getPhoneExtension();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the phoneExtension attribute.
     * 
     * @param newPhoneExtension
     *     The new value of phoneExtension.
     * @generated
     */
    public void setPhoneExtension( String newPhoneExtension ) throws Exception {
        metaDataMap.put("PhoneExtension", newPhoneExtension);

        if (newPhoneExtension == null || newPhoneExtension.equals("")) {
            newPhoneExtension = null;


        }
        eObjXContactMethodExt.setPhoneExtension( newPhoneExtension );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateTxId attribute.
     *
     * @generated
     */
    public String getXContactMethodLastUpdateTxId() {
        return DWLFunctionUtils.getStringFromLong(eObjXContactMethodExt.getLastUpdateTxId());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateUser attribute.
     *
     * @generated
     */
    public String getXContactMethodLastUpdateUser() {
        return eObjXContactMethodExt.getLastUpdateUser();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateDt attribute.
     *
     * @generated
     */
    public String getXContactMethodLastUpdateDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXContactMethodExt.getLastUpdateDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateTxId attribute.
     *
     * @param newLastUpdateTxId
     *     The new value of LastUpdateTxId.
     * @generated
     */
    public void setXContactMethodLastUpdateTxId(String newLastUpdateTxId) {
        metaDataMap.put("XContactMethodLastUpdateTxId", newLastUpdateTxId);

        if ((newLastUpdateTxId == null) || newLastUpdateTxId.equals("")) {
            newLastUpdateTxId = null;
        }
        eObjXContactMethodExt.setLastUpdateTxId(DWLFunctionUtils.getLongFromString(newLastUpdateTxId));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateUser attribute.
     *
     * @param newLastUpdateUser
     *     The new value of LastUpdateUser.
     * @generated
     */
    public void setXContactMethodLastUpdateUser(String newLastUpdateUser) {
        metaDataMap.put("XContactMethodLastUpdateUser", newLastUpdateUser);

        if ((newLastUpdateUser == null) || newLastUpdateUser.equals("")) {
            newLastUpdateUser = null;
        }
        eObjXContactMethodExt.setLastUpdateUser(newLastUpdateUser);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateDt attribute.
     *
     * @param newLastUpdateDt
     *     The new value of LastUpdateDt.
     * @throws Exception
     * @generated
     */
    public void setXContactMethodLastUpdateDate(String newLastUpdateDt) throws Exception {
        metaDataMap.put("XContactMethodLastUpdateDate", newLastUpdateDt);

        if ((newLastUpdateDt == null) || newLastUpdateDt.equals("")) {
            newLastUpdateDt = null;
        }

        eObjXContactMethodExt.setLastUpdateDt(DWLFunctionUtils.getTimestampFromTimestampString(newLastUpdateDt));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XContactMethodHistActionCode history attribute.
     *
     * @generated
     */
    public String getXContactMethodHistActionCode() {
        return eObjXContactMethodExt.getHistActionCode();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XContactMethodHistActionCode history attribute.
     *
     * @param aXContactMethodHistActionCode
     *     The new value of XContactMethodHistActionCode.
     * @generated
     */
    public void setXContactMethodHistActionCode(String aXContactMethodHistActionCode) {
        metaDataMap.put("XContactMethodHistActionCode", aXContactMethodHistActionCode);

        if ((aXContactMethodHistActionCode == null) || aXContactMethodHistActionCode.equals("")) {
            aXContactMethodHistActionCode = null;
        }
        eObjXContactMethodExt.setHistActionCode(aXContactMethodHistActionCode);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XContactMethodHistCreateDate history attribute.
     *
     * @generated
     */
    public String getXContactMethodHistCreateDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXContactMethodExt.getHistCreateDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XContactMethodHistCreateDate history attribute.
     *
     * @param aXContactMethodHistCreateDate
     *     The new value of XContactMethodHistCreateDate.
     * @generated
     */
    public void setXContactMethodHistCreateDate(String aXContactMethodHistCreateDate) throws Exception{
        metaDataMap.put("XContactMethodHistCreateDate", aXContactMethodHistCreateDate);

        if ((aXContactMethodHistCreateDate == null) || aXContactMethodHistCreateDate.equals("")) {
            aXContactMethodHistCreateDate = null;
        }

        eObjXContactMethodExt.setHistCreateDt(DWLFunctionUtils.getTimestampFromTimestampString(aXContactMethodHistCreateDate));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XContactMethodHistCreatedBy history attribute.
     *
     * @generated
     */
    public String getXContactMethodHistCreatedBy() {
        return eObjXContactMethodExt.getHistCreatedBy();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XContactMethodHistCreatedBy history attribute.
     *
     * @param aXContactMethodHistCreatedBy
     *     The new value of XContactMethodHistCreatedBy.
     * @generated
     */
    public void setXContactMethodHistCreatedBy(String aXContactMethodHistCreatedBy) {
        metaDataMap.put("XContactMethodHistCreatedBy", aXContactMethodHistCreatedBy);

        if ((aXContactMethodHistCreatedBy == null) || aXContactMethodHistCreatedBy.equals("")) {
            aXContactMethodHistCreatedBy = null;
        }

        eObjXContactMethodExt.setHistCreatedBy(aXContactMethodHistCreatedBy);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XContactMethodHistEndDate history attribute.
     *
     * @generated
     */
    public String getXContactMethodHistEndDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXContactMethodExt.getHistEndDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XContactMethodHistEndDate history attribute.
     *
     * @param aXContactMethodHistEndDate
     *     The new value of XContactMethodHistEndDate.
     * @generated
     */
    public void setXContactMethodHistEndDate(String aXContactMethodHistEndDate) throws Exception{
        metaDataMap.put("XContactMethodHistEndDate", aXContactMethodHistEndDate);

        if ((aXContactMethodHistEndDate == null) || aXContactMethodHistEndDate.equals("")) {
            aXContactMethodHistEndDate = null;
        }
        eObjXContactMethodExt.setHistEndDt(DWLFunctionUtils.getTimestampFromTimestampString(aXContactMethodHistEndDate));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XContactMethodHistoryIdPK history attribute.
     *
     * @generated
     */
    public String getXContactMethodHistoryIdPK() {
        return DWLFunctionUtils.getStringFromLong(eObjXContactMethodExt.getHistoryIdPK());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XContactMethodHistoryIdPK history attribute.
     *
     * @param aXContactMethodHistoryIdPK
     *     The new value of XContactMethodHistoryIdPK.
     * @generated
     */
    public void setXContactMethodHistoryIdPK(String aXContactMethodHistoryIdPK) {
        metaDataMap.put("XContactMethodHistoryIdPK", aXContactMethodHistoryIdPK);

        if ((aXContactMethodHistoryIdPK == null) || aXContactMethodHistoryIdPK.equals("")) {
            aXContactMethodHistoryIdPK = null;
        }
        eObjXContactMethodExt.setHistoryIdPK(DWLFunctionUtils.getLongFromString(aXContactMethodHistoryIdPK));
    }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation during an add transaction.
     *
     * @generated
     */
    public DWLStatus validateAdd(int level, DWLStatus status) throws Exception {

        status = super.validateAdd(level, status);
        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0038I Add any controller-level custom validation logic to be
            // executed for this object during an "add" transaction

        }

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            // MDM_TODO0: CDKWB0039I Add any component-level custom validation logic to be
            // executed for this object during an "add" transaction
        }
        status = getValidationStatus(level, status);
        return status;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation during an update transaction.
     *
     * @generated
     */
    public DWLStatus validateUpdate(int level, DWLStatus status) throws Exception {
    logger.finest("ENTER validateUpdate(int level, DWLStatus status)");

        status = super.validateUpdate(level, status);
        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0040I Add any controller-level custom validation logic to be
            // executed for this object during an "update" transaction

        }

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            assignBeforeImageValues(metaDataMap);
            
            // MDM_TODO0: CDKWB0041I Add any component-level custom validation logic to be
            // executed for this object during an "update" transaction
        }
        status = getValidationStatus(level, status);
    if (logger.isFinestEnabled()) {
        	String returnValue = status.toString();
      logger.finest("RETURN validateUpdate(int level, DWLStatus status) " + returnValue);
    }
        return status;
    }



    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation common to both add and update transactions.
     *
     * @generated
     */
     
    private DWLStatus getValidationStatus(int level, DWLStatus status) throws Exception {
    logger.finest("ENTER getValidationStatus(int level, DWLStatus status)");

        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0034I Add any common controller-level custom validation
            // logic to be executed for this object during either "add" or
            // "update" transactions
    	}

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            // MDM_TODO0: CDKWB0035I Add any common component-level custom validation logic
            // to be executed for this object during either "add" or "update"
            // transactions
        }
        
        if (logger.isFinestEnabled()) {
            String returnValue = status.toString();
      logger.finest("RETURN getValidationStatus(int level, DWLStatus status) " + returnValue);
        }
    
        return status;
    }

    private DWLError createDWLError(String entityName, String propertyName,String reasonCode){	
		DWLError err = new DWLError();
		err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCONTACT_METHOD_BOBJ_EXT).longValue());
		err.setReasonCode(new Long(reasonCode).longValue());
		err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
			String infoForLogging="Error: Validation error occured. Property " + propertyName + " is null, in entity " + entityName + ", component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
			logger.finest("createDWLError " + infoForLogging);
		}
		return err;
    }
    






	 /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets a record from the extension table.
     *
     * @throws DWLBaseException
     * @generated
     */
    public void getRecord() throws DWLBaseException {
    logger.finest("ENTER getRecord()");
    
    try {
         			
         }
         catch (Exception e) {
            DWLExceptionUtils.log(e);
            
            if (logger.isFinestEnabled()) {
        		String infoForLogging="Error: Error reading record " + e.getMessage(); 
      logger.finest("getRecord() " + infoForLogging);
      }
            status = new DWLStatus();

            TCRMReadException readEx = new TCRMReadException();
            IDWLErrorMessage  errHandler = DWLClassFactory.getErrorHandler();
            DWLError          error = errHandler.getErrorMessage(DSEAAdditionsExtsComponentID.XCONTACT_METHOD_BOBJ_EXT,
                                                                 TCRMErrorCode.READ_RECORD_ERROR,
                                                                 DSEAAdditionsExtsErrorReasonCode.READ_EXTENSION_XCONTACTMETHOD_FAILED,
                                                                 getControl(), new String[0]);
            error.setThrowable(e);
            status.addError(error);
            status.setStatus(DWLStatus.FATAL);
            readEx.setStatus(status);
            throw readEx;
        }	    		
    logger.finest("RETURN getRecord()");
  }


}

