
/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[33f2ee203d253a207d9af75df4b2efee]
 */

package com.ibm.daimler.dsea.component;

import com.dwl.tcrm.common.TCRMCommon;



import com.dwl.base.DWLControl;

import com.dwl.base.constant.DWLControlKeys;
import com.dwl.base.constant.DWLUtilErrorReasonCode;

import com.dwl.base.error.DWLError;
import com.dwl.base.error.DWLErrorCode;
import com.dwl.base.error.DWLStatus;

import com.dwl.base.exception.DWLBaseException;
import com.dwl.base.exception.DWLUpdateException;

import com.dwl.base.util.DWLClassFactory;
import com.dwl.base.util.DWLExceptionUtils;
import com.dwl.base.util.DWLFunctionUtils;

import com.dwl.management.config.client.Configuration;

import com.dwl.tcrm.common.ITCRMValidation;

import com.dwl.tcrm.utilities.DateFormatter;
import com.dwl.tcrm.utilities.DateValidator;
import com.dwl.tcrm.utilities.TCRMClassFactory;

import com.ibm.daimler.dsea.component.XRetailerBObj;
import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsComponentID;
import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsErrorReasonCode;
import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsPropertyKeys;

import com.ibm.daimler.dsea.entityObject.EObjXCustomerRetailerJPN;

import com.ibm.daimler.dsea.interfaces.DSEAAdditionsExts;

import com.ibm.mdm.common.codetype.interfaces.CodeTypeComponentHelper;

import com.ibm.mdm.common.codetype.obj.CodeTypeBObj;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * This class provides the implementation of the business object
 * <code>XCustomerRetailerJPNBObj</code>.
 * 
 * @see com.dwl.tcrm.common.TCRMCommon
 * @generated
 */
 

@SuppressWarnings("serial")
public class XCustomerRetailerJPNBObj extends TCRMCommon  {

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected EObjXCustomerRetailerJPN eObjXCustomerRetailerJPN;
	/**
    * <!-- begin-user-doc -->
	  * <!-- end-user-doc -->
    * @generated 
    */
	 private final static com.dwl.base.logging.IDWLLogger logger = com.dwl.base.logging.DWLLoggerManager.getLogger(XCustomerRetailerJPNBObj.class);
		
 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected String sourceIdentifierValue;
	protected boolean isValidStartDate = true;
	
	protected boolean isValidEndDate = true;
	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected XRetailerBObj XRetailerBObj;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */     
    public XCustomerRetailerJPNBObj() {
        super();
        init();
        eObjXCustomerRetailerJPN = new EObjXCustomerRetailerJPN();
        setComponentID(DSEAAdditionsExtsComponentID.XCUSTOMER_RETAILER_JPNBOBJ);
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Initializes the fields required to populate the metaDataMap. Each key is
     * an element-level field of the business object.
     *
     * @generated
     */
    private void init() {
        metaDataMap.put("XCustomerRetailerJPNpkId", null);
        metaDataMap.put("ContId", null);
        metaDataMap.put("RetailerId", null);
        metaDataMap.put("SourceIdentifierType", null);
        metaDataMap.put("SourceIdentifierValue", null);
        metaDataMap.put("StartDate", null);
        metaDataMap.put("EndDate", null);
        metaDataMap.put("DeleteFlag", null);
        metaDataMap.put("XCustomerRetailerJPNHistActionCode", null);
        metaDataMap.put("XCustomerRetailerJPNHistCreateDate", null);
        metaDataMap.put("XCustomerRetailerJPNHistCreatedBy", null);
        metaDataMap.put("XCustomerRetailerJPNHistEndDate", null);
        metaDataMap.put("XCustomerRetailerJPNHistoryIdPK", null);
        metaDataMap.put("XCustomerRetailerJPNLastUpdateDate", null);
        metaDataMap.put("XCustomerRetailerJPNLastUpdateTxId", null);
        metaDataMap.put("XCustomerRetailerJPNLastUpdateUser", null);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Refreshes all the attributes this business object supports.
     *
     * @see com.dwl.base.DWLCommon#refreshMap()
     * @generated
     */
    public void refreshMap() {

        if (bRequireMapRefresh) {
            super.refreshMap();
            metaDataMap.put("XCustomerRetailerJPNpkId", getXCustomerRetailerJPNpkId());
            metaDataMap.put("ContId", getContId());
            metaDataMap.put("RetailerId", getRetailerId());
            metaDataMap.put("SourceIdentifierType", getSourceIdentifierType());
            metaDataMap.put("SourceIdentifierValue", getSourceIdentifierValue());
            metaDataMap.put("StartDate", getStartDate());
            metaDataMap.put("EndDate", getEndDate());
            metaDataMap.put("DeleteFlag", getDeleteFlag());
            metaDataMap.put("XCustomerRetailerJPNHistActionCode", getXCustomerRetailerJPNHistActionCode());
            metaDataMap.put("XCustomerRetailerJPNHistCreateDate", getXCustomerRetailerJPNHistCreateDate());
            metaDataMap.put("XCustomerRetailerJPNHistCreatedBy", getXCustomerRetailerJPNHistCreatedBy());
            metaDataMap.put("XCustomerRetailerJPNHistEndDate", getXCustomerRetailerJPNHistEndDate());
            metaDataMap.put("XCustomerRetailerJPNHistoryIdPK", getXCustomerRetailerJPNHistoryIdPK());
            metaDataMap.put("XCustomerRetailerJPNLastUpdateDate", getXCustomerRetailerJPNLastUpdateDate());
            metaDataMap.put("XCustomerRetailerJPNLastUpdateTxId", getXCustomerRetailerJPNLastUpdateTxId());
            metaDataMap.put("XCustomerRetailerJPNLastUpdateUser", getXCustomerRetailerJPNLastUpdateUser());
            bRequireMapRefresh = false;
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the control object on this business object.
     *
     * @see com.dwl.base.DWLCommon#setControl(DWLControl)
     * @generated
     */
    public void setControl(DWLControl newDWLControl) {
        super.setControl(newDWLControl);

        if (eObjXCustomerRetailerJPN != null) {
            eObjXCustomerRetailerJPN.setControl(newDWLControl);
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the entity object associated with this business object.
     *
     * @generated
     */
    public EObjXCustomerRetailerJPN getEObjXCustomerRetailerJPN() {
        bRequireMapRefresh = true;
        return eObjXCustomerRetailerJPN;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the entity object associated with this business object.
     *
     * @param eObjXCustomerRetailerJPN
     *            The eObjXCustomerRetailerJPN to set.
     * @generated
     */
    public void setEObjXCustomerRetailerJPN(EObjXCustomerRetailerJPN eObjXCustomerRetailerJPN) {
        bRequireMapRefresh = true;
        this.eObjXCustomerRetailerJPN = eObjXCustomerRetailerJPN;
        if (this.eObjXCustomerRetailerJPN != null && this.eObjXCustomerRetailerJPN.getControl() == null) {
            DWLControl control = this.getControl();
            if (control != null) {
                this.eObjXCustomerRetailerJPN.setControl(control);
            }
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xCustomerRetailerJPNpkId attribute.
     * 
     * @generated
     */
    public String getXCustomerRetailerJPNpkId (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXCustomerRetailerJPN.getXCustomerRetailerJPNpkId());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xCustomerRetailerJPNpkId attribute.
     * 
     * @param newXCustomerRetailerJPNpkId
     *     The new value of xCustomerRetailerJPNpkId.
     * @generated
     */
    public void setXCustomerRetailerJPNpkId( String newXCustomerRetailerJPNpkId ) throws Exception {
        metaDataMap.put("XCustomerRetailerJPNpkId", newXCustomerRetailerJPNpkId);

        if (newXCustomerRetailerJPNpkId == null || newXCustomerRetailerJPNpkId.equals("")) {
            newXCustomerRetailerJPNpkId = null;


        }
        eObjXCustomerRetailerJPN.setXCustomerRetailerJPNpkId( DWLFunctionUtils.getLongFromString(newXCustomerRetailerJPNpkId) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the contId attribute.
     * 
     * @generated
     */
    public String getContId (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXCustomerRetailerJPN.getContId());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the contId attribute.
     * 
     * @param newContId
     *     The new value of contId.
     * @generated
     */
    public void setContId( String newContId ) throws Exception {
        metaDataMap.put("ContId", newContId);

        if (newContId == null || newContId.equals("")) {
            newContId = null;


        }
        eObjXCustomerRetailerJPN.setContId( DWLFunctionUtils.getLongFromString(newContId) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the retailerId attribute.
     * 
     * @generated
     */
    public String getRetailerId (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXCustomerRetailerJPN.getRetailerId());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the retailerId attribute.
     * 
     * @param newRetailerId
     *     The new value of retailerId.
     * @generated
     */
    public void setRetailerId( String newRetailerId ) throws Exception {
        metaDataMap.put("RetailerId", newRetailerId);

        if (newRetailerId == null || newRetailerId.equals("")) {
            newRetailerId = null;


        }
        eObjXCustomerRetailerJPN.setRetailerId( DWLFunctionUtils.getLongFromString(newRetailerId) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the sourceIdentifierType attribute.
     * 
     * @generated
     */
    public String getSourceIdentifierType (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXCustomerRetailerJPN.getSourceIdentifier());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the sourceIdentifierType attribute.
     * 
     * @param newSourceIdentifierType
     *     The new value of sourceIdentifierType.
     * @generated
     */
    public void setSourceIdentifierType( String newSourceIdentifierType ) throws Exception {
        metaDataMap.put("SourceIdentifierType", newSourceIdentifierType);

        if (newSourceIdentifierType == null || newSourceIdentifierType.equals("")) {
            newSourceIdentifierType = null;


        }
        eObjXCustomerRetailerJPN.setSourceIdentifier( DWLFunctionUtils.getLongFromString(newSourceIdentifierType) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the sourceIdentifierValue attribute.
     * 
     * @generated
     */
    public String getSourceIdentifierValue (){
      return sourceIdentifierValue;
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the sourceIdentifierValue attribute.
     * 
     * @param newSourceIdentifierValue
     *     The new value of sourceIdentifierValue.
     * @generated
     */
    public void setSourceIdentifierValue( String newSourceIdentifierValue ) throws Exception {
        metaDataMap.put("SourceIdentifierValue", newSourceIdentifierValue);

        if (newSourceIdentifierValue == null || newSourceIdentifierValue.equals("")) {
            newSourceIdentifierValue = null;


        }
        sourceIdentifierValue = newSourceIdentifierValue;
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the startDate attribute.
     * 
     * @generated
     */
    public String getStartDate (){
   
        return DWLFunctionUtils.getStringFromTimestamp(eObjXCustomerRetailerJPN.getStartDate());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the startDate attribute.
     * 
     * @param newStartDate
     *     The new value of startDate.
     * @generated
     */
    public void setStartDate( String newStartDate ) throws Exception {
        metaDataMap.put("StartDate", newStartDate);
       	isValidStartDate = true;

        if (newStartDate == null || newStartDate.equals("")) {
            newStartDate = null;
            eObjXCustomerRetailerJPN.setStartDate(null);


        }
    else {
        	if (DateValidator.validates(newStartDate)) {
           		eObjXCustomerRetailerJPN.setStartDate(DateFormatter.getStartDateTimestamp(newStartDate));
            	metaDataMap.put("StartDate", getStartDate());
        	} else {
            	if (Configuration.getConfiguration().getConfigItem(
              "/IBM/DWLCommonServices/InternalValidation/enabled").getBooleanValue()) {
                	if (metaDataMap.get("StartDate") != null) {
                    	metaDataMap.put("StartDate", "");
                	}
                	isValidStartDate = false;
                	eObjXCustomerRetailerJPN.setStartDate(null);
            	}
        	}
        }
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the endDate attribute.
     * 
     * @generated
     */
    public String getEndDate (){
   
        return DWLFunctionUtils.getStringFromTimestamp(eObjXCustomerRetailerJPN.getEndDate());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the endDate attribute.
     * 
     * @param newEndDate
     *     The new value of endDate.
     * @generated
     */
    public void setEndDate( String newEndDate ) throws Exception {
        metaDataMap.put("EndDate", newEndDate);
       	isValidEndDate = true;

        if (newEndDate == null || newEndDate.equals("")) {
            newEndDate = null;
            eObjXCustomerRetailerJPN.setEndDate(null);


        }
    else {
        	if (DateValidator.validates(newEndDate)) {
           		eObjXCustomerRetailerJPN.setEndDate(DateFormatter.getStartDateTimestamp(newEndDate));
            	metaDataMap.put("EndDate", getEndDate());
        	} else {
            	if (Configuration.getConfiguration().getConfigItem(
              "/IBM/DWLCommonServices/InternalValidation/enabled").getBooleanValue()) {
                	if (metaDataMap.get("EndDate") != null) {
                    	metaDataMap.put("EndDate", "");
                	}
                	isValidEndDate = false;
                	eObjXCustomerRetailerJPN.setEndDate(null);
            	}
        	}
        }
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the deleteFlag attribute.
     * 
     * @generated
     */
    public String getDeleteFlag (){
   
        return eObjXCustomerRetailerJPN.getDeleteFlag();
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the deleteFlag attribute.
     * 
     * @param newDeleteFlag
     *     The new value of deleteFlag.
     * @generated
     */
    public void setDeleteFlag( String newDeleteFlag ) throws Exception {
        metaDataMap.put("DeleteFlag", newDeleteFlag);

        if (newDeleteFlag == null || newDeleteFlag.equals("")) {
            newDeleteFlag = null;


        }
        eObjXCustomerRetailerJPN.setDeleteFlag( newDeleteFlag );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XRetailerBObj attribute.
     * 
     * @generated
     */
    public XRetailerBObj getXRetailerBObj (){
      return XRetailerBObj;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public void setXRetailerBObj(XRetailerBObj newBObj ) {
    XRetailerBObj = newBObj;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateTxId attribute.
     *
     * @generated
     */
    public String getXCustomerRetailerJPNLastUpdateTxId() {
        return DWLFunctionUtils.getStringFromLong(eObjXCustomerRetailerJPN.getLastUpdateTxId());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateUser attribute.
     *
     * @generated
     */
    public String getXCustomerRetailerJPNLastUpdateUser() {
        return eObjXCustomerRetailerJPN.getLastUpdateUser();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateDt attribute.
     *
     * @generated
     */
    public String getXCustomerRetailerJPNLastUpdateDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXCustomerRetailerJPN.getLastUpdateDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateTxId attribute.
     *
     * @param newLastUpdateTxId
     *     The new value of LastUpdateTxId.
     * @generated
     */
    public void setXCustomerRetailerJPNLastUpdateTxId(String newLastUpdateTxId) {
        metaDataMap.put("XCustomerRetailerJPNLastUpdateTxId", newLastUpdateTxId);

        if ((newLastUpdateTxId == null) || newLastUpdateTxId.equals("")) {
            newLastUpdateTxId = null;
        }
        eObjXCustomerRetailerJPN.setLastUpdateTxId(DWLFunctionUtils.getLongFromString(newLastUpdateTxId));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateUser attribute.
     *
     * @param newLastUpdateUser
     *     The new value of LastUpdateUser.
     * @generated
     */
    public void setXCustomerRetailerJPNLastUpdateUser(String newLastUpdateUser) {
        metaDataMap.put("XCustomerRetailerJPNLastUpdateUser", newLastUpdateUser);

        if ((newLastUpdateUser == null) || newLastUpdateUser.equals("")) {
            newLastUpdateUser = null;
        }
        eObjXCustomerRetailerJPN.setLastUpdateUser(newLastUpdateUser);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateDt attribute.
     *
     * @param newLastUpdateDt
     *     The new value of LastUpdateDt.
     * @throws Exception
     * @generated
     */
    public void setXCustomerRetailerJPNLastUpdateDate(String newLastUpdateDt) throws Exception {
        metaDataMap.put("XCustomerRetailerJPNLastUpdateDate", newLastUpdateDt);

        if ((newLastUpdateDt == null) || newLastUpdateDt.equals("")) {
            newLastUpdateDt = null;
        }

        eObjXCustomerRetailerJPN.setLastUpdateDt(DWLFunctionUtils.getTimestampFromTimestampString(newLastUpdateDt));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XCustomerRetailerJPNHistActionCode history attribute.
     *
     * @generated
     */
    public String getXCustomerRetailerJPNHistActionCode() {
        return eObjXCustomerRetailerJPN.getHistActionCode();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XCustomerRetailerJPNHistActionCode history attribute.
     *
     * @param aXCustomerRetailerJPNHistActionCode
     *     The new value of XCustomerRetailerJPNHistActionCode.
     * @generated
     */
    public void setXCustomerRetailerJPNHistActionCode(String aXCustomerRetailerJPNHistActionCode) {
        metaDataMap.put("XCustomerRetailerJPNHistActionCode", aXCustomerRetailerJPNHistActionCode);

        if ((aXCustomerRetailerJPNHistActionCode == null) || aXCustomerRetailerJPNHistActionCode.equals("")) {
            aXCustomerRetailerJPNHistActionCode = null;
        }
        eObjXCustomerRetailerJPN.setHistActionCode(aXCustomerRetailerJPNHistActionCode);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XCustomerRetailerJPNHistCreateDate history attribute.
     *
     * @generated
     */
    public String getXCustomerRetailerJPNHistCreateDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXCustomerRetailerJPN.getHistCreateDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XCustomerRetailerJPNHistCreateDate history attribute.
     *
     * @param aXCustomerRetailerJPNHistCreateDate
     *     The new value of XCustomerRetailerJPNHistCreateDate.
     * @generated
     */
    public void setXCustomerRetailerJPNHistCreateDate(String aXCustomerRetailerJPNHistCreateDate) throws Exception{
        metaDataMap.put("XCustomerRetailerJPNHistCreateDate", aXCustomerRetailerJPNHistCreateDate);

        if ((aXCustomerRetailerJPNHistCreateDate == null) || aXCustomerRetailerJPNHistCreateDate.equals("")) {
            aXCustomerRetailerJPNHistCreateDate = null;
        }

        eObjXCustomerRetailerJPN.setHistCreateDt(DWLFunctionUtils.getTimestampFromTimestampString(aXCustomerRetailerJPNHistCreateDate));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XCustomerRetailerJPNHistCreatedBy history attribute.
     *
     * @generated
     */
    public String getXCustomerRetailerJPNHistCreatedBy() {
        return eObjXCustomerRetailerJPN.getHistCreatedBy();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XCustomerRetailerJPNHistCreatedBy history attribute.
     *
     * @param aXCustomerRetailerJPNHistCreatedBy
     *     The new value of XCustomerRetailerJPNHistCreatedBy.
     * @generated
     */
    public void setXCustomerRetailerJPNHistCreatedBy(String aXCustomerRetailerJPNHistCreatedBy) {
        metaDataMap.put("XCustomerRetailerJPNHistCreatedBy", aXCustomerRetailerJPNHistCreatedBy);

        if ((aXCustomerRetailerJPNHistCreatedBy == null) || aXCustomerRetailerJPNHistCreatedBy.equals("")) {
            aXCustomerRetailerJPNHistCreatedBy = null;
        }

        eObjXCustomerRetailerJPN.setHistCreatedBy(aXCustomerRetailerJPNHistCreatedBy);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XCustomerRetailerJPNHistEndDate history attribute.
     *
     * @generated
     */
    public String getXCustomerRetailerJPNHistEndDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXCustomerRetailerJPN.getHistEndDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XCustomerRetailerJPNHistEndDate history attribute.
     *
     * @param aXCustomerRetailerJPNHistEndDate
     *     The new value of XCustomerRetailerJPNHistEndDate.
     * @generated
     */
    public void setXCustomerRetailerJPNHistEndDate(String aXCustomerRetailerJPNHistEndDate) throws Exception{
        metaDataMap.put("XCustomerRetailerJPNHistEndDate", aXCustomerRetailerJPNHistEndDate);

        if ((aXCustomerRetailerJPNHistEndDate == null) || aXCustomerRetailerJPNHistEndDate.equals("")) {
            aXCustomerRetailerJPNHistEndDate = null;
        }
        eObjXCustomerRetailerJPN.setHistEndDt(DWLFunctionUtils.getTimestampFromTimestampString(aXCustomerRetailerJPNHistEndDate));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XCustomerRetailerJPNHistoryIdPK history attribute.
     *
     * @generated
     */
    public String getXCustomerRetailerJPNHistoryIdPK() {
        return DWLFunctionUtils.getStringFromLong(eObjXCustomerRetailerJPN.getHistoryIdPK());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XCustomerRetailerJPNHistoryIdPK history attribute.
     *
     * @param aXCustomerRetailerJPNHistoryIdPK
     *     The new value of XCustomerRetailerJPNHistoryIdPK.
     * @generated
     */
    public void setXCustomerRetailerJPNHistoryIdPK(String aXCustomerRetailerJPNHistoryIdPK) {
        metaDataMap.put("XCustomerRetailerJPNHistoryIdPK", aXCustomerRetailerJPNHistoryIdPK);

        if ((aXCustomerRetailerJPNHistoryIdPK == null) || aXCustomerRetailerJPNHistoryIdPK.equals("")) {
            aXCustomerRetailerJPNHistoryIdPK = null;
        }
        eObjXCustomerRetailerJPN.setHistoryIdPK(DWLFunctionUtils.getLongFromString(aXCustomerRetailerJPNHistoryIdPK));
    }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation during an add transaction.
     *
     * @generated
     */
    public DWLStatus validateAdd(int level, DWLStatus status) throws Exception {

        status = super.validateAdd(level, status);
        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0038I Add any controller-level custom validation logic to be
            // executed for this object during an "add" transaction


            XRetailerBObj xRetailer = getXRetailerBObj();
            if( xRetailer != null ){
            	status = xRetailer.validateAdd(level, status);
            }
        }

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            // MDM_TODO0: CDKWB0039I Add any component-level custom validation logic to be
            // executed for this object during an "add" transaction
        }
        status = getValidationStatus(level, status);
        return status;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation during an update transaction.
     *
     * @generated
     */
    public DWLStatus validateUpdate(int level, DWLStatus status) throws Exception {
    logger.finest("ENTER validateUpdate(int level, DWLStatus status)");

        status = super.validateUpdate(level, status);
        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0040I Add any controller-level custom validation logic to be
            // executed for this object during an "update" transaction

            if (eObjXCustomerRetailerJPN.getXCustomerRetailerJPNpkId() == null) {
                DWLError err = new DWLError();
                err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCUSTOMER_RETAILER_JPNBOBJ).longValue());
                err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.XCUSTOMERRETAILERJPN_XCUSTOMERRETAILERJPNPKID_NULL).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                	String infoForLogging="Error: Validation error occured for update. No primary key for entity XCustomerRetailerJPN, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("validateUpdate(int level, DWLStatus status) " + infoForLogging);
                }
                status.addError(err);
            }
            if (eObjXCustomerRetailerJPN.getLastUpdateDt() == null) {
                DWLError err = new DWLError();
                err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCUSTOMER_RETAILER_JPNBOBJ).longValue());
                err.setReasonCode(new Long(DWLUtilErrorReasonCode.LAST_UPDATED_DATE_NULL).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
                if (logger.isFinestEnabled()) {
                	String infoForLogging="Error: Validation error occured for update. No last update date for entity XCustomerRetailerJPN, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("validateUpdate(int level, DWLStatus status) " + infoForLogging);
                }
                status.addError(err);
            }
           XRetailerBObj xRetailer = (XRetailerBObj) getXRetailerBObj();
           if( xRetailer != null ){
           		if (xRetailer.getEObjXRetailer().getPrimaryKey() == null) {
               		status = xRetailer.validateAdd(level, status);
           		} else  {
               		status = xRetailer.validateUpdate(level, status);
           		}
           }
        }

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            assignBeforeImageValues(metaDataMap);
            
            // MDM_TODO0: CDKWB0041I Add any component-level custom validation logic to be
            // executed for this object during an "update" transaction
        }
        status = getValidationStatus(level, status);
    if (logger.isFinestEnabled()) {
        	String returnValue = status.toString();
      logger.finest("RETURN validateUpdate(int level, DWLStatus status) " + returnValue);
    }
        return status;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Populate the before image of this business object.
     *
     * @see com.dwl.base.DWLCommon#populateBeforeImage()
     * @generated
     */
    public void populateBeforeImage() throws DWLBaseException {
    logger.finest("ENTER populateBeforeImage()");

        DSEAAdditionsExts comp = null;
        try {
        
      comp = (DSEAAdditionsExts)TCRMClassFactory.getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
        	
        } catch (Exception e) {
      if (logger.isFinestEnabled()) {
        String infoForLogging="Error: Fatal error while updating record " + e.getMessage();
      logger.finest("populateBeforeImage() " + infoForLogging);
      }
            DWLExceptionUtils.throwDWLBaseException(e, 
            									new DWLUpdateException(e.getMessage()), 
            									this.getStatus(), DWLStatus.FATAL,
                                  DSEAAdditionsExtsComponentID.XCUSTOMER_RETAILER_JPNBOBJ, 
                                  "DIERR",
                                  DSEAAdditionsExtsErrorReasonCode.XCUSTOMERRETAILERJPN_BEFORE_IMAGE_NOT_POPULATED, 
                                  this.getControl());
        }
        
        comp.loadBeforeImage(this);
    logger.finest("RETURN populateBeforeImage()");
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation common to both add and update transactions.
     *
     * @generated
     */
     
    private DWLStatus getValidationStatus(int level, DWLStatus status) throws Exception {
    logger.finest("ENTER getValidationStatus(int level, DWLStatus status)");

        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0034I Add any common controller-level custom validation
            // logic to be executed for this object during either "add" or
            // "update" transactions
    		controllerValidation_SourceIdentifier(status);
    		controllerValidation_StartDate(status);
    		controllerValidation_EndDate(status);
    	}

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            // MDM_TODO0: CDKWB0035I Add any common component-level custom validation logic
            // to be executed for this object during either "add" or "update"
            // transactions
    		componentValidation_SourceIdentifier(status);
    		componentValidation_StartDate(status);
    		componentValidation_EndDate(status);
        }
        
        if (logger.isFinestEnabled()) {
            String returnValue = status.toString();
      logger.finest("RETURN getValidationStatus(int level, DWLStatus status) " + returnValue);
        }
    
        return status;
    }

    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "SourceIdentifier"
     *
     * @generated
     */
	private void componentValidation_SourceIdentifier(DWLStatus status) {
  
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "StartDate"
     *
     * @generated
     */
	private void componentValidation_StartDate(DWLStatus status) {
  
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "EndDate"
     *
     * @generated
     */
	private void componentValidation_EndDate(DWLStatus status) {
  
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "SourceIdentifier"
     *
     * @generated
     */
	private void controllerValidation_SourceIdentifier(DWLStatus status) throws Exception {
  
      //persistent code type
            boolean isSourceIdentifierNull = false;
            if ((eObjXCustomerRetailerJPN.getSourceIdentifier() == null) &&
               ((getSourceIdentifierValue() == null) || 
                 getSourceIdentifierValue().trim().equals(""))) {
                isSourceIdentifierNull = true;
            }
            if (!isSourceIdentifierNull) {
                if (checkForInvalidXcustomerretailerjpnSourceidentifier()) {
                    DWLError err = new DWLError();
                    err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCUSTOMER_RETAILER_JPNBOBJ).longValue());
                    err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XCUSTOMERRETAILERJPN_SOURCEIDENTIFIER).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                    String infoForLogging="Error: Custom validation error occured for entity XCustomerRetailerJPN, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("controllerValidation_SourceIdentifier " + infoForLogging);
        }
                status.addError(err);
            }

             }
    			
    	}
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "StartDate"
     *
     * @generated
     */
	private void controllerValidation_StartDate(DWLStatus status) throws Exception {
  
            boolean isStartDateNull = (eObjXCustomerRetailerJPN.getStartDate() == null);
            if (!isValidStartDate) {
              	DWLError err = new DWLError();
               	err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCUSTOMER_RETAILER_JPNBOBJ).longValue());
               	err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XCUSTOMERRETAILERJPN_STARTDATE).longValue());
               	err.setErrorType(DWLErrorCode.DATA_INVALID_ERROR);
                String infoForLogging="Error: Validation error. Invalid time specified on property StartDate in entity XCustomerRetailerJPN, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode();
      logger.finest("controllerValidation_StartDate " + infoForLogging);
               	status.addError(err);
            } 
    	}
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "EndDate"
     *
     * @generated
     */
	private void controllerValidation_EndDate(DWLStatus status) throws Exception {
  
            boolean isEndDateNull = (eObjXCustomerRetailerJPN.getEndDate() == null);
            if (!isValidEndDate) {
              	DWLError err = new DWLError();
               	err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCUSTOMER_RETAILER_JPNBOBJ).longValue());
               	err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XCUSTOMERRETAILERJPN_ENDDATE).longValue());
               	err.setErrorType(DWLErrorCode.DATA_INVALID_ERROR);
                String infoForLogging="Error: Validation error. Invalid time specified on property EndDate in entity XCustomerRetailerJPN, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode();
      logger.finest("controllerValidation_EndDate " + infoForLogging);
               	status.addError(err);
            } 
    	}
    private DWLError createDWLError(String entityName, String propertyName,String reasonCode){	
		DWLError err = new DWLError();
		err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XCUSTOMER_RETAILER_JPNBOBJ).longValue());
		err.setReasonCode(new Long(reasonCode).longValue());
		err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
			String infoForLogging="Error: Validation error occured. Property " + propertyName + " is null, in entity " + entityName + ", component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
			logger.finest("createDWLError " + infoForLogging);
		}
		return err;
    }
    
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Check the value of the field SourceIdentifier and return true if the
     * error reason INVALID_XCUSTOMERRETAILERJPN_SOURCEIDENTIFIER should be
     * returned.
     *
     * @generated
  **/
	private boolean checkForInvalidXcustomerretailerjpnSourceidentifier() throws Exception {
    logger.finest("ENTER checkForInvalidXcustomerretailerjpnSourceidentifier()");
        boolean notValid = false;
      	String langId = (String) this.getControl().get(DWLControlKeys.LANG_ID);
      	CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
    Long codeType = DWLFunctionUtils.getLongFromString( getSourceIdentifierType() );
    String codeValue = getSourceIdentifierValue();
    if( codeValue != null && codeValue.trim().equals("")){
      codeValue = null;
    }
     
        if ( codeType != null && codeValue == null ){

             if( codeTypeCompHelper.isCodeValid("cdsourceidenttp", langId, getSourceIdentifierType(),
                 CodeTypeComponentHelper.ACTIVE, getControl())) {
                 CodeTypeBObj ctBObj = codeTypeCompHelper
                 					.getCodeTypeByCode("cdsourceidenttp", langId, getSourceIdentifierType(),
                         								getControl());
               	if (ctBObj != null) {
                   	setSourceIdentifierValue( ctBObj.getvalue() );
               	}
             }
             else{
             	if (logger.isFinestEnabled()) {
              	 	String infoForLogging="NotValid 1";
      logger.finest("checkForInvalidXcustomerretailerjpnSourceidentifier() " + infoForLogging);
        }
                 notValid = true;
           }
        }
        else if (codeType == null && codeValue != null ){
          
             CodeTypeBObj ctBObj = codeTypeCompHelper
                      .getCodeTypeByValue("cdsourceidenttp", langId, codeValue,
                                 getControl());

             if (ctBObj != null) {
                 setSourceIdentifierType(ctBObj.gettp_cd());
             } 
             else {
             	if (logger.isFinestEnabled()) {
              	  	String infoForLogging="NotValid 2";
      logger.finest("checkForInvalidXcustomerretailerjpnSourceidentifier() " + infoForLogging);
        }
                  notValid = true;
             }
        }
        else if ( codeType != null && codeValue != null
             && !codeTypeCompHelper.isCodeValuePairValid("cdsourceidenttp", langId, getSourceIdentifierType(), 
                     new String[] { codeValue }, CodeTypeComponentHelper.ACTIVE, getControl())) {	
       if (logger.isFinestEnabled()) {
       		String infoForLogging="NotValid 3";
      logger.finest("checkForInvalidXcustomerretailerjpnSourceidentifier() " + infoForLogging);
       }
             notValid = true;
        }
        if (logger.isFinestEnabled()) {
      String returnValue ="" +notValid;
      logger.finest("RETURN checkForInvalidXcustomerretailerjpnSourceidentifier() " + returnValue);
    }
    return notValid;
     } 
				 



}

