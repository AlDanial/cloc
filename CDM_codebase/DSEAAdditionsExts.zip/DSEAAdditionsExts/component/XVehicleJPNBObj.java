
/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[7a6e0204db011c5e5312f88f6b9f19f1]
 */

package com.ibm.daimler.dsea.component;

import com.dwl.tcrm.common.TCRMCommon;



import com.dwl.base.DWLControl;

import com.dwl.base.constant.DWLControlKeys;
import com.dwl.base.constant.DWLUtilErrorReasonCode;

import com.dwl.base.error.DWLError;
import com.dwl.base.error.DWLErrorCode;
import com.dwl.base.error.DWLStatus;

import com.dwl.base.exception.DWLBaseException;
import com.dwl.base.exception.DWLUpdateException;

import com.dwl.base.util.DWLClassFactory;
import com.dwl.base.util.DWLExceptionUtils;
import com.dwl.base.util.DWLFunctionUtils;

import com.dwl.management.config.client.Configuration;

import com.dwl.tcrm.common.ITCRMValidation;

import com.dwl.tcrm.utilities.DateFormatter;
import com.dwl.tcrm.utilities.DateValidator;
import com.dwl.tcrm.utilities.TCRMClassFactory;

import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsComponentID;
import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsErrorReasonCode;
import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsPropertyKeys;

import com.ibm.daimler.dsea.entityObject.EObjXVehicleJPN;

import com.ibm.daimler.dsea.interfaces.DSEAAdditionsExts;

import com.ibm.mdm.common.codetype.interfaces.CodeTypeComponentHelper;

import com.ibm.mdm.common.codetype.obj.CodeTypeBObj;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * This class provides the implementation of the business object
 * <code>XVehicleJPNBObj</code>.
 * 
 * @see com.dwl.tcrm.common.TCRMCommon
 * @generated
 */
 

@SuppressWarnings("serial")
public class XVehicleJPNBObj extends TCRMCommon  {

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected EObjXVehicleJPN eObjXVehicleJPN;
	/**
    * <!-- begin-user-doc -->
	  * <!-- end-user-doc -->
    * @generated 
    */
	 private final static com.dwl.base.logging.IDWLLogger logger = com.dwl.base.logging.DWLLoggerManager.getLogger(XVehicleJPNBObj.class);
		
 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected String sourceIdentifierValue;
	protected boolean isValidLastModifiedSystemDate = true;
	
	protected boolean isValidCreateDate = true;
	
	protected boolean isValidChangedDate = true;
	
	protected boolean isValidLastServiceDate = true;
	


    protected boolean isValidEndDate = true;



    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */     
    public XVehicleJPNBObj() {
        super();
        init();
        eObjXVehicleJPN = new EObjXVehicleJPN();
        setComponentID(DSEAAdditionsExtsComponentID.XVEHICLE_JPNBOBJ);
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Initializes the fields required to populate the metaDataMap. Each key is
     * an element-level field of the business object.
     *
     * @generated
     */
    private void init() {
        metaDataMap.put("XVehicleJPNpkId", null);
        metaDataMap.put("GlobalVIN", null);
        metaDataMap.put("BauMuster", null);
        metaDataMap.put("TypeClass", null);
        metaDataMap.put("SubMuster", null);
        metaDataMap.put("Color", null);
        metaDataMap.put("Trim", null);
        metaDataMap.put("BatchInd", null);
        metaDataMap.put("MarketName", null);
        metaDataMap.put("SourceIdentifierType", null);
        metaDataMap.put("SourceIdentifierValue", null);
        metaDataMap.put("LastModifiedSystemDate", null);
        metaDataMap.put("CreateDate", null);
        metaDataMap.put("ChangedDate", null);
        metaDataMap.put("LastServiceDate", null);
        metaDataMap.put("SFDCId", null);
        metaDataMap.put("VehicleAddressType", null);
        metaDataMap.put("VehicleType", null);
        metaDataMap.put("DeleteFlag", null);
        metaDataMap.put("EndDate", null);
        metaDataMap.put("EngineNumber", null);
        metaDataMap.put("MyCarId", null);
        metaDataMap.put("XVehicleJPNHistActionCode", null);
        metaDataMap.put("XVehicleJPNHistCreateDate", null);
        metaDataMap.put("XVehicleJPNHistCreatedBy", null);
        metaDataMap.put("XVehicleJPNHistEndDate", null);
        metaDataMap.put("XVehicleJPNHistoryIdPK", null);
        metaDataMap.put("XVehicleJPNLastUpdateDate", null);
        metaDataMap.put("XVehicleJPNLastUpdateTxId", null);
        metaDataMap.put("XVehicleJPNLastUpdateUser", null);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Refreshes all the attributes this business object supports.
     *
     * @see com.dwl.base.DWLCommon#refreshMap()
     * @generated
     */
    public void refreshMap() {

        if (bRequireMapRefresh) {
            super.refreshMap();
            metaDataMap.put("XVehicleJPNpkId", getXVehicleJPNpkId());
            metaDataMap.put("GlobalVIN", getGlobalVIN());
            metaDataMap.put("BauMuster", getBauMuster());
            metaDataMap.put("TypeClass", getTypeClass());
            metaDataMap.put("SubMuster", getSubMuster());
            metaDataMap.put("Color", getColor());
            metaDataMap.put("Trim", getTrim());
            metaDataMap.put("BatchInd", getBatchInd());
            metaDataMap.put("MarketName", getMarketName());
            metaDataMap.put("SourceIdentifierType", getSourceIdentifierType());
            metaDataMap.put("SourceIdentifierValue", getSourceIdentifierValue());
            metaDataMap.put("LastModifiedSystemDate", getLastModifiedSystemDate());
            metaDataMap.put("CreateDate", getCreateDate());
            metaDataMap.put("ChangedDate", getChangedDate());
            metaDataMap.put("LastServiceDate", getLastServiceDate());
            metaDataMap.put("SFDCId", getSFDCId());
            metaDataMap.put("VehicleAddressType", getVehicleAddressType());
            metaDataMap.put("VehicleType", getVehicleType());
            metaDataMap.put("DeleteFlag", getDeleteFlag());
            metaDataMap.put("EndDate", getEndDate());
            metaDataMap.put("EngineNumber", getEngineNumber());
            metaDataMap.put("MyCarId", getMyCarId());
            metaDataMap.put("XVehicleJPNHistActionCode", getXVehicleJPNHistActionCode());
            metaDataMap.put("XVehicleJPNHistCreateDate", getXVehicleJPNHistCreateDate());
            metaDataMap.put("XVehicleJPNHistCreatedBy", getXVehicleJPNHistCreatedBy());
            metaDataMap.put("XVehicleJPNHistEndDate", getXVehicleJPNHistEndDate());
            metaDataMap.put("XVehicleJPNHistoryIdPK", getXVehicleJPNHistoryIdPK());
            metaDataMap.put("XVehicleJPNLastUpdateDate", getXVehicleJPNLastUpdateDate());
            metaDataMap.put("XVehicleJPNLastUpdateTxId", getXVehicleJPNLastUpdateTxId());
            metaDataMap.put("XVehicleJPNLastUpdateUser", getXVehicleJPNLastUpdateUser());
            bRequireMapRefresh = false;
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the control object on this business object.
     *
     * @see com.dwl.base.DWLCommon#setControl(DWLControl)
     * @generated
     */
    public void setControl(DWLControl newDWLControl) {
        super.setControl(newDWLControl);

        if (eObjXVehicleJPN != null) {
            eObjXVehicleJPN.setControl(newDWLControl);
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the entity object associated with this business object.
     *
     * @generated
     */
    public EObjXVehicleJPN getEObjXVehicleJPN() {
        bRequireMapRefresh = true;
        return eObjXVehicleJPN;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the entity object associated with this business object.
     *
     * @param eObjXVehicleJPN
     *            The eObjXVehicleJPN to set.
     * @generated
     */
    public void setEObjXVehicleJPN(EObjXVehicleJPN eObjXVehicleJPN) {
        bRequireMapRefresh = true;
        this.eObjXVehicleJPN = eObjXVehicleJPN;
        if (this.eObjXVehicleJPN != null && this.eObjXVehicleJPN.getControl() == null) {
            DWLControl control = this.getControl();
            if (control != null) {
                this.eObjXVehicleJPN.setControl(control);
            }
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the xVehicleJPNpkId attribute.
     * 
     * @generated
     */
    public String getXVehicleJPNpkId (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXVehicleJPN.getXVehicleJPNpkId());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the xVehicleJPNpkId attribute.
     * 
     * @param newXVehicleJPNpkId
     *     The new value of xVehicleJPNpkId.
     * @generated
     */
    public void setXVehicleJPNpkId( String newXVehicleJPNpkId ) throws Exception {
        metaDataMap.put("XVehicleJPNpkId", newXVehicleJPNpkId);

        if (newXVehicleJPNpkId == null || newXVehicleJPNpkId.equals("")) {
            newXVehicleJPNpkId = null;


        }
        eObjXVehicleJPN.setXVehicleJPNpkId( DWLFunctionUtils.getLongFromString(newXVehicleJPNpkId) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the globalVIN attribute.
     * 
     * @generated
     */
    public String getGlobalVIN (){
   
        return eObjXVehicleJPN.getGlobalVIN();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the globalVIN attribute.
     * 
     * @param newGlobalVIN
     *     The new value of globalVIN.
     * @generated
     */
    public void setGlobalVIN( String newGlobalVIN ) throws Exception {
        metaDataMap.put("GlobalVIN", newGlobalVIN);

        if (newGlobalVIN == null || newGlobalVIN.equals("")) {
            newGlobalVIN = null;


        }
        eObjXVehicleJPN.setGlobalVIN( newGlobalVIN );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the bauMuster attribute.
     * 
     * @generated
     */
    public String getBauMuster (){
   
        return eObjXVehicleJPN.getBauMuster();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the bauMuster attribute.
     * 
     * @param newBauMuster
     *     The new value of bauMuster.
     * @generated
     */
    public void setBauMuster( String newBauMuster ) throws Exception {
        metaDataMap.put("BauMuster", newBauMuster);

        if (newBauMuster == null || newBauMuster.equals("")) {
            newBauMuster = null;


        }
        eObjXVehicleJPN.setBauMuster( newBauMuster );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the typeClass attribute.
     * 
     * @generated
     */
    public String getTypeClass (){
   
        return eObjXVehicleJPN.getTypeClass();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the typeClass attribute.
     * 
     * @param newTypeClass
     *     The new value of typeClass.
     * @generated
     */
    public void setTypeClass( String newTypeClass ) throws Exception {
        metaDataMap.put("TypeClass", newTypeClass);

        if (newTypeClass == null || newTypeClass.equals("")) {
            newTypeClass = null;


        }
        eObjXVehicleJPN.setTypeClass( newTypeClass );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the subMuster attribute.
     * 
     * @generated
     */
    public String getSubMuster (){
   
        return eObjXVehicleJPN.getSubMuster();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the subMuster attribute.
     * 
     * @param newSubMuster
     *     The new value of subMuster.
     * @generated
     */
    public void setSubMuster( String newSubMuster ) throws Exception {
        metaDataMap.put("SubMuster", newSubMuster);

        if (newSubMuster == null || newSubMuster.equals("")) {
            newSubMuster = null;


        }
        eObjXVehicleJPN.setSubMuster( newSubMuster );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the color attribute.
     * 
     * @generated
     */
    public String getColor (){
   
        return eObjXVehicleJPN.getColor();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the color attribute.
     * 
     * @param newColor
     *     The new value of color.
     * @generated
     */
    public void setColor( String newColor ) throws Exception {
        metaDataMap.put("Color", newColor);

        if (newColor == null || newColor.equals("")) {
            newColor = null;


        }
        eObjXVehicleJPN.setColor( newColor );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the trim attribute.
     * 
     * @generated
     */
    public String getTrim (){
   
        return eObjXVehicleJPN.getTrim();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the trim attribute.
     * 
     * @param newTrim
     *     The new value of trim.
     * @generated
     */
    public void setTrim( String newTrim ) throws Exception {
        metaDataMap.put("Trim", newTrim);

        if (newTrim == null || newTrim.equals("")) {
            newTrim = null;


        }
        eObjXVehicleJPN.setTrim( newTrim );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the batchInd attribute.
     * 
     * @generated
     */
    public String getBatchInd (){
   
        return eObjXVehicleJPN.getBatchInd();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the batchInd attribute.
     * 
     * @param newBatchInd
     *     The new value of batchInd.
     * @generated
     */
    public void setBatchInd( String newBatchInd ) throws Exception {
        metaDataMap.put("BatchInd", newBatchInd);

        if (newBatchInd == null || newBatchInd.equals("")) {
            newBatchInd = null;


        }
        eObjXVehicleJPN.setBatchInd( newBatchInd );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the marketName attribute.
     * 
     * @generated
     */
    public String getMarketName (){
   
        return eObjXVehicleJPN.getMarketName();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the marketName attribute.
     * 
     * @param newMarketName
     *     The new value of marketName.
     * @generated
     */
    public void setMarketName( String newMarketName ) throws Exception {
        metaDataMap.put("MarketName", newMarketName);

        if (newMarketName == null || newMarketName.equals("")) {
            newMarketName = null;


        }
        eObjXVehicleJPN.setMarketName( newMarketName );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the sourceIdentifierType attribute.
     * 
     * @generated
     */
    public String getSourceIdentifierType (){
   
        return DWLFunctionUtils.getStringFromLong(eObjXVehicleJPN.getSourceIdentifier());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the sourceIdentifierType attribute.
     * 
     * @param newSourceIdentifierType
     *     The new value of sourceIdentifierType.
     * @generated
     */
    public void setSourceIdentifierType( String newSourceIdentifierType ) throws Exception {
        metaDataMap.put("SourceIdentifierType", newSourceIdentifierType);

        if (newSourceIdentifierType == null || newSourceIdentifierType.equals("")) {
            newSourceIdentifierType = null;


        }
        eObjXVehicleJPN.setSourceIdentifier( DWLFunctionUtils.getLongFromString(newSourceIdentifierType) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the sourceIdentifierValue attribute.
     * 
     * @generated
     */
    public String getSourceIdentifierValue (){
      return sourceIdentifierValue;
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the sourceIdentifierValue attribute.
     * 
     * @param newSourceIdentifierValue
     *     The new value of sourceIdentifierValue.
     * @generated
     */
    public void setSourceIdentifierValue( String newSourceIdentifierValue ) throws Exception {
        metaDataMap.put("SourceIdentifierValue", newSourceIdentifierValue);

        if (newSourceIdentifierValue == null || newSourceIdentifierValue.equals("")) {
            newSourceIdentifierValue = null;


        }
        sourceIdentifierValue = newSourceIdentifierValue;
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the lastModifiedSystemDate attribute.
     * 
     * @generated
     */
    public String getLastModifiedSystemDate (){
   
        return DWLFunctionUtils.getStringFromTimestamp(eObjXVehicleJPN.getLastModifiedSystemDate());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the lastModifiedSystemDate attribute.
     * 
     * @param newLastModifiedSystemDate
     *     The new value of lastModifiedSystemDate.
     * @generated
     */
    public void setLastModifiedSystemDate( String newLastModifiedSystemDate ) throws Exception {
        metaDataMap.put("LastModifiedSystemDate", newLastModifiedSystemDate);
       	isValidLastModifiedSystemDate = true;

        if (newLastModifiedSystemDate == null || newLastModifiedSystemDate.equals("")) {
            newLastModifiedSystemDate = null;
            eObjXVehicleJPN.setLastModifiedSystemDate(null);


        }
    else {
        	if (DateValidator.validates(newLastModifiedSystemDate)) {
           		eObjXVehicleJPN.setLastModifiedSystemDate(DateFormatter.getStartDateTimestamp(newLastModifiedSystemDate));
            	metaDataMap.put("LastModifiedSystemDate", getLastModifiedSystemDate());
        	} else {
            	if (Configuration.getConfiguration().getConfigItem(
              "/IBM/DWLCommonServices/InternalValidation/enabled").getBooleanValue()) {
                	if (metaDataMap.get("LastModifiedSystemDate") != null) {
                    	metaDataMap.put("LastModifiedSystemDate", "");
                	}
                	isValidLastModifiedSystemDate = false;
                	eObjXVehicleJPN.setLastModifiedSystemDate(null);
            	}
        	}
        }
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the createDate attribute.
     * 
     * @generated
     */
    public String getCreateDate (){
   
        return DWLFunctionUtils.getStringFromTimestamp(eObjXVehicleJPN.getCreateDate());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the createDate attribute.
     * 
     * @param newCreateDate
     *     The new value of createDate.
     * @generated
     */
    public void setCreateDate( String newCreateDate ) throws Exception {
        metaDataMap.put("CreateDate", newCreateDate);
       	isValidCreateDate = true;

        if (newCreateDate == null || newCreateDate.equals("")) {
            newCreateDate = null;
            eObjXVehicleJPN.setCreateDate(null);


        }
    else {
        	if (DateValidator.validates(newCreateDate)) {
           		eObjXVehicleJPN.setCreateDate(DateFormatter.getStartDateTimestamp(newCreateDate));
            	metaDataMap.put("CreateDate", getCreateDate());
        	} else {
            	if (Configuration.getConfiguration().getConfigItem(
              "/IBM/DWLCommonServices/InternalValidation/enabled").getBooleanValue()) {
                	if (metaDataMap.get("CreateDate") != null) {
                    	metaDataMap.put("CreateDate", "");
                	}
                	isValidCreateDate = false;
                	eObjXVehicleJPN.setCreateDate(null);
            	}
        	}
        }
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the changedDate attribute.
     * 
     * @generated
     */
    public String getChangedDate (){
   
        return DWLFunctionUtils.getStringFromTimestamp(eObjXVehicleJPN.getChangedDate());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the changedDate attribute.
     * 
     * @param newChangedDate
     *     The new value of changedDate.
     * @generated
     */
    public void setChangedDate( String newChangedDate ) throws Exception {
        metaDataMap.put("ChangedDate", newChangedDate);
       	isValidChangedDate = true;

        if (newChangedDate == null || newChangedDate.equals("")) {
            newChangedDate = null;
            eObjXVehicleJPN.setChangedDate(null);


        }
    else {
        	if (DateValidator.validates(newChangedDate)) {
           		eObjXVehicleJPN.setChangedDate(DateFormatter.getStartDateTimestamp(newChangedDate));
            	metaDataMap.put("ChangedDate", getChangedDate());
        	} else {
            	if (Configuration.getConfiguration().getConfigItem(
              "/IBM/DWLCommonServices/InternalValidation/enabled").getBooleanValue()) {
                	if (metaDataMap.get("ChangedDate") != null) {
                    	metaDataMap.put("ChangedDate", "");
                	}
                	isValidChangedDate = false;
                	eObjXVehicleJPN.setChangedDate(null);
            	}
        	}
        }
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the lastServiceDate attribute.
     * 
     * @generated
     */
    public String getLastServiceDate (){
   
        return DWLFunctionUtils.getStringFromTimestamp(eObjXVehicleJPN.getLastServiceDate());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the lastServiceDate attribute.
     * 
     * @param newLastServiceDate
     *     The new value of lastServiceDate.
     * @generated
     */
    public void setLastServiceDate( String newLastServiceDate ) throws Exception {
        metaDataMap.put("LastServiceDate", newLastServiceDate);
       	isValidLastServiceDate = true;

        if (newLastServiceDate == null || newLastServiceDate.equals("")) {
            newLastServiceDate = null;
            eObjXVehicleJPN.setLastServiceDate(null);


        }
    else {
        	if (DateValidator.validates(newLastServiceDate)) {
           		eObjXVehicleJPN.setLastServiceDate(DateFormatter.getStartDateTimestamp(newLastServiceDate));
            	metaDataMap.put("LastServiceDate", getLastServiceDate());
        	} else {
            	if (Configuration.getConfiguration().getConfigItem(
              "/IBM/DWLCommonServices/InternalValidation/enabled").getBooleanValue()) {
                	if (metaDataMap.get("LastServiceDate") != null) {
                    	metaDataMap.put("LastServiceDate", "");
                	}
                	isValidLastServiceDate = false;
                	eObjXVehicleJPN.setLastServiceDate(null);
            	}
        	}
        }
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the sFDCId attribute.
     * 
     * @generated
     */
    public String getSFDCId (){
   
        return eObjXVehicleJPN.getSFDCId();
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the sFDCId attribute.
     * 
     * @param newSFDCId
     *     The new value of sFDCId.
     * @generated
     */
    public void setSFDCId( String newSFDCId ) throws Exception {
        metaDataMap.put("SFDCId", newSFDCId);

        if (newSFDCId == null || newSFDCId.equals("")) {
            newSFDCId = null;


        }
        eObjXVehicleJPN.setSFDCId( newSFDCId );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the vehicleAddressType attribute.
     * 
     * @generated
     */
    public String getVehicleAddressType (){
   
        return eObjXVehicleJPN.getVehicleAddressType();
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the vehicleAddressType attribute.
     * 
     * @param newVehicleAddressType
     *     The new value of vehicleAddressType.
     * @generated
     */
    public void setVehicleAddressType( String newVehicleAddressType ) throws Exception {
        metaDataMap.put("VehicleAddressType", newVehicleAddressType);

        if (newVehicleAddressType == null || newVehicleAddressType.equals("")) {
            newVehicleAddressType = null;


        }
        eObjXVehicleJPN.setVehicleAddressType( newVehicleAddressType );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the vehicleType attribute.
     * 
     * @generated
     */
    public String getVehicleType (){
   
        return eObjXVehicleJPN.getVehicleType();
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the vehicleType attribute.
     * 
     * @param newVehicleType
     *     The new value of vehicleType.
     * @generated
     */
    public void setVehicleType( String newVehicleType ) throws Exception {
        metaDataMap.put("VehicleType", newVehicleType);

        if (newVehicleType == null || newVehicleType.equals("")) {
            newVehicleType = null;


        }
        eObjXVehicleJPN.setVehicleType( newVehicleType );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the deleteFlag attribute.
     * 
     * @generated
     */
    public String getDeleteFlag (){
   
        return eObjXVehicleJPN.getDeleteFlag();
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the deleteFlag attribute.
     * 
     * @param newDeleteFlag
     *     The new value of deleteFlag.
     * @generated
     */
    public void setDeleteFlag( String newDeleteFlag ) throws Exception {
        metaDataMap.put("DeleteFlag", newDeleteFlag);

        if (newDeleteFlag == null || newDeleteFlag.equals("")) {
            newDeleteFlag = null;


        }
        eObjXVehicleJPN.setDeleteFlag( newDeleteFlag );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the endDate attribute.
     * 
     * @generated
     */
    public String getEndDate (){
   
        return DWLFunctionUtils.getStringFromTimestamp(eObjXVehicleJPN.getEndDate());
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the endDate attribute.
     * 
     * @param newEndDate
     *     The new value of endDate.
     * @generated
     */
    public void setEndDate( String newEndDate ) throws Exception {
        metaDataMap.put("EndDate", newEndDate);
       	isValidEndDate = true;

        if (newEndDate == null || newEndDate.equals("")) {
            newEndDate = null;
            eObjXVehicleJPN.setEndDate(null);


        }
    else {
        	if (DateValidator.validates(newEndDate)) {
           		eObjXVehicleJPN.setEndDate(DateFormatter.getStartDateTimestamp(newEndDate));
            	metaDataMap.put("EndDate", getEndDate());
        	} else {
            	if (Configuration.getConfiguration().getConfigItem(
              "/IBM/DWLCommonServices/InternalValidation/enabled").getBooleanValue()) {
                	if (metaDataMap.get("EndDate") != null) {
                    	metaDataMap.put("EndDate", "");
                	}
                	isValidEndDate = false;
                	eObjXVehicleJPN.setEndDate(null);
            	}
        	}
        }
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the engineNumber attribute.
     * 
     * @generated
     */
    public String getEngineNumber (){
   
        return eObjXVehicleJPN.getEngineNumber();
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the engineNumber attribute.
     * 
     * @param newEngineNumber
     *     The new value of engineNumber.
     * @generated
     */
    public void setEngineNumber( String newEngineNumber ) throws Exception {
        metaDataMap.put("EngineNumber", newEngineNumber);

        if (newEngineNumber == null || newEngineNumber.equals("")) {
            newEngineNumber = null;


        }
        eObjXVehicleJPN.setEngineNumber( newEngineNumber );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the myCarId attribute.
     * 
     * @generated
     */
    public String getMyCarId (){
   
        return eObjXVehicleJPN.getMyCarId();
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the myCarId attribute.
     * 
     * @param newMyCarId
     *     The new value of myCarId.
     * @generated
     */
    public void setMyCarId( String newMyCarId ) throws Exception {
        metaDataMap.put("MyCarId", newMyCarId);

        if (newMyCarId == null || newMyCarId.equals("")) {
            newMyCarId = null;


        }
        eObjXVehicleJPN.setMyCarId( newMyCarId );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateTxId attribute.
     *
     * @generated
     */
    public String getXVehicleJPNLastUpdateTxId() {
        return DWLFunctionUtils.getStringFromLong(eObjXVehicleJPN.getLastUpdateTxId());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateUser attribute.
     *
     * @generated
     */
    public String getXVehicleJPNLastUpdateUser() {
        return eObjXVehicleJPN.getLastUpdateUser();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateDt attribute.
     *
     * @generated
     */
    public String getXVehicleJPNLastUpdateDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXVehicleJPN.getLastUpdateDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateTxId attribute.
     *
     * @param newLastUpdateTxId
     *     The new value of LastUpdateTxId.
     * @generated
     */
    public void setXVehicleJPNLastUpdateTxId(String newLastUpdateTxId) {
        metaDataMap.put("XVehicleJPNLastUpdateTxId", newLastUpdateTxId);

        if ((newLastUpdateTxId == null) || newLastUpdateTxId.equals("")) {
            newLastUpdateTxId = null;
        }
        eObjXVehicleJPN.setLastUpdateTxId(DWLFunctionUtils.getLongFromString(newLastUpdateTxId));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateUser attribute.
     *
     * @param newLastUpdateUser
     *     The new value of LastUpdateUser.
     * @generated
     */
    public void setXVehicleJPNLastUpdateUser(String newLastUpdateUser) {
        metaDataMap.put("XVehicleJPNLastUpdateUser", newLastUpdateUser);

        if ((newLastUpdateUser == null) || newLastUpdateUser.equals("")) {
            newLastUpdateUser = null;
        }
        eObjXVehicleJPN.setLastUpdateUser(newLastUpdateUser);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateDt attribute.
     *
     * @param newLastUpdateDt
     *     The new value of LastUpdateDt.
     * @throws Exception
     * @generated
     */
    public void setXVehicleJPNLastUpdateDate(String newLastUpdateDt) throws Exception {
        metaDataMap.put("XVehicleJPNLastUpdateDate", newLastUpdateDt);

        if ((newLastUpdateDt == null) || newLastUpdateDt.equals("")) {
            newLastUpdateDt = null;
        }

        eObjXVehicleJPN.setLastUpdateDt(DWLFunctionUtils.getTimestampFromTimestampString(newLastUpdateDt));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XVehicleJPNHistActionCode history attribute.
     *
     * @generated
     */
    public String getXVehicleJPNHistActionCode() {
        return eObjXVehicleJPN.getHistActionCode();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XVehicleJPNHistActionCode history attribute.
     *
     * @param aXVehicleJPNHistActionCode
     *     The new value of XVehicleJPNHistActionCode.
     * @generated
     */
    public void setXVehicleJPNHistActionCode(String aXVehicleJPNHistActionCode) {
        metaDataMap.put("XVehicleJPNHistActionCode", aXVehicleJPNHistActionCode);

        if ((aXVehicleJPNHistActionCode == null) || aXVehicleJPNHistActionCode.equals("")) {
            aXVehicleJPNHistActionCode = null;
        }
        eObjXVehicleJPN.setHistActionCode(aXVehicleJPNHistActionCode);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XVehicleJPNHistCreateDate history attribute.
     *
     * @generated
     */
    public String getXVehicleJPNHistCreateDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXVehicleJPN.getHistCreateDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XVehicleJPNHistCreateDate history attribute.
     *
     * @param aXVehicleJPNHistCreateDate
     *     The new value of XVehicleJPNHistCreateDate.
     * @generated
     */
    public void setXVehicleJPNHistCreateDate(String aXVehicleJPNHistCreateDate) throws Exception{
        metaDataMap.put("XVehicleJPNHistCreateDate", aXVehicleJPNHistCreateDate);

        if ((aXVehicleJPNHistCreateDate == null) || aXVehicleJPNHistCreateDate.equals("")) {
            aXVehicleJPNHistCreateDate = null;
        }

        eObjXVehicleJPN.setHistCreateDt(DWLFunctionUtils.getTimestampFromTimestampString(aXVehicleJPNHistCreateDate));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XVehicleJPNHistCreatedBy history attribute.
     *
     * @generated
     */
    public String getXVehicleJPNHistCreatedBy() {
        return eObjXVehicleJPN.getHistCreatedBy();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XVehicleJPNHistCreatedBy history attribute.
     *
     * @param aXVehicleJPNHistCreatedBy
     *     The new value of XVehicleJPNHistCreatedBy.
     * @generated
     */
    public void setXVehicleJPNHistCreatedBy(String aXVehicleJPNHistCreatedBy) {
        metaDataMap.put("XVehicleJPNHistCreatedBy", aXVehicleJPNHistCreatedBy);

        if ((aXVehicleJPNHistCreatedBy == null) || aXVehicleJPNHistCreatedBy.equals("")) {
            aXVehicleJPNHistCreatedBy = null;
        }

        eObjXVehicleJPN.setHistCreatedBy(aXVehicleJPNHistCreatedBy);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XVehicleJPNHistEndDate history attribute.
     *
     * @generated
     */
    public String getXVehicleJPNHistEndDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjXVehicleJPN.getHistEndDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XVehicleJPNHistEndDate history attribute.
     *
     * @param aXVehicleJPNHistEndDate
     *     The new value of XVehicleJPNHistEndDate.
     * @generated
     */
    public void setXVehicleJPNHistEndDate(String aXVehicleJPNHistEndDate) throws Exception{
        metaDataMap.put("XVehicleJPNHistEndDate", aXVehicleJPNHistEndDate);

        if ((aXVehicleJPNHistEndDate == null) || aXVehicleJPNHistEndDate.equals("")) {
            aXVehicleJPNHistEndDate = null;
        }
        eObjXVehicleJPN.setHistEndDt(DWLFunctionUtils.getTimestampFromTimestampString(aXVehicleJPNHistEndDate));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the XVehicleJPNHistoryIdPK history attribute.
     *
     * @generated
     */
    public String getXVehicleJPNHistoryIdPK() {
        return DWLFunctionUtils.getStringFromLong(eObjXVehicleJPN.getHistoryIdPK());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the XVehicleJPNHistoryIdPK history attribute.
     *
     * @param aXVehicleJPNHistoryIdPK
     *     The new value of XVehicleJPNHistoryIdPK.
     * @generated
     */
    public void setXVehicleJPNHistoryIdPK(String aXVehicleJPNHistoryIdPK) {
        metaDataMap.put("XVehicleJPNHistoryIdPK", aXVehicleJPNHistoryIdPK);

        if ((aXVehicleJPNHistoryIdPK == null) || aXVehicleJPNHistoryIdPK.equals("")) {
            aXVehicleJPNHistoryIdPK = null;
        }
        eObjXVehicleJPN.setHistoryIdPK(DWLFunctionUtils.getLongFromString(aXVehicleJPNHistoryIdPK));
    }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation during an add transaction.
     *
     * @generated
     */
    public DWLStatus validateAdd(int level, DWLStatus status) throws Exception {

        status = super.validateAdd(level, status);
        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0038I Add any controller-level custom validation logic to be
            // executed for this object during an "add" transaction

        }

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            // MDM_TODO0: CDKWB0039I Add any component-level custom validation logic to be
            // executed for this object during an "add" transaction
        }
        status = getValidationStatus(level, status);
        return status;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation during an update transaction.
     *
     * @generated
     */
    public DWLStatus validateUpdate(int level, DWLStatus status) throws Exception {
    logger.finest("ENTER validateUpdate(int level, DWLStatus status)");

        status = super.validateUpdate(level, status);
        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0040I Add any controller-level custom validation logic to be
            // executed for this object during an "update" transaction

            if (eObjXVehicleJPN.getXVehicleJPNpkId() == null) {
                DWLError err = new DWLError();
                err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XVEHICLE_JPNBOBJ).longValue());
                err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.XVEHICLEJPN_XVEHICLEJPNPKID_NULL).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                	String infoForLogging="Error: Validation error occured for update. No primary key for entity XVehicleJPN, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("validateUpdate(int level, DWLStatus status) " + infoForLogging);
                }
                status.addError(err);
            }
            if (eObjXVehicleJPN.getLastUpdateDt() == null) {
                DWLError err = new DWLError();
                err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XVEHICLE_JPNBOBJ).longValue());
                err.setReasonCode(new Long(DWLUtilErrorReasonCode.LAST_UPDATED_DATE_NULL).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
                if (logger.isFinestEnabled()) {
                	String infoForLogging="Error: Validation error occured for update. No last update date for entity XVehicleJPN, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("validateUpdate(int level, DWLStatus status) " + infoForLogging);
                }
                status.addError(err);
            }
        }

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            assignBeforeImageValues(metaDataMap);
            
            // MDM_TODO0: CDKWB0041I Add any component-level custom validation logic to be
            // executed for this object during an "update" transaction
        }
        status = getValidationStatus(level, status);
    if (logger.isFinestEnabled()) {
        	String returnValue = status.toString();
      logger.finest("RETURN validateUpdate(int level, DWLStatus status) " + returnValue);
    }
        return status;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Populate the before image of this business object.
     *
     * @see com.dwl.base.DWLCommon#populateBeforeImage()
     * @generated
     */
    public void populateBeforeImage() throws DWLBaseException {
    logger.finest("ENTER populateBeforeImage()");

        DSEAAdditionsExts comp = null;
        try {
        
      comp = (DSEAAdditionsExts)TCRMClassFactory.getTCRMComponent(DSEAAdditionsExtsPropertyKeys.DSEAADDITIONS_EXTS_COMPONENT);
        	
        } catch (Exception e) {
      if (logger.isFinestEnabled()) {
        String infoForLogging="Error: Fatal error while updating record " + e.getMessage();
      logger.finest("populateBeforeImage() " + infoForLogging);
      }
            DWLExceptionUtils.throwDWLBaseException(e, 
            									new DWLUpdateException(e.getMessage()), 
            									this.getStatus(), DWLStatus.FATAL,
                                  DSEAAdditionsExtsComponentID.XVEHICLE_JPNBOBJ, 
                                  "DIERR",
                                  DSEAAdditionsExtsErrorReasonCode.XVEHICLEJPN_BEFORE_IMAGE_NOT_POPULATED, 
                                  this.getControl());
        }
        
        comp.loadBeforeImage(this);
    logger.finest("RETURN populateBeforeImage()");
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation common to both add and update transactions.
     *
     * @generated
     */
     
    private DWLStatus getValidationStatus(int level, DWLStatus status) throws Exception {
    logger.finest("ENTER getValidationStatus(int level, DWLStatus status)");

        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0034I Add any common controller-level custom validation
            // logic to be executed for this object during either "add" or
            // "update" transactions
    		controllerValidation_SourceIdentifier(status);
    		controllerValidation_LastModifiedSystemDate(status);
    		controllerValidation_CreateDate(status);
    		controllerValidation_ChangedDate(status);
    		controllerValidation_LastServiceDate(status);
    		controllerValidation_EndDate(status);
    	}

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            // MDM_TODO0: CDKWB0035I Add any common component-level custom validation logic
            // to be executed for this object during either "add" or "update"
            // transactions
    		componentValidation_SourceIdentifier(status);
    		componentValidation_LastModifiedSystemDate(status);
    		componentValidation_CreateDate(status);
    		componentValidation_ChangedDate(status);
    		componentValidation_LastServiceDate(status);
    		componentValidation_EndDate(status);
        }
        
        if (logger.isFinestEnabled()) {
            String returnValue = status.toString();
      logger.finest("RETURN getValidationStatus(int level, DWLStatus status) " + returnValue);
        }
    
        return status;
    }

    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "SourceIdentifier"
     *
     * @generated
     */
	private void componentValidation_SourceIdentifier(DWLStatus status) {
  
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "LastModifiedSystemDate"
     *
     * @generated
     */
	private void componentValidation_LastModifiedSystemDate(DWLStatus status) {
  
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "CreateDate"
     *
     * @generated
     */
	private void componentValidation_CreateDate(DWLStatus status) {
  
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "ChangedDate"
     *
     * @generated
     */
	private void componentValidation_ChangedDate(DWLStatus status) {
  
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "LastServiceDate"
     *
     * @generated
     */
	private void componentValidation_LastServiceDate(DWLStatus status) {
  
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "EndDate"
     *
     * @generated
     */
  private void componentValidation_EndDate(DWLStatus status) {
  
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "SourceIdentifier"
     *
     * @generated
     */
	private void controllerValidation_SourceIdentifier(DWLStatus status) throws Exception {
  
      //persistent code type
            boolean isSourceIdentifierNull = false;
            if ((eObjXVehicleJPN.getSourceIdentifier() == null) &&
               ((getSourceIdentifierValue() == null) || 
                 getSourceIdentifierValue().trim().equals(""))) {
                isSourceIdentifierNull = true;
            }
            if (!isSourceIdentifierNull) {
                if (checkForInvalidXvehiclejpnSourceidentifier()) {
                    DWLError err = new DWLError();
                    err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XVEHICLE_JPNBOBJ).longValue());
                    err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XVEHICLEJPN_SOURCEIDENTIFIER).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                    String infoForLogging="Error: Custom validation error occured for entity XVehicleJPN, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("controllerValidation_SourceIdentifier " + infoForLogging);
        }
                status.addError(err);
            }

             }
    			
    	}
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "LastModifiedSystemDate"
     *
     * @generated
     */
	private void controllerValidation_LastModifiedSystemDate(DWLStatus status) throws Exception {
  
            boolean isLastModifiedSystemDateNull = (eObjXVehicleJPN.getLastModifiedSystemDate() == null);
            if (!isValidLastModifiedSystemDate) {
              	DWLError err = new DWLError();
               	err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XVEHICLE_JPNBOBJ).longValue());
               	err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XVEHICLEJPN_LASTMODIFIEDSYSTEMDATE).longValue());
               	err.setErrorType(DWLErrorCode.DATA_INVALID_ERROR);
                String infoForLogging="Error: Validation error. Invalid time specified on property LastModifiedSystemDate in entity XVehicleJPN, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode();
      logger.finest("controllerValidation_LastModifiedSystemDate " + infoForLogging);
               	status.addError(err);
            } 
    	}
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "CreateDate"
     *
     * @generated
     */
	private void controllerValidation_CreateDate(DWLStatus status) throws Exception {
  
            boolean isCreateDateNull = (eObjXVehicleJPN.getCreateDate() == null);
            if (!isValidCreateDate) {
              	DWLError err = new DWLError();
               	err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XVEHICLE_JPNBOBJ).longValue());
               	err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XVEHICLEJPN_CREATEDATE).longValue());
               	err.setErrorType(DWLErrorCode.DATA_INVALID_ERROR);
                String infoForLogging="Error: Validation error. Invalid time specified on property CreateDate in entity XVehicleJPN, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode();
      logger.finest("controllerValidation_CreateDate " + infoForLogging);
               	status.addError(err);
            } 
    	}
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "ChangedDate"
     *
     * @generated
     */
	private void controllerValidation_ChangedDate(DWLStatus status) throws Exception {
  
            boolean isChangedDateNull = (eObjXVehicleJPN.getChangedDate() == null);
            if (!isValidChangedDate) {
              	DWLError err = new DWLError();
               	err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XVEHICLE_JPNBOBJ).longValue());
               	err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XVEHICLEJPN_CHANGEDDATE).longValue());
               	err.setErrorType(DWLErrorCode.DATA_INVALID_ERROR);
                String infoForLogging="Error: Validation error. Invalid time specified on property ChangedDate in entity XVehicleJPN, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode();
      logger.finest("controllerValidation_ChangedDate " + infoForLogging);
               	status.addError(err);
            } 
    	}
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "LastServiceDate"
     *
     * @generated
     */
	private void controllerValidation_LastServiceDate(DWLStatus status) throws Exception {
  
            boolean isLastServiceDateNull = (eObjXVehicleJPN.getLastServiceDate() == null);
            if (!isValidLastServiceDate) {
              	DWLError err = new DWLError();
               	err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XVEHICLE_JPNBOBJ).longValue());
               	err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XVEHICLEJPN_LASTSERVICEDATE).longValue());
               	err.setErrorType(DWLErrorCode.DATA_INVALID_ERROR);
                String infoForLogging="Error: Validation error. Invalid time specified on property LastServiceDate in entity XVehicleJPN, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode();
      logger.finest("controllerValidation_LastServiceDate " + infoForLogging);
               	status.addError(err);
            } 
    	}
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "EndDate"
     *
     * @generated
     */
  private void controllerValidation_EndDate(DWLStatus status) throws Exception {
  
            boolean isEndDateNull = (eObjXVehicleJPN.getEndDate() == null);
            if (!isValidEndDate) {
              	DWLError err = new DWLError();
               	err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XVEHICLE_JPNBOBJ).longValue());
               	err.setReasonCode(new Long(DSEAAdditionsExtsErrorReasonCode.INVALID_XVEHICLEJPN_ENDDATE).longValue());
               	err.setErrorType(DWLErrorCode.DATA_INVALID_ERROR);
                String infoForLogging="Error: Validation error. Invalid time specified on property EndDate in entity XVehicleJPN, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode();
      logger.finest("controllerValidation_EndDate " + infoForLogging);
               	status.addError(err);
            } 
    	}


    private DWLError createDWLError(String entityName, String propertyName,String reasonCode){	
		DWLError err = new DWLError();
		err.setComponentType(new Long(DSEAAdditionsExtsComponentID.XVEHICLE_JPNBOBJ).longValue());
		err.setReasonCode(new Long(reasonCode).longValue());
		err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
			String infoForLogging="Error: Validation error occured. Property " + propertyName + " is null, in entity " + entityName + ", component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
			logger.finest("createDWLError " + infoForLogging);
		}
		return err;
    }
    
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Check the value of the field SourceIdentifier and return true if the
     * error reason INVALID_XVEHICLEJPN_SOURCEIDENTIFIER should be returned.
     *
     * @generated
  **/
	private boolean checkForInvalidXvehiclejpnSourceidentifier() throws Exception {
    logger.finest("ENTER checkForInvalidXvehiclejpnSourceidentifier()");
        boolean notValid = false;
      	String langId = (String) this.getControl().get(DWLControlKeys.LANG_ID);
      	CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
    Long codeType = DWLFunctionUtils.getLongFromString( getSourceIdentifierType() );
    String codeValue = getSourceIdentifierValue();
    if( codeValue != null && codeValue.trim().equals("")){
      codeValue = null;
    }
     
        if ( codeType != null && codeValue == null ){

             if( codeTypeCompHelper.isCodeValid("cdsourceidenttp", langId, getSourceIdentifierType(),
                 CodeTypeComponentHelper.ACTIVE, getControl())) {
                 CodeTypeBObj ctBObj = codeTypeCompHelper
                 					.getCodeTypeByCode("cdsourceidenttp", langId, getSourceIdentifierType(),
                         								getControl());
               	if (ctBObj != null) {
                   	setSourceIdentifierValue( ctBObj.getvalue() );
               	}
             }
             else{
             	if (logger.isFinestEnabled()) {
              	 	String infoForLogging="NotValid 1";
      logger.finest("checkForInvalidXvehiclejpnSourceidentifier() " + infoForLogging);
        }
                 notValid = true;
           }
        }
        else if (codeType == null && codeValue != null ){
          
             CodeTypeBObj ctBObj = codeTypeCompHelper
                      .getCodeTypeByValue("cdsourceidenttp", langId, codeValue,
                                 getControl());

             if (ctBObj != null) {
                 setSourceIdentifierType(ctBObj.gettp_cd());
             } 
             else {
             	if (logger.isFinestEnabled()) {
              	  	String infoForLogging="NotValid 2";
      logger.finest("checkForInvalidXvehiclejpnSourceidentifier() " + infoForLogging);
        }
                  notValid = true;
             }
        }
        else if ( codeType != null && codeValue != null
             && !codeTypeCompHelper.isCodeValuePairValid("cdsourceidenttp", langId, getSourceIdentifierType(), 
                     new String[] { codeValue }, CodeTypeComponentHelper.ACTIVE, getControl())) {	
       if (logger.isFinestEnabled()) {
       		String infoForLogging="NotValid 3";
      logger.finest("checkForInvalidXvehiclejpnSourceidentifier() " + infoForLogging);
       }
             notValid = true;
        }
        if (logger.isFinestEnabled()) {
      String returnValue ="" +notValid;
      logger.finest("RETURN checkForInvalidXvehiclejpnSourceidentifier() " + returnValue);
    }
    return notValid;
     } 
				 



}

