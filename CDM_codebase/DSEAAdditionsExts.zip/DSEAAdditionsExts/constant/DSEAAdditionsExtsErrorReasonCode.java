/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[44def86ddd4e73ad1097ecc8c0a52262]
 */
package com.ibm.daimler.dsea.constant;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * Defines the error message codes used in this module.
 *
 * @generated
 */
public class DSEAAdditionsExtsErrorReasonCode {

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: XMarketName
     *
     * @generated
     */
    public final static String XPERSON_XMARKETNAME_NULL = "1100348";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: XBatchInd
     *
     * @generated
     */
    public final static String XPERSON_XBATCHIND_NULL = "1100362";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XOccupation is not correct
     *
     * @generated
     */
    public final static String INVALID_XPERSON_XOCCUPATION = "1101230";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XBirthDateFS is not correct
     *
     * @generated
     */
    public final static String INVALID_XPERSON_XBIRTHDATEFS = "1104343";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * LastActivityDate is not correct
     *
     * @generated
     */
    public final static String INVALID_XPERSON_LASTACTIVITYDATE = "1110395";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XLastModifiedSystemDate is not correct
     *
     * @generated
     */
    public final static String INVALID_XPERSON_XLASTMODIFIEDSYSTEMDATE = "1102927";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XPerson insert failed.
     *
     * @generated
     */
    public final static String INSERT_EXTENSION_XPERSON_FAILED = "1100034";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XPerson delete failed.
     *
     * @generated
     */
    public final static String DELETE_EXTENSION_XPERSON_FAILED = "1100038";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XPerson read failed.
     *
     * @generated
     */
    public final static String READ_EXTENSION_XPERSON_FAILED = "1100042";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XPerson update failed.
     *
     * @generated
     */
    public final static String UPDATE_EXTENSION_XPERSON_FAILED = "1100046";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: XMarketName
     *
     * @generated
     */
    public final static String XORG_XMARKETNAME_NULL = "1100354";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: XBatchInd
     *
     * @generated
     */
    public final static String XORG_XBATCHIND_NULL = "1100370";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XNumberOfEmployees is not correct
     *
     * @generated
     */
    public final static String INVALID_XORG_XNUMBEROFEMPLOYEES = "1101243";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XLastModifiedSystemDate is not correct
     *
     * @generated
     */
    public final static String INVALID_XORG_XLASTMODIFIEDSYSTEMDATE = "1103024";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XCorporateCategory is not correct
     *
     * @generated
     */
    public final static String INVALID_XORG_XCORPORATECATEGORY = "1104887";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XCorporateGroup is not correct
     *
     * @generated
     */
    public final static String INVALID_XORG_XCORPORATEGROUP = "1104900";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * LastActivityDate is not correct
     *
     * @generated
     */
    public final static String INVALID_XORG_LASTACTIVITYDATE = "1110407";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XOrg insert failed.
     *
     * @generated
     */
    public final static String INSERT_EXTENSION_XORG_FAILED = "1100083";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XOrg delete failed.
     *
     * @generated
     */
    public final static String DELETE_EXTENSION_XORG_FAILED = "1100087";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XOrg read failed.
     *
     * @generated
     */
    public final static String READ_EXTENSION_XORG_FAILED = "1100091";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XOrg update failed.
     *
     * @generated
     */
    public final static String UPDATE_EXTENSION_XORG_FAILED = "1100095";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XAddressVerificationDate is not correct
     *
     * @generated
     */
    public final static String INVALID_XADDRESS_XADDRESSVERIFICATIONDATE = "1100320";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XSubcity is not correct
     *
     * @generated
     */
    public final static String INVALID_XADDRESS_XSUBCITY = "1100869";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XDistrict is not correct
     *
     * @generated
     */
    public final static String INVALID_XADDRESS_XDISTRICT = "1100882";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XAddress insert failed.
     *
     * @generated
     */
    public final static String INSERT_EXTENSION_XADDRESS_FAILED = "1100132";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XAddress delete failed.
     *
     * @generated
     */
    public final static String DELETE_EXTENSION_XADDRESS_FAILED = "1100136";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XAddress read failed.
     *
     * @generated
     */
    public final static String READ_EXTENSION_XADDRESS_FAILED = "1100140";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XAddress update failed.
     *
     * @generated
     */
    public final static String UPDATE_EXTENSION_XADDRESS_FAILED = "1100144";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XVerified is not correct
     *
     * @generated
     */
    public final static String INVALID_XADDRESSGROUP_XVERIFIED = "1100895";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: XAddressRetailerFlag
     *
     * @generated
     */
    public final static String XADDRESSGROUP_XADDRESSRETAILERFLAG_NULL = "1103192";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XLastModifiedSystemDate is not correct
     *
     * @generated
     */
    public final static String INVALID_XADDRESSGROUP_XLASTMODIFIEDSYSTEMDATE = "1103020";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XAddressGroup insert failed.
     *
     * @generated
     */
    public final static String INSERT_EXTENSION_XADDRESSGROUP_FAILED = "1100173";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XAddressGroup delete failed.
     *
     * @generated
     */
    public final static String DELETE_EXTENSION_XADDRESSGROUP_FAILED = "1100177";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XAddressGroup read failed.
     *
     * @generated
     */
    public final static String READ_EXTENSION_XADDRESSGROUP_FAILED = "1100181";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XAddressGroup update failed.
     *
     * @generated
     */
    public final static String UPDATE_EXTENSION_XADDRESSGROUP_FAILED = "1100185";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XVerified is not correct
     *
     * @generated
     */
    public final static String INVALID_XCONTACTMETHODGROUP_XVERIFIED = "1100908";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XLastModifiedSystemDate is not correct
     *
     * @generated
     */
    public final static String INVALID_XCONTACTMETHODGROUP_XLASTMODIFIEDSYSTEMDATE = "1103057";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XContactMethodGroup insert failed.
     *
     * @generated
     */
    public final static String INSERT_EXTENSION_XCONTACTMETHODGROUP_FAILED = "1100214";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XContactMethodGroup delete failed.
     *
     * @generated
     */
    public final static String DELETE_EXTENSION_XCONTACTMETHODGROUP_FAILED = "1100218";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XContactMethodGroup read failed.
     *
     * @generated
     */
    public final static String READ_EXTENSION_XCONTACTMETHODGROUP_FAILED = "1100222";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XContactMethodGroup update failed.
     *
     * @generated
     */
    public final static String UPDATE_EXTENSION_XCONTACTMETHODGROUP_FAILED = "1100226";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XSourceIdentifier is not correct
     *
     * @generated
     */
    public final static String INVALID_XCONTACTREL_XSOURCEIDENTIFIER = "1100379";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XLastModifiedSystemDate is not correct
     *
     * @generated
     */
    public final static String INVALID_XCONTACTREL_XLASTMODIFIEDSYSTEMDATE = "1103122";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XContactRel insert failed.
     *
     * @generated
     */
    public final static String INSERT_EXTENSION_XCONTACTREL_FAILED = "1100255";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XContactRel delete failed.
     *
     * @generated
     */
    public final static String DELETE_EXTENSION_XCONTACTREL_FAILED = "1100259";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XContactRel read failed.
     *
     * @generated
     */
    public final static String READ_EXTENSION_XCONTACTREL_FAILED = "1100263";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XContactRel update failed.
     *
     * @generated
     */
    public final static String UPDATE_EXTENSION_XCONTACTREL_FAILED = "1100267";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XLastModifiedSystemDate is not correct
     *
     * @generated
     */
    public final static String INVALID_XPERSONNAME_XLASTMODIFIEDSYSTEMDATE = "1102939";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XPersonName insert failed.
     *
     * @generated
     */
    public final static String INSERT_EXTENSION_XPERSONNAME_FAILED = "1100296";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XPersonName delete failed.
     *
     * @generated
     */
    public final static String DELETE_EXTENSION_XPERSONNAME_FAILED = "1100300";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XPersonName read failed.
     *
     * @generated
     */
    public final static String READ_EXTENSION_XPERSONNAME_FAILED = "1100304";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XPersonName update failed.
     *
     * @generated
     */
    public final static String UPDATE_EXTENSION_XPERSONNAME_FAILED = "1100308";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XLastModifiedSystemDate is not correct
     *
     * @generated
     */
    public final static String INVALID_XORGNAME_XLASTMODIFIEDSYSTEMDATE = "1103000";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XOrgName insert failed.
     *
     * @generated
     */
    public final static String INSERT_EXTENSION_XORGNAME_FAILED = "1102976";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XOrgName delete failed.
     *
     * @generated
     */
    public final static String DELETE_EXTENSION_XORGNAME_FAILED = "1102980";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XOrgName read failed.
     *
     * @generated
     */
    public final static String READ_EXTENSION_XORGNAME_FAILED = "1102984";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XOrgName update failed.
     *
     * @generated
     */
    public final static String UPDATE_EXTENSION_XORGNAME_FAILED = "1102988";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XLastModifiedSystemDate is not correct
     *
     * @generated
     */
    public final static String INVALID_XIDENTIFIER_XLASTMODIFIEDSYSTEMDATE = "1103110";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XIdentifier insert failed.
     *
     * @generated
     */
    public final static String INSERT_EXTENSION_XIDENTIFIER_FAILED = "1103086";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XIdentifier delete failed.
     *
     * @generated
     */
    public final static String DELETE_EXTENSION_XIDENTIFIER_FAILED = "1103090";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XIdentifier read failed.
     *
     * @generated
     */
    public final static String READ_EXTENSION_XIDENTIFIER_FAILED = "1103094";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XIdentifier update failed.
     *
     * @generated
     */
    public final static String UPDATE_EXTENSION_XIDENTIFIER_FAILED = "1103098";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XContract insert failed.
     *
     * @generated
     */
    public final static String INSERT_EXTENSION_XCONTRACT_FAILED = "1101326";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XContract delete failed.
     *
     * @generated
     */
    public final static String DELETE_EXTENSION_XCONTRACT_FAILED = "1101330";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XContract read failed.
     *
     * @generated
     */
    public final static String READ_EXTENSION_XCONTRACT_FAILED = "1101334";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XContract update failed.
     *
     * @generated
     */
    public final static String UPDATE_EXTENSION_XCONTRACT_FAILED = "1101338";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XSourceIdentifier is not correct
     *
     * @generated
     */
    public final static String INVALID_XCONTRACTROLE_XSOURCEIDENTIFIER = "1101394";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XContractRole insert failed.
     *
     * @generated
     */
    public final static String INSERT_EXTENSION_XCONTRACTROLE_FAILED = "1101375";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XContractRole delete failed.
     *
     * @generated
     */
    public final static String DELETE_EXTENSION_XCONTRACTROLE_FAILED = "1101379";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XContractRole read failed.
     *
     * @generated
     */
    public final static String READ_EXTENSION_XCONTRACTROLE_FAILED = "1101383";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XContractRole update failed.
     *
     * @generated
     */
    public final static String UPDATE_EXTENSION_XCONTRACTROLE_FAILED = "1101387";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XContactMethod insert failed.
     *
     * @generated
     */
    public final static String INSERT_EXTENSION_XCONTACTMETHOD_FAILED = "1103820";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XContactMethod delete failed.
     *
     * @generated
     */
    public final static String DELETE_EXTENSION_XCONTACTMETHOD_FAILED = "1103824";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XContactMethod read failed.
     *
     * @generated
     */
    public final static String READ_EXTENSION_XCONTACTMETHOD_FAILED = "1103828";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XContactMethod update failed.
     *
     * @generated
     */
    public final static String UPDATE_EXTENSION_XCONTACTMETHOD_FAILED = "1103832";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XLastModifiedSystemDate is not correct
     *
     * @generated
     */
    public final static String INVALID_XCONTEQUIV_XLASTMODIFIEDSYSTEMDATE = "1107792";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: subcity_tp_cd
     *
     * @generated
     */
    public final static String XCDSUBCITY_SUBCITY_TP_CD_NULL = "1100430";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: name
     *
     * @generated
     */
    public final static String XCDSUBCITY_NAME_NULL = "1100438";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: district_tp_cd
     *
     * @generated
     */
    public final static String XCDDISTRICT_DISTRICT_TP_CD_NULL = "1100483";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: name
     *
     * @generated
     */
    public final static String XCDDISTRICT_NAME_NULL = "1100491";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: preference_tp_cd
     *
     * @generated
     */
    public final static String XCDPREFERENCE_PREFERENCE_TP_CD_NULL = "1100536";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: name
     *
     * @generated
     */
    public final static String XCDPREFERENCE_NAME_NULL = "1100544";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: verified_tp_cd
     *
     * @generated
     */
    public final static String XCDVERIFIED_VERIFIED_TP_CD_NULL = "1100589";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: name
     *
     * @generated
     */
    public final static String XCDVERIFIED_NAME_NULL = "1100597";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: occupation_tp_cd
     *
     * @generated
     */
    public final static String XCDOCCUPATION_OCCUPATION_TP_CD_NULL = "1100695";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: name
     *
     * @generated
     */
    public final static String XCDOCCUPATION_NAME_NULL = "1100703";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: numofemp_tp_cd
     *
     * @generated
     */
    public final static String XCDNUMBEROFEMPLOYEES_NUMOFEMP_TP_CD_NULL = "1100748";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: name
     *
     * @generated
     */
    public final static String XCDNUMBEROFEMPLOYEES_NAME_NULL = "1100756";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: action_tp_cd
     *
     * @generated
     */
    public final static String XCDACTION_ACTION_TP_CD_NULL = "1100854";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: name
     *
     * @generated
     */
    public final static String XCDACTION_NAME_NULL = "1100862";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: retailer_role_tp_cd
     *
     * @generated
     */
    public final static String XCDRETAILERROLE_RETAILER_ROLE_TP_CD_NULL = "1101445";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: name
     *
     * @generated
     */
    public final static String XCDRETAILERROLE_NAME_NULL = "1101453";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: vehicle_sales_tp_cd
     *
     * @generated
     */
    public final static String XCDVEHICLESALES_VEHICLE_SALES_TP_CD_NULL = "1101551";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: name
     *
     * @generated
     */
    public final static String XCDVEHICLESALES_NAME_NULL = "1101559";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: connectme_usage_tp_cd
     *
     * @generated
     */
    public final static String XCDCONNECTMEUSAGE_CONNECTME_USAGE_TP_CD_NULL = "1101498";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: name
     *
     * @generated
     */
    public final static String XCDCONNECTMEUSAGE_NAME_NULL = "1101506";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: vehicle_usage_tp_cd
     *
     * @generated
     */
    public final static String XCDVEHICLEUSAGE_VEHICLE_USAGE_TP_CD_NULL = "1101604";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: name
     *
     * @generated
     */
    public final static String XCDVEHICLEUSAGE_NAME_NULL = "1101612";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: vehicle_owner_tp_cd
     *
     * @generated
     */
    public final static String XCDVEHICLEOWNERSHIP_VEHICLE_OWNER_TP_CD_NULL = "1101657";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: name
     *
     * @generated
     */
    public final static String XCDVEHICLEOWNERSHIP_NAME_NULL = "1101665";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: vehicle_role_tp_cd
     *
     * @generated
     */
    public final static String XCDVEHICLEROLE_VEHICLE_ROLE_TP_CD_NULL = "1101710";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: name
     *
     * @generated
     */
    public final static String XCDVEHICLEROLE_NAME_NULL = "1101718";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: PreferencepkId
     *
     * @generated
     */
    public final static String XPREFERENCE_PREFERENCEPKID_NULL = "1100948";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: LocationGroupId
     *
     * @generated
     */
    public final static String XPREFERENCE_LOCATIONGROUPID_NULL = "1101015";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Preferred is not correct
     *
     * @generated
     */
    public final static String INVALID_XPREFERENCE_PREFERRED = "1101146";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * SourceIdentifier is not correct
     *
     * @generated
     */
    public final static String INVALID_XPREFERENCE_SOURCEIDENTIFIER = "1102858";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * StartDate is not correct
     *
     * @generated
     */
    public final static String INVALID_XPREFERENCE_STARTDATE = "1102876";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * EndDate is not correct
     *
     * @generated
     */
    public final static String INVALID_XPREFERENCE_ENDDATE = "1102888";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * LastModifiedSystemDate is not correct
     *
     * @generated
     */
    public final static String INVALID_XPREFERENCE_LASTMODIFIEDSYSTEMDATE = "1103134";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The before image of XPreference is empty.
     *
     * @generated
     */
    public final static String XPREFERENCE_BEFORE_IMAGE_NOT_POPULATED = "1100952";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * An attempt to read the XPreference failed.
     *
     * @generated
     */
    public final static String GETXPREFERENCE_FAILED = "1100969";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The id is null.
     *
     * @generated
     */
    public final static String GETXPREFERENCE_ID_NULL = "1100973";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The format of inquireAsOfDate is not correct.
     *
     * @generated
     */
    public final static String GETXPREFERENCE_INVALID_INQUIRE_AS_OF_DATE_FORMAT = "1100977";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * An attempt to read the XPreference failed.
     *
     * @generated
     */
    public final static String GETXPREFERENCEBYLOCATIONGROUPID_FAILED = "1101034";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The id is null.
     *
     * @generated
     */
    public final static String GETXPREFERENCEBYLOCATIONGROUPID_ID_NULL = "1101038";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The format of inquireAsOfDate is not correct.
     *
     * @generated
     */
    public final static String GETXPREFERENCEBYLOCATIONGROUPID_INVALID_INQUIRE_AS_OF_DATE_FORMAT = "1101042";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XPreference insert failed.
     *
     * @generated
     */
    public final static String ADDXPREFERENCE_FAILED = "1100992";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Duplicate primary key already exists.
     *
     * @generated
     */
    public final static String DUPLICATE_PRIMARY_KEY_XPREFERENCE = "1100996";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XPreference update failed.
     *
     * @generated
     */
    public final static String UPDATEXPREFERENCE_FAILED = "1101009";
    
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XPreference delete failed.
     *
     * @generated NOT
     */
    public final static String DELETEXPREFERENCE_FAILED = "11010098";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: PrivacyAgreementpkId
     *
     * @generated
     */
    public final static String XPRIVACYAGREEMENT_PRIVACYAGREEMENTPKID_NULL = "1101078";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: LocationGroupId
     *
     * @generated
     */
    public final static String XPRIVACYAGREEMENT_LOCATIONGROUPID_NULL = "1102851";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Action is not correct
     *
     * @generated
     */
    public final static String INVALID_XPRIVACYAGREEMENT_ACTION = "1101159";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * SourceIdentifier is not correct
     *
     * @generated
     */
    public final static String INVALID_XPRIVACYAGREEMENT_SOURCEIDENTIFIER = "1101172";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * StartDate is not correct
     *
     * @generated
     */
    public final static String INVALID_XPRIVACYAGREEMENT_STARTDATE = "1101190";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * EndDate is not correct
     *
     * @generated
     */
    public final static String INVALID_XPRIVACYAGREEMENT_ENDDATE = "1101202";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * LastModifiedSystemDate is not correct
     *
     * @generated
     */
    public final static String INVALID_XPRIVACYAGREEMENT_LASTMODIFIEDSYSTEMDATE = "1103146";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The before image of XPrivacyAgreement is empty.
     *
     * @generated
     */
    public final static String XPRIVACYAGREEMENT_BEFORE_IMAGE_NOT_POPULATED = "1101082";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * An attempt to read the XPrivacyAgreement failed.
     *
     * @generated
     */
    public final static String GETXPRIVACYAGREEMENT_FAILED = "1101099";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The id is null.
     *
     * @generated
     */
    public final static String GETXPRIVACYAGREEMENT_ID_NULL = "1101103";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The format of inquireAsOfDate is not correct.
     *
     * @generated
     */
    public final static String GETXPRIVACYAGREEMENT_INVALID_INQUIRE_AS_OF_DATE_FORMAT = "1101107";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * An attempt to read the XPrivacyAgreement failed.
     *
     * @generated
     */
    public final static String GETXPRIVAGREEMENTBYLOCATIONGROUPID_FAILED = "1101274";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The id is null.
     *
     * @generated
     */
    public final static String GETXPRIVAGREEMENTBYLOCATIONGROUPID_ID_NULL = "1101278";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The format of inquireAsOfDate is not correct.
     *
     * @generated
     */
    public final static String GETXPRIVAGREEMENTBYLOCATIONGROUPID_INVALID_INQUIRE_AS_OF_DATE_FORMAT = "1101282";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XPrivacyAgreement insert failed.
     *
     * @generated
     */
    public final static String ADDXPRIVACYAGREEMENT_FAILED = "1101122";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Duplicate primary key already exists.
     *
     * @generated
     */
    public final static String DUPLICATE_PRIMARY_KEY_XPRIVACYAGREEMENT = "1101126";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XPrivacyAgreement update failed.
     *
     * @generated
     */
    public final static String UPDATEXPRIVACYAGREEMENT_FAILED = "1101139";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: RetailerpkId
     *
     * @generated
     */
    public final static String XRETAILER_RETAILERPKID_NULL = "1101752";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: RetailerCode
     *
     * @generated
     */
    public final static String XRETAILER_RETAILERCODE_NULL = "1101819";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * SourceIdentifier is not correct
     *
     * @generated
     */
    public final static String INVALID_XRETAILER_SOURCEIDENTIFIER = "1102499";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * LastModifiedSystemDate is not correct
     *
     * @generated
     */
    public final static String INVALID_XRETAILER_LASTMODIFIEDSYSTEMDATE = "1103166";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * CreateDate is not correct
     *
     * @generated
     */
    public final static String INVALID_XRETAILER_CREATEDATE = "1107603";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * ChangedDate is not correct
     *
     * @generated
     */
    public final static String INVALID_XRETAILER_CHANGEDDATE = "1107642";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The before image of XRetailer is empty.
     *
     * @generated
     */
    public final static String XRETAILER_BEFORE_IMAGE_NOT_POPULATED = "1101756";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * An attempt to read the XRetailer failed.
     *
     * @generated
     */
    public final static String GETXRETAILER_FAILED = "1101773";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The id is null.
     *
     * @generated
     */
    public final static String GETXRETAILER_ID_NULL = "1101777";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The format of inquireAsOfDate is not correct.
     *
     * @generated
     */
    public final static String GETXRETAILER_INVALID_INQUIRE_AS_OF_DATE_FORMAT = "1101781";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * An attempt to read the XRetailer failed.
     *
     * @generated
     */
    public final static String GETXRETAILERBYRETAILERCODE_FAILED = "1103243";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The id is null.
     *
     * @generated
     */
    public final static String GETXRETAILERBYRETAILERCODE_ID_NULL = "1103247";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The format of inquireAsOfDate is not correct.
     *
     * @generated
     */
    public final static String GETXRETAILERBYRETAILERCODE_INVALID_INQUIRE_AS_OF_DATE_FORMAT = "1103251";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * An attempt to read the XRetailer failed.
     *
     * @generated
     */
    public final static String GETXRETAILERBYNDCODE_FAILED = "1107628";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The id is null.
     *
     * @generated
     */
    public final static String GETXRETAILERBYNDCODE_ID_NULL = "1107632";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The format of inquireAsOfDate is not correct.
     *
     * @generated
     */
    public final static String GETXRETAILERBYNDCODE_INVALID_INQUIRE_AS_OF_DATE_FORMAT = "1107636";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * An attempt to read the XRetailer failed.
     *
     * @generated
     */
    public final static String GETXRETAILERBYGSCODE_FAILED = "1107667";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The id is null.
     *
     * @generated
     */
    public final static String GETXRETAILERBYGSCODE_ID_NULL = "1107671";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The format of inquireAsOfDate is not correct.
     *
     * @generated
     */
    public final static String GETXRETAILERBYGSCODE_INVALID_INQUIRE_AS_OF_DATE_FORMAT = "1107675";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * An attempt to read the XRetailer failed.
     *
     * @generated
     */
    public final static String GETXRETAILERBYGSCODEANDMARKETNAME_FAILED = "1107694";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The id is null.
     *
     * @generated
     */
    public final static String GETXRETAILERBYGSCODEANDMARKETNAME_ID_NULL = "1107698";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The format of inquireAsOfDate is not correct.
     *
     * @generated
     */
    public final static String GETXRETAILERBYGSCODEANDMARKETNAME_INVALID_INQUIRE_AS_OF_DATE_FORMAT = "1107702";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * An attempt to read the XRetailer failed.
     *
     * @generated
     */
    public final static String GETXRETAILERBYRETAILERCODEANDMARKETNAME_FAILED = "1107723";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The id is null.
     *
     * @generated
     */
    public final static String GETXRETAILERBYRETAILERCODEANDMARKETNAME_ID_NULL = "1107727";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The format of inquireAsOfDate is not correct.
     *
     * @generated
     */
    public final static String GETXRETAILERBYRETAILERCODEANDMARKETNAME_INVALID_INQUIRE_AS_OF_DATE_FORMAT = "1107731";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * An attempt to read the XRetailer failed.
     *
     * @generated
     */
    public final static String GETXRETAILERBYNDCODEANDMARKETNAME_FAILED = "1107752";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The id is null.
     *
     * @generated
     */
    public final static String GETXRETAILERBYNDCODEANDMARKETNAME_ID_NULL = "1107756";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The format of inquireAsOfDate is not correct.
     *
     * @generated
     */
    public final static String GETXRETAILERBYNDCODEANDMARKETNAME_INVALID_INQUIRE_AS_OF_DATE_FORMAT = "1107760";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XRetailer insert failed.
     *
     * @generated
     */
    public final static String ADDXRETAILER_FAILED = "1101796";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Duplicate primary key already exists.
     *
     * @generated
     */
    public final static String DUPLICATE_PRIMARY_KEY_XRETAILER = "1101800";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XRetailer update failed.
     *
     * @generated
     */
    public final static String UPDATEXRETAILER_FAILED = "1101813";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: CustomerRetailerpkId
     *
     * @generated
     */
    public final static String XCUSTOMERRETAILER_CUSTOMERRETAILERPKID_NULL = "1102083";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * SourceIdentifier is not correct
     *
     * @generated
     */
    public final static String INVALID_XCUSTOMERRETAILER_SOURCEIDENTIFIER = "1102486";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * StartDate is not correct
     *
     * @generated
     */
    public final static String INVALID_XCUSTOMERRETAILER_STARTDATE = "1102653";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * EndDate is not correct
     *
     * @generated
     */
    public final static String INVALID_XCUSTOMERRETAILER_ENDDATE = "1102665";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The before image of XCustomerRetailer is empty.
     *
     * @generated
     */
    public final static String XCUSTOMERRETAILER_BEFORE_IMAGE_NOT_POPULATED = "1102087";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * In a one-to-many containment, the reference in the child object has a value which does not match the parent object during an update transaction.
     *
     * @generated
     */
    public final static String XCUSTOMERRETAILER_XRETAILER_REFERENCE_INVALID = "1102735";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * In a one-to-many containment, the reference in the child object has a value which does not match the parent object during an update transaction.
     *
     * @generated
     */
    public final static String XCUSTOMERRETAILER_XCUSTOMERRETAILERROLE_REFERENCE_INVALID = "1102749";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * An attempt to read the XCustomerRetailer failed.
     *
     * @generated
     */
    public final static String GETXCUSTOMERRETAILER_FAILED = "1102104";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The id is null.
     *
     * @generated
     */
    public final static String GETXCUSTOMERRETAILER_ID_NULL = "1102108";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The format of inquireAsOfDate is not correct.
     *
     * @generated
     */
    public final static String GETXCUSTOMERRETAILER_INVALID_INQUIRE_AS_OF_DATE_FORMAT = "1102112";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * An attempt to read the XCustomerRetailer failed.
     *
     * @generated
     */
    public final static String GETALLXCUSTOMERRETAILERBYPARTYID_FAILED = "1102905";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The id is null.
     *
     * @generated
     */
    public final static String GETALLXCUSTOMERRETAILERBYPARTYID_ID_NULL = "1102909";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The format of inquireAsOfDate is not correct.
     *
     * @generated
     */
    public final static String GETALLXCUSTOMERRETAILERBYPARTYID_INVALID_INQUIRE_AS_OF_DATE_FORMAT = "1102913";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XCustomerRetailer insert failed.
     *
     * @generated
     */
    public final static String ADDXCUSTOMERRETAILER_FAILED = "1102127";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Duplicate primary key already exists.
     *
     * @generated
     */
    public final static String DUPLICATE_PRIMARY_KEY_XCUSTOMERRETAILER = "1102131";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XCustomerRetailer update failed.
     *
     * @generated
     */
    public final static String UPDATEXCUSTOMERRETAILER_FAILED = "1102144";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: CustomerRetailerRolepkId
     *
     * @generated
     */
    public final static String XCUSTOMERRETAILERROLE_CUSTOMERRETAILERROLEPKID_NULL = "1102178";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * RetailerRole is not correct
     *
     * @generated
     */
    public final static String INVALID_XCUSTOMERRETAILERROLE_RETAILERROLE = "1102436";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * SourceIdentifier is not correct
     *
     * @generated
     */
    public final static String INVALID_XCUSTOMERRETAILERROLE_SOURCEIDENTIFIER = "1102449";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * StartDate is not correct
     *
     * @generated
     */
    public final static String INVALID_XCUSTOMERRETAILERROLE_STARTDATE = "1102467";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * EndDate is not correct
     *
     * @generated
     */
    public final static String INVALID_XCUSTOMERRETAILERROLE_ENDDATE = "1102479";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The before image of XCustomerRetailerRole is empty.
     *
     * @generated
     */
    public final static String XCUSTOMERRETAILERROLE_BEFORE_IMAGE_NOT_POPULATED = "1102182";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * An attempt to read the XCustomerRetailerRole failed.
     *
     * @generated
     */
    public final static String GETXCUSTOMERRETAILERROLE_FAILED = "1102199";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The id is null.
     *
     * @generated
     */
    public final static String GETXCUSTOMERRETAILERROLE_ID_NULL = "1102203";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The format of inquireAsOfDate is not correct.
     *
     * @generated
     */
    public final static String GETXCUSTOMERRETAILERROLE_INVALID_INQUIRE_AS_OF_DATE_FORMAT = "1102207";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * An attempt to read the XCustomerRetailerRole failed.
     *
     * @generated
     */
    public final static String GETALLRETAILERROLEBYCUSTOMERRETAILERID_FAILED = "1102782";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The id is null.
     *
     * @generated
     */
    public final static String GETALLRETAILERROLEBYCUSTOMERRETAILERID_ID_NULL = "1102786";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The format of inquireAsOfDate is not correct.
     *
     * @generated
     */
    public final static String GETALLRETAILERROLEBYCUSTOMERRETAILERID_INVALID_INQUIRE_AS_OF_DATE_FORMAT = "1102790";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XCustomerRetailerRole insert failed.
     *
     * @generated
     */
    public final static String ADDXCUSTOMERRETAILERROLE_FAILED = "1102222";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Duplicate primary key already exists.
     *
     * @generated
     */
    public final static String DUPLICATE_PRIMARY_KEY_XCUSTOMERRETAILERROLE = "1102226";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XCustomerRetailerRole update failed.
     *
     * @generated
     */
    public final static String UPDATEXCUSTOMERRETAILERROLE_FAILED = "1102239";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: VehiclepkId
     *
     * @generated
     */
    public final static String XVEHICLE_VEHICLEPKID_NULL = "1101879";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Country is not correct
     *
     * @generated
     */
    public final static String INVALID_XVEHICLE_COUNTRY = "1102043";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * SourceIdentifier is not correct
     *
     * @generated
     */
    public final static String INVALID_XVEHICLE_SOURCEIDENTIFIER = "1102512";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * LastModifiedSystemDate is not correct
     *
     * @generated
     */
    public final static String INVALID_XVEHICLE_LASTMODIFIEDSYSTEMDATE = "1103186";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * CreateDate is not correct
     *
     * @generated
     */
    public final static String INVALID_XVEHICLE_CREATEDATE = "1103214";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * ChangedDate is not correct
     *
     * @generated
     */
    public final static String INVALID_XVEHICLE_CHANGEDDATE = "1103226";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * LastServiceDate is not correct
     *
     * @generated
     */
    public final static String INVALID_XVEHICLE_LASTSERVICEDATE = "1103386";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The before image of XVehicle is empty.
     *
     * @generated
     */
    public final static String XVEHICLE_BEFORE_IMAGE_NOT_POPULATED = "1101883";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * An attempt to read the XVehicle failed.
     *
     * @generated
     */
    public final static String GETXVEHICLE_FAILED = "1101900";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The id is null.
     *
     * @generated
     */
    public final static String GETXVEHICLE_ID_NULL = "1101904";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The format of inquireAsOfDate is not correct.
     *
     * @generated
     */
    public final static String GETXVEHICLE_INVALID_INQUIRE_AS_OF_DATE_FORMAT = "1101908";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XVehicle insert failed.
     *
     * @generated
     */
    public final static String ADDXVEHICLE_FAILED = "1101923";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Duplicate primary key already exists.
     *
     * @generated
     */
    public final static String DUPLICATE_PRIMARY_KEY_XVEHICLE = "1101927";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XVehicle update failed.
     *
     * @generated
     */
    public final static String UPDATEXVEHICLE_FAILED = "1101940";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: CustomerVehiclepkId
     *
     * @generated
     */
    public final static String XCUSTOMERVEHICLE_CUSTOMERVEHICLEPKID_NULL = "1102273";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * ConnectMeUsage is not correct
     *
     * @generated
     */
    public final static String INVALID_XCUSTOMERVEHICLE_CONNECTMEUSAGE = "1102575";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * SourceIdentifier is not correct
     *
     * @generated
     */
    public final static String INVALID_XCUSTOMERVEHICLE_SOURCEIDENTIFIER = "1102596";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * VehicleSales is not correct
     *
     * @generated
     */
    public final static String INVALID_XCUSTOMERVEHICLE_VEHICLESALES = "1102609";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * VehicleUsage is not correct
     *
     * @generated
     */
    public final static String INVALID_XCUSTOMERVEHICLE_VEHICLEUSAGE = "1102622";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * StartDate is not correct
     *
     * @generated
     */
    public final static String INVALID_XCUSTOMERVEHICLE_STARTDATE = "1102677";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * EndDate is not correct
     *
     * @generated
     */
    public final static String INVALID_XCUSTOMERVEHICLE_ENDDATE = "1102689";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The before image of XCustomerVehicle is empty.
     *
     * @generated
     */
    public final static String XCUSTOMERVEHICLE_BEFORE_IMAGE_NOT_POPULATED = "1102277";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * In a one-to-many containment, the reference in the child object has a value which does not match the parent object during an update transaction.
     *
     * @generated
     */
    public final static String XCUSTOMERVEHICLE_XVEHICLE_REFERENCE_INVALID = "1102833";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * In a one-to-many containment, the reference in the child object has a value which does not match the parent object during an update transaction.
     *
     * @generated
     */
    public final static String XCUSTOMERVEHICLE_XCUSTOMERVEHICLEROLE_REFERENCE_INVALID = "1102847";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * An attempt to read the XCustomerVehicle failed.
     *
     * @generated
     */
    public final static String GETXCUSTOMERVEHICLE_FAILED = "1102294";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The id is null.
     *
     * @generated
     */
    public final static String GETXCUSTOMERVEHICLE_ID_NULL = "1102298";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The format of inquireAsOfDate is not correct.
     *
     * @generated
     */
    public final static String GETXCUSTOMERVEHICLE_INVALID_INQUIRE_AS_OF_DATE_FORMAT = "1102302";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * An attempt to read the XCustomerVehicle failed.
     *
     * @generated
     */
    public final static String GETALLXCUSTOMERVEHICLEBYPARTYID_FAILED = "1104744";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The id is null.
     *
     * @generated
     */
    public final static String GETALLXCUSTOMERVEHICLEBYPARTYID_ID_NULL = "1104748";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The format of inquireAsOfDate is not correct.
     *
     * @generated
     */
    public final static String GETALLXCUSTOMERVEHICLEBYPARTYID_INVALID_INQUIRE_AS_OF_DATE_FORMAT = "1104752";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XCustomerVehicle insert failed.
     *
     * @generated
     */
    public final static String ADDXCUSTOMERVEHICLE_FAILED = "1102317";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Duplicate primary key already exists.
     *
     * @generated
     */
    public final static String DUPLICATE_PRIMARY_KEY_XCUSTOMERVEHICLE = "1102321";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XCustomerVehicle update failed.
     *
     * @generated
     */
    public final static String UPDATEXCUSTOMERVEHICLE_FAILED = "1102334";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: CustomerVehicleRolepkId
     *
     * @generated
     */
    public final static String XCUSTOMERVEHICLEROLE_CUSTOMERVEHICLEROLEPKID_NULL = "1102368";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * VehicleRole is not correct
     *
     * @generated
     */
    public final static String INVALID_XCUSTOMERVEHICLEROLE_VEHICLEROLE = "1102525";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * SourceIdentifier is not correct
     *
     * @generated
     */
    public final static String INVALID_XCUSTOMERVEHICLEROLE_SOURCEIDENTIFIER = "1102538";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * ChangedDate is not correct
     *
     * @generated
     */
    public final static String INVALID_XCUSTOMERVEHICLEROLE_CHANGEDDATE = "1105597";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * StartDate is not correct
     *
     * @generated
     */
    public final static String INVALID_XCUSTOMERVEHICLEROLE_STARTDATE = "1102556";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * EndDate is not correct
     *
     * @generated
     */
    public final static String INVALID_XCUSTOMERVEHICLEROLE_ENDDATE = "1102568";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The before image of XCustomerVehicleRole is empty.
     *
     * @generated
     */
    public final static String XCUSTOMERVEHICLEROLE_BEFORE_IMAGE_NOT_POPULATED = "1102372";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * An attempt to read the XCustomerVehicleRole failed.
     *
     * @generated
     */
    public final static String GETXCUSTOMERVEHICLEROLE_FAILED = "1102389";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The id is null.
     *
     * @generated
     */
    public final static String GETXCUSTOMERVEHICLEROLE_ID_NULL = "1102393";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The format of inquireAsOfDate is not correct.
     *
     * @generated
     */
    public final static String GETXCUSTOMERVEHICLEROLE_INVALID_INQUIRE_AS_OF_DATE_FORMAT = "1102397";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * An attempt to read the XCustomerVehicleRole failed.
     *
     * @generated
     */
    public final static String GETALLVEHICLEROLEBYCUSTOMERVEHICLEID_FAILED = "1102809";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The id is null.
     *
     * @generated
     */
    public final static String GETALLVEHICLEROLEBYCUSTOMERVEHICLEID_ID_NULL = "1102813";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The format of inquireAsOfDate is not correct.
     *
     * @generated
     */
    public final static String GETALLVEHICLEROLEBYCUSTOMERVEHICLEID_INVALID_INQUIRE_AS_OF_DATE_FORMAT = "1102817";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XCustomerVehicleRole insert failed.
     *
     * @generated
     */
    public final static String ADDXCUSTOMERVEHICLEROLE_FAILED = "1102412";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Duplicate primary key already exists.
     *
     * @generated
     */
    public final static String DUPLICATE_PRIMARY_KEY_XCUSTOMERVEHICLEROLE = "1102416";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XCustomerVehicleRole update failed.
     *
     * @generated
     */
    public final static String UPDATEXCUSTOMERVEHICLEROLE_FAILED = "1102429";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XContEquiv insert failed.
     *
     * @generated
     */
    public final static String INSERT_EXTENSION_XCONTEQUIV_FAILED = "1103338";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XContEquiv delete failed.
     *
     * @generated
     */
    public final static String DELETE_EXTENSION_XCONTEQUIV_FAILED = "1103342";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XContEquiv read failed.
     *
     * @generated
     */
    public final static String READ_EXTENSION_XCONTEQUIV_FAILED = "1103346";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XContEquiv update failed.
     *
     * @generated
     */
    public final static String UPDATE_EXTENSION_XCONTEQUIV_FAILED = "1103350";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: CompanyIdentificationpkId
     *
     * @generated
     */
    public final static String XCOMPANYIDENTIFICATION_COMPANYIDENTIFICATIONPKID_NULL = "1103420";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The before image of XCompanyIdentification is empty.
     *
     * @generated
     */
    public final static String XCOMPANYIDENTIFICATION_BEFORE_IMAGE_NOT_POPULATED = "1103424";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * An attempt to read the XCompanyIdentification failed.
     *
     * @generated
     */
    public final static String GETXCOMPANYIDENTIFICATION_FAILED = "1103441";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The id is null.
     *
     * @generated
     */
    public final static String GETXCOMPANYIDENTIFICATION_ID_NULL = "1103445";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The format of inquireAsOfDate is not correct.
     *
     * @generated
     */
    public final static String GETXCOMPANYIDENTIFICATION_INVALID_INQUIRE_AS_OF_DATE_FORMAT = "1103449";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XCompanyIdentification insert failed.
     *
     * @generated
     */
    public final static String ADDXCOMPANYIDENTIFICATION_FAILED = "1103464";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Duplicate primary key already exists.
     *
     * @generated
     */
    public final static String DUPLICATE_PRIMARY_KEY_XCOMPANYIDENTIFICATION = "1103468";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XCompanyIdentification update failed.
     *
     * @generated
     */
    public final static String UPDATEXCOMPANYIDENTIFICATION_FAILED = "1103481";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: ContractpkId
     *
     * @generated
     */
    public final static String XCONTRACTDETAILS_CONTRACTPKID_NULL = "1103523";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * ContractStatus is not correct
     *
     * @generated
     */
    public final static String INVALID_XCONTRACTDETAILS_CONTRACTSTATUS = "1103644";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Country is not correct
     *
     * @generated
     */
    public final static String INVALID_XCONTRACTDETAILS_COUNTRY = "1103761";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * SourceIdentifier is not correct
     *
     * @generated
     */
    public final static String INVALID_XCONTRACTDETAILS_SOURCEIDENTIFIER = "1103631";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * StartDate is not correct
     *
     * @generated
     */
    public final static String INVALID_XCONTRACTDETAILS_STARTDATE = "1103612";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * EndDate is not correct
     *
     * @generated
     */
    public final static String INVALID_XCONTRACTDETAILS_ENDDATE = "1103624";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * LastModifiedSystemDate is not correct
     *
     * @generated
     */
    public final static String INVALID_XCONTRACTDETAILS_LASTMODIFIEDSYSTEMDATE = "1104676";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The before image of XContractDetails is empty.
     *
     * @generated
     */
    public final static String XCONTRACTDETAILS_BEFORE_IMAGE_NOT_POPULATED = "1103527";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * In a one-to-many containment, the reference in the child object has a value which does not match the parent object during an update transaction.
     *
     * @generated
     */
    public final static String XCONTRACTDETAILS_GUARANTORDETAILS_REFERENCE_INVALID = "1105571";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * In a one-to-many containment, the reference in the child object has a value which does not match the parent object during an update transaction.
     *
     * @generated
     */
    public final static String XCONTRACTDETAILS_COBORROWERDETAILS_REFERENCE_INVALID = "1105577";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * An attempt to read the XContractDetails failed.
     *
     * @generated
     */
    public final static String GETXCONTRACTDETAILS_FAILED = "1103544";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The id is null.
     *
     * @generated
     */
    public final static String GETXCONTRACTDETAILS_ID_NULL = "1103548";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The format of inquireAsOfDate is not correct.
     *
     * @generated
     */
    public final static String GETXCONTRACTDETAILS_INVALID_INQUIRE_AS_OF_DATE_FORMAT = "1103552";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * An attempt to read the XContractDetails failed.
     *
     * @generated
     */
    public final static String GETALLXCONTRACTDETAILSBYPARTYID_FAILED = "1104717";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The id is null.
     *
     * @generated
     */
    public final static String GETALLXCONTRACTDETAILSBYPARTYID_ID_NULL = "1104721";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The format of inquireAsOfDate is not correct.
     *
     * @generated
     */
    public final static String GETALLXCONTRACTDETAILSBYPARTYID_INVALID_INQUIRE_AS_OF_DATE_FORMAT = "1104725";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XContractDetails insert failed.
     *
     * @generated
     */
    public final static String ADDXCONTRACTDETAILS_FAILED = "1103567";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Duplicate primary key already exists.
     *
     * @generated
     */
    public final static String DUPLICATE_PRIMARY_KEY_XCONTRACTDETAILS = "1103571";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XContractDetails update failed.
     *
     * @generated
     */
    public final static String UPDATEXCONTRACTDETAILS_FAILED = "1103584";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: XGurantorIndividualpkId
     *
     * @generated
     */
    public final static String XGURANTORINDIVIDUAL_XGURANTORINDIVIDUALPKID_NULL = "1103890";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Title is not correct
     *
     * @generated
     */
    public final static String INVALID_XGURANTORINDIVIDUAL_TITLE = "1104114";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * BirthDate is not correct
     *
     * @generated
     */
    public final static String INVALID_XGURANTORINDIVIDUAL_BIRTHDATE = "1104164";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * AddressUsage is not correct
     *
     * @generated
     */
    public final static String INVALID_XGURANTORINDIVIDUAL_ADDRESSUSAGE = "1104171";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Country is not correct
     *
     * @generated
     */
    public final static String INVALID_XGURANTORINDIVIDUAL_COUNTRY = "1104248";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * SourceIdentifier is not correct
     *
     * @generated
     */
    public final static String INVALID_XGURANTORINDIVIDUAL_SOURCEIDENTIFIER = "1104309";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * StartDate is not correct
     *
     * @generated
     */
    public final static String INVALID_XGURANTORINDIVIDUAL_STARTDATE = "1104466";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * EndDate is not correct
     *
     * @generated
     */
    public final static String INVALID_XGURANTORINDIVIDUAL_ENDDATE = "1104478";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * LastModifiedSystemDate is not correct
     *
     * @generated
     */
    public final static String INVALID_XGURANTORINDIVIDUAL_LASTMODIFIEDSYSTEMDATE = "1104696";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The before image of XGurantorIndividual is empty.
     *
     * @generated
     */
    public final static String XGURANTORINDIVIDUAL_BEFORE_IMAGE_NOT_POPULATED = "1103894";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * An attempt to read the XGurantorIndividual failed.
     *
     * @generated
     */
    public final static String GETXGURANTORINDIVIDUAL_FAILED = "1103911";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The id is null.
     *
     * @generated
     */
    public final static String GETXGURANTORINDIVIDUAL_ID_NULL = "1103915";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The format of inquireAsOfDate is not correct.
     *
     * @generated
     */
    public final static String GETXGURANTORINDIVIDUAL_INVALID_INQUIRE_AS_OF_DATE_FORMAT = "1103919";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * An attempt to read the XGurantorIndividual failed.
     *
     * @generated
     */
    public final static String GETALLXGURANTORINDIVIDUALBYCONTRACTDETAILSID_FAILED = "1104403";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The id is null.
     *
     * @generated
     */
    public final static String GETALLXGURANTORINDIVIDUALBYCONTRACTDETAILSID_ID_NULL = "1104407";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The format of inquireAsOfDate is not correct.
     *
     * @generated
     */
    public final static String GETALLXGURANTORINDIVIDUALBYCONTRACTDETAILSID_INVALID_INQUIRE_AS_OF_DATE_FORMAT = "1104411";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XGurantorIndividual insert failed.
     *
     * @generated
     */
    public final static String ADDXGURANTORINDIVIDUAL_FAILED = "1103934";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Duplicate primary key already exists.
     *
     * @generated
     */
    public final static String DUPLICATE_PRIMARY_KEY_XGURANTORINDIVIDUAL = "1103938";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XGurantorIndividual update failed.
     *
     * @generated
     */
    public final static String UPDATEXGURANTORINDIVIDUAL_FAILED = "1103951";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: XGurantorCompanypkId
     *
     * @generated
     */
    public final static String XGURANTORCOMPANY_XGURANTORCOMPANYPKID_NULL = "1103985";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Industry is not correct
     *
     * @generated
     */
    public final static String INVALID_XGURANTORCOMPANY_INDUSTRY = "1104069";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * AddressUsage is not correct
     *
     * @generated
     */
    public final static String INVALID_XGURANTORCOMPANY_ADDRESSUSAGE = "1104533";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Country is not correct
     *
     * @generated
     */
    public final static String INVALID_XGURANTORCOMPANY_COUNTRY = "1104594";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * SourceIdentifier is not correct
     *
     * @generated
     */
    public final static String INVALID_XGURANTORCOMPANY_SOURCEIDENTIFIER = "1104350";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * StartDate is not correct
     *
     * @generated
     */
    public final static String INVALID_XGURANTORCOMPANY_STARTDATE = "1104490";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * EndDate is not correct
     *
     * @generated
     */
    public final static String INVALID_XGURANTORCOMPANY_ENDDATE = "1104502";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * LastModifiedSystemDate is not correct
     *
     * @generated
     */
    public final static String INVALID_XGURANTORCOMPANY_LASTMODIFIEDSYSTEMDATE = "1104700";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The before image of XGurantorCompany is empty.
     *
     * @generated
     */
    public final static String XGURANTORCOMPANY_BEFORE_IMAGE_NOT_POPULATED = "1103989";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * An attempt to read the XGurantorCompany failed.
     *
     * @generated
     */
    public final static String GETXGURANTORCOMPANY_FAILED = "1104006";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The id is null.
     *
     * @generated
     */
    public final static String GETXGURANTORCOMPANY_ID_NULL = "1104010";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The format of inquireAsOfDate is not correct.
     *
     * @generated
     */
    public final static String GETXGURANTORCOMPANY_INVALID_INQUIRE_AS_OF_DATE_FORMAT = "1104014";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * An attempt to read the XGurantorCompany failed.
     *
     * @generated
     */
    public final static String GETALLXGURANTORCOMPANYBYCONTRACTDETAILSID_FAILED = "1104444";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The id is null.
     *
     * @generated
     */
    public final static String GETALLXGURANTORCOMPANYBYCONTRACTDETAILSID_ID_NULL = "1104448";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The format of inquireAsOfDate is not correct.
     *
     * @generated
     */
    public final static String GETALLXGURANTORCOMPANYBYCONTRACTDETAILSID_INVALID_INQUIRE_AS_OF_DATE_FORMAT = "1104452";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XGurantorCompany insert failed.
     *
     * @generated
     */
    public final static String ADDXGURANTORCOMPANY_FAILED = "1104029";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Duplicate primary key already exists.
     *
     * @generated
     */
    public final static String DUPLICATE_PRIMARY_KEY_XGURANTORCOMPANY = "1104033";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XGurantorCompany update failed.
     *
     * @generated
     */
    public final static String UPDATEXGURANTORCOMPANY_FAILED = "1104046";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: corp_cat_tp_cd
     *
     * @generated
     */
    public final static String XCORPORATECATEGORY_CORP_CAT_TP_CD_NULL = "1104819";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: name
     *
     * @generated
     */
    public final static String XCORPORATECATEGORY_NAME_NULL = "1104827";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: corp_group_tp_cd
     *
     * @generated
     */
    public final static String XCORPORATEGROUP_CORP_GROUP_TP_CD_NULL = "1104872";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: name
     *
     * @generated
     */
    public final static String XCORPORATEGROUP_NAME_NULL = "1104880";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: XDealerRetailerpkId
     *
     * @generated
     */
    public final static String XDEALERRETAILER_XDEALERRETAILERPKID_NULL = "1104980";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The before image of XDealerRetailer is empty.
     *
     * @generated
     */
    public final static String XDEALERRETAILER_BEFORE_IMAGE_NOT_POPULATED = "1104984";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * An attempt to read the XDealerRetailer failed.
     *
     * @generated
     */
    public final static String GETXDEALERRETAILER_FAILED = "1105001";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The id is null.
     *
     * @generated
     */
    public final static String GETXDEALERRETAILER_ID_NULL = "1105005";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The format of inquireAsOfDate is not correct.
     *
     * @generated
     */
    public final static String GETXDEALERRETAILER_INVALID_INQUIRE_AS_OF_DATE_FORMAT = "1105009";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XDealerRetailer insert failed.
     *
     * @generated
     */
    public final static String ADDXDEALERRETAILER_FAILED = "1105024";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Duplicate primary key already exists.
     *
     * @generated
     */
    public final static String DUPLICATE_PRIMARY_KEY_XDEALERRETAILER = "1105028";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XDealerRetailer update failed.
     *
     * @generated
     */
    public final static String UPDATEXDEALERRETAILER_FAILED = "1105041";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: XMagicRelpkId
     *
     * @generated
     */
    public final static String XMAGICREL_XMAGICRELPKID_NULL = "1105091";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The before image of XMagicRel is empty.
     *
     * @generated
     */
    public final static String XMAGICREL_BEFORE_IMAGE_NOT_POPULATED = "1105095";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * An attempt to read the XMagicRel failed.
     *
     * @generated
     */
    public final static String GETXMAGICREL_FAILED = "1105112";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The id is null.
     *
     * @generated
     */
    public final static String GETXMAGICREL_ID_NULL = "1105116";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The format of inquireAsOfDate is not correct.
     *
     * @generated
     */
    public final static String GETXMAGICREL_INVALID_INQUIRE_AS_OF_DATE_FORMAT = "1105120";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XMagicRel insert failed.
     *
     * @generated
     */
    public final static String ADDXMAGICREL_FAILED = "1105135";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Duplicate primary key already exists.
     *
     * @generated
     */
    public final static String DUPLICATE_PRIMARY_KEY_XMAGICREL = "1105139";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XMagicRel update failed.
     *
     * @generated
     */
    public final static String UPDATEXMAGICREL_FAILED = "1105152";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: XConsentpkId
     *
     * @generated
     */
    public final static String XCONSENT_XCONSENTPKID_NULL = "1105218";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * ConsentAction is not correct
     *
     * @generated
     */
    public final static String INVALID_XCONSENT_CONSENTACTION = "1105302";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * SourceIdentifier is not correct
     *
     * @generated
     */
    public final static String INVALID_XCONSENT_SOURCEIDENTIFIER = "1105315";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * LastModifiedSystemDate is not correct
     *
     * @generated
     */
    public final static String INVALID_XCONSENT_LASTMODIFIEDSYSTEMDATE = "1105345";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The before image of XConsent is empty.
     *
     * @generated
     */
    public final static String XCONSENT_BEFORE_IMAGE_NOT_POPULATED = "1105222";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * An attempt to read the XConsent failed.
     *
     * @generated
     */
    public final static String GETXCONSENT_FAILED = "1105239";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The id is null.
     *
     * @generated
     */
    public final static String GETXCONSENT_ID_NULL = "1105243";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The format of inquireAsOfDate is not correct.
     *
     * @generated
     */
    public final static String GETXCONSENT_INVALID_INQUIRE_AS_OF_DATE_FORMAT = "1105247";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * An attempt to read the XConsent failed.
     *
     * @generated
     */
    public final static String GETXCONSENTBYCONTID_FAILED = "1105362";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The id is null.
     *
     * @generated
     */
    public final static String GETXCONSENTBYCONTID_ID_NULL = "1105366";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The format of inquireAsOfDate is not correct.
     *
     * @generated
     */
    public final static String GETXCONSENTBYCONTID_INVALID_INQUIRE_AS_OF_DATE_FORMAT = "1105370";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XConsent insert failed.
     *
     * @generated
     */
    public final static String ADDXCONSENT_FAILED = "1105262";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Duplicate primary key already exists.
     *
     * @generated
     */
    public final static String DUPLICATE_PRIMARY_KEY_XCONSENT = "1105266";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XConsent update failed.
     *
     * @generated
     */
    public final static String UPDATEXCONSENT_FAILED = "1105279";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: XContractRelpkId
     *
     * @generated
     */
    public final static String XCONTRACTREL_XCONTRACTRELPKID_NULL = "1105406";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * StartDate is not correct
     *
     * @generated
     */
    public final static String INVALID_XCONTRACTREL_STARTDATE = "1105519";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * EndDate is not correct
     *
     * @generated
     */
    public final static String INVALID_XCONTRACTREL_ENDDATE = "1105533";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The before image of XContractRel is empty.
     *
     * @generated
     */
    public final static String XCONTRACTREL_BEFORE_IMAGE_NOT_POPULATED = "1105410";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * An attempt to read the XContractRel failed.
     *
     * @generated
     */
    public final static String GETXCONTRACTREL_FAILED = "1105427";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The id is null.
     *
     * @generated
     */
    public final static String GETXCONTRACTREL_ID_NULL = "1105431";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The format of inquireAsOfDate is not correct.
     *
     * @generated
     */
    public final static String GETXCONTRACTREL_INVALID_INQUIRE_AS_OF_DATE_FORMAT = "1105435";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XContractRel insert failed.
     *
     * @generated
     */
    public final static String ADDXCONTRACTREL_FAILED = "1105450";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Duplicate primary key already exists.
     *
     * @generated
     */
    public final static String DUPLICATE_PRIMARY_KEY_XCONTRACTREL = "1105454";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XContractRel update failed.
     *
     * @generated
     */
    public final static String UPDATEXCONTRACTREL_FAILED = "1105467";
    
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: XCustomerRetailerJPNpkId
     *
     * @generated
     */
    public final static String XCUSTOMERRETAILERJPN_XCUSTOMERRETAILERJPNPKID_NULL = "1105867";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * SourceIdentifier is not correct
     *
     * @generated
     */
    public final static String INVALID_XCUSTOMERRETAILERJPN_SOURCEIDENTIFIER = "1105951";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * StartDate is not correct
     *
     * @generated
     */
    public final static String INVALID_XCUSTOMERRETAILERJPN_STARTDATE = "1105969";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * EndDate is not correct
     *
     * @generated
     */
    public final static String INVALID_XCUSTOMERRETAILERJPN_ENDDATE = "1105981";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The before image of XCustomerRetailerJPN is empty.
     *
     * @generated
     */
    public final static String XCUSTOMERRETAILERJPN_BEFORE_IMAGE_NOT_POPULATED = "1105871";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * In a one-to-many containment, the reference in the child object has a value which does not match the parent object during an update transaction.
     *
     * @generated
     */
    public final static String XCUSTOMERRETAILERJPN_XRETAILER_REFERENCE_INVALID = "1107543";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * An attempt to read the XCustomerRetailerJPN failed.
     *
     * @generated
     */
    public final static String GETXCUSTOMERRETAILERJPN_FAILED = "1105888";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The id is null.
     *
     * @generated
     */
    public final static String GETXCUSTOMERRETAILERJPN_ID_NULL = "1105892";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The format of inquireAsOfDate is not correct.
     *
     * @generated
     */
    public final static String GETXCUSTOMERRETAILERJPN_INVALID_INQUIRE_AS_OF_DATE_FORMAT = "1105896";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * An attempt to read the XCustomerRetailerJPN failed.
     *
     * @generated
     */
    public final static String GETALLXCUSTOMERRETAILERJPNBYPARTYID_FAILED = "1106909";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The id is null.
     *
     * @generated
     */
    public final static String GETALLXCUSTOMERRETAILERJPNBYPARTYID_ID_NULL = "1106913";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The format of inquireAsOfDate is not correct.
     *
     * @generated
     */
    public final static String GETALLXCUSTOMERRETAILERJPNBYPARTYID_INVALID_INQUIRE_AS_OF_DATE_FORMAT = "1106917";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XCustomerRetailerJPN insert failed.
     *
     * @generated
     */
    public final static String ADDXCUSTOMERRETAILERJPN_FAILED = "1105911";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Duplicate primary key already exists.
     *
     * @generated
     */
    public final static String DUPLICATE_PRIMARY_KEY_XCUSTOMERRETAILERJPN = "1105915";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XCustomerRetailerJPN update failed.
     *
     * @generated
     */
    public final static String UPDATEXCUSTOMERRETAILERJPN_FAILED = "1105928";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: XVehicleJPNpkId
     *
     * @generated
     */
    public final static String XVEHICLEJPN_XVEHICLEJPNPKID_NULL = "1106221";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * SourceIdentifier is not correct
     *
     * @generated
     */
    public final static String INVALID_XVEHICLEJPN_SOURCEIDENTIFIER = "1106353";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * LastModifiedSystemDate is not correct
     *
     * @generated
     */
    public final static String INVALID_XVEHICLEJPN_LASTMODIFIEDSYSTEMDATE = "1107484";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * CreateDate is not correct
     *
     * @generated
     */
    public final static String INVALID_XVEHICLEJPN_CREATEDATE = "1106383";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * ChangedDate is not correct
     *
     * @generated
     */
    public final static String INVALID_XVEHICLEJPN_CHANGEDDATE = "1106395";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * LastServiceDate is not correct
     *
     * @generated
     */
    public final static String INVALID_XVEHICLEJPN_LASTSERVICEDATE = "1106407";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * EndDate is not correct
     *
     * @generated
     */
    public final static String INVALID_XVEHICLEJPN_ENDDATE = "1107852";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The before image of XVehicleJPN is empty.
     *
     * @generated
     */
    public final static String XVEHICLEJPN_BEFORE_IMAGE_NOT_POPULATED = "1106225";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * An attempt to read the XVehicleJPN failed.
     *
     * @generated
     */
    public final static String GETXVEHICLEJPN_FAILED = "1106242";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The id is null.
     *
     * @generated
     */
    public final static String GETXVEHICLEJPN_ID_NULL = "1106246";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The format of inquireAsOfDate is not correct.
     *
     * @generated
     */
    public final static String GETXVEHICLEJPN_INVALID_INQUIRE_AS_OF_DATE_FORMAT = "1106250";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * An attempt to read the XVehicleJPN failed.
     *
     * @generated
     */
    public final static String GETXVEHICLEJPNBYGLOBALVIN_FAILED = "1106944";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The id is null.
     *
     * @generated
     */
    public final static String GETXVEHICLEJPNBYGLOBALVIN_ID_NULL = "1106948";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The format of inquireAsOfDate is not correct.
     *
     * @generated
     */
    public final static String GETXVEHICLEJPNBYGLOBALVIN_INVALID_INQUIRE_AS_OF_DATE_FORMAT = "1106952";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XVehicleJPN insert failed.
     *
     * @generated
     */
    public final static String ADDXVEHICLEJPN_FAILED = "1106265";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Duplicate primary key already exists.
     *
     * @generated
     */
    public final static String DUPLICATE_PRIMARY_KEY_XVEHICLEJPN = "1106269";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XVehicleJPN update failed.
     *
     * @generated
     */
    public final static String UPDATEXVEHICLEJPN_FAILED = "1106282";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: XCustomerVehicleJPNpkId
     *
     * @generated
     */
    public final static String XCUSTOMERVEHICLEJPN_XCUSTOMERVEHICLEJPNPKID_NULL = "1106441";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * ConnectMeUsage is not correct
     *
     * @generated
     */
    public final static String INVALID_XCUSTOMERVEHICLEJPN_CONNECTMEUSAGE = "1106698";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * VehicleSales is not correct
     *
     * @generated
     */
    public final static String INVALID_XCUSTOMERVEHICLEJPN_VEHICLESALES = "1106719";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * VehicleUsage is not correct
     *
     * @generated
     */
    public final static String INVALID_XCUSTOMERVEHICLEJPN_VEHICLEUSAGE = "1106732";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * StartDate is not correct
     *
     * @generated
     */
    public final static String INVALID_XCUSTOMERVEHICLEJPN_STARTDATE = "1106758";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * EndDate is not correct
     *
     * @generated
     */
    public final static String INVALID_XCUSTOMERVEHICLEJPN_ENDDATE = "1106770";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * SourceIdentifier is not correct
     *
     * @generated
     */
    public final static String INVALID_XCUSTOMERVEHICLEJPN_SOURCEIDENTIFIER = "1106777";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The before image of XCustomerVehicleJPN is empty.
     *
     * @generated
     */
    public final static String XCUSTOMERVEHICLEJPN_BEFORE_IMAGE_NOT_POPULATED = "1106445";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * In a one-to-many containment, the reference in the child object has a value which does not match the parent object during an update transaction.
     *
     * @generated
     */
    public final static String XCUSTOMERVEHICLEJPN_XVEHICLEJPN_REFERENCE_INVALID = "1106797";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * In a one-to-many containment, the reference in the child object has a value which does not match the parent object during an update transaction.
     *
     * @generated
     */
    public final static String XCUSTOMERVEHICLEJPN_XCUSTOMERVEHICLEROLEJPN_REFERENCE_INVALID = "1106811";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * An attempt to read the XCustomerVehicleJPN failed.
     *
     * @generated
     */
    public final static String GETXCUSTOMERVEHICLEJPN_FAILED = "1106462";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The id is null.
     *
     * @generated
     */
    public final static String GETXCUSTOMERVEHICLEJPN_ID_NULL = "1106466";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The format of inquireAsOfDate is not correct.
     *
     * @generated
     */
    public final static String GETXCUSTOMERVEHICLEJPN_INVALID_INQUIRE_AS_OF_DATE_FORMAT = "1106470";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * An attempt to read the XCustomerVehicleJPN failed.
     *
     * @generated
     */
    public final static String GETALLXCUSTOMERVEHICLEJPNBYPARTYID_FAILED = "1106969";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The id is null.
     *
     * @generated
     */
    public final static String GETALLXCUSTOMERVEHICLEJPNBYPARTYID_ID_NULL = "1106973";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The format of inquireAsOfDate is not correct.
     *
     * @generated
     */
    public final static String GETALLXCUSTOMERVEHICLEJPNBYPARTYID_INVALID_INQUIRE_AS_OF_DATE_FORMAT = "1106977";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * An attempt to read the XCustomerVehicleJPN failed.
     *
     * @generated
     */
    public final static String GETALLCVRBYVEHICLEID_FAILED = "1107877";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The id is null.
     *
     * @generated
     */
    public final static String GETALLCVRBYVEHICLEID_ID_NULL = "1107881";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The format of inquireAsOfDate is not correct.
     *
     * @generated
     */
    public final static String GETALLCVRBYVEHICLEID_INVALID_INQUIRE_AS_OF_DATE_FORMAT = "1107885";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XCustomerVehicleJPN insert failed.
     *
     * @generated
     */
    public final static String ADDXCUSTOMERVEHICLEJPN_FAILED = "1106485";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Duplicate primary key already exists.
     *
     * @generated
     */
    public final static String DUPLICATE_PRIMARY_KEY_XCUSTOMERVEHICLEJPN = "1106489";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XCustomerVehicleJPN update failed.
     *
     * @generated
     */
    public final static String UPDATEXCUSTOMERVEHICLEJPN_FAILED = "1106502";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: XCustomerVehicleRoleJPNpkId
     *
     * @generated
     */
    public final static String XCUSTOMERVEHICLEROLEJPN_XCUSTOMERVEHICLEROLEJPNPKID_NULL = "1106536";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * VehicleRole is not correct
     *
     * @generated
     */
    public final static String INVALID_XCUSTOMERVEHICLEROLEJPN_VEHICLEROLE = "1106612";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * StartDate is not correct
     *
     * @generated
     */
    public final static String INVALID_XCUSTOMERVEHICLEROLEJPN_STARTDATE = "1106630";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * EndDate is not correct
     *
     * @generated
     */
    public final static String INVALID_XCUSTOMERVEHICLEROLEJPN_ENDDATE = "1106642";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * SourceIdentifier is not correct
     *
     * @generated
     */
    public final static String INVALID_XCUSTOMERVEHICLEROLEJPN_SOURCEIDENTIFIER = "1106649";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * ChangedDate is not correct
     *
     * @generated
     */
    public final static String INVALID_XCUSTOMERVEHICLEROLEJPN_CHANGEDDATE = "1106667";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The before image of XCustomerVehicleRoleJPN is empty.
     *
     * @generated
     */
    public final static String XCUSTOMERVEHICLEROLEJPN_BEFORE_IMAGE_NOT_POPULATED = "1106540";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * An attempt to read the XCustomerVehicleRoleJPN failed.
     *
     * @generated
     */
    public final static String GETXCUSTOMERVEHICLEROLEJPN_FAILED = "1106557";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The id is null.
     *
     * @generated
     */
    public final static String GETXCUSTOMERVEHICLEROLEJPN_ID_NULL = "1106561";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The format of inquireAsOfDate is not correct.
     *
     * @generated
     */
    public final static String GETXCUSTOMERVEHICLEROLEJPN_INVALID_INQUIRE_AS_OF_DATE_FORMAT = "1106565";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * An attempt to read the XCustomerVehicleRoleJPN failed.
     *
     * @generated
     */
    public final static String GETALLVEHICLEROLEBYCUSTOMERVEHICLEJPNID_FAILED = "1106828";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The id is null.
     *
     * @generated
     */
    public final static String GETALLVEHICLEROLEBYCUSTOMERVEHICLEJPNID_ID_NULL = "1106832";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The format of inquireAsOfDate is not correct.
     *
     * @generated
     */
    public final static String GETALLVEHICLEROLEBYCUSTOMERVEHICLEJPNID_INVALID_INQUIRE_AS_OF_DATE_FORMAT = "1106836";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XCustomerVehicleRoleJPN insert failed.
     *
     * @generated
     */
    public final static String ADDXCUSTOMERVEHICLEROLEJPN_FAILED = "1106580";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Duplicate primary key already exists.
     *
     * @generated
     */
    public final static String DUPLICATE_PRIMARY_KEY_XCUSTOMERVEHICLEROLEJPN = "1106584";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XCustomerVehicleRoleJPN update failed.
     *
     * @generated
     */
    public final static String UPDATEXCUSTOMERVEHICLEROLEJPN_FAILED = "1106597";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: DataSharingpkId
     *
     * @generated
     */
    public final static String XDATASHARING_DATASHARINGPKID_NULL = "1107015";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * GCUpdateDate is not correct
     *
     * @generated
     */
    public final static String INVALID_XDATASHARING_GCUPDATEDATE = "1110435";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * WSDataSharingUpdateDate is not correct
     *
     * @generated
     */
    public final static String INVALID_XDATASHARING_WSDATASHARINGUPDATEDATE = "1110455";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * SourceIdentifier is not correct
     *
     * @generated
     */
    public final static String INVALID_XDATASHARING_SOURCEIDENTIFIER = "1107115";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * StartDate is not correct
     *
     * @generated
     */
    public final static String INVALID_XDATASHARING_STARTDATE = "1107133";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * LastModifiedSystemDate is not correct
     *
     * @generated
     */
    public final static String INVALID_XDATASHARING_LASTMODIFIEDSYSTEMDATE = "1107145";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The before image of XDataSharing is empty.
     *
     * @generated
     */
    public final static String XDATASHARING_BEFORE_IMAGE_NOT_POPULATED = "1107019";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * An attempt to read the XDataSharing failed.
     *
     * @generated
     */
    public final static String GETXDATASHARING_FAILED = "1107036";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The id is null.
     *
     * @generated
     */
    public final static String GETXDATASHARING_ID_NULL = "1107040";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The format of inquireAsOfDate is not correct.
     *
     * @generated
     */
    public final static String GETXDATASHARING_INVALID_INQUIRE_AS_OF_DATE_FORMAT = "1107044";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * An attempt to read the XDataSharing failed.
     *
     * @generated
     */
    public final static String GETDATASHARINGBYPARTYID_FAILED = "1107258";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The id is null.
     *
     * @generated
     */
    public final static String GETDATASHARINGBYPARTYID_ID_NULL = "1107262";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The format of inquireAsOfDate is not correct.
     *
     * @generated
     */
    public final static String GETDATASHARINGBYPARTYID_INVALID_INQUIRE_AS_OF_DATE_FORMAT = "1107266";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XDataSharing insert failed.
     *
     * @generated
     */
    public final static String ADDXDATASHARING_FAILED = "1107059";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Duplicate primary key already exists.
     *
     * @generated
     */
    public final static String DUPLICATE_PRIMARY_KEY_XDATASHARING = "1107063";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XDataSharing update failed.
     *
     * @generated
     */
    public final static String UPDATEXDATASHARING_FAILED = "1107076";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: XVehicleKORpkId
     *
     * @generated
     */
    public final static String XVEHICLEKOR_XVEHICLEKORPKID_NULL = "1107921";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * LastModifiedSystemDate is not correct
     *
     * @generated
     */
    public final static String INVALID_XVEHICLEKOR_LASTMODIFIEDSYSTEMDATE = "1108071";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * CreateDate is not correct
     *
     * @generated
     */
    public final static String INVALID_XVEHICLEKOR_CREATEDATE = "1108083";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * ChangedDate is not correct
     *
     * @generated
     */
    public final static String INVALID_XVEHICLEKOR_CHANGEDDATE = "1108095";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * LastServiceDate is not correct
     *
     * @generated
     */
    public final static String INVALID_XVEHICLEKOR_LASTSERVICEDATE = "1108107";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * EndDate is not correct
     *
     * @generated
     */
    public final static String INVALID_XVEHICLEKOR_ENDDATE = "1108151";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * SourceIdentifier is not correct
     *
     * @generated
     */
    public final static String INVALID_XVEHICLEKOR_SOURCEIDENTIFIER = "1108193";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: SourceIdentifier
     *
     * @generated
     */
    public final static String XVEHICLEKOR_SOURCEIDENTIFIER_NULL = "1108197";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The before image of XVehicleKOR is empty.
     *
     * @generated
     */
    public final static String XVEHICLEKOR_BEFORE_IMAGE_NOT_POPULATED = "1107925";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * An attempt to read the XVehicleKOR failed.
     *
     * @generated
     */
    public final static String GETXVEHICLEKOR_FAILED = "1107942";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The id is null.
     *
     * @generated
     */
    public final static String GETXVEHICLEKOR_ID_NULL = "1107946";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The format of inquireAsOfDate is not correct.
     *
     * @generated
     */
    public final static String GETXVEHICLEKOR_INVALID_INQUIRE_AS_OF_DATE_FORMAT = "1107950";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * An attempt to read the XVehicleKOR failed.
     *
     * @generated
     */
    public final static String GETXVEHICLEKORBYGLOBALVIN_FAILED = "1108176";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The id is null.
     *
     * @generated
     */
    public final static String GETXVEHICLEKORBYGLOBALVIN_ID_NULL = "1108180";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The format of inquireAsOfDate is not correct.
     *
     * @generated
     */
    public final static String GETXVEHICLEKORBYGLOBALVIN_INVALID_INQUIRE_AS_OF_DATE_FORMAT = "1108184";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XVehicleKOR insert failed.
     *
     * @generated
     */
    public final static String ADDXVEHICLEKOR_FAILED = "1107965";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Duplicate primary key already exists.
     *
     * @generated
     */
    public final static String DUPLICATE_PRIMARY_KEY_XVEHICLEKOR = "1107969";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XVehicleKOR update failed.
     *
     * @generated
     */
    public final static String UPDATEXVEHICLEKOR_FAILED = "1107982";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: groupName
     *
     * @generated
     */
    public final static String XCUSTOMERVEHICLEKOR_GROUPNAME_NULL = "1108678";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: groupName
     *
     * @generated
     */
    //public final static String XCUSTOMERVEHICLEKOR_GROUPNAME_NULL = "1108678";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: XCustomerVehicleKORpkId
     *
     * @generated
     */
    public final static String XCUSTOMERVEHICLEKOR_XCUSTOMERVEHICLEKORPKID_NULL = "1108233";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * ConnectMeUsage is not correct
     *
     * @generated
     */
    public final static String INVALID_XCUSTOMERVEHICLEKOR_CONNECTMEUSAGE = "1108325";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * VehicleSales is not correct
     *
     * @generated
     */
    public final static String INVALID_XCUSTOMERVEHICLEKOR_VEHICLESALES = "1108346";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * VehicleUsage is not correct
     *
     * @generated
     */
    public final static String INVALID_XCUSTOMERVEHICLEKOR_VEHICLEUSAGE = "1108359";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * StartDate is not correct
     *
     * @generated
     */
    public final static String INVALID_XCUSTOMERVEHICLEKOR_STARTDATE = "1108385";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * EndDate is not correct
     *
     * @generated
     */
    public final static String INVALID_XCUSTOMERVEHICLEKOR_ENDDATE = "1108397";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * SourceIdentifier is not correct
     *
     * @generated
     */
    public final static String INVALID_XCUSTOMERVEHICLEKOR_SOURCEIDENTIFIER = "1108404";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The before image of XCustomerVehicleKOR is empty.
     *
     * @generated
     */
    public final static String XCUSTOMERVEHICLEKOR_BEFORE_IMAGE_NOT_POPULATED = "1108237";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * In a one-to-many containment, the reference in the child object has a value which does not match the parent object during an update transaction.
     *
     * @generated
     */
    public final static String XCUSTOMERVEHICLEKOR_XVEHICLEKOR_REFERENCE_INVALID = "1108456";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * In a one-to-many containment, the reference in the child object has a value which does not match the parent object during an update transaction.
     *
     * @generated
     */
    public final static String XCUSTOMERVEHICLEKOR_XCUSTOMERVEHICLEROLEKOR_REFERENCE_INVALID = "1108470";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * An attempt to read the XCustomerVehicleKOR failed.
     *
     * @generated
     */
    public final static String GETXCUSTOMERVEHICLEKOR_FAILED = "1108254";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The id is null.
     *
     * @generated
     */
    public final static String GETXCUSTOMERVEHICLEKOR_ID_NULL = "1108258";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The format of inquireAsOfDate is not correct.
     *
     * @generated
     */
    public final static String GETXCUSTOMERVEHICLEKOR_INVALID_INQUIRE_AS_OF_DATE_FORMAT = "1108262";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * An attempt to read the XCustomerVehicleKOR failed.
     *
     * @generated
     */
    public final static String GETALLXCUSTOMERVEHICLEKORBYPARTYID_FAILED = "1108695";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The id is null.
     *
     * @generated
     */
    public final static String GETALLXCUSTOMERVEHICLEKORBYPARTYID_ID_NULL = "1108699";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The format of inquireAsOfDate is not correct.
     *
     * @generated
     */
    public final static String GETALLXCUSTOMERVEHICLEKORBYPARTYID_INVALID_INQUIRE_AS_OF_DATE_FORMAT = "1108703";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * An attempt to read the XCustomerVehicleKOR failed.
     *
     * @generated
     */
    public final static String GETALLCVRBYVEHICLE_ID_FAILED = "1108722";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The id is null.
     *
     * @generated
     */
    public final static String GETALLCVRBYVEHICLE_ID_ID_NULL = "1108726";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The format of inquireAsOfDate is not correct.
     *
     * @generated
     */
    public final static String GETALLCVRBYVEHICLE_ID_INVALID_INQUIRE_AS_OF_DATE_FORMAT = "1108730";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XCustomerVehicleKOR insert failed.
     *
     * @generated
     */
    public final static String ADDXCUSTOMERVEHICLEKOR_FAILED = "1108277";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Duplicate primary key already exists.
     *
     * @generated
     */
    public final static String DUPLICATE_PRIMARY_KEY_XCUSTOMERVEHICLEKOR = "1108281";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XCustomerVehicleKOR update failed.
     *
     * @generated
     */
    public final static String UPDATEXCUSTOMERVEHICLEKOR_FAILED = "1108294";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: XCustomerVehicleRoleKORpkId
     *
     * @generated
     */
    public final static String XCUSTOMERVEHICLEROLEKOR_XCUSTOMERVEHICLEROLEKORPKID_NULL = "1108504";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * VehicleRole is not correct
     *
     * @generated
     */
    public final static String INVALID_XCUSTOMERVEHICLEROLEKOR_VEHICLEROLE = "1108588";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * StartDate is not correct
     *
     * @generated
     */
    public final static String INVALID_XCUSTOMERVEHICLEROLEKOR_STARTDATE = "1108606";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * EndDate is not correct
     *
     * @generated
     */
    public final static String INVALID_XCUSTOMERVEHICLEROLEKOR_ENDDATE = "1108618";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * SourceIdentifier is not correct
     *
     * @generated
     */
    public final static String INVALID_XCUSTOMERVEHICLEROLEKOR_SOURCEIDENTIFIER = "1108625";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * ChangedDate is not correct
     *
     * @generated
     */
    public final static String INVALID_XCUSTOMERVEHICLEROLEKOR_CHANGEDDATE = "1108643";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The before image of XCustomerVehicleRoleKOR is empty.
     *
     * @generated
     */
    public final static String XCUSTOMERVEHICLEROLEKOR_BEFORE_IMAGE_NOT_POPULATED = "1108508";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * An attempt to read the XCustomerVehicleRoleKOR failed.
     *
     * @generated
     */
    public final static String GETXCUSTOMERVEHICLEROLEKOR_FAILED = "1108525";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The id is null.
     *
     * @generated
     */
    public final static String GETXCUSTOMERVEHICLEROLEKOR_ID_NULL = "1108529";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The format of inquireAsOfDate is not correct.
     *
     * @generated
     */
    public final static String GETXCUSTOMERVEHICLEROLEKOR_INVALID_INQUIRE_AS_OF_DATE_FORMAT = "1108533";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * An attempt to read the XCustomerVehicleRoleKOR failed.
     *
     * @generated
     */
    public final static String GETALLVEHICLEROLEBYCUSTOMERVEHICLEKORID_FAILED = "1108660";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The id is null.
     *
     * @generated
     */
    public final static String GETALLVEHICLEROLEBYCUSTOMERVEHICLEKORID_ID_NULL = "1108664";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The format of inquireAsOfDate is not correct.
     *
     * @generated
     */
    public final static String GETALLVEHICLEROLEBYCUSTOMERVEHICLEKORID_INVALID_INQUIRE_AS_OF_DATE_FORMAT = "1108668";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XCustomerVehicleRoleKOR insert failed.
     *
     * @generated
     */
    public final static String ADDXCUSTOMERVEHICLEROLEKOR_FAILED = "1108548";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Duplicate primary key already exists.
     *
     * @generated
     */
    public final static String DUPLICATE_PRIMARY_KEY_XCUSTOMERVEHICLEROLEKOR = "1108552";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XCustomerVehicleRoleKOR update failed.
     *
     * @generated
     */
    public final static String UPDATEXCUSTOMERVEHICLEROLEKOR_FAILED = "1108565";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: XEpucidTemppkId
     *
     * @generated
     */
    public final static String XEPUCIDTEMP_XEPUCIDTEMPPKID_NULL = "1108766";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The before image of XEpucidTemp is empty.
     *
     * @generated
     */
    public final static String XEPUCIDTEMP_BEFORE_IMAGE_NOT_POPULATED = "1108770";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * An attempt to read the XEpucidTemp failed.
     *
     * @generated
     */
    public final static String GETXEPUCIDTEMP_FAILED = "1108787";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The id is null.
     *
     * @generated
     */
    public final static String GETXEPUCIDTEMP_ID_NULL = "1108791";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The format of inquireAsOfDate is not correct.
     *
     * @generated
     */
    public final static String GETXEPUCIDTEMP_INVALID_INQUIRE_AS_OF_DATE_FORMAT = "1108795";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XEpucidTemp insert failed.
     *
     * @generated
     */
    public final static String ADDXEPUCIDTEMP_FAILED = "1108810";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Duplicate primary key already exists.
     *
     * @generated
     */
    public final static String DUPLICATE_PRIMARY_KEY_XEPUCIDTEMP = "1108814";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XEpucidTemp update failed.
     *
     * @generated
     */
    public final static String UPDATEXEPUCIDTEMP_FAILED = "1108827";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: XContractJPNpkId
     *
     * @generated
     */
    public final static String XCONTRACTDETAILSJPN_XCONTRACTJPNPKID_NULL = "1108929";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * ContractStatus is not correct
     *
     * @generated
     */
    public final static String INVALID_XCONTRACTDETAILSJPN_CONTRACTSTATUS = "1109021";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * SourceIdentifier is not correct
     *
     * @generated
     */
    public final static String INVALID_XCONTRACTDETAILSJPN_SOURCEIDENTIFIER = "1109042";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * StartDate is not correct
     *
     * @generated
     */
    public final static String INVALID_XCONTRACTDETAILSJPN_STARTDATE = "1109060";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * EndDate is not correct
     *
     * @generated
     */
    public final static String INVALID_XCONTRACTDETAILSJPN_ENDDATE = "1109072";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * LastModifiedSystemDate is not correct
     *
     * @generated
     */
    public final static String INVALID_XCONTRACTDETAILSJPN_LASTMODIFIEDSYSTEMDATE = "1109084";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The before image of XContractDetailsJPN is empty.
     *
     * @generated
     */
    public final static String XCONTRACTDETAILSJPN_BEFORE_IMAGE_NOT_POPULATED = "1108933";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * In a one-to-many containment, the reference in the child object has a value which does not match the parent object during an update transaction.
     *
     * @generated
     */
    public final static String XCONTRACTDETAILSJPN_GUARANTORDETAILSJPN_REFERENCE_INVALID = "1109090";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * In a one-to-many containment, the reference in the child object has a value which does not match the parent object during an update transaction.
     *
     * @generated
     */
    public final static String XCONTRACTDETAILSJPN_FINANCECONTRACTORDETAILSJPN_REFERENCE_INVALID = "1109096";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * An attempt to read the XContractDetailsJPN failed.
     *
     * @generated
     */
    public final static String GETXCONTRACTDETAILSJPN_FAILED = "1108950";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The id is null.
     *
     * @generated
     */
    public final static String GETXCONTRACTDETAILSJPN_ID_NULL = "1108954";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The format of inquireAsOfDate is not correct.
     *
     * @generated
     */
    public final static String GETXCONTRACTDETAILSJPN_INVALID_INQUIRE_AS_OF_DATE_FORMAT = "1108958";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * An attempt to read the XContractDetailsJPN failed.
     *
     * @generated
     */
    public final static String GETALLXCONTRACTDETAILSJPNBYPARTYID_FAILED = "1109280";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The id is null.
     *
     * @generated
     */
    public final static String GETALLXCONTRACTDETAILSJPNBYPARTYID_ID_NULL = "1109284";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The format of inquireAsOfDate is not correct.
     *
     * @generated
     */
    public final static String GETALLXCONTRACTDETAILSJPNBYPARTYID_INVALID_INQUIRE_AS_OF_DATE_FORMAT = "1109288";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XContractDetailsJPN insert failed.
     *
     * @generated
     */
    public final static String ADDXCONTRACTDETAILSJPN_FAILED = "1108973";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Duplicate primary key already exists.
     *
     * @generated
     */
    public final static String DUPLICATE_PRIMARY_KEY_XCONTRACTDETAILSJPN = "1108977";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XContractDetailsJPN update failed.
     *
     * @generated
     */
    public final static String UPDATEXCONTRACTDETAILSJPN_FAILED = "1108990";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: XContractRelJPNpkId
     *
     * @generated
     */
    public final static String XCONTRACTRELJPN_XCONTRACTRELJPNPKID_NULL = "1109138";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * StartDate is not correct
     *
     * @generated
     */
    public final static String INVALID_XCONTRACTRELJPN_STARTDATE = "1109251";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * EndDate is not correct
     *
     * @generated
     */
    public final static String INVALID_XCONTRACTRELJPN_ENDDATE = "1109263";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The before image of XContractRelJPN is empty.
     *
     * @generated
     */
    public final static String XCONTRACTRELJPN_BEFORE_IMAGE_NOT_POPULATED = "1109142";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * An attempt to read the XContractRelJPN failed.
     *
     * @generated
     */
    public final static String GETXCONTRACTRELJPN_FAILED = "1109159";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The id is null.
     *
     * @generated
     */
    public final static String GETXCONTRACTRELJPN_ID_NULL = "1109163";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The format of inquireAsOfDate is not correct.
     *
     * @generated
     */
    public final static String GETXCONTRACTRELJPN_INVALID_INQUIRE_AS_OF_DATE_FORMAT = "1109167";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XContractRelJPN insert failed.
     *
     * @generated
     */
    public final static String ADDXCONTRACTRELJPN_FAILED = "1109182";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Duplicate primary key already exists.
     *
     * @generated
     */
    public final static String DUPLICATE_PRIMARY_KEY_XCONTRACTRELJPN = "1109186";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XContractRelJPN update failed.
     *
     * @generated
     */
    public final static String UPDATEXCONTRACTRELJPN_FAILED = "1109199";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: XVehicleAuspkId
     *
     * @generated
     */
    public final static String XVEHICLEAUS_XVEHICLEAUSPKID_NULL = "1109388";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: GlobalVIN
     *
     * @generated
     */
    public final static String XVEHICLEAUS_GLOBALVIN_NULL = "1109461";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * VehicleYear is not correct
     *
     * @generated
     */
    public final static String INVALID_XVEHICLEAUS_VEHICLEYEAR = "1109513";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * SourceIdentifier is not correct
     *
     * @generated
     */
    public final static String INVALID_XVEHICLEAUS_SOURCEIDENTIFIER = "1109564";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * LastModifiedSystemDate is not correct
     *
     * @generated
     */
    public final static String INVALID_XVEHICLEAUS_LASTMODIFIEDSYSTEMDATE = "1109582";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The before image of XVehicleAus is empty.
     *
     * @generated
     */
    public final static String XVEHICLEAUS_BEFORE_IMAGE_NOT_POPULATED = "1109392";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * An attempt to read the XVehicleAus failed.
     *
     * @generated
     */
    public final static String GETXVEHICLEAUS_FAILED = "1109409";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The id is null.
     *
     * @generated
     */
    public final static String GETXVEHICLEAUS_ID_NULL = "1109413";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The format of inquireAsOfDate is not correct.
     *
     * @generated
     */
    public final static String GETXVEHICLEAUS_INVALID_INQUIRE_AS_OF_DATE_FORMAT = "1109417";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * An attempt to read the XVehicleAus failed.
     *
     * @generated
     */
    public final static String GETXVEHICLEAUSBYGLOBALVINANDMARKETNAME_FAILED = "1110012";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The id is null.
     *
     * @generated
     */
    public final static String GETXVEHICLEAUSBYGLOBALVINANDMARKETNAME_ID_NULL = "1110016";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The format of inquireAsOfDate is not correct.
     *
     * @generated
     */
    public final static String GETXVEHICLEAUSBYGLOBALVINANDMARKETNAME_INVALID_INQUIRE_AS_OF_DATE_FORMAT = "1110020";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XVehicleAus insert failed.
     *
     * @generated
     */
    public final static String ADDXVEHICLEAUS_FAILED = "1109432";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Duplicate primary key already exists.
     *
     * @generated
     */
    public final static String DUPLICATE_PRIMARY_KEY_XVEHICLEAUS = "1109436";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XVehicleAus update failed.
     *
     * @generated
     */
    public final static String UPDATEXVEHICLEAUS_FAILED = "1109449";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: XCustomerVehicleAuspkId
     *
     * @generated
     */
    public final static String XCUSTOMERVEHICLEAUS_XCUSTOMERVEHICLEAUSPKID_NULL = "1109616";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: ContId
     *
     * @generated
     */
    public final static String XCUSTOMERVEHICLEAUS_CONTID_NULL = "1109683";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: VehicleId
     *
     * @generated
     */
    public final static String XCUSTOMERVEHICLEAUS_VEHICLEID_NULL = "1109691";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * PurchaseDate is not correct
     *
     * @generated
     */
    public final static String INVALID_XCUSTOMERVEHICLEAUS_PURCHASEDATE = "1109713";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * EndDate is not correct
     *
     * @generated
     */
    public final static String INVALID_XCUSTOMERVEHICLEAUS_ENDDATE = "1109725";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * SourceIdentifier is not correct
     *
     * @generated
     */
    public final static String INVALID_XCUSTOMERVEHICLEAUS_SOURCEIDENTIFIER = "1109744";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * LastModifiedSystemDate is not correct
     *
     * @generated
     */
    public final static String INVALID_XCUSTOMERVEHICLEAUS_LASTMODIFIEDSYSTEMDATE = "1109762";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The before image of XCustomerVehicleAus is empty.
     *
     * @generated
     */
    public final static String XCUSTOMERVEHICLEAUS_BEFORE_IMAGE_NOT_POPULATED = "1109620";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * In a one-to-many containment, the reference in the child object has a value which does not match the parent object during an update transaction.
     *
     * @generated
     */
    public final static String XCUSTOMERVEHICLEAUS_XVEHICLEAUS_REFERENCE_INVALID = "1110133";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * In a one-to-many containment, the reference in the child object has a value which does not match the parent object during an update transaction.
     *
     * @generated
     */
    public final static String XCUSTOMERVEHICLEAUS_XCUSTOMERVEHICLEROLEAUS_REFERENCE_INVALID = "1110139";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * An attempt to read the XCustomerVehicleAus failed.
     *
     * @generated
     */
    public final static String GETXCUSTOMERVEHICLEAUS_FAILED = "1109637";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The id is null.
     *
     * @generated
     */
    public final static String GETXCUSTOMERVEHICLEAUS_ID_NULL = "1109641";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The format of inquireAsOfDate is not correct.
     *
     * @generated
     */
    public final static String GETXCUSTOMERVEHICLEAUS_INVALID_INQUIRE_AS_OF_DATE_FORMAT = "1109645";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * An attempt to read the XCustomerVehicleAus failed.
     *
     * @generated
     */
    public final static String GETALLXCUSTOMERVEHICLEAUSBYPARTYID_FAILED = "1110041";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The id is null.
     *
     * @generated
     */
    public final static String GETALLXCUSTOMERVEHICLEAUSBYPARTYID_ID_NULL = "1110045";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The format of inquireAsOfDate is not correct.
     *
     * @generated
     */
    public final static String GETALLXCUSTOMERVEHICLEAUSBYPARTYID_INVALID_INQUIRE_AS_OF_DATE_FORMAT = "1110049";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * An attempt to read the XCustomerVehicleAus failed.
     *
     * @generated
     */
    public final static String GETALLXCUSTOMERVEHICLEAUSBYVEHICLEID_FAILED = "1110093";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The id is null.
     *
     * @generated
     */
    public final static String GETALLXCUSTOMERVEHICLEAUSBYVEHICLEID_ID_NULL = "1110097";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The format of inquireAsOfDate is not correct.
     *
     * @generated
     */
    public final static String GETALLXCUSTOMERVEHICLEAUSBYVEHICLEID_INVALID_INQUIRE_AS_OF_DATE_FORMAT = "1110101";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XCustomerVehicleAus insert failed.
     *
     * @generated
     */
    public final static String ADDXCUSTOMERVEHICLEAUS_FAILED = "1109660";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Duplicate primary key already exists.
     *
     * @generated
     */
    public final static String DUPLICATE_PRIMARY_KEY_XCUSTOMERVEHICLEAUS = "1109664";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XCustomerVehicleAus update failed.
     *
     * @generated
     */
    public final static String UPDATEXCUSTOMERVEHICLEAUS_FAILED = "1109677";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: vehicle_rel_status_tp_cd
     *
     * @generated
     */
    public final static String XVEHICLERELSTATUS_VEHICLE_REL_STATUS_TP_CD_NULL = "1109809";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: name
     *
     * @generated
     */
    public final static String XVEHICLERELSTATUS_NAME_NULL = "1109817";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: XCustomerRoleAuspkId
     *
     * @generated
     */
    public final static String XCUSTOMERVEHICLEROLEAUS_XCUSTOMERROLEAUSPKID_NULL = "1109851";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: CustomerVehicleId
     *
     * @generated
     */
    public final static String XCUSTOMERVEHICLEROLEAUS_CUSTOMERVEHICLEID_NULL = "1109918";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * VehicleRole is not correct
     *
     * @generated
     */
    public final static String INVALID_XCUSTOMERVEHICLEROLEAUS_VEHICLEROLE = "1109927";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * VehicleRelStatus is not correct
     *
     * @generated
     */
    public final static String INVALID_XCUSTOMERVEHICLEROLEAUS_VEHICLERELSTATUS = "1109940";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * StartDate is not correct
     *
     * @generated
     */
    public final static String INVALID_XCUSTOMERVEHICLEROLEAUS_STARTDATE = "1109958";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * EndDate is not correct
     *
     * @generated
     */
    public final static String INVALID_XCUSTOMERVEHICLEROLEAUS_ENDDATE = "1109970";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * SourceIdentifier is not correct
     *
     * @generated
     */
    public final static String INVALID_XCUSTOMERVEHICLEROLEAUS_SOURCEIDENTIFIER = "1109977";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * LastModifiedSystemDate is not correct
     *
     * @generated
     */
    public final static String INVALID_XCUSTOMERVEHICLEROLEAUS_LASTMODIFIEDSYSTEMDATE = "1109995";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: XCustomerVehicleAusReference
     *
     * @generated
     */
    public final static String XCUSTOMERVEHICLEROLEAUS_XCUSTOMERVEHICLEAUSREFERENCE_NULL = "1110147";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The before image of XCustomerVehicleRoleAus is empty.
     *
     * @generated
     */
    public final static String XCUSTOMERVEHICLEROLEAUS_BEFORE_IMAGE_NOT_POPULATED = "1109855";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * An attempt to read the XCustomerVehicleRoleAus failed.
     *
     * @generated
     */
    public final static String GETXCUSTOMERVEHICLEROLEAUS_FAILED = "1109872";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The id is null.
     *
     * @generated
     */
    public final static String GETXCUSTOMERVEHICLEROLEAUS_ID_NULL = "1109876";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The format of inquireAsOfDate is not correct.
     *
     * @generated
     */
    public final static String GETXCUSTOMERVEHICLEROLEAUS_INVALID_INQUIRE_AS_OF_DATE_FORMAT = "1109880";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * An attempt to read the XCustomerVehicleRoleAus failed.
     *
     * @generated
     */
    public final static String GETALLVEHICLEROLEAUSBYCUSTOMERVEHICLEID_FAILED = "1110068";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The id is null.
     *
     * @generated
     */
    public final static String GETALLVEHICLEROLEAUSBYCUSTOMERVEHICLEID_ID_NULL = "1110072";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The format of inquireAsOfDate is not correct.
     *
     * @generated
     */
    public final static String GETALLVEHICLEROLEAUSBYCUSTOMERVEHICLEID_INVALID_INQUIRE_AS_OF_DATE_FORMAT = "1110076";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * An attempt to read the XCustomerVehicleRoleAus failed.
     *
     * @generated
     */
    public final static String GETALLXCUSTOMERVEHICLEROLEAUSBYXCUSTOMERVEHICLEAUS_FAILED = "1110164";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The id is null.
     *
     * @generated
     */
    public final static String GETALLXCUSTOMERVEHICLEROLEAUSBYXCUSTOMERVEHICLEAUS_ID_NULL = "1110168";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The format of inquireAsOfDate is not correct.
     *
     * @generated
     */
    public final static String GETALLXCUSTOMERVEHICLEROLEAUSBYXCUSTOMERVEHICLEAUS_INVALID_INQUIRE_AS_OF_DATE_FORMAT = "1110172";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XCustomerVehicleRoleAus insert failed.
     *
     * @generated
     */
    public final static String ADDXCUSTOMERVEHICLEROLEAUS_FAILED = "1109895";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Duplicate primary key already exists.
     *
     * @generated
     */
    public final static String DUPLICATE_PRIMARY_KEY_XCUSTOMERVEHICLEROLEAUS = "1109899";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XCustomerVehicleRoleAus update failed.
     *
     * @generated
     */
    public final static String UPDATEXCUSTOMERVEHICLEROLEAUS_FAILED = "1109912";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: XVRCollapsepkId
     *
     * @generated
     */
    public final static String XVRCOLLAPSE_XVRCOLLAPSEPKID_NULL = "1110240";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: SuspectIds
     *
     * @generated
     */
    public final static String XVRCOLLAPSE_SUSPECTIDS_NULL = "1110329";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * CreateDate is not correct
     *
     * @generated
     */
    public final static String INVALID_XVRCOLLAPSE_CREATEDATE = "1110349";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: MarketName
     *
     * @generated
     */
    public final static String XVRCOLLAPSE_MARKETNAME_NULL = "1110357";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The before image of XVRCollapse is empty.
     *
     * @generated
     */
    public final static String XVRCOLLAPSE_BEFORE_IMAGE_NOT_POPULATED = "1110244";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * An attempt to read the XVRCollapse failed.
     *
     * @generated
     */
    public final static String GETXVRCOLLAPSE_FAILED = "1110261";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The id is null.
     *
     * @generated
     */
    public final static String GETXVRCOLLAPSE_ID_NULL = "1110265";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The format of inquireAsOfDate is not correct.
     *
     * @generated
     */
    public final static String GETXVRCOLLAPSE_INVALID_INQUIRE_AS_OF_DATE_FORMAT = "1110269";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XVRCollapse insert failed.
     *
     * @generated
     */
    public final static String ADDXVRCOLLAPSE_FAILED = "1110284";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Duplicate primary key already exists.
     *
     * @generated
     */
    public final static String DUPLICATE_PRIMARY_KEY_XVRCOLLAPSE = "1110288";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XVRCollapse update failed.
     *
     * @generated
     */
    public final static String UPDATEXVRCOLLAPSE_FAILED = "1110301";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: XDeleteAuditpkId
     *
     * @generated
     */
    public final static String XDELETEAUDIT_XDELETEAUDITPKID_NULL = "1110521";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: CONT_ID
     *
     * @generated
     */
    public final static String XDELETEAUDIT_CONT_ID_NULL = "1110594";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: ADMIN_CLIENT_ID
     *
     * @generated
     */
    public final static String XDELETEAUDIT_ADMIN_CLIENT_ID_NULL = "1110600";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * DELETE_DATE is not correct
     *
     * @generated
     */
    public final static String INVALID_XDELETEAUDIT_DELETE_DATE = "1110647";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The before image of XDeleteAudit is empty.
     *
     * @generated
     */
    public final static String XDELETEAUDIT_BEFORE_IMAGE_NOT_POPULATED = "1110525";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * An attempt to read the XDeleteAudit failed.
     *
     * @generated
     */
    public final static String GETXDELETEAUDIT_FAILED = "1110542";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The id is null.
     *
     * @generated
     */
    public final static String GETXDELETEAUDIT_ID_NULL = "1110546";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The format of inquireAsOfDate is not correct.
     *
     * @generated
     */
    public final static String GETXDELETEAUDIT_INVALID_INQUIRE_AS_OF_DATE_FORMAT = "1110550";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XDeleteAudit insert failed.
     *
     * @generated
     */
    public final static String ADDXDELETEAUDIT_FAILED = "1110565";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Duplicate primary key already exists.
     *
     * @generated
     */
    public final static String DUPLICATE_PRIMARY_KEY_XDELETEAUDIT = "1110569";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * XDeleteAudit update failed.
     *
     * @generated
     */
    public final static String UPDATEXDELETEAUDIT_FAILED = "1110582";
}


