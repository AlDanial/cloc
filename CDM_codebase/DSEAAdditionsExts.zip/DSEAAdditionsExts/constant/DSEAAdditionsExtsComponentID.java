/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[0b7cb80f88936507520f094e6c05108a]
 */

package com.ibm.daimler.dsea.constant;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * Defines the component IDs used in this module.
 *
 * @generated
 */
public class DSEAAdditionsExtsComponentID {

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for DSEAAdditionsExtsComponent.
     *
     * @generated
     */
    public final static String DSEAADDITIONS_EXTS_COMPONENT = "1100007";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for DSEAAdditionsExtsController.
     *
     * @generated
     */
    public final static String DSEAADDITIONS_EXTS_CONTROLLER = "1100008";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for XPersonBObjExt.
     *
     * @generated
     */
    public final static String XPERSON_BOBJ_EXT = "1100010";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for XOrgBObjExt.
     *
     * @generated
     */
    public final static String XORG_BOBJ_EXT = "1100059";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for XAddressBObjExt.
     *
     * @generated
     */
    public final static String XADDRESS_BOBJ_EXT = "1100108";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for XAddressGroupBObjExt.
     *
     * @generated
     */
    public final static String XADDRESS_GROUP_BOBJ_EXT = "1100149";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for XContactMethodGroupBObjExt.
     *
     * @generated
     */
    public final static String XCONTACT_METHOD_GROUP_BOBJ_EXT = "1100190";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for XContactRelBObjExt.
     *
     * @generated
     */
    public final static String XCONTACT_REL_BOBJ_EXT = "1100231";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for XPersonNameBObjExt.
     *
     * @generated
     */
    public final static String XPERSON_NAME_BOBJ_EXT = "1100272";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for XCdSubcityTypeBObj.
     *
     * @generated
     */
    public final static String XCD_SUBCITY_TYPE_BOBJ = "1100390";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for XCdDistrictTypeBObj.
     *
     * @generated
     */
    public final static String XCD_DISTRICT_TYPE_BOBJ = "1100443";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for XCdPreferenceTypeBObj.
     *
     * @generated
     */
    public final static String XCD_PREFERENCE_TYPE_BOBJ = "1100496";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for XCdVerifiedTypeBObj.
     *
     * @generated
     */
    public final static String XCD_VERIFIED_TYPE_BOBJ = "1100549";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for XCdOccupationTypeBObj.
     *
     * @generated
     */
    public final static String XCD_OCCUPATION_TYPE_BOBJ = "1100655";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for XCdNumberOfEmployeesTypeBObj.
     *
     * @generated
     */
    public final static String XCD_NUMBER_OF_EMPLOYEES_TYPE_BOBJ = "1100708";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for XCdActionTypeBObj.
     *
     * @generated
     */
    public final static String XCD_ACTION_TYPE_BOBJ = "1100814";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for XPreferenceBObj.
     *
     * @generated
     */
    public final static String XPREFERENCE_BOBJ = "1100919";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for XPrivacyAgreementBObj.
     *
     * @generated
     */
    public final static String XPRIVACY_AGREEMENT_BOBJ = "1101049";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for XContractBObjExt.
     *
     * @generated
     */
    public final static String XCONTRACT_BOBJ_EXT = "1101302";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for XContractRoleBObjExt.
     *
     * @generated
     */
    public final static String XCONTRACT_ROLE_BOBJ_EXT = "1101351";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for XCdRetailerRoleTypeBObj.
     *
     * @generated
     */
    public final static String XCD_RETAILER_ROLE_TYPE_BOBJ = "1101405";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for XCdConnectMeUsageTypeBObj.
     *
     * @generated
     */
    public final static String XCD_CONNECT_ME_USAGE_TYPE_BOBJ = "1101458";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for XCdVehicleSalesTypeBObj.
     *
     * @generated
     */
    public final static String XCD_VEHICLE_SALES_TYPE_BOBJ = "1101511";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for XCdVehicleUsageTypeBObj.
     *
     * @generated
     */
    public final static String XCD_VEHICLE_USAGE_TYPE_BOBJ = "1101564";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for XCdVehicleOwnerShipTypeBObj.
     *
     * @generated
     */
    public final static String XCD_VEHICLE_OWNER_SHIP_TYPE_BOBJ = "1101617";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for XCdVehicleRoleTypeBObj.
     *
     * @generated
     */
    public final static String XCD_VEHICLE_ROLE_TYPE_BOBJ = "1101670";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for XRetailerBObj.
     *
     * @generated
     */
    public final static String XRETAILER_BOBJ = "1101723";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for XVehicleBObj.
     *
     * @generated
     */
    public final static String XVEHICLE_BOBJ = "1101850";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for XCustomerRetailerBObj.
     *
     * @generated
     */
    public final static String XCUSTOMER_RETAILER_BOBJ = "1102054";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for XCustomerRetailerRoleBObj.
     *
     * @generated
     */
    public final static String XCUSTOMER_RETAILER_ROLE_BOBJ = "1102149";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for XCustomerVehicleBObj.
     *
     * @generated
     */
    public final static String XCUSTOMER_VEHICLE_BOBJ = "1102244";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for XCustomerVehicleRoleBObj.
     *
     * @generated
     */
    public final static String XCUSTOMER_VEHICLE_ROLE_BOBJ = "1102339";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for XOrgNameBObjExt.
     *
     * @generated
     */
    public final static String XORG_NAME_BOBJ_EXT = "1102952";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for XIdentifierBObjExt.
     *
     * @generated
     */
    public final static String XIDENTIFIER_BOBJ_EXT = "1103062";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for XContEquivBObjExt.
     *
     * @generated
     */
    public final static String XCONT_EQUIV_BOBJ_EXT = "1103314";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for XCompanyIdentificationBObj.
     *
     * @generated
     */
    public final static String XCOMPANY_IDENTIFICATION_BOBJ = "1103391";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for XContractDetailsBObj.
     *
     * @generated
     */
    public final static String XCONTRACT_DETAILS_BOBJ = "1103494";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for XContactMethodBObjExt.
     *
     * @generated
     */
    public final static String XCONTACT_METHOD_BOBJ_EXT = "1103796";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for XGurantorIndividualBObj.
     *
     * @generated
     */
    public final static String XGURANTOR_INDIVIDUAL_BOBJ = "1103861";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for XGurantorCompanyBObj.
     *
     * @generated
     */
    public final static String XGURANTOR_COMPANY_BOBJ = "1103956";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for XCorporateCategoryTypeBObj.
     *
     * @generated
     */
    public final static String XCORPORATE_CATEGORY_TYPE_BOBJ = "1104779";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for XCorporateGroupTypeBObj.
     *
     * @generated
     */
    public final static String XCORPORATE_GROUP_TYPE_BOBJ = "1104832";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for XDealerRetailerBObj.
     *
     * @generated
     */
    public final static String XDEALER_RETAILER_BOBJ = "1104951";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for XMagicRelBObj.
     *
     * @generated
     */
    public final static String XMAGIC_REL_BOBJ = "1105062";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for XConsentBObj.
     *
     * @generated
     */
    public final static String XCONSENT_BOBJ = "1105189";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for XContractRelBObj.
     *
     * @generated
     */
    public final static String XCONTRACT_REL_BOBJ = "1105377";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for GuarantorDetailsBObj.
     *
     * @generated
     */
    public final static String GUARANTOR_DETAILS_BOBJ = "1105538";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for CoborrowerDetailsBObj.
     *
     * @generated
     */
    public final static String COBORROWER_DETAILS_BOBJ = "1105554";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for XCustomerRetailerJPNBObj.
     *
     * @generated
     */
    public final static String XCUSTOMER_RETAILER_JPNBOBJ = "1105838";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for XVehicleJPNBObj.
     *
     * @generated
     */
    public final static String XVEHICLE_JPNBOBJ = "1106192";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for XCustomerVehicleJPNBObj.
     *
     * @generated
     */
    public final static String XCUSTOMER_VEHICLE_JPNBOBJ = "1106412";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for XCustomerVehicleRoleJPNBObj.
     *
     * @generated
     */
    public final static String XCUSTOMER_VEHICLE_ROLE_JPNBOBJ = "1106507";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for XDataSharingBObj.
     *
     * @generated
     */
    public final static String XDATA_SHARING_BOBJ = "1106986";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for XVehicleKORBObj.
     *
     * @generated
     */
    public final static String XVEHICLE_KORBOBJ = "1107892";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for XCustomerVehicleKORBObj.
     *
     * @generated
     */
    public final static String XCUSTOMER_VEHICLE_KORBOBJ = "1108204";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for XCustomerVehicleRoleKORBObj.
     *
     * @generated
     */
    public final static String XCUSTOMER_VEHICLE_ROLE_KORBOBJ = "1108475";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for XEpucidTempBObj.
     *
     * @generated
     */
    public final static String XEPUCID_TEMP_BOBJ = "1108737";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for FinanceContractorDetailsJPNBObj.
     *
     * @generated
     */
    public final static String FINANCE_CONTRACTOR_DETAILS_JPNBOBJ = "1108860";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for GuarantorDetailsJPNBObj.
     *
     * @generated
     */
    public final static String GUARANTOR_DETAILS_JPNBOBJ = "1108880";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for XContractDetailsJPNBObj.
     *
     * @generated
     */
    public final static String XCONTRACT_DETAILS_JPNBOBJ = "1108900";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for XContractRelJPNBObj.
     *
     * @generated
     */
    public final static String XCONTRACT_REL_JPNBOBJ = "1109109";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for XVehicleAusBObj.
     *
     * @generated
     */
    public final static String XVEHICLE_AUS_BOBJ = "1109359";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for XCustomerVehicleAusBObj.
     *
     * @generated
     */
    public final static String XCUSTOMER_VEHICLE_AUS_BOBJ = "1109587";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for XVehicleRelStatusTypeBObj.
     *
     * @generated
     */
    public final static String XVEHICLE_REL_STATUS_TYPE_BOBJ = "1109769";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for XCustomerVehicleRoleAusBObj.
     *
     * @generated
     */
    public final static String XCUSTOMER_VEHICLE_ROLE_AUS_BOBJ = "1109822";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for XVRCollapseBObj.
     *
     * @generated
     */
    public final static String XVRCOLLAPSE_BOBJ = "1110211";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for XDeleteAuditBObj.
     *
     * @generated
     */
    public final static String XDELETE_AUDIT_BOBJ = "1110492";
}


