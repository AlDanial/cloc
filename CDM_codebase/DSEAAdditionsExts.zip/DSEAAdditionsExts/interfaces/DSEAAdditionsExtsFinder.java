/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[2b671e193b1fc09c9b84932be77156ea]
 */

package com.ibm.daimler.dsea.interfaces;

import com.dwl.base.DWLControl;
import com.dwl.tcrm.common.ITCRMController;




import com.dwl.base.DWLResponse;

import com.dwl.base.exception.DWLBaseException;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * Controller level interface for all DSEAAdditionsExts read-only transactions.
 * @generated
 */
public interface DSEAAdditionsExtsFinder extends ITCRMController {

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXPreference.
     *
     * @generated
     **/
     public DWLResponse getXPreference(String PreferencepkId, DWLControl control) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXPreferenceByLocationGroupId.
     *
     * @generated
     **/
     public DWLResponse getXPreferenceByLocationGroupId(String LocationGroupId,  DWLControl control) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXPrivacyAgreement.
     *
     * @generated
     **/
     public DWLResponse getXPrivacyAgreement(String PrivacyAgreementpkId, DWLControl control) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXPrivAgreementByLocationGroupId.
     *
     * @generated
     **/
     public DWLResponse getXPrivAgreementByLocationGroupId(String LocationGroupId,  DWLControl control) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXRetailer.
     *
     * @generated
     **/
     public DWLResponse getXRetailer(String RetailerpkId,  DWLControl control) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXRetailerByRetailerCode.
     *
     * @generated
     **/
     public DWLResponse getXRetailerByRetailerCode(String RetailerCode,  DWLControl control) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXRetailerByNDCode.
     *
     * @generated
     **/
     public DWLResponse getXRetailerByNDCode(String NDCode,  DWLControl control) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXRetailerByGSCode.
     *
     * @generated
     **/
     public DWLResponse getXRetailerByGSCode(String GSCode,  DWLControl control) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXRetailerByGSCodeAndMarketName.
     *
     * @generated
     **/
     public DWLResponse getXRetailerByGSCodeAndMarketName(String GSCode, String MarketName,  DWLControl control) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXRetailerByRetailerCodeAndMarketName.
     *
     * @generated
     **/
     public DWLResponse getXRetailerByRetailerCodeAndMarketName(String RetailerCode, String MarketName,  DWLControl control) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXRetailerByNDCodeAndMarketName.
     *
     * @generated
     **/
     public DWLResponse getXRetailerByNDCodeAndMarketName(String NDCode, String MarketName,  DWLControl control) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXCustomerRetailer.
     *
     * @generated
     **/
     public DWLResponse getXCustomerRetailer(String CustomerRetailerpkId,  DWLControl control) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getAllXCustomerRetailerByPartyId.
     *
     * @generated
     **/
     public DWLResponse getAllXCustomerRetailerByPartyId(String ContId,  DWLControl control) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXCustomerRetailerRole.
     *
     * @generated
     **/
     public DWLResponse getXCustomerRetailerRole(String CustomerRetailerRolepkId,  DWLControl control) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getAllRetailerRoleByCustomerRetailerId.
     *
     * @generated
     **/
     public DWLResponse getAllRetailerRoleByCustomerRetailerId(String CustomerRetailerId,  DWLControl control) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXVehicle.
     *
     * @generated
     **/
     public DWLResponse getXVehicle(String VehiclepkId,  DWLControl control) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXCustomerVehicle.
     *
     * @generated
     **/
     public DWLResponse getXCustomerVehicle(String CustomerVehiclepkId,  DWLControl control) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getAllXCustomerVehicleByPartyId.
     *
     * @generated
     **/
     public DWLResponse getAllXCustomerVehicleByPartyId(String ContId,  DWLControl control) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXCustomerVehicleRole.
     *
     * @generated
     **/
     public DWLResponse getXCustomerVehicleRole(String CustomerVehicleRolepkId,  DWLControl control) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getAllVehicleRoleByCustomerVehicleId.
     *
     * @generated
     **/
     public DWLResponse getAllVehicleRoleByCustomerVehicleId(String CustomerVehicleId,  DWLControl control) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXCompanyIdentification.
     *
     * @generated
     **/
     public DWLResponse getXCompanyIdentification(String CompanyIdentificationpkId,  DWLControl control) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXContractDetails.
     *
     * @generated
     **/
     public DWLResponse getXContractDetails(String ContractpkId,  DWLControl control) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getAllXContractDetailsByPartyId.
     *
     * @generated
     **/
     public DWLResponse getAllXContractDetailsByPartyId(String ContId,  DWLControl control) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXGurantorIndividual.
     *
     * @generated
     **/
     public DWLResponse getXGurantorIndividual(String XGurantorIndividualpkId,  DWLControl control) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getAllXGurantorIndividualByContractDetailsId.
     *
     * @generated
     **/
     public DWLResponse getAllXGurantorIndividualByContractDetailsId(String ContractDetailsId,  DWLControl control) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXGurantorCompany.
     *
     * @generated
     **/
     public DWLResponse getXGurantorCompany(String XGurantorCompanypkId,  DWLControl control) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getAllXGurantorCompanyByContractDetailsId.
     *
     * @generated
     **/
     public DWLResponse getAllXGurantorCompanyByContractDetailsId(String ContractDetailsId,  DWLControl control) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXDealerRetailer.
     *
     * @generated
     **/
     public DWLResponse getXDealerRetailer(String XDealerRetailerpkId,  DWLControl control) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXMagicRel.
     *
     * @generated
     **/
     public DWLResponse getXMagicRel(String XMagicRelpkId,  DWLControl control) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXConsent.
     *
     * @generated
     **/
     public DWLResponse getXConsent(String XConsentpkId,  DWLControl control) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXConsentByContId.
     *
     * @generated
     **/
     public DWLResponse getXConsentByContId(String ContId,  DWLControl control) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXContractRel.
     *
     * @generated
     **/
     public DWLResponse getXContractRel(String XContractRelpkId,  DWLControl control) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXCustomerRetailerJPN.
     *
     * @generated
     **/
     public DWLResponse getXCustomerRetailerJPN(String XCustomerRetailerJPNpkId,  DWLControl control) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getAllXCustomerRetailerJPNByPartyId.
     *
     * @generated
     **/
     public DWLResponse getAllXCustomerRetailerJPNByPartyId(String ContId,  DWLControl control) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXVehicleJPN.
     *
     * @generated
     **/
     public DWLResponse getXVehicleJPN(String XVehicleJPNpkId,  DWLControl control) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXVehicleJPNByGlobalVIN.
     *
     * @generated
     **/
     public DWLResponse getXVehicleJPNByGlobalVIN(String GlobalVIN,  DWLControl control) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXCustomerVehicleJPN.
     *
     * @generated
     **/
     public DWLResponse getXCustomerVehicleJPN(String XCustomerVehicleJPNpkId,  DWLControl control) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getAllXCustomerVehicleJPNByPartyId.
     *
     * @generated
     **/
     public DWLResponse getAllXCustomerVehicleJPNByPartyId(String ContId,  DWLControl control) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getAllCVRByVehicleId.
     *
     * @generated
     **/
     public DWLResponse getAllCVRByVehicleId(String VehicleId,  DWLControl control) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXCustomerVehicleRoleJPN.
     *
     * @generated
     **/
     public DWLResponse getXCustomerVehicleRoleJPN(String XCustomerVehicleRoleJPNpkId,  DWLControl control) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getAllVehicleRoleByCustomerVehicleJPNId.
     *
     * @generated
     **/
     public DWLResponse getAllVehicleRoleByCustomerVehicleJPNId(String CustomerVehicleId,  DWLControl control) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXDataSharing.
     *
     * @generated
     **/
     public DWLResponse getXDataSharing(String DataSharingpkId,  DWLControl control) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getDataSharingByPartyId.
     *
     * @generated
     **/
     public DWLResponse getDataSharingByPartyId(String ContId,  DWLControl control) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXVehicleKOR.
     *
     * @generated
     **/
     public DWLResponse getXVehicleKOR(String XVehicleKORpkId,  DWLControl control) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXVehicleKORByGlobalVIN.
     *
     * @generated
     **/
     public DWLResponse getXVehicleKORByGlobalVIN(String GlobalVIN,  DWLControl control) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXCustomerVehicleKOR.
     *
     * @generated
     **/
     public DWLResponse getXCustomerVehicleKOR(String XCustomerVehicleKORpkId,  DWLControl control) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getAllXCustomerVehicleKORByPartyId.
     *
     * @generated
     **/
     public DWLResponse getAllXCustomerVehicleKORByPartyId(String ContId,  DWLControl control) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getAllCVRByVehicle_ID.
     *
     * @generated
     **/
     public DWLResponse getAllCVRByVehicle_ID(String VehicleId,  DWLControl control) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXCustomerVehicleRoleKOR.
     *
     * @generated
     **/
     public DWLResponse getXCustomerVehicleRoleKOR(String XCustomerVehicleRoleKORpkId,  DWLControl control) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getAllVehicleRoleByCustomerVehicleKORId.
     *
     * @generated
     **/
     public DWLResponse getAllVehicleRoleByCustomerVehicleKORId(String CustomerVehicleId,  DWLControl control) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXEpucidTemp.
     *
     * @generated
     **/
     public DWLResponse getXEpucidTemp(String XEpucidTemppkId,  DWLControl control) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXContractDetailsJPN.
     *
     * @generated
     **/
     public DWLResponse getXContractDetailsJPN(String XContractJPNpkId,  DWLControl control) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getAllXContractDetailsJPNByPartyId.
     *
     * @generated
     **/
     public DWLResponse getAllXContractDetailsJPNByPartyId(String ContId,  DWLControl control) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXContractRelJPN.
     *
     * @generated
     **/
     public DWLResponse getXContractRelJPN(String XContractRelJPNpkId,  DWLControl control) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXVehicleAus.
     *
     * @generated
     **/
     public DWLResponse getXVehicleAus(String XVehicleAuspkId,  DWLControl control) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXvehicleAusByGlobalVINAndMarketName.
     *
     * @generated
     **/
     public DWLResponse getXvehicleAusByGlobalVINAndMarketName(String GlobalVIN, String MarketName,  DWLControl control) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXCustomerVehicleAus.
     *
     * @generated
     **/
     public DWLResponse getXCustomerVehicleAus(String XCustomerVehicleAuspkId,  DWLControl control) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getAllXCustomerVehicleAusByPartyId.
     *
     * @generated
     **/
     public DWLResponse getAllXCustomerVehicleAusByPartyId(String ContId,  DWLControl control) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getAllXCustomerVehicleAusByVehicleId.
     *
     * @generated
     **/
     public DWLResponse getAllXCustomerVehicleAusByVehicleId(String VehicleId,  DWLControl control) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXCustomerVehicleRoleAus.
     *
     * @generated
     **/
     public DWLResponse getXCustomerVehicleRoleAus(String XCustomerRoleAuspkId,  DWLControl control) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getAllVehicleRoleAusByCustomerVehicleId.
     *
     * @generated
     **/
     public DWLResponse getAllVehicleRoleAusByCustomerVehicleId(String CustomerVehicleId,  DWLControl control) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction
     * getAllXCustomerVehicleRoleAusByXCustomerVehicleAus.
     *
     * @generated
     **/
     public DWLResponse getAllXCustomerVehicleRoleAusByXCustomerVehicleAus(String XCustomerVehicleAusReference,  DWLControl control) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXVRCollapse.
     *
     * @generated
     **/
     public DWLResponse getXVRCollapse(String XVRCollapsepkId,  DWLControl control) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getXDeleteAudit.
     *
     * @generated
     **/
     public DWLResponse getXDeleteAudit(String XDeleteAuditpkId,  DWLControl control) throws DWLBaseException;

}


