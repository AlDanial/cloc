/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[7af472b1258e0affe711553aeab94508]
 */

package com.ibm.daimler.dsea.interfaces;


import com.dwl.tcrm.common.ITCRMController;



import com.dwl.base.DWLResponse;

import com.dwl.base.exception.DWLBaseException;

import com.ibm.daimler.dsea.component.XCompanyIdentificationBObj;
import com.ibm.daimler.dsea.component.XConsentBObj;
import com.ibm.daimler.dsea.component.XContractDetailsBObj;
import com.ibm.daimler.dsea.component.XContractDetailsJPNBObj;
import com.ibm.daimler.dsea.component.XContractRelBObj;
import com.ibm.daimler.dsea.component.XContractRelJPNBObj;
import com.ibm.daimler.dsea.component.XCustomerRetailerBObj;
import com.ibm.daimler.dsea.component.XCustomerRetailerJPNBObj;
import com.ibm.daimler.dsea.component.XCustomerRetailerRoleBObj;
import com.ibm.daimler.dsea.component.XCustomerVehicleAusBObj;
import com.ibm.daimler.dsea.component.XCustomerVehicleBObj;
import com.ibm.daimler.dsea.component.XCustomerVehicleJPNBObj;
import com.ibm.daimler.dsea.component.XCustomerVehicleKORBObj;
import com.ibm.daimler.dsea.component.XCustomerVehicleRoleAusBObj;
import com.ibm.daimler.dsea.component.XCustomerVehicleRoleBObj;
import com.ibm.daimler.dsea.component.XCustomerVehicleRoleJPNBObj;
import com.ibm.daimler.dsea.component.XCustomerVehicleRoleKORBObj;
import com.ibm.daimler.dsea.component.XDataSharingBObj;
import com.ibm.daimler.dsea.component.XDealerRetailerBObj;
import com.ibm.daimler.dsea.component.XDeleteAuditBObj;
import com.ibm.daimler.dsea.component.XEpucidTempBObj;
import com.ibm.daimler.dsea.component.XGurantorCompanyBObj;
import com.ibm.daimler.dsea.component.XGurantorIndividualBObj;
import com.ibm.daimler.dsea.component.XMagicRelBObj;
import com.ibm.daimler.dsea.component.XPreferenceBObj;
import com.ibm.daimler.dsea.component.XPrivacyAgreementBObj;
import com.ibm.daimler.dsea.component.XRetailerBObj;
import com.ibm.daimler.dsea.component.XVRCollapseBObj;
import com.ibm.daimler.dsea.component.XVehicleAusBObj;
import com.ibm.daimler.dsea.component.XVehicleAddressBObj;
import com.ibm.daimler.dsea.component.XVehicleBObj;
import com.ibm.daimler.dsea.component.XVehicleJPNBObj;
import com.ibm.daimler.dsea.component.XVehicleKORBObj;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * Controller level interface for DSEAAdditionsExts persistent transactions.
 * @generated
 */
public interface DSEAAdditionsExtsTxn extends ITCRMController {

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction addXPreference.
     *
     * @generated
     **/
    public DWLResponse addXPreference(XPreferenceBObj theBObj) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction updateXPreference.
     *
     * @generated
     **/
    public DWLResponse updateXPreference(XPreferenceBObj theBObj) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction addXPrivacyAgreement.
     *
     * @generated
     **/
    public DWLResponse addXPrivacyAgreement(XPrivacyAgreementBObj theBObj) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction updateXPrivacyAgreement.
     *
     * @generated
     **/
    public DWLResponse updateXPrivacyAgreement(XPrivacyAgreementBObj theBObj) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction addXRetailer.
     *
     * @generated
     **/
    public DWLResponse addXRetailer(XRetailerBObj theBObj) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction updateXRetailer.
     *
     * @generated
     **/
    public DWLResponse updateXRetailer(XRetailerBObj theBObj) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction addXCustomerRetailer.
     *
     * @generated
     **/
    public DWLResponse addXCustomerRetailer(XCustomerRetailerBObj theBObj) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction updateXCustomerRetailer.
     *
     * @generated
     **/
    public DWLResponse updateXCustomerRetailer(XCustomerRetailerBObj theBObj) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction addXCustomerRetailerRole.
     *
     * @generated
     **/
    public DWLResponse addXCustomerRetailerRole(XCustomerRetailerRoleBObj theBObj) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction updateXCustomerRetailerRole.
     *
     * @generated
     **/
    public DWLResponse updateXCustomerRetailerRole(XCustomerRetailerRoleBObj theBObj) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction addXVehicle.
     *
     * @generated
     **/
    public DWLResponse addXVehicle(XVehicleBObj theBObj) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction updateXVehicle.
     *
     * @generated
     **/
    public DWLResponse updateXVehicle(XVehicleBObj theBObj) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction addXCustomerVehicle.
     *
     * @generated
     **/
    public DWLResponse addXCustomerVehicle(XCustomerVehicleBObj theBObj) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction updateXCustomerVehicle.
     *
     * @generated
     **/
    public DWLResponse updateXCustomerVehicle(XCustomerVehicleBObj theBObj) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction addXCustomerVehicleRole.
     *
     * @generated
     **/
    public DWLResponse addXCustomerVehicleRole(XCustomerVehicleRoleBObj theBObj) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction updateXCustomerVehicleRole.
     *
     * @generated
     **/
    public DWLResponse updateXCustomerVehicleRole(XCustomerVehicleRoleBObj theBObj) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction addXCompanyIdentification.
     *
     * @generated
     **/
    public DWLResponse addXCompanyIdentification(XCompanyIdentificationBObj theBObj) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction updateXCompanyIdentification.
     *
     * @generated
     **/
    public DWLResponse updateXCompanyIdentification(XCompanyIdentificationBObj theBObj) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction addXContractDetails.
     *
     * @generated
     **/
    public DWLResponse addXContractDetails(XContractDetailsBObj theBObj) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction updateXContractDetails.
     *
     * @generated
     **/
    public DWLResponse updateXContractDetails(XContractDetailsBObj theBObj) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction addXGurantorIndividual.
     *
     * @generated
     **/
    public DWLResponse addXGurantorIndividual(XGurantorIndividualBObj theBObj) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction updateXGurantorIndividual.
     *
     * @generated
     **/
    public DWLResponse updateXGurantorIndividual(XGurantorIndividualBObj theBObj) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction addXGurantorCompany.
     *
     * @generated
     **/
    public DWLResponse addXGurantorCompany(XGurantorCompanyBObj theBObj) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction updateXGurantorCompany.
     *
     * @generated
     **/
    public DWLResponse updateXGurantorCompany(XGurantorCompanyBObj theBObj) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction addXDealerRetailer.
     *
     * @generated
     **/
    public DWLResponse addXDealerRetailer(XDealerRetailerBObj theBObj) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction updateXDealerRetailer.
     *
     * @generated
     **/
    public DWLResponse updateXDealerRetailer(XDealerRetailerBObj theBObj) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction addXMagicRel.
     *
     * @generated
     **/
    public DWLResponse addXMagicRel(XMagicRelBObj theBObj) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction updateXMagicRel.
     *
     * @generated
     **/
    public DWLResponse updateXMagicRel(XMagicRelBObj theBObj) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction addXConsent.
     *
     * @generated
     **/
    public DWLResponse addXConsent(XConsentBObj theBObj) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction updateXConsent.
     *
     * @generated
     **/
    public DWLResponse updateXConsent(XConsentBObj theBObj) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction addXContractRel.
     *
     * @generated
     **/
    public DWLResponse addXContractRel(XContractRelBObj theBObj) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction updateXContractRel.
     *
     * @generated
     **/
    public DWLResponse updateXContractRel(XContractRelBObj theBObj) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction addXCustomerRetailerJPN.
     *
     * @generated
     **/
    public DWLResponse addXCustomerRetailerJPN(XCustomerRetailerJPNBObj theBObj) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction updateXCustomerRetailerJPN.
     *
     * @generated
     **/
    public DWLResponse updateXCustomerRetailerJPN(XCustomerRetailerJPNBObj theBObj) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction addXVehicleJPN.
     *
     * @generated
     **/
    public DWLResponse addXVehicleJPN(XVehicleJPNBObj theBObj) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction updateXVehicleJPN.
     *
     * @generated
     **/
    public DWLResponse updateXVehicleJPN(XVehicleJPNBObj theBObj) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction addXCustomerVehicleJPN.
     *
     * @generated
     **/
    public DWLResponse addXCustomerVehicleJPN(XCustomerVehicleJPNBObj theBObj) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction updateXCustomerVehicleJPN.
     *
     * @generated
     **/
    public DWLResponse updateXCustomerVehicleJPN(XCustomerVehicleJPNBObj theBObj) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction addXCustomerVehicleRoleJPN.
     *
     * @generated
     **/
    public DWLResponse addXCustomerVehicleRoleJPN(XCustomerVehicleRoleJPNBObj theBObj) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction updateXCustomerVehicleRoleJPN.
     *
     * @generated
     **/
    public DWLResponse updateXCustomerVehicleRoleJPN(XCustomerVehicleRoleJPNBObj theBObj) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction addXDataSharing.
     *
     * @generated
     **/
    public DWLResponse addXDataSharing(XDataSharingBObj theBObj) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction updateXDataSharing.
     *
     * @generated
     **/
    public DWLResponse updateXDataSharing(XDataSharingBObj theBObj) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction addXVehicleKOR.
     *
     * @generated
     **/
    public DWLResponse addXVehicleKOR(XVehicleKORBObj theBObj) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction updateXVehicleKOR.
     *
     * @generated
     **/
    public DWLResponse updateXVehicleKOR(XVehicleKORBObj theBObj) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction addXCustomerVehicleKOR.
     *
     * @generated
     **/
    public DWLResponse addXCustomerVehicleKOR(XCustomerVehicleKORBObj theBObj) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction updateXCustomerVehicleKOR.
     *
     * @generated
     **/
    public DWLResponse updateXCustomerVehicleKOR(XCustomerVehicleKORBObj theBObj) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction addXCustomerVehicleRoleKOR.
     *
     * @generated
     **/
    public DWLResponse addXCustomerVehicleRoleKOR(XCustomerVehicleRoleKORBObj theBObj) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction updateXCustomerVehicleRoleKOR.
     *
     * @generated
     **/
    public DWLResponse updateXCustomerVehicleRoleKOR(XCustomerVehicleRoleKORBObj theBObj) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction addXEpucidTemp.
     *
     * @generated
     **/
    public DWLResponse addXEpucidTemp(XEpucidTempBObj theBObj) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction updateXEpucidTemp.
     *
     * @generated
     **/
    public DWLResponse updateXEpucidTemp(XEpucidTempBObj theBObj) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction addXContractDetailsJPN.
     *
     * @generated
     **/
    public DWLResponse addXContractDetailsJPN(XContractDetailsJPNBObj theBObj) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction updateXContractDetailsJPN.
     *
     * @generated
     **/
    public DWLResponse updateXContractDetailsJPN(XContractDetailsJPNBObj theBObj) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction addXContractRelJPN.
     *
     * @generated
     **/
    public DWLResponse addXContractRelJPN(XContractRelJPNBObj theBObj) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction updateXContractRelJPN.
     *
     * @generated
     **/
    public DWLResponse updateXContractRelJPN(XContractRelJPNBObj theBObj) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction addXVehicleAus.
     *
     * @generated
     **/
    public DWLResponse addXVehicleAus(XVehicleAusBObj theBObj) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction updateXVehicleAus.
     *
     * @generated
     **/
    public DWLResponse updateXVehicleAus(XVehicleAusBObj theBObj) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction addXCustomerVehicleAus.
     *
     * @generated
     **/
    public DWLResponse addXCustomerVehicleAus(XCustomerVehicleAusBObj theBObj) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction updateXCustomerVehicleAus.
     *
     * @generated
     **/
    public DWLResponse updateXCustomerVehicleAus(XCustomerVehicleAusBObj theBObj) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction addXCustomerVehicleRoleAus.
     *
     * @generated
     **/
    public DWLResponse addXCustomerVehicleRoleAus(XCustomerVehicleRoleAusBObj theBObj) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction updateXCustomerVehicleRoleAus.
     *
     * @generated
     **/
    public DWLResponse updateXCustomerVehicleRoleAus(XCustomerVehicleRoleAusBObj theBObj) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction addXVRCollapse.
     *
     * @generated
     **/
    public DWLResponse addXVRCollapse(XVRCollapseBObj theBObj) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction updateXVRCollapse.
     *
     * @generated
     **/
    public DWLResponse updateXVRCollapse(XVRCollapseBObj theBObj) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction addXDeleteAudit.
     *
     * @generated
     **/
    public DWLResponse addXDeleteAudit(XDeleteAuditBObj theBObj) throws DWLBaseException;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction updateXDeleteAudit.
     *
     * @generated
     **/
    public DWLResponse updateXDeleteAudit(XDeleteAuditBObj theBObj) throws DWLBaseException;

}


