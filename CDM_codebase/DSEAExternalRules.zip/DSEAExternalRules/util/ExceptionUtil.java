package com.ibm.daimler.dsea.extrules.util;

import com.dwl.base.DWLControl;
import com.dwl.base.IDWLErrorMessage;
import com.dwl.base.error.DWLError;
import com.dwl.base.error.DWLStatus;
import com.dwl.tcrm.utilities.TCRMClassFactory;

public class ExceptionUtil {

	private static IDWLErrorMessage errHandler;

	private static DWLStatus status = new DWLStatus();

	public ExceptionUtil() {
		errHandler = TCRMClassFactory.getErrorHandler();
	}

	public static DWLStatus throwError(String componentId, String errType,
			String reasonCode, DWLControl control) {

		DWLError error = errHandler.getErrorMessage(componentId, errType,
				reasonCode, control, new String[0]);

		status.addError(error);
		status.setStatus(DWLStatus.FATAL);
		return status; 

	}

}
