package com.ibm.daimler.dsea.extrules.util;

/**
 * Typed exception for UCID Generation errors.
 * 
 * @author
 *
 */
public class UCIDException extends Exception {
	public UCIDException(String message, Throwable cause) {
		super(message, cause);
	}
	
	public UCIDException(String message) {
		this (message, null);
	}
}
