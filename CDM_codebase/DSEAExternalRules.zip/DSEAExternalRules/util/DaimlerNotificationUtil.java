package com.ibm.daimler.dsea.extrules.util;

import java.sql.Timestamp;

import com.dwl.base.DWLControl;
import com.dwl.base.notification.CommonNotification;
import com.dwl.base.notification.NotificationLocal;
import com.dwl.base.notification.NotificationLocalHome;
import com.dwl.base.performance.PerformanceMonitor;
import com.dwl.base.performance.PerformanceMonitorConfig;
import com.dwl.base.performance.PerformanceMonitorFactory;
import com.dwl.base.util.ServiceLocator;
import com.dwl.base.util.StringUtils;
import com.dwl.tcrm.common.TCRMControlKeys;
import com.dwl.tcrm.coreParty.component.TCRMConsolidatedPartyBObj;
import com.dwl.tcrm.exception.TCRMException;
import com.ibm.daimler.dsea.extrules.behaviour.CollapseMultiplePartiesBehvExt;
import com.ibm.daimler.dsea.extrules.constant.ExternalRuleConstant;
import com.ibm.daimler.dsea.extrules.notification.CustomNotificationCollapseAUS;
import com.ibm.daimler.dsea.extrules.notification.CustomNotificationCollapseBRZ;
import com.ibm.daimler.dsea.extrules.notification.CustomNotificationCollapseIND;
import com.ibm.daimler.dsea.extrules.notification.CustomNotificationCollapseJPN;
import com.ibm.daimler.dsea.extrules.notification.CustomNotificationCollapseKOR;
import com.ibm.daimler.dsea.extrules.notification.CustomNotificationCollapseMYS;
import com.ibm.daimler.dsea.extrules.notification.CustomNotificationCollapseTHA;
import com.ibm.daimler.dsea.extrules.notification.CustomNotificationCollapseTUR;

public class DaimlerNotificationUtil {

	private static final String MONITOR_TRANS_SEND_NOTIFICATION = null;
	private final static com.dwl.base.logging.IDWLLogger logger = com.dwl.base.logging.DWLLoggerManager
			.getLogger(DaimlerNotificationUtil.class);
	String transactionStatus = "FATAL";

	public void sendCollapseNotificationToQueue(
			TCRMConsolidatedPartyBObj consolidatedParty, String marketName,
			DWLControl control) {

		if (marketName != null
				&& marketName
						.equalsIgnoreCase(ExternalRuleConstant.JAPAN_MARKET_NAME)) {
			CustomNotificationCollapseJPN scNotification = new CustomNotificationCollapseJPN();
			String TxnType = (String) control.get(DWLControl.REQUEST_NAME);

			scNotification.setTxnType(TxnType);
			scNotification
					.setTxnTime(new Timestamp(System.currentTimeMillis()));
			scNotification.setRequestId(control.get(DWLControl.REQUEST_ID)
					.toString());
			scNotification.setUserId((String) control
					.get(TCRMControlKeys.USER_NAME));
			scNotification.setExternalCorrelationId(control
					.getExternalCorrelationId());
			scNotification.setControl(control);
			scNotification.setCommonObject(consolidatedParty);
			scNotification.setTransactionStat(this.transactionStatus);
			scNotification.getMessage();

			try {
				sendNotification(scNotification);
			} catch (TCRMException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		if (marketName != null
				&& (marketName.equalsIgnoreCase(ExternalRuleConstant.MARKET_NAME_AUSTRALIA) 
						|| marketName.equalsIgnoreCase(ExternalRuleConstant.MARKET_NAME_NEWZEALAND))) {
			CustomNotificationCollapseAUS scNotification = new CustomNotificationCollapseAUS();
			String TxnType = (String) control.get(DWLControl.REQUEST_NAME);

			scNotification.setTxnType(TxnType);
			scNotification.setTxnTime(new Timestamp(System.currentTimeMillis()));
			scNotification.setRequestId(control.get(DWLControl.REQUEST_ID).toString());
			scNotification.setUserId((String) control.get(TCRMControlKeys.USER_NAME));
			scNotification.setExternalCorrelationId(control.getExternalCorrelationId());
			scNotification.setControl(control);
			scNotification.setCommonObject(consolidatedParty);
			scNotification.setTransactionStat(this.transactionStatus);
			scNotification.getMessage();

			try {
				sendNotification(scNotification);
			} catch (TCRMException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		if (marketName != null
				&& marketName
						.equalsIgnoreCase(ExternalRuleConstant.MARKET_NAME_INDIA)) {
			CustomNotificationCollapseIND scNotification = new CustomNotificationCollapseIND();
			String TxnType = (String) control.get(DWLControl.REQUEST_NAME);

			scNotification.setTxnType(TxnType);
			scNotification
					.setTxnTime(new Timestamp(System.currentTimeMillis()));
			scNotification.setRequestId(control.get(DWLControl.REQUEST_ID)
					.toString());
			scNotification.setUserId((String) control
					.get(TCRMControlKeys.USER_NAME));
			scNotification.setExternalCorrelationId(control
					.getExternalCorrelationId());
			scNotification.setControl(control);
			scNotification.setCommonObject(consolidatedParty);
			scNotification.setTransactionStat(this.transactionStatus);
			scNotification.getMessage();

			try {
				sendNotification(scNotification);
			} catch (TCRMException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		if (marketName != null
				&& marketName
						.equalsIgnoreCase(ExternalRuleConstant.MARKET_NAME_MALAYSIA)) {
			CustomNotificationCollapseMYS scNotification = new CustomNotificationCollapseMYS();
			String TxnType = (String) control.get(DWLControl.REQUEST_NAME);

			scNotification.setTxnType(TxnType);
			scNotification
					.setTxnTime(new Timestamp(System.currentTimeMillis()));
			scNotification.setRequestId(control.get(DWLControl.REQUEST_ID)
					.toString());
			scNotification.setUserId((String) control
					.get(TCRMControlKeys.USER_NAME));
			scNotification.setExternalCorrelationId(control
					.getExternalCorrelationId());
			scNotification.setControl(control);
			scNotification.setCommonObject(consolidatedParty);
			scNotification.setTransactionStat(this.transactionStatus);
			scNotification.getMessage();

			try {
				sendNotification(scNotification);
			} catch (TCRMException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		if (marketName != null
				&& marketName
						.equalsIgnoreCase(ExternalRuleConstant.MARKET_NAME_THAILAND)) {
			CustomNotificationCollapseTHA scNotification = new CustomNotificationCollapseTHA();
			String TxnType = (String) control.get(DWLControl.REQUEST_NAME);

			scNotification.setTxnType(TxnType);
			scNotification
					.setTxnTime(new Timestamp(System.currentTimeMillis()));
			scNotification.setRequestId(control.get(DWLControl.REQUEST_ID)
					.toString());
			scNotification.setUserId((String) control
					.get(TCRMControlKeys.USER_NAME));
			scNotification.setExternalCorrelationId(control
					.getExternalCorrelationId());
			scNotification.setControl(control);
			scNotification.setCommonObject(consolidatedParty);
			scNotification.setTransactionStat(this.transactionStatus);
			scNotification.getMessage();

			try {
				sendNotification(scNotification);
			} catch (TCRMException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		//commented for Turkey
		/*if (marketName != null
				&& marketName
						.equalsIgnoreCase(ExternalRuleConstant.MARKET_NAME_TURKEY)) {
			CustomNotificationCollapseTUR scNotification = new CustomNotificationCollapseTUR();
			String TxnType = (String) control.get(DWLControl.REQUEST_NAME);

			scNotification.setTxnType(TxnType);
			scNotification
					.setTxnTime(new Timestamp(System.currentTimeMillis()));
			scNotification.setRequestId(control.get(DWLControl.REQUEST_ID)
					.toString());
			scNotification.setUserId((String) control
					.get(TCRMControlKeys.USER_NAME));
			scNotification.setExternalCorrelationId(control
					.getExternalCorrelationId());
			scNotification.setControl(control);
			scNotification.setCommonObject(consolidatedParty);
			scNotification.setTransactionStat(this.transactionStatus);
			scNotification.getMessage();

			try {
				sendNotification(scNotification);
			} catch (TCRMException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}*/

		if (marketName != null
				&& marketName
						.equalsIgnoreCase(ExternalRuleConstant.KOREA_MARKET_NAME)) {
			CustomNotificationCollapseKOR scNotification = new CustomNotificationCollapseKOR();
			String TxnType = (String) control.get(DWLControl.REQUEST_NAME);

			scNotification.setTxnType(TxnType);
			scNotification
					.setTxnTime(new Timestamp(System.currentTimeMillis()));
			scNotification.setRequestId(control.get(DWLControl.REQUEST_ID)
					.toString());
			scNotification.setUserId((String) control
					.get(TCRMControlKeys.USER_NAME));
			scNotification.setExternalCorrelationId(control
					.getExternalCorrelationId());
			scNotification.setControl(control);
			scNotification.setCommonObject(consolidatedParty);
			scNotification.setTransactionStat(this.transactionStatus);
			scNotification.getMessage();

			try {
				sendNotification(scNotification);
			} catch (TCRMException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		if (marketName != null
				&& marketName
						.equalsIgnoreCase(ExternalRuleConstant.MARKET_NAME_BRAZIL)) {
			CustomNotificationCollapseBRZ scNotification = new CustomNotificationCollapseBRZ();
			String TxnType = (String) control.get(DWLControl.REQUEST_NAME);

			scNotification.setTxnType(TxnType);
			scNotification
					.setTxnTime(new Timestamp(System.currentTimeMillis()));
			scNotification.setRequestId(control.get(DWLControl.REQUEST_ID)
					.toString());
			scNotification.setUserId((String) control
					.get(TCRMControlKeys.USER_NAME));
			scNotification.setExternalCorrelationId(control
					.getExternalCorrelationId());
			scNotification.setControl(control);
			scNotification.setCommonObject(consolidatedParty);
			scNotification.setTransactionStat(this.transactionStatus);
			scNotification.getMessage();

			try {
				sendNotification(scNotification);
			} catch (TCRMException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	@SuppressWarnings("deprecation")
	public void sendNotification(CommonNotification theCommonNotification)
			throws TCRMException {
		PerformanceMonitorFactory performanceMonitorFactory = PerformanceMonitorConfig
				.getInstance().getPerformanceMonitorFactory();
		@SuppressWarnings("deprecation")
		PerformanceMonitor performanceMonitor = performanceMonitorFactory
				.newCustomerNotificationMonitor();
		boolean success = false;

		performanceMonitor.start(theCommonNotification.getControl(),
				MONITOR_TRANS_SEND_NOTIFICATION, getClass());

		try {
			NotificationLocal theNotificationBean = getNotificationLocalHome()
					.create();

			theNotificationBean.notify(theCommonNotification);

			success = true;
		} catch (TCRMException ex) {
			throw ex;
		} catch (Exception ex) {
			if (logger.isErrorEnabled())
				logger.error(ex.getLocalizedMessage());
			TCRMException tcrmEx = new TCRMException(ex.getMessage());
			throw tcrmEx;
		} finally {
			performanceMonitor.stop(success);
		}
	}

	protected final static NotificationLocalHome getNotificationLocalHome()
			throws Exception {

		ServiceLocator serviceLocator = ServiceLocator.getInstance();
		NotificationLocalHome home = (NotificationLocalHome) serviceLocator
				.getLocalHome("ejblocal:com/dwl/base/notification/NotificationLocal");

		return home;

	}

}
