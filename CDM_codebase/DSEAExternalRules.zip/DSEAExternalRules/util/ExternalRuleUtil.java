package com.ibm.daimler.dsea.extrules.util;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import javax.xml.bind.DatatypeConverter;

import com.dwl.base.DWLControl;
import com.dwl.base.DWLResponse;
import com.dwl.base.IDWLErrorMessage;
import com.dwl.base.constant.DWLControlKeys;
import com.dwl.base.db.DataManager;
import com.dwl.base.db.QueryConnection;
import com.dwl.base.db.SQLParam;
import com.dwl.base.db.SQLQuery;
import com.dwl.base.error.DWLError;
import com.dwl.base.error.DWLErrorCode;
import com.dwl.base.error.DWLStatus;
import com.dwl.base.exception.DWLBaseException;
import com.dwl.base.exception.DWLExtensionException;
import com.dwl.base.exception.DWLPropertyNotFoundException;
import com.dwl.base.exception.DWLUpdateException;
import com.dwl.base.exception.ServiceLocatorException;
import com.dwl.base.logging.DWLLoggerManager;
import com.dwl.base.logging.IDWLLogger;
import com.dwl.base.util.DWLClassFactory;
import com.dwl.base.util.DWLDateTimeUtilities;
import com.dwl.base.util.DWLExceptionUtils;
import com.dwl.base.util.StringUtils;
import com.dwl.tcrm.common.TCRMErrorCode;
import com.dwl.tcrm.coreParty.component.TCRMOrganizationBObj;
import com.dwl.tcrm.coreParty.component.TCRMOrganizationNameBObj;
import com.dwl.tcrm.coreParty.component.TCRMPartyBObj;
import com.dwl.tcrm.coreParty.component.TCRMPartyComponent;
import com.dwl.tcrm.coreParty.component.TCRMPartyContactMethodBObj;
import com.dwl.tcrm.coreParty.component.TCRMPartyIdentificationBObj;
import com.dwl.tcrm.coreParty.component.TCRMPartyRelationshipBObj;
import com.dwl.tcrm.coreParty.component.TCRMPersonBObj;
import com.dwl.tcrm.coreParty.component.TCRMPersonNameBObj;
import com.dwl.tcrm.coreParty.component.TCRMSuspectBObj;
import com.dwl.tcrm.coreParty.component.TCRMSuspectOrganizationBObj;
import com.dwl.tcrm.coreParty.component.TCRMSuspectPersonBObj;
import com.dwl.tcrm.coreParty.interfaces.ISuspectProcessor;
import com.dwl.tcrm.exception.TCRMException;
import com.dwl.tcrm.exception.TCRMXmlHandlerException;
import com.dwl.tcrm.utilities.DateFormatter;
import com.dwl.tcrm.utilities.TCRMClassFactory;
import com.dwl.unifi.tx.exception.BusinessProxyException;
import com.ibm.daimler.dsea.component.DSEAAdditionsExtsComponent;
import com.ibm.daimler.dsea.component.XAddressGroupBObjExt;
import com.ibm.daimler.dsea.component.XConsentBObj;
import com.ibm.daimler.dsea.component.XContEquivBObjExt;
import com.ibm.daimler.dsea.component.XContactMethodGroupBObjExt;
import com.ibm.daimler.dsea.component.XContactRelBObjExt;
import com.ibm.daimler.dsea.component.XContractRelBObj;
import com.ibm.daimler.dsea.component.XContractRelJPNBObj;
import com.ibm.daimler.dsea.component.XCustomerRetailerBObj;
import com.ibm.daimler.dsea.component.XCustomerRetailerJPNBObj;
import com.ibm.daimler.dsea.component.XCustomerVehicleAusBObj;
import com.ibm.daimler.dsea.component.XCustomerVehicleBObj;
import com.ibm.daimler.dsea.component.XCustomerVehicleJPNBObj;
import com.ibm.daimler.dsea.component.XCustomerVehicleKORBObj;
import com.ibm.daimler.dsea.component.XCustomerVehicleRoleAusBObj;
import com.ibm.daimler.dsea.component.XCustomerVehicleRoleBObj;
import com.ibm.daimler.dsea.component.XCustomerVehicleRoleJPNBObj;
import com.ibm.daimler.dsea.component.XDataSharingBObj;
import com.ibm.daimler.dsea.component.XOrgBObjExt;
import com.ibm.daimler.dsea.component.XPersonBObjExt;
import com.ibm.daimler.dsea.component.XPreferenceBObj;
import com.ibm.daimler.dsea.component.XRetailerBObj;
import com.ibm.daimler.dsea.component.XVehicleAusBObj;
import com.ibm.daimler.dsea.component.XVehicleBObj;
import com.ibm.daimler.dsea.component.XVehicleJPNBObj;
import com.ibm.daimler.dsea.component.XVehicleKORBObj;
import com.ibm.daimler.dsea.component.XCustomerVehicleRoleKORBObj;
import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsComponentID;
import com.ibm.daimler.dsea.constant.DSEAAdditionsExtsErrorReasonCode;
import com.ibm.daimler.dsea.extrules.constant.ExternalRuleConstant;
import com.ibm.daimler.dsea.extrules.constant.DSEAExternalRulesComponentID;
import com.ibm.daimler.dsea.extrules.constant.DSEAExternalRulesErrorReasonCode;
import com.ibm.daimler.dsea.component.DSEAAdditionsExtsComponent;
import com.ibm.daimler.dsea.component.XAddressBObjExt;
import com.ibm.daimler.dsea.component.XAddressGroupBObjExt;
import com.ibm.daimler.dsea.extrules.sdp.SurvivorshipRuleUtil;
import com.ibm.daimler.dsea.component.XContEquivBObjExt;
import com.ibm.daimler.dsea.component.XContactMethodGroupBObjExt;
import com.ibm.daimler.dsea.component.XIdentifierBObjExt;
import com.ibm.daimler.dsea.component.XOrgBObjExt;
import com.ibm.daimler.dsea.component.XOrgNameBObjExt;
import com.ibm.daimler.dsea.component.XPersonBObjExt;
import com.ibm.daimler.dsea.component.XPersonNameBObjExt;
import com.ibm.daimler.dsea.component.XPreferenceBObj;
import com.ibm.daimler.dsea.component.XPrivacyAgreementBObj;
import com.ibm.mdm.common.codetype.interfaces.CodeTypeComponentHelper;
import com.ibm.mdm.common.codetype.obj.CodeTypeBObj;


public class ExternalRuleUtil implements ExternalRuleConstant {

	private final static IDWLLogger logger = DWLLoggerManager.getLogger(ExternalRuleUtil.class);
	private IDWLErrorMessage errHandler;
	public static Vector<DWLError> vectReqDWLError = new Vector<DWLError>();
	public ExternalRuleUtil() {
        super();
        IDWLErrorMessage errHandler = TCRMClassFactory.getErrorHandler();
    }


	private QueryConnection connection = null;

	public String generateUCID() throws UCIDException {
		if (logger.isFinestEnabled())
			logger.finest(ExternalRuleConstant.LOG_ENTRY_OF_METHOD
					+ "GenerationOfUCID.generateUCID()");

		String UCIDValue;

		try {
			String deploymentValue = getValueFromDatabase(ExternalRuleConstant.UCID_DEPLOYMENT_PREFIX_KEY);
			String secretStringValue = getValueFromDatabase(ExternalRuleConstant.UCID_SECRET_STRING_PREFIX_KEY);
			String sequenceValue = getSequenceFromDatabase();

			String originalValue = deploymentValue + sequenceValue
					+ secretStringValue;

			MessageDigest md = MessageDigest
					.getInstance(ExternalRuleConstant.HASH_ALGORITHM);
			byte[] hash = md.digest(originalValue
					.getBytes(ExternalRuleConstant.ENCODING));

			String encryptedValue = DatatypeConverter.printHexBinary(hash);
			checkFormatOfEncryptedString(encryptedValue);

			UCIDValue = deploymentValue + sequenceValue
					+ encryptedValue.substring(0, 7);
		} catch (NoSuchAlgorithmException e) {
			String msg = UCIDErrorCodes.CDM_MDM_00000002.getFormattedError("?",
					ExternalRuleConstant.HASH_ALGORITHM);
			logger.error(msg);
			throw new UCIDException(msg, e);
		} catch (UnsupportedEncodingException e) {
			String msg = UCIDErrorCodes.CDM_MDM_00000003.getFormattedError("?",
					ExternalRuleConstant.ENCODING);
			logger.error(msg);
			throw new UCIDException(msg, e);
		} finally {
			try {
				if (connection != null) {
					connection.close();
				}
			} catch (Exception e) {
				if (logger.isWarnEnabled()) {
					String msg = UCIDErrorCodes.CDM_MDM_00000004
							.getFormattedError("?", e.getMessage());
					logger.warn(msg);
				}
			}
		}

		if (logger.isFinestEnabled())
			logger.finest(ExternalRuleConstant.LOG_EXIT_OF_METHOD
					+ "GenerationOfUCID.generateUCID(): " + UCIDValue);
		return UCIDValue;
	}

	protected void setDBConnection() throws UCIDException {
		if (logger.isFinestEnabled())
			logger.finest(ExternalRuleConstant.LOG_ENTRY_OF_METHOD
					+ "setDBConnection()");

		try {
			connection = DataManager.getInstance().getQueryConnection();
			if (connection == null) {
				// should never happen as getQueryConnection returns an
				// exception in case of an error
				String msg = UCIDErrorCodes.CDM_MDM_00000005
						.getFormattedError();
				logger.error(msg);
				throw new UCIDException(msg);
			}
		} catch (ServiceLocatorException e) {
			connection = null;
			String msg = UCIDErrorCodes.CDM_MDM_00000005.getFormattedError();
			logger.error(msg);
			throw new UCIDException(msg, e);
		}

		if (logger.isFinestEnabled())
			logger.finest(ExternalRuleConstant.LOG_EXIT_OF_METHOD
					+ "setDBConnection()");
	}

	protected ResultSet doQuery(String sql, Object[] parameters)
			throws UCIDException {
		if (logger.isFinestEnabled())
			logger.finest(ExternalRuleConstant.LOG_ENTRY_OF_METHOD
					+ "doQuery(String sql, Object[] parameters): " + sql + ", "
					+ parameters);

		setDBConnection();
		ResultSet rs = connection.queryResults(sql, parameters);

		if (logger.isFinestEnabled())
			logger.finest(ExternalRuleConstant.LOG_EXIT_OF_METHOD
					+ "doQuery(String sql, Object[] parameters): " + rs);
		return rs;
	}

	protected String getValueFromDatabase(String key) throws UCIDException {
		if (logger.isFinestEnabled())
			logger.finest(ExternalRuleConstant.LOG_ENTRY_OF_METHOD
					+ "getValueFromDatabase(String key): " + key);

		String value = null;
		Object[] parameters = new Object[1];

		ResultSet resultValueStatement = null;
		parameters[0] = new String(key);

		try {
			resultValueStatement = doQuery(
					ExternalRuleConstant.QUERY_SELECT_VALUE, parameters);

			if (resultValueStatement.next()) {
				value = resultValueStatement.getString(1);
			}
		} catch (SQLException e) {
			String msg = UCIDErrorCodes.CDM_MDM_00000006.getFormattedError();
			logger.error(msg);
			throw new UCIDException(msg, e);
		} finally {
			try {
				if (resultValueStatement != null) {
					resultValueStatement.close();
				}
			} catch (SQLException e) {
				if (logger.isWarnEnabled()) {
					String msg = UCIDErrorCodes.CDM_MDM_00000007
							.getFormattedError();
					logger.warn(msg);
				}
			}
		}

		if (value == null) {
			String msg = UCIDErrorCodes.CDM_MDM_00000001.getFormattedError("?",
					key);
			logger.error(msg);
			throw new UCIDException(msg);
		}

		if (logger.isFinestEnabled())
			logger.finest(ExternalRuleConstant.LOG_EXIT_OF_METHOD
					+ "getValueFromDatabase(String key): " + value);
		return value;
	}

	protected String getSequenceFromDatabase() throws UCIDException {
		if (logger.isFinestEnabled())
			logger.finest(ExternalRuleConstant.LOG_ENTRY_OF_METHOD
					+ "getSequenceFromDatabase()");

		String value = null;
		ResultSet resultSelectSequence = null;

		try {
			resultSelectSequence = doQuery(
					ExternalRuleConstant.QUERY_SELECT_SEQUENCE, null);

			if (resultSelectSequence.next()) {
				long sequenceNumber = resultSelectSequence.getLong(1);
				value = String.format("%010d",
						new Object[] { Long.valueOf(sequenceNumber) });
			}
		} catch (SQLException e) {
			String msg = UCIDErrorCodes.CDM_MDM_00000006.getFormattedError();
			logger.error(msg);
			throw new UCIDException(msg, e);
		} finally {
			try {
				if (resultSelectSequence != null) {
					resultSelectSequence.close();
				}
			} catch (SQLException e) {
				if (logger.isWarnEnabled()) {
					String msg = UCIDErrorCodes.CDM_MDM_00000007
							.getFormattedError();
					logger.warn(msg);
				}
			}
		}

		if (value == null) {
			String msg = UCIDErrorCodes.CDM_MDM_00000008.getFormattedError();
			logger.error(msg);
			throw new UCIDException(msg);
		}

		if (logger.isFinestEnabled())
			logger.finest(ExternalRuleConstant.LOG_EXIT_OF_METHOD
					+ "getSequenceFromDatabase(): " + value);
		return value;
	}

	private void checkFormatOfEncryptedString(String encryptedValue)
			throws UCIDException {
		if (logger.isFinestEnabled())
			logger.finest(ExternalRuleConstant.LOG_ENTRY_OF_METHOD
					+ "checkFormatOfEncryptedString(String encryptedValue): "
					+ encryptedValue);

		if ((encryptedValue == null) || (encryptedValue.isEmpty())
				|| encryptedValue.length() < 7) {
			String msg = UCIDErrorCodes.CDM_MDM_00000009.getFormattedError("?",
					encryptedValue);
			logger.error(msg);
			throw new UCIDException(msg);
		}

		if (logger.isFinestEnabled())
			logger.finest(ExternalRuleConstant.LOG_EXIT_OF_METHOD
					+ "checkFormatOfEncryptedString(String encryptedValue)");
	}

	// Collapse parties logic start
	// CRR Logic start
	public void survivedCRRDetails(Vector<TCRMPartyBObj> vecParties,
			TCRMPartyBObj collapsedPartyBObj, DWLControl control)
			throws Exception {
		HashMap<String, XCustomerRetailerBObj> xCustomerRetailerMap = new HashMap<String, XCustomerRetailerBObj>();
		Vector<XCustomerRetailerBObj> vecXCustomerRetailerBObjs = new Vector<XCustomerRetailerBObj>();
		DWLResponse dwlResponse = new DWLResponse();
		DWLResponse response = null;
		DSEAAdditionsExtsComponent dseaAdditionsExtsComponent = new DSEAAdditionsExtsComponent();
		String partytId = null;
		String retailerCode = null;
		Vector<XRetailerBObj> vecDBRetailBObj = null;
		String collapsedPartyId = collapsedPartyBObj.getPartyId();

		for (TCRMPartyBObj partyBObj : vecParties) {
			partytId = partyBObj.getPartyId();
			dwlResponse = dseaAdditionsExtsComponent
					.getAllXCustomerRetailerByPartyId(partytId, control);
			if (dwlResponse.getData() != null) {
				vecXCustomerRetailerBObjs = (Vector<XCustomerRetailerBObj>) dwlResponse
						.getData();
			}
			for (int j = 0; j < vecXCustomerRetailerBObjs.size(); j++) {
				XCustomerRetailerBObj xCustomerRetailerBObj = (XCustomerRetailerBObj) vecXCustomerRetailerBObjs
						.get(j);
				if (!xCustomerRetailerMap.containsKey(xCustomerRetailerBObj
						.getXRetailerBObj().getRetailerCode())) {
					xCustomerRetailerMap.put(xCustomerRetailerBObj
							.getXRetailerBObj().getRetailerCode(),
							xCustomerRetailerBObj);
				} else {
					XCustomerRetailerBObj xContretailerBObjInMap = xCustomerRetailerMap
							.get(xCustomerRetailerBObj.getXRetailerBObj()
									.getRetailerCode());
					Timestamp requestPersonLastModifiedDt = DateFormatter
							.getTimestamp(xContretailerBObjInMap
									.getXRetailerBObj()
									.getLastModifiedSystemDate());
					Timestamp existingPersonLastModifiedDt = DateFormatter
							.getTimestamp(xCustomerRetailerBObj
									.getXRetailerBObj()
									.getLastModifiedSystemDate());
					if (requestPersonLastModifiedDt.after(existingPersonLastModifiedDt)) {
						xCustomerRetailerMap.put(xContretailerBObjInMap
								.getXRetailerBObj().getRetailerCode(),
								xContretailerBObjInMap);
					} else {
						xCustomerRetailerMap.put(xCustomerRetailerBObj
								.getXRetailerBObj().getRetailerCode(),
								xCustomerRetailerBObj);
					}

				}

			}
		}

		for (Map.Entry<String, XCustomerRetailerBObj> entry : xCustomerRetailerMap
				.entrySet()) {
			XCustomerRetailerBObj tempXCustomerRetailerBObj = entry.getValue();
			XCustomerRetailerBObj survivedXCustomerRetailerBObj = new XCustomerRetailerBObj();
			survivedXCustomerRetailerBObj = tempXCustomerRetailerBObj;
			survivedXCustomerRetailerBObj.setContId(collapsedPartyId);
			survivedXCustomerRetailerBObj.setControl(control);
			retailerCode = survivedXCustomerRetailerBObj.getXRetailerBObj()
					.getRetailerCode();
			vecDBRetailBObj = retailerObjectByRetailerCode(retailerCode,
					control);
			if (vecDBRetailBObj == null || vecDBRetailBObj.isEmpty()) {
				response = dseaAdditionsExtsComponent
						.addXCustomerRetailer(survivedXCustomerRetailerBObj);
			} else {
				survivedXCustomerRetailerBObj.getXRetailerBObj()
						.setRetailerpkId(
								vecDBRetailBObj.get(0).getRetailerpkId());
				survivedXCustomerRetailerBObj.getXRetailerBObj()
						.setXRetailerLastUpdateDate(
								vecDBRetailBObj.get(0)
										.getXRetailerLastUpdateDate());
				survivedXCustomerRetailerBObj.setRetailerId(vecDBRetailBObj
						.get(0).getRetailerpkId());
				response = dseaAdditionsExtsComponent
						.addXCustomerRetailer(survivedXCustomerRetailerBObj);
			}
			if (response.getStatus().getStatus() == DWLStatus.FATAL) {
				throw new BusinessProxyException();
			}
		}
	}

	public Vector<XRetailerBObj> retailerObjectByRetailerCode(
			String retailerCode, DWLControl control) throws Exception {
		Vector<XRetailerBObj> resultRetailerBObj = new Vector<XRetailerBObj>();
		List<SQLParam> params = new ArrayList<SQLParam>();
		params.add(0, new SQLParam(retailerCode));
		resultRetailerBObj = executeQueryRetailerObject(
				ExternalRuleConstant.GET_RETAILER_IDPK, params, control);
		return resultRetailerBObj;
	}
	
	public Vector<XRetailerBObj> retailerObjectByNDCode(
			String ndCode, DWLControl control) throws Exception {
		Vector<XRetailerBObj> resultRetailerBObj = new Vector<XRetailerBObj>();
		List<SQLParam> params = new ArrayList<SQLParam>();
		params.add(0, new SQLParam(ndCode));
		resultRetailerBObj = executeQueryRetailerObject(
				ExternalRuleConstant.GET_RETAILER_IDPK_BY_NDCODE, params, control);
		return resultRetailerBObj;
	}

	public Vector<XRetailerBObj> executeQueryRetailerObject(
			String sqlStatement, List params, DWLControl control)
			throws Exception {

		Vector<XRetailerBObj> resultContVechRel = new Vector<XRetailerBObj>();
		DSEAAdditionsExtsComponent dSEAAdditionsExtsComponent = new DSEAAdditionsExtsComponent();
		String xRetailerId = null;
		SQLQuery query = new SQLQuery();
		ResultSet rs = null;
		try {
			rs = query.executeQuery(sqlStatement, params);
			if (rs.next()) {
				do {
					xRetailerId = rs
							.getString(ExternalRuleConstant.RETAILER_ID);
					XRetailerBObj contVechRelObj = ((XRetailerBObj) (dSEAAdditionsExtsComponent
							.getXRetailer(xRetailerId, control)).getData());
					if (contVechRelObj != null) {
						resultContVechRel.add(contVechRelObj);
					}
				} while (rs.next());
			}
		} catch (Exception e) {
			throw e;
		} finally {
			if (rs != null && !rs.isClosed()) {
				rs.close();
				rs = null;
			}
			query.close();
		}

		return resultContVechRel;

	}

	// CRR Logic end

	// CVR Logic start
	public void survivedCVRDetails(Vector<TCRMPartyBObj> vecParties,
			TCRMPartyBObj collapsedPartyBObj, DWLControl control)
			throws Exception {
		HashMap<String, XCustomerVehicleBObj> xCustomerVehicleMap = new HashMap<String, XCustomerVehicleBObj>();
		Vector<XCustomerVehicleBObj> vecXCustomerVehicleBObjs = new Vector<XCustomerVehicleBObj>();
		DWLResponse dwlResponse = new DWLResponse();
		DWLResponse response = null;
		DSEAAdditionsExtsComponent dseaAdditionsExtsComponent = new DSEAAdditionsExtsComponent();
		String partytId = null;
		String globalVIN = null;
		String requestPersonRetailerCode = null;
		String existingPersonRetailerCode = null;
		Vector<XVehicleBObj> vecDBVehicleBObj = null;
		String collapsedPartyId = collapsedPartyBObj.getPartyId();
		Vector<XCustomerVehicleRoleBObj> vecParty1XCustomerVehicleRoleBObjs = new Vector<XCustomerVehicleRoleBObj>();
		Vector<XCustomerVehicleRoleBObj> vecParty2XCustomerVehicleRoleBObjs = new Vector<XCustomerVehicleRoleBObj>();
		Vector<XCustomerVehicleRoleBObj> vecSurvivedVehicleRoleBObjs = new Vector<XCustomerVehicleRoleBObj>();
		Vector<XCustomerVehicleRoleBObj> vecFinalVehicleRoleBObjs = new Vector<XCustomerVehicleRoleBObj>();

		for (TCRMPartyBObj partyBObj : vecParties) {
			partytId = partyBObj.getPartyId();
			vecXCustomerVehicleBObjs = getAllXCustomerVehicleByPartyId(
					partytId, control);
			if (vecXCustomerVehicleBObjs != null
					&& vecXCustomerVehicleBObjs.size() > 0) {
				for (int j = 0; j < vecXCustomerVehicleBObjs.size(); j++) {
					XCustomerVehicleBObj xCustomerVehicleBObj = (XCustomerVehicleBObj) vecXCustomerVehicleBObjs
							.get(j);
					
					if (!xCustomerVehicleMap.containsKey((xCustomerVehicleBObj
							.getXVehicleBObj().getGlobalVIN()) + (xCustomerVehicleBObj.getRetailerId()))) {
						xCustomerVehicleMap.put((xCustomerVehicleBObj
								.getXVehicleBObj().getGlobalVIN()) + (xCustomerVehicleBObj.getRetailerId()),
								xCustomerVehicleBObj);
					} else {
						XCustomerVehicleBObj xContVehicleBObjInMap = xCustomerVehicleMap
								.get((xCustomerVehicleBObj
										.getXVehicleBObj().getGlobalVIN()) + (xCustomerVehicleBObj.getRetailerId()));
						requestPersonRetailerCode = xContVehicleBObjInMap
								.getRetailerId();
						existingPersonRetailerCode = xCustomerVehicleBObj
								.getRetailerId();

						if (requestPersonRetailerCode != null
								&& existingPersonRetailerCode != null
								&& requestPersonRetailerCode
										.equalsIgnoreCase(existingPersonRetailerCode)) {
							Timestamp requestPersonLastModifiedDt = DateFormatter
									.getTimestamp(xContVehicleBObjInMap
											.getXCustomerVehicleLastUpdateDate());
							Timestamp existingPersonLastModifiedDt = DateFormatter
									.getTimestamp(xCustomerVehicleBObj
											.getXCustomerVehicleLastUpdateDate());
							if (requestPersonLastModifiedDt
									.after(existingPersonLastModifiedDt)) {
								vecParty1XCustomerVehicleRoleBObjs = xContVehicleBObjInMap
										.getItemsXCustomerVehicleRoleBObj();

								if (vecParty1XCustomerVehicleRoleBObjs != null
										&& vecParty1XCustomerVehicleRoleBObjs
												.size() > 0) {
									for (XCustomerVehicleRoleBObj xCustomerVehicleRoleBObj : vecParty1XCustomerVehicleRoleBObjs) {
										if (xCustomerVehicleRoleBObj
												.getEndDate() == null) {
											vecFinalVehicleRoleBObjs
													.add(xCustomerVehicleRoleBObj);
										}

									}
								}

								xContVehicleBObjInMap
										.getItemsXCustomerVehicleRoleBObj()
										.clear();
								xContVehicleBObjInMap
										.getItemsXCustomerVehicleRoleBObj()
										.addAll(vecFinalVehicleRoleBObjs);

							} else {
								vecParty2XCustomerVehicleRoleBObjs = xCustomerVehicleBObj
										.getItemsXCustomerVehicleRoleBObj();

								if (vecParty2XCustomerVehicleRoleBObjs != null
										&& vecParty2XCustomerVehicleRoleBObjs
												.size() > 0) {

									for (XCustomerVehicleRoleBObj xCustomerVehicleRoleBObj : vecParty2XCustomerVehicleRoleBObjs) {
										if (xCustomerVehicleRoleBObj
												.getEndDate() == null) {
											vecFinalVehicleRoleBObjs
													.add(xCustomerVehicleRoleBObj);
										}

									}

								}

								xCustomerVehicleBObj
										.getItemsXCustomerVehicleRoleBObj()
										.clear();
								xCustomerVehicleBObj
										.getItemsXCustomerVehicleRoleBObj()
										.addAll(vecParty2XCustomerVehicleRoleBObjs);

							}

							Timestamp person1ModifiedDt = DateFormatter
									.getTimestamp(xContVehicleBObjInMap
											.getXCustomerVehicleLastUpdateDate());

							Timestamp person2ModifiedDt = DateFormatter
									.getTimestamp(xCustomerVehicleBObj
											.getXCustomerVehicleLastUpdateDate());

							if (person1ModifiedDt.after(person2ModifiedDt)) {

								xCustomerVehicleMap.put((xContVehicleBObjInMap
										.getXVehicleBObj().getGlobalVIN()) + (xContVehicleBObjInMap.getRetailerId()),
										xContVehicleBObjInMap);
							}

							else {

								xCustomerVehicleMap.put((xCustomerVehicleBObj
										.getXVehicleBObj().getGlobalVIN()) + (xCustomerVehicleBObj.getRetailerId()),
										xCustomerVehicleBObj);
							}

						} else {

							xCustomerVehicleMap.put((xCustomerVehicleBObj
									.getXVehicleBObj().getGlobalVIN()) + (xCustomerVehicleBObj.getRetailerId()),
									xCustomerVehicleBObj);
						}

					}

				}
			}
		}

		for (Map.Entry<String, XCustomerVehicleBObj> entry : xCustomerVehicleMap
				.entrySet()) {
			XCustomerVehicleBObj tempXCustomerVehicleBObj = entry.getValue();
			XCustomerVehicleBObj survivedXCustomerVehicleBObj = new XCustomerVehicleBObj();
			survivedXCustomerVehicleBObj = tempXCustomerVehicleBObj;
			survivedXCustomerVehicleBObj.setContId(collapsedPartyId);
			survivedXCustomerVehicleBObj.setControl(control);
			globalVIN = survivedXCustomerVehicleBObj.getXVehicleBObj()
					.getGlobalVIN();
			vecDBVehicleBObj = vehicleObjectByGVIN(globalVIN, control);
			if (vecDBVehicleBObj == null || vecDBVehicleBObj.isEmpty()) {
				response = dseaAdditionsExtsComponent
						.addXCustomerVehicle(survivedXCustomerVehicleBObj);
			} else {
				survivedXCustomerVehicleBObj.getXVehicleBObj().setVehiclepkId(
						vecDBVehicleBObj.get(0).getVehiclepkId());
				survivedXCustomerVehicleBObj.getXVehicleBObj()
						.setXVehicleLastUpdateDate(
								vecDBVehicleBObj.get(0)
										.getXVehicleLastUpdateDate());
				survivedXCustomerVehicleBObj.setVehicleId(vecDBVehicleBObj.get(
						0).getVehiclepkId());
				response = dseaAdditionsExtsComponent
						.addXCustomerVehicle(survivedXCustomerVehicleBObj);
			}
			if (response.getStatus().getStatus() == DWLStatus.FATAL) {
				throw new BusinessProxyException();
			}
		}
	}

	public Vector<XCustomerVehicleBObj> getAllXCustomerVehicleByPartyId(
			String partyId, DWLControl control) throws Exception {
		Vector<XCustomerVehicleBObj> resultVehicleBObj = new Vector<XCustomerVehicleBObj>();
		List<SQLParam> params = new ArrayList<SQLParam>();
		params.add(0, new SQLParam(partyId));
		resultVehicleBObj = executeQueryAllVehicle(ExternalRuleConstant.GET_CUSTOMERVEHICLE_IDPK, params, control);
		return resultVehicleBObj;
	}
	
	public Vector<XCustomerVehicleKORBObj> getAllXCustomerVehicleKORByPartyId(String partyId, DWLControl control) throws Exception {
		Vector<XCustomerVehicleKORBObj> resultVehicleBObj = new Vector<XCustomerVehicleKORBObj>();
		List<SQLParam> params = new ArrayList<SQLParam>();
		params.add(0, new SQLParam(partyId));
		resultVehicleBObj = executeQueryAllVehicleKOR(ExternalRuleConstant.GET_CUSTOMERVEHICLEKOR_IDPK, params, control);
		return resultVehicleBObj;
	}

	public Vector<XCustomerVehicleKORBObj> executeQueryAllVehicleKOR(
			String sqlStatement, List params, DWLControl control) throws Exception, ServiceLocatorException, ClassNotFoundException, SQLException
			 {

		Vector<XCustomerVehicleKORBObj> resultContVechRel = new Vector<XCustomerVehicleKORBObj>();
		DSEAAdditionsExtsComponent dSEAAdditionsExtsComponent = new DSEAAdditionsExtsComponent();
		String customerVehicleId = null;
		SQLQuery query = new SQLQuery();
		ResultSet rs = null;
		try {
			rs = query.executeQuery(sqlStatement, params);
			if (rs.next()) {
				do {
					customerVehicleId = rs.getString(ExternalRuleConstant.CUSTOMERVEHICLEKOR_ID);
					XCustomerVehicleKORBObj contVechRelObj = ((XCustomerVehicleKORBObj) (dSEAAdditionsExtsComponent.getXCustomerVehicleKOR(customerVehicleId, control)).getData());
					if (contVechRelObj != null) {
						resultContVechRel.add(contVechRelObj);
					}
				} while (rs.next());
			}
		} catch (DWLExtensionException e) {
			 DWLExceptionUtils.throwDWLBaseException(e, 
						new DWLUpdateException(e.getMessage()), null, DWLStatus.FATAL, DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_KORBOBJ, "DIERR",
						DSEAAdditionsExtsErrorReasonCode.XCUSTOMERVEHICLEKOR_BEFORE_IMAGE_NOT_POPULATED, control, errHandler);
		} finally {
			if (rs != null && !rs.isClosed()) {
				rs.close();
				rs = null;
			}
			query.close();
		}

		return resultContVechRel;

	}
	public Vector<XCustomerVehicleBObj> executeQueryAllVehicle(
			String sqlStatement, List params, DWLControl control) throws Exception, ServiceLocatorException, ClassNotFoundException, SQLException
			 {

		Vector<XCustomerVehicleBObj> resultContVechRel = new Vector<XCustomerVehicleBObj>();
		DSEAAdditionsExtsComponent dSEAAdditionsExtsComponent = new DSEAAdditionsExtsComponent();
		String customerVehicleId = null;
		SQLQuery query = new SQLQuery();
		ResultSet rs = null;
		try {
			rs = query.executeQuery(sqlStatement, params);
			if (rs.next()) {
				do {
					customerVehicleId = rs.getString(ExternalRuleConstant.CUSTOMERVEHICLE_ID);
					XCustomerVehicleBObj contVechRelObj = ((XCustomerVehicleBObj) (dSEAAdditionsExtsComponent.getXCustomerVehicle(customerVehicleId, control)).getData());
					if (contVechRelObj != null) {
						resultContVechRel.add(contVechRelObj);
					}
				} while (rs.next());
			}
		} catch (DWLExtensionException e) {
			 DWLExceptionUtils.throwDWLBaseException(e, 
						new DWLUpdateException(e.getMessage()), null, DWLStatus.FATAL, DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_BOBJ, "DIERR",
						DSEAAdditionsExtsErrorReasonCode.XCUSTOMERVEHICLE_BEFORE_IMAGE_NOT_POPULATED, control, errHandler);
		} finally {
			if (rs != null && !rs.isClosed()) {
				rs.close();
				rs = null;
			}
			query.close();
		}

		return resultContVechRel;

	}

	public Vector<XVehicleBObj> vehicleObjectByGVIN(String globalVIN,
			DWLControl control) throws Exception {
		Vector<XVehicleBObj> resultVehicleBObj = new Vector<XVehicleBObj>();
		List<SQLParam> params = new ArrayList<SQLParam>();
		params.add(0, new SQLParam(globalVIN));
		resultVehicleBObj = executeQueryVehicleObject(
				ExternalRuleConstant.GET_VEHICLE_IDPK, params, control);
		return resultVehicleBObj;
	}
	public Vector<XVehicleKORBObj> vehicleObjectByGVIN_KOR(String globalVIN,DWLControl control) throws Exception {
		Vector<XVehicleKORBObj> resultVehicleBObj = new Vector<XVehicleKORBObj>();
		List<SQLParam> params = new ArrayList<SQLParam>();
		params.add(0, new SQLParam(globalVIN));
		resultVehicleBObj = executeQueryVehicleKORObject(ExternalRuleConstant.GET_VEHICLE_IDPK_KOR, params, control);
		return resultVehicleBObj;
	}
	
	public Vector<XVehicleKORBObj> executeQueryVehicleKORObject(String sqlStatement,List params, DWLControl control) throws Exception {

		Vector<XVehicleKORBObj> resultContVechRel = new Vector<XVehicleKORBObj>();
		DSEAAdditionsExtsComponent dSEAAdditionsExtsComponent = new DSEAAdditionsExtsComponent();
		String xVehicleId = null;
		SQLQuery query = new SQLQuery();
		ResultSet rs = null;
		try {
			rs = query.executeQuery(sqlStatement, params);
			if (rs.next()) {
				do {
					xVehicleId = rs.getString(ExternalRuleConstant.VEHICLE_ID_KOR);
					XVehicleKORBObj contVechRelObj = ((XVehicleKORBObj) (dSEAAdditionsExtsComponent.getXVehicleKOR(xVehicleId, control)).getData());
					if (contVechRelObj != null) {
						resultContVechRel.add(contVechRelObj);
					}
				} while (rs.next());
			}
		} catch (Exception e) {
			throw e;
		} finally {
			if (rs != null && !rs.isClosed()) {
				rs.close();
				rs = null;
			}
			query.close();
		}

		return resultContVechRel;

	}
	
	public Vector<XVehicleBObj> executeQueryVehicleObject(String sqlStatement,
			List params, DWLControl control) throws Exception {

		Vector<XVehicleBObj> resultContVechRel = new Vector<XVehicleBObj>();
		DSEAAdditionsExtsComponent dSEAAdditionsExtsComponent = new DSEAAdditionsExtsComponent();
		String xVehicleId = null;
		SQLQuery query = new SQLQuery();
		ResultSet rs = null;
		try {
			rs = query.executeQuery(sqlStatement, params);
			if (rs.next()) {
				do {
					xVehicleId = rs.getString(ExternalRuleConstant.VEHICLE_ID);
					XVehicleBObj contVechRelObj = ((XVehicleBObj) (dSEAAdditionsExtsComponent
							.getXVehicle(xVehicleId, control)).getData());
					if (contVechRelObj != null) {
						resultContVechRel.add(contVechRelObj);
					}
				} while (rs.next());
			}
		} catch (Exception e) {
			throw e;
		} finally {
			if (rs != null && !rs.isClosed()) {
				rs.close();
				rs = null;
			}
			query.close();
		}

		return resultContVechRel;

	}


	//AU NZ CVR Logic Start

	/**
	 * 
	 * @param vecParties
	 * @param collapsedPartyAusBObj
	 * @param control
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	public void survivedCVRDetailsAus(Vector<TCRMPartyBObj> vecParties, TCRMPartyBObj collapsedPartyAusBObj, DWLControl control)throws Exception
	{
		HashMap<String, XCustomerVehicleAusBObj> xCustomerVehicleAusMap = new HashMap<String, XCustomerVehicleAusBObj>();
		Vector<XCustomerVehicleAusBObj> vecXCustomerVehicleAusBObjs = new Vector<XCustomerVehicleAusBObj>();
		DWLResponse dwlResponse = new DWLResponse();
		DWLResponse response = null;
		DSEAAdditionsExtsComponent dseaAdditionsExtsComponent = new DSEAAdditionsExtsComponent();
		String partytId = null;
		String globalVIN = null;
		String requestCustomerRetailerCode = null;
		String existingCustomerRetailerCode = null;
		Vector<XVehicleAusBObj> vecDBVehicleAusBObj = null;
		String collapsedPartyId = collapsedPartyAusBObj.getPartyId();
		Vector<XCustomerVehicleRoleAusBObj> vecParty1XCustomerVehicleRoleAusBObjs = new Vector<XCustomerVehicleRoleAusBObj>();
		Vector<XCustomerVehicleRoleAusBObj> vecParty2XCustomerVehicleRoleAusBObjs = new Vector<XCustomerVehicleRoleAusBObj>();
		Vector<XCustomerVehicleRoleAusBObj> vecSurvivedVehicleRoleAusBObjs = new Vector<XCustomerVehicleRoleAusBObj>();
		Vector<XCustomerVehicleRoleAusBObj> vecFinalVehicleRoleAusBObjs = new Vector<XCustomerVehicleRoleAusBObj>();

		for (TCRMPartyBObj partyAusBObj : vecParties)
		{
			partytId = partyAusBObj.getPartyId();

			//retrieve all vehicle rels from db by cont id
			vecXCustomerVehicleAusBObjs = getAllXCustomerVehicleAusByPartyId(partytId, control);

			if (vecXCustomerVehicleAusBObjs != null && vecXCustomerVehicleAusBObjs.size() > 0)
			{
				for (int j = 0; j < vecXCustomerVehicleAusBObjs.size(); j++)
				{
					XCustomerVehicleAusBObj XCustomerVehicleAusBObj = (XCustomerVehicleAusBObj) vecXCustomerVehicleAusBObjs.get(j);

					if (!xCustomerVehicleAusMap.containsKey((XCustomerVehicleAusBObj.getXVehicleAusBObj().getGlobalVIN()) + (XCustomerVehicleAusBObj.getRetailerId()))) 
					{
						xCustomerVehicleAusMap.put((XCustomerVehicleAusBObj.getXVehicleAusBObj().getGlobalVIN()) + (XCustomerVehicleAusBObj.getRetailerId()),XCustomerVehicleAusBObj);
					} 
					else 
					{
						XCustomerVehicleAusBObj xContVehicleAusBObjInMap = xCustomerVehicleAusMap.get((XCustomerVehicleAusBObj.getXVehicleAusBObj().getGlobalVIN()) + (XCustomerVehicleAusBObj.getRetailerId()));
						requestCustomerRetailerCode = xContVehicleAusBObjInMap.getRetailerId();
						existingCustomerRetailerCode = XCustomerVehicleAusBObj.getRetailerId();

						if (requestCustomerRetailerCode != null&& existingCustomerRetailerCode != null&& requestCustomerRetailerCode.equalsIgnoreCase(existingCustomerRetailerCode)) 
						{
							Timestamp mapCustomerLastModifiedDt = DateFormatter.getTimestamp(xContVehicleAusBObjInMap.getXCustomerVehicleAusLastUpdateDate());
							Timestamp existingCustomerLastModifiedDt = DateFormatter.getTimestamp(XCustomerVehicleAusBObj.getXCustomerVehicleAusLastUpdateDate());

							if (mapCustomerLastModifiedDt.after(existingCustomerLastModifiedDt)) 
							{
								vecParty1XCustomerVehicleRoleAusBObjs = xContVehicleAusBObjInMap.getItemsXCustomerVehicleRoleAusBObj();
								if (vecParty1XCustomerVehicleRoleAusBObjs != null&& vecParty1XCustomerVehicleRoleAusBObjs.size() > 0) 
								{
									for (XCustomerVehicleRoleAusBObj XCustomerVehicleRoleAusBObj : vecParty1XCustomerVehicleRoleAusBObjs) 
									{
										if (XCustomerVehicleRoleAusBObj.getEndDate() == null) 
										{
											vecFinalVehicleRoleAusBObjs.add(XCustomerVehicleRoleAusBObj);
										}
									}
								}

								xContVehicleAusBObjInMap.getItemsXCustomerVehicleRoleAusBObj().clear();
								xContVehicleAusBObjInMap.getItemsXCustomerVehicleRoleAusBObj().addAll(vecFinalVehicleRoleAusBObjs);
							} 
							else 
							{
								vecParty2XCustomerVehicleRoleAusBObjs = XCustomerVehicleAusBObj.getItemsXCustomerVehicleRoleAusBObj();

								if (vecParty2XCustomerVehicleRoleAusBObjs != null&& vecParty2XCustomerVehicleRoleAusBObjs.size() > 0)
								{
									for (XCustomerVehicleRoleAusBObj XCustomerVehicleRoleAusBObj : vecParty2XCustomerVehicleRoleAusBObjs) 
									{
										if (XCustomerVehicleRoleAusBObj.getEndDate() == null) {vecFinalVehicleRoleAusBObjs.add(XCustomerVehicleRoleAusBObj);}
									}
								}

								XCustomerVehicleAusBObj.getItemsXCustomerVehicleRoleAusBObj().clear();
								XCustomerVehicleAusBObj.getItemsXCustomerVehicleRoleAusBObj().addAll(vecParty2XCustomerVehicleRoleAusBObjs);

							}

							Timestamp custVehRel1ModifiedDt = DateFormatter.getTimestamp(xContVehicleAusBObjInMap.getXCustomerVehicleAusLastUpdateDate());
							Timestamp custVehRel2ModifiedDt = DateFormatter.getTimestamp(XCustomerVehicleAusBObj.getXCustomerVehicleAusLastUpdateDate());

							if (custVehRel1ModifiedDt.after(custVehRel2ModifiedDt)) 
							{

								xCustomerVehicleAusMap.put((xContVehicleAusBObjInMap.getXVehicleAusBObj().getGlobalVIN()) + (xContVehicleAusBObjInMap.getRetailerId()),xContVehicleAusBObjInMap);
							}

							else
							{
								xCustomerVehicleAusMap.put((XCustomerVehicleAusBObj.getXVehicleAusBObj().getGlobalVIN()) + (XCustomerVehicleAusBObj.getRetailerId()),XCustomerVehicleAusBObj);
							}

						} else 
						{
							xCustomerVehicleAusMap.put((XCustomerVehicleAusBObj.getXVehicleAusBObj().getGlobalVIN()) + (XCustomerVehicleAusBObj.getRetailerId()),XCustomerVehicleAusBObj);
						}

					}

				}
			}
		}

		for (Map.Entry<String, XCustomerVehicleAusBObj> entry : xCustomerVehicleAusMap.entrySet()) 
		{
			XCustomerVehicleAusBObj tempXCustomerVehicleAusBObj = entry.getValue();
			XCustomerVehicleAusBObj survivedXCustomerVehicleAusBObj = new XCustomerVehicleAusBObj();
			survivedXCustomerVehicleAusBObj = tempXCustomerVehicleAusBObj;
			survivedXCustomerVehicleAusBObj.setContId(collapsedPartyId);
			survivedXCustomerVehicleAusBObj.setControl(control);
			globalVIN = survivedXCustomerVehicleAusBObj.getXVehicleAusBObj().getGlobalVIN();
			vecDBVehicleAusBObj = vehicleObjectByGVINAus(globalVIN, control);

			if (vecDBVehicleAusBObj == null || vecDBVehicleAusBObj.isEmpty()) {
				response = dseaAdditionsExtsComponent.addXCustomerVehicleAus(survivedXCustomerVehicleAusBObj);
			} 
			else 
			{
				survivedXCustomerVehicleAusBObj.getXVehicleAusBObj().setXVehicleAuspkId(vecDBVehicleAusBObj.get(0).getXVehicleAuspkId());
				survivedXCustomerVehicleAusBObj.getXVehicleAusBObj().setXVehicleAusLastUpdateDate(vecDBVehicleAusBObj.get(0).getXVehicleAusLastUpdateDate());
				survivedXCustomerVehicleAusBObj.setVehicleId(vecDBVehicleAusBObj.get(0).getXVehicleAuspkId());
				response = dseaAdditionsExtsComponent.addXCustomerVehicleAus(survivedXCustomerVehicleAusBObj);
			}
			if (response.getStatus().getStatus() == DWLStatus.FATAL) {
				throw new BusinessProxyException();
			}
		}
	}


	public Vector<XCustomerVehicleAusBObj> getAllXCustomerVehicleAusByPartyId(String partyId, DWLControl control) throws Exception 
	{
		Vector<XCustomerVehicleAusBObj> resultVehicleAusBObj = new Vector<XCustomerVehicleAusBObj>();
		List<SQLParam> params = new ArrayList<SQLParam>();
		params.add(0, new SQLParam(partyId));
		resultVehicleAusBObj = executeQueryAllVehicleAus(ExternalRuleConstant.GET_CUSTOMERVEHICLEAUS_ID_PK, params, control);
		return resultVehicleAusBObj;
	}

	@SuppressWarnings("rawtypes")
	public Vector<XCustomerVehicleAusBObj> executeQueryAllVehicleAus(String sqlStatement, List params, DWLControl control) throws Exception, ServiceLocatorException, ClassNotFoundException, SQLException
	{

		Vector<XCustomerVehicleAusBObj> resultContVechRel = new Vector<XCustomerVehicleAusBObj>();
		DSEAAdditionsExtsComponent dSEAAdditionsExtsComponent = new DSEAAdditionsExtsComponent();
		String customerVehicleAusId = null;
		SQLQuery query = new SQLQuery();
		ResultSet rs = null;
		try {
			rs = query.executeQuery(sqlStatement, params);
			if (rs.next()) {
				do {
					customerVehicleAusId = rs.getString(ExternalRuleConstant.XCUSTOMER_VEHICLE_AUSPK_ID);
					XCustomerVehicleAusBObj contVechRelObj = ((XCustomerVehicleAusBObj) (dSEAAdditionsExtsComponent.getXCustomerVehicleAus(customerVehicleAusId, control)).getData());
					if (contVechRelObj != null)
					{
						resultContVechRel.add(contVechRelObj);
					}
				} while (rs.next());
			}
		} 
		catch (DWLExtensionException e)
		{
			DWLExceptionUtils.throwDWLBaseException(e, 
					new DWLUpdateException(e.getMessage()), null, DWLStatus.FATAL, DSEAAdditionsExtsComponentID.XCUSTOMER_VEHICLE_AUS_BOBJ, "DIERR",
					DSEAAdditionsExtsErrorReasonCode.XCUSTOMERVEHICLEAUS_BEFORE_IMAGE_NOT_POPULATED, control, errHandler);
		} 
		finally 
		{
			if (rs != null && !rs.isClosed())
			{
				rs.close();
				rs = null;
			}
			query.close();
		}

		return resultContVechRel;

	}
	/**
	 * 
	 * @param globalVIN
	 * @param control
	 * @return
	 * @throws Exception
	 */
	public Vector<XVehicleAusBObj> vehicleObjectByGVINAus(String globalVIN,DWLControl control) throws Exception 
	{
		Vector<XVehicleAusBObj> resultVehicleAusBObj = new Vector<XVehicleAusBObj>();
		List<SQLParam> params = new ArrayList<SQLParam>();
		params.add(0, new SQLParam(globalVIN));
		resultVehicleAusBObj = executeQueryVehicleAusObject(ExternalRuleConstant.GET_VEHICLE_AUS_ID_PK, params, control);
		return resultVehicleAusBObj;
	}

	/**
	 * 
	 * @param sqlStatement
	 * @param params
	 * @param control
	 * @return
	 * @throws Exception
	 */
	public Vector<XVehicleAusBObj> executeQueryVehicleAusObject(String sqlStatement,List params, DWLControl control) throws Exception 
	{

		Vector<XVehicleAusBObj> resultContVechRel = new Vector<XVehicleAusBObj>();
		DSEAAdditionsExtsComponent dSEAAdditionsExtsComponent = new DSEAAdditionsExtsComponent();
		String xVehicleAusId = null;
		SQLQuery query = new SQLQuery();
		ResultSet rs = null;
		try {
			rs = query.executeQuery(sqlStatement, params);
			if (rs.next()) {
				do {
					xVehicleAusId = rs.getString(ExternalRuleConstant.VEHICLE_AUS_ID);
					XVehicleAusBObj contVechRelObj = ((XVehicleAusBObj) (dSEAAdditionsExtsComponent.getXVehicleAus(xVehicleAusId, control)).getData());
					if (contVechRelObj != null) {
						resultContVechRel.add(contVechRelObj);
					}
				} while (rs.next());
			}
		} catch (Exception e) {
			throw e;
		} finally {
			if (rs != null && !rs.isClosed()) {
				rs.close();
				rs = null;
			}
			query.close();
		}

		return resultContVechRel;

	}


	//AU NZ CVR Logic End
	
	//2019-04-10 AU NZ CCR Logic : Start
	/**
	 * 
	 * @param vecParties
	 * @param collapsedPartyBObj
	 * @param control
	 * @throws Exception
	 */
		public void survivedCCRDetailsForAus(Vector<TCRMPartyBObj> vecParties,TCRMPartyBObj collapsedPartyBObj, DWLControl control) throws Exception
		{
			String partytId = null;
			Vector<XContactRelBObjExt> vecPartyRelationshipResponse = new Vector<XContactRelBObjExt>();
			Vector<XContactRelBObjExt> vecPartyRelationshipResponseTo = new Vector<XContactRelBObjExt>();
			Vector<XContactRelBObjExt> vecPartyRelationshipResponseFrom = new Vector<XContactRelBObjExt>();

			TCRMPartyComponent partyComponent = new TCRMPartyComponent();				

			HashMap<String, XContactRelBObjExt> xCustomerRelationshipMap = new HashMap<String, XContactRelBObjExt>();
			HashMap<String, XContactRelBObjExt> xCustomerRelationshipMapTo = new HashMap<String, XContactRelBObjExt>();
			String collapsedPartyId = collapsedPartyBObj.getPartyId();

			for (TCRMPartyBObj partyBObj : vecParties) 
			{

				partytId = partyBObj.getPartyId();


				if(partytId!=null )
				{

					vecPartyRelationshipResponse = partyComponent.getAllPartyRelationships(partytId, "ALL",control);

					if (vecPartyRelationshipResponse != null && !vecPartyRelationshipResponse.isEmpty() && vecPartyRelationshipResponse.size() > 0) 
					{


						for(XContactRelBObjExt partyRelationshipResponse:vecPartyRelationshipResponse)
						{
							if(null != partyRelationshipResponse.getRelationshipFromPartyId() && partyRelationshipResponse.getRelationshipFromPartyId().equals(partytId))
							{
								vecPartyRelationshipResponseFrom.add(partyRelationshipResponse);

							}

							else if (null != partyRelationshipResponse.getRelationshipToPartyId()&& partyRelationshipResponse.getRelationshipToPartyId().equals(partytId))
							{
								vecPartyRelationshipResponseTo.add(partyRelationshipResponse);
							}

						}

						if( null!= vecPartyRelationshipResponseFrom && !vecPartyRelationshipResponseFrom.isEmpty()&& vecPartyRelationshipResponseFrom.size() > 0)
						{

							for (int j = 0; j < vecPartyRelationshipResponseFrom.size(); j++) 
							{
								XContactRelBObjExt xContactRelBObjExt = (XContactRelBObjExt) vecPartyRelationshipResponseFrom.get(j);							

								String relationshipType = xContactRelBObjExt.getRelationshipDescription();							
								String retilerCode = xContactRelBObjExt.getXRetailerCode();
								String relationshipToPartyId = xContactRelBObjExt.getRelationshipToPartyId();

								String mapKey = relationshipType+retilerCode+relationshipToPartyId;

								if(null == retilerCode)
								{
									if (!xCustomerRelationshipMap.containsKey(mapKey)) 
									{	
										xCustomerRelationshipMap.put(mapKey,xContactRelBObjExt);

								} else 
								{
									XContactRelBObjExt xContactRelBObjInMap = xCustomerRelationshipMap.get(mapKey);

										String requestRelationshipType = xContactRelBObjInMap.getRelationshipDescription();
										String existingRelationshipType = xContactRelBObjExt.getRelationshipDescription();									

										//Same Relationship type
										if(requestRelationshipType != null && existingRelationshipType != null && (requestRelationshipType).equalsIgnoreCase(existingRelationshipType))
										{
											Timestamp requestPersonLastModifiedDt = DateFormatter.getTimestamp(xContactRelBObjInMap.getXLastModifiedSystemDate());										
											Timestamp existingPersonLastModifiedDt = DateFormatter.getTimestamp(xContactRelBObjExt.getXLastModifiedSystemDate());

											//Incoming C2C latest
											if (requestPersonLastModifiedDt.after(existingPersonLastModifiedDt))
											{				
												xCustomerRelationshipMap.put(mapKey,xContactRelBObjInMap);
											}
											//Existing C2C latest
											else 
											{										
												xCustomerRelationshipMap.put(mapKey,xContactRelBObjExt);										
											}
										}
									}
								}
							}
						}									


						if( null!= vecPartyRelationshipResponseTo && !vecPartyRelationshipResponseTo.isEmpty()&& vecPartyRelationshipResponseTo.size() > 0)
						{
							for (int j = 0; j < vecPartyRelationshipResponseTo.size(); j++) 
							{
								XContactRelBObjExt xContactRelBObjExt = (XContactRelBObjExt) vecPartyRelationshipResponseTo.get(j);							

								String relationshipType = xContactRelBObjExt.getRelationshipDescription();						
								String retilerCode = xContactRelBObjExt.getXRetailerCode();
								String relationshipFromPartyId = xContactRelBObjExt.getRelationshipFromPartyId();

								String mapKey = relationshipType+retilerCode+relationshipFromPartyId;

								if(null == retilerCode)
								{
									if (!xCustomerRelationshipMapTo.containsKey(mapKey)) 
									{	
										xCustomerRelationshipMapTo.put(mapKey,xContactRelBObjExt);

									} else 
									{
										XContactRelBObjExt xContactRelBObjInMap = xCustomerRelationshipMapTo.get(mapKey);

										String requestRelationshipType = xContactRelBObjInMap.getRelationshipDescription();
										String existingRelationshipType = xContactRelBObjExt.getRelationshipDescription();


										//Same Relationship type
										if(requestRelationshipType != null && existingRelationshipType != null && (requestRelationshipType).equalsIgnoreCase(existingRelationshipType))
										{
											Timestamp requestPersonLastModifiedDt = DateFormatter.getTimestamp(xContactRelBObjInMap.getXLastModifiedSystemDate());										
											Timestamp existingPersonLastModifiedDt = DateFormatter.getTimestamp(xContactRelBObjExt.getXLastModifiedSystemDate());

											//Incoming C2C latest
											if (requestPersonLastModifiedDt.after(existingPersonLastModifiedDt))
											{				
												xCustomerRelationshipMapTo.put(mapKey,xContactRelBObjInMap);
											}
											//Existing C2C latest
											else 
											{										
												xCustomerRelationshipMapTo.put(mapKey,xContactRelBObjExt);										
											}
										}
									}
								}
							}
						}
					}
				}
			}


			Vector<XContactRelBObjExt> survivedXContactRelBobjs = new Vector<XContactRelBObjExt>();

			if(null != xCustomerRelationshipMap && !xCustomerRelationshipMap.isEmpty() && xCustomerRelationshipMap.size()>0)
			{
				for(String key : xCustomerRelationshipMap.keySet())
				{
					survivedXContactRelBobjs.add(xCustomerRelationshipMap.get(key));
				}			

				if(null != survivedXContactRelBobjs && !survivedXContactRelBobjs.isEmpty() && survivedXContactRelBobjs.size()> 0)
				{
					for (  XContactRelBObjExt survivedXContactRelBObjExt: survivedXContactRelBobjs) 
					{			
						XContactRelBObjExt xRelRequestObject = new XContactRelBObjExt();						
						xRelRequestObject.setRelationshipType(survivedXContactRelBObjExt.getRelationshipType());
						xRelRequestObject.setRelationshipValue(survivedXContactRelBObjExt.getRelationshipValue());
						xRelRequestObject.setRelationshipDescription(survivedXContactRelBObjExt.getRelationshipDescription());
						xRelRequestObject.setRelationshipAssignmentType(survivedXContactRelBObjExt.getRelationshipAssignmentType());
						xRelRequestObject.setRelationshipAssignmentValue(survivedXContactRelBObjExt.getRelationshipAssignmentValue());
						xRelRequestObject.setXContactRelRetailerFlag(survivedXContactRelBObjExt.getXContactRelRetailerFlag());
						xRelRequestObject.setXRetailerCode(survivedXContactRelBObjExt.getXRetailerCode());
						xRelRequestObject.setXSourceIdentifierType(survivedXContactRelBObjExt.getXSourceIdentifierType());
						xRelRequestObject.setXContactPosition(survivedXContactRelBObjExt.getXContactPosition());		
						xRelRequestObject.setXContactRole(survivedXContactRelBObjExt.getXContactRole());				
						xRelRequestObject.setXLastModifiedSystemDate(survivedXContactRelBObjExt.getXLastModifiedSystemDate());
						xRelRequestObject.setDeleteFlag(survivedXContactRelBObjExt.getDeleteFlag());
						xRelRequestObject.setStartDate(survivedXContactRelBObjExt.getStartDate());
						xRelRequestObject.setEndDate(survivedXContactRelBObjExt.getEndDate());

						xRelRequestObject.setRelationshipFromValue(survivedXContactRelBObjExt.getRelationshipToPartyId());
						xRelRequestObject.setRelationshipToValue(collapsedPartyId);
						xRelRequestObject.setRelationshipFromPartyId(collapsedPartyId);
						xRelRequestObject.setRelationshipToPartyId(survivedXContactRelBObjExt.getRelationshipToPartyId());

						xRelRequestObject.setControl(survivedXContactRelBObjExt.getControl());
						
						partyComponent.addPartyRelationship(xRelRequestObject);	

					}
				}
			}

			Vector<XContactRelBObjExt> survivedXContactRelToBobjs = new Vector<XContactRelBObjExt>();

			if(null != xCustomerRelationshipMapTo && !xCustomerRelationshipMapTo.isEmpty() && xCustomerRelationshipMapTo.size()>0)
			{
				for(String key : xCustomerRelationshipMapTo.keySet())
				{
					survivedXContactRelToBobjs.add(xCustomerRelationshipMapTo.get(key));
				}
				if(null != survivedXContactRelToBobjs && !survivedXContactRelToBobjs.isEmpty() && survivedXContactRelToBobjs.size()> 0)
				{
					for (  XContactRelBObjExt survivedXContactRelBObjExt: survivedXContactRelToBobjs) 
					{			

						XContactRelBObjExt xRelRequestObject = new XContactRelBObjExt();
						xRelRequestObject.setRelationshipType(survivedXContactRelBObjExt.getRelationshipType());
						xRelRequestObject.setRelationshipValue(survivedXContactRelBObjExt.getRelationshipValue());
						xRelRequestObject.setRelationshipDescription(survivedXContactRelBObjExt.getRelationshipDescription());
						xRelRequestObject.setRelationshipAssignmentType(survivedXContactRelBObjExt.getRelationshipAssignmentType());
						xRelRequestObject.setRelationshipAssignmentValue(survivedXContactRelBObjExt.getRelationshipAssignmentValue());
						xRelRequestObject.setXContactRelRetailerFlag(survivedXContactRelBObjExt.getXContactRelRetailerFlag());
						xRelRequestObject.setXRetailerCode(survivedXContactRelBObjExt.getXRetailerCode());
						xRelRequestObject.setXSourceIdentifierType(survivedXContactRelBObjExt.getXSourceIdentifierType());
						xRelRequestObject.setXContactPosition(survivedXContactRelBObjExt.getXContactPosition());		
						xRelRequestObject.setXContactRole(survivedXContactRelBObjExt.getXContactRole());				
						xRelRequestObject.setXLastModifiedSystemDate(survivedXContactRelBObjExt.getXLastModifiedSystemDate());
						xRelRequestObject.setDeleteFlag(survivedXContactRelBObjExt.getDeleteFlag());
						xRelRequestObject.setStartDate(survivedXContactRelBObjExt.getStartDate());
						xRelRequestObject.setEndDate(survivedXContactRelBObjExt.getEndDate());
						
						xRelRequestObject.setRelationshipFromValue(collapsedPartyId);
						xRelRequestObject.setRelationshipToValue(survivedXContactRelBObjExt.getRelationshipFromPartyId());
						xRelRequestObject.setRelationshipFromPartyId(survivedXContactRelBObjExt.getRelationshipFromPartyId());
						xRelRequestObject.setRelationshipToPartyId(collapsedPartyId);

						xRelRequestObject.setControl(survivedXContactRelBObjExt.getControl());

						partyComponent.addPartyRelationship(xRelRequestObject);	


					}
				}
			}

		}
		//2019-04-10 AU NZ CCR Logic : End 		
		
		
	// CVR Logic end

	// CCR Logic start
		public void survivedCCRDetails(Vector<TCRMPartyBObj> vecParties,TCRMPartyBObj collapsedPartyBObj, DWLControl control) throws Exception {
			

			HashMap<String, XContactRelBObjExt> xCustomerRelationshipMap = new HashMap<String, XContactRelBObjExt>();
			Vector<TCRMPartyRelationshipBObj> vecPartyRelationshipResponse = new Vector<TCRMPartyRelationshipBObj>();
			String partytId = null;
			String collapsedPartyId = collapsedPartyBObj.getPartyId();
			String partyType = null;
			
			TCRMPartyComponent partyComponent = new TCRMPartyComponent();
			XContactRelBObjExt xRelRequestObject = new XContactRelBObjExt();
			
			String person1RetailerId = null;
			String person2RetailerId = null;
			String org1RetailerId = null;
			String org2RetailerId = null;
			
			String companyId1 = null;
			String companyId2 = null;
			String relationshipType1 = null;
			String relationshipType2 = null;
			String personId1 = null;
			String personId2 = null;
			
			//CCCCC
			
			for (TCRMPartyBObj partyBObj : vecParties) {
				partyType = partyBObj.getPartyType();
				partytId = partyBObj.getPartyId();
				
				if(partyType!=null && partyType.equalsIgnoreCase("P")){
				vecPartyRelationshipResponse = partyComponent
						.getAllPartyRelationships(
								partytId, "ACTIVE",
								control);
				if (vecPartyRelationshipResponse != null
						&& vecPartyRelationshipResponse.size() > 0) {
					for (int j = 0; j < vecPartyRelationshipResponse.size(); j++) {
						XContactRelBObjExt xContactRelBObjExt = (XContactRelBObjExt) vecPartyRelationshipResponse
								.get(j);
						if (!xCustomerRelationshipMap.containsKey(xContactRelBObjExt.getXRetailerCode())) {
							xCustomerRelationshipMap.put((xContactRelBObjExt.getRelationshipDescription()+xContactRelBObjExt.getXRetailerCode()+xContactRelBObjExt.getRelationshipFromPartyId()),
									xContactRelBObjExt);
						} else {
							XContactRelBObjExt xContactRelBObjInMap = xCustomerRelationshipMap
									.get((xContactRelBObjExt.getRelationshipDescription()+xContactRelBObjExt.getXRetailerCode()+xContactRelBObjExt.getRelationshipFromPartyId()));
							
							companyId1 = xContactRelBObjInMap.getRelationshipFromPartyId();
							companyId2 = xContactRelBObjExt.getRelationshipFromPartyId();
							
							person1RetailerId = xContactRelBObjInMap
									.getXRetailerCode();
							person2RetailerId = xContactRelBObjExt
									.getXRetailerCode();
							relationshipType1 = xContactRelBObjInMap.getRelationshipDescription();
							relationshipType2 = xContactRelBObjExt.getRelationshipDescription();
							
							if(relationshipType1 != null
									&& relationshipType2 != null
									&& relationshipType1
											.equalsIgnoreCase(relationshipType2)){

							if (person1RetailerId != null
									&& person2RetailerId != null
									&& person1RetailerId
											.equalsIgnoreCase(person2RetailerId)) {
								
								if (companyId1 != null && companyId2 != null
										&& companyId1
												.equalsIgnoreCase(companyId2)) {
									
									Timestamp person1LastModifiedDt = DateFormatter
											.getTimestamp(xContactRelBObjInMap
													.getXLastModifiedSystemDate());
									Timestamp person2LastModifiedDt = DateFormatter
											.getTimestamp(xContactRelBObjExt
													.getXLastModifiedSystemDate());
									if (person1LastModifiedDt.after(person2LastModifiedDt)) {

										xCustomerRelationshipMap.put((xContactRelBObjInMap.getRelationshipDescription()+xContactRelBObjInMap.getXRetailerCode()+xContactRelBObjInMap.getRelationshipFromPartyId()),
												xContactRelBObjInMap);
									}

									else {

										xCustomerRelationshipMap.put((xContactRelBObjExt.getRelationshipDescription()+xContactRelBObjExt.getXRetailerCode()+xContactRelBObjExt.getRelationshipFromPartyId()),
												xContactRelBObjExt);
									}

								} else {

									xCustomerRelationshipMap.put((xContactRelBObjExt.getRelationshipDescription()+xContactRelBObjExt.getXRetailerCode()+xContactRelBObjExt.getRelationshipFromPartyId()),
											xContactRelBObjExt);
								}
								

							} else {
								
								if (companyId1 != null && companyId2 != null
										&& companyId1
												.equalsIgnoreCase(companyId2)) {
								
								xCustomerRelationshipMap.put((xContactRelBObjExt.getRelationshipDescription()+xContactRelBObjExt.getXRetailerCode()+xContactRelBObjExt.getRelationshipFromPartyId()),
										xContactRelBObjExt);
								}
							}
							
							} else {
								
								xCustomerRelationshipMap.put((xContactRelBObjExt.getRelationshipDescription()+xContactRelBObjExt.getXRetailerCode()+xContactRelBObjExt.getRelationshipFromPartyId()),
										xContactRelBObjExt);
							}

						}

					}
				}
				
				} else {
					
					vecPartyRelationshipResponse = partyComponent
							.getAllPartyRelationships(
									partytId, "ACTIVE",
									control);
					if (vecPartyRelationshipResponse != null
							&& vecPartyRelationshipResponse.size() > 0) {
						for (int j = 0; j < vecPartyRelationshipResponse.size(); j++) {
							XContactRelBObjExt xContactRelBObjExt = (XContactRelBObjExt) vecPartyRelationshipResponse
									.get(j);
							if (!xCustomerRelationshipMap.containsKey(xContactRelBObjExt.getXRetailerCode())) {
								xCustomerRelationshipMap.put((xContactRelBObjExt.getRelationshipDescription()+xContactRelBObjExt.getXRetailerCode()+xContactRelBObjExt.getRelationshipToPartyId()),
										xContactRelBObjExt);
							} else {
								XContactRelBObjExt xContactRelBObjInMap = xCustomerRelationshipMap
										.get((xContactRelBObjExt.getRelationshipDescription()+xContactRelBObjExt.getXRetailerCode()+xContactRelBObjExt.getRelationshipToPartyId()));
								
								personId1 = xContactRelBObjInMap.getRelationshipToPartyId();
								personId2 = xContactRelBObjExt.getRelationshipToPartyId();
								
								org1RetailerId = xContactRelBObjInMap
										.getXRetailerCode();
								org2RetailerId = xContactRelBObjExt
										.getXRetailerCode();
								relationshipType1 = xContactRelBObjInMap.getRelationshipDescription();
								relationshipType2 = xContactRelBObjExt.getRelationshipDescription();
								
								if(relationshipType1 != null
										&& relationshipType2 != null
										&& relationshipType1
												.equalsIgnoreCase(relationshipType2)){

								if (org1RetailerId != null
										&& org2RetailerId != null
										&& org1RetailerId
												.equalsIgnoreCase(org2RetailerId)) {
									
									if (personId1 != null && personId2 != null
											&& personId1
													.equalsIgnoreCase(personId2)) {
										
										Timestamp person1LastModifiedDt = DateFormatter
												.getTimestamp(xContactRelBObjInMap
														.getXLastModifiedSystemDate());
										Timestamp person2LastModifiedDt = DateFormatter
												.getTimestamp(xContactRelBObjExt
														.getXLastModifiedSystemDate());
										if (person1LastModifiedDt.after(person2LastModifiedDt)) {

											xCustomerRelationshipMap.put((xContactRelBObjInMap.getRelationshipDescription()+xContactRelBObjInMap.getXRetailerCode()+xContactRelBObjInMap.getRelationshipToPartyId()),
													xContactRelBObjInMap);
										}

										else {

											xCustomerRelationshipMap.put((xContactRelBObjExt.getRelationshipDescription()+xContactRelBObjExt.getXRetailerCode()+xContactRelBObjExt.getRelationshipToPartyId()),
													xContactRelBObjExt);
										}

									} else {

										xCustomerRelationshipMap.put((xContactRelBObjExt.getRelationshipDescription()+xContactRelBObjExt.getXRetailerCode()+xContactRelBObjExt.getRelationshipToPartyId()),
												xContactRelBObjExt);
									}
									

								} else {
									
									if (personId1 != null && personId2 != null
											&& personId1
													.equalsIgnoreCase(personId2)) {
									
									xCustomerRelationshipMap.put((xContactRelBObjExt.getRelationshipDescription()+xContactRelBObjExt.getXRetailerCode()+xContactRelBObjExt.getRelationshipToPartyId()),
											xContactRelBObjExt);
									}
								}
								
								} else {
									
									xCustomerRelationshipMap.put((xContactRelBObjExt.getRelationshipDescription()+xContactRelBObjExt.getXRetailerCode()+xContactRelBObjExt.getRelationshipToPartyId()),
											xContactRelBObjExt);
								}

							}

						}
					}
				}
			}
			
			
			for (Map.Entry<String, XContactRelBObjExt> entry : xCustomerRelationshipMap
					.entrySet()) {
				XContactRelBObjExt tempXContactRelBObjExt = entry.getValue();
				XContactRelBObjExt survivedXContactRelBObjExt = new XContactRelBObjExt();
				survivedXContactRelBObjExt = tempXContactRelBObjExt;
				
				xRelRequestObject.setRelationshipType(survivedXContactRelBObjExt.getRelationshipType());
				xRelRequestObject.setRelationshipValue(survivedXContactRelBObjExt.getRelationshipValue());
				xRelRequestObject.setRelationshipDescription(survivedXContactRelBObjExt.getRelationshipDescription());
				xRelRequestObject.setXContactRelRetailerFlag(survivedXContactRelBObjExt.getXContactRelRetailerFlag());
				xRelRequestObject.setXRetailerCode(survivedXContactRelBObjExt.getXRetailerCode());
				xRelRequestObject.setXSourceIdentifierType(survivedXContactRelBObjExt.getXSourceIdentifierType());
				xRelRequestObject.setXContactPosition(survivedXContactRelBObjExt.getXContactPosition());		
				xRelRequestObject.setXContactRole(survivedXContactRelBObjExt.getXContactRole());
				xRelRequestObject.setXLastModifiedSystemDate(survivedXContactRelBObjExt.getXLastModifiedSystemDate());
				xRelRequestObject.setControl(survivedXContactRelBObjExt.getControl());
				
				if(partyType!=null && partyType.equalsIgnoreCase("P")){
				xRelRequestObject.setRelationshipFromValue(collapsedPartyId);
				xRelRequestObject.setRelationshipToValue(survivedXContactRelBObjExt.getRelationshipFromPartyId());
				} else {
					xRelRequestObject.setRelationshipFromValue(survivedXContactRelBObjExt.getRelationshipToPartyId());
					xRelRequestObject.setRelationshipToValue(collapsedPartyId);
				}

				partyComponent.addPartyRelationship(xRelRequestObject);				
				
			}
			
			//hhjjjj

		
			
		}
		// CCR Logic end
	// Collapse parties logic end
		
		// Contract FS Logic start
		
		// Contract FS Logic start
		public void survivedContractFSDetails(Vector<TCRMPartyBObj> vecParties,
                TCRMPartyBObj collapsedPartyBObj, DWLControl control)
                throws Exception {
			HashMap<String, Vector<XContractRelBObj>> xContractDetailsMap = new HashMap<String, Vector<XContractRelBObj>>();
		    DSEAAdditionsExtsComponent dseaAdditionsExtsComponent = new DSEAAdditionsExtsComponent();
		    String partytId = null;
		    String collapsedPartyId = collapsedPartyBObj.getPartyId();

		    for (TCRMPartyBObj partyBObj : vecParties) {
		    	partytId = partyBObj.getPartyId();
		    	Vector<XContractRelBObj> vectXcontractRel= getContractRelByPartyId(control,partytId);
		    	//for (int j = 0; j < vectXcontractRel.size(); j++) {
		    	//    XContractRelBObj xContractRelBObj = (XContractRelBObj) vectXcontractRel.get(j);
		    	xContractDetailsMap.put(partytId,vectXcontractRel);
		    	//}
		    }

		    for (Map.Entry<String, Vector<XContractRelBObj>> entry : xContractDetailsMap.entrySet()) {
		    	Vector<XContractRelBObj> vecTempXContractRelBObj = entry.getValue();
		    	XContractRelBObj survivedXContractRelBObj = new XContractRelBObj();
        
		    	for(XContractRelBObj tempXContractRelBObj : vecTempXContractRelBObj){
		    	XContractRelBObj inactivexContractRelBObj = endExistingContractRel(control,tempXContractRelBObj.getContId(),tempXContractRelBObj.getContractId(),dseaAdditionsExtsComponent);
		    	survivedXContractRelBObj = new XContractRelBObj();
		    	survivedXContractRelBObj = tempXContractRelBObj;
		    	survivedXContractRelBObj.setContId(collapsedPartyId);
		    	survivedXContractRelBObj.setControl(control);                     
		    	addNewContractRelforSurvivedParty(control,survivedXContractRelBObj.getContId(),survivedXContractRelBObj.getContractId(),dseaAdditionsExtsComponent,inactivexContractRelBObj);
		    	}                       
		    }
		}
		
		/**
		 * 
		 * @param control
		 * @param contId
		 * @param contractpkId
		 * @param dseaAdditionsExtsComponent
		 * @param inactivexContractRelBObj
		 * @throws Exception
		 */
		private void addNewContractRel(DWLControl control, String contId,
				String contractpkId,
				DSEAAdditionsExtsComponent dseaAdditionsExtsComponent,
				XContractRelBObj inactivexContractRelBObj) throws Exception {
			
			XContractRelBObj newXContractRelBObj = new XContractRelBObj();
			newXContractRelBObj.setContractId(contractpkId);
			newXContractRelBObj.setContId(contId);
			newXContractRelBObj.setMarket(inactivexContractRelBObj.getMarket());
			newXContractRelBObj.setPersonOrgCode(inactivexContractRelBObj.getPersonOrgCode());
			newXContractRelBObj.setContractRole(inactivexContractRelBObj.getContractRole());
			newXContractRelBObj.setStartDate(inactivexContractRelBObj.getStartDate());
			newXContractRelBObj.setX_BPID(inactivexContractRelBObj.getX_BPID());
			newXContractRelBObj.setControl(control);
			DWLResponse response=dseaAdditionsExtsComponent.addXContractRel(newXContractRelBObj);
			
			if (response.getStatus().getStatus() == DWLStatus.FATAL) {
				throw new BusinessProxyException();
			}
			
			
			
		}
		/**
		 * 
		 * @param control
		 * @param contId
		 * @param contractpkId
		 * @param dseaAdditionsExtsComponent
		 * @param inactivexContractRelBObj
		 * @throws Exception
		 */
		private void addNewContractRelforSurvivedParty(DWLControl control, String contId,
				String contractpkId,
				DSEAAdditionsExtsComponent dseaAdditionsExtsComponent,
				XContractRelBObj inactivexContractRelBObj) throws Exception {
			
			XContractRelBObj newXContractRelBObj = new XContractRelBObj();
			newXContractRelBObj.setContractId(contractpkId);
			newXContractRelBObj.setContId(contId);
			newXContractRelBObj.setMarket(inactivexContractRelBObj.getMarket());
			newXContractRelBObj.setPersonOrgCode(inactivexContractRelBObj.getPersonOrgCode());
			newXContractRelBObj.setContractRole(inactivexContractRelBObj.getContractRole());
			newXContractRelBObj.setStartDate(inactivexContractRelBObj.getStartDate());
			String bpid = inactivexContractRelBObj.getX_BPID();
			newXContractRelBObj.setX_BPID(inactivexContractRelBObj.getX_BPID());
			newXContractRelBObj.setControl(control);
			DWLResponse response=dseaAdditionsExtsComponent.addXContractRel(newXContractRelBObj);
			
			if (response.getStatus().getStatus() == DWLStatus.FATAL) {
				throw new BusinessProxyException();
			}
			
			
			
		}
		/**
		 * 
		 * @param control
		 * @param partytId
		 * @param contractpkId
		 * @param dseaAdditionsExtsComponent
		 * @return
		 * @throws Exception
		 */
		private XContractRelBObj endExistingContractRel(DWLControl control, String partytId,
				String contractpkId, DSEAAdditionsExtsComponent dseaAdditionsExtsComponent) throws Exception {
			Vector<XContractRelBObj> vect = getContractRel(control,partytId,contractpkId);
			XContractRelBObj xContractRelBObjInDb = null;
			XContractRelBObj xContractRelBObj=vect.get(0);
			long milliseconds = System.currentTimeMillis();
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SS");
			Date endDate = new Date(milliseconds);
			xContractRelBObj.setEndDate(sdf.format(endDate));
			xContractRelBObj.setControl(control);
			DWLResponse res=dseaAdditionsExtsComponent.updateXContractRel(xContractRelBObj);
			if (res.getStatus().getStatus() == DWLStatus.FATAL) {
				throw new BusinessProxyException();
			}
			if(res!=null){
				xContractRelBObjInDb = (XContractRelBObj)res.getData();
			}
			return xContractRelBObjInDb;
			
		}
		
		/**
		 * 
		 * @param control
		 * @param contId
		 * @param contractpkId
		 * @return
		 * @throws Exception
		 */
		public Vector getContractRel(DWLControl control, String contId, String contractpkId)
				throws Exception {
			SQLQuery sqlQuery = new SQLQuery();
			ResultSet objResultSet = null;
			String getContractIdSql = ExternalRuleConstant.GET_CONTRACT_REL;
			String contequivId = null;
			List<SQLParam> params = new ArrayList<SQLParam>();
			XContEquivBObjExt xContBObjExt = new XContEquivBObjExt();
			XContEquivBObjExt getContequivResponse = null;
			DWLStatus dwlStatus = null;
			String contractRelID = null;
			String lastupdate_dt = null;
			Vector<XContractRelBObj> vect =new Vector<XContractRelBObj>();
			try {
				params = new ArrayList<SQLParam>();
				params.add(0, new SQLParam(contractpkId));
				params.add(1, new SQLParam(contId));			
				
			
				
				objResultSet = sqlQuery.executeQuery(getContractIdSql, params);
				while (objResultSet.next()) {
					XContractRelBObj xContractRelBObj = new XContractRelBObj();
					xContractRelBObj.setXContractRelpkId(objResultSet.getString(ExternalRuleConstant.CONTRACT_REL_ID));
					xContractRelBObj.setContractId(objResultSet.getString("CONTRACT_ID"));
					xContractRelBObj.setContId(objResultSet.getString("CONT_ID"));
					xContractRelBObj.setMarket(objResultSet.getString("MARKET"));
					xContractRelBObj.setPersonOrgCode(objResultSet.getString("PERSON_ORG_CODE"));
					xContractRelBObj.setContractRole(objResultSet.getString("CONTRACT_ROLE"));
					xContractRelBObj.setStartDate(objResultSet.getString("START_DATE"));
					xContractRelBObj.setEndDate(objResultSet.getString("END_DATE"));
					xContractRelBObj.setX_BPID(objResultSet.getString("X_BPID"));
					xContractRelBObj.setXContractRelLastUpdateDate(objResultSet.getString(ExternalRuleConstant.LAST_UPDATE_DT));
					vect.add(xContractRelBObj);
					
					
				}
			} catch (Exception ex) {
				logger.finest(ex);
				throw ex;
				
			}finally{
				if (objResultSet != null && !objResultSet.isClosed()) {
					objResultSet.close();
					objResultSet = null;
				}
				sqlQuery.close();				
				
			}
		
			return vect;
		}
		
		/**
		 * 
		 * @param control
		 * @param contId
		 * @param contractpkId
		 * @return
		 * @throws Exception
		 */
		public Vector getContractRelByPartyId(DWLControl control, String contId)
				throws Exception {
			SQLQuery sqlQuery = new SQLQuery();
			ResultSet objResultSet = null;
			String getContractIdSql = ExternalRuleConstant.GET_CONTRACT_REL_BY_PARTYID;
			String contequivId = null;
			List<SQLParam> params = new ArrayList<SQLParam>();
			XContEquivBObjExt xContBObjExt = new XContEquivBObjExt();
			XContEquivBObjExt getContequivResponse = null;
			DWLStatus dwlStatus = null;
			String contractRelID = null;
			String lastupdate_dt = null;
			Vector<XContractRelBObj> vect =new Vector<XContractRelBObj>();
			try {
				params = new ArrayList<SQLParam>();
				params.add(0, new SQLParam(contId));
				//params.add(1, new SQLParam(contId));			
				
			
				
				objResultSet = sqlQuery.executeQuery(getContractIdSql, params);
				while (objResultSet.next()) {
					XContractRelBObj xContractRelBObj = new XContractRelBObj();
					xContractRelBObj.setXContractRelpkId(objResultSet.getString(ExternalRuleConstant.CONTRACT_REL_ID));
					xContractRelBObj.setContractId(objResultSet.getString("CONTRACT_ID"));
					xContractRelBObj.setContId(objResultSet.getString("CONT_ID"));
					xContractRelBObj.setMarket(objResultSet.getString("MARKET"));
					xContractRelBObj.setPersonOrgCode(objResultSet.getString("PERSON_ORG_CODE"));
					xContractRelBObj.setContractRole(objResultSet.getString("CONTRACT_ROLE"));
					xContractRelBObj.setStartDate(objResultSet.getString("START_DATE"));
					xContractRelBObj.setEndDate(objResultSet.getString("END_DATE"));
					xContractRelBObj.setX_BPID(objResultSet.getString("X_BPID"));
					xContractRelBObj.setXContractRelLastUpdateDate(objResultSet.getString(ExternalRuleConstant.LAST_UPDATE_DT));
					vect.add(xContractRelBObj);
					
					
				}
			} catch (Exception ex) {
				logger.finest(ex);
				throw ex;
				
			}finally{
				if (objResultSet != null && !objResultSet.isClosed()) {
					objResultSet.close();
					objResultSet = null;
				}
				sqlQuery.close();
				
				
			}
		
			return vect;
		}
		
		
		// Contract FS Logic end
		
		//June 2, 2021 : Changed by Shashi for Consent survivorship logic : Start 
		/**
		 * Method to survive consent details for Turkey
		 * @param vecParties
		 * @param collapsedPartyBObj
		 * @param control
		 * @throws Exception
		 */
		public void surviveConsentDetailsForTurkey(Vector<TCRMPartyBObj> vecParties, TCRMPartyBObj collapsedPartyBObj, DWLControl control) throws Exception 
		{

			HashMap<String,XConsentBObj> XConsentDetailsMap = new HashMap<String, XConsentBObj>();
			Vector<XConsentBObj> vecXConsentBObjs = new Vector<XConsentBObj>();
			DWLResponse dwlResponse = new DWLResponse();
			DWLResponse response = null;
			DSEAAdditionsExtsComponent dseaAdditionsExtsComponent = new DSEAAdditionsExtsComponent();
			String partytId = null;
			String mobileparty = null;
			String emailparty = null;
			String addrpartyWS = null;
			String addrpartyRT = null;
			String collapsedPartyId = collapsedPartyBObj.getPartyId();
			String collapsedPersonorgtype = getPartyTypefromContId(collapsedPartyId,control);
			String collapsedMobile = getMobilefromContId(collapsedPartyId,control);
			String collapsedEmail = getEmailfromContId(collapsedPartyId,control);
			String collapsedHomeAddressWS = getHomeAddrfromContIdWS(collapsedPartyId,control);
			String collapsedBusinessAddressWS = getBusinessAddrfromContIdWS(collapsedPartyId,control);
			String collapsedHomeAddressRT = getHomeAddrfromContIdRetail(collapsedPartyId,control);
			String collapsedBusinessAddressRT = getBusinessAddrfromContIdRetail(collapsedPartyId,control);
			Timestamp collapsedMobilexmodifydt  = DateFormatter.getTimestamp(getMobilexmodiydtfromContId(collapsedPartyId,control));
			Timestamp collapsedEmailxmodifydt  = DateFormatter.getTimestamp(getEmailxmodiydtfromContId(collapsedPartyId,control));
			Timestamp collapsedHomeAddrxmodifydtWS  = DateFormatter.getTimestamp(getHomeAddrXmodifyDTfromContIdWS(collapsedPartyId,control));
			Timestamp collapsedBusinessAddrxmodifydtWS  = DateFormatter.getTimestamp(getBusinessAddrXmodifyDtfromContIdWS(collapsedPartyId,control));
			Timestamp collapsedHomeAddrxmodifydtRT  = DateFormatter.getTimestamp(getHomeAddrXmodifyDtfromContIdRetail(collapsedPartyId,control));
			Timestamp collapsedBusinessddAddrxmodifydtRT  = DateFormatter.getTimestamp(getBusinessAddrXmodifyDtfromContIdRetail(collapsedPartyId,control));

			
			if(collapsedMobile!=null && !collapsedMobile.equalsIgnoreCase(VALUE_DELETED) && StringUtils.isNonBlank(collapsedMobile) && collapsedMobilexmodifydt!=null ){
				
				for(TCRMPartyBObj partyBObj : vecParties)
				{
					Vector<XContactMethodGroupBObjExt> PartyContactMethodBObjs = partyBObj.getItemsTCRMPartyContactMethodBObj();
					if(PartyContactMethodBObjs.size() > 0){
						for(XContactMethodGroupBObjExt PContactMethodBObj : PartyContactMethodBObjs){
							if(CONTACT_METHOD_USAGE_TYPE_MOBILE_PHONE.equalsIgnoreCase(PContactMethodBObj.getContactMethodUsageType()) 
									&& collapsedMobile.equalsIgnoreCase(PContactMethodBObj.getTCRMContactMethodBObj().getReferenceNumber())
									&& collapsedMobilexmodifydt.equals(DateFormatter.getTimestamp(PContactMethodBObj.getXLastModifiedSystemDate()))){
								mobileparty = partyBObj.getPartyId();
								break;
							}
								
							
						}
						
						
					}
					
				}
				
			}
			
			
           if(collapsedEmail!=null && !collapsedEmail.equalsIgnoreCase(VALUE_DELETED) &&  StringUtils.isNonBlank(collapsedEmail) && collapsedEmailxmodifydt!=null ){
				
				for(TCRMPartyBObj partyBObj : vecParties)
				{
					Vector<XContactMethodGroupBObjExt> PartyContactMethodBObjs = partyBObj.getItemsTCRMPartyContactMethodBObj();
					if(PartyContactMethodBObjs.size() > 0){
						for(XContactMethodGroupBObjExt PContactMethodBObj : PartyContactMethodBObjs){
							if(CONTACT_METHOD_USAGE_TYPE_EMAIL.equalsIgnoreCase(PContactMethodBObj.getContactMethodUsageType()) 
									&& collapsedEmail.equalsIgnoreCase(PContactMethodBObj.getTCRMContactMethodBObj().getReferenceNumber())
									&& collapsedEmailxmodifydt.equals(DateFormatter.getTimestamp(PContactMethodBObj.getXLastModifiedSystemDate()))){
								 emailparty = partyBObj.getPartyId();
								break;
							}
								
							
						}
						
						
					}
					
				}
				
			}
           
           
           if(collapsedPersonorgtype!=null && StringUtils.isNonBlank(collapsedPersonorgtype)){
        	   if("P".equalsIgnoreCase(collapsedPersonorgtype)){
        		   
        		  if(collapsedHomeAddressWS != null && !collapsedHomeAddressWS.contains(VALUE_DELETED) && StringUtils.isNonBlank(collapsedHomeAddressWS) 
        				  && collapsedHomeAddrxmodifydtWS!=null){
        			  
        			  for(TCRMPartyBObj partyBObj : vecParties)
      				{
        				  Vector<XAddressGroupBObjExt> PartyAddressGroupBObjs = partyBObj.getItemsTCRMPartyAddressBObj();
        				  if(PartyAddressGroupBObjs.size() > 0){
        					  for(XAddressGroupBObjExt PAddrGroupBObj : PartyAddressGroupBObjs){
        						  if("1001".equalsIgnoreCase(PAddrGroupBObj.getAddressUsageType()) 
        								  && "N".equalsIgnoreCase(PAddrGroupBObj.getXAddressRetailerFlag())){
        							 String fullhomeaddr = PAddrGroupBObj.getTCRMAddressBObj().getAddressLineOne();
        							 
        							 if(PAddrGroupBObj.getTCRMAddressBObj().getAddressLineTwo() != null){
        								 fullhomeaddr = fullhomeaddr.concat(PAddrGroupBObj.getTCRMAddressBObj().getAddressLineTwo());
        							 }
        							 if(PAddrGroupBObj.getTCRMAddressBObj().getAddressLineThree() != null){
        								 fullhomeaddr = fullhomeaddr.concat(PAddrGroupBObj.getTCRMAddressBObj().getAddressLineThree());
        							 }
        							 if(PAddrGroupBObj.getTCRMAddressBObj().getCity() !=  null){ 
        							 
        							 fullhomeaddr = fullhomeaddr.concat(PAddrGroupBObj.getTCRMAddressBObj().getCity());
        							 }
        							 if(PAddrGroupBObj.getTCRMAddressBObj().getZipPostalCode() != null){
        								 fullhomeaddr = fullhomeaddr.concat(PAddrGroupBObj.getTCRMAddressBObj().getZipPostalCode());
        							 }
        									 
        						
        							 fullhomeaddr = fullhomeaddr.replaceAll("\\s", "");
        							 
        							 if(collapsedHomeAddressWS.equalsIgnoreCase(fullhomeaddr) && 
        								 collapsedHomeAddrxmodifydtWS.equals(DateFormatter.getTimestamp(PAddrGroupBObj.getXLastModifiedSystemDate())))
        								 {
        								 addrpartyWS = partyBObj.getPartyId();
        								 break;
        								 }
        							 
        						  }
        						  
        					  }
        					  
        				  }
        				  
      				}
        			  
        		  }
        		  
        		  
        		  
        		  if(collapsedHomeAddressRT != null && !collapsedHomeAddressRT.contains(VALUE_DELETED) && StringUtils.isNonBlank(collapsedHomeAddressRT) 
        				  && collapsedHomeAddrxmodifydtRT!=null){
        			  
        			  for(TCRMPartyBObj partyBObj : vecParties)
      				{
        				  Vector<XAddressGroupBObjExt> PartyAddressGroupBObjs = partyBObj.getItemsTCRMPartyAddressBObj();
        				  if(PartyAddressGroupBObjs.size() > 0){
        					  for(XAddressGroupBObjExt PAddrGroupBObj : PartyAddressGroupBObjs){
        						  if("1001".equalsIgnoreCase(PAddrGroupBObj.getAddressUsageType()) 
        								  && "Y".equalsIgnoreCase(PAddrGroupBObj.getXAddressRetailerFlag())){
        							  String fullhomeaddr = PAddrGroupBObj.getTCRMAddressBObj().getAddressLineOne();
         							 
         							 if(PAddrGroupBObj.getTCRMAddressBObj().getAddressLineTwo() != null){
         								 fullhomeaddr = fullhomeaddr.concat(PAddrGroupBObj.getTCRMAddressBObj().getAddressLineTwo());
         							 }
         							 if(PAddrGroupBObj.getTCRMAddressBObj().getAddressLineThree() != null){
         								 fullhomeaddr = fullhomeaddr.concat(PAddrGroupBObj.getTCRMAddressBObj().getAddressLineThree());
         							 }
         							 if(PAddrGroupBObj.getTCRMAddressBObj().getCity() !=  null){ 
         							 
         							 fullhomeaddr = fullhomeaddr.concat(PAddrGroupBObj.getTCRMAddressBObj().getCity());
         							 }
         							 if(PAddrGroupBObj.getTCRMAddressBObj().getZipPostalCode() != null){
         								 fullhomeaddr = fullhomeaddr.concat(PAddrGroupBObj.getTCRMAddressBObj().getZipPostalCode());
         							 }
        							 fullhomeaddr = fullhomeaddr.replaceAll("\\s", "");
        							 
        							 if(collapsedHomeAddressRT.equalsIgnoreCase(fullhomeaddr) && 
        									 collapsedHomeAddrxmodifydtRT.equals(DateFormatter.getTimestamp(PAddrGroupBObj.getXLastModifiedSystemDate())))
        								 {
        								 addrpartyRT = partyBObj.getPartyId();
        								 break;
        								 }
        							 
        						  }
        						  
        					  }
        					  
        				  }
        				  
      				}
        			  
        		  }
        		   
        		   
        	   }
        	   else if("O".equalsIgnoreCase(collapsedPersonorgtype)){
        		   
        		   
        		   if(collapsedBusinessAddressWS != null && !collapsedBusinessAddressWS.contains(VALUE_DELETED) && StringUtils.isNonBlank(collapsedBusinessAddressWS) 
         				  && collapsedBusinessAddrxmodifydtWS!=null){
         			  
         			  for(TCRMPartyBObj partyBObj : vecParties)
       				{
         				  Vector<XAddressGroupBObjExt> PartyAddressGroupBObjs = partyBObj.getItemsTCRMPartyAddressBObj();
         				  if(PartyAddressGroupBObjs.size() > 0){
         					  for(XAddressGroupBObjExt PAddrGroupBObj : PartyAddressGroupBObjs){
         						  if("3".equalsIgnoreCase(PAddrGroupBObj.getAddressUsageType()) 
         								  && "N".equalsIgnoreCase(PAddrGroupBObj.getXAddressRetailerFlag())){
         							 
                                     String fulladdr = PAddrGroupBObj.getTCRMAddressBObj().getAddressLineOne();
         							 
         							 if(PAddrGroupBObj.getTCRMAddressBObj().getAddressLineTwo() != null){
         								fulladdr = fulladdr.concat(PAddrGroupBObj.getTCRMAddressBObj().getAddressLineTwo());
         							 }
         							 if(PAddrGroupBObj.getTCRMAddressBObj().getAddressLineThree() != null){
         								fulladdr = fulladdr.concat(PAddrGroupBObj.getTCRMAddressBObj().getAddressLineThree());
         							 }
         							 if(PAddrGroupBObj.getTCRMAddressBObj().getCity() !=  null){ 
         							 
         								fulladdr = fulladdr.concat(PAddrGroupBObj.getTCRMAddressBObj().getCity());
         							 }
         							 if(PAddrGroupBObj.getTCRMAddressBObj().getZipPostalCode() != null){
         								fulladdr = fulladdr.concat(PAddrGroupBObj.getTCRMAddressBObj().getZipPostalCode());
         							 }
         							 
         							 fulladdr = fulladdr.replaceAll("\\s", "");
         							 
         							 if(collapsedBusinessAddressWS.equalsIgnoreCase(fulladdr) && 
         									collapsedBusinessAddrxmodifydtWS.equals(DateFormatter.getTimestamp(PAddrGroupBObj.getXLastModifiedSystemDate())))
         								 {
         								 addrpartyWS = partyBObj.getPartyId();
         								 break;
         								 }
         							 
         						  }
         						  
         					  }
         					  
         				  }
         				  
       				}
         			  
         		  }
         		  
         		  
         		  
         		  if(collapsedBusinessAddressRT != null && !collapsedBusinessAddressRT.contains(VALUE_DELETED) && StringUtils.isNonBlank(collapsedBusinessAddressRT) 
         				  && collapsedBusinessddAddrxmodifydtRT!=null){
         			  
         			  for(TCRMPartyBObj partyBObj : vecParties)
       				{
         				  Vector<XAddressGroupBObjExt> PartyAddressGroupBObjs = partyBObj.getItemsTCRMPartyAddressBObj();
         				  if(PartyAddressGroupBObjs.size() > 0){
         					  for(XAddressGroupBObjExt PAddrGroupBObj : PartyAddressGroupBObjs){
         						  if("3".equalsIgnoreCase(PAddrGroupBObj.getAddressUsageType()) 
         								  && "Y".equalsIgnoreCase(PAddrGroupBObj.getXAddressRetailerFlag())){
                                     String fulladdr = PAddrGroupBObj.getTCRMAddressBObj().getAddressLineOne();
         							 
         							 if(PAddrGroupBObj.getTCRMAddressBObj().getAddressLineTwo() != null){
         								fulladdr = fulladdr.concat(PAddrGroupBObj.getTCRMAddressBObj().getAddressLineTwo());
         							 }
         							 if(PAddrGroupBObj.getTCRMAddressBObj().getAddressLineThree() != null){
         								fulladdr = fulladdr.concat(PAddrGroupBObj.getTCRMAddressBObj().getAddressLineThree());
         							 }
         							 if(PAddrGroupBObj.getTCRMAddressBObj().getCity() !=  null){ 
         							 
         								fulladdr = fulladdr.concat(PAddrGroupBObj.getTCRMAddressBObj().getCity());
         							 }
         							 if(PAddrGroupBObj.getTCRMAddressBObj().getZipPostalCode() != null){
         								fulladdr = fulladdr.concat(PAddrGroupBObj.getTCRMAddressBObj().getZipPostalCode());
         							 }

         							 
         							fulladdr = fulladdr.replaceAll("\\s", "");
         							 
         							 if(collapsedBusinessAddressRT.equalsIgnoreCase(fulladdr) && 
         									collapsedBusinessddAddrxmodifydtRT.equals(DateFormatter.getTimestamp(PAddrGroupBObj.getXLastModifiedSystemDate())))
         								 {
         								 addrpartyRT = partyBObj.getPartyId();
         								 break;
         								 }
         							 
         						  }
         						  
         					  }
         					  
         				  }
         				  
       				}
         			  
         		  }
         		   
        		   
        	   }
           }
           
			
           if(mobileparty!=null && StringUtils.isNonBlank(mobileparty)){
           dwlResponse = dseaAdditionsExtsComponent.getXConsentByContId(mobileparty, control);
           Vector<XConsentBObj> vecXConsent = (Vector<XConsentBObj>) dwlResponse.getData();
           
           if(null!= vecXConsent && vecXConsent.size()>0)
			{
				for(XConsentBObj consentBObj : vecXConsent)
				{
					String retailerFlag = consentBObj.getRetailerFlag();
					String retailerId = consentBObj.getRetailerId();
					String communicationChannel = consentBObj.getCommunicationChannel();
					
					if(ExternalRuleConstant.CONSENT_RETAILER_FLAG_N.equalsIgnoreCase(retailerFlag))
					{
						if(communicationChannel.equalsIgnoreCase("PHONE") 
								||communicationChannel.equalsIgnoreCase("SMS") ){
						String mapKey = communicationChannel;
						
						if(!XConsentDetailsMap.containsKey(mapKey))
						{
							XConsentDetailsMap.put(mapKey, consentBObj);
						}
						
						}
						
					}
					
					else if(ExternalRuleConstant.CONSENT_RETAILER_FLAG_Y.equalsIgnoreCase(retailerFlag))
					{
						if(communicationChannel.equalsIgnoreCase("PHONE") 
								||communicationChannel.equalsIgnoreCase("SMS") ){
						String mapKey = communicationChannel + retailerId;
						if(!XConsentDetailsMap.containsKey(mapKey))
						{
							XConsentDetailsMap.put(mapKey, consentBObj);
						}
						
						}
					}
				}
				
			}
           
           
           
           }
           
           if(emailparty!=null && StringUtils.isNonBlank(emailparty)){
               dwlResponse = dseaAdditionsExtsComponent.getXConsentByContId(emailparty, control);
               Vector<XConsentBObj> vecXConsent = (Vector<XConsentBObj>) dwlResponse.getData();
               
               if(null!= vecXConsent && vecXConsent.size()>0)
    			{
    				for(XConsentBObj consentBObj : vecXConsent)
    				{
    					String retailerFlag = consentBObj.getRetailerFlag();
    					String retailerId = consentBObj.getRetailerId();
    					String communicationChannel = consentBObj.getCommunicationChannel();
    					
    					if(ExternalRuleConstant.CONSENT_RETAILER_FLAG_N.equalsIgnoreCase(retailerFlag))
    					{
    						if(communicationChannel.equalsIgnoreCase("EMAIL")){
    						String mapKey = communicationChannel;
    						
    						if(!XConsentDetailsMap.containsKey(mapKey))
    						{
    							XConsentDetailsMap.put(mapKey, consentBObj);
    						}
    						
    						}
    						
    					}
    					
    					else if(ExternalRuleConstant.CONSENT_RETAILER_FLAG_Y.equalsIgnoreCase(retailerFlag))
    					{
    						if(communicationChannel.equalsIgnoreCase("EMAIL")){
    						String mapKey = communicationChannel + retailerId;
    						if(!XConsentDetailsMap.containsKey(mapKey))
    						{
    							XConsentDetailsMap.put(mapKey, consentBObj);
    						}
    						
    						}
    					}
    				}
    				
    			}
               
               
               
               }
           
           
           if(addrpartyWS!=null && StringUtils.isNonBlank(addrpartyWS)){
               dwlResponse = dseaAdditionsExtsComponent.getXConsentByContId(addrpartyWS, control);
               Vector<XConsentBObj> vecXConsent = (Vector<XConsentBObj>) dwlResponse.getData();
               
               if(null!= vecXConsent && vecXConsent.size()>0)
    			{
    				for(XConsentBObj consentBObj : vecXConsent)
    				{
    					String retailerFlag = consentBObj.getRetailerFlag();
    					String retailerId = consentBObj.getRetailerId();
    					String communicationChannel = consentBObj.getCommunicationChannel();
    					
    					if(ExternalRuleConstant.CONSENT_RETAILER_FLAG_N.equalsIgnoreCase(retailerFlag))
    					{
    						if(communicationChannel.equalsIgnoreCase("POSTAL")){
    						String mapKey = communicationChannel;
    						
    						if(!XConsentDetailsMap.containsKey(mapKey))
    						{
    							XConsentDetailsMap.put(mapKey, consentBObj);
    						}
    						
    						}
    						
    					}
    					
    					
    				}
    				
    			}
               
               
               
               }
           
           
           if(addrpartyRT!=null && StringUtils.isNonBlank(addrpartyRT)){
               dwlResponse = dseaAdditionsExtsComponent.getXConsentByContId(addrpartyRT, control);
               Vector<XConsentBObj> vecXConsent = (Vector<XConsentBObj>) dwlResponse.getData();
               
               if(null!= vecXConsent && vecXConsent.size()>0)
    			{
    				for(XConsentBObj consentBObj : vecXConsent)
    				{
    					String retailerFlag = consentBObj.getRetailerFlag();
    					String retailerId = consentBObj.getRetailerId();
    					String communicationChannel = consentBObj.getCommunicationChannel();
    					
    					if(ExternalRuleConstant.CONSENT_RETAILER_FLAG_Y.equalsIgnoreCase(retailerFlag))
    					{
    						if(communicationChannel.equalsIgnoreCase("POSTAL")){
    						String mapKey = communicationChannel + retailerId;
    						if(!XConsentDetailsMap.containsKey(mapKey))
    						{
    							XConsentDetailsMap.put(mapKey, consentBObj);
    						}
    						
    						}
    					}
    					
    					
    				}
    				
    			}
               
               
               
               }
           
		/*	for(TCRMPartyBObj partyBObj : vecParties)
			{
				partytId = partyBObj.getPartyId();
				dwlResponse = dseaAdditionsExtsComponent.getXConsentByContId(partytId, control);
				Vector<XConsentBObj> vecXConsent = (Vector<XConsentBObj>) dwlResponse.getData();
				
				if(null!= vecXConsent && vecXConsent.size()>0)
				{
					for(XConsentBObj consentBObj : vecXConsent)
					{
						String reatilerFlag = consentBObj.getRetailerFlag();
						String retailerId = consentBObj.getRetailerId();
						String communicationChannel = consentBObj.getCommunicationChannel();
						String requestSourceType = consentBObj.getSourceIdentifierType();
						if(ExternalRuleConstant.CONSENT_RETAILER_FLAG_N.equalsIgnoreCase(reatilerFlag))
						{
							String mapKey = communicationChannel;
							if(!XConsentDetailsMap.containsKey(mapKey))
							{
								XConsentDetailsMap.put(mapKey, consentBObj);
							}
							else
							{
								XConsentBObj XConsentDetailsinMap = XConsentDetailsMap.get(mapKey);
								String existingSourceType = XConsentDetailsinMap.getSourceIdentifierType();
								String requestSourcePriority = getSOurcePriorityForConsent(requestSourceType);
								String existingSourcePriority = getSOurcePriorityForConsent(existingSourceType);
								
								Timestamp requestConsentLastModifiedDt = DateFormatter
										.getTimestamp(consentBObj.getLastModifiedSystemDate());
								
								Timestamp existingConsentLastModifiedDt = DateFormatter
										.getTimestamp(XConsentDetailsinMap.getLastModifiedSystemDate());
								if(requestSourceType.equalsIgnoreCase(existingSourceType))
								{
									
									if (requestConsentLastModifiedDt.after(existingConsentLastModifiedDt))
									{
										XConsentDetailsMap.put(mapKey, consentBObj);
									}
									else
										XConsentDetailsMap.put(mapKey, XConsentDetailsinMap);
								}
								else
								{
									if(requestSourcePriority.equalsIgnoreCase(existingSourcePriority))
									{
										if (requestConsentLastModifiedDt.after(existingConsentLastModifiedDt))
										{
											XConsentDetailsMap.put(mapKey, consentBObj);
										}
										else
											XConsentDetailsMap.put(mapKey, XConsentDetailsinMap);
									}
									else
									{
										if(Integer.parseInt(requestSourcePriority) > Integer.parseInt(existingSourcePriority))
										{
											XConsentDetailsMap.put(mapKey, consentBObj);
										}
										else
											XConsentDetailsMap.put(mapKey, XConsentDetailsinMap);
									}
								}
							}
						}
						else if(ExternalRuleConstant.CONSENT_RETAILER_FLAG_Y.equalsIgnoreCase(reatilerFlag))
						{
							String mapKey = communicationChannel + retailerId;
							if(!XConsentDetailsMap.containsKey(mapKey))
							{
								XConsentDetailsMap.put(mapKey, consentBObj);
							}
							else
							{
								XConsentBObj XConsentDetailsinMap = XConsentDetailsMap.get(mapKey);
								String existingSourceType = XConsentDetailsinMap.getSourceIdentifierType();
								String requestSourcePriority = getSOurcePriorityForConsent(requestSourceType);
								String existingSourcePriority = getSOurcePriorityForConsent(existingSourceType);
								
								Timestamp requestConsentLastModifiedDt = DateFormatter
										.getTimestamp(consentBObj.getLastModifiedSystemDate());
								
								Timestamp existingConsentLastModifiedDt = DateFormatter
										.getTimestamp(XConsentDetailsinMap.getLastModifiedSystemDate());
								if(requestSourceType.equalsIgnoreCase(existingSourceType))
								{
									if (requestConsentLastModifiedDt.after(existingConsentLastModifiedDt))
									{
										XConsentDetailsMap.put(mapKey, consentBObj);
									}
									else
										XConsentDetailsMap.put(mapKey, XConsentDetailsinMap);
								}
								else
								{
									if(requestSourcePriority.equalsIgnoreCase(existingSourcePriority))
									{
										if (requestConsentLastModifiedDt.after(existingConsentLastModifiedDt))
										{
											XConsentDetailsMap.put(mapKey, consentBObj);
										}
										else
											XConsentDetailsMap.put(mapKey, XConsentDetailsinMap);
									}
									else
									{
										if(Integer.parseInt(requestSourcePriority) > Integer.parseInt(existingSourcePriority))
										{
											XConsentDetailsMap.put(mapKey, consentBObj);
										}
										else
											XConsentDetailsMap.put(mapKey, XConsentDetailsinMap);
									}
								}
							}
						}
						
					}
				}
				
			}*/
			for(Map.Entry<String, XConsentBObj> entry : XConsentDetailsMap.entrySet())
			{
				XConsentBObj tempXConsentBObj = entry.getValue();
				XConsentBObj survivedXConsentBObj = new XConsentBObj();
				//XConsentBObj inactivexConsentBObj = endExistingConsent(control,tempXConsentBObj.getContId(),tempXConsentBObj.getXConsentpkId(),dseaAdditionsExtsComponent);
				/*survivedXConsentBObj = tempXConsentBObj;
				survivedXConsentBObj.setContId(collapsedPartyId);
				survivedXConsentBObj.setControl(control);*/				
				addNewConsentforSurvivedParty(control,collapsedPartyId,tempXConsentBObj,dseaAdditionsExtsComponent);
				
			}
		
			
			
			
		}
		
		// Start
		
		public String getPartyTypefromContId(String contid,DWLControl dwlControl) throws SQLException
		{

			// TODO Auto-generated method stub
			SQLQuery sqlQuery = new SQLQuery();
			ResultSet objResultSet = null;
			String getPartyIdSql = ExternalRuleConstant.SEARCH_PARTYTYPE_BY_CONT;
			String partytype = null;
			List<SQLParam> params = new ArrayList<SQLParam>();

			try {
				params = new ArrayList<SQLParam>();
				params.add(0, new SQLParam(contid));

				objResultSet = sqlQuery.executeQuery(getPartyIdSql, params);
				while (objResultSet.next()) {
					partytype = objResultSet
							.getString(ExternalRuleConstant.PARTY_TYPE);
				}

				//objResultSet.close();
			} catch (Exception ex) {
				ex.printStackTrace();
			}finally{
				

				if(null!= objResultSet && !objResultSet.isClosed())
				{
					objResultSet.close();
				}
				if(sqlQuery != null )
				{
					sqlQuery.close();
				}
				
			}

			return partytype;

		}
		
		
		public String getMobilefromContId(String contid,DWLControl dwlControl) throws SQLException
		{

			// TODO Auto-generated method stub
			SQLQuery sqlQuery = new SQLQuery();
			ResultSet objResultSet = null;
			String getPartyIdSql = ExternalRuleConstant.SEARCH_MOBILE_BY_CONT;
			String mobile = null;
			List<SQLParam> params = new ArrayList<SQLParam>();

			try {
				params = new ArrayList<SQLParam>();
				params.add(0, new SQLParam(contid));

				objResultSet = sqlQuery.executeQuery(getPartyIdSql, params);
				while (objResultSet.next()) {
					mobile = objResultSet
							.getString(ExternalRuleConstant.REF_NUM);
				}

				//objResultSet.close();
			} catch (Exception ex) {
				ex.printStackTrace();
			}finally{
				

				if(null!= objResultSet && !objResultSet.isClosed())
				{
					objResultSet.close();
				}
				if(sqlQuery != null )
				{
					sqlQuery.close();
				}
				
			}

			return mobile;

		}
		
		public String getMobilexmodiydtfromContId(String contid,DWLControl dwlControl) throws SQLException
		{

			// TODO Auto-generated method stub
			SQLQuery sqlQuery = new SQLQuery();
			ResultSet objResultSet = null;
			String getPartyIdSql = ExternalRuleConstant.SEARCH_MOBILE_XMODIFY_DT_BY_CONT;
			String mobilemodifydt = null;
			List<SQLParam> params = new ArrayList<SQLParam>();

			try {
				params = new ArrayList<SQLParam>();
				params.add(0, new SQLParam(contid));

				objResultSet = sqlQuery.executeQuery(getPartyIdSql, params);
				while (objResultSet.next()) {
					mobilemodifydt = objResultSet
							.getString(ExternalRuleConstant.XMODIFY_SYS_DT);
				}

				//objResultSet.close();
			} catch (Exception ex) {
				ex.printStackTrace();
			}finally{
				

				if(null!= objResultSet && !objResultSet.isClosed())
				{
					objResultSet.close();
				}
				if(sqlQuery != null )
				{
					sqlQuery.close();
				}
				
			}

			return mobilemodifydt;

		}
		
		public String getEmailfromContId(String contid,DWLControl dwlControl) throws SQLException
		{

			// TODO Auto-generated method stub
			SQLQuery sqlQuery = new SQLQuery();
			ResultSet objResultSet = null;
			String getPartyIdSql = ExternalRuleConstant.SEARCH_EMAIL_BY_CONT;
			String mobile = null;
			List<SQLParam> params = new ArrayList<SQLParam>();

			try {
				params = new ArrayList<SQLParam>();
				params.add(0, new SQLParam(contid));

				objResultSet = sqlQuery.executeQuery(getPartyIdSql, params);
				while (objResultSet.next()) {
					mobile = objResultSet
							.getString(ExternalRuleConstant.REF_NUM);
				}

				//objResultSet.close();
			} catch (Exception ex) {
				ex.printStackTrace();
			}finally{
				

				if(null!= objResultSet && !objResultSet.isClosed())
				{
					objResultSet.close();
				}
				if(sqlQuery != null )
				{
					sqlQuery.close();
				}
				
			}

			return mobile;

		}
		
		public String getEmailxmodiydtfromContId(String contid,DWLControl dwlControl) throws SQLException
		{

			// TODO Auto-generated method stub
			SQLQuery sqlQuery = new SQLQuery();
			ResultSet objResultSet = null;
			String getPartyIdSql = ExternalRuleConstant.SEARCH_EMAIL_XMODIFY_DT_BY_CONT;
			String Emailmodifydt = null;
			List<SQLParam> params = new ArrayList<SQLParam>();

			try {
				params = new ArrayList<SQLParam>();
				params.add(0, new SQLParam(contid));

				objResultSet = sqlQuery.executeQuery(getPartyIdSql, params);
				while (objResultSet.next()) {
					Emailmodifydt = objResultSet
							.getString(ExternalRuleConstant.XMODIFY_SYS_DT);
				}

				//objResultSet.close();
			} catch (Exception ex) {
				ex.printStackTrace();
			}finally{
				

				if(null!= objResultSet && !objResultSet.isClosed())
				{
					objResultSet.close();
				}
				if(sqlQuery != null )
				{
					sqlQuery.close();
				}
				
			}

			return Emailmodifydt;

		}
		
		
		public String getHomeAddrfromContIdWS(String contid,DWLControl dwlControl) throws SQLException
		{

			// TODO Auto-generated method stub
			SQLQuery sqlQuery = new SQLQuery();
			ResultSet objResultSet = null;
			String getPartyIdSql = ExternalRuleConstant.SEARCH_HOMEADDR_BY_CONT_WS;
			String homeaddr = null;
			List<SQLParam> params = new ArrayList<SQLParam>();

			try {
				params = new ArrayList<SQLParam>();
				params.add(0, new SQLParam(contid));

				objResultSet = sqlQuery.executeQuery(getPartyIdSql, params);
				while (objResultSet.next()) {
					homeaddr = objResultSet
							.getString(ExternalRuleConstant.FULL_ADDR);
				}

				//objResultSet.close();
			} catch (Exception ex) {
				ex.printStackTrace();
			}finally{
				

				if(null!= objResultSet && !objResultSet.isClosed())
				{
					objResultSet.close();
				}
				if(sqlQuery != null )
				{
					sqlQuery.close();
				}
				
			}

			return homeaddr;

		}
		
		public String getBusinessAddrfromContIdWS(String contid,DWLControl dwlControl) throws SQLException
		{

			// TODO Auto-generated method stub
			SQLQuery sqlQuery = new SQLQuery();
			ResultSet objResultSet = null;
			String getPartyIdSql = ExternalRuleConstant.SEARCH_BUSINESSADDR_BY_CONT_WS;
			String homeaddr = null;
			List<SQLParam> params = new ArrayList<SQLParam>();

			try {
				params = new ArrayList<SQLParam>();
				params.add(0, new SQLParam(contid));

				objResultSet = sqlQuery.executeQuery(getPartyIdSql, params);
				while (objResultSet.next()) {
					homeaddr = objResultSet
							.getString(ExternalRuleConstant.FULL_ADDR);
				}

				//objResultSet.close();
			} catch (Exception ex) {
				ex.printStackTrace();
			}finally{
				

				if(null!= objResultSet && !objResultSet.isClosed())
				{
					objResultSet.close();
				}
				if(sqlQuery != null )
				{
					sqlQuery.close();
				}
				
			}

			return homeaddr;

		}
		
		
		public String getHomeAddrfromContIdRetail(String contid,DWLControl dwlControl) throws SQLException
		{

			// TODO Auto-generated method stub
			SQLQuery sqlQuery = new SQLQuery();
			ResultSet objResultSet = null;
			String getPartyIdSql = ExternalRuleConstant.SEARCH_HOMEADDR_BY_CONT_RT;
			String homeaddr = null;
			List<SQLParam> params = new ArrayList<SQLParam>();

			try {
				params = new ArrayList<SQLParam>();
				params.add(0, new SQLParam(contid));

				objResultSet = sqlQuery.executeQuery(getPartyIdSql, params);
				while (objResultSet.next()) {
					homeaddr = objResultSet
							.getString(ExternalRuleConstant.FULL_ADDR);
				}

				//objResultSet.close();
			} catch (Exception ex) {
				ex.printStackTrace();
			}finally{
				

				if(null!= objResultSet && !objResultSet.isClosed())
				{
					objResultSet.close();
				}
				if(sqlQuery != null )
				{
					sqlQuery.close();
				}
				
			}

			return homeaddr;

		}
		
		public String getBusinessAddrfromContIdRetail(String contid,DWLControl dwlControl) throws SQLException
		{

			// TODO Auto-generated method stub
			SQLQuery sqlQuery = new SQLQuery();
			ResultSet objResultSet = null;
			String getPartyIdSql = ExternalRuleConstant.SEARCH_BUSINESSADDR_BY_CONT_RT;
			String homeaddr = null;
			List<SQLParam> params = new ArrayList<SQLParam>();

			try {
				params = new ArrayList<SQLParam>();
				params.add(0, new SQLParam(contid));

				objResultSet = sqlQuery.executeQuery(getPartyIdSql, params);
				while (objResultSet.next()) {
					homeaddr = objResultSet
							.getString(ExternalRuleConstant.FULL_ADDR);
				}

				//objResultSet.close();
			} catch (Exception ex) {
				ex.printStackTrace();
			}finally{
				

				if(null!= objResultSet && !objResultSet.isClosed())
				{
					objResultSet.close();
				}
				if(sqlQuery != null )
				{
					sqlQuery.close();
				}
				
			}

			return homeaddr;

		}
		public String getHomeAddrXmodifyDTfromContIdWS(String contid,DWLControl dwlControl) throws SQLException
		{

			// TODO Auto-generated method stub
			SQLQuery sqlQuery = new SQLQuery();
			ResultSet objResultSet = null;
			String getPartyIdSql = ExternalRuleConstant.SEARCH_HOMEADDR_XMODIFYDT_BY_CONT_WS;
			String homeaddrXmodifyDt = null;
			List<SQLParam> params = new ArrayList<SQLParam>();

			try {
				params = new ArrayList<SQLParam>();
				params.add(0, new SQLParam(contid));

				objResultSet = sqlQuery.executeQuery(getPartyIdSql, params);
				while (objResultSet.next()) {
					homeaddrXmodifyDt = objResultSet
							.getString(ExternalRuleConstant.XMODIFY_SYS_DT);
				}

				//objResultSet.close();
			} catch (Exception ex) {
				ex.printStackTrace();
			}finally{
				

				if(null!= objResultSet && !objResultSet.isClosed())
				{
					objResultSet.close();
				}
				if(sqlQuery != null )
				{
					sqlQuery.close();
				}
				
			}

			return homeaddrXmodifyDt;

		}
		
		public String getBusinessAddrXmodifyDtfromContIdWS(String contid,DWLControl dwlControl) throws SQLException
		{

			// TODO Auto-generated method stub
			SQLQuery sqlQuery = new SQLQuery();
			ResultSet objResultSet = null;
			String getPartyIdSql = ExternalRuleConstant.SEARCH_BUSINESSADDR_XMODIFYDT_BY_CONT_WS;
			String homeaddr = null;
			List<SQLParam> params = new ArrayList<SQLParam>();

			try {
				params = new ArrayList<SQLParam>();
				params.add(0, new SQLParam(contid));

				objResultSet = sqlQuery.executeQuery(getPartyIdSql, params);
				while (objResultSet.next()) {
					homeaddr = objResultSet
							.getString(ExternalRuleConstant.XMODIFY_SYS_DT);
				}

				//objResultSet.close();
			} catch (Exception ex) {
				ex.printStackTrace();
			}finally{
				
				if(null!= objResultSet && !objResultSet.isClosed())
				{
					objResultSet.close();
				}
				if(sqlQuery != null )
				{
					sqlQuery.close();
				}
				
			}

			return homeaddr;

		}
		public String getHomeAddrXmodifyDtfromContIdRetail(String contid,DWLControl dwlControl) throws SQLException
		{

			// TODO Auto-generated method stub
			SQLQuery sqlQuery = new SQLQuery();
			ResultSet objResultSet = null;
			String getPartyIdSql = ExternalRuleConstant.SEARCH_HOMEADDR_XMODIFYDT_BY_CONT_RT;
			String homeaddr = null;
			List<SQLParam> params = new ArrayList<SQLParam>();

			try {
				params = new ArrayList<SQLParam>();
				params.add(0, new SQLParam(contid));

				objResultSet = sqlQuery.executeQuery(getPartyIdSql, params);
				while (objResultSet.next()) {
					homeaddr = objResultSet
							.getString(ExternalRuleConstant.XMODIFY_SYS_DT);
				}
				//objResultSet.close();
			} catch (Exception ex) {
				ex.printStackTrace();
			}finally{
				

				if(null!= objResultSet && !objResultSet.isClosed())
				{
					objResultSet.close();
				}
				if(sqlQuery != null )
				{
					sqlQuery.close();
				}
				
			}

			return homeaddr;

		}
		
		public String getBusinessAddrXmodifyDtfromContIdRetail(String contid,DWLControl dwlControl) throws SQLException
		{

			// TODO Auto-generated method stub
			SQLQuery sqlQuery = new SQLQuery();
			ResultSet objResultSet = null;
			String getPartyIdSql = ExternalRuleConstant.SEARCH_BUSINESSADDR_XMODIFYDT_BY_CONT_RT;
			String homeaddr = null;
			List<SQLParam> params = new ArrayList<SQLParam>();

			try {
				params = new ArrayList<SQLParam>();
				params.add(0, new SQLParam(contid));

				objResultSet = sqlQuery.executeQuery(getPartyIdSql, params);
				while (objResultSet.next()) {
					homeaddr = objResultSet
							.getString(ExternalRuleConstant.XMODIFY_SYS_DT);
				}

				//objResultSet.close();
			} catch (Exception ex) {
				ex.printStackTrace();
			}finally{
				

				if(null!= objResultSet && !objResultSet.isClosed())
				{
					objResultSet.close();
				}
				if(sqlQuery != null )
				{
					sqlQuery.close();
				}
				
			}

			return homeaddr;

		}
		
		//End of Changes 
		
		public String getSOurcePriorityForConsent (String sourceSystemType) throws Exception {

			String sourcePriority = null;

			if(StringUtils.isNonBlank(sourceSystemType))
			{
				if(ExternalRuleConstant.SOURCE_IDENTIFIER_TYPE_SFDC.equalsIgnoreCase(sourceSystemType) || 
						ExternalRuleConstant.SOURCE_IDENTIFIER_TYPE_CUSTOMER_PORTAL.equalsIgnoreCase(sourceSystemType) || 
						ExternalRuleConstant.SOURCE_IDENTIFIER_TYPE_ONEWEB.equalsIgnoreCase(sourceSystemType) || 
						ExternalRuleConstant.SOURCE_IDENTIFIER_TYPE_COMPASS.equalsIgnoreCase(sourceSystemType) ||
						ExternalRuleConstant.SOURCE_IDENTIFIER_TYPE_TDS.equalsIgnoreCase(sourceSystemType) ||
						ExternalRuleConstant.SOURCE_IDENTIFIER_TYPE_LEADMANAGEMENT_SOCIAL_MEDIA.equalsIgnoreCase(sourceSystemType) ||
						ExternalRuleConstant.SOURCE_IDENTIFIER_TYPE_PCS.equalsIgnoreCase(sourceSystemType))
				{
					sourcePriority = ExternalRuleConstant.SOURCE_PRIORITY_2;
				}
				else if(ExternalRuleConstant.SOURCE_IDENTIFIER_TYPE_LEADMANAGEMENT_INSURANCE.equalsIgnoreCase(sourceSystemType))
				{
					sourcePriority = ExternalRuleConstant.SOURCE_PRIORITY_1;				
				}
				else
				{
					//Hard Coded for the time being, need to be corrected
					sourcePriority = ExternalRuleConstant.SOURCE_PRIORITY_1;
				}
			}
			return sourcePriority;		
		}
		
		private void addNewConsentforSurvivedParty(DWLControl control, String collapsedPartyId,XConsentBObj tempXConsentBObj,
                DSEAAdditionsExtsComponent dseaAdditionsExtsComponent) throws Exception {
          
          XConsentBObj newXConsentBObj = new XConsentBObj();
          newXConsentBObj.setContId(collapsedPartyId);
          newXConsentBObj.setCommunicationChannel(tempXConsentBObj.getCommunicationChannel());
          newXConsentBObj.setConsentActionType(tempXConsentBObj.getConsentActionType());
          newXConsentBObj.setConsentActionValue(tempXConsentBObj.getConsentActionValue());
          newXConsentBObj.setLastModifiedSystemDate(tempXConsentBObj.getLastModifiedSystemDate());
          newXConsentBObj.setRetailerFlag(tempXConsentBObj.getRetailerFlag());
          newXConsentBObj.setRetailerId(tempXConsentBObj.getRetailerId());
          newXConsentBObj.setSourceIdentifierType(tempXConsentBObj.getSourceIdentifierType());
          newXConsentBObj.setSourceIdentifierValue(tempXConsentBObj.getSourceIdentifierValue());
          newXConsentBObj.setControl(control);
          DWLResponse response=dseaAdditionsExtsComponent.addXConsent(newXConsentBObj);
          
          if (response.getStatus().getStatus() == DWLStatus.FATAL) {
                throw new BusinessProxyException();
          }
          
          
          
   }
		
		
		private void addNewConsentforSurvivedPartyAEM(DWLControl control, String collapsedPartyId,XConsentBObj tempXConsentBObj,
                DSEAAdditionsExtsComponent dseaAdditionsExtsComponent) throws Exception {
          
          XConsentBObj newXConsentBObj = new XConsentBObj();
          newXConsentBObj.setContId(collapsedPartyId);
          newXConsentBObj.setCommunicationChannel(tempXConsentBObj.getCommunicationChannel());
          newXConsentBObj.setConsentActionType(tempXConsentBObj.getConsentActionType());
          newXConsentBObj.setConsentActionValue(tempXConsentBObj.getConsentActionValue());
          newXConsentBObj.setLastModifiedSystemDate(tempXConsentBObj.getLastModifiedSystemDate());
          newXConsentBObj.setRetailerFlag(tempXConsentBObj.getRetailerFlag());
          newXConsentBObj.setRetailerId(tempXConsentBObj.getRetailerId());
          newXConsentBObj.setSourceIdentifierType(tempXConsentBObj.getSourceIdentifierType());
          newXConsentBObj.setSourceIdentifierValue(tempXConsentBObj.getSourceIdentifierValue());
          newXConsentBObj.setControl(control);
          DWLResponse response=dseaAdditionsExtsComponent.addXConsent(newXConsentBObj);
          
          if (response.getStatus().getStatus() == DWLStatus.FATAL) {
                throw new BusinessProxyException();
          }
          
          
          
   }

		//June 1, 2018 : Added by Diparnab for Consent survivorship logic : End

		//Japan create suspect changes start

		public void matchRulesAdjustForJapan(TCRMPartyBObj tcrmPartyBObj, DWLControl control) throws Exception {	 
			XPersonBObjExt tcrmPersonBObj = null;
			XOrgBObjExt tcrmOrgBObj = null;
		//			System.out.println("In Match Rule Adjustment++++");
			TCRMPartyComponent partyComponent = new TCRMPartyComponent();
			Vector<TCRMSuspectBObj> vecSuspectObject = new Vector<TCRMSuspectBObj>();
			DSEAAdditionsExtsComponent dseaAdditionsExtsComponent= new DSEAAdditionsExtsComponent();
			Vector<XCustomerVehicleJPNBObj> vecSourceCustomerVehObject = new Vector<XCustomerVehicleJPNBObj>();
			Vector<XAddressGroupBObjExt> vecSourceAddressObject = new Vector<XAddressGroupBObjExt>();
			Vector<XContactMethodGroupBObjExt> vecSourceContactMethodObject = new Vector<XContactMethodGroupBObjExt>();
			Vector<XContEquivBObjExt> vecSourceContequivObject = new Vector<XContEquivBObjExt>();
			Vector<XDataSharingBObj> vecSourceDataSharingObject = new Vector<XDataSharingBObj>();			
			Vector<XPreferenceBObj> vecSourcePreferenceObject = new Vector<XPreferenceBObj>();
			Vector<TCRMPersonNameBObj> vecSourcePersonNameObject = new Vector<TCRMPersonNameBObj>();	
			Vector<TCRMOrganizationNameBObj> vecSourceOrgNameObject = new Vector<TCRMOrganizationNameBObj>();
			String sourcePartyId = null;
			DWLResponse responseSourceCustomerVehicleObj = null;
			DWLResponse responseSuspectCustomerVehicleObj = null;
			DWLResponse responseSourceXDataSharingObj = null;
			DWLResponse responseSuspectXDataSharingObj = null;			
			DWLResponse responseSourcePrefObj = null;
			DWLResponse responseSuspectPrefObj = null;			
			StringBuffer sb = new StringBuffer();
			List<String> sourceGlobalVINList = new ArrayList<String>();
			List<String> sourceAddressTypeList = new ArrayList<String>();
			List<String> sourceContactMethodTypeList = new ArrayList<String>();
			List<String> sourceVehicleAddressList = new ArrayList<String>();
			List<String> sourceMyMIdList = new ArrayList<String>();
			//Added by Sameeha for Multiple MMID merge issue | 12-Feb- 2020: Start
			List<String> suspectMultipleMyMIdList = new ArrayList<String>();
			//Added by Sameeha for Multiple MMID merge issue | 12-Feb- 2020: End
			List<String> sourceDataSharingList = new ArrayList<String>();
			List<String> sourcePrefIndicatorList = new ArrayList<String>();
			HashMap<String, List<String>> xContactMethodSourceMap = new HashMap<String, List<String>>();
			HashMap<String, List<String>> xAddressSourceMap = new HashMap<String, List<String>>();
			boolean isSourceAnonNamePresent = false;

			try {
				if (tcrmPartyBObj instanceof XPersonBObjExt) {

					tcrmPersonBObj = (XPersonBObjExt) tcrmPartyBObj;
					control = tcrmPersonBObj.getControl();								
					vecSuspectObject = tcrmPersonBObj.getItemsTCRMSuspectBObj();
					sourcePartyId = tcrmPersonBObj.getPartyId();

					//Source Vehicle Address changes start
					responseSourceCustomerVehicleObj = dseaAdditionsExtsComponent.getAllXCustomerVehicleJPNByPartyId(sourcePartyId, control);				
					if (responseSourceCustomerVehicleObj != null) {
						vecSourceCustomerVehObject = (Vector<XCustomerVehicleJPNBObj>) responseSourceCustomerVehicleObj
								.getData();
						if(vecSourceCustomerVehObject!=null){
							if (vecSourceCustomerVehObject.get(0).getStatus()
									.getStatus() == DWLStatus.FATAL) {
								throwExceptionifTxnFails(responseSourceCustomerVehicleObj, sb);
							}
						}
					} else {
						throwExceptionifTxnFails(responseSourceCustomerVehicleObj, sb);
					}

					if(vecSourceCustomerVehObject!=null && vecSourceCustomerVehObject.size()>0){					
						for(XCustomerVehicleJPNBObj xCustomerVehicleJPNBObj : vecSourceCustomerVehObject){
							String vehRelSourceEndDate = xCustomerVehicleJPNBObj.getEndDate();
							if(vehRelSourceEndDate == null){
								XVehicleJPNBObj xVehicleJPNBObj = 	xCustomerVehicleJPNBObj.getXVehicleJPNBObj();
								String globalVIN = xVehicleJPNBObj.getGlobalVIN();
								String vehicleAddress = xVehicleJPNBObj.getVehicleAddressType();
								if(globalVIN!=null){
									sourceGlobalVINList.add(globalVIN);	
								}
								if(vehicleAddress!=null){
									sourceVehicleAddressList.add(vehicleAddress);	
								}
							}
						}					
					}
					//Source Vehicle Address changes end
					//Source Work Address and Work Phone and Sales Type address changes start				
					vecSourceAddressObject = tcrmPersonBObj.getItemsTCRMPartyAddressBObj();
					vecSourceContactMethodObject = tcrmPersonBObj.getItemsTCRMPartyContactMethodBObj();

					if(vecSourceAddressObject!=null && vecSourceAddressObject.size()>0){
						for(XAddressGroupBObjExt xAddressGroupBObjExt : vecSourceAddressObject){
							String addressEndaDate = xAddressGroupBObjExt.getEndDate();
							if(addressEndaDate == null){
								String retailerFlag = xAddressGroupBObjExt.getXAddressRetailerFlag();
								if(retailerFlag!=null && retailerFlag.equalsIgnoreCase(ExternalRuleConstant.ADDRESS_RETAILER_FLAG_N)){
									String addressType = xAddressGroupBObjExt.getAddressUsageType();
									if(addressType!=null && ((addressType.equalsIgnoreCase(ExternalRuleConstant.ADDRESS_USAGE_TYPE_OTHER_KANJI_ADDRESS_1))
											|| (addressType.equalsIgnoreCase(ExternalRuleConstant.ADDRESS_USAGE_TYPE_OTHER_KANJI_ADDRESS_2)) 
											|| (addressType.equalsIgnoreCase(ExternalRuleConstant.ADDRESS_USAGE_TYPE_OTHER_KANJI_ADDRESS_3)))){
										String locationGroupId = xAddressGroupBObjExt.getPartyAddressIdPK();
										responseSourcePrefObj = dseaAdditionsExtsComponent.getXPreferenceByLocationGroupId(locationGroupId, control);
										if (responseSourcePrefObj != null) {
											vecSourcePreferenceObject = (Vector<XPreferenceBObj>) responseSourcePrefObj
													.getData();
											if(vecSourcePreferenceObject!=null){
												if (vecSourcePreferenceObject.get(0).getStatus()
														.getStatus() == DWLStatus.FATAL) {
													throwExceptionifTxnFails(responseSourcePrefObj, sb);
												}
											}
										} else {
											throwExceptionifTxnFails(responseSourcePrefObj, sb);
										}

										if(vecSourcePreferenceObject!=null && vecSourcePreferenceObject.size()>0){
											XPreferenceBObj xPreferenceBObj = (XPreferenceBObj)(vecSourcePreferenceObject.get(0));
											String prefIndicator = xPreferenceBObj.getPreferredType();
											sourcePrefIndicatorList.add(prefIndicator);
										}
									}
								}
							}
						}

					}

					if(vecSourceAddressObject!=null && vecSourceAddressObject.size()>0){
						for(XAddressGroupBObjExt xAddressGroupBObjExt : vecSourceAddressObject){
							String addressEndaDate = xAddressGroupBObjExt.getEndDate();
							List<String> addressTypeSourceList = new ArrayList<String>();
							if(addressEndaDate == null){
								String retailerFlag = xAddressGroupBObjExt.getXAddressRetailerFlag();
								if(retailerFlag!=null && retailerFlag.equalsIgnoreCase(ExternalRuleConstant.ADDRESS_RETAILER_FLAG_N)){
									String addressValue = new String();
									String addressType = xAddressGroupBObjExt.getAddressUsageType();								
									String addrLineOne = xAddressGroupBObjExt.getTCRMAddressBObj().getAddressLineOne();
									String addrLineTwo = xAddressGroupBObjExt.getTCRMAddressBObj().getAddressLineTwo();
									String addrLineThree = xAddressGroupBObjExt.getTCRMAddressBObj().getAddressLineThree();
									String city = xAddressGroupBObjExt.getTCRMAddressBObj().getCity();
									String postalCode = xAddressGroupBObjExt.getTCRMAddressBObj().getZipPostalCode();
									String residenceNumber = xAddressGroupBObjExt.getTCRMAddressBObj().getResidenceNumber();
									String provinceType = xAddressGroupBObjExt.getTCRMAddressBObj().getProvinceStateType();
									String countryType = xAddressGroupBObjExt.getTCRMAddressBObj().getCountryType();								
									addressValue = addrLineOne + addrLineTwo + addrLineThree + city + postalCode + residenceNumber + provinceType + countryType;

									if (!xAddressSourceMap.containsKey(addressValue)) {
										addressTypeSourceList.add(addressType);
										xAddressSourceMap.put(addressValue, addressTypeSourceList);
									} else {
										List<String> addressTypeSourceOtherList = xAddressSourceMap.get(addressValue);
										addressTypeSourceOtherList.add(addressType);
										xAddressSourceMap.put(addressValue,addressTypeSourceOtherList);
									}								
								}
							}
						}

					}

					if(vecSourceContactMethodObject!=null && vecSourceContactMethodObject.size()>0){					
						for(XContactMethodGroupBObjExt xContactMethodGroupBObjExt : vecSourceContactMethodObject){
							String contactEndDate = xContactMethodGroupBObjExt.getEndDate();
							List<String> contactTypeSourceList = new ArrayList<String>();
							if(contactEndDate == null){
								String contactMethodType = xContactMethodGroupBObjExt.getContactMethodUsageType();
								String contactMethodCat = xContactMethodGroupBObjExt.getTCRMContactMethodBObj().getContactMethodType();
								if(contactMethodCat!=null && contactMethodCat.equalsIgnoreCase(ExternalRuleConstant.CONTACTMETHOD_CATEGORY_PHONE)){
									String referenceNumber = xContactMethodGroupBObjExt.getTCRMContactMethodBObj().getReferenceNumber();

									if (!xContactMethodSourceMap.containsKey(referenceNumber)) {
										contactTypeSourceList.add(contactMethodType);
										xContactMethodSourceMap.put(referenceNumber, contactTypeSourceList);
									} else {
										List<String> contactTypeSourceOtherList = xContactMethodSourceMap.get(referenceNumber);
										contactTypeSourceOtherList.add(contactMethodType);
										xContactMethodSourceMap.put(referenceNumber,contactTypeSourceOtherList);
									}
								}
							}
						}

					}				
					//Source Work Address and Work Phone and Sales Type address changes end

					//Source MyMercedes Id changes start				
					vecSourceContequivObject = tcrmPersonBObj.getItemsTCRMAdminContEquivBObj();				
					if(vecSourceContequivObject!=null && vecSourceContequivObject.size()>0){
						for(XContEquivBObjExt xContEquivBObjExt : vecSourceContequivObject){
							String adminSystemType = xContEquivBObjExt.getAdminSystemType();
							if(adminSystemType!=null && adminSystemType.equalsIgnoreCase(ExternalRuleConstant.SOURCE_NAME_MYMERCEDES)){
								String sourceMyMId = xContEquivBObjExt.getAdminPartyId();
								sourceMyMIdList.add(sourceMyMId);
							}
						}
					}

					//Source MyMercedes Id changes end

					//Source DataSharing changes start
					responseSourceXDataSharingObj = dseaAdditionsExtsComponent.getDataSharingByPartyId(sourcePartyId, control);				
					if (responseSourceXDataSharingObj != null) {
						vecSourceDataSharingObject = (Vector<XDataSharingBObj>) responseSourceXDataSharingObj
								.getData();
						if(vecSourceDataSharingObject!=null){
							if (vecSourceDataSharingObject.get(0).getStatus()
									.getStatus() == DWLStatus.FATAL) {
								throwExceptionifTxnFails(responseSourceXDataSharingObj, sb);
							}
						}
					} else {
						throwExceptionifTxnFails(responseSourceXDataSharingObj, sb);
					}

					if(vecSourceDataSharingObject!=null && vecSourceDataSharingObject.size()>0){					
						for(XDataSharingBObj xDataSharingBObj : vecSourceDataSharingObject){
							String dataSharingRetailerFlag = xDataSharingBObj.getRetailerFlag();
							if(dataSharingRetailerFlag!= null && (dataSharingRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.DATASHARING_FLAG_N))){
								String dataSharingFlag = xDataSharingBObj.getDataSharingFlag();
								if(dataSharingFlag!=null){
									sourceDataSharingList.add(dataSharingFlag);	
								}
							}
						}					
					}
					//Source DataSharing changes end
					
					//Source Name Anonymous changes start
					vecSourcePersonNameObject = tcrmPersonBObj.getItemsTCRMPersonNameBObj();
					if(vecSourcePersonNameObject!=null && vecSourcePersonNameObject.size()>0){
					for(TCRMPersonNameBObj tcrmPersonNameBObj: vecSourcePersonNameObject){
						String lastName = tcrmPersonNameBObj.getLastName();
						if(lastName!=null && ((lastName.contains(ExternalRuleConstant.ANON_VALUE_1)) || (lastName.contains(ExternalRuleConstant.ANON_VALUE_2)) 
								|| (lastName.contains(ExternalRuleConstant.ANON_VALUE_3)) || (lastName.contains(ExternalRuleConstant.ANON_VALUE_4))
								|| (lastName.contains(ExternalRuleConstant.ANON_VALUE_5)) || (lastName.contains(ExternalRuleConstant.ANON_VALUE_6)))){
							
							isSourceAnonNamePresent = true;
							break;
							}
						}					
					}
					//Source Name Anonymous changes end

					if (vecSuspectObject != null && vecSuspectObject.size() > 0) {
						for (TCRMSuspectBObj tempSuspectBObj : vecSuspectObject) {
							String suspectCatType = tempSuspectBObj.getMatchCategoryCode();
							XPersonBObjExt suspectPersonBObj=new XPersonBObjExt();
							//String suspectPartyId = tempSuspectBObj.getTCRMSuspectPersonBObj().getPartyId();
							String suspectPartyId = String.valueOf(tempSuspectBObj.getEObjSuspect().getContId());
							
							if(tempSuspectBObj.getTCRMSuspectPersonBObj()==null)
							{
								suspectPersonBObj = (XPersonBObjExt) partyComponent.getPerson(suspectPartyId, "2", tempSuspectBObj.getControl());
								//tempSuspectBObj.setTCRMSuspectPersonBObj(suspectPersonBObj);
								TCRMSuspectPersonBObj suspectPerson=new TCRMSuspectPersonBObj();
								suspectPerson.getItemsTCRMAdminContEquivBObj().addAll(suspectPersonBObj.getItemsTCRMAdminContEquivBObj());
								suspectPerson.getItemsTCRMPartyAddressBObj().addAll(suspectPersonBObj.getItemsTCRMPartyAddressBObj());
								suspectPerson.getItemsTCRMPartyContactMethodBObj().addAll(suspectPersonBObj.getItemsTCRMPartyContactMethodBObj());
								suspectPerson.getItemsTCRMPersonNameBObj().addAll(suspectPersonBObj.getItemsTCRMPersonNameBObj());
								suspectPerson.getItemsTCRMPartyIdentificationBObj().addAll(suspectPersonBObj.getItemsTCRMPartyIdentificationBObj());
								tempSuspectBObj.setTCRMSuspectPersonBObj(suspectPerson);
								/*tempSuspectBObj.getTCRMSuspectPersonBObj().getItemsTCRMPartyAddressBObj().addAll(suspectPersonBObj.getItemsTCRMPartyAddressBObj());
								tempSuspectBObj.getTCRMSuspectPersonBObj().getItemsTCRMPartyContactMethodBObj().addAll(suspectPersonBObj.getItemsTCRMPartyContactMethodBObj());
								tempSuspectBObj.getTCRMSuspectPersonBObj().getItemsTCRMPersonNameBObj().addAll(suspectPersonBObj.getItemsTCRMPersonNameBObj());
								tempSuspectBObj.getTCRMSuspectPersonBObj().getItemsTCRMAdminContEquivBObj().addAll(suspectPersonBObj.getItemsTCRMAdminContEquivBObj());*/
							}

							

							if (suspectCatType.equalsIgnoreCase(ExternalRuleConstant.SUSPECT_CATEGORY_VALUEA1)) {

								//Suspect Work Address and Work Phone and Sales Type address changes start		
								Vector<XAddressGroupBObjExt> vecSuspectAddressObject = new Vector<XAddressGroupBObjExt>();
								Vector<XContactMethodGroupBObjExt> vecSuspectContactMethodObject = new Vector<XContactMethodGroupBObjExt>();
								Vector<TCRMPersonNameBObj> vecSuspectPersonNameObject = new Vector<TCRMPersonNameBObj>();
								List<String> suspectAddressTypeList = new ArrayList<String>();
								List<String> suspectContactMethodTypeList = new ArrayList<String>();
								List<String> suspectPrefIndicatorList = new ArrayList<String>();
								HashMap<String, List<String>> xContactMethodSuspectMap = new HashMap<String, List<String>>();
								HashMap<String, List<String>> xAddressSuspectMap = new HashMap<String, List<String>>();								
								Vector<XPreferenceBObj> vecSuspectPreferenceObject = new Vector<XPreferenceBObj>();
								boolean isWorkAddressPresent = false;
								boolean isWorkPhonePresent = false;
								boolean isSuspectAnonNamePresent = false;

								vecSuspectAddressObject = tempSuspectBObj.getTCRMSuspectPersonBObj().getItemsTCRMPartyAddressBObj();
								vecSuspectContactMethodObject = tempSuspectBObj.getTCRMSuspectPersonBObj().getItemsTCRMPartyContactMethodBObj();

								if(vecSuspectAddressObject!=null && vecSuspectAddressObject.size()>0){
									for(XAddressGroupBObjExt xAddressGroupBObjExt : vecSuspectAddressObject){
										String addressEndaDate = xAddressGroupBObjExt.getEndDate();
										if(addressEndaDate == null){
											String retailerFlag = xAddressGroupBObjExt.getXAddressRetailerFlag();
											if(retailerFlag!=null && retailerFlag.equalsIgnoreCase(ExternalRuleConstant.ADDRESS_RETAILER_FLAG_N)){
												String addressType = xAddressGroupBObjExt.getAddressUsageType();
												if(addressType!=null && ((addressType.equalsIgnoreCase(ExternalRuleConstant.ADDRESS_USAGE_TYPE_OTHER_KANJI_ADDRESS_1))
														|| (addressType.equalsIgnoreCase(ExternalRuleConstant.ADDRESS_USAGE_TYPE_OTHER_KANJI_ADDRESS_2)) 
														|| (addressType.equalsIgnoreCase(ExternalRuleConstant.ADDRESS_USAGE_TYPE_OTHER_KANJI_ADDRESS_3)))){
													String locationGroupId = xAddressGroupBObjExt.getPartyAddressIdPK();
													responseSuspectPrefObj = dseaAdditionsExtsComponent.getXPreferenceByLocationGroupId(locationGroupId, control);
													if (responseSuspectPrefObj != null) {
														vecSuspectPreferenceObject = (Vector<XPreferenceBObj>) responseSuspectPrefObj
																.getData();
														if(vecSuspectPreferenceObject!=null){
															if (vecSuspectPreferenceObject.get(0).getStatus()
																	.getStatus() == DWLStatus.FATAL) {
																throwExceptionifTxnFails(responseSuspectPrefObj, sb);
															}
														}
													} else {
														throwExceptionifTxnFails(responseSuspectPrefObj, sb);
													}

													if(vecSuspectPreferenceObject!=null && vecSuspectPreferenceObject.size()>0){
														XPreferenceBObj xPreferenceBObj = (XPreferenceBObj)(vecSuspectPreferenceObject.get(0));
														String prefIndicator = xPreferenceBObj.getPreferredType();
														suspectPrefIndicatorList.add(prefIndicator);
													}
												}
											}
										}
									}
								}

								if(vecSuspectAddressObject!=null && vecSuspectAddressObject.size()>0){
									for(XAddressGroupBObjExt xAddressGroupBObjExt : vecSuspectAddressObject){
										String addressEndaDate = xAddressGroupBObjExt.getEndDate();
										List<String> addressTypeSuspectList = new ArrayList<String>();
										if(addressEndaDate == null){
											String retailerFlag = xAddressGroupBObjExt.getXAddressRetailerFlag();
											if(retailerFlag!=null && retailerFlag.equalsIgnoreCase(ExternalRuleConstant.ADDRESS_RETAILER_FLAG_N)){
												String addressValue = new String();
												String addressType = xAddressGroupBObjExt.getAddressUsageType();								
												String addrLineOne = xAddressGroupBObjExt.getTCRMAddressBObj().getAddressLineOne();
												String addrLineTwo = xAddressGroupBObjExt.getTCRMAddressBObj().getAddressLineTwo();
												String addrLineThree = xAddressGroupBObjExt.getTCRMAddressBObj().getAddressLineThree();
												String city = xAddressGroupBObjExt.getTCRMAddressBObj().getCity();
												String postalCode = xAddressGroupBObjExt.getTCRMAddressBObj().getZipPostalCode();
												String residenceNumber = xAddressGroupBObjExt.getTCRMAddressBObj().getResidenceNumber();
												String provinceType = xAddressGroupBObjExt.getTCRMAddressBObj().getProvinceStateType();
												String countryType = xAddressGroupBObjExt.getTCRMAddressBObj().getCountryType();								
												addressValue = addrLineOne + addrLineTwo + addrLineThree + city + postalCode + residenceNumber + provinceType + countryType;

												if (!xAddressSuspectMap.containsKey(addressValue)) {
													addressTypeSuspectList.add(addressType);
													xAddressSuspectMap.put(addressValue, addressTypeSuspectList);
												} else {
													List<String> addressTypeSuspectOtherList = xAddressSuspectMap.get(addressValue);
													addressTypeSuspectOtherList.add(addressType);
													xAddressSuspectMap.put(addressValue,addressTypeSuspectOtherList);
												}								
											}
										}
									}

								}

								if(vecSuspectContactMethodObject!=null && vecSuspectContactMethodObject.size()>0){
									for(XContactMethodGroupBObjExt xContactMethodGroupBObjExt : vecSuspectContactMethodObject){
										List<String> contactTypeSuspectList = new ArrayList<String>();
										String contactEndDate = xContactMethodGroupBObjExt.getEndDate();
										if(contactEndDate == null){

											String contactMethodType = xContactMethodGroupBObjExt.getContactMethodUsageType();
											String contactMethodCat = xContactMethodGroupBObjExt.getTCRMContactMethodBObj().getContactMethodType();
											if(contactMethodCat!=null && contactMethodCat.equalsIgnoreCase(ExternalRuleConstant.CONTACTMETHOD_CATEGORY_PHONE)){
												String referenceNumber = xContactMethodGroupBObjExt.getTCRMContactMethodBObj().getReferenceNumber();

														if (!xContactMethodSuspectMap.containsKey(referenceNumber)) {
															contactTypeSuspectList.add(contactMethodType);
															xContactMethodSuspectMap.put(referenceNumber, contactTypeSuspectList);
														} else {
															List<String> contactTypeSuspectOtherList = xContactMethodSuspectMap.get(referenceNumber);
															contactTypeSuspectOtherList.add(contactMethodType);
															xContactMethodSuspectMap.put(referenceNumber,contactTypeSuspectOtherList);
														}
													}
												}
										}
								}	

								if ((xAddressSourceMap!=null && xAddressSourceMap.size()>0) && (xAddressSuspectMap!=null && xAddressSuspectMap.size()>0)){									
									for (Map.Entry<String, List<String>> sourceEntry : xAddressSourceMap.entrySet()) {
										String sourceAddressValue = sourceEntry.getKey();
										List<String> sourceAddressUsageTypeList = new ArrayList<String>();
										sourceAddressUsageTypeList = sourceEntry.getValue();

										for (Map.Entry<String, List<String>> suspectEntry : xAddressSuspectMap.entrySet()) {
											String suspectAddressValue = suspectEntry.getKey();
											if(suspectAddressValue!=null && suspectAddressValue!=null && (sourceAddressValue.equalsIgnoreCase(suspectAddressValue))){
												List<String> suspectAddressUsageTypeList = new ArrayList<String>();
												suspectAddressUsageTypeList = suspectEntry.getValue();
												if((sourceAddressUsageTypeList!=null && sourceAddressUsageTypeList.size()>0 && (sourceAddressUsageTypeList.contains(ExternalRuleConstant.ADDRESS_USAGE_TYPE_BUSINESS_KANJI_ADDRESS))) 
														|| (suspectAddressUsageTypeList!=null && suspectAddressUsageTypeList.size()>0 && (suspectAddressUsageTypeList.contains(ExternalRuleConstant.ADDRESS_USAGE_TYPE_BUSINESS_KANJI_ADDRESS)))){
													isWorkAddressPresent = true;
													break;
												}
											}
										}
									}
								}

								if ((xContactMethodSourceMap!=null && xContactMethodSourceMap.size()>0) && (xContactMethodSuspectMap!=null && xContactMethodSuspectMap.size()>0)){
									for (Map.Entry<String, List<String>> sourceEntry : xContactMethodSourceMap.entrySet()) {
										String sourceContactMethodValue = sourceEntry.getKey();
										List<String> sourceContactTypeList = new ArrayList<String>();
										sourceContactTypeList = sourceEntry.getValue();

										for (Map.Entry<String, List<String>> suspectEntry : xContactMethodSuspectMap.entrySet()) {
											String suspectContactMethodValue = suspectEntry.getKey();
											if(sourceContactMethodValue!=null && suspectContactMethodValue!=null && (sourceContactMethodValue.equalsIgnoreCase(suspectContactMethodValue))){
												List<String> suspectContactTypeList = new ArrayList<String>();
												suspectContactTypeList = suspectEntry.getValue();
												if((sourceContactTypeList!=null && sourceContactTypeList.size()>0 && (sourceContactTypeList.contains(ExternalRuleConstant.WORK_PHONE_TYPE_JPN))) 
														|| (suspectContactTypeList!=null && suspectContactTypeList.size()>0 && (suspectContactTypeList.contains(ExternalRuleConstant.WORK_PHONE_TYPE_JPN)))){
													isWorkPhonePresent = true;
													break;
												}
											}
										}
									}
								}
								//Suspect Work Address and Work Phone and Sales Type address changes end

								//Suspect Vehicle Address changes start
								Vector<XCustomerVehicleJPNBObj> vecSuspectCustomerVehObject = new Vector<XCustomerVehicleJPNBObj>();
								List<String> suspectVehicleAddressList = new ArrayList<String>();												
								responseSuspectCustomerVehicleObj = dseaAdditionsExtsComponent.getAllXCustomerVehicleJPNByPartyId(suspectPartyId, control);				
								if (responseSuspectCustomerVehicleObj != null) {
									vecSuspectCustomerVehObject = (Vector<XCustomerVehicleJPNBObj>) responseSuspectCustomerVehicleObj
											.getData();
									if(vecSuspectCustomerVehObject!=null){
										if (vecSuspectCustomerVehObject.get(0).getStatus()
												.getStatus() == DWLStatus.FATAL) {
											throwExceptionifTxnFails(responseSuspectCustomerVehicleObj, sb);
										}
									}
								} else {
									throwExceptionifTxnFails(responseSuspectCustomerVehicleObj, sb);
								}

								if(vecSuspectCustomerVehObject!=null && vecSuspectCustomerVehObject.size()>0){					
									for(XCustomerVehicleJPNBObj xCustomerVehicleJPNBObj : vecSuspectCustomerVehObject){
										String vehRelSuspectEndDate = xCustomerVehicleJPNBObj.getEndDate();
										if(vehRelSuspectEndDate == null){
											XVehicleJPNBObj xVehicleJPNBObj = 	xCustomerVehicleJPNBObj.getXVehicleJPNBObj();
											String vehicleAddress = xVehicleJPNBObj.getVehicleAddressType();
											if(vehicleAddress!=null){
												suspectVehicleAddressList.add(vehicleAddress);	
											}
										}
									}					
								}
								//Suspect Vehicle Address changes end

								//Suspect MyMercedes Id changes start		
								Vector<XContEquivBObjExt> vecSuspectContequivObject = new Vector<XContEquivBObjExt>();
								List<String> suspectMyMIdList = new ArrayList<String>();
								vecSuspectContequivObject = tempSuspectBObj.getTCRMSuspectPersonBObj().getItemsTCRMAdminContEquivBObj();				
								if(vecSuspectContequivObject!=null && vecSuspectContequivObject.size()>0){
									for(XContEquivBObjExt xContEquivBObjExt : vecSuspectContequivObject){
										String adminSystemType = xContEquivBObjExt.getAdminSystemType();
										if(adminSystemType!=null && adminSystemType.equalsIgnoreCase(ExternalRuleConstant.SOURCE_NAME_MYMERCEDES)){
											String suspectMyMId = xContEquivBObjExt.getAdminPartyId();	
											suspectMyMIdList.add(suspectMyMId);
											//Added by Sameeha for Multiple MMID merge issue | 12-Feb- 2020: Start
											suspectMultipleMyMIdList.add(suspectMyMId);
											//Added by Sameeha for Multiple MMID merge issue | 12-Feb- 2020: End

										}
									}
								}

								//Suspect MyMercedes Id changes end

								//Suspect DataSharing changes start
								Vector<XDataSharingBObj> vecSuspectDataSharingObject = new Vector<XDataSharingBObj>();
								List<String> suspectDataSharingList = new ArrayList<String>();
								responseSuspectXDataSharingObj = dseaAdditionsExtsComponent.getDataSharingByPartyId(suspectPartyId, control);				
								if (responseSuspectXDataSharingObj != null) {
									vecSuspectDataSharingObject = (Vector<XDataSharingBObj>) responseSuspectXDataSharingObj
											.getData();
									if(vecSuspectDataSharingObject!=null){
										if (vecSuspectDataSharingObject.get(0).getStatus()
												.getStatus() == DWLStatus.FATAL) {
											throwExceptionifTxnFails(responseSuspectXDataSharingObj, sb);
										}
									}
								} else {
									throwExceptionifTxnFails(responseSuspectXDataSharingObj, sb);
								}

								if(vecSuspectDataSharingObject!=null && vecSuspectDataSharingObject.size()>0){					
									for(XDataSharingBObj xDataSharingBObj : vecSuspectDataSharingObject){
										String dataSharingRetailerFlag = xDataSharingBObj.getRetailerFlag();
										if(dataSharingRetailerFlag!= null && (dataSharingRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.DATASHARING_FLAG_N))){
											String dataSharingFlag = xDataSharingBObj.getDataSharingFlag();
											if(dataSharingFlag!=null){
												suspectDataSharingList.add(dataSharingFlag);	
											}
										}
									}					
								}
								//Suspect DataSharing changes end
								
								//Suspect Name Anonymous changes start
								vecSuspectPersonNameObject = tempSuspectBObj.getTCRMSuspectPersonBObj().getItemsTCRMPersonNameBObj();
								if(vecSuspectPersonNameObject!=null && vecSuspectPersonNameObject.size()>0){
								for(TCRMPersonNameBObj tcrmSuspectPersonNameBObj: vecSuspectPersonNameObject){
									String lastName = tcrmSuspectPersonNameBObj.getLastName();
									if(lastName!=null && ((lastName.contains(ExternalRuleConstant.ANON_VALUE_1)) || (lastName.contains(ExternalRuleConstant.ANON_VALUE_2)) 
											|| (lastName.contains(ExternalRuleConstant.ANON_VALUE_3)) || (lastName.contains(ExternalRuleConstant.ANON_VALUE_4))
											|| (lastName.contains(ExternalRuleConstant.ANON_VALUE_5)) || (lastName.contains(ExternalRuleConstant.ANON_VALUE_6)))){
										
										isSuspectAnonNamePresent = true;
										break;
										}
									}					
								}
								//Suspect Name Anonymous changes end

								if (isWorkAddressPresent){
									/*ISuspectProcessor suspectComp = (ISuspectProcessor) TCRMClassFactory
											.getTCRMComponent("suspect_component");*/
									//String x=ExternalRuleConstant.SUSPECT_CATEGORY_TYPEB;
									tempSuspectBObj.setAdjustedMatchCategoryCode(ExternalRuleConstant.MATCH_CAT_CODE_B);
									tempSuspectBObj.setMatchCategoryAdjustmentType(ExternalRuleConstant.SUSP_REASON_CODE_WORKADDRESS_TYPE);
									//tempSuspectBObj.setMatchCategoryAdjustmentValue(ExternalRuleConstant.SUSP_REASON_CODE_WORKADDRESS_TYPE);
/*									TCRMSuspectBObj updateSuspectA1toBBObj = new TCRMSuspectBObj();
									updateSuspectA1toBBObj.setControl(tempSuspectBObj.getControl());
									updateSuspectA1toBBObj.setSuspectIdPK(tempSuspectBObj.getSuspectIdPK());
									updateSuspectA1toBBObj.setPartySuspectLastUpdateDate(tempSuspectBObj.getPartySuspectLastUpdateDate());
									updateSuspectA1toBBObj.setCurrentSuspectCategoryType(ExternalRuleConstant.SUSPECT_CATEGORY_TYPEB);
									updateSuspectA1toBBObj.setCurrentSuspectCategoryValue(ExternalRuleConstant.SUSPECT_CATEGORY_VALUEB);
									updateSuspectA1toBBObj.setPartyId(tempSuspectBObj.getPartyId());
									updateSuspectA1toBBObj.setSuspectStatusType(tempSuspectBObj.getSuspectStatusType());
									updateSuspectA1toBBObj.setSuspectStatusValue(tempSuspectBObj.getSuspectStatusValue());
									updateSuspectA1toBBObj.setSuspectPartyId(tempSuspectBObj.getSuspectPartyId());
									updateSuspectA1toBBObj.setSourceType(tempSuspectBObj.getSourceType());
									updateSuspectA1toBBObj.setSourceValue(tempSuspectBObj.getSourceValue());
									updateSuspectA1toBBObj.setWeight(tempSuspectBObj.getWeight());
									updateSuspectA1toBBObj.setNonMatchRelevencyType(ExternalRuleConstant.SUSP_REASON_CODE_WORKADDRESS_TYPE);
									suspectComp.updateSuspect(updateSuspectA1toBBObj);*/
								} else if (isWorkPhonePresent){
									
									
									tempSuspectBObj.setAdjustedMatchCategoryCode(ExternalRuleConstant.MATCH_CAT_CODE_B);
									tempSuspectBObj.setMatchCategoryAdjustmentType(ExternalRuleConstant.SUSP_REASON_CODE_WORKPHONE_TYPE);
									/*ISuspectProcessor suspectComp = (ISuspectProcessor) TCRMClassFactory
											.getTCRMComponent("suspect_component");
									TCRMSuspectBObj updateSuspectA1toBBObj = new TCRMSuspectBObj();
									updateSuspectA1toBBObj.setControl(tempSuspectBObj.getControl());
									updateSuspectA1toBBObj.setSuspectIdPK(tempSuspectBObj.getSuspectIdPK());
									updateSuspectA1toBBObj.setPartySuspectLastUpdateDate(tempSuspectBObj.getPartySuspectLastUpdateDate());
									updateSuspectA1toBBObj.setCurrentSuspectCategoryType(ExternalRuleConstant.SUSPECT_CATEGORY_TYPEB);
									updateSuspectA1toBBObj.setCurrentSuspectCategoryValue(ExternalRuleConstant.SUSPECT_CATEGORY_VALUEB);
									updateSuspectA1toBBObj.setPartyId(tempSuspectBObj.getPartyId());
									updateSuspectA1toBBObj.setSuspectStatusType(tempSuspectBObj.getSuspectStatusType());
									updateSuspectA1toBBObj.setSuspectStatusValue(tempSuspectBObj.getSuspectStatusValue());
									updateSuspectA1toBBObj.setSuspectPartyId(tempSuspectBObj.getSuspectPartyId());
									updateSuspectA1toBBObj.setSourceType(tempSuspectBObj.getSourceType());
									updateSuspectA1toBBObj.setSourceValue(tempSuspectBObj.getSourceValue());
									updateSuspectA1toBBObj.setWeight(tempSuspectBObj.getWeight());
									updateSuspectA1toBBObj.setNonMatchRelevencyType(ExternalRuleConstant.SUSP_REASON_CODE_WORKPHONE_TYPE);
									suspectComp.updateSuspect(updateSuspectA1toBBObj);*/
								} else if ((sourceVehicleAddressList!=null && sourceVehicleAddressList.size()>0) 
										|| (suspectVehicleAddressList!=null && suspectVehicleAddressList.size()>0)){
									
									tempSuspectBObj.setAdjustedMatchCategoryCode(ExternalRuleConstant.MATCH_CAT_CODE_B);
									tempSuspectBObj.setMatchCategoryAdjustmentType(ExternalRuleConstant.SUSP_REASON_CODE_VEHICLEADDRESS_TYPE);

											/*ISuspectProcessor suspectComp = (ISuspectProcessor) TCRMClassFactory
													.getTCRMComponent("suspect_component");
											TCRMSuspectBObj updateSuspectA1toBBObj = new TCRMSuspectBObj();
											updateSuspectA1toBBObj.setControl(tempSuspectBObj.getControl());
											updateSuspectA1toBBObj.setSuspectIdPK(tempSuspectBObj.getSuspectIdPK());
											updateSuspectA1toBBObj.setPartySuspectLastUpdateDate(tempSuspectBObj.getPartySuspectLastUpdateDate());
											updateSuspectA1toBBObj.setCurrentSuspectCategoryType(ExternalRuleConstant.SUSPECT_CATEGORY_TYPEB);
											updateSuspectA1toBBObj.setCurrentSuspectCategoryValue(ExternalRuleConstant.SUSPECT_CATEGORY_VALUEB);
											updateSuspectA1toBBObj.setPartyId(tempSuspectBObj.getPartyId());
											updateSuspectA1toBBObj.setSuspectStatusType(tempSuspectBObj.getSuspectStatusType());
											updateSuspectA1toBBObj.setSuspectStatusValue(tempSuspectBObj.getSuspectStatusValue());
											updateSuspectA1toBBObj.setSuspectPartyId(tempSuspectBObj.getSuspectPartyId());
											updateSuspectA1toBBObj.setSourceType(tempSuspectBObj.getSourceType());
											updateSuspectA1toBBObj.setSourceValue(tempSuspectBObj.getSourceValue());
											updateSuspectA1toBBObj.setWeight(tempSuspectBObj.getWeight());
											updateSuspectA1toBBObj.setNonMatchRelevencyType(ExternalRuleConstant.SUSP_REASON_CODE_VEHICLEADDRESS_TYPE);
											suspectComp.updateSuspect(updateSuspectA1toBBObj);*/										
										} else if ((sourceMyMIdList!=null && sourceMyMIdList.size()>0) 
												&& (suspectMyMIdList!=null && suspectMyMIdList.size()>0)){
											
											tempSuspectBObj.setAdjustedMatchCategoryCode(ExternalRuleConstant.MATCH_CAT_CODE_B);
											tempSuspectBObj.setMatchCategoryAdjustmentType(ExternalRuleConstant.SUSP_REASON_CODE_MYMID_TYPE);

											/*ISuspectProcessor suspectComp = (ISuspectProcessor) TCRMClassFactory
													.getTCRMComponent("suspect_component");
											TCRMSuspectBObj updateSuspectA1toBBObj = new TCRMSuspectBObj();
											updateSuspectA1toBBObj.setControl(tempSuspectBObj.getControl());
											updateSuspectA1toBBObj.setSuspectIdPK(tempSuspectBObj.getSuspectIdPK());
											updateSuspectA1toBBObj.setPartySuspectLastUpdateDate(tempSuspectBObj.getPartySuspectLastUpdateDate());
											updateSuspectA1toBBObj.setCurrentSuspectCategoryType(ExternalRuleConstant.SUSPECT_CATEGORY_TYPEB);
											updateSuspectA1toBBObj.setCurrentSuspectCategoryValue(ExternalRuleConstant.SUSPECT_CATEGORY_VALUEB);
											updateSuspectA1toBBObj.setPartyId(tempSuspectBObj.getPartyId());
											updateSuspectA1toBBObj.setSuspectStatusType(tempSuspectBObj.getSuspectStatusType());
											updateSuspectA1toBBObj.setSuspectStatusValue(tempSuspectBObj.getSuspectStatusValue());
											updateSuspectA1toBBObj.setSuspectPartyId(tempSuspectBObj.getSuspectPartyId());
											updateSuspectA1toBBObj.setSourceType(tempSuspectBObj.getSourceType());
											updateSuspectA1toBBObj.setSourceValue(tempSuspectBObj.getSourceValue());
											updateSuspectA1toBBObj.setWeight(tempSuspectBObj.getWeight());
											updateSuspectA1toBBObj.setNonMatchRelevencyType(ExternalRuleConstant.SUSP_REASON_CODE_MYMID_TYPE);
											suspectComp.updateSuspect(updateSuspectA1toBBObj);	*/									
										} 
								//Added by Sameeha for Multiple MMID merge issue | 12-Feb- 2020: Start
										else if (sourceMyMIdList.isEmpty() 
												&& (suspectMultipleMyMIdList!=null && suspectMultipleMyMIdList.size()>1)){
											
											tempSuspectBObj.setAdjustedMatchCategoryCode(ExternalRuleConstant.MATCH_CAT_CODE_B);
											tempSuspectBObj.setMatchCategoryAdjustmentType(ExternalRuleConstant.SUSP_REASON_CODE_MULTIPLE_MYMID_TYPE);

																			
										}
								//Added by Sameeha for Multiple MMID merge issue | 12-Feb- 2020: End

										else if ((sourceDataSharingList!=null && sourceDataSharingList.size()>0 && (sourceDataSharingList.contains(ExternalRuleConstant.DATASHARING_FLAG_N))) 
												&& (suspectDataSharingList!=null && suspectDataSharingList.size()>0 && (suspectDataSharingList.contains(ExternalRuleConstant.DATASHARING_FLAG_N)))){

											tempSuspectBObj.setAdjustedMatchCategoryCode(ExternalRuleConstant.MATCH_CAT_CODE_B);
											tempSuspectBObj.setMatchCategoryAdjustmentType(ExternalRuleConstant.SUSP_REASON_CODE_DATASHARINGFLAG_TYPE);
/*											ISuspectProcessor suspectComp = (ISuspectProcessor) TCRMClassFactory
													.getTCRMComponent("suspect_component");
											TCRMSuspectBObj updateSuspectA1toBBObj = new TCRMSuspectBObj();
											updateSuspectA1toBBObj.setControl(tempSuspectBObj.getControl());
											updateSuspectA1toBBObj.setSuspectIdPK(tempSuspectBObj.getSuspectIdPK());
											updateSuspectA1toBBObj.setPartySuspectLastUpdateDate(tempSuspectBObj.getPartySuspectLastUpdateDate());
											updateSuspectA1toBBObj.setCurrentSuspectCategoryType(ExternalRuleConstant.SUSPECT_CATEGORY_TYPEB);
											updateSuspectA1toBBObj.setCurrentSuspectCategoryValue(ExternalRuleConstant.SUSPECT_CATEGORY_VALUEB);
											updateSuspectA1toBBObj.setPartyId(tempSuspectBObj.getPartyId());
											updateSuspectA1toBBObj.setSuspectStatusType(tempSuspectBObj.getSuspectStatusType());
											updateSuspectA1toBBObj.setSuspectStatusValue(tempSuspectBObj.getSuspectStatusValue());
											updateSuspectA1toBBObj.setSuspectPartyId(tempSuspectBObj.getSuspectPartyId());
											updateSuspectA1toBBObj.setSourceType(tempSuspectBObj.getSourceType());
											updateSuspectA1toBBObj.setSourceValue(tempSuspectBObj.getSourceValue());
											updateSuspectA1toBBObj.setWeight(tempSuspectBObj.getWeight());
											updateSuspectA1toBBObj.setNonMatchRelevencyType(ExternalRuleConstant.SUSP_REASON_CODE_DATASHARINGFLAG_TYPE);
											suspectComp.updateSuspect(updateSuspectA1toBBObj);	*/									
										} else if ((sourcePrefIndicatorList!=null && sourcePrefIndicatorList.size()>0 && (sourcePrefIndicatorList.contains(ExternalRuleConstant.PREFERRED_TYPE_Y))) 
												|| (suspectPrefIndicatorList!=null && suspectPrefIndicatorList.size()>0 && (suspectPrefIndicatorList.contains(ExternalRuleConstant.PREFERRED_TYPE_Y)))){

											tempSuspectBObj.setAdjustedMatchCategoryCode(ExternalRuleConstant.MATCH_CAT_CODE_B);
											tempSuspectBObj.setMatchCategoryAdjustmentType(ExternalRuleConstant.SUSP_REASON_CODE_PREFADDRINDICATOR_TYPE);
/*											ISuspectProcessor suspectComp = (ISuspectProcessor) TCRMClassFactory
													.getTCRMComponent("suspect_component");
											TCRMSuspectBObj updateSuspectA1toBBObj = new TCRMSuspectBObj();
											updateSuspectA1toBBObj.setControl(tempSuspectBObj.getControl());
											updateSuspectA1toBBObj.setSuspectIdPK(tempSuspectBObj.getSuspectIdPK());
											updateSuspectA1toBBObj.setPartySuspectLastUpdateDate(tempSuspectBObj.getPartySuspectLastUpdateDate());
											updateSuspectA1toBBObj.setCurrentSuspectCategoryType(ExternalRuleConstant.SUSPECT_CATEGORY_TYPEB);
											updateSuspectA1toBBObj.setCurrentSuspectCategoryValue(ExternalRuleConstant.SUSPECT_CATEGORY_VALUEB);
											updateSuspectA1toBBObj.setPartyId(tempSuspectBObj.getPartyId());
											updateSuspectA1toBBObj.setSuspectStatusType(tempSuspectBObj.getSuspectStatusType());
											updateSuspectA1toBBObj.setSuspectStatusValue(tempSuspectBObj.getSuspectStatusValue());
											updateSuspectA1toBBObj.setSuspectPartyId(tempSuspectBObj.getSuspectPartyId());
											updateSuspectA1toBBObj.setSourceType(tempSuspectBObj.getSourceType());
											updateSuspectA1toBBObj.setSourceValue(tempSuspectBObj.getSourceValue());
											updateSuspectA1toBBObj.setWeight(tempSuspectBObj.getWeight());
											updateSuspectA1toBBObj.setNonMatchRelevencyType(ExternalRuleConstant.SUSP_REASON_CODE_PREFADDRINDICATOR_TYPE);
											suspectComp.updateSuspect(updateSuspectA1toBBObj);	*/									
										} else if (isSourceAnonNamePresent && isSuspectAnonNamePresent){
											
											tempSuspectBObj.setAdjustedMatchCategoryCode(ExternalRuleConstant.MATCH_CAT_CODE_B);
											tempSuspectBObj.setMatchCategoryAdjustmentType(ExternalRuleConstant.SUSP_REASON_CODE_ANONNAME_VALUES);
											/*ISuspectProcessor suspectComp = (ISuspectProcessor) TCRMClassFactory
													.getTCRMComponent("suspect_component");
											TCRMSuspectBObj updateSuspectA1toBBObj = new TCRMSuspectBObj();
											updateSuspectA1toBBObj.setControl(tempSuspectBObj.getControl());
											updateSuspectA1toBBObj.setSuspectIdPK(tempSuspectBObj.getSuspectIdPK());
											updateSuspectA1toBBObj.setPartySuspectLastUpdateDate(tempSuspectBObj.getPartySuspectLastUpdateDate());
											updateSuspectA1toBBObj.setCurrentSuspectCategoryType(ExternalRuleConstant.SUSPECT_CATEGORY_TYPEB);
											updateSuspectA1toBBObj.setCurrentSuspectCategoryValue(ExternalRuleConstant.SUSPECT_CATEGORY_VALUEB);
											updateSuspectA1toBBObj.setPartyId(tempSuspectBObj.getPartyId());
											updateSuspectA1toBBObj.setSuspectStatusType(tempSuspectBObj.getSuspectStatusType());
											updateSuspectA1toBBObj.setSuspectStatusValue(tempSuspectBObj.getSuspectStatusValue());
											updateSuspectA1toBBObj.setSuspectPartyId(tempSuspectBObj.getSuspectPartyId());
											updateSuspectA1toBBObj.setSourceType(tempSuspectBObj.getSourceType());
											updateSuspectA1toBBObj.setSourceValue(tempSuspectBObj.getSourceValue());
											updateSuspectA1toBBObj.setWeight(tempSuspectBObj.getWeight());
											updateSuspectA1toBBObj.setNonMatchRelevencyType(ExternalRuleConstant.SUSP_REASON_CODE_ANONNAME_VALUES);
											suspectComp.updateSuspect(updateSuspectA1toBBObj);*/
										}
									}
								}
							}
						}

						if (tcrmPartyBObj instanceof XOrgBObjExt) {

							tcrmOrgBObj = (XOrgBObjExt) tcrmPartyBObj;
							control = tcrmOrgBObj.getControl();							
							vecSuspectObject = tcrmOrgBObj.getItemsTCRMSuspectBObj();
							sourcePartyId = tcrmOrgBObj.getPartyId();

							//Source Vehicle Address changes start
							responseSourceCustomerVehicleObj = dseaAdditionsExtsComponent.getAllXCustomerVehicleJPNByPartyId(sourcePartyId, control);				
							if (responseSourceCustomerVehicleObj != null) {
								vecSourceCustomerVehObject = (Vector<XCustomerVehicleJPNBObj>) responseSourceCustomerVehicleObj
										.getData();
								if(vecSourceCustomerVehObject!=null){
									if (vecSourceCustomerVehObject.get(0).getStatus()
											.getStatus() == DWLStatus.FATAL) {
										throwExceptionifTxnFails(responseSourceCustomerVehicleObj, sb);
									}
								}
							} else {
								throwExceptionifTxnFails(responseSourceCustomerVehicleObj, sb);
							}

							if(vecSourceCustomerVehObject!=null && vecSourceCustomerVehObject.size()>0){					
								for(XCustomerVehicleJPNBObj xCustomerVehicleJPNBObj : vecSourceCustomerVehObject){
									String vehRelSourceEndDate = xCustomerVehicleJPNBObj.getEndDate();
									if(vehRelSourceEndDate == null){
										XVehicleJPNBObj xVehicleJPNBObj = 	xCustomerVehicleJPNBObj.getXVehicleJPNBObj();
										String globalVIN = xVehicleJPNBObj.getGlobalVIN();
										String vehicleAddress = xVehicleJPNBObj.getVehicleAddressType();
										if(globalVIN!=null){
											sourceGlobalVINList.add(globalVIN);	
										}
										if(vehicleAddress!=null){
											sourceVehicleAddressList.add(vehicleAddress);	
										}
									}
								}					
							}
							//Source Vehicle Address changes end
							//Source Work Address and Work Phone and Sales Type address changes start				
							vecSourceAddressObject = tcrmOrgBObj.getItemsTCRMPartyAddressBObj();
							vecSourceContactMethodObject = tcrmOrgBObj.getItemsTCRMPartyContactMethodBObj();

							if(vecSourceAddressObject!=null && vecSourceAddressObject.size()>0){
								for(XAddressGroupBObjExt xAddressGroupBObjExt : vecSourceAddressObject){
									String addressEndaDate = xAddressGroupBObjExt.getEndDate();
									if(addressEndaDate == null){
										String retailerFlag = xAddressGroupBObjExt.getXAddressRetailerFlag();
										if(retailerFlag!=null && retailerFlag.equalsIgnoreCase(ExternalRuleConstant.ADDRESS_RETAILER_FLAG_N)){
											String addressType = xAddressGroupBObjExt.getAddressUsageType();
											if(addressType!=null && ((addressType.equalsIgnoreCase(ExternalRuleConstant.ADDRESS_USAGE_TYPE_OTHER_KANJI_ADDRESS_1))
													|| (addressType.equalsIgnoreCase(ExternalRuleConstant.ADDRESS_USAGE_TYPE_OTHER_KANJI_ADDRESS_1)) 
													|| (addressType.equalsIgnoreCase(ExternalRuleConstant.ADDRESS_USAGE_TYPE_OTHER_KANJI_ADDRESS_1)))){
												String locationGroupId = xAddressGroupBObjExt.getPartyAddressIdPK();
												responseSourcePrefObj = dseaAdditionsExtsComponent.getXPreferenceByLocationGroupId(locationGroupId, control);
												if (responseSourcePrefObj != null) {
													vecSourcePreferenceObject = (Vector<XPreferenceBObj>) responseSourcePrefObj
															.getData();
													if(vecSourcePreferenceObject!=null){
														if (vecSourcePreferenceObject.get(0).getStatus()
																.getStatus() == DWLStatus.FATAL) {
															throwExceptionifTxnFails(responseSourcePrefObj, sb);
														}
													}
												} else {
													throwExceptionifTxnFails(responseSourcePrefObj, sb);
												}

												if(vecSourcePreferenceObject!=null && vecSourcePreferenceObject.size()>0){
													XPreferenceBObj xPreferenceBObj = (XPreferenceBObj)(vecSourcePreferenceObject.get(0));
													String prefIndicator = xPreferenceBObj.getPreferredType();
													sourcePrefIndicatorList.add(prefIndicator);
												}
											}
										}
									}
								}

							}

							if(vecSourceAddressObject!=null && vecSourceAddressObject.size()>0){
								for(XAddressGroupBObjExt xAddressGroupBObjExt : vecSourceAddressObject){
									String addressEndaDate = xAddressGroupBObjExt.getEndDate();
									List<String> addressTypeSourceList = new ArrayList<String>();
									if(addressEndaDate == null){
										String retailerFlag = xAddressGroupBObjExt.getXAddressRetailerFlag();
										if(retailerFlag!=null && retailerFlag.equalsIgnoreCase(ExternalRuleConstant.ADDRESS_RETAILER_FLAG_N)){
											String addressValue = new String();
											String addressType = xAddressGroupBObjExt.getAddressUsageType();								
											String addrLineOne = xAddressGroupBObjExt.getTCRMAddressBObj().getAddressLineOne();
											String addrLineTwo = xAddressGroupBObjExt.getTCRMAddressBObj().getAddressLineTwo();
											String addrLineThree = xAddressGroupBObjExt.getTCRMAddressBObj().getAddressLineThree();
											String city = xAddressGroupBObjExt.getTCRMAddressBObj().getCity();
											String postalCode = xAddressGroupBObjExt.getTCRMAddressBObj().getZipPostalCode();
											String residenceNumber = xAddressGroupBObjExt.getTCRMAddressBObj().getResidenceNumber();
											String provinceType = xAddressGroupBObjExt.getTCRMAddressBObj().getProvinceStateType();
											String countryType = xAddressGroupBObjExt.getTCRMAddressBObj().getCountryType();								
											addressValue = addrLineOne + addrLineTwo + addrLineThree + city + postalCode + residenceNumber + provinceType + countryType;

											if (!xAddressSourceMap.containsKey(addressValue)) {
												addressTypeSourceList.add(addressType);
												xAddressSourceMap.put(addressValue, addressTypeSourceList);
											} else {
												List<String> addressTypeSourceOtherList = xAddressSourceMap.get(addressValue);
												addressTypeSourceOtherList.add(addressType);
												xAddressSourceMap.put(addressValue,addressTypeSourceOtherList);
											}								
										}
									}
								}

							}

							if(vecSourceContactMethodObject!=null && vecSourceContactMethodObject.size()>0){					
								for(XContactMethodGroupBObjExt xContactMethodGroupBObjExt : vecSourceContactMethodObject){
									String contactEndDate = xContactMethodGroupBObjExt.getEndDate();
									List<String> contactTypeSourceList = new ArrayList<String>();
									if(contactEndDate == null){
										String contactMethodType = xContactMethodGroupBObjExt.getContactMethodUsageType();
										String contactMethodCat = xContactMethodGroupBObjExt.getTCRMContactMethodBObj().getContactMethodType();
										if(contactMethodCat!=null && contactMethodCat.equalsIgnoreCase(ExternalRuleConstant.CONTACTMETHOD_CATEGORY_PHONE)){
											String referenceNumber = xContactMethodGroupBObjExt.getTCRMContactMethodBObj().getReferenceNumber();

											if (!xContactMethodSourceMap.containsKey(referenceNumber)) {
												contactTypeSourceList.add(contactMethodType);
												xContactMethodSourceMap.put(referenceNumber, contactTypeSourceList);
											} else {
												List<String> contactTypeSourceOtherList = xContactMethodSourceMap.get(referenceNumber);
												contactTypeSourceOtherList.add(contactMethodType);
												xContactMethodSourceMap.put(referenceNumber,contactTypeSourceOtherList);
											}
										}
									}
								}

							}				
							//Source Work Address and Work Phone and Sales Type address changes end

							//Source MyMercedes Id changes start				
							vecSourceContequivObject = tcrmOrgBObj.getItemsTCRMAdminContEquivBObj();				
							if(vecSourceContequivObject!=null && vecSourceContequivObject.size()>0){
								for(XContEquivBObjExt xContEquivBObjExt : vecSourceContequivObject){
									String adminSystemType = xContEquivBObjExt.getAdminSystemType();
									if(adminSystemType!=null && adminSystemType.equalsIgnoreCase(ExternalRuleConstant.SOURCE_NAME_MYMERCEDES)){
										String sourceMyMId = xContEquivBObjExt.getAdminPartyId();
										sourceMyMIdList.add(sourceMyMId);
									}
								}
							}

							//Source MyMercedes Id changes end

							//Source DataSharing changes start
							responseSourceXDataSharingObj = dseaAdditionsExtsComponent.getDataSharingByPartyId(sourcePartyId, control);				
							if (responseSourceXDataSharingObj != null) {
								vecSourceDataSharingObject = (Vector<XDataSharingBObj>) responseSourceXDataSharingObj
										.getData();
								if(vecSourceDataSharingObject!=null){
									if (vecSourceDataSharingObject.get(0).getStatus()
											.getStatus() == DWLStatus.FATAL) {
										throwExceptionifTxnFails(responseSourceXDataSharingObj, sb);
									}
								}
							} else {
								throwExceptionifTxnFails(responseSourceXDataSharingObj, sb);
							}

							if(vecSourceDataSharingObject!=null && vecSourceDataSharingObject.size()>0){					
								for(XDataSharingBObj xDataSharingBObj : vecSourceDataSharingObject){
									String dataSharingRetailerFlag = xDataSharingBObj.getRetailerFlag();
									if(dataSharingRetailerFlag!= null && (dataSharingRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.DATASHARING_FLAG_N))){
										String dataSharingFlag = xDataSharingBObj.getDataSharingFlag();
										if(dataSharingFlag!=null){
											sourceDataSharingList.add(dataSharingFlag);	
										}
									}
								}					
							}
							//Source DataSharing changes end
							
							//Source Name Anonymous changes start
							vecSourceOrgNameObject = tcrmOrgBObj.getItemsTCRMOrganizationNameBObj();
							if(vecSourceOrgNameObject!=null && vecSourceOrgNameObject.size()>0){
							for(TCRMOrganizationNameBObj tcrmOrgNameBObj: vecSourceOrgNameObject){
								String OrgName = tcrmOrgNameBObj.getOrganizationName();
								if(OrgName!=null && ((OrgName.contains(ExternalRuleConstant.ANON_VALUE_1)) || (OrgName.contains(ExternalRuleConstant.ANON_VALUE_2)) 
										|| (OrgName.contains(ExternalRuleConstant.ANON_VALUE_3)) || (OrgName.contains(ExternalRuleConstant.ANON_VALUE_4))
										|| (OrgName.contains(ExternalRuleConstant.ANON_VALUE_5)) || (OrgName.contains(ExternalRuleConstant.ANON_VALUE_6)))){
									
									isSourceAnonNamePresent = true;
									break;
									}
								}					
							}
							//Source Name Anonymous changes end

							if (vecSuspectObject != null && vecSuspectObject.size() > 0) {
								for (TCRMSuspectBObj tempSuspectBObj : vecSuspectObject) {
									//String suspectCatType = tempSuspectBObj.getCurrentSuspectCategoryValue();
									XOrgBObjExt suspectOrgBObj=new XOrgBObjExt();
									String suspectCatType = tempSuspectBObj.getMatchCategoryCode();
									String suspectPartyId = String.valueOf(tempSuspectBObj.getEObjSuspect().getContId());
									
									if(tempSuspectBObj.getTCRMSuspectOrganizationBObj()==null)
									{
										suspectOrgBObj = (XOrgBObjExt) partyComponent.getOrganization(suspectPartyId, "2", tempSuspectBObj.getControl());
										
										TCRMSuspectOrganizationBObj suspectOrg=new TCRMSuspectOrganizationBObj();
										suspectOrg.getItemsTCRMAdminContEquivBObj().addAll(suspectOrgBObj.getItemsTCRMAdminContEquivBObj());
										suspectOrg.getItemsTCRMPartyAddressBObj().addAll(suspectOrgBObj.getItemsTCRMPartyAddressBObj());
										suspectOrg.getItemsTCRMPartyContactMethodBObj().addAll(suspectOrgBObj.getItemsTCRMPartyContactMethodBObj());
										suspectOrg.getItemsTCRMOrganizationNameBObj().addAll(suspectOrgBObj.getItemsTCRMOrganizationNameBObj());
										suspectOrg.getItemsTCRMPartyIdentificationBObj().addAll(suspectOrgBObj.getItemsTCRMPartyIdentificationBObj());
										tempSuspectBObj.setTCRMSuspectOrganizationBObj(suspectOrg);
									}

									if (suspectCatType.equalsIgnoreCase(ExternalRuleConstant.SUSPECT_CATEGORY_VALUEA1)) {

										//Suspect Work Address and Work Phone and Sales Type address changes start		
										Vector<XAddressGroupBObjExt> vecSuspectAddressObject = new Vector<XAddressGroupBObjExt>();
										Vector<XContactMethodGroupBObjExt> vecSuspectContactMethodObject = new Vector<XContactMethodGroupBObjExt>();
										Vector<TCRMOrganizationNameBObj> vecSuspectOrgNameObject = new Vector<TCRMOrganizationNameBObj>();
										List<String> suspectAddressTypeList = new ArrayList<String>();
										List<String> suspectContactMethodTypeList = new ArrayList<String>();
										List<String> suspectPrefIndicatorList = new ArrayList<String>();
										HashMap<String, List<String>> xContactMethodSuspectMap = new HashMap<String, List<String>>();
										HashMap<String, List<String>> xAddressSuspectMap = new HashMap<String, List<String>>();
										Vector<XPreferenceBObj> vecSuspectPreferenceObject = new Vector<XPreferenceBObj>();
										boolean isWorkAddressPresent = false;
										boolean isWorkPhonePresent = false;
										boolean isSuspectAnonNamePresent = false;

										vecSuspectAddressObject = tempSuspectBObj.getTCRMSuspectOrganizationBObj().getItemsTCRMPartyAddressBObj();
										vecSuspectContactMethodObject = tempSuspectBObj.getTCRMSuspectOrganizationBObj().getItemsTCRMPartyContactMethodBObj();

										if(vecSuspectAddressObject!=null && vecSuspectAddressObject.size()>0){
											for(XAddressGroupBObjExt xAddressGroupBObjExt : vecSuspectAddressObject){
												String addressEndaDate = xAddressGroupBObjExt.getEndDate();
												if(addressEndaDate == null){
													String retailerFlag = xAddressGroupBObjExt.getXAddressRetailerFlag();
													if(retailerFlag!=null && retailerFlag.equalsIgnoreCase(ExternalRuleConstant.ADDRESS_RETAILER_FLAG_N)){
														String addressType = xAddressGroupBObjExt.getAddressUsageType();
														if(addressType!=null && ((addressType.equalsIgnoreCase(ExternalRuleConstant.ADDRESS_USAGE_TYPE_OTHER_KANJI_ADDRESS_1))
																|| (addressType.equalsIgnoreCase(ExternalRuleConstant.ADDRESS_USAGE_TYPE_OTHER_KANJI_ADDRESS_2)) 
																|| (addressType.equalsIgnoreCase(ExternalRuleConstant.ADDRESS_USAGE_TYPE_OTHER_KANJI_ADDRESS_3)))){
															String locationGroupId = xAddressGroupBObjExt.getPartyAddressIdPK();
															responseSuspectPrefObj = dseaAdditionsExtsComponent.getXPreferenceByLocationGroupId(locationGroupId, control);
															if (responseSuspectPrefObj != null) {
																vecSuspectPreferenceObject = (Vector<XPreferenceBObj>) responseSuspectPrefObj
																		.getData();
																if(vecSuspectPreferenceObject!=null){
																	if (vecSuspectPreferenceObject.get(0).getStatus()
																			.getStatus() == DWLStatus.FATAL) {
																		throwExceptionifTxnFails(responseSuspectPrefObj, sb);
																	}
																}
															} else {
																throwExceptionifTxnFails(responseSuspectPrefObj, sb);
															}

															if(vecSuspectPreferenceObject!=null && vecSuspectPreferenceObject.size()>0){
																XPreferenceBObj xPreferenceBObj = (XPreferenceBObj)(vecSuspectPreferenceObject.get(0));
																String prefIndicator = xPreferenceBObj.getPreferredType();
																suspectPrefIndicatorList.add(prefIndicator);
															}
														}
													}
												}
											}
										}

										if(vecSuspectAddressObject!=null && vecSuspectAddressObject.size()>0){
											for(XAddressGroupBObjExt xAddressGroupBObjExt : vecSuspectAddressObject){
												String addressEndaDate = xAddressGroupBObjExt.getEndDate();
												List<String> addressTypeSuspectList = new ArrayList<String>();
												if(addressEndaDate == null){
													String retailerFlag = xAddressGroupBObjExt.getXAddressRetailerFlag();
													if(retailerFlag!=null && retailerFlag.equalsIgnoreCase(ExternalRuleConstant.ADDRESS_RETAILER_FLAG_N)){
														String addressValue = new String();
														String addressType = xAddressGroupBObjExt.getAddressUsageType();								
														String addrLineOne = xAddressGroupBObjExt.getTCRMAddressBObj().getAddressLineOne();
														String addrLineTwo = xAddressGroupBObjExt.getTCRMAddressBObj().getAddressLineTwo();
														String addrLineThree = xAddressGroupBObjExt.getTCRMAddressBObj().getAddressLineThree();
														String city = xAddressGroupBObjExt.getTCRMAddressBObj().getCity();
														String postalCode = xAddressGroupBObjExt.getTCRMAddressBObj().getZipPostalCode();
														String residenceNumber = xAddressGroupBObjExt.getTCRMAddressBObj().getResidenceNumber();
														String provinceType = xAddressGroupBObjExt.getTCRMAddressBObj().getProvinceStateType();
														String countryType = xAddressGroupBObjExt.getTCRMAddressBObj().getCountryType();								
														addressValue = addrLineOne + addrLineTwo + addrLineThree + city + postalCode + residenceNumber + provinceType + countryType;

														if (!xAddressSuspectMap.containsKey(addressValue)) {
															addressTypeSuspectList.add(addressType);
															xAddressSuspectMap.put(addressValue, addressTypeSuspectList);
														} else {
															List<String> addressTypeSuspectOtherList = xAddressSuspectMap.get(addressValue);
															addressTypeSuspectOtherList.add(addressType);
															xAddressSuspectMap.put(addressValue,addressTypeSuspectOtherList);
														}								
													}
												}
											}

										}

										if(vecSuspectContactMethodObject!=null && vecSuspectContactMethodObject.size()>0){
											for(XContactMethodGroupBObjExt xContactMethodGroupBObjExt : vecSuspectContactMethodObject){
												List<String> contactTypeSuspectList = new ArrayList<String>();
												String contactEndDate = xContactMethodGroupBObjExt.getEndDate();
												if(contactEndDate == null){

													String contactMethodType = xContactMethodGroupBObjExt.getContactMethodUsageType();
													String contactMethodCat = xContactMethodGroupBObjExt.getTCRMContactMethodBObj().getContactMethodType();
													if(contactMethodCat!=null && contactMethodCat.equalsIgnoreCase(ExternalRuleConstant.CONTACTMETHOD_CATEGORY_PHONE)){
														String referenceNumber = xContactMethodGroupBObjExt.getTCRMContactMethodBObj().getReferenceNumber();

														if (!xContactMethodSuspectMap.containsKey(referenceNumber)) {
															contactTypeSuspectList.add(contactMethodType);
															xContactMethodSuspectMap.put(referenceNumber, contactTypeSuspectList);
														} else {
															List<String> contactTypeSuspectOtherList = xContactMethodSuspectMap.get(referenceNumber);
															contactTypeSuspectOtherList.add(contactMethodType);
															xContactMethodSuspectMap.put(referenceNumber,contactTypeSuspectOtherList);
														}
													}
												}
											}

										}	

										if ((xAddressSourceMap!=null && xAddressSourceMap.size()>0) && (xAddressSuspectMap!=null && xAddressSuspectMap.size()>0)){
											for (Map.Entry<String, List<String>> sourceEntry : xAddressSourceMap.entrySet()) {
												String sourceAddressValue = sourceEntry.getKey();
												List<String> sourceAddressUsageTypeList = new ArrayList<String>();
												sourceAddressUsageTypeList = sourceEntry.getValue();

												for (Map.Entry<String, List<String>> suspectEntry : xAddressSuspectMap.entrySet()) {
													String suspectAddressValue = suspectEntry.getKey();
													if(suspectAddressValue!=null && suspectAddressValue!=null && (sourceAddressValue.equalsIgnoreCase(suspectAddressValue))){
														List<String> suspectAddressUsageTypeList = new ArrayList<String>();
														suspectAddressUsageTypeList = suspectEntry.getValue();
														if((sourceAddressUsageTypeList!=null && sourceAddressUsageTypeList.size()>0 && (sourceAddressUsageTypeList.contains(ExternalRuleConstant.ADDRESS_USAGE_TYPE_BUSINESS_KANJI_ADDRESS))) 
																|| (suspectAddressUsageTypeList!=null && suspectAddressUsageTypeList.size()>0 && (suspectAddressUsageTypeList.contains(ExternalRuleConstant.ADDRESS_USAGE_TYPE_BUSINESS_KANJI_ADDRESS)))){
															isWorkAddressPresent = true;
															break;
														}
													}
												}
											}
										}

										if ((xContactMethodSourceMap!=null && xContactMethodSourceMap.size()>0) && (xContactMethodSuspectMap!=null && xContactMethodSuspectMap.size()>0)){
											for (Map.Entry<String, List<String>> sourceEntry : xContactMethodSourceMap.entrySet()) {
												String sourceContactMethodValue = sourceEntry.getKey();
												List<String> sourceContactTypeList = new ArrayList<String>();
												sourceContactTypeList = sourceEntry.getValue();

												for (Map.Entry<String, List<String>> suspectEntry : xContactMethodSuspectMap.entrySet()) {
													String suspectContactMethodValue = suspectEntry.getKey();
													if(sourceContactMethodValue!=null && suspectContactMethodValue!=null && (sourceContactMethodValue.equalsIgnoreCase(suspectContactMethodValue))){
														List<String> suspectContactTypeList = new ArrayList<String>();
														suspectContactTypeList = suspectEntry.getValue();
														if((sourceContactTypeList!=null && sourceContactTypeList.size()>0 && (sourceContactTypeList.contains(ExternalRuleConstant.WORK_PHONE_TYPE_JPN))) 
																|| (suspectContactTypeList!=null && suspectContactTypeList.size()>0 && (suspectContactTypeList.contains(ExternalRuleConstant.WORK_PHONE_TYPE_JPN)))){
															isWorkPhonePresent = true;
															break;
														}
													}
												}
											}
										}
										//Suspect Work Address and Work Phone and Sales Type address changes end

										//Suspect Vehicle Address changes start
										Vector<XCustomerVehicleJPNBObj> vecSuspectCustomerVehObject = new Vector<XCustomerVehicleJPNBObj>();
										List<String> suspectVehicleAddressList = new ArrayList<String>();												
										responseSuspectCustomerVehicleObj = dseaAdditionsExtsComponent.getAllXCustomerVehicleJPNByPartyId(suspectPartyId, control);				
										if (responseSuspectCustomerVehicleObj != null) {
											vecSuspectCustomerVehObject = (Vector<XCustomerVehicleJPNBObj>) responseSuspectCustomerVehicleObj
													.getData();
											if(vecSuspectCustomerVehObject!=null){
												if (vecSuspectCustomerVehObject.get(0).getStatus()
														.getStatus() == DWLStatus.FATAL) {
													throwExceptionifTxnFails(responseSuspectCustomerVehicleObj, sb);
												}
											}
										} else {
											throwExceptionifTxnFails(responseSuspectCustomerVehicleObj, sb);
										}

										if(vecSuspectCustomerVehObject!=null && vecSuspectCustomerVehObject.size()>0){					
											for(XCustomerVehicleJPNBObj xCustomerVehicleJPNBObj : vecSuspectCustomerVehObject){
												String vehRelSuspectEndDate = xCustomerVehicleJPNBObj.getEndDate();
												if(vehRelSuspectEndDate == null){
													XVehicleJPNBObj xVehicleJPNBObj = 	xCustomerVehicleJPNBObj.getXVehicleJPNBObj();
													String vehicleAddress = xVehicleJPNBObj.getVehicleAddressType();
													if(vehicleAddress!=null){
														suspectVehicleAddressList.add(vehicleAddress);	
													}
												}
											}					
										}
										//Suspect Vehicle Address changes end

										//Suspect MyMercedes Id changes start		
										Vector<XContEquivBObjExt> vecSuspectContequivObject = new Vector<XContEquivBObjExt>();
										List<String> suspectMyMIdList = new ArrayList<String>(); 
										vecSuspectContequivObject = tempSuspectBObj.getTCRMSuspectOrganizationBObj().getItemsTCRMAdminContEquivBObj();				
										if(vecSuspectContequivObject!=null && vecSuspectContequivObject.size()>0){
											for(XContEquivBObjExt xContEquivBObjExt : vecSuspectContequivObject){
												String adminSystemType = xContEquivBObjExt.getAdminSystemType();
												if(adminSystemType!=null && adminSystemType.equalsIgnoreCase(ExternalRuleConstant.SOURCE_NAME_MYMERCEDES)){
													String suspectMyMId = xContEquivBObjExt.getAdminPartyId();	
													suspectMyMIdList.add(suspectMyMId);
												}
											}
										}

										//Suspect MyMercedes Id changes end

										//Suspect DataSharing changes start
										Vector<XDataSharingBObj> vecSuspectDataSharingObject = new Vector<XDataSharingBObj>();
										List<String> suspectDataSharingList = new ArrayList<String>();
										responseSuspectXDataSharingObj = dseaAdditionsExtsComponent.getDataSharingByPartyId(suspectPartyId, control);				
										if (responseSuspectXDataSharingObj != null) {
											vecSuspectDataSharingObject = (Vector<XDataSharingBObj>) responseSuspectXDataSharingObj
													.getData();
											if(vecSuspectDataSharingObject!=null){
												if (vecSuspectDataSharingObject.get(0).getStatus()
														.getStatus() == DWLStatus.FATAL) {
													throwExceptionifTxnFails(responseSuspectXDataSharingObj, sb);
												}
											}
										} else {
											throwExceptionifTxnFails(responseSuspectXDataSharingObj, sb);
										}

										if(vecSuspectDataSharingObject!=null && vecSuspectDataSharingObject.size()>0){					
											for(XDataSharingBObj xDataSharingBObj : vecSuspectDataSharingObject){
												String dataSharingRetailerFlag = xDataSharingBObj.getRetailerFlag();
												if(dataSharingRetailerFlag!= null && (dataSharingRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.DATASHARING_FLAG_N))){
													String dataSharingFlag = xDataSharingBObj.getDataSharingFlag();
													if(dataSharingFlag!=null){
														suspectDataSharingList.add(dataSharingFlag);	
													}
												}
											}					
										}
										//Suspect DataSharing changes end
										
										//Suspect Name Anonymous changes start
										vecSuspectOrgNameObject = tempSuspectBObj.getTCRMSuspectOrganizationBObj().getItemsTCRMOrganizationNameBObj();
										if(vecSuspectOrgNameObject!=null && vecSuspectOrgNameObject.size()>0){
										for(TCRMOrganizationNameBObj tcrmSuspectOrgNameBObj: vecSuspectOrgNameObject){
											String orgName = tcrmSuspectOrgNameBObj.getOrganizationName();
											if(orgName!=null && ((orgName.contains(ExternalRuleConstant.ANON_VALUE_1)) || (orgName.contains(ExternalRuleConstant.ANON_VALUE_2)) 
													|| (orgName.contains(ExternalRuleConstant.ANON_VALUE_3)) || (orgName.contains(ExternalRuleConstant.ANON_VALUE_4))
													|| (orgName.contains(ExternalRuleConstant.ANON_VALUE_5)) || (orgName.contains(ExternalRuleConstant.ANON_VALUE_6)))){
												
												isSuspectAnonNamePresent = true;
												break;
												}
											}					
										}
										//Suspect Name Anonymous changes end

										if(isWorkAddressPresent){
											
											tempSuspectBObj.setAdjustedMatchCategoryCode(ExternalRuleConstant.MATCH_CAT_CODE_B);
											tempSuspectBObj.setMatchCategoryAdjustmentType(ExternalRuleConstant.SUSP_REASON_CODE_WORKADDRESS_TYPE);
											/*ISuspectProcessor suspectComp = (ISuspectProcessor) TCRMClassFactory
													.getTCRMComponent("suspect_component");
											TCRMSuspectBObj updateSuspectA1toBBObj = new TCRMSuspectBObj();
											updateSuspectA1toBBObj.setControl(tempSuspectBObj.getControl());
											updateSuspectA1toBBObj.setSuspectIdPK(tempSuspectBObj.getSuspectIdPK());
											updateSuspectA1toBBObj.setPartySuspectLastUpdateDate(tempSuspectBObj.getPartySuspectLastUpdateDate());
											updateSuspectA1toBBObj.setCurrentSuspectCategoryType(ExternalRuleConstant.SUSPECT_CATEGORY_TYPEB);
											updateSuspectA1toBBObj.setCurrentSuspectCategoryValue(ExternalRuleConstant.SUSPECT_CATEGORY_VALUEB);
											updateSuspectA1toBBObj.setPartyId(tempSuspectBObj.getPartyId());
											updateSuspectA1toBBObj.setSuspectStatusType(tempSuspectBObj.getSuspectStatusType());
											updateSuspectA1toBBObj.setSuspectStatusValue(tempSuspectBObj.getSuspectStatusValue());
											updateSuspectA1toBBObj.setSuspectPartyId(tempSuspectBObj.getSuspectPartyId());
											updateSuspectA1toBBObj.setSourceType(tempSuspectBObj.getSourceType());
											updateSuspectA1toBBObj.setSourceValue(tempSuspectBObj.getSourceValue());
											updateSuspectA1toBBObj.setWeight(tempSuspectBObj.getWeight());
											updateSuspectA1toBBObj.setNonMatchRelevencyType(ExternalRuleConstant.SUSP_REASON_CODE_WORKADDRESS_TYPE);
											suspectComp.updateSuspect(updateSuspectA1toBBObj);*/
										} 								
										else if(isWorkPhonePresent){
											tempSuspectBObj.setAdjustedMatchCategoryCode(ExternalRuleConstant.MATCH_CAT_CODE_B);
											tempSuspectBObj.setMatchCategoryAdjustmentType(ExternalRuleConstant.SUSP_REASON_CODE_WORKPHONE_TYPE);
											/*ISuspectProcessor suspectComp = (ISuspectProcessor) TCRMClassFactory
													.getTCRMComponent("suspect_component");
											TCRMSuspectBObj updateSuspectA1toBBObj = new TCRMSuspectBObj();
											updateSuspectA1toBBObj.setControl(tempSuspectBObj.getControl());
											updateSuspectA1toBBObj.setSuspectIdPK(tempSuspectBObj.getSuspectIdPK());
											updateSuspectA1toBBObj.setPartySuspectLastUpdateDate(tempSuspectBObj.getPartySuspectLastUpdateDate());
											updateSuspectA1toBBObj.setCurrentSuspectCategoryType(ExternalRuleConstant.SUSPECT_CATEGORY_TYPEB);
											updateSuspectA1toBBObj.setCurrentSuspectCategoryValue(ExternalRuleConstant.SUSPECT_CATEGORY_VALUEB);
											updateSuspectA1toBBObj.setPartyId(tempSuspectBObj.getPartyId());
											updateSuspectA1toBBObj.setSuspectStatusType(tempSuspectBObj.getSuspectStatusType());
											updateSuspectA1toBBObj.setSuspectStatusValue(tempSuspectBObj.getSuspectStatusValue());
											updateSuspectA1toBBObj.setSuspectPartyId(tempSuspectBObj.getSuspectPartyId());
											updateSuspectA1toBBObj.setSourceType(tempSuspectBObj.getSourceType());
											updateSuspectA1toBBObj.setSourceValue(tempSuspectBObj.getSourceValue());
											updateSuspectA1toBBObj.setWeight(tempSuspectBObj.getWeight());
											updateSuspectA1toBBObj.setNonMatchRelevencyType(ExternalRuleConstant.SUSP_REASON_CODE_WORKPHONE_TYPE);
											suspectComp.updateSuspect(updateSuspectA1toBBObj);*/
										} else if ((sourceVehicleAddressList!=null && sourceVehicleAddressList.size()>0) 
												|| (suspectVehicleAddressList!=null && suspectVehicleAddressList.size()>0)){

											tempSuspectBObj.setAdjustedMatchCategoryCode(ExternalRuleConstant.MATCH_CAT_CODE_B);
											tempSuspectBObj.setMatchCategoryAdjustmentType(ExternalRuleConstant.SUSP_REASON_CODE_VEHICLEADDRESS_TYPE);
											/*ISuspectProcessor suspectComp = (ISuspectProcessor) TCRMClassFactory
													.getTCRMComponent("suspect_component");
											TCRMSuspectBObj updateSuspectA1toBBObj = new TCRMSuspectBObj();
											updateSuspectA1toBBObj.setControl(tempSuspectBObj.getControl());
											updateSuspectA1toBBObj.setSuspectIdPK(tempSuspectBObj.getSuspectIdPK());
											updateSuspectA1toBBObj.setPartySuspectLastUpdateDate(tempSuspectBObj.getPartySuspectLastUpdateDate());
											updateSuspectA1toBBObj.setCurrentSuspectCategoryType(ExternalRuleConstant.SUSPECT_CATEGORY_TYPEB);
											updateSuspectA1toBBObj.setCurrentSuspectCategoryValue(ExternalRuleConstant.SUSPECT_CATEGORY_VALUEB);
											updateSuspectA1toBBObj.setPartyId(tempSuspectBObj.getPartyId());
											updateSuspectA1toBBObj.setSuspectStatusType(tempSuspectBObj.getSuspectStatusType());
											updateSuspectA1toBBObj.setSuspectStatusValue(tempSuspectBObj.getSuspectStatusValue());
											updateSuspectA1toBBObj.setSuspectPartyId(tempSuspectBObj.getSuspectPartyId());
											updateSuspectA1toBBObj.setSourceType(tempSuspectBObj.getSourceType());
											updateSuspectA1toBBObj.setSourceValue(tempSuspectBObj.getSourceValue());
											updateSuspectA1toBBObj.setWeight(tempSuspectBObj.getWeight());
											updateSuspectA1toBBObj.setNonMatchRelevencyType(ExternalRuleConstant.SUSP_REASON_CODE_VEHICLEADDRESS_TYPE);
											suspectComp.updateSuspect(updateSuspectA1toBBObj);*/

										} else if ((sourceMyMIdList!=null && sourceMyMIdList.size()>0) 
												&& (suspectMyMIdList!=null && suspectMyMIdList.size()>0)){

											tempSuspectBObj.setAdjustedMatchCategoryCode(ExternalRuleConstant.MATCH_CAT_CODE_B);
											tempSuspectBObj.setMatchCategoryAdjustmentType(ExternalRuleConstant.SUSP_REASON_CODE_MYMID_TYPE);
											/*ISuspectProcessor suspectComp = (ISuspectProcessor) TCRMClassFactory
													.getTCRMComponent("suspect_component");
											TCRMSuspectBObj updateSuspectA1toBBObj = new TCRMSuspectBObj();
											updateSuspectA1toBBObj.setControl(tempSuspectBObj.getControl());
											updateSuspectA1toBBObj.setSuspectIdPK(tempSuspectBObj.getSuspectIdPK());
											updateSuspectA1toBBObj.setPartySuspectLastUpdateDate(tempSuspectBObj.getPartySuspectLastUpdateDate());
											updateSuspectA1toBBObj.setCurrentSuspectCategoryType(ExternalRuleConstant.SUSPECT_CATEGORY_TYPEB);
											updateSuspectA1toBBObj.setCurrentSuspectCategoryValue(ExternalRuleConstant.SUSPECT_CATEGORY_VALUEB);
											updateSuspectA1toBBObj.setPartyId(tempSuspectBObj.getPartyId());
											updateSuspectA1toBBObj.setSuspectStatusType(tempSuspectBObj.getSuspectStatusType());
											updateSuspectA1toBBObj.setSuspectStatusValue(tempSuspectBObj.getSuspectStatusValue());
											updateSuspectA1toBBObj.setSuspectPartyId(tempSuspectBObj.getSuspectPartyId());
											updateSuspectA1toBBObj.setSourceType(tempSuspectBObj.getSourceType());
											updateSuspectA1toBBObj.setSourceValue(tempSuspectBObj.getSourceValue());
											updateSuspectA1toBBObj.setWeight(tempSuspectBObj.getWeight());
											updateSuspectA1toBBObj.setNonMatchRelevencyType(ExternalRuleConstant.SUSP_REASON_CODE_MYMID_TYPE);
											suspectComp.updateSuspect(updateSuspectA1toBBObj);*/

										} else if ((sourceDataSharingList!=null && sourceDataSharingList.size()>0 && (sourceDataSharingList.contains(ExternalRuleConstant.DATASHARING_FLAG_N))) 
												&& (suspectDataSharingList!=null && suspectDataSharingList.size()>0 && (suspectDataSharingList.contains(ExternalRuleConstant.DATASHARING_FLAG_N)))){

											tempSuspectBObj.setAdjustedMatchCategoryCode(ExternalRuleConstant.MATCH_CAT_CODE_B);
											tempSuspectBObj.setMatchCategoryAdjustmentType(ExternalRuleConstant.SUSP_REASON_CODE_DATASHARINGFLAG_TYPE);
											/*ISuspectProcessor suspectComp = (ISuspectProcessor) TCRMClassFactory
													.getTCRMComponent("suspect_component");
											TCRMSuspectBObj updateSuspectA1toBBObj = new TCRMSuspectBObj();
											updateSuspectA1toBBObj.setControl(tempSuspectBObj.getControl());
											updateSuspectA1toBBObj.setSuspectIdPK(tempSuspectBObj.getSuspectIdPK());
											updateSuspectA1toBBObj.setPartySuspectLastUpdateDate(tempSuspectBObj.getPartySuspectLastUpdateDate());
											updateSuspectA1toBBObj.setCurrentSuspectCategoryType(ExternalRuleConstant.SUSPECT_CATEGORY_TYPEB);
											updateSuspectA1toBBObj.setCurrentSuspectCategoryValue(ExternalRuleConstant.SUSPECT_CATEGORY_VALUEB);
											updateSuspectA1toBBObj.setPartyId(tempSuspectBObj.getPartyId());
											updateSuspectA1toBBObj.setSuspectStatusType(tempSuspectBObj.getSuspectStatusType());
											updateSuspectA1toBBObj.setSuspectStatusValue(tempSuspectBObj.getSuspectStatusValue());
											updateSuspectA1toBBObj.setSuspectPartyId(tempSuspectBObj.getSuspectPartyId());
											updateSuspectA1toBBObj.setSourceType(tempSuspectBObj.getSourceType());
											updateSuspectA1toBBObj.setSourceValue(tempSuspectBObj.getSourceValue());
											updateSuspectA1toBBObj.setWeight(tempSuspectBObj.getWeight());
											updateSuspectA1toBBObj.setNonMatchRelevencyType(ExternalRuleConstant.SUSP_REASON_CODE_DATASHARINGFLAG_TYPE);
											suspectComp.updateSuspect(updateSuspectA1toBBObj);*/

										} else if ((sourcePrefIndicatorList!=null && sourcePrefIndicatorList.size()>0 && (sourcePrefIndicatorList.contains(ExternalRuleConstant.PREFERRED_TYPE_Y))) 
												|| (suspectPrefIndicatorList!=null && suspectPrefIndicatorList.size()>0 && (suspectPrefIndicatorList.contains(ExternalRuleConstant.PREFERRED_TYPE_Y)))){

											tempSuspectBObj.setAdjustedMatchCategoryCode(ExternalRuleConstant.MATCH_CAT_CODE_B);
											tempSuspectBObj.setMatchCategoryAdjustmentType(ExternalRuleConstant.SUSP_REASON_CODE_PREFADDRINDICATOR_TYPE);
											/*ISuspectProcessor suspectComp = (ISuspectProcessor) TCRMClassFactory
													.getTCRMComponent("suspect_component");
											TCRMSuspectBObj updateSuspectA1toBBObj = new TCRMSuspectBObj();
											updateSuspectA1toBBObj.setControl(tempSuspectBObj.getControl());
											updateSuspectA1toBBObj.setSuspectIdPK(tempSuspectBObj.getSuspectIdPK());
											updateSuspectA1toBBObj.setPartySuspectLastUpdateDate(tempSuspectBObj.getPartySuspectLastUpdateDate());
											updateSuspectA1toBBObj.setCurrentSuspectCategoryType(ExternalRuleConstant.SUSPECT_CATEGORY_TYPEB);
											updateSuspectA1toBBObj.setCurrentSuspectCategoryValue(ExternalRuleConstant.SUSPECT_CATEGORY_VALUEB);
											updateSuspectA1toBBObj.setPartyId(tempSuspectBObj.getPartyId());
											updateSuspectA1toBBObj.setSuspectStatusType(tempSuspectBObj.getSuspectStatusType());
											updateSuspectA1toBBObj.setSuspectStatusValue(tempSuspectBObj.getSuspectStatusValue());
											updateSuspectA1toBBObj.setSuspectPartyId(tempSuspectBObj.getSuspectPartyId());
											updateSuspectA1toBBObj.setSourceType(tempSuspectBObj.getSourceType());
											updateSuspectA1toBBObj.setSourceValue(tempSuspectBObj.getSourceValue());
											updateSuspectA1toBBObj.setWeight(tempSuspectBObj.getWeight());
											updateSuspectA1toBBObj.setNonMatchRelevencyType(ExternalRuleConstant.SUSP_REASON_CODE_PREFADDRINDICATOR_TYPE);
											suspectComp.updateSuspect(updateSuspectA1toBBObj);*/

										} else if (isSourceAnonNamePresent && isSuspectAnonNamePresent){
											
											tempSuspectBObj.setAdjustedMatchCategoryCode(ExternalRuleConstant.MATCH_CAT_CODE_B);
											tempSuspectBObj.setMatchCategoryAdjustmentType(ExternalRuleConstant.SUSP_REASON_CODE_ANONNAME_VALUES);
											/*ISuspectProcessor suspectComp = (ISuspectProcessor) TCRMClassFactory
													.getTCRMComponent("suspect_component");
											TCRMSuspectBObj updateSuspectA1toBBObj = new TCRMSuspectBObj();
											updateSuspectA1toBBObj.setControl(tempSuspectBObj.getControl());
											updateSuspectA1toBBObj.setSuspectIdPK(tempSuspectBObj.getSuspectIdPK());
											updateSuspectA1toBBObj.setPartySuspectLastUpdateDate(tempSuspectBObj.getPartySuspectLastUpdateDate());
											updateSuspectA1toBBObj.setCurrentSuspectCategoryType(ExternalRuleConstant.SUSPECT_CATEGORY_TYPEB);
											updateSuspectA1toBBObj.setCurrentSuspectCategoryValue(ExternalRuleConstant.SUSPECT_CATEGORY_VALUEB);
											updateSuspectA1toBBObj.setPartyId(tempSuspectBObj.getPartyId());
											updateSuspectA1toBBObj.setSuspectStatusType(tempSuspectBObj.getSuspectStatusType());
											updateSuspectA1toBBObj.setSuspectStatusValue(tempSuspectBObj.getSuspectStatusValue());
											updateSuspectA1toBBObj.setSuspectPartyId(tempSuspectBObj.getSuspectPartyId());
											updateSuspectA1toBBObj.setSourceType(tempSuspectBObj.getSourceType());
											updateSuspectA1toBBObj.setSourceValue(tempSuspectBObj.getSourceValue());
											updateSuspectA1toBBObj.setWeight(tempSuspectBObj.getWeight());
											updateSuspectA1toBBObj.setNonMatchRelevencyType(ExternalRuleConstant.SUSP_REASON_CODE_ANONNAME_VALUES);
											suspectComp.updateSuspect(updateSuspectA1toBBObj);*/
										}
									}

								}

							}

						}
					}
					catch (Exception e) {
						e.printStackTrace();
						throw new BusinessProxyException();

					}
				}
		public void matchRulesAdjustForKorea(TCRMPartyBObj tcrmPartyBObj, DWLControl control) throws Exception {
			 
			XPersonBObjExt tcrmPersonBObj = null;
			XOrgBObjExt tcrmOrgBObj = null;
			Vector<TCRMSuspectBObj> vecSuspectObject = new Vector<TCRMSuspectBObj>();
			DSEAAdditionsExtsComponent dseaAdditionsExtsComponent= new DSEAAdditionsExtsComponent();
			Vector<XCustomerVehicleKORBObj> vecSourceCustomerVehObject = new Vector<XCustomerVehicleKORBObj>();
			Vector<XCustomerVehicleKORBObj> vecSuspectCustomerVehObject = new Vector<XCustomerVehicleKORBObj>();
			String sourcePartyId = null;
			String suspectPartyId = null;
			DWLResponse responseSourceCustomerVehicleObj = null;
			DWLResponse responseSuspectCustomerVehicleObj = null;
			DWLResponse responseSourceXDataSharingObj = null;
			DWLResponse responseSuspectXDataSharingObj = null;			
			DWLResponse responseSourcePrefObj = null;
			DWLResponse responseSuspectPrefObj = null;			
			StringBuffer sb = new StringBuffer();
			List<String> sourceGlobalVINList = new ArrayList<String>();
			List<String> suspectGlobalVINList = new ArrayList<String>();
			List<String> sourceContactMethodTypeList = new ArrayList<String>();
			List<String> sourceVehicleAddressList = new ArrayList<String>();
			List<String> sourceMyMIdList = new ArrayList<String>();
			List<String> sourceDataSharingList = new ArrayList<String>();
			List<String> sourcePrefIndicatorList = new ArrayList<String>();
			HashMap<String, List<String>> xContactMethodSourceMap = new HashMap<String, List<String>>();
			HashMap<String, List<String>> xAddressSourceMap = new HashMap<String, List<String>>();
			//Start
			XPersonBObjExt tcrmPersonForNameBObj = null;
			Vector<TCRMSuspectBObj> vecSuspectForNameObject = new Vector<TCRMSuspectBObj>();
			boolean nameMismatch =  false;
			//End
			try {
				if (tcrmPartyBObj instanceof XPersonBObjExt) {

					tcrmPersonBObj = (XPersonBObjExt) tcrmPartyBObj;
					control = tcrmPersonBObj.getControl();								
					vecSuspectObject = tcrmPersonBObj.getItemsTCRMSuspectBObj();
					sourcePartyId = tcrmPersonBObj.getPartyId();
					
					
					
					//START downgrade for name mismatch more than 2 character
					
					Vector<TCRMPersonNameBObj> vecSourceName = tcrmPersonBObj.getItemsTCRMPersonNameBObj();
					String sourceName = vecSourceName.firstElement().getLastName();
					
					if (null != vecSuspectObject && vecSuspectObject.size() > 0 ){
						for (TCRMSuspectBObj suspectForNameBobj :vecSuspectObject ){
						suspectPartyId = suspectForNameBobj.getSuspectPartyId();
						TCRMPartyComponent partyComponent = new TCRMPartyComponent();
						TCRMPersonBObj suspectPersonforNameBobj = partyComponent.getPerson(suspectPartyId, "1",control);
						String suspectCatType = suspectForNameBobj.getMatchCategoryCode();
						
						if (ExternalRuleConstant.SUSPECT_CATEGORY_VALUEA1.equalsIgnoreCase(suspectCatType)){
							Vector<TCRMPersonNameBObj> vecSuspectName = suspectPersonforNameBobj.getItemsTCRMPersonNameBObj();
							String suspectName = vecSuspectName.firstElement().getLastName();
							nameMismatch = noOfChar(sourceName.toUpperCase(), suspectName.toUpperCase());
							if(nameMismatch){
								
								suspectForNameBobj.setAdjustedMatchCategoryCode(ExternalRuleConstant.SUSPECT_CATEGORY_VALUEB);
								suspectForNameBobj.setMatchCategoryAdjustmentType(ExternalRuleConstant.SUSP_REASON_CODE_NAME_2);
								/*ISuspectProcessor suspectComp = (ISuspectProcessor) TCRMClassFactory.getTCRMComponent("suspect_component");
								TCRMSuspectBObj updateSuspectA1toBBObj = new TCRMSuspectBObj();
								updateSuspectA1toBBObj.setControl(suspectForNameBobj.getControl());
								updateSuspectA1toBBObj.setSuspectIdPK(suspectForNameBobj.getSuspectIdPK());
								updateSuspectA1toBBObj.setPartySuspectLastUpdateDate(suspectForNameBobj.getPartySuspectLastUpdateDate());
								updateSuspectA1toBBObj.setCurrentSuspectCategoryType(ExternalRuleConstant.SUSPECT_CATEGORY_TYPEB);
								updateSuspectA1toBBObj.setCurrentSuspectCategoryValue(ExternalRuleConstant.SUSPECT_CATEGORY_VALUEB);
								updateSuspectA1toBBObj.setPartyId(suspectForNameBobj.getPartyId());
								updateSuspectA1toBBObj.setSuspectStatusType(suspectForNameBobj.getSuspectStatusType());
								updateSuspectA1toBBObj.setSuspectStatusValue(suspectForNameBobj.getSuspectStatusValue());
								updateSuspectA1toBBObj.setSuspectPartyId(suspectForNameBobj.getSuspectPartyId());
								updateSuspectA1toBBObj.setSourceType(suspectForNameBobj.getSourceType());
								updateSuspectA1toBBObj.setSourceValue(suspectForNameBobj.getSourceValue());
								updateSuspectA1toBBObj.setWeight(suspectForNameBobj.getWeight());
								updateSuspectA1toBBObj.setNonMatchRelevencyType(ExternalRuleConstant.SUSP_REASON_CODE_NAME_2);
								suspectComp.updateSuspect(updateSuspectA1toBBObj);*/
								
							}
						}
						
						}
					}
					
					//END downgrade for name mismatch more than 2 character
					
					//Start Upgrade for phone + VIN match
					
					String sourceType = tcrmPersonBObj.getXSourceTypeFlag();
					
					// Commented for REARCH
					/*if(!"REARCH".equals(sourceType)){
					
					Vector<TCRMPartyContactMethodBObj> vecSourceContactMethodBObj = new Vector<TCRMPartyContactMethodBObj>();
					vecSourceContactMethodBObj = tcrmPersonBObj.getItemsTCRMPartyContactMethodBObj();
					List<String> sourcePhoneList = new ArrayList<String>();
					for(TCRMPartyContactMethodBObj partyContactMethodBObj : vecSourceContactMethodBObj){
						if("1044".equals(partyContactMethodBObj.getContactMethodUsageType())
								||"1045".equals(partyContactMethodBObj.getContactMethodUsageType())
								||"1046".equals(partyContactMethodBObj.getContactMethodUsageType()) 
								|| "1038".equals(partyContactMethodBObj.getContactMethodUsageType())
								|| "1039".equals(partyContactMethodBObj.getContactMethodUsageType())
								|| "1040".equals(partyContactMethodBObj.getContactMethodUsageType())){
							String sourcePhone = partyContactMethodBObj.getTCRMContactMethodBObj().getReferenceNumber();
							sourcePhoneList.add(sourcePhone); 
						}
					}
					
					responseSourceCustomerVehicleObj = dseaAdditionsExtsComponent.getAllXCustomerVehicleKORByPartyId(sourcePartyId, control);				
					if (responseSourceCustomerVehicleObj != null) {
						vecSourceCustomerVehObject = (Vector<XCustomerVehicleKORBObj>) responseSourceCustomerVehicleObj
								.getData();
						if(vecSourceCustomerVehObject!=null){
							if (vecSourceCustomerVehObject.get(0).getStatus()
									.getStatus() == DWLStatus.FATAL) {
								throwExceptionifTxnFails(responseSourceCustomerVehicleObj, sb);
							}
						}
					} else {
						throwExceptionifTxnFails(responseSourceCustomerVehicleObj, sb);
					}

					if(vecSourceCustomerVehObject!=null && vecSourceCustomerVehObject.size()>0){					
						for(XCustomerVehicleKORBObj xCustomerVehicleKORBObj : vecSourceCustomerVehObject){
							String vehRelSourceEndDate = xCustomerVehicleKORBObj.getEndDate();
							if(vehRelSourceEndDate == null){
								XVehicleKORBObj xVehicleKORBObj = 	xCustomerVehicleKORBObj.getXVehicleKORBObj();
								String globalVIN = xVehicleKORBObj.getGlobalVIN();
								if(globalVIN!=null){
									sourceGlobalVINList.add(globalVIN);	
								}
							}
						}					
					}
					
					
					if (vecSuspectObject != null && vecSuspectObject.size() > 0) {
						for (TCRMSuspectBObj tempSuspectBObj : vecSuspectObject) {
							boolean isPhoneExact = false;
							boolean isVINExact = false;
							
							suspectPartyId = tempSuspectBObj.getSuspectPartyId();
							TCRMPartyComponent partyComponent = new TCRMPartyComponent();
							TCRMPersonBObj suspectPerson = partyComponent.getPerson(suspectPartyId, "1",control);
							
							String suspectCatType = tempSuspectBObj.getMatchCategoryCode();
							
							if (suspectCatType.equalsIgnoreCase(ExternalRuleConstant.SUSPECT_CATEGORY_VALUEB)) {
								responseSuspectCustomerVehicleObj = dseaAdditionsExtsComponent.getAllXCustomerVehicleKORByPartyId(suspectPartyId, control);				
								if (responseSuspectCustomerVehicleObj != null) {
									vecSuspectCustomerVehObject = (Vector<XCustomerVehicleKORBObj>) responseSuspectCustomerVehicleObj
											.getData();
									if(vecSuspectCustomerVehObject!=null){
										if (vecSuspectCustomerVehObject.get(0).getStatus()
												.getStatus() == DWLStatus.FATAL) {
											throwExceptionifTxnFails(responseSuspectCustomerVehicleObj, sb);
										}
									}
								} else {
									throwExceptionifTxnFails(responseSuspectCustomerVehicleObj, sb);
								}

								if(vecSuspectCustomerVehObject!=null && vecSuspectCustomerVehObject.size()>0){					
									for(XCustomerVehicleKORBObj xCustomerVehicleKORBObj : vecSuspectCustomerVehObject){
										String vehRelSuspectEndDate = xCustomerVehicleKORBObj.getEndDate();
										if(vehRelSuspectEndDate == null){
											XVehicleKORBObj xVehicleKORBObj = 	xCustomerVehicleKORBObj.getXVehicleKORBObj();
											String globalVIN = xVehicleKORBObj.getGlobalVIN();
											if(globalVIN!=null){
												suspectGlobalVINList.add(globalVIN);	
											}
										}
									}					
								}
							

								Vector<TCRMPartyContactMethodBObj> vecSuspectContactMethodBObj = new Vector<TCRMPartyContactMethodBObj>();
								vecSuspectContactMethodBObj = suspectPerson.getItemsTCRMPartyContactMethodBObj();
								List<String> suspectPhoneList = new ArrayList<String>();
								for(TCRMPartyContactMethodBObj partyContactMethodBObjForSuspect : vecSuspectContactMethodBObj){
									if("1044".equals(partyContactMethodBObjForSuspect.getContactMethodUsageType())
											||"1045".equals(partyContactMethodBObjForSuspect.getContactMethodUsageType())
											||"1046".equals(partyContactMethodBObjForSuspect.getContactMethodUsageType())
											|| "1038".equals(partyContactMethodBObjForSuspect.getContactMethodUsageType())
											 || "1039".equals(partyContactMethodBObjForSuspect.getContactMethodUsageType())
											 || "1040".equals(partyContactMethodBObjForSuspect.getContactMethodUsageType())){
										String suspectPhone = partyContactMethodBObjForSuspect.getTCRMContactMethodBObj().getReferenceNumber();
										if(sourcePhoneList.contains(suspectPhone)){
											isPhoneExact = true;
											break;
										}
									}
								}
								
								if(suspectGlobalVINList.size()>0 && sourceGlobalVINList.size()>0){
									for(int i = 0; i<suspectGlobalVINList.size(); i++){
										if(sourceGlobalVINList.contains(suspectGlobalVINList.get(i))){
											isVINExact = true;
											break;
										}
									}
								}
								
								
								 
								if (isPhoneExact && isVINExact){
									tempSuspectBObj.setAdjustedMatchCategoryCode(ExternalRuleConstant.SUSPECT_CATEGORY_VALUEA1);
									tempSuspectBObj.setMatchCategoryAdjustmentType(ExternalRuleConstant.SUSP_REASON_CODE_PHONE_VIN_TYPE);
									/*ISuspectProcessor suspectComp = (ISuspectProcessor) TCRMClassFactory
											.getTCRMComponent("suspect_component");
									TCRMSuspectBObj updateSuspectBtoA1BObj = new TCRMSuspectBObj();
									updateSuspectBtoA1BObj.setControl(tempSuspectBObj.getControl());
									updateSuspectBtoA1BObj.setSuspectIdPK(tempSuspectBObj.getSuspectIdPK());
									updateSuspectBtoA1BObj.setPartySuspectLastUpdateDate(tempSuspectBObj.getPartySuspectLastUpdateDate());
									updateSuspectBtoA1BObj.setCurrentSuspectCategoryType(ExternalRuleConstant.SUSPECT_CATEGORY_TYPEA1);
									updateSuspectBtoA1BObj.setCurrentSuspectCategoryValue(ExternalRuleConstant.SUSPECT_CATEGORY_VALUEA1);
									updateSuspectBtoA1BObj.setPartyId(tempSuspectBObj.getPartyId());
									updateSuspectBtoA1BObj.setSuspectStatusType(tempSuspectBObj.getSuspectStatusType());
									updateSuspectBtoA1BObj.setSuspectStatusValue(tempSuspectBObj.getSuspectStatusValue());
									updateSuspectBtoA1BObj.setSuspectPartyId(tempSuspectBObj.getSuspectPartyId());
									updateSuspectBtoA1BObj.setSourceType(tempSuspectBObj.getSourceType());
									updateSuspectBtoA1BObj.setSourceValue(tempSuspectBObj.getSourceValue());
									updateSuspectBtoA1BObj.setWeight(tempSuspectBObj.getWeight());
									updateSuspectBtoA1BObj.setNonMatchRelevencyType(ExternalRuleConstant.SUSP_REASON_CODE_PHONE_VIN_TYPE);
									suspectComp.updateSuspect(updateSuspectBtoA1BObj);
								} 
							}
						}
						//End Upgrade for phone + VIN match
					}
					}*/
				}

				if (tcrmPartyBObj instanceof XOrgBObjExt) {

					tcrmOrgBObj = (XOrgBObjExt) tcrmPartyBObj;
					control = tcrmOrgBObj.getControl();							
					vecSuspectObject = tcrmOrgBObj.getItemsTCRMSuspectBObj();
					sourcePartyId = tcrmOrgBObj.getPartyId();
					
					String suspectVAT = null;
					String suspectCRN = null;

					Vector<XOrgNameBObjExt> vecSourceOrganizationNameBObj = new Vector<XOrgNameBObjExt>();
					vecSourceOrganizationNameBObj = tcrmOrgBObj.getItemsTCRMOrganizationNameBObj();
					List<String> sourceNameList = new ArrayList<String>();
					for(int i = 0; i<vecSourceOrganizationNameBObj.size();i++){
						if("1003".equals(vecSourceOrganizationNameBObj.get(i).getNameUsageType())
								||"1004".equals(vecSourceOrganizationNameBObj.get(i).getNameUsageType())){
							String sourceName = vecSourceOrganizationNameBObj.get(i).getOrganizationName();
							sourceNameList.add(sourceName); 
						}
					}
						
					Vector<TCRMPartyContactMethodBObj> vecSourceContactMethodBObj = new Vector<TCRMPartyContactMethodBObj>();
					vecSourceContactMethodBObj = tcrmOrgBObj.getItemsTCRMPartyContactMethodBObj();
					List<String> sourcePhoneList = new ArrayList<String>();
					for(TCRMPartyContactMethodBObj partyContactMethodBObj : vecSourceContactMethodBObj){
						if("1038".equals(partyContactMethodBObj.getContactMethodUsageType())
								||"1039".equals(partyContactMethodBObj.getContactMethodUsageType())
								||"1040".equals(partyContactMethodBObj.getContactMethodUsageType())
								||"1044".equals(partyContactMethodBObj.getContactMethodUsageType())
								||"1045".equals(partyContactMethodBObj.getContactMethodUsageType())
								||"1046".equals(partyContactMethodBObj.getContactMethodUsageType())){
							String sourcePhone = partyContactMethodBObj.getTCRMContactMethodBObj().getReferenceNumber();
							sourcePhoneList.add(sourcePhone); 
						}
					}
					
					String vatNo = null, crnNo = null;
					
					if(tcrmOrgBObj.getItemsTCRMPartyIdentificationBObj()!=null && tcrmOrgBObj.getItemsTCRMPartyIdentificationBObj().size()>0){
						Vector<TCRMPartyIdentificationBObj> vectorIdentification = new Vector<TCRMPartyIdentificationBObj>();
						vectorIdentification = tcrmOrgBObj.getItemsTCRMPartyIdentificationBObj();
						for(TCRMPartyIdentificationBObj identification : vectorIdentification){
							
							if("1032".equals(identification.getIdentificationType())){
								crnNo = identification.getIdentificationNumber();
							}
							if("1033".equals(identification.getIdentificationType())){
								vatNo = identification.getIdentificationNumber();
							}
						}					
					}
					//Source DataSharing changes end

					if (vecSuspectObject != null && vecSuspectObject.size() > 0) {
						for (TCRMSuspectBObj tempSuspectBObj : vecSuspectObject) {
							String suspectCatType = tempSuspectBObj.getMatchCategoryCode();
							 
							suspectPartyId = tempSuspectBObj.getSuspectPartyId();
							
							TCRMPartyComponent partyComponent = new TCRMPartyComponent();
							if (suspectCatType.equalsIgnoreCase(ExternalRuleConstant.SUSPECT_CATEGORY_VALUEB)) {
								
								TCRMOrganizationBObj suspectOrganizationBObj = partyComponent.getOrganization(suspectPartyId, "1", control);
								Vector<TCRMOrganizationNameBObj> vectorOrgNameSuspects = suspectOrganizationBObj.getItemsTCRMOrganizationNameBObj();
								Vector<TCRMPartyContactMethodBObj> vectorOrgContactSuspects = suspectOrganizationBObj.getItemsTCRMPartyContactMethodBObj();
								Vector<TCRMPartyIdentificationBObj> vectorOrgIdentSuspects = suspectOrganizationBObj.getItemsTCRMPartyIdentificationBObj();
								boolean isNameExact = false;
								boolean isPhoneExact = false;
								boolean isCRNExact = false;
								boolean isVATExact = false;
								boolean isPhoneMissing = false;
								boolean isCRNMissing = false;
								boolean isVATMissing = false;
								
								for(TCRMOrganizationNameBObj organizationNameBObj: vectorOrgNameSuspects){
									if("1003".equals(organizationNameBObj.getNameUsageType())
											||"1004".equals(organizationNameBObj.getNameUsageType())){
										if(sourceNameList.contains(organizationNameBObj.getOrganizationName())){
											isNameExact=true;
											break;
										}
									}
								}
								for(TCRMPartyContactMethodBObj contactMethod: vectorOrgContactSuspects){
									if("1038".equals(contactMethod.getContactMethodUsageType())
											||"1039".equals(contactMethod.getContactMethodUsageType())
											||"1040".equals(contactMethod.getContactMethodUsageType())
											||"1044".equals(contactMethod.getContactMethodUsageType())
											||"1045".equals(contactMethod.getContactMethodUsageType())
											||"1046".equals(contactMethod.getContactMethodUsageType())){
										String suspectPhone = contactMethod.getTCRMContactMethodBObj().getReferenceNumber();
										if(sourcePhoneList.contains(suspectPhone)){
											isPhoneExact = true;
											break;
										}
									}
								}

								for(TCRMPartyIdentificationBObj partyIdentification : vectorOrgIdentSuspects){
									
									if("1032".equals(partyIdentification.getIdentificationType()) &&
											partyIdentification.getIdentificationValue()!=null){
										suspectCRN = partyIdentification.getIdentificationNumber();	
										
									}else if("1033".equals(partyIdentification.getIdentificationType()) && partyIdentification.getIdentificationValue()!=null){
										suspectVAT = partyIdentification.getIdentificationNumber();

									} 

								}
								

								//Vat
								if(vatNo==null || !StringUtils.isNonBlank(vatNo )
										|| suspectVAT==null || !StringUtils.isNonBlank(suspectVAT ) ){
									isVATMissing = true;
								}else if(vatNo!=null && StringUtils.isNonBlank(vatNo) 
										&& vatNo.equalsIgnoreCase(suspectVAT)){
									isVATExact = true;
								}
								//Com Reg Id
								 if(crnNo==null || !StringUtils.isNonBlank(crnNo)
										|| suspectCRN==null || !StringUtils.isNonBlank(suspectCRN)){
									isCRNMissing = true;
								}else if(crnNo!=null && StringUtils.isNonBlank(crnNo) 
										&& crnNo.equalsIgnoreCase(suspectCRN)){
									isCRNExact = true;
								}
								
								if(isPhoneExact==false){
									if(sourcePhoneList.size()==0 || vectorOrgContactSuspects.size()==0){
										isPhoneMissing=true;
									}
								}
															
								if(isNameExact && isVATExact && isCRNExact && isPhoneMissing){
									tempSuspectBObj.setAdjustedMatchCategoryCode(ExternalRuleConstant.SUSPECT_CATEGORY_VALUEA1);
									tempSuspectBObj.setMatchCategoryAdjustmentType(ExternalRuleConstant.SUSP_REASON_CODE_NAME_VAT_CRN_TYPE);
									/*ISuspectProcessor suspectComp = (ISuspectProcessor) TCRMClassFactory
											.getTCRMComponent("suspect_component");
									TCRMSuspectBObj updateSuspectBtoA1BObj = new TCRMSuspectBObj();
									updateSuspectBtoA1BObj.setControl(tempSuspectBObj.getControl());
									updateSuspectBtoA1BObj.setSuspectIdPK(tempSuspectBObj.getSuspectIdPK());
									updateSuspectBtoA1BObj.setPartySuspectLastUpdateDate(tempSuspectBObj.getPartySuspectLastUpdateDate());
									updateSuspectBtoA1BObj.setCurrentSuspectCategoryType(ExternalRuleConstant.SUSPECT_CATEGORY_TYPEA1);
									updateSuspectBtoA1BObj.setCurrentSuspectCategoryValue(ExternalRuleConstant.SUSPECT_CATEGORY_VALUEA1);
									updateSuspectBtoA1BObj.setPartyId(tempSuspectBObj.getPartyId());
									updateSuspectBtoA1BObj.setSuspectStatusType(tempSuspectBObj.getSuspectStatusType());
									updateSuspectBtoA1BObj.setSuspectStatusValue(tempSuspectBObj.getSuspectStatusValue());
									updateSuspectBtoA1BObj.setSuspectPartyId(tempSuspectBObj.getSuspectPartyId());
									updateSuspectBtoA1BObj.setSourceType(tempSuspectBObj.getSourceType());
									updateSuspectBtoA1BObj.setSourceValue(tempSuspectBObj.getSourceValue());
									updateSuspectBtoA1BObj.setWeight(tempSuspectBObj.getWeight());
									updateSuspectBtoA1BObj.setNonMatchRelevencyType(ExternalRuleConstant.SUSP_REASON_CODE_NAME_VAT_CRN_TYPE);
									suspectComp.updateSuspect(updateSuspectBtoA1BObj);*/
								} 								
								else if(isNameExact && isCRNExact && isPhoneExact && isVATMissing){
									tempSuspectBObj.setAdjustedMatchCategoryCode(ExternalRuleConstant.SUSPECT_CATEGORY_VALUEA1);
									tempSuspectBObj.setMatchCategoryAdjustmentType(ExternalRuleConstant.SUSP_REASON_CODE_NAME_CRN_PHONE_TYPE);
								/*	ISuspectProcessor suspectComp = (ISuspectProcessor) TCRMClassFactory
											.getTCRMComponent("suspect_component");
									TCRMSuspectBObj updateSuspectA1toBBObj = new TCRMSuspectBObj();
									updateSuspectA1toBBObj.setControl(tempSuspectBObj.getControl());
									updateSuspectA1toBBObj.setSuspectIdPK(tempSuspectBObj.getSuspectIdPK());
									updateSuspectA1toBBObj.setPartySuspectLastUpdateDate(tempSuspectBObj.getPartySuspectLastUpdateDate());
									updateSuspectA1toBBObj.setCurrentSuspectCategoryType(ExternalRuleConstant.SUSPECT_CATEGORY_TYPEA1);
									updateSuspectA1toBBObj.setCurrentSuspectCategoryValue(ExternalRuleConstant.SUSPECT_CATEGORY_VALUEA1);
									updateSuspectA1toBBObj.setPartyId(tempSuspectBObj.getPartyId());
									updateSuspectA1toBBObj.setSuspectStatusType(tempSuspectBObj.getSuspectStatusType());
									updateSuspectA1toBBObj.setSuspectStatusValue(tempSuspectBObj.getSuspectStatusValue());
									updateSuspectA1toBBObj.setSuspectPartyId(tempSuspectBObj.getSuspectPartyId());
									updateSuspectA1toBBObj.setSourceType(tempSuspectBObj.getSourceType());
									updateSuspectA1toBBObj.setSourceValue(tempSuspectBObj.getSourceValue());
									updateSuspectA1toBBObj.setWeight(tempSuspectBObj.getWeight());
									updateSuspectA1toBBObj.setNonMatchRelevencyType(ExternalRuleConstant.SUSP_REASON_CODE_NAME_CRN_PHONE_TYPE);
									suspectComp.updateSuspect(updateSuspectA1toBBObj);*/
								} else if (isNameExact && isVATExact && isPhoneMissing && isCRNMissing){
									tempSuspectBObj.setAdjustedMatchCategoryCode(ExternalRuleConstant.SUSPECT_CATEGORY_VALUEA1);
									tempSuspectBObj.setMatchCategoryAdjustmentType(ExternalRuleConstant.SUSP_REASON_CODE_NAME_VAT_TYPE);

									/*ISuspectProcessor suspectComp = (ISuspectProcessor) TCRMClassFactory
											.getTCRMComponent("suspect_component");
									TCRMSuspectBObj updateSuspectA1toBBObj = new TCRMSuspectBObj();
									updateSuspectA1toBBObj.setControl(tempSuspectBObj.getControl());
									updateSuspectA1toBBObj.setSuspectIdPK(tempSuspectBObj.getSuspectIdPK());
									updateSuspectA1toBBObj.setPartySuspectLastUpdateDate(tempSuspectBObj.getPartySuspectLastUpdateDate());
									updateSuspectA1toBBObj.setCurrentSuspectCategoryType(ExternalRuleConstant.SUSPECT_CATEGORY_TYPEA1);
									updateSuspectA1toBBObj.setCurrentSuspectCategoryValue(ExternalRuleConstant.SUSPECT_CATEGORY_VALUEA1);
									updateSuspectA1toBBObj.setPartyId(tempSuspectBObj.getPartyId());
									updateSuspectA1toBBObj.setSuspectStatusType(tempSuspectBObj.getSuspectStatusType());
									updateSuspectA1toBBObj.setSuspectStatusValue(tempSuspectBObj.getSuspectStatusValue());
									updateSuspectA1toBBObj.setSuspectPartyId(tempSuspectBObj.getSuspectPartyId());
									updateSuspectA1toBBObj.setSourceType(tempSuspectBObj.getSourceType());
									updateSuspectA1toBBObj.setSourceValue(tempSuspectBObj.getSourceValue());
									updateSuspectA1toBBObj.setWeight(tempSuspectBObj.getWeight());
									updateSuspectA1toBBObj.setNonMatchRelevencyType(ExternalRuleConstant.SUSP_REASON_CODE_NAME_VAT_TYPE);
									suspectComp.updateSuspect(updateSuspectA1toBBObj);*/
								}else if (isNameExact && isVATExact && isPhoneExact && isCRNMissing){
									tempSuspectBObj.setAdjustedMatchCategoryCode(ExternalRuleConstant.SUSPECT_CATEGORY_VALUEA1);
									tempSuspectBObj.setMatchCategoryAdjustmentType(ExternalRuleConstant.SUSP_REASON_CODE_NAME_VAT_PHONE_TYPE);

									/*ISuspectProcessor suspectComp = (ISuspectProcessor) TCRMClassFactory
											.getTCRMComponent("suspect_component");
									TCRMSuspectBObj updateSuspectA1toBBObj = new TCRMSuspectBObj();
									updateSuspectA1toBBObj.setControl(tempSuspectBObj.getControl());
									updateSuspectA1toBBObj.setSuspectIdPK(tempSuspectBObj.getSuspectIdPK());
									updateSuspectA1toBBObj.setPartySuspectLastUpdateDate(tempSuspectBObj.getPartySuspectLastUpdateDate());
									updateSuspectA1toBBObj.setCurrentSuspectCategoryType(ExternalRuleConstant.SUSPECT_CATEGORY_TYPEA1);
									updateSuspectA1toBBObj.setCurrentSuspectCategoryValue(ExternalRuleConstant.SUSPECT_CATEGORY_VALUEA1);
									updateSuspectA1toBBObj.setPartyId(tempSuspectBObj.getPartyId());
									updateSuspectA1toBBObj.setSuspectStatusType(tempSuspectBObj.getSuspectStatusType());
									updateSuspectA1toBBObj.setSuspectStatusValue(tempSuspectBObj.getSuspectStatusValue());
									updateSuspectA1toBBObj.setSuspectPartyId(tempSuspectBObj.getSuspectPartyId());
									updateSuspectA1toBBObj.setSourceType(tempSuspectBObj.getSourceType());
									updateSuspectA1toBBObj.setSourceValue(tempSuspectBObj.getSourceValue());
									updateSuspectA1toBBObj.setWeight(tempSuspectBObj.getWeight());
									updateSuspectA1toBBObj.setNonMatchRelevencyType(ExternalRuleConstant.SUSP_REASON_CODE_NAME_VAT_PHONE_TYPE);
									suspectComp.updateSuspect(updateSuspectA1toBBObj);*/
								}
								else if (isNameExact && isVATExact && isPhoneExact && isCRNExact){
									tempSuspectBObj.setAdjustedMatchCategoryCode(ExternalRuleConstant.SUSPECT_CATEGORY_VALUEA1);
									tempSuspectBObj.setMatchCategoryAdjustmentType(ExternalRuleConstant.SUSP_REASON_CODE_NAME_VAT_CRN_PHONE_TYPE);
								}
							}

						}

					}

				}
			}
			catch (Exception e) {
				e.printStackTrace();
				throw new BusinessProxyException();

			}
		
		}
		    public void matchRulesAdjustForBrasil(TCRMPartyBObj tcrmPartyBObj, DWLControl control) throws Exception {
		    	XPersonBObjExt tcrmPersonBObj = null;
				Vector<TCRMSuspectBObj> vecSuspectObject = new Vector<TCRMSuspectBObj>();
				DSEAAdditionsExtsComponent dseaAdditionsExtsComponent= new DSEAAdditionsExtsComponent();
				String sourcePartyId = null;
				String suspectPartyId = null;
				DWLResponse responseSourceXDataSharingObj = null;
				DWLResponse responseSuspectXDataSharingObj = null;			
				DWLResponse responseSourcePrefObj = null;
				DWLResponse responseSuspectPrefObj = null;			
				StringBuffer sb = new StringBuffer();
				List<String> sourceContactMethodTypeList = new ArrayList<String>();
				List<String> sourceMyMIdList = new ArrayList<String>();
				List<String> sourceDataSharingList = new ArrayList<String>();
				List<String> sourcePrefIndicatorList = new ArrayList<String>();
				HashMap<String, List<String>> xContactMethodSourceMap = new HashMap<String, List<String>>();
				HashMap<String, List<String>> xAddressSourceMap = new HashMap<String, List<String>>();  
				
		    
				if (tcrmPartyBObj instanceof XPersonBObjExt) {

					tcrmPersonBObj = (XPersonBObjExt) tcrmPartyBObj;
					control = tcrmPersonBObj.getControl();							
					vecSuspectObject = tcrmPersonBObj.getItemsTCRMSuspectBObj();
					sourcePartyId = tcrmPersonBObj.getPartyId();
					
					

					Vector<XPersonNameBObjExt> vecSourcePersonNameBObj = new Vector<XPersonNameBObjExt>();
					vecSourcePersonNameBObj = tcrmPersonBObj.getItemsTCRMPersonNameBObj();
					List<String> sourceNameList = new ArrayList<String>();
					for(int i = 0; i<vecSourcePersonNameBObj.size();i++){
						if("1".equals(vecSourcePersonNameBObj.get(i).getNameUsageType())){
							String fName = vecSourcePersonNameBObj.get(i).getGivenNameOne();
							String lName = vecSourcePersonNameBObj.get(i).getLastName();
							sourceNameList.add(fName.concat(lName)); 
						}
					}
						
					Vector<TCRMPartyContactMethodBObj> vecSourcePhoneBObj = new Vector<TCRMPartyContactMethodBObj>();
					vecSourcePhoneBObj = tcrmPersonBObj.getItemsTCRMPartyContactMethodBObj();
					List<String> sourcePhoneList = new ArrayList<String>();
					
					for(TCRMPartyContactMethodBObj partyContactMethodBObj : vecSourcePhoneBObj){
						if("1049".equals(partyContactMethodBObj.getContactMethodUsageType())
								||"1050".equals(partyContactMethodBObj.getContactMethodUsageType())
								||"1051".equals(partyContactMethodBObj.getContactMethodUsageType())){
							String sourcePhone = partyContactMethodBObj.getTCRMContactMethodBObj().getReferenceNumber();
							sourcePhoneList.add(sourcePhone); 
						}
					}
					
					Vector<TCRMPartyContactMethodBObj> vecSourceEmailBObj = new Vector<TCRMPartyContactMethodBObj>();
					vecSourceEmailBObj = tcrmPersonBObj.getItemsTCRMPartyContactMethodBObj();
					List<String> sourceEmailList = new ArrayList<String>();
					
					for(TCRMPartyContactMethodBObj partyContactMethodBObj : vecSourceEmailBObj){
						if("1053".equals(partyContactMethodBObj.getContactMethodUsageType())){
							String sourceEmail = partyContactMethodBObj.getTCRMContactMethodBObj().getReferenceNumber();
							sourceEmailList.add(sourceEmail); 
						}
					}
					String sourceCPFId = null;
					
				if(tcrmPersonBObj.getItemsTCRMPartyIdentificationBObj()!=null && tcrmPersonBObj.getItemsTCRMPartyIdentificationBObj().size()>0){
					Vector<TCRMPartyIdentificationBObj> vectorIdentification = new Vector<TCRMPartyIdentificationBObj>();
					vectorIdentification = tcrmPersonBObj.getItemsTCRMPartyIdentificationBObj();
					for(TCRMPartyIdentificationBObj identification : vectorIdentification){
						
						if("1039".equals(identification.getIdentificationType())){
							sourceCPFId = identification.getIdentificationNumber();
						}
						
					}					
				}
					//Source DataSharing changes end

				if (vecSuspectObject != null && vecSuspectObject.size() > 0) {
					for (TCRMSuspectBObj tempSuspectBObj : vecSuspectObject) {
						//System.out.println(tempSuspectBObj.toXML());
						String suspectCatType = tempSuspectBObj.getMatchCategoryCode();
						 
						suspectPartyId = tempSuspectBObj.getSuspectPartyId();
						//System.out.println("Suspect Party: " + suspectCatType + " " + suspectPartyId);
						TCRMPartyComponent partyComponent = new TCRMPartyComponent();
						if (suspectCatType.equalsIgnoreCase(ExternalRuleConstant.SUSPECT_CATEGORY_VALUEA1)) {
							
							TCRMPersonBObj suspectPersonBObj = partyComponent.getPerson(suspectPartyId, "1", control);
							Vector<TCRMPersonNameBObj> vectorPerNameSuspects = suspectPersonBObj.getItemsTCRMPersonNameBObj();
							Vector<TCRMPartyContactMethodBObj> vectorContactSuspects = suspectPersonBObj.getItemsTCRMPartyContactMethodBObj();
							Vector<TCRMPartyIdentificationBObj> vectorIdentSuspects = suspectPersonBObj.getItemsTCRMPartyIdentificationBObj();
							boolean isNameExact = false;
							boolean isPhoneExact = false;
							boolean isEmailExact = false;
							boolean isCPFIdExact = false;
							boolean isPhoneMismatchTrue = false;
							boolean isCPFMismatchTrue = false;
							
							
							for(TCRMPersonNameBObj personNameBObj: vectorPerNameSuspects){
								if("1".equals(personNameBObj.getNameUsageType())){
									String suspectname = personNameBObj.getGivenNameOne().concat(personNameBObj.getLastName());
									if(sourceNameList.contains(suspectname)){
										isNameExact=true;
										break;
									}
								}
							}
							for(TCRMPartyContactMethodBObj contactMethod: vectorContactSuspects){
								if("1049".equals(contactMethod.getContactMethodUsageType())
										||"1050".equals(contactMethod.getContactMethodUsageType())
										||"1051".equals(contactMethod.getContactMethodUsageType())){
									String suspectPhone = contactMethod.getTCRMContactMethodBObj().getReferenceNumber();
									if(sourcePhoneList.contains(suspectPhone)){
										isPhoneExact = true;
										break;
									}else {
										
										for (String sourcePh : sourcePhoneList){
											int lengthPh =  charDiffBr( sourcePh,  suspectPhone);
											if (lengthPh == 1 || lengthPh == 2 )
											{
												isPhoneMismatchTrue = true;
											    break;
											}
										}
										
									}
								}
							}
							for(TCRMPartyContactMethodBObj contactMethod: vectorContactSuspects){
								if("1053".equals(contactMethod.getContactMethodUsageType())){
									String suspectEmail = contactMethod.getTCRMContactMethodBObj().getReferenceNumber();
									if(sourceEmailList.contains(suspectEmail)){
										isEmailExact = true;
										break;
									}
								}
							}
							String suspectCPFId = null;
							for(TCRMPartyIdentificationBObj partyIdentification : vectorIdentSuspects){
								
								if("1039".equals(partyIdentification.getIdentificationType()) &&
										partyIdentification.getIdentificationValue()!=null){
									suspectCPFId = partyIdentification.getIdentificationNumber();	
								} 

							}
							
							if(sourceCPFId != null || StringUtils.isNonBlank(sourceCPFId)){
								int lengthCPFId = charDiffBr(sourceCPFId ,suspectCPFId);
								if (lengthCPFId == 3 )
									isCPFMismatchTrue = true;
								
							}
							
							
							//Start Downgrade
							if (isNameExact && isCPFMismatchTrue && isPhoneMismatchTrue && isEmailExact){
								tempSuspectBObj.setAdjustedMatchCategoryCode(ExternalRuleConstant.SUSPECT_CATEGORY_VALUEB);
								tempSuspectBObj.setMatchCategoryAdjustmentType(ExternalRuleConstant.SUSP_REASON_CODE_NAME_CPF3_PH_1_2_EMAIL_TYPE);
								
							}
						}
						
						
                   if (suspectCatType.equalsIgnoreCase(ExternalRuleConstant.SUSPECT_CATEGORY_VALUEC)) {
							
							TCRMPersonBObj suspectPersonBObj = partyComponent.getPerson(suspectPartyId, "1", control);
							Vector<TCRMPersonNameBObj> vectorPerNameSuspects = suspectPersonBObj.getItemsTCRMPersonNameBObj();
							Vector<TCRMPartyContactMethodBObj> vectorContactSuspects = suspectPersonBObj.getItemsTCRMPartyContactMethodBObj();
							Vector<TCRMPartyIdentificationBObj> vectorIdentSuspects = suspectPersonBObj.getItemsTCRMPartyIdentificationBObj();
							boolean isNameExact = false;
							boolean isPhoneExact = false;
							boolean isEmailExact = false;
							boolean isCPFIdExact = false;
							boolean isPhoneMismatchTrue = false;
							boolean isCPFMismatchTrue = false;
							boolean isNameDifferent = false;

							
							/*for(TCRMPersonNameBObj personNameBObj: vectorPerNameSuspects){
								if("1".equals(personNameBObj.getNameUsageType())){
									String suspectname = personNameBObj.getGivenNameOne().concat(personNameBObj.getLastName());
									for (String sourceName : sourceNameList){
									int lengthName = charDiffNameBr(sourceName.toUpperCase(), suspectname.toUpperCase());
									if (lengthName > 3){
										isNameDifferent = true;
									}
										
									}
								}
							}*/
							for(TCRMPartyContactMethodBObj contactMethod: vectorContactSuspects){
								if("1049".equals(contactMethod.getContactMethodUsageType())
										||"1050".equals(contactMethod.getContactMethodUsageType())
										||"1051".equals(contactMethod.getContactMethodUsageType())){
									String suspectPhone = contactMethod.getTCRMContactMethodBObj().getReferenceNumber();
									if(sourcePhoneList.contains(suspectPhone)){
										isPhoneExact = true;
										break;
									}
								}
							}
							for(TCRMPartyContactMethodBObj contactMethod: vectorContactSuspects){
								if("1053".equals(contactMethod.getContactMethodUsageType())){
									String suspectEmail = contactMethod.getTCRMContactMethodBObj().getReferenceNumber();
									if(sourceEmailList.contains(suspectEmail)){
										isEmailExact = true;
										break;
									}
								}
							}
							String suspectCPFId = null;
							for(TCRMPartyIdentificationBObj partyIdentification : vectorIdentSuspects){
								
								if("1039".equals(partyIdentification.getIdentificationType()) &&
										partyIdentification.getIdentificationValue()!=null){
									suspectCPFId = partyIdentification.getIdentificationNumber();	
								} 

							}
							
							if(sourceCPFId != null || StringUtils.isNonBlank(sourceCPFId)){
								if (sourceCPFId.equalsIgnoreCase(suspectCPFId))
									isCPFIdExact = true;
							}
							
							
							//Start Upgrade
							if (isNameDifferent && isCPFIdExact && isPhoneExact && isEmailExact){
								tempSuspectBObj.setAdjustedMatchCategoryCode(ExternalRuleConstant.SUSPECT_CATEGORY_VALUEB);
								tempSuspectBObj.setMatchCategoryAdjustmentType(ExternalRuleConstant.SUSP_REASON_CODE_NAME_CPF3_PH_1_2_EMAIL_TYPE);
								
							}
						}
					}
				}
			}
	    }
		
		public void matchRulesAdjustForSpecialVR(TCRMPartyBObj tcrmPartyBObj, DWLControl control, String market) throws Exception {
			XPersonBObjExt tcrmPersonBObj = null;
			XOrgBObjExt tcrmOrgBObj = null;
			Vector<TCRMSuspectBObj> vecSuspectObject = new Vector<TCRMSuspectBObj>();
			DSEAAdditionsExtsComponent dseaAdditionsExtsComponent= new DSEAAdditionsExtsComponent();
			String sourcePartyId = null;
			String suspectPartyId = null;
			if (tcrmPartyBObj instanceof XPersonBObjExt) {

				tcrmPersonBObj = (XPersonBObjExt) tcrmPartyBObj;
				
				control = tcrmPersonBObj.getControl();							
				vecSuspectObject = tcrmPersonBObj.getItemsTCRMSuspectBObj();
				sourcePartyId = tcrmPersonBObj.getPartyId();
				int countCVR = 0;
				countCVR = getTotalCVRoles(sourcePartyId, market);
				
				if (vecSuspectObject != null && vecSuspectObject.size() > 0) {
					for (TCRMSuspectBObj tempSuspectBObj : vecSuspectObject) {
						
						suspectPartyId = tempSuspectBObj.getSuspectPartyId();
						countCVR += getTotalCVRoles(suspectPartyId, market);
						
					}
				}
				
				if(countCVR > 500){
					
					for (TCRMSuspectBObj tempSuspectBObj : vecSuspectObject) {
						String suspectCatType = tempSuspectBObj.getMatchCategoryCode();
						 
						TCRMPartyComponent partyComponent = new TCRMPartyComponent();
						if (suspectCatType.equalsIgnoreCase(ExternalRuleConstant.SUSPECT_CATEGORY_VALUEA1)||
								suspectCatType.equalsIgnoreCase(ExternalRuleConstant.SUSPECT_CATEGORY_VALUEB)) {
							tempSuspectBObj.setAdjustedMatchCategoryCode(ExternalRuleConstant.SUSPECT_CATEGORY_VALUEC);
							tempSuspectBObj.setMatchCategoryAdjustmentType(ExternalRuleConstant.SUSP_REASON_CODE_NAME_CVR_MORE_THAN_500);
						}
					}
					
				}
			}
			if (tcrmPartyBObj instanceof XOrgBObjExt) {

				tcrmOrgBObj = (XOrgBObjExt) tcrmPartyBObj;
				
				control = tcrmOrgBObj.getControl();							
				vecSuspectObject = tcrmOrgBObj.getItemsTCRMSuspectBObj();
				sourcePartyId = tcrmOrgBObj.getPartyId();

				int countCVR = 0;
				//String suspectContIDs = sourcePartyId+",";
				countCVR = getTotalCVRoles(sourcePartyId, market);
				
				if (vecSuspectObject != null && vecSuspectObject.size() > 0) {
					for (TCRMSuspectBObj tempSuspectBObj : vecSuspectObject) {
						suspectPartyId = tempSuspectBObj.getSuspectPartyId();
						countCVR += getTotalCVRoles(suspectPartyId, market);
					}
				}
				
				if(countCVR > 500){
					
					for (TCRMSuspectBObj tempSuspectBObj : vecSuspectObject) {
						String suspectCatType = tempSuspectBObj.getMatchCategoryCode();
						 
						TCRMPartyComponent partyComponent = new TCRMPartyComponent();
						if (suspectCatType.equalsIgnoreCase(ExternalRuleConstant.SUSPECT_CATEGORY_VALUEA1)
								||suspectCatType.equalsIgnoreCase(ExternalRuleConstant.SUSPECT_CATEGORY_VALUEB)) {
							tempSuspectBObj.setAdjustedMatchCategoryCode(ExternalRuleConstant.SUSPECT_CATEGORY_VALUEC);
							tempSuspectBObj.setMatchCategoryAdjustmentType(ExternalRuleConstant.SUSP_REASON_CODE_NAME_CVR_MORE_THAN_500);
							//suspectContIDs += tempSuspectBObj.getSuspectPartyId()+",";
						}
					}
				}
			}
		}
		public void throwExceptionifTxnFails(DWLResponse response, StringBuffer sBuffer) throws BusinessProxyException {
			DWLStatus status;
			Vector<DWLError> error;
			String serr;
			if(response!=null){
				status = response.getStatus();			
				error = status.getDwlErrorGroup();				
				if (error != null && error.size() > 0) {
					status.setStatus(response.getStatus().getStatus());		
					for (DWLError dw : error) {
						serr = dw.getErrorMessage();
						sBuffer.append("::" + serr);
						vectReqDWLError.add(dw);
					}		
					throw new BusinessProxyException(sBuffer.toString());		
				}
			}
		}
		//Japan create suspect changes end
		
		//August 7, 2018 : Added by Shandeep for handling retailer add, update : Start
		
		public void survivedCRRDetailsTUR(Vector<TCRMPartyBObj> vecParties,
				TCRMPartyBObj collapsedPartyBObj, DWLControl control)
				throws Exception {
			HashMap<String, XCustomerRetailerBObj> xCustomerRetailerMap = new HashMap<String, XCustomerRetailerBObj>();
			Vector<XCustomerRetailerBObj> vecXCustomerRetailerBObjs = new Vector<XCustomerRetailerBObj>();
			DWLResponse dwlResponse = new DWLResponse();
			DWLResponse response = null;
			//DWLResponse retailer_response = null;
			DSEAAdditionsExtsComponent dseaAdditionsExtsComponent = new DSEAAdditionsExtsComponent();
			String partytId = null;
			String retailerCode = null;
			XRetailerBObj DBRetailerBObj = null;
			String collapsedPartyId = collapsedPartyBObj.getPartyId();

			for (TCRMPartyBObj partyBObj : vecParties) {
				partytId = partyBObj.getPartyId();
				dwlResponse = dseaAdditionsExtsComponent.getAllXCustomerRetailerByPartyId(partytId, control);
				if (dwlResponse.getData() != null) {
					vecXCustomerRetailerBObjs = (Vector<XCustomerRetailerBObj>) dwlResponse
							.getData();
				}
				for (int j = 0; j < vecXCustomerRetailerBObjs.size(); j++) {
					XCustomerRetailerBObj xCustomerRetailerBObj = (XCustomerRetailerBObj) vecXCustomerRetailerBObjs
							.get(j);
					if (!xCustomerRetailerMap.containsKey(xCustomerRetailerBObj
							.getXRetailerBObj().getRetailerCode())) {
						xCustomerRetailerMap.put(xCustomerRetailerBObj
								.getXRetailerBObj().getRetailerCode(),
								xCustomerRetailerBObj);
					} else {
						XCustomerRetailerBObj xContretailerBObjInMap = xCustomerRetailerMap
								.get(xCustomerRetailerBObj.getXRetailerBObj()
										.getRetailerCode());
						Timestamp requestPersonLastModifiedDt = DateFormatter
								.getTimestamp(xContretailerBObjInMap
										.getXRetailerBObj()
										.getLastModifiedSystemDate());
						Timestamp existingPersonLastModifiedDt = DateFormatter
								.getTimestamp(xCustomerRetailerBObj
										.getXRetailerBObj()
										.getLastModifiedSystemDate());
						if (requestPersonLastModifiedDt.after(existingPersonLastModifiedDt)) {
							xCustomerRetailerMap.put(xContretailerBObjInMap
									.getXRetailerBObj().getRetailerCode(),
									xContretailerBObjInMap);
						} else {
							xCustomerRetailerMap.put(xCustomerRetailerBObj
									.getXRetailerBObj().getRetailerCode(),
									xCustomerRetailerBObj);
						}

					}

				}
			}

			for (Map.Entry<String, XCustomerRetailerBObj> entry : xCustomerRetailerMap
					.entrySet()) {
				XCustomerRetailerBObj tempXCustomerRetailerBObj = entry.getValue();
				XCustomerRetailerBObj survivedXCustomerRetailerBObj = new XCustomerRetailerBObj();
				survivedXCustomerRetailerBObj = tempXCustomerRetailerBObj;
				survivedXCustomerRetailerBObj.setContId(collapsedPartyId);
				survivedXCustomerRetailerBObj.setControl(control);
				retailerCode = survivedXCustomerRetailerBObj.getXRetailerBObj()
						.getRetailerCode();
				DWLResponse retailer_response = dseaAdditionsExtsComponent.getXRetailerByRetailerCodeAndMarketName(retailerCode, "TUR", control);
				DBRetailerBObj = (XRetailerBObj) retailer_response.getData();
				survivedXCustomerRetailerBObj.setXRetailerBObj(null);
				survivedXCustomerRetailerBObj.setRetailerId(DBRetailerBObj.getRetailerpkId());
				survivedXCustomerRetailerBObj.setObjectReferenceId(ExternalRuleConstant.MARKET_NAME_TURKEY);
					response = dseaAdditionsExtsComponent
							.addXCustomerRetailer(survivedXCustomerRetailerBObj);
					if (response.getStatus().getStatus() == DWLStatus.FATAL) {
						throw new BusinessProxyException();
					}

				}
		}

	//September 13, 2018 : Added by Arup for handling retailer add, update : Start
	/**
	 * 
	 * @param vecParties
	 * @param collapsedPartyBObj
	 * @param control
	 * @throws Exception
	 */
	public void survivedCRRDetailsAus(Vector<TCRMPartyBObj> vecParties,	TCRMPartyBObj collapsedPartyBObj, String marketName, DWLControl control) throws Exception {

		HashMap<String, XCustomerRetailerBObj> xCustomerRetailerMap = new HashMap<String, XCustomerRetailerBObj>();
		Vector<XCustomerRetailerBObj> vecXCustomerRetailerBObjs = new Vector<XCustomerRetailerBObj>();
		DWLResponse dwlResponse = new DWLResponse();
		DWLResponse response = null;
		//DWLResponse retailer_response = null;
		DSEAAdditionsExtsComponent dseaAdditionsExtsComponent = new DSEAAdditionsExtsComponent();
		String partytId = null;
		String ndCode = null;
		XRetailerBObj DBRetailerBObj = null;
		String collapsedPartyId = collapsedPartyBObj.getPartyId();

		for (TCRMPartyBObj partyBObj : vecParties) {

			partytId = partyBObj.getPartyId();

			dwlResponse = dseaAdditionsExtsComponent.getAllXCustomerRetailerByPartyId(partytId, control);

			if (null != dwlResponse.getData()) 
			{

				vecXCustomerRetailerBObjs = (Vector<XCustomerRetailerBObj>) dwlResponse.getData();

				if (null != vecXCustomerRetailerBObjs && !vecXCustomerRetailerBObjs.isEmpty() && vecXCustomerRetailerBObjs.size() > 0){
					for (int j = 0; j < vecXCustomerRetailerBObjs.size(); j++) {

						XCustomerRetailerBObj xCustomerRetailerBObj = (XCustomerRetailerBObj) vecXCustomerRetailerBObjs.get(j);
						if(null != xCustomerRetailerBObj)
						{
							if (!xCustomerRetailerMap.containsKey(xCustomerRetailerBObj.getXRetailerBObj().getNDCode())) {

								xCustomerRetailerMap.put(xCustomerRetailerBObj.getXRetailerBObj().getNDCode(),xCustomerRetailerBObj);

							} 
							else {

								XCustomerRetailerBObj xContRetailerBObjInMap = xCustomerRetailerMap.get(xCustomerRetailerBObj.getXRetailerBObj().getNDCode());
								Timestamp requestPersonLastModifiedDt = DateFormatter.getTimestamp(xContRetailerBObjInMap.getXCustomerRetailerLastUpdateDate());
								Timestamp existingPersonLastModifiedDt = DateFormatter.getTimestamp(xCustomerRetailerBObj.getXCustomerRetailerLastUpdateDate());

								if (requestPersonLastModifiedDt.after(existingPersonLastModifiedDt)) {

									xCustomerRetailerMap.put(xContRetailerBObjInMap.getXRetailerBObj().getNDCode(),xContRetailerBObjInMap);

								} else {

									xCustomerRetailerMap.put(xCustomerRetailerBObj.getXRetailerBObj().getNDCode(),xCustomerRetailerBObj);
								}

							}
						}
					}

				}
			}
		}
		
			for (Map.Entry<String, XCustomerRetailerBObj> entry : xCustomerRetailerMap.entrySet()) {

				XCustomerRetailerBObj tempXCustomerRetailerBObj = entry.getValue();
				XCustomerRetailerBObj survivedXCustomerRetailerBObj = new XCustomerRetailerBObj();
				survivedXCustomerRetailerBObj = tempXCustomerRetailerBObj;
				survivedXCustomerRetailerBObj.setContId(collapsedPartyId);
				survivedXCustomerRetailerBObj.setControl(control);
				ndCode = survivedXCustomerRetailerBObj.getXRetailerBObj().getNDCode();
				DWLResponse retailer_response = dseaAdditionsExtsComponent.getXRetailerByNDCodeAndMarketName(ndCode, marketName, control);
				DBRetailerBObj = (XRetailerBObj) retailer_response.getData();
				survivedXCustomerRetailerBObj.setXRetailerBObj(null);
				survivedXCustomerRetailerBObj.setRetailerId(DBRetailerBObj.getRetailerpkId());
				survivedXCustomerRetailerBObj.setObjectReferenceId(marketName);
				response = dseaAdditionsExtsComponent.addXCustomerRetailer(survivedXCustomerRetailerBObj);

				if (response.getStatus().getStatus() == DWLStatus.FATAL) {
					throw new BusinessProxyException();
				}
			
		}

	}

	//September 13, 2018 : Added by Arup for handling retailer add, update : End


		
		
		public void survivedCRRDetailsForJapan(Vector<TCRMPartyBObj> vecParties,
				TCRMPartyBObj collapsedPartyBObj, DWLControl control)
				throws Exception {
			HashMap<String, XCustomerRetailerJPNBObj> xCustomerRetailerMap = new HashMap<String, XCustomerRetailerJPNBObj>();
			Vector<XCustomerRetailerJPNBObj> vecXCustomerRetailerJPNBObjs = new Vector<XCustomerRetailerJPNBObj>();
			DWLResponse dwlResponse = new DWLResponse();
			DWLResponse response = null;
			DSEAAdditionsExtsComponent dseaAdditionsExtsComponent = new DSEAAdditionsExtsComponent();
			String partytId = null;
			String ndCode = null;
			Vector<XRetailerBObj> vecDBRetailBObj = null;
			String collapsedPartyId = collapsedPartyBObj.getPartyId();

			for (TCRMPartyBObj partyBObj : vecParties) {
				partytId = partyBObj.getPartyId();
				dwlResponse = dseaAdditionsExtsComponent
						.getAllXCustomerRetailerJPNByPartyId(partytId, control);
				if (dwlResponse.getData() != null) {
					vecXCustomerRetailerJPNBObjs = (Vector<XCustomerRetailerJPNBObj>) dwlResponse
							.getData();
				}
				for (int j = 0; j < vecXCustomerRetailerJPNBObjs.size(); j++) {
					XCustomerRetailerJPNBObj xCustomerRetailerBObj = (XCustomerRetailerJPNBObj) vecXCustomerRetailerJPNBObjs
							.get(j);
					if (!xCustomerRetailerMap.containsKey(xCustomerRetailerBObj
							.getXRetailerBObj().getNDCode())) {
						xCustomerRetailerMap.put(xCustomerRetailerBObj
								.getXRetailerBObj().getNDCode(),
								xCustomerRetailerBObj);
					} else {
						XCustomerRetailerJPNBObj xContretailerBObjInMap = xCustomerRetailerMap
								.get(xCustomerRetailerBObj.getXRetailerBObj()
										.getNDCode());
						Timestamp requestPersonLastModifiedDt = DateFormatter
								.getTimestamp(xContretailerBObjInMap
										.getXRetailerBObj()
										.getLastModifiedSystemDate());
						Timestamp existingPersonLastModifiedDt = DateFormatter
								.getTimestamp(xCustomerRetailerBObj
										.getXRetailerBObj()
										.getLastModifiedSystemDate());
						if (requestPersonLastModifiedDt.after(existingPersonLastModifiedDt)) {
							xCustomerRetailerMap.put(xContretailerBObjInMap
									.getXRetailerBObj().getNDCode(),
									xContretailerBObjInMap);
						} else {
							xCustomerRetailerMap.put(xCustomerRetailerBObj
									.getXRetailerBObj().getNDCode(),
									xCustomerRetailerBObj);
						}

					}

				}
			}

			for (Map.Entry<String, XCustomerRetailerJPNBObj> entry : xCustomerRetailerMap
					.entrySet()) {
				XCustomerRetailerJPNBObj tempXCustomerRetailerBObj = entry.getValue();
				XCustomerRetailerJPNBObj survivedXCustomerRetailerBObj = new XCustomerRetailerJPNBObj();
				survivedXCustomerRetailerBObj = tempXCustomerRetailerBObj;
				survivedXCustomerRetailerBObj.setContId(collapsedPartyId);
				survivedXCustomerRetailerBObj.setControl(control);
				ndCode = survivedXCustomerRetailerBObj.getXRetailerBObj()
						.getNDCode();
				vecDBRetailBObj = retailerObjectByNDCode(ndCode,
						control);
				if (vecDBRetailBObj == null || vecDBRetailBObj.isEmpty()) {
					response = dseaAdditionsExtsComponent
							.addXCustomerRetailerJPN(survivedXCustomerRetailerBObj);
				} else {
					survivedXCustomerRetailerBObj.getXRetailerBObj()
							.setRetailerpkId(
									vecDBRetailBObj.get(0).getRetailerpkId());
					survivedXCustomerRetailerBObj.getXRetailerBObj()
							.setXRetailerLastUpdateDate(
									vecDBRetailBObj.get(0)
											.getXRetailerLastUpdateDate());
					survivedXCustomerRetailerBObj.setRetailerId(vecDBRetailBObj
							.get(0).getRetailerpkId());
					response = dseaAdditionsExtsComponent
							.addXCustomerRetailerJPN(survivedXCustomerRetailerBObj);
				}
				if (response.getStatus().getStatus() == DWLStatus.FATAL) {
					throw new BusinessProxyException();
				}
			}
		}
		
		public void survivedCVRDetailsForKorea(Vector<TCRMPartyBObj> vecParties,TCRMPartyBObj collapsedPartyBObj, DWLControl control) throws Exception {
			
			HashMap<String, XCustomerVehicleKORBObj> xCustomerVehicleKORMap = new HashMap<String, XCustomerVehicleKORBObj>();
			Vector<XCustomerVehicleKORBObj> vecXCustomerVehicleKORBObjs = new Vector<XCustomerVehicleKORBObj>();
			DWLResponse dwlResponse = new DWLResponse();
			DWLResponse response = null;
			DSEAAdditionsExtsComponent dseaAdditionsExtsComponent = new DSEAAdditionsExtsComponent();
			String partytId = null;
			String globalVIN = null;
			String requestPersonRetailerCode = null;
			String existingPersonRetailerCode = null;
			Vector<XVehicleKORBObj> vecDBVehicleKORBObj = null;
			String collapsedPartyId = collapsedPartyBObj.getPartyId();
			Vector<XCustomerVehicleRoleKORBObj> vecParty1XCustomerVehicleKORRoleBObjs = new Vector<XCustomerVehicleRoleKORBObj>();
			Vector<XCustomerVehicleRoleKORBObj> vecParty2XCustomerVehicleKORRoleBObjs = new Vector<XCustomerVehicleRoleKORBObj>();
			Vector<XCustomerVehicleRoleKORBObj> vecSurvivedVehicleKORRoleBObjs = new Vector<XCustomerVehicleRoleKORBObj>();
			Vector<XCustomerVehicleRoleKORBObj> vecFinalVehicleKORRoleBObjs = new Vector<XCustomerVehicleRoleKORBObj>();

			try{
				for (TCRMPartyBObj partyBObj : vecParties) {
					partytId = partyBObj.getPartyId();
					vecXCustomerVehicleKORBObjs = getAllXCustomerVehicleKORByPartyId(partytId, control);
					if (vecXCustomerVehicleKORBObjs != null
							&& vecXCustomerVehicleKORBObjs.size() > 0) {
						for (int j = 0; j < vecXCustomerVehicleKORBObjs.size(); j++) {
							XCustomerVehicleKORBObj XCustomerVehicleKORBObj = (XCustomerVehicleKORBObj) vecXCustomerVehicleKORBObjs.get(j);
							
							if (!xCustomerVehicleKORMap.containsKey(
									(XCustomerVehicleKORBObj.getXVehicleKORBObj().getGlobalVIN()) + (XCustomerVehicleKORBObj.getRetailerId()))) {
								xCustomerVehicleKORMap.put(
										(XCustomerVehicleKORBObj.getXVehicleKORBObj().getGlobalVIN()) + (XCustomerVehicleKORBObj.getRetailerId()),XCustomerVehicleKORBObj);
							} else {
								XCustomerVehicleKORBObj xContVehicleKORBObjInMap = xCustomerVehicleKORMap.get(
										(XCustomerVehicleKORBObj.getXVehicleKORBObj().getGlobalVIN()) + (XCustomerVehicleKORBObj.getRetailerId()));
								requestPersonRetailerCode = xContVehicleKORBObjInMap.getRetailerId();
								existingPersonRetailerCode = XCustomerVehicleKORBObj.getRetailerId();
	
								if (requestPersonRetailerCode != null
										&& existingPersonRetailerCode != null
										&& requestPersonRetailerCode.equalsIgnoreCase(existingPersonRetailerCode)) {
									Timestamp requestPersonLastModifiedDt = DateFormatter.getTimestamp(xContVehicleKORBObjInMap.getXCustomerVehicleKORLastUpdateDate());
									Timestamp existingPersonLastModifiedDt = DateFormatter.getTimestamp(XCustomerVehicleKORBObj.getXCustomerVehicleKORLastUpdateDate());
									if (requestPersonLastModifiedDt.after(existingPersonLastModifiedDt)) {
										vecParty1XCustomerVehicleKORRoleBObjs = xContVehicleKORBObjInMap.getItemsXCustomerVehicleRoleKORBObj();
	
										if (vecParty1XCustomerVehicleKORRoleBObjs != null && vecParty1XCustomerVehicleKORRoleBObjs.size() > 0) {
											for (XCustomerVehicleRoleKORBObj xCustomerVehicleKORRoleBObj : vecParty1XCustomerVehicleKORRoleBObjs) {
												if (xCustomerVehicleKORRoleBObj.getEndDate() == null) {
													vecFinalVehicleKORRoleBObjs.add(xCustomerVehicleKORRoleBObj);
												}
											}
										}
	
										xContVehicleKORBObjInMap.getItemsXCustomerVehicleRoleKORBObj().clear();
										xContVehicleKORBObjInMap.getItemsXCustomerVehicleRoleKORBObj().addAll(vecFinalVehicleKORRoleBObjs);
	
									} else {
										vecParty2XCustomerVehicleKORRoleBObjs = XCustomerVehicleKORBObj.getItemsXCustomerVehicleRoleKORBObj();
	
										if (vecParty2XCustomerVehicleKORRoleBObjs != null && vecParty2XCustomerVehicleKORRoleBObjs.size() > 0) {
	
											for (XCustomerVehicleRoleKORBObj xCustomerVehicleKORRoleBObj : vecParty2XCustomerVehicleKORRoleBObjs) {
												if (xCustomerVehicleKORRoleBObj.getEndDate() == null) {
													vecFinalVehicleKORRoleBObjs.add(xCustomerVehicleKORRoleBObj);
												}
											}
										}
	
										XCustomerVehicleKORBObj.getItemsXCustomerVehicleRoleKORBObj().clear();
										XCustomerVehicleKORBObj.getItemsXCustomerVehicleRoleKORBObj().addAll(vecFinalVehicleKORRoleBObjs);
	
									}
	
									Timestamp person1ModifiedDt = DateFormatter.getTimestamp(xContVehicleKORBObjInMap.getXCustomerVehicleKORLastUpdateDate());
	
									Timestamp person2ModifiedDt = DateFormatter.getTimestamp(XCustomerVehicleKORBObj.getXCustomerVehicleKORLastUpdateDate());
									
									// Take timestamp for Start Dt and End Dt
									Timestamp person1StartDt = DateFormatter.getTimestamp(xContVehicleKORBObjInMap.getStartDate());
									Timestamp person2StartDt = DateFormatter.getTimestamp(XCustomerVehicleKORBObj.getStartDate());
									
									Timestamp person1EndDt = DateFormatter.getTimestamp(xContVehicleKORBObjInMap.getEndDate());
									Timestamp person2EndDt = DateFormatter.getTimestamp(XCustomerVehicleKORBObj.getEndDate());
	
									if (person1ModifiedDt.after(person2ModifiedDt)) {
										//Set StartDt oldest and EndDt latest or null
										if (null == person1EndDt || null == person2EndDt ){
											xContVehicleKORBObjInMap.setEndDate(null);
										} else if ((null != person1EndDt && null != person2EndDt) && (person1EndDt.before(person2EndDt))){
											xContVehicleKORBObjInMap.setEndDate(XCustomerVehicleKORBObj.getEndDate());
										}
										if ((null != person2StartDt && null != person1StartDt)&&(person1StartDt.after(person2StartDt)) && (!person1StartDt.equals(person2StartDt))){
											xContVehicleKORBObjInMap.setStartDate(XCustomerVehicleKORBObj.getStartDate());
										}
	
										xCustomerVehicleKORMap.put((xContVehicleKORBObjInMap.getXVehicleKORBObj().getGlobalVIN()) + (xContVehicleKORBObjInMap.getRetailerId()),xContVehicleKORBObjInMap);
									}
	
									else {
										//Set StartDt oldest and EndDt latest or null
										if(null == person1EndDt || null == person2EndDt ){
											XCustomerVehicleKORBObj.setEndDate(null);
										}else if ((null != person2EndDt && null != person1EndDt) && (person2EndDt.before(person1EndDt))){
											XCustomerVehicleKORBObj.setEndDate(xContVehicleKORBObjInMap.getEndDate());
										}
										if ((null != person2StartDt && null != person1StartDt) && (person2StartDt.after(person1StartDt))){
											XCustomerVehicleKORBObj.setStartDate(xContVehicleKORBObjInMap.getStartDate());
										}
	
										xCustomerVehicleKORMap.put((XCustomerVehicleKORBObj.getXVehicleKORBObj().getGlobalVIN()) + (XCustomerVehicleKORBObj.getRetailerId()),XCustomerVehicleKORBObj);
									}
	
								} else {
	
									xCustomerVehicleKORMap.put((XCustomerVehicleKORBObj.getXVehicleKORBObj().getGlobalVIN()) + (XCustomerVehicleKORBObj.getRetailerId()),XCustomerVehicleKORBObj);
								}
	
							}
	
						}
					}
				}
	
			for (Map.Entry<String, XCustomerVehicleKORBObj> entry : xCustomerVehicleKORMap.entrySet()) {
				XCustomerVehicleKORBObj tempXCustomerVehicleKORBObj = entry.getValue();
				XCustomerVehicleKORBObj survivedXCustomerVehicleKORBObj = new XCustomerVehicleKORBObj();
				survivedXCustomerVehicleKORBObj = tempXCustomerVehicleKORBObj;
				survivedXCustomerVehicleKORBObj.setContId(collapsedPartyId);
				survivedXCustomerVehicleKORBObj.setControl(control);
				globalVIN = survivedXCustomerVehicleKORBObj.getXVehicleKORBObj().getGlobalVIN();
				vecDBVehicleKORBObj = vehicleObjectByGVIN_KOR(globalVIN, control);
				if (vecDBVehicleKORBObj == null || vecDBVehicleKORBObj.isEmpty()) {
					response = dseaAdditionsExtsComponent.addXCustomerVehicleKOR(survivedXCustomerVehicleKORBObj);
				} else {
					survivedXCustomerVehicleKORBObj.getXVehicleKORBObj().setXVehicleKORpkId(vecDBVehicleKORBObj.get(0).getXVehicleKORpkId());
					survivedXCustomerVehicleKORBObj.getXVehicleKORBObj().setXVehicleKORLastUpdateDate(vecDBVehicleKORBObj.get(0).getXVehicleKORLastUpdateDate());
					survivedXCustomerVehicleKORBObj.setVehicleId(vecDBVehicleKORBObj.get(0).getXVehicleKORpkId());
					response = dseaAdditionsExtsComponent.addXCustomerVehicleKOR(survivedXCustomerVehicleKORBObj);
				}
				if (response.getStatus().getStatus() == DWLStatus.FATAL) {
					throw new BusinessProxyException();
				}
			}		
		}catch(Exception e){
			e.printStackTrace();
		}
	}
		public void survivedCVRDetailsForJapan(Vector<TCRMPartyBObj> vecParties,
				TCRMPartyBObj collapsedPartyBObj, DWLControl control)
				throws Exception {
			HashMap<String, XCustomerVehicleJPNBObj> xCustomerVehicleMap = new HashMap<String, XCustomerVehicleJPNBObj>();			
			Vector<XCustomerVehicleJPNBObj> vecXCustomerVehicleBObjs = new Vector<XCustomerVehicleJPNBObj>();			
			DWLResponse dwlResponse = new DWLResponse();
			DWLResponse response = null;
			DSEAAdditionsExtsComponent dseaAdditionsExtsComponent = new DSEAAdditionsExtsComponent();
			String partytId = null;
			String globalVIN = null;
			String requestPersonRetailerCode = null;
			String existingPersonRetailerCode = null;
			//Vector<XVehicleBObj> vecDBVehicleBObj = null;
			String collapsedPartyId = collapsedPartyBObj.getPartyId();
			Vector<XCustomerVehicleRoleJPNBObj> vecParty1XCustomerVehicleRoleBObjs = new Vector<XCustomerVehicleRoleJPNBObj>();
			Vector<XCustomerVehicleRoleJPNBObj> vecParty2XCustomerVehicleRoleBObjs = new Vector<XCustomerVehicleRoleJPNBObj>();
			Vector<XCustomerVehicleRoleJPNBObj> vecSurvivedVehicleRoleBObjs = new Vector<XCustomerVehicleRoleJPNBObj>();
			Vector <XCustomerVehicleJPNBObj> VecUnmergedXCustomerVehicleJPNBObj = new Vector<XCustomerVehicleJPNBObj>();
			HashMap<String, Vector<XCustomerVehicleJPNBObj>> finalCustomerVehicleMap = new HashMap<String, Vector<XCustomerVehicleJPNBObj>>();
			
			boolean toBeMerged = false;

			for (TCRMPartyBObj partyBObj : vecParties) {
				partytId = partyBObj.getPartyId();
				//vecXCustomerVehicleBObjs = getAllXCustomerVehicleByPartyId(partytId, control);
				DWLResponse response1 = dseaAdditionsExtsComponent.getAllXCustomerVehicleJPNByPartyId(partytId, control);
				vecXCustomerVehicleBObjs = (Vector<XCustomerVehicleJPNBObj>)response1.getData();
				
				Vector<XCustomerVehicleJPNBObj> vecXCustomerVehicleRetailBObjs = new Vector<XCustomerVehicleJPNBObj>();
				Vector<XCustomerVehicleJPNBObj> vecXCustomerVehicleWholesaleBObjs = new Vector<XCustomerVehicleJPNBObj>();
				
				
				
				if (vecXCustomerVehicleBObjs != null
						&& vecXCustomerVehicleBObjs.size() > 0) {
					
					for(XCustomerVehicleJPNBObj tempCustomerVehicleJPNBObj:vecXCustomerVehicleBObjs)
					{
						if(tempCustomerVehicleJPNBObj.getRetailerId()!=null)
						{
							vecXCustomerVehicleRetailBObjs.add(tempCustomerVehicleJPNBObj);
						}
						else
						{
							vecXCustomerVehicleWholesaleBObjs.add(tempCustomerVehicleJPNBObj);
						}
					}
					
					/*for (int j = 0; j < vecXCustomerVehicleBObjs.size(); j++) 
					{
						XCustomerVehicleJPNBObj xCustomerVehicleBObj = (XCustomerVehicleJPNBObj) vecXCustomerVehicleBObjs
								.get(j);
						if(xCustomerVehicleBObj.getRetailerId()!=null )//&& checkIfCVRActive(xCustomerVehicleBObj.getEndDate()) )
						{*/
						if(vecXCustomerVehicleRetailBObjs.size()>0)
						{
							if(vecXCustomerVehicleRetailBObjs.size()==1)
							{
								XCustomerVehicleJPNBObj xCustomerVehicleBObj = (XCustomerVehicleJPNBObj) vecXCustomerVehicleRetailBObjs.get(0);
								if (!xCustomerVehicleMap.containsKey((xCustomerVehicleBObj
										.getXVehicleJPNBObj().getGlobalVIN()) + xCustomerVehicleBObj
										.getXVehicleJPNBObj().getVehicleType()+ (xCustomerVehicleBObj.getRetailerId()))) 
								{
									xCustomerVehicleMap.put((xCustomerVehicleBObj
											.getXVehicleJPNBObj().getGlobalVIN()) +  xCustomerVehicleBObj
											.getXVehicleJPNBObj().getVehicleType() + (xCustomerVehicleBObj.getRetailerId()),
											xCustomerVehicleBObj);
								} 
								
								else 
								{
									XCustomerVehicleJPNBObj xContVehicleBObjInMap = xCustomerVehicleMap.get((xCustomerVehicleBObj
													.getXVehicleJPNBObj().getGlobalVIN()) +  xCustomerVehicleBObj
													.getXVehicleJPNBObj().getVehicleType() + (xCustomerVehicleBObj.getRetailerId()));
									requestPersonRetailerCode = xContVehicleBObjInMap
											.getRetailerId();
									existingPersonRetailerCode = xCustomerVehicleBObj
											.getRetailerId();
									
									if (requestPersonRetailerCode != null
											&& existingPersonRetailerCode != null
											&& requestPersonRetailerCode
													.equalsIgnoreCase(existingPersonRetailerCode)) 
									{			
										//sort VR based on start date
										Vector <XCustomerVehicleJPNBObj> tempVecXCustomerVehicleJPNBObj = new Vector<XCustomerVehicleJPNBObj>();
										tempVecXCustomerVehicleJPNBObj.add(xContVehicleBObjInMap);
										tempVecXCustomerVehicleJPNBObj.add(xCustomerVehicleBObj);
										
										if(xContVehicleBObjInMap.getStartDate()!=null && xCustomerVehicleBObj.getStartDate()!=null)
										{
											Collections.sort(tempVecXCustomerVehicleJPNBObj,
													new Comparator<XCustomerVehicleJPNBObj>() {// Ascending sort
																						// - for delta
																						// load
														public int compare(XCustomerVehicleJPNBObj xCustomerVehicleJPN1,
																XCustomerVehicleJPNBObj xCustomerVehicleJPN2) {
															
															return xCustomerVehicleJPN1
																	.getStartDate()
																	.compareTo(
																			xCustomerVehicleJPN2.getStartDate());
														}
													});
										}
																	
										SimpleDateFormat simpleDateFmt = new SimpleDateFormat("yyyy-MM-dd");
										java.util.Date xCustomerVehicleJPN1EndDt =null;
										java.util.Date xCustomerVehicleJPN2StartDt =null;
										//java.util.Date xCustomerVehicleJPN2EndDt =null;
										
										toBeMerged = false;
										
										if(tempVecXCustomerVehicleJPNBObj.get(0).getEndDate()!=null && 
												tempVecXCustomerVehicleJPNBObj.get(1).getStartDate()!=null)
										{
										xCustomerVehicleJPN1EndDt =simpleDateFmt.parse(tempVecXCustomerVehicleJPNBObj.get(0).getEndDate());
										xCustomerVehicleJPN2StartDt =simpleDateFmt.parse(tempVecXCustomerVehicleJPNBObj.get(1).getStartDate());
										
										long difference = xCustomerVehicleJPN2StartDt.getTime() - xCustomerVehicleJPN1EndDt.getTime();
										float daysBetween = (difference / (1000*60*60*24));
										if(daysBetween<=1)
										{
											toBeMerged = true;
										}
										}
										else if(tempVecXCustomerVehicleJPNBObj.get(0).getEndDate()==null)
										{
											toBeMerged = true;
										}
										if(toBeMerged)
										{
										vecParty1XCustomerVehicleRoleBObjs = xContVehicleBObjInMap.getItemsXCustomerVehicleRoleJPNBObj();
										vecParty2XCustomerVehicleRoleBObjs = xCustomerVehicleBObj.getItemsXCustomerVehicleRoleJPNBObj();
										Vector<XCustomerVehicleRoleJPNBObj> vecFinalVehicleRoleBObjs = new Vector<XCustomerVehicleRoleJPNBObj>();
										HashMap<String, XCustomerVehicleRoleJPNBObj> xCustomerVehicleRoleMap = new HashMap<String, XCustomerVehicleRoleJPNBObj>();
										for(XCustomerVehicleRoleJPNBObj Party1XCustomerVehicleRoleBObj :vecParty1XCustomerVehicleRoleBObjs)
										{
											if(!xCustomerVehicleRoleMap.containsKey(Party1XCustomerVehicleRoleBObj.getVehicleRoleType()))
											{
												xCustomerVehicleRoleMap.put(Party1XCustomerVehicleRoleBObj.getVehicleRoleType(), Party1XCustomerVehicleRoleBObj);
											}
										}
										
										for(XCustomerVehicleRoleJPNBObj Party2XCustomerVehicleRoleBObj :vecParty2XCustomerVehicleRoleBObjs)
										{
											if(!xCustomerVehicleRoleMap.containsKey(Party2XCustomerVehicleRoleBObj.getVehicleRoleType()))
											{
												xCustomerVehicleRoleMap.put(Party2XCustomerVehicleRoleBObj.getVehicleRoleType(), Party2XCustomerVehicleRoleBObj);
											}
											else
											{
												XCustomerVehicleRoleJPNBObj Party1XCustomerVehicleRoleBObj = xCustomerVehicleRoleMap.get(Party2XCustomerVehicleRoleBObj.getVehicleRoleType());
												
												/*
												Timestamp Person1RoleLastModifiedDt = DateFormatter.getTimestamp(Party1XCustomerVehicleRoleBObj.getXCustomerVehicleRoleJPNLastUpdateDate());
												Timestamp Person2RoleLastModifiedDt = DateFormatter.getTimestamp(Party2XCustomerVehicleRoleBObj.getXCustomerVehicleRoleJPNLastUpdateDate());
												if(Person2RoleLastModifiedDt.after(Person1RoleLastModifiedDt))
												{
													xCustomerVehicleRoleMap.put(Party2XCustomerVehicleRoleBObj.getVehicleRoleType(), Party2XCustomerVehicleRoleBObj);
												}
												*/
												Vector <XCustomerVehicleRoleJPNBObj> tempVecXCustomerVehicleRoleJPNBObj = new Vector<XCustomerVehicleRoleJPNBObj>();
												tempVecXCustomerVehicleRoleJPNBObj.add(Party1XCustomerVehicleRoleBObj);
												tempVecXCustomerVehicleRoleJPNBObj.add(Party2XCustomerVehicleRoleBObj);
												
												if(Party1XCustomerVehicleRoleBObj.getStartDate()!=null && Party2XCustomerVehicleRoleBObj.getStartDate()!=null)
												{
													Collections.sort(tempVecXCustomerVehicleRoleJPNBObj,
															new Comparator<XCustomerVehicleRoleJPNBObj>() {// Ascending sort
																								// - for delta
																								// load
																public int compare(XCustomerVehicleRoleJPNBObj xCustomerVehicleRoleJPN1,
																		XCustomerVehicleRoleJPNBObj xCustomerVehicleRoleJPN2) {
																	
																	return xCustomerVehicleRoleJPN1
																			.getStartDate()
																			.compareTo(
																					xCustomerVehicleRoleJPN2.getStartDate());
																}
															});
													
													Timestamp Person1RoleLastModifiedDt = DateFormatter.getTimestamp(Party1XCustomerVehicleRoleBObj.getXCustomerVehicleRoleJPNLastUpdateDate());
													Timestamp Person2RoleLastModifiedDt = DateFormatter.getTimestamp(Party2XCustomerVehicleRoleBObj.getXCustomerVehicleRoleJPNLastUpdateDate());
													if(Person2RoleLastModifiedDt.after(Person1RoleLastModifiedDt))
													{
														Party2XCustomerVehicleRoleBObj.setStartDate(tempVecXCustomerVehicleRoleJPNBObj.get(0).getStartDate());
														if(tempVecXCustomerVehicleRoleJPNBObj.get(0).getEndDate()!=null && 
																tempVecXCustomerVehicleRoleJPNBObj.get(1).getEndDate()!=null)
														{
															Timestamp role1EndDt = DateFormatter.getTimestamp(tempVecXCustomerVehicleRoleJPNBObj.get(0).getEndDate());
															Timestamp role2EndDt = DateFormatter.getTimestamp(tempVecXCustomerVehicleRoleJPNBObj.get(1).getEndDate());
															
															if(role2EndDt.after(role1EndDt))
															{
																Party2XCustomerVehicleRoleBObj.setEndDate(tempVecXCustomerVehicleRoleJPNBObj.get(1).getEndDate());
															}
															else
															{
																Party2XCustomerVehicleRoleBObj.setEndDate(tempVecXCustomerVehicleRoleJPNBObj.get(0).getEndDate());
															}
														}
														else
														{
															Party2XCustomerVehicleRoleBObj.setEndDate(null);
														}
														xCustomerVehicleRoleMap.put(Party2XCustomerVehicleRoleBObj.getVehicleRoleType(), Party2XCustomerVehicleRoleBObj);
													}
													else
													{
														Party1XCustomerVehicleRoleBObj.setStartDate(tempVecXCustomerVehicleRoleJPNBObj.get(0).getStartDate());
														if(tempVecXCustomerVehicleRoleJPNBObj.get(0).getEndDate()!=null && 
																tempVecXCustomerVehicleRoleJPNBObj.get(1).getEndDate()!=null)
														{
															Timestamp role1EndDt = DateFormatter.getTimestamp(tempVecXCustomerVehicleRoleJPNBObj.get(0).getEndDate());
															Timestamp role2EndDt = DateFormatter.getTimestamp(tempVecXCustomerVehicleRoleJPNBObj.get(1).getEndDate());
															
															if(role2EndDt.after(role1EndDt))
															{
																Party1XCustomerVehicleRoleBObj.setEndDate(tempVecXCustomerVehicleRoleJPNBObj.get(1).getEndDate());
															}
															else
															{
																Party1XCustomerVehicleRoleBObj.setEndDate(tempVecXCustomerVehicleRoleJPNBObj.get(0).getEndDate());
															}
														}
														else
														{
															Party1XCustomerVehicleRoleBObj.setEndDate(null);
														}
														xCustomerVehicleRoleMap.put(Party1XCustomerVehicleRoleBObj.getVehicleRoleType(), Party1XCustomerVehicleRoleBObj);
													}
													
												}
												
											}
											
										}
										
										for (Map.Entry<String, XCustomerVehicleRoleJPNBObj> entry : xCustomerVehicleRoleMap.entrySet()) 
										{
											vecFinalVehicleRoleBObjs.add(entry.getValue());
										}
										

										Timestamp person1ModifiedDt = DateFormatter
												.getTimestamp(xContVehicleBObjInMap
														.getXCustomerVehicleJPNLastUpdateDate());

										Timestamp person2ModifiedDt = DateFormatter
												.getTimestamp(xCustomerVehicleBObj
														.getXCustomerVehicleJPNLastUpdateDate());
										
										if (person1ModifiedDt.after(person2ModifiedDt)) {
											xContVehicleBObjInMap.getItemsXCustomerVehicleRoleJPNBObj().clear();
											xContVehicleBObjInMap.getItemsXCustomerVehicleRoleJPNBObj().addAll(vecFinalVehicleRoleBObjs);
											xContVehicleBObjInMap.setStartDate(tempVecXCustomerVehicleJPNBObj.get(0).getStartDate());
											
											if(xContVehicleBObjInMap.getVehicleSalesType()!=null && xCustomerVehicleBObj.getVehicleSalesType()!=null)
											{
												if(!xContVehicleBObjInMap.getVehicleSalesType().equalsIgnoreCase(ExternalRuleConstant.VEHICLE_SALES_TYPE_UNKNOWN)
														&& !xCustomerVehicleBObj.getVehicleSalesType().equalsIgnoreCase(ExternalRuleConstant.VEHICLE_SALES_TYPE_UNKNOWN))
												{
													xContVehicleBObjInMap.setVehicleSalesType(tempVecXCustomerVehicleJPNBObj.get(0).getVehicleSalesType());
												}
												else if(xContVehicleBObjInMap.getVehicleSalesType().equalsIgnoreCase(ExternalRuleConstant.VEHICLE_SALES_TYPE_UNKNOWN)
														&& !xCustomerVehicleBObj.getVehicleSalesType().equalsIgnoreCase(ExternalRuleConstant.VEHICLE_SALES_TYPE_UNKNOWN))
												{
													xContVehicleBObjInMap.setVehicleSalesType(xCustomerVehicleBObj.getVehicleSalesType());
												}
											}
											else if(xContVehicleBObjInMap.getVehicleSalesType()==null && xCustomerVehicleBObj.getVehicleSalesType()!=null)
											{
												xContVehicleBObjInMap.setVehicleSalesType(xCustomerVehicleBObj.getVehicleSalesType());
											}
											
											if(tempVecXCustomerVehicleJPNBObj.get(0).getEndDate()!=null && tempVecXCustomerVehicleJPNBObj.get(1).getEndDate()!=null)
											{
											java.util.Date xCustomerVehicleJPN2EndDt = simpleDateFmt.parse(tempVecXCustomerVehicleJPNBObj.get(1).getEndDate());
											if(xCustomerVehicleJPN2EndDt.after(xCustomerVehicleJPN1EndDt))
											{
											xContVehicleBObjInMap.setEndDate(tempVecXCustomerVehicleJPNBObj.get(1).getEndDate());
											}
											else
											{
											xContVehicleBObjInMap.setEndDate(tempVecXCustomerVehicleJPNBObj.get(0).getEndDate());
											}
											}
											else if(tempVecXCustomerVehicleJPNBObj.get(0).getEndDate()==null)
											{
												xContVehicleBObjInMap.setEndDate(null);
											}
											else
											{
												xContVehicleBObjInMap.setEndDate(tempVecXCustomerVehicleJPNBObj.get(1).getEndDate());
											}
											xCustomerVehicleMap.put((xContVehicleBObjInMap
													.getXVehicleJPNBObj().getGlobalVIN()) + xContVehicleBObjInMap
													.getXVehicleJPNBObj().getVehicleType()+ (xContVehicleBObjInMap.getRetailerId()),
													xContVehicleBObjInMap);
										}

										else {
											xCustomerVehicleBObj.getItemsXCustomerVehicleRoleJPNBObj().clear();
											xCustomerVehicleBObj.getItemsXCustomerVehicleRoleJPNBObj().addAll(vecFinalVehicleRoleBObjs);
											xCustomerVehicleBObj.setStartDate(tempVecXCustomerVehicleJPNBObj.get(0).getStartDate());
											
											if(xContVehicleBObjInMap.getVehicleSalesType()!=null && xCustomerVehicleBObj.getVehicleSalesType()!=null)
											{
												if(!xContVehicleBObjInMap.getVehicleSalesType().equalsIgnoreCase(ExternalRuleConstant.VEHICLE_SALES_TYPE_UNKNOWN)
														&& !xCustomerVehicleBObj.getVehicleSalesType().equalsIgnoreCase(ExternalRuleConstant.VEHICLE_SALES_TYPE_UNKNOWN))
												{
													xCustomerVehicleBObj.setVehicleSalesType(tempVecXCustomerVehicleJPNBObj.get(0).getVehicleSalesType());
												}
												else if(xCustomerVehicleBObj.getVehicleSalesType().equalsIgnoreCase(ExternalRuleConstant.VEHICLE_SALES_TYPE_UNKNOWN)
														&& !xContVehicleBObjInMap.getVehicleSalesType().equalsIgnoreCase(ExternalRuleConstant.VEHICLE_SALES_TYPE_UNKNOWN))
												{
													xCustomerVehicleBObj.setVehicleSalesType(xContVehicleBObjInMap.getVehicleSalesType());
												}
											}
											
											else if(xContVehicleBObjInMap.getVehicleSalesType()!=null && xCustomerVehicleBObj.getVehicleSalesType()==null)
											{
												xCustomerVehicleBObj.setVehicleSalesType(xContVehicleBObjInMap.getVehicleSalesType());
											}
											
											if(tempVecXCustomerVehicleJPNBObj.get(0).getEndDate()!=null && tempVecXCustomerVehicleJPNBObj.get(1).getEndDate()!=null)
											{
											java.util.Date xCustomerVehicleJPN2EndDt = simpleDateFmt.parse(tempVecXCustomerVehicleJPNBObj.get(1).getEndDate());
											if(xCustomerVehicleJPN2EndDt.after(xCustomerVehicleJPN1EndDt))
											{
												xCustomerVehicleBObj.setEndDate(tempVecXCustomerVehicleJPNBObj.get(1).getEndDate());
											}
											else
											{
												xCustomerVehicleBObj.setEndDate(tempVecXCustomerVehicleJPNBObj.get(0).getEndDate());
											}
											}
											else if(tempVecXCustomerVehicleJPNBObj.get(0).getEndDate()==null)
											{
												xCustomerVehicleBObj.setEndDate(null);
											}
											else
											{
												xCustomerVehicleBObj.setEndDate(tempVecXCustomerVehicleJPNBObj.get(1).getEndDate());
											}
											xCustomerVehicleMap.put((xCustomerVehicleBObj
													.getXVehicleJPNBObj().getGlobalVIN()) +xCustomerVehicleBObj
													.getXVehicleJPNBObj().getVehicleType() + (xCustomerVehicleBObj.getRetailerId()),
													xCustomerVehicleBObj);
										}

									}
										else
										{
											
											VecUnmergedXCustomerVehicleJPNBObj.add(xContVehicleBObjInMap);
											VecUnmergedXCustomerVehicleJPNBObj.add(xCustomerVehicleBObj);
											
											xCustomerVehicleMap.remove((xCustomerVehicleBObj
													.getXVehicleJPNBObj().getGlobalVIN()) +  xCustomerVehicleBObj
													.getXVehicleJPNBObj().getVehicleType() + (xCustomerVehicleBObj.getRetailerId()));																						
												
										}
									} 
									else {

										xCustomerVehicleMap.put((xCustomerVehicleBObj
												.getXVehicleJPNBObj().getGlobalVIN()) +  xCustomerVehicleBObj.getXVehicleJPNBObj().getVehicleType() + (xCustomerVehicleBObj.getRetailerId()),
												xCustomerVehicleBObj);
									}

								}
								
							}
						
							else
							{
								HashMap<String, XCustomerVehicleJPNBObj> tempCustomerVehicleMap = new HashMap<String, XCustomerVehicleJPNBObj>();
								tempCustomerVehicleMap =checkForActiveCVR(vecXCustomerVehicleRetailBObjs);
								
								/*if(xCustomerVehicleJPNBObj == null)
								{
									Collections.sort(vecXCustomerVehicleRetailBObjs,
											new Comparator<XCustomerVehicleJPNBObj>() {// Ascending sort
																				// - for delta
																				// load
												public int compare(XCustomerVehicleJPNBObj xCustomerVehicleJPN1,
														XCustomerVehicleJPNBObj xCustomerVehicleJPN2) {
													
													return xCustomerVehicleJPN1
															.getEndDate()
															.compareTo(
																	xCustomerVehicleJPN2.getEndDate());
												}
											});
									
									xCustomerVehicleJPNBObj = vecXCustomerVehicleRetailBObjs.get(vecXCustomerVehicleRetailBObjs.size()-1);
								}*/
								for(Map.Entry<String, XCustomerVehicleJPNBObj> entry1 : tempCustomerVehicleMap
										.entrySet())
								{
									XCustomerVehicleJPNBObj xCustomerVehicleJPNBObj=entry1.getValue();
								if (!xCustomerVehicleMap.containsKey((xCustomerVehicleJPNBObj
										.getXVehicleJPNBObj().getGlobalVIN()) + xCustomerVehicleJPNBObj
										.getXVehicleJPNBObj().getVehicleType()+ (xCustomerVehicleJPNBObj.getRetailerId()))) 
								{
									xCustomerVehicleMap.put((xCustomerVehicleJPNBObj
											.getXVehicleJPNBObj().getGlobalVIN()) +  xCustomerVehicleJPNBObj
											.getXVehicleJPNBObj().getVehicleType() + (xCustomerVehicleJPNBObj.getRetailerId()),
											xCustomerVehicleJPNBObj);
									
									
								} 
								else 
								{
									XCustomerVehicleJPNBObj xContVehicleBObjInMap = xCustomerVehicleMap.get((xCustomerVehicleJPNBObj
													.getXVehicleJPNBObj().getGlobalVIN()) +  xCustomerVehicleJPNBObj
													.getXVehicleJPNBObj().getVehicleType() + (xCustomerVehicleJPNBObj.getRetailerId()));
									requestPersonRetailerCode = xContVehicleBObjInMap
											.getRetailerId();
									existingPersonRetailerCode = xCustomerVehicleJPNBObj
											.getRetailerId();

									if (requestPersonRetailerCode != null
											&& existingPersonRetailerCode != null
											&& requestPersonRetailerCode
													.equalsIgnoreCase(existingPersonRetailerCode)) 
									{			
										//sort VR based on start date
										Vector <XCustomerVehicleJPNBObj> tempVecXCustomerVehicleJPNBObj = new Vector<XCustomerVehicleJPNBObj>();
										tempVecXCustomerVehicleJPNBObj.add(xContVehicleBObjInMap);
										tempVecXCustomerVehicleJPNBObj.add(xCustomerVehicleJPNBObj);
										if(xContVehicleBObjInMap.getStartDate()!=null && xCustomerVehicleJPNBObj.getStartDate()!=null)
										{
											Collections.sort(tempVecXCustomerVehicleJPNBObj,
													new Comparator<XCustomerVehicleJPNBObj>() {// Ascending sort
																						// - for delta
																						// load
														public int compare(XCustomerVehicleJPNBObj xCustomerVehicleJPN1,
																XCustomerVehicleJPNBObj xCustomerVehicleJPN2) {
															
															return xCustomerVehicleJPN1
																	.getStartDate()
																	.compareTo(
																			xCustomerVehicleJPN2.getStartDate());
														}
													});
										}
																	
										SimpleDateFormat simpleDateFmt = new SimpleDateFormat("yyyy-MM-dd");
										java.util.Date xCustomerVehicleJPN1EndDt =null;
										java.util.Date xCustomerVehicleJPN2StartDt =null;
										toBeMerged = false;
										
										
										
										if(tempVecXCustomerVehicleJPNBObj.get(0).getEndDate()!=null && 
												tempVecXCustomerVehicleJPNBObj.get(1).getStartDate()!=null)
										{
										xCustomerVehicleJPN1EndDt =simpleDateFmt.parse(tempVecXCustomerVehicleJPNBObj.get(0).getEndDate());
										xCustomerVehicleJPN2StartDt =simpleDateFmt.parse(tempVecXCustomerVehicleJPNBObj.get(1).getStartDate());
										
										long difference = xCustomerVehicleJPN2StartDt.getTime() - xCustomerVehicleJPN1EndDt.getTime();
										float daysBetween = (difference / (1000*60*60*24));
										if(daysBetween<=1)
										{
											toBeMerged = true;
										}
										}
										else if(tempVecXCustomerVehicleJPNBObj.get(0).getEndDate()==null)
										{
											toBeMerged = true;
										}
										if(toBeMerged)
										{
										vecParty1XCustomerVehicleRoleBObjs = xContVehicleBObjInMap.getItemsXCustomerVehicleRoleJPNBObj();
										vecParty2XCustomerVehicleRoleBObjs = xCustomerVehicleJPNBObj.getItemsXCustomerVehicleRoleJPNBObj();
										Vector<XCustomerVehicleRoleJPNBObj> vecFinalVehicleRoleBObjs = new Vector<XCustomerVehicleRoleJPNBObj>();
										HashMap<String, XCustomerVehicleRoleJPNBObj> xCustomerVehicleRoleMap = new HashMap<String, XCustomerVehicleRoleJPNBObj>();
										for(XCustomerVehicleRoleJPNBObj Party1XCustomerVehicleRoleBObj :vecParty1XCustomerVehicleRoleBObjs)
										{
											if(!xCustomerVehicleRoleMap.containsKey(Party1XCustomerVehicleRoleBObj.getVehicleRoleType()))
											{
												xCustomerVehicleRoleMap.put(Party1XCustomerVehicleRoleBObj.getVehicleRoleType(), Party1XCustomerVehicleRoleBObj);
											}
										}
										
										for(XCustomerVehicleRoleJPNBObj Party2XCustomerVehicleRoleBObj :vecParty2XCustomerVehicleRoleBObjs)
										{
											if(!xCustomerVehicleRoleMap.containsKey(Party2XCustomerVehicleRoleBObj.getVehicleRoleType()))
											{
												xCustomerVehicleRoleMap.put(Party2XCustomerVehicleRoleBObj.getVehicleRoleType(), Party2XCustomerVehicleRoleBObj);
											}
											else
											{
												XCustomerVehicleRoleJPNBObj Party1XCustomerVehicleRoleBObj = xCustomerVehicleRoleMap.get(Party2XCustomerVehicleRoleBObj.getVehicleRoleType());
												
												/*Timestamp Person1RoleLastModifiedDt = DateFormatter.getTimestamp(Party1XCustomerVehicleRoleBObj.getXCustomerVehicleRoleJPNLastUpdateDate());
												Timestamp Person2RoleLastModifiedDt = DateFormatter.getTimestamp(Party2XCustomerVehicleRoleBObj.getXCustomerVehicleRoleJPNLastUpdateDate());
												if(Person2RoleLastModifiedDt.after(Person1RoleLastModifiedDt))
												{
													xCustomerVehicleRoleMap.put(Party2XCustomerVehicleRoleBObj.getVehicleRoleType(), Party2XCustomerVehicleRoleBObj);
												}*/
												
												Vector <XCustomerVehicleRoleJPNBObj> tempVecXCustomerVehicleRoleJPNBObj = new Vector<XCustomerVehicleRoleJPNBObj>();
												tempVecXCustomerVehicleRoleJPNBObj.add(Party1XCustomerVehicleRoleBObj);
												tempVecXCustomerVehicleRoleJPNBObj.add(Party2XCustomerVehicleRoleBObj);
												
												if(Party1XCustomerVehicleRoleBObj.getStartDate()!=null && Party2XCustomerVehicleRoleBObj.getStartDate()!=null)
												{
													
													Collections.sort(tempVecXCustomerVehicleRoleJPNBObj,
															new Comparator<XCustomerVehicleRoleJPNBObj>() {// Ascending sort
																								// - for delta
																								// load
																public int compare(XCustomerVehicleRoleJPNBObj xCustomerVehicleRoleJPN1,
																		XCustomerVehicleRoleJPNBObj xCustomerVehicleRoleJPN2) {
																	
																	return xCustomerVehicleRoleJPN1
																			.getStartDate()
																			.compareTo(
																					xCustomerVehicleRoleJPN2.getStartDate());
																}
															});
													
													Timestamp Person1RoleLastModifiedDt = DateFormatter.getTimestamp(Party1XCustomerVehicleRoleBObj.getXCustomerVehicleRoleJPNLastUpdateDate());
													Timestamp Person2RoleLastModifiedDt = DateFormatter.getTimestamp(Party2XCustomerVehicleRoleBObj.getXCustomerVehicleRoleJPNLastUpdateDate());
													if(Person2RoleLastModifiedDt.after(Person1RoleLastModifiedDt))
													{
														Party2XCustomerVehicleRoleBObj.setStartDate(tempVecXCustomerVehicleRoleJPNBObj.get(0).getStartDate());
														if(tempVecXCustomerVehicleRoleJPNBObj.get(0).getEndDate()!=null && 
																tempVecXCustomerVehicleRoleJPNBObj.get(1).getEndDate()!=null)
														{
															Timestamp role1EndDt = DateFormatter.getTimestamp(tempVecXCustomerVehicleRoleJPNBObj.get(0).getEndDate());
															Timestamp role2EndDt = DateFormatter.getTimestamp(tempVecXCustomerVehicleRoleJPNBObj.get(1).getEndDate());
															
															if(role2EndDt.after(role1EndDt))
															{
																Party2XCustomerVehicleRoleBObj.setEndDate(tempVecXCustomerVehicleRoleJPNBObj.get(1).getEndDate());
															}
															else
															{
																Party2XCustomerVehicleRoleBObj.setEndDate(tempVecXCustomerVehicleRoleJPNBObj.get(0).getEndDate());
															}
														}
														else
														{
															Party2XCustomerVehicleRoleBObj.setEndDate(null);
														}
														xCustomerVehicleRoleMap.put(Party2XCustomerVehicleRoleBObj.getVehicleRoleType(), Party2XCustomerVehicleRoleBObj);
													}
													else
													{
														Party1XCustomerVehicleRoleBObj.setStartDate(tempVecXCustomerVehicleRoleJPNBObj.get(0).getStartDate());
														if(tempVecXCustomerVehicleRoleJPNBObj.get(0).getEndDate()!=null && 
																tempVecXCustomerVehicleRoleJPNBObj.get(1).getEndDate()!=null)
														{
															Timestamp role1EndDt = DateFormatter.getTimestamp(tempVecXCustomerVehicleRoleJPNBObj.get(0).getEndDate());
															Timestamp role2EndDt = DateFormatter.getTimestamp(tempVecXCustomerVehicleRoleJPNBObj.get(1).getEndDate());
															
															if(role2EndDt.after(role1EndDt))
															{
																Party1XCustomerVehicleRoleBObj.setEndDate(tempVecXCustomerVehicleRoleJPNBObj.get(1).getEndDate());
															}
															else
															{
																Party1XCustomerVehicleRoleBObj.setEndDate(tempVecXCustomerVehicleRoleJPNBObj.get(0).getEndDate());
															}
														}
														else
														{
															Party1XCustomerVehicleRoleBObj.setEndDate(null);
														}
														xCustomerVehicleRoleMap.put(Party1XCustomerVehicleRoleBObj.getVehicleRoleType(), Party1XCustomerVehicleRoleBObj);
													}
													
													
													
												}
											}
											
										}
										
										for (Map.Entry<String, XCustomerVehicleRoleJPNBObj> entry : xCustomerVehicleRoleMap.entrySet()) 
										{
											vecFinalVehicleRoleBObjs.add(entry.getValue());
										}
										

										Timestamp person1ModifiedDt = DateFormatter
												.getTimestamp(xContVehicleBObjInMap
														.getXCustomerVehicleJPNLastUpdateDate());

										Timestamp person2ModifiedDt = DateFormatter
												.getTimestamp(xCustomerVehicleJPNBObj
														.getXCustomerVehicleJPNLastUpdateDate());
										
										if (person1ModifiedDt.after(person2ModifiedDt)) {
											xContVehicleBObjInMap.getItemsXCustomerVehicleRoleJPNBObj().clear();
											xContVehicleBObjInMap.getItemsXCustomerVehicleRoleJPNBObj().addAll(vecFinalVehicleRoleBObjs);
											xContVehicleBObjInMap.setStartDate(tempVecXCustomerVehicleJPNBObj.get(0).getStartDate());
											
											if(xContVehicleBObjInMap.getVehicleSalesType()!=null && xCustomerVehicleJPNBObj.getVehicleSalesType()!=null)
											{
												if(!xContVehicleBObjInMap.getVehicleSalesType().equalsIgnoreCase(ExternalRuleConstant.VEHICLE_SALES_TYPE_UNKNOWN)
														&& !xCustomerVehicleJPNBObj.getVehicleSalesType().equalsIgnoreCase(ExternalRuleConstant.VEHICLE_SALES_TYPE_UNKNOWN))
												{
													xContVehicleBObjInMap.setVehicleSalesType(tempVecXCustomerVehicleJPNBObj.get(0).getVehicleSalesType());
												}
												else if(xContVehicleBObjInMap.getVehicleSalesType().equalsIgnoreCase(ExternalRuleConstant.VEHICLE_SALES_TYPE_UNKNOWN)
														&& !xCustomerVehicleJPNBObj.getVehicleSalesType().equalsIgnoreCase(ExternalRuleConstant.VEHICLE_SALES_TYPE_UNKNOWN))
												{
													xContVehicleBObjInMap.setVehicleSalesType(xCustomerVehicleJPNBObj.getVehicleSalesType());
												}
											}
											
											else if(xContVehicleBObjInMap.getVehicleSalesType()==null && xCustomerVehicleJPNBObj.getVehicleSalesType()!=null)
											{
												xContVehicleBObjInMap.setVehicleSalesType(xCustomerVehicleJPNBObj.getVehicleSalesType());
											}
											
											if(tempVecXCustomerVehicleJPNBObj.get(0).getEndDate()!=null && tempVecXCustomerVehicleJPNBObj.get(1).getEndDate()!=null)
											{
											java.util.Date xCustomerVehicleJPN2EndDt = simpleDateFmt.parse(tempVecXCustomerVehicleJPNBObj.get(1).getEndDate());
											if(xCustomerVehicleJPN2EndDt.after(xCustomerVehicleJPN1EndDt))
											{
											xContVehicleBObjInMap.setEndDate(tempVecXCustomerVehicleJPNBObj.get(1).getEndDate());
											}
											else
											{
											xContVehicleBObjInMap.setEndDate(tempVecXCustomerVehicleJPNBObj.get(0).getEndDate());
											}
											}
											else if(tempVecXCustomerVehicleJPNBObj.get(0).getEndDate()==null)
											{
												xContVehicleBObjInMap.setEndDate(null);
											}
											else
											{
												xContVehicleBObjInMap.setEndDate(tempVecXCustomerVehicleJPNBObj.get(1).getEndDate());
											}
											xCustomerVehicleMap.put((xContVehicleBObjInMap
													.getXVehicleJPNBObj().getGlobalVIN()) + xContVehicleBObjInMap
													.getXVehicleJPNBObj().getVehicleType()+ (xContVehicleBObjInMap.getRetailerId()),
													xContVehicleBObjInMap);
											
										}

										else {
											xCustomerVehicleJPNBObj.getItemsXCustomerVehicleRoleJPNBObj().clear();
											xCustomerVehicleJPNBObj.getItemsXCustomerVehicleRoleJPNBObj().addAll(vecFinalVehicleRoleBObjs);
											xCustomerVehicleJPNBObj.setStartDate(tempVecXCustomerVehicleJPNBObj.get(0).getStartDate());
											
											if(xContVehicleBObjInMap.getVehicleSalesType()!=null && xCustomerVehicleJPNBObj.getVehicleSalesType()!=null)
											{
												if(!xContVehicleBObjInMap.getVehicleSalesType().equalsIgnoreCase(ExternalRuleConstant.VEHICLE_SALES_TYPE_UNKNOWN)
														&& !xCustomerVehicleJPNBObj.getVehicleSalesType().equalsIgnoreCase(ExternalRuleConstant.VEHICLE_SALES_TYPE_UNKNOWN))
												{
													xCustomerVehicleJPNBObj.setVehicleSalesType(tempVecXCustomerVehicleJPNBObj.get(0).getVehicleSalesType());
												}
												else if(xCustomerVehicleJPNBObj.getVehicleSalesType().equalsIgnoreCase(ExternalRuleConstant.VEHICLE_SALES_TYPE_UNKNOWN)
														&& !xContVehicleBObjInMap.getVehicleSalesType().equalsIgnoreCase(ExternalRuleConstant.VEHICLE_SALES_TYPE_UNKNOWN))
												{
													xCustomerVehicleJPNBObj.setVehicleSalesType(xContVehicleBObjInMap.getVehicleSalesType());
												}
											}
											
											else if(xContVehicleBObjInMap.getVehicleSalesType()!=null && xCustomerVehicleJPNBObj.getVehicleSalesType()==null)
											{
												xCustomerVehicleJPNBObj.setVehicleSalesType(xContVehicleBObjInMap.getVehicleSalesType());
											}
											
											if(tempVecXCustomerVehicleJPNBObj.get(0).getEndDate()!=null && tempVecXCustomerVehicleJPNBObj.get(1).getEndDate()!=null)
											{
											java.util.Date xCustomerVehicleJPN2EndDt = simpleDateFmt.parse(tempVecXCustomerVehicleJPNBObj.get(1).getEndDate());
											if(xCustomerVehicleJPN2EndDt.after(xCustomerVehicleJPN1EndDt))
											{
												xCustomerVehicleJPNBObj.setEndDate(tempVecXCustomerVehicleJPNBObj.get(1).getEndDate());
											}
											else
											{
												xCustomerVehicleJPNBObj.setEndDate(tempVecXCustomerVehicleJPNBObj.get(0).getEndDate());
											}
											}
											else if(tempVecXCustomerVehicleJPNBObj.get(0).getEndDate()==null)
											{
												xCustomerVehicleJPNBObj.setEndDate(null);
											}
											else
											{
												xCustomerVehicleJPNBObj.setEndDate(tempVecXCustomerVehicleJPNBObj.get(1).getEndDate());
											}
											xCustomerVehicleMap.put((xCustomerVehicleJPNBObj
													.getXVehicleJPNBObj().getGlobalVIN()) +xCustomerVehicleJPNBObj
													.getXVehicleJPNBObj().getVehicleType() + (xCustomerVehicleJPNBObj.getRetailerId()),
													xCustomerVehicleJPNBObj);
											
										}

									}
										else
										{
											
											VecUnmergedXCustomerVehicleJPNBObj.add(xContVehicleBObjInMap);
											VecUnmergedXCustomerVehicleJPNBObj.add(xCustomerVehicleJPNBObj);
											
											xCustomerVehicleMap.remove((xCustomerVehicleJPNBObj
													.getXVehicleJPNBObj().getGlobalVIN()) +  xCustomerVehicleJPNBObj
													.getXVehicleJPNBObj().getVehicleType() + (xCustomerVehicleJPNBObj.getRetailerId()));
																					
										}
									} 
									else {

										xCustomerVehicleMap.put((xCustomerVehicleJPNBObj
												.getXVehicleJPNBObj().getGlobalVIN()) +  xCustomerVehicleJPNBObj.getXVehicleJPNBObj().getVehicleType() + (xCustomerVehicleJPNBObj.getRetailerId()),
												xCustomerVehicleJPNBObj);
									}

								}
							}
						}
				}						
						//}
					//}
					
					
					
					//Handle wholesale CVR
					/*for (int j = 0; j < vecXCustomerVehicleBObjs.size(); j++) 
					{
						XCustomerVehicleJPNBObj xCustomerVehicleBObj = (XCustomerVehicleJPNBObj) vecXCustomerVehicleBObjs
								.get(j);
						if(xCustomerVehicleBObj.getRetailerId()==null) // && checkIfCVRActive(xCustomerVehicleBObj.getEndDate()) )
						{*/
							if(vecXCustomerVehicleWholesaleBObjs.size() >0)	
							{
							if(vecXCustomerVehicleWholesaleBObjs.size()==1)
							{
								XCustomerVehicleJPNBObj xCustomerVehicleBObj = (XCustomerVehicleJPNBObj) vecXCustomerVehicleWholesaleBObjs
										.get(0);
								if (!xCustomerVehicleMap.containsKey((xCustomerVehicleBObj
										.getXVehicleJPNBObj().getGlobalVIN()) + xCustomerVehicleBObj
										.getXVehicleJPNBObj().getVehicleType())) 
								{
									xCustomerVehicleMap.put((xCustomerVehicleBObj
											.getXVehicleJPNBObj().getGlobalVIN()) +  xCustomerVehicleBObj
											.getXVehicleJPNBObj().getVehicleType() ,
											xCustomerVehicleBObj);
								} 
								
								else 
								{
									XCustomerVehicleJPNBObj xContVehicleBObjInMap = xCustomerVehicleMap.get((xCustomerVehicleBObj
													.getXVehicleJPNBObj().getGlobalVIN()) +  xCustomerVehicleBObj
													.getXVehicleJPNBObj().getVehicleType() );
									requestPersonRetailerCode = xContVehicleBObjInMap
											.getRetailerId();
									existingPersonRetailerCode = xCustomerVehicleBObj
											.getRetailerId();

									if (requestPersonRetailerCode == null
											&& existingPersonRetailerCode == null
											) 
									{			
										//sort VR based on start date
										Vector <XCustomerVehicleJPNBObj> tempVecXCustomerVehicleJPNBObj = new Vector<XCustomerVehicleJPNBObj>();
										tempVecXCustomerVehicleJPNBObj.add(xContVehicleBObjInMap);
										tempVecXCustomerVehicleJPNBObj.add(xCustomerVehicleBObj);
										if(xContVehicleBObjInMap.getStartDate()!=null && xCustomerVehicleBObj.getStartDate()!=null)
										{
											Collections.sort(tempVecXCustomerVehicleJPNBObj,
													new Comparator<XCustomerVehicleJPNBObj>() {// Ascending sort
																						// - for delta
																						// load
														public int compare(XCustomerVehicleJPNBObj xCustomerVehicleJPN1,
																XCustomerVehicleJPNBObj xCustomerVehicleJPN2) {
															
															return xCustomerVehicleJPN1
																	.getStartDate()
																	.compareTo(
																			xCustomerVehicleJPN2.getStartDate());
														}
													});
										}
																	
										SimpleDateFormat simpleDateFmt = new SimpleDateFormat("yyyy-MM-dd");
										java.util.Date xCustomerVehicleJPN1EndDt =null;
										java.util.Date xCustomerVehicleJPN2StartDt =null;
										toBeMerged = false;
										
										if(tempVecXCustomerVehicleJPNBObj.get(0).getEndDate()!=null && 
												tempVecXCustomerVehicleJPNBObj.get(1).getStartDate()!=null)
										{
										xCustomerVehicleJPN1EndDt =simpleDateFmt.parse(tempVecXCustomerVehicleJPNBObj.get(0).getEndDate());
										xCustomerVehicleJPN2StartDt =simpleDateFmt.parse(tempVecXCustomerVehicleJPNBObj.get(1).getStartDate());
										
										long difference = xCustomerVehicleJPN2StartDt.getTime() - xCustomerVehicleJPN1EndDt.getTime();
										float daysBetween = (difference / (1000*60*60*24));
										if(daysBetween<=1)
										{
											toBeMerged = true;
										}
										}
										else if(tempVecXCustomerVehicleJPNBObj.get(0).getEndDate()==null)
										{
											toBeMerged = true;
										}
										if(toBeMerged)
										{
										vecParty1XCustomerVehicleRoleBObjs = xContVehicleBObjInMap.getItemsXCustomerVehicleRoleJPNBObj();
										vecParty2XCustomerVehicleRoleBObjs = xCustomerVehicleBObj.getItemsXCustomerVehicleRoleJPNBObj();
										Vector<XCustomerVehicleRoleJPNBObj> vecFinalVehicleRoleBObjs = new Vector<XCustomerVehicleRoleJPNBObj>();
										HashMap<String, XCustomerVehicleRoleJPNBObj> xCustomerVehicleRoleMap = new HashMap<String, XCustomerVehicleRoleJPNBObj>();
										for(XCustomerVehicleRoleJPNBObj Party1XCustomerVehicleRoleBObj :vecParty1XCustomerVehicleRoleBObjs)
										{
											if(!xCustomerVehicleRoleMap.containsKey(Party1XCustomerVehicleRoleBObj.getVehicleRoleType()))
											{
												xCustomerVehicleRoleMap.put(Party1XCustomerVehicleRoleBObj.getVehicleRoleType(), Party1XCustomerVehicleRoleBObj);
											}
										}
										
										for(XCustomerVehicleRoleJPNBObj Party2XCustomerVehicleRoleBObj :vecParty2XCustomerVehicleRoleBObjs)
										{
											if(!xCustomerVehicleRoleMap.containsKey(Party2XCustomerVehicleRoleBObj.getVehicleRoleType()))
											{
												xCustomerVehicleRoleMap.put(Party2XCustomerVehicleRoleBObj.getVehicleRoleType(), Party2XCustomerVehicleRoleBObj);
											}
											else
											{
												XCustomerVehicleRoleJPNBObj Party1XCustomerVehicleRoleBObj = xCustomerVehicleRoleMap.get(Party2XCustomerVehicleRoleBObj.getVehicleRoleType());
												
												/*Timestamp Person1RoleLastModifiedDt = DateFormatter.getTimestamp(Party1XCustomerVehicleRoleBObj.getXCustomerVehicleRoleJPNLastUpdateDate());
												Timestamp Person2RoleLastModifiedDt = DateFormatter.getTimestamp(Party2XCustomerVehicleRoleBObj.getXCustomerVehicleRoleJPNLastUpdateDate());
												if(Person2RoleLastModifiedDt.after(Person1RoleLastModifiedDt))
												{
													xCustomerVehicleRoleMap.put(Party2XCustomerVehicleRoleBObj.getVehicleRoleType(), Party2XCustomerVehicleRoleBObj);
												}*/
												
												
												Vector <XCustomerVehicleRoleJPNBObj> tempVecXCustomerVehicleRoleJPNBObj = new Vector<XCustomerVehicleRoleJPNBObj>();
												tempVecXCustomerVehicleRoleJPNBObj.add(Party1XCustomerVehicleRoleBObj);
												tempVecXCustomerVehicleRoleJPNBObj.add(Party2XCustomerVehicleRoleBObj);
												
												if(Party1XCustomerVehicleRoleBObj.getStartDate()!=null && Party2XCustomerVehicleRoleBObj.getStartDate()!=null)
												{
													Collections.sort(tempVecXCustomerVehicleRoleJPNBObj,
															new Comparator<XCustomerVehicleRoleJPNBObj>() {// Ascending sort
																								// - for delta
																								// load
																public int compare(XCustomerVehicleRoleJPNBObj xCustomerVehicleRoleJPN1,
																		XCustomerVehicleRoleJPNBObj xCustomerVehicleRoleJPN2) {
																	
																	return xCustomerVehicleRoleJPN1
																			.getStartDate()
																			.compareTo(
																					xCustomerVehicleRoleJPN2.getStartDate());
																}
															});
													
													Timestamp Person1RoleLastModifiedDt = DateFormatter.getTimestamp(Party1XCustomerVehicleRoleBObj.getXCustomerVehicleRoleJPNLastUpdateDate());
													Timestamp Person2RoleLastModifiedDt = DateFormatter.getTimestamp(Party2XCustomerVehicleRoleBObj.getXCustomerVehicleRoleJPNLastUpdateDate());
													if(Person2RoleLastModifiedDt.after(Person1RoleLastModifiedDt))
													{
														Party2XCustomerVehicleRoleBObj.setStartDate(tempVecXCustomerVehicleRoleJPNBObj.get(0).getStartDate());
														if(tempVecXCustomerVehicleRoleJPNBObj.get(0).getEndDate()!=null && 
																tempVecXCustomerVehicleRoleJPNBObj.get(1).getEndDate()!=null)
														{
															Timestamp role1EndDt = DateFormatter.getTimestamp(tempVecXCustomerVehicleRoleJPNBObj.get(0).getEndDate());
															Timestamp role2EndDt = DateFormatter.getTimestamp(tempVecXCustomerVehicleRoleJPNBObj.get(1).getEndDate());
															
															if(role2EndDt.after(role1EndDt))
															{
																Party2XCustomerVehicleRoleBObj.setEndDate(tempVecXCustomerVehicleRoleJPNBObj.get(1).getEndDate());
															}
															else
															{
																Party2XCustomerVehicleRoleBObj.setEndDate(tempVecXCustomerVehicleRoleJPNBObj.get(0).getEndDate());
															}
														}
														else
														{
															Party2XCustomerVehicleRoleBObj.setEndDate(null);
														}
														xCustomerVehicleRoleMap.put(Party2XCustomerVehicleRoleBObj.getVehicleRoleType(), Party2XCustomerVehicleRoleBObj);
													}
													else
													{
														Party1XCustomerVehicleRoleBObj.setStartDate(tempVecXCustomerVehicleRoleJPNBObj.get(0).getStartDate());
														if(tempVecXCustomerVehicleRoleJPNBObj.get(0).getEndDate()!=null && 
																tempVecXCustomerVehicleRoleJPNBObj.get(1).getEndDate()!=null)
														{
															Timestamp role1EndDt = DateFormatter.getTimestamp(tempVecXCustomerVehicleRoleJPNBObj.get(0).getEndDate());
															Timestamp role2EndDt = DateFormatter.getTimestamp(tempVecXCustomerVehicleRoleJPNBObj.get(1).getEndDate());
															
															if(role2EndDt.after(role1EndDt))
															{
																Party1XCustomerVehicleRoleBObj.setEndDate(tempVecXCustomerVehicleRoleJPNBObj.get(1).getEndDate());
															}
															else
															{
																Party1XCustomerVehicleRoleBObj.setEndDate(tempVecXCustomerVehicleRoleJPNBObj.get(0).getEndDate());
															}
														}
														else
														{
															Party1XCustomerVehicleRoleBObj.setEndDate(null);
														}
														xCustomerVehicleRoleMap.put(Party1XCustomerVehicleRoleBObj.getVehicleRoleType(), Party1XCustomerVehicleRoleBObj);
													}
													
												}
											}
											
										}
										
										for (Map.Entry<String, XCustomerVehicleRoleJPNBObj> entry : xCustomerVehicleRoleMap.entrySet()) 
										{
											vecFinalVehicleRoleBObjs.add(entry.getValue());
										}
										

										Timestamp person1ModifiedDt = DateFormatter
												.getTimestamp(xContVehicleBObjInMap
														.getXCustomerVehicleJPNLastUpdateDate());

										Timestamp person2ModifiedDt = DateFormatter
												.getTimestamp(xCustomerVehicleBObj
														.getXCustomerVehicleJPNLastUpdateDate());
										
										if (person1ModifiedDt.after(person2ModifiedDt)) {
											xContVehicleBObjInMap.getItemsXCustomerVehicleRoleJPNBObj().clear();
											xContVehicleBObjInMap.getItemsXCustomerVehicleRoleJPNBObj().addAll(vecFinalVehicleRoleBObjs);
											xContVehicleBObjInMap.setStartDate(tempVecXCustomerVehicleJPNBObj.get(0).getStartDate());
											
											if(xContVehicleBObjInMap.getVehicleSalesType()!=null && xCustomerVehicleBObj.getVehicleSalesType()!=null)
											{
												if(!xContVehicleBObjInMap.getVehicleSalesType().equalsIgnoreCase(ExternalRuleConstant.VEHICLE_SALES_TYPE_UNKNOWN)
														&& !xCustomerVehicleBObj.getVehicleSalesType().equalsIgnoreCase(ExternalRuleConstant.VEHICLE_SALES_TYPE_UNKNOWN))
												{
													xContVehicleBObjInMap.setVehicleSalesType(tempVecXCustomerVehicleJPNBObj.get(0).getVehicleSalesType());
												}
												else if(xContVehicleBObjInMap.getVehicleSalesType().equalsIgnoreCase(ExternalRuleConstant.VEHICLE_SALES_TYPE_UNKNOWN)
														&& !xCustomerVehicleBObj.getVehicleSalesType().equalsIgnoreCase(ExternalRuleConstant.VEHICLE_SALES_TYPE_UNKNOWN))
												{
													xContVehicleBObjInMap.setVehicleSalesType(xCustomerVehicleBObj.getVehicleSalesType());
												}
											}
											
											else if(xContVehicleBObjInMap.getVehicleSalesType()==null && xCustomerVehicleBObj.getVehicleSalesType()!=null)
											{
												xContVehicleBObjInMap.setVehicleSalesType(xCustomerVehicleBObj.getVehicleSalesType());
											}
											
											if(tempVecXCustomerVehicleJPNBObj.get(0).getEndDate()!=null && tempVecXCustomerVehicleJPNBObj.get(1).getEndDate()!=null)
											{
											java.util.Date xCustomerVehicleJPN2EndDt = simpleDateFmt.parse(tempVecXCustomerVehicleJPNBObj.get(1).getEndDate());
											if(xCustomerVehicleJPN2EndDt.after(xCustomerVehicleJPN1EndDt))
											{
											xContVehicleBObjInMap.setEndDate(tempVecXCustomerVehicleJPNBObj.get(1).getEndDate());
											}
											else
											{
											xContVehicleBObjInMap.setEndDate(tempVecXCustomerVehicleJPNBObj.get(0).getEndDate());
											}
											}
											else if(tempVecXCustomerVehicleJPNBObj.get(0).getEndDate()==null)
											{
												xContVehicleBObjInMap.setEndDate(null);
											}
											else
											{
												xContVehicleBObjInMap.setEndDate(tempVecXCustomerVehicleJPNBObj.get(1).getEndDate());
											}
											xCustomerVehicleMap.put((xContVehicleBObjInMap
													.getXVehicleJPNBObj().getGlobalVIN()) + xContVehicleBObjInMap
													.getXVehicleJPNBObj().getVehicleType(),
													xContVehicleBObjInMap);
										}

										else {
											xCustomerVehicleBObj.getItemsXCustomerVehicleRoleJPNBObj().clear();
											xCustomerVehicleBObj.getItemsXCustomerVehicleRoleJPNBObj().addAll(vecFinalVehicleRoleBObjs);
											xCustomerVehicleBObj.setStartDate(tempVecXCustomerVehicleJPNBObj.get(0).getStartDate());
											
											if(xContVehicleBObjInMap.getVehicleSalesType()!=null && xCustomerVehicleBObj.getVehicleSalesType()!=null)
											{
												if(!xContVehicleBObjInMap.getVehicleSalesType().equalsIgnoreCase(ExternalRuleConstant.VEHICLE_SALES_TYPE_UNKNOWN)
														&& !xCustomerVehicleBObj.getVehicleSalesType().equalsIgnoreCase(ExternalRuleConstant.VEHICLE_SALES_TYPE_UNKNOWN))
												{
													xCustomerVehicleBObj.setVehicleSalesType(tempVecXCustomerVehicleJPNBObj.get(0).getVehicleSalesType());
												}
												else if(xCustomerVehicleBObj.getVehicleSalesType().equalsIgnoreCase(ExternalRuleConstant.VEHICLE_SALES_TYPE_UNKNOWN)
														&& !xContVehicleBObjInMap.getVehicleSalesType().equalsIgnoreCase(ExternalRuleConstant.VEHICLE_SALES_TYPE_UNKNOWN))
												{
													xCustomerVehicleBObj.setVehicleSalesType(xContVehicleBObjInMap.getVehicleSalesType());
												}
											}
											
											else if(xContVehicleBObjInMap.getVehicleSalesType()!=null && xCustomerVehicleBObj.getVehicleSalesType()==null)
											{
												xCustomerVehicleBObj.setVehicleSalesType(xContVehicleBObjInMap.getVehicleSalesType());
											}
											if(tempVecXCustomerVehicleJPNBObj.get(0).getEndDate()!=null && tempVecXCustomerVehicleJPNBObj.get(1).getEndDate()!=null)
											{
											java.util.Date xCustomerVehicleJPN2EndDt = simpleDateFmt.parse(tempVecXCustomerVehicleJPNBObj.get(1).getEndDate());
											if(xCustomerVehicleJPN2EndDt.after(xCustomerVehicleJPN1EndDt))
											{
												xCustomerVehicleBObj.setEndDate(tempVecXCustomerVehicleJPNBObj.get(1).getEndDate());
											}
											else
											{
												xCustomerVehicleBObj.setEndDate(tempVecXCustomerVehicleJPNBObj.get(0).getEndDate());
											}
											}
											else if(tempVecXCustomerVehicleJPNBObj.get(0).getEndDate()==null)
											{
												xCustomerVehicleBObj.setEndDate(null);
											}
											else
											{
												xCustomerVehicleBObj.setEndDate(tempVecXCustomerVehicleJPNBObj.get(1).getEndDate());
											}
											xCustomerVehicleMap.put((xCustomerVehicleBObj
													.getXVehicleJPNBObj().getGlobalVIN()) +xCustomerVehicleBObj
													.getXVehicleJPNBObj().getVehicleType() ,
													xCustomerVehicleBObj);
										}

									}
										else
										{
											VecUnmergedXCustomerVehicleJPNBObj.add(xContVehicleBObjInMap);
											VecUnmergedXCustomerVehicleJPNBObj.add(xCustomerVehicleBObj);
											
											xCustomerVehicleMap.remove((xCustomerVehicleBObj
													.getXVehicleJPNBObj().getGlobalVIN()) +  xCustomerVehicleBObj
													.getXVehicleJPNBObj().getVehicleType());		
										}
									} 
									else {

										xCustomerVehicleMap.put((xCustomerVehicleBObj
												.getXVehicleJPNBObj().getGlobalVIN()) +  xCustomerVehicleBObj.getXVehicleJPNBObj().getVehicleType() ,
												xCustomerVehicleBObj);
									}

								}
								
							}
													
							else
							{
								HashMap<String, XCustomerVehicleJPNBObj> tempCustomerVehicleMap = new HashMap<String, XCustomerVehicleJPNBObj>();
								tempCustomerVehicleMap =checkForActiveCVR(vecXCustomerVehicleWholesaleBObjs);
								
							/*	if(xCustomerVehicleJPNBObj == null)
								{
									Collections.sort(vecXCustomerVehicleWholesaleBObjs,
											new Comparator<XCustomerVehicleJPNBObj>() {// Ascending sort
																				// - for delta
																				// load
												public int compare(XCustomerVehicleJPNBObj xCustomerVehicleJPN1,
														XCustomerVehicleJPNBObj xCustomerVehicleJPN2) {
													
													return xCustomerVehicleJPN1
															.getEndDate()
															.compareTo(
																	xCustomerVehicleJPN2.getEndDate());
												}
											});
									
									xCustomerVehicleJPNBObj = vecXCustomerVehicleWholesaleBObjs.get(vecXCustomerVehicleWholesaleBObjs.size()-1);
								}*/

								for(Map.Entry<String, XCustomerVehicleJPNBObj> entry1 : tempCustomerVehicleMap
										.entrySet())
								{
									XCustomerVehicleJPNBObj xCustomerVehicleJPNBObj=entry1.getValue();
								if (!xCustomerVehicleMap.containsKey((xCustomerVehicleJPNBObj
										.getXVehicleJPNBObj().getGlobalVIN()) + xCustomerVehicleJPNBObj
										.getXVehicleJPNBObj().getVehicleType())) 
								{
									xCustomerVehicleMap.put((xCustomerVehicleJPNBObj
											.getXVehicleJPNBObj().getGlobalVIN()) +  xCustomerVehicleJPNBObj
											.getXVehicleJPNBObj().getVehicleType() ,
											xCustomerVehicleJPNBObj);
									
									
								} 
								else 
								{
									XCustomerVehicleJPNBObj xContVehicleBObjInMap = xCustomerVehicleMap.get((xCustomerVehicleJPNBObj
													.getXVehicleJPNBObj().getGlobalVIN()) +  xCustomerVehicleJPNBObj
													.getXVehicleJPNBObj().getVehicleType() );
									requestPersonRetailerCode = xContVehicleBObjInMap
											.getRetailerId();
									existingPersonRetailerCode = xCustomerVehicleJPNBObj
											.getRetailerId();

									if (requestPersonRetailerCode == null
											&& existingPersonRetailerCode == null
											) 
									{			
										//sort VR based on start date
										Vector <XCustomerVehicleJPNBObj> tempVecXCustomerVehicleJPNBObj = new Vector<XCustomerVehicleJPNBObj>();
										tempVecXCustomerVehicleJPNBObj.add(xContVehicleBObjInMap);
										tempVecXCustomerVehicleJPNBObj.add(xCustomerVehicleJPNBObj);
										if(xContVehicleBObjInMap.getStartDate()!=null && xCustomerVehicleJPNBObj.getStartDate()!=null)
										{
											Collections.sort(tempVecXCustomerVehicleJPNBObj,
													new Comparator<XCustomerVehicleJPNBObj>() {// Ascending sort
																						// - for delta
																						// load
														public int compare(XCustomerVehicleJPNBObj xCustomerVehicleJPN1,
																XCustomerVehicleJPNBObj xCustomerVehicleJPN2) {
															
															return xCustomerVehicleJPN1
																	.getStartDate()
																	.compareTo(
																			xCustomerVehicleJPN2.getStartDate());
														}
													});
										}
																	
										SimpleDateFormat simpleDateFmt = new SimpleDateFormat("yyyy-MM-dd");
										java.util.Date xCustomerVehicleJPN1EndDt =null;
										java.util.Date xCustomerVehicleJPN2StartDt =null;
										
										toBeMerged = false;
										
										if(tempVecXCustomerVehicleJPNBObj.get(0).getEndDate()!=null && 
												tempVecXCustomerVehicleJPNBObj.get(1).getStartDate()!=null)
										{
										xCustomerVehicleJPN1EndDt =simpleDateFmt.parse(tempVecXCustomerVehicleJPNBObj.get(0).getEndDate());
										xCustomerVehicleJPN2StartDt =simpleDateFmt.parse(tempVecXCustomerVehicleJPNBObj.get(1).getStartDate());
										
										long difference = xCustomerVehicleJPN2StartDt.getTime() - xCustomerVehicleJPN1EndDt.getTime();
										float daysBetween = (difference / (1000*60*60*24));
										if(daysBetween<=1)
										{
											toBeMerged = true;
										}
										}
										else if(tempVecXCustomerVehicleJPNBObj.get(0).getEndDate()==null)
										{
											toBeMerged = true;
										}
										if(toBeMerged)
										{
										vecParty1XCustomerVehicleRoleBObjs = xContVehicleBObjInMap.getItemsXCustomerVehicleRoleJPNBObj();
										vecParty2XCustomerVehicleRoleBObjs = xCustomerVehicleJPNBObj.getItemsXCustomerVehicleRoleJPNBObj();
										Vector<XCustomerVehicleRoleJPNBObj> vecFinalVehicleRoleBObjs = new Vector<XCustomerVehicleRoleJPNBObj>();
										HashMap<String, XCustomerVehicleRoleJPNBObj> xCustomerVehicleRoleMap = new HashMap<String, XCustomerVehicleRoleJPNBObj>();
										for(XCustomerVehicleRoleJPNBObj Party1XCustomerVehicleRoleBObj :vecParty1XCustomerVehicleRoleBObjs)
										{
											if(!xCustomerVehicleRoleMap.containsKey(Party1XCustomerVehicleRoleBObj.getVehicleRoleType()))
											{
												xCustomerVehicleRoleMap.put(Party1XCustomerVehicleRoleBObj.getVehicleRoleType(), Party1XCustomerVehicleRoleBObj);
											}
										}
										
										for(XCustomerVehicleRoleJPNBObj Party2XCustomerVehicleRoleBObj :vecParty2XCustomerVehicleRoleBObjs)
										{
											if(!xCustomerVehicleRoleMap.containsKey(Party2XCustomerVehicleRoleBObj.getVehicleRoleType()))
											{
												xCustomerVehicleRoleMap.put(Party2XCustomerVehicleRoleBObj.getVehicleRoleType(), Party2XCustomerVehicleRoleBObj);
											}
											else
											{
												XCustomerVehicleRoleJPNBObj Party1XCustomerVehicleRoleBObj = xCustomerVehicleRoleMap.get(Party2XCustomerVehicleRoleBObj.getVehicleRoleType());
												
												/*Timestamp Person1RoleLastModifiedDt = DateFormatter.getTimestamp(Party1XCustomerVehicleRoleBObj.getXCustomerVehicleRoleJPNLastUpdateDate());
												Timestamp Person2RoleLastModifiedDt = DateFormatter.getTimestamp(Party2XCustomerVehicleRoleBObj.getXCustomerVehicleRoleJPNLastUpdateDate());
												if(Person2RoleLastModifiedDt.after(Person1RoleLastModifiedDt))
												{
													xCustomerVehicleRoleMap.put(Party2XCustomerVehicleRoleBObj.getVehicleRoleType(), Party2XCustomerVehicleRoleBObj);
												}*/
												
												Vector <XCustomerVehicleRoleJPNBObj> tempVecXCustomerVehicleRoleJPNBObj = new Vector<XCustomerVehicleRoleJPNBObj>();
												tempVecXCustomerVehicleRoleJPNBObj.add(Party1XCustomerVehicleRoleBObj);
												tempVecXCustomerVehicleRoleJPNBObj.add(Party2XCustomerVehicleRoleBObj);
												
												if(Party1XCustomerVehicleRoleBObj.getStartDate()!=null && Party2XCustomerVehicleRoleBObj.getStartDate()!=null)
												{
													Collections.sort(tempVecXCustomerVehicleRoleJPNBObj,
															new Comparator<XCustomerVehicleRoleJPNBObj>() {// Ascending sort
																								// - for delta
																								// load
																public int compare(XCustomerVehicleRoleJPNBObj xCustomerVehicleRoleJPN1,
																		XCustomerVehicleRoleJPNBObj xCustomerVehicleRoleJPN2) {
																	
																	return xCustomerVehicleRoleJPN1
																			.getStartDate()
																			.compareTo(
																					xCustomerVehicleRoleJPN2.getStartDate());
																}
															});
													
													Timestamp Person1RoleLastModifiedDt = DateFormatter.getTimestamp(Party1XCustomerVehicleRoleBObj.getXCustomerVehicleRoleJPNLastUpdateDate());
													Timestamp Person2RoleLastModifiedDt = DateFormatter.getTimestamp(Party2XCustomerVehicleRoleBObj.getXCustomerVehicleRoleJPNLastUpdateDate());
													if(Person2RoleLastModifiedDt.after(Person1RoleLastModifiedDt))
													{
														Party2XCustomerVehicleRoleBObj.setStartDate(tempVecXCustomerVehicleRoleJPNBObj.get(0).getStartDate());
														if(tempVecXCustomerVehicleRoleJPNBObj.get(0).getEndDate()!=null && 
																tempVecXCustomerVehicleRoleJPNBObj.get(1).getEndDate()!=null)
														{
															Timestamp role1EndDt = DateFormatter.getTimestamp(tempVecXCustomerVehicleRoleJPNBObj.get(0).getEndDate());
															Timestamp role2EndDt = DateFormatter.getTimestamp(tempVecXCustomerVehicleRoleJPNBObj.get(1).getEndDate());
															
															if(role2EndDt.after(role1EndDt))
															{
																Party2XCustomerVehicleRoleBObj.setEndDate(tempVecXCustomerVehicleRoleJPNBObj.get(1).getEndDate());
															}
															else
															{
																Party2XCustomerVehicleRoleBObj.setEndDate(tempVecXCustomerVehicleRoleJPNBObj.get(0).getEndDate());
															}
														}
														else
														{
															Party2XCustomerVehicleRoleBObj.setEndDate(null);
														}
														xCustomerVehicleRoleMap.put(Party2XCustomerVehicleRoleBObj.getVehicleRoleType(), Party2XCustomerVehicleRoleBObj);
													}
													else
													{
														Party1XCustomerVehicleRoleBObj.setStartDate(tempVecXCustomerVehicleRoleJPNBObj.get(0).getStartDate());
														if(tempVecXCustomerVehicleRoleJPNBObj.get(0).getEndDate()!=null && 
																tempVecXCustomerVehicleRoleJPNBObj.get(1).getEndDate()!=null)
														{
															Timestamp role1EndDt = DateFormatter.getTimestamp(tempVecXCustomerVehicleRoleJPNBObj.get(0).getEndDate());
															Timestamp role2EndDt = DateFormatter.getTimestamp(tempVecXCustomerVehicleRoleJPNBObj.get(1).getEndDate());
															
															if(role2EndDt.after(role1EndDt))
															{
																Party1XCustomerVehicleRoleBObj.setEndDate(tempVecXCustomerVehicleRoleJPNBObj.get(1).getEndDate());
															}
															else
															{
																Party1XCustomerVehicleRoleBObj.setEndDate(tempVecXCustomerVehicleRoleJPNBObj.get(0).getEndDate());
															}
														}
														else
														{
															Party1XCustomerVehicleRoleBObj.setEndDate(null);
														}
														xCustomerVehicleRoleMap.put(Party1XCustomerVehicleRoleBObj.getVehicleRoleType(), Party1XCustomerVehicleRoleBObj);
													}
													
												}
											}
											
										}
										
										for (Map.Entry<String, XCustomerVehicleRoleJPNBObj> entry : xCustomerVehicleRoleMap.entrySet()) 
										{
											vecFinalVehicleRoleBObjs.add(entry.getValue());
										}
										

										Timestamp person1ModifiedDt = DateFormatter
												.getTimestamp(xContVehicleBObjInMap
														.getXCustomerVehicleJPNLastUpdateDate());

										Timestamp person2ModifiedDt = DateFormatter
												.getTimestamp(xCustomerVehicleJPNBObj
														.getXCustomerVehicleJPNLastUpdateDate());
										
										if (person1ModifiedDt.after(person2ModifiedDt)) {
											xContVehicleBObjInMap.getItemsXCustomerVehicleRoleJPNBObj().clear();
											xContVehicleBObjInMap.getItemsXCustomerVehicleRoleJPNBObj().addAll(vecFinalVehicleRoleBObjs);
											xContVehicleBObjInMap.setStartDate(tempVecXCustomerVehicleJPNBObj.get(0).getStartDate());
											
											
											if(xContVehicleBObjInMap.getVehicleSalesType()!=null && xCustomerVehicleJPNBObj.getVehicleSalesType()!=null)
											{
												if(!xContVehicleBObjInMap.getVehicleSalesType().equalsIgnoreCase(ExternalRuleConstant.VEHICLE_SALES_TYPE_UNKNOWN)
														&& !xCustomerVehicleJPNBObj.getVehicleSalesType().equalsIgnoreCase(ExternalRuleConstant.VEHICLE_SALES_TYPE_UNKNOWN))
												{
													xContVehicleBObjInMap.setVehicleSalesType(tempVecXCustomerVehicleJPNBObj.get(0).getVehicleSalesType());
												}
												else if(xContVehicleBObjInMap.getVehicleSalesType().equalsIgnoreCase(ExternalRuleConstant.VEHICLE_SALES_TYPE_UNKNOWN)
														&& !xCustomerVehicleJPNBObj.getVehicleSalesType().equalsIgnoreCase(ExternalRuleConstant.VEHICLE_SALES_TYPE_UNKNOWN))
												{
													xContVehicleBObjInMap.setVehicleSalesType(xCustomerVehicleJPNBObj.getVehicleSalesType());
												}
											}
											
											else if(xContVehicleBObjInMap.getVehicleSalesType()==null && xCustomerVehicleJPNBObj.getVehicleSalesType()!=null)
											{
												xContVehicleBObjInMap.setVehicleSalesType(xCustomerVehicleJPNBObj.getVehicleSalesType());
											}
											
											if(tempVecXCustomerVehicleJPNBObj.get(0).getEndDate()!=null && tempVecXCustomerVehicleJPNBObj.get(1).getEndDate()!=null)
											{
											java.util.Date xCustomerVehicleJPN2EndDt = simpleDateFmt.parse(tempVecXCustomerVehicleJPNBObj.get(1).getEndDate());
											if(xCustomerVehicleJPN2EndDt.after(xCustomerVehicleJPN1EndDt))
											{
											xContVehicleBObjInMap.setEndDate(tempVecXCustomerVehicleJPNBObj.get(1).getEndDate());
											}
											else
											{
											xContVehicleBObjInMap.setEndDate(tempVecXCustomerVehicleJPNBObj.get(0).getEndDate());
											}
											}
											else if(tempVecXCustomerVehicleJPNBObj.get(0).getEndDate()==null)
											{
												xContVehicleBObjInMap.setEndDate(null);
											}
											else
											{
												xContVehicleBObjInMap.setEndDate(tempVecXCustomerVehicleJPNBObj.get(1).getEndDate());
											}
											xCustomerVehicleMap.put((xContVehicleBObjInMap
													.getXVehicleJPNBObj().getGlobalVIN()) + xContVehicleBObjInMap
													.getXVehicleJPNBObj().getVehicleType(),
													xContVehicleBObjInMap);
											
										}

										else {
											xCustomerVehicleJPNBObj.getItemsXCustomerVehicleRoleJPNBObj().clear();
											xCustomerVehicleJPNBObj.getItemsXCustomerVehicleRoleJPNBObj().addAll(vecFinalVehicleRoleBObjs);
											xCustomerVehicleJPNBObj.setStartDate(tempVecXCustomerVehicleJPNBObj.get(0).getStartDate());
											
											if(xContVehicleBObjInMap.getVehicleSalesType()!=null && xCustomerVehicleJPNBObj.getVehicleSalesType()!=null)
											{
												if(!xContVehicleBObjInMap.getVehicleSalesType().equalsIgnoreCase(ExternalRuleConstant.VEHICLE_SALES_TYPE_UNKNOWN)
														&& !xCustomerVehicleJPNBObj.getVehicleSalesType().equalsIgnoreCase(ExternalRuleConstant.VEHICLE_SALES_TYPE_UNKNOWN))
												{
													xCustomerVehicleJPNBObj.setVehicleSalesType(tempVecXCustomerVehicleJPNBObj.get(0).getVehicleSalesType());
												}
												else if(xCustomerVehicleJPNBObj.getVehicleSalesType().equalsIgnoreCase(ExternalRuleConstant.VEHICLE_SALES_TYPE_UNKNOWN)
														&& !xContVehicleBObjInMap.getVehicleSalesType().equalsIgnoreCase(ExternalRuleConstant.VEHICLE_SALES_TYPE_UNKNOWN))
												{
													xCustomerVehicleJPNBObj.setVehicleSalesType(xContVehicleBObjInMap.getVehicleSalesType());
												}
											}
											
											else if(xContVehicleBObjInMap.getVehicleSalesType()!=null && xCustomerVehicleJPNBObj.getVehicleSalesType()==null)
											{
												xCustomerVehicleJPNBObj.setVehicleSalesType(xContVehicleBObjInMap.getVehicleSalesType());
											}
						
											if(tempVecXCustomerVehicleJPNBObj.get(0).getEndDate()!=null && tempVecXCustomerVehicleJPNBObj.get(1).getEndDate()!=null)
											{
											java.util.Date xCustomerVehicleJPN2EndDt = simpleDateFmt.parse(tempVecXCustomerVehicleJPNBObj.get(1).getEndDate());
											if(xCustomerVehicleJPN2EndDt.after(xCustomerVehicleJPN1EndDt))
											{
												xCustomerVehicleJPNBObj.setEndDate(tempVecXCustomerVehicleJPNBObj.get(1).getEndDate());
											}
											else
											{
												xCustomerVehicleJPNBObj.setEndDate(tempVecXCustomerVehicleJPNBObj.get(0).getEndDate());
											}
											}
											else if(tempVecXCustomerVehicleJPNBObj.get(0).getEndDate()==null)
											{
												xCustomerVehicleJPNBObj.setEndDate(null);
											}
											else
											{
												xCustomerVehicleJPNBObj.setEndDate(tempVecXCustomerVehicleJPNBObj.get(1).getEndDate());
											}
											xCustomerVehicleMap.put((xCustomerVehicleJPNBObj
													.getXVehicleJPNBObj().getGlobalVIN()) +xCustomerVehicleJPNBObj
													.getXVehicleJPNBObj().getVehicleType() ,
													xCustomerVehicleJPNBObj);
											
										}

									}
										else
										{
											VecUnmergedXCustomerVehicleJPNBObj.add(xContVehicleBObjInMap);
											VecUnmergedXCustomerVehicleJPNBObj.add(xCustomerVehicleJPNBObj);
											
											xCustomerVehicleMap.remove((xCustomerVehicleJPNBObj
													.getXVehicleJPNBObj().getGlobalVIN()) +  xCustomerVehicleJPNBObj
													.getXVehicleJPNBObj().getVehicleType());
										}
									} 
									else {

										xCustomerVehicleMap.put((xCustomerVehicleJPNBObj
												.getXVehicleJPNBObj().getGlobalVIN()) +  xCustomerVehicleJPNBObj.getXVehicleJPNBObj().getVehicleType() ,
												xCustomerVehicleJPNBObj);
									}

								}
							}
														
						}
					}
				}
			}

			
			
			// Handle final CVR 
			
			for (Map.Entry<String, XCustomerVehicleJPNBObj> entry : xCustomerVehicleMap
					.entrySet()) 
			{
				Vector<XCustomerVehicleJPNBObj> vectempXCustomerVehicleBObjs = new Vector<XCustomerVehicleJPNBObj>();  
				XCustomerVehicleJPNBObj tempXCustomerVehicleBObj = entry.getValue();
				vectempXCustomerVehicleBObjs.add(tempXCustomerVehicleBObj);
				finalCustomerVehicleMap.put(entry.getKey(), vectempXCustomerVehicleBObjs);
			}
				
			for(XCustomerVehicleJPNBObj tempXCustomerVehicleJPNBObj:VecUnmergedXCustomerVehicleJPNBObj)
			{
				if(finalCustomerVehicleMap.containsKey(tempXCustomerVehicleJPNBObj.getXVehicleJPNBObj().getGlobalVIN()+
						tempXCustomerVehicleJPNBObj.getXVehicleJPNBObj().getVehicleType()+tempXCustomerVehicleJPNBObj.getRetailerId()
						))
				{
					finalCustomerVehicleMap.get(tempXCustomerVehicleJPNBObj.getXVehicleJPNBObj().getGlobalVIN()+
						tempXCustomerVehicleJPNBObj.getXVehicleJPNBObj().getVehicleType()+tempXCustomerVehicleJPNBObj.getRetailerId()).
						add(tempXCustomerVehicleJPNBObj);
				}
				else
				{
					Vector<XCustomerVehicleJPNBObj> vectempXCustomerVehicleBObjs = new Vector<XCustomerVehicleJPNBObj>(); 
					vectempXCustomerVehicleBObjs.add(tempXCustomerVehicleJPNBObj);
					finalCustomerVehicleMap.put(tempXCustomerVehicleJPNBObj.getXVehicleJPNBObj().getGlobalVIN()+
						tempXCustomerVehicleJPNBObj.getXVehicleJPNBObj().getVehicleType()+tempXCustomerVehicleJPNBObj.getRetailerId(), vectempXCustomerVehicleBObjs);
				}
			}
			
			for(Map.Entry<String, Vector<XCustomerVehicleJPNBObj>> entry : finalCustomerVehicleMap
					.entrySet())
			{
				
				Collections.sort(entry.getValue(),
						new Comparator<XCustomerVehicleJPNBObj>() {// Ascending sort
															// - for delta
															// load
							public int compare(XCustomerVehicleJPNBObj xCustomerVehicleJPN1,
									XCustomerVehicleJPNBObj xCustomerVehicleJPN2) {
								
								return xCustomerVehicleJPN1
										.getStartDate()
										.compareTo(
												xCustomerVehicleJPN2.getStartDate());
							}
						});
			}
			
			for(Map.Entry<String, Vector<XCustomerVehicleJPNBObj>> entry : finalCustomerVehicleMap
					.entrySet())
			{
				Vector<XCustomerVehicleJPNBObj> vecUnmergedXCustomerVehicleBObjs = new Vector<XCustomerVehicleJPNBObj>(); 
				vecUnmergedXCustomerVehicleBObjs = entry.getValue();
				
				for(int i=0;i<vecUnmergedXCustomerVehicleBObjs.size();i++)
				 {
					 for(int j =i+1;j<vecUnmergedXCustomerVehicleBObjs.size();j++)
					 {
						    SimpleDateFormat simpleDateFmt = new SimpleDateFormat("yyyy-MM-dd");
						    java.util.Date xCustomerVehicleJPN1EndDt =null;
							java.util.Date xCustomerVehicleJPN2StartDt =null;
							
							toBeMerged = false;
							if(vecUnmergedXCustomerVehicleBObjs.get(0).getEndDate()!=null && 
									vecUnmergedXCustomerVehicleBObjs.get(1).getStartDate()!=null)
							{
							xCustomerVehicleJPN1EndDt =simpleDateFmt.parse(vecUnmergedXCustomerVehicleBObjs.get(0).getEndDate());
							xCustomerVehicleJPN2StartDt =simpleDateFmt.parse(vecUnmergedXCustomerVehicleBObjs.get(1).getStartDate());
							
							long difference = xCustomerVehicleJPN2StartDt.getTime() - xCustomerVehicleJPN1EndDt.getTime();
							float daysBetween = (difference / (1000*60*60*24));
							if(daysBetween<=1)
							{
								toBeMerged = true;
							}
							}
							else if(vecUnmergedXCustomerVehicleBObjs.get(0).getEndDate()==null)
							{
								toBeMerged = true;
							}
							
							if(toBeMerged)
							{
								//toBeMerged = true;
								Vector<XCustomerVehicleRoleJPNBObj>vectempParty1XCustomerVehicleRoleBObjs =new Vector<XCustomerVehicleRoleJPNBObj>();
								Vector<XCustomerVehicleRoleJPNBObj>vectempParty2XCustomerVehicleRoleBObjs =new Vector<XCustomerVehicleRoleJPNBObj>();
								vectempParty1XCustomerVehicleRoleBObjs = vecUnmergedXCustomerVehicleBObjs.get(i).getItemsXCustomerVehicleRoleJPNBObj();
								vectempParty2XCustomerVehicleRoleBObjs = vecUnmergedXCustomerVehicleBObjs.get(j).getItemsXCustomerVehicleRoleJPNBObj();
								HashMap<String, XCustomerVehicleRoleJPNBObj> xCustomerVehicleRoleMap = new HashMap<String, XCustomerVehicleRoleJPNBObj>();
								
								Vector<XCustomerVehicleRoleJPNBObj> vecFinalVehicleRoleBObjs = new Vector<XCustomerVehicleRoleJPNBObj>();
								
								for(XCustomerVehicleRoleJPNBObj Party1XCustomerVehicleRoleBObj :vectempParty1XCustomerVehicleRoleBObjs)
								{
									if(!xCustomerVehicleRoleMap.containsKey(Party1XCustomerVehicleRoleBObj.getVehicleRoleType()))
									{
										xCustomerVehicleRoleMap.put(Party1XCustomerVehicleRoleBObj.getVehicleRoleType(), Party1XCustomerVehicleRoleBObj);
									}
								}
								for(XCustomerVehicleRoleJPNBObj Party2XCustomerVehicleRoleBObj :vectempParty2XCustomerVehicleRoleBObjs)
								{
									if(!xCustomerVehicleRoleMap.containsKey(Party2XCustomerVehicleRoleBObj.getVehicleRoleType()))
									{
										xCustomerVehicleRoleMap.put(Party2XCustomerVehicleRoleBObj.getVehicleRoleType(), Party2XCustomerVehicleRoleBObj);
									}
									else
									{
										XCustomerVehicleRoleJPNBObj Party1XCustomerVehicleRoleBObj = xCustomerVehicleRoleMap.get(Party2XCustomerVehicleRoleBObj.getVehicleRoleType());
										
										/*Timestamp Person1RoleLastModifiedDt = DateFormatter.getTimestamp(Party1XCustomerVehicleRoleBObj.getXCustomerVehicleRoleJPNLastUpdateDate());
										Timestamp Person2RoleLastModifiedDt = DateFormatter.getTimestamp(Party2XCustomerVehicleRoleBObj.getXCustomerVehicleRoleJPNLastUpdateDate());
										if(Person2RoleLastModifiedDt.after(Person1RoleLastModifiedDt))
										{
											xCustomerVehicleRoleMap.put(Party2XCustomerVehicleRoleBObj.getVehicleRoleType(), Party2XCustomerVehicleRoleBObj);
										}*/
										
										Vector <XCustomerVehicleRoleJPNBObj> tempVecXCustomerVehicleRoleJPNBObj = new Vector<XCustomerVehicleRoleJPNBObj>();
										tempVecXCustomerVehicleRoleJPNBObj.add(Party1XCustomerVehicleRoleBObj);
										tempVecXCustomerVehicleRoleJPNBObj.add(Party2XCustomerVehicleRoleBObj);
										
										if(Party1XCustomerVehicleRoleBObj.getStartDate()!=null && Party2XCustomerVehicleRoleBObj.getStartDate()!=null)
										{
											Collections.sort(tempVecXCustomerVehicleRoleJPNBObj,
													new Comparator<XCustomerVehicleRoleJPNBObj>() {// Ascending sort
																						// - for delta
																						// load
														public int compare(XCustomerVehicleRoleJPNBObj xCustomerVehicleRoleJPN1,
																XCustomerVehicleRoleJPNBObj xCustomerVehicleRoleJPN2) {
															
															return xCustomerVehicleRoleJPN1
																	.getStartDate()
																	.compareTo(
																			xCustomerVehicleRoleJPN2.getStartDate());
														}
													});
											
											Timestamp Person1RoleLastModifiedDt = DateFormatter.getTimestamp(Party1XCustomerVehicleRoleBObj.getXCustomerVehicleRoleJPNLastUpdateDate());
											Timestamp Person2RoleLastModifiedDt = DateFormatter.getTimestamp(Party2XCustomerVehicleRoleBObj.getXCustomerVehicleRoleJPNLastUpdateDate());
											if(Person2RoleLastModifiedDt.after(Person1RoleLastModifiedDt))
											{
												Party2XCustomerVehicleRoleBObj.setStartDate(tempVecXCustomerVehicleRoleJPNBObj.get(0).getStartDate());
												if(tempVecXCustomerVehicleRoleJPNBObj.get(0).getEndDate()!=null && 
														tempVecXCustomerVehicleRoleJPNBObj.get(1).getEndDate()!=null)
												{
													Timestamp role1EndDt = DateFormatter.getTimestamp(tempVecXCustomerVehicleRoleJPNBObj.get(0).getEndDate());
													Timestamp role2EndDt = DateFormatter.getTimestamp(tempVecXCustomerVehicleRoleJPNBObj.get(1).getEndDate());
													
													if(role2EndDt.after(role1EndDt))
													{
														Party2XCustomerVehicleRoleBObj.setEndDate(tempVecXCustomerVehicleRoleJPNBObj.get(1).getEndDate());
													}
													else
													{
														Party2XCustomerVehicleRoleBObj.setEndDate(tempVecXCustomerVehicleRoleJPNBObj.get(0).getEndDate());
													}
												}
												else
												{
													Party2XCustomerVehicleRoleBObj.setEndDate(null);
												}
												xCustomerVehicleRoleMap.put(Party2XCustomerVehicleRoleBObj.getVehicleRoleType(), Party2XCustomerVehicleRoleBObj);
											}
											else
											{
												Party1XCustomerVehicleRoleBObj.setStartDate(tempVecXCustomerVehicleRoleJPNBObj.get(0).getStartDate());
												if(tempVecXCustomerVehicleRoleJPNBObj.get(0).getEndDate()!=null && 
														tempVecXCustomerVehicleRoleJPNBObj.get(1).getEndDate()!=null)
												{
													Timestamp role1EndDt = DateFormatter.getTimestamp(tempVecXCustomerVehicleRoleJPNBObj.get(0).getEndDate());
													Timestamp role2EndDt = DateFormatter.getTimestamp(tempVecXCustomerVehicleRoleJPNBObj.get(1).getEndDate());
													
													if(role2EndDt.after(role1EndDt))
													{
														Party1XCustomerVehicleRoleBObj.setEndDate(tempVecXCustomerVehicleRoleJPNBObj.get(1).getEndDate());
													}
													else
													{
														Party1XCustomerVehicleRoleBObj.setEndDate(tempVecXCustomerVehicleRoleJPNBObj.get(0).getEndDate());
													}
												}
												else
												{
													Party1XCustomerVehicleRoleBObj.setEndDate(null);
												}
												xCustomerVehicleRoleMap.put(Party1XCustomerVehicleRoleBObj.getVehicleRoleType(), Party1XCustomerVehicleRoleBObj);
											}
											
										}
									}
									
								}
								
								for (Map.Entry<String, XCustomerVehicleRoleJPNBObj> entry1 : xCustomerVehicleRoleMap.entrySet()) 
								{
									vecFinalVehicleRoleBObjs.add(entry1.getValue());
								}
								
								Timestamp person1ModifiedDt = DateFormatter
										.getTimestamp(vecUnmergedXCustomerVehicleBObjs.get(i)
												.getXCustomerVehicleJPNLastUpdateDate());

								Timestamp person2ModifiedDt = DateFormatter
										.getTimestamp(vecUnmergedXCustomerVehicleBObjs.get(j)
												.getXCustomerVehicleJPNLastUpdateDate());
								
								if (person1ModifiedDt.after(person2ModifiedDt)) {
									vecUnmergedXCustomerVehicleBObjs.get(i).getItemsXCustomerVehicleRoleJPNBObj().clear();
									vecUnmergedXCustomerVehicleBObjs.get(i).getItemsXCustomerVehicleRoleJPNBObj().addAll(vecFinalVehicleRoleBObjs);
									vecUnmergedXCustomerVehicleBObjs.get(i).setStartDate(vecUnmergedXCustomerVehicleBObjs.get(i).getStartDate());
									//vecUnmergedXCustomerVehicleBObjs.get(i).setEndDate(vecUnmergedXCustomerVehicleBObjs.get(j).getEndDate());
									
									
									if(vecUnmergedXCustomerVehicleBObjs.get(i).getVehicleSalesType()!=null && vecUnmergedXCustomerVehicleBObjs.get(j).getVehicleSalesType()!=null)
									{
										
										if(vecUnmergedXCustomerVehicleBObjs.get(i).getVehicleSalesType().equalsIgnoreCase(ExternalRuleConstant.VEHICLE_SALES_TYPE_UNKNOWN)
												&& !vecUnmergedXCustomerVehicleBObjs.get(j).getVehicleSalesType().equalsIgnoreCase(ExternalRuleConstant.VEHICLE_SALES_TYPE_UNKNOWN))
										{
											vecUnmergedXCustomerVehicleBObjs.get(i).setVehicleSalesType(vecUnmergedXCustomerVehicleBObjs.get(j).getVehicleSalesType());
										}
									}
									
									
									else if(vecUnmergedXCustomerVehicleBObjs.get(i).getVehicleSalesType()==null && vecUnmergedXCustomerVehicleBObjs.get(j).getVehicleSalesType()!=null)
									{
										vecUnmergedXCustomerVehicleBObjs.get(i).setVehicleSalesType(vecUnmergedXCustomerVehicleBObjs.get(j).getVehicleSalesType());
									}
									
									if(vecUnmergedXCustomerVehicleBObjs.get(i).getEndDate()!=null && vecUnmergedXCustomerVehicleBObjs.get(j).getEndDate()!=null)
									{
									java.util.Date xCustomerVehicleJPN2EndDt = simpleDateFmt.parse(vecUnmergedXCustomerVehicleBObjs.get(j).getEndDate());
									if(xCustomerVehicleJPN2EndDt.after(xCustomerVehicleJPN1EndDt))
									{
										vecUnmergedXCustomerVehicleBObjs.get(i).setEndDate(vecUnmergedXCustomerVehicleBObjs.get(j).getEndDate());
									}
									else
									{
										vecUnmergedXCustomerVehicleBObjs.get(i).setEndDate(vecUnmergedXCustomerVehicleBObjs.get(i).getEndDate());
									}
									}
									else if(vecUnmergedXCustomerVehicleBObjs.get(i).getEndDate()==null)
									{
										vecUnmergedXCustomerVehicleBObjs.get(i).setEndDate(null);
									}
									else
									{
										vecUnmergedXCustomerVehicleBObjs.get(i).setEndDate(vecUnmergedXCustomerVehicleBObjs.get(j).getEndDate());
									}
									
									vecUnmergedXCustomerVehicleBObjs.remove(j);
									i=i-1;
									break;
								}
								else {
									vecUnmergedXCustomerVehicleBObjs.get(j).getItemsXCustomerVehicleRoleJPNBObj().clear();
									vecUnmergedXCustomerVehicleBObjs.get(j).getItemsXCustomerVehicleRoleJPNBObj().addAll(vecFinalVehicleRoleBObjs);
									vecUnmergedXCustomerVehicleBObjs.get(j).setStartDate(vecUnmergedXCustomerVehicleBObjs.get(i).getStartDate());
									//vecUnmergedXCustomerVehicleBObjs.get(j).setEndDate(vecUnmergedXCustomerVehicleBObjs.get(j).getEndDate());
									
									if(vecUnmergedXCustomerVehicleBObjs.get(i).getVehicleSalesType()!=null && vecUnmergedXCustomerVehicleBObjs.get(j).getVehicleSalesType()!=null)
									{
										
										if(vecUnmergedXCustomerVehicleBObjs.get(j).getVehicleSalesType().equalsIgnoreCase(ExternalRuleConstant.VEHICLE_SALES_TYPE_UNKNOWN)
												&& !vecUnmergedXCustomerVehicleBObjs.get(i).getVehicleSalesType().equalsIgnoreCase(ExternalRuleConstant.VEHICLE_SALES_TYPE_UNKNOWN))
										{
											vecUnmergedXCustomerVehicleBObjs.get(j).setVehicleSalesType(vecUnmergedXCustomerVehicleBObjs.get(i).getVehicleSalesType());
										}
									}
									
									else if(vecUnmergedXCustomerVehicleBObjs.get(j).getVehicleSalesType()==null && vecUnmergedXCustomerVehicleBObjs.get(i).getVehicleSalesType()!=null)
									{
										vecUnmergedXCustomerVehicleBObjs.get(j).setVehicleSalesType(vecUnmergedXCustomerVehicleBObjs.get(i).getVehicleSalesType());
									}
									
									if(vecUnmergedXCustomerVehicleBObjs.get(i).getEndDate()!=null && vecUnmergedXCustomerVehicleBObjs.get(j).getEndDate()!=null)
									{
									java.util.Date xCustomerVehicleJPN2EndDt = simpleDateFmt.parse(vecUnmergedXCustomerVehicleBObjs.get(j).getEndDate());
									if(xCustomerVehicleJPN2EndDt.after(xCustomerVehicleJPN1EndDt))
									{
										vecUnmergedXCustomerVehicleBObjs.get(j).setEndDate(vecUnmergedXCustomerVehicleBObjs.get(j).getEndDate());
									}
									else
									{
										vecUnmergedXCustomerVehicleBObjs.get(j).setEndDate(vecUnmergedXCustomerVehicleBObjs.get(i).getEndDate());
									}
									}
									else if(vecUnmergedXCustomerVehicleBObjs.get(i).getEndDate()==null)
									{
										vecUnmergedXCustomerVehicleBObjs.get(j).setEndDate(null);
									}
									else
									{
										vecUnmergedXCustomerVehicleBObjs.get(j).setEndDate(vecUnmergedXCustomerVehicleBObjs.get(j).getEndDate());
									}
									
									vecUnmergedXCustomerVehicleBObjs.set(i, vecUnmergedXCustomerVehicleBObjs.get(j));
									vecUnmergedXCustomerVehicleBObjs.remove(j);
									i=i-1;
									break;
								}
							}
							else
							{
								break;
							}
					 }
				 }
			}
			
			//if(toBeMerged)
			//{
			for (Map.Entry<String, Vector<XCustomerVehicleJPNBObj>> entry : finalCustomerVehicleMap
					.entrySet()) {
							
				Vector<XCustomerVehicleJPNBObj> tempXCustomerVehicleBObjs = entry.getValue();
				
				for(XCustomerVehicleJPNBObj tempXCustomerVehicleBObj :tempXCustomerVehicleBObjs)
				{
					XCustomerVehicleJPNBObj survivedXCustomerVehicleBObj = new XCustomerVehicleJPNBObj();
					survivedXCustomerVehicleBObj = tempXCustomerVehicleBObj;
					survivedXCustomerVehicleBObj.setContId(collapsedPartyId);
					survivedXCustomerVehicleBObj.setControl(control);
					if(tempXCustomerVehicleBObj.getXVehicleJPNBObj()!=null)
					{
					globalVIN = survivedXCustomerVehicleBObj.getXVehicleJPNBObj()
							.getGlobalVIN();
					}
					//vecDBVehicleBObj = vehicleObjectByGVIN(globalVIN, control);
					DWLResponse response2 = dseaAdditionsExtsComponent.getXVehicleJPNByGlobalVIN(globalVIN, control);
					XVehicleJPNBObj dbVehicleJPNBObj = (XVehicleJPNBObj)response2.getData();
					//System.out.println("Survived CVR:" + survivedXCustomerVehicleBObj.toXML());
					
					if (dbVehicleJPNBObj == null) {
						response = dseaAdditionsExtsComponent
								.addXCustomerVehicleJPN(survivedXCustomerVehicleBObj);
					} else {
						//survivedXCustomerVehicleBObj.getXVehicleJPNBObj().setXVehicleJPNpkId(dbVehicleJPNBObj.getXVehicleJPNpkId());
						//survivedXCustomerVehicleBObj.getXVehicleJPNBObj().setXVehicleJPNLastUpdateDate(dbVehicleJPNBObj.getXVehicleJPNLastUpdateDate());
						survivedXCustomerVehicleBObj.setVehicleId(dbVehicleJPNBObj.getXVehicleJPNpkId());
						survivedXCustomerVehicleBObj.setXVehicleJPNBObj(null);
						String objectToString =((XCustomerVehicleJPNBObj)survivedXCustomerVehicleBObj).toXML("MDM", "MDMDomains.xsd", 0, null, false);	
				  		//System.out.println("Survived CVR:"+objectToString);
						response = dseaAdditionsExtsComponent.addXCustomerVehicleJPN(survivedXCustomerVehicleBObj);
					}
					if (response.getStatus().getStatus() == DWLStatus.FATAL) {
						throw new BusinessProxyException();
					}
				}
				
				
			}
		//}
		}
		
		
		/*private boolean checkIfCVRActive(String endDate) throws Exception
		{
			SimpleDateFormat simpleDateFmt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
			if(endDate!=null)
			{
			Date parsedTimeStamp =simpleDateFmt.parse(endDate);
			Timestamp timeStamp = new Timestamp(parsedTimeStamp.getTime()) ;
			if(timeStamp.after(DWLDateTimeUtilities.getCurrentSystemTimeAsTimestamp()))
			{
				return true;
			}
			else
			{
				return false;
			}
			}
			else
			{
				 return true;
			}
		}*/
		
		private HashMap<String, XCustomerVehicleJPNBObj> checkForActiveCVR(Vector<XCustomerVehicleJPNBObj> vecXCustomerVehicleJPNBObjs) throws Exception
		{
			/*for(XCustomerVehicleJPNBObj xCustomerVehicleJPNBObj :vecXCustomerVehicleJPNBObjs)
			{
				SimpleDateFormat simpleDateFmt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
				if(xCustomerVehicleJPNBObj.getEndDate()!=null)
				{
				Date parsedTimeStamp =simpleDateFmt.parse(xCustomerVehicleJPNBObj.getEndDate());
				Timestamp timeStamp = new Timestamp(parsedTimeStamp.getTime()) ;
				if(timeStamp.after(DWLDateTimeUtilities.getCurrentSystemTimeAsTimestamp()))
				{
					return xCustomerVehicleJPNBObj;
				}
				else
				{
					return null;
				}
				}
				else
				{
					 return xCustomerVehicleJPNBObj;
				}
			}
			return null;*/
			HashMap<String, XCustomerVehicleJPNBObj> xCustomerVehicleMap = new HashMap<String, XCustomerVehicleJPNBObj>();
			SimpleDateFormat simpleDateFmt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
			for(XCustomerVehicleJPNBObj xCustomerVehicleJPNBObj :vecXCustomerVehicleJPNBObjs)
			{
				if (!xCustomerVehicleMap.containsKey((xCustomerVehicleJPNBObj
						.getXVehicleJPNBObj().getGlobalVIN()) + xCustomerVehicleJPNBObj
						.getXVehicleJPNBObj().getVehicleType() +xCustomerVehicleJPNBObj.getRetailerId())) 
				{
					xCustomerVehicleMap.put((xCustomerVehicleJPNBObj
							.getXVehicleJPNBObj().getGlobalVIN()) +  xCustomerVehicleJPNBObj
							.getXVehicleJPNBObj().getVehicleType() + xCustomerVehicleJPNBObj.getRetailerId() ,
							xCustomerVehicleJPNBObj);
								
				} 
				else
				{
					XCustomerVehicleJPNBObj xContVehicleBObjInMap = xCustomerVehicleMap.get((xCustomerVehicleJPNBObj
							.getXVehicleJPNBObj().getGlobalVIN()) +  xCustomerVehicleJPNBObj
							.getXVehicleJPNBObj().getVehicleType() + xCustomerVehicleJPNBObj.getRetailerId());
					
					if(xContVehicleBObjInMap.getEndDate()==null && xCustomerVehicleJPNBObj.getEndDate()==null)
					{
						Date parsedTimeStampReq =simpleDateFmt.parse(xCustomerVehicleJPNBObj.getStartDate());
						Timestamp timeStampReq = new Timestamp(parsedTimeStampReq.getTime()) ;
						Date parsedTimeStampMap =simpleDateFmt.parse(xContVehicleBObjInMap.getStartDate());
						Timestamp timeStampMap = new Timestamp(parsedTimeStampMap.getTime()) ;
						
						if(timeStampMap.after(timeStampReq))
						{
							xCustomerVehicleMap.put((xCustomerVehicleJPNBObj
									.getXVehicleJPNBObj().getGlobalVIN()) +  xCustomerVehicleJPNBObj
									.getXVehicleJPNBObj().getVehicleType()+ xCustomerVehicleJPNBObj.getRetailerId() ,
									xCustomerVehicleJPNBObj);
						}
					}
					else if(xContVehicleBObjInMap.getEndDate()!=null && xCustomerVehicleJPNBObj.getEndDate()!=null)
					{
						
						Date parsedTimeStampReq =simpleDateFmt.parse(xCustomerVehicleJPNBObj.getEndDate());
						Timestamp timeStampReq = new Timestamp(parsedTimeStampReq.getTime()) ;
						Date parsedTimeStampMap =simpleDateFmt.parse(xContVehicleBObjInMap.getEndDate());
						Timestamp timeStampMap = new Timestamp(parsedTimeStampMap.getTime()) ;
						
						if(timeStampMap.before(timeStampReq))
						{
							xCustomerVehicleMap.put((xCustomerVehicleJPNBObj
									.getXVehicleJPNBObj().getGlobalVIN()) +  xCustomerVehicleJPNBObj
									.getXVehicleJPNBObj().getVehicleType() + xCustomerVehicleJPNBObj.getRetailerId() ,
									xCustomerVehicleJPNBObj);
						}
						
					}
					else
					{
						if(xCustomerVehicleJPNBObj.getEndDate()==null)
						{
							xCustomerVehicleMap.put((xCustomerVehicleJPNBObj
									.getXVehicleJPNBObj().getGlobalVIN()) +  xCustomerVehicleJPNBObj
									.getXVehicleJPNBObj().getVehicleType() + xCustomerVehicleJPNBObj.getRetailerId() ,
									xCustomerVehicleJPNBObj);
						}
					}
				}
			}
			return xCustomerVehicleMap;
		}
		
		public void survivedCCRDetailsForJapan(Vector<TCRMPartyBObj> vecParties,TCRMPartyBObj collapsedPartyBObj, DWLControl control) throws Exception 
		{
			String partytId = null;
			String partyType = null;
			Vector<TCRMPartyRelationshipBObj> vecPartyRelationshipResponse = new Vector<TCRMPartyRelationshipBObj>();
			TCRMPartyComponent partyComponent = new TCRMPartyComponent();
			String mapKey = null;
			String requestCompanyId = null;
			String existingCompanyId = null;
			String requestRelationshipType = null;
			String existingRelationshipType = null;
			String requestPersonRetailerCode = null;
			String existingPersonRetailerCode = null;
			String requestPersonContId = null;
			String existingPersonContId = null;
			String requestOrgRetailerCode = null;
			String existingOrgRetailerCode = null;
			XContactRelBObjExt xRelRequestObject = new XContactRelBObjExt();
			HashMap<String, XContactRelBObjExt> xCustomerRelationshipMap = new HashMap<String, XContactRelBObjExt>();
			String collapsedPartyId = collapsedPartyBObj.getPartyId();
			
			for (TCRMPartyBObj partyBObj : vecParties) 
			{
				partyType = partyBObj.getPartyType();
				partytId = partyBObj.getPartyId();
				
				//If suspect parties are Person 
				if(partyType!=null && partyType.equalsIgnoreCase("P"))
				{
						
					//Get all Relationships with the request Person cont id
					vecPartyRelationshipResponse = partyComponent.getAllPartyRelationships(partytId, "ACTIVE",control);
					
					if (vecPartyRelationshipResponse != null && vecPartyRelationshipResponse.size() > 0) 
					{
						
						for (int j = 0; j < vecPartyRelationshipResponse.size(); j++) 
						{
							XContactRelBObjExt xContactRelBObjExt = (XContactRelBObjExt) vecPartyRelationshipResponse.get(j);
							mapKey = xContactRelBObjExt.getRelationshipDescription()+xContactRelBObjExt.getXRetailerCode() ;
							
							if(xContactRelBObjExt.getXRetailerCode()!=null)
							{
								
							if (!xCustomerRelationshipMap.containsKey(mapKey)) 
							{	
								xCustomerRelationshipMap.put(mapKey,xContactRelBObjExt);
								
							} else 
							{
								XContactRelBObjExt xContactRelBObjInMap = xCustomerRelationshipMap.get(mapKey);
								
								requestCompanyId = xContactRelBObjInMap.getRelationshipToPartyId();
								existingCompanyId = xContactRelBObjExt.getRelationshipToPartyId();
								
								requestPersonRetailerCode = xContactRelBObjInMap.getXRetailerCode();
								existingPersonRetailerCode = xContactRelBObjExt.getXRetailerCode();
								requestRelationshipType = xContactRelBObjInMap.getRelationshipDescription();
								existingRelationshipType = xContactRelBObjExt.getRelationshipDescription();
								
								//Same Relationship type
								if(requestRelationshipType != null && existingRelationshipType != null && requestRelationshipType.equalsIgnoreCase(existingRelationshipType))
								{
		
									//Same Retailer Code
									if (requestPersonRetailerCode != null && existingPersonRetailerCode != null && requestPersonRetailerCode.equalsIgnoreCase(existingPersonRetailerCode)) 
									{			
										Timestamp requestPersonLastModifiedDt = DateFormatter.getTimestamp(xContactRelBObjInMap.getXLastModifiedSystemDate());										
										Timestamp existingPersonLastModifiedDt = DateFormatter.getTimestamp(xContactRelBObjExt.getXLastModifiedSystemDate());
										
										//Same company Id
										if (requestCompanyId != null && existingCompanyId != null && requestCompanyId.equalsIgnoreCase(existingCompanyId)) 
										{	
											
											if (requestPersonLastModifiedDt.after(existingPersonLastModifiedDt)) 
											{					
												xCustomerRelationshipMap.put(mapKey,xContactRelBObjInMap);
											}
											else
											{
												xCustomerRelationshipMap.put(mapKey,xContactRelBObjExt);
											}
																			
										}
										else
										{
											if (requestPersonLastModifiedDt.after(existingPersonLastModifiedDt)) 
											{					
												xCustomerRelationshipMap.put(mapKey,xContactRelBObjInMap);
											}
											else
											{
												xCustomerRelationshipMap.put(mapKey,xContactRelBObjExt);
											}
										}
									}
									else
									{
										//Different Retailer Code
										if (requestCompanyId != null && existingCompanyId != null && requestCompanyId.equalsIgnoreCase(existingCompanyId)) {
										
											xCustomerRelationshipMap.put(mapKey,xContactRelBObjExt);
										}
									}
								}
								else
								{
									//Different Relationship description
									xCustomerRelationshipMap.put(mapKey,xContactRelBObjExt);
								}
							}
						}
							else
							{
								if (!xCustomerRelationshipMap.containsKey(mapKey)) 
								{	
									xCustomerRelationshipMap.put(mapKey,xContactRelBObjExt);
									
								} else 
								{
									XContactRelBObjExt xContactRelBObjInMap = xCustomerRelationshipMap.get(mapKey);
									
									//Same Relationship type
									if(requestRelationshipType != null && existingRelationshipType != null && requestRelationshipType.equalsIgnoreCase(existingRelationshipType))
									{
										Timestamp requestPersonLastModifiedDt = DateFormatter.getTimestamp(xContactRelBObjInMap.getXLastModifiedSystemDate());										
										Timestamp existingPersonLastModifiedDt = DateFormatter.getTimestamp(xContactRelBObjExt.getXLastModifiedSystemDate());
										
										//Incoming C2C latest
										if (requestPersonLastModifiedDt.after(existingPersonLastModifiedDt))
										{				
											xCustomerRelationshipMap.put(mapKey,xContactRelBObjInMap);
										}
										//Existing C2C latest
										else 
										{										
											xCustomerRelationshipMap.put(mapKey,xContactRelBObjExt);										
										}
									}
								}
							}
						}
					}
				}
				
				else 
				{
					//If Suspect parties are Organization
					vecPartyRelationshipResponse = partyComponent.getAllPartyRelationships(partytId, "ACTIVE",control);
								
					if (vecPartyRelationshipResponse != null && vecPartyRelationshipResponse.size() > 0) 
					{
						
						for (int j = 0; j < vecPartyRelationshipResponse.size(); j++) 
						{
							XContactRelBObjExt xContactRelBObjExt = (XContactRelBObjExt) vecPartyRelationshipResponse.get(j);
							mapKey = xContactRelBObjExt.getRelationshipDescription()+xContactRelBObjExt.getXRetailerCode()+xContactRelBObjExt.getRelationshipToPartyId();
							
							if(xContactRelBObjExt.getXRetailerCode()!=null)
							{
								
							if (!xCustomerRelationshipMap.containsKey(xContactRelBObjExt.getXRetailerCode())) 
							{								
								xCustomerRelationshipMap.put(mapKey,xContactRelBObjExt);
								
							}
							else 
							{
								XContactRelBObjExt xContactRelBObjInMap = xCustomerRelationshipMap.get(mapKey);
								
								requestPersonContId = xContactRelBObjInMap.getRelationshipToPartyId();
								existingPersonContId = xContactRelBObjExt.getRelationshipToPartyId();
								
								requestOrgRetailerCode = xContactRelBObjInMap.getXRetailerCode();
								existingOrgRetailerCode = xContactRelBObjExt.getXRetailerCode();
								requestRelationshipType = xContactRelBObjInMap.getRelationshipDescription();
								existingRelationshipType = xContactRelBObjExt.getRelationshipDescription();
								
								//Same Relationship Description
								if(requestRelationshipType != null && existingRelationshipType != null && requestRelationshipType.equalsIgnoreCase(existingRelationshipType))
								{
	
									//Same Retailer Code
									if (requestOrgRetailerCode != null && existingOrgRetailerCode != null && requestOrgRetailerCode.equalsIgnoreCase(existingOrgRetailerCode)) 
									{
										
										//Same Person contId
										if (requestPersonContId != null && existingPersonContId != null && requestPersonContId.equalsIgnoreCase(existingPersonContId)) 
										{
											
											Timestamp requestPersonLastModifiedDt = DateFormatter.getTimestamp(xContactRelBObjInMap.getXLastModifiedSystemDate());
											Timestamp existingPersonLastModifiedDt = DateFormatter.getTimestamp(xContactRelBObjExt.getXLastModifiedSystemDate());
											
											//incoming C2C latest
											if (requestPersonLastModifiedDt.after(existingPersonLastModifiedDt))
											{	
												xCustomerRelationshipMap.put((xContactRelBObjInMap.getRelationshipDescription()+xContactRelBObjInMap.getXRetailerCode()+xContactRelBObjInMap.getRelationshipToPartyId()),xContactRelBObjInMap);
											}
											//Existing latest
											else 
											{	
												xCustomerRelationshipMap.put(mapKey,xContactRelBObjExt);
											}
										}
										 else 
										 {
												//different Person contId
												xCustomerRelationshipMap.put(mapKey,xContactRelBObjExt);
										 }
									}
									
									else 
									{
										//Different Retailer code
										if (requestPersonContId != null && existingPersonContId != null && requestPersonContId.equalsIgnoreCase(existingPersonContId)) 
										{						
											xCustomerRelationshipMap.put(mapKey,xContactRelBObjExt);
										}
									}
								}
								
								 else 
								 {
										//Different Relationship Description
										xCustomerRelationshipMap.put(mapKey,xContactRelBObjExt);
								 }
							}
						}
							else
							{
								if (!xCustomerRelationshipMap.containsKey(mapKey)) 
								{	
									xCustomerRelationshipMap.put(mapKey,xContactRelBObjExt);
									
								} else 
								{
									XContactRelBObjExt xContactRelBObjInMap = xCustomerRelationshipMap.get(mapKey);
									
									//Same Relationship type
									if(requestRelationshipType != null && existingRelationshipType != null && requestRelationshipType.equalsIgnoreCase(existingRelationshipType))
									{
										Timestamp requestPersonLastModifiedDt = DateFormatter.getTimestamp(xContactRelBObjInMap.getXLastModifiedSystemDate());										
										Timestamp existingPersonLastModifiedDt = DateFormatter.getTimestamp(xContactRelBObjExt.getXLastModifiedSystemDate());
										
										//Incoming C2C latest
										if (requestPersonLastModifiedDt.after(existingPersonLastModifiedDt))
										{				
											xCustomerRelationshipMap.put(mapKey,xContactRelBObjInMap);
										}
										//Existing C2C latest
										else 
										{										
											xCustomerRelationshipMap.put(mapKey,xContactRelBObjExt);										
										}
									}
								}
							}
						}
					}
				}
			}
			
			
			Vector<XContactRelBObjExt> survivedXContactRelBobjs = new Vector<XContactRelBObjExt>();
			for(String key : xCustomerRelationshipMap.keySet())
			{
				survivedXContactRelBobjs.add(xCustomerRelationshipMap.get(key));
			}
			
			for (  XContactRelBObjExt survivedXContactRelBObjExt: survivedXContactRelBobjs) 
			{			
				xRelRequestObject.setRelationshipType(survivedXContactRelBObjExt.getRelationshipType());
				xRelRequestObject.setRelationshipValue(survivedXContactRelBObjExt.getRelationshipValue());
				xRelRequestObject.setRelationshipDescription(survivedXContactRelBObjExt.getRelationshipDescription());
				xRelRequestObject.setXContactRelRetailerFlag(survivedXContactRelBObjExt.getXContactRelRetailerFlag());
				xRelRequestObject.setXRetailerCode(survivedXContactRelBObjExt.getXRetailerCode());
				xRelRequestObject.setXSourceIdentifierType(survivedXContactRelBObjExt.getXSourceIdentifierType());
				xRelRequestObject.setXContactPosition(survivedXContactRelBObjExt.getXContactPosition());		
				xRelRequestObject.setXContactRole(survivedXContactRelBObjExt.getXContactRole());				
				xRelRequestObject.setXLastModifiedSystemDate(survivedXContactRelBObjExt.getXLastModifiedSystemDate());
				xRelRequestObject.setControl(survivedXContactRelBObjExt.getControl());
				xRelRequestObject.setDeleteFlag(survivedXContactRelBObjExt.getDeleteFlag());
				
				if(partyType!=null && partyType.equalsIgnoreCase("P"))
				{
					xRelRequestObject.setRelationshipFromValue(survivedXContactRelBObjExt.getRelationshipToPartyId());
					xRelRequestObject.setRelationshipToValue(collapsedPartyId);
				} else 
				{
						xRelRequestObject.setRelationshipFromValue(survivedXContactRelBObjExt.getRelationshipToPartyId());
						xRelRequestObject.setRelationshipToValue(collapsedPartyId);
				}

					partyComponent.addPartyRelationship(xRelRequestObject);	
			}
			
		}
		
		
		
		
		
		//August 31, 2018 : Added by Naman for Consent survivorship logic : Start 
				/**
				 * Method to survive consent details for Japan
				 * @param vecParties
				 * @param collapsedPartyBObj
				 * @param control
				 * @throws Exception
				 */
		
		public void surviveConsentDetailsForJapan(Vector<TCRMPartyBObj> vecParties, TCRMPartyBObj collapsedPartyBObj, DWLControl control) throws Exception 
		{

			HashMap<String,XConsentBObj> XConsentDetailsMap = new HashMap<String, XConsentBObj>();		
			DWLResponse dwlResponse = new DWLResponse();			
			DSEAAdditionsExtsComponent dseaAdditionsExtsComponent = new DSEAAdditionsExtsComponent();
			String partytId = null;
			String collapsedPartyId = collapsedPartyBObj.getPartyId();
			for(TCRMPartyBObj partyBObj : vecParties)
			{
				partytId = partyBObj.getPartyId();
				dwlResponse = dseaAdditionsExtsComponent.getXConsentByContId(partytId, control);
				Vector<XConsentBObj> vecXConsent = (Vector<XConsentBObj>) dwlResponse.getData();
				
				if(null!= vecXConsent && vecXConsent.size()>0)
				{
					for(XConsentBObj consentBObj : vecXConsent)
					{
						String reatilerFlag = consentBObj.getRetailerFlag();
						String retailerId = consentBObj.getRetailerId();
						String communicationChannel = consentBObj.getCommunicationChannel();
						if(ExternalRuleConstant.CONSENT_RETAILER_FLAG_N.equalsIgnoreCase(reatilerFlag))
						{
							String mapKey = communicationChannel;
							if(!XConsentDetailsMap.containsKey(mapKey))
							{
								XConsentDetailsMap.put(mapKey, consentBObj);
							}
							else
							{
								XConsentBObj XConsentDetailsinMap = XConsentDetailsMap.get(mapKey);
								Timestamp requestConsentLastModifiedDt = DateFormatter
										.getTimestamp(consentBObj.getLastModifiedSystemDate());
								
								Timestamp existingConsentLastModifiedDt = DateFormatter
										.getTimestamp(XConsentDetailsinMap.getLastModifiedSystemDate());
								
								if (requestConsentLastModifiedDt.after(existingConsentLastModifiedDt))
								{
									XConsentDetailsMap.put(mapKey, consentBObj);
								}
								else
									XConsentDetailsMap.put(mapKey, XConsentDetailsinMap);
							}
						}
						else if(ExternalRuleConstant.CONSENT_RETAILER_FLAG_Y.equalsIgnoreCase(reatilerFlag))
						{
							String mapKey = communicationChannel + retailerId;
							if(!XConsentDetailsMap.containsKey(mapKey))
							{
								XConsentDetailsMap.put(mapKey, consentBObj);
							}
							else
							{
								XConsentBObj XConsentDetailsinMap = XConsentDetailsMap.get(mapKey);
								Timestamp requestConsentLastModifiedDt = DateFormatter
										.getTimestamp(consentBObj.getLastModifiedSystemDate());
								
								Timestamp existingConsentLastModifiedDt = DateFormatter
										.getTimestamp(XConsentDetailsinMap.getLastModifiedSystemDate());
								
								if (requestConsentLastModifiedDt.after(existingConsentLastModifiedDt))
								{
									XConsentDetailsMap.put(mapKey, consentBObj);
								}
								else
									XConsentDetailsMap.put(mapKey, XConsentDetailsinMap);
							}
						}
						
					}
				}
				
			}
			for(Map.Entry<String, XConsentBObj> entry : XConsentDetailsMap.entrySet())
			{
				XConsentBObj tempXConsentBObj = entry.getValue();
				XConsentBObj survivedXConsentBObj = new XConsentBObj();
				//XConsentBObj inactivexConsentBObj = endExistingConsent(control,tempXConsentBObj.getContId(),tempXConsentBObj.getXConsentpkId(),dseaAdditionsExtsComponent);
				/*survivedXConsentBObj = tempXConsentBObj;
				survivedXConsentBObj.setContId(collapsedPartyId);
				survivedXConsentBObj.setControl(control);*/				
				addNewConsentforSurvivedParty(control,collapsedPartyId,tempXConsentBObj,dseaAdditionsExtsComponent);
				
			}
		
			
			
			
		}
		
		//August 31, 2018 : Added by Naman for Consent survivorship logic : End
		
		
		

		//August 31, 2018 : Added by Naman for DataSharing  survivorship logic : Start 
				/**
				 * Method to survive consent details for Japan
				 * @param vecParties
				 * @param collapsedPartyBObj
				 * @param control
				 * @throws Exception
				 */
		
		public void surviveDataSharingDetailsForJapan(Vector<TCRMPartyBObj> vecParties, TCRMPartyBObj collapsedPartyBObj, DWLControl control) throws Exception 
		{
			String collapsedPartyId = collapsedPartyBObj.getPartyId();
			DSEAAdditionsExtsComponent dseaAdditionsExtsComponent = new DSEAAdditionsExtsComponent();
			String partyId = null;
			DWLResponse dwlResponse = new DWLResponse();
			Vector<XDataSharingBObj> vecXWholesaleDataSharing = new Vector<XDataSharingBObj> ();
			HashMap<String,XDataSharingBObj> XRetailDataSharingMap = new HashMap<String, XDataSharingBObj>();	
			boolean isRetailBObjPresent = false;
			for(TCRMPartyBObj partyBObj : vecParties)
			{
				partyId = partyBObj.getPartyId();
				dwlResponse = dseaAdditionsExtsComponent.getDataSharingByPartyId(partyId ,control);
				Vector<XDataSharingBObj> vecXDataSharing = (Vector<XDataSharingBObj>) dwlResponse.getData();
				if(vecXDataSharing!=null)
				{
				for(XDataSharingBObj tempXDataSharing :vecXDataSharing)
				{
					
					if(tempXDataSharing.getRetailerId()!=null || tempXDataSharing.getRetailerFlag().equalsIgnoreCase(ExternalRuleConstant.DATASHARING_RETAILER_FLAG_Y))
					{
						isRetailBObjPresent = true;
						XRetailDataSharingMap.put(tempXDataSharing.getRetailerId(), tempXDataSharing);
					}
					
					else
					{
						if(tempXDataSharing.getDataSharingFlag().equalsIgnoreCase(ExternalRuleConstant.DATASHARING_FLAG_Y))
						vecXWholesaleDataSharing.add(tempXDataSharing);
					}
					}
				}			
			}
			
			if(!vecXWholesaleDataSharing.isEmpty())
			{
			Collections.sort(vecXWholesaleDataSharing,
					new Comparator<XDataSharingBObj>() {// Ascending sort
														// - for delta
														// load
						public int compare(XDataSharingBObj dataSharing1,
								XDataSharingBObj dataSharing2) {
							if (dataSharing1.getLastModifiedSystemDate() == null
									|| dataSharing2
											.getLastModifiedSystemDate() == null)
								return 0;
							return dataSharing1
									.getLastModifiedSystemDate()
									.compareTo(
											dataSharing2.getLastModifiedSystemDate());
						}
					});
			
			
			XDataSharingBObj WSDataSharingBObj = vecXWholesaleDataSharing.get(0);
						
			
			//String objectToString =((XDataSharingBObj)WSDataSharingBObj).toXML("MDM", "MDMDomains.xsd", 0, null, false);	
	  		//System.out.println(objectToString);
			
			for(Map.Entry<String, XDataSharingBObj> entry : XRetailDataSharingMap.entrySet())
			{
				XDataSharingBObj reqRetailDataSharing = entry.getValue();
				XDataSharingBObj tempDataSharing = new XDataSharingBObj ();
				
				tempDataSharing.setContId(collapsedPartyId);
				tempDataSharing.setRetailerFlag(DATASHARING_RETAILER_FLAG_Y);
				tempDataSharing.setRetailerId(reqRetailDataSharing.getRetailerId());
				tempDataSharing.setDataSharingFlag(WSDataSharingBObj.getDataSharingFlag());
				tempDataSharing.setSourceIdentifierType(WSDataSharingBObj.getSourceIdentifierType());
				tempDataSharing.setSourceIdentifierValue(WSDataSharingBObj.getSourceIdentifierValue());
				tempDataSharing.setStartDate(WSDataSharingBObj.getStartDate());
				tempDataSharing.setLastModifiedSystemDate(WSDataSharingBObj.getLastModifiedSystemDate());
				
				addNewDataSharingforSurvivedParty(control, collapsedPartyId, tempDataSharing, dseaAdditionsExtsComponent);
			}
			
			XDataSharingBObj finalWSDataSharingBObj = new XDataSharingBObj ();
			
			finalWSDataSharingBObj.setContId(collapsedPartyId);
			finalWSDataSharingBObj.setDataSharingFlag(WSDataSharingBObj.getDataSharingFlag());
			finalWSDataSharingBObj.setRetailerFlag(DATASHARING_RETAILER_FLAG_N);
			finalWSDataSharingBObj.setRetailerId(null);
			finalWSDataSharingBObj.setSourceIdentifierType(WSDataSharingBObj.getSourceIdentifierType());
			finalWSDataSharingBObj.setSourceIdentifierValue(WSDataSharingBObj.getSourceIdentifierValue());
			finalWSDataSharingBObj.setStartDate(WSDataSharingBObj.getStartDate());
			finalWSDataSharingBObj.setLastModifiedSystemDate(WSDataSharingBObj.getLastModifiedSystemDate());
			
			addNewDataSharingforSurvivedParty(control, collapsedPartyId, finalWSDataSharingBObj, dseaAdditionsExtsComponent);
		
			}
			}
		
		//August 31, 2018 : Added by Naman for Data Sharing survivorship logic : End
		
		
		public void survivedContractFSDetailsForJapan(Vector<TCRMPartyBObj> vecParties,
				TCRMPartyBObj collapsedPartyBObj, DWLControl control)
				throws Exception {
			HashMap<String, XContractRelJPNBObj> xContractDetailsMap = new HashMap<String, XContractRelJPNBObj>();
			Vector<XContractRelJPNBObj> vecXContractDetailsBObjs = new Vector<XContractRelJPNBObj>();
			DWLResponse dwlResponse = new DWLResponse();
			DWLResponse response = null;
			DSEAAdditionsExtsComponent dseaAdditionsExtsComponent = new DSEAAdditionsExtsComponent();
			String partytId = null;
			String contractNumber = null;
			String collapsedPartyId = collapsedPartyBObj.getPartyId();

			for (TCRMPartyBObj partyBObj : vecParties) {
				partytId = partyBObj.getPartyId();
				Vector<XContractRelJPNBObj> vectXcontractRel= getContractRelJPNByPartyId(control,partytId);
				for (int j = 0; j < vectXcontractRel.size(); j++) {
					XContractRelJPNBObj xContractRelBObj = (XContractRelJPNBObj) vectXcontractRel
							.get(j);
							xContractDetailsMap.put(xContractRelBObj.getContId()+xContractRelBObj.getContractId()+xContractRelBObj.getContractRole(),xContractRelBObj);

				}
			}

			//validateContractRelationship(xContractDetailsMap,control);
			
			for (Map.Entry<String, XContractRelJPNBObj> entry : xContractDetailsMap
					.entrySet()) {
				XContractRelJPNBObj tempXContractRelBObj = entry.getValue();
				XContractRelJPNBObj survivedXContractRelBObj = new XContractRelJPNBObj();
				XContractRelJPNBObj inactivexContractRelBObj = endExistingContractRelJPN(control,tempXContractRelBObj.getContId(),tempXContractRelBObj.getContractId(),dseaAdditionsExtsComponent);
							
				survivedXContractRelBObj = tempXContractRelBObj;
				survivedXContractRelBObj.setContId(collapsedPartyId);
				survivedXContractRelBObj.setControl(control);				
				addNewContractRelJPNforSurvivedParty(control,survivedXContractRelBObj.getContId(),survivedXContractRelBObj.getContractId(),dseaAdditionsExtsComponent,inactivexContractRelBObj);
				
				
			}
		}
		
		public void validateContractRelationship(HashMap<String, XContractRelJPNBObj> xContractDetailsMap, DWLControl control) throws BusinessProxyException {
		
			boolean isContractorRolePresent = false;
			boolean isGuarantorRolePresent = false;
			
			HashMap<String, List<XContractRelJPNBObj>> xContractDetailsGroupByContractIdMap = new HashMap<String, List<XContractRelJPNBObj>>();

			for (Map.Entry<String, XContractRelJPNBObj> entry : xContractDetailsMap
					.entrySet()) 
			{
				XContractRelJPNBObj tempXContractRelBObj = entry.getValue();
			if(!xContractDetailsGroupByContractIdMap.containsKey(tempXContractRelBObj.getContractId()))
			{
				List<XContractRelJPNBObj> list = new ArrayList<XContractRelJPNBObj>();
				list.add(tempXContractRelBObj);
				
				xContractDetailsGroupByContractIdMap.put(tempXContractRelBObj.getContractId(), list);
			}
			else
			{
				xContractDetailsGroupByContractIdMap.get(tempXContractRelBObj.getContractId()).add(tempXContractRelBObj);
			}
			}
			
			for (Map.Entry<String, List<XContractRelJPNBObj>> entry : xContractDetailsGroupByContractIdMap
					.entrySet()) 
			{
				List<XContractRelJPNBObj> listXContractRelJPNBObj = entry.getValue();
				
				/*if(listXContractRelJPNBObj.contains(ExternalRuleConstant.GUARANTOR_ROLE) && 
						listXContractRelJPNBObj.contains(ExternalRuleConstant.CONTRACTOR_ROLE))*/
				for(int i=0;i<listXContractRelJPNBObj.size();i++)
				{
					
					if(listXContractRelJPNBObj.get(i).getContractRole().equalsIgnoreCase(ExternalRuleConstant.GUARANTOR_ROLE))
					{
						isGuarantorRolePresent = true;
					}
					else if(listXContractRelJPNBObj.get(i).getContractRole().equalsIgnoreCase(ExternalRuleConstant.CONTRACTOR_ROLE))
					{
						isContractorRolePresent = true;
					}
					
				}
					
				if(isGuarantorRolePresent && isContractorRolePresent )
				{
					DWLError error = errHandler
	 						.getErrorMessage(
	 								DSEAExternalRulesComponentID.MAINTAIN_CONTRACT_FSJPNBUSINESS_PROXY,
	 								DWLErrorCode.FIELD_VALIDATION_ERROR,
	 								DSEAExternalRulesErrorReasonCode.MAINTAINCONTRACTFSJPN_CONTRACTOR_GUARANTOR_SAME,
	 								control, new String[0]);
	 				vectReqDWLError.add(error);
	 				throw new BusinessProxyException(error.getErrorMessage());
					
				}
				
			}
			}
			
		
		public Vector getContractRelJPNByPartyId(DWLControl control, String contId)
				throws Exception {
			SQLQuery sqlQuery = new SQLQuery();
			ResultSet objResultSet = null;
			String getContractIdSql = ExternalRuleConstant.GET_CONTRACT_RELJPN_BY_PARTYID;
			String contequivId = null;
			List<SQLParam> params = new ArrayList<SQLParam>();
			XContEquivBObjExt xContBObjExt = new XContEquivBObjExt();
			XContEquivBObjExt getContequivResponse = null;
			DWLStatus dwlStatus = null;
			String contractRelID = null;
			String lastupdate_dt = null;
			Vector<XContractRelJPNBObj> vect =new Vector<XContractRelJPNBObj>();
			try {
				params = new ArrayList<SQLParam>();
				params.add(0, new SQLParam(contId));
				//params.add(1, new SQLParam(contId));			
				
			
				
				objResultSet = sqlQuery.executeQuery(getContractIdSql, params);
				while (objResultSet.next()) {
					XContractRelJPNBObj xContractRelBObj = new XContractRelJPNBObj();
					xContractRelBObj.setXContractRelJPNpkId(objResultSet.getString(ExternalRuleConstant.CONTRACT_RELJPN_ID));
					xContractRelBObj.setContractId(objResultSet.getString("CONTRACT_ID"));
					xContractRelBObj.setContId(objResultSet.getString("CONT_ID"));
					xContractRelBObj.setMarketName(objResultSet.getString("MARKET_NAME"));
					xContractRelBObj.setPersonOrgCode(objResultSet.getString("PERSON_ORG_CODE"));
					xContractRelBObj.setContractRole(objResultSet.getString("CONTRACT_ROLE"));
					xContractRelBObj.setStartDate(objResultSet.getString("START_DT"));
					xContractRelBObj.setEndDate(objResultSet.getString("END_DT"));
					xContractRelBObj.setXContractRelJPNLastUpdateDate(objResultSet.getString(ExternalRuleConstant.LAST_UPDATE_DT));
					vect.add(xContractRelBObj);
					
					
				}
			} catch (Exception ex) {
				logger.finest(ex);
				throw ex;    
				
			}finally{
				if (objResultSet != null && !objResultSet.isClosed()) {
					objResultSet.close();
					objResultSet = null;
				}	
				sqlQuery.close();
			}
		
			return vect;
		}
		
		private XContractRelJPNBObj endExistingContractRelJPN(DWLControl control, String partytId,
				String contractpkId, DSEAAdditionsExtsComponent dseaAdditionsExtsComponent) throws Exception {
			Vector<XContractRelJPNBObj> vect = getContractRelJPN(control,partytId,contractpkId);
			XContractRelJPNBObj xContractRelBObjInDb = null;
			XContractRelJPNBObj xContractRelBObj=vect.get(0);
			long milliseconds = System.currentTimeMillis();
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SS");
			Date endDate = new Date(milliseconds);
			xContractRelBObj.setEndDate(sdf.format(endDate));
			xContractRelBObj.setControl(control);
			DWLResponse res=dseaAdditionsExtsComponent.updateXContractRelJPN(xContractRelBObj);
			if (res.getStatus().getStatus() == DWLStatus.FATAL) {
				throw new BusinessProxyException();
			}
			if(res!=null){
				xContractRelBObjInDb = (XContractRelJPNBObj)res.getData();
			}
			return xContractRelBObjInDb;
			
		}
		
		public Vector getContractRelJPN(DWLControl control, String contId, String contractpkId)
				throws Exception {
			SQLQuery sqlQuery = new SQLQuery();
			ResultSet objResultSet = null;
			String getContractIdSql = ExternalRuleConstant.GET_CONTRACT_RELJPN;
			String contequivId = null;
			List<SQLParam> params = new ArrayList<SQLParam>();
			XContEquivBObjExt xContBObjExt = new XContEquivBObjExt();
			XContEquivBObjExt getContequivResponse = null;
			DWLStatus dwlStatus = null;
			String contractRelID = null;
			String lastupdate_dt = null;
			Vector<XContractRelJPNBObj> vect =new Vector<XContractRelJPNBObj>();
			try {
				params = new ArrayList<SQLParam>();
				params.add(0, new SQLParam(contractpkId));
				params.add(1, new SQLParam(contId));			
				
			
				
				objResultSet = sqlQuery.executeQuery(getContractIdSql, params);
				while (objResultSet.next()) {
					XContractRelJPNBObj xContractRelBObj = new XContractRelJPNBObj();
					xContractRelBObj.setXContractRelJPNpkId(objResultSet.getString(ExternalRuleConstant.CONTRACT_RELJPN_ID));
					xContractRelBObj.setContractId(objResultSet.getString("CONTRACT_ID"));
					xContractRelBObj.setContId(objResultSet.getString("CONT_ID"));
					xContractRelBObj.setMarketName(objResultSet.getString("MARKET_NAME"));
					xContractRelBObj.setPersonOrgCode(objResultSet.getString("PERSON_ORG_CODE"));
					xContractRelBObj.setContractRole(objResultSet.getString("CONTRACT_ROLE"));
					xContractRelBObj.setStartDate(objResultSet.getString("START_DT"));
					xContractRelBObj.setEndDate(objResultSet.getString("END_DT"));
					xContractRelBObj.setXContractRelJPNLastUpdateDate(objResultSet.getString(ExternalRuleConstant.LAST_UPDATE_DT));
					vect.add(xContractRelBObj);
					
					
				}
			} catch (Exception ex) {
				logger.finest(ex);
				throw ex;
				
			}finally{
				if (objResultSet != null && !objResultSet.isClosed()) {
					objResultSet.close();
					objResultSet = null;
				}
				sqlQuery.close();				
				
			}
		
			return vect;
		}
		
		private void addNewContractRelJPNforSurvivedParty(DWLControl control, String contId,
				String contractpkId,
				DSEAAdditionsExtsComponent dseaAdditionsExtsComponent,
				XContractRelJPNBObj inactivexContractRelBObj) throws Exception {
			
			XContractRelJPNBObj newXContractRelBObj = new XContractRelJPNBObj();
			newXContractRelBObj.setContractId(contractpkId);
			newXContractRelBObj.setContId(contId);
			newXContractRelBObj.setMarketName(inactivexContractRelBObj.getMarketName());
			newXContractRelBObj.setPersonOrgCode(inactivexContractRelBObj.getPersonOrgCode());
			newXContractRelBObj.setContractRole(inactivexContractRelBObj.getContractRole());
			newXContractRelBObj.setStartDate(inactivexContractRelBObj.getStartDate());
			newXContractRelBObj.setControl(control);
			DWLResponse response=dseaAdditionsExtsComponent.addXContractRelJPN(newXContractRelBObj);
			
			if (response.getStatus().getStatus() == DWLStatus.FATAL) {
				throw new BusinessProxyException();
			}
			
			
			
		}
		
		private void addNewDataSharingforSurvivedParty(DWLControl control, String collapsedPartyId,XDataSharingBObj tempXDataSharingBObj,
                DSEAAdditionsExtsComponent dseaAdditionsExtsComponent) throws Exception {
          
			 	         
		  tempXDataSharingBObj.setControl(control);
	          
          DWLResponse response=dseaAdditionsExtsComponent.addXDataSharing(tempXDataSharingBObj);
          //String objectToString =((XConsentBObj)response.getData()).toXML("MDM", "MDMDomains.xsd", 0, null, false);	
  		 // System.out.println(objectToString);
          if (response.getStatus().getStatus() == DWLStatus.FATAL) {
                throw new BusinessProxyException();
          }
          
		}
		
		public static String getCodeValueFromType(String codeTableName,
				String codeType, DWLControl control) throws Exception {

			CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory
					.getCodeTypeComponentHelper();
			String langId = (String) control.get(DWLControlKeys.LANG_ID);
			String codeValue = null;
			CodeTypeBObj ctBObj = codeTypeCompHelper.getCodeTypeByCode(
					codeTableName, langId, codeType, control);
			if (ctBObj != null) {
				codeValue = ctBObj.getvalue();
			}
			return codeValue;
		}
		
		
	//----------------------------------------------For Performance Improvement Start
		
		public static Vector<XConsentBObj> fetchAllConsentDetails(Vector<TCRMPartyBObj> vecParty, DWLControl control) throws BusinessProxyException, SQLException{
			String finalPartyId = new String();
			if(vecParty!=null && vecParty.size()>0){				
			for(TCRMPartyBObj tCRMPartyBObj : vecParty){
				String partyId = tCRMPartyBObj.getPartyId();
				finalPartyId = partyId + ", " + finalPartyId  ;
				}
			}		
			finalPartyId = finalPartyId.replaceAll(", $", "");
			SQLQuery sqlQuery = new SQLQuery();
			ResultSet objResultSet = null;
			String contractRelIdSql = ExternalRuleConstant.SEARCH_XCONSENT_DETAILS_PARTYID + finalPartyId + SEARCH_COMMON;
			Vector<XConsentBObj> vecConsentDetailsJPNBObj = new Vector<XConsentBObj>();

			try {
				objResultSet = sqlQuery.executeQuery(contractRelIdSql);
				while (objResultSet.next()) {					
					XConsentBObj newXConsentDetailsJPNBObj= new XConsentBObj();										
					newXConsentDetailsJPNBObj.setXConsentpkId(objResultSet.getString("XCONSENTPK_ID"));	
					newXConsentDetailsJPNBObj.setContId(objResultSet.getString("CONT_ID"));
					newXConsentDetailsJPNBObj.setCommunicationChannel(objResultSet.getString("COMM_CHANNNEL"));
					newXConsentDetailsJPNBObj.setConsentActionType(objResultSet.getString("CONSENT_ACTION_TP_CD"));
					newXConsentDetailsJPNBObj.setSourceIdentifierType(objResultSet.getString("SOURCE_IDENT_TP_CD"));
					newXConsentDetailsJPNBObj.setRetailerId(objResultSet.getString("RETAILER_ID"));
					newXConsentDetailsJPNBObj.setRetailerFlag(objResultSet.getString("RETAILER_FLAG"));
					newXConsentDetailsJPNBObj.setLastModifiedSystemDate(objResultSet.getString("LAST_MODIFIED_SYSTEM_DT"));
					newXConsentDetailsJPNBObj.setXConsentLastUpdateDate(objResultSet.getString("LAST_UPDATE_DT"));
					newXConsentDetailsJPNBObj.setXConsentLastUpdateTxId(objResultSet.getString("LAST_UPDATE_TX_ID"));
					newXConsentDetailsJPNBObj.setXConsentLastUpdateUser(objResultSet.getString("LAST_UPDATE_USER"));					
					vecConsentDetailsJPNBObj.add(newXConsentDetailsJPNBObj);
				}		
			} catch (Exception ex) {
				ex.printStackTrace();
			}finally{
			if(objResultSet != null)		
				objResultSet.close();	
				sqlQuery.close();
			}
			return vecConsentDetailsJPNBObj;
		}
		
		public static Vector<XDataSharingBObj> fetchAllDataSharingDetails(Vector<TCRMPartyBObj> vecParty, DWLControl control) throws BusinessProxyException, SQLException{
			String finalPartyId = new String();
			if(vecParty!=null && vecParty.size()>0){				
			for(TCRMPartyBObj tCRMPartyBObj : vecParty){
				String partyId = tCRMPartyBObj.getPartyId();
				finalPartyId = partyId + ", " + finalPartyId  ;
				}
			}		
			finalPartyId = finalPartyId.replaceAll(", $", "");
			SQLQuery sqlQuery = new SQLQuery();
			ResultSet objResultSet = null;
			String contractRelIdSql = ExternalRuleConstant.SEARCH_XDATASHARING_DETAILS_PARTYID + finalPartyId + SEARCH_COMMON;
			Vector<XDataSharingBObj> vecDataSharingDetailsJPNBObj = new Vector<XDataSharingBObj>();

			try {
				objResultSet = sqlQuery.executeQuery(contractRelIdSql);
				while (objResultSet.next()) {					
					XDataSharingBObj newXDataSaringDetailsJPNBObj= new XDataSharingBObj();										
					newXDataSaringDetailsJPNBObj.setDataSharingpkId(objResultSet.getString("DATASHARINGPK_ID"));	
					newXDataSaringDetailsJPNBObj.setDataSharingFlag(objResultSet.getString("DATA_SHARING_FLAG"));
					newXDataSaringDetailsJPNBObj.setContId(objResultSet.getString("CONT_ID"));
					newXDataSaringDetailsJPNBObj.setRetailerId(objResultSet.getString("RETAILER_ID"));
					newXDataSaringDetailsJPNBObj.setRetailerFlag(objResultSet.getString("RETAILER_FLAG"));
					newXDataSaringDetailsJPNBObj.setSourceIdentifierType(objResultSet.getString("SOURCE_IDENT_TP_CD"));
					newXDataSaringDetailsJPNBObj.setStartDate(objResultSet.getString("START_DT"));
					newXDataSaringDetailsJPNBObj.setLastModifiedSystemDate(objResultSet.getString("MODIFY_SYS_DT"));
					newXDataSaringDetailsJPNBObj.setXDataSharingLastUpdateDate(objResultSet.getString("LAST_UPDATE_DT"));
					newXDataSaringDetailsJPNBObj.setXDataSharingLastUpdateTxId(objResultSet.getString("LAST_UPDATE_TX_ID"));
					newXDataSaringDetailsJPNBObj.setXDataSharingLastUpdateUser(objResultSet.getString("LAST_UPDATE_USER"));					
					vecDataSharingDetailsJPNBObj.add(newXDataSaringDetailsJPNBObj);
				}		
			} catch (Exception ex) {
				ex.printStackTrace();
			}finally{
			if(objResultSet != null)		
				objResultSet.close();	
				sqlQuery.close();
			}
			return vecDataSharingDetailsJPNBObj;
		}
		
		public static Vector<XContractRelJPNBObj> fetchAllContractRelDetails(Vector<TCRMPartyBObj> vecParty, DWLControl control) throws BusinessProxyException, SQLException{
			String finalPartyId = new String();
			if(vecParty!=null && vecParty.size()>0){				
			for(TCRMPartyBObj tCRMPartyBObj : vecParty){
				String partyId = tCRMPartyBObj.getPartyId();
				finalPartyId = partyId + ", " + finalPartyId  ;
				}
			}		
			finalPartyId = finalPartyId.replaceAll(", $", "");
			SQLQuery sqlQuery = new SQLQuery();
			ResultSet objResultSet = null;
			String contractRelIdSql = ExternalRuleConstant.SEARCH_XCONTRACTREL_DETAILS_PARTYID1 + finalPartyId + SEARCH_XCONTRACTREL_DETAILS_PARTYID2;
			Vector<XContractRelJPNBObj> vecContractRelDetailsJPNBObj = new Vector<XContractRelJPNBObj>();

			try {
				objResultSet = sqlQuery.executeQuery(contractRelIdSql);
				while (objResultSet.next()) {					
					XContractRelJPNBObj newXContractRelDetailsJPNBObj= new XContractRelJPNBObj();					
					newXContractRelDetailsJPNBObj.setXContractRelJPNpkId(objResultSet.getString(ExternalRuleConstant.CONTRACT_RELJPN_ID));
					newXContractRelDetailsJPNBObj.setContractId(objResultSet.getString("CONTRACT_ID"));
					newXContractRelDetailsJPNBObj.setContId(objResultSet.getString("CONT_ID"));
					newXContractRelDetailsJPNBObj.setMarketName(objResultSet.getString("MARKET_NAME"));
					newXContractRelDetailsJPNBObj.setPersonOrgCode(objResultSet.getString("PERSON_ORG_CODE"));
					newXContractRelDetailsJPNBObj.setContractRole(objResultSet.getString("CONTRACT_ROLE"));
					newXContractRelDetailsJPNBObj.setStartDate(objResultSet.getString("START_DT"));
					newXContractRelDetailsJPNBObj.setEndDate(objResultSet.getString("END_DT"));
					newXContractRelDetailsJPNBObj.setXContractRelJPNLastUpdateDate(objResultSet.getString("LAST_UPDATE_DT"));
					newXContractRelDetailsJPNBObj.setXContractRelJPNLastUpdateTxId(objResultSet.getString("LAST_UPDATE_TX_ID"));
					newXContractRelDetailsJPNBObj.setXContractRelJPNLastUpdateUser(objResultSet.getString("LAST_UPDATE_USER"));				
					vecContractRelDetailsJPNBObj.add(newXContractRelDetailsJPNBObj);
				}		
			} catch (Exception ex) {
				ex.printStackTrace();
			}finally{		
				if(objResultSet != null)
					objResultSet.close();
				sqlQuery.close();		
			}
			return vecContractRelDetailsJPNBObj;
		}
		
		public static Vector<XCustomerRetailerJPNBObj> fetchAllCustomerRetailerDetails(Vector<TCRMPartyBObj> vecParty, DWLControl control) throws BusinessProxyException, SQLException{
			String finalPartyId = new String();
			if(vecParty!=null && vecParty.size()>0){				
			for(TCRMPartyBObj tCRMPartyBObj : vecParty){
				String partyId = tCRMPartyBObj.getPartyId();
				finalPartyId = partyId + ", " + finalPartyId  ;
				}
			}		
			finalPartyId = finalPartyId.replaceAll(", $", "");
			SQLQuery sqlQuery = new SQLQuery();			
			ResultSet objResultSet = null;
			String contractRelIdSql = ExternalRuleConstant.SEARCH_XCUSTOMERRETAILER_DETAILS_PARTYID + finalPartyId + SEARCH_COMMON;
			String retailerIdSql = ExternalRuleConstant.SEARCH_RETAILER_DETAILS_RETAILERID;
			Vector<XCustomerRetailerJPNBObj> vecCustomerRetailerDetailsJPNBObj = new Vector<XCustomerRetailerJPNBObj>();

			try {
				objResultSet = sqlQuery.executeQuery(contractRelIdSql);
				while (objResultSet.next()) {					
					XCustomerRetailerJPNBObj newXCustomerRetailerDetailsJPNBObj= new XCustomerRetailerJPNBObj();
					XRetailerBObj newXRetailerBObj = new XRetailerBObj();
					String retailerId = objResultSet.getString("RETAILER_ID");
					
					newXCustomerRetailerDetailsJPNBObj.setXCustomerRetailerJPNpkId(objResultSet.getString("XCUSTOMERRETAILERJPNPK_ID"));
					newXCustomerRetailerDetailsJPNBObj.setContId(objResultSet.getString("CONT_ID"));
					newXCustomerRetailerDetailsJPNBObj.setRetailerId(objResultSet.getString("RETAILER_ID"));
					newXCustomerRetailerDetailsJPNBObj.setSourceIdentifierType(objResultSet.getString("SOURCE_IDENT_TP_CD"));
					newXCustomerRetailerDetailsJPNBObj.setStartDate(objResultSet.getString("START_DT"));
					newXCustomerRetailerDetailsJPNBObj.setEndDate(objResultSet.getString("END_DT"));
					newXCustomerRetailerDetailsJPNBObj.setDeleteFlag(objResultSet.getString("DELETE_FLAG"));
					newXCustomerRetailerDetailsJPNBObj.setXCustomerRetailerJPNLastUpdateDate(objResultSet.getString("LAST_UPDATE_DT"));
					newXCustomerRetailerDetailsJPNBObj.setXCustomerRetailerJPNLastUpdateTxId(objResultSet.getString("LAST_UPDATE_TX_ID"));
					newXCustomerRetailerDetailsJPNBObj.setXCustomerRetailerJPNLastUpdateUser(objResultSet.getString("LAST_UPDATE_USER"));	
					
					if(retailerId!=null){						
						newXRetailerBObj = getXRetailerByRetailerId(retailerId);
					}	
					newXCustomerRetailerDetailsJPNBObj.setXRetailerBObj(newXRetailerBObj);					
					vecCustomerRetailerDetailsJPNBObj.add(newXCustomerRetailerDetailsJPNBObj);
				}		
			} catch (Exception ex) {
				ex.printStackTrace();
			}finally{	
				if(objResultSet != null)
					objResultSet.close();
				sqlQuery.close();		
			}
			return vecCustomerRetailerDetailsJPNBObj;
		}
		
		public static Vector<XContactRelBObjExt> fetchAllCustomerRelationshipDetails(Vector<TCRMPartyBObj> vecParty, DWLControl control) throws BusinessProxyException, SQLException{
			String finalPartyId = new String();
			if(vecParty!=null && vecParty.size()>0){				
			for(TCRMPartyBObj tCRMPartyBObj : vecParty){
				String partyId = tCRMPartyBObj.getPartyId();
				finalPartyId = partyId + ", " + finalPartyId  ;
				}
			}		
			finalPartyId = finalPartyId.replaceAll(", $", "");
			SQLQuery sqlQuery = new SQLQuery();
			ResultSet objResultSet = null;
			String contractRelIdSql = ExternalRuleConstant.SEARCH_XCONTACTREL_DETAILS_PARTYID1 + finalPartyId + SEARCH_XCONTACTREL_DETAILS_PARTYID2 + finalPartyId + SEARCH_COMMON;
			Vector<XContactRelBObjExt> vecContactRelDetailsJPNBObj = new Vector<XContactRelBObjExt>();

			try {
				objResultSet = sqlQuery.executeQuery(contractRelIdSql);
				while (objResultSet.next()) {					
					XContactRelBObjExt newXContactRelDetailsJPNBObj= new XContactRelBObjExt();					
					newXContactRelDetailsJPNBObj.setPartyRelationshipIdPK(objResultSet.getString("CONT_REL_ID"));
					newXContactRelDetailsJPNBObj.setRelationshipType(objResultSet.getString("REL_TP_CD"));
					newXContactRelDetailsJPNBObj.setRelationshipDescription(objResultSet.getString("REL_DESC"));
					newXContactRelDetailsJPNBObj.setStartDate(objResultSet.getString("START_DT"));
					newXContactRelDetailsJPNBObj.setEndDate(objResultSet.getString("END_DT"));
					newXContactRelDetailsJPNBObj.setRelationshipToPartyId(objResultSet.getString("TO_CONT_ID"));
					newXContactRelDetailsJPNBObj.setRelationshipFromPartyId(objResultSet.getString("FROM_CONT_ID"));
					newXContactRelDetailsJPNBObj.setPartyRelationshipLastUpdateDate(objResultSet.getString("LAST_UPDATE_DT"));
					newXContactRelDetailsJPNBObj.setPartyRelationshipLastUpdateTxId(objResultSet.getString("LAST_UPDATE_TX_ID"));
					newXContactRelDetailsJPNBObj.setPartyRelationshipLastUpdateUser(objResultSet.getString("LAST_UPDATE_USER"));						
					newXContactRelDetailsJPNBObj.setRelationshipAssignmentType(objResultSet.getString("REL_ASSIGN_TP_CD"));
					newXContactRelDetailsJPNBObj.setRelationshipEndReasonType(objResultSet.getString("END_REASON_TP_CD"));
					newXContactRelDetailsJPNBObj.setXRetailerCode(objResultSet.getString("XRETAILER_CODE"));
					newXContactRelDetailsJPNBObj.setXContactRole(objResultSet.getString("XCONTACT_ROLE"));
					newXContactRelDetailsJPNBObj.setXContactPosition(objResultSet.getString("XCONTACT_POSITION"));
					newXContactRelDetailsJPNBObj.setXContactRelRetailerFlag(objResultSet.getString("XCONTACTREL_RETAILER_FLAG"));
					newXContactRelDetailsJPNBObj.setXSourceIdentifierType(objResultSet.getString("XSOURCE_IDENT_TP_CD"));
					newXContactRelDetailsJPNBObj.setXLastModifiedSystemDate(objResultSet.getString("XMODIFY_SYS_DT"));
					newXContactRelDetailsJPNBObj.setDeleteFlag(objResultSet.getString("DELETE_FLAG"));
					
					vecContactRelDetailsJPNBObj.add(newXContactRelDetailsJPNBObj);
				}		
			} catch (Exception ex) {
				ex.printStackTrace();
			}finally{		
				if(objResultSet != null)
					objResultSet.close();
				sqlQuery.close();	
			}
			return vecContactRelDetailsJPNBObj;
		}
		
		public static Vector<XCustomerVehicleJPNBObj> fetchAllCustomerVehcileDetails(Vector<TCRMPartyBObj> vecParty, DWLControl control) throws BusinessProxyException, SQLException{
			String finalPartyId = new String();
			if(vecParty!=null && vecParty.size()>0){				
			for(TCRMPartyBObj tCRMPartyBObj : vecParty){
				String partyId = tCRMPartyBObj.getPartyId();
				finalPartyId = partyId + ", " + finalPartyId  ;
				}
			}		
			finalPartyId = finalPartyId.replaceAll(", $", "");
			SQLQuery sqlQuery = new SQLQuery();			
			ResultSet objResultSet = null;
			String vehicleRelIdSql = ExternalRuleConstant.SEARCH_XCUSTVEHICLEREL_DETAILS_PARTYID1 + finalPartyId + SEARCH_COMMON;		
			Vector<XCustomerVehicleJPNBObj> vecCustomerVehicleDetailsJPNBObj = new Vector<XCustomerVehicleJPNBObj>();

			try {
				objResultSet = sqlQuery.executeQuery(vehicleRelIdSql);
				while (objResultSet.next()) {					
					XCustomerVehicleJPNBObj newXCustomerVehcileDetailsJPNBObj= new XCustomerVehicleJPNBObj();
					XVehicleJPNBObj newXVehcileBObj = new XVehicleJPNBObj();
					Vector<XCustomerVehicleRoleJPNBObj> vecXCustomerVehicleRoleJPNBObj= new Vector<XCustomerVehicleRoleJPNBObj>();					
					String vehicleId = objResultSet.getString("VEHICLE_ID");
					String vehicleRelId = objResultSet.getString("XCUSTOMER_VEHICLE_JPNPK_ID");
					
					newXCustomerVehcileDetailsJPNBObj.setXCustomerVehicleJPNpkId(objResultSet.getString("XCUSTOMER_VEHICLE_JPNPK_ID"));
					newXCustomerVehcileDetailsJPNBObj.setContId(objResultSet.getString("CONT_ID"));
					newXCustomerVehcileDetailsJPNBObj.setVehicleId(objResultSet.getString("VEHICLE_ID"));
					newXCustomerVehcileDetailsJPNBObj.setRetailerId(objResultSet.getString("RETAILER_ID"));
					newXCustomerVehcileDetailsJPNBObj.setConnectMeUsageType(objResultSet.getString("CONNECTME_USAGE_TP_CD"));
					newXCustomerVehcileDetailsJPNBObj.setLicensePlate(objResultSet.getString("LICENSE_PLATE"));					
					newXCustomerVehcileDetailsJPNBObj.setVehicleSalesType(objResultSet.getString("VEHICLE_SALES_TP_CD"));
					newXCustomerVehcileDetailsJPNBObj.setVehicleUsageType(objResultSet.getString("VEHICLE_USAGE_TP_CD"));
					newXCustomerVehcileDetailsJPNBObj.setVehicleOwnerShip(objResultSet.getString("VEHICLE_OWNERSHIP"));					
					newXCustomerVehcileDetailsJPNBObj.setStartDate(objResultSet.getString("START_DT"));
					newXCustomerVehcileDetailsJPNBObj.setEndDate(objResultSet.getString("END_DT"));
					newXCustomerVehcileDetailsJPNBObj.setSourceIdentifierType(objResultSet.getString("SOURCE_IDENT_TP_CD"));
					newXCustomerVehcileDetailsJPNBObj.setCustVehRetFlag(objResultSet.getString("CUSTVEHRET_FLAG"));
					newXCustomerVehcileDetailsJPNBObj.setDeleteFlag(objResultSet.getString("DELETE_FLAG"));
					newXCustomerVehcileDetailsJPNBObj.setSFDCId(objResultSet.getString("SFDC_ID"));
					newXCustomerVehcileDetailsJPNBObj.setServiceName(objResultSet.getString("SERVICE_NAME"));					
					newXCustomerVehcileDetailsJPNBObj.setXCustomerVehicleJPNLastUpdateDate(objResultSet.getString("LAST_UPDATE_DT"));
					newXCustomerVehcileDetailsJPNBObj.setXCustomerVehicleJPNLastUpdateTxId(objResultSet.getString("LAST_UPDATE_TX_ID"));
					newXCustomerVehcileDetailsJPNBObj.setXCustomerVehicleJPNLastUpdateUser(objResultSet.getString("LAST_UPDATE_USER"));	
					
					if(vehicleId!=null){						
						newXVehcileBObj = getXVehicleByVehicleId(vehicleId);
					}	
					
					if(vehicleRelId!=null){						
						vecXCustomerVehicleRoleJPNBObj = getXVehcileRoleByVehcileRelId(vehicleRelId);
					}
					
					newXCustomerVehcileDetailsJPNBObj.setXVehicleJPNBObj(newXVehcileBObj);
					
					if(vecXCustomerVehicleRoleJPNBObj!=null && vecXCustomerVehicleRoleJPNBObj.size()>0){
					newXCustomerVehcileDetailsJPNBObj.getItemsXCustomerVehicleRoleJPNBObj().addAll(vecXCustomerVehicleRoleJPNBObj);
					}
					
					vecCustomerVehicleDetailsJPNBObj.add(newXCustomerVehcileDetailsJPNBObj);
				}		
			} catch (Exception ex) {
				ex.printStackTrace();
			}finally{	
				if(objResultSet != null)
					objResultSet.close();
				sqlQuery.close();	
			}
			return vecCustomerVehicleDetailsJPNBObj;
		}
		
	public void surviveConsentDetailsForJapanPerformance(
			Vector<XConsentBObj> vecConsentDetailsJPNBObj,
			TCRMPartyBObj collapsedPartyBObj, DWLControl control)
			throws Exception {

		HashMap<String, XConsentBObj> xConsentDetailsMap = new HashMap<String, XConsentBObj>();
		DSEAAdditionsExtsComponent dseaAdditionsExtsComponent = new DSEAAdditionsExtsComponent();
		String collapsedPartyId = collapsedPartyBObj.getPartyId();

		for (XConsentBObj consentBObj : vecConsentDetailsJPNBObj) {
			String reatilerFlag = consentBObj.getRetailerFlag();
			String retailerId = consentBObj.getRetailerId();
			String communicationChannel = consentBObj.getCommunicationChannel();
			if (ExternalRuleConstant.CONSENT_RETAILER_FLAG_N
					.equalsIgnoreCase(reatilerFlag)) {
				String mapKey = communicationChannel;
				if (!xConsentDetailsMap.containsKey(mapKey)) {
					xConsentDetailsMap.put(mapKey, consentBObj);
				} else {
					XConsentBObj xConsentDetailsinMap = xConsentDetailsMap
							.get(mapKey);
					Timestamp requestConsentLastModifiedDt = DateFormatter
							.getTimestamp(consentBObj
									.getLastModifiedSystemDate());

					Timestamp existingConsentLastModifiedDt = DateFormatter
							.getTimestamp(xConsentDetailsinMap
									.getLastModifiedSystemDate());

					if (requestConsentLastModifiedDt
							.after(existingConsentLastModifiedDt)) {
						xConsentDetailsMap.put(mapKey, consentBObj);
					} else
						xConsentDetailsMap.put(mapKey, xConsentDetailsinMap);
				}
			} else if (ExternalRuleConstant.CONSENT_RETAILER_FLAG_Y
					.equalsIgnoreCase(reatilerFlag)) {
				String mapKey = communicationChannel + retailerId;
				if (!xConsentDetailsMap.containsKey(mapKey)) {
					xConsentDetailsMap.put(mapKey, consentBObj);
				} else {
					XConsentBObj xConsentDetailsinMap = xConsentDetailsMap
							.get(mapKey);
					Timestamp requestConsentLastModifiedDt = DateFormatter
							.getTimestamp(consentBObj
									.getLastModifiedSystemDate());

					Timestamp existingConsentLastModifiedDt = DateFormatter
							.getTimestamp(xConsentDetailsinMap
									.getLastModifiedSystemDate());

					if (requestConsentLastModifiedDt
							.after(existingConsentLastModifiedDt)) {
						xConsentDetailsMap.put(mapKey, consentBObj);
					} else
						xConsentDetailsMap.put(mapKey, xConsentDetailsinMap);
				}
			}
		}

		for (Map.Entry<String, XConsentBObj> entry : xConsentDetailsMap
				.entrySet()) {
			XConsentBObj tempXConsentBObj = entry.getValue();
			addNewConsentforSurvivedParty(control, collapsedPartyId,
					tempXConsentBObj, dseaAdditionsExtsComponent);

		}
	}
	
	public void surviveDataSharingDetailsForJapanPerformance(
			Vector<XDataSharingBObj> vecDataSharingDetailsJPNBObj,
			TCRMPartyBObj collapsedPartyBObj, DWLControl control)
			throws Exception {
		String collapsedPartyId = collapsedPartyBObj.getPartyId();
		DSEAAdditionsExtsComponent dseaAdditionsExtsComponent = new DSEAAdditionsExtsComponent();
		Vector<XDataSharingBObj> vecXWholesaleDataSharing = new Vector<XDataSharingBObj>();
		HashMap<String, XDataSharingBObj> xRetailDataSharingMap = new HashMap<String, XDataSharingBObj>();
		boolean isRetailBObjPresent = false;

		for (XDataSharingBObj tempXDataSharing : vecDataSharingDetailsJPNBObj) {

			if (tempXDataSharing.getRetailerId() != null
					|| tempXDataSharing.getRetailerFlag().equalsIgnoreCase(
							ExternalRuleConstant.DATASHARING_RETAILER_FLAG_Y)) {
				isRetailBObjPresent = true;
				xRetailDataSharingMap.put(tempXDataSharing.getRetailerId(),
						tempXDataSharing);
			}

			else {
				if (tempXDataSharing.getDataSharingFlag().equalsIgnoreCase(
						ExternalRuleConstant.DATASHARING_FLAG_Y))
					vecXWholesaleDataSharing.add(tempXDataSharing);
			}
		}

		if (!vecXWholesaleDataSharing.isEmpty()) {
			Collections.sort(vecXWholesaleDataSharing,
					new Comparator<XDataSharingBObj>() {// Ascending sort
						// - for delta
						// load
						public int compare(XDataSharingBObj dataSharing1,
								XDataSharingBObj dataSharing2) {
							if (dataSharing1.getLastModifiedSystemDate() == null
									|| dataSharing2.getLastModifiedSystemDate() == null)
								return 0;
							return dataSharing1
									.getLastModifiedSystemDate()
									.compareTo(
											dataSharing2
													.getLastModifiedSystemDate());
						}
					});

			XDataSharingBObj wSDataSharingBObj = vecXWholesaleDataSharing
					.get(0);

			for (Map.Entry<String, XDataSharingBObj> entry : xRetailDataSharingMap
					.entrySet()) {
				XDataSharingBObj reqRetailDataSharing = entry.getValue();
				XDataSharingBObj tempDataSharing = new XDataSharingBObj();

				tempDataSharing.setContId(collapsedPartyId);
				tempDataSharing.setRetailerFlag(DATASHARING_RETAILER_FLAG_Y);
				tempDataSharing.setRetailerId(reqRetailDataSharing
						.getRetailerId());
				tempDataSharing.setDataSharingFlag(wSDataSharingBObj
						.getDataSharingFlag());
				tempDataSharing.setSourceIdentifierType(wSDataSharingBObj
						.getSourceIdentifierType());
				tempDataSharing.setSourceIdentifierValue(wSDataSharingBObj
						.getSourceIdentifierValue());
				tempDataSharing.setStartDate(wSDataSharingBObj.getStartDate());
				tempDataSharing.setLastModifiedSystemDate(wSDataSharingBObj
						.getLastModifiedSystemDate());

				addNewDataSharingforSurvivedParty(control, collapsedPartyId,
						tempDataSharing, dseaAdditionsExtsComponent);
			}

			XDataSharingBObj finalWSDataSharingBObj = new XDataSharingBObj();

			finalWSDataSharingBObj.setContId(collapsedPartyId);
			finalWSDataSharingBObj.setDataSharingFlag(wSDataSharingBObj
					.getDataSharingFlag());
			finalWSDataSharingBObj.setRetailerFlag(DATASHARING_RETAILER_FLAG_N);
			finalWSDataSharingBObj.setRetailerId(null);
			finalWSDataSharingBObj.setSourceIdentifierType(wSDataSharingBObj
					.getSourceIdentifierType());
			finalWSDataSharingBObj.setSourceIdentifierValue(wSDataSharingBObj
					.getSourceIdentifierValue());
			finalWSDataSharingBObj.setStartDate(wSDataSharingBObj
					.getStartDate());
			finalWSDataSharingBObj.setLastModifiedSystemDate(wSDataSharingBObj
					.getLastModifiedSystemDate());

			addNewDataSharingforSurvivedParty(control, collapsedPartyId,
					finalWSDataSharingBObj, dseaAdditionsExtsComponent);

		}
	}
	
	public void surviveContractFSDetailsForJapanPerformance(Vector<XContractRelJPNBObj> vecContractRelDetailsJPNBObj,
			TCRMPartyBObj collapsedPartyBObj, DWLControl control)
			throws Exception {
		HashMap<String, XContractRelJPNBObj> xContractDetailsMap = new HashMap<String, XContractRelJPNBObj>();
		Vector<XContractRelJPNBObj> vecXContractDetailsBObjs = new Vector<XContractRelJPNBObj>();
		DWLResponse dwlResponse = new DWLResponse();
		DWLResponse response = null;
		DSEAAdditionsExtsComponent dseaAdditionsExtsComponent = new DSEAAdditionsExtsComponent();
		String contractNumber = null;
		String collapsedPartyId = collapsedPartyBObj.getPartyId();
		for (int j = 0; j < vecContractRelDetailsJPNBObj.size(); j++) {
			XContractRelJPNBObj xContractRelBObj = (XContractRelJPNBObj) vecContractRelDetailsJPNBObj
					.get(j);
					xContractDetailsMap.put(xContractRelBObj.getContId()+xContractRelBObj.getContractId(),xContractRelBObj);
		}
		validateContractRelationship(xContractDetailsMap,control);
		
		for (Map.Entry<String, XContractRelJPNBObj> entry : xContractDetailsMap
				.entrySet()) {
			XContractRelJPNBObj tempXContractRelBObj = entry.getValue();
			XContractRelJPNBObj survivedXContractRelBObj = new XContractRelJPNBObj();
			XContractRelJPNBObj inactivexContractRelBObj = endExistingContractRelJPN(control,tempXContractRelBObj.getContId(),tempXContractRelBObj.getContractId(),dseaAdditionsExtsComponent);
						
			survivedXContractRelBObj = tempXContractRelBObj;
			survivedXContractRelBObj.setContId(collapsedPartyId);
			survivedXContractRelBObj.setControl(control);				
			addNewContractRelJPNforSurvivedParty(control,survivedXContractRelBObj.getContId(),survivedXContractRelBObj.getContractId(),dseaAdditionsExtsComponent,inactivexContractRelBObj);			
		}
	}
	
	public void surviveCustomerRetailerForJapanPerformance(Vector<XCustomerRetailerJPNBObj> vecCustomeRetailerDetailsJPNBObj,
			TCRMPartyBObj collapsedPartyBObj, DWLControl control)
			throws Exception {
		HashMap<String, XCustomerRetailerJPNBObj> xCustomerRetailerMap = new HashMap<String, XCustomerRetailerJPNBObj>();
		Vector<XCustomerRetailerJPNBObj> vecXCustomerRetailerJPNBObjs = new Vector<XCustomerRetailerJPNBObj>();
		DWLResponse dwlResponse = new DWLResponse();
		DWLResponse response = null;
		DSEAAdditionsExtsComponent dseaAdditionsExtsComponent = new DSEAAdditionsExtsComponent();
		String partytId = null;
		String ndCode = null;
		Vector<XRetailerBObj> vecDBRetailBObj = null;
		String collapsedPartyId = collapsedPartyBObj.getPartyId();

		for (int j = 0; j < vecCustomeRetailerDetailsJPNBObj.size(); j++) {
			XCustomerRetailerJPNBObj xCustomerRetailerBObj = (XCustomerRetailerJPNBObj) vecCustomeRetailerDetailsJPNBObj
					.get(j);
			if (!xCustomerRetailerMap.containsKey(xCustomerRetailerBObj
					.getXRetailerBObj().getNDCode())) {
				xCustomerRetailerMap.put(xCustomerRetailerBObj
						.getXRetailerBObj().getNDCode(),
						xCustomerRetailerBObj);
			} else {
				XCustomerRetailerJPNBObj xContretailerBObjInMap = xCustomerRetailerMap
						.get(xCustomerRetailerBObj.getXRetailerBObj()
								.getNDCode());
				Timestamp requestPersonLastModifiedDt = DateFormatter
						.getTimestamp(xContretailerBObjInMap
								.getXRetailerBObj()
								.getLastModifiedSystemDate());
				Timestamp existingPersonLastModifiedDt = DateFormatter
						.getTimestamp(xCustomerRetailerBObj
								.getXRetailerBObj()
								.getLastModifiedSystemDate());
				if (requestPersonLastModifiedDt.after(existingPersonLastModifiedDt)) {
					xCustomerRetailerMap.put(xContretailerBObjInMap
							.getXRetailerBObj().getNDCode(),
							xContretailerBObjInMap);
				} else {
					xCustomerRetailerMap.put(xCustomerRetailerBObj
							.getXRetailerBObj().getNDCode(),
							xCustomerRetailerBObj);
				}

			}

		}

		for (Map.Entry<String, XCustomerRetailerJPNBObj> entry : xCustomerRetailerMap
				.entrySet()) {
			XCustomerRetailerJPNBObj tempXCustomerRetailerBObj = entry.getValue();
			XCustomerRetailerJPNBObj survivedXCustomerRetailerBObj = new XCustomerRetailerJPNBObj();
			survivedXCustomerRetailerBObj = tempXCustomerRetailerBObj;
			survivedXCustomerRetailerBObj.setContId(collapsedPartyId);
			survivedXCustomerRetailerBObj.setControl(control);
			ndCode = survivedXCustomerRetailerBObj.getXRetailerBObj()
					.getNDCode();
			vecDBRetailBObj = retailerObjectByNDCode(ndCode,
					control);
			if (vecDBRetailBObj == null || vecDBRetailBObj.isEmpty()) {
				response = dseaAdditionsExtsComponent
						.addXCustomerRetailerJPN(survivedXCustomerRetailerBObj);
			} else {
				survivedXCustomerRetailerBObj.getXRetailerBObj()
						.setRetailerpkId(
								vecDBRetailBObj.get(0).getRetailerpkId());
				survivedXCustomerRetailerBObj.getXRetailerBObj()
						.setXRetailerLastUpdateDate(
								vecDBRetailBObj.get(0)
										.getXRetailerLastUpdateDate());
				survivedXCustomerRetailerBObj.setRetailerId(vecDBRetailBObj
						.get(0).getRetailerpkId());
				response = dseaAdditionsExtsComponent
						.addXCustomerRetailerJPN(survivedXCustomerRetailerBObj);
			}
			if (response.getStatus().getStatus() == DWLStatus.FATAL) {
				throw new BusinessProxyException();
			}
		}
	}
	
	public static XRetailerBObj getXRetailerByRetailerId (String retailerId)  throws Exception  {
		SQLQuery sqlQuery = new SQLQuery();
		ResultSet objResultSet = null;
		String retailerIdSql = ExternalRuleConstant.SEARCH_RETAILER_DETAILS_RETAILERID;
		List<SQLParam> params = new ArrayList<SQLParam>();
		XRetailerBObj finalXRetailerBObj=null;
		String last_updt_dt=null;
		try {
			params = new ArrayList<SQLParam>();
			params.add(0, new SQLParam(retailerId));
			objResultSet = sqlQuery.executeQuery(retailerIdSql, params);
			while (objResultSet.next()) {
				XRetailerBObj newXRetailerBObj = new XRetailerBObj();
				
				newXRetailerBObj.setRetailerpkId(objResultSet.getString("RETAILERPK_ID"));
				newXRetailerBObj.setRetailerCode(objResultSet.getString("RETAILER_CODE"));
				newXRetailerBObj.setRetailerName(objResultSet.getString("RETAILER_NAME"));
				newXRetailerBObj.setBranchName(objResultSet.getString("BRANCH_NAME"));
				newXRetailerBObj.setSourceIdentifierType(objResultSet.getString("SOURCE_IDENT_TP_CD"));
				newXRetailerBObj.setGSCode(objResultSet.getString("GS_CODE"));
				newXRetailerBObj.setGCCode(objResultSet.getString("GC_CODE"));
				newXRetailerBObj.setLastModifiedSystemDate(objResultSet.getString("MODIFY_SYS_DT"));
				newXRetailerBObj.setNDCode(objResultSet.getString("ND_CODE"));
				newXRetailerBObj.setMarketName(objResultSet.getString("MARKET_NAME"));
				newXRetailerBObj.setDealerActiveFlag(objResultSet.getString("DEALER_ACTIVE_FLAG"));
				newXRetailerBObj.setDealerGroup(objResultSet.getString("DEALER_GROUP"));
				newXRetailerBObj.setDealerRolloutFlag(objResultSet.getString("DEALER_ROLLOUT_FLAG"));
				newXRetailerBObj.setBatchInd(objResultSet.getString("BATCH_IND"));
				newXRetailerBObj.setCreateDate(objResultSet.getString("CREATE_DT"));
				newXRetailerBObj.setChangedDate(objResultSet.getString("CHANGED_DT"));
				newXRetailerBObj.setCRMCompanyCode(objResultSet.getString("CRM_COMPANY_CODE"));
				newXRetailerBObj.setXRetailerLastUpdateDate(objResultSet.getString("LAST_UPDATE_DT"));
				newXRetailerBObj.setXRetailerLastUpdateTxId(objResultSet.getString("LAST_UPDATE_TX_ID"));
				newXRetailerBObj.setXRetailerLastUpdateUser(objResultSet.getString("LAST_UPDATE_USER"));
				
				finalXRetailerBObj = newXRetailerBObj;
			}
		} catch (Exception ex) {
			if (objResultSet != null) {
				objResultSet.close();
			}
			logger.finest(ex.getMessage());
		}finally{			
			if(objResultSet != null)
				objResultSet.close();
			sqlQuery.close();		
		}
		return finalXRetailerBObj;
	}
	
	public void surviveCustomerRelationshipForJapanPerformance(Vector<XContactRelBObjExt> vecContactRelationshipDetailsJPNBObj,TCRMPartyBObj collapsedPartyBObj, DWLControl control) throws Exception 
	{
		String partytId = null;
		String partyType = null;
		TCRMPartyComponent partyComponent = new TCRMPartyComponent();
		String mapKey = null;
		String requestCompanyId = null;
		String existingCompanyId = null;
		String requestRelationshipType = null;
		String existingRelationshipType = null;
		String requestPersonRetailerCode = null;
		String existingPersonRetailerCode = null;
		String requestPersonContId = null;
		String existingPersonContId = null;
		String requestOrgRetailerCode = null;
		String existingOrgRetailerCode = null;
		XContactRelBObjExt xRelRequestObject = new XContactRelBObjExt();
		HashMap<String, XContactRelBObjExt> xCustomerRelationshipMap = new HashMap<String, XContactRelBObjExt>();
		String collapsedPartyId = collapsedPartyBObj.getPartyId();
			
		partyType = collapsedPartyBObj.getPartyType();
		if(partyType!=null && partyType.equalsIgnoreCase("P"))
		{
			
			if (vecContactRelationshipDetailsJPNBObj != null && vecContactRelationshipDetailsJPNBObj.size() > 0) 
			{
				
				for (int j = 0; j < vecContactRelationshipDetailsJPNBObj.size(); j++) 
				{
					XContactRelBObjExt xContactRelBObjExt = (XContactRelBObjExt) vecContactRelationshipDetailsJPNBObj.get(j);
					mapKey = xContactRelBObjExt.getRelationshipDescription()+xContactRelBObjExt.getXRetailerCode() ;
					
					if(xContactRelBObjExt.getXRetailerCode()!=null)
					{
						
					if (!xCustomerRelationshipMap.containsKey(mapKey)) 
					{	
						xCustomerRelationshipMap.put(mapKey,xContactRelBObjExt);
						
					} else 
					{
						XContactRelBObjExt xContactRelBObjInMap = xCustomerRelationshipMap.get(mapKey);
						
						requestCompanyId = xContactRelBObjInMap.getRelationshipToPartyId();
						existingCompanyId = xContactRelBObjExt.getRelationshipToPartyId();
						
						requestPersonRetailerCode = xContactRelBObjInMap.getXRetailerCode();
						existingPersonRetailerCode = xContactRelBObjExt.getXRetailerCode();
						requestRelationshipType = xContactRelBObjInMap.getRelationshipDescription();
						existingRelationshipType = xContactRelBObjExt.getRelationshipDescription();
						
						//Same Relationship type
						if(requestRelationshipType != null && existingRelationshipType != null && requestRelationshipType.equalsIgnoreCase(existingRelationshipType))
						{

							//Same Retailer Code
							if (requestPersonRetailerCode != null && existingPersonRetailerCode != null && requestPersonRetailerCode.equalsIgnoreCase(existingPersonRetailerCode)) 
							{			
								Timestamp requestPersonLastModifiedDt = DateFormatter.getTimestamp(xContactRelBObjInMap.getXLastModifiedSystemDate());										
								Timestamp existingPersonLastModifiedDt = DateFormatter.getTimestamp(xContactRelBObjExt.getXLastModifiedSystemDate());
								
								//Same company Id
								if (requestCompanyId != null && existingCompanyId != null && requestCompanyId.equalsIgnoreCase(existingCompanyId)) 
								{	
									
									if (requestPersonLastModifiedDt.after(existingPersonLastModifiedDt)) 
									{					
										xCustomerRelationshipMap.put(mapKey,xContactRelBObjInMap);
									}
									else
									{
										xCustomerRelationshipMap.put(mapKey,xContactRelBObjExt);
									}
																	
								}
								else
								{
									if (requestPersonLastModifiedDt.after(existingPersonLastModifiedDt)) 
									{					
										xCustomerRelationshipMap.put(mapKey,xContactRelBObjInMap);
									}
									else
									{
										xCustomerRelationshipMap.put(mapKey,xContactRelBObjExt);
									}
								}
							}
							else
							{
								//Different Retailer Code
								if (requestCompanyId != null && existingCompanyId != null && requestCompanyId.equalsIgnoreCase(existingCompanyId)) {
								
									xCustomerRelationshipMap.put(mapKey,xContactRelBObjExt);
								}
							}
						}
						else
						{
							//Different Relationship description
							xCustomerRelationshipMap.put(mapKey,xContactRelBObjExt);
						}
					}
				}
					else
					{
						if (!xCustomerRelationshipMap.containsKey(mapKey)) 
						{	
							xCustomerRelationshipMap.put(mapKey,xContactRelBObjExt);
							
						} else 
						{
							XContactRelBObjExt xContactRelBObjInMap = xCustomerRelationshipMap.get(mapKey);
							
							//Same Relationship type
							if(requestRelationshipType != null && existingRelationshipType != null && requestRelationshipType.equalsIgnoreCase(existingRelationshipType))
							{
								Timestamp requestPersonLastModifiedDt = DateFormatter.getTimestamp(xContactRelBObjInMap.getXLastModifiedSystemDate());										
								Timestamp existingPersonLastModifiedDt = DateFormatter.getTimestamp(xContactRelBObjExt.getXLastModifiedSystemDate());
								
								//Incoming C2C latest
								if (requestPersonLastModifiedDt.after(existingPersonLastModifiedDt))
								{				
									xCustomerRelationshipMap.put(mapKey,xContactRelBObjInMap);
								}
								//Existing C2C latest
								else 
								{										
									xCustomerRelationshipMap.put(mapKey,xContactRelBObjExt);										
								}
							}
						}
					}
				}
			}
		}
			
			else 
			{							
				if (vecContactRelationshipDetailsJPNBObj != null && vecContactRelationshipDetailsJPNBObj.size() > 0) 
				{
					
					for (int j = 0; j < vecContactRelationshipDetailsJPNBObj.size(); j++) 
					{
						XContactRelBObjExt xContactRelBObjExt = (XContactRelBObjExt) vecContactRelationshipDetailsJPNBObj.get(j);
						mapKey = xContactRelBObjExt.getRelationshipDescription()+xContactRelBObjExt.getXRetailerCode()+xContactRelBObjExt.getRelationshipToPartyId();
						
						if(xContactRelBObjExt.getXRetailerCode()!=null)
						{
							
						if (!xCustomerRelationshipMap.containsKey(xContactRelBObjExt.getXRetailerCode())) 
						{								
							xCustomerRelationshipMap.put(mapKey,xContactRelBObjExt);
							
						}
						else 
						{
							XContactRelBObjExt xContactRelBObjInMap = xCustomerRelationshipMap.get(mapKey);
							
							requestPersonContId = xContactRelBObjInMap.getRelationshipToPartyId();
							existingPersonContId = xContactRelBObjExt.getRelationshipToPartyId();
							
							requestOrgRetailerCode = xContactRelBObjInMap.getXRetailerCode();
							existingOrgRetailerCode = xContactRelBObjExt.getXRetailerCode();
							requestRelationshipType = xContactRelBObjInMap.getRelationshipDescription();
							existingRelationshipType = xContactRelBObjExt.getRelationshipDescription();
							
							//Same Relationship Description
							if(requestRelationshipType != null && existingRelationshipType != null && requestRelationshipType.equalsIgnoreCase(existingRelationshipType))
							{

								//Same Retailer Code
								if (requestOrgRetailerCode != null && existingOrgRetailerCode != null && requestOrgRetailerCode.equalsIgnoreCase(existingOrgRetailerCode)) 
								{
									
									//Same Person contId
									if (requestPersonContId != null && existingPersonContId != null && requestPersonContId.equalsIgnoreCase(existingPersonContId)) 
									{
										
										Timestamp requestPersonLastModifiedDt = DateFormatter.getTimestamp(xContactRelBObjInMap.getXLastModifiedSystemDate());
										Timestamp existingPersonLastModifiedDt = DateFormatter.getTimestamp(xContactRelBObjExt.getXLastModifiedSystemDate());
										
										//incoming C2C latest
										if (requestPersonLastModifiedDt.after(existingPersonLastModifiedDt))
										{	
											xCustomerRelationshipMap.put((xContactRelBObjInMap.getRelationshipDescription()+xContactRelBObjInMap.getXRetailerCode()+xContactRelBObjInMap.getRelationshipToPartyId()),xContactRelBObjInMap);
										}
										//Existing latest
										else 
										{	
											xCustomerRelationshipMap.put(mapKey,xContactRelBObjExt);
										}
									}
									 else 
									 {
											//different Person contId
											xCustomerRelationshipMap.put(mapKey,xContactRelBObjExt);
									 }
								}
								
								else 
								{
									//Different Retailer code
									if (requestPersonContId != null && existingPersonContId != null && requestPersonContId.equalsIgnoreCase(existingPersonContId)) 
									{						
										xCustomerRelationshipMap.put(mapKey,xContactRelBObjExt);
									}
								}
							}
							
							 else 
							 {
									//Different Relationship Description
									xCustomerRelationshipMap.put(mapKey,xContactRelBObjExt);
							 }
						}
					}
						else
						{
							if (!xCustomerRelationshipMap.containsKey(mapKey)) 
							{	
								xCustomerRelationshipMap.put(mapKey,xContactRelBObjExt);
								
							} else 
							{
								XContactRelBObjExt xContactRelBObjInMap = xCustomerRelationshipMap.get(mapKey);
								
								//Same Relationship type
								if(requestRelationshipType != null && existingRelationshipType != null && requestRelationshipType.equalsIgnoreCase(existingRelationshipType))
								{
									Timestamp requestPersonLastModifiedDt = DateFormatter.getTimestamp(xContactRelBObjInMap.getXLastModifiedSystemDate());										
									Timestamp existingPersonLastModifiedDt = DateFormatter.getTimestamp(xContactRelBObjExt.getXLastModifiedSystemDate());
									
									//Incoming C2C latest
									if (requestPersonLastModifiedDt.after(existingPersonLastModifiedDt))
									{				
										xCustomerRelationshipMap.put(mapKey,xContactRelBObjInMap);
									}
									//Existing C2C latest
									else 
									{										
										xCustomerRelationshipMap.put(mapKey,xContactRelBObjExt);										
									}
								}
							}
						}
					}
				}
			}		
		
		Vector<XContactRelBObjExt> survivedXContactRelBobjs = new Vector<XContactRelBObjExt>();
		for(String key : xCustomerRelationshipMap.keySet())
		{
			survivedXContactRelBobjs.add(xCustomerRelationshipMap.get(key));
		}
		
		for (  XContactRelBObjExt survivedXContactRelBObjExt: survivedXContactRelBobjs) 
		{			
			xRelRequestObject.setRelationshipType(survivedXContactRelBObjExt.getRelationshipType());
			xRelRequestObject.setRelationshipValue(survivedXContactRelBObjExt.getRelationshipValue());
			xRelRequestObject.setRelationshipDescription(survivedXContactRelBObjExt.getRelationshipDescription());
			xRelRequestObject.setXContactRelRetailerFlag(survivedXContactRelBObjExt.getXContactRelRetailerFlag());
			xRelRequestObject.setXRetailerCode(survivedXContactRelBObjExt.getXRetailerCode());
			xRelRequestObject.setXSourceIdentifierType(survivedXContactRelBObjExt.getXSourceIdentifierType());
			xRelRequestObject.setXContactPosition(survivedXContactRelBObjExt.getXContactPosition());		
			xRelRequestObject.setXContactRole(survivedXContactRelBObjExt.getXContactRole());				
			xRelRequestObject.setXLastModifiedSystemDate(survivedXContactRelBObjExt.getXLastModifiedSystemDate());
			xRelRequestObject.setControl(survivedXContactRelBObjExt.getControl());
			xRelRequestObject.setDeleteFlag(survivedXContactRelBObjExt.getDeleteFlag());
			
			if(partyType!=null && partyType.equalsIgnoreCase("P"))
			{
				xRelRequestObject.setRelationshipFromValue(survivedXContactRelBObjExt.getRelationshipToPartyId());
				xRelRequestObject.setRelationshipToValue(collapsedPartyId);
			} else 
			{
					xRelRequestObject.setRelationshipFromValue(survivedXContactRelBObjExt.getRelationshipToPartyId());
					xRelRequestObject.setRelationshipToValue(collapsedPartyId);
			}

				partyComponent.addPartyRelationship(xRelRequestObject);	
		}
		
	}
	
	public static XVehicleJPNBObj getXVehicleByVehicleId (String vehicleId)  throws Exception  {
		SQLQuery sqlQuery = new SQLQuery();
		ResultSet objResultSet = null;
		String vehicleIdSql = ExternalRuleConstant.SEARCH_XVEHICLE_DETAILS_VEHICLEID;
		List<SQLParam> params = new ArrayList<SQLParam>();
		XVehicleJPNBObj finalXVehicleBObj=null;
		try {
			params = new ArrayList<SQLParam>();
			params.add(0, new SQLParam(vehicleId));
			objResultSet = sqlQuery.executeQuery(vehicleIdSql, params);
			while (objResultSet.next()) {
				XVehicleJPNBObj newXVehicleBObj = new XVehicleJPNBObj();				
				newXVehicleBObj.setXVehicleJPNpkId(objResultSet.getString("XVEHICLE_JPNPK_ID"));
				newXVehicleBObj.setGlobalVIN(objResultSet.getString("GLOBAL_VIN"));
				newXVehicleBObj.setBauMuster(objResultSet.getString("BAU_MUSTER"));
				newXVehicleBObj.setTypeClass(objResultSet.getString("TYPE_CLASS"));
				newXVehicleBObj.setSubMuster(objResultSet.getString("SUB_MUSTER"));				
				newXVehicleBObj.setColor(objResultSet.getString("COLOR"));
				newXVehicleBObj.setTrim(objResultSet.getString("TRIM"));
				newXVehicleBObj.setBatchInd(objResultSet.getString("BATCH_IND"));
				newXVehicleBObj.setMarketName(objResultSet.getString("MARKET_NAME"));				
				newXVehicleBObj.setSourceIdentifierType(objResultSet.getString("SOURCE_IDENT_TP_CD"));
				newXVehicleBObj.setLastModifiedSystemDate(objResultSet.getString("MODIFY_SYS_DT"));
				newXVehicleBObj.setCreateDate(objResultSet.getString("CREATE_DT"));
				newXVehicleBObj.setChangedDate(objResultSet.getString("CHANGED_DT"));
				newXVehicleBObj.setLastServiceDate(objResultSet.getString("LAST_SERVICE_DT"));
				newXVehicleBObj.setSFDCId(objResultSet.getString("SFDC_ID"));		
				newXVehicleBObj.setVehicleAddressType(objResultSet.getString("VEHICLE_ADDRESS_TYPE"));
				newXVehicleBObj.setVehicleType(objResultSet.getString("VEHICLE_TYPE"));							
				newXVehicleBObj.setDeleteFlag(objResultSet.getString("DELETE_FLAG"));
				newXVehicleBObj.setEndDate(objResultSet.getString("END_DT"));
				newXVehicleBObj.setEngineNumber(objResultSet.getString("ENGINE_NUM"));
				newXVehicleBObj.setMyCarId(objResultSet.getString("MYCAR_ID"));				
				newXVehicleBObj.setXVehicleJPNLastUpdateDate(objResultSet.getString("LAST_UPDATE_DT"));
				newXVehicleBObj.setXVehicleJPNLastUpdateTxId(objResultSet.getString("LAST_UPDATE_TX_ID"));
				newXVehicleBObj.setXVehicleJPNLastUpdateUser(objResultSet.getString("LAST_UPDATE_USER"));				
				finalXVehicleBObj = newXVehicleBObj;
			}
		} catch (Exception ex) {
			logger.finest(ex.getMessage());
		}finally{			
			if(objResultSet != null)
				objResultSet.close();
			sqlQuery.close();			
		}
		return finalXVehicleBObj;
	}
	
	public static Vector<XCustomerVehicleRoleJPNBObj> getXVehcileRoleByVehcileRelId(String vehicleRelId) throws BusinessProxyException, SQLException{		
		SQLQuery sqlQuery = new SQLQuery();
		ResultSet objResultSet = null;
		String vehicleRoleIdSql = ExternalRuleConstant.SEARCH_XCUSTVEHICLEROLE_DETAILS_VEHRELID;
		List<SQLParam> params = new ArrayList<SQLParam>(); 
		Vector<XCustomerVehicleRoleJPNBObj> vecVehicleRoleDetailsJPNBObj = new Vector<XCustomerVehicleRoleJPNBObj>();
		try {
			params = new ArrayList<SQLParam>();
			params.add(0, new SQLParam(vehicleRelId));
			objResultSet = sqlQuery.executeQuery(vehicleRoleIdSql,params);
			while (objResultSet.next()) {					
				XCustomerVehicleRoleJPNBObj newVehicleRoleDetailsJPNBObj= new XCustomerVehicleRoleJPNBObj();		
				
				newVehicleRoleDetailsJPNBObj.setXCustomerVehicleRoleJPNpkId(objResultSet.getString("XCUSTOMERVEHICLEROLEJPNPK_ID"));
				newVehicleRoleDetailsJPNBObj.setCustomerVehicleId(objResultSet.getString("CUSTOMER_VEHICLE_ID"));
				newVehicleRoleDetailsJPNBObj.setVehicleRoleType(objResultSet.getString("VEHICLE_ROLE_TP_CD"));
				newVehicleRoleDetailsJPNBObj.setStartDate(objResultSet.getString("START_DT"));
				newVehicleRoleDetailsJPNBObj.setEndDate(objResultSet.getString("END_DT"));
				newVehicleRoleDetailsJPNBObj.setSourceIdentifierType(objResultSet.getString("SOURCE_IDENT_TP_CD"));
				newVehicleRoleDetailsJPNBObj.setChangedDate(objResultSet.getString("CHANGED_DT"));
				newVehicleRoleDetailsJPNBObj.setXCustomerVehicleRoleJPNLastUpdateDate(objResultSet.getString("LAST_UPDATE_DT"));
				newVehicleRoleDetailsJPNBObj.setXCustomerVehicleRoleJPNLastUpdateTxId(objResultSet.getString("LAST_UPDATE_TX_ID"));
				newVehicleRoleDetailsJPNBObj.setXCustomerVehicleRoleJPNLastUpdateUser(objResultSet.getString("LAST_UPDATE_USER"));						
				
				vecVehicleRoleDetailsJPNBObj.add(newVehicleRoleDetailsJPNBObj);
			}		
		} catch (Exception ex) {
			ex.printStackTrace();
		}finally{
			
			if(null!= objResultSet && !objResultSet.isClosed())
			{
				objResultSet.close();
			}
			
			if(sqlQuery!= null)
			{
				sqlQuery.close();
			}
					
		}
		return vecVehicleRoleDetailsJPNBObj;
	}
	
	public void surviveCustomerVehicleForJapanPerformance(Vector<XCustomerVehicleJPNBObj> vecCustomerVehicleDetailsJPNBObj,
			TCRMPartyBObj collapsedPartyBObj, DWLControl control)
			throws Exception {
		HashMap<String, XCustomerVehicleJPNBObj> xCustomerVehicleMap = new HashMap<String, XCustomerVehicleJPNBObj>();			
		Vector<XCustomerVehicleJPNBObj> vecXCustomerVehicleBObjs = new Vector<XCustomerVehicleJPNBObj>();			
		DWLResponse dwlResponse = new DWLResponse();
		DWLResponse response = null;
		DSEAAdditionsExtsComponent dseaAdditionsExtsComponent = new DSEAAdditionsExtsComponent();
		String partytId = null;
		String globalVIN = null;
		String requestPersonRetailerCode = null;
		String existingPersonRetailerCode = null;
		//Vector<XVehicleBObj> vecDBVehicleBObj = null;
		String collapsedPartyId = collapsedPartyBObj.getPartyId();
		Vector<XCustomerVehicleRoleJPNBObj> vecParty1XCustomerVehicleRoleBObjs = new Vector<XCustomerVehicleRoleJPNBObj>();
		Vector<XCustomerVehicleRoleJPNBObj> vecParty2XCustomerVehicleRoleBObjs = new Vector<XCustomerVehicleRoleJPNBObj>();
		Vector<XCustomerVehicleRoleJPNBObj> vecSurvivedVehicleRoleBObjs = new Vector<XCustomerVehicleRoleJPNBObj>();
		Vector <XCustomerVehicleJPNBObj> VecUnmergedXCustomerVehicleJPNBObj = new Vector<XCustomerVehicleJPNBObj>();
		HashMap<String, Vector<XCustomerVehicleJPNBObj>> finalCustomerVehicleMap = new HashMap<String, Vector<XCustomerVehicleJPNBObj>>();
		
		boolean toBeMerged = false;

			//partytId = partyBObj.getPartyId();
			//vecXCustomerVehicleBObjs = getAllXCustomerVehicleByPartyId(partytId, control);
			//DWLResponse response1 = dseaAdditionsExtsComponent.getAllXCustomerVehicleJPNByPartyId(partytId, control);
			//vecXCustomerVehicleBObjs = (Vector<XCustomerVehicleJPNBObj>)response1.getData();
			
			Vector<XCustomerVehicleJPNBObj> vecXCustomerVehicleRetailBObjs = new Vector<XCustomerVehicleJPNBObj>();
			Vector<XCustomerVehicleJPNBObj> vecXCustomerVehicleWholesaleBObjs = new Vector<XCustomerVehicleJPNBObj>();
			
			
			
			if (vecCustomerVehicleDetailsJPNBObj != null
					&& vecCustomerVehicleDetailsJPNBObj.size() > 0) {
				
				for(XCustomerVehicleJPNBObj tempCustomerVehicleJPNBObj:vecCustomerVehicleDetailsJPNBObj)
				{
					if(tempCustomerVehicleJPNBObj.getRetailerId()!=null)
					{
						vecXCustomerVehicleRetailBObjs.add(tempCustomerVehicleJPNBObj);
					}
					else
					{
						vecXCustomerVehicleWholesaleBObjs.add(tempCustomerVehicleJPNBObj);
					}
				}
				
				/*for (int j = 0; j < vecXCustomerVehicleBObjs.size(); j++) 
				{
					XCustomerVehicleJPNBObj xCustomerVehicleBObj = (XCustomerVehicleJPNBObj) vecXCustomerVehicleBObjs
							.get(j);
					if(xCustomerVehicleBObj.getRetailerId()!=null )//&& checkIfCVRActive(xCustomerVehicleBObj.getEndDate()) )
					{*/
					if(vecXCustomerVehicleRetailBObjs.size()>0)
					{
						if(vecXCustomerVehicleRetailBObjs.size()==1)
						{
							XCustomerVehicleJPNBObj xCustomerVehicleBObj = (XCustomerVehicleJPNBObj) vecXCustomerVehicleRetailBObjs.get(0);
							if (!xCustomerVehicleMap.containsKey((xCustomerVehicleBObj
									.getXVehicleJPNBObj().getGlobalVIN()) + xCustomerVehicleBObj
									.getXVehicleJPNBObj().getVehicleType()+ (xCustomerVehicleBObj.getRetailerId()))) 
							{
								xCustomerVehicleMap.put((xCustomerVehicleBObj
										.getXVehicleJPNBObj().getGlobalVIN()) +  xCustomerVehicleBObj
										.getXVehicleJPNBObj().getVehicleType() + (xCustomerVehicleBObj.getRetailerId()),
										xCustomerVehicleBObj);
							} 
							
							else 
							{
								XCustomerVehicleJPNBObj xContVehicleBObjInMap = xCustomerVehicleMap.get((xCustomerVehicleBObj
												.getXVehicleJPNBObj().getGlobalVIN()) +  xCustomerVehicleBObj
												.getXVehicleJPNBObj().getVehicleType() + (xCustomerVehicleBObj.getRetailerId()));
								requestPersonRetailerCode = xContVehicleBObjInMap
										.getRetailerId();
								existingPersonRetailerCode = xCustomerVehicleBObj
										.getRetailerId();
								
								if (requestPersonRetailerCode != null
										&& existingPersonRetailerCode != null
										&& requestPersonRetailerCode
												.equalsIgnoreCase(existingPersonRetailerCode)) 
								{			
									//sort VR based on start date
									Vector <XCustomerVehicleJPNBObj> tempVecXCustomerVehicleJPNBObj = new Vector<XCustomerVehicleJPNBObj>();
									tempVecXCustomerVehicleJPNBObj.add(xContVehicleBObjInMap);
									tempVecXCustomerVehicleJPNBObj.add(xCustomerVehicleBObj);
									
									if(xContVehicleBObjInMap.getStartDate()!=null && xCustomerVehicleBObj.getStartDate()!=null)
									{
										Collections.sort(tempVecXCustomerVehicleJPNBObj,
												new Comparator<XCustomerVehicleJPNBObj>() {// Ascending sort
																					// - for delta
																					// load
													public int compare(XCustomerVehicleJPNBObj xCustomerVehicleJPN1,
															XCustomerVehicleJPNBObj xCustomerVehicleJPN2) {
														
														return xCustomerVehicleJPN1
																.getStartDate()
																.compareTo(
																		xCustomerVehicleJPN2.getStartDate());
													}
												});
									}
																
									SimpleDateFormat simpleDateFmt = new SimpleDateFormat("yyyy-MM-dd");
									java.util.Date xCustomerVehicleJPN1EndDt =null;
									java.util.Date xCustomerVehicleJPN2StartDt =null;
									//java.util.Date xCustomerVehicleJPN2EndDt =null;
									
									toBeMerged = false;
									
									if(tempVecXCustomerVehicleJPNBObj.get(0).getEndDate()!=null && 
											tempVecXCustomerVehicleJPNBObj.get(1).getStartDate()!=null)
									{
									xCustomerVehicleJPN1EndDt =simpleDateFmt.parse(tempVecXCustomerVehicleJPNBObj.get(0).getEndDate());
									xCustomerVehicleJPN2StartDt =simpleDateFmt.parse(tempVecXCustomerVehicleJPNBObj.get(1).getStartDate());
									
									long difference = xCustomerVehicleJPN2StartDt.getTime() - xCustomerVehicleJPN1EndDt.getTime();
									float daysBetween = (difference / (1000*60*60*24));
									if(daysBetween<=1)
									{
										toBeMerged = true;
									}
									}
									else if(tempVecXCustomerVehicleJPNBObj.get(0).getEndDate()==null)
									{
										toBeMerged = true;
									}
									if(toBeMerged)
									{
									vecParty1XCustomerVehicleRoleBObjs = xContVehicleBObjInMap.getItemsXCustomerVehicleRoleJPNBObj();
									vecParty2XCustomerVehicleRoleBObjs = xCustomerVehicleBObj.getItemsXCustomerVehicleRoleJPNBObj();
									Vector<XCustomerVehicleRoleJPNBObj> vecFinalVehicleRoleBObjs = new Vector<XCustomerVehicleRoleJPNBObj>();
									HashMap<String, XCustomerVehicleRoleJPNBObj> xCustomerVehicleRoleMap = new HashMap<String, XCustomerVehicleRoleJPNBObj>();
									for(XCustomerVehicleRoleJPNBObj Party1XCustomerVehicleRoleBObj :vecParty1XCustomerVehicleRoleBObjs)
									{
										if(!xCustomerVehicleRoleMap.containsKey(Party1XCustomerVehicleRoleBObj.getVehicleRoleType()))
										{
											xCustomerVehicleRoleMap.put(Party1XCustomerVehicleRoleBObj.getVehicleRoleType(), Party1XCustomerVehicleRoleBObj);
										}
									}
									
									for(XCustomerVehicleRoleJPNBObj Party2XCustomerVehicleRoleBObj :vecParty2XCustomerVehicleRoleBObjs)
									{
										if(!xCustomerVehicleRoleMap.containsKey(Party2XCustomerVehicleRoleBObj.getVehicleRoleType()))
										{
											xCustomerVehicleRoleMap.put(Party2XCustomerVehicleRoleBObj.getVehicleRoleType(), Party2XCustomerVehicleRoleBObj);
										}
										else
										{
											XCustomerVehicleRoleJPNBObj Party1XCustomerVehicleRoleBObj = xCustomerVehicleRoleMap.get(Party2XCustomerVehicleRoleBObj.getVehicleRoleType());
											
											/*
											Timestamp Person1RoleLastModifiedDt = DateFormatter.getTimestamp(Party1XCustomerVehicleRoleBObj.getXCustomerVehicleRoleJPNLastUpdateDate());
											Timestamp Person2RoleLastModifiedDt = DateFormatter.getTimestamp(Party2XCustomerVehicleRoleBObj.getXCustomerVehicleRoleJPNLastUpdateDate());
											if(Person2RoleLastModifiedDt.after(Person1RoleLastModifiedDt))
											{
												xCustomerVehicleRoleMap.put(Party2XCustomerVehicleRoleBObj.getVehicleRoleType(), Party2XCustomerVehicleRoleBObj);
											}
											*/
											Vector <XCustomerVehicleRoleJPNBObj> tempVecXCustomerVehicleRoleJPNBObj = new Vector<XCustomerVehicleRoleJPNBObj>();
											tempVecXCustomerVehicleRoleJPNBObj.add(Party1XCustomerVehicleRoleBObj);
											tempVecXCustomerVehicleRoleJPNBObj.add(Party2XCustomerVehicleRoleBObj);
											
											if(Party1XCustomerVehicleRoleBObj.getStartDate()!=null && Party2XCustomerVehicleRoleBObj.getStartDate()!=null)
											{
												Collections.sort(tempVecXCustomerVehicleRoleJPNBObj,
														new Comparator<XCustomerVehicleRoleJPNBObj>() {// Ascending sort
																							// - for delta
																							// load
															public int compare(XCustomerVehicleRoleJPNBObj xCustomerVehicleRoleJPN1,
																	XCustomerVehicleRoleJPNBObj xCustomerVehicleRoleJPN2) {
																
																return xCustomerVehicleRoleJPN1
																		.getStartDate()
																		.compareTo(
																				xCustomerVehicleRoleJPN2.getStartDate());
															}
														});
												
												Timestamp Person1RoleLastModifiedDt = DateFormatter.getTimestamp(Party1XCustomerVehicleRoleBObj.getXCustomerVehicleRoleJPNLastUpdateDate());
												Timestamp Person2RoleLastModifiedDt = DateFormatter.getTimestamp(Party2XCustomerVehicleRoleBObj.getXCustomerVehicleRoleJPNLastUpdateDate());
												if(Person2RoleLastModifiedDt.after(Person1RoleLastModifiedDt))
												{
													Party2XCustomerVehicleRoleBObj.setStartDate(tempVecXCustomerVehicleRoleJPNBObj.get(0).getStartDate());
													if(tempVecXCustomerVehicleRoleJPNBObj.get(0).getEndDate()!=null && 
															tempVecXCustomerVehicleRoleJPNBObj.get(1).getEndDate()!=null)
													{
														Timestamp role1EndDt = DateFormatter.getTimestamp(tempVecXCustomerVehicleRoleJPNBObj.get(0).getEndDate());
														Timestamp role2EndDt = DateFormatter.getTimestamp(tempVecXCustomerVehicleRoleJPNBObj.get(1).getEndDate());
														
														if(role2EndDt.after(role1EndDt))
														{
															Party2XCustomerVehicleRoleBObj.setEndDate(tempVecXCustomerVehicleRoleJPNBObj.get(1).getEndDate());
														}
														else
														{
															Party2XCustomerVehicleRoleBObj.setEndDate(tempVecXCustomerVehicleRoleJPNBObj.get(0).getEndDate());
														}
													}
													else
													{
														Party2XCustomerVehicleRoleBObj.setEndDate(null);
													}
													xCustomerVehicleRoleMap.put(Party2XCustomerVehicleRoleBObj.getVehicleRoleType(), Party2XCustomerVehicleRoleBObj);
												}
												else
												{
													Party1XCustomerVehicleRoleBObj.setStartDate(tempVecXCustomerVehicleRoleJPNBObj.get(0).getStartDate());
													if(tempVecXCustomerVehicleRoleJPNBObj.get(0).getEndDate()!=null && 
															tempVecXCustomerVehicleRoleJPNBObj.get(1).getEndDate()!=null)
													{
														Timestamp role1EndDt = DateFormatter.getTimestamp(tempVecXCustomerVehicleRoleJPNBObj.get(0).getEndDate());
														Timestamp role2EndDt = DateFormatter.getTimestamp(tempVecXCustomerVehicleRoleJPNBObj.get(1).getEndDate());
														
														if(role2EndDt.after(role1EndDt))
														{
															Party1XCustomerVehicleRoleBObj.setEndDate(tempVecXCustomerVehicleRoleJPNBObj.get(1).getEndDate());
														}
														else
														{
															Party1XCustomerVehicleRoleBObj.setEndDate(tempVecXCustomerVehicleRoleJPNBObj.get(0).getEndDate());
														}
													}
													else
													{
														Party1XCustomerVehicleRoleBObj.setEndDate(null);
													}
													xCustomerVehicleRoleMap.put(Party1XCustomerVehicleRoleBObj.getVehicleRoleType(), Party1XCustomerVehicleRoleBObj);
												}
												
											}
											
										}
										
									}
									
									for (Map.Entry<String, XCustomerVehicleRoleJPNBObj> entry : xCustomerVehicleRoleMap.entrySet()) 
									{
										vecFinalVehicleRoleBObjs.add(entry.getValue());
									}
									

									Timestamp person1ModifiedDt = DateFormatter
											.getTimestamp(xContVehicleBObjInMap
													.getXCustomerVehicleJPNLastUpdateDate());

									Timestamp person2ModifiedDt = DateFormatter
											.getTimestamp(xCustomerVehicleBObj
													.getXCustomerVehicleJPNLastUpdateDate());
									
									if (person1ModifiedDt.after(person2ModifiedDt)) {
										xContVehicleBObjInMap.getItemsXCustomerVehicleRoleJPNBObj().clear();
										xContVehicleBObjInMap.getItemsXCustomerVehicleRoleJPNBObj().addAll(vecFinalVehicleRoleBObjs);
										xContVehicleBObjInMap.setStartDate(tempVecXCustomerVehicleJPNBObj.get(0).getStartDate());
										if(tempVecXCustomerVehicleJPNBObj.get(0).getEndDate()!=null && tempVecXCustomerVehicleJPNBObj.get(1).getEndDate()!=null)
										{
										java.util.Date xCustomerVehicleJPN2EndDt = simpleDateFmt.parse(tempVecXCustomerVehicleJPNBObj.get(1).getEndDate());
										if(xCustomerVehicleJPN2EndDt.after(xCustomerVehicleJPN1EndDt))
										{
										xContVehicleBObjInMap.setEndDate(tempVecXCustomerVehicleJPNBObj.get(1).getEndDate());
										}
										else
										{
										xContVehicleBObjInMap.setEndDate(tempVecXCustomerVehicleJPNBObj.get(0).getEndDate());
										}
										}
										else if(tempVecXCustomerVehicleJPNBObj.get(0).getEndDate()==null)
										{
											xContVehicleBObjInMap.setEndDate(null);
										}
										else
										{
											xContVehicleBObjInMap.setEndDate(tempVecXCustomerVehicleJPNBObj.get(1).getEndDate());
										}
										xCustomerVehicleMap.put((xContVehicleBObjInMap
												.getXVehicleJPNBObj().getGlobalVIN()) + xContVehicleBObjInMap
												.getXVehicleJPNBObj().getVehicleType()+ (xContVehicleBObjInMap.getRetailerId()),
												xContVehicleBObjInMap);
									}

									else {
										xCustomerVehicleBObj.getItemsXCustomerVehicleRoleJPNBObj().clear();
										xCustomerVehicleBObj.getItemsXCustomerVehicleRoleJPNBObj().addAll(vecFinalVehicleRoleBObjs);
										xCustomerVehicleBObj.setStartDate(tempVecXCustomerVehicleJPNBObj.get(0).getStartDate());
										if(tempVecXCustomerVehicleJPNBObj.get(0).getEndDate()!=null && tempVecXCustomerVehicleJPNBObj.get(1).getEndDate()!=null)
										{
										java.util.Date xCustomerVehicleJPN2EndDt = simpleDateFmt.parse(tempVecXCustomerVehicleJPNBObj.get(1).getEndDate());
										if(xCustomerVehicleJPN2EndDt.after(xCustomerVehicleJPN1EndDt))
										{
											xCustomerVehicleBObj.setEndDate(tempVecXCustomerVehicleJPNBObj.get(1).getEndDate());
										}
										else
										{
											xCustomerVehicleBObj.setEndDate(tempVecXCustomerVehicleJPNBObj.get(0).getEndDate());
										}
										}
										else if(tempVecXCustomerVehicleJPNBObj.get(0).getEndDate()==null)
										{
											xCustomerVehicleBObj.setEndDate(null);
										}
										else
										{
											xCustomerVehicleBObj.setEndDate(tempVecXCustomerVehicleJPNBObj.get(1).getEndDate());
										}
										xCustomerVehicleMap.put((xCustomerVehicleBObj
												.getXVehicleJPNBObj().getGlobalVIN()) +xCustomerVehicleBObj
												.getXVehicleJPNBObj().getVehicleType() + (xCustomerVehicleBObj.getRetailerId()),
												xCustomerVehicleBObj);
									}

								}
									else
									{
										
										VecUnmergedXCustomerVehicleJPNBObj.add(xContVehicleBObjInMap);
										VecUnmergedXCustomerVehicleJPNBObj.add(xCustomerVehicleBObj);
										
										xCustomerVehicleMap.remove((xCustomerVehicleBObj
												.getXVehicleJPNBObj().getGlobalVIN()) +  xCustomerVehicleBObj
												.getXVehicleJPNBObj().getVehicleType() + (xCustomerVehicleBObj.getRetailerId()));																						
											
									}
								} 
								else {

									xCustomerVehicleMap.put((xCustomerVehicleBObj
											.getXVehicleJPNBObj().getGlobalVIN()) +  xCustomerVehicleBObj.getXVehicleJPNBObj().getVehicleType() + (xCustomerVehicleBObj.getRetailerId()),
											xCustomerVehicleBObj);
								}

							}
							
						}
					
						else
						{
							HashMap<String, XCustomerVehicleJPNBObj> tempCustomerVehicleMap = new HashMap<String, XCustomerVehicleJPNBObj>();
							tempCustomerVehicleMap =checkForActiveCVR(vecXCustomerVehicleRetailBObjs);
							
							/*if(xCustomerVehicleJPNBObj == null)
							{
								Collections.sort(vecXCustomerVehicleRetailBObjs,
										new Comparator<XCustomerVehicleJPNBObj>() {// Ascending sort
																			// - for delta
																			// load
											public int compare(XCustomerVehicleJPNBObj xCustomerVehicleJPN1,
													XCustomerVehicleJPNBObj xCustomerVehicleJPN2) {
												
												return xCustomerVehicleJPN1
														.getEndDate()
														.compareTo(
																xCustomerVehicleJPN2.getEndDate());
											}
										});
								
								xCustomerVehicleJPNBObj = vecXCustomerVehicleRetailBObjs.get(vecXCustomerVehicleRetailBObjs.size()-1);
							}*/
							for(Map.Entry<String, XCustomerVehicleJPNBObj> entry1 : tempCustomerVehicleMap
									.entrySet())
							{
								XCustomerVehicleJPNBObj xCustomerVehicleJPNBObj=entry1.getValue();
							if (!xCustomerVehicleMap.containsKey((xCustomerVehicleJPNBObj
									.getXVehicleJPNBObj().getGlobalVIN()) + xCustomerVehicleJPNBObj
									.getXVehicleJPNBObj().getVehicleType()+ (xCustomerVehicleJPNBObj.getRetailerId()))) 
							{
								xCustomerVehicleMap.put((xCustomerVehicleJPNBObj
										.getXVehicleJPNBObj().getGlobalVIN()) +  xCustomerVehicleJPNBObj
										.getXVehicleJPNBObj().getVehicleType() + (xCustomerVehicleJPNBObj.getRetailerId()),
										xCustomerVehicleJPNBObj);
								
								
							} 
							else 
							{
								XCustomerVehicleJPNBObj xContVehicleBObjInMap = xCustomerVehicleMap.get((xCustomerVehicleJPNBObj
												.getXVehicleJPNBObj().getGlobalVIN()) +  xCustomerVehicleJPNBObj
												.getXVehicleJPNBObj().getVehicleType() + (xCustomerVehicleJPNBObj.getRetailerId()));
								requestPersonRetailerCode = xContVehicleBObjInMap
										.getRetailerId();
								existingPersonRetailerCode = xCustomerVehicleJPNBObj
										.getRetailerId();

								if (requestPersonRetailerCode != null
										&& existingPersonRetailerCode != null
										&& requestPersonRetailerCode
												.equalsIgnoreCase(existingPersonRetailerCode)) 
								{			
									//sort VR based on start date
									Vector <XCustomerVehicleJPNBObj> tempVecXCustomerVehicleJPNBObj = new Vector<XCustomerVehicleJPNBObj>();
									tempVecXCustomerVehicleJPNBObj.add(xContVehicleBObjInMap);
									tempVecXCustomerVehicleJPNBObj.add(xCustomerVehicleJPNBObj);
									if(xContVehicleBObjInMap.getStartDate()!=null && xCustomerVehicleJPNBObj.getStartDate()!=null)
									{
										Collections.sort(tempVecXCustomerVehicleJPNBObj,
												new Comparator<XCustomerVehicleJPNBObj>() {// Ascending sort
																					// - for delta
																					// load
													public int compare(XCustomerVehicleJPNBObj xCustomerVehicleJPN1,
															XCustomerVehicleJPNBObj xCustomerVehicleJPN2) {
														
														return xCustomerVehicleJPN1
																.getStartDate()
																.compareTo(
																		xCustomerVehicleJPN2.getStartDate());
													}
												});
									}
																
									SimpleDateFormat simpleDateFmt = new SimpleDateFormat("yyyy-MM-dd");
									java.util.Date xCustomerVehicleJPN1EndDt =null;
									java.util.Date xCustomerVehicleJPN2StartDt =null;
									toBeMerged = false;
									
									
									
									if(tempVecXCustomerVehicleJPNBObj.get(0).getEndDate()!=null && 
											tempVecXCustomerVehicleJPNBObj.get(1).getStartDate()!=null)
									{
									xCustomerVehicleJPN1EndDt =simpleDateFmt.parse(tempVecXCustomerVehicleJPNBObj.get(0).getEndDate());
									xCustomerVehicleJPN2StartDt =simpleDateFmt.parse(tempVecXCustomerVehicleJPNBObj.get(1).getStartDate());
									
									long difference = xCustomerVehicleJPN2StartDt.getTime() - xCustomerVehicleJPN1EndDt.getTime();
									float daysBetween = (difference / (1000*60*60*24));
									if(daysBetween<=1)
									{
										toBeMerged = true;
									}
									}
									else if(tempVecXCustomerVehicleJPNBObj.get(0).getEndDate()==null)
									{
										toBeMerged = true;
									}
									if(toBeMerged)
									{
									vecParty1XCustomerVehicleRoleBObjs = xContVehicleBObjInMap.getItemsXCustomerVehicleRoleJPNBObj();
									vecParty2XCustomerVehicleRoleBObjs = xCustomerVehicleJPNBObj.getItemsXCustomerVehicleRoleJPNBObj();
									Vector<XCustomerVehicleRoleJPNBObj> vecFinalVehicleRoleBObjs = new Vector<XCustomerVehicleRoleJPNBObj>();
									
									HashMap<String, XCustomerVehicleRoleJPNBObj> xCustomerVehicleRoleMap = new HashMap<String, XCustomerVehicleRoleJPNBObj>();
									for(XCustomerVehicleRoleJPNBObj Party1XCustomerVehicleRoleBObj :vecParty1XCustomerVehicleRoleBObjs)
									{
										if(!xCustomerVehicleRoleMap.containsKey(Party1XCustomerVehicleRoleBObj.getVehicleRoleType()))
										{
											xCustomerVehicleRoleMap.put(Party1XCustomerVehicleRoleBObj.getVehicleRoleType(), Party1XCustomerVehicleRoleBObj);
										}
									}
									
									for(XCustomerVehicleRoleJPNBObj Party2XCustomerVehicleRoleBObj :vecParty2XCustomerVehicleRoleBObjs)
									{
										if(!xCustomerVehicleRoleMap.containsKey(Party2XCustomerVehicleRoleBObj.getVehicleRoleType()))
										{
											xCustomerVehicleRoleMap.put(Party2XCustomerVehicleRoleBObj.getVehicleRoleType(), Party2XCustomerVehicleRoleBObj);
										}
										else
										{
											XCustomerVehicleRoleJPNBObj Party1XCustomerVehicleRoleBObj = xCustomerVehicleRoleMap.get(Party2XCustomerVehicleRoleBObj.getVehicleRoleType());
											
											/*Timestamp Person1RoleLastModifiedDt = DateFormatter.getTimestamp(Party1XCustomerVehicleRoleBObj.getXCustomerVehicleRoleJPNLastUpdateDate());
											Timestamp Person2RoleLastModifiedDt = DateFormatter.getTimestamp(Party2XCustomerVehicleRoleBObj.getXCustomerVehicleRoleJPNLastUpdateDate());
											if(Person2RoleLastModifiedDt.after(Person1RoleLastModifiedDt))
											{
												xCustomerVehicleRoleMap.put(Party2XCustomerVehicleRoleBObj.getVehicleRoleType(), Party2XCustomerVehicleRoleBObj);
											}*/
											
											Vector <XCustomerVehicleRoleJPNBObj> tempVecXCustomerVehicleRoleJPNBObj = new Vector<XCustomerVehicleRoleJPNBObj>();
											tempVecXCustomerVehicleRoleJPNBObj.add(Party1XCustomerVehicleRoleBObj);
											tempVecXCustomerVehicleRoleJPNBObj.add(Party2XCustomerVehicleRoleBObj);
											
											if(Party1XCustomerVehicleRoleBObj.getStartDate()!=null && Party2XCustomerVehicleRoleBObj.getStartDate()!=null)
											{
												
												Collections.sort(tempVecXCustomerVehicleRoleJPNBObj,
														new Comparator<XCustomerVehicleRoleJPNBObj>() {// Ascending sort
																							// - for delta
																							// load
															public int compare(XCustomerVehicleRoleJPNBObj xCustomerVehicleRoleJPN1,
																	XCustomerVehicleRoleJPNBObj xCustomerVehicleRoleJPN2) {
																
																return xCustomerVehicleRoleJPN1
																		.getStartDate()
																		.compareTo(
																				xCustomerVehicleRoleJPN2.getStartDate());
															}
														});
												
												Timestamp Person1RoleLastModifiedDt = DateFormatter.getTimestamp(Party1XCustomerVehicleRoleBObj.getXCustomerVehicleRoleJPNLastUpdateDate());
												Timestamp Person2RoleLastModifiedDt = DateFormatter.getTimestamp(Party2XCustomerVehicleRoleBObj.getXCustomerVehicleRoleJPNLastUpdateDate());
												if(Person2RoleLastModifiedDt.after(Person1RoleLastModifiedDt))
												{
													Party2XCustomerVehicleRoleBObj.setStartDate(tempVecXCustomerVehicleRoleJPNBObj.get(0).getStartDate());
													if(tempVecXCustomerVehicleRoleJPNBObj.get(0).getEndDate()!=null && 
															tempVecXCustomerVehicleRoleJPNBObj.get(1).getEndDate()!=null)
													{
														Timestamp role1EndDt = DateFormatter.getTimestamp(tempVecXCustomerVehicleRoleJPNBObj.get(0).getEndDate());
														Timestamp role2EndDt = DateFormatter.getTimestamp(tempVecXCustomerVehicleRoleJPNBObj.get(1).getEndDate());
														
														if(role2EndDt.after(role1EndDt))
														{
															Party2XCustomerVehicleRoleBObj.setEndDate(tempVecXCustomerVehicleRoleJPNBObj.get(1).getEndDate());
														}
														else
														{
															Party2XCustomerVehicleRoleBObj.setEndDate(tempVecXCustomerVehicleRoleJPNBObj.get(0).getEndDate());
														}
													}
													else
													{
														Party2XCustomerVehicleRoleBObj.setEndDate(null);
													}
													xCustomerVehicleRoleMap.put(Party2XCustomerVehicleRoleBObj.getVehicleRoleType(), Party2XCustomerVehicleRoleBObj);
												}
												else
												{
													Party1XCustomerVehicleRoleBObj.setStartDate(tempVecXCustomerVehicleRoleJPNBObj.get(0).getStartDate());
													if(tempVecXCustomerVehicleRoleJPNBObj.get(0).getEndDate()!=null && 
															tempVecXCustomerVehicleRoleJPNBObj.get(1).getEndDate()!=null)
													{
														Timestamp role1EndDt = DateFormatter.getTimestamp(tempVecXCustomerVehicleRoleJPNBObj.get(0).getEndDate());
														Timestamp role2EndDt = DateFormatter.getTimestamp(tempVecXCustomerVehicleRoleJPNBObj.get(1).getEndDate());
														
														if(role2EndDt.after(role1EndDt))
														{
															Party1XCustomerVehicleRoleBObj.setEndDate(tempVecXCustomerVehicleRoleJPNBObj.get(1).getEndDate());
														}
														else
														{
															Party1XCustomerVehicleRoleBObj.setEndDate(tempVecXCustomerVehicleRoleJPNBObj.get(0).getEndDate());
														}
													}
													else
													{
														Party1XCustomerVehicleRoleBObj.setEndDate(null);
													}
													xCustomerVehicleRoleMap.put(Party1XCustomerVehicleRoleBObj.getVehicleRoleType(), Party1XCustomerVehicleRoleBObj);
												}
												
												
												
											}
										}
										
									}
									
									for (Map.Entry<String, XCustomerVehicleRoleJPNBObj> entry : xCustomerVehicleRoleMap.entrySet()) 
									{
										vecFinalVehicleRoleBObjs.add(entry.getValue());
									}
									

									Timestamp person1ModifiedDt = DateFormatter
											.getTimestamp(xContVehicleBObjInMap
													.getXCustomerVehicleJPNLastUpdateDate());

									Timestamp person2ModifiedDt = DateFormatter
											.getTimestamp(xCustomerVehicleJPNBObj
													.getXCustomerVehicleJPNLastUpdateDate());
									
									if (person1ModifiedDt.after(person2ModifiedDt)) {
										xContVehicleBObjInMap.getItemsXCustomerVehicleRoleJPNBObj().clear();
										xContVehicleBObjInMap.getItemsXCustomerVehicleRoleJPNBObj().addAll(vecFinalVehicleRoleBObjs);
										xContVehicleBObjInMap.setStartDate(tempVecXCustomerVehicleJPNBObj.get(0).getStartDate());
										if(tempVecXCustomerVehicleJPNBObj.get(0).getEndDate()!=null && tempVecXCustomerVehicleJPNBObj.get(1).getEndDate()!=null)
										{
										java.util.Date xCustomerVehicleJPN2EndDt = simpleDateFmt.parse(tempVecXCustomerVehicleJPNBObj.get(1).getEndDate());
										if(xCustomerVehicleJPN2EndDt.after(xCustomerVehicleJPN1EndDt))
										{
										xContVehicleBObjInMap.setEndDate(tempVecXCustomerVehicleJPNBObj.get(1).getEndDate());
										}
										else
										{
										xContVehicleBObjInMap.setEndDate(tempVecXCustomerVehicleJPNBObj.get(0).getEndDate());
										}
										}
										else if(tempVecXCustomerVehicleJPNBObj.get(0).getEndDate()==null)
										{
											xContVehicleBObjInMap.setEndDate(null);
										}
										else
										{
											xContVehicleBObjInMap.setEndDate(tempVecXCustomerVehicleJPNBObj.get(1).getEndDate());
										}
										xCustomerVehicleMap.put((xContVehicleBObjInMap
												.getXVehicleJPNBObj().getGlobalVIN()) + xContVehicleBObjInMap
												.getXVehicleJPNBObj().getVehicleType()+ (xContVehicleBObjInMap.getRetailerId()),
												xContVehicleBObjInMap);
										
									}

									else {
										xCustomerVehicleJPNBObj.getItemsXCustomerVehicleRoleJPNBObj().clear();
										xCustomerVehicleJPNBObj.getItemsXCustomerVehicleRoleJPNBObj().addAll(vecFinalVehicleRoleBObjs);
										xCustomerVehicleJPNBObj.setStartDate(tempVecXCustomerVehicleJPNBObj.get(0).getStartDate());
										if(tempVecXCustomerVehicleJPNBObj.get(0).getEndDate()!=null && tempVecXCustomerVehicleJPNBObj.get(1).getEndDate()!=null)
										{
										java.util.Date xCustomerVehicleJPN2EndDt = simpleDateFmt.parse(tempVecXCustomerVehicleJPNBObj.get(1).getEndDate());
										if(xCustomerVehicleJPN2EndDt.after(xCustomerVehicleJPN1EndDt))
										{
											xCustomerVehicleJPNBObj.setEndDate(tempVecXCustomerVehicleJPNBObj.get(1).getEndDate());
										}
										else
										{
											xCustomerVehicleJPNBObj.setEndDate(tempVecXCustomerVehicleJPNBObj.get(0).getEndDate());
										}
										}
										else if(tempVecXCustomerVehicleJPNBObj.get(0).getEndDate()==null)
										{
											xCustomerVehicleJPNBObj.setEndDate(null);
										}
										else
										{
											xCustomerVehicleJPNBObj.setEndDate(tempVecXCustomerVehicleJPNBObj.get(1).getEndDate());
										}
										xCustomerVehicleMap.put((xCustomerVehicleJPNBObj
												.getXVehicleJPNBObj().getGlobalVIN()) +xCustomerVehicleJPNBObj
												.getXVehicleJPNBObj().getVehicleType() + (xCustomerVehicleJPNBObj.getRetailerId()),
												xCustomerVehicleJPNBObj);
										
									}

								}
									else
									{
										
										VecUnmergedXCustomerVehicleJPNBObj.add(xContVehicleBObjInMap);
										VecUnmergedXCustomerVehicleJPNBObj.add(xCustomerVehicleJPNBObj);
										
										xCustomerVehicleMap.remove((xCustomerVehicleJPNBObj
												.getXVehicleJPNBObj().getGlobalVIN()) +  xCustomerVehicleJPNBObj
												.getXVehicleJPNBObj().getVehicleType() + (xCustomerVehicleJPNBObj.getRetailerId()));
																				
									}
								} 
								else {

									xCustomerVehicleMap.put((xCustomerVehicleJPNBObj
											.getXVehicleJPNBObj().getGlobalVIN()) +  xCustomerVehicleJPNBObj.getXVehicleJPNBObj().getVehicleType() + (xCustomerVehicleJPNBObj.getRetailerId()),
											xCustomerVehicleJPNBObj);
								}

							}
						}
					}
			}						
					//}
				//}
				
				
				
				//Handle wholesale CVR
				/*for (int j = 0; j < vecXCustomerVehicleBObjs.size(); j++) 
				{
					XCustomerVehicleJPNBObj xCustomerVehicleBObj = (XCustomerVehicleJPNBObj) vecXCustomerVehicleBObjs
							.get(j);
					if(xCustomerVehicleBObj.getRetailerId()==null) // && checkIfCVRActive(xCustomerVehicleBObj.getEndDate()) )
					{*/
						if(vecXCustomerVehicleWholesaleBObjs.size() >0)	
						{
						if(vecXCustomerVehicleWholesaleBObjs.size()==1)
						{
							XCustomerVehicleJPNBObj xCustomerVehicleBObj = (XCustomerVehicleJPNBObj) vecXCustomerVehicleWholesaleBObjs
									.get(0);
							if (!xCustomerVehicleMap.containsKey((xCustomerVehicleBObj
									.getXVehicleJPNBObj().getGlobalVIN()) + xCustomerVehicleBObj
									.getXVehicleJPNBObj().getVehicleType())) 
							{
								xCustomerVehicleMap.put((xCustomerVehicleBObj
										.getXVehicleJPNBObj().getGlobalVIN()) +  xCustomerVehicleBObj
										.getXVehicleJPNBObj().getVehicleType() ,
										xCustomerVehicleBObj);
							} 
							
							else 
							{
								XCustomerVehicleJPNBObj xContVehicleBObjInMap = xCustomerVehicleMap.get((xCustomerVehicleBObj
												.getXVehicleJPNBObj().getGlobalVIN()) +  xCustomerVehicleBObj
												.getXVehicleJPNBObj().getVehicleType() );
								requestPersonRetailerCode = xContVehicleBObjInMap
										.getRetailerId();
								existingPersonRetailerCode = xCustomerVehicleBObj
										.getRetailerId();

								if (requestPersonRetailerCode == null
										&& existingPersonRetailerCode == null
										) 
								{			
									//sort VR based on start date
									Vector <XCustomerVehicleJPNBObj> tempVecXCustomerVehicleJPNBObj = new Vector<XCustomerVehicleJPNBObj>();
									tempVecXCustomerVehicleJPNBObj.add(xContVehicleBObjInMap);
									tempVecXCustomerVehicleJPNBObj.add(xCustomerVehicleBObj);
									if(xContVehicleBObjInMap.getStartDate()!=null && xCustomerVehicleBObj.getStartDate()!=null)
									{
										Collections.sort(tempVecXCustomerVehicleJPNBObj,
												new Comparator<XCustomerVehicleJPNBObj>() {// Ascending sort
																					// - for delta
																					// load
													public int compare(XCustomerVehicleJPNBObj xCustomerVehicleJPN1,
															XCustomerVehicleJPNBObj xCustomerVehicleJPN2) {
														
														return xCustomerVehicleJPN1
																.getStartDate()
																.compareTo(
																		xCustomerVehicleJPN2.getStartDate());
													}
												});
									}
																
									SimpleDateFormat simpleDateFmt = new SimpleDateFormat("yyyy-MM-dd");
									java.util.Date xCustomerVehicleJPN1EndDt =null;
									java.util.Date xCustomerVehicleJPN2StartDt =null;
									toBeMerged = false;
									
									if(tempVecXCustomerVehicleJPNBObj.get(0).getEndDate()!=null && 
											tempVecXCustomerVehicleJPNBObj.get(1).getStartDate()!=null)
									{
									xCustomerVehicleJPN1EndDt =simpleDateFmt.parse(tempVecXCustomerVehicleJPNBObj.get(0).getEndDate());
									xCustomerVehicleJPN2StartDt =simpleDateFmt.parse(tempVecXCustomerVehicleJPNBObj.get(1).getStartDate());
									
									long difference = xCustomerVehicleJPN2StartDt.getTime() - xCustomerVehicleJPN1EndDt.getTime();
									float daysBetween = (difference / (1000*60*60*24));
									if(daysBetween<=1)
									{
										toBeMerged = true;
									}
									}
									else if(tempVecXCustomerVehicleJPNBObj.get(0).getEndDate()==null)
									{
										toBeMerged = true;
									}
									if(toBeMerged)
									{
									vecParty1XCustomerVehicleRoleBObjs = xContVehicleBObjInMap.getItemsXCustomerVehicleRoleJPNBObj();
									vecParty2XCustomerVehicleRoleBObjs = xCustomerVehicleBObj.getItemsXCustomerVehicleRoleJPNBObj();
									Vector<XCustomerVehicleRoleJPNBObj> vecFinalVehicleRoleBObjs = new Vector<XCustomerVehicleRoleJPNBObj>();
									HashMap<String, XCustomerVehicleRoleJPNBObj> xCustomerVehicleRoleMap = new HashMap<String, XCustomerVehicleRoleJPNBObj>();
									for(XCustomerVehicleRoleJPNBObj Party1XCustomerVehicleRoleBObj :vecParty1XCustomerVehicleRoleBObjs)
									{
										if(!xCustomerVehicleRoleMap.containsKey(Party1XCustomerVehicleRoleBObj.getVehicleRoleType()))
										{
											xCustomerVehicleRoleMap.put(Party1XCustomerVehicleRoleBObj.getVehicleRoleType(), Party1XCustomerVehicleRoleBObj);
										}
									}
									
									for(XCustomerVehicleRoleJPNBObj Party2XCustomerVehicleRoleBObj :vecParty2XCustomerVehicleRoleBObjs)
									{
										if(!xCustomerVehicleRoleMap.containsKey(Party2XCustomerVehicleRoleBObj.getVehicleRoleType()))
										{
											xCustomerVehicleRoleMap.put(Party2XCustomerVehicleRoleBObj.getVehicleRoleType(), Party2XCustomerVehicleRoleBObj);
										}
										else
										{
											XCustomerVehicleRoleJPNBObj Party1XCustomerVehicleRoleBObj = xCustomerVehicleRoleMap.get(Party2XCustomerVehicleRoleBObj.getVehicleRoleType());
											
											/*Timestamp Person1RoleLastModifiedDt = DateFormatter.getTimestamp(Party1XCustomerVehicleRoleBObj.getXCustomerVehicleRoleJPNLastUpdateDate());
											Timestamp Person2RoleLastModifiedDt = DateFormatter.getTimestamp(Party2XCustomerVehicleRoleBObj.getXCustomerVehicleRoleJPNLastUpdateDate());
											if(Person2RoleLastModifiedDt.after(Person1RoleLastModifiedDt))
											{
												xCustomerVehicleRoleMap.put(Party2XCustomerVehicleRoleBObj.getVehicleRoleType(), Party2XCustomerVehicleRoleBObj);
											}*/
											
											
											Vector <XCustomerVehicleRoleJPNBObj> tempVecXCustomerVehicleRoleJPNBObj = new Vector<XCustomerVehicleRoleJPNBObj>();
											tempVecXCustomerVehicleRoleJPNBObj.add(Party1XCustomerVehicleRoleBObj);
											tempVecXCustomerVehicleRoleJPNBObj.add(Party2XCustomerVehicleRoleBObj);
											
											if(Party1XCustomerVehicleRoleBObj.getStartDate()!=null && Party2XCustomerVehicleRoleBObj.getStartDate()!=null)
											{
												Collections.sort(tempVecXCustomerVehicleRoleJPNBObj,
														new Comparator<XCustomerVehicleRoleJPNBObj>() {// Ascending sort
																							// - for delta
																							// load
															public int compare(XCustomerVehicleRoleJPNBObj xCustomerVehicleRoleJPN1,
																	XCustomerVehicleRoleJPNBObj xCustomerVehicleRoleJPN2) {
																
																return xCustomerVehicleRoleJPN1
																		.getStartDate()
																		.compareTo(
																				xCustomerVehicleRoleJPN2.getStartDate());
															}
														});
												
												Timestamp Person1RoleLastModifiedDt = DateFormatter.getTimestamp(Party1XCustomerVehicleRoleBObj.getXCustomerVehicleRoleJPNLastUpdateDate());
												Timestamp Person2RoleLastModifiedDt = DateFormatter.getTimestamp(Party2XCustomerVehicleRoleBObj.getXCustomerVehicleRoleJPNLastUpdateDate());
												if(Person2RoleLastModifiedDt.after(Person1RoleLastModifiedDt))
												{
													Party2XCustomerVehicleRoleBObj.setStartDate(tempVecXCustomerVehicleRoleJPNBObj.get(0).getStartDate());
													if(tempVecXCustomerVehicleRoleJPNBObj.get(0).getEndDate()!=null && 
															tempVecXCustomerVehicleRoleJPNBObj.get(1).getEndDate()!=null)
													{
														Timestamp role1EndDt = DateFormatter.getTimestamp(tempVecXCustomerVehicleRoleJPNBObj.get(0).getEndDate());
														Timestamp role2EndDt = DateFormatter.getTimestamp(tempVecXCustomerVehicleRoleJPNBObj.get(1).getEndDate());
														
														if(role2EndDt.after(role1EndDt))
														{
															Party2XCustomerVehicleRoleBObj.setEndDate(tempVecXCustomerVehicleRoleJPNBObj.get(1).getEndDate());
														}
														else
														{
															Party2XCustomerVehicleRoleBObj.setEndDate(tempVecXCustomerVehicleRoleJPNBObj.get(0).getEndDate());
														}
													}
													else
													{
														Party2XCustomerVehicleRoleBObj.setEndDate(null);
													}
													xCustomerVehicleRoleMap.put(Party2XCustomerVehicleRoleBObj.getVehicleRoleType(), Party2XCustomerVehicleRoleBObj);
												}
												else
												{
													Party1XCustomerVehicleRoleBObj.setStartDate(tempVecXCustomerVehicleRoleJPNBObj.get(0).getStartDate());
													if(tempVecXCustomerVehicleRoleJPNBObj.get(0).getEndDate()!=null && 
															tempVecXCustomerVehicleRoleJPNBObj.get(1).getEndDate()!=null)
													{
														Timestamp role1EndDt = DateFormatter.getTimestamp(tempVecXCustomerVehicleRoleJPNBObj.get(0).getEndDate());
														Timestamp role2EndDt = DateFormatter.getTimestamp(tempVecXCustomerVehicleRoleJPNBObj.get(1).getEndDate());
														
														if(role2EndDt.after(role1EndDt))
														{
															Party1XCustomerVehicleRoleBObj.setEndDate(tempVecXCustomerVehicleRoleJPNBObj.get(1).getEndDate());
														}
														else
														{
															Party1XCustomerVehicleRoleBObj.setEndDate(tempVecXCustomerVehicleRoleJPNBObj.get(0).getEndDate());
														}
													}
													else
													{
														Party1XCustomerVehicleRoleBObj.setEndDate(null);
													}
													xCustomerVehicleRoleMap.put(Party1XCustomerVehicleRoleBObj.getVehicleRoleType(), Party1XCustomerVehicleRoleBObj);
												}
												
											}
										}
										
									}
									
									for (Map.Entry<String, XCustomerVehicleRoleJPNBObj> entry : xCustomerVehicleRoleMap.entrySet()) 
									{
										vecFinalVehicleRoleBObjs.add(entry.getValue());
									}
									

									Timestamp person1ModifiedDt = DateFormatter
											.getTimestamp(xContVehicleBObjInMap
													.getXCustomerVehicleJPNLastUpdateDate());

									Timestamp person2ModifiedDt = DateFormatter
											.getTimestamp(xCustomerVehicleBObj
													.getXCustomerVehicleJPNLastUpdateDate());
									
									if (person1ModifiedDt.after(person2ModifiedDt)) {
										xContVehicleBObjInMap.getItemsXCustomerVehicleRoleJPNBObj().clear();
										xContVehicleBObjInMap.getItemsXCustomerVehicleRoleJPNBObj().addAll(vecFinalVehicleRoleBObjs);
										xContVehicleBObjInMap.setStartDate(tempVecXCustomerVehicleJPNBObj.get(0).getStartDate());
										if(tempVecXCustomerVehicleJPNBObj.get(0).getEndDate()!=null && tempVecXCustomerVehicleJPNBObj.get(1).getEndDate()!=null)
										{
										java.util.Date xCustomerVehicleJPN2EndDt = simpleDateFmt.parse(tempVecXCustomerVehicleJPNBObj.get(1).getEndDate());
										if(xCustomerVehicleJPN2EndDt.after(xCustomerVehicleJPN1EndDt))
										{
										xContVehicleBObjInMap.setEndDate(tempVecXCustomerVehicleJPNBObj.get(1).getEndDate());
										}
										else
										{
										xContVehicleBObjInMap.setEndDate(tempVecXCustomerVehicleJPNBObj.get(0).getEndDate());
										}
										}
										else if(tempVecXCustomerVehicleJPNBObj.get(0).getEndDate()==null)
										{
											xContVehicleBObjInMap.setEndDate(null);
										}
										else
										{
											xContVehicleBObjInMap.setEndDate(tempVecXCustomerVehicleJPNBObj.get(1).getEndDate());
										}
										xCustomerVehicleMap.put((xContVehicleBObjInMap
												.getXVehicleJPNBObj().getGlobalVIN()) + xContVehicleBObjInMap
												.getXVehicleJPNBObj().getVehicleType(),
												xContVehicleBObjInMap);
									}

									else {
										xCustomerVehicleBObj.getItemsXCustomerVehicleRoleJPNBObj().clear();
										xCustomerVehicleBObj.getItemsXCustomerVehicleRoleJPNBObj().addAll(vecFinalVehicleRoleBObjs);
										xCustomerVehicleBObj.setStartDate(tempVecXCustomerVehicleJPNBObj.get(0).getStartDate());
										if(tempVecXCustomerVehicleJPNBObj.get(0).getEndDate()!=null && tempVecXCustomerVehicleJPNBObj.get(1).getEndDate()!=null)
										{
										java.util.Date xCustomerVehicleJPN2EndDt = simpleDateFmt.parse(tempVecXCustomerVehicleJPNBObj.get(1).getEndDate());
										if(xCustomerVehicleJPN2EndDt.after(xCustomerVehicleJPN1EndDt))
										{
											xCustomerVehicleBObj.setEndDate(tempVecXCustomerVehicleJPNBObj.get(1).getEndDate());
										}
										else
										{
											xCustomerVehicleBObj.setEndDate(tempVecXCustomerVehicleJPNBObj.get(0).getEndDate());
										}
										}
										else if(tempVecXCustomerVehicleJPNBObj.get(0).getEndDate()==null)
										{
											xCustomerVehicleBObj.setEndDate(null);
										}
										else
										{
											xCustomerVehicleBObj.setEndDate(tempVecXCustomerVehicleJPNBObj.get(1).getEndDate());
										}
										xCustomerVehicleMap.put((xCustomerVehicleBObj
												.getXVehicleJPNBObj().getGlobalVIN()) +xCustomerVehicleBObj
												.getXVehicleJPNBObj().getVehicleType() ,
												xCustomerVehicleBObj);
									}

								}
									else
									{
										VecUnmergedXCustomerVehicleJPNBObj.add(xContVehicleBObjInMap);
										VecUnmergedXCustomerVehicleJPNBObj.add(xCustomerVehicleBObj);
										
										xCustomerVehicleMap.remove((xCustomerVehicleBObj
												.getXVehicleJPNBObj().getGlobalVIN()) +  xCustomerVehicleBObj
												.getXVehicleJPNBObj().getVehicleType());		
									}
								} 
								else {

									xCustomerVehicleMap.put((xCustomerVehicleBObj
											.getXVehicleJPNBObj().getGlobalVIN()) +  xCustomerVehicleBObj.getXVehicleJPNBObj().getVehicleType() ,
											xCustomerVehicleBObj);
								}

							}
							
						}
												
						else
						{
							HashMap<String, XCustomerVehicleJPNBObj> tempCustomerVehicleMap = new HashMap<String, XCustomerVehicleJPNBObj>();
							tempCustomerVehicleMap =checkForActiveCVR(vecXCustomerVehicleWholesaleBObjs);
							
						/*	if(xCustomerVehicleJPNBObj == null)
							{
								Collections.sort(vecXCustomerVehicleWholesaleBObjs,
										new Comparator<XCustomerVehicleJPNBObj>() {// Ascending sort
																			// - for delta
																			// load
											public int compare(XCustomerVehicleJPNBObj xCustomerVehicleJPN1,
													XCustomerVehicleJPNBObj xCustomerVehicleJPN2) {
												
												return xCustomerVehicleJPN1
														.getEndDate()
														.compareTo(
																xCustomerVehicleJPN2.getEndDate());
											}
										});
								
								xCustomerVehicleJPNBObj = vecXCustomerVehicleWholesaleBObjs.get(vecXCustomerVehicleWholesaleBObjs.size()-1);
							}*/

							for(Map.Entry<String, XCustomerVehicleJPNBObj> entry1 : tempCustomerVehicleMap
									.entrySet())
							{
								XCustomerVehicleJPNBObj xCustomerVehicleJPNBObj=entry1.getValue();
							if (!xCustomerVehicleMap.containsKey((xCustomerVehicleJPNBObj
									.getXVehicleJPNBObj().getGlobalVIN()) + xCustomerVehicleJPNBObj
									.getXVehicleJPNBObj().getVehicleType())) 
							{
								xCustomerVehicleMap.put((xCustomerVehicleJPNBObj
										.getXVehicleJPNBObj().getGlobalVIN()) +  xCustomerVehicleJPNBObj
										.getXVehicleJPNBObj().getVehicleType() ,
										xCustomerVehicleJPNBObj);
								
								
							} 
							else 
							{
								XCustomerVehicleJPNBObj xContVehicleBObjInMap = xCustomerVehicleMap.get((xCustomerVehicleJPNBObj
												.getXVehicleJPNBObj().getGlobalVIN()) +  xCustomerVehicleJPNBObj
												.getXVehicleJPNBObj().getVehicleType() );
								requestPersonRetailerCode = xContVehicleBObjInMap
										.getRetailerId();
								existingPersonRetailerCode = xCustomerVehicleJPNBObj
										.getRetailerId();

								if (requestPersonRetailerCode == null
										&& existingPersonRetailerCode == null
										) 
								{			
									//sort VR based on start date
									Vector <XCustomerVehicleJPNBObj> tempVecXCustomerVehicleJPNBObj = new Vector<XCustomerVehicleJPNBObj>();
									tempVecXCustomerVehicleJPNBObj.add(xContVehicleBObjInMap);
									tempVecXCustomerVehicleJPNBObj.add(xCustomerVehicleJPNBObj);
									if(xContVehicleBObjInMap.getStartDate()!=null && xCustomerVehicleJPNBObj.getStartDate()!=null)
									{
										Collections.sort(tempVecXCustomerVehicleJPNBObj,
												new Comparator<XCustomerVehicleJPNBObj>() {// Ascending sort
																					// - for delta
																					// load
													public int compare(XCustomerVehicleJPNBObj xCustomerVehicleJPN1,
															XCustomerVehicleJPNBObj xCustomerVehicleJPN2) {
														
														return xCustomerVehicleJPN1
																.getStartDate()
																.compareTo(
																		xCustomerVehicleJPN2.getStartDate());
													}
												});
									}
																
									SimpleDateFormat simpleDateFmt = new SimpleDateFormat("yyyy-MM-dd");
									java.util.Date xCustomerVehicleJPN1EndDt =null;
									java.util.Date xCustomerVehicleJPN2StartDt =null;
									
									toBeMerged = false;
									
									if(tempVecXCustomerVehicleJPNBObj.get(0).getEndDate()!=null && 
											tempVecXCustomerVehicleJPNBObj.get(1).getStartDate()!=null)
									{
									xCustomerVehicleJPN1EndDt =simpleDateFmt.parse(tempVecXCustomerVehicleJPNBObj.get(0).getEndDate());
									xCustomerVehicleJPN2StartDt =simpleDateFmt.parse(tempVecXCustomerVehicleJPNBObj.get(1).getStartDate());
									
									long difference = xCustomerVehicleJPN2StartDt.getTime() - xCustomerVehicleJPN1EndDt.getTime();
									float daysBetween = (difference / (1000*60*60*24));
									if(daysBetween<=1)
									{
										toBeMerged = true;
									}
									}
									else if(tempVecXCustomerVehicleJPNBObj.get(0).getEndDate()==null)
									{
										toBeMerged = true;
									}
									if(toBeMerged)
									{
									vecParty1XCustomerVehicleRoleBObjs = xContVehicleBObjInMap.getItemsXCustomerVehicleRoleJPNBObj();
									vecParty2XCustomerVehicleRoleBObjs = xCustomerVehicleJPNBObj.getItemsXCustomerVehicleRoleJPNBObj();
									Vector<XCustomerVehicleRoleJPNBObj> vecFinalVehicleRoleBObjs = new Vector<XCustomerVehicleRoleJPNBObj>();
									HashMap<String, XCustomerVehicleRoleJPNBObj> xCustomerVehicleRoleMap = new HashMap<String, XCustomerVehicleRoleJPNBObj>();
									for(XCustomerVehicleRoleJPNBObj Party1XCustomerVehicleRoleBObj :vecParty1XCustomerVehicleRoleBObjs)
									{
										if(!xCustomerVehicleRoleMap.containsKey(Party1XCustomerVehicleRoleBObj.getVehicleRoleType()))
										{
											xCustomerVehicleRoleMap.put(Party1XCustomerVehicleRoleBObj.getVehicleRoleType(), Party1XCustomerVehicleRoleBObj);
										}
									}
									
									for(XCustomerVehicleRoleJPNBObj Party2XCustomerVehicleRoleBObj :vecParty2XCustomerVehicleRoleBObjs)
									{
										if(!xCustomerVehicleRoleMap.containsKey(Party2XCustomerVehicleRoleBObj.getVehicleRoleType()))
										{
											xCustomerVehicleRoleMap.put(Party2XCustomerVehicleRoleBObj.getVehicleRoleType(), Party2XCustomerVehicleRoleBObj);
										}
										else
										{
											XCustomerVehicleRoleJPNBObj Party1XCustomerVehicleRoleBObj = xCustomerVehicleRoleMap.get(Party2XCustomerVehicleRoleBObj.getVehicleRoleType());
											
											/*Timestamp Person1RoleLastModifiedDt = DateFormatter.getTimestamp(Party1XCustomerVehicleRoleBObj.getXCustomerVehicleRoleJPNLastUpdateDate());
											Timestamp Person2RoleLastModifiedDt = DateFormatter.getTimestamp(Party2XCustomerVehicleRoleBObj.getXCustomerVehicleRoleJPNLastUpdateDate());
											if(Person2RoleLastModifiedDt.after(Person1RoleLastModifiedDt))
											{
												xCustomerVehicleRoleMap.put(Party2XCustomerVehicleRoleBObj.getVehicleRoleType(), Party2XCustomerVehicleRoleBObj);
											}*/
											
											Vector <XCustomerVehicleRoleJPNBObj> tempVecXCustomerVehicleRoleJPNBObj = new Vector<XCustomerVehicleRoleJPNBObj>();
											tempVecXCustomerVehicleRoleJPNBObj.add(Party1XCustomerVehicleRoleBObj);
											tempVecXCustomerVehicleRoleJPNBObj.add(Party2XCustomerVehicleRoleBObj);
											
											if(Party1XCustomerVehicleRoleBObj.getStartDate()!=null && Party2XCustomerVehicleRoleBObj.getStartDate()!=null)
											{
												Collections.sort(tempVecXCustomerVehicleRoleJPNBObj,
														new Comparator<XCustomerVehicleRoleJPNBObj>() {// Ascending sort
																							// - for delta
																							// load
															public int compare(XCustomerVehicleRoleJPNBObj xCustomerVehicleRoleJPN1,
																	XCustomerVehicleRoleJPNBObj xCustomerVehicleRoleJPN2) {
																
																return xCustomerVehicleRoleJPN1
																		.getStartDate()
																		.compareTo(
																				xCustomerVehicleRoleJPN2.getStartDate());
															}
														});
												
												Timestamp Person1RoleLastModifiedDt = DateFormatter.getTimestamp(Party1XCustomerVehicleRoleBObj.getXCustomerVehicleRoleJPNLastUpdateDate());
												Timestamp Person2RoleLastModifiedDt = DateFormatter.getTimestamp(Party2XCustomerVehicleRoleBObj.getXCustomerVehicleRoleJPNLastUpdateDate());
												if(Person2RoleLastModifiedDt.after(Person1RoleLastModifiedDt))
												{
													Party2XCustomerVehicleRoleBObj.setStartDate(tempVecXCustomerVehicleRoleJPNBObj.get(0).getStartDate());
													if(tempVecXCustomerVehicleRoleJPNBObj.get(0).getEndDate()!=null && 
															tempVecXCustomerVehicleRoleJPNBObj.get(1).getEndDate()!=null)
													{
														Timestamp role1EndDt = DateFormatter.getTimestamp(tempVecXCustomerVehicleRoleJPNBObj.get(0).getEndDate());
														Timestamp role2EndDt = DateFormatter.getTimestamp(tempVecXCustomerVehicleRoleJPNBObj.get(1).getEndDate());
														
														if(role2EndDt.after(role1EndDt))
														{
															Party2XCustomerVehicleRoleBObj.setEndDate(tempVecXCustomerVehicleRoleJPNBObj.get(1).getEndDate());
														}
														else
														{
															Party2XCustomerVehicleRoleBObj.setEndDate(tempVecXCustomerVehicleRoleJPNBObj.get(0).getEndDate());
														}
													}
													else
													{
														Party2XCustomerVehicleRoleBObj.setEndDate(null);
													}
													xCustomerVehicleRoleMap.put(Party2XCustomerVehicleRoleBObj.getVehicleRoleType(), Party2XCustomerVehicleRoleBObj);
												}
												else
												{
													Party1XCustomerVehicleRoleBObj.setStartDate(tempVecXCustomerVehicleRoleJPNBObj.get(0).getStartDate());
													if(tempVecXCustomerVehicleRoleJPNBObj.get(0).getEndDate()!=null && 
															tempVecXCustomerVehicleRoleJPNBObj.get(1).getEndDate()!=null)
													{
														Timestamp role1EndDt = DateFormatter.getTimestamp(tempVecXCustomerVehicleRoleJPNBObj.get(0).getEndDate());
														Timestamp role2EndDt = DateFormatter.getTimestamp(tempVecXCustomerVehicleRoleJPNBObj.get(1).getEndDate());
														
														if(role2EndDt.after(role1EndDt))
														{
															Party1XCustomerVehicleRoleBObj.setEndDate(tempVecXCustomerVehicleRoleJPNBObj.get(1).getEndDate());
														}
														else
														{
															Party1XCustomerVehicleRoleBObj.setEndDate(tempVecXCustomerVehicleRoleJPNBObj.get(0).getEndDate());
														}
													}
													else
													{
														Party1XCustomerVehicleRoleBObj.setEndDate(null);
													}
													xCustomerVehicleRoleMap.put(Party1XCustomerVehicleRoleBObj.getVehicleRoleType(), Party1XCustomerVehicleRoleBObj);
												}
												
											}
										}
										
									}
									
									for (Map.Entry<String, XCustomerVehicleRoleJPNBObj> entry : xCustomerVehicleRoleMap.entrySet()) 
									{
										vecFinalVehicleRoleBObjs.add(entry.getValue());
									}
									

									Timestamp person1ModifiedDt = DateFormatter
											.getTimestamp(xContVehicleBObjInMap
													.getXCustomerVehicleJPNLastUpdateDate());

									Timestamp person2ModifiedDt = DateFormatter
											.getTimestamp(xCustomerVehicleJPNBObj
													.getXCustomerVehicleJPNLastUpdateDate());
									
									if (person1ModifiedDt.after(person2ModifiedDt)) {
										xContVehicleBObjInMap.getItemsXCustomerVehicleRoleJPNBObj().clear();
										xContVehicleBObjInMap.getItemsXCustomerVehicleRoleJPNBObj().addAll(vecFinalVehicleRoleBObjs);
										xContVehicleBObjInMap.setStartDate(tempVecXCustomerVehicleJPNBObj.get(0).getStartDate());
										if(tempVecXCustomerVehicleJPNBObj.get(0).getEndDate()!=null && tempVecXCustomerVehicleJPNBObj.get(1).getEndDate()!=null)
										{
										java.util.Date xCustomerVehicleJPN2EndDt = simpleDateFmt.parse(tempVecXCustomerVehicleJPNBObj.get(1).getEndDate());
										if(xCustomerVehicleJPN2EndDt.after(xCustomerVehicleJPN1EndDt))
										{
										xContVehicleBObjInMap.setEndDate(tempVecXCustomerVehicleJPNBObj.get(1).getEndDate());
										}
										else
										{
										xContVehicleBObjInMap.setEndDate(tempVecXCustomerVehicleJPNBObj.get(0).getEndDate());
										}
										}
										else if(tempVecXCustomerVehicleJPNBObj.get(0).getEndDate()==null)
										{
											xContVehicleBObjInMap.setEndDate(null);
										}
										else
										{
											xContVehicleBObjInMap.setEndDate(tempVecXCustomerVehicleJPNBObj.get(1).getEndDate());
										}
										xCustomerVehicleMap.put((xContVehicleBObjInMap
												.getXVehicleJPNBObj().getGlobalVIN()) + xContVehicleBObjInMap
												.getXVehicleJPNBObj().getVehicleType(),
												xContVehicleBObjInMap);
										
									}

									else {
										xCustomerVehicleJPNBObj.getItemsXCustomerVehicleRoleJPNBObj().clear();
										xCustomerVehicleJPNBObj.getItemsXCustomerVehicleRoleJPNBObj().addAll(vecFinalVehicleRoleBObjs);
										xCustomerVehicleJPNBObj.setStartDate(tempVecXCustomerVehicleJPNBObj.get(0).getStartDate());
										if(tempVecXCustomerVehicleJPNBObj.get(0).getEndDate()!=null && tempVecXCustomerVehicleJPNBObj.get(1).getEndDate()!=null)
										{
										java.util.Date xCustomerVehicleJPN2EndDt = simpleDateFmt.parse(tempVecXCustomerVehicleJPNBObj.get(1).getEndDate());
										if(xCustomerVehicleJPN2EndDt.after(xCustomerVehicleJPN1EndDt))
										{
											xCustomerVehicleJPNBObj.setEndDate(tempVecXCustomerVehicleJPNBObj.get(1).getEndDate());
										}
										else
										{
											xCustomerVehicleJPNBObj.setEndDate(tempVecXCustomerVehicleJPNBObj.get(0).getEndDate());
										}
										}
										else if(tempVecXCustomerVehicleJPNBObj.get(0).getEndDate()==null)
										{
											xCustomerVehicleJPNBObj.setEndDate(null);
										}
										else
										{
											xCustomerVehicleJPNBObj.setEndDate(tempVecXCustomerVehicleJPNBObj.get(1).getEndDate());
										}
										xCustomerVehicleMap.put((xCustomerVehicleJPNBObj
												.getXVehicleJPNBObj().getGlobalVIN()) +xCustomerVehicleJPNBObj
												.getXVehicleJPNBObj().getVehicleType() ,
												xCustomerVehicleJPNBObj);
										
									}

								}
									else
									{
										VecUnmergedXCustomerVehicleJPNBObj.add(xContVehicleBObjInMap);
										VecUnmergedXCustomerVehicleJPNBObj.add(xCustomerVehicleJPNBObj);
										
										xCustomerVehicleMap.remove((xCustomerVehicleJPNBObj
												.getXVehicleJPNBObj().getGlobalVIN()) +  xCustomerVehicleJPNBObj
												.getXVehicleJPNBObj().getVehicleType());
									}
								} 
								else {

									xCustomerVehicleMap.put((xCustomerVehicleJPNBObj
											.getXVehicleJPNBObj().getGlobalVIN()) +  xCustomerVehicleJPNBObj.getXVehicleJPNBObj().getVehicleType() ,
											xCustomerVehicleJPNBObj);
								}

							}
						}
													
					}
				}
			}

		
		
		// Handle final CVR 
		
		for (Map.Entry<String, XCustomerVehicleJPNBObj> entry : xCustomerVehicleMap
				.entrySet()) 
		{
			Vector<XCustomerVehicleJPNBObj> vectempXCustomerVehicleBObjs = new Vector<XCustomerVehicleJPNBObj>();  
			XCustomerVehicleJPNBObj tempXCustomerVehicleBObj = entry.getValue();
			vectempXCustomerVehicleBObjs.add(tempXCustomerVehicleBObj);
			finalCustomerVehicleMap.put(entry.getKey(), vectempXCustomerVehicleBObjs);
		}
			
		for(XCustomerVehicleJPNBObj tempXCustomerVehicleJPNBObj:VecUnmergedXCustomerVehicleJPNBObj)
		{
			if(finalCustomerVehicleMap.containsKey(tempXCustomerVehicleJPNBObj.getXVehicleJPNBObj().getGlobalVIN()+
					tempXCustomerVehicleJPNBObj.getXVehicleJPNBObj().getVehicleType()+tempXCustomerVehicleJPNBObj.getRetailerId()
					))
			{
				finalCustomerVehicleMap.get(tempXCustomerVehicleJPNBObj.getXVehicleJPNBObj().getGlobalVIN()+
					tempXCustomerVehicleJPNBObj.getXVehicleJPNBObj().getVehicleType()+tempXCustomerVehicleJPNBObj.getRetailerId()).
					add(tempXCustomerVehicleJPNBObj);
			}
			else
			{
				Vector<XCustomerVehicleJPNBObj> vectempXCustomerVehicleBObjs = new Vector<XCustomerVehicleJPNBObj>(); 
				vectempXCustomerVehicleBObjs.add(tempXCustomerVehicleJPNBObj);
				finalCustomerVehicleMap.put(tempXCustomerVehicleJPNBObj.getXVehicleJPNBObj().getGlobalVIN()+
					tempXCustomerVehicleJPNBObj.getXVehicleJPNBObj().getVehicleType()+tempXCustomerVehicleJPNBObj.getRetailerId(), vectempXCustomerVehicleBObjs);
			}
		}
		
		for(Map.Entry<String, Vector<XCustomerVehicleJPNBObj>> entry : finalCustomerVehicleMap
				.entrySet())
		{
			
			Collections.sort(entry.getValue(),
					new Comparator<XCustomerVehicleJPNBObj>() {// Ascending sort
														// - for delta
														// load
						public int compare(XCustomerVehicleJPNBObj xCustomerVehicleJPN1,
								XCustomerVehicleJPNBObj xCustomerVehicleJPN2) {
							
							return xCustomerVehicleJPN1
									.getStartDate()
									.compareTo(
											xCustomerVehicleJPN2.getStartDate());
						}
					});
		}
		
		for(Map.Entry<String, Vector<XCustomerVehicleJPNBObj>> entry : finalCustomerVehicleMap
				.entrySet())
		{
			Vector<XCustomerVehicleJPNBObj> vecUnmergedXCustomerVehicleBObjs = new Vector<XCustomerVehicleJPNBObj>(); 
			vecUnmergedXCustomerVehicleBObjs = entry.getValue();
			
			for(int i=0;i<vecUnmergedXCustomerVehicleBObjs.size();i++)
			 {
				 for(int j =i+1;j<vecUnmergedXCustomerVehicleBObjs.size();j++)
				 {
					    SimpleDateFormat simpleDateFmt = new SimpleDateFormat("yyyy-MM-dd");
					    java.util.Date xCustomerVehicleJPN1EndDt =null;
						java.util.Date xCustomerVehicleJPN2StartDt =null;
						
						toBeMerged = false;
						if(vecUnmergedXCustomerVehicleBObjs.get(0).getEndDate()!=null && 
								vecUnmergedXCustomerVehicleBObjs.get(1).getStartDate()!=null)
						{
						xCustomerVehicleJPN1EndDt =simpleDateFmt.parse(vecUnmergedXCustomerVehicleBObjs.get(0).getEndDate());
						xCustomerVehicleJPN2StartDt =simpleDateFmt.parse(vecUnmergedXCustomerVehicleBObjs.get(1).getStartDate());
						
						long difference = xCustomerVehicleJPN2StartDt.getTime() - xCustomerVehicleJPN1EndDt.getTime();
						float daysBetween = (difference / (1000*60*60*24));
						if(daysBetween<=1)
						{
							toBeMerged = true;
						}
						}
						else if(vecUnmergedXCustomerVehicleBObjs.get(0).getEndDate()==null)
						{
							toBeMerged = true;
						}
						
						if(toBeMerged)
						{
							//toBeMerged = true;
							Vector<XCustomerVehicleRoleJPNBObj>vectempParty1XCustomerVehicleRoleBObjs =new Vector<XCustomerVehicleRoleJPNBObj>();
							Vector<XCustomerVehicleRoleJPNBObj>vectempParty2XCustomerVehicleRoleBObjs =new Vector<XCustomerVehicleRoleJPNBObj>();
							vectempParty1XCustomerVehicleRoleBObjs = vecUnmergedXCustomerVehicleBObjs.get(i).getItemsXCustomerVehicleRoleJPNBObj();
							vectempParty2XCustomerVehicleRoleBObjs = vecUnmergedXCustomerVehicleBObjs.get(j).getItemsXCustomerVehicleRoleJPNBObj();
							HashMap<String, XCustomerVehicleRoleJPNBObj> xCustomerVehicleRoleMap = new HashMap<String, XCustomerVehicleRoleJPNBObj>();
							
							Vector<XCustomerVehicleRoleJPNBObj> vecFinalVehicleRoleBObjs = new Vector<XCustomerVehicleRoleJPNBObj>();
							
							for(XCustomerVehicleRoleJPNBObj Party1XCustomerVehicleRoleBObj :vectempParty1XCustomerVehicleRoleBObjs)
							{
								if(!xCustomerVehicleRoleMap.containsKey(Party1XCustomerVehicleRoleBObj.getVehicleRoleType()))
								{
									xCustomerVehicleRoleMap.put(Party1XCustomerVehicleRoleBObj.getVehicleRoleType(), Party1XCustomerVehicleRoleBObj);
								}
							}
							for(XCustomerVehicleRoleJPNBObj Party2XCustomerVehicleRoleBObj :vectempParty2XCustomerVehicleRoleBObjs)
							{
								if(!xCustomerVehicleRoleMap.containsKey(Party2XCustomerVehicleRoleBObj.getVehicleRoleType()))
								{
									xCustomerVehicleRoleMap.put(Party2XCustomerVehicleRoleBObj.getVehicleRoleType(), Party2XCustomerVehicleRoleBObj);
								}
								else
								{
									XCustomerVehicleRoleJPNBObj Party1XCustomerVehicleRoleBObj = xCustomerVehicleRoleMap.get(Party2XCustomerVehicleRoleBObj.getVehicleRoleType());
									
									/*Timestamp Person1RoleLastModifiedDt = DateFormatter.getTimestamp(Party1XCustomerVehicleRoleBObj.getXCustomerVehicleRoleJPNLastUpdateDate());
									Timestamp Person2RoleLastModifiedDt = DateFormatter.getTimestamp(Party2XCustomerVehicleRoleBObj.getXCustomerVehicleRoleJPNLastUpdateDate());
									if(Person2RoleLastModifiedDt.after(Person1RoleLastModifiedDt))
									{
										xCustomerVehicleRoleMap.put(Party2XCustomerVehicleRoleBObj.getVehicleRoleType(), Party2XCustomerVehicleRoleBObj);
									}*/
									
									Vector <XCustomerVehicleRoleJPNBObj> tempVecXCustomerVehicleRoleJPNBObj = new Vector<XCustomerVehicleRoleJPNBObj>();
									tempVecXCustomerVehicleRoleJPNBObj.add(Party1XCustomerVehicleRoleBObj);
									tempVecXCustomerVehicleRoleJPNBObj.add(Party2XCustomerVehicleRoleBObj);
									
									if(Party1XCustomerVehicleRoleBObj.getStartDate()!=null && Party2XCustomerVehicleRoleBObj.getStartDate()!=null)
									{
										Collections.sort(tempVecXCustomerVehicleRoleJPNBObj,
												new Comparator<XCustomerVehicleRoleJPNBObj>() {// Ascending sort
																					// - for delta
																					// load
													public int compare(XCustomerVehicleRoleJPNBObj xCustomerVehicleRoleJPN1,
															XCustomerVehicleRoleJPNBObj xCustomerVehicleRoleJPN2) {
														
														return xCustomerVehicleRoleJPN1
																.getStartDate()
																.compareTo(
																		xCustomerVehicleRoleJPN2.getStartDate());
													}
												});
										
										Timestamp Person1RoleLastModifiedDt = DateFormatter.getTimestamp(Party1XCustomerVehicleRoleBObj.getXCustomerVehicleRoleJPNLastUpdateDate());
										Timestamp Person2RoleLastModifiedDt = DateFormatter.getTimestamp(Party2XCustomerVehicleRoleBObj.getXCustomerVehicleRoleJPNLastUpdateDate());
										if(Person2RoleLastModifiedDt.after(Person1RoleLastModifiedDt))
										{
											Party2XCustomerVehicleRoleBObj.setStartDate(tempVecXCustomerVehicleRoleJPNBObj.get(0).getStartDate());
											if(tempVecXCustomerVehicleRoleJPNBObj.get(0).getEndDate()!=null && 
													tempVecXCustomerVehicleRoleJPNBObj.get(1).getEndDate()!=null)
											{
												Timestamp role1EndDt = DateFormatter.getTimestamp(tempVecXCustomerVehicleRoleJPNBObj.get(0).getEndDate());
												Timestamp role2EndDt = DateFormatter.getTimestamp(tempVecXCustomerVehicleRoleJPNBObj.get(1).getEndDate());
												
												if(role2EndDt.after(role1EndDt))
												{
													Party2XCustomerVehicleRoleBObj.setEndDate(tempVecXCustomerVehicleRoleJPNBObj.get(1).getEndDate());
												}
												else
												{
													Party2XCustomerVehicleRoleBObj.setEndDate(tempVecXCustomerVehicleRoleJPNBObj.get(0).getEndDate());
												}
											}
											else
											{
												Party2XCustomerVehicleRoleBObj.setEndDate(null);
											}
											xCustomerVehicleRoleMap.put(Party2XCustomerVehicleRoleBObj.getVehicleRoleType(), Party2XCustomerVehicleRoleBObj);
										}
										else
										{
											Party1XCustomerVehicleRoleBObj.setStartDate(tempVecXCustomerVehicleRoleJPNBObj.get(0).getStartDate());
											if(tempVecXCustomerVehicleRoleJPNBObj.get(0).getEndDate()!=null && 
													tempVecXCustomerVehicleRoleJPNBObj.get(1).getEndDate()!=null)
											{
												Timestamp role1EndDt = DateFormatter.getTimestamp(tempVecXCustomerVehicleRoleJPNBObj.get(0).getEndDate());
												Timestamp role2EndDt = DateFormatter.getTimestamp(tempVecXCustomerVehicleRoleJPNBObj.get(1).getEndDate());
												
												if(role2EndDt.after(role1EndDt))
												{
													Party1XCustomerVehicleRoleBObj.setEndDate(tempVecXCustomerVehicleRoleJPNBObj.get(1).getEndDate());
												}
												else
												{
													Party1XCustomerVehicleRoleBObj.setEndDate(tempVecXCustomerVehicleRoleJPNBObj.get(0).getEndDate());
												}
											}
											else
											{
												Party1XCustomerVehicleRoleBObj.setEndDate(null);
											}
											xCustomerVehicleRoleMap.put(Party1XCustomerVehicleRoleBObj.getVehicleRoleType(), Party1XCustomerVehicleRoleBObj);
										}
										
									}
								}
								
							}
							
							for (Map.Entry<String, XCustomerVehicleRoleJPNBObj> entry1 : xCustomerVehicleRoleMap.entrySet()) 
							{
								vecFinalVehicleRoleBObjs.add(entry1.getValue());
							}
							
							Timestamp person1ModifiedDt = DateFormatter
									.getTimestamp(vecUnmergedXCustomerVehicleBObjs.get(i)
											.getXCustomerVehicleJPNLastUpdateDate());

							Timestamp person2ModifiedDt = DateFormatter
									.getTimestamp(vecUnmergedXCustomerVehicleBObjs.get(j)
											.getXCustomerVehicleJPNLastUpdateDate());
							
							if (person1ModifiedDt.after(person2ModifiedDt)) {
								vecUnmergedXCustomerVehicleBObjs.get(i).getItemsXCustomerVehicleRoleJPNBObj().clear();
								vecUnmergedXCustomerVehicleBObjs.get(i).getItemsXCustomerVehicleRoleJPNBObj().addAll(vecFinalVehicleRoleBObjs);
								vecUnmergedXCustomerVehicleBObjs.get(i).setStartDate(vecUnmergedXCustomerVehicleBObjs.get(i).getStartDate());
								//vecUnmergedXCustomerVehicleBObjs.get(i).setEndDate(vecUnmergedXCustomerVehicleBObjs.get(j).getEndDate());
								
								if(vecUnmergedXCustomerVehicleBObjs.get(i).getEndDate()!=null && vecUnmergedXCustomerVehicleBObjs.get(j).getEndDate()!=null)
								{
								java.util.Date xCustomerVehicleJPN2EndDt = simpleDateFmt.parse(vecUnmergedXCustomerVehicleBObjs.get(j).getEndDate());
								if(xCustomerVehicleJPN2EndDt.after(xCustomerVehicleJPN1EndDt))
								{
									vecUnmergedXCustomerVehicleBObjs.get(i).setEndDate(vecUnmergedXCustomerVehicleBObjs.get(j).getEndDate());
								}
								else
								{
									vecUnmergedXCustomerVehicleBObjs.get(i).setEndDate(vecUnmergedXCustomerVehicleBObjs.get(i).getEndDate());
								}
								}
								else if(vecUnmergedXCustomerVehicleBObjs.get(i).getEndDate()==null)
								{
									vecUnmergedXCustomerVehicleBObjs.get(i).setEndDate(null);
								}
								else
								{
									vecUnmergedXCustomerVehicleBObjs.get(i).setEndDate(vecUnmergedXCustomerVehicleBObjs.get(j).getEndDate());
								}
								
								vecUnmergedXCustomerVehicleBObjs.remove(j);
								i=i-1;
								break;
							}
							else {
								vecUnmergedXCustomerVehicleBObjs.get(j).getItemsXCustomerVehicleRoleJPNBObj().clear();
								vecUnmergedXCustomerVehicleBObjs.get(j).getItemsXCustomerVehicleRoleJPNBObj().addAll(vecFinalVehicleRoleBObjs);
								vecUnmergedXCustomerVehicleBObjs.get(j).setStartDate(vecUnmergedXCustomerVehicleBObjs.get(i).getStartDate());
								//vecUnmergedXCustomerVehicleBObjs.get(j).setEndDate(vecUnmergedXCustomerVehicleBObjs.get(j).getEndDate());
								
								if(vecUnmergedXCustomerVehicleBObjs.get(i).getEndDate()!=null && vecUnmergedXCustomerVehicleBObjs.get(j).getEndDate()!=null)
								{
								java.util.Date xCustomerVehicleJPN2EndDt = simpleDateFmt.parse(vecUnmergedXCustomerVehicleBObjs.get(j).getEndDate());
								if(xCustomerVehicleJPN2EndDt.after(xCustomerVehicleJPN1EndDt))
								{
									vecUnmergedXCustomerVehicleBObjs.get(j).setEndDate(vecUnmergedXCustomerVehicleBObjs.get(j).getEndDate());
								}
								else
								{
									vecUnmergedXCustomerVehicleBObjs.get(j).setEndDate(vecUnmergedXCustomerVehicleBObjs.get(i).getEndDate());
								}
								}
								else if(vecUnmergedXCustomerVehicleBObjs.get(i).getEndDate()==null)
								{
									vecUnmergedXCustomerVehicleBObjs.get(j).setEndDate(null);
								}
								else
								{
									vecUnmergedXCustomerVehicleBObjs.get(j).setEndDate(vecUnmergedXCustomerVehicleBObjs.get(j).getEndDate());
								}
								
								vecUnmergedXCustomerVehicleBObjs.set(i, vecUnmergedXCustomerVehicleBObjs.get(j));
								vecUnmergedXCustomerVehicleBObjs.remove(j);
								i=i-1;
								break;
							}
						}
						else
						{
							break;
						}
				 }
			 }
		}
		
		//if(toBeMerged)
		//{
		for (Map.Entry<String, Vector<XCustomerVehicleJPNBObj>> entry : finalCustomerVehicleMap
				.entrySet()) {
						
			Vector<XCustomerVehicleJPNBObj> tempXCustomerVehicleBObjs = entry.getValue();
			
			for(XCustomerVehicleJPNBObj tempXCustomerVehicleBObj :tempXCustomerVehicleBObjs)
			{
				XCustomerVehicleJPNBObj survivedXCustomerVehicleBObj = new XCustomerVehicleJPNBObj();
				survivedXCustomerVehicleBObj = tempXCustomerVehicleBObj;
				survivedXCustomerVehicleBObj.setContId(collapsedPartyId);
				survivedXCustomerVehicleBObj.setControl(control);
				if(tempXCustomerVehicleBObj.getXVehicleJPNBObj()!=null)
				{
				globalVIN = survivedXCustomerVehicleBObj.getXVehicleJPNBObj()
						.getGlobalVIN();
				}
				//vecDBVehicleBObj = vehicleObjectByGVIN(globalVIN, control);
				DWLResponse response2 = dseaAdditionsExtsComponent.getXVehicleJPNByGlobalVIN(globalVIN, control);
				XVehicleJPNBObj dbVehicleJPNBObj = (XVehicleJPNBObj)response2.getData();
				if (dbVehicleJPNBObj == null) {
					response = dseaAdditionsExtsComponent
							.addXCustomerVehicleJPN(survivedXCustomerVehicleBObj);
				} else {
					//survivedXCustomerVehicleBObj.getXVehicleJPNBObj().setXVehicleJPNpkId(dbVehicleJPNBObj.getXVehicleJPNpkId());
					//survivedXCustomerVehicleBObj.getXVehicleJPNBObj().setXVehicleJPNLastUpdateDate(dbVehicleJPNBObj.getXVehicleJPNLastUpdateDate());
					survivedXCustomerVehicleBObj.setVehicleId(dbVehicleJPNBObj.getXVehicleJPNpkId());
					survivedXCustomerVehicleBObj.setXVehicleJPNBObj(null);
					String objectToString =((XCustomerVehicleJPNBObj)survivedXCustomerVehicleBObj).toXML("MDM", "MDMDomains.xsd", 0, null, false);	
			  		//System.out.println(objectToString);
					//System.out.println("Survived CVR:" +survivedXCustomerVehicleBObj.toXML());
					response = dseaAdditionsExtsComponent.addXCustomerVehicleJPN(survivedXCustomerVehicleBObj);
				}
				if (response.getStatus().getStatus() == DWLStatus.FATAL) {
					throw new BusinessProxyException();
				}
			}
			
			
		}
	//}
	}
		
 //---------------------------------------------------For Performance Improvement End
	
	public boolean noOfChar(String sourceI, String suspectI) throws Exception 
	{
	  /*  String source = null;
		String suspect = null;
		source = sourceI.toUpperCase();
		suspect = suspectI.toUpperCase();*/
		boolean isMismatchMore = false;
	    int min = 0;
	    int count = 0;
		if (sourceI.length() < suspectI.length())
			
			 min = sourceI.length();
		else 
			 min = suspectI.length();
		
		for (int i = 0 ;  i < min ; i++)
		{
			if (sourceI.charAt(i) != suspectI.charAt(i))
				
				count ++;	
		}
		 if (count > 1 )
			 isMismatchMore = true;
		return isMismatchMore;
	}

	public void survivedCRRDetailsMVP(Vector<TCRMPartyBObj> vecParties,
			TCRMPartyBObj collapsedPartyBObj, String marketName, DWLControl control)
			throws Exception {
		HashMap<String, XCustomerRetailerBObj> xCustomerRetailerMap = new HashMap<String, XCustomerRetailerBObj>();
		Vector<XCustomerRetailerBObj> vecXCustomerRetailerBObjs = new Vector<XCustomerRetailerBObj>();
		DWLResponse dwlResponse = new DWLResponse();
		DWLResponse response = null;
		//DWLResponse retailer_response = null;
		DSEAAdditionsExtsComponent dseaAdditionsExtsComponent = new DSEAAdditionsExtsComponent();
		String partytId = null;
		String retailerCode = null;
		XRetailerBObj DBRetailerBObj = null;
		String collapsedPartyId = collapsedPartyBObj.getPartyId();
		for (TCRMPartyBObj partyBObj : vecParties) {
			partytId = partyBObj.getPartyId();
			dwlResponse = dseaAdditionsExtsComponent.getAllXCustomerRetailerByPartyId(partytId, control);
			if (dwlResponse.getData() != null) {
				vecXCustomerRetailerBObjs = (Vector<XCustomerRetailerBObj>) dwlResponse
						.getData();
			}
			for (int j = 0; j < vecXCustomerRetailerBObjs.size(); j++) {
				XCustomerRetailerBObj xCustomerRetailerBObj = (XCustomerRetailerBObj) vecXCustomerRetailerBObjs
						.get(j);
				if (!xCustomerRetailerMap.containsKey(xCustomerRetailerBObj
						.getXRetailerBObj().getRetailerCode())) {
					xCustomerRetailerMap.put(xCustomerRetailerBObj
							.getXRetailerBObj().getRetailerCode(),
							xCustomerRetailerBObj);
				} else {
					XCustomerRetailerBObj xContretailerBObjInMap = xCustomerRetailerMap
							.get(xCustomerRetailerBObj.getXRetailerBObj()
									.getRetailerCode());
					Timestamp requestPersonLastModifiedDt = DateFormatter
							.getTimestamp(xContretailerBObjInMap
									.getXRetailerBObj()
									.getLastModifiedSystemDate());
					Timestamp existingPersonLastModifiedDt = DateFormatter
							.getTimestamp(xCustomerRetailerBObj
									.getXRetailerBObj()
									.getLastModifiedSystemDate());
					if (requestPersonLastModifiedDt.after(existingPersonLastModifiedDt)) {
						xCustomerRetailerMap.put(xContretailerBObjInMap
								.getXRetailerBObj().getRetailerCode(),
								xContretailerBObjInMap);
					} else {
						xCustomerRetailerMap.put(xCustomerRetailerBObj
								.getXRetailerBObj().getRetailerCode(),
								xCustomerRetailerBObj);
					}

				}

			}
		}
		for (Map.Entry<String, XCustomerRetailerBObj> entry : xCustomerRetailerMap
				.entrySet()) {
			XCustomerRetailerBObj tempXCustomerRetailerBObj = entry.getValue();
			XCustomerRetailerBObj survivedXCustomerRetailerBObj = new XCustomerRetailerBObj();
			survivedXCustomerRetailerBObj = tempXCustomerRetailerBObj;
			survivedXCustomerRetailerBObj.setContId(collapsedPartyId);
			survivedXCustomerRetailerBObj.setControl(control);
			retailerCode = survivedXCustomerRetailerBObj.getXRetailerBObj()
					.getRetailerCode();
			DWLResponse retailer_response = dseaAdditionsExtsComponent.getXRetailerByRetailerCodeAndMarketName(retailerCode, marketName, control);
			DBRetailerBObj = (XRetailerBObj) retailer_response.getData();
			survivedXCustomerRetailerBObj.setXRetailerBObj(null);
			survivedXCustomerRetailerBObj.setRetailerId(DBRetailerBObj.getRetailerpkId());
			survivedXCustomerRetailerBObj.setObjectReferenceId(marketName);
				response = dseaAdditionsExtsComponent
						.addXCustomerRetailer(survivedXCustomerRetailerBObj);
				if (response.getStatus().getStatus() == DWLStatus.FATAL) {
					throw new BusinessProxyException();
				}

		}
	}

	public void surviveConsentDetailsForMVP(Vector<TCRMPartyBObj> vecParties, TCRMPartyBObj collapsedPartyBObj, DWLControl control) throws Exception 
	{
		HashMap<String,XConsentBObj> XConsentDetailsMap = new HashMap<String, XConsentBObj>();
		Vector<XConsentBObj> vecXConsentBObjs = new Vector<XConsentBObj>();
		DWLResponse dwlResponse = new DWLResponse();
		DWLResponse response = null;
		DSEAAdditionsExtsComponent dseaAdditionsExtsComponent = new DSEAAdditionsExtsComponent();
		String partytId = null;
		String collapsedPartyId = collapsedPartyBObj.getPartyId();
		for(TCRMPartyBObj partyBObj : vecParties)
		{
			partytId = partyBObj.getPartyId();
			dwlResponse = dseaAdditionsExtsComponent.getXConsentByContId(partytId, control);
			Vector<XConsentBObj> vecXConsent = (Vector<XConsentBObj>) dwlResponse.getData();
			
			if(null!= vecXConsent && vecXConsent.size()>0)
			{
				for(XConsentBObj consentBObj : vecXConsent)
				{
					String reatilerFlag = consentBObj.getRetailerFlag();
					String retailerId = consentBObj.getRetailerId();
					String communicationChannel = consentBObj.getCommunicationChannel();
					String requestSourceType = consentBObj.getSourceIdentifierType();
					if(ExternalRuleConstant.CONSENT_RETAILER_FLAG_N.equalsIgnoreCase(reatilerFlag))
					{
						String mapKey = communicationChannel;
						if(!XConsentDetailsMap.containsKey(mapKey))
						{
							XConsentDetailsMap.put(mapKey, consentBObj);
						}
						else
						{
							XConsentBObj XConsentDetailsinMap = XConsentDetailsMap.get(mapKey);
							String existingSourceType = XConsentDetailsinMap.getSourceIdentifierType();
							String requestSourcePriority = getSOurcePriorityForConsent(requestSourceType);
							String existingSourcePriority = getSOurcePriorityForConsent(existingSourceType);
							
							Timestamp requestConsentLastModifiedDt = DateFormatter
									.getTimestamp(consentBObj.getLastModifiedSystemDate());
							
							Timestamp existingConsentLastModifiedDt = DateFormatter
									.getTimestamp(XConsentDetailsinMap.getLastModifiedSystemDate());
							if(requestSourceType.equalsIgnoreCase(existingSourceType))
							{
								if (requestConsentLastModifiedDt.after(existingConsentLastModifiedDt))
								{
									XConsentDetailsMap.put(mapKey, consentBObj);
								}
								else
									XConsentDetailsMap.put(mapKey, XConsentDetailsinMap);
							}
							else
							{
								if(requestSourcePriority.equalsIgnoreCase(existingSourcePriority))
								{
									if (requestConsentLastModifiedDt.after(existingConsentLastModifiedDt))
									{
										XConsentDetailsMap.put(mapKey, consentBObj);
									}
									else
										XConsentDetailsMap.put(mapKey, XConsentDetailsinMap);
								}
								else
								{
									if(Integer.parseInt(requestSourcePriority) > Integer.parseInt(existingSourcePriority))
									{
										XConsentDetailsMap.put(mapKey, consentBObj);
									}
									else
										XConsentDetailsMap.put(mapKey, XConsentDetailsinMap);
								}
							}
						}
					}
					else if(ExternalRuleConstant.CONSENT_RETAILER_FLAG_Y.equalsIgnoreCase(reatilerFlag))
					{
						String mapKey = communicationChannel + retailerId;
						if(!XConsentDetailsMap.containsKey(mapKey))
						{
							XConsentDetailsMap.put(mapKey, consentBObj);
						}
						else
						{
							XConsentBObj XConsentDetailsinMap = XConsentDetailsMap.get(mapKey);
							String existingSourceType = XConsentDetailsinMap.getSourceIdentifierType();
							String requestSourcePriority = getSOurcePriorityForConsent(requestSourceType);
							String existingSourcePriority = getSOurcePriorityForConsent(existingSourceType);
							
							Timestamp requestConsentLastModifiedDt = DateFormatter
									.getTimestamp(consentBObj.getLastModifiedSystemDate());
							
							Timestamp existingConsentLastModifiedDt = DateFormatter
									.getTimestamp(XConsentDetailsinMap.getLastModifiedSystemDate());
							if(requestSourceType.equalsIgnoreCase(existingSourceType))
							{
								if (requestConsentLastModifiedDt.after(existingConsentLastModifiedDt))
								{
									XConsentDetailsMap.put(mapKey, consentBObj);
								}
								else
									XConsentDetailsMap.put(mapKey, XConsentDetailsinMap);
							}
							else
							{
								if(requestSourcePriority.equalsIgnoreCase(existingSourcePriority))
								{
									if (requestConsentLastModifiedDt.after(existingConsentLastModifiedDt))
									{
										XConsentDetailsMap.put(mapKey, consentBObj);
									}
									else
										XConsentDetailsMap.put(mapKey, XConsentDetailsinMap);
								}
								else
								{
									if(Integer.parseInt(requestSourcePriority) > Integer.parseInt(existingSourcePriority))
									{
										XConsentDetailsMap.put(mapKey, consentBObj);
									}
									else
										XConsentDetailsMap.put(mapKey, XConsentDetailsinMap);
								}
							}
						}
					}
					
				}
			}
			
		}
		for(Map.Entry<String, XConsentBObj> entry : XConsentDetailsMap.entrySet())
		{
			XConsentBObj tempXConsentBObj = entry.getValue();
			XConsentBObj survivedXConsentBObj = new XConsentBObj();
			//XConsentBObj inactivexConsentBObj = endExistingConsent(control,tempXConsentBObj.getContId(),tempXConsentBObj.getXConsentpkId(),dseaAdditionsExtsComponent);
			/*survivedXConsentBObj = tempXConsentBObj;
			survivedXConsentBObj.setContId(collapsedPartyId);
			survivedXConsentBObj.setControl(control);*/				
			addNewConsentforSurvivedParty(control,collapsedPartyId,tempXConsentBObj,dseaAdditionsExtsComponent);
			
		}
	
	}
	
	public String getSOurcePriorityForConsentMVP (String sourceSystemType) throws Exception {
		String sourcePriority = null;

		if(StringUtils.isNonBlank(sourceSystemType))
		{
			if(ExternalRuleConstant.SOURCE_SYSTEM_TYPE_SFDC_MVP.equalsIgnoreCase(sourceSystemType) || ExternalRuleConstant.SOURCE_SYSTEM_TYPE_AUTOLINE_MVP.equalsIgnoreCase(sourceSystemType))
			{
				sourcePriority = ExternalRuleConstant.SOURCE_PRIORITY_2;
			
				sourcePriority = ExternalRuleConstant.SOURCE_PRIORITY_1;				
			}
			else
			{
				//Hard Coded for the time being, need to be corrected
				sourcePriority = ExternalRuleConstant.SOURCE_PRIORITY_1;
			}
		}
		return sourcePriority;	
	}
	
	private void addNewConsentforSurvivedPartyMVP(DWLControl control, String collapsedPartyId,XConsentBObj tempXConsentBObj,
            DSEAAdditionsExtsComponent dseaAdditionsExtsComponent) throws Exception {
      
		
		XConsentBObj newXConsentBObj = new XConsentBObj();
		newXConsentBObj.setContId(collapsedPartyId);
		newXConsentBObj.setCommunicationChannel(tempXConsentBObj.getCommunicationChannel());
		newXConsentBObj.setConsentActionType(tempXConsentBObj.getConsentActionType());
		newXConsentBObj.setConsentActionValue(tempXConsentBObj.getConsentActionValue());
		newXConsentBObj.setLastModifiedSystemDate(tempXConsentBObj.getLastModifiedSystemDate());
		newXConsentBObj.setRetailerFlag(tempXConsentBObj.getRetailerFlag());
		newXConsentBObj.setRetailerId(tempXConsentBObj.getRetailerId());
		newXConsentBObj.setSourceIdentifierType(tempXConsentBObj.getSourceIdentifierType());
		newXConsentBObj.setSourceIdentifierValue(tempXConsentBObj.getSourceIdentifierValue());
		newXConsentBObj.setControl(control);
		DWLResponse response=dseaAdditionsExtsComponent.addXConsent(newXConsentBObj);
  
		if (response.getStatus().getStatus() == DWLStatus.FATAL) {
			throw new BusinessProxyException();
      }
      
      
      
}

	//Consent survivorship logic MVP: End
	
	
	//May 21, 2019 : Added by Sameeha for MVP Cluster 2: Start

	public void survivedCRRDetailsHRS(Vector<TCRMPartyBObj> vecParties,
			TCRMPartyBObj collapsedPartyBObj, String marketName, DWLControl control) throws Exception {
		// TODO Auto-generated method stub
		

		HashMap<String, XCustomerRetailerBObj> xCustomerRetailerMap = new HashMap<String, XCustomerRetailerBObj>();
		Vector<XCustomerRetailerBObj> vecXCustomerRetailerBObjs = new Vector<XCustomerRetailerBObj>();
		DWLResponse dwlResponse = new DWLResponse();
		DWLResponse response = null;
		//DWLResponse retailer_response = null;
		DSEAAdditionsExtsComponent dseaAdditionsExtsComponent = new DSEAAdditionsExtsComponent();
		String partytId = null;
		String retailerCode = null;
		XRetailerBObj DBRetailerBObj = null;
		String collapsedPartyId = collapsedPartyBObj.getPartyId();

		for (TCRMPartyBObj partyBObj : vecParties) {
			partytId = partyBObj.getPartyId();
			dwlResponse = dseaAdditionsExtsComponent.getAllXCustomerRetailerByPartyId(partytId, control);
			if (dwlResponse.getData() != null) {
				vecXCustomerRetailerBObjs = (Vector<XCustomerRetailerBObj>) dwlResponse
						.getData();
			}
			for (int j = 0; j < vecXCustomerRetailerBObjs.size(); j++) {
				XCustomerRetailerBObj xCustomerRetailerBObj = (XCustomerRetailerBObj) vecXCustomerRetailerBObjs
						.get(j);
				if (!xCustomerRetailerMap.containsKey(xCustomerRetailerBObj
						.getXRetailerBObj().getRetailerCode())) {
					xCustomerRetailerMap.put(xCustomerRetailerBObj
							.getXRetailerBObj().getRetailerCode(),
							xCustomerRetailerBObj);
				} else {
					XCustomerRetailerBObj xContretailerBObjInMap = xCustomerRetailerMap
							.get(xCustomerRetailerBObj.getXRetailerBObj()
									.getRetailerCode());
					Timestamp requestPersonLastModifiedDt = DateFormatter
							.getTimestamp(xContretailerBObjInMap
									.getXRetailerBObj()
									.getLastModifiedSystemDate());
					Timestamp existingPersonLastModifiedDt = DateFormatter
							.getTimestamp(xCustomerRetailerBObj
									.getXRetailerBObj()
									.getLastModifiedSystemDate());
					if (requestPersonLastModifiedDt.after(existingPersonLastModifiedDt)) {
						xCustomerRetailerMap.put(xContretailerBObjInMap
								.getXRetailerBObj().getRetailerCode(),
								xContretailerBObjInMap);
					} else {
						xCustomerRetailerMap.put(xCustomerRetailerBObj
								.getXRetailerBObj().getRetailerCode(),
								xCustomerRetailerBObj);
					}

				}

			}
		}

		for (Map.Entry<String, XCustomerRetailerBObj> entry : xCustomerRetailerMap
				.entrySet()) {
			XCustomerRetailerBObj tempXCustomerRetailerBObj = entry.getValue();
			XCustomerRetailerBObj survivedXCustomerRetailerBObj = new XCustomerRetailerBObj();
			survivedXCustomerRetailerBObj = tempXCustomerRetailerBObj;
			survivedXCustomerRetailerBObj.setContId(collapsedPartyId);
			survivedXCustomerRetailerBObj.setControl(control);
			retailerCode = survivedXCustomerRetailerBObj.getXRetailerBObj()
					.getRetailerCode();
			DWLResponse retailer_response = dseaAdditionsExtsComponent.getXRetailerByRetailerCodeAndMarketName(retailerCode, marketName, control);
			DBRetailerBObj = (XRetailerBObj) retailer_response.getData();
			survivedXCustomerRetailerBObj.setXRetailerBObj(null);
			survivedXCustomerRetailerBObj.setRetailerId(DBRetailerBObj.getRetailerpkId());
			survivedXCustomerRetailerBObj.setObjectReferenceId(marketName);
				response = dseaAdditionsExtsComponent
						.addXCustomerRetailer(survivedXCustomerRetailerBObj);
				if (response.getStatus().getStatus() == DWLStatus.FATAL) {
					throw new BusinessProxyException();
				}

			}
		
		
	}
	

	public void surviveConsentDetailsForHRS(Vector<TCRMPartyBObj> vecParties, TCRMPartyBObj collapsedPartyBObj, DWLControl control) throws Exception {
		// TODO Auto-generated method stub
		
		HashMap<String,XConsentBObj> XConsentDetailsMap = new HashMap<String, XConsentBObj>();
		Vector<XConsentBObj> vecXConsentBObjs = new Vector<XConsentBObj>();
		DWLResponse dwlResponse = new DWLResponse();
		DWLResponse response = null;
		DSEAAdditionsExtsComponent dseaAdditionsExtsComponent = new DSEAAdditionsExtsComponent();
		String partytId = null;
		String collapsedPartyId = collapsedPartyBObj.getPartyId();
		for(TCRMPartyBObj partyBObj : vecParties)
		{
			partytId = partyBObj.getPartyId();
			dwlResponse = dseaAdditionsExtsComponent.getXConsentByContId(partytId, control);
			Vector<XConsentBObj> vecXConsent = (Vector<XConsentBObj>) dwlResponse.getData();
			
			if(null!= vecXConsent && vecXConsent.size()>0)
			{
				for(XConsentBObj consentBObj : vecXConsent)
				{
					String reatilerFlag = consentBObj.getRetailerFlag();
					String retailerId = consentBObj.getRetailerId();
					String communicationChannel = consentBObj.getCommunicationChannel();
					String requestSourceType = consentBObj.getSourceIdentifierType();
					if(ExternalRuleConstant.CONSENT_RETAILER_FLAG_N.equalsIgnoreCase(reatilerFlag))
					{
						String mapKey = communicationChannel;
						if(!XConsentDetailsMap.containsKey(mapKey))
						{
							XConsentDetailsMap.put(mapKey, consentBObj);
						}
						else
						{
							XConsentBObj XConsentDetailsinMap = XConsentDetailsMap.get(mapKey);
							String existingSourceType = XConsentDetailsinMap.getSourceIdentifierType();
							//May 24, 2019 : Added by Sameeha to remove source priority: Start

							Timestamp requestConsentLastModifiedDt = DateFormatter	.getTimestamp(consentBObj.getLastModifiedSystemDate());
							
							Timestamp existingConsentLastModifiedDt = DateFormatter.getTimestamp(XConsentDetailsinMap.getLastModifiedSystemDate());
							
							if (requestConsentLastModifiedDt.after(existingConsentLastModifiedDt))
								{
									XConsentDetailsMap.put(mapKey, consentBObj);
								}
							else
									XConsentDetailsMap.put(mapKey, XConsentDetailsinMap);
							
							//May 24, 2019 : Added by Sameeha to remove source priority: End

						}
						
					}
					else if(ExternalRuleConstant.CONSENT_RETAILER_FLAG_Y.equalsIgnoreCase(reatilerFlag))
					{
						String mapKey = communicationChannel + retailerId;
						if(!XConsentDetailsMap.containsKey(mapKey))
						{
							XConsentDetailsMap.put(mapKey, consentBObj);
						}
						else
						{
							XConsentBObj XConsentDetailsinMap = XConsentDetailsMap.get(mapKey);
							String existingSourceType = XConsentDetailsinMap.getSourceIdentifierType();
							
							//May 24, 2019 : Added by Sameeha to remove source priority: Start

							Timestamp requestConsentLastModifiedDt = DateFormatter.getTimestamp(consentBObj.getLastModifiedSystemDate());
							
							Timestamp existingConsentLastModifiedDt = DateFormatter.getTimestamp(XConsentDetailsinMap.getLastModifiedSystemDate());
							
							if (requestConsentLastModifiedDt.after(existingConsentLastModifiedDt))
								{
									XConsentDetailsMap.put(mapKey, consentBObj);
								}
							else
									XConsentDetailsMap.put(mapKey, XConsentDetailsinMap);
							
							//May 24, 2019 : Added by Sameeha to remove source priority: End

						}
					}
					
				}
			}
			
		}
		for(Map.Entry<String, XConsentBObj> entry : XConsentDetailsMap.entrySet())
		{
			XConsentBObj tempXConsentBObj = entry.getValue();
			XConsentBObj survivedXConsentBObj = new XConsentBObj();
			//XConsentBObj inactivexConsentBObj = endExistingConsent(control,tempXConsentBObj.getContId(),tempXConsentBObj.getXConsentpkId(),dseaAdditionsExtsComponent);
			/*survivedXConsentBObj = tempXConsentBObj;
			survivedXConsentBObj.setContId(collapsedPartyId);
			survivedXConsentBObj.setControl(control);*/				
			addNewConsentforSurvivedParty(control,collapsedPartyId,tempXConsentBObj,dseaAdditionsExtsComponent);
			
		}
	
		
		
		
	
		
	}
	
	//May 21, 2019 : Added by Sameeha for MVP Cluster 2: End
	
		//June 4, 2019 : Added by Ashish for Data Sharing survivor-ship logic : Start
	
	public void surviveDataSharingDetailsForHRS(Vector<TCRMPartyBObj> vecParties, TCRMPartyBObj collapsedPartyBObj, DWLControl control) throws Exception 
	{
		String collapsedPartyId = collapsedPartyBObj.getPartyId();
		DSEAAdditionsExtsComponent dseaAdditionsExtsComponent = new DSEAAdditionsExtsComponent();
		String partyId = null;
		DWLResponse dwlResponse = new DWLResponse();
		Vector<XDataSharingBObj> vecXWholesaleDataSharing = new Vector<XDataSharingBObj> ();
		HashMap<String,XDataSharingBObj> XRetailDataSharingMap = new HashMap<String, XDataSharingBObj>();	
		boolean isRetailBObjPresent = false;
		for(TCRMPartyBObj partyBObj : vecParties)
		{
			partyId = partyBObj.getPartyId();
			dwlResponse = dseaAdditionsExtsComponent.getDataSharingByPartyId(partyId ,control);
			Vector<XDataSharingBObj> vecXDataSharing = (Vector<XDataSharingBObj>) dwlResponse.getData();
			if(vecXDataSharing!=null)
			{
			for(XDataSharingBObj tempXDataSharing :vecXDataSharing)
			{
				
				if(tempXDataSharing.getRetailerId()!=null || tempXDataSharing.getRetailerFlag().equalsIgnoreCase(ExternalRuleConstant.DATASHARING_RETAILER_FLAG_Y))
				{
					isRetailBObjPresent = true;
					XRetailDataSharingMap.put(tempXDataSharing.getRetailerId(), tempXDataSharing);
				}
				
				else
				{
					if(tempXDataSharing.getDataSharingFlag().equalsIgnoreCase(ExternalRuleConstant.DATASHARING_FLAG_Y))
					vecXWholesaleDataSharing.add(tempXDataSharing);
				}
				}
			}			
		}
		
		if(!vecXWholesaleDataSharing.isEmpty())
		{
		Collections.sort(vecXWholesaleDataSharing,
				new Comparator<XDataSharingBObj>() {// Ascending sort
													// - for delta
													// load
					public int compare(XDataSharingBObj dataSharing1,
							XDataSharingBObj dataSharing2) {
						if (dataSharing1.getLastModifiedSystemDate() == null
								|| dataSharing2
										.getLastModifiedSystemDate() == null)
							return 0;
						return dataSharing1
								.getLastModifiedSystemDate()
								.compareTo(
										dataSharing2.getLastModifiedSystemDate());
					}
				});
		
		
		XDataSharingBObj WSDataSharingBObj = vecXWholesaleDataSharing.get(0);
					
		
		//String objectToString =((XDataSharingBObj)WSDataSharingBObj).toXML("MDM", "MDMDomains.xsd", 0, null, false);	
  		//System.out.println(objectToString);
		
		for(Map.Entry<String, XDataSharingBObj> entry : XRetailDataSharingMap.entrySet())
		{
			XDataSharingBObj reqRetailDataSharing = entry.getValue();
			XDataSharingBObj tempDataSharing = new XDataSharingBObj ();
			
			tempDataSharing.setContId(collapsedPartyId);
			tempDataSharing.setRetailerFlag(DATASHARING_RETAILER_FLAG_Y);
			tempDataSharing.setRetailerId(reqRetailDataSharing.getRetailerId());
			tempDataSharing.setDataSharingFlag(WSDataSharingBObj.getDataSharingFlag());
			tempDataSharing.setSourceIdentifierType(WSDataSharingBObj.getSourceIdentifierType());
			tempDataSharing.setSourceIdentifierValue(WSDataSharingBObj.getSourceIdentifierValue());
			tempDataSharing.setStartDate(WSDataSharingBObj.getStartDate());
			tempDataSharing.setLastModifiedSystemDate(WSDataSharingBObj.getLastModifiedSystemDate());
			
			addNewDataSharingHRSforSurvivedParty(control, collapsedPartyId, tempDataSharing, dseaAdditionsExtsComponent);
		}
		
		XDataSharingBObj finalWSDataSharingBObj = new XDataSharingBObj ();
		
		finalWSDataSharingBObj.setContId(collapsedPartyId);
		finalWSDataSharingBObj.setDataSharingFlag(WSDataSharingBObj.getDataSharingFlag());
		finalWSDataSharingBObj.setRetailerFlag(DATASHARING_RETAILER_FLAG_N);
		finalWSDataSharingBObj.setRetailerId(null);
		finalWSDataSharingBObj.setSourceIdentifierType(WSDataSharingBObj.getSourceIdentifierType());
		finalWSDataSharingBObj.setSourceIdentifierValue(WSDataSharingBObj.getSourceIdentifierValue());
		finalWSDataSharingBObj.setStartDate(WSDataSharingBObj.getStartDate());
		finalWSDataSharingBObj.setLastModifiedSystemDate(WSDataSharingBObj.getLastModifiedSystemDate());
		
		addNewDataSharingHRSforSurvivedParty(control, collapsedPartyId, finalWSDataSharingBObj, dseaAdditionsExtsComponent);
	
		}
		}
	
	private void addNewDataSharingHRSforSurvivedParty(DWLControl control, String collapsedPartyId,XDataSharingBObj tempXDataSharingBObj,
            DSEAAdditionsExtsComponent dseaAdditionsExtsComponent) throws Exception {
      
		 	         
	  tempXDataSharingBObj.setControl(control);
          
      DWLResponse response=dseaAdditionsExtsComponent.addXDataSharing(tempXDataSharingBObj);
      //String objectToString =((XConsentBObj)response.getData()).toXML("MDM", "MDMDomains.xsd", 0, null, false);	
		 // System.out.println(objectToString);
      if (response.getStatus().getStatus() == DWLStatus.FATAL) {
            throw new BusinessProxyException();
      }
      
	}
	
	private void addNewDataSharingKORforSurvivedParty(DWLControl control, String collapsedPartyId,XDataSharingBObj tempXDataSharingBObj,
            DSEAAdditionsExtsComponent dseaAdditionsExtsComponent) throws Exception {
      
		 	         
	  tempXDataSharingBObj.setControl(control);
          
      DWLResponse response=dseaAdditionsExtsComponent.addXDataSharing(tempXDataSharingBObj);
      //String objectToString =((XConsentBObj)response.getData()).toXML("MDM", "MDMDomains.xsd", 0, null, false);	
		 // System.out.println(objectToString);
      if (response.getStatus().getStatus() == DWLStatus.FATAL) {
            throw new BusinessProxyException();
      }
      
	}
	private void addNewDataSharingAEMforSurvivedParty(DWLControl control, String collapsedPartyId,XDataSharingBObj tempXDataSharingBObj,
            DSEAAdditionsExtsComponent dseaAdditionsExtsComponent) throws Exception {
      
		 	         
	  tempXDataSharingBObj.setControl(control);
          
      DWLResponse response=dseaAdditionsExtsComponent.addXDataSharing(tempXDataSharingBObj);
      //String objectToString =((XConsentBObj)response.getData()).toXML("MDM", "MDMDomains.xsd", 0, null, false);	
		 // System.out.println(objectToString);
      if (response.getStatus().getStatus() == DWLStatus.FATAL) {
            throw new BusinessProxyException();
      }
      
	}
	
	
	//June 4, 2019 : Added by Ashish for Data Sharing survivor-ship logic : End

	//AMRUTA GANDHI:  VR AFTER MERGE CODE FOR CLUSTER2 ****** START 
	
	public void survivedCVRDetailsHRS(Vector<TCRMPartyBObj> vecParties,TCRMPartyBObj collapsedPartyBObj, DWLControl control)
			throws Exception {
		HashMap<String, XCustomerVehicleBObj> xCustomerVehicleMap = new HashMap<String, XCustomerVehicleBObj>();
		HashMap<String, XCustomerVehicleBObj> xCustomerVehicleMapAfterDiffRetailerProcessed = new HashMap<String, XCustomerVehicleBObj>();		
		Vector<XCustomerVehicleBObj> vecXCustomerVehicleBObjs = new Vector<XCustomerVehicleBObj>();
		Vector<XCustomerVehicleBObj> vecXCustomerVehicleBObjsForDiffRetailer = new Vector<XCustomerVehicleBObj>();
		DWLResponse dwlResponse = new DWLResponse();
		DWLResponse response = null;
		DSEAAdditionsExtsComponent dseaAdditionsExtsComponent = new DSEAAdditionsExtsComponent();
		String partytId = null;
		String globalVIN = null;
		String requestPersonRetailerCode = null;
		String existingPersonRetailerCode = null;
		Vector<XVehicleBObj> vecDBVehicleBObj = null;
		String collapsedPartyId = collapsedPartyBObj.getPartyId();
		Vector<XCustomerVehicleRoleBObj> vecParty1XCustomerVehicleRoleBObjs = new Vector<XCustomerVehicleRoleBObj>();
		Vector<XCustomerVehicleRoleBObj> allDiffRetailerVehicleRolesToCheckOldestStartDate = new Vector<XCustomerVehicleRoleBObj>();
		Vector<XCustomerVehicleRoleBObj> allXCustomerVehicleRoleBObjsToCheckOldestStartDate = new Vector<XCustomerVehicleRoleBObj>();
		Vector<XCustomerVehicleRoleBObj> vecParty2XCustomerVehicleRoleBObjs = new Vector<XCustomerVehicleRoleBObj>();
		Vector<XCustomerVehicleRoleBObj> vecSurvivedVehicleRoleBObjs = new Vector<XCustomerVehicleRoleBObj>();
		Vector<XCustomerVehicleRoleBObj> vecFinalVehicleRoleBObjs = new Vector<XCustomerVehicleRoleBObj>();
		String globalVINParty1=null;
		String globalVINParty2=null;
		String retailerParty1=null;
		String retailerParty2=null;
		//Timestamp tempOldestStartDate=null;
		boolean isDifferntRetailer =false ;
		HashMap<String, Timestamp> OldestStartDatePerRoleMap= new HashMap<String, Timestamp>();
		
		//System.out.println("******"+vecParties.size());
		for (TCRMPartyBObj partyBObj : vecParties) {
			partytId = partyBObj.getPartyId();
			//System.err.println("PARTY----> "+partytId );
			vecXCustomerVehicleBObjs = getAllXCustomerVehicleByPartyId(partytId, control);
			if (vecXCustomerVehicleBObjs != null && vecXCustomerVehicleBObjs.size() > 0) {
				for (int j = 0; j < vecXCustomerVehicleBObjs.size(); j++) {
					XCustomerVehicleBObj xCustomerVehicleBObj = (XCustomerVehicleBObj) vecXCustomerVehicleBObjs.get(j);
					System.err.println("PARTY ->> " +partytId + " Global vin  ->> " +xCustomerVehicleBObj.getXVehicleBObj().getGlobalVIN());
					if(null==globalVINParty1 && null==retailerParty1){
						
								globalVINParty1=xCustomerVehicleBObj.getXVehicleBObj().getGlobalVIN();
								retailerParty1=xCustomerVehicleBObj.getRetailerId();
					}
					else if(null!=globalVINParty1 && null!=retailerParty1){
						globalVINParty2=xCustomerVehicleBObj.getXVehicleBObj().getGlobalVIN();
						retailerParty2=xCustomerVehicleBObj.getRetailerId();
					}
					
					if (!xCustomerVehicleMap.containsKey((xCustomerVehicleBObj.getXVehicleBObj().getGlobalVIN())
							+ (xCustomerVehicleBObj.getRetailerId()))) 
					{
						xCustomerVehicleMap.put((xCustomerVehicleBObj.getXVehicleBObj().getGlobalVIN()) + (xCustomerVehicleBObj.getRetailerId()),
								xCustomerVehicleBObj);
						vecXCustomerVehicleBObjsForDiffRetailer.add(xCustomerVehicleBObj);
						if(xCustomerVehicleMap.size()>1 )
						{
							/*  If global VIN + retailer code is not matching that means either different vehicle or 
							 * different retailer is attached to two different parties
							 * Scenario for Different Retailers comes 
							 * * */
							
							if(globalVINParty1.equalsIgnoreCase(globalVINParty2) && !retailerParty1.equalsIgnoreCase(retailerParty2)){
							//System.err.println("xCustomerVehicleMap.size() --> "+xCustomerVehicleMap.size());
							isDifferntRetailer=true;
							
							xCustomerVehicleMap=handleDifferentRetailers(vecXCustomerVehicleBObjsForDiffRetailer,
									xCustomerVehicleMap,allDiffRetailerVehicleRolesToCheckOldestStartDate,OldestStartDatePerRoleMap);
							//xCustomerVehicleMap.clear();
							//xCustomerVehicleMap.putAll(xCustomerVehicleMapAfterDiffRetailerProcessed);
							//System.err.println("xCustomerVehicleMap after -- > "+xCustomerVehicleMap.size());
							}
						}
						
					} else {
						XCustomerVehicleBObj xContVehicleBObjInMap = xCustomerVehicleMap.get((xCustomerVehicleBObj.getXVehicleBObj().getGlobalVIN()) 
								+ (xCustomerVehicleBObj.getRetailerId()));
						requestPersonRetailerCode = xContVehicleBObjInMap.getRetailerId();
						//System.err.println("requestPersonRetailerCode  -- > "+requestPersonRetailerCode);
						existingPersonRetailerCode = xCustomerVehicleBObj.getRetailerId();
						System.err.println("Party 1 RetailerCode ->> "+requestPersonRetailerCode+" , "+ 
										   "Party 2 RetailerCode ->> "+existingPersonRetailerCode);
						
						//IF retailer code matches 
						if (requestPersonRetailerCode != null && existingPersonRetailerCode != null && requestPersonRetailerCode
										.equalsIgnoreCase(existingPersonRetailerCode)) 
						{
							//Request last modified date
							Timestamp requestPersonLastModifiedDt = DateFormatter.getTimestamp(xContVehicleBObjInMap.getXCustomerVehicleLastUpdateDate());
							//System.err.println("Party 1 ->> "+ requestPersonLastModifiedDt);
							//DB last modified date
							Timestamp existingPersonLastModifiedDt = DateFormatter.getTimestamp(xCustomerVehicleBObj.getXCustomerVehicleLastUpdateDate());
//							System.err.println("Party 1 LastModifiedDt ->> "+ requestPersonLastModifiedDt
//							+ " ," +"Party 2 LastModifiedDt  ->> "+existingPersonLastModifiedDt);
//							//If request is latest than DB last modified date then put all active roles in final bobj
						
							
							allXCustomerVehicleRoleBObjsToCheckOldestStartDate.addAll(xContVehicleBObjInMap.getItemsXCustomerVehicleRoleBObj());
							allXCustomerVehicleRoleBObjsToCheckOldestStartDate.addAll(xCustomerVehicleBObj.getItemsXCustomerVehicleRoleBObj());
							//System.err.println(allXCustomerVehicleRoleBObjsToCheckOldestStartDate.size());
							OldestStartDatePerRoleMap=setOldestStartdateToActiveRole(allXCustomerVehicleRoleBObjsToCheckOldestStartDate);
							
							if (requestPersonLastModifiedDt.after(existingPersonLastModifiedDt)) {
								// get all the request customer vehicle roles into Vector 
								vecParty1XCustomerVehicleRoleBObjs = xContVehicleBObjInMap.getItemsXCustomerVehicleRoleBObj();
								//System.err.println("vecParty1XCustomerVehicleRoleBObjs.size  -- > "+vecParty1XCustomerVehicleRoleBObjs.size());
								if (vecParty1XCustomerVehicleRoleBObjs != null  && vecParty1XCustomerVehicleRoleBObjs.size() > 0) {
									for (XCustomerVehicleRoleBObj xCustomerVehicleRoleBObj : vecParty1XCustomerVehicleRoleBObjs) {

										
										if (xCustomerVehicleRoleBObj.getEndDate() == null) 
										{
											// put all active roles into final vector 
											if(null!=OldestStartDatePerRoleMap && OldestStartDatePerRoleMap.size()!=0){
											if(xCustomerVehicleRoleBObj.getVehicleRoleType().equalsIgnoreCase(SALES_ROLE_TYPE)){
												xCustomerVehicleRoleBObj.setStartDate((OldestStartDatePerRoleMap.get(SALES_ROLE_TYPE)).toString());
											}else if(xCustomerVehicleRoleBObj.getVehicleRoleType().equalsIgnoreCase(AFTERSALES_ROLE_TYPE)){
												xCustomerVehicleRoleBObj.setStartDate((OldestStartDatePerRoleMap.get(AFTERSALES_ROLE_TYPE)).toString());
											}else if(xCustomerVehicleRoleBObj.getVehicleRoleType().equalsIgnoreCase(DRIVER_ROLE_TYPE)){
												xCustomerVehicleRoleBObj.setStartDate((OldestStartDatePerRoleMap.get(DRIVER_ROLE_TYPE)).toString());
											}	
													vecFinalVehicleRoleBObjs.add(xCustomerVehicleRoleBObj);
											}
										}
										else{}
									}
								}

								xContVehicleBObjInMap.getItemsXCustomerVehicleRoleBObj().clear();
								xContVehicleBObjInMap.getItemsXCustomerVehicleRoleBObj().addAll(vecFinalVehicleRoleBObjs);
								//System.err.println("vecFinalVehicleRoleBObjs -- >"+vecFinalVehicleRoleBObjs.size());

							}
							//If DB has latest data than Request last modified date then put all active roles in final bobj
							else {
								// get all db customer vehicle roles into vector
								vecParty2XCustomerVehicleRoleBObjs = xCustomerVehicleBObj.getItemsXCustomerVehicleRoleBObj();

								if (vecParty2XCustomerVehicleRoleBObjs != null && vecParty2XCustomerVehicleRoleBObjs.size() > 0) 
								{

									for (XCustomerVehicleRoleBObj xCustomerVehicleRoleBObj : vecParty2XCustomerVehicleRoleBObjs) {
										if (xCustomerVehicleRoleBObj.getEndDate() == null) {
											// put all active roles into final vector 
											//vecFinalVehicleRoleBObjs.add(xCustomerVehicleRoleBObj);
											
											// put all active roles into final vector 
											if(null!=OldestStartDatePerRoleMap && OldestStartDatePerRoleMap.size()!=0){
												if(xCustomerVehicleRoleBObj.getVehicleRoleType().equalsIgnoreCase(SALES_ROLE_TYPE)){
													xCustomerVehicleRoleBObj.setStartDate((OldestStartDatePerRoleMap.get(SALES_ROLE_TYPE)).toString());
												}else if(xCustomerVehicleRoleBObj.getVehicleRoleType().equalsIgnoreCase(AFTERSALES_ROLE_TYPE)){
													xCustomerVehicleRoleBObj.setStartDate((OldestStartDatePerRoleMap.get(AFTERSALES_ROLE_TYPE)).toString());
												}else if(xCustomerVehicleRoleBObj.getVehicleRoleType().equalsIgnoreCase(DRIVER_ROLE_TYPE)){
													xCustomerVehicleRoleBObj.setStartDate((OldestStartDatePerRoleMap.get(DRIVER_ROLE_TYPE)).toString());
												}
													vecFinalVehicleRoleBObjs.add(xCustomerVehicleRoleBObj);
											}
										}

									}

								}
								//System.err.println("******************vecFinalVehicleRoleBObjs.size()-->> "+vecFinalVehicleRoleBObjs.size());

								xCustomerVehicleBObj.getItemsXCustomerVehicleRoleBObj().clear();
								//xCustomerVehicleBObj.getItemsXCustomerVehicleRoleBObj().addAll(vecParty2XCustomerVehicleRoleBObjs);
								xCustomerVehicleBObj.getItemsXCustomerVehicleRoleBObj().addAll(vecFinalVehicleRoleBObjs);

							}
							// xCustomerVehicleBObj: - Final active roles from DB which are latest than Request
							//xContVehicleBObjInMap:- Final Active roles from request which are latest than DB
							
							// Request XCustomerVehicleLastUpdateDate
							Timestamp person1ModifiedDt = DateFormatter.getTimestamp(xContVehicleBObjInMap.getXCustomerVehicleLastUpdateDate());
							// DB XCustomerVehicleLastUpdateDate
							//System.err.println("person1ModifiedDt --->>> "+person1ModifiedDt);
							Timestamp person2ModifiedDt = DateFormatter.getTimestamp(xCustomerVehicleBObj.getXCustomerVehicleLastUpdateDate());
							//System.err.println("person2ModifiedDt --->>> "+person2ModifiedDt);
							if (person1ModifiedDt.after(person2ModifiedDt)) {

								xCustomerVehicleMap.put((xContVehicleBObjInMap.getXVehicleBObj().getGlobalVIN()) 
										+ (xContVehicleBObjInMap.getRetailerId()),xContVehicleBObjInMap);
							}

							else {

								xCustomerVehicleMap.put((xCustomerVehicleBObj
										.getXVehicleBObj().getGlobalVIN()) + (xCustomerVehicleBObj.getRetailerId()),
										xCustomerVehicleBObj);
							}

						} 
						// for different retailers 
						else {
							
							
							xCustomerVehicleMap.put((xCustomerVehicleBObj.getXVehicleBObj().getGlobalVIN()) + 
									(xCustomerVehicleBObj.getRetailerId()),xCustomerVehicleBObj);	
							
						}

					}

				}
			}
		}
		

		
		for (Map.Entry<String, XCustomerVehicleBObj> entry : xCustomerVehicleMap.entrySet()) {
			XCustomerVehicleBObj tempXCustomerVehicleBObj = entry.getValue();
			XCustomerVehicleBObj survivedXCustomerVehicleBObj = new XCustomerVehicleBObj();
			survivedXCustomerVehicleBObj = tempXCustomerVehicleBObj;
			survivedXCustomerVehicleBObj.setContId(collapsedPartyId);
			survivedXCustomerVehicleBObj.setControl(control);
			globalVIN = survivedXCustomerVehicleBObj.getXVehicleBObj().getGlobalVIN();
			vecDBVehicleBObj = vehicleObjectByGVIN(globalVIN, control);
			if (vecDBVehicleBObj == null || vecDBVehicleBObj.isEmpty()) {
				response = dseaAdditionsExtsComponent.addXCustomerVehicle(survivedXCustomerVehicleBObj);
			} else {
				survivedXCustomerVehicleBObj.getXVehicleBObj().setVehiclepkId(vecDBVehicleBObj.get(0).getVehiclepkId());
				survivedXCustomerVehicleBObj.getXVehicleBObj().setXVehicleLastUpdateDate(vecDBVehicleBObj.get(0).getXVehicleLastUpdateDate());
				survivedXCustomerVehicleBObj.setVehicleId(vecDBVehicleBObj.get(0).getVehiclepkId());
				System.err.println("Final relationship count ->>  "+xCustomerVehicleMap.size()+", "+
				"Survived XCustomerVehicleRoleBObj Count ->> "+survivedXCustomerVehicleBObj.getItemsXCustomerVehicleRoleBObj().size());
				response = dseaAdditionsExtsComponent.addXCustomerVehicle(survivedXCustomerVehicleBObj);
			}
			if (response.getStatus().getStatus() == DWLStatus.FATAL) {
				throw new BusinessProxyException();
			}
		}
	}
	

	//July 18, 2019 : Added by Pushpraj for MVP Cluster 3: Start

	public void survivedCRRDetailsAEM(Vector<TCRMPartyBObj> vecParties,
			TCRMPartyBObj collapsedPartyBObj, String marketName, DWLControl control) throws Exception {
		// TODO Auto-generated method stub
		

		HashMap<String, XCustomerRetailerBObj> xCustomerRetailerMap = new HashMap<String, XCustomerRetailerBObj>();
		Vector<XCustomerRetailerBObj> vecXCustomerRetailerBObjs = new Vector<XCustomerRetailerBObj>();
		DWLResponse dwlResponse = new DWLResponse();
		DWLResponse response = null;
		//DWLResponse retailer_response = null;
		DSEAAdditionsExtsComponent dseaAdditionsExtsComponent = new DSEAAdditionsExtsComponent();
		String partytId = null;
		String retailerCode = null;
		XRetailerBObj DBRetailerBObj = null;
		String collapsedPartyId = collapsedPartyBObj.getPartyId();

		for (TCRMPartyBObj partyBObj : vecParties) {
			partytId = partyBObj.getPartyId();
			dwlResponse = dseaAdditionsExtsComponent.getAllXCustomerRetailerByPartyId(partytId, control);
			if (dwlResponse.getData() != null) {
				vecXCustomerRetailerBObjs = (Vector<XCustomerRetailerBObj>) dwlResponse
						.getData();
			}
			for (int j = 0; j < vecXCustomerRetailerBObjs.size(); j++) {
				XCustomerRetailerBObj xCustomerRetailerBObj = (XCustomerRetailerBObj) vecXCustomerRetailerBObjs
						.get(j);
				if (!xCustomerRetailerMap.containsKey(xCustomerRetailerBObj
						.getXRetailerBObj().getRetailerCode())) {
					xCustomerRetailerMap.put(xCustomerRetailerBObj
							.getXRetailerBObj().getRetailerCode(),
							xCustomerRetailerBObj);
				} else {
					XCustomerRetailerBObj xContretailerBObjInMap = xCustomerRetailerMap
							.get(xCustomerRetailerBObj.getXRetailerBObj()
									.getRetailerCode());
					Timestamp requestPersonLastModifiedDt = DateFormatter
							.getTimestamp(xContretailerBObjInMap
									.getXRetailerBObj()
									.getLastModifiedSystemDate());
					Timestamp existingPersonLastModifiedDt = DateFormatter
							.getTimestamp(xCustomerRetailerBObj
									.getXRetailerBObj()
									.getLastModifiedSystemDate());
					if (requestPersonLastModifiedDt.after(existingPersonLastModifiedDt)) {
						xCustomerRetailerMap.put(xContretailerBObjInMap
								.getXRetailerBObj().getRetailerCode(),
								xContretailerBObjInMap);
					} else {
						xCustomerRetailerMap.put(xCustomerRetailerBObj
								.getXRetailerBObj().getRetailerCode(),
								xCustomerRetailerBObj);
					}

				}

			}
		}

		for (Map.Entry<String, XCustomerRetailerBObj> entry : xCustomerRetailerMap
				.entrySet()) {
			XCustomerRetailerBObj tempXCustomerRetailerBObj = entry.getValue();
			XCustomerRetailerBObj survivedXCustomerRetailerBObj = new XCustomerRetailerBObj();
			survivedXCustomerRetailerBObj = tempXCustomerRetailerBObj;
			survivedXCustomerRetailerBObj.setContId(collapsedPartyId);
			survivedXCustomerRetailerBObj.setControl(control);
			retailerCode = survivedXCustomerRetailerBObj.getXRetailerBObj()
					.getRetailerCode();
			DWLResponse retailer_response = dseaAdditionsExtsComponent.getXRetailerByRetailerCodeAndMarketName(retailerCode, marketName, control);
			DBRetailerBObj = (XRetailerBObj) retailer_response.getData();
			survivedXCustomerRetailerBObj.setXRetailerBObj(null);
			survivedXCustomerRetailerBObj.setRetailerId(DBRetailerBObj.getRetailerpkId());
			survivedXCustomerRetailerBObj.setObjectReferenceId(marketName);
				response = dseaAdditionsExtsComponent
						.addXCustomerRetailer(survivedXCustomerRetailerBObj);
				if (response.getStatus().getStatus() == DWLStatus.FATAL) {
					throw new BusinessProxyException();
				}

			}
		
		
	}
	

	public void surviveConsentDetailsForAEM(Vector<TCRMPartyBObj> vecParties, TCRMPartyBObj collapsedPartyBObj, DWLControl control) throws Exception {
		// TODO Auto-generated method stub
		
		HashMap<String,XConsentBObj> XConsentDetailsMap = new HashMap<String, XConsentBObj>();
		Vector<XConsentBObj> vecXConsentBObjs = new Vector<XConsentBObj>();
		DWLResponse dwlResponse = new DWLResponse();
		DWLResponse response = null;
		DSEAAdditionsExtsComponent dseaAdditionsExtsComponent = new DSEAAdditionsExtsComponent();
		String partytId = null;
		String collapsedPartyId = collapsedPartyBObj.getPartyId();
		for(TCRMPartyBObj partyBObj : vecParties)
		{
			partytId = partyBObj.getPartyId();
			dwlResponse = dseaAdditionsExtsComponent.getXConsentByContId(partytId, control);
			Vector<XConsentBObj> vecXConsent = (Vector<XConsentBObj>) dwlResponse.getData();
			
			if(null!= vecXConsent && vecXConsent.size()>0)
			{
				for(XConsentBObj consentBObj : vecXConsent)
				{
					String reatilerFlag = consentBObj.getRetailerFlag();
					String retailerId = consentBObj.getRetailerId();
					String communicationChannel = consentBObj.getCommunicationChannel();
					String requestSourceType = consentBObj.getSourceIdentifierType();
					if(ExternalRuleConstant.CONSENT_RETAILER_FLAG_N.equalsIgnoreCase(reatilerFlag))
					{
						String mapKey = communicationChannel;
						if(!XConsentDetailsMap.containsKey(mapKey))
						{
							XConsentDetailsMap.put(mapKey, consentBObj);
						}
						else
						{
							XConsentBObj XConsentDetailsinMap = XConsentDetailsMap.get(mapKey);
							String existingSourceType = XConsentDetailsinMap.getSourceIdentifierType();
							//July 18, 2019 : Added by Pushpraj to remove source priority: Start

							Timestamp requestConsentLastModifiedDt = DateFormatter	.getTimestamp(consentBObj.getLastModifiedSystemDate());
							
							Timestamp existingConsentLastModifiedDt = DateFormatter.getTimestamp(XConsentDetailsinMap.getLastModifiedSystemDate());
							
							if (requestConsentLastModifiedDt.after(existingConsentLastModifiedDt))
								{
									XConsentDetailsMap.put(mapKey, consentBObj);
								}
							else
									XConsentDetailsMap.put(mapKey, XConsentDetailsinMap);
							
							//July 18, 2019 : Added by Pushpraj to remove source priority: End

						}
						
					}
					else if(ExternalRuleConstant.CONSENT_RETAILER_FLAG_Y.equalsIgnoreCase(reatilerFlag))
					{
						String mapKey = communicationChannel + retailerId;
						if(!XConsentDetailsMap.containsKey(mapKey))
						{
							XConsentDetailsMap.put(mapKey, consentBObj);
						}
						else
						{
							XConsentBObj XConsentDetailsinMap = XConsentDetailsMap.get(mapKey);
							String existingSourceType = XConsentDetailsinMap.getSourceIdentifierType();
							
							//July 18, 2019 : Added by Pushpraj to remove source priority: Start

							Timestamp requestConsentLastModifiedDt = DateFormatter.getTimestamp(consentBObj.getLastModifiedSystemDate());
							
							Timestamp existingConsentLastModifiedDt = DateFormatter.getTimestamp(XConsentDetailsinMap.getLastModifiedSystemDate());
							
							if (requestConsentLastModifiedDt.after(existingConsentLastModifiedDt))
								{
									XConsentDetailsMap.put(mapKey, consentBObj);
								}
							else
									XConsentDetailsMap.put(mapKey, XConsentDetailsinMap);
							
							//July 18, 2019 : Added by Pushpraj to remove source priority: End

						}
					}
					
				}
			}
			
		}
		for(Map.Entry<String, XConsentBObj> entry : XConsentDetailsMap.entrySet())
		{
			XConsentBObj tempXConsentBObj = entry.getValue();
			XConsentBObj survivedXConsentBObj = new XConsentBObj();
			//XConsentBObj inactivexConsentBObj = endExistingConsent(control,tempXConsentBObj.getContId(),tempXConsentBObj.getXConsentpkId(),dseaAdditionsExtsComponent);
			/*survivedXConsentBObj = tempXConsentBObj;
			survivedXConsentBObj.setContId(collapsedPartyId);
			survivedXConsentBObj.setControl(control);*/				
			addNewConsentforSurvivedPartyAEM(control,collapsedPartyId,tempXConsentBObj,dseaAdditionsExtsComponent);
			
		}
	
		
		
		
	
		
	}
	
	//July 18, 2019 : Added by Pushpraj for MVP Cluster 3: End
	
		//July 18, 2019 : Added by Pushpraj for Data Sharing survivor-ship logic : Start
	
	public void surviveDataSharingDetailsForAEM(Vector<TCRMPartyBObj> vecParties, TCRMPartyBObj collapsedPartyBObj, DWLControl control) throws Exception 
	{
		String collapsedPartyId = collapsedPartyBObj.getPartyId();
		DSEAAdditionsExtsComponent dseaAdditionsExtsComponent = new DSEAAdditionsExtsComponent();
		String partyId = null;
		DWLResponse dwlResponse = new DWLResponse();
		Vector<XDataSharingBObj> vecXWholesaleDataSharing = new Vector<XDataSharingBObj> ();
		HashMap<String,XDataSharingBObj> XRetailDataSharingMap = new HashMap<String, XDataSharingBObj>();	
		boolean isRetailBObjPresent = false;
		for(TCRMPartyBObj partyBObj : vecParties)
		{
			partyId = partyBObj.getPartyId();
			dwlResponse = dseaAdditionsExtsComponent.getDataSharingByPartyId(partyId ,control);
			Vector<XDataSharingBObj> vecXDataSharing = (Vector<XDataSharingBObj>) dwlResponse.getData();
			if(vecXDataSharing!=null)
			{
			for(XDataSharingBObj tempXDataSharing :vecXDataSharing)
			{
				
				if(tempXDataSharing.getRetailerId()!=null || tempXDataSharing.getRetailerFlag().equalsIgnoreCase(ExternalRuleConstant.DATASHARING_RETAILER_FLAG_Y))
				{
					isRetailBObjPresent = true;
					XRetailDataSharingMap.put(tempXDataSharing.getRetailerId(), tempXDataSharing);
				}
				
				else
				{
					if(tempXDataSharing.getDataSharingFlag().equalsIgnoreCase(ExternalRuleConstant.DATASHARING_FLAG_Y))
					vecXWholesaleDataSharing.add(tempXDataSharing);
				}
				}
			}			
		}
		
		if(!vecXWholesaleDataSharing.isEmpty())
		{
		Collections.sort(vecXWholesaleDataSharing,
				new Comparator<XDataSharingBObj>() {// Ascending sort
													// - for delta
													// load
					public int compare(XDataSharingBObj dataSharing1,
							XDataSharingBObj dataSharing2) {
						if (dataSharing1.getLastModifiedSystemDate() == null
								|| dataSharing2
										.getLastModifiedSystemDate() == null)
							return 0;
						return dataSharing1
								.getLastModifiedSystemDate()
								.compareTo(
										dataSharing2.getLastModifiedSystemDate());
					}
				});
		
		
		XDataSharingBObj WSDataSharingBObj = vecXWholesaleDataSharing.get(0);
					
		
		//String objectToString =((XDataSharingBObj)WSDataSharingBObj).toXML("MDM", "MDMDomains.xsd", 0, null, false);	
  		//System.out.println(objectToString);
		
		for(Map.Entry<String, XDataSharingBObj> entry : XRetailDataSharingMap.entrySet())
		{
			XDataSharingBObj reqRetailDataSharing = entry.getValue();
			XDataSharingBObj tempDataSharing = new XDataSharingBObj ();
			
			tempDataSharing.setContId(collapsedPartyId);
			tempDataSharing.setRetailerFlag(DATASHARING_RETAILER_FLAG_Y);
			tempDataSharing.setRetailerId(reqRetailDataSharing.getRetailerId());
			tempDataSharing.setDataSharingFlag(WSDataSharingBObj.getDataSharingFlag());
			tempDataSharing.setSourceIdentifierType(WSDataSharingBObj.getSourceIdentifierType());
			tempDataSharing.setSourceIdentifierValue(WSDataSharingBObj.getSourceIdentifierValue());
			tempDataSharing.setStartDate(WSDataSharingBObj.getStartDate());
			tempDataSharing.setLastModifiedSystemDate(WSDataSharingBObj.getLastModifiedSystemDate());
			
			addNewDataSharingAEMforSurvivedParty(control, collapsedPartyId, tempDataSharing, dseaAdditionsExtsComponent);
		}
		
		XDataSharingBObj finalWSDataSharingBObj = new XDataSharingBObj ();
		
		finalWSDataSharingBObj.setContId(collapsedPartyId);
		finalWSDataSharingBObj.setDataSharingFlag(WSDataSharingBObj.getDataSharingFlag());
		finalWSDataSharingBObj.setRetailerFlag(DATASHARING_RETAILER_FLAG_N);
		finalWSDataSharingBObj.setRetailerId(null);
		finalWSDataSharingBObj.setSourceIdentifierType(WSDataSharingBObj.getSourceIdentifierType());
		finalWSDataSharingBObj.setSourceIdentifierValue(WSDataSharingBObj.getSourceIdentifierValue());
		finalWSDataSharingBObj.setStartDate(WSDataSharingBObj.getStartDate());
		finalWSDataSharingBObj.setLastModifiedSystemDate(WSDataSharingBObj.getLastModifiedSystemDate());
		
		addNewDataSharingAEMforSurvivedParty(control, collapsedPartyId, finalWSDataSharingBObj, dseaAdditionsExtsComponent);
	
		}
		}
		
		
		//  VR AFTER MERGE CODE FOR CLUSTER3 ****** START 
	
	public void survivedCVRDetailsAEM(Vector<TCRMPartyBObj> vecParties,TCRMPartyBObj collapsedPartyBObj, DWLControl control)
			throws Exception {
		HashMap<String, XCustomerVehicleBObj> xCustomerVehicleMap = new HashMap<String, XCustomerVehicleBObj>();
		HashMap<String, XCustomerVehicleBObj> xCustomerVehicleMapAfterDiffRetailerProcessed = new HashMap<String, XCustomerVehicleBObj>();		
		Vector<XCustomerVehicleBObj> vecXCustomerVehicleBObjs = new Vector<XCustomerVehicleBObj>();
		Vector<XCustomerVehicleBObj> vecXCustomerVehicleBObjsForDiffRetailer = new Vector<XCustomerVehicleBObj>();
		DWLResponse dwlResponse = new DWLResponse();
		DWLResponse response = null;
		DSEAAdditionsExtsComponent dseaAdditionsExtsComponent = new DSEAAdditionsExtsComponent();
		String partytId = null;
		String globalVIN = null;
		String requestPersonRetailerCode = null;
		String existingPersonRetailerCode = null;
		Vector<XVehicleBObj> vecDBVehicleBObj = null;
		String collapsedPartyId = collapsedPartyBObj.getPartyId();
		Vector<XCustomerVehicleRoleBObj> vecParty1XCustomerVehicleRoleBObjs = new Vector<XCustomerVehicleRoleBObj>();
		Vector<XCustomerVehicleRoleBObj> allDiffRetailerVehicleRolesToCheckOldestStartDate = new Vector<XCustomerVehicleRoleBObj>();
		Vector<XCustomerVehicleRoleBObj> allXCustomerVehicleRoleBObjsToCheckOldestStartDate = new Vector<XCustomerVehicleRoleBObj>();
		Vector<XCustomerVehicleRoleBObj> vecParty2XCustomerVehicleRoleBObjs = new Vector<XCustomerVehicleRoleBObj>();
		Vector<XCustomerVehicleRoleBObj> vecSurvivedVehicleRoleBObjs = new Vector<XCustomerVehicleRoleBObj>();
		Vector<XCustomerVehicleRoleBObj> vecFinalVehicleRoleBObjs = new Vector<XCustomerVehicleRoleBObj>();
		Vector<XCustomerVehicleRoleBObj> vecFinalVehicleRoleBObjsToBeSurvived = new Vector<XCustomerVehicleRoleBObj>();
		String globalVINParty1=null;
		String globalVINParty2=null;
		String retailerParty1=null;
		String retailerParty2=null;
		//Timestamp tempOldestStartDate=null;
		boolean isDifferntRetailer =false ;
		HashMap<String, Timestamp> OldestStartDatePerRoleMap= new HashMap<String, Timestamp>();
		ArrayList<String> addedRolesToSurvive=new ArrayList<String>();
		
		//System.out.println("******"+vecParties.size());
		for (TCRMPartyBObj partyBObj : vecParties) {
			partytId = partyBObj.getPartyId();
			//System.err.println("PARTY----> "+partytId );
			vecXCustomerVehicleBObjs = getAllXCustomerVehicleByPartyId(partytId, control);
			if (vecXCustomerVehicleBObjs != null && vecXCustomerVehicleBObjs.size() > 0) {
				for (int j = 0; j < vecXCustomerVehicleBObjs.size(); j++) {
					XCustomerVehicleBObj xCustomerVehicleBObj = (XCustomerVehicleBObj) vecXCustomerVehicleBObjs.get(j);
					//System.err.println("PARTY ->> " +partytId + " Global vin  ->> " +xCustomerVehicleBObj.getXVehicleBObj().getGlobalVIN());
					if(null==globalVINParty1 && null==retailerParty1){
						
								globalVINParty1=xCustomerVehicleBObj.getXVehicleBObj().getGlobalVIN();
								retailerParty1=xCustomerVehicleBObj.getRetailerId();
					}
					else if(null!=globalVINParty1 && null!=retailerParty1){
						globalVINParty2=xCustomerVehicleBObj.getXVehicleBObj().getGlobalVIN();
						retailerParty2=xCustomerVehicleBObj.getRetailerId();
					}
					
					if (!xCustomerVehicleMap.containsKey((xCustomerVehicleBObj.getXVehicleBObj().getGlobalVIN())
							+ (xCustomerVehicleBObj.getRetailerId()))) 
					{
						xCustomerVehicleMap.put((xCustomerVehicleBObj.getXVehicleBObj().getGlobalVIN()) + (xCustomerVehicleBObj.getRetailerId()),
								xCustomerVehicleBObj);
						vecXCustomerVehicleBObjsForDiffRetailer.add(xCustomerVehicleBObj);
						if(xCustomerVehicleMap.size()>1 )
						{
							/*  If global VIN + retailer code is not matching that means either different vehicle or 
							 * different retailer is attached to two different parties
							 * Scenario for Different Retailers comes 
							 * * */
							
							if(globalVINParty1.equalsIgnoreCase(globalVINParty2) && !retailerParty1.equalsIgnoreCase(retailerParty2)){
							//System.err.println("xCustomerVehicleMap.size() --> "+xCustomerVehicleMap.size());
							isDifferntRetailer=true;
							
							xCustomerVehicleMap=handleDifferentRetailersAEM(vecXCustomerVehicleBObjsForDiffRetailer,
									xCustomerVehicleMap,allDiffRetailerVehicleRolesToCheckOldestStartDate,OldestStartDatePerRoleMap);
							//xCustomerVehicleMap.clear();
							//xCustomerVehicleMap.putAll(xCustomerVehicleMapAfterDiffRetailerProcessed);
							//System.err.println("xCustomerVehicleMap after -- > "+xCustomerVehicleMap.size());
							}
						}
						
					} else {
						XCustomerVehicleBObj xContVehicleBObjInMap = xCustomerVehicleMap.get((xCustomerVehicleBObj.getXVehicleBObj().getGlobalVIN()) 
								+ (xCustomerVehicleBObj.getRetailerId()));
						requestPersonRetailerCode = xContVehicleBObjInMap.getRetailerId();
						//System.err.println("requestPersonRetailerCode  -- > "+requestPersonRetailerCode);
						existingPersonRetailerCode = xCustomerVehicleBObj.getRetailerId();
						//System.err.println("Party 1 RetailerCode ->> "+requestPersonRetailerCode+" , "+ 
										  // "Party 2 RetailerCode ->> "+existingPersonRetailerCode);
						
						//IF retailer code matches 
						if (requestPersonRetailerCode != null && existingPersonRetailerCode != null && requestPersonRetailerCode
										.equalsIgnoreCase(existingPersonRetailerCode)) 
						{
							//Request last modified date
							Timestamp requestPersonLastModifiedDt = DateFormatter.getTimestamp(xContVehicleBObjInMap.getXCustomerVehicleLastUpdateDate());
							//System.err.println("Party 1 ->> "+ requestPersonLastModifiedDt);
							//DB last modified date
							Timestamp existingPersonLastModifiedDt = DateFormatter.getTimestamp(xCustomerVehicleBObj.getXCustomerVehicleLastUpdateDate());
							//System.err.println("Party 1 LastModifiedDt ->> "+ requestPersonLastModifiedDt
							//+ " ," +"Party 2 LastModifiedDt  ->> "+existingPersonLastModifiedDt);
//							//If request is latest than DB last modified date then put all active roles in final bobj
						
							
							allXCustomerVehicleRoleBObjsToCheckOldestStartDate.addAll(xContVehicleBObjInMap.getItemsXCustomerVehicleRoleBObj());
							allXCustomerVehicleRoleBObjsToCheckOldestStartDate.addAll(xCustomerVehicleBObj.getItemsXCustomerVehicleRoleBObj());
							//System.err.println(allXCustomerVehicleRoleBObjsToCheckOldestStartDate.size());
							OldestStartDatePerRoleMap=setOldestStartdateToActiveRole(allXCustomerVehicleRoleBObjsToCheckOldestStartDate);
							
							if (requestPersonLastModifiedDt.after(existingPersonLastModifiedDt)) {
								// get all the request customer vehicle roles into Vector 
								vecParty1XCustomerVehicleRoleBObjs = xContVehicleBObjInMap.getItemsXCustomerVehicleRoleBObj();
								//System.err.println("vecParty1XCustomerVehicleRoleBObjs.size  -- > "+vecParty1XCustomerVehicleRoleBObjs.size());
								if (vecParty1XCustomerVehicleRoleBObjs != null  && vecParty1XCustomerVehicleRoleBObjs.size() > 0) {
									for (XCustomerVehicleRoleBObj xCustomerVehicleRoleBObj : vecParty1XCustomerVehicleRoleBObjs) {

										
										if (xCustomerVehicleRoleBObj.getEndDate() == null) 
										{
											// put all active roles into final vector 
											if(null!=OldestStartDatePerRoleMap && OldestStartDatePerRoleMap.size()!=0){
											if(xCustomerVehicleRoleBObj.getVehicleRoleType().equalsIgnoreCase(SALES_ROLE_TYPE)){
												xCustomerVehicleRoleBObj.setStartDate((OldestStartDatePerRoleMap.get(SALES_ROLE_TYPE)).toString());
											}else if(xCustomerVehicleRoleBObj.getVehicleRoleType().equalsIgnoreCase(AFTERSALES_ROLE_TYPE)){
												xCustomerVehicleRoleBObj.setStartDate((OldestStartDatePerRoleMap.get(AFTERSALES_ROLE_TYPE)).toString());
											}else if(xCustomerVehicleRoleBObj.getVehicleRoleType().equalsIgnoreCase(DRIVER_ROLE_TYPE)){
												xCustomerVehicleRoleBObj.setStartDate((OldestStartDatePerRoleMap.get(DRIVER_ROLE_TYPE)).toString());
											}	
													vecFinalVehicleRoleBObjs.add(xCustomerVehicleRoleBObj);
											}
										}
									}
								}

								xContVehicleBObjInMap.getItemsXCustomerVehicleRoleBObj().clear();
								xContVehicleBObjInMap.getItemsXCustomerVehicleRoleBObj().addAll(vecFinalVehicleRoleBObjs);
								//System.err.println("vecFinalVehicleRoleBObjs -- >"+vecFinalVehicleRoleBObjs.size());

							}
							//If DB has latest data than Request last modified date then put all active roles in final bobj
							else {
								// get all db customer vehicle roles into vector
								vecParty2XCustomerVehicleRoleBObjs = xCustomerVehicleBObj.getItemsXCustomerVehicleRoleBObj();

								if (vecParty2XCustomerVehicleRoleBObjs != null && vecParty2XCustomerVehicleRoleBObjs.size() > 0) 
								{

									for (XCustomerVehicleRoleBObj xCustomerVehicleRoleBObj : vecParty2XCustomerVehicleRoleBObjs) {
										if (xCustomerVehicleRoleBObj.getEndDate() == null) {
											// put all active roles into final vector 
											//vecFinalVehicleRoleBObjs.add(xCustomerVehicleRoleBObj);
											
											// put all active roles into final vector 
											if(null!=OldestStartDatePerRoleMap && OldestStartDatePerRoleMap.size()!=0){
												if(xCustomerVehicleRoleBObj.getVehicleRoleType().equalsIgnoreCase(SALES_ROLE_TYPE)){
													xCustomerVehicleRoleBObj.setStartDate((OldestStartDatePerRoleMap.get(SALES_ROLE_TYPE)).toString());
												}else if(xCustomerVehicleRoleBObj.getVehicleRoleType().equalsIgnoreCase(AFTERSALES_ROLE_TYPE)){
													xCustomerVehicleRoleBObj.setStartDate((OldestStartDatePerRoleMap.get(AFTERSALES_ROLE_TYPE)).toString());
												}else if(xCustomerVehicleRoleBObj.getVehicleRoleType().equalsIgnoreCase(DRIVER_ROLE_TYPE)){
													xCustomerVehicleRoleBObj.setStartDate((OldestStartDatePerRoleMap.get(DRIVER_ROLE_TYPE)).toString());
												}
													vecFinalVehicleRoleBObjs.add(xCustomerVehicleRoleBObj);
											}
										}

									}

								}
								//System.err.println("******************vecFinalVehicleRoleBObjs.size()-->> "+vecFinalVehicleRoleBObjs.size());

								xCustomerVehicleBObj.getItemsXCustomerVehicleRoleBObj().clear();
								//xCustomerVehicleBObj.getItemsXCustomerVehicleRoleBObj().addAll(vecParty2XCustomerVehicleRoleBObjs);
								xCustomerVehicleBObj.getItemsXCustomerVehicleRoleBObj().addAll(vecFinalVehicleRoleBObjs);

							}
							// xCustomerVehicleBObj: - Final active roles from DB which are latest than Request
							//xContVehicleBObjInMap:- Final Active roles from request which are latest than DB
							
							// Request XCustomerVehicleLastUpdateDate
							Timestamp person1ModifiedDt = DateFormatter.getTimestamp(xContVehicleBObjInMap.getXCustomerVehicleLastUpdateDate());
							// DB XCustomerVehicleLastUpdateDate
							//System.err.println("person1ModifiedDt --->>> "+person1ModifiedDt);
							Timestamp person2ModifiedDt = DateFormatter.getTimestamp(xCustomerVehicleBObj.getXCustomerVehicleLastUpdateDate());
							//System.err.println("person2ModifiedDt --->>> "+person2ModifiedDt);
							if (person1ModifiedDt.after(person2ModifiedDt)) {

								xCustomerVehicleMap.put((xContVehicleBObjInMap.getXVehicleBObj().getGlobalVIN()) 
										+ (xContVehicleBObjInMap.getRetailerId()),xContVehicleBObjInMap);
							}

							else {

								xCustomerVehicleMap.put((xCustomerVehicleBObj
										.getXVehicleBObj().getGlobalVIN()) + (xCustomerVehicleBObj.getRetailerId()),
										xCustomerVehicleBObj);
							}

						} 
						// for different retailers 
						else {
							
							
							xCustomerVehicleMap.put((xCustomerVehicleBObj.getXVehicleBObj().getGlobalVIN()) + 
									(xCustomerVehicleBObj.getRetailerId()),xCustomerVehicleBObj);	
							
						}

					}

				}
			}
		}
		

		
		for (Map.Entry<String, XCustomerVehicleBObj> entry : xCustomerVehicleMap.entrySet()) {
			XCustomerVehicleBObj tempXCustomerVehicleBObj = entry.getValue();
			XCustomerVehicleBObj survivedXCustomerVehicleBObj = new XCustomerVehicleBObj();
			survivedXCustomerVehicleBObj = tempXCustomerVehicleBObj;
			survivedXCustomerVehicleBObj.setContId(collapsedPartyId);
			survivedXCustomerVehicleBObj.setControl(control);
			globalVIN = survivedXCustomerVehicleBObj.getXVehicleBObj().getGlobalVIN();
			vecDBVehicleBObj = vehicleObjectByGVIN(globalVIN, control);
			if (vecDBVehicleBObj == null || vecDBVehicleBObj.isEmpty()) {
				response = dseaAdditionsExtsComponent.addXCustomerVehicle(survivedXCustomerVehicleBObj);
			} else {
				survivedXCustomerVehicleBObj.getXVehicleBObj().setVehiclepkId(vecDBVehicleBObj.get(0).getVehiclepkId());
				survivedXCustomerVehicleBObj.getXVehicleBObj().setXVehicleLastUpdateDate(vecDBVehicleBObj.get(0).getXVehicleLastUpdateDate());
				survivedXCustomerVehicleBObj.setVehicleId(vecDBVehicleBObj.get(0).getVehiclepkId());
				System.err.println("Final relationship count ->>  "+xCustomerVehicleMap.size()+", "+
				"Survived XCustomerVehicleRoleBObj Count ->> "+survivedXCustomerVehicleBObj.getItemsXCustomerVehicleRoleBObj().size());
				response = dseaAdditionsExtsComponent.addXCustomerVehicle(survivedXCustomerVehicleBObj);
			}
			if (response.getStatus().getStatus() == DWLStatus.FATAL) {
				throw new BusinessProxyException();
			}
		}
	}
	
	
	
	private HashMap<String, XCustomerVehicleBObj> handleDifferentRetailers(
			Vector<XCustomerVehicleBObj> vecXCustomerVehicleBObjs, // XCustomerVehicleRoles entries for 2 suspect parties
			HashMap<String, XCustomerVehicleBObj> xCustomerVehicleMap, // input combination of global VIN + retailer code
			Vector<XCustomerVehicleRoleBObj> allDiffRetailerVehicleRolesToCheckOldestStartDate, // blank
			HashMap<String, Timestamp> oldestStartDatePerRoleMap2) throws Exception {
		// TODO Auto-generated method stub
		allDiffRetailerVehicleRolesToCheckOldestStartDate= new Vector<XCustomerVehicleRoleBObj>();
		Vector<XCustomerVehicleRoleBObj> vecFinalVehicleRoleBObjForDiffRetailers = new Vector<XCustomerVehicleRoleBObj>();
		XCustomerVehicleBObj xCustomerVehicleBObj=null;
		Vector<XCustomerVehicleRoleBObj> allXCustomerVehicleRoleBObjs = new Vector<XCustomerVehicleRoleBObj>();
		//HashMap<String, Timestamp> OldestStartDatePerRoleMap= new HashMap<String, Timestamp>();

		//System.err.println("vecXCustomerVehicleBObjs.size() -- >" + vecXCustomerVehicleBObjs.size());
		int xCustomerVehicleMapSize=xCustomerVehicleMap.size();
		for (int j=0; j<vecXCustomerVehicleBObjs.size(); j++){
		
			xCustomerVehicleBObj=vecXCustomerVehicleBObjs.get(j);
			
//			XCustomerVehicleBObj xContVehicleBObjInMap = xCustomerVehicleMap.get((xCustomerVehicleBObj.getXVehicleBObj().getGlobalVIN()) 
//				+ (xCustomerVehicleBObj.getRetailerId()));
				
			//System.err.println("xCustomerVehicleBObj retailer code-- >"+xCustomerVehicleBObj.getRetailerId());
		allDiffRetailerVehicleRolesToCheckOldestStartDate.addAll(xCustomerVehicleBObj.getItemsXCustomerVehicleRoleBObj());
		}
		oldestStartDatePerRoleMap2=setOldestStartdateToActiveRole(allDiffRetailerVehicleRolesToCheckOldestStartDate);
		
		
		//allDiffRetailerVehicleRolesToCheckOldestStartDate = xContVehicleBObjInMap.getItemsXCustomerVehicleRoleBObj();
		for (int k=0; k<vecXCustomerVehicleBObjs.size(); k++){
			xCustomerVehicleBObj=vecXCustomerVehicleBObjs.get(k);
			vecFinalVehicleRoleBObjForDiffRetailers.removeAllElements();
			allXCustomerVehicleRoleBObjs=xCustomerVehicleBObj.getItemsXCustomerVehicleRoleBObj();
		//System.err.println("allXCustomerVehicleRoleBObjs.size  -- > "+allXCustomerVehicleRoleBObjs.size());
		if (allXCustomerVehicleRoleBObjs != null  && allXCustomerVehicleRoleBObjs.size() > 0) {
			for (XCustomerVehicleRoleBObj xCustomerVehicleRoleBObj : allXCustomerVehicleRoleBObjs) {

								// put all active +inactive roles into final vector 
				
				try {
					if(null!=oldestStartDatePerRoleMap2 && oldestStartDatePerRoleMap2.size()!=0)
					{
					if(xCustomerVehicleRoleBObj.getVehicleRoleType().equalsIgnoreCase(SALES_ROLE_TYPE)){
						xCustomerVehicleRoleBObj.setStartDate((oldestStartDatePerRoleMap2.get(SALES_ROLE_TYPE)).toString());
						xCustomerVehicleRoleBObj.setEndDate(null);
					}else if(xCustomerVehicleRoleBObj.getVehicleRoleType().equalsIgnoreCase(AFTERSALES_ROLE_TYPE)){
						xCustomerVehicleRoleBObj.setStartDate((oldestStartDatePerRoleMap2.get(AFTERSALES_ROLE_TYPE)).toString());
					}else if(xCustomerVehicleRoleBObj.getVehicleRoleType().equalsIgnoreCase(DRIVER_ROLE_TYPE)){
						xCustomerVehicleRoleBObj.setStartDate((oldestStartDatePerRoleMap2.get(DRIVER_ROLE_TYPE)).toString());
					}	
					}
					vecFinalVehicleRoleBObjForDiffRetailers.add(xCustomerVehicleRoleBObj);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
							
			}		}
		
		xCustomerVehicleBObj.getItemsXCustomerVehicleRoleBObj().clear();
		xCustomerVehicleBObj.getItemsXCustomerVehicleRoleBObj().addAll(vecFinalVehicleRoleBObjForDiffRetailers);
		
		//System.err.println("xCustomerVehicleMap before and retailer code -- > "+xCustomerVehicleMap.size()+" - "+xCustomerVehicleBObj.getRetailerId());
		xCustomerVehicleMap.put((xCustomerVehicleBObj.getXVehicleBObj().getGlobalVIN()) + 
				(xCustomerVehicleBObj.getRetailerId()),xCustomerVehicleBObj);
		//System.err.println("xCustomerVehicleMap after -- > "+xCustomerVehicleMap.size()+" - "+xCustomerVehicleBObj.getRetailerId());
		}
	
		
		return xCustomerVehicleMap;	
	}

	//Amruta Gandhi:  GET THE OLDEST START DATE OUT OF ALL THE SURVIVED -- START 
	private HashMap<String, Timestamp> setOldestStartdateToActiveRole(
			Vector<XCustomerVehicleRoleBObj> allXCustomerVehicleRoleBObjsToCheckOldestStartDate)throws Exception {
		// TODO Auto-generated method stub
		
		Timestamp salesRoleSameReatilerOldestStartDate=null;
		Timestamp afterSalesRoleSameReatilerOldestStartDate=null;
		Timestamp driverRoleSameReatilerOldestStartDate=null;
		Timestamp tempOldestStartDate=null;
		HashMap<String, Timestamp> OldestStartDatePerRoleMap= new HashMap<String, Timestamp>();
		
		if (allXCustomerVehicleRoleBObjsToCheckOldestStartDate != null  && allXCustomerVehicleRoleBObjsToCheckOldestStartDate.size() > 0) {
			for (XCustomerVehicleRoleBObj xCustomerVehicleRoleBObj : allXCustomerVehicleRoleBObjsToCheckOldestStartDate) {

		if(null!=xCustomerVehicleRoleBObj.getStartDate())
		{
			
	
			if(xCustomerVehicleRoleBObj.getVehicleRoleType().equalsIgnoreCase(SALES_ROLE_TYPE)){
				tempOldestStartDate=null;
				tempOldestStartDate=DateFormatter.getTimestamp(xCustomerVehicleRoleBObj.getStartDate());
				if(null!=salesRoleSameReatilerOldestStartDate ){
					if(tempOldestStartDate.before(salesRoleSameReatilerOldestStartDate))
					{
						salesRoleSameReatilerOldestStartDate=tempOldestStartDate;
					}
				}
				else {
					salesRoleSameReatilerOldestStartDate=tempOldestStartDate;
				}
				
			}else if(xCustomerVehicleRoleBObj.getVehicleRoleType().equalsIgnoreCase(AFTERSALES_ROLE_TYPE)){
				tempOldestStartDate=null;
				tempOldestStartDate=DateFormatter.getTimestamp(xCustomerVehicleRoleBObj.getStartDate());
				if(null!=afterSalesRoleSameReatilerOldestStartDate ){
					if(tempOldestStartDate.before(afterSalesRoleSameReatilerOldestStartDate))
					{
						afterSalesRoleSameReatilerOldestStartDate=tempOldestStartDate;
					}
				}
				else {
					afterSalesRoleSameReatilerOldestStartDate=tempOldestStartDate;
				}
				
			}else if(xCustomerVehicleRoleBObj.getVehicleRoleType().equalsIgnoreCase(DRIVER_ROLE_TYPE)){
				tempOldestStartDate=null;
				tempOldestStartDate=DateFormatter.getTimestamp(xCustomerVehicleRoleBObj.getStartDate());
				if(null!=driverRoleSameReatilerOldestStartDate ){
					if(tempOldestStartDate.before(driverRoleSameReatilerOldestStartDate))
					{
						driverRoleSameReatilerOldestStartDate=tempOldestStartDate;
					}
				}
				else {
					driverRoleSameReatilerOldestStartDate=tempOldestStartDate;
				}
			}
		}
		else{
			 tempOldestStartDate=null;
		}
			}
		}
		if(null!=salesRoleSameReatilerOldestStartDate)
		{
			tempOldestStartDate= salesRoleSameReatilerOldestStartDate;
			OldestStartDatePerRoleMap.put(SALES_ROLE_TYPE, salesRoleSameReatilerOldestStartDate);
		}
		if(null!=afterSalesRoleSameReatilerOldestStartDate)
		{
			tempOldestStartDate= afterSalesRoleSameReatilerOldestStartDate;
			OldestStartDatePerRoleMap.put(AFTERSALES_ROLE_TYPE, afterSalesRoleSameReatilerOldestStartDate);
		}
		if(null!=driverRoleSameReatilerOldestStartDate)
		{
			tempOldestStartDate= driverRoleSameReatilerOldestStartDate;
			OldestStartDatePerRoleMap.put(DRIVER_ROLE_TYPE, driverRoleSameReatilerOldestStartDate);
		}
		
		System.err.println("OldestStartDatePerRoleMap-->> "+OldestStartDatePerRoleMap.size());
		return OldestStartDatePerRoleMap;
	}//Amruta Gandhi:  GET THE OLDEST START DATE OUT OF ALL THE SURVIVED -- END 
	
	//AMRUTA GANDHI:  VR AFTER MERGE CODE FOR CLUSTER2 ****** END 
	
	
	private HashMap<String, XCustomerVehicleBObj> handleDifferentRetailersAEM(
			Vector<XCustomerVehicleBObj> vecXCustomerVehicleBObjs, // XCustomerVehicleRoles entries for 2 suspect parties
			HashMap<String, XCustomerVehicleBObj> xCustomerVehicleMap, // input combination of global VIN + retailer code
			Vector<XCustomerVehicleRoleBObj> allDiffRetailerVehicleRolesToCheckOldestStartDate, // blank
			HashMap<String, Timestamp> oldestStartDatePerRoleMap2) throws Exception {
		// TODO Auto-generated method stub
		allDiffRetailerVehicleRolesToCheckOldestStartDate= new Vector<XCustomerVehicleRoleBObj>();
		Vector<XCustomerVehicleRoleBObj> vecFinalVehicleRoleBObjForDiffRetailers = new Vector<XCustomerVehicleRoleBObj>();
		XCustomerVehicleBObj xCustomerVehicleBObj=null;
		Vector<XCustomerVehicleRoleBObj> allXCustomerVehicleRoleBObjs = new Vector<XCustomerVehicleRoleBObj>();
		//HashMap<String, Timestamp> OldestStartDatePerRoleMap= new HashMap<String, Timestamp>();

		//System.err.println("vecXCustomerVehicleBObjs.size() -- >" + vecXCustomerVehicleBObjs.size());
		int xCustomerVehicleMapSize=xCustomerVehicleMap.size();
		for (int j=0; j<vecXCustomerVehicleBObjs.size(); j++){
		
			xCustomerVehicleBObj=vecXCustomerVehicleBObjs.get(j);
			
//			XCustomerVehicleBObj xContVehicleBObjInMap = xCustomerVehicleMap.get((xCustomerVehicleBObj.getXVehicleBObj().getGlobalVIN()) 
//				+ (xCustomerVehicleBObj.getRetailerId()));
				
			//System.err.println("xCustomerVehicleBObj retailer code-- >"+xCustomerVehicleBObj.getRetailerId());
		allDiffRetailerVehicleRolesToCheckOldestStartDate.addAll(xCustomerVehicleBObj.getItemsXCustomerVehicleRoleBObj());
		}
		oldestStartDatePerRoleMap2=setOldestStartdateToActiveRole(allDiffRetailerVehicleRolesToCheckOldestStartDate);
		
		
		//allDiffRetailerVehicleRolesToCheckOldestStartDate = xContVehicleBObjInMap.getItemsXCustomerVehicleRoleBObj();
		for (int k=0; k<vecXCustomerVehicleBObjs.size(); k++){
			xCustomerVehicleBObj=vecXCustomerVehicleBObjs.get(k);
			vecFinalVehicleRoleBObjForDiffRetailers.removeAllElements();
			allXCustomerVehicleRoleBObjs=xCustomerVehicleBObj.getItemsXCustomerVehicleRoleBObj();
		//System.err.println("allXCustomerVehicleRoleBObjs.size  -- > "+allXCustomerVehicleRoleBObjs.size());
		if (allXCustomerVehicleRoleBObjs != null  && allXCustomerVehicleRoleBObjs.size() > 0) {
			for (XCustomerVehicleRoleBObj xCustomerVehicleRoleBObj : allXCustomerVehicleRoleBObjs) {

								// put all active +inactive roles into final vector 
				
				try {
					if(null!=oldestStartDatePerRoleMap2 && oldestStartDatePerRoleMap2.size()!=0)
					{
					if(xCustomerVehicleRoleBObj.getVehicleRoleType().equalsIgnoreCase(SALES_ROLE_TYPE)){
						xCustomerVehicleRoleBObj.setStartDate((oldestStartDatePerRoleMap2.get(SALES_ROLE_TYPE)).toString());
						xCustomerVehicleRoleBObj.setEndDate(null);
					}else if(xCustomerVehicleRoleBObj.getVehicleRoleType().equalsIgnoreCase(AFTERSALES_ROLE_TYPE)){
						xCustomerVehicleRoleBObj.setStartDate((oldestStartDatePerRoleMap2.get(AFTERSALES_ROLE_TYPE)).toString());
					}else if(xCustomerVehicleRoleBObj.getVehicleRoleType().equalsIgnoreCase(DRIVER_ROLE_TYPE)){
						xCustomerVehicleRoleBObj.setStartDate((oldestStartDatePerRoleMap2.get(DRIVER_ROLE_TYPE)).toString());
					}	
					}
					vecFinalVehicleRoleBObjForDiffRetailers.add(xCustomerVehicleRoleBObj);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
							
			}		}
		
		xCustomerVehicleBObj.getItemsXCustomerVehicleRoleBObj().clear();
		xCustomerVehicleBObj.getItemsXCustomerVehicleRoleBObj().addAll(vecFinalVehicleRoleBObjForDiffRetailers);
		
		//System.err.println("xCustomerVehicleMap before and retailer code -- > "+xCustomerVehicleMap.size()+" - "+xCustomerVehicleBObj.getRetailerId());
		xCustomerVehicleMap.put((xCustomerVehicleBObj.getXVehicleBObj().getGlobalVIN()) + 
				(xCustomerVehicleBObj.getRetailerId()),xCustomerVehicleBObj);
		//System.err.println("xCustomerVehicleMap after -- > "+xCustomerVehicleMap.size()+" - "+xCustomerVehicleBObj.getRetailerId());
		}
	
		return xCustomerVehicleMap;	
	}
	public int charDiffBr(String source, String suspect) throws Exception 
	{
	 
	
	    int min = 0;
	    int count = 0;
		if (source.length() < suspect.length())
			
			 min = source.length();
		else 
			 min = suspect.length();
		
		for (int i = 0 ;  i < min ; i++)
		{
			if (source.charAt(i) != suspect.charAt(i))
				
				count ++;	
		}
		 
		return count;
	}
	//  GET THE OLDEST START DATE OUT OF ALL THE SURVIVED -- START 
	private HashMap<String, Timestamp> setOldestStartdateToActiveRoleAEM(
			Vector<XCustomerVehicleRoleBObj> allXCustomerVehicleRoleBObjsToCheckOldestStartDate)throws Exception {
		// TODO Auto-generated method stub
		
		Timestamp salesRoleSameReatilerOldestStartDate=null;
		Timestamp afterSalesRoleSameReatilerOldestStartDate=null;
		Timestamp driverRoleSameReatilerOldestStartDate=null;
		Timestamp tempOldestStartDate=null;
		HashMap<String, Timestamp> OldestStartDatePerRoleMap= new HashMap<String, Timestamp>();
		
		if (allXCustomerVehicleRoleBObjsToCheckOldestStartDate != null  && allXCustomerVehicleRoleBObjsToCheckOldestStartDate.size() > 0) {
			for (XCustomerVehicleRoleBObj xCustomerVehicleRoleBObj : allXCustomerVehicleRoleBObjsToCheckOldestStartDate) {

		if(null!=xCustomerVehicleRoleBObj.getStartDate())
		{
			
	
			if(xCustomerVehicleRoleBObj.getVehicleRoleType().equalsIgnoreCase(SALES_ROLE_TYPE)){
				tempOldestStartDate=null;
				tempOldestStartDate=DateFormatter.getTimestamp(xCustomerVehicleRoleBObj.getStartDate());
				if(null!=salesRoleSameReatilerOldestStartDate ){
					if(tempOldestStartDate.before(salesRoleSameReatilerOldestStartDate))
					{
						salesRoleSameReatilerOldestStartDate=tempOldestStartDate;
					}
				}
				else {
					salesRoleSameReatilerOldestStartDate=tempOldestStartDate;
				}
				
			}else if(xCustomerVehicleRoleBObj.getVehicleRoleType().equalsIgnoreCase(AFTERSALES_ROLE_TYPE)){
				tempOldestStartDate=null;
				tempOldestStartDate=DateFormatter.getTimestamp(xCustomerVehicleRoleBObj.getStartDate());
				if(null!=afterSalesRoleSameReatilerOldestStartDate ){
					if(tempOldestStartDate.before(afterSalesRoleSameReatilerOldestStartDate))
					{
						afterSalesRoleSameReatilerOldestStartDate=tempOldestStartDate;
					}
				}
				else {
					afterSalesRoleSameReatilerOldestStartDate=tempOldestStartDate;
				}
				
			}else if(xCustomerVehicleRoleBObj.getVehicleRoleType().equalsIgnoreCase(DRIVER_ROLE_TYPE)){
				tempOldestStartDate=null;
				tempOldestStartDate=DateFormatter.getTimestamp(xCustomerVehicleRoleBObj.getStartDate());
				if(null!=driverRoleSameReatilerOldestStartDate ){
					if(tempOldestStartDate.before(driverRoleSameReatilerOldestStartDate))
					{
						driverRoleSameReatilerOldestStartDate=tempOldestStartDate;
					}
				}
				else {
					driverRoleSameReatilerOldestStartDate=tempOldestStartDate;
				}
			}
		}
		else{
			 tempOldestStartDate=null;
		}
			}
		}
		if(null!=salesRoleSameReatilerOldestStartDate)
		{
			tempOldestStartDate= salesRoleSameReatilerOldestStartDate;
			OldestStartDatePerRoleMap.put(SALES_ROLE_TYPE, salesRoleSameReatilerOldestStartDate);
		}
		if(null!=afterSalesRoleSameReatilerOldestStartDate)
		{
			tempOldestStartDate= afterSalesRoleSameReatilerOldestStartDate;
			OldestStartDatePerRoleMap.put(AFTERSALES_ROLE_TYPE, afterSalesRoleSameReatilerOldestStartDate);
		}
		if(null!=driverRoleSameReatilerOldestStartDate)
		{
			tempOldestStartDate= driverRoleSameReatilerOldestStartDate;
			OldestStartDatePerRoleMap.put(DRIVER_ROLE_TYPE, driverRoleSameReatilerOldestStartDate);
		}
		
		System.err.println("OldestStartDatePerRoleMap-->> "+OldestStartDatePerRoleMap.size());
		return OldestStartDatePerRoleMap;
	}

	public void survivedCRRDetailsZA(Vector<TCRMPartyBObj> vecParties,
			TCRMPartyBObj collapsedPartyBObj, String marketName, DWLControl control) throws Exception {
		HashMap<String, XCustomerRetailerBObj> xCustomerRetailerMap = new HashMap<String, XCustomerRetailerBObj>();
		Vector<XCustomerRetailerBObj> vecXCustomerRetailerBObjs = new Vector<XCustomerRetailerBObj>();
		DWLResponse dwlResponse = new DWLResponse();
		DWLResponse response = null;
		//DWLResponse retailer_response = null;
		DSEAAdditionsExtsComponent dseaAdditionsExtsComponent = new DSEAAdditionsExtsComponent();
		String partytId = null;
		String retailerCode = null;
		XRetailerBObj DBRetailerBObj = null;
		String collapsedPartyId = collapsedPartyBObj.getPartyId();

		for (TCRMPartyBObj partyBObj : vecParties) {
			partytId = partyBObj.getPartyId();
			dwlResponse = dseaAdditionsExtsComponent.getAllXCustomerRetailerByPartyId(partytId, control);
			if (dwlResponse.getData() != null) {
				vecXCustomerRetailerBObjs = (Vector<XCustomerRetailerBObj>) dwlResponse
						.getData();
			}
			for (int j = 0; j < vecXCustomerRetailerBObjs.size(); j++) {
				XCustomerRetailerBObj xCustomerRetailerBObj = (XCustomerRetailerBObj) vecXCustomerRetailerBObjs
						.get(j);
				if (!xCustomerRetailerMap.containsKey(xCustomerRetailerBObj
						.getXRetailerBObj().getRetailerCode())) {
					xCustomerRetailerMap.put(xCustomerRetailerBObj
							.getXRetailerBObj().getRetailerCode(),
							xCustomerRetailerBObj);
				} else {
					XCustomerRetailerBObj xContretailerBObjInMap = xCustomerRetailerMap
							.get(xCustomerRetailerBObj.getXRetailerBObj()
									.getRetailerCode());
					Timestamp requestPersonLastModifiedDt = DateFormatter
							.getTimestamp(xContretailerBObjInMap
									.getXRetailerBObj()
									.getLastModifiedSystemDate());
					Timestamp existingPersonLastModifiedDt = DateFormatter
							.getTimestamp(xCustomerRetailerBObj
									.getXRetailerBObj()
									.getLastModifiedSystemDate());
					if (requestPersonLastModifiedDt.after(existingPersonLastModifiedDt)) {
						xCustomerRetailerMap.put(xContretailerBObjInMap
								.getXRetailerBObj().getRetailerCode(),
								xContretailerBObjInMap);
					} else {
						xCustomerRetailerMap.put(xCustomerRetailerBObj
								.getXRetailerBObj().getRetailerCode(),
								xCustomerRetailerBObj);
					}

				}

			}
		}

		for (Map.Entry<String, XCustomerRetailerBObj> entry : xCustomerRetailerMap
				.entrySet()) {
			XCustomerRetailerBObj tempXCustomerRetailerBObj = entry.getValue();
			XCustomerRetailerBObj survivedXCustomerRetailerBObj = new XCustomerRetailerBObj();
			survivedXCustomerRetailerBObj = tempXCustomerRetailerBObj;
			survivedXCustomerRetailerBObj.setContId(collapsedPartyId);
			survivedXCustomerRetailerBObj.setControl(control);
			retailerCode = survivedXCustomerRetailerBObj.getXRetailerBObj()
					.getRetailerCode();
			DWLResponse retailer_response = dseaAdditionsExtsComponent.getXRetailerByRetailerCodeAndMarketName(retailerCode, marketName, control);
			DBRetailerBObj = (XRetailerBObj) retailer_response.getData();
			survivedXCustomerRetailerBObj.setXRetailerBObj(null);
			survivedXCustomerRetailerBObj.setRetailerId(DBRetailerBObj.getRetailerpkId());
			survivedXCustomerRetailerBObj.setObjectReferenceId(marketName);
				response = dseaAdditionsExtsComponent
						.addXCustomerRetailer(survivedXCustomerRetailerBObj);
				if (response.getStatus().getStatus() == DWLStatus.FATAL) {
					throw new BusinessProxyException();
				}

			}
		}
	
	public void surviveConsentDetailsForZA(Vector<TCRMPartyBObj> vecParties, TCRMPartyBObj collapsedPartyBObj, DWLControl control) throws Exception {

        HashMap<String,XConsentBObj> XConsentDetailsMap = new HashMap<String, XConsentBObj>();
        Vector<XConsentBObj> vecXConsentBObjs = new Vector<XConsentBObj>();
        DWLResponse dwlResponse = new DWLResponse();
        DWLResponse response = null;
        DSEAAdditionsExtsComponent dseaAdditionsExtsComponent = new DSEAAdditionsExtsComponent();
        String partytId = null;
        String collapsedPartyId = collapsedPartyBObj.getPartyId();
        for(TCRMPartyBObj partyBObj : vecParties)
        {
              partytId = partyBObj.getPartyId();
              dwlResponse = dseaAdditionsExtsComponent.getXConsentByContId(partytId, control);
              Vector<XConsentBObj> vecXConsent = (Vector<XConsentBObj>) dwlResponse.getData();
              
              if(null!= vecXConsent && vecXConsent.size()>0)
              {
                    for(XConsentBObj consentBObj : vecXConsent)
                    {
                          String reatilerFlag = consentBObj.getRetailerFlag();
                          String retailerId = consentBObj.getRetailerId();
                          String communicationChannel = consentBObj.getCommunicationChannel();
                          String requestSourceType = consentBObj.getSourceIdentifierType();
                          if(ExternalRuleConstant.CONSENT_RETAILER_FLAG_N.equalsIgnoreCase(reatilerFlag))
                          {
                                String mapKey = communicationChannel;
                                if(!XConsentDetailsMap.containsKey(mapKey))
                                {
                                      XConsentDetailsMap.put(mapKey, consentBObj);
                                }
                                else
                                {
                                      XConsentBObj XConsentDetailsinMap = XConsentDetailsMap.get(mapKey);
                                      String existingSourceType = XConsentDetailsinMap.getSourceIdentifierType();
                                      String requestSourcePriority = getSOurcePriorityForConsentZA(requestSourceType);
                                      String existingSourcePriority = getSOurcePriorityForConsentZA(existingSourceType);
                                      
                                      String requestConsentActionValue = consentBObj.getConsentActionValue();
                                      String existingConsentActionValue = XConsentDetailsinMap.getConsentActionValue();

                                      Timestamp requestConsentLastModifiedDt = DateFormatter
                                                  .getTimestamp(consentBObj.getLastModifiedSystemDate());
                                      
                                      Timestamp existingConsentLastModifiedDt = DateFormatter
                                                  .getTimestamp(XConsentDetailsinMap.getLastModifiedSystemDate());
                                      if(requestSourceType.equalsIgnoreCase(existingSourceType))
                                      {
                                            if (requestConsentLastModifiedDt.after(existingConsentLastModifiedDt))
                                            {
                                                  XConsentDetailsMap.put(mapKey, consentBObj);
                                            }
                                            else
                                                  XConsentDetailsMap.put(mapKey, XConsentDetailsinMap);
                                      }
                                      else
                                      {
                                            if(requestSourcePriority.equalsIgnoreCase(existingSourcePriority))
                                            {
                                                  if(("NONE".equals(requestConsentActionValue) && "NONE".equals(existingConsentActionValue))
                                                        || (!"NONE".equals(requestConsentActionValue) && !"NONE".equals(existingConsentActionValue))){
                                                  
                                                        if (requestConsentLastModifiedDt.after(existingConsentLastModifiedDt))
                                                        {
                                                              XConsentDetailsMap.put(mapKey, consentBObj);
                                                        }
                                                        else
                                                              XConsentDetailsMap.put(mapKey, XConsentDetailsinMap);
                                                        
                                                  }else if (("NONE".equals(requestConsentActionValue) && SOURCE_IDENTIFIER_TYPE_SFDC.equals(requestSourceType))
                                                              || ("NONE".equals(existingConsentActionValue) && SOURCE_IDENTIFIER_TYPE_SFDC.equals(existingSourceType))){
                                                                    
                                                              if (requestConsentLastModifiedDt.after(existingConsentLastModifiedDt))
                                                              {
                                                                    XConsentDetailsMap.put(mapKey, consentBObj);
                                                              }
                                                              else
                                                                    XConsentDetailsMap.put(mapKey, XConsentDetailsinMap);
                                                  }else if (("NONE".equals(requestConsentActionValue) && SOURCE_IDENTIFIER_TYPE_TDS.equals(requestSourceType))
                                                              || ("NONE".equals(requestConsentActionValue) && SOURCE_IDENTIFIER_TYPE_CBU.equals(requestSourceType))){
                                                              
                                                                    XConsentDetailsMap.put(mapKey, XConsentDetailsinMap);
                                                                    
                                                  }else if (("NONE".equals(existingConsentActionValue) && SOURCE_IDENTIFIER_TYPE_TDS.equals(existingSourceType))
                                                              || ("NONE".equals(existingConsentActionValue) && SOURCE_IDENTIFIER_TYPE_CBU.equals(existingSourceType))){
                                                        
                                                        XConsentDetailsMap.put(mapKey, consentBObj);
                                                        
                                                  }else{
                                                        if (requestConsentLastModifiedDt.after(existingConsentLastModifiedDt))
                                                        {
                                                              XConsentDetailsMap.put(mapKey, consentBObj);
                                                        }
                                                        else
                                                              XConsentDetailsMap.put(mapKey, XConsentDetailsinMap);
                                                  }
                                                  
                                            }
                                            else
                                            {
                                                  if(Integer.parseInt(requestSourcePriority) > Integer.parseInt(existingSourcePriority))
                                                  {
                                                        XConsentDetailsMap.put(mapKey, consentBObj);
                                                  }
                                                  else
                                                        XConsentDetailsMap.put(mapKey, XConsentDetailsinMap);
                                            }
                                      }
                                }
                          }
                          else if(ExternalRuleConstant.CONSENT_RETAILER_FLAG_Y.equalsIgnoreCase(reatilerFlag))
                          {
                                String mapKey = communicationChannel + retailerId;
                                if(!XConsentDetailsMap.containsKey(mapKey))
                                {
                                      XConsentDetailsMap.put(mapKey, consentBObj);
                                }
                                else
                                {
                                      XConsentBObj XConsentDetailsinMap = XConsentDetailsMap.get(mapKey);
                                      String existingSourceType = XConsentDetailsinMap.getSourceIdentifierType();
                                      String requestSourcePriority = getSOurcePriorityForConsent(requestSourceType);
                                      String existingSourcePriority = getSOurcePriorityForConsent(existingSourceType);
                                      
                                      Timestamp requestConsentLastModifiedDt = DateFormatter
                                                  .getTimestamp(consentBObj.getLastModifiedSystemDate());
                                      
                                      Timestamp existingConsentLastModifiedDt = DateFormatter
                                                  .getTimestamp(XConsentDetailsinMap.getLastModifiedSystemDate());
                                      if(requestSourceType.equalsIgnoreCase(existingSourceType))
                                      {
                                            if (requestConsentLastModifiedDt.after(existingConsentLastModifiedDt))
                                            {
                                                  XConsentDetailsMap.put(mapKey, consentBObj);
                                            }
                                            else
                                                  XConsentDetailsMap.put(mapKey, XConsentDetailsinMap);
                                      }
                                      else
                                      {
                                            if(requestSourcePriority.equalsIgnoreCase(existingSourcePriority))
                                            {
                                                  if (requestConsentLastModifiedDt.after(existingConsentLastModifiedDt))
                                                  {
                                                        XConsentDetailsMap.put(mapKey, consentBObj);
                                                  }
                                                  else
                                                        XConsentDetailsMap.put(mapKey, XConsentDetailsinMap);
                                            }
                                            else
                                            {
                                                  if(Integer.parseInt(requestSourcePriority) > Integer.parseInt(existingSourcePriority))
                                                  {
                                                        XConsentDetailsMap.put(mapKey, consentBObj);
                                                  }
                                                  else
                                                        XConsentDetailsMap.put(mapKey, XConsentDetailsinMap);
                                            }
                                      }
                                }
                          }
                          
                    }
              }
              
        }
        
        Timestamp latestLastModifiedDate = null;
        int count = 0;
        for(Map.Entry<String, XConsentBObj> entry : XConsentDetailsMap.entrySet()){
              XConsentBObj tempXConsentBObj = entry.getValue();
              Timestamp existingConsentLastModifiedDt = null;
              count++;
              
              if(count==1){
                    latestLastModifiedDate = DateFormatter.getTimestamp(tempXConsentBObj.getLastModifiedSystemDate());
              }else{
                    existingConsentLastModifiedDt = DateFormatter.getTimestamp(tempXConsentBObj.getLastModifiedSystemDate());
                    if(existingConsentLastModifiedDt.after(latestLastModifiedDate)){
                          latestLastModifiedDate = existingConsentLastModifiedDt;
                    }
              }
              
              
        }
        for(Map.Entry<String, XConsentBObj> entry : XConsentDetailsMap.entrySet())
        {
              XConsentBObj tempXConsentBObj = entry.getValue();
              XConsentBObj survivedXConsentBObj = new XConsentBObj();
              
              tempXConsentBObj.setLastModifiedSystemDate(latestLastModifiedDate.toString());
              addNewConsentforSurvivedParty(control,collapsedPartyId,tempXConsentBObj,dseaAdditionsExtsComponent);
              
        }
  
        
        
        
  }
	
	
	
	public void survivedCVRDetailsZA(Vector<TCRMPartyBObj> vecParties,TCRMPartyBObj collapsedPartyBObj, DWLControl control)
			throws Exception {
		HashMap<String, XCustomerVehicleBObj> xCustomerVehicleMap = new HashMap<String, XCustomerVehicleBObj>();
		HashMap<String, XCustomerVehicleBObj> xCustomerVehicleMapAfterDiffRetailerProcessed = new HashMap<String, XCustomerVehicleBObj>();		
		Vector<XCustomerVehicleBObj> vecXCustomerVehicleBObjs = new Vector<XCustomerVehicleBObj>();
		Vector<XCustomerVehicleBObj> vecXCustomerVehicleBObjsForDiffRetailer = new Vector<XCustomerVehicleBObj>();
		DWLResponse dwlResponse = new DWLResponse();
		DWLResponse response = null;
		DSEAAdditionsExtsComponent dseaAdditionsExtsComponent = new DSEAAdditionsExtsComponent();
		String partytId = null;
		String globalVIN = null;
		String requestPersonRetailerCode = null;
		String existingPersonRetailerCode = null;
		Vector<XVehicleBObj> vecDBVehicleBObj = null;
		String collapsedPartyId = collapsedPartyBObj.getPartyId();
		Vector<XCustomerVehicleRoleBObj> vecParty1XCustomerVehicleRoleBObjs = new Vector<XCustomerVehicleRoleBObj>();
		Vector<XCustomerVehicleRoleBObj> allDiffRetailerVehicleRolesToCheckOldestStartDate = new Vector<XCustomerVehicleRoleBObj>();
		Vector<XCustomerVehicleRoleBObj> allXCustomerVehicleRoleBObjsToCheckOldestStartDate = new Vector<XCustomerVehicleRoleBObj>();
		Vector<XCustomerVehicleRoleBObj> vecParty2XCustomerVehicleRoleBObjs = new Vector<XCustomerVehicleRoleBObj>();
		Vector<XCustomerVehicleRoleBObj> vecSurvivedVehicleRoleBObjs = new Vector<XCustomerVehicleRoleBObj>();
		Vector<XCustomerVehicleRoleBObj> vecFinalVehicleRoleBObjs = new Vector<XCustomerVehicleRoleBObj>();
		String globalVINParty1=null;
		String globalVINParty2=null;
		String retailerParty1=null;
		String retailerParty2=null;
		//Timestamp tempOldestStartDate=null;
		boolean isDifferntRetailer =false ;
		HashMap<String, Timestamp> OldestStartDatePerRoleMap= new HashMap<String, Timestamp>();
		
		//System.out.println("******"+vecParties.size());
		for (TCRMPartyBObj partyBObj : vecParties) {
			partytId = partyBObj.getPartyId();
			//System.err.println("PARTY----> "+partytId );
			vecXCustomerVehicleBObjs = getAllXCustomerVehicleByPartyId(partytId, control);
			if (vecXCustomerVehicleBObjs != null && vecXCustomerVehicleBObjs.size() > 0) {
				for (int j = 0; j < vecXCustomerVehicleBObjs.size(); j++) {
					XCustomerVehicleBObj xCustomerVehicleBObj = (XCustomerVehicleBObj) vecXCustomerVehicleBObjs.get(j);
					//System.err.println("PARTY ->> " +partytId + " Global vin  ->> " +xCustomerVehicleBObj.getXVehicleBObj().getGlobalVIN());
					if(null==globalVINParty1 && null==retailerParty1){
						
								globalVINParty1=xCustomerVehicleBObj.getXVehicleBObj().getGlobalVIN();
								retailerParty1=xCustomerVehicleBObj.getRetailerId();
					}
					else if(null!=globalVINParty1 && null!=retailerParty1){
						globalVINParty2=xCustomerVehicleBObj.getXVehicleBObj().getGlobalVIN();
						retailerParty2=xCustomerVehicleBObj.getRetailerId();
					}
					
					if (!xCustomerVehicleMap.containsKey((xCustomerVehicleBObj.getXVehicleBObj().getGlobalVIN())
							+ (xCustomerVehicleBObj.getRetailerId()))) 
					{
						xCustomerVehicleMap.put((xCustomerVehicleBObj.getXVehicleBObj().getGlobalVIN()) + (xCustomerVehicleBObj.getRetailerId()),
								xCustomerVehicleBObj);
						vecXCustomerVehicleBObjsForDiffRetailer.add(xCustomerVehicleBObj);
						if(xCustomerVehicleMap.size()>1 )
						{
							/*  If global VIN + retailer code is not matching that means either different vehicle or 
							 * different retailer is attached to two different parties
							 * Scenario for Different Retailers comes 
							 * * */
							
							if(globalVINParty1.equalsIgnoreCase(globalVINParty2) && !retailerParty1.equalsIgnoreCase(retailerParty2)){
							//System.err.println("xCustomerVehicleMap.size() --> "+xCustomerVehicleMap.size());
							isDifferntRetailer=true;
							
							xCustomerVehicleMap=handleDifferentRetailers(vecXCustomerVehicleBObjsForDiffRetailer,
									xCustomerVehicleMap,allDiffRetailerVehicleRolesToCheckOldestStartDate,OldestStartDatePerRoleMap);
							//xCustomerVehicleMap.clear();
							//xCustomerVehicleMap.putAll(xCustomerVehicleMapAfterDiffRetailerProcessed);
							//System.err.println("xCustomerVehicleMap after -- > "+xCustomerVehicleMap.size());
							}
						}
						
					} else {
						XCustomerVehicleBObj xContVehicleBObjInMap = xCustomerVehicleMap.get((xCustomerVehicleBObj.getXVehicleBObj().getGlobalVIN()) 
								+ (xCustomerVehicleBObj.getRetailerId()));
						requestPersonRetailerCode = xContVehicleBObjInMap.getRetailerId();
						//System.err.println("requestPersonRetailerCode  -- > "+requestPersonRetailerCode);
						existingPersonRetailerCode = xCustomerVehicleBObj.getRetailerId();
						System.err.println("Party 1 RetailerCode ->> "+requestPersonRetailerCode+" , "+ 
										   "Party 2 RetailerCode ->> "+existingPersonRetailerCode);
						
						//IF retailer code matches 
						if (requestPersonRetailerCode != null && existingPersonRetailerCode != null && requestPersonRetailerCode
										.equalsIgnoreCase(existingPersonRetailerCode)) 
						{
							//Request last modified date
							Timestamp requestPersonLastModifiedDt = DateFormatter.getTimestamp(xContVehicleBObjInMap.getXCustomerVehicleLastUpdateDate());
							//System.err.println("Party 1 ->> "+ requestPersonLastModifiedDt);
							//DB last modified date
							Timestamp existingPersonLastModifiedDt = DateFormatter.getTimestamp(xCustomerVehicleBObj.getXCustomerVehicleLastUpdateDate());
							System.err.println("Party 1 LastModifiedDt ->> "+ requestPersonLastModifiedDt
							+ " ," +"Party 2 LastModifiedDt  ->> "+existingPersonLastModifiedDt);
//							//If request is latest than DB last modified date then put all active roles in final bobj
						
							
							allXCustomerVehicleRoleBObjsToCheckOldestStartDate.addAll(xContVehicleBObjInMap.getItemsXCustomerVehicleRoleBObj());
							allXCustomerVehicleRoleBObjsToCheckOldestStartDate.addAll(xCustomerVehicleBObj.getItemsXCustomerVehicleRoleBObj());
							//System.err.println(allXCustomerVehicleRoleBObjsToCheckOldestStartDate.size());
							OldestStartDatePerRoleMap=setOldestStartdateToActiveRole(allXCustomerVehicleRoleBObjsToCheckOldestStartDate);
							
							if (requestPersonLastModifiedDt.after(existingPersonLastModifiedDt)) {
								// get all the request customer vehicle roles into Vector 
								vecParty1XCustomerVehicleRoleBObjs = xContVehicleBObjInMap.getItemsXCustomerVehicleRoleBObj();
								//System.err.println("vecParty1XCustomerVehicleRoleBObjs.size  -- > "+vecParty1XCustomerVehicleRoleBObjs.size());
								if (vecParty1XCustomerVehicleRoleBObjs != null  && vecParty1XCustomerVehicleRoleBObjs.size() > 0) {
									for (XCustomerVehicleRoleBObj xCustomerVehicleRoleBObj : vecParty1XCustomerVehicleRoleBObjs) {

										
										if (xCustomerVehicleRoleBObj.getEndDate() == null) 
										{
											// put all active roles into final vector 
											if(null!=OldestStartDatePerRoleMap && OldestStartDatePerRoleMap.size()!=0){
											if(xCustomerVehicleRoleBObj.getVehicleRoleType().equalsIgnoreCase(SALES_ROLE_TYPE)){
												xCustomerVehicleRoleBObj.setStartDate((OldestStartDatePerRoleMap.get(SALES_ROLE_TYPE)).toString());
											}else if(xCustomerVehicleRoleBObj.getVehicleRoleType().equalsIgnoreCase(AFTERSALES_ROLE_TYPE)){
												xCustomerVehicleRoleBObj.setStartDate((OldestStartDatePerRoleMap.get(AFTERSALES_ROLE_TYPE)).toString());
											}else if(xCustomerVehicleRoleBObj.getVehicleRoleType().equalsIgnoreCase(DRIVER_ROLE_TYPE)){
												xCustomerVehicleRoleBObj.setStartDate((OldestStartDatePerRoleMap.get(DRIVER_ROLE_TYPE)).toString());
											}	
													vecFinalVehicleRoleBObjs.add(xCustomerVehicleRoleBObj);
											}
										}
										else{}
									}
								}

								xContVehicleBObjInMap.getItemsXCustomerVehicleRoleBObj().clear();
								xContVehicleBObjInMap.getItemsXCustomerVehicleRoleBObj().addAll(vecFinalVehicleRoleBObjs);
								//System.err.println("vecFinalVehicleRoleBObjs -- >"+vecFinalVehicleRoleBObjs.size());

							}
							//If DB has latest data than Request last modified date then put all active roles in final bobj
							else {
								// get all db customer vehicle roles into vector
								vecParty2XCustomerVehicleRoleBObjs = xCustomerVehicleBObj.getItemsXCustomerVehicleRoleBObj();

								if (vecParty2XCustomerVehicleRoleBObjs != null && vecParty2XCustomerVehicleRoleBObjs.size() > 0) 
								{

									for (XCustomerVehicleRoleBObj xCustomerVehicleRoleBObj : vecParty2XCustomerVehicleRoleBObjs) {
										if (xCustomerVehicleRoleBObj.getEndDate() == null) {
											// put all active roles into final vector 
											//vecFinalVehicleRoleBObjs.add(xCustomerVehicleRoleBObj);
											
											// put all active roles into final vector 
											if(null!=OldestStartDatePerRoleMap && OldestStartDatePerRoleMap.size()!=0){
												if(xCustomerVehicleRoleBObj.getVehicleRoleType().equalsIgnoreCase(SALES_ROLE_TYPE)){
													xCustomerVehicleRoleBObj.setStartDate((OldestStartDatePerRoleMap.get(SALES_ROLE_TYPE)).toString());
												}else if(xCustomerVehicleRoleBObj.getVehicleRoleType().equalsIgnoreCase(AFTERSALES_ROLE_TYPE)){
													xCustomerVehicleRoleBObj.setStartDate((OldestStartDatePerRoleMap.get(AFTERSALES_ROLE_TYPE)).toString());
												}else if(xCustomerVehicleRoleBObj.getVehicleRoleType().equalsIgnoreCase(DRIVER_ROLE_TYPE)){
													xCustomerVehicleRoleBObj.setStartDate((OldestStartDatePerRoleMap.get(DRIVER_ROLE_TYPE)).toString());
												}
													vecFinalVehicleRoleBObjs.add(xCustomerVehicleRoleBObj);
											}
										}

									}

								}
								//System.err.println("******************vecFinalVehicleRoleBObjs.size()-->> "+vecFinalVehicleRoleBObjs.size());

								xCustomerVehicleBObj.getItemsXCustomerVehicleRoleBObj().clear();
								//xCustomerVehicleBObj.getItemsXCustomerVehicleRoleBObj().addAll(vecParty2XCustomerVehicleRoleBObjs);
								xCustomerVehicleBObj.getItemsXCustomerVehicleRoleBObj().addAll(vecFinalVehicleRoleBObjs);

							}
							// xCustomerVehicleBObj: - Final active roles from DB which are latest than Request
							//xContVehicleBObjInMap:- Final Active roles from request which are latest than DB
							
							// Request XCustomerVehicleLastUpdateDate
							Timestamp person1ModifiedDt = DateFormatter.getTimestamp(xContVehicleBObjInMap.getXCustomerVehicleLastUpdateDate());
							// DB XCustomerVehicleLastUpdateDate
							//System.err.println("person1ModifiedDt --->>> "+person1ModifiedDt);
							Timestamp person2ModifiedDt = DateFormatter.getTimestamp(xCustomerVehicleBObj.getXCustomerVehicleLastUpdateDate());
							//System.err.println("person2ModifiedDt --->>> "+person2ModifiedDt);
							if (person1ModifiedDt.after(person2ModifiedDt)) {

								xCustomerVehicleMap.put((xContVehicleBObjInMap.getXVehicleBObj().getGlobalVIN()) 
										+ (xContVehicleBObjInMap.getRetailerId()),xContVehicleBObjInMap);
							}

							else {

								xCustomerVehicleMap.put((xCustomerVehicleBObj
										.getXVehicleBObj().getGlobalVIN()) + (xCustomerVehicleBObj.getRetailerId()),
										xCustomerVehicleBObj);
							}

						} 
						// for different retailers 
						else {
							
							
							xCustomerVehicleMap.put((xCustomerVehicleBObj.getXVehicleBObj().getGlobalVIN()) + 
									(xCustomerVehicleBObj.getRetailerId()),xCustomerVehicleBObj);	
							
						}

					}

				}
			}
		}
		

		
		for (Map.Entry<String, XCustomerVehicleBObj> entry : xCustomerVehicleMap.entrySet()) {
			XCustomerVehicleBObj tempXCustomerVehicleBObj = entry.getValue();
			XCustomerVehicleBObj survivedXCustomerVehicleBObj = new XCustomerVehicleBObj();
			survivedXCustomerVehicleBObj = tempXCustomerVehicleBObj;
			survivedXCustomerVehicleBObj.setContId(collapsedPartyId);
			survivedXCustomerVehicleBObj.setControl(control);
			globalVIN = survivedXCustomerVehicleBObj.getXVehicleBObj().getGlobalVIN();
			vecDBVehicleBObj = vehicleObjectByGVIN(globalVIN, control);
			if (vecDBVehicleBObj == null || vecDBVehicleBObj.isEmpty()) {
				response = dseaAdditionsExtsComponent.addXCustomerVehicle(survivedXCustomerVehicleBObj);
			} else {
				survivedXCustomerVehicleBObj.getXVehicleBObj().setVehiclepkId(vecDBVehicleBObj.get(0).getVehiclepkId());
				survivedXCustomerVehicleBObj.getXVehicleBObj().setXVehicleLastUpdateDate(vecDBVehicleBObj.get(0).getXVehicleLastUpdateDate());
				survivedXCustomerVehicleBObj.setVehicleId(vecDBVehicleBObj.get(0).getVehiclepkId());
				System.err.println("Final relationship count ->>  "+xCustomerVehicleMap.size()+", "+
				"Survived XCustomerVehicleRoleBObj Count ->> "+survivedXCustomerVehicleBObj.getItemsXCustomerVehicleRoleBObj().size());
				response = dseaAdditionsExtsComponent.addXCustomerVehicle(survivedXCustomerVehicleBObj);
			}
			if (response.getStatus().getStatus() == DWLStatus.FATAL) {
				throw new BusinessProxyException();
			}
		}
	}
	
	public void surviveDataSharingDetailsForZA(Vector<TCRMPartyBObj> vecParties, TCRMPartyBObj collapsedPartyBObj, DWLControl control) throws Exception 
	{
		String collapsedPartyId = collapsedPartyBObj.getPartyId();
		DSEAAdditionsExtsComponent dseaAdditionsExtsComponent = new DSEAAdditionsExtsComponent();
		String partyId = null;
		DWLResponse dwlResponse = new DWLResponse();
		Vector<XDataSharingBObj> vecXWholesaleDataSharing = new Vector<XDataSharingBObj> ();
		HashMap<String,XDataSharingBObj> XRetailDataSharingMap = new HashMap<String, XDataSharingBObj>();	
		boolean isRetailBObjPresent = false;
		for(TCRMPartyBObj partyBObj : vecParties)
		{
			partyId = partyBObj.getPartyId();
			dwlResponse = dseaAdditionsExtsComponent.getDataSharingByPartyId(partyId ,control);
			Vector<XDataSharingBObj> vecXDataSharing = (Vector<XDataSharingBObj>) dwlResponse.getData();
			if(vecXDataSharing!=null)
			{
			for(XDataSharingBObj tempXDataSharing :vecXDataSharing)
			{
				
				if(tempXDataSharing.getRetailerId()!=null || tempXDataSharing.getRetailerFlag().equalsIgnoreCase(ExternalRuleConstant.DATASHARING_RETAILER_FLAG_Y))
				{
					isRetailBObjPresent = true;
					XRetailDataSharingMap.put(tempXDataSharing.getRetailerId(), tempXDataSharing);
				}
				
				else
				{
					if(tempXDataSharing.getDataSharingFlag().equalsIgnoreCase(ExternalRuleConstant.DATASHARING_FLAG_Y))
					vecXWholesaleDataSharing.add(tempXDataSharing);
				}
				}
			}			
		}
		
		if(!vecXWholesaleDataSharing.isEmpty())
		{
		Collections.sort(vecXWholesaleDataSharing,
				new Comparator<XDataSharingBObj>() {// Ascending sort
													// - for delta
													// load
					public int compare(XDataSharingBObj dataSharing1,
							XDataSharingBObj dataSharing2) {
						if (dataSharing1.getLastModifiedSystemDate() == null
								|| dataSharing2
										.getLastModifiedSystemDate() == null)
							return 0;
						return dataSharing1
								.getLastModifiedSystemDate()
								.compareTo(
										dataSharing2.getLastModifiedSystemDate());
					}
				});
		
		
		XDataSharingBObj WSDataSharingBObj = vecXWholesaleDataSharing.get(0);
					
		
		//String objectToString =((XDataSharingBObj)WSDataSharingBObj).toXML("MDM", "MDMDomains.xsd", 0, null, false);	
  		//System.out.println(objectToString);
		
		for(Map.Entry<String, XDataSharingBObj> entry : XRetailDataSharingMap.entrySet())
		{
			XDataSharingBObj reqRetailDataSharing = entry.getValue();
			XDataSharingBObj tempDataSharing = new XDataSharingBObj ();
			
			tempDataSharing.setContId(collapsedPartyId);
			tempDataSharing.setRetailerFlag(DATASHARING_RETAILER_FLAG_Y);
			tempDataSharing.setRetailerId(reqRetailDataSharing.getRetailerId());
			tempDataSharing.setDataSharingFlag(WSDataSharingBObj.getDataSharingFlag());
			tempDataSharing.setSourceIdentifierType(WSDataSharingBObj.getSourceIdentifierType());
			tempDataSharing.setSourceIdentifierValue(WSDataSharingBObj.getSourceIdentifierValue());
			tempDataSharing.setStartDate(WSDataSharingBObj.getStartDate());
			tempDataSharing.setLastModifiedSystemDate(WSDataSharingBObj.getLastModifiedSystemDate());
			
			addNewDataSharingHRSforSurvivedParty(control, collapsedPartyId, tempDataSharing, dseaAdditionsExtsComponent);
		}
		
		XDataSharingBObj finalWSDataSharingBObj = new XDataSharingBObj ();
		
		finalWSDataSharingBObj.setContId(collapsedPartyId);
		finalWSDataSharingBObj.setDataSharingFlag(WSDataSharingBObj.getDataSharingFlag());
		finalWSDataSharingBObj.setRetailerFlag(DATASHARING_RETAILER_FLAG_N);
		finalWSDataSharingBObj.setRetailerId(null);
		finalWSDataSharingBObj.setSourceIdentifierType(WSDataSharingBObj.getSourceIdentifierType());
		finalWSDataSharingBObj.setSourceIdentifierValue(WSDataSharingBObj.getSourceIdentifierValue());
		finalWSDataSharingBObj.setStartDate(WSDataSharingBObj.getStartDate());
		finalWSDataSharingBObj.setLastModifiedSystemDate(WSDataSharingBObj.getLastModifiedSystemDate());
		
		addNewDataSharingHRSforSurvivedParty(control, collapsedPartyId, finalWSDataSharingBObj, dseaAdditionsExtsComponent);
	
		}
		}
		
			public String getSOurcePriorityForConsentZA (String sourceSystemType) throws Exception {

        String sourcePriority = null;

        if(StringUtils.isNonBlank(sourceSystemType))
        {
              if(ExternalRuleConstant.SOURCE_IDENTIFIER_TYPE_SFDC.equalsIgnoreCase(sourceSystemType) || 
                          ExternalRuleConstant.SOURCE_IDENTIFIER_TYPE_CBU.equalsIgnoreCase(sourceSystemType) ||
                          ExternalRuleConstant.SOURCE_IDENTIFIER_TYPE_TDS.equalsIgnoreCase(sourceSystemType))
              {
                    sourcePriority = ExternalRuleConstant.SOURCE_PRIORITY_3;
              }
              else if(ExternalRuleConstant.SOURCE_IDENTIFIER_TYPE_AUTOLINE.equalsIgnoreCase(sourceSystemType) ||
                          ExternalRuleConstant.SOURCE_IDENTIFIER_TYPE_COMPASS.equalsIgnoreCase(sourceSystemType))
              {
                    sourcePriority = ExternalRuleConstant.SOURCE_PRIORITY_2;                     
              }
              else
              {
                    //Hard Coded for the time being, need to be corrected
                    sourcePriority = ExternalRuleConstant.SOURCE_PRIORITY_1;
              }
        }
        return sourcePriority;        
  }
	
	/* Added by Pushpraj for Middle East Market */
	public  String processNameDataAEM(String nameValue,String marketName,String partyType) throws Exception
	{
		if(marketName !=null && marketName.equalsIgnoreCase(MIDDLE_EAST_MARKET))
		{
			if(!nameValue.matches(REGEX_ME_MARKET))
			{
				nameValue="";
			}
		}
	
		// Any other logic for other AEM markets
		
		return nameValue;
	}
	
	public static int getTotalCVRoles (String contId, String market)  throws Exception  {
		SQLQuery sqlQuery = new SQLQuery();
		int count=0;
		ResultSet objResultSet = null;
		String vehicleRoleSql = null;
		if("TUR".equals(market)||"IND".equals(market)||"MYS".equals(market)||"THA".equals(market)||
				"HU".equals(market)||"RO".equals(market)||"SK".equals(market)||"SG".equals(market)
				||"ID".equals(market)||"VN".equals(market)||"ZA".equals(market)||"BR".equals(market)
				||"AR".equals(market)||"ME".equals(market)||"EG".equals(market)){
			vehicleRoleSql = ExternalRuleConstant.COUNT_XCUSTVEHICLEROLE_DETAILS_CONTID_ALL;
		}
		else if("JPN".equals(market)){
			vehicleRoleSql = ExternalRuleConstant.COUNT_XCUSTVEHICLEROLE_DETAILS_CONTID_JPN;
		}
		else if("AU".equals(market)||"NZ".equals(market)){
			vehicleRoleSql = ExternalRuleConstant.COUNT_XCUSTVEHICLEROLE_DETAILS_CONTID_AUNZ;
		}
		else if("KOR".equals(market)){
			vehicleRoleSql = ExternalRuleConstant.COUNT_XCUSTVEHICLEROLE_DETAILS_CONTID_KOR;
		}
		List<SQLParam> params = new ArrayList<SQLParam>();
		XVehicleJPNBObj finalXVehicleBObj=null;
		try {
			params = new ArrayList<SQLParam>();
			params.add(0, new SQLParam(contId));
			objResultSet = sqlQuery.executeQuery(vehicleRoleSql, params);
			while (objResultSet.next()) {
				count = Integer.parseInt(objResultSet.getString("TOTAL_ROLES"));
			}
		} catch (Exception ex) {
			logger.finest(ex.getMessage());
		}finally{			
			if(objResultSet != null)
				objResultSet.close();
			sqlQuery.close();			
		}
		return count;
	}
	
	public void matchRulesAdjustForTHAFS(TCRMPartyBObj tcrmPartyBObj,
			DWLControl control) throws Exception {

    	XPersonBObjExt tcrmPersonBObj = null;
    	XOrgBObjExt tcrmOrgBobj = null;
		Vector<TCRMSuspectBObj> vecSuspectObject = new Vector<TCRMSuspectBObj>();
		DSEAAdditionsExtsComponent dseaAdditionsExtsComponent= new DSEAAdditionsExtsComponent();
		String sourcePartyId = null;
		String suspectPartyId = null;
		DWLResponse responseSourcePrefObj = null;
		DWLResponse responseSuspectPrefObj = null;			
		StringBuffer sb = new StringBuffer();
		TCRMPartyComponent partyComponent = new TCRMPartyComponent();
		String sourceRecordType = null;
		String suspectRecordType = null;
		Vector<String> fsTypes = new Vector<String>();
		fsTypes.add("FS");
		fsTypes.add("MPCFS");
		
		if (tcrmPartyBObj instanceof XPersonBObjExt) {

			tcrmPersonBObj = (XPersonBObjExt) tcrmPartyBObj;
			control = tcrmPersonBObj.getControl();							
			vecSuspectObject = tcrmPersonBObj.getItemsTCRMSuspectBObj();
			sourcePartyId = tcrmPersonBObj.getPartyId();
			SurvivorshipRuleUtil survivorshipUtil = new SurvivorshipRuleUtil();
			
			sourceRecordType = survivorshipUtil.checkRecordTypeForPerson(tcrmPersonBObj);
			
			if (vecSuspectObject != null && vecSuspectObject.size() > 0) {
				for (TCRMSuspectBObj tempSuspectBObj : vecSuspectObject) {
					//System.out.println(tempSuspectBObj.toXML());
					String suspectCatType = tempSuspectBObj.getMatchCategoryCode();
					 
					suspectPartyId = tempSuspectBObj.getSuspectPartyId();
				
					XPersonBObjExt suspectPersonBObj = (XPersonBObjExt) partyComponent.getPerson(suspectPartyId, "1", control);
					
					suspectRecordType = survivorshipUtil.checkRecordTypeForPerson(suspectPersonBObj);
					
					if (suspectCatType.equalsIgnoreCase(ExternalRuleConstant.SUSPECT_CATEGORY_VALUEA1)) {
						
						if(fsTypes.contains(sourceRecordType) && fsTypes.contains(suspectRecordType)){
							tempSuspectBObj.setAdjustedMatchCategoryCode(ExternalRuleConstant.SUSPECT_CATEGORY_VALUEB);
							tempSuspectBObj.setMatchCategoryAdjustmentType(ExternalRuleConstant.SUSP_REASON_CODE_DO_NOT_MERGE_FS_CUSTOMERS);	
						}
						
					}
			
				}

			}

		}else if (tcrmPartyBObj instanceof XOrgBObjExt) {

			tcrmOrgBobj = (XOrgBObjExt) tcrmPartyBObj;
			control = tcrmOrgBobj.getControl();							
			vecSuspectObject = tcrmOrgBobj.getItemsTCRMSuspectBObj();
			sourcePartyId = tcrmOrgBobj.getPartyId();
			SurvivorshipRuleUtil survivorshipUtil = new SurvivorshipRuleUtil();
			
			sourceRecordType = survivorshipUtil.checkRecordTypeForOrg(tcrmOrgBobj);
			
			if (vecSuspectObject != null && vecSuspectObject.size() > 0) {
				for (TCRMSuspectBObj tempSuspectBObj : vecSuspectObject) {
					//System.out.println(tempSuspectBObj.toXML());
					String suspectCatType = tempSuspectBObj.getMatchCategoryCode();
					 
					suspectPartyId = tempSuspectBObj.getSuspectPartyId();
				
					XOrgBObjExt suspectOrgBObj = (XOrgBObjExt) partyComponent.getOrganization(suspectPartyId, "1", control);
					
					suspectRecordType = survivorshipUtil.checkRecordTypeForOrg(suspectOrgBObj);
					
					if (suspectCatType.equalsIgnoreCase(ExternalRuleConstant.SUSPECT_CATEGORY_VALUEA1)) {
						
						if(fsTypes.contains(sourceRecordType) && fsTypes.contains(suspectRecordType)){
							tempSuspectBObj.setAdjustedMatchCategoryCode(ExternalRuleConstant.SUSPECT_CATEGORY_VALUEB);
							tempSuspectBObj.setMatchCategoryAdjustmentType(ExternalRuleConstant.SUSP_REASON_CODE_DO_NOT_MERGE_FS_CUSTOMERS);	
						}
						
					}
			
				}

			}

		}
	}

	public void survivedDataSharingDetailsForKorRearch(
			Vector<TCRMPartyBObj> vecParties, TCRMPartyBObj collapsedPartyBObj,
			DWLControl control) throws Exception {
		
		String collapsedPartyId = collapsedPartyBObj.getPartyId();
		DSEAAdditionsExtsComponent dseaAdditionsExtsComponent = new DSEAAdditionsExtsComponent();
		String partyId = null;
		DWLResponse dwlResponse = new DWLResponse();
		Vector<XDataSharingBObj> vecXWholesaleDataSharing = new Vector<XDataSharingBObj> ();
		boolean isRetailBObjPresent = false;
		for(TCRMPartyBObj partyBObj : vecParties)
		{
			partyId = partyBObj.getPartyId();
			dwlResponse = dseaAdditionsExtsComponent.getDataSharingByPartyId(partyId ,control);
			Vector<XDataSharingBObj> vecXDataSharing = (Vector<XDataSharingBObj>) dwlResponse.getData();
			if(vecXDataSharing!=null)
			{
				for(XDataSharingBObj tempXDataSharing :vecXDataSharing)
				{	
					if(tempXDataSharing.getDataSharingFlag().equalsIgnoreCase(ExternalRuleConstant.DATASHARING_FLAG_Y))
					vecXWholesaleDataSharing.add(tempXDataSharing);
				}
			}			
		}
		
			if(!vecXWholesaleDataSharing.isEmpty())
			{
				Collections.sort(vecXWholesaleDataSharing,
						new Comparator<XDataSharingBObj>() {// Ascending sort
															// - for delta
															// load
							public int compare(XDataSharingBObj dataSharing1,
									XDataSharingBObj dataSharing2) {
								if (dataSharing1.getLastModifiedSystemDate() == null
										|| dataSharing2
												.getLastModifiedSystemDate() == null)
									return 0;
								return dataSharing1
										.getLastModifiedSystemDate()
										.compareTo(
												dataSharing2.getLastModifiedSystemDate());
							}
						});
				
				
				XDataSharingBObj WSDataSharingBObj = vecXWholesaleDataSharing.get(0);
				
				
				XDataSharingBObj finalWSDataSharingBObj = new XDataSharingBObj ();
				
				finalWSDataSharingBObj.setContId(collapsedPartyId);
				finalWSDataSharingBObj.setDataSharingFlag(WSDataSharingBObj.getDataSharingFlag());
				finalWSDataSharingBObj.setCustomerMergeInd(WSDataSharingBObj.getCustomerMergeInd());
				finalWSDataSharingBObj.setGCUpdateDate(WSDataSharingBObj.getGCUpdateDate());
				finalWSDataSharingBObj.setDataSharingWholesale(WSDataSharingBObj.getDataSharingWholesale());
				finalWSDataSharingBObj.setWSDataSharingUpdateDate(WSDataSharingBObj.getWSDataSharingUpdateDate());
				finalWSDataSharingBObj.setRetailerId(null);
				finalWSDataSharingBObj.setSourceIdentifierType(WSDataSharingBObj.getSourceIdentifierType());
				finalWSDataSharingBObj.setSourceIdentifierValue(WSDataSharingBObj.getSourceIdentifierValue());
				finalWSDataSharingBObj.setStartDate(WSDataSharingBObj.getStartDate());
				finalWSDataSharingBObj.setLastModifiedSystemDate(WSDataSharingBObj.getLastModifiedSystemDate());
				
				addNewDataSharingKORforSurvivedParty(control, collapsedPartyId, finalWSDataSharingBObj, dseaAdditionsExtsComponent);
			
			}
		}
	
	public static  String getAnonymizedValueByPartyId(String suspectPartyId)
			throws BusinessProxyException, SQLException {

		SQLQuery sqlQuery = new SQLQuery();
		ResultSet objResultSet = null;
		String anonymized_valueSql = null;
		String anonymized_value = null;
		List<SQLParam> params = new ArrayList<SQLParam>();

		try {

			anonymized_valueSql = ExternalRuleConstant.ANONYMIZED_VAL_BY_PARTYID;

			params = new ArrayList<SQLParam>();
			params.add(0, new SQLParam(suspectPartyId));

			objResultSet = sqlQuery.executeQuery(anonymized_valueSql, params);
			if (objResultSet.next()) {
				anonymized_value = objResultSet
						.getString(ExternalRuleConstant.X_ANONYMIZED);
			}

		 } catch (Exception ex) {
			ex.printStackTrace();
		}finally{
			

			if(null!= objResultSet && !objResultSet.isClosed())
			{
				objResultSet.close();
			}
			if(sqlQuery != null )
			{
				sqlQuery.close();
			}
			
		}

		return anonymized_value;

	}
	
	
// Start of Match Upgrade for Thailand By Shashi (15-10-2020)
	
	public void matchRulesAdjustForTHA(TCRMPartyBObj tcrmPartyBObj, DWLControl control, String Market) throws Exception {
          //Upgrade B suspect to A1 - Exact Name & Phone
	      //Upgrade B suspect to A1 - Exact Name & Email
	      //Upgrade B suspect to A1 - Exact NationalID


	    	XPersonBObjExt tcrmPersonBObj = null;
			Vector<TCRMSuspectBObj> vecSuspectObject = new Vector<TCRMSuspectBObj>();
			Vector<Integer> tempVec = new Vector<Integer>();
			List<TCRMSuspectBObj> list = new ArrayList<TCRMSuspectBObj>();
			String sourcePartyId = null;
			String suspectPartyId = null;
			String anonymized_value = null;
			

					
		
			
	    
			if (tcrmPartyBObj instanceof XPersonBObjExt) {

				tcrmPersonBObj = (XPersonBObjExt) tcrmPartyBObj;
				control = tcrmPersonBObj.getControl();							
				vecSuspectObject = tcrmPersonBObj.getItemsTCRMSuspectBObj();
				sourcePartyId = tcrmPersonBObj.getPartyId();
				TCRMPartyComponent component = new TCRMPartyComponent();
				
			if(ExternalRuleConstant.MARKET_NAME_THAILAND.equalsIgnoreCase(Market)){	

				Vector<XPersonNameBObjExt> vecSourcePersonNameBObj = new Vector<XPersonNameBObjExt>();
				vecSourcePersonNameBObj = tcrmPersonBObj.getItemsTCRMPersonNameBObj();
				List<String> sourceNameList = new ArrayList<String>();
				for(int i = 0; i<vecSourcePersonNameBObj.size();i++){
					if("1".equals(vecSourcePersonNameBObj.get(i).getNameUsageType())){
						String fName = vecSourcePersonNameBObj.get(i).getGivenNameOne();
						String lName = vecSourcePersonNameBObj.get(i).getLastName();
						sourceNameList.add(fName.concat(lName)); 
					}
				}
					
				Vector<TCRMPartyContactMethodBObj> vecSourcePhoneBObj = new Vector<TCRMPartyContactMethodBObj>();
				vecSourcePhoneBObj = tcrmPersonBObj.getItemsTCRMPartyContactMethodBObj();
				List<String> sourcePhoneList = new ArrayList<String>();
				
				for(TCRMPartyContactMethodBObj partyContactMethodBObj : vecSourcePhoneBObj){
					if("1001".equals(partyContactMethodBObj.getContactMethodUsageType())
							||"1002".equals(partyContactMethodBObj.getContactMethodUsageType())
							||"1003".equals(partyContactMethodBObj.getContactMethodUsageType())
							||"1004".equals(partyContactMethodBObj.getContactMethodUsageType())
							||"1005".equals(partyContactMethodBObj.getContactMethodUsageType())
							||"1006".equals(partyContactMethodBObj.getContactMethodUsageType())){
						String sourcePhone = partyContactMethodBObj.getTCRMContactMethodBObj().getReferenceNumber();
						sourcePhoneList.add(sourcePhone); 
					}
				}
				
				Vector<TCRMPartyContactMethodBObj> vecSourceEmailBObj = new Vector<TCRMPartyContactMethodBObj>();
				vecSourceEmailBObj = tcrmPersonBObj.getItemsTCRMPartyContactMethodBObj();
				List<String> sourceEmailList = new ArrayList<String>();
				
				for(TCRMPartyContactMethodBObj partyContactMethodBObj : vecSourceEmailBObj){
					if("1007".equals(partyContactMethodBObj.getContactMethodUsageType())){
						String sourceEmail = partyContactMethodBObj.getTCRMContactMethodBObj().getReferenceNumber();
						sourceEmailList.add(sourceEmail); 
					}
				}
				String sourceNationalId = null;
				
			if(tcrmPersonBObj.getItemsTCRMPartyIdentificationBObj()!=null && tcrmPersonBObj.getItemsTCRMPartyIdentificationBObj().size()>0){
				Vector<TCRMPartyIdentificationBObj> vectorIdentification = new Vector<TCRMPartyIdentificationBObj>();
				vectorIdentification = tcrmPersonBObj.getItemsTCRMPartyIdentificationBObj();
				for(TCRMPartyIdentificationBObj identification : vectorIdentification){
					
					if("1006".equals(identification.getIdentificationType())){
						sourceNationalId = identification.getIdentificationNumber();
					}
					
				}					
			}
				

			if (vecSuspectObject != null && vecSuspectObject.size() > 0) {
				for (TCRMSuspectBObj tempSuspectBObj : vecSuspectObject) {
					
					String suspectCatType = tempSuspectBObj.getMatchCategoryCode();
					 
					suspectPartyId = tempSuspectBObj.getSuspectPartyId();
					
					TCRMPartyComponent partyComponent = new TCRMPartyComponent();
					if (suspectCatType.equalsIgnoreCase(ExternalRuleConstant.SUSPECT_CATEGORY_VALUEB)) {
						
						TCRMPersonBObj suspectPersonBObj = partyComponent.getPerson(suspectPartyId, "1", control);
						Vector<TCRMPersonNameBObj> vectorPerNameSuspects = suspectPersonBObj.getItemsTCRMPersonNameBObj();
						Vector<TCRMPartyContactMethodBObj> vectorContactSuspects = suspectPersonBObj.getItemsTCRMPartyContactMethodBObj();
						Vector<TCRMPartyIdentificationBObj> vectorIdentSuspects = suspectPersonBObj.getItemsTCRMPartyIdentificationBObj();
						boolean isNameExact = false;
						boolean isPhoneExact = false;
						boolean isEmailExact = false;
						boolean isNationalIdExact = false;
						
						
						
						for(TCRMPersonNameBObj personNameBObj: vectorPerNameSuspects){
							if("1".equals(personNameBObj.getNameUsageType())){
								String suspectname = personNameBObj.getGivenNameOne().concat(personNameBObj.getLastName());
								if(sourceNameList.contains(suspectname)){
									isNameExact=true;
									break;
								}
							}
						}
						for(TCRMPartyContactMethodBObj contactMethod: vectorContactSuspects){
							if("1001".equals(contactMethod.getContactMethodUsageType())
									||"1002".equals(contactMethod.getContactMethodUsageType())
									||"1003".equals(contactMethod.getContactMethodUsageType())
									||"1004".equals(contactMethod.getContactMethodUsageType())
									||"1005".equals(contactMethod.getContactMethodUsageType())
									||"1006".equals(contactMethod.getContactMethodUsageType())){
								String suspectPhone = contactMethod.getTCRMContactMethodBObj().getReferenceNumber();
								if(sourcePhoneList.contains(suspectPhone)){
									isPhoneExact = true;
									break;
								}
							}
						}
						for(TCRMPartyContactMethodBObj contactMethod: vectorContactSuspects){
							if("1007".equals(contactMethod.getContactMethodUsageType())){
								String suspectEmail = contactMethod.getTCRMContactMethodBObj().getReferenceNumber();
								if(sourceEmailList.contains(suspectEmail)){
									isEmailExact = true;
									break;
								}
							}
						}
						
						String suspectNationalId = null;
						for(TCRMPartyIdentificationBObj partyIdentification : vectorIdentSuspects){
							
							if("1006".equals(partyIdentification.getIdentificationType()) &&
									partyIdentification.getIdentificationValue()!=null){
								suspectNationalId = partyIdentification.getIdentificationNumber();	
							} 

						}
						
						if(sourceNationalId != null || StringUtils.isNonBlank(sourceNationalId)){
							if (sourceNationalId.equalsIgnoreCase(suspectNationalId))
								isNationalIdExact = true;
							
						}
						
						
						//Start Upgrade
						if ((isNameExact && isEmailExact) || (isNameExact && isPhoneExact) || (isNationalIdExact)){
							tempSuspectBObj.setAdjustedMatchCategoryCode(ExternalRuleConstant.MATCH_CAT_CODE_A1);
							tempSuspectBObj.setMatchCategoryAdjustmentType(ExternalRuleConstant.MATCH_CAT_ADJUSTMENT_TYPE_FN_LN_PHONE_EMAIL_NATIONALID_EXACT_THA);
							tempSuspectBObj.setMatchCategoryAdjustmentValue(ExternalRuleConstant.MATCH_CAT_ADJUSTMENT_VALUE_FN_LN_PHONE_EMAIL_NATIONALID_EXACT_THA);
							
						}
					 }
					
            
				  }
			  }
		   }	
			//code changes for X_ANONYMIZED Start	
				if (vecSuspectObject != null && vecSuspectObject.size() > 0) {
					
					for (TCRMSuspectBObj tempSuspectBObj : vecSuspectObject) {
						
						 suspectPartyId = tempSuspectBObj.getSuspectPartyId();
						anonymized_value = getAnonymizedValueByPartyId(suspectPartyId);
						
						if(null !=  anonymized_value && anonymized_value.equalsIgnoreCase("Y") ){
							tempSuspectBObj.setAdjustedMatchCategoryCode(ExternalRuleConstant.MATCH_CAT_CODE_C);
							//System.out.println("set Match Code C");
							tempSuspectBObj.setWeight("0");
							//System.out.println("set weight");
						}
					}
					
					for (TCRMSuspectBObj tempSuspectBObj : vecSuspectObject) {
						
						 suspectPartyId = tempSuspectBObj.getPartyId();
						anonymized_value = getAnonymizedValueByPartyId(suspectPartyId);
						
							if(null != anonymized_value && anonymized_value.equalsIgnoreCase("Y")){
								throw new Exception();
							
							}
						}
					
					
				}
			//CODE changes for X_ANONYMIZED end	
		}
  }
	// Start of Match Adjustment for Japan By Shashi (18-06-2021)
	
		public void matchRulesAdjustForJPN(TCRMPartyBObj tcrmPartyBObj, DWLControl control, String Market) throws Exception {
	          //Upgrade B suspect to A1 - Exact Name & Phone(Mobile,Home Or Hm-M)& Data Sharing all Yes
		      //Upgrade B suspect to A1 - Exact Name & Email(Private, Other Or P-O)& Data Sharing all Yes
		      //Downgrade A1 suspect to B - name mismatch
			  //Downgrade A1 suspect to B - One of Datasharing is No
			  


		    	XPersonBObjExt tcrmPersonBObj = null;
		    	XOrgBObjExt tcrmOrgBObj = null;
				Vector<TCRMSuspectBObj> vecSuspectObject = new Vector<TCRMSuspectBObj>();
				DWLResponse responseSourceXDataSharingObj = null;
				DWLResponse responseSuspectXDataSharingObj = null;	
				DSEAAdditionsExtsComponent dseaAdditionsExtsComponent= new DSEAAdditionsExtsComponent();
				Vector<XDataSharingBObj> vecSourceDataSharingObject = new Vector<XDataSharingBObj>();
				List<String> sourceDataSharingList = new ArrayList<String>();
				String sourcePartyId = null;
				String suspectPartyId = null;
				StringBuffer sb = new StringBuffer();
						
			
				
		    try{
				if (tcrmPartyBObj instanceof XPersonBObjExt) {

					tcrmPersonBObj = (XPersonBObjExt) tcrmPartyBObj;
					control = tcrmPersonBObj.getControl();							
					vecSuspectObject = tcrmPersonBObj.getItemsTCRMSuspectBObj();
					sourcePartyId = tcrmPersonBObj.getPartyId();
					
				if(ExternalRuleConstant.JAPAN_MARKET_NAME.equalsIgnoreCase(Market)){	

					Vector<XPersonNameBObjExt> vecSourcePersonNameBObj = new Vector<XPersonNameBObjExt>();
					vecSourcePersonNameBObj = tcrmPersonBObj.getItemsTCRMPersonNameBObj();
					List<String> sourceKanjiNameList = new ArrayList<String>();
					List<String> sourceKanaNameList = new ArrayList<String>();
					for(int i = 0; i<vecSourcePersonNameBObj.size();i++){
						if("1001".equals(vecSourcePersonNameBObj.get(i).getNameUsageType())){
							String fName = vecSourcePersonNameBObj.get(i).getGivenNameOne();
							String lName = vecSourcePersonNameBObj.get(i).getLastName();
							if(fName!=null && lName!=null && StringUtils.isNonBlank(fName) && StringUtils.isNonBlank(lName)){
								sourceKanjiNameList.add(fName.concat(lName)); 
							}
						}
						else if("1002".equals(vecSourcePersonNameBObj.get(i).getNameUsageType())){
							String fName = vecSourcePersonNameBObj.get(i).getGivenNameOne();
							String lName = vecSourcePersonNameBObj.get(i).getLastName();
							if(fName!=null && lName!=null && StringUtils.isNonBlank(fName) && StringUtils.isNonBlank(lName)){
								sourceKanaNameList.add(fName.concat(lName)); 
							}
						}
					}
						
					Vector<TCRMPartyContactMethodBObj> vecSourcePhoneBObj = new Vector<TCRMPartyContactMethodBObj>();
					vecSourcePhoneBObj = tcrmPersonBObj.getItemsTCRMPartyContactMethodBObj();
					List<String> sourcePhoneList = new ArrayList<String>();
					List<String> sourceHomePhone = new ArrayList<String>();
					List<String> sourceMobilePhone = new ArrayList<String>();
					List<String> sourcePrivateEmail = new ArrayList<String>();
					List<String> sourceOtherEmail = new ArrayList<String>();
					
					
					
					for(TCRMPartyContactMethodBObj partyContactMethodBObj : vecSourcePhoneBObj){
						if("1024".equals(partyContactMethodBObj.getContactMethodUsageType())){
							String sourcephone = partyContactMethodBObj.getTCRMContactMethodBObj().getReferenceNumber();
							if(sourcephone !=null && !sourcephone.equalsIgnoreCase(VALUE_DELETED)){
							sourceHomePhone.add(sourcephone); 
							}
							
						}
						else if("1027".equals(partyContactMethodBObj.getContactMethodUsageType())){
							String sourcephone = partyContactMethodBObj.getTCRMContactMethodBObj().getReferenceNumber();
							if(sourcephone !=null && !sourcephone.equalsIgnoreCase(VALUE_DELETED)){
							sourceMobilePhone.add(sourcephone); 
							}
						}
						else if("1030".equals(partyContactMethodBObj.getContactMethodUsageType())){
							String sourceEmail = partyContactMethodBObj.getTCRMContactMethodBObj().getReferenceNumber();
							if(sourceEmail !=null && !sourceEmail.equalsIgnoreCase(VALUE_DELETED)){
							sourcePrivateEmail.add(sourceEmail); 
							}
							
						}
						else if("1032".equals(partyContactMethodBObj.getContactMethodUsageType())){
							String sourceEmail = partyContactMethodBObj.getTCRMContactMethodBObj().getReferenceNumber();
							if(sourceEmail !=null && !sourceEmail.equalsIgnoreCase(VALUE_DELETED)){
							sourceOtherEmail.add(sourceEmail); 
							}
						}
					}
					
					
					//Source DataSharing changes start
					responseSourceXDataSharingObj = dseaAdditionsExtsComponent.getDataSharingByPartyId(sourcePartyId, control);				
					if (responseSourceXDataSharingObj != null) {
						vecSourceDataSharingObject = (Vector<XDataSharingBObj>) responseSourceXDataSharingObj
								.getData();
						if(vecSourceDataSharingObject!=null){
							if (vecSourceDataSharingObject.get(0).getStatus()
									.getStatus() == DWLStatus.FATAL) {
								throwExceptionifTxnFails(responseSourceXDataSharingObj, sb);
							}
						}
					} else {
						throwExceptionifTxnFails(responseSourceXDataSharingObj, sb);
					}

					if(vecSourceDataSharingObject!=null && vecSourceDataSharingObject.size()>0){					
						for(XDataSharingBObj xDataSharingBObj : vecSourceDataSharingObject){
							String dataSharingRetailerFlag = xDataSharingBObj.getRetailerFlag();
							if(dataSharingRetailerFlag!= null && (dataSharingRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.DATASHARING_FLAG_N))){
								String dataSharingFlag = xDataSharingBObj.getDataSharingFlag();
								if(dataSharingFlag!=null){
									sourceDataSharingList.add(dataSharingFlag);	
								}
							}
						}					
					}
					//Source DataSharing changes end
					
					
				
					
				
					

				if (vecSuspectObject != null && vecSuspectObject.size() > 0) {
					for (TCRMSuspectBObj tempSuspectBObj : vecSuspectObject) {
						
						String suspectCatType = tempSuspectBObj.getMatchCategoryCode();
						 
						suspectPartyId = tempSuspectBObj.getSuspectPartyId();
						
						TCRMPartyComponent partyComponent = new TCRMPartyComponent();
						if (suspectCatType.equalsIgnoreCase(ExternalRuleConstant.SUSPECT_CATEGORY_VALUEB)) {
							
							TCRMPersonBObj suspectPersonBObj = partyComponent.getPerson(suspectPartyId, "1", control);
							Vector<TCRMPersonNameBObj> vectorPerNameSuspects = suspectPersonBObj.getItemsTCRMPersonNameBObj();
							Vector<TCRMPartyContactMethodBObj> vectorContactSuspects = suspectPersonBObj.getItemsTCRMPartyContactMethodBObj();
							boolean isKanaNameExact = false;
							boolean isKanjiNameExact = false;
							boolean isNameExact = false;
							boolean isHomePhoneExact = false;
							boolean isMobilePhoneExact = false;
							boolean isHomeMobilePhoneExact = false;
							boolean isMobileHomePhoneExact = false;
							boolean isPhoneExact = false;
							boolean isPrivateEmailExact = false;
							boolean isOtherEmailExact = false;
							boolean isPrivateOtherEmailExact = false;
							boolean isOtherPrivateEmailExact = false;
							boolean isEmailExact = false;
							boolean isDataSharingFlagNo = false;
							
							
							
							// Suspect Name Changes Start
							for(TCRMPersonNameBObj personNameBObj: vectorPerNameSuspects){
								if("1001".equals(personNameBObj.getNameUsageType())){
									String fname = personNameBObj.getGivenNameOne();
									String lname = personNameBObj.getLastName();
									String suspectname = null;
									if(fname!=null && lname != null && StringUtils.isNonBlank(fname) && StringUtils.isNonBlank(lname)){
									suspectname = fname.concat(lname);
									}
									if(sourceKanjiNameList.contains(suspectname)){
										isKanjiNameExact=true;
										break;
									}
								}
								
							}
							
							for(TCRMPersonNameBObj personNameBObj: vectorPerNameSuspects){
								 if("1002".equals(personNameBObj.getNameUsageType())){
									String fname = personNameBObj.getGivenNameOne();
									String lname = personNameBObj.getLastName();
									String suspectname = null;
									if(fname!=null && lname != null && StringUtils.isNonBlank(fname) && StringUtils.isNonBlank(lname)){
									suspectname = fname.concat(lname);
									}
									if(sourceKanaNameList.contains(suspectname)){
										isKanaNameExact=true;
										break;
									}
								}
							}
							
							if(isKanjiNameExact && isKanaNameExact){
								isNameExact = true;
							}
							
							// Suspect Name Changes End
							
							//Suspect Phone Changes Start
							for(TCRMPartyContactMethodBObj contactMethod: vectorContactSuspects){
								if("1024".equals(contactMethod.getContactMethodUsageType())){
									String suspectPhone = contactMethod.getTCRMContactMethodBObj().getReferenceNumber();
									if(sourceHomePhone.contains(suspectPhone)){
										isHomePhoneExact = true;
										break;
									}
								}
							}
							
							
							for(TCRMPartyContactMethodBObj contactMethod: vectorContactSuspects){
								if("1027".equals(contactMethod.getContactMethodUsageType())){
									String suspectPhone = contactMethod.getTCRMContactMethodBObj().getReferenceNumber();
									if(sourceMobilePhone.contains(suspectPhone)){
										isMobilePhoneExact = true;
										break;
									}
								}
							}
							
							for(TCRMPartyContactMethodBObj contactMethod: vectorContactSuspects){
								if("1027".equals(contactMethod.getContactMethodUsageType())){
									String suspectPhone = contactMethod.getTCRMContactMethodBObj().getReferenceNumber();
									if(sourceHomePhone.contains(suspectPhone)){
										isHomeMobilePhoneExact = true;
										break;
									}
								}
							}
							
							for(TCRMPartyContactMethodBObj contactMethod: vectorContactSuspects){
								if("1024".equals(contactMethod.getContactMethodUsageType())){
									String suspectPhone = contactMethod.getTCRMContactMethodBObj().getReferenceNumber();
									if(sourceMobilePhone.contains(suspectPhone)){
										isMobileHomePhoneExact = true;
										break;
									}
								}
							}
							
							if(isHomePhoneExact || isMobilePhoneExact || isHomeMobilePhoneExact || isMobileHomePhoneExact){
								isPhoneExact = true;
							}
							//Suspect Phone Changes End
							
							// Suspect Email Changes Start
							for(TCRMPartyContactMethodBObj contactMethod: vectorContactSuspects){
								if("1030".equals(contactMethod.getContactMethodUsageType())){
									String suspectEmail = contactMethod.getTCRMContactMethodBObj().getReferenceNumber();
									if(sourcePrivateEmail.contains(suspectEmail)){
										isPrivateEmailExact = true;
										break;
									}
								}
							}
							
							for(TCRMPartyContactMethodBObj contactMethod: vectorContactSuspects){
								if("1032".equals(contactMethod.getContactMethodUsageType())){
									String suspectEmail = contactMethod.getTCRMContactMethodBObj().getReferenceNumber();
									if(sourceOtherEmail.contains(suspectEmail)){
										isOtherEmailExact = true;
										break;
									}
								}
							}
							
							for(TCRMPartyContactMethodBObj contactMethod: vectorContactSuspects){
								if("1032".equals(contactMethod.getContactMethodUsageType())){
									String suspectEmail = contactMethod.getTCRMContactMethodBObj().getReferenceNumber();
									if(sourcePrivateEmail.contains(suspectEmail)){
										isPrivateOtherEmailExact = true;
										break;
									}
								}
							}
							
							for(TCRMPartyContactMethodBObj contactMethod: vectorContactSuspects){
								if("1030".equals(contactMethod.getContactMethodUsageType())){
									String suspectEmail = contactMethod.getTCRMContactMethodBObj().getReferenceNumber();
									if(sourceOtherEmail.contains(suspectEmail)){
										isOtherPrivateEmailExact = true;
										break;
									}
								}
							}
							
							if(isPrivateEmailExact || isOtherEmailExact || isPrivateOtherEmailExact || isOtherPrivateEmailExact){
								isEmailExact = true;
							}
							// Suspect Email Changes End
							
							//Suspect DataSharing changes start
							Vector<XDataSharingBObj> vecSuspectDataSharingObject = new Vector<XDataSharingBObj>();
							List<String> suspectDataSharingList = new ArrayList<String>();
							responseSuspectXDataSharingObj = dseaAdditionsExtsComponent.getDataSharingByPartyId(suspectPartyId, control);				
							if (responseSuspectXDataSharingObj != null) {
								vecSuspectDataSharingObject = (Vector<XDataSharingBObj>) responseSuspectXDataSharingObj
										.getData();
								if(vecSuspectDataSharingObject!=null){
									if (vecSuspectDataSharingObject.get(0).getStatus()
											.getStatus() == DWLStatus.FATAL) {
										throwExceptionifTxnFails(responseSuspectXDataSharingObj, sb);
									}
								}
							} else {
								throwExceptionifTxnFails(responseSuspectXDataSharingObj, sb);
							}

							if(vecSuspectDataSharingObject!=null && vecSuspectDataSharingObject.size()>0){					
								for(XDataSharingBObj xDataSharingBObj : vecSuspectDataSharingObject){
									String dataSharingRetailerFlag = xDataSharingBObj.getRetailerFlag();
									if(dataSharingRetailerFlag!= null && (dataSharingRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.DATASHARING_FLAG_N))){
										String dataSharingFlag = xDataSharingBObj.getDataSharingFlag();
										if(dataSharingFlag!=null){
											suspectDataSharingList.add(dataSharingFlag);	
										}
									}
								}					
							}
							//Suspect DataSharing changes end
							
							if ((sourceDataSharingList!=null && sourceDataSharingList.size()>0 && (sourceDataSharingList.contains(ExternalRuleConstant.DATASHARING_FLAG_N))) 
									&& (suspectDataSharingList!=null && suspectDataSharingList.size()>0 && (suspectDataSharingList.contains(ExternalRuleConstant.DATASHARING_FLAG_N)))){
								isDataSharingFlagNo = true;
							}
							
							
							//Start Upgrade
							if(!isDataSharingFlagNo){
							if ((isNameExact && isEmailExact) || (isNameExact && isPhoneExact)){
								tempSuspectBObj.setAdjustedMatchCategoryCode(ExternalRuleConstant.MATCH_CAT_CODE_A1);
								tempSuspectBObj.setMatchCategoryAdjustmentType(ExternalRuleConstant.MATCH_CAT_ADJUSTMENT_TYPE_UPGRADE_B_TO_A1_PERSON_JPN);
								tempSuspectBObj.setMatchCategoryAdjustmentValue(ExternalRuleConstant.MATCH_CAT_ADJUSTMENT_VALUE_UPGRADE_B_TO_A1_PERSON_JPN);
								
							}
							}
						 }
						else if (suspectCatType.equalsIgnoreCase(ExternalRuleConstant.SUSPECT_CATEGORY_VALUEA1)) {
							
							TCRMPersonBObj suspectPersonBObj = partyComponent.getPerson(suspectPartyId, "1", control);
							Vector<TCRMPersonNameBObj> vectorPerNameSuspects = suspectPersonBObj.getItemsTCRMPersonNameBObj();
							Vector<TCRMPartyContactMethodBObj> vectorContactSuspects = suspectPersonBObj.getItemsTCRMPartyContactMethodBObj();
							boolean isKanaNameExact = false;
							boolean isKanjiNameExact = false;
							boolean isNameExact = false;
							boolean isHomePhoneExact = false;
							boolean isMobilePhoneExact = false;
							boolean isHomeMobilePhoneExact = false;
							boolean isMobileHomePhoneExact = false;
							boolean isPhoneExact = false;
							boolean isPrivateEmailExact = false;
							boolean isOtherEmailExact = false;
							boolean isPrivateOtherEmailExact = false;
							boolean isOtherPrivateEmailExact = false;
							boolean isEmailExact = false;
							boolean isDataSharingFlagNo = false;
							boolean isDowngraded = false;
							
							
							
							// Suspect Name Changes Start
							for(TCRMPersonNameBObj personNameBObj: vectorPerNameSuspects){
								if("1001".equals(personNameBObj.getNameUsageType())){
									String fname = personNameBObj.getGivenNameOne();
									String lname = personNameBObj.getLastName();
									String suspectname = null;
									if(fname!=null && lname != null && StringUtils.isNonBlank(fname) && StringUtils.isNonBlank(lname)){
									suspectname = fname.concat(lname);
									}
									if(sourceKanjiNameList.contains(suspectname)){
										isKanjiNameExact=true;
										break;
									}
								}
								
							}
							
							for(TCRMPersonNameBObj personNameBObj: vectorPerNameSuspects){
								 if("1002".equals(personNameBObj.getNameUsageType())){
									String fname = personNameBObj.getGivenNameOne();
									String lname = personNameBObj.getLastName();
									String suspectname = null;
									if(fname!=null && lname != null && StringUtils.isNonBlank(fname) && StringUtils.isNonBlank(lname)){
									suspectname = fname.concat(lname);
									}
									if(sourceKanaNameList.contains(suspectname)){
										isKanaNameExact=true;
										break;
									}
								}
							}
							
							if(isKanjiNameExact && isKanaNameExact){
								isNameExact = true;
							}
							
							// Suspect Name Changes End
							
							//Suspect Phone Changes Start
							for(TCRMPartyContactMethodBObj contactMethod: vectorContactSuspects){
								if("1024".equals(contactMethod.getContactMethodUsageType())){
									String suspectPhone = contactMethod.getTCRMContactMethodBObj().getReferenceNumber();
									if(sourceHomePhone.contains(suspectPhone)){
										isHomePhoneExact = true;
										break;
									}
								}
							}
							
							
							for(TCRMPartyContactMethodBObj contactMethod: vectorContactSuspects){
								if("1027".equals(contactMethod.getContactMethodUsageType())){
									String suspectPhone = contactMethod.getTCRMContactMethodBObj().getReferenceNumber();
									if(sourceMobilePhone.contains(suspectPhone)){
										isMobilePhoneExact = true;
										break;
									}
								}
							}
							
							for(TCRMPartyContactMethodBObj contactMethod: vectorContactSuspects){
								if("1027".equals(contactMethod.getContactMethodUsageType())){
									String suspectPhone = contactMethod.getTCRMContactMethodBObj().getReferenceNumber();
									if(sourceHomePhone.contains(suspectPhone)){
										isHomeMobilePhoneExact = true;
										break;
									}
								}
							}
							
							for(TCRMPartyContactMethodBObj contactMethod: vectorContactSuspects){
								if("1024".equals(contactMethod.getContactMethodUsageType())){
									String suspectPhone = contactMethod.getTCRMContactMethodBObj().getReferenceNumber();
									if(sourceMobilePhone.contains(suspectPhone)){
										isMobileHomePhoneExact = true;
										break;
									}
								}
							}
							
							if(isHomePhoneExact || isMobilePhoneExact || isHomeMobilePhoneExact || isMobileHomePhoneExact){
								isPhoneExact = true;
							}
							//Suspect Phone Changes End
							
							// Suspect Email Changes Start
							for(TCRMPartyContactMethodBObj contactMethod: vectorContactSuspects){
								if("1030".equals(contactMethod.getContactMethodUsageType())){
									String suspectEmail = contactMethod.getTCRMContactMethodBObj().getReferenceNumber();
									if(sourcePrivateEmail.contains(suspectEmail)){
										isPrivateEmailExact = true;
										break;
									}
								}
							}
							
							for(TCRMPartyContactMethodBObj contactMethod: vectorContactSuspects){
								if("1032".equals(contactMethod.getContactMethodUsageType())){
									String suspectEmail = contactMethod.getTCRMContactMethodBObj().getReferenceNumber();
									if(sourceOtherEmail.contains(suspectEmail)){
										isOtherEmailExact = true;
										break;
									}
								}
							}
							
							for(TCRMPartyContactMethodBObj contactMethod: vectorContactSuspects){
								if("1032".equals(contactMethod.getContactMethodUsageType())){
									String suspectEmail = contactMethod.getTCRMContactMethodBObj().getReferenceNumber();
									if(sourcePrivateEmail.contains(suspectEmail)){
										isPrivateOtherEmailExact = true;
										break;
									}
								}
							}
							
							for(TCRMPartyContactMethodBObj contactMethod: vectorContactSuspects){
								if("1030".equals(contactMethod.getContactMethodUsageType())){
									String suspectEmail = contactMethod.getTCRMContactMethodBObj().getReferenceNumber();
									if(sourceOtherEmail.contains(suspectEmail)){
										isOtherPrivateEmailExact = true;
										break;
									}
								}
							}
							
							if(isPrivateEmailExact || isOtherEmailExact || isPrivateOtherEmailExact || isOtherPrivateEmailExact){
								isEmailExact = true;
							}
							// Suspect Email Changes End
							
							//Suspect DataSharing changes start
							Vector<XDataSharingBObj> vecSuspectDataSharingObject = new Vector<XDataSharingBObj>();
							List<String> suspectDataSharingList = new ArrayList<String>();
							responseSuspectXDataSharingObj = dseaAdditionsExtsComponent.getDataSharingByPartyId(suspectPartyId, control);				
							if (responseSuspectXDataSharingObj != null) {
								vecSuspectDataSharingObject = (Vector<XDataSharingBObj>) responseSuspectXDataSharingObj
										.getData();
								if(vecSuspectDataSharingObject!=null){
									if (vecSuspectDataSharingObject.get(0).getStatus()
											.getStatus() == DWLStatus.FATAL) {
										throwExceptionifTxnFails(responseSuspectXDataSharingObj, sb);
									}
								}
							} else {
								throwExceptionifTxnFails(responseSuspectXDataSharingObj, sb);
							}

							if(vecSuspectDataSharingObject!=null && vecSuspectDataSharingObject.size()>0){					
								for(XDataSharingBObj xDataSharingBObj : vecSuspectDataSharingObject){
									String dataSharingRetailerFlag = xDataSharingBObj.getRetailerFlag();
									if(dataSharingRetailerFlag!= null && (dataSharingRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.DATASHARING_FLAG_N))){
										String dataSharingFlag = xDataSharingBObj.getDataSharingFlag();
										if(dataSharingFlag!=null){
											suspectDataSharingList.add(dataSharingFlag);	
										}
									}
								}					
							}
							//Suspect DataSharing changes end
							
							if ((sourceDataSharingList!=null && sourceDataSharingList.size()>0 && (sourceDataSharingList.contains(ExternalRuleConstant.DATASHARING_FLAG_N))) 
									&& (suspectDataSharingList!=null && suspectDataSharingList.size()>0 && (suspectDataSharingList.contains(ExternalRuleConstant.DATASHARING_FLAG_N)))){
								isDataSharingFlagNo = true;
							}
							
							if((isNameExact && isPhoneExact) || (isNameExact && isEmailExact)){
								isDowngraded = true;
							}
							
							//Start Downgrade
							
							
		
							if (isDataSharingFlagNo || !(isNameExact)  ||  !(isDowngraded)){
								tempSuspectBObj.setAdjustedMatchCategoryCode(ExternalRuleConstant.MATCH_CAT_CODE_B);
								tempSuspectBObj.setMatchCategoryAdjustmentType(ExternalRuleConstant.MATCH_CAT_ADJUSTMENT_TYPE_DOWNGRADE_A1_TO_B_PERSON_JPN);
								tempSuspectBObj.setMatchCategoryAdjustmentValue(ExternalRuleConstant.MATCH_CAT_ADJUSTMENT_VALUE_DOWNGRADE_A1_TO_B_PERSON_JPN);
								
							}
							
						 }
						
	            
					  }
				  }
			   }	
			}
			
				if (tcrmPartyBObj instanceof XOrgBObjExt) {
					

					tcrmOrgBObj = (XOrgBObjExt) tcrmPartyBObj;
					control = tcrmOrgBObj.getControl();							
					vecSuspectObject = tcrmOrgBObj.getItemsTCRMSuspectBObj();
					sourcePartyId = tcrmOrgBObj.getPartyId();
					
				if(ExternalRuleConstant.JAPAN_MARKET_NAME.equalsIgnoreCase(Market)){	

					Vector<XOrgNameBObjExt> vecSourceOrgNameBObj = new Vector<XOrgNameBObjExt>();
					vecSourceOrgNameBObj = tcrmOrgBObj.getItemsTCRMOrganizationNameBObj();
					List<String> sourceKanjiNameList = new ArrayList<String>();
					
					for(int i = 0; i<vecSourceOrgNameBObj.size();i++){
						if("1001".equals(vecSourceOrgNameBObj.get(i).getNameUsageType())){
							String orgName = vecSourceOrgNameBObj.get(i).getOrganizationName();
							if(orgName!=null && StringUtils.isNonBlank(orgName)){
								sourceKanjiNameList.add(orgName); 
							}
						}
						
					}
						
					Vector<TCRMPartyContactMethodBObj> vecSourcePhoneBObj = new Vector<TCRMPartyContactMethodBObj>();
					vecSourcePhoneBObj = tcrmOrgBObj.getItemsTCRMPartyContactMethodBObj();
					List<String> sourcePhoneList = new ArrayList<String>();
					
					for(TCRMPartyContactMethodBObj partyContactMethodBObj : vecSourcePhoneBObj){
						if("1024".equals(partyContactMethodBObj.getContactMethodUsageType())
								||"1025".equals(partyContactMethodBObj.getContactMethodUsageType())
								||"1026".equals(partyContactMethodBObj.getContactMethodUsageType())
								||"1027".equals(partyContactMethodBObj.getContactMethodUsageType())
								||"1028".equals(partyContactMethodBObj.getContactMethodUsageType())
								||"1029".equals(partyContactMethodBObj.getContactMethodUsageType())){
							String sourcePhone = partyContactMethodBObj.getTCRMContactMethodBObj().getReferenceNumber();
							if(sourcePhone!= null && !sourcePhone.equalsIgnoreCase(VALUE_DELETED)){
							sourcePhoneList.add(sourcePhone); 
							}
						}
					}
					
					
					//Source DataSharing changes start
					responseSourceXDataSharingObj = dseaAdditionsExtsComponent.getDataSharingByPartyId(sourcePartyId, control);				
					if (responseSourceXDataSharingObj != null) {
						vecSourceDataSharingObject = (Vector<XDataSharingBObj>) responseSourceXDataSharingObj
								.getData();
						if(vecSourceDataSharingObject!=null){
							if (vecSourceDataSharingObject.get(0).getStatus()
									.getStatus() == DWLStatus.FATAL) {
								throwExceptionifTxnFails(responseSourceXDataSharingObj, sb);
							}
						}
					} else {
						throwExceptionifTxnFails(responseSourceXDataSharingObj, sb);
					}

					if(vecSourceDataSharingObject!=null && vecSourceDataSharingObject.size()>0){					
						for(XDataSharingBObj xDataSharingBObj : vecSourceDataSharingObject){
							String dataSharingRetailerFlag = xDataSharingBObj.getRetailerFlag();
							if(dataSharingRetailerFlag!= null && (dataSharingRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.DATASHARING_FLAG_N))){
								String dataSharingFlag = xDataSharingBObj.getDataSharingFlag();
								if(dataSharingFlag!=null){
									sourceDataSharingList.add(dataSharingFlag);	
								}
							}
						}					
					}
					//Source DataSharing changes end
					
					
				
					
				
					

				if (vecSuspectObject != null && vecSuspectObject.size() > 0) {
					for (TCRMSuspectBObj tempSuspectBObj : vecSuspectObject) {
						
						String suspectCatType = tempSuspectBObj.getMatchCategoryCode();
						 
						suspectPartyId = tempSuspectBObj.getSuspectPartyId();
						
						TCRMPartyComponent partyComponent = new TCRMPartyComponent();
						if (suspectCatType.equalsIgnoreCase(ExternalRuleConstant.SUSPECT_CATEGORY_VALUEB)) {
							
							TCRMOrganizationBObj suspectOrgBObj = partyComponent.getOrganization(suspectPartyId, "1", control);
							Vector<TCRMOrganizationNameBObj> vectorOrgNameSuspects = suspectOrgBObj.getItemsTCRMOrganizationNameBObj();
							Vector<TCRMPartyContactMethodBObj> vectorContactSuspects = suspectOrgBObj.getItemsTCRMPartyContactMethodBObj();
							boolean isKanjiNameExact = false;
							boolean isPhoneExact = false;
							boolean isDataSharingFlagNo = false;
							
							
							
							// Suspect Name Changes Start
							for(TCRMOrganizationNameBObj orgNameBObj: vectorOrgNameSuspects){
								if("1001".equals(orgNameBObj.getNameUsageType())){
									String oname = orgNameBObj.getOrganizationName();
									String suspectname = null;
									if(oname!=null &&  StringUtils.isNonBlank(oname)){
									suspectname = oname;
									}
									if(sourceKanjiNameList.contains(suspectname)){
										isKanjiNameExact=true;
										break;
									}
								}
								
							}
						
							
							// Suspect Name Changes End
							
							//Suspect Phone Changes Start
							for(TCRMPartyContactMethodBObj contactMethod: vectorContactSuspects){
								if("1024".equals(contactMethod.getContactMethodUsageType())
										||"1025".equals(contactMethod.getContactMethodUsageType())
										||"1026".equals(contactMethod.getContactMethodUsageType())
										||"1027".equals(contactMethod.getContactMethodUsageType())
										||"1028".equals(contactMethod.getContactMethodUsageType())
										||"1029".equals(contactMethod.getContactMethodUsageType())){
									String suspectPhone = contactMethod.getTCRMContactMethodBObj().getReferenceNumber();
									if(sourcePhoneList.contains(suspectPhone)){
										isPhoneExact = true;
										break;
									}
								}
							}
							//Suspect Phone Changes End
							
							
							
							//Suspect DataSharing changes start
							Vector<XDataSharingBObj> vecSuspectDataSharingObject = new Vector<XDataSharingBObj>();
							List<String> suspectDataSharingList = new ArrayList<String>();
							responseSuspectXDataSharingObj = dseaAdditionsExtsComponent.getDataSharingByPartyId(suspectPartyId, control);				
							if (responseSuspectXDataSharingObj != null) {
								vecSuspectDataSharingObject = (Vector<XDataSharingBObj>) responseSuspectXDataSharingObj
										.getData();
								if(vecSuspectDataSharingObject!=null){
									if (vecSuspectDataSharingObject.get(0).getStatus()
											.getStatus() == DWLStatus.FATAL) {
										throwExceptionifTxnFails(responseSuspectXDataSharingObj, sb);
									}
								}
							} else {
								throwExceptionifTxnFails(responseSuspectXDataSharingObj, sb);
							}

							if(vecSuspectDataSharingObject!=null && vecSuspectDataSharingObject.size()>0){					
								for(XDataSharingBObj xDataSharingBObj : vecSuspectDataSharingObject){
									String dataSharingRetailerFlag = xDataSharingBObj.getRetailerFlag();
									if(dataSharingRetailerFlag!= null && (dataSharingRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.DATASHARING_FLAG_N))){
										String dataSharingFlag = xDataSharingBObj.getDataSharingFlag();
										if(dataSharingFlag!=null){
											suspectDataSharingList.add(dataSharingFlag);	
										}
									}
								}					
							}
							//Suspect DataSharing changes end
							
							if ((sourceDataSharingList!=null && sourceDataSharingList.size()>0 && (sourceDataSharingList.contains(ExternalRuleConstant.DATASHARING_FLAG_N))) 
									&& (suspectDataSharingList!=null && suspectDataSharingList.size()>0 && (suspectDataSharingList.contains(ExternalRuleConstant.DATASHARING_FLAG_N)))){
								isDataSharingFlagNo = true;
							}
							
							
							//Start Upgrade
							if(!isDataSharingFlagNo){
							if ((isKanjiNameExact && isPhoneExact)){
								tempSuspectBObj.setAdjustedMatchCategoryCode(ExternalRuleConstant.MATCH_CAT_CODE_A1);
								tempSuspectBObj.setMatchCategoryAdjustmentType(ExternalRuleConstant.MATCH_CAT_ADJUSTMENT_TYPE_UPGRADE_B_TO_A1_ORG_JPN);
								tempSuspectBObj.setMatchCategoryAdjustmentValue(ExternalRuleConstant.MATCH_CAT_ADJUSTMENT_VALUE_UPGRADE_B_TO_A1_ORG_JPN);
								
							}
							}
						 }
						
						
	            
					  }
				  }
			   }	
			
					
					
					
				}
			
			}catch (Exception e) {
					e.printStackTrace();
					throw new BusinessProxyException();

				}
	  }
		// Start of Match Upgrade for AU_NZ By Shashi (20-08-2021)
		
		public void matchRulesAdjustForAUNZ(TCRMPartyBObj tcrmPartyBObj, DWLControl control, String Market) throws Exception {
	           //Upgrade B suspect to A1 - Exact Name & Email
		  


		    	XPersonBObjExt tcrmPersonBObj = null;
				Vector<TCRMSuspectBObj> vecSuspectObject = new Vector<TCRMSuspectBObj>();
			
				String sourcePartyId = null;
				String suspectPartyId = null;
						
			
				
		    
				if (tcrmPartyBObj instanceof XPersonBObjExt) {

					tcrmPersonBObj = (XPersonBObjExt) tcrmPartyBObj;
					control = tcrmPersonBObj.getControl();							
					vecSuspectObject = tcrmPersonBObj.getItemsTCRMSuspectBObj();
					sourcePartyId = tcrmPersonBObj.getPartyId();
					
				if(ExternalRuleConstant.MARKET_NAME_AUSTRALIA.equalsIgnoreCase(Market) 
						|| ExternalRuleConstant.MARKET_NAME_NEWZEALAND.equalsIgnoreCase(Market)){	

					Vector<XPersonNameBObjExt> vecSourcePersonNameBObj = new Vector<XPersonNameBObjExt>();
					vecSourcePersonNameBObj = tcrmPersonBObj.getItemsTCRMPersonNameBObj();
					List<String> sourceNameList = new ArrayList<String>();
					for(int i = 0; i<vecSourcePersonNameBObj.size();i++){
						if("1".equals(vecSourcePersonNameBObj.get(i).getNameUsageType())){
							String fName = vecSourcePersonNameBObj.get(i).getGivenNameOne();
							String lName = vecSourcePersonNameBObj.get(i).getLastName();
							if(fName!=null && lName!=null && StringUtils.isNonBlank(fName) && StringUtils.isNonBlank(lName)){
							sourceNameList.add(fName.concat(lName)); 
							}
						}
					}
						
					
					
					Vector<TCRMPartyContactMethodBObj> vecSourceEmailBObj = new Vector<TCRMPartyContactMethodBObj>();
					vecSourceEmailBObj = tcrmPersonBObj.getItemsTCRMPartyContactMethodBObj();
					List<String> sourceEmailList = new ArrayList<String>();
					
					for(TCRMPartyContactMethodBObj partyContactMethodBObj : vecSourceEmailBObj){
						if("1018".equals(partyContactMethodBObj.getContactMethodUsageType())){
							String sourceEmail = partyContactMethodBObj.getTCRMContactMethodBObj().getReferenceNumber();
							if( sourceEmail!= null && !sourceEmail.equalsIgnoreCase(VALUE_DELETED)){
							sourceEmailList.add(sourceEmail); 
							}
						}
					}
					
					

				if (vecSuspectObject != null && vecSuspectObject.size() > 0) {
					for (TCRMSuspectBObj tempSuspectBObj : vecSuspectObject) {
						
						String suspectCatType = tempSuspectBObj.getMatchCategoryCode();
						 
						suspectPartyId = tempSuspectBObj.getSuspectPartyId();
						
						TCRMPartyComponent partyComponent = new TCRMPartyComponent();
						if (suspectCatType.equalsIgnoreCase(ExternalRuleConstant.SUSPECT_CATEGORY_VALUEB)) {
							
							TCRMPersonBObj suspectPersonBObj = partyComponent.getPerson(suspectPartyId, "1", control);
							Vector<TCRMPersonNameBObj> vectorPerNameSuspects = suspectPersonBObj.getItemsTCRMPersonNameBObj();
							Vector<TCRMPartyContactMethodBObj> vectorContactSuspects = suspectPersonBObj.getItemsTCRMPartyContactMethodBObj();
							Vector<TCRMPartyIdentificationBObj> vectorIdentSuspects = suspectPersonBObj.getItemsTCRMPartyIdentificationBObj();
							boolean isNameExact = false;
							boolean isEmailExact = false;
							
							
							
							
							for(TCRMPersonNameBObj personNameBObj: vectorPerNameSuspects){
								if("1".equals(personNameBObj.getNameUsageType())){
									String fname = personNameBObj.getGivenNameOne();
									String lname = personNameBObj.getLastName();
									String suspectname = null;
									if(fname!=null && lname != null && StringUtils.isNonBlank(fname) && StringUtils.isNonBlank(lname)){
									suspectname = fname.concat(lname);
									}
									if(sourceNameList.contains(suspectname)){
										isNameExact=true;
										break;
									}
								}
							}
							
							for(TCRMPartyContactMethodBObj contactMethod: vectorContactSuspects){
								if("1018".equals(contactMethod.getContactMethodUsageType())){
									String suspectEmail = contactMethod.getTCRMContactMethodBObj().getReferenceNumber();
									if(sourceEmailList.contains(suspectEmail)){
										isEmailExact = true;
										break;
									}
								}
							}
							
							
							
							//Start Upgrade
							if ((isNameExact && isEmailExact)){
								tempSuspectBObj.setAdjustedMatchCategoryCode(ExternalRuleConstant.MATCH_CAT_CODE_A1);
								tempSuspectBObj.setMatchCategoryAdjustmentType(ExternalRuleConstant.MATCH_CAT_ADJUSTMENT_TYPE_UPGRADE_B_TO_A1_PERSON_AU_NZ);
								tempSuspectBObj.setMatchCategoryAdjustmentValue(ExternalRuleConstant.MATCH_CAT_ADJUSTMENT_VALUE_UPGRADE_B_TO_A1_PERSON_AU_NZ);
								
							}
						 }
						
	            
					  }
				  }
			   }	
			}
	  }

}
		
