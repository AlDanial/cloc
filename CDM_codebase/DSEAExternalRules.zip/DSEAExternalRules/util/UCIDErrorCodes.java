package com.ibm.daimler.dsea.extrules.util;

import java.util.Map;

/**
 * This enum holds and describes error messages that can occur during the
 * generation of a UCID.
 * 
 * @author IBM
 * 
 */
public enum UCIDErrorCodes {
	/**
	 * DB Configuration Error. No (default) value available for the given
	 * CONFIGELEMENT. UCID cannot be generated.
	 */
	CDM_MDM_00000001("neither VALUE nor DEFAULT_VALUE found in CONFIGELEMENT where NAME= ?"),

	/**
	 * Invalid hash algorithm used. UCID cannot be generated.
	 */
	CDM_MDM_00000002("hash algorithm not available: ?"),

	/**
	 * Invalid encoding used. UCID cannot be generated.
	 */
	CDM_MDM_00000003("encoding not supported: ?"),

	/**
	 * An error occurred while closing a DB connection.
	 */
	CDM_MDM_00000004("QueryConnection cannot be closed: ?"),

	/**
	 * An error occurred while opening a DB connection. UCID cannot be
	 * generated.
	 */
	CDM_MDM_00000005("could not get a query connection"),

	/**
	 * Result retrieved from DB cannot be read as String. UCID cannot be
	 * generated.
	 */
	CDM_MDM_00000006("ResultSet cannot be read"),

	/**
	 * An error occurred while closing a ResultSet.
	 */
	CDM_MDM_00000007("ResultSet cannot be closed"),

	/**
	 * DB Configuration Error. Sequence number could not be retrieved from DB.
	 * UCID cannot be generated.
	 */
	CDM_MDM_00000008("sequence did not return result"),

	/**
	 * Wrong format of encrypted value. UCID cannot be generated.
	 */
	CDM_MDM_00000009("Encrypted value does not match expected format: ?");

	private final String errorMessage;

	private UCIDErrorCodes(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	/**
	 * Converts and returns the enum's name (e.g., CDM_MDM_00000001) into
	 * Daimler's official error ID format (e.g., CDM.MDM.00000001).
	 * 
	 * @return ID of error message in Daimler format
	 */
	public String getErrorId() {
		return this.name().replace('_', '.');
	}

	/**
	 * Returns a formatted error message in english and replaces multiple
	 * placeholders (Map.key) with new string values (Map.value). The format is:
	 * &lt;errorId&gt; - &lt;errorMessage&gt;
	 * 
	 * @param para
	 *            a <code>Map</code> object containing key/value-pairs with
	 *            placeholder and to-be-replaced value
	 * @return formatted error message with multiple (one or many) replaced
	 *         placeholder
	 */
	public String getFormattedError(Map<String, String> para) {
		String error = new String(errorMessage);
		for (Map.Entry<String, String> entry : para.entrySet()) {
			error = error.replace(entry.getKey(), entry.getValue());
		}

		return getErrorId() + " - " + error;
	}

	/**
	 * Returns a formatted error message in english and replaces the placeholder
	 * <code>match</code> with the substring <code>replace</code>. The format
	 * is: &lt;errorId&gt; - &lt;errorMessage&gt;
	 * 
	 * @param match
	 *            a string that needs to be replaced, e.g., "?"
	 * @param replace
	 *            a string that is used instead of <code>match</code>
	 * @return formatted error message with a single replaced placeholder
	 */
	public String getFormattedError(String match, String replace) {
		return getErrorId() + " - " + errorMessage.replace(match, replace);
	}

	/**
	 * Returns a formatted error message in english. The format is:
	 * &lt;errorId&gt; - &lt;errorMessage&gt;
	 * 
	 * @return formatted error message
	 */
	public String getFormattedError() {
		return getErrorId() + " - " + errorMessage;
	}

}