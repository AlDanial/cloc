/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[ed28c1194f832dc595a312f4277d8333]
 */

package com.ibm.daimler.dsea.extrules.behaviour;

import java.util.Vector;

import com.dwl.base.DWLControl;
import com.dwl.base.DWLResponse;
import com.dwl.base.IDWLErrorMessage;
import com.dwl.base.error.DWLError;
import com.dwl.base.error.DWLStatus;
import com.dwl.base.exception.DWLBaseException;
import com.dwl.base.extensionFramework.ClientJavaExtensionSet;
import com.dwl.base.extensionFramework.ExtensionParameters;
import com.dwl.tcrm.common.TCRMErrorCode;
import com.dwl.tcrm.coreParty.component.TCRMOrganizationBObj;
import com.dwl.tcrm.coreParty.component.TCRMPartyAddressBObj;
import com.dwl.tcrm.coreParty.component.TCRMPartyBObj;
import com.dwl.tcrm.coreParty.component.TCRMPartyComponent;
import com.dwl.tcrm.coreParty.component.TCRMPartyContactMethodBObj;
import com.dwl.tcrm.coreParty.component.TCRMPersonBObj;
import com.dwl.tcrm.utilities.TCRMClassFactory;
import com.ibm.daimler.dsea.component.DSEAAdditionsExtsComponent;
import com.ibm.daimler.dsea.component.XAddressGroupBObjExt;
import com.ibm.daimler.dsea.component.XContEquivBObjExt;
import com.ibm.daimler.dsea.component.XContactMethodGroupBObjExt;
import com.ibm.daimler.dsea.component.XIdentifierBObjExt;
import com.ibm.daimler.dsea.component.XOrgBObjExt;
import com.ibm.daimler.dsea.component.XPersonBObjExt;
import com.ibm.daimler.dsea.component.XPreferenceBObj;
import com.ibm.daimler.dsea.component.XPrivacyAgreementBObj;
import com.ibm.daimler.dsea.extrules.constant.DSEAExternalRulesComponentID;
import com.ibm.daimler.dsea.extrules.constant.DSEAExternalRulesErrorReasonCode;
import com.ibm.daimler.dsea.extrules.constant.ExternalRuleConstant;

/**
 * <!-- begin-user-doc --> <!-- end-user-doc -->
 *
 * This is a Java rule that extends the behavior of WCC. @see
 * com.dwl.base.extensionFramework.ClientJavaExtensionSet
 * 
 * @generated not
 */
public class GetPartyBehvExt extends ClientJavaExtensionSet {
	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 *
	 * The execute method will be called in case of extension activation.
	 *
	 * @generated not
	 */
	public void execute(ExtensionParameters params) {
		// MDM_TODO: CDKWB0018I Write customized business logic for the
		// extension here.
		Object aObject = params.getTransactionObjectHierarchy();
		TCRMPersonBObj tcrmPersonBObj = null;
		TCRMOrganizationBObj tcrmOrganizationBObj = null;
		DWLResponse response = null;
		DWLStatus status = null;
		DSEAAdditionsExtsComponent dseaAddComponent = new DSEAAdditionsExtsComponent();
		String locationGroupId = null;
		Vector<TCRMPartyAddressBObj> tcrmPartyAddress = null;
		Vector<TCRMPartyContactMethodBObj> tcrmContactMethodGroup = null;
		DWLControl control = null;
		DWLResponse response1 = null;
		String contId = null;
		String requestName = null;
		String marketName=null;
		String deleteFlagValue=null;
		Vector<XContEquivBObjExt> vecXcontEquivObj=new  Vector<XContEquivBObjExt>();
		String partyLastModDate=null;
		DWLControl controlParent = params.getControl();
		IDWLErrorMessage errorHandler = TCRMClassFactory.getErrorHandler();
		DWLStatus dwlStatus = params.getExtensionSetStatus();
		
		if (controlParent.get("request_name") != null) {
			requestName = (controlParent.get("request_name")).toString();
		}
		
		boolean value = false;
		
		if((requestName.equalsIgnoreCase(ExternalRuleConstant.SEARCHSUSPECT_WITHTASKMANAGEMENT)) || (requestName.equalsIgnoreCase(ExternalRuleConstant.SEARCHSUSPECT_WITHOUTTASKMANAGEMENT))
				|| (requestName.equalsIgnoreCase(ExternalRuleConstant.CREATESUSPECTS))){
			value = true;
		}
		
		if (!value) {
		try {
			if (aObject instanceof XPersonBObjExt) {
				tcrmPersonBObj = (XPersonBObjExt) aObject;
				control = tcrmPersonBObj.getControl();
				contId = tcrmPersonBObj.getPartyId();
				marketName=((XPersonBObjExt) aObject).getXMarketName();
				deleteFlagValue=((XPersonBObjExt) aObject).getDeleteFlag();
				vecXcontEquivObj=tcrmPersonBObj.getItemsTCRMAdminContEquivBObj();
				partyLastModDate=((XPersonBObjExt) aObject).getXLastModifiedSystemDate();
				tcrmPartyAddress = tcrmPersonBObj
						.getItemsTCRMPartyAddressBObj();
				tcrmContactMethodGroup = tcrmPersonBObj
						.getItemsTCRMPartyContactMethodBObj();
			}
			if (aObject instanceof XOrgBObjExt) {
				tcrmOrganizationBObj = (XOrgBObjExt) aObject;
				control = tcrmOrganizationBObj.getControl();
				contId = tcrmOrganizationBObj.getPartyId();
				marketName=((XOrgBObjExt) aObject).getXMarketName();
				deleteFlagValue=((XOrgBObjExt) aObject).getDeleteFlag();
				vecXcontEquivObj=tcrmOrganizationBObj.getItemsTCRMAdminContEquivBObj();
				partyLastModDate=((XOrgBObjExt) aObject).getXLastModifiedSystemDate();
				tcrmPartyAddress = tcrmOrganizationBObj
						.getItemsTCRMPartyAddressBObj();
				tcrmContactMethodGroup = tcrmOrganizationBObj
						.getItemsTCRMPartyContactMethodBObj();
			}
			if (tcrmPartyAddress != null && tcrmPartyAddress.size()>0) {
				for (int j = 0; j < tcrmPartyAddress.size(); j++) {
					TCRMPartyAddressBObj tcrmAddress = tcrmPartyAddress.get(j);
					locationGroupId = tcrmAddress.getPartyAddressIdPK();
					response = dseaAddComponent
							.getXPreferenceByLocationGroupId(locationGroupId,
									control);
					response1 = dseaAddComponent
							.getXPrivAgreementByLocationGroupId(
									locationGroupId, control);
					if (response != null) {
						@SuppressWarnings("unchecked")
						Vector<XPreferenceBObj> xpref = (Vector<XPreferenceBObj>) response
								.getData();
						if (xpref != null && xpref.size() > 0) {
							XAddressGroupBObjExt xAddressGroup = (XAddressGroupBObjExt) tcrmAddress;
							xAddressGroup.setXPreferenceBObj(xpref.get(0));
						}
					}
					if (response1 != null) {

						@SuppressWarnings("unchecked")
						Vector<XPrivacyAgreementBObj> xprivAgreement = (Vector<XPrivacyAgreementBObj>) response1
								.getData();
						if (xprivAgreement != null && xprivAgreement.size() > 0) {
							XAddressGroupBObjExt xAddressGroup = (XAddressGroupBObjExt) tcrmAddress;
							xAddressGroup
									.setXPrivacyAgreementBObj(xprivAgreement
											.get(0));
						}
					}
					
					//Fix to populate the SFAddressID for all the addresses in get response: 29Oct 2021
					TCRMPartyComponent partyComponent = new TCRMPartyComponent();
					XAddressGroupBObjExt addressViaGranularTransaction = (XAddressGroupBObjExt) partyComponent.getPartyAddressByIdPK(locationGroupId, control);
					if(null != addressViaGranularTransaction)
					{
						String sFAddressID = addressViaGranularTransaction.getSFAddressId();
						if(null != sFAddressID)
						{
							XAddressGroupBObjExt xAddressGroup = (XAddressGroupBObjExt) tcrmAddress;
							xAddressGroup.setSFAddressId(sFAddressID);
						}
					}
				}

			}
			if (tcrmContactMethodGroup != null && tcrmContactMethodGroup.size()>0) {
				for (int k = 0; k < tcrmContactMethodGroup.size(); k++) {
					TCRMPartyContactMethodBObj tcrmContactMethod = tcrmContactMethodGroup
							.get(k);
					locationGroupId = tcrmContactMethod
							.getPartyContactMethodIdPK();
					response = dseaAddComponent
							.getXPreferenceByLocationGroupId(locationGroupId,
									control);
					response1 = dseaAddComponent
							.getXPrivAgreementByLocationGroupId(
									locationGroupId, control);
					if (response != null) {
						Vector<XPreferenceBObj> xpref = (Vector<XPreferenceBObj>) response
								.getData();
						if (xpref != null && xpref.size() > 0) {
							XContactMethodGroupBObjExt xContactMethodGroup = (XContactMethodGroupBObjExt) tcrmContactMethod;
							xContactMethodGroup
									.setXPreferenceBObj(xpref.get(0));
							
						}
					}
					if (response1 != null) {
						Vector<XPrivacyAgreementBObj> xprivAgreement = (Vector<XPrivacyAgreementBObj>) response1
								.getData();
						if (xprivAgreement != null && xprivAgreement.size() > 0) {
							XContactMethodGroupBObjExt xContactMethodGroup = (XContactMethodGroupBObjExt) tcrmContactMethod;
							xContactMethodGroup
									.setXPrivacyAgreementBObj(xprivAgreement
											.get(0));
						}
					}
				}
			}
			
			// Japan Market UCID Changes
			if(marketName !=null && marketName.equalsIgnoreCase(ExternalRuleConstant.JAPAN_MARKET_NAME))
			{
				XContEquivBObjExt ucidObj=new XContEquivBObjExt();
				
				Vector<XContEquivBObjExt> contequivToBeDeleted = new Vector<XContEquivBObjExt>();
				//Vector<XContEquivBObjExt> vecXcontEquivObj=
				for(XContEquivBObjExt currXCont : vecXcontEquivObj)
				{
					if(currXCont.getAdminSystemType().equalsIgnoreCase(ExternalRuleConstant.UCID_SOURCE_TYPE))
					{
						ucidObj=currXCont;
						if(ucidObj!=null)
						{
							contequivToBeDeleted.add(ucidObj);
							XIdentifierBObjExt newPartyIdentificationBObj=new  XIdentifierBObjExt();
						newPartyIdentificationBObj.setIdentificationType(ExternalRuleConstant.UCID_TYPE);
						newPartyIdentificationBObj.setIdentificationValue(ExternalRuleConstant.UCID_TEXT);
						newPartyIdentificationBObj.setIdentificationNumber(ucidObj.getAdminPartyId());
						newPartyIdentificationBObj.setXLastModifiedSystemDate(partyLastModDate);
						newPartyIdentificationBObj.setIdentificationDescription(ucidObj.getDescription());
						
						newPartyIdentificationBObj.setPartyId(ucidObj.getPartyId());

						newPartyIdentificationBObj.setControl(control);
						((TCRMPartyBObj) aObject)
								.setTCRMPartyIdentificationBObj(newPartyIdentificationBObj);
						}
					}
				}
				
				((TCRMPartyBObj) aObject).getItemsTCRMAdminContEquivBObj().removeAll(contequivToBeDeleted);
				
				
			}
			
		} catch (DWLBaseException e) {
			
			e.printStackTrace();			
			DWLError error = errorHandler.getErrorMessage(DSEAExternalRulesComponentID.GET_PARTY_BEHV_EXT, TCRMErrorCode.READ_RECORD_ERROR, 
					DSEAExternalRulesErrorReasonCode.GET_PARTY_RETRIEVE_FAILED, control, new String[0]);
			dwlStatus.addError(error);
			dwlStatus.setStatus(DWLStatus.FATAL);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			DWLError error = errorHandler.getErrorMessage(DSEAExternalRulesComponentID.GET_PARTY_BEHV_EXT, TCRMErrorCode.READ_RECORD_ERROR, 
					DSEAExternalRulesErrorReasonCode.GET_PARTY_RETRIEVE_FAILED, control, new String[0]);
			dwlStatus.addError(error);
			dwlStatus.setStatus(DWLStatus.FATAL);
		}
		
		}
	}
}
