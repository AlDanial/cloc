/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[a8678faa81ea3a091ed172faa53fac29]
 */

package com.ibm.daimler.dsea.extrules.behaviour;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import com.dwl.base.DWLControl;
import com.dwl.base.DWLResponse;
import com.dwl.base.IDWLErrorMessage;
import com.dwl.base.error.DWLError;
import com.dwl.base.error.DWLStatus;
import com.dwl.base.extensionFramework.ClientJavaExtensionSet;
import com.dwl.base.extensionFramework.ExtensionParameters;
import com.dwl.base.logging.DWLLoggerManager;
import com.dwl.base.logging.IDWLLogger;
import com.dwl.tcrm.common.TCRMErrorCode;
import com.dwl.tcrm.coreParty.component.TCRMOrganizationBObj;
import com.dwl.tcrm.coreParty.component.TCRMPartyBObj;
import com.dwl.tcrm.coreParty.component.TCRMPartyPrivPrefBObj;
import com.dwl.tcrm.coreParty.component.TCRMPersonBObj;
import com.dwl.tcrm.coreParty.component.TCRMPersonNameBObj;
import com.dwl.tcrm.coreParty.component.TCRMSuspectBObj;
import com.dwl.tcrm.coreParty.interfaces.ISuspectProcessor;
import com.dwl.tcrm.utilities.TCRMClassFactory;
import com.dwl.unifi.tx.exception.BusinessProxyException;
//import com.ibm.daimler.dsea.composite.util.CommonUtil;
import com.ibm.daimler.dsea.extrules.constant.DSEAExternalRulesComponentID;
import com.ibm.daimler.dsea.extrules.constant.DSEAExternalRulesErrorReasonCode;
import com.ibm.daimler.dsea.extrules.constant.ExternalRuleConstant;
import com.ibm.daimler.dsea.extrules.util.ExternalRuleUtil;

import com.ibm.daimler.dsea.component.XOrgBObjExt;
import com.ibm.daimler.dsea.component.XPersonBObjExt;


/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * This is a Java rule that extends the behavior of WCC. @see
 * com.dwl.base.extensionFramework.ClientJavaExtensionSet
 * 
 * @generated
 */
public class CreateSuspectsBehvExt extends ClientJavaExtensionSet {

	private static final IDWLLogger logger = DWLLoggerManager
			.getLogger(CreateSuspectsBehvExt.class);

	//private IDWLErrorMessage errHandler;
	//IDWLErrorMessage errorHandler = TCRMClassFactory.getErrorHandler();

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 *
	 * The execute method will be called in case of extension activation.
	 *
	 * @generated
	 */
	public void execute(ExtensionParameters params) {
		Object aObject = params.getTransactionObjectHierarchy();
		ExternalRuleUtil externalRuleUtil = new ExternalRuleUtil();
		IDWLErrorMessage errorHandler = TCRMClassFactory.getErrorHandler();
		DWLStatus dwlStatus = params.getExtensionSetStatus();
		TCRMPartyBObj tcrmPartyObject = (TCRMPartyBObj) aObject;
		XPersonBObjExt tcrmPersonBObj = null;
		XOrgBObjExt tcrmOrgBObj = null;
		String marketName = null;
		DWLControl control = null;
		try {
			if (aObject == null) {
				logger.error("DaimlerPartyBehavior: The ObjectHierarchy is null");
				return;
			}
			if (aObject instanceof XPersonBObjExt) {
				tcrmPersonBObj = (XPersonBObjExt)aObject;
				
//				System.out.println("Person Obj Create Suspect" + tcrmPersonBObj.toXML("TCRM", "MDMDomains.xsd", 0, null, false));
				control = tcrmPersonBObj.getControl();
				marketName = tcrmPersonBObj.getXMarketName();
			}
			if (aObject instanceof XOrgBObjExt) {
				tcrmOrgBObj = (XOrgBObjExt) aObject;
				control = tcrmOrgBObj.getControl();
				marketName = tcrmOrgBObj.getXMarketName();
			}
			
			//Japan Market
			if (marketName != null
					&& marketName
							.equalsIgnoreCase(ExternalRuleConstant.JAPAN_MARKET_NAME)) {
				/*externalRuleUtil.matchRulesAdjustForJapan(tcrmPartyObject,
						control);*/
				}
			//Korea Market
		/*	else if(marketName != null && marketName.equalsIgnoreCase(ExternalRuleConstant.KOREA_MARKET_NAME)){
				//externalRuleUtil.matchRulesAdjustForKorea(tcrmPartyObject,control);
			}*/
		}
		catch (Exception e) {
			e.printStackTrace();
			DWLError error = errorHandler.getErrorMessage(DSEAExternalRulesComponentID.CREATE_SUSPECTS_BEHV_EXT, TCRMErrorCode.INSERT_RECORD_ERROR, 
					DSEAExternalRulesErrorReasonCode.CREATE_SUSPECTS_FAILED, control, new String[0]);
			dwlStatus.addError(error);
			dwlStatus.setStatus(DWLStatus.FATAL);
		}

	}

}
