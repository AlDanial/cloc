/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[bb645e45de86980c35095abcf7cbec5c]
 */

package com.ibm.daimler.dsea.extrules.behaviour;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.sql.Timestamp;
import java.util.Vector;

import com.dwl.base.DWLControl;
import com.dwl.base.DWLResponse;
import com.dwl.base.IDWLErrorMessage;
import com.dwl.base.error.DWLError;
import com.dwl.base.error.DWLStatus;
import com.dwl.base.extensionFramework.ClientJavaExtensionSet;
import com.dwl.base.extensionFramework.ExtensionParameters;
import com.dwl.base.util.DWLDateFormatter;
import com.dwl.base.util.DWLDateTimeUtilities;
import com.dwl.base.notification.CommonNotification;
import com.dwl.base.notification.NotificationLocal;
import com.dwl.base.notification.NotificationLocalHome;
import com.dwl.base.performance.PerformanceMonitor;
import com.dwl.base.performance.PerformanceMonitorConfig;
import com.dwl.base.performance.PerformanceMonitorFactory;
import com.dwl.base.util.ServiceLocator;
import com.dwl.tcrm.common.TCRMControlKeys;
import com.dwl.tcrm.common.TCRMErrorCode;
import com.dwl.tcrm.coreParty.component.TCRMConsolidatedPartyBObj;
import com.dwl.tcrm.coreParty.component.TCRMPartyBObj;
import com.dwl.tcrm.coreParty.component.TCRMPartyIdentificationBObj;
import com.dwl.tcrm.coreParty.component.TCRMPartyListBObj;
import com.dwl.tcrm.coreParty.component.TCRMPersonBObj;
import com.dwl.tcrm.exception.TCRMException;
import com.dwl.tcrm.utilities.TCRMClassFactory;
import com.dwl.unifi.tx.exception.BusinessProxyException;
import com.ibm.daimler.dsea.component.DSEAAdditionsExtsComponent;
import com.ibm.daimler.dsea.component.XConsentBObj;
import com.ibm.daimler.dsea.component.XContactRelBObjExt;
import com.ibm.daimler.dsea.component.XContractRelJPNBObj;
import com.ibm.daimler.dsea.component.XCustomerRetailerJPNBObj;
import com.ibm.daimler.dsea.component.XCustomerVehicleJPNBObj;
import com.ibm.daimler.dsea.component.XDataSharingBObj;

import com.ibm.daimler.dsea.component.XPersonBObjExt;
import com.ibm.daimler.dsea.component.XOrgBObjExt;
import com.ibm.daimler.dsea.component.XVRCollapseBObj;
import com.ibm.daimler.dsea.extrules.constant.DSEAExternalRulesComponentID;
import com.ibm.daimler.dsea.extrules.constant.DSEAExternalRulesErrorReasonCode;
import com.ibm.daimler.dsea.extrules.constant.ExternalRuleConstant;
import com.ibm.daimler.dsea.extrules.util.DaimlerNotificationUtil;
import com.ibm.daimler.dsea.extrules.util.ExternalRuleUtil;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * This is a Java rule that extends the behavior of WCC. @see
 * com.dwl.base.extensionFramework.ClientJavaExtensionSet
 * 
 * @generated not
 */
public class CollapseMultiplePartiesBehvExt extends ClientJavaExtensionSet {
	
	String transactionStatus="FATAL";
	private final static com.dwl.base.logging.IDWLLogger logger = com.dwl.base.logging.DWLLoggerManager.getLogger(CollapseMultiplePartiesBehvExt.class);	
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The execute method will be called in case of extension activation.
     *
     * @generated not
     */
    public void execute(ExtensionParameters params) {
    	// MDM_TODO: CDKWB0018I Write customized business logic for the extension here.    	
    	DWLControl control = null;   	
    	ExternalRuleUtil externalRuleUtil = new ExternalRuleUtil();   
    	IDWLErrorMessage errorHandler = TCRMClassFactory.getErrorHandler();
		DWLStatus dwlStatus = params.getExtensionSetStatus();
		String sourceRearch = null;
    	try {
			
			TCRMConsolidatedPartyBObj consolidatedParty = (TCRMConsolidatedPartyBObj)params.getWorkingObjectHierarchy();
			TCRMPartyBObj party = consolidatedParty.getTCRMPartyBObj();
			control = party.getControl();
			TCRMPartyListBObj partlyList = consolidatedParty.getTCRMPartyListBObj();
			Vector<TCRMPartyBObj> vecParty = partlyList.getItemsTCRMPartyBObj();
			
			TCRMPartyBObj party1 = (TCRMPartyBObj) vecParty.get(0);
			String partyType = party1.getPartyType();
			String xMarketName = null;
			if(ExternalRuleConstant.PERSON_ORG_CODE_P.equalsIgnoreCase(partyType))
			{
				XPersonBObjExt vecPerson = (XPersonBObjExt)party1;
				xMarketName = vecPerson.getXMarketName();
				sourceRearch = vecPerson.getXSourceTypeFlag();
			}
			else if(ExternalRuleConstant.PERSON_ORG_CODE_O.equalsIgnoreCase(partyType))
			{
				XOrgBObjExt vecOrg = (XOrgBObjExt)party1;
				xMarketName = vecOrg.getXMarketName();
				sourceRearch = vecOrg.getXSourceTypeFlag();
			}
			
			if(!(ExternalRuleConstant.JAPAN_MARKET_NAME.equalsIgnoreCase(xMarketName)))
			{	

				if(ExternalRuleConstant.MARKET_NAME_AUSTRALIA.equalsIgnoreCase(xMarketName) || ExternalRuleConstant.MARKET_NAME_NEWZEALAND.equalsIgnoreCase(xMarketName))
				{
					/*externalRuleUtil.survivedCRRDetailsAus(vecParty,party, xMarketName, control);
					String flag = control.getClientTransactionName();
					if(!"Y".equals(flag)|| flag == null){
						externalRuleUtil.survivedCVRDetailsAus(vecParty,party, control);
					}
					else{

						DSEAAdditionsExtsComponent dseaAdditionsExtsComponent= new DSEAAdditionsExtsComponent();
						TCRMPartyBObj newPartyBObj = null;
						String suspectContIDs = new String();
						
						for (int i = 0; i < vecParty.size(); i++) {
							
							newPartyBObj = (TCRMPartyBObj) vecParty.elementAt(i);
							suspectContIDs += newPartyBObj.getPartyId()+",";
						}
						
						String suspectIDs=suspectContIDs.substring(0, suspectContIDs.length()-1);
						DWLResponse response = new DWLResponse();
						StringBuffer sb = new StringBuffer();
						Date d = new Date(System.currentTimeMillis());
						SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SS");
						String date = sdf.format(d);
						XVRCollapseBObj vrCollapseDetails = new XVRCollapseBObj();
						vrCollapseDetails.setSuspectIds(suspectIDs);
						vrCollapseDetails.setGoldenContId(party.getPartyId());
						vrCollapseDetails.setFlag("N");
						vrCollapseDetails.setMarketName(xMarketName);
						vrCollapseDetails.setCreateDate(date);
						vrCollapseDetails.setControl(control);
						try{
							response = dseaAdditionsExtsComponent.addXVRCollapse(vrCollapseDetails);
							if (response.getStatus().getStatus() == DWLStatus.FATAL) {
								sb.append("Adding List of Suspect IDs Failed");
								throw new BusinessProxyException(sb.toString());
							}
						} catch (Exception e){
							e.printStackTrace();
							sb.append("Adding List of Suspect IDs Failed");
							throw new BusinessProxyException(sb.toString());
						}
						
					}
					externalRuleUtil.survivedCCRDetailsForAus(vecParty,party, control);*/
				}
				//May 21, 2019 : Added by Sameeha for MVP Cluster 2: Start

				else if(ExternalRuleConstant.HUNGARY_MARKET_NAME.equalsIgnoreCase(xMarketName) 
						|| ExternalRuleConstant.ROMANIA_MARKET_NAME.equalsIgnoreCase(xMarketName)
						|| ExternalRuleConstant.SLOVAKIA_MARKET_NAME.equalsIgnoreCase(xMarketName)){
					
					externalRuleUtil.survivedCRRDetailsHRS(vecParty,party, xMarketName, control);
					externalRuleUtil.surviveConsentDetailsForHRS(vecParty, party, control);
					
					//Start of change for special VR merge Cl2 TF
					String flag = control.getClientTransactionName();
					if(!"Y".equals(flag)|| flag == null){
						externalRuleUtil.survivedCVRDetailsHRS(vecParty,party, control);
					}
					else{
						handleSpecialVR(vecParty, party, xMarketName, control);
					}
					
					//End of change for special VR merge Cl2 TF
					
					externalRuleUtil.surviveDataSharingDetailsForHRS(vecParty, party, control);

					
				}
				//May 21, 2019 : Added by Sameeha for MVP Cluster 2: End
				
				
				else if(ExternalRuleConstant.SOUTH_AFRICA_MARKET_NAME.equalsIgnoreCase(xMarketName)){
					
					externalRuleUtil.survivedCRRDetailsZA(vecParty,party, xMarketName, control);
					externalRuleUtil.surviveConsentDetailsForZA(vecParty, party, control);
					
					//Start of change for special VR merge ZA TF
					String flag = control.getClientTransactionName();
					if(!"Y".equals(flag)|| flag == null){
						externalRuleUtil.survivedCVRDetailsZA(vecParty,party, control);
					}
					else{
						handleSpecialVR(vecParty, party, xMarketName, control);
					}
					
					//End of change for special VR merge ZA TF
					externalRuleUtil.surviveDataSharingDetailsForZA(vecParty, party, control);

				}
				
				//July 18, 2019 : Added by Pushpraj for MVP Cluster 3: Start

				else if(ExternalRuleConstant.AEM_MARKETS.contains(xMarketName)
						&& !ExternalRuleConstant.MARKET_NAME_MIDDLEEAST.equalsIgnoreCase(xMarketName)
						){
					
					externalRuleUtil.survivedCRRDetailsAEM(vecParty,party, xMarketName, control);
					externalRuleUtil.surviveConsentDetailsForAEM(vecParty, party, control);
					
					//Start of change for special VR merge Cl3 TF
					String flag = control.getClientTransactionName();
					if(!"Y".equals(flag)|| flag == null){
						externalRuleUtil.survivedCVRDetailsAEM(vecParty,party, control);
					}
					else{
						handleSpecialVR(vecParty, party, xMarketName, control);
					}
					
					//End of change for special VR merge Cl3 TF
					
					externalRuleUtil.surviveDataSharingDetailsForAEM(vecParty, party, control);

					
				}
				//July 18, 2019 : Added by Pushpraj for MVP Cluster 3: End
				
				else
				{
					
						// Changed for KOR REARCH
						if(!ExternalRuleConstant.KOREA_MARKET_NAME.equalsIgnoreCase(xMarketName)){
							externalRuleUtil.survivedCRRDetails(vecParty,party, control);
							externalRuleUtil.survivedContractFSDetails(vecParty,party, control);
						}					
					
					if(!ExternalRuleConstant.KOREA_MARKET_NAME.equalsIgnoreCase(xMarketName)){
						
						String flag = control.getClientTransactionName();
						if(!"Y".equals(flag)|| flag == null){
							externalRuleUtil.survivedCVRDetails(vecParty,party, control);
						}
						else{
							DSEAAdditionsExtsComponent dseaAdditionsExtsComponent= new DSEAAdditionsExtsComponent();
							TCRMPartyBObj newPartyBObj = null;
							String suspectContIDs = new String();
							
							for (int i = 0; i < vecParty.size(); i++) {
								
								newPartyBObj = (TCRMPartyBObj) vecParty.elementAt(i);
								suspectContIDs += newPartyBObj.getPartyId()+",";
							}
							
							String suspectIDs=suspectContIDs.substring(0, suspectContIDs.length()-1);
							DWLResponse response = new DWLResponse();
							StringBuffer sb = new StringBuffer();
							Date d = new Date(System.currentTimeMillis());
							SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SS");
							String date = sdf.format(d);
							XVRCollapseBObj vrCollapseDetails = new XVRCollapseBObj();
							vrCollapseDetails.setSuspectIds(suspectIDs);
							vrCollapseDetails.setGoldenContId(party.getPartyId());
							vrCollapseDetails.setFlag("N");
							vrCollapseDetails.setMarketName(xMarketName);
							vrCollapseDetails.setCreateDate(date);
							vrCollapseDetails.setControl(control);
							try{
								response = dseaAdditionsExtsComponent.addXVRCollapse(vrCollapseDetails);
								if (response.getStatus().getStatus() == DWLStatus.FATAL) {
									sb.append("Adding List of Suspect IDs Failed");
									throw new BusinessProxyException(sb.toString());
								}
							} catch (Exception e){
								e.printStackTrace();
								sb.append("Adding List of Suspect IDs Failed");
								throw new BusinessProxyException(sb.toString());
							}
							
						}
					}
					else{
						
						externalRuleUtil.survivedDataSharingDetailsForKorRearch(vecParty,party, control);
						
						// Commented for REARCH
						/*if(!"REARCH".equals(sourceRearch)){
							// Commented for REARCH
							String flag = control.getClientTransactionName();
							if(!"Y".equals(flag)|| flag == null){
								externalRuleUtil.survivedCVRDetailsForKorea(vecParty,party, control);
							}
							else{
								DSEAAdditionsExtsComponent dseaAdditionsExtsComponent= new DSEAAdditionsExtsComponent();
								TCRMPartyBObj newPartyBObj = null;
								String suspectContIDs = new String();
								
								for (int i = 0; i < vecParty.size(); i++) {
									
									newPartyBObj = (TCRMPartyBObj) vecParty.elementAt(i);
									suspectContIDs += newPartyBObj.getPartyId()+",";
								}
								
								String suspectIDs=suspectContIDs.substring(0, suspectContIDs.length()-1);
								DWLResponse response = new DWLResponse();
								StringBuffer sb = new StringBuffer();
								Date d = new Date(System.currentTimeMillis());
								SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SS");
								String date = sdf.format(d);
								XVRCollapseBObj vrCollapseDetails = new XVRCollapseBObj();
								vrCollapseDetails.setSuspectIds(suspectIDs);
								vrCollapseDetails.setGoldenContId(party.getPartyId());
								vrCollapseDetails.setFlag("N");
								vrCollapseDetails.setMarketName(xMarketName);
								vrCollapseDetails.setCreateDate(date);
								
								vrCollapseDetails.setControl(control);
								try{
									response = dseaAdditionsExtsComponent.addXVRCollapse(vrCollapseDetails);
									if (response.getStatus().getStatus() == DWLStatus.FATAL) {
										sb.append("Adding List of Suspect IDs Failed");
										throw new BusinessProxyException(sb.toString());
									}
								} catch (Exception e){
									e.printStackTrace();
									sb.append("Adding List of Suspect IDs Failed");
									throw new BusinessProxyException(sb.toString());
								}
								
							}
						
						externalRuleUtil.survivedCCRDetails(vecParty,party, control);
						}else{
							externalRuleUtil.survivedDataSharingDetailsForKorRearch(vecParty,party, control);
						}*/
						
					}
					//externalRuleUtil.survivedCCRDetails(vecParty,party, control);
				}
				if( ExternalRuleConstant.MARKET_NAME_BRAZIL.equalsIgnoreCase(xMarketName))
				{
					externalRuleUtil.survivedCRRDetailsMVP(vecParty,party, xMarketName, control);
					externalRuleUtil.surviveConsentDetailsForMVP(vecParty, party, control);
				}
				else{
					if(!ExternalRuleConstant.MARKET_NAME_TURKEY.equalsIgnoreCase(xMarketName)
						&& (! ExternalRuleConstant.MARKET_NAME_THAILAND.equalsIgnoreCase(xMarketName))
						&& (! ExternalRuleConstant.MARKET_NAME_MALAYSIA.equalsIgnoreCase(xMarketName))
						&& (! ExternalRuleConstant.KOREA_MARKET_NAME.equalsIgnoreCase(xMarketName))
						&& (! ExternalRuleConstant.MARKET_NAME_INDIA.equalsIgnoreCase(xMarketName))){
						externalRuleUtil.survivedCCRDetails(vecParty,party, control);
					}
					if(!ExternalRuleConstant.HUNGARY_MARKET_NAME.equalsIgnoreCase(xMarketName) 
						&& (! ExternalRuleConstant.ROMANIA_MARKET_NAME.equalsIgnoreCase(xMarketName))
						&& (! ExternalRuleConstant.SLOVAKIA_MARKET_NAME.equalsIgnoreCase(xMarketName))
						&& (! ExternalRuleConstant.SOUTH_AFRICA_MARKET_NAME.equalsIgnoreCase(xMarketName))
						&& (! ExternalRuleConstant.MARKET_NAME_TURKEY.equalsIgnoreCase(xMarketName))
						&& (! ExternalRuleConstant.AEM_MARKETS.contains(xMarketName))
						&& (! ExternalRuleConstant.MARKET_NAME_INDIA.equalsIgnoreCase(xMarketName))){
						externalRuleUtil.survivedCVRDetails(vecParty,party, control);
					}
				}
			}
		
			if(xMarketName!=null && ExternalRuleConstant.JAPAN_MARKET_NAME.equalsIgnoreCase(xMarketName))
			{			
				/*Vector<XConsentBObj> vecConsentDetailsJPNBObj = externalRuleUtil.fetchAllConsentDetails(vecParty,control);				
				Vector<XDataSharingBObj> vecDataSharingDetailsJPNBObj = externalRuleUtil.fetchAllDataSharingDetails(vecParty,control);				
				Vector<XContractRelJPNBObj> vecContractRelDetailsJPNBObj = externalRuleUtil.fetchAllContractRelDetails(vecParty,control);				
				Vector<XCustomerRetailerJPNBObj> vecCustomeRetailerDetailsJPNBObj = externalRuleUtil.fetchAllCustomerRetailerDetails(vecParty,control);				
				Vector<XContactRelBObjExt> vecContactRelationshipDetailsJPNBObj = externalRuleUtil.fetchAllCustomerRelationshipDetails(vecParty,control);				
				Vector<XCustomerVehicleJPNBObj> vecCustomerVehicleDetailsJPNBObj = externalRuleUtil.fetchAllCustomerVehcileDetails(vecParty,control);*/
				
				/*externalRuleUtil.survivedCRRDetailsForJapan(vecParty,party, control);
				String flag = control.getClientTransactionName();
				if(!"Y".equals(flag)|| flag == null){
					externalRuleUtil.survivedCVRDetailsForJapan(vecParty,party, control);
				}
				else{
					DSEAAdditionsExtsComponent dseaAdditionsExtsComponent= new DSEAAdditionsExtsComponent();
					TCRMPartyBObj newPartyBObj = null;
					String suspectContIDs = new String();
					
					for (int i = 0; i < vecParty.size(); i++) {
						
						newPartyBObj = (TCRMPartyBObj) vecParty.elementAt(i);
						suspectContIDs += newPartyBObj.getPartyId()+",";
					}
					
					String suspectIDs=suspectContIDs.substring(0, suspectContIDs.length()-1);
					DWLResponse response = new DWLResponse();
					StringBuffer sb = new StringBuffer();
					Date d = new Date(System.currentTimeMillis());
					SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SS");
					String date = sdf.format(d);
					XVRCollapseBObj vrCollapseDetails = new XVRCollapseBObj();
					vrCollapseDetails.setSuspectIds(suspectIDs);
					vrCollapseDetails.setGoldenContId(party.getPartyId());
					vrCollapseDetails.setFlag("N");
					vrCollapseDetails.setMarketName(xMarketName);
					vrCollapseDetails.setCreateDate(date);
					
					vrCollapseDetails.setControl(control);
					try{
						response = dseaAdditionsExtsComponent.addXVRCollapse(vrCollapseDetails);
						if (response.getStatus().getStatus() == DWLStatus.FATAL) {
							sb.append("Adding List of Suspect IDs Failed");
							throw new BusinessProxyException(sb.toString());
						}
					} catch (Exception e){
						e.printStackTrace();
						sb.append("Adding List of Suspect IDs Failed");
						throw new BusinessProxyException(sb.toString());
					}
					
				}
				externalRuleUtil.survivedCCRDetailsForJapan(vecParty,party, control);
				externalRuleUtil.surviveConsentDetailsForJapan(vecParty, party, control);*/
				externalRuleUtil.surviveDataSharingDetailsForJapan(vecParty, party, control);
				/*externalRuleUtil.survivedContractFSDetailsForJapan(vecParty,party, control);
				
				if(vecContactRelationshipDetailsJPNBObj!=null && vecContactRelationshipDetailsJPNBObj.size()>0){
					externalRuleUtil.surviveCustomerRelationshipForJapanPerformance(vecContactRelationshipDetailsJPNBObj, party, control);
				}
				
				if(vecCustomeRetailerDetailsJPNBObj!=null && vecCustomeRetailerDetailsJPNBObj.size()>0){
					externalRuleUtil.surviveCustomerRetailerForJapanPerformance(vecCustomeRetailerDetailsJPNBObj, party, control);
				}			
				if(vecConsentDetailsJPNBObj!=null && vecConsentDetailsJPNBObj.size()>0){
					externalRuleUtil.surviveConsentDetailsForJapanPerformance(vecConsentDetailsJPNBObj, party, control);
				}
				if(vecDataSharingDetailsJPNBObj!=null && vecDataSharingDetailsJPNBObj.size()>0){
					externalRuleUtil.surviveDataSharingDetailsForJapanPerformance(vecDataSharingDetailsJPNBObj, party, control);
				}
				if(vecContractRelDetailsJPNBObj!=null && vecContractRelDetailsJPNBObj.size()>0){
					externalRuleUtil.surviveContractFSDetailsForJapanPerformance(vecContractRelDetailsJPNBObj, party, control);
				}*/
				
				/*if(vecCustomerVehicleDetailsJPNBObj!=null && vecCustomerVehicleDetailsJPNBObj.size()>0){
					externalRuleUtil.surviveCustomerVehicleForJapanPerformance(vecCustomerVehicleDetailsJPNBObj, party, control);
				}*/
			}
			if (xMarketName != null) {
				DaimlerNotificationUtil notificationUtil = new DaimlerNotificationUtil();
				notificationUtil.sendCollapseNotificationToQueue(
						consolidatedParty, xMarketName, control);
			}
			

		} catch (Exception e) {
			e.printStackTrace();			
			DWLError error = errorHandler.getErrorMessage(DSEAExternalRulesComponentID.COLLAPSE_MULTIPLE_PARTIES_BEHV_EXT, TCRMErrorCode.INSERT_RECORD_ERROR, 
					DSEAExternalRulesErrorReasonCode.COLLAPSE_MULTIPLE_PARTIES_FAILED, control, new String[0]);
			dwlStatus.addError(error);
			dwlStatus.setStatus(DWLStatus.FATAL);
		}
    }
    
    /**
     * 
     * @param vecParty
     * @param party
     * @param xMarketName
     * @param control
     * @throws Exception 
     */
    void handleSpecialVR(Vector<TCRMPartyBObj> vecParty, TCRMPartyBObj party, String xMarketName, DWLControl control) throws Exception{


		DSEAAdditionsExtsComponent dseaAdditionsExtsComponent= new DSEAAdditionsExtsComponent();
		TCRMPartyBObj newPartyBObj = null;
		String suspectContIDs = new String();
		
		for (int i = 0; i < vecParty.size(); i++) {
			
			newPartyBObj = (TCRMPartyBObj) vecParty.elementAt(i);
			suspectContIDs += newPartyBObj.getPartyId()+",";
		}
		
		String suspectIDs=suspectContIDs.substring(0, suspectContIDs.length()-1);
		DWLResponse response = new DWLResponse();
		StringBuffer sb = new StringBuffer();
		Date d = new Date(System.currentTimeMillis());
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SS");
		String date = sdf.format(d);
		XVRCollapseBObj vrCollapseDetails = new XVRCollapseBObj();
		vrCollapseDetails.setSuspectIds(suspectIDs);
		vrCollapseDetails.setGoldenContId(party.getPartyId());
		vrCollapseDetails.setFlag("N");
		vrCollapseDetails.setMarketName(xMarketName);
		vrCollapseDetails.setCreateDate(date);
		vrCollapseDetails.setControl(control);
		try{
			response = dseaAdditionsExtsComponent.addXVRCollapse(vrCollapseDetails);
			if (response.getStatus().getStatus() == DWLStatus.FATAL) {
				sb.append("Adding List of Suspect IDs Failed");
				throw new BusinessProxyException(sb.toString());
			}
		} catch (Exception e){
			e.printStackTrace();
			sb.append("Adding List of Suspect IDs Failed");
			throw new BusinessProxyException(sb.toString());
		}
		
	
    }

    
}


