/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[0d176f250091cdca162c7dcfdaed6719]
 */

package com.ibm.daimler.dsea.extrules.behaviour;

import java.util.Vector;

import com.dwl.base.DWLControl;
import com.dwl.base.extensionFramework.ClientJavaExtensionSet;
import com.dwl.base.extensionFramework.ExtensionParameters;
import com.dwl.base.util.StringUtils;
import com.dwl.tcrm.coreParty.component.ProbabilisticOrganizationSearchResultBObj;
import com.dwl.tcrm.coreParty.component.ProbabilisticPersonSearchResultBObj;
import com.dwl.tcrm.coreParty.component.TCRMAdminContEquivBObj;
import com.dwl.tcrm.coreParty.component.TCRMContactMethodBObj;
import com.dwl.tcrm.coreParty.component.TCRMOrganizationBObj;
import com.dwl.tcrm.coreParty.component.TCRMOrganizationNameBObj;
import com.dwl.tcrm.coreParty.component.TCRMOrganizationSearchResultBObj;
import com.dwl.tcrm.coreParty.component.TCRMPartyComponent;
import com.dwl.tcrm.coreParty.component.TCRMPartyContactMethodBObj;
import com.dwl.tcrm.coreParty.component.TCRMPartyIdentificationBObj;
import com.dwl.tcrm.coreParty.component.TCRMPersonBObj;
import com.dwl.tcrm.coreParty.component.TCRMPersonNameBObj;
import com.dwl.tcrm.coreParty.component.TCRMPersonSearchResultBObj;
import com.dwl.tcrm.exception.TCRMException;
import com.ibm.daimler.dsea.component.XAddressBObjExt;
import com.ibm.daimler.dsea.component.XAddressGroupBObjExt;
import com.ibm.daimler.dsea.component.XContEquivBObjExt;
import com.ibm.daimler.dsea.component.XContactMethodGroupBObjExt;
import com.ibm.daimler.dsea.component.XIdentifierBObjExt;
import com.ibm.daimler.dsea.component.XOrgBObjExt;
import com.ibm.daimler.dsea.component.XPersonBObjExt;
import com.ibm.daimler.dsea.component.XPrivacyAgreementBObj;
import com.ibm.daimler.dsea.extrules.constant.ExternalRuleConstant;

/**
 * <!-- begin-user-doc --> <!-- end-user-doc -->
 *
 * This is a Java rule that extends the behavior of WCC. @see
 * com.dwl.base.extensionFramework.ClientJavaExtensionSet
 * 
 * @generated not
 */
public class SearchProbabilisticBehvExt extends ClientJavaExtensionSet {
	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 *
	 * The execute method will be called in case of extension activation.
	 *
	 * @generated not
	 */
	public void execute(ExtensionParameters params) {
		// MDM_TODO: CDKWB0018I Write customized business logic for the
		// extension here.

		Vector aObject = (Vector) params.getTransactionObjectHierarchy();

		if (aObject.size() > 0) {
			Vector<ProbabilisticPersonSearchResultBObj> vecSearchPersonBObj = new Vector<ProbabilisticPersonSearchResultBObj>();
			Vector<ProbabilisticOrganizationSearchResultBObj> vecSearchOrgBObj = new Vector<ProbabilisticOrganizationSearchResultBObj>();
			TCRMPersonSearchResultBObj personSearchResultBObj = null;
			TCRMPersonSearchResultBObj personSearchFinalResultBObj = null;
			TCRMOrganizationSearchResultBObj orgSearchResultBObj = null;
			TCRMOrganizationSearchResultBObj orgSearchFinalResultBObj = null;
			DWLControl control = null;
			String partyId = null;
			String identificationType = null;
			TCRMPersonBObj tcrmPersonFinalBObj = null;
			TCRMOrganizationBObj tcrmOrgFinalBObj = null;
			Vector<TCRMPartyIdentificationBObj> vecIdentificationBObj = new Vector<TCRMPartyIdentificationBObj>();
			TCRMAdminContEquivBObj adminContequivBObj = null;
			TCRMPartyComponent partyComponent = new TCRMPartyComponent();
			String marketNameInput = null;
			String marketNameDB = null;
			Vector<ProbabilisticPersonSearchResultBObj> vecFinalSearchPersonBObj = new Vector<ProbabilisticPersonSearchResultBObj>();
			Vector<ProbabilisticPersonSearchResultBObj> vecRemovedSearchPersonBObj = new Vector<ProbabilisticPersonSearchResultBObj>();
			Vector<ProbabilisticOrganizationSearchResultBObj> vecFinalSearchOrgBObj = new Vector<ProbabilisticOrganizationSearchResultBObj>();
			Vector<ProbabilisticOrganizationSearchResultBObj> vecRemovedSearchOrgBObj = new Vector<ProbabilisticOrganizationSearchResultBObj>();
			
			//Changes start for Japan Market
			Vector<TCRMAdminContEquivBObj> vecAdminContequivBObj = new Vector<TCRMAdminContEquivBObj>();
			//Changes end for Japan Market
			
			//Changes start for Korea Market
			Vector<XIdentifierBObjExt> vecIdentifierBObj = new Vector<XIdentifierBObjExt>();			
			Vector<TCRMOrganizationNameBObj> vecOrgNameBObjs = new Vector<TCRMOrganizationNameBObj>();
			Vector<TCRMPartyContactMethodBObj> vecContactMethodBObjs = new Vector<TCRMPartyContactMethodBObj>();
			//Changes end for Korea Market
			
			// STS Declartion of attributes
			TCRMPersonBObj newPersonBObjSTS =null;
			TCRMOrganizationBObj organizationBObj=null;
			Vector<TCRMPersonNameBObj> vecPersonNameBObj = new  Vector<TCRMPersonNameBObj>();
			Vector<TCRMOrganizationNameBObj> vecOrganizationNameBObjs= new Vector<TCRMOrganizationNameBObj>();
			Vector<XAddressGroupBObjExt> vecAddressBObjExts = new Vector<XAddressGroupBObjExt>();
			
			
			Vector<XIdentifierBObjExt> vecIdentifierBrasilBObj = new Vector<XIdentifierBObjExt>();
			Vector<TCRMPartyContactMethodBObj> vecContactMethodBrasilBObjs = new Vector<TCRMPartyContactMethodBObj>();
			//BR Changes
			if ((aObject.get(0)) instanceof ProbabilisticPersonSearchResultBObj) {
				vecSearchPersonBObj = aObject;
				String clientSystemNameSTS=null;
				for (ProbabilisticPersonSearchResultBObj probPerson : vecSearchPersonBObj) {
					control = probPerson.getControl();
					clientSystemNameSTS=control.getClientSystemName();
					personSearchResultBObj = probPerson
							.getTCRMPersonSearchResultBObj();
					partyId = personSearchResultBObj.getPartyId();
					try {
						if (((ExternalRuleConstant.MARKET_NAME_AUSTRALIA.equalsIgnoreCase(marketNameInput))  && clientSystemNameSTS!=null 
								&& clientSystemNameSTS.equalsIgnoreCase(ExternalRuleConstant.CLIENT_SYS_NAME_STS_AUS))
								||(ExternalRuleConstant.MARKET_NAME_BRAZIL.equalsIgnoreCase(marketNameInput)))
						{
							tcrmPersonFinalBObj = partyComponent.getPerson(partyId,
									ExternalRuleConstant.INQUIRY_LVL_1, control);	
						}
						
						else
						{
						tcrmPersonFinalBObj = partyComponent.getPerson(partyId,
								ExternalRuleConstant.INQUIRY_LVL_0, control);
						}				
					} catch (TCRMException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					marketNameInput = (String) control.get("geographical_region");
					marketNameDB = ((XPersonBObjExt) tcrmPersonFinalBObj).getXMarketName();
					
					if(marketNameInput!=null && marketNameDB!=null && (marketNameInput.equalsIgnoreCase(marketNameDB))){
						vecFinalSearchPersonBObj.add(probPerson);
					} else {
						
						vecRemovedSearchPersonBObj.add(probPerson);
					}
				}
				
				vecSearchPersonBObj.removeAll(vecRemovedSearchPersonBObj);
				
				
				if(vecFinalSearchPersonBObj!=null && vecFinalSearchPersonBObj.size()>0) {
				for (ProbabilisticPersonSearchResultBObj probPerson : vecFinalSearchPersonBObj) {
					control = probPerson.getControl();
			
					personSearchFinalResultBObj = probPerson
							.getTCRMPersonSearchResultBObj();
					partyId = personSearchFinalResultBObj.getPartyId();
					try {
						if ((ExternalRuleConstant.MARKET_NAME_AUSTRALIA.equalsIgnoreCase(marketNameInput)  && clientSystemNameSTS!=null 
								&& clientSystemNameSTS.equalsIgnoreCase(ExternalRuleConstant.CLIENT_SYS_NAME_STS_AUS) )
								||(ExternalRuleConstant.MARKET_NAME_BRAZIL.equalsIgnoreCase(marketNameInput)))
						{
							tcrmPersonFinalBObj = partyComponent.getPerson(partyId,
									ExternalRuleConstant.INQUIRY_LVL_1, control);	
						}
						else
						{
						tcrmPersonFinalBObj = partyComponent.getPerson(partyId,
								ExternalRuleConstant.INQUIRY_LVL_0, control);
						}//BR Change
					} catch (TCRMException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
					if(marketNameInput!=null && marketNameInput.equalsIgnoreCase(ExternalRuleConstant.JAPAN_MARKET_NAME)){
					
					vecIdentificationBObj = tcrmPersonFinalBObj
							.getItemsTCRMPartyIdentificationBObj();
					if (vecIdentificationBObj.size() > 0) {
						for (TCRMPartyIdentificationBObj identificationBObj : vecIdentificationBObj) {
							identificationType = identificationBObj
									.getIdentificationType();
							if (identificationType
									.equalsIgnoreCase(ExternalRuleConstant.UCID_TYPE) && identificationBObj.getIdentificationDescription()!=null && identificationBObj.getIdentificationDescription().equalsIgnoreCase(ExternalRuleConstant.MASTER_KEY)) {
								personSearchFinalResultBObj
										.setIdentificationType(identificationType);
								personSearchFinalResultBObj
										.setIdentificationTypeValue(identificationBObj
												.getIdentificationValue());
								personSearchFinalResultBObj
										.setIdentificationNum(identificationBObj
												.getIdentificationNumber());
							}
						}

					}
					
					// Changes start for Japan Market
					
					vecAdminContequivBObj = tcrmPersonFinalBObj
							.getItemsTCRMAdminContEquivBObj();
					if (vecAdminContequivBObj.size() > 0) {
						for (TCRMAdminContEquivBObj adminContequivBObj1 : vecAdminContequivBObj) {
							String adminSystemType = adminContequivBObj1
									.getAdminSystemType();
							String retailFlag = ((XContEquivBObjExt)adminContequivBObj1)
									.getXSourceRetailerFlag();
							if ((adminSystemType!=null && (adminSystemType
									.equalsIgnoreCase(ExternalRuleConstant.SOURCE_IDENTIFIER_TYPE_SFDC))) 
									&& (retailFlag!=null && (retailFlag.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_N)))) {
								personSearchFinalResultBObj
										.setAdminSystemType(adminSystemType);
								personSearchFinalResultBObj
										.setAdminSystemValue(adminContequivBObj1
										.getAdminSystemValue());
								personSearchFinalResultBObj
										.setAdminClientNum(adminContequivBObj1
										.getAdminPartyId());
							}
						}

					}
					// Changes end for Japan Market
					} else if(marketNameInput!=null &&  (
							marketNameInput.equalsIgnoreCase(ExternalRuleConstant.INDONESIA_MARKET_NAME)
							|| marketNameInput.equalsIgnoreCase(ExternalRuleConstant.VIETNAM_MARKET_NAME)
							|| marketNameInput.equalsIgnoreCase(ExternalRuleConstant.MARKET_NAME_BRAZIL)
							|| marketNameInput.equalsIgnoreCase(ExternalRuleConstant.SINGAPORE_MARKET_NAME)
							|| marketNameInput.equalsIgnoreCase(ExternalRuleConstant.HUNGARY_MARKET_NAME)
							|| marketNameInput.equalsIgnoreCase(ExternalRuleConstant.ROMANIA_MARKET_NAME)
							|| marketNameInput.equalsIgnoreCase(ExternalRuleConstant.SLOVAKIA_MARKET_NAME)
							|| ExternalRuleConstant.AEM_MARKETS.contains(marketNameInput)
							|| marketNameInput.equalsIgnoreCase(ExternalRuleConstant.SOUTH_AFRICA_MARKET_NAME)))
						{

						//Changes Start for MVP Market
						
						vecAdminContequivBObj = tcrmPersonFinalBObj.getItemsTCRMAdminContEquivBObj();
						if (vecAdminContequivBObj.size() > 0) {
							for (TCRMAdminContEquivBObj adminContequivBObj1 : vecAdminContequivBObj) {
								String adminSystemType = adminContequivBObj1.getAdminSystemType();
								String retailFlag = ((XContEquivBObjExt)adminContequivBObj1).getXSourceRetailerFlag();
								if (adminSystemType!=null && (adminSystemType.equalsIgnoreCase(ExternalRuleConstant.SOURCE_SYSTEM_TYPE_SFDC_MVP) 
										&& retailFlag!=null && retailFlag.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_N)) ){
									//SFDC ID
									personSearchFinalResultBObj.setAdminSystemType(adminSystemType);
									personSearchFinalResultBObj.setAdminSystemValue(adminContequivBObj1.getAdminSystemValue());
									personSearchFinalResultBObj.setAdminClientNum(adminContequivBObj1.getAdminPartyId());
									
									
								}else if (adminSystemType!=null && adminSystemType.equalsIgnoreCase(ExternalRuleConstant.SOURCE_SYSTEM_TYPE_UCID_MVP)){
									//UCID
									personSearchFinalResultBObj.setIdentificationType(ExternalRuleConstant.UCID_TYPE);
									personSearchFinalResultBObj.setIdentificationTypeValue(ExternalRuleConstant.UCID_TEXT);
									personSearchFinalResultBObj.setIdentificationNum(adminContequivBObj1.getAdminPartyId());
								}
							}

						}
						// Changes end for MVP Market
						
					} else if(marketNameInput!=null && marketNameInput.equalsIgnoreCase(ExternalRuleConstant.KOREA_MARKET_NAME)){

						//Changes Start for Korea Market
						
						vecAdminContequivBObj = tcrmPersonFinalBObj.getItemsTCRMAdminContEquivBObj();
						if (vecAdminContequivBObj.size() > 0) {
							for (TCRMAdminContEquivBObj adminContequivBObj1 : vecAdminContequivBObj) {
								String adminSystemType = adminContequivBObj1.getAdminSystemType();
								String retailFlag = ((XContEquivBObjExt)adminContequivBObj1).getXSourceRetailerFlag();
								if (adminSystemType!=null && (adminSystemType.equalsIgnoreCase(ExternalRuleConstant.SOURCE_IDENTIFIER_TYPE_SFDC) 
										&& retailFlag!=null && retailFlag.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_N)) ){
									//SFDC ID
									if(adminContequivBObj1.getDescription().equalsIgnoreCase(ExternalRuleConstant.CHARACTER_Y)){
										personSearchFinalResultBObj.setAdminSystemType(adminSystemType);
										personSearchFinalResultBObj.setAdminSystemValue(adminContequivBObj1.getAdminSystemValue());
										personSearchFinalResultBObj.setAdminClientNum(adminContequivBObj1.getAdminPartyId());
									}
									
								}else if (adminSystemType!=null && adminSystemType.equalsIgnoreCase(ExternalRuleConstant.ADMIN_SYS_TP_UCID)){
									//UCID
									if(adminContequivBObj1.getDescription().equalsIgnoreCase(ExternalRuleConstant.CHARACTER_Y)){
										personSearchFinalResultBObj.setIdentificationType(ExternalRuleConstant.UCID_TYPE);
										personSearchFinalResultBObj.setIdentificationTypeValue(ExternalRuleConstant.UCID_TEXT);
										personSearchFinalResultBObj.setIdentificationNum(adminContequivBObj1.getAdminPartyId());
									}
								}
							}

						}
						// Changes end for Korea Market
						
						
					}
					else{
						
						vecIdentificationBObj = tcrmPersonFinalBObj.getItemsTCRMPartyIdentificationBObj();
						if (vecIdentificationBObj.size() > 0) {
							for (TCRMPartyIdentificationBObj identificationBObj : vecIdentificationBObj) {
								identificationType = identificationBObj
										.getIdentificationType();
								if (identificationType
										.equalsIgnoreCase(ExternalRuleConstant.UCID_TYPE)) {
									personSearchFinalResultBObj
											.setIdentificationType(identificationType);
									personSearchFinalResultBObj
											.setIdentificationTypeValue(identificationBObj
													.getIdentificationValue());
									personSearchFinalResultBObj
											.setIdentificationNum(identificationBObj
													.getIdentificationNumber());
								}
							}

						}
						
						if (tcrmPersonFinalBObj.getItemsTCRMAdminContEquivBObj() != null
								&& tcrmPersonFinalBObj
										.getItemsTCRMAdminContEquivBObj().size() > 0) {
							adminContequivBObj = (TCRMAdminContEquivBObj) tcrmPersonFinalBObj
									.getItemsTCRMAdminContEquivBObj().get(0);
		
							personSearchFinalResultBObj
									.setAdminSystemType(adminContequivBObj
											.getAdminSystemType());
							personSearchFinalResultBObj
									.setAdminSystemValue(adminContequivBObj
											.getAdminSystemValue());
							personSearchFinalResultBObj
									.setAdminClientNum(adminContequivBObj
											.getAdminPartyId());
						}
						
						
					}

					

					// Start Removing unnecessary tags
					personSearchFinalResultBObj.setAddressId(null);
					personSearchFinalResultBObj.setAddrLineOne(null);
					personSearchFinalResultBObj.setAddressFormatInd(null);
					personSearchFinalResultBObj.setAddrLineThree(null);
					personSearchFinalResultBObj.setAddrLineTwo(null);
					personSearchFinalResultBObj.setBuildingName(null);
					personSearchFinalResultBObj.setCityName(null);
					personSearchFinalResultBObj.setContactMethodId(null);
					personSearchFinalResultBObj
							.setContactMethodReferenceNumber(null);
					personSearchFinalResultBObj.setContactMethodType(null);
					personSearchFinalResultBObj.setContractNum(null);
					personSearchFinalResultBObj.setContactMethodValue(null);
					personSearchFinalResultBObj.setCountryType(null);
					personSearchFinalResultBObj.setCountryValue(null);
					personSearchFinalResultBObj.setCountyCode(null);
					personSearchFinalResultBObj.setDateOfBirth(null);
					personSearchFinalResultBObj.setPhoneAreaCode(null);
					personSearchFinalResultBObj.setPhoneExchange(null);
					personSearchFinalResultBObj.setPhoneExtension(null);
					personSearchFinalResultBObj.setLatitudeDegrees(null);
					personSearchFinalResultBObj.setLongtitudeDegrees(null);
					personSearchFinalResultBObj.setPartyId(null);
					personSearchFinalResultBObj.setPartyType(null);
					personSearchFinalResultBObj.setPersonNameId(null);
					personSearchFinalResultBObj.setPhoneAreaCode(null);
					personSearchFinalResultBObj.setPhoneExchange(null);
					personSearchFinalResultBObj.setPhoneExtension(null);
					personSearchFinalResultBObj.setPhoneNumber(null);
					personSearchFinalResultBObj.setPhoneticCityName(null);
					personSearchFinalResultBObj.setPhoneticGivenNameFour(null);
					personSearchFinalResultBObj.setPhoneticGivenNameOne(null);
					personSearchFinalResultBObj.setPhoneticGivenNameThree(null);
					personSearchFinalResultBObj.setPhoneticGivenNameTwo(null);
					personSearchFinalResultBObj.setPhoneticLastName(null);
					personSearchFinalResultBObj.setPnGivenNameFour(null);
					personSearchFinalResultBObj.setPnGivenNameOne(null);
					personSearchFinalResultBObj.setPnGivenNameThree(null);
					personSearchFinalResultBObj.setPnGivenNameTwo(null);
					personSearchFinalResultBObj.setPnLastName(null);
					personSearchFinalResultBObj.setPnSuffix(null);
					personSearchFinalResultBObj.setPostDirectional(null);
					personSearchFinalResultBObj.setPreDirectional(null);
					personSearchFinalResultBObj.setProvState(null);
					personSearchFinalResultBObj.setProvStateType(null);
					personSearchFinalResultBObj.setProvStateValue(null);
					personSearchFinalResultBObj.setStreetName(null);
					personSearchFinalResultBObj.setStreetNumber(null);
					personSearchFinalResultBObj.setStreetPrefix(null);
					personSearchFinalResultBObj.setStreetSuffix(null);
					personSearchFinalResultBObj.setTelephoneNum(null);
					personSearchFinalResultBObj.setTempHolder(null);
					personSearchFinalResultBObj.setZipPostalCode(null);
					personSearchFinalResultBObj.setPartyActiveIndicator(null);
					personSearchFinalResultBObj.setResultNumber(null);
					personSearchFinalResultBObj.setResultsFound(null);
					personSearchFinalResultBObj.setGivenNameFour(null);

					personSearchFinalResultBObj.setGivenNameThree(null);
					personSearchFinalResultBObj.setGivenNameTwo(null);
					personSearchFinalResultBObj.setHouseNum(null);
					// End Removing unnecessary tags
					
					// 2018-11-21 Changes for Australia Market Digital App TDS: Start
					
					if (!((ExternalRuleConstant.MARKET_NAME_AUSTRALIA.equalsIgnoreCase(marketNameInput) 
							|| ExternalRuleConstant.MARKET_NAME_NEWZEALAND.equalsIgnoreCase(marketNameInput))
							&& StringUtils.isNonBlank(control.getRequestOrigin()) && ExternalRuleConstant.SEARCH_PERSON_DIG_APPS.equalsIgnoreCase(control.getRequestOrigin())
						//BR CHange
							|| ((ExternalRuleConstant.MARKET_NAME_BRAZIL.equalsIgnoreCase(marketNameInput))
									&& StringUtils.isNonBlank(control.getRequestOrigin()) && ExternalRuleConstant.SEARCH_PERSON_DIGITAL_APP_Brasil.equalsIgnoreCase(control.getRequestOrigin()))))
					{
						personSearchFinalResultBObj.setGender(null);
						personSearchFinalResultBObj.setGivenNameOne(null);
					}
					

					// 2018-11-21 Changes for Australia Market Digital App TDS: End
					

					//Start: Changes for Korea Market Digital App STouch
					if (!((ExternalRuleConstant.KOREA_MARKET_NAME.equalsIgnoreCase(marketNameInput)) 
							&& StringUtils.isNonBlank(control.getCustomerEnvironment()) && ExternalRuleConstant.SEARCH_PERSON_DIGITAL_APP.equalsIgnoreCase(control.getCustomerEnvironment())
							//BR Change
							|| ((ExternalRuleConstant.MARKET_NAME_BRAZIL.equalsIgnoreCase(marketNameInput))
							&& StringUtils.isNonBlank(control.getRequestOrigin()) && ExternalRuleConstant.SEARCH_PERSON_DIGITAL_APP_Brasil.equalsIgnoreCase(control.getRequestOrigin())))){
						personSearchFinalResultBObj.setLastName(null);
					}
					//End: Changes for Korea Market Digital All STouch
					
					//Start: Changes for Brasil (Phone and CPF Id) SEARCH_PERSON_DIGITAL_APP_Brasil
					
					if ((ExternalRuleConstant.MARKET_NAME_BRAZIL.equalsIgnoreCase(marketNameInput)) 
							&& StringUtils.isNonBlank(control.getRequestOrigin()) && ExternalRuleConstant.SEARCH_PERSON_DIGITAL_APP_Brasil.equalsIgnoreCase(control.getRequestOrigin()))
					{
						
						vecIdentifierBrasilBObj = tcrmPersonFinalBObj.getItemsTCRMPartyIdentificationBObj();
						for (XIdentifierBObjExt identifier : vecIdentifierBrasilBObj){
							if ("1039".equalsIgnoreCase(identifier.getIdentificationType())){
								personSearchFinalResultBObj.setAddrLineOne(identifier.getIdentificationNumber());
							} else {
								personSearchFinalResultBObj.setAddrLineOne(null);
							}
						}
						
						 
						 vecContactMethodBObjs = tcrmPersonFinalBObj.getItemsTCRMPartyContactMethodBObj();
						for (TCRMPartyContactMethodBObj contactMethods : vecContactMethodBObjs ){
							
							 if ("1049".equalsIgnoreCase(contactMethods.getContactMethodUsageType())){
								 //needs to be changed
								 personSearchFinalResultBObj.setPhoneAreaCode(contactMethods.getTCRMContactMethodBObj().getReferenceNumber());
							 }
							 if ("1050".equalsIgnoreCase(contactMethods.getContactMethodUsageType())){
								 personSearchFinalResultBObj.setPhoneExchange(contactMethods.getTCRMContactMethodBObj().getReferenceNumber());
							 }
							 if ("1051".equalsIgnoreCase(contactMethods.getContactMethodUsageType())){
								 personSearchFinalResultBObj.setPhoneExtension(contactMethods.getTCRMContactMethodBObj().getReferenceNumber());
							 }
							 if ("1053".equalsIgnoreCase(contactMethods.getContactMethodUsageType())){
								 personSearchFinalResultBObj.setLatitudeDegrees(contactMethods.getTCRMContactMethodBObj().getReferenceNumber());
							 }
						}
						
						
					}
						
					
					
					// End: Changes for Brasil (Phone and CPF Id)
					
					
					//START : STS - New Source system for AUS, needs some extra fields to be shown in the search person response.
					if (ExternalRuleConstant.MARKET_NAME_AUSTRALIA.equalsIgnoreCase(marketNameInput)  && clientSystemNameSTS!=null 
							&& clientSystemNameSTS.equalsIgnoreCase(ExternalRuleConstant.CLIENT_SYS_NAME_STS_AUS) ){
						try {	
						// Add First Name and Last name in response 
						vecPersonNameBObj = tcrmPersonFinalBObj.getItemsTCRMPersonNameBObj();
						for(TCRMPersonNameBObj newTCRMPersonNameBObj: vecPersonNameBObj){
							//System.err.println("newTCRMPersonNameBObj.getNameUsageType()-----"+newTCRMPersonNameBObj.getNameUsageType());
							if(newTCRMPersonNameBObj.getNameUsageType().equalsIgnoreCase(ExternalRuleConstant.NAME_USAGE_TYPE_LEGAL)){
								personSearchFinalResultBObj.setGivenNameOne(newTCRMPersonNameBObj.getGivenNameOne());
								personSearchFinalResultBObj.setLastName(newTCRMPersonNameBObj.getLastName());
							}
						
						}
						//Added Birthdate-for STS - AUS
						personSearchFinalResultBObj.setDateOfBirth(tcrmPersonFinalBObj.getBirthDate());
						
						// STS-AUS customer do not want to see any type code, they just need to see values which describes the content
						personSearchFinalResultBObj.setIdentificationType(null);
						personSearchFinalResultBObj.setAdminSystemType(null);
						
						newPersonBObjSTS= new TCRMPersonBObj();
						newPersonBObjSTS.setPartyActiveIndicator(null);
//						if(null!=tcrmPersonFinalBObj.getSourceIdentifierType())
//							newPersonBObjSTS.setSourceIdentifierType(tcrmPersonFinalBObj.getSourceIdentifierType());
						if(null!=tcrmPersonFinalBObj.getSourceIdentifierValue())
							newPersonBObjSTS.setSourceIdentifierValue(tcrmPersonFinalBObj.getSourceIdentifierValue());
						// Add All address of person in response in response
						Vector<XAddressGroupBObjExt> newAddressObjectSet= new Vector<XAddressGroupBObjExt>();
						vecAddressBObjExts= tcrmPersonFinalBObj.getItemsTCRMPartyAddressBObj();
						
						if(null!=vecAddressBObjExts && vecAddressBObjExts.size()!=0){
							newAddressObjectSet=setAddressFieldsInresponse(vecAddressBObjExts);
							newPersonBObjSTS.getItemsTCRMPartyAddressBObj().addAll(newAddressObjectSet);

						
						}
						
						//Add all contact methods of person in response
						Vector<XContactMethodGroupBObjExt> vecTCRMPartyContactMethodBObj = new Vector<XContactMethodGroupBObjExt>();
						Vector<XContactMethodGroupBObjExt> vecTosetContactMethodBObj = new Vector<XContactMethodGroupBObjExt>();
						vecTCRMPartyContactMethodBObj=tcrmPersonFinalBObj.getItemsTCRMPartyContactMethodBObj();
						if(null!=vecTCRMPartyContactMethodBObj && vecTCRMPartyContactMethodBObj.size()!=0)
						{
							vecTosetContactMethodBObj=setContactMethodBObjInResposne(vecTCRMPartyContactMethodBObj);
							newPersonBObjSTS.getItemsTCRMPartyContactMethodBObj().addAll(vecTosetContactMethodBObj);
							
						}
						
//						//Add all SFDC IDs (WS+Retail) of person in response
//						Vector<TCRMAdminContEquivBObj> vecAdminContEquivBObjs= new Vector<TCRMAdminContEquivBObj>();
//						Vector<TCRMAdminContEquivBObj> vecTosetAdminContEquivBObjs= new Vector<TCRMAdminContEquivBObj>();
//						vecAdminContequivBObj=tcrmPersonFinalBObj.getItemsTCRMAdminContEquivBObj();
//						if(null!=vecAdminContequivBObj && vecAdminContequivBObj.size()!=0){
//							vecTosetAdminContEquivBObjs=setSFDCidsforsearchResult(vecAdminContequivBObj);
//							newPersonBObjSTS.getItemsTCRMAdminContEquivBObj().addAll(vecTosetAdminContEquivBObjs); 
//						}
//						
						if(null!=newPersonBObjSTS){
							Vector<TCRMPersonBObj> vecPersonBObjs = new Vector<TCRMPersonBObj>();
							vecPersonBObjs.addElement(newPersonBObjSTS);
							//vecPersonBObjs.get(0).addRecord().
						
					
							//personSearchFinalResultBObj.setAdditionalResultDetail(new Vector());
							personSearchFinalResultBObj.setAdditionalResultDetail(vecPersonBObjs);
							personSearchFinalResultBObj.setComponentID(null);
						}				
												
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}	
						
						
					}
					//END : STS - New Source system for AUS, needs some extra fields to be shown in the search person response.
					
				}
				
			}

			}

			if (aObject.size() > 0 && (aObject.get(0)) instanceof ProbabilisticOrganizationSearchResultBObj) {
				vecSearchOrgBObj = aObject;
				String clientSystemNameSTS=null;
				
				for (ProbabilisticOrganizationSearchResultBObj probOrg : vecSearchOrgBObj) {
					control = probOrg.getControl();
					orgSearchResultBObj = probOrg.getTCRMOrganizationSearchResultBObj();
					partyId = orgSearchResultBObj.getPartyId();
					clientSystemNameSTS=control.getClientSystemName();
					marketNameInput = (String) control.get("geographical_region");
					try {
						if (ExternalRuleConstant.MARKET_NAME_AUSTRALIA.equalsIgnoreCase(marketNameInput)  && clientSystemNameSTS!=null 
								&& clientSystemNameSTS.equalsIgnoreCase(ExternalRuleConstant.CLIENT_SYS_NAME_STS_AUS) )
						{
							tcrmOrgFinalBObj = partyComponent.getOrganization(
									partyId, ExternalRuleConstant.INQUIRY_LVL_1,
									control);	
						}
						else
						{
						tcrmOrgFinalBObj = partyComponent.getOrganization(
								partyId, ExternalRuleConstant.INQUIRY_LVL_0,
								control);
						}
					} catch (TCRMException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					marketNameInput = (String) control.get("geographical_region");
					marketNameDB = ((XOrgBObjExt) tcrmOrgFinalBObj).getXMarketName();
					
					if(marketNameInput!=null && marketNameDB!=null && (marketNameInput.equalsIgnoreCase(marketNameDB))){
						vecFinalSearchOrgBObj.add(probOrg);
					} else {
						
						vecRemovedSearchOrgBObj.add(probOrg);
					}
				}
				
				vecSearchOrgBObj.removeAll(vecRemovedSearchOrgBObj);
				
				if(vecFinalSearchOrgBObj!=null && vecFinalSearchOrgBObj.size()>0) {
				for (ProbabilisticOrganizationSearchResultBObj probOrg : vecFinalSearchOrgBObj) {
					control = probOrg.getControl();					
					orgSearchFinalResultBObj = probOrg.getTCRMOrganizationSearchResultBObj();
					partyId = orgSearchFinalResultBObj.getPartyId();
					try {
						tcrmOrgFinalBObj = partyComponent.getOrganization(
								partyId, ExternalRuleConstant.INQUIRY_LVL_1,
								control);
					} catch (TCRMException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
					if(marketNameInput!=null && marketNameInput.equalsIgnoreCase(ExternalRuleConstant.JAPAN_MARKET_NAME)){
						
						vecIdentificationBObj = tcrmOrgFinalBObj
								.getItemsTCRMPartyIdentificationBObj();
						if (vecIdentificationBObj.size() > 0) {
							for (TCRMPartyIdentificationBObj identificationBObj : vecIdentificationBObj) {
								identificationType = identificationBObj
										.getIdentificationType();
								if (identificationType.equalsIgnoreCase(ExternalRuleConstant.UCID_TYPE) &&
										identificationBObj.getIdentificationDescription()!=null && identificationBObj.getIdentificationDescription().equalsIgnoreCase(ExternalRuleConstant.MASTER_KEY)) {
									orgSearchFinalResultBObj
											.setIdentificationType(identificationType);
									orgSearchFinalResultBObj
											.setIdentificationTypeValue(identificationBObj
													.getIdentificationValue());
									orgSearchFinalResultBObj
											.setIdentificationNum(identificationBObj
													.getIdentificationNumber());
								}
							}

						}
						
						// Changes start for Japan Market
						
						vecAdminContequivBObj = tcrmOrgFinalBObj
								.getItemsTCRMAdminContEquivBObj();
						if (vecAdminContequivBObj.size() > 0) {
							for (TCRMAdminContEquivBObj adminContequivBObj1 : vecAdminContequivBObj) {
								String adminSystemType = adminContequivBObj1
										.getAdminSystemType();
								String retailFlag = ((XContEquivBObjExt)adminContequivBObj1)
										.getXSourceRetailerFlag();
								if ((adminSystemType!=null && (adminSystemType
										.equalsIgnoreCase(ExternalRuleConstant.SOURCE_IDENTIFIER_TYPE_SFDC))) 
										&& (retailFlag!=null && (retailFlag.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_N)))) {
									orgSearchFinalResultBObj
											.setAdminSystemType(adminSystemType);
									orgSearchFinalResultBObj
											.setAdminSystemValue(adminContequivBObj1
											.getAdminSystemValue());
									orgSearchFinalResultBObj
											.setAdminClientNum(adminContequivBObj1
											.getAdminPartyId());
								}
							}

						}
						// Changes end for Japan Market
					} else if(marketNameInput!=null &&  (
									marketNameInput.equalsIgnoreCase(ExternalRuleConstant.INDONESIA_MARKET_NAME)
									|| marketNameInput.equalsIgnoreCase(ExternalRuleConstant.VIETNAM_MARKET_NAME)
									|| marketNameInput.equalsIgnoreCase(ExternalRuleConstant.MARKET_NAME_BRAZIL)
									|| marketNameInput.equalsIgnoreCase(ExternalRuleConstant.SINGAPORE_MARKET_NAME)
									|| marketNameInput.equalsIgnoreCase(ExternalRuleConstant.HUNGARY_MARKET_NAME)
									|| marketNameInput.equalsIgnoreCase(ExternalRuleConstant.ROMANIA_MARKET_NAME)
									|| marketNameInput.equalsIgnoreCase(ExternalRuleConstant.SLOVAKIA_MARKET_NAME)
									|| marketNameInput.equalsIgnoreCase(ExternalRuleConstant.SOUTH_AFRICA_MARKET_NAME)
									|| ExternalRuleConstant.AEM_MARKETS.contains(marketNameInput)))
						 {
							 vecAdminContequivBObj = tcrmOrgFinalBObj.getItemsTCRMAdminContEquivBObj();
						if (vecAdminContequivBObj.size() > 0) {
							for (TCRMAdminContEquivBObj adminContequivBObj1 : vecAdminContequivBObj) {
								String adminSystemType = adminContequivBObj1.getAdminSystemType();
								String retailFlag = ((XContEquivBObjExt)adminContequivBObj1).getXSourceRetailerFlag();
								if (adminSystemType!=null && (adminSystemType.equalsIgnoreCase(ExternalRuleConstant.SOURCE_SYSTEM_TYPE_SFDC_MVP) 
										&& retailFlag!=null && retailFlag.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_N)) ){
									//SFDC ID
									orgSearchFinalResultBObj.setAdminSystemType(adminSystemType);
									orgSearchFinalResultBObj.setAdminSystemValue(adminContequivBObj1.getAdminSystemValue());
									orgSearchFinalResultBObj.setAdminClientNum(adminContequivBObj1.getAdminPartyId());
									
									
								}else if (adminSystemType!=null && adminSystemType.equalsIgnoreCase(ExternalRuleConstant.SOURCE_SYSTEM_TYPE_UCID_MVP)){
									//UCID
									orgSearchFinalResultBObj.setIdentificationType(ExternalRuleConstant.UCID_TYPE);
									orgSearchFinalResultBObj.setIdentificationTypeValue(ExternalRuleConstant.UCID_TEXT);
									orgSearchFinalResultBObj.setIdentificationNum(adminContequivBObj1.getAdminPartyId());
								}
							}

						}
							
						
					}else if(marketNameInput!=null && marketNameInput.equalsIgnoreCase(ExternalRuleConstant.KOREA_MARKET_NAME)){

						//Changes Start for Korea Market
						
						vecAdminContequivBObj = tcrmOrgFinalBObj.getItemsTCRMAdminContEquivBObj();
						if (vecAdminContequivBObj.size() > 0) {
							for (TCRMAdminContEquivBObj adminContequivBObj1 : vecAdminContequivBObj) {
								String adminSystemType = adminContequivBObj1.getAdminSystemType();
								String retailFlag = ((XContEquivBObjExt)adminContequivBObj1).getXSourceRetailerFlag();
								if (adminSystemType!=null && (adminSystemType.equalsIgnoreCase(ExternalRuleConstant.SOURCE_IDENTIFIER_TYPE_SFDC) 
										&& retailFlag!=null && retailFlag.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_N)) ){
									//SFDC ID
									orgSearchFinalResultBObj.setAdminSystemType(adminSystemType);
									orgSearchFinalResultBObj.setAdminSystemValue(adminContequivBObj1.getAdminSystemValue());
									orgSearchFinalResultBObj.setAdminClientNum(adminContequivBObj1.getAdminPartyId());
									
									
								}else if (adminSystemType!=null && adminSystemType.equalsIgnoreCase(ExternalRuleConstant.ADMIN_SYS_TP_UCID)){
									//UCID
									orgSearchFinalResultBObj.setIdentificationType(ExternalRuleConstant.UCID_TYPE);
									orgSearchFinalResultBObj.setIdentificationTypeValue(ExternalRuleConstant.UCID_TEXT);
									orgSearchFinalResultBObj.setIdentificationNum(adminContequivBObj1.getAdminPartyId());
								}
							}

						}
						
						//Changes for DA
						if(ExternalRuleConstant.SEARCH_ORG_DIGITAL_APP_KOR.equalsIgnoreCase(control.getCustomerEnvironment())){
							
							//Identifiers
							vecIdentifierBObj = tcrmOrgFinalBObj.getItemsTCRMPartyIdentificationBObj();
							for(XIdentifierBObjExt identifierBObj : vecIdentifierBObj){
								//Vat No KOR in Address Line Three
								if(identifierBObj.getIdentificationType().equalsIgnoreCase(ExternalRuleConstant.ID_TYPE_VAT_NO_KOR)){
									orgSearchFinalResultBObj.setAddrLineThree(identifierBObj.getIdentificationNumber());
									
								}else {
									orgSearchFinalResultBObj.setAddrLineThree(null);
								}
								//Com Reg No KOR in Address Line Two
								if(identifierBObj.getIdentificationType().equalsIgnoreCase(ExternalRuleConstant.ID_TYPE_COM_REG_ID_KOR)){
									orgSearchFinalResultBObj.setAddrLineTwo(identifierBObj.getIdentificationNumber());								
								}	else {
									orgSearchFinalResultBObj.setAddrLineTwo(null);
								}
							}
							
							//Name
							vecOrgNameBObjs = tcrmOrgFinalBObj.getItemsTCRMOrganizationNameBObj();
							for(TCRMOrganizationNameBObj orgNameBObj : vecOrgNameBObjs){
								//Korean Name
								if(orgNameBObj.getNameUsageType().equalsIgnoreCase(ExternalRuleConstant.NAME_USAGE_TYPE_KOREA)){
									orgSearchFinalResultBObj.setOrganizationName(orgNameBObj.getOrganizationName());								}
							}
							
							//Phone Numbers
							
							vecContactMethodBObjs = tcrmOrgFinalBObj.getItemsTCRMPartyContactMethodBObj();
							boolean isHomePhoneSet = false;
							boolean isWorkPhoneSet = false;
							boolean isMobileSet = false;
							boolean isWorkMobileSet = false;
							for(TCRMPartyContactMethodBObj contactMethodBObj : vecContactMethodBObjs){
								//Home Phone in Building Name
								//Work Phone in City Name
								//Mobile in ContactMethodReferenceNumber
								//Work Mobile in Street Name
								
								if(contactMethodBObj.getContactMethodUsageType().equalsIgnoreCase(ExternalRuleConstant.CONTACT_METHOD_HOMEPHONE_KOR)){
									orgSearchFinalResultBObj.setBuildingName(contactMethodBObj.getTCRMContactMethodBObj().getReferenceNumber());
									isHomePhoneSet = true;
								}
								if(contactMethodBObj.getContactMethodUsageType().equalsIgnoreCase(ExternalRuleConstant.CONTACT_METHOD_WORKPHONE_KOR)){
									orgSearchFinalResultBObj.setCityName(contactMethodBObj.getTCRMContactMethodBObj().getReferenceNumber());
									isWorkPhoneSet = true;
								}
								if(contactMethodBObj.getContactMethodUsageType().equalsIgnoreCase(ExternalRuleConstant.CONTACT_METHOD_MOBILE_KOR)){
									orgSearchFinalResultBObj.setContactMethodReferenceNumber(contactMethodBObj.getTCRMContactMethodBObj().getReferenceNumber());
									isMobileSet = true;
								}
								if(contactMethodBObj.getContactMethodUsageType().equalsIgnoreCase(ExternalRuleConstant.CONTACT_METHOD_WORKMOBILE_KOR)){
									orgSearchFinalResultBObj.setStreetName(contactMethodBObj.getTCRMContactMethodBObj().getReferenceNumber());
									isWorkMobileSet = true;
								}	
							}
							
							if(!isHomePhoneSet){
								orgSearchFinalResultBObj.setBuildingName(null);
							}if(!isWorkPhoneSet){
								orgSearchFinalResultBObj.setCityName(null);
							}if(!isMobileSet){
								orgSearchFinalResultBObj.setContactMethodReferenceNumber(null);
							}if(!isWorkMobileSet){
								orgSearchFinalResultBObj.setStreetName(null);
							}
						}
						
						// Changes end for Korea Market
						
						
					} 
					else {
					
					vecIdentificationBObj = tcrmOrgFinalBObj
							.getItemsTCRMPartyIdentificationBObj();
					if (vecIdentificationBObj.size() > 0) {
						for (TCRMPartyIdentificationBObj identificationBObj : vecIdentificationBObj) {
							identificationType = identificationBObj
									.getIdentificationType();
							if (identificationType
									.equalsIgnoreCase(ExternalRuleConstant.UCID_TYPE)) {
								orgSearchFinalResultBObj
										.setIdentificationType(identificationType);
								orgSearchFinalResultBObj
										.setIdentificationTypeValue(identificationBObj
												.getIdentificationValue());
								orgSearchFinalResultBObj
										.setIdentificationNum(identificationBObj
												.getIdentificationNumber());
							}
						}

					}

					if (tcrmOrgFinalBObj.getItemsTCRMAdminContEquivBObj() != null
							&& tcrmOrgFinalBObj
									.getItemsTCRMAdminContEquivBObj().size() > 0) {
						adminContequivBObj = (TCRMAdminContEquivBObj) tcrmOrgFinalBObj
								.getItemsTCRMAdminContEquivBObj().get(0);

						orgSearchFinalResultBObj
								.setAdminSystemType(adminContequivBObj
										.getAdminSystemType());
						orgSearchFinalResultBObj
								.setAdminSystemValue(adminContequivBObj
										.getAdminSystemValue());
						orgSearchFinalResultBObj
								.setAdminClientNum(adminContequivBObj
										.getAdminPartyId());
					}
				}

					// Start Removing unnecessary tags
					orgSearchFinalResultBObj.setAddressId(null);
					
					orgSearchFinalResultBObj.setAddressFormatInd(null);
					if(!ExternalRuleConstant.SEARCH_ORG_DIGITAL_APP_KOR.equalsIgnoreCase(control.getCustomerEnvironment())){
						orgSearchFinalResultBObj.setAddrLineOne(null);
						orgSearchFinalResultBObj.setAddrLineThree(null);
						orgSearchFinalResultBObj.setAddrLineTwo(null);					
						orgSearchFinalResultBObj.setBuildingName(null);
						orgSearchFinalResultBObj.setCityName(null);
					}
					orgSearchFinalResultBObj.setContactMethodId(null);
					if(!ExternalRuleConstant.SEARCH_ORG_DIGITAL_APP_KOR.equalsIgnoreCase(control.getCustomerEnvironment())){
					orgSearchFinalResultBObj.setContactMethodReferenceNumber(null);
					}
					orgSearchFinalResultBObj.setContactMethodType(null);
					orgSearchFinalResultBObj.setContractNum(null);
					orgSearchFinalResultBObj.setContactMethodValue(null);
					orgSearchFinalResultBObj.setCountryType(null);
					orgSearchFinalResultBObj.setCountryValue(null);
					orgSearchFinalResultBObj.setCountyCode(null);
					orgSearchFinalResultBObj.setHouseNum(null);
					orgSearchFinalResultBObj.setLatitudeDegrees(null);
					orgSearchFinalResultBObj.setLongtitudeDegrees(null);
					orgSearchFinalResultBObj.setPartyId(null);
					orgSearchFinalResultBObj.setPartyType(null);
					orgSearchFinalResultBObj.setPhoneAreaCode(null);
					orgSearchFinalResultBObj.setPhoneExchange(null);
					orgSearchFinalResultBObj.setPhoneExtension(null);
					orgSearchFinalResultBObj.setPhoneNumber(null);
					orgSearchFinalResultBObj.setPhoneticCityName(null);
					orgSearchFinalResultBObj.setPostDirectional(null);
					orgSearchFinalResultBObj.setPreDirectional(null);
					orgSearchFinalResultBObj.setProvState(null);
					orgSearchFinalResultBObj.setProvStateType(null);
					orgSearchFinalResultBObj.setProvStateValue(null);
					if(!ExternalRuleConstant.SEARCH_ORG_DIGITAL_APP_KOR.equalsIgnoreCase(control.getCustomerEnvironment())){
						orgSearchFinalResultBObj.setStreetName(null);
					}
					orgSearchFinalResultBObj.setStreetNumber(null);
					orgSearchFinalResultBObj.setStreetPrefix(null);
					orgSearchFinalResultBObj.setStreetSuffix(null);
					orgSearchFinalResultBObj.setTelephoneNum(null);
					orgSearchFinalResultBObj.setTempHolder(null);
					orgSearchFinalResultBObj.setZipPostalCode(null);
					orgSearchFinalResultBObj.setPartyActiveIndicator(null);
					orgSearchFinalResultBObj.setResultNumber(null);
					orgSearchFinalResultBObj.setResultsFound(null);
					if(!ExternalRuleConstant.SEARCH_ORG_DIGITAL_APP_KOR.equalsIgnoreCase(control.getCustomerEnvironment())){
					    orgSearchFinalResultBObj.setOrganizationName(null);
					}
					orgSearchFinalResultBObj.setOrganizationType(null);
					orgSearchFinalResultBObj.setOrganizationValue(null);
					// End Removing unnecessary tags
				
				
				
				
				//START : STS - New Source system for AUS, needs some extra fields to be shown in the search person response.
				if (ExternalRuleConstant.MARKET_NAME_AUSTRALIA.equalsIgnoreCase(marketNameInput)  && clientSystemNameSTS!=null 
						&& clientSystemNameSTS.equalsIgnoreCase(ExternalRuleConstant.CLIENT_SYS_NAME_STS_AUS) ){
					try {	
						// STS-AUS customer do not want to see any type code, they just need to see values which describes the content
						orgSearchFinalResultBObj.setIdentificationType(null);
						orgSearchFinalResultBObj.setAdminSystemType(null);
						orgSearchFinalResultBObj.setComponentID(null);
						
					// Add First Name and Last name in response 
						vecOrganizationNameBObjs = tcrmOrgFinalBObj.getItemsTCRMOrganizationNameBObj();
					if (null!=vecOrganizationNameBObjs && vecOrganizationNameBObjs.size()!=0){
					for(TCRMOrganizationNameBObj newTCRMOrgNameBObj: vecOrganizationNameBObjs){
						//System.err.println("newTCRMPersonNameBObj.getNameUsageType()-----"+newTCRMPersonNameBObj.getNameUsageType());
						if(newTCRMOrgNameBObj.getNameUsageType().equalsIgnoreCase(ExternalRuleConstant.NAME_USAGE_TYPE_LEGAL)){
							orgSearchFinalResultBObj.setOrganizationName(newTCRMOrgNameBObj.getOrganizationName());
						}
					
					}
					}
					TCRMOrganizationBObj newOrganizationBObj =null;
					newOrganizationBObj= new TCRMOrganizationBObj();
					newOrganizationBObj.setPartyActiveIndicator(null);
					orgSearchFinalResultBObj.setComponentID(null);
					
//					if(null!=tcrmOrgFinalBObj.getSourceIdentifierType())
//						newOrganizationBObj.setSourceIdentifierType(tcrmOrgFinalBObj.getSourceIdentifierType());
					if(null!=tcrmOrgFinalBObj.getSourceIdentifierValue())
						newOrganizationBObj.setSourceIdentifierValue(tcrmOrgFinalBObj.getSourceIdentifierValue());
					// Add All address of person in response in response
					Vector<XAddressGroupBObjExt> newAddressObjectSet= new Vector<XAddressGroupBObjExt>();
					vecAddressBObjExts= tcrmOrgFinalBObj.getItemsTCRMPartyAddressBObj();
					if(null!=vecAddressBObjExts && vecAddressBObjExts.size()!=0){
						newAddressObjectSet=setAddressFieldsInresponse(vecAddressBObjExts);
						newOrganizationBObj.getItemsTCRMPartyAddressBObj().addAll(newAddressObjectSet);

					
					}
					
					//Add all contact methods of person in response
					Vector<XContactMethodGroupBObjExt> vecTCRMPartyContactMethodBObj = new Vector<XContactMethodGroupBObjExt>();
					Vector<XContactMethodGroupBObjExt> vecTosetContactMethodBObj = new Vector<XContactMethodGroupBObjExt>();
					vecTCRMPartyContactMethodBObj=tcrmOrgFinalBObj.getItemsTCRMPartyContactMethodBObj();
					if(null!=vecTCRMPartyContactMethodBObj && vecTCRMPartyContactMethodBObj.size()!=0)
					{
						vecTosetContactMethodBObj=setContactMethodBObjInResposne(vecTCRMPartyContactMethodBObj);
						newOrganizationBObj.getItemsTCRMPartyContactMethodBObj().addAll(vecTosetContactMethodBObj);
						
					}
					
					//Add all SFDC IDs (WS+Retail) of person in response
//					Vector<TCRMAdminContEquivBObj> vecAdminContEquivBObjs= new Vector<TCRMAdminContEquivBObj>();
//					Vector<TCRMAdminContEquivBObj> vecTosetAdminContEquivBObjs= new Vector<TCRMAdminContEquivBObj>();
//					vecAdminContequivBObj=tcrmOrgFinalBObj.getItemsTCRMAdminContEquivBObj();
//					if(null!=vecAdminContequivBObj && vecAdminContequivBObj.size()!=0){
//						vecTosetAdminContEquivBObjs=setSFDCidsforsearchResult(vecAdminContequivBObj);
//						newOrganizationBObj.getItemsTCRMAdminContEquivBObj().addAll(vecTosetAdminContEquivBObjs); 
//					}
					
					if(null!=newOrganizationBObj){
						Vector<TCRMOrganizationBObj>  vecOrgBObjs = new Vector<TCRMOrganizationBObj>();
						vecOrgBObjs.addElement(newOrganizationBObj);
						orgSearchFinalResultBObj.setAdditionalResultDetail(vecOrgBObjs);
						orgSearchFinalResultBObj.setComponentID(null);

						//vecPersonBObjs.get(index)(newPersonBObjSTS);
					}
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}	
		
				}
				//END : STS - New Source system for AUS, needs some extra fields to be shown in the search person response.
				}

			}
			}

		}
	}

	private Vector<TCRMAdminContEquivBObj> setSFDCidsforsearchResult(
			Vector<TCRMAdminContEquivBObj> vecAdminContequivBObj) {
		// TODO Auto-generated method stub
		
		Vector<TCRMAdminContEquivBObj> vecFinalAdminContEquivBObjs= new Vector<TCRMAdminContEquivBObj>();
		TCRMAdminContEquivBObj contEquivBObj= null;
		
		for(TCRMAdminContEquivBObj adminContEquivBObj: vecAdminContequivBObj){
			contEquivBObj = new TCRMAdminContEquivBObj();
			contEquivBObj.setComponentID(null);
			contEquivBObj.setAdminPartyId(adminContEquivBObj.getAdminPartyId());
			//contEquivBObj.setAdminSystemType(adminContEquivBObj.getAdminSystemType());
			contEquivBObj.setAdminSystemValue(adminContEquivBObj.getAdminSystemValue());
			vecFinalAdminContEquivBObjs.addElement(contEquivBObj);
		}
		return vecFinalAdminContEquivBObjs;
	}

	private Vector<XContactMethodGroupBObjExt> setContactMethodBObjInResposne(
			Vector<XContactMethodGroupBObjExt> vecTCRMPartyContactMethodBObj) {
		// TODO Auto-generated method stub
		Vector<XContactMethodGroupBObjExt> vecFinalPartyContactMethodBObj = new Vector<XContactMethodGroupBObjExt>();
		XContactMethodGroupBObjExt finalTCRMPartyContactMethodBObj=null;
		XPrivacyAgreementBObj xPrivacyAgreementBObj=null;
		XPrivacyAgreementBObj xFinalPrivacyAgreementBObj=null;
		TCRMContactMethodBObj finalTcMethodBObj= null;
		
		TCRMContactMethodBObj resultTcMethodBObj= null;
		try {
		for(XContactMethodGroupBObjExt partyContactMethod: vecTCRMPartyContactMethodBObj){
			finalTCRMPartyContactMethodBObj= new XContactMethodGroupBObjExt();
			//finalTCRMPartyContactMethodBObj.setContactMethodUsageType(partyContactMethod.getContactMethodUsageType());
			finalTCRMPartyContactMethodBObj.setContactMethodUsageValue(partyContactMethod.getContactMethodUsageValue());
			resultTcMethodBObj= new TCRMContactMethodBObj();
			resultTcMethodBObj= partyContactMethod.getTCRMContactMethodBObj();
			finalTcMethodBObj= new TCRMContactMethodBObj();
			xPrivacyAgreementBObj= new XPrivacyAgreementBObj();
			xFinalPrivacyAgreementBObj= new XPrivacyAgreementBObj();
			xPrivacyAgreementBObj=partyContactMethod.getXPrivacyAgreementBObj();
			
			if(null!=xPrivacyAgreementBObj.getActionType() || null!=xPrivacyAgreementBObj.getActionValue()){
//				if(null!=xPrivacyAgreementBObj.getActionType())
//				xFinalPrivacyAgreementBObj.setActionType(xPrivacyAgreementBObj.getActionType());
			//	System.err.println("xPrivacyAgreementBObj.getActionValue()-----"+xPrivacyAgreementBObj.getActionValue());
				if(null!=xPrivacyAgreementBObj.getActionValue())
				xFinalPrivacyAgreementBObj.setActionValue(xPrivacyAgreementBObj.getActionValue());
				xFinalPrivacyAgreementBObj.setComponentID(null);
				finalTCRMPartyContactMethodBObj.setXPrivacyAgreementBObj(xFinalPrivacyAgreementBObj);
			}else{
				finalTCRMPartyContactMethodBObj.setXPrivacyAgreementBObj(null);
			}
			
			finalTCRMPartyContactMethodBObj.setXPreferenceBObj(null);
				//added to set it to null-temp opt-in is commented
			//finalTCRMPartyContactMethodBObj.setXPrivacyAgreementBObj(null);	
	
			finalTcMethodBObj.setReferenceNumber(resultTcMethodBObj.getReferenceNumber());
			finalTcMethodBObj.setComponentID(null);
			finalTCRMPartyContactMethodBObj.setTCRMContactMethodBObj(finalTcMethodBObj);
			finalTCRMPartyContactMethodBObj.setComponentID(null);
			vecFinalPartyContactMethodBObj.add(finalTCRMPartyContactMethodBObj);
		}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return vecFinalPartyContactMethodBObj;
	}

	private Vector<XAddressGroupBObjExt> setAddressFieldsInresponse(
			Vector<XAddressGroupBObjExt> vecAddressBObjExts) throws Exception {
		// TODO Auto-generated method stub
		Vector<XAddressGroupBObjExt> finalAddressVector= new Vector<XAddressGroupBObjExt>();
		//TCRMPartyAddressBObj xPartyAddressBObjExt=null;
		XAddressGroupBObjExt xPartyAddressBObjExt= null;
		XAddressBObjExt oneTCRMAddressBObj= null;
		XAddressBObjExt resultTCRMAddressBObj= null;
		XPrivacyAgreementBObj xPrivacyAgreementBObj= new  XPrivacyAgreementBObj();
		XPrivacyAgreementBObj xFinalPrivacyAgreementBObj= null;
		
		for(XAddressGroupBObjExt newXAddressBObjExt:vecAddressBObjExts){
			xPartyAddressBObjExt= new XAddressGroupBObjExt();
			//xPartyAddressBObjExt.setAddressUsageType(newXAddressBObjExt.getAddressUsageType());
			xPartyAddressBObjExt.setAddressUsageValue(newXAddressBObjExt.getAddressUsageValue());
			oneTCRMAddressBObj= new XAddressBObjExt();
			
			resultTCRMAddressBObj = new XAddressBObjExt();
			resultTCRMAddressBObj=(XAddressBObjExt) newXAddressBObjExt.getTCRMAddressBObj();
			if( null!= resultTCRMAddressBObj.getAddressLineOne())
			oneTCRMAddressBObj.setAddressLineOne(resultTCRMAddressBObj.getAddressLineOne());
			if( null!= resultTCRMAddressBObj.getAddressLineTwo())
			oneTCRMAddressBObj.setAddressLineTwo(resultTCRMAddressBObj.getAddressLineTwo());
			if( null!= resultTCRMAddressBObj.getAddressLineThree())
			oneTCRMAddressBObj.setAddressLineThree(resultTCRMAddressBObj.getAddressLineThree());
			if( null!= resultTCRMAddressBObj.getCity())
			oneTCRMAddressBObj.setCity(resultTCRMAddressBObj.getCity());
			if( null!= resultTCRMAddressBObj.getZipPostalCode())
			oneTCRMAddressBObj.setZipPostalCode(resultTCRMAddressBObj.getZipPostalCode());
//			if( null!= resultTCRMAddressBObj.getCountryType())
//			oneTCRMAddressBObj.setCountryType(resultTCRMAddressBObj.getCountryType());
			if( null!= resultTCRMAddressBObj.getCountryValue())
			oneTCRMAddressBObj.setCountryValue(resultTCRMAddressBObj.getCountryValue());
			if( null!= resultTCRMAddressBObj.getXSuburb())
			oneTCRMAddressBObj.setXSuburb(resultTCRMAddressBObj.getXSuburb());
			else
				oneTCRMAddressBObj.setXSuburb(ExternalRuleConstant.XSUBURBDEFAULT);
			if(null!=newXAddressBObjExt.getXPrivacyAgreementBObj())
			xPrivacyAgreementBObj=newXAddressBObjExt.getXPrivacyAgreementBObj();
			if (null!=xPrivacyAgreementBObj.getActionType() || null!=xPrivacyAgreementBObj.getActionValue()){
				xPrivacyAgreementBObj=newXAddressBObjExt.getXPrivacyAgreementBObj();
				xFinalPrivacyAgreementBObj= new XPrivacyAgreementBObj();
				
//				if(null!=xPrivacyAgreementBObj.getActionType()){
//					xFinalPrivacyAgreementBObj.setActionType(xPrivacyAgreementBObj.getActionType());
//				}
				if(null!=xPrivacyAgreementBObj.getActionValue()){
					xFinalPrivacyAgreementBObj.setActionValue(xPrivacyAgreementBObj.getActionValue());
				}
				xFinalPrivacyAgreementBObj.setComponentID(null);
				xPartyAddressBObjExt.setXPrivacyAgreementBObj(xFinalPrivacyAgreementBObj);
			}else{
				xPartyAddressBObjExt.setXPrivacyAgreementBObj(null);	
			}
			oneTCRMAddressBObj.setComponentID(null);
		//	xPartyAddressBObjExt.setXPrivacyAgreementBObj(null);
			xPartyAddressBObjExt.setXPreferenceBObj(null);
			xPartyAddressBObjExt.setTCRMAddressBObj(oneTCRMAddressBObj);
			xPartyAddressBObjExt.setComponentID(null);
			finalAddressVector.addElement(xPartyAddressBObjExt);
		}
		return finalAddressVector;
	}
}
