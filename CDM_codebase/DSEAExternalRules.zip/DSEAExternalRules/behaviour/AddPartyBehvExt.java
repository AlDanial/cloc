/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[8a11672eb7cb8375c17509d52c36962e]
 */

package com.ibm.daimler.dsea.extrules.behaviour;

import java.util.Vector;

import com.dwl.base.DWLControl;
import com.dwl.base.IDWLErrorMessage;
import com.dwl.base.error.DWLError;
import com.dwl.base.error.DWLStatus;
import com.dwl.base.extensionFramework.ClientJavaExtensionSet;
import com.dwl.base.extensionFramework.ExtensionParameters;
import com.dwl.base.util.StringUtils;
import com.dwl.tcrm.common.TCRMErrorCode;
import com.dwl.tcrm.coreParty.component.TCRMOrganizationBObj;
import com.dwl.tcrm.coreParty.component.TCRMPartyIdentificationBObj;
import com.dwl.tcrm.coreParty.component.TCRMPersonBObj;
import com.dwl.tcrm.exception.TCRMException;
import com.dwl.tcrm.utilities.TCRMClassFactory;
import com.dwl.unifi.tx.exception.BusinessProxyException;
import com.ibm.daimler.dsea.component.XContEquivBObjExt;
import com.ibm.daimler.dsea.component.XIdentifierBObjExt;
import com.ibm.daimler.dsea.component.XOrgBObjExt;
import com.ibm.daimler.dsea.component.XPersonBObjExt;
import com.ibm.daimler.dsea.extrules.constant.DSEAExternalRulesComponentID;
import com.ibm.daimler.dsea.extrules.constant.DSEAExternalRulesErrorReasonCode;
import com.ibm.daimler.dsea.extrules.constant.ExternalRuleConstant;
import com.ibm.daimler.dsea.extrules.util.ExternalRuleUtil;

/**
 * <!-- begin-user-doc --> <!-- end-user-doc -->
 *
 * This is a Java rule that extends the behavior of WCC. @see
 * com.dwl.base.extensionFramework.ClientJavaExtensionSet
 * 
 * @generated not
 */
public class AddPartyBehvExt extends ClientJavaExtensionSet {
	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 *
	 * The execute method will be called in case of extension activation.
	 *
	 * @generated not
	 */
	public void execute(ExtensionParameters params) {
		// MDM_TODO: CDKWB0018I Write customized business logic for the
		// extension here.

		Object aObject = params.getTransactionObjectHierarchy();

		XPersonBObjExt tcrmPersonBObj = null;
		XOrgBObjExt tcrmOrganizationBObj = null;

		DWLControl control = params.getControl();

		String requestName = null;
		String reArch = null;
		boolean isvalidateSFDC_UCID=false;
		
		IDWLErrorMessage errorHandler = TCRMClassFactory.getErrorHandler();
		DWLStatus dwlStatus = params.getExtensionSetStatus();

		if (control.get("request_name") != null) {
			requestName = (control.get("request_name")).toString();
		}
		if (control.get("REARCH") != null) {
			reArch = (control.get("REARCH")).toString();
		}
		if(control.get("isSFDC_UCID")!=null){
			isvalidateSFDC_UCID=(Boolean) (control.get("isSFDC_UCID"));
		}
				
		boolean value = false;
		if ((requestName
				.equalsIgnoreCase(ExternalRuleConstant.COLLAPSEMULTIPLEPARTIES))
				|| (requestName
						.equalsIgnoreCase(ExternalRuleConstant.COLLAPSEPARTIESWITHRULES))
				|| (requestName
						.equalsIgnoreCase(ExternalRuleConstant.COLLAPSEMULTIPLEACTIVEPARTIES))
				|| (requestName
						.equalsIgnoreCase(ExternalRuleConstant.ASYNCREIDENTIFYSUSPECTS))
				|| (requestName
						.equalsIgnoreCase(ExternalRuleConstant.UNDOCOLLAPSEMULTIPLEPARTIES))) {

			value = true;
		}
		// Logic for Person Object
		if (!value) {
			if (aObject instanceof TCRMPersonBObj) {
				try {
					tcrmPersonBObj = (XPersonBObjExt) aObject;
					DWLControl dwlControl = tcrmPersonBObj.getControl();

					XIdentifierBObjExt newPartyIdentificationBObj = new XIdentifierBObjExt();
					XContEquivBObjExt newContEquivBObj = new XContEquivBObjExt();
					ExternalRuleUtil extRuleUtil = new ExternalRuleUtil();
					String newUID = null;
					String marketName = tcrmPersonBObj.getXMarketName();

					// Rearchitecture Changes : Start
					//
					if(!"true".equals(reArch) && !isvalidateSFDC_UCID){
						newUID = extRuleUtil.generateUCID();
					}
					
					// Rearchitecture Changes : End
					if (StringUtils.isNonBlank(newUID)) {
						
						//Japan Market
						if(marketName!=null && marketName.equalsIgnoreCase(ExternalRuleConstant.JAPAN_MARKET_NAME))
								{
							newContEquivBObj.setAdminPartyId(newUID);
							newContEquivBObj.setAdminSystemType(ExternalRuleConstant.UCID_SOURCE_TYPE);
							newContEquivBObj.setAdminSystemValue(ExternalRuleConstant.UCID_SOURCE_VALUE);
							newContEquivBObj.setXLastModifiedSystemDate(tcrmPersonBObj.getXLastModifiedSystemDate());
							newContEquivBObj.setControl(control);
							
							newContEquivBObj.setDescription(ExternalRuleConstant.MASTER_KEY);
							/*newContequiv.setXSourceRetailerFlag(currPartyUCIDObj.getXIdentifierRetailerFlag());
							newContequiv.setXRetailerId(currPartyUCIDObj.getXRetailerId());*/
							tcrmPersonBObj.setTCRMAdminContEquivBObj(newContEquivBObj);
						}
					            
						else if(marketName!=null && (
								marketName.equalsIgnoreCase(ExternalRuleConstant.INDONESIA_MARKET_NAME)
								|| marketName.equalsIgnoreCase(ExternalRuleConstant.VIETNAM_MARKET_NAME)
								|| marketName.equalsIgnoreCase(ExternalRuleConstant.MARKET_NAME_BRAZIL)
								|| marketName.equalsIgnoreCase(ExternalRuleConstant.SINGAPORE_MARKET_NAME)))
							
						{	
		
							newContEquivBObj.setAdminPartyId(newUID);
							newContEquivBObj.setAdminSystemType(ExternalRuleConstant.UCID_SOURCE_TYPE);
							newContEquivBObj.setAdminSystemValue(ExternalRuleConstant.UCID_SOURCE_VALUE);
							newContEquivBObj.setXLastModifiedSystemDate(tcrmPersonBObj.getXLastModifiedSystemDate());
							newContEquivBObj.setControl(dwlControl);
							tcrmPersonBObj.setTCRMAdminContEquivBObj(newContEquivBObj);						
						}
						//April 17, 2019 : Added by Sameeha for MVP2 : Start

						else if(marketName!=null && (
								marketName.equalsIgnoreCase(ExternalRuleConstant.HUNGARY_MARKET_NAME)
								|| marketName.equalsIgnoreCase(ExternalRuleConstant.ROMANIA_MARKET_NAME)
								|| marketName.equalsIgnoreCase(ExternalRuleConstant.SLOVAKIA_MARKET_NAME)))
							
						{	
		
							newContEquivBObj.setAdminPartyId(newUID);
							newContEquivBObj.setAdminSystemType(ExternalRuleConstant.UCID_SOURCE_TYPE);
							newContEquivBObj.setAdminSystemValue(ExternalRuleConstant.UCID_SOURCE_VALUE);
							newContEquivBObj.setXLastModifiedSystemDate(tcrmPersonBObj.getCreatedDate());
							newContEquivBObj.setControl(dwlControl);
							tcrmPersonBObj.setTCRMAdminContEquivBObj(newContEquivBObj);
		
							
						}

						else if(marketName!=null && 
								marketName.equalsIgnoreCase(ExternalRuleConstant.SOUTH_AFRICA_MARKET_NAME))
							
						{	
		
							newContEquivBObj.setAdminPartyId(newUID);
							newContEquivBObj.setAdminSystemType(ExternalRuleConstant.UCID_SOURCE_TYPE);
							newContEquivBObj.setAdminSystemValue(ExternalRuleConstant.UCID_SOURCE_VALUE);
							newContEquivBObj.setXLastModifiedSystemDate(tcrmPersonBObj.getXLastModifiedSystemDate());
							newContEquivBObj.setControl(dwlControl);
							tcrmPersonBObj.setTCRMAdminContEquivBObj(newContEquivBObj);
		
							
						}
						
						//April 17, 2019 : Added by Sameeha for MVP2 : End

						else if(marketName!=null && (ExternalRuleConstant.AEM_MARKETS.contains(marketName)))
						{	
		
							newContEquivBObj.setAdminPartyId(newUID);
							newContEquivBObj.setAdminSystemType(ExternalRuleConstant.UCID_SOURCE_TYPE);
							newContEquivBObj.setAdminSystemValue(ExternalRuleConstant.UCID_SOURCE_VALUE);
							newContEquivBObj.setXLastModifiedSystemDate(tcrmPersonBObj.getXLastModifiedSystemDate());
							newContEquivBObj.setControl(dwlControl);
							tcrmPersonBObj.setTCRMAdminContEquivBObj(newContEquivBObj);
		
							
						}
						
						
						//All Markets Except Korea
						else if(marketName!=null && !marketName.equalsIgnoreCase(ExternalRuleConstant.KOREA_MARKET_NAME)){
							newPartyIdentificationBObj.setIdentificationType(ExternalRuleConstant.UCID_TYPE);
							newPartyIdentificationBObj.setIdentificationValue(ExternalRuleConstant.UCID_TEXT);
							newPartyIdentificationBObj.setIdentificationNumber(newUID);
							newPartyIdentificationBObj.setXLastModifiedSystemDate(tcrmPersonBObj.getXLastModifiedSystemDate());
	
							newPartyIdentificationBObj.setControl(dwlControl);
							tcrmPersonBObj.setTCRMPartyIdentificationBObj(newPartyIdentificationBObj);
						}else{
							//Korea Market
							if (!ExternalRuleConstant.STOUCH_UCID.equalsIgnoreCase(control.getLineOfBusiness())) 
							{
								if(!"true".equals(reArch)){
							newContEquivBObj.setAdminSystemType(ExternalRuleConstant.ADMIN_SYS_TP_UCID);
							newContEquivBObj.setAdminSystemValue(ExternalRuleConstant.ADMIN_SYS_VALUE_UCID);
							newContEquivBObj.setAdminPartyId(newUID);
							//description set as Y for active Party and lastModifiedDate
							newContEquivBObj.setDescription(ExternalRuleConstant.CHARACTER_Y);
							newContEquivBObj.setXLastModifiedSystemDate(tcrmPersonBObj.getXLastModifiedSystemDate());
							newContEquivBObj.setXSourceRetailerFlag(ExternalRuleConstant.CHARACTER_N);
							
							newContEquivBObj.setControl(dwlControl);
							tcrmPersonBObj.setTCRMAdminContEquivBObj(newContEquivBObj);
							}
							}
						}
					
					if(marketName!=null && marketName.equalsIgnoreCase(ExternalRuleConstant.KOREA_MARKET_NAME)){
						//Korea Market
						String sourceIdentifierType = null;
						XContEquivBObjExt newContEquivBObjforSTouch = new XContEquivBObjExt();

						sourceIdentifierType = tcrmPersonBObj.getSourceIdentifierType();
						if(sourceIdentifierType != null && sourceIdentifierType.equalsIgnoreCase(ExternalRuleConstant.SOURCE_IDENTIFIER_TYPE_STOUCH)){
							
							newContEquivBObjforSTouch.setAdminSystemType(ExternalRuleConstant.ADMIN_SYS_TP_STOUCH);
							newContEquivBObjforSTouch.setAdminSystemValue(ExternalRuleConstant.ADMIN_SYS_VALUE_STOUCH);
							newContEquivBObjforSTouch.setAdminPartyId("STouchID");
							//description set as Y for active Party and lastModifiedDate
							newContEquivBObjforSTouch.setDescription(ExternalRuleConstant.CHARACTER_Y);
							newContEquivBObjforSTouch.setXLastModifiedSystemDate(tcrmPersonBObj.getXLastModifiedSystemDate());

							newContEquivBObjforSTouch.setControl(dwlControl);
							tcrmPersonBObj.setTCRMAdminContEquivBObj(newContEquivBObjforSTouch);
							
						}
					}

				}else if(isvalidateSFDC_UCID && null==newUID) {
					//Japan Market
					if(marketName!=null && marketName.equalsIgnoreCase(ExternalRuleConstant.JAPAN_MARKET_NAME))
					{
						newContEquivBObj.setAdminPartyId((String) (control.get("JPN_UCID")));
						newContEquivBObj.setAdminSystemType(ExternalRuleConstant.UCID_SOURCE_TYPE);
						newContEquivBObj.setAdminSystemValue(ExternalRuleConstant.UCID_SOURCE_VALUE);
						newContEquivBObj.setXLastModifiedSystemDate(tcrmPersonBObj.getXLastModifiedSystemDate());
						newContEquivBObj.setControl(control);
						
						newContEquivBObj.setDescription(ExternalRuleConstant.MASTER_KEY);
						/*newContequiv.setXSourceRetailerFlag(currPartyUCIDObj.getXIdentifierRetailerFlag());
						newContequiv.setXRetailerId(currPartyUCIDObj.getXRetailerId());*/
						tcrmPersonBObj.setTCRMAdminContEquivBObj(newContEquivBObj);
					}
				}
					
				}catch (Exception e) {
								
					DWLError error = errorHandler.getErrorMessage(DSEAExternalRulesComponentID.ADD_PARTY_BEHV_EXT, TCRMErrorCode.INSERT_RECORD_ERROR, 
							DSEAExternalRulesErrorReasonCode.ADD_PARTY_UCID_INSERT_FAILED, control, new String[0]);					
					dwlStatus.addError(error);
					dwlStatus.setStatus(DWLStatus.FATAL);										

				}
			}

			// Logic for Organization Object
			if (aObject instanceof TCRMOrganizationBObj) {
				try {

					tcrmOrganizationBObj = (XOrgBObjExt) aObject;
					DWLControl dwlControl = tcrmOrganizationBObj.getControl();

					XIdentifierBObjExt newPartyIdentificationBObj = new XIdentifierBObjExt();
					ExternalRuleUtil extRuleUtil = new ExternalRuleUtil();
					String newUID = null;
					String marketName = tcrmOrganizationBObj.getXMarketName();
					XContEquivBObjExt newContEquivBObj = new XContEquivBObjExt();
					
					// Rearchitecture Changes : Start
					
				/*	if(mvp_poc == null || !mvp_poc.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_Y))
					{
						newUID = extRuleUtil.generateUCID();
					}*/
					
					if(!"true".equals(reArch)&& !isvalidateSFDC_UCID){
						newUID = extRuleUtil.generateUCID();
					}
					
					// Rearchitecture Changes : End
					
					if (StringUtils.isNonBlank(newUID)) 
					{
					
					//Japan Market
					if(marketName!=null && marketName.equalsIgnoreCase(ExternalRuleConstant.JAPAN_MARKET_NAME))
					{
					if (StringUtils.isNonBlank(newUID)) {
					newContEquivBObj.setAdminPartyId(newUID);
					newContEquivBObj.setAdminSystemType(ExternalRuleConstant.UCID_SOURCE_TYPE);
					newContEquivBObj.setAdminSystemValue(ExternalRuleConstant.UCID_SOURCE_VALUE);
					newContEquivBObj.setXLastModifiedSystemDate(tcrmOrganizationBObj.getXLastModifiedSystemDate());
					newContEquivBObj.setControl(control);
					newContEquivBObj.setDescription(ExternalRuleConstant.MASTER_KEY);
					/*newContequiv.setXSourceRetailerFlag(currPartyUCIDObj.getXIdentifierRetailerFlag());
					newContequiv.setXRetailerId(currPartyUCIDObj.getXRetailerId());*/
					tcrmOrganizationBObj.setTCRMAdminContEquivBObj(newContEquivBObj);
					}
					}
					else if(marketName!=null && (
							marketName.equalsIgnoreCase(ExternalRuleConstant.INDONESIA_MARKET_NAME)
							|| marketName.equalsIgnoreCase(ExternalRuleConstant.VIETNAM_MARKET_NAME)
							|| marketName.equalsIgnoreCase(ExternalRuleConstant.MARKET_NAME_BRAZIL)
							|| marketName.equalsIgnoreCase(ExternalRuleConstant.SINGAPORE_MARKET_NAME)))
					{
							
	
						newContEquivBObj.setAdminPartyId(newUID);
						newContEquivBObj.setAdminSystemType(ExternalRuleConstant.UCID_SOURCE_TYPE);
						newContEquivBObj.setAdminSystemValue(ExternalRuleConstant.UCID_SOURCE_VALUE);
						newContEquivBObj.setXLastModifiedSystemDate(tcrmOrganizationBObj.getXLastModifiedSystemDate());
						newContEquivBObj.setControl(control);
						tcrmOrganizationBObj.setTCRMAdminContEquivBObj(newContEquivBObj);
	
						
					}
					else if(marketName!=null && 
							marketName.equalsIgnoreCase(ExternalRuleConstant.SOUTH_AFRICA_MARKET_NAME))
						
					{	
	
						newContEquivBObj.setAdminPartyId(newUID);
						newContEquivBObj.setAdminSystemType(ExternalRuleConstant.UCID_SOURCE_TYPE);
						newContEquivBObj.setAdminSystemValue(ExternalRuleConstant.UCID_SOURCE_VALUE);
						newContEquivBObj.setXLastModifiedSystemDate(tcrmOrganizationBObj.getXLastModifiedSystemDate());
						newContEquivBObj.setControl(dwlControl);
						tcrmOrganizationBObj.setTCRMAdminContEquivBObj(newContEquivBObj);
	
						
					}
					
					else if(marketName!=null && (ExternalRuleConstant.AEM_MARKETS.contains(marketName)))
					{	
	
						newContEquivBObj.setAdminPartyId(newUID);
						newContEquivBObj.setAdminSystemType(ExternalRuleConstant.UCID_SOURCE_TYPE);
						newContEquivBObj.setAdminSystemValue(ExternalRuleConstant.UCID_SOURCE_VALUE);
						newContEquivBObj.setXLastModifiedSystemDate(tcrmOrganizationBObj.getXLastModifiedSystemDate());
						newContEquivBObj.setControl(dwlControl);
						tcrmOrganizationBObj.setTCRMAdminContEquivBObj(newContEquivBObj);
	
						
					}
					
					//April 17, 2019 : Added by Sameeha for MVP2 : Start

					else if(marketName!=null && (
							marketName.equalsIgnoreCase(ExternalRuleConstant.HUNGARY_MARKET_NAME)
							|| marketName.equalsIgnoreCase(ExternalRuleConstant.ROMANIA_MARKET_NAME)
							|| marketName.equalsIgnoreCase(ExternalRuleConstant.SLOVAKIA_MARKET_NAME)))
					{
						
						newContEquivBObj.setAdminPartyId(newUID);
						newContEquivBObj.setAdminSystemType(ExternalRuleConstant.UCID_SOURCE_TYPE);
						newContEquivBObj.setAdminSystemValue(ExternalRuleConstant.UCID_SOURCE_VALUE);
						newContEquivBObj.setXLastModifiedSystemDate(tcrmOrganizationBObj.getCreatedDate());
						newContEquivBObj.setControl(control);
						tcrmOrganizationBObj.setTCRMAdminContEquivBObj(newContEquivBObj);
						
					}
					
					//April 17, 2019 : Added by Sameeha for MVP2 : End
					
					
					else if(marketName!=null && (ExternalRuleConstant.AEM_MARKETS.contains(marketName)))
					{	
	
						newContEquivBObj.setAdminPartyId(newUID);
						newContEquivBObj.setAdminSystemType(ExternalRuleConstant.UCID_SOURCE_TYPE);
						newContEquivBObj.setAdminSystemValue(ExternalRuleConstant.UCID_SOURCE_VALUE);
						newContEquivBObj.setXLastModifiedSystemDate(tcrmOrganizationBObj.getXLastModifiedSystemDate());
						newContEquivBObj.setControl(dwlControl);
						tcrmOrganizationBObj.setTCRMAdminContEquivBObj(newContEquivBObj);
	
						
					}

					else if(marketName!=null && !marketName.equalsIgnoreCase(ExternalRuleConstant.KOREA_MARKET_NAME)){
						newPartyIdentificationBObj.setIdentificationType(ExternalRuleConstant.UCID_TYPE);
						newPartyIdentificationBObj.setIdentificationValue(ExternalRuleConstant.UCID_TEXT);
						newPartyIdentificationBObj.setIdentificationNumber(newUID);
						newPartyIdentificationBObj.setXLastModifiedSystemDate(tcrmOrganizationBObj.getXLastModifiedSystemDate());

						newPartyIdentificationBObj.setControl(dwlControl);
						tcrmOrganizationBObj.setTCRMPartyIdentificationBObj(newPartyIdentificationBObj);
					}else{
						if (StringUtils.isNonBlank(newUID)) {
	
							//Korea Market
							newContEquivBObj.setAdminSystemType(ExternalRuleConstant.ADMIN_SYS_TP_UCID);
							newContEquivBObj.setAdminSystemValue(ExternalRuleConstant.ADMIN_SYS_VALUE_UCID);
							newContEquivBObj.setAdminPartyId(newUID);
							
							//description set as Y for active Party and set lastModifiedDate
							newContEquivBObj.setDescription(ExternalRuleConstant.CHARACTER_Y);
							newContEquivBObj.setXLastModifiedSystemDate(tcrmOrganizationBObj.getXLastModifiedSystemDate());
							newContEquivBObj.setXSourceRetailerFlag(ExternalRuleConstant.CHARACTER_N);
							newContEquivBObj.setControl(dwlControl);
							tcrmOrganizationBObj.setTCRMAdminContEquivBObj(newContEquivBObj);
	
						}
					}
					if(marketName!=null && marketName.equalsIgnoreCase(ExternalRuleConstant.KOREA_MARKET_NAME)){
						//Korea Market
						String sourceIdentifierType = null;
						XContEquivBObjExt newContEquivBObjforSTouch = new XContEquivBObjExt();

						sourceIdentifierType = tcrmOrganizationBObj.getSourceIdentifierType();
						if(sourceIdentifierType != null && sourceIdentifierType.equalsIgnoreCase(ExternalRuleConstant.SOURCE_IDENTIFIER_TYPE_STOUCH)){
							
							newContEquivBObjforSTouch.setAdminSystemType(ExternalRuleConstant.ADMIN_SYS_TP_STOUCH);
							newContEquivBObjforSTouch.setAdminSystemValue(ExternalRuleConstant.ADMIN_SYS_VALUE_STOUCH);
							newContEquivBObjforSTouch.setAdminPartyId("STouchID");
							//description set as Y for active Party and lastModifiedDate
							newContEquivBObjforSTouch.setDescription(ExternalRuleConstant.CHARACTER_Y);
							newContEquivBObjforSTouch.setXLastModifiedSystemDate(tcrmOrganizationBObj.getXLastModifiedSystemDate());

							newContEquivBObjforSTouch.setControl(dwlControl);
							tcrmOrganizationBObj.setTCRMAdminContEquivBObj(newContEquivBObjforSTouch);
							
						}
					}
						
					}else if(isvalidateSFDC_UCID && null==newUID) {
						//Japan Market
						if(marketName!=null && marketName.equalsIgnoreCase(ExternalRuleConstant.JAPAN_MARKET_NAME))
						{
						if ((String) (control.get("JPN_UCID"))!=null) {
						newContEquivBObj.setAdminPartyId((String) (control.get("JPN_UCID")));
						newContEquivBObj.setAdminSystemType(ExternalRuleConstant.UCID_SOURCE_TYPE);
						newContEquivBObj.setAdminSystemValue(ExternalRuleConstant.UCID_SOURCE_VALUE);
						newContEquivBObj.setXLastModifiedSystemDate(tcrmOrganizationBObj.getXLastModifiedSystemDate());
						newContEquivBObj.setControl(control);
						newContEquivBObj.setDescription(ExternalRuleConstant.MASTER_KEY);
						/*newContequiv.setXSourceRetailerFlag(currPartyUCIDObj.getXIdentifierRetailerFlag());
						newContequiv.setXRetailerId(currPartyUCIDObj.getXRetailerId());*/
						tcrmOrganizationBObj.setTCRMAdminContEquivBObj(newContEquivBObj);
						}
						}
					}
					
				}
				catch (Exception e) {
			
					DWLError error = errorHandler.getErrorMessage(DSEAExternalRulesComponentID.ADD_PARTY_BEHV_EXT, TCRMErrorCode.INSERT_RECORD_ERROR, 
							DSEAExternalRulesErrorReasonCode.ADD_PARTY_UCID_INSERT_FAILED, control, new String[0]);
					
					dwlStatus.addError(error);
					dwlStatus.setStatus(DWLStatus.FATAL);

				}
			}
		}
	}
}
