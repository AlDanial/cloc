/* _______________________________________________________ {COPYRIGHT-TOP} _____
* Licensed Materials - Property of IBM
* Restricted Materials of IBM
*
* 5725-E59
*
* (C) Copyright IBM Corp. 2011, 2014  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
* ________________________________________________________ {COPYRIGHT-END} _____*/
package com.ibm.daimler.dsea.extrules.sdp;

import java.lang.Character.UnicodeBlock;
import java.util.Vector;

import org.apache.xerces.impl.dv.util.HexBin;
import org.apache.xml.serializer.unicode.UnicodeNormalizer;

import sun.nio.cs.UnicodeEncoder;
import sun.text.normalizer.UnicodeMatcher;

import com.dwl.base.DWLCommon;
import com.dwl.base.DWLControl;
import com.dwl.base.IDWLErrorMessage;
import com.dwl.base.error.DWLStatus;
import com.dwl.base.logging.DWLLoggerManager;
import com.dwl.base.logging.IDWLLogger;
import com.dwl.base.util.StringUtils;
import com.dwl.tcrm.common.TCRMErrorCode;
import com.dwl.tcrm.coreParty.component.ProbabilisticPersonSearchBObj;
import com.dwl.tcrm.coreParty.component.TCRMAddressBObj;
import com.dwl.tcrm.coreParty.component.TCRMContactMethodBObj;
import com.dwl.tcrm.coreParty.component.TCRMPartyAddressBObj;
import com.dwl.tcrm.coreParty.component.TCRMPartyBankAccountBObj;
import com.dwl.tcrm.coreParty.component.TCRMPartyChargeCardBObj;
import com.dwl.tcrm.coreParty.component.TCRMPartyComponent;
import com.dwl.tcrm.coreParty.component.TCRMPartyContactMethodBObj;
import com.dwl.tcrm.coreParty.component.TCRMPartyIdentificationBObj;
import com.dwl.tcrm.coreParty.component.TCRMPersonBObj;
import com.dwl.tcrm.coreParty.component.TCRMPersonNameBObj;
import com.dwl.tcrm.coreParty.constant.TCRMCoreComponentID;
import com.dwl.tcrm.coreParty.constant.TCRMCoreErrorReasonCode;
import com.dwl.tcrm.exception.TCRMDataInvalidException;
import com.dwl.tcrm.utilities.DateFormatter;
import com.dwl.tcrm.utilities.TCRMClassFactory;
import com.dwl.tcrm.utilities.TCRMExceptionUtils;
import com.ibm.daimler.dsea.component.XPersonBObjExt;
import com.ibm.mdm.common.util.PropertyManager;
import com.ibm.mdm.eme.metadata.CriticalData;
import com.ibm.mdm.mds.pme.api.bean.Attribute;
import com.ibm.mdm.mds.pme.api.bean.Record;
import com.ibm.mdm.mds.pme.api.bean.RecordId;
import com.ibm.daimler.dsea.component.*;
import com.ibm.daimler.dsea.extrules.constant.ExternalRuleConstant;
import com.ibm.daimler.dsea.extrules.util.ExternalRuleUtil;
import com.sun.xml.internal.fastinfoset.algorithm.HexadecimalEncodingAlgorithm;

/**
 * The PersonDerivedDataConverter provides an implementation of the IConverter
 * interface. Used to convert the TCRMPersonBObj to EME Record Object.
 * 
 * @since EVERETT
 * @see com.ibm.mdm.eme.converters.IConverter
 */
public class PersonDerivedDataConverter extends PartyDerivedDataConverter {
    public static final String copyright =  "Licensed Materials -- Property of IBM\n(c) Copyright IBM Corp. 2011, 2014\nUS Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.";



	private Record personRecord = null;

	private static final String BIRTH_DATE_MDM_ATTRIBUTE_NAME = "BirthDate";

	private static final String GENDER_TYPE_MDM_ATTRIBUTE_NAME = "GenderType";
	
	private static final String DECEASED_DATE_MDM_ATTRIBUTE_NAME = "DeceasedDate";

	private static final String GIVEN_NAME_ONE_MDM_ATTRIBUTE_NAME = "GivenNameOne";

	private static final String GIVEN_NAME_TWO_MDM_ATTRIBUTE_NAME = "GivenNameTwo";
	
	private static final String GIVEN_NAME_THREE_MDM_ATTRIBUTE_NAME = "GivenNameThree";

	private static final String GENERATION_VALUE_MDM_ATTRIBUTE_NAME = "GenerationValue";
	
	private static final String PREFIX_VALUE_MDM_ATTRIBUTE_NAME = "PrefixValue";

	private static final String LAST_NAME_MDM_ATTRIBUTE_NAME = "LastName";
	
	private static final String PERSON_PERSONNAME_NAMEUSAGETYPE_PREFIX = "Person.PersonName.NameUsageType.";
	
	private static final String PERSON_PARTYADDRESS_ADDRESSUSAGETYPE_PREFIX = "Person.PartyAddress.AddressUsageType.";
	
	private static final String PERSON_PARTYIDENTIFICATION_IDENTIFICATIONTYPE_PREFIX = "Person.PartyIdentification.IdentificationType.";
	
	private static final String PERSON_PARTYCONTACTMETHOD_CONTACTMETHODUSAGETYPE_PREFIX = "Person.PartyContactMethod.ContactMethodUsageType.";

	private static final String BANK_NUMBER_MDM_ATTRIBUTE_NAME = "BankNumber";

	private static final String BRANCH_NUMBER_MDM_ATTRIBUTE_NAME = "BranchNumber";

	private static final String ACCOUNT_NUMBER_MDM_ATTRIBUTE_NAME = "AccountNumber";

	private static final String PERSON_PARTYBANKACCOUNT_ACCOUNTTYPE_PREFIX = "Person.PartyBankAccount.AccountType.";

	private static final String CARD_NUMBER_MDM_ATTRIBUTE_NAME = "CardNumber";

	private static final String PERSON_PARTYCHARGECARD_CARDTYPE_PREFIX = "Person.PartyChargeCard.CardType.";

	private static final Object CONTACTMETHOD_USAGETYPE_MDM_ATTRIBUTE_NAME = "ContactMethodUsageType";

	private static final Object PERSON_GROUP_NAME = "Person";
	
	private static final String MARKET_MDM_ATTRIBUTE_NAME = "XMarketName";
	
	//Flag to indicate if this called from probabilistic search
	boolean probabilisticSearch = false;
	
	private static final IDWLLogger logger = DWLLoggerManager.getLogger(PersonDerivedDataConverter.class);
	
	private static IDWLErrorMessage errHandler;
	
	private boolean isNationalIdPresent = false;
	/**
	 * Builds an attribute with attrCode,elementName,elementValue and
	 * activeIndicator.
	 * 
	 * @param attrCode
	 * @param elementName
	 * @param elementValue
	 * @param activeInd
	 * @return
	 */
	private Attribute buildAttribute(String attrCode, String elementName,
			Object elementValue) {
		Attribute personAttrs = new Attribute(attrCode);
		personAttrs.setField(elementName, elementValue);
		return personAttrs;
	}

	/**
	 * Builds all person name attributes for a person
	 * 
	 * @param vecPersonName
	 * @throws Exception
	 */
	private void buildPersonNameAttributes(
			Vector<TCRMPersonNameBObj> vecPersonName, String xmarketName) throws Exception {

		if (vecPersonName != null && vecPersonName.size() > 0) {
			Vector<CriticalData> vecCritVectorForPersonName = getCriticalDataElementsOfChildObjectOfPerson(vecPersonName.firstElement());

			for (TCRMPersonNameBObj persNameBObj : vecPersonName) {
				String nameUsageTp = persNameBObj.getNameUsageType();

				
				if (probabilisticSearch && nameUsageTp==null)
				 {
					 //Default name usage type is 1 if not provided in the request
					 nameUsageTp = "1";
				 }

				String attrCode = PropertyManager.getOptionalProperty(PERSON_PERSONNAME_NAMEUSAGETYPE_PREFIX+nameUsageTp, null);

				if(attrCode!=null){
				Attribute newAttr = new Attribute(attrCode);

				for (CriticalData criticalData : vecCritVectorForPersonName) {
					String instancePK = criticalData.getInstancePK();
					if(instancePK == null || instancePK.equals(nameUsageTp)) {
						String fieldName = criticalData.getElementName();
						String givenNameOne = persNameBObj.getGivenNameOne();
						if (StringUtils.isBlank(persNameBObj
									.getGivenNameOne())
									&& fieldName
											.equalsIgnoreCase(GIVEN_NAME_ONE_MDM_ATTRIBUTE_NAME)) {
								// April 17 : Dhaval : Added MVP2 3 countries.
								if(xmarketName!=null && xmarketName.equalsIgnoreCase(ExternalRuleConstant.INDONESIA_MARKET_NAME) || 
										xmarketName.equalsIgnoreCase(ExternalRuleConstant.VIETNAM_MARKET_NAME) ||
										xmarketName.equalsIgnoreCase(ExternalRuleConstant.SINGAPORE_MARKET_NAME) ||
										xmarketName.equalsIgnoreCase(ExternalRuleConstant.MARKET_NAME_BRAZIL) ||
										xmarketName.equalsIgnoreCase(ExternalRuleConstant.HUNGARY_MARKET_NAME) ||
										xmarketName.equalsIgnoreCase(ExternalRuleConstant.ROMANIA_MARKET_NAME) ||
										xmarketName.equalsIgnoreCase(ExternalRuleConstant.SLOVAKIA_MARKET_NAME))
								{ 
									if(givenNameOne == null || givenNameOne.isEmpty()){

										givenNameOne = "DUMMY";
									}
									newAttr.setField("givenname1", givenNameOne);
								}

							}
						if (StringUtils.isNonBlank(persNameBObj.getGivenNameOne())
								&& fieldName
								.equalsIgnoreCase(GIVEN_NAME_ONE_MDM_ATTRIBUTE_NAME)) {
							if(xmarketName!=null && xmarketName.equalsIgnoreCase(ExternalRuleConstant.JAPAN_MARKET_NAME))
							{
							
							if(givenNameOne.contains("お客様個人名を入力してください")){
			                	  
								givenNameOne = givenNameOne.replace("お客様個人名を入力してください", "");
			                	  
			                  } else if(givenNameOne.contains("【お客様個人名を入力してください】")){
			                	  
			                	  givenNameOne = givenNameOne.replace("【お客様個人名を入力してください】", "");
			                	  
			                  } else if(givenNameOne.contains("削除顧客")){
			                	  
			                	  givenNameOne = givenNameOne.replace("削除顧客", "");
			                	  
			                  } else if(givenNameOne.contains("不明")){
			                	  
			                	  givenNameOne = givenNameOne.replace("不明", "");
			                	  
			                  } else if(givenNameOne.contains("フメイ")){
			                	  
			                	  givenNameOne = givenNameOne.replace("フメイ", "");
			                	  
			                  } else if(givenNameOne.contains("名乗らず")){
			                	  
			                	  givenNameOne = givenNameOne.replace("名乗らず", ""); 
			                  }
			                  if(givenNameOne.contains("　")){
			                	  
			                	  givenNameOne = givenNameOne.replaceAll("　", " ");
			                  }if(givenNameOne.contains("－")){
			                	  
			                	  givenNameOne = givenNameOne.replaceAll("－", "-");
			                    
		                  } if(givenNameOne.contains("・")){
		                	  
		                	  givenNameOne = givenNameOne.replaceAll("・", "・");
		                  }
		                  	if(givenNameOne.contains("�")){
		                	  
		                	  givenNameOne = givenNameOne.replaceAll("�", "");
		                  }
							}
							if(xmarketName!=null && xmarketName.equalsIgnoreCase(ExternalRuleConstant.MARKET_NAME_INDIA))
							{
								if(givenNameOne.contains("�")){
				                	  
				                	  givenNameOne = givenNameOne.replaceAll("�", "");
				                  }else if(givenNameOne.contains("✔")){
				                	  
				                	  givenNameOne = givenNameOne.replaceAll("✔", "");
				                  }
													
							}
							if(xmarketName!=null && xmarketName.equalsIgnoreCase(ExternalRuleConstant.MARKET_NAME_AUSTRALIA)
									||xmarketName!=null && xmarketName.equalsIgnoreCase(ExternalRuleConstant.MARKET_NAME_NEWZEALAND))
							{
								if(givenNameOne.contains("�")){
				                	  
				                	  givenNameOne = givenNameOne.replaceAll("�", "");
				                  }
													
							}
							if(xmarketName.equalsIgnoreCase(ExternalRuleConstant.KOREA_MARKET_NAME))
							{
								if(givenNameOne.contains("~")){
									givenNameOne = givenNameOne.replaceAll("~", " ");
								}if(givenNameOne.contains("�")){
									givenNameOne = givenNameOne.replaceAll("�", " ");
								}if(givenNameOne.contains(":")){
									givenNameOne = givenNameOne.replaceAll(":", " ");
								}if(givenNameOne.contains(" ")){
									givenNameOne = givenNameOne.replaceAll(" ", " ");
								}if(givenNameOne.contains("^")){
									givenNameOne = givenNameOne.replaceAll("^", " ");
								}if(givenNameOne.contains("|")){
									givenNameOne = givenNameOne.replaceAll("|", " ");
								}
							}
							/* AEM Market changes - Pushpraj */
								if(xmarketName!=null && ExternalRuleConstant.AEM_MARKETS.contains(xmarketName))
								{
									ExternalRuleUtil extUtil=new ExternalRuleUtil();
									givenNameOne=extUtil.processNameDataAEM(givenNameOne,xmarketName,PERSON_GROUP_NAME.toString());
								}
							if(isNationalIdPresent && ((XPersonNameBObjExt)persNameBObj).getXPersonNameRetailerFlag()!= null &&
									((XPersonNameBObjExt)persNameBObj).getXPersonNameRetailerFlag().equals("FS")){
								newAttr.setField("givenname1", ((XPersonNameBObjExt)persNameBObj).getXGivenNameOneLocal());
							}else{
								newAttr.setField("givenname1", givenNameOne);
							}
						} else if (StringUtils.isNonBlank(persNameBObj
								.getGivenNameTwo())
								&& fieldName
								.equalsIgnoreCase(GIVEN_NAME_TWO_MDM_ATTRIBUTE_NAME)) {
							if(isNationalIdPresent && ((XPersonNameBObjExt)persNameBObj).getXPersonNameRetailerFlag()!= null &&
									((XPersonNameBObjExt)persNameBObj).getXPersonNameRetailerFlag().equals("FS")){
								newAttr.setField("givenname2", ((XPersonNameBObjExt)persNameBObj).getXGivenNameTwoLocal());
							}else{
								newAttr.setField("givenname2", persNameBObj.getGivenNameTwo());
							}
						} else if (StringUtils.isNonBlank(persNameBObj
								.getGivenNameThree())
								&& fieldName
								.equalsIgnoreCase(GIVEN_NAME_THREE_MDM_ATTRIBUTE_NAME)) {
							newAttr.setField("givenname3", persNameBObj
									.getGivenNameThree());
						}else if (StringUtils.isNonBlank(persNameBObj
								.getGenerationValue())
								&& fieldName
								.equalsIgnoreCase(GENERATION_VALUE_MDM_ATTRIBUTE_NAME)) {
							newAttr.setField("generation", persNameBObj
									.getGenerationValue());
						} else if (StringUtils.isNonBlank(persNameBObj
								.getPrefixValue())
								&& fieldName
								.equalsIgnoreCase(PREFIX_VALUE_MDM_ATTRIBUTE_NAME)) {
							newAttr.setField("prefix", persNameBObj
									.getPrefixValue());
						}else if (StringUtils.isNonBlank(persNameBObj
								.getLastName())
								&& fieldName
								.equalsIgnoreCase(LAST_NAME_MDM_ATTRIBUTE_NAME)) {
							String lastName = persNameBObj.getLastName();
							
							if(xmarketName!=null && xmarketName.equalsIgnoreCase(ExternalRuleConstant.JAPAN_MARKET_NAME))
							{
							if(lastName.contains("お客様個人名を入力してください")){
			                	  
								lastName = lastName.replace("お客様個人名を入力してください", "");
			                	  
			                  } else if(lastName.contains("【お客様個人名を入力してください】")){
			                	  
			                	  lastName = lastName.replace("【お客様個人名を入力してください】", "");
			                	  
			                  } else if(lastName.contains("削除顧客")){
			                	  
			                	  lastName = lastName.replace("削除顧客", "");
			                	  
			                  } else if(lastName.contains("不明")){
			                	  
			                	  lastName = lastName.replace("不明", "");
			                	  
			                  } else if(lastName.contains("フメイ")){
			                	  
			                	  lastName = lastName.replace("フメイ", "");
			                	  
			                  } else if(lastName.contains("名乗らず")){
			                	  
			                	  lastName = lastName.replace("名乗らず", ""); 
			                 
			                  } if(lastName.contains("　")){
			                	  
			                	  lastName = lastName.replaceAll("　", " ");
			                  }if(lastName.contains("－")){
			                	  
			                	  lastName = lastName.replaceAll("－", "-");
			                    
		                  } if(lastName.contains("・")){
		                	  
		                	  lastName = lastName.replaceAll("・", "・");
		                  }
		                  	if(lastName.contains("�")){
		                	  
		                	  lastName = lastName.replaceAll("�", "");
		                  }
							}
								if(xmarketName!=null && xmarketName.equalsIgnoreCase(ExternalRuleConstant.MARKET_NAME_INDIA))
							{
								if(lastName.contains("�")){
				                	  
									lastName = lastName.replaceAll("�", "");
				                  }else if(lastName.contains("✔")){
				                	  
				                	  lastName = lastName.replaceAll("✔", "");
				                  }
													
							}
								if(xmarketName.equalsIgnoreCase(ExternalRuleConstant.KOREA_MARKET_NAME))
								{
									if(lastName.contains("~")){
										lastName = lastName.replaceAll("~", " ");
									}if(lastName.contains("�")){
										lastName = lastName.replaceAll("�", " ");
									}if(lastName.contains(":")){
										lastName = lastName.replaceAll(":", " ");
									}if(lastName.contains(" ")){
										lastName = lastName.replaceAll(" ", " ");
									}if(lastName.contains("^")){
										lastName = lastName.replaceAll("^", " ");
									}if(lastName.contains("|")){
										lastName = lastName.replaceAll("|", " ");
									}
								}
								if(xmarketName!=null && xmarketName.equalsIgnoreCase(ExternalRuleConstant.MARKET_NAME_AUSTRALIA)
										||xmarketName!=null && xmarketName.equalsIgnoreCase(ExternalRuleConstant.MARKET_NAME_NEWZEALAND))
								{
									if(lastName.contains("�")){
					                	  
										lastName = lastName.replaceAll("�", "");
					                  }
														
								}
							/* AEM Market changes - Pushpraj */
								if(xmarketName!=null && ExternalRuleConstant.AEM_MARKETS.contains(xmarketName))
								{
									ExternalRuleUtil extUtil=new ExternalRuleUtil();
									lastName=extUtil.processNameDataAEM(lastName,xmarketName,PERSON_GROUP_NAME.toString());
								}
								
							if(isNationalIdPresent && ((XPersonNameBObjExt)persNameBObj).getXPersonNameRetailerFlag()!= null &&
									((XPersonNameBObjExt)persNameBObj).getXPersonNameRetailerFlag().equals("FS")){
								newAttr.setField("lastname", ((XPersonNameBObjExt)persNameBObj).getXLastNameLocal());
							}else{
								newAttr.setField("lastname", lastName);
							}
						}
					}
				}
				if (newAttr.getFieldNames().size() > 0) {
					
					boolean isPersonNameActive = checkIfActiveObject(persNameBObj.getEObjPersonName().getEndDt(), persNameBObj.getControl());
					newAttr.setActive(isPersonNameActive);
					
					personRecord.addAttribute(newAttr);
					}
				}
			}
		}

	}

	/**
	 * Builds all person address attributes for a person
	 * 
	 * @param vecPersonAddress
	 * @throws Exception
	 */
	private void buildPersonAddressAttributes(
			Vector<TCRMPartyAddressBObj> vecPersonAddress, String xmarketName) throws Exception {

		if (vecPersonAddress != null && vecPersonAddress.size() > 0) {
			Vector<CriticalData> vecPartyAddress = getCriticalDataElementsOfChildObjectOfPerson(vecPersonAddress.firstElement());
			Vector<CriticalData> vecCritVectorForAddr = getCriticalDataElementsOfChildObjectOfPerson(vecPersonAddress
					.firstElement().getTCRMAddressBObj());
			for (TCRMPartyAddressBObj prtyAddressBobj : vecPersonAddress) {
				TCRMAddressBObj tcrmAddBObj = prtyAddressBobj.getTCRMAddressBObj();

				String addressUsageType = prtyAddressBobj.getAddressUsageType();
				
				if (probabilisticSearch && addressUsageType==null)
				 {
					 //default address usage type to 1 if not provided in the request
					addressUsageType = "1";
				 }
				String attrCode = null;
				for (CriticalData partyAddressCriticalData : vecPartyAddress) {
					if (StringUtils.isBlank(attrCode)) {
						String instancePK = partyAddressCriticalData.getInstancePK();
						if (instancePK == null || instancePK.equals(addressUsageType))  {
							attrCode = PropertyManager.getOptionalProperty(PERSON_PARTYADDRESS_ADDRESSUSAGETYPE_PREFIX+addressUsageType, null);

							if(attrCode!=null){

								Attribute personAddrAttr = new Attribute(attrCode);
								for (CriticalData criticalData : vecCritVectorForAddr) {

									String fieldName = criticalData.getElementName();
									if (StringUtils.isNonBlank(tcrmAddBObj.getCity())
											&& fieldName
											.equalsIgnoreCase(CITY_MDM_ATTRIBUTE_NAME)) {
										String cityName=tcrmAddBObj.getCity();
										
										if(xmarketName.equalsIgnoreCase(ExternalRuleConstant.JAPAN_MARKET_NAME))
										{
											if(cityName.contains("　")){
							                	  
												cityName = cityName.replaceAll("　", " ");
											}if(cityName.contains("－")){
							                	  
												cityName = cityName.replaceAll("－", "-");
							                    
						                  } if(cityName.contains("・")){
						                	  
						                	  cityName = cityName.replaceAll("・", "・");
						                  }
						                  	if(cityName.contains("�")){
						                	  
						                	  cityName = cityName.replaceAll("�", "");
						                  }
						                	
										}
										
										if(xmarketName.equalsIgnoreCase(ExternalRuleConstant.KOREA_MARKET_NAME))
										{
											if(cityName.contains("~")){
												cityName = cityName.replaceAll("~", " ");
											}if(cityName.contains("�")){
												cityName = cityName.replaceAll("�", " ");
											}if(cityName.contains(":")){
												cityName = cityName.replaceAll(":", " ");
											}if(cityName.contains(" ")){
												cityName = cityName.replaceAll(" ", " ");
											}if(cityName.contains("^")){
												cityName = cityName.replaceAll("^", " ");
											}if(cityName.contains("|")){
												cityName = cityName.replaceAll("|", " ");
											}if(cityName.equalsIgnoreCase("DUMMY")){
							                	  
							                	  cityName = " ";
							                  }
										}
										if(xmarketName!=null && xmarketName.equalsIgnoreCase(ExternalRuleConstant.MARKET_NAME_AUSTRALIA)
												||xmarketName!=null && xmarketName.equalsIgnoreCase(ExternalRuleConstant.MARKET_NAME_NEWZEALAND))
										{
											if(cityName.contains("�")){

												cityName = cityName.replaceAll("�", "");
											}

										}
										personAddrAttr.setField("city", cityName);
									} else if (StringUtils.isNonBlank(tcrmAddBObj
											.getResidenceNumber())
											&& fieldName
											.equalsIgnoreCase(RESIDENCE_NUMBER_MDM_ATTRIBUTE_NAME)) {
										String residenceNum=tcrmAddBObj.getResidenceNumber();
										if(xmarketName.equalsIgnoreCase(ExternalRuleConstant.JAPAN_MARKET_NAME))
										{
											if(residenceNum.contains("　")){
							                	  
												residenceNum = residenceNum.replaceAll("　", " ");
											}if(residenceNum.contains("－")){
							                	  
												residenceNum = residenceNum.replaceAll("－", "-");
							                    
						                  } if(residenceNum.contains("・")){
						                	  
						                	  residenceNum = residenceNum.replaceAll("・", "・");
						                  }
						                  	if(residenceNum.contains("�")){
						                	  
						                	  residenceNum = residenceNum.replaceAll("�", "");
						                  }
										}
										if(xmarketName.equalsIgnoreCase(ExternalRuleConstant.KOREA_MARKET_NAME))
										{
											if(residenceNum.contains("~")){
												residenceNum = residenceNum.replaceAll("~", " ");
											}if(residenceNum.contains("�")){
												residenceNum = residenceNum.replaceAll("�", " ");
											}if(residenceNum.contains("^")){
												residenceNum = residenceNum.replaceAll("^", " ");
											}if(residenceNum.contains(":")){
												residenceNum = residenceNum.replaceAll(":", " ");
											}if(residenceNum.contains("|")){
												residenceNum = residenceNum.replaceAll("|", " ");
											}if(residenceNum.contains(" ")){
												residenceNum = residenceNum.replaceAll(" ", " ");
											}if(residenceNum.equalsIgnoreCase("DUMMY")){
												residenceNum = " ";
											}
										}

										if(xmarketName!=null && xmarketName.equalsIgnoreCase(ExternalRuleConstant.MARKET_NAME_AUSTRALIA)
												||xmarketName!=null && xmarketName.equalsIgnoreCase(ExternalRuleConstant.MARKET_NAME_NEWZEALAND))
										{
											if(residenceNum.contains("�")){

												residenceNum = residenceNum.replaceAll("�", "");
											}

										}

										personAddrAttr.setField("residencenum", residenceNum);
									} else if (StringUtils.isNonBlank(tcrmAddBObj
											.getProvinceStateType())
											&& fieldName
											.equalsIgnoreCase(PROVINCE_STATE_MDM_ATTRIBUTE_NAME)) {
										personAddrAttr.setField("provstate", tcrmAddBObj
												.getProvinceStateType());
									} else if (StringUtils.isNonBlank(tcrmAddBObj
											.getAddressLineOne())
											&& fieldName
											.equalsIgnoreCase(ADDRESS_LINE_ONE_MDM_ATTRIBUTE_NAME)) {
										
										
										String addressLineOne = tcrmAddBObj.getAddressLineOne();
										
										if(xmarketName.equalsIgnoreCase(ExternalRuleConstant.JAPAN_MARKET_NAME))
										{
										if(addressLineOne.contains("　")){
						                	  
											addressLineOne = addressLineOne.replaceAll("　", " ");
										}if(addressLineOne.contains("－")){
						                	  
						                	  addressLineOne = addressLineOne.replaceAll("－", "-");
						                    
					                  } if(addressLineOne.contains("・")){
					                	  
					                	  addressLineOne = addressLineOne.replaceAll("・", "・");
					                  }
					                  if(addressLineOne.contains("�")){
					                	  
					                	  addressLineOne = addressLineOne.replaceAll("�", "");
					                  }
										}
											if(xmarketName.equalsIgnoreCase(ExternalRuleConstant.KOREA_MARKET_NAME))
										{
											if(addressLineOne.contains("~")){							                	  
												addressLineOne = addressLineOne.replaceAll("~", " ");
											}if(addressLineOne.contains("�")){							                	  
												addressLineOne = addressLineOne.replaceAll("�", " ");
											}if(addressLineOne.contains(":")){							                	  
												addressLineOne = addressLineOne.replaceAll(":", " ");
											}if(addressLineOne.contains("^")){							                	  
												addressLineOne = addressLineOne.replaceAll("^", " ");
											}if(addressLineOne.contains("|")){							                	  
												addressLineOne = addressLineOne.replaceAll("|", " ");
											}if(addressLineOne.contains(" ")){
												addressLineOne = addressLineOne.replaceAll(" ", " ");
											}if(addressLineOne.equalsIgnoreCase("DUMMY")){
												addressLineOne = " ";
											}
										}

										if(xmarketName!=null && xmarketName.equalsIgnoreCase(ExternalRuleConstant.MARKET_NAME_AUSTRALIA)
												||xmarketName!=null && xmarketName.equalsIgnoreCase(ExternalRuleConstant.MARKET_NAME_NEWZEALAND))
										{
											if(addressLineOne.contains("�")){

												addressLineOne = addressLineOne.replaceAll("�", "");
											}

										}

										personAddrAttr.setField("addrline1", addressLineOne);
										
									} else if (StringUtils.isNonBlank(tcrmAddBObj
											.getAddressLineTwo())
											&& fieldName
											.equalsIgnoreCase(ADDRESS_LINE_TWO_MDM_ATTRIBUTE_NAME)) {
										
										
										String addressLineTwo = tcrmAddBObj.getAddressLineTwo();
										
										if(xmarketName.equalsIgnoreCase(ExternalRuleConstant.JAPAN_MARKET_NAME))
										{
											
										if(addressLineTwo.contains("　")){
						                   addressLineTwo = addressLineTwo.replaceAll("　", " ");
										
										} if(addressLineTwo.contains("－")){
						                          addressLineTwo = addressLineTwo.replaceAll("－", "-");
						                    
					                  } if(addressLineTwo.contains("・")){
					                	   	    addressLineTwo = addressLineTwo.replaceAll("・", "・");
					                 
					                  }
					                  if(addressLineTwo.contains("�")){
				                	   	    addressLineTwo = addressLineTwo.replaceAll("�", "");
				                 
					                  	}
										}
										if(xmarketName.equalsIgnoreCase(ExternalRuleConstant.KOREA_MARKET_NAME))
										{
											if(addressLineTwo.contains("~")){							                	  
												addressLineTwo = addressLineTwo.replaceAll("~", " ");
											}if(addressLineTwo.contains("�")){							                	  
												addressLineTwo = addressLineTwo.replaceAll("�", " ");
											}if(addressLineTwo.contains("^")){							                	  
												addressLineTwo = addressLineTwo.replaceAll("^", " ");
											}if(addressLineTwo.contains(":")){							                	  
												addressLineTwo = addressLineTwo.replaceAll(":", " ");
											}if(addressLineTwo.contains("|")){							                	  
												addressLineTwo = addressLineTwo.replaceAll("|", " ");
											}if(addressLineTwo.contains(" ")){
												addressLineTwo = addressLineTwo.replaceAll(" ", " ");
											}if(addressLineTwo.equalsIgnoreCase("DUMMY")){
												addressLineTwo = " ";
											}
										}

										if(xmarketName!=null && xmarketName.equalsIgnoreCase(ExternalRuleConstant.MARKET_NAME_AUSTRALIA)
												||xmarketName!=null && xmarketName.equalsIgnoreCase(ExternalRuleConstant.MARKET_NAME_NEWZEALAND))
										{
											if(addressLineTwo.contains("�")){

												addressLineTwo = addressLineTwo.replaceAll("�", "");
											}

										}
										personAddrAttr.setField("addrline2", addressLineTwo);
									} else if (StringUtils.isNonBlank(tcrmAddBObj
											.getAddressLineThree())
											&& fieldName
											.equalsIgnoreCase(ADDRESS_LINE_THREE_MDM_ATTRIBUTE_NAME)) {
										
										String addressLineThree = tcrmAddBObj.getAddressLineThree();
										
										if(xmarketName.equalsIgnoreCase(ExternalRuleConstant.JAPAN_MARKET_NAME))
										{
										if(addressLineThree.contains("　")){
						                	  
											addressLineThree = addressLineThree.replaceAll("　", " ");
																                	  
						                  } if(addressLineThree.contains("－")){
						                	  
						                	  addressLineThree = addressLineThree.replaceAll("－", "-");
						                    
					                  } if(addressLineThree.contains("・")){
					                	  
					                	  addressLineThree = addressLineThree.replaceAll("・", "・");
					                  }
					                  	if(addressLineThree.contains("�")){
					                	  
					                	  addressLineThree = addressLineThree.replaceAll("�", "");
					                  }
										}
										if(xmarketName.equalsIgnoreCase(ExternalRuleConstant.KOREA_MARKET_NAME))
										{
											if(addressLineThree.contains("~")){							                	  
												addressLineThree = addressLineThree.replaceAll("~", " ");
											}if(addressLineThree.contains("�")){							                	  
												addressLineThree = addressLineThree.replaceAll("�", " ");
											}if(addressLineThree.contains("|")){							                	  
												addressLineThree = addressLineThree.replaceAll("|", " ");
											}if(addressLineThree.contains("^")){							                	  
												addressLineThree = addressLineThree.replaceAll("^", " ");
											}if(addressLineThree.contains(":")){							                	  
												addressLineThree = addressLineThree.replaceAll(":", " ");
											}if(addressLineThree.contains(" ")){
												addressLineThree = addressLineThree.replaceAll(" ", " ");
											}if(addressLineThree.equalsIgnoreCase("DUMMY")){
												addressLineThree = " ";
											}
										}
										personAddrAttr.setField("addrline3", addressLineThree);
									} else if (StringUtils.isNonBlank(tcrmAddBObj
											.getZipPostalCode())
											&& fieldName
											.equalsIgnoreCase(ZIP_POSTAL_CODE_MDM_ATTRIBUTE_NAME)) {
										String zipPostalCode=tcrmAddBObj.getZipPostalCode();
										
										if(xmarketName.equalsIgnoreCase(ExternalRuleConstant.KOREA_MARKET_NAME))
										{
											if(zipPostalCode.contains("~")){							                	  
												zipPostalCode = zipPostalCode.replaceAll("~", " ");
											}if(zipPostalCode.contains("�")){							                	  
												zipPostalCode = zipPostalCode.replaceAll("�", " ");
											}if(zipPostalCode.contains("|")){							                	  
												zipPostalCode = zipPostalCode.replaceAll("|", " ");
											}if(zipPostalCode.contains("^")){							                	  
												zipPostalCode = zipPostalCode.replaceAll("^", " ");
											}if(zipPostalCode.contains(":")){							                	  
												zipPostalCode = zipPostalCode.replaceAll(":", " ");
											}if(zipPostalCode.contains(" ")){
												zipPostalCode = zipPostalCode.replaceAll(" ", " ");
											}if(zipPostalCode.equalsIgnoreCase("DUMMY")){
												zipPostalCode = " ";
											}
										}
										if(xmarketName.equalsIgnoreCase(ExternalRuleConstant.JAPAN_MARKET_NAME))
										{			                  		
					                  		if(!zipPostalCode.matches("[0-9]*"))
					                  		{
					                  			zipPostalCode=null;
					                  		}
										}

										if(xmarketName!=null && xmarketName.equalsIgnoreCase(ExternalRuleConstant.MARKET_NAME_AUSTRALIA)
												||xmarketName!=null && xmarketName.equalsIgnoreCase(ExternalRuleConstant.MARKET_NAME_NEWZEALAND))
										{
											if(zipPostalCode.contains("�")){

												zipPostalCode = zipPostalCode.replaceAll("�", "");
											}

										}

										personAddrAttr.setField("postalcode", zipPostalCode);
										
									}

								}
								if (personAddrAttr.getFieldNames().size() > 0) {
									boolean isPersonAddrActive = checkIfActiveObject(prtyAddressBobj.getEObjLocationGroup().getEndDt(), prtyAddressBobj.getControl());
									personAddrAttr.setActive(isPersonAddrActive);
									
									// Start change to exclude all Address from EME_RECCMPD for Japan,AU&NZ by Shashi (20-08-2021)
									if(xmarketName != null && !(xmarketName.equalsIgnoreCase(ExternalRuleConstant.JAPAN_MARKET_NAME)
											|| xmarketName.equalsIgnoreCase(ExternalRuleConstant.MARKET_NAME_AUSTRALIA)
											|| xmarketName.equalsIgnoreCase(ExternalRuleConstant.MARKET_NAME_NEWZEALAND)))
									{	
									
									personRecord.addAttribute(personAddrAttr);
									}
									// End Changes
								}
							}
						}
					}
				}
			}
		}
	}

	/**
	 * Builds all person identification attributes for a person
	 * 
	 * @param vecPersonIdentification
	 * @throws Exception
	 */
	private void buildPersonIdentificationAttributes(
			Vector<TCRMPartyIdentificationBObj> vecPersonIdentification, String xmarketName)
			throws Exception {
		if (vecPersonIdentification != null
				&& vecPersonIdentification.size() > 0) {
			Vector<CriticalData> vecCritVectorForPersonIdentification = getCriticalDataElementsOfChildObjectOfPerson(vecPersonIdentification
					.firstElement());

			for (TCRMPartyIdentificationBObj prtyIdentBobj : vecPersonIdentification) {
				String identUsageType = prtyIdentBobj.getIdentificationType();
				String attrCode = PropertyManager.getOptionalProperty(PERSON_PARTYIDENTIFICATION_IDENTIFICATIONTYPE_PREFIX+identUsageType, null);

				if(attrCode!=null){

					for (CriticalData criticalData : vecCritVectorForPersonIdentification) {
						String instancePK = criticalData.getInstancePK();
						if (instancePK == null || instancePK.equals(identUsageType)) {
							String fieldName = criticalData.getElementName();

							if (StringUtils.isNonBlank(prtyIdentBobj
									.getIdentificationNumber())
									&& fieldName
									.equalsIgnoreCase(IDENTIFICATION_NUMBER_MDM_ATTRIBUTE_NAME)) {
								Attribute personIdentAttr = new Attribute(attrCode);
								personIdentAttr.setField("idnum", prtyIdentBobj
										.getIdentificationNumber());
								//changed for FS
								if(prtyIdentBobj.getIdentificationType() != null && prtyIdentBobj.getIdentificationType().equals("1006"))
									isNationalIdPresent = true;
								//changed for FS
								boolean isPersonIdentificationActive = checkIfActiveObject(prtyIdentBobj.getEObjIdentifier().getEndDt(), prtyIdentBobj.getControl());
								personIdentAttr.setActive(isPersonIdentificationActive);
								
									// Start change to exclude all Ids from EME_RECCMPD for Thailand by Shashi (15-10-2020)
								if(xmarketName != null && !(xmarketName.equalsIgnoreCase(ExternalRuleConstant.MARKET_NAME_THAILAND)))
								{	
									//If market is other than THA then add it
									personRecord.addAttribute(personIdentAttr);
								}
								
								
								// End
							}
						}
					}
				}
			}
		}
	}

	/**
	 * Builds all person contact method attributes for a person
	 * 
	 * @param vecPersonContMethod
	 * @throws Exception
	 */
	private void buildPersonContactMethodAttributes(
			Vector<TCRMPartyContactMethodBObj> vecPersonContMethod)
			throws Exception {
		if (vecPersonContMethod != null && vecPersonContMethod.size() > 0) {
			Vector<CriticalData> vecCritVectorForPartyContMethod = getCriticalDataElementsOfChildObjectOfPerson(vecPersonContMethod
					.firstElement());
			Vector<CriticalData> vecCritVectorForContMethod = getCriticalDataElementsOfChildObjectOfPerson(vecPersonContMethod
					.firstElement().getTCRMContactMethodBObj());

			for (TCRMPartyContactMethodBObj prtyContBobj : vecPersonContMethod) {
				TCRMContactMethodBObj contMethodBobj = prtyContBobj
						.getTCRMContactMethodBObj();


				String contMethodUsageType = prtyContBobj
						.getContactMethodUsageType();

				if (probabilisticSearch && contMethodUsageType==null)
				{
					//default contact method usage type to 1 if none provided in he request
					contMethodUsageType = "1";
				}

				//start of change for AU NZ 8 Aug 2018 to exclude smart phone numbers

				//For AUNZ phones exclude smart numbers from matching
				if(!isAUNZPhone(contMethodUsageType) || !isSmartNumber(contMethodBobj.getReferenceNumber())){

					//End of change for AU NZ 8 Aug 2018 to exclude smart phone numbers

					String attrCode = PropertyManager.getOptionalProperty(PERSON_PARTYCONTACTMETHOD_CONTACTMETHODUSAGETYPE_PREFIX+contMethodUsageType, null);

					if(attrCode!=null){

						for (CriticalData partyContMethodcriticalData : vecCritVectorForPartyContMethod) {
							String entityName = partyContMethodcriticalData.getEntityType();
							String instancePK = partyContMethodcriticalData.getInstancePK();
							if(partyContMethodcriticalData.getElementName().equals(CONTACTMETHOD_USAGETYPE_MDM_ATTRIBUTE_NAME)){
								if ((entityName==null && instancePK == null)||( entityName.equals(CONTACTMETHOD_USAGETYPE_MDM_ATTRIBUTE_NAME)&& instancePK.equals(contMethodUsageType))) {
									for (CriticalData contMethodcriticalData : vecCritVectorForContMethod) {
										String fieldName = contMethodcriticalData.getElementName();
										if (StringUtils.isNonBlank(contMethodBobj
												.getReferenceNumber())
												&& fieldName
												.equalsIgnoreCase(REFERENCE_NUMBER_MDM_ATTRIBUTE_NAME)) {
											Attribute personContMethAttr = new Attribute(attrCode);

											if(prtyContBobj.getContactMethodUsageType().equals("1007") || prtyContBobj.getContactMethodUsageType().equalsIgnoreCase("1013")
													||prtyContBobj.getContactMethodUsageType().equals("1018") || prtyContBobj.getContactMethodUsageType().equals("1035")|| prtyContBobj.getContactMethodUsageType().equalsIgnoreCase("1030")
													|| prtyContBobj.getContactMethodUsageType().equalsIgnoreCase("1031") || prtyContBobj.getContactMethodUsageType().equalsIgnoreCase("1032") || prtyContBobj.getContactMethodUsageType().equalsIgnoreCase("1041") 
													|| prtyContBobj.getContactMethodUsageType().equalsIgnoreCase("1053"))
												personContMethAttr.setField("email", contMethodBobj
														.getReferenceNumber());
											else{	

												personContMethAttr.setField("refnum", contMethodBobj
														.getReferenceNumber());
											}
											boolean isPersonContMethActive = checkIfActiveObject(prtyContBobj.getEObjLocationGroup().getEndDt(), prtyContBobj.getControl());
											personContMethAttr.setActive(isPersonContMethActive);

											personRecord.addAttribute(personContMethAttr);
										}
									}
								}	
							}		
						}
					}
				}
			}
		}
	}
	
	/**
	 * Builds all person Bank Account attributes for a person
	 * 
	 * @param vecPersonBankAccount
	 * @throws Exception
	 */
	private void buildPersonBankAccountAttributes(
			Vector<TCRMPartyBankAccountBObj> vecPersonBankAccount) throws Exception {

		if (vecPersonBankAccount != null && vecPersonBankAccount.size() > 0) {
			Vector<CriticalData> vecCritVectorForBankAccount = getCriticalDataElementsOfChildObjectOfPerson(vecPersonBankAccount
					.firstElement());
			for (TCRMPartyBankAccountBObj prtyBankAccountBobj : vecPersonBankAccount) {
				
				String accountType = prtyBankAccountBobj.getAccountType();

				String attrCode = PropertyManager.getOptionalProperty(PERSON_PARTYBANKACCOUNT_ACCOUNTTYPE_PREFIX+accountType, null);

				if(attrCode!=null){

					Attribute personBankAcctAttr = new Attribute(attrCode);
					for (CriticalData criticalData : vecCritVectorForBankAccount) {
						String instancePK = criticalData.getInstancePK();
						if (instancePK == null || instancePK.equals(accountType)) {
							String fieldName = criticalData.getElementName();
							if (StringUtils.isNonBlank(prtyBankAccountBobj.getBankNumber())
									&& fieldName
									.equalsIgnoreCase(BANK_NUMBER_MDM_ATTRIBUTE_NAME)) {
								personBankAcctAttr.setField("banknum", prtyBankAccountBobj.getBankNumber());
							} else if (StringUtils.isNonBlank(prtyBankAccountBobj
									.getBranchNumber())
									&& fieldName
									.equalsIgnoreCase(BRANCH_NUMBER_MDM_ATTRIBUTE_NAME)) {
								personBankAcctAttr.setField("branchnum", prtyBankAccountBobj
										.getBranchNumber());
							} else if (StringUtils.isNonBlank(prtyBankAccountBobj
									.getAccountNumber())
									&& fieldName
									.equalsIgnoreCase(ACCOUNT_NUMBER_MDM_ATTRIBUTE_NAME)) {
								personBankAcctAttr.setField("acctnum", prtyBankAccountBobj
										.getAccountNumber());
							} 
						}
					}
					if (personBankAcctAttr.getFieldNames().size() > 0) {
						boolean isPersonBankAccountActive = checkIfActiveObject(prtyBankAccountBobj.getEObjPaymentSource().getEndDt(), prtyBankAccountBobj.getControl());
						personBankAcctAttr.setActive(isPersonBankAccountActive);

						personRecord.addAttribute(personBankAcctAttr);
					}
				}	
			}
		}
	}
	
	/**
	 * Builds all person Bank Account attributes for a person
	 * 
	 * @param vecPersonBankAccount
	 * @throws Exception
	 */
	private void buildPersonChargeCardAttributes(
			Vector<TCRMPartyChargeCardBObj> vecPersonChargeCard) throws Exception {

		if (vecPersonChargeCard != null && vecPersonChargeCard.size() > 0) {
			Vector<CriticalData> vecCritVectorForChargeCard = getCriticalDataElementsOfChildObjectOfPerson(vecPersonChargeCard
					.firstElement());
			for (TCRMPartyChargeCardBObj prtyChargeCardBobj : vecPersonChargeCard) {
				
				String cardType = prtyChargeCardBobj.getCardType();

				String attrCode = PropertyManager.getOptionalProperty(PERSON_PARTYCHARGECARD_CARDTYPE_PREFIX+cardType, null);

				if(attrCode!=null){

					Attribute personChargeCardAttr = new Attribute(attrCode);
					for (CriticalData criticalData : vecCritVectorForChargeCard) {
						String instancePK = criticalData.getInstancePK();
						if (instancePK == null || instancePK.equals(cardType)) {
							String fieldName = criticalData.getElementName();
							if (StringUtils.isNonBlank(prtyChargeCardBobj.getCardNumber())
									&& fieldName
									.equalsIgnoreCase(CARD_NUMBER_MDM_ATTRIBUTE_NAME)) {
								personChargeCardAttr.setField("cardnum", prtyChargeCardBobj.getCardNumber());
							}  
						}
					}
					if (personChargeCardAttr.getFieldNames().size() > 0) {
						boolean isPersonChargeCardActive = checkIfActiveObject(prtyChargeCardBobj.getEObjPaymentSource().getEndDt(), prtyChargeCardBobj.getControl());
						personChargeCardAttr.setActive(isPersonChargeCardActive);

						personRecord.addAttribute(personChargeCardAttr);
					}
				}
			}
		}
	}
	
	/** Builds all the person attributes
	 * @param personObj
	 * @throws Exception
	 */
	private void buildPersonAttributes(TCRMPersonBObj personObj) throws Exception	{
		
		Vector<CriticalData> vecCritVectorForPerson = getCriticalDataElementsForGroup(personObj);

		// For each element a check is done if that element belongs to list
		// of active critical data elements of that group,only then it is
		// synchronized to EME.
		for (CriticalData criticalData : vecCritVectorForPerson) {
			
			String fieldName = criticalData.getElementName();
			if (StringUtils.isNonBlank(personObj.getBirthDate())
					&& fieldName
					.equalsIgnoreCase(BIRTH_DATE_MDM_ATTRIBUTE_NAME)) {
				
				//DOB removed for Australia Person
				if(!"AU".equalsIgnoreCase(((XPersonBObjExt)personObj).getXMarketName()) && !"NZ".equalsIgnoreCase(((XPersonBObjExt)personObj).getXMarketName())
						&& !"IND".equalsIgnoreCase(((XPersonBObjExt)personObj).getXMarketName()) && !"TUR".equalsIgnoreCase(((XPersonBObjExt)personObj).getXMarketName())
						&& !"ID".equalsIgnoreCase(((XPersonBObjExt) personObj).getXMarketName())
						&& !"VN".equalsIgnoreCase(((XPersonBObjExt) personObj)
								.getXMarketName())
						&& !"SG".equalsIgnoreCase(((XPersonBObjExt) personObj)
								.getXMarketName())
						&& !"ZA".equalsIgnoreCase(((XPersonBObjExt) personObj)
										.getXMarketName())
						&& !"JPN".equalsIgnoreCase(((XPersonBObjExt) personObj)
										.getXMarketName())				
								&& !ExternalRuleConstant.AEM_MARKETS.contains(((XPersonBObjExt) personObj)
										.getXMarketName())) {
					
					// convert to Date.
					personRecord.addAttribute(buildAttribute("PERBIRTHDATE",
							"val",
							DateFormatter.getDate(personObj.getBirthDate())));
				}
			}  
		}
	}

	public Record convert(DWLCommon rootBObj) throws Exception {

		TCRMPersonBObj personObj;
		XPersonBObjExt xPersonBOBjExt = new XPersonBObjExt();
		RecordId newRecordId;
		TCRMPartyComponent partyComponent = new TCRMPartyComponent();

		// Check if this is used to convert ProbabilisticPersonSearchBObj
		if (rootBObj instanceof ProbabilisticPersonSearchBObj) {
			probabilisticSearch = true;		
			newRecordId = new RecordId("MDMSP", "");
			personRecord = new Record(PERSON_REC_TYPE, newRecordId);
			
			String xmarketNameForSearch=rootBObj.getControl().getGeographicalRegion();		
			if (((ProbabilisticPersonSearchBObj) rootBObj).getTCRMPersonBObj() != null)
			{
				buildPersonAttributes(((ProbabilisticPersonSearchBObj) rootBObj).getTCRMPersonBObj());
			}
			//changed identification order before name
			buildPersonIdentificationAttributes(((ProbabilisticPersonSearchBObj) rootBObj)
					.getItemsTCRMPartyIdentificationBObj(),xmarketNameForSearch);
			
			buildPersonNameAttributes(((ProbabilisticPersonSearchBObj) rootBObj)
						.getItemsTCRMPersonNameBObj(),xmarketNameForSearch);

			/*buildPersonIdentificationAttributes(((ProbabilisticPersonSearchBObj) rootBObj)
						.getItemsTCRMPartyIdentificationBObj());*/

			
			buildPersonAddressAttributes(((ProbabilisticPersonSearchBObj) rootBObj)
					.getItemsTCRMPartyAddressBObj(),xmarketNameForSearch);
			
			buildPersonContactMethodAttributes(((ProbabilisticPersonSearchBObj) rootBObj)
					.getItemsTCRMPartyContactMethodBObj());

		}
		 else {
			personObj = (TCRMPersonBObj) rootBObj;
			
	    	//Changed for marketName CMPVAL (25 May 2018)
			DWLControl control = personObj.getControl();
			String partyId = null;
			String marketName = null;
			String marketNameSync = null;
			partyId = personObj.getPartyId();
			String txnType = (control.get("txnCategory")).toString();
			String requestName = (control.get("request_name")).toString();				
			xPersonBOBjExt = (XPersonBObjExt)partyComponent.getPerson(partyId, "0", control);
									
			if(txnType!=null && txnType.equalsIgnoreCase("update")){
			marketName = (control.get("marketName")).toString();
			}
			
			if (txnType != null && (txnType.equalsIgnoreCase("delete"))) {
				newRecordId = new RecordId("MDMSP", personObj.getPartyId());
				personRecord = new Record(PERSON_REC_TYPE, newRecordId);
				return personRecord;
			}
			
			//if(requestName!=null && requestName.equalsIgnoreCase("synchronizeeME")){
				marketNameSync = xPersonBOBjExt.getXMarketName();
			
			
			newRecordId = new RecordId("MDMSP", personObj.getPartyId());

			personRecord = new Record(PERSON_REC_TYPE, newRecordId);
			Vector<CriticalData> vecCritVectorForPerson = getCriticalDataElementsForGroup(personObj);
			
			//August 08, 2018 : Added by Diparnab for removal of magic number from Comparison String for Turkey Market : Start
			
			if(isMarketTurkey(txnType, requestName, marketName, marketNameSync, xPersonBOBjExt))
			{
				Vector<TCRMPartyIdentificationBObj> magicNumberVec = new Vector<TCRMPartyIdentificationBObj>();
				
				if(null!= personObj.getItemsTCRMPartyIdentificationBObj() && personObj.getItemsTCRMPartyIdentificationBObj().size()>0)
				{
					Vector<TCRMPartyIdentificationBObj> identificationBObjVec = personObj.getItemsTCRMPartyIdentificationBObj();
					
					for(TCRMPartyIdentificationBObj identificationBObj : identificationBObjVec)						
					{
						if(ExternalRuleConstant.ID_TYPE_MAGIC.equalsIgnoreCase(identificationBObj.getIdentificationType()))
						{
							magicNumberVec.add(identificationBObj);
						}
					}
					
					//November 16, 2018 : Added by Diparnab for fixing Magic Number removal from comparison string : Start
					/**
					 * Restrict all magic numbers from being populated in the comparison string
					 */
					if(null!= magicNumberVec && magicNumberVec.size()>0)
					{
						for(TCRMPartyIdentificationBObj dbMagicNumberBobj : magicNumberVec)
						{
							if(null!= dbMagicNumberBobj)
							{
								identificationBObjVec.remove(dbMagicNumberBobj);
							}							
						}
					}	
					
					//November 16, 2018 : Added by Diparnab for fixing Magic Number removal from comparison string : End
				}
			}
			
			//August 08, 2018 : Added by Diparnab for removal of magic number from Comparison String for Turkey Market : End
			
			buildPersonIdentificationAttributes(personObj
					.getItemsTCRMPartyIdentificationBObj(),marketNameSync);

			buildPersonNameAttributes(personObj.getItemsTCRMPersonNameBObj(),marketNameSync);

			buildPersonAddressAttributes(personObj.getItemsTCRMPartyAddressBObj(),marketNameSync);


			buildPersonContactMethodAttributes(personObj.getItemsTCRMPartyContactMethodBObj());

			if(personObj.getTCRMFinancialProfileBObj()!=null){
				buildPersonBankAccountAttributes(personObj
						.getTCRMFinancialProfileBObj().getItemsTCRMPartyBankAccountBObj());

				buildPersonChargeCardAttributes(personObj
						.getTCRMFinancialProfileBObj().getItemsTCRMPartyChargeCardBObj());
			}


			// For each element a check is done if that element belongs to list of
			// active critical data elements of that group,only then it is
			// synchronized to EME.
			for (CriticalData criticalData : vecCritVectorForPerson) {
				String fieldName = criticalData.getElementName();

				if (StringUtils.isNonBlank(personObj.getBirthDate())
						&& fieldName
						.equalsIgnoreCase(BIRTH_DATE_MDM_ATTRIBUTE_NAME)) {		
					
					//July 22, 2018 : Modified by Diparnab for restricting Birthdate from being populated in Comparison String for Person Update for IND/AU/NZ/TUR : Start
					//For Data Synchronyzation job
					if(StringUtils.isNonBlank(requestName) && "synchronizeeME".equalsIgnoreCase(requestName))
					{
						if (!"AU".equalsIgnoreCase(marketNameSync)
								&& !"NZ".equalsIgnoreCase(marketNameSync)
								&& !"IND".equalsIgnoreCase(marketNameSync)
								&& !"TUR".equalsIgnoreCase(marketNameSync)
								&& !"ID".equalsIgnoreCase(marketNameSync)
								&& !"VN".equalsIgnoreCase(marketNameSync)
								&& !"SG".equalsIgnoreCase(marketNameSync)
								&& !"BR".equalsIgnoreCase(marketNameSync)
								&& !"HU".equalsIgnoreCase(marketNameSync)
								&& !"RO".equalsIgnoreCase(marketNameSync)
								&& !"SK".equalsIgnoreCase(marketNameSync)
								&& !"ZA".equalsIgnoreCase(marketNameSync)
								&& !"THA".equalsIgnoreCase(marketNameSync)
								&& !"JPN".equalsIgnoreCase(marketNameSync)
								&& !ExternalRuleConstant.AEM_MARKETS.contains(marketNameSync)) {
							// convert to Date.
							personRecord.addAttribute(buildAttribute("PERBIRTHDATE", "val", 
							DateFormatter.getDate(personObj.getBirthDate())));	
						}
					}
					//For Update Flow
					else if(StringUtils.isNonBlank(txnType) && "update".equalsIgnoreCase(txnType))
					{
						if (!"AU".equalsIgnoreCase(marketName)
								&& !"NZ".equalsIgnoreCase(marketName)
								&& !"IND".equalsIgnoreCase(marketName)
								&& !"TUR".equalsIgnoreCase(marketName)
								&& !"ID".equalsIgnoreCase(marketName)
								&& !"VN".equalsIgnoreCase(marketName)
								&& !"SG".equalsIgnoreCase(marketName)
								&& !"BR".equalsIgnoreCase(marketName)
								&& !"HU".equalsIgnoreCase(marketName)
								&& !"RO".equalsIgnoreCase(marketName)
								&& !"SK".equalsIgnoreCase(marketName)
								&& !"ZA".equalsIgnoreCase(marketName)
								&& !"THA".equalsIgnoreCase(marketName)
								&& !"JPN".equalsIgnoreCase(marketName)
								&& !ExternalRuleConstant.AEM_MARKETS.contains(marketName)) {
							//convert to Date.
							personRecord.addAttribute(buildAttribute("PERBIRTHDATE", "val", DateFormatter.getDate(personObj.getBirthDate())));	
						}
					}
					//For Create Flow
					else {
						if (!"AU".equalsIgnoreCase(xPersonBOBjExt
								.getXMarketName())
								&& !"NZ".equalsIgnoreCase(xPersonBOBjExt
										.getXMarketName())
								&& !"IND".equalsIgnoreCase(xPersonBOBjExt
										.getXMarketName())
								&& !"TUR".equalsIgnoreCase(xPersonBOBjExt
										.getXMarketName())
								&& !"ID".equalsIgnoreCase(xPersonBOBjExt
										.getXMarketName())
								&& !"VN".equalsIgnoreCase(xPersonBOBjExt
										.getXMarketName())
								&& !"SG".equalsIgnoreCase(xPersonBOBjExt
										.getXMarketName())
								&& !"BR".equalsIgnoreCase(xPersonBOBjExt
										.getXMarketName())
								&& !"HU".equalsIgnoreCase(xPersonBOBjExt
										.getXMarketName())
								&& !"RO".equalsIgnoreCase(xPersonBOBjExt
										.getXMarketName())
								&& !"SK".equalsIgnoreCase(xPersonBOBjExt
										.getXMarketName())
								&& !"ZA".equalsIgnoreCase(xPersonBOBjExt
												.getXMarketName())
								&& !"THA".equalsIgnoreCase(xPersonBOBjExt
												.getXMarketName())
								&& !"JPN".equalsIgnoreCase(xPersonBOBjExt
												.getXMarketName())
								&& !ExternalRuleConstant.AEM_MARKETS.contains(xPersonBOBjExt
										.getXMarketName())) {
							//convert to Date.
							personRecord.addAttribute(buildAttribute("PERBIRTHDATE", "val", 
									DateFormatter.getDate(personObj.getBirthDate())));	
						}
					}					
					//July 22, 2018 : Modified by Diparnab for restricting Birthdate from being populated in Comparison String for Person Update for IND/AU/NZ/TUR : End
					
				} else if (StringUtils.isNonBlank(personObj.getGenderType())
						&& fieldName
						.equalsIgnoreCase(GENDER_TYPE_MDM_ATTRIBUTE_NAME)) {
					//May 23, 2018 : Modified by Diparnab : Start
					//Exclude Gender from comparison string for India and Turkey
					
					//July 22, 2018 : Modified by Diparnab for restricting Gender from being populated in the Comparison String for Person update for IND/TUR : Start
					//For Data Synchronyzation job
					if(StringUtils.isNonBlank(requestName) && "synchronizeeME".equalsIgnoreCase(requestName))
					{
						if (!"IND".equalsIgnoreCase(marketNameSync)
								&& !"TUR".equalsIgnoreCase(marketNameSync)
								&& !"ID".equalsIgnoreCase(marketNameSync)
								&& !"VN".equalsIgnoreCase(marketNameSync)
								&& !"SG".equalsIgnoreCase(marketNameSync)
								&& !"BR".equalsIgnoreCase(marketNameSync)
								&& !"HU".equalsIgnoreCase(marketNameSync)
								&& !"RO".equalsIgnoreCase(marketNameSync)
								&& !"SK".equalsIgnoreCase(marketNameSync)
								&& !"ZA".equalsIgnoreCase(marketNameSync)
								&& !"THA".equalsIgnoreCase(marketNameSync)
								&& !"JPN".equalsIgnoreCase(marketNameSync)
								&& !"AU".equalsIgnoreCase(marketNameSync)
								&& !"NZ".equalsIgnoreCase(marketNameSync)
								&& !ExternalRuleConstant.AEM_MARKETS.contains(marketNameSync)) {
							personRecord.addAttribute(buildAttribute("PERGENDER", "gender", personObj.getGenderType()));
						}
					}
					//For Update Flow
					else if (StringUtils.isNonBlank(txnType) && "update".equalsIgnoreCase(txnType))
					{
						if (!"IND".equalsIgnoreCase(marketName)
								&& !"TUR".equalsIgnoreCase(marketName)
								&& !"ID".equalsIgnoreCase(marketName)
								&& !"VN".equalsIgnoreCase(marketName)
								&& !"SG".equalsIgnoreCase(marketName)
								&& !"BR".equalsIgnoreCase(marketName)
								&& !"HU".equalsIgnoreCase(marketName)
								&& !"RO".equalsIgnoreCase(marketName)
								&& !"SK".equalsIgnoreCase(marketName)
								&& !"ZA".equalsIgnoreCase(marketName)
								&& !"THA".equalsIgnoreCase(marketName)
								&& !"JPN".equalsIgnoreCase(marketName)
								&& !"AU".equalsIgnoreCase(marketName)
								&& !"NZ".equalsIgnoreCase(marketName)
								&& !ExternalRuleConstant.AEM_MARKETS.contains(marketName)) {
							personRecord.addAttribute(buildAttribute("PERGENDER", "gender", personObj.getGenderType()));
						}
					}
					//For Create Flow
					else
					{
						if (!"IND".equalsIgnoreCase(xPersonBOBjExt
								.getXMarketName())
								&& !"TUR".equalsIgnoreCase(xPersonBOBjExt
										.getXMarketName())
								&& !"ID".equalsIgnoreCase(xPersonBOBjExt
										.getXMarketName())
								&& !"VN".equalsIgnoreCase(xPersonBOBjExt
										.getXMarketName())
								&& !"SG".equalsIgnoreCase(xPersonBOBjExt
										.getXMarketName())
								&& !"BR".equalsIgnoreCase(xPersonBOBjExt
										.getXMarketName())
								&& !"HU".equalsIgnoreCase(xPersonBOBjExt
										.getXMarketName())
								&& !"RO".equalsIgnoreCase(xPersonBOBjExt
										.getXMarketName())
								&& !"SK".equalsIgnoreCase(xPersonBOBjExt
										.getXMarketName())
								&& !"ZA".equalsIgnoreCase(xPersonBOBjExt
												.getXMarketName())
								&& !"THA".equalsIgnoreCase(xPersonBOBjExt
												.getXMarketName())
								&& !"JPN".equalsIgnoreCase(xPersonBOBjExt
												.getXMarketName())
								&& !"AU".equalsIgnoreCase(xPersonBOBjExt
												.getXMarketName())
								&& !"NZ".equalsIgnoreCase(xPersonBOBjExt
												.getXMarketName())
								&& !ExternalRuleConstant.AEM_MARKETS.contains(xPersonBOBjExt
										.getXMarketName()))				
								{
							personRecord.addAttribute(buildAttribute("PERGENDER", "gender",
									personObj.getGenderType()));
						}
					}
										
					//July 22, 2018 : Modified by Diparnab for restricting Gender from being populated in the Comparison String for Person update for IND/TUR : Start
					
					//May 23, 2018 : Modified by Diparnab : End
					
				} else if (StringUtils.isNonBlank(personObj.getDeceasedDate())
						&& fieldName
						.equalsIgnoreCase(DECEASED_DATE_MDM_ATTRIBUTE_NAME)) {
					// convert to Date.
					personRecord
					.addAttribute(buildAttribute("PERDECEASDTE", "val",
							DateFormatter.getDate(personObj
									.getDeceasedDate())));

				} else if (StringUtils.isNonBlank(xPersonBOBjExt.getXMarketName())
						&& fieldName
						.equalsIgnoreCase(MARKET_MDM_ATTRIBUTE_NAME)) {
					personRecord
					.addAttribute(buildAttribute("PERMARKET", "market",
							xPersonBOBjExt.getXMarketName()));

				}
				
				//Changed for marketName CMPVAL (25 May 2018)
				
				else if (txnType!=null && txnType.equalsIgnoreCase("update")
						&& fieldName
						.equalsIgnoreCase(MARKET_MDM_ATTRIBUTE_NAME)) {
					personRecord
					.addAttribute(buildAttribute("PERMARKET", "market",
							marketName));

				}
				
				else if (requestName!=null && requestName.equalsIgnoreCase("synchronizeeME")
						&& fieldName
						.equalsIgnoreCase(MARKET_MDM_ATTRIBUTE_NAME)) {
					personRecord
					.addAttribute(buildAttribute("PERMARKET", "market",
							marketNameSync));

				}
				
				//Changes end for PME
			}
		}

		//Check that there are attributes added to the record
		//otherwise return insufficient search criteria error
		if (probabilisticSearch && personRecord.getAttributes().isEmpty())
		{
			DWLStatus status = new DWLStatus();
			errHandler = TCRMClassFactory.getErrorHandler();
			
			TCRMExceptionUtils.throwTCRMException(null,
					new TCRMDataInvalidException(), status,
					DWLStatus.FATAL,
					TCRMCoreComponentID.PROBABILISTIC_PERSON_SEARCH_OBJECT,
					TCRMErrorCode.DATA_INVALID_ERROR,
					TCRMCoreErrorReasonCode.SEARCH_NO_CRITIERIA,
					rootBObj.getControl(), errHandler);
		}
		return personRecord;

	}
	private Vector<CriticalData> getCriticalDataElementsOfChildObjectOfPerson(DWLCommon bObj) throws Exception{
		
		Vector<CriticalData> vecCritDataElemOfIncomingBObj = getCriticalDataElementsForGroup(bObj);
		Vector<CriticalData> vecCritDataElemOfIncomingBObjForPerson = new Vector<CriticalData>();
		for(CriticalData criticalData : vecCritDataElemOfIncomingBObj){
			if(criticalData.getUltimateParentGroupName().equals(PERSON_GROUP_NAME)){
				vecCritDataElemOfIncomingBObjForPerson.add(criticalData);
			}
		}
		return vecCritDataElemOfIncomingBObjForPerson;
		
	}
	
	
	//August 07, 2018 : Added by Diparnab for Magic Number removal as a Match Attribute for Turkey Market : Start
	/**
	 * Method to check whether the request record is for Turkey Market
	 * @param txnType
	 * @param requestName
	 * @param marketName
	 * @param marketNameSync
	 * @param personObj
	 * @return
	 */
	private boolean isMarketTurkey(String txnType, String requestName, String marketName, String marketNameSync, XPersonBObjExt xPersonObj) 
	{
		boolean isMarketTurkey = false;
		//For Derived data synchronization job
		if(StringUtils.isNonBlank(requestName) && "synchronizeeME".equalsIgnoreCase(requestName) && "TUR".equalsIgnoreCase(marketNameSync))
		{
			isMarketTurkey =  true;
		}
		//For Customer Update Flow
		else if (StringUtils.isNonBlank(txnType) && "update".equalsIgnoreCase(txnType) && "TUR".equalsIgnoreCase(marketName))
		{
			isMarketTurkey =  true;
		}
		//For Customer Add Flow
		else if ("TUR".equalsIgnoreCase(xPersonObj.getXMarketName()))
		{
			isMarketTurkey = true;
		}
		return isMarketTurkey;		
	}
	//August 07, 2018 : Added by Diparnab for Magic Number removal as a Match Attribute for Turkey Market : End

	/**
	 * returns true if usage type is for AU NZ
	 * @author shrdatta
	 * @param contactMethodUsageType
	 * @return
	 */
	private Boolean isAUNZPhone(String contactMethodUsageType){

		Boolean result = false;

		if(ExternalRuleConstant.CONTACT_METHOD_USAGE_TYPE_HOME_PHONE_AUS.equalsIgnoreCase(contactMethodUsageType)
				||ExternalRuleConstant.CONTACT_METHOD_USAGE_TYPE_WORK_PHONE_AUS.equalsIgnoreCase(contactMethodUsageType)
				||ExternalRuleConstant.CONTACT_METHOD_USAGE_TYPE_MOBILE_AUS.equalsIgnoreCase(contactMethodUsageType)
				||ExternalRuleConstant.CONTACT_METHOD_USAGE_TYPE_FAX_AUS.equalsIgnoreCase(contactMethodUsageType)
				||ExternalRuleConstant.CONTACT_METHOD_USAGE_TYPE_SMS_AUS.equalsIgnoreCase(contactMethodUsageType)){
			result = true;
		}
		return result;
	}

	/**
	 * Returns true for Australian Smart Numbers
	 * @author shrdatta
	 * @param referenceNumber
	 * @return
	 */
	private Boolean isSmartNumber(String referenceNumber){

		Boolean result = false;

		//numbers starting with 1800 or 1300 with total number of digits 10 and starting with 13 with total number of digits 6 are smart numbers

		if(StringUtils.isNonBlank(referenceNumber)){

			//starts with 1800 and 10 digit
			if(referenceNumber.startsWith(ExternalRuleConstant.SMART_NUMBER_AUS_PREFIX_1800) && referenceNumber.length() == 10){
				result = true;
			}
			//starts with 1300 and 10 digit
			else if(referenceNumber.startsWith(ExternalRuleConstant.SMART_NUMBER_AUS_PREFIX_1300) && referenceNumber.length() == 10){
				result = true;
			}
			//starts with 13 and 6 digit
			else if(referenceNumber.startsWith(ExternalRuleConstant.SMART_NUMBER_AUS_PREFIX_13) && referenceNumber.length() == 6){
				result = true;
			}  
		}

		return result;
	}

}
