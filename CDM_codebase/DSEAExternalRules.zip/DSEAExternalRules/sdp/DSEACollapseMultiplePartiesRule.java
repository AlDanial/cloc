/* _______________________________________________________ {COPYRIGHT-TOP} _____
* Licensed Materials - Property of IBM
* Restricted Materials of IBM
*
* 5725-E59
*
* (C) Copyright IBM Corp. 2006, 2014  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
* ________________________________________________________ {COPYRIGHT-END} _____*/
/**_________________________________________
 * RCSID -- $RCSfile: CollapseMultiplePartiesRule.java,v $
 *          $Date: 2011/09/26 22:23:27 $
 * 
 *          $Author: cgheorgh $
 *__________________________________________ 
 */

package com.ibm.daimler.dsea.extrules.sdp;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;
import java.util.Vector;

import com.dwl.base.DWLControl;
import com.dwl.base.DWLResponse;
import com.dwl.base.IDWLErrorMessage;
import com.dwl.base.error.DWLError;
import com.dwl.base.error.DWLStatus;
import com.dwl.base.exception.DWLBaseException;
import com.dwl.base.externalrule.Rule;
import com.dwl.base.logging.DWLLoggerManager;
import com.dwl.base.logging.IDWLLogger;
import com.dwl.tcrm.common.TCRMErrorCode;
import com.dwl.tcrm.common.TCRMRecordFilter;
import com.dwl.tcrm.coreParty.component.TCRMPartyBObj;
import com.dwl.tcrm.coreParty.component.TCRMPartyRelationshipBObj;
import com.dwl.tcrm.coreParty.component.TCRMPartyRelationshipRoleBObj;
import com.dwl.tcrm.coreParty.constant.TCRMCoreComponentID;
import com.dwl.tcrm.coreParty.constant.TCRMCoreErrorReasonCode;
import com.dwl.tcrm.coreParty.constant.TCRMCorePropertyKeys;
import com.dwl.tcrm.coreParty.interfaces.IParty;
import com.dwl.tcrm.coreParty.interfaces.IPartyBusinessServices;
import com.dwl.tcrm.utilities.TCRMClassFactory;
import com.dwl.tcrm.coreParty.entityObject.EObjContactRel;
import com.ibm.daimler.dsea.component.DSEAAdditionsExtsComponent;
import com.ibm.daimler.dsea.component.XDataSharingBObj;
import com.ibm.daimler.dsea.component.XOrgBObjExt;
import com.ibm.daimler.dsea.component.XPersonBObjExt;
import com.ibm.daimler.dsea.extrules.constant.ExternalRuleConstant;
import com.ibm.daimler.dsea.extrules.util.ExternalRuleUtil;
import com.ibm.daimler.dsea.component.XContEquivBObjExt;

/**
 * CollapseMultiplePartiesRule: Rule 119
 * <UL>
 * <LI>It will collapse multiple parties by delegate the transaction to
 * TCRMPartyComponent.collapseObjectsSurvivingRules(vecParties, true)
 * 
 * <LI>It will deal with party children and alerts, admin party and party
 * relationships, and party relationship roles (party relationship roles is not
 * included in preview transactions)
 * </UL>
 * 
 * By using the business key elements and Last Update Date Field, this method
 * combines the information on all the parties and then create a party object
 * which holds the most recent information of those input parties.
 */
public class DSEACollapseMultiplePartiesRule extends Rule {
    public static final String copyright =  "Licensed Materials -- Property of IBM\n(c) Copyright IBM Corp. 2006, 2014\nUS Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.";


	protected final static IDWLLogger logger = DWLLoggerManager
			.getLogger(DSEACollapseMultiplePartiesRule.class);

	protected String ruleName = "CollapseMultiplePartiesRule";

	protected String debugStr = "External Java Rule 119 " + ruleName + ": ";

	private boolean bCollapsePartiesAdminContEquiv;

	private boolean bCollapsePartiesAlerts = true;

	private boolean bCollapsePartiesRelationships = true;

	IParty partyComp = null;

	/**
	 * @param input
	 *            A vector of <code>TCRMPartyBObj</code> suspect parties passed by 
	 *            the caller.
	 * @param componentObject
	 *            ISuspectProcessor
	 * 
	 * @return A Vector containing instances of TCRMSuspectBObj and DWLStatus.
	 */
	public Object execute(Object input, Object componentObject) throws Exception {
		if (logger.isFineEnabled()){
			logger.fine(debugStr + "Entering Rule");
		}

		Vector vecParties = (Vector) input;

		// The last element is bPreview, get it and remove it from vecParties
		Boolean bPreviewTrans = (Boolean) vecParties.elementAt(vecParties
				.size() - 1);
		boolean bPreview = bPreviewTrans.booleanValue();
		vecParties.removeElementAt(vecParties.size() - 1);

		partyComp = (IParty) TCRMClassFactory
				.getTCRMComponent(TCRMCorePropertyKeys.PARTY_COMPONENT);

		DWLStatus status = ((TCRMPartyBObj) vecParties.elementAt(0))
				.getStatus();

		TCRMPartyBObj collapsedPartyBObj = null;

		Vector vecRet = new Vector();
		DWLControl dwlControl = null;

		try {
			// 1. Party relationship will not be collapsed; so before collapse
			// the parties, save party relationships of all parties
			// participating
			// in collapsing, and remove them from the parties; after
			// collapsing, put them back to the parties
			Vector vecAllRels = new Vector();
			Map hmRelationships = new HashMap();
			Vector tmpRel = new Vector();

			// 1.1 Remove all party relationships from each partyBObj and save
			// them in a hashmap before collapsing parties
			TCRMPartyBObj tmpPartyBObj = null;

			for (int i = 0; i < vecParties.size(); i++) {
				tmpPartyBObj = (TCRMPartyBObj) vecParties.elementAt(i);

				// 1.1.1 Remove all partyRelationships before collapsing and
				// save the relationships to a temporary holder.
				if (tmpPartyBObj.getItemsTCRMPartyRelationshipBObj() != null
						&& tmpPartyBObj.getItemsTCRMPartyRelationshipBObj()
								.size() > 0) {
					// Save the party relationships to a hashmap; using partyId
					// as key
					tmpRel.addAll(tmpPartyBObj
							.getItemsTCRMPartyRelationshipBObj());
					hmRelationships.put(tmpPartyBObj.getPartyId(), tmpRel);

					tmpRel = new Vector();

					// 1.1.2 Save party relationships from each the party and
					// accumulate all partyRelationships to one place.
					vecAllRels.addAll(tmpPartyBObj
							.getItemsTCRMPartyRelationshipBObj());

					// 1.1.3 Remove partyRelationships for the party before
					// collapsing.
					tmpPartyBObj.getItemsTCRMPartyRelationshipBObj()
							.removeAllElements();
				}
			}

			// 2. Collapse parties
			TCRMPartyBObj collapsedPartyCandidate = (TCRMPartyBObj) vecParties
					.elementAt(0);
			dwlControl = collapsedPartyCandidate.getControl();

			// 2.1 Get partyAlert and PartyAdminSysKeys
			for (int idx1 = 0; idx1 < vecParties.size(); idx1++) {
				collapsedPartyCandidate = (TCRMPartyBObj) vecParties
						.elementAt(idx1);

				if (isCollapsedPartiesAlerts()) {
					if (logger.isFineEnabled()){
						logger.fine(debugStr + "Retrieving Alerts");
					}

					Vector vec = partyComp.getAllPartyAlerts(
							collapsedPartyCandidate.getPartyId(),
							TCRMRecordFilter.ACTIVE, dwlControl);

		      	    if (vec != null){
		      	      (collapsedPartyCandidate.getItemsTCRMAlertBObj()).addAll(vec);		      	    
		      	    }
				}

				if (isCollapsedPartiesAdminContEquiv()) {
					if (logger.isFineEnabled()){
						logger.fine(debugStr + "Retrieving AdminContEquiv");
					}

					Vector vec = partyComp.getAllPartyAdminSysKeys(
							collapsedPartyCandidate.getPartyId(), dwlControl);
					(collapsedPartyCandidate.getItemsTCRMAdminContEquivBObj())
							.addAll(vec);
				}
			}
			// Collapse all parties
			// For Market Check
			TCRMPartyBObj vecParty = (TCRMPartyBObj) vecParties.get(0);
			String partyType = vecParty.getPartyType();
			String xMarketName = null;
			String sourceArch = null;
			if(ExternalRuleConstant.PERSON_ORG_CODE_P.equalsIgnoreCase(partyType))
			{
				XPersonBObjExt vecPerson = (XPersonBObjExt)vecParty;
				xMarketName = vecPerson.getXMarketName();
				sourceArch = vecPerson.getXSourceTypeFlag();
			}
			else if(ExternalRuleConstant.PERSON_ORG_CODE_O.equalsIgnoreCase(partyType))
			{
				XOrgBObjExt vecOrg = (XOrgBObjExt)vecParty;
				xMarketName = vecOrg.getXMarketName();
				sourceArch = vecOrg.getXSourceTypeFlag();
			}
			
			if(ExternalRuleConstant.MARKET_NAME_AUSTRALIA.equalsIgnoreCase(xMarketName))
			{
				//for Australia
				
				//Start of change by TF 24 Feb 2020

				//filter parties without WS SFID or duplicate SFID
				filterPartiesSfdcId(vecParties);

				//no party info to collapse throw error 
				
				if(vecParties.size()<2){


					collapsedPartyBObj = new TCRMPartyBObj();
					status = addError(dwlControl, TCRMErrorCode.UPDATE_RECORD_ERROR,
							TCRMCoreErrorReasonCode.COLLAPSE_MULTIPLE_PARTIES_FAILED_NO_PARTY_INFO_TO_COLLAPSE,null);
					collapsedPartyBObj.setStatus(status);
					vecRet.add(collapsedPartyBObj);
					return vecRet;
				}
				//End of change by TF 24 Feb 2020
				
				SurvivorshipRuleUtilAus survivorshipRuleUtilAus = new SurvivorshipRuleUtilAus();
				Vector vecCollapsedParty = survivorshipRuleUtilAus.collapseObjectsSurvivingRules(vecParties, true);
				collapsedPartyBObj = (TCRMPartyBObj) vecCollapsedParty.elementAt(0);
			}
			else if(ExternalRuleConstant.MARKET_NAME_NEWZEALAND.equalsIgnoreCase(xMarketName))
					{
				//for New Zealand
				//Start of change by TF 24 Feb 2020

				//filter parties without WS SFID or duplicate SFID
				filterPartiesSfdcId(vecParties);

				//check if no party info to collapse throw error 
				if(vecParties.size()<2){

					collapsedPartyBObj = new TCRMPartyBObj();
					status = addError(dwlControl, TCRMErrorCode.UPDATE_RECORD_ERROR,
							TCRMCoreErrorReasonCode.COLLAPSE_MULTIPLE_PARTIES_FAILED_NO_PARTY_INFO_TO_COLLAPSE,null);
					collapsedPartyBObj.setStatus(status);
					vecRet.add(collapsedPartyBObj);
					return vecRet;
				}
				//End of change by TF 24 Feb 2020
				
				SurvivorshipRuleUtilAus survivorshipRuleUtilAus = new SurvivorshipRuleUtilAus();
				Vector vecCollapsedParty = survivorshipRuleUtilAus.collapseObjectsSurvivingRules(vecParties, true);
				collapsedPartyBObj = (TCRMPartyBObj) vecCollapsedParty.elementAt(0);
					}
			else if(ExternalRuleConstant.MARKET_NAME_INDIA.equalsIgnoreCase(xMarketName))
			{
				//for INDIA
				//Start of change by TF 2 Mar 2020

				//filter parties without WS SFID or duplicate SFID
				filterPartiesSfdcId(vecParties);

				//check if no party info to collapse throw error 
				if(vecParties.size()<2){

					collapsedPartyBObj = new TCRMPartyBObj();
					status = addError(dwlControl, TCRMErrorCode.UPDATE_RECORD_ERROR,
							TCRMCoreErrorReasonCode.COLLAPSE_MULTIPLE_PARTIES_FAILED_NO_PARTY_INFO_TO_COLLAPSE,null);
					collapsedPartyBObj.setStatus(status);
					vecRet.add(collapsedPartyBObj);
					return vecRet;
				}
				//End of change by 2 Mar 2020
				
				SurvivorshipRuleUtilIND survivorshipRuleUtilIND = new SurvivorshipRuleUtilIND();
				Vector vecCollapsedParty = survivorshipRuleUtilIND.collapseObjectsSurvivingRulesIND(vecParties, true);
				collapsedPartyBObj = (TCRMPartyBObj) vecCollapsedParty.elementAt(0);
			}
			//May 28, 2018 : Added by Diparnab for Turkey : Start
			else if(ExternalRuleConstant.MARKET_NAME_TURKEY.equalsIgnoreCase(xMarketName))
			{
				//for Turkey
				//Start of change by TF 2 Mar 2020

				//filter parties without WS SFID or duplicate SFID
				filterPartiesSfdcId(vecParties);

				//check if no party info to collapse throw error 
				if(vecParties.size()<2){

					collapsedPartyBObj = new TCRMPartyBObj();
					status = addError(dwlControl, TCRMErrorCode.UPDATE_RECORD_ERROR,
							TCRMCoreErrorReasonCode.COLLAPSE_MULTIPLE_PARTIES_FAILED_NO_PARTY_INFO_TO_COLLAPSE,null);
					collapsedPartyBObj.setStatus(status);
					vecRet.add(collapsedPartyBObj);
					return vecRet;
				}
				//End of change by 2 Mar 2020
				
				SurvivorshipRuleUtilTUR survivorshipRuleUtilTUR = new SurvivorshipRuleUtilTUR();
				Vector vecCollapsedParty = survivorshipRuleUtilTUR.collapseObjectsSurvivingRules(vecParties, true);
				collapsedPartyBObj = (TCRMPartyBObj) vecCollapsedParty.elementAt(0);
			}
			//May 28, 2018 : Added by Diparnab for Turkey : End
			
			//Aug 28, 2018 : Added by Pushpraj for JPN : Start
			else if(ExternalRuleConstant.JAPAN_MARKET_NAME.equalsIgnoreCase(xMarketName))
			{	
				//Removing Orphan from Merge by Sumit on 5th March , 2020 : Start

				//filter parties without WS SFID or duplicate SFID
				filterPartiesSfdcIdJPN(vecParties);

				//no party info to collapse throw error 
				if(vecParties.size()<2){
					collapsedPartyBObj = new TCRMPartyBObj();
					status = addError(dwlControl, TCRMErrorCode.UPDATE_RECORD_ERROR,
							TCRMCoreErrorReasonCode.COLLAPSE_MULTIPLE_PARTIES_FAILED_NO_PARTY_INFO_TO_COLLAPSE,null);
					collapsedPartyBObj.setStatus(status);
				}
				//Removing Orphan from Merge by Sumit on 5th March , 2020 : END
				
				//filter parties according to Merge flag Present or not : Added by Shashi - 7 June 2022
				filterPartiesOnMergeflagJPN(vecParties);

				//no party info to collapse throw error 
				if(vecParties.size()<2){
					collapsedPartyBObj = new TCRMPartyBObj();
					status = addError(dwlControl, TCRMErrorCode.UPDATE_RECORD_ERROR,
							TCRMCoreErrorReasonCode.COLLAPSE_MULTIPLE_PARTIES_FAILED_NO_PARTY_INFO_TO_COLLAPSE,null);
					collapsedPartyBObj.setStatus(status);
				}
				// End of Changes
				
				SurvivorshipRuleUtilJPN survivorshipRuleUtilJPN=new SurvivorshipRuleUtilJPN();
				Vector vecCollapsedParty=survivorshipRuleUtilJPN.collapseObjectsSurvivingRules(vecParties, true);
				collapsedPartyBObj=(TCRMPartyBObj) vecCollapsedParty.firstElement();
			}
			
			//Aug 28, 2018 : Added by Pushpraj for JPN : End
			
		
			else if(ExternalRuleConstant.KOREA_MARKET_NAME.equalsIgnoreCase(xMarketName))
			{
				if("REARCH".equals(sourceArch)){
					filterPartiesByDataSharing(vecParties, dwlControl);

					//check if no party info to collapse throw error 
					if(vecParties.size()<2){

						collapsedPartyBObj = new TCRMPartyBObj();
						status = addError(dwlControl, TCRMErrorCode.UPDATE_RECORD_ERROR,
								TCRMCoreErrorReasonCode.COLLAPSE_MULTIPLE_PARTIES_FAILED_NO_PARTY_INFO_TO_COLLAPSE,null);
						collapsedPartyBObj.setStatus(status);
						vecRet.add(collapsedPartyBObj);
						return vecRet;
					}
				}
			
				
				SurvivorshipRuleUtilKOR survivorshipRuleUtilKOR=new SurvivorshipRuleUtilKOR();
				Vector vecCollapsedParty=SurvivorshipRuleUtilKOR.collapseObjectsSurvivingRules(vecParties, true);
				collapsedPartyBObj=(TCRMPartyBObj) vecCollapsedParty.firstElement();
			}
			else if(ExternalRuleConstant.MARKET_NAME_BRAZIL.equalsIgnoreCase(xMarketName))
			{
				//for BRAZIL..
				//Start of change by TF 2 Mar 2020

				//filter parties without WS SFID or duplicate SFID
				filterPartiesSfdcId(vecParties);

				//check if no party info to collapse throw error 
				if(vecParties.size()<2){

					collapsedPartyBObj = new TCRMPartyBObj();
					status = addError(dwlControl, TCRMErrorCode.UPDATE_RECORD_ERROR,
							TCRMCoreErrorReasonCode.COLLAPSE_MULTIPLE_PARTIES_FAILED_NO_PARTY_INFO_TO_COLLAPSE,null);
					collapsedPartyBObj.setStatus(status);
					vecRet.add(collapsedPartyBObj);
					return vecRet;
				}
				//End of change by 2 Mar 2020
				
				SuvivorshipRuleUtilMVP survivorshipRuleUtilMVP=new SuvivorshipRuleUtilMVP();
				Vector vecCollapsedParty = SuvivorshipRuleUtilMVP.collapseObjectsSurvivingRules(vecParties, true);
				collapsedPartyBObj=(TCRMPartyBObj) vecCollapsedParty.firstElement();
			}
			
			else if(ExternalRuleConstant.MARKET_NAME_INDONESIA.equalsIgnoreCase(xMarketName) ||ExternalRuleConstant.MARKET_NAME_VIETNAM.equalsIgnoreCase(xMarketName) || ExternalRuleConstant.MARKET_NAME_SINGAPORE.equalsIgnoreCase(xMarketName))
			{
				//CL1 ReArch
				//Start of change by TF 2 Mar 2020

				//filter parties without WS SFID or duplicate SFID
				filterPartiesSfdcId(vecParties);

				//check if no party info to collapse throw error 
				if(vecParties.size()<2){

					collapsedPartyBObj = new TCRMPartyBObj();
					status = addError(dwlControl, TCRMErrorCode.UPDATE_RECORD_ERROR,
							TCRMCoreErrorReasonCode.COLLAPSE_MULTIPLE_PARTIES_FAILED_NO_PARTY_INFO_TO_COLLAPSE,null);
					collapsedPartyBObj.setStatus(status);
					vecRet.add(collapsedPartyBObj);
					return vecRet;
				}
				//End of change by 2 Mar 2020
				
				SurvivorshipRuleUtilCL1 survivorshipRuleUtilCL1=new SurvivorshipRuleUtilCL1();
				Vector vecCollapsedParty = survivorshipRuleUtilCL1.collapseObjectsSurvivingRules(vecParties, true);
				collapsedPartyBObj=(TCRMPartyBObj) vecCollapsedParty.firstElement();
			
			}
			else if(ExternalRuleConstant.HUNGARY_MARKET_NAME.equalsIgnoreCase(xMarketName) 
					||ExternalRuleConstant.ROMANIA_MARKET_NAME.equalsIgnoreCase(xMarketName) 
					|| ExternalRuleConstant.SLOVAKIA_MARKET_NAME.equalsIgnoreCase(xMarketName))
			{
				//for HUNGARY,ROMANIA,SLOVAKIA ----culster--2
				//Start of change by TF 2 Mar 2020

				//filter parties without WS SFID or duplicate SFID
				filterPartiesSfdcId(vecParties);

				//check if no party info to collapse throw error 
				if(vecParties.size()<2){

					collapsedPartyBObj = new TCRMPartyBObj();
					status = addError(dwlControl, TCRMErrorCode.UPDATE_RECORD_ERROR,
							TCRMCoreErrorReasonCode.COLLAPSE_MULTIPLE_PARTIES_FAILED_NO_PARTY_INFO_TO_COLLAPSE,null);
					collapsedPartyBObj.setStatus(status);
					vecRet.add(collapsedPartyBObj);
					return vecRet;
				}
				//End of change by 2 Mar 2020
				
				SuvivorshipRuleUtilHRS SuvivorshipRuleUtilHRS=new SuvivorshipRuleUtilHRS();
				Vector vecCollapsedParty = SuvivorshipRuleUtilHRS.collapseObjectsSurvivingRules(vecParties, true);
				collapsedPartyBObj=(TCRMPartyBObj) vecCollapsedParty.firstElement();
			}
			else if(ExternalRuleConstant.SOUTH_AFRICA_MARKET_NAME.equalsIgnoreCase(xMarketName))
			{
				//for ZA
				//Start of change by TF 2 Mar 2020

				//filter parties without WS SFID or duplicate SFID
				filterPartiesSfdcId(vecParties);

				//check if no party info to collapse throw error 
				if(vecParties.size()<2){

					collapsedPartyBObj = new TCRMPartyBObj();
					status = addError(dwlControl, TCRMErrorCode.UPDATE_RECORD_ERROR,
							TCRMCoreErrorReasonCode.COLLAPSE_MULTIPLE_PARTIES_FAILED_NO_PARTY_INFO_TO_COLLAPSE,null);
					collapsedPartyBObj.setStatus(status);
					vecRet.add(collapsedPartyBObj);
					return vecRet;
				}
				//End of change by 2 Mar 2020
				
				SuvivorshipRuleUtilZA SuvivorshipRuleUtilZA=new SuvivorshipRuleUtilZA();
				Vector vecCollapsedParty = SuvivorshipRuleUtilZA.collapseObjectsSurvivingRules(vecParties, true);
				collapsedPartyBObj=(TCRMPartyBObj) vecCollapsedParty.firstElement();
			}
			else if(ExternalRuleConstant.AEM_MARKETS.contains(xMarketName)
					&& !ExternalRuleConstant.MARKET_NAME_MIDDLEEAST.equalsIgnoreCase(xMarketName)
					)
			{
				
				//for AEM...cluster ...3
				//Start of change by TF 2 Mar 2020

				//filter parties without WS SFID or duplicate SFID
				filterPartiesSfdcId(vecParties);

				//check if no party info to collapse throw error 
				if(vecParties.size()<2){

					collapsedPartyBObj = new TCRMPartyBObj();
					status = addError(dwlControl, TCRMErrorCode.UPDATE_RECORD_ERROR,
							TCRMCoreErrorReasonCode.COLLAPSE_MULTIPLE_PARTIES_FAILED_NO_PARTY_INFO_TO_COLLAPSE,null);
					collapsedPartyBObj.setStatus(status);
					vecRet.add(collapsedPartyBObj);
					return vecRet;
				}
				//End of change by 2 Mar 2020
				
				SuvivorshipRuleUtilAEM suvivorshipRuleUtilAEM=new SuvivorshipRuleUtilAEM();
				Vector vecCollapsedParty = suvivorshipRuleUtilAEM.collapseObjectsSurvivingRules(vecParties, true);
				collapsedPartyBObj=(TCRMPartyBObj) vecCollapsedParty.firstElement();
				
			}
		
			
			else if(ExternalRuleConstant.MARKET_NAME_MIDDLEEAST.equalsIgnoreCase(xMarketName))
			{

				
				//Middle East
				//Start of change by TF 2 Mar 2020

				//filter parties without WS SFID or duplicate SFID
				filterPartiesSfdcId(vecParties);

				//check if no party info to collapse throw error 
				if(vecParties.size()<2){

					collapsedPartyBObj = new TCRMPartyBObj();
					status = addError(dwlControl, TCRMErrorCode.UPDATE_RECORD_ERROR,
							TCRMCoreErrorReasonCode.COLLAPSE_MULTIPLE_PARTIES_FAILED_NO_PARTY_INFO_TO_COLLAPSE,null);
					collapsedPartyBObj.setStatus(status);
					vecRet.add(collapsedPartyBObj);
					return vecRet;
				}
				//End of change by 2 Mar 2020
				
				SurvivorshipRuleUtilME survivorshipRuleUtilME=new SurvivorshipRuleUtilME();
				Vector vecCollapsedParty = survivorshipRuleUtilME.collapseObjectsSurvivingRules(vecParties, true);
				collapsedPartyBObj=(TCRMPartyBObj) vecCollapsedParty.firstElement();
				
			
			}
			
			
			else
			{	// for MYS & THA
				
				if(ExternalRuleConstant.MARKET_NAME_THAILAND.equals(xMarketName) && 
						ExternalRuleConstant.PERSON_ORG_CODE_P.equalsIgnoreCase(partyType)){
					
					boolean isVecHasFS = false;
					Vector<XPersonBObjExt> finalPartyBObjs = new Vector<XPersonBObjExt>();
					XPersonBObjExt tempBObj = null;
					String recordType = null;
					SurvivorshipRuleUtilTHA survivorshipRuleUtilTHA = new SurvivorshipRuleUtilTHA();
					
					String PartyId = null;
					String annonymized_value = null;
					
					for(XPersonBObjExt personBObj : (Vector<XPersonBObjExt>)vecParties){
						PartyId = personBObj.getPartyId();
						annonymized_value =  ExternalRuleUtil.getAnonymizedValueByPartyId(PartyId);
						//System.out.println("Is Empty check =" +annonymized_value );
						
						/*if(annonymized_value == null){
							annonymized_value = "N";
						}*/
						if(null != annonymized_value && annonymized_value.equalsIgnoreCase("N")){
							
							/*recordType = survivorshipRuleUtil.checkRecordTypeForPerson(personBObj);
							if(recordType.equalsIgnoreCase("MPC")){
								finalPartyBObjs.add(personBObj);
							}else{
								//check if FS is added in vector or not
								if(!isVecHasFS){
									finalPartyBObjs.add(personBObj);
									isVecHasFS = true;
								}
							}*/
							finalPartyBObjs.add(personBObj);
						}
							
						}
						
					//Fixed by TF 27March to change original vector 
					//vecParties = finalPartyBObjs;

					vecParties.clear();
					vecParties.addAll(finalPartyBObjs);
					
					//for THA_Person
					//Start of change by TF 2 Mar 2020

					//filter parties without WS SFID or duplicate SFID
					filterPartiesSfdcId(vecParties);
					//check if no party info to collapse throw error 
					if(vecParties.size()<2){

						collapsedPartyBObj = new TCRMPartyBObj();
						status = addError(dwlControl, TCRMErrorCode.UPDATE_RECORD_ERROR,
								TCRMCoreErrorReasonCode.COLLAPSE_MULTIPLE_PARTIES_FAILED_NO_PARTY_INFO_TO_COLLAPSE,null);
						collapsedPartyBObj.setStatus(status);
						vecRet.add(collapsedPartyBObj);
						return vecRet;
					}
					//End of change by 2 Mar 2020
					
					Vector vecCollapsedParty = survivorshipRuleUtilTHA.collapseObjectsSurvivingRules(vecParties, true);
					collapsedPartyBObj = (TCRMPartyBObj) vecCollapsedParty.elementAt(0);
					
				}else if(ExternalRuleConstant.MARKET_NAME_THAILAND.equals(xMarketName) && 
						ExternalRuleConstant.PERSON_ORG_CODE_O.equalsIgnoreCase(partyType)){
					
					boolean isVecHasFS = false;
					Vector<XOrgBObjExt> finalPartyBObjs = new Vector<XOrgBObjExt>();
					XOrgBObjExt tempBObj = null;
					String recordType = null;
					SurvivorshipRuleUtilTHA survivorshipRuleUtilTHA = new SurvivorshipRuleUtilTHA();
					
					for(XOrgBObjExt orgBObj : (Vector<XOrgBObjExt>)vecParties){
							
							/*recordType = survivorshipRuleUtil.checkRecordTypeForOrg(orgBObj);
							if(recordType.equalsIgnoreCase("MPC")){
								finalPartyBObjs.add(orgBObj);
							}else{
								//check if FS is added in vector or not
								if(!isVecHasFS){
									finalPartyBObjs.add(orgBObj);
									isVecHasFS = true;
								}
							}*/
						
						finalPartyBObjs.add(orgBObj);
							
						}
						
					//Fixed by TF 27March to change original vector 
					//vecParties = finalPartyBObjs;
					
					vecParties.clear();
					vecParties.addAll(finalPartyBObjs);
					
					//for THA_org
					//Start of change by TF 2 Mar 2020

					//filter parties without WS SFID or duplicate SFID
					filterPartiesSfdcId(vecParties);
					//check if no party info to collapse throw error 
					if(vecParties.size()<2){

						collapsedPartyBObj = new TCRMPartyBObj();
						status = addError(dwlControl, TCRMErrorCode.UPDATE_RECORD_ERROR,
								TCRMCoreErrorReasonCode.COLLAPSE_MULTIPLE_PARTIES_FAILED_NO_PARTY_INFO_TO_COLLAPSE,null);
						collapsedPartyBObj.setStatus(status);
						vecRet.add(collapsedPartyBObj);
						return vecRet;
					}
					//End of change by 2 Mar 2020
					Vector vecCollapsedParty = survivorshipRuleUtilTHA.collapseObjectsSurvivingRules(vecParties, true);
					collapsedPartyBObj = (TCRMPartyBObj) vecCollapsedParty.elementAt(0);					
				}
				else{
					if(ExternalRuleConstant.MARKET_NAME_MALAYSIA.equals(xMarketName)){
					SurvivorshipRuleUtilMYS survivorshipRuleUtilMYS = new SurvivorshipRuleUtilMYS();
					//for MH
					//Start of change by TF 6 Mar 2020

					//filter parties without WS SFID or duplicate SFID
					filterPartiesSfdcId(vecParties);
					//check if no party info to collapse throw error 
					if(vecParties.size()<2){

						collapsedPartyBObj = new TCRMPartyBObj();
						status = addError(dwlControl, TCRMErrorCode.UPDATE_RECORD_ERROR,
								TCRMCoreErrorReasonCode.COLLAPSE_MULTIPLE_PARTIES_FAILED_NO_PARTY_INFO_TO_COLLAPSE,null);
						collapsedPartyBObj.setStatus(status);
						vecRet.add(collapsedPartyBObj);
						return vecRet;
					}
					//End of change by 6 Mar 2020
					Vector vecCollapsedParty = survivorshipRuleUtilMYS.collapseObjectsSurvivingRules(vecParties, true);
					collapsedPartyBObj = (TCRMPartyBObj) vecCollapsedParty.elementAt(0);
					
					}
		       	}
				
			}
			// 2.2 Collapse all parties
			//Vector vecCollapsedParty = partyComp.collapseObjectsSurvivingRules(vecParties, true);
			/*SurvivorshipRuleUtil survivorshipRuleUtil = new SurvivorshipRuleUtil();
			Vector vecCollapsedParty = survivorshipRuleUtil.collapseObjectsSurvivingRules(vecParties, true);
			collapsedPartyBObj = (TCRMPartyBObj) vecCollapsedParty.elementAt(0);*/
			
			
			
			
			//PMR01986,130,702
			//Commented out the following steps 3,4 and 5 and re-implement
			//PartyRelationship and associate roles collapsing process
			// 3. Restore relationships to each corresponding partyBObj
			/*Vector vecTmpRelationships = new Vector();

			for (int i = 0; i < vecParties.size(); i++) {
				tmpPartyBObj = (TCRMPartyBObj) vecParties.elementAt(i);

				vecTmpRelationships = (Vector) hmRelationships.get(tmpPartyBObj
						.getPartyId());

				// Restore each partyRelationships to corresponding partyBObj
				// after collapsing
				if (vecTmpRelationships != null
						&& vecTmpRelationships.size() > 0) {
					tmpPartyBObj.getItemsTCRMPartyRelationshipBObj().addAll(
							vecTmpRelationships);
				}
			}*/

			// 4. Process relationships (relinquish reciprocal relationship +
			// repetitive relationships) and relationship roles
			/*collapsedPartyBObj = processPartyRelationships(vecParties,
					collapsedPartyBObj, partyComp);*/

			// 5. Process party relationship roles: identify which partyRelRoles
			// belong to its corresponding partyRelationshipBObj
			/*Vector vecPartyRelationshipRoles = null;

			if (!bPreview) {
				vecPartyRelationshipRoles = processPartyRelationshipRoles(vecAllRels);
			} else {
				vecPartyRelationshipRoles = new Vector();
			}*/

			//PMR01986,130,702 
			//Re-implement PartyRelationship and PartyRelationshipRoles
			Vector vecPartyRelationshipRoles =  new Vector();
			String sourcePartyId = ((TCRMPartyBObj)vecParties.get(0)).getPartyId();
			processPartyRelationships(sourcePartyId, vecAllRels, hmRelationships, collapsedPartyBObj, vecPartyRelationshipRoles, bPreview);
			
			// Add the party without mandatory search
			collapsedPartyBObj.setMandatorySearchDone("Y");
			collapsedPartyBObj.setControl(dwlControl);

			// Construct the returned vector
			// 7. Add the collapsed partyBObj to the list returned: it is the
			// second last element of the returned vector.
			vecRet.add(collapsedPartyBObj);

			// 8. Return vecPartyRelationshipRoles: it is the last element of
			// the returned vector.
			vecRet.add(vecPartyRelationshipRoles);
		} catch (DWLBaseException ex) {
            // Added by AutomatedFix
            com.dwl.base.util.DWLExceptionUtils.log(ex);
			status = ex.getStatus();
		} catch (Exception ex) {
            // Added by AutomatedFix
            com.dwl.base.util.DWLExceptionUtils.log(ex);
			status = addError(dwlControl, TCRMErrorCode.UPDATE_RECORD_ERROR,
					TCRMCoreErrorReasonCode.COLLAPSE_MULTIPLE_PARTIES_FAILED,
					ex.getMessage());
		}

		collapsedPartyBObj.setStatus(status);

		return vecRet;
	}

	/**
	 * Processing partyRelationships and associate partyRelationshipRoles
	 * 
	 * @param sourcePartyId source Party Id
	 * @param vecAllRels all partyRelationships from all collapsing parties
	 * @param relmap a HashMap contains party id and its PartyRelationships
	 * @param collapsedPartyBObj survived party after collapinsg
	 * @param vecPartyRelationshipRoles PartyRelationshipRoles belong to collapsedPartyBObj partyRelationships
	 * @param bPreview a flag to indentify if it's for preview 
	 * @throws Exception 
	 * @throws DWLBaseException 
	 */
	protected void processPartyRelationships(String sourcePartyId, Vector vecAllRels,
			Map relmap, TCRMPartyBObj collapsedPartyBObj,
			Vector vecPartyRelationshipRoles, boolean bPreview) throws DWLBaseException, Exception {
		
		String toValue;
		String nonCollapsingPartyId = null;//partyId which is not involving collapsing parties
		
		HashMap<String, LinkedList<TCRMPartyRelationshipBObj>> survivedRelsMap = new HashMap<String, LinkedList<TCRMPartyRelationshipBObj>>();
				
		TCRMPartyRelationshipBObj partyRel;
		
		for(int i = 0; i < vecAllRels.size(); i++) {
			partyRel = (TCRMPartyRelationshipBObj) vecAllRels.elementAt(i);
			toValue = partyRel.getRelationshipToValue();
			//if the toValue(PartyId) is not in relmap, the PartyId does not belong to collapsing parties
			if (relmap.get(toValue) == null) {
				nonCollapsingPartyId = toValue;
			} else {
				nonCollapsingPartyId = null;
			}
			
			//if nonCollapsingPartyId is null, it means that both fromPartyId and toPartyId blong to collapsing parties which
			//will be collpased. So, the relationship will be dropped accordingly.
			//Only when nonCollapsingPartyId is not null, the correspoing relationship is kept for survived party
			if (nonCollapsingPartyId != null) {
				if (survivedRelsMap.get(nonCollapsingPartyId) != null) {
					if (!isDuplicate(sourcePartyId, partyRel, survivedRelsMap.get(nonCollapsingPartyId), nonCollapsingPartyId))
						survivedRelsMap.get(nonCollapsingPartyId).add(partyRel);
				} else {
					LinkedList<TCRMPartyRelationshipBObj> survivedRelsList = new LinkedList<TCRMPartyRelationshipBObj>();
					survivedRelsList.add(partyRel);
					survivedRelsMap.put(nonCollapsingPartyId, survivedRelsList);
				}
				
			}
			
		}
		//processing partyRelationshipRoles
		//If PartyRelationshipRole is not used in customers' implementation,
		//feel free to comment out the following 2 lines and thus avoiding to handle 
		//reltionshipRoles for performance consideration. In this case, only an emtpy vecPartyRelationshipRoles 
		//is returned to core MDM in caller method.
		//if (!bPreview && !survivedRelsMap.isEmpty())
		//	processRelationshipRoles(vecPartyRelationshipRoles ,survivedRelsMap);
		
		
		//attached survived relationships to survived party
		//attachRelationship(collapsedPartyBObj, survivedRelsMap);
		
	}
	


	/**
	 * Check whether a PartyRelationship is a duplicate of other PartyRelationships in a list
	 * 
	 * @param sourcePartyId source party id
	 * @param partyRel a TCRMPartyRelstionshipBObj to compare with TCRMPartyRelstionshipBObj in arrayList
	 * @param relList a list of TCRMPartyRelstionshipBObj
	 * @param nonCollapsingPartyId a PartyId which does not belongs to collapsing parties
	 * @return  
	 *         true   if a duplicate PartyRelationship exists in list, new partyRelatinship will not be added into the list;
	 *         otherwise false if no duplicate in list, new partyRelationship will be added into the list
	 * @throws Exception 
	 * @throws DWLBaseException 
	 */
	protected boolean isDuplicate(String sourcePartyId, TCRMPartyRelationshipBObj partyRel,
			LinkedList<TCRMPartyRelationshipBObj> relList, String nonCollapsingPartyId) throws DWLBaseException, Exception {
		
		boolean duplicteFlag = false;
		String partyRelfromValue = partyRel.getRelationshipFromValue();
		//FromValue alwasys belongs to collpasing parties, set it to empty for comparing the business keys
		partyRel.setRelationshipFromValue("");
		
		String aRelFromValue;

		//looping and compareing new relationship(partyRel) with relationship in the list(relList)
		//either keep it or replace with new relationship in the list
		//based on business key and last update date
		for(TCRMPartyRelationshipBObj aRel : relList) {
			aRelFromValue = aRel.getRelationshipFromValue();
			//set fromValue to empty for comparing business keys
			aRel.setRelationshipFromValue("");
			//if partyRelationship has same business keys and last update date is later then the one in the list
			//remove the partyrelationship from the list and replace with new one in caller method
			//if partyRelationship has same businesskey and same LUD, keep relationship from source party
			//if they're not from source party, keep the one from  greater id 
			if (partyRel.isBusinessKeySame(aRel)) {
				
				if ((partyRel.compareLUD(aRel) > 0 )  
						|| (partyRel.compareLUD(aRel) == 0 && !aRelFromValue.equals(sourcePartyId)
								&& (Long.parseLong(partyRelfromValue) > Long.parseLong(aRelFromValue)))){
					//found duplicate and duplicate is earlier then new one so remove the duplicate from the list
					relList.remove(aRel);
					//after remove the duplicate, there is no duplicate in the list comparing the new one, 
					//so set duplicteFlag to false, and then the new one can be added into list later in caller method
					duplicteFlag = false;
					
				} else {
					//found duplicate in list and duplicate has more recent last update date, 
					//keep the one in list and reset its fromValue. 
					//new one will not be added into list
					//so, set the duplicteFlag to true as well
					aRel.setRelationshipFromValue(aRelFromValue);
					duplicteFlag = true;
					
				}
				
				//list should contains only one duplicate. So skip out of loop once duplicate is found.
				break;
			} else {
				//no duplicate, set duplicteFlag to false, the new one will be added into list.
				//The old one will also be kept and reset its fromValue
				duplicteFlag = false;
				aRel.setRelationshipFromValue(aRelFromValue);
			}
			
		}
		//if new partyRelationship will be added into list, then reset its fromValue
		//for processing relationship roles later
		if (!duplicteFlag) {
			partyRel.setRelationshipFromValue(partyRelfromValue);
		}
		return duplicteFlag;
	}

	/**
	 * Process PartyRelationshipRoles for surviving relationships
	 * 
	 * @param vecRelRoles
	 * @param survivedRelsMap
	 * @throws Exception 
	 */
	protected void processRelationshipRoles(Vector vecRelRoles,
			HashMap<String, LinkedList<TCRMPartyRelationshipBObj>> survivedRelsMap) throws Exception {
		
		
			IPartyBusinessServices partyBizComp = (IPartyBusinessServices) TCRMClassFactory
								.getTCRMComponent(TCRMCorePropertyKeys.PARTY_BUSINESS_SERVICES_COMPONENT);
			
		    Iterator<String> it = survivedRelsMap.keySet().iterator();
		    String nonCollapsingPartyId = null;
		    LinkedList<TCRMPartyRelationshipBObj> relList = new LinkedList<TCRMPartyRelationshipBObj>();
		    String relationshipId, fromPartyId, toPartyId;
		    
		    DWLControl dwlControl;
		    
		    int linkid = 0;//use to link relationship and it roles via ObjectReferenceId
		    Vector tempRoles = new Vector();
		    TCRMPartyRelationshipRoleBObj tempRole;
		    //loop the survivedRelsMap to get each relationship and 
		    //retrieve relationshipRoles via party business services
		    //linked partyRelationship and relationshipRoles using ObjectreferenceId
		    //So, after persisting survived parties and relationship,
		    //RelstionshipRoles attributes of party id and relationship id can be populated accordingly
		    while (it.hasNext()) {
		    	nonCollapsingPartyId = it.next();
		    	relList = survivedRelsMap.get(nonCollapsingPartyId);
		    	for(TCRMPartyRelationshipBObj aRel : relList) {
		    		
	    			//when roles is not empty, set ObjectReferenceId to link relationship and its roles
	    			//ObjectReferenceId will be reset to null after linking relationship and its roles in MDM core 
	    			aRel.setObjectReferenceId(String.valueOf(linkid));
		    		relationshipId = aRel.getPartyRelationshipIdPK();
		    		fromPartyId = aRel.getRelationshipFromPartyId();
		    		toPartyId = aRel.getRelationshipToPartyId();
		    		dwlControl = aRel.getControl();
		    		
		    		//retrieve roles for relationship
		    		tempRoles.addAll(partyBizComp.getAllPartyRelationshipRoles(relationshipId, fromPartyId, TCRMRecordFilter.ACTIVE, dwlControl));
		    		tempRoles.addAll(partyBizComp.getAllPartyRelationshipRoles(relationshipId, toPartyId, TCRMRecordFilter.ACTIVE, dwlControl));
		    		
	    			for(int i = 0; i < tempRoles.size(); i++) {
	    				tempRole =(TCRMPartyRelationshipRoleBObj)tempRoles.elementAt(i);
		    			//set role's ObjectReferenceId to link to relationship
		    			//ObjectReferenceId will be reset to null after linking relationship and its roles in MDM core 
	    				tempRole.setObjectReferenceId(String.valueOf(linkid));
    					tempRole.setPartyRelationshipRoleIdPK(null);
    					//set partyId to null only when partyId belongs to collpasing parties
    					if (!nonCollapsingPartyId.equals(tempRole.getPartyId()))
    						tempRole.setPartyId(null);
	    			}
		    		
		    		vecRelRoles.addAll(tempRoles);
		    		tempRoles.clear();
		    		linkid++;
		    	}
		    	
		    }
		
	}
	/**
	 * Attach processed relationship to survived party
	 * 
	 * @param collapsedPartyBObj
	 * @param survivedRelsMap
	 */
	private void attachRelationship(
			TCRMPartyBObj collapsedPartyBObj,
			HashMap<String, LinkedList<TCRMPartyRelationshipBObj>> survivedRelsMap) {
		
	    Iterator<String> it = survivedRelsMap.keySet().iterator();
	    String nonCollapsingPartyId = null;
	    LinkedList<TCRMPartyRelationshipBObj> relList = new LinkedList<TCRMPartyRelationshipBObj>();

		while(it.hasNext()) {
			nonCollapsingPartyId = it.next();
			relList = survivedRelsMap.get(nonCollapsingPartyId);
			collapsedPartyBObj.getItemsTCRMPartyRelationshipBObj().addAll(relList);
			
		}
	}


	
	/**
	 * @return Holding the error messages if there are any
	 */
	protected DWLStatus addError(DWLControl theControl, String sErrorCode,
			String sReasonCode, String sDetail) {
		IDWLErrorMessage errHandler = TCRMClassFactory.getErrorHandler();

		DWLError error = errHandler.getErrorMessage(
				TCRMCoreComponentID.PARTY_COMPONENT, sErrorCode, sReasonCode,
				theControl, new String[0]);

		error.setDetail(sDetail);
		DWLStatus status = new DWLStatus();
		status.addError(error);
		status.setStatus(DWLStatus.FATAL);
		return status;
	}

	/**
	 * @param tmpCollapseAlerts
	 *            Set bCollapseAlerts to "true" if collapse partyAlerts is
	 *            desired otherwsie "false"
	 */
	public void setCollapsedPartiesAlerts(boolean tmpCollapseAlerts) {
		bCollapsePartiesAlerts = tmpCollapseAlerts;
	}

	public boolean isCollapsedPartiesAlerts() {
		return bCollapsePartiesAlerts;
	}

	/**
	 * Set bCollapsePartiesAdminContEquiv to "true" if collapse AdminContEquiv
	 * is desired otherwise "false"
	 */
	public void setCollapsePartiesAdminContEquiv(
			boolean tmpCollapsePartiesAdminContEquiv) {
		bCollapsePartiesAdminContEquiv = tmpCollapsePartiesAdminContEquiv;
	}

	protected boolean isCollapsedPartiesAdminContEquiv() {
		return bCollapsePartiesAdminContEquiv;
	}

	protected boolean isCollapsePartiesRelationships() {
		return bCollapsePartiesRelationships;
	}

	/**
	 * 
	 * @param vecCompleteParties
	 * @param collapsedPartyBObj
	 */
	private TCRMPartyBObj processPartyRelationships(Vector vecCompleteParties,
			TCRMPartyBObj collapsedPartyBObj, IParty partyComp)
			throws Exception {
		// 2.2 Process party relationships of parties involving in collapsing
		// for the new collapsedParty; if thirdPartyBObj is supplied,
		// process all partyRelations within TCRMPartyListBObj, and add them
		// into thirdPartyBObj.

		// 2.2.1 Get all the relationships for the party (when we call
		// getParty() for each party above, we use inquiry level "4",
		// so all the party relationships should be retrieved.

		// Put the partyBObj which has partyRelationship to a separate vector for collapsing party relationships
		TCRMPartyBObj collapsedPartyCandidate = null;
		Vector vecPartiesWithRelationships = new Vector();

		for (int i = 0; i < vecCompleteParties.size(); i++) {
			collapsedPartyCandidate = (TCRMPartyBObj) vecCompleteParties
					.elementAt(i);

			// Save the party which has party relationships to one place
			if (collapsedPartyCandidate.getItemsTCRMPartyRelationshipBObj() != null
					&& collapsedPartyCandidate
							.getItemsTCRMPartyRelationshipBObj().size() > 0) {
				vecPartiesWithRelationships.add(collapsedPartyCandidate);
			}
		}

		// 2.2.2 Collapse party relationships - relinquish reciprocal
		// relationship + repetitive relationships in the case of collapse
		Vector rel = null;

		if (vecPartiesWithRelationships.size() > 0) {
			
			//add source party in the end of vecPartiesWithRelationships
			TCRMPartyBObj sourceParty=(TCRMPartyBObj)vecCompleteParties.get(0);
			vecPartiesWithRelationships.add(sourceParty);
			
			rel = partyComp.collapsePartyRelationshipsSurvivingRules(vecPartiesWithRelationships);
		}

		if (rel != null && rel.size() > 0) {
			collapsedPartyBObj.getItemsTCRMPartyRelationshipBObj().removeAllElements();
			collapsedPartyBObj.getItemsTCRMPartyRelationshipBObj().addAll(rel);
		} else { // If there are no relationships returned, the collapsed bobj should not have any party relationships
			collapsedPartyBObj.getItemsTCRMPartyRelationshipBObj().removeAllElements();
		}

		return collapsedPartyBObj;
	}

	/**
	 * 
	 * Process party relationship roles: get all partyRelationshipRoles and set
	 * each ObjectReferenceId of partyRelationship and its partyRelRole to a
	 * unique value, we will use this unique value to identify which
	 * partyRelRoles belong to its corresponding partyRelationship
	 * 
	 * @param vecAllRels
	 *            Vector
	 * @return Vector
	 * @throws Exception
	 */
	private Vector processPartyRelationshipRoles(Vector vecAllRels)
			throws Exception {
		// 2. Process relationships (relinquish reciprocal relationship +
		// repetitive relationships) and relationship roles

		// 2.1 Process party relationship roles: add party relationship role to
		// the survived party

		// Get the party business component from the Class factory
		IPartyBusinessServices partyBusSvcComp = (IPartyBusinessServices) TCRMClassFactory
				.getTCRMComponent(TCRMCorePropertyKeys.PARTY_BUSINESS_SERVICES_COMPONENT);

		Vector vecPartyRelationshipRoles = new Vector();
		TCRMPartyRelationshipBObj partyRel = null;

		for (int index = 0; (vecAllRels != null && index < vecAllRels.size()); index++) {
			partyRel = (TCRMPartyRelationshipBObj) vecAllRels.elementAt(index);

			if (partyRel != null) {
				// Set object reference id as identifier for roles
				partyRel.setObjectReferenceId(index + "");

				Long aryIds[] = new Long[] {
						partyRel.getEObjContactRel().getFromContId(),
						partyRel.getEObjContactRel().getToContId() };

				Long id = null;
				for (int j = 0; j < aryIds.length; j++) {
					id = aryIds[j];

					if (id != null && id.longValue() != 0) {
						Vector vector = partyBusSvcComp
								.getAllPartyRelationshipRoles(partyRel
										.getPartyRelationshipIdPK(), id
										.toString(), TCRMRecordFilter.ACTIVE,
										partyRel.getControl());

						for (int i = 0; (vector != null && i < vector.size()); i++) {
							// set object reference id same as relationship
							((TCRMPartyRelationshipRoleBObj) vector
									.elementAt(i)).setObjectReferenceId(index
									+ "");
						}

						vecPartyRelationshipRoles.addAll(vector);
					}
				}
			}
		}

		return vecPartyRelationshipRoles;
	}

	/**
	 * @deprecated in 10.0. Please use IDWLLogger instead and follow code convention for logging.
	 * @param str
	 */
	protected void debugOut(String str) {
//		System.out.println(str);
	}

	/**
	 * @author shreya
	 * filter parties without WS SF ID
	 * or with duplicate WS SF ID
	 * 
	 */
	private void filterPartiesSfdcId(Vector vecParties)
	{	
		Iterator partyIterator = vecParties.iterator();
		boolean flagWsSfdcId;
		// hash_map thats stores cont ID vs WS SFDC ID
		HashMap<String, String> partyWsSfdcIdMap = new HashMap<String, String>();

		ArrayList<String> listWsSfdcId = new ArrayList<String>();
		Iterator<String> itrWsSfId = null;

		while (partyIterator.hasNext()) {

			flagWsSfdcId = false;

			TCRMPartyBObj party = (TCRMPartyBObj) partyIterator.next();

			Vector<XContEquivBObjExt> vecContEquiv = party.getItemsTCRMAdminContEquivBObj();

			if (vecContEquiv != null && !vecContEquiv.isEmpty()) {

				for (XContEquivBObjExt contEquiv : vecContEquiv) {

					if(contEquiv != null)
					{
						if (ExternalRuleUtil.SOURCE_IDENTIFIER_TYPE_SFDC.equalsIgnoreCase(contEquiv.getAdminSystemType())
								|| contEquiv.getAdminSystemValue().equalsIgnoreCase(ExternalRuleUtil.ADMIN_SYS_VALUE_SFDC)
								
								) {

							if (contEquiv.getXSourceRetailerFlag().equalsIgnoreCase("N")
									|| contEquiv.getXSourceRetailerFlag().equalsIgnoreCase("FSWS")) {
								
								//turn flag on to determine WS SFID present
								flagWsSfdcId = true;
								
								//put in map for duplicate filtering
								partyWsSfdcIdMap.put(party.getPartyId(), contEquiv.getAdminPartyId());
							}
						}
					}
				}
			}

			// Parties with no WS SFDC ID to filter out
			if (!flagWsSfdcId) {
				partyIterator.remove();

			}
		}

		//iterating through all WS SFDC IDs to identify duplicates

		//Arraylist with all WS SFIDs, with duplicates
		listWsSfdcId = new ArrayList<String>(partyWsSfdcIdMap.values());

		itrWsSfId = partyWsSfdcIdMap.values().iterator();

		while (itrWsSfId.hasNext()) {

			String sfdcId = itrWsSfId.next();

			//listWsSfdcId is never changed
			if(Collections.frequency(listWsSfdcId, sfdcId)> 1)
				//if(listWsSfdcId.contains(sfdcId))
			{
				//remove all ContIDs with dup SF ID from hashmap
				itrWsSfId.remove();
			}
		}

		//iterating through party vector to remove parties with dup SFDC ID
		partyIterator = vecParties.iterator();
		while (partyIterator.hasNext()) {

			TCRMPartyBObj party = (TCRMPartyBObj) partyIterator.next();

			//If map of parties with unique WS sFID does not have a party ID:
			//remove it from further processing
			if(!partyWsSfdcIdMap.containsKey(party.getPartyId())){
				partyIterator.remove();
			}
		}
	}
	
	//Added by Sumit on 5th March , 2020 : Start
	private void filterPartiesSfdcIdJPN(Vector vecParties)
	{	
		Iterator partyIterator = vecParties.iterator();
		boolean flagWsSfdcId;
		while (partyIterator.hasNext()) {

			flagWsSfdcId = false;
			TCRMPartyBObj party = (TCRMPartyBObj) partyIterator.next();
			Vector<XContEquivBObjExt> vecContEquiv = party.getItemsTCRMAdminContEquivBObj();

			if (vecContEquiv != null && !vecContEquiv.isEmpty()) {
				
				for (XContEquivBObjExt contEquiv : vecContEquiv) {
					
					if(contEquiv != null){
						if ((contEquiv.getAdminSystemType().equalsIgnoreCase(ExternalRuleUtil.SOURCE_IDENTIFIER_TYPE_SFDC)) 
								&& contEquiv.getXSourceRetailerFlag().equalsIgnoreCase("N") 
								&& contEquiv.getDescription().equalsIgnoreCase("M")) {								
									flagWsSfdcId = true; //turn flag on to determine WS SFID present																								
						}
					}
				}
			}			
			// Parties with no WS SFDC ID to filter out
			if (!flagWsSfdcId) {
				partyIterator.remove();
			}
		}
	}
		
	// Filter parties according to Merge flag Japan : Added by Shashi - 7 June 2022	
	private void filterPartiesOnMergeflagJPN(Vector vecParties)
		{	
			Iterator partyIterator = vecParties.iterator();
			boolean flagMergePresent;
			while (partyIterator.hasNext()) {

			flagMergePresent = false;
			TCRMPartyBObj partyval = (TCRMPartyBObj) partyIterator.next();
				
			String Partycheck = partyval.getPartyType();
			String Mergeflag = null;
			
			if(ExternalRuleConstant.PERSON_ORG_CODE_P.equalsIgnoreCase(Partycheck))
			{
				XPersonBObjExt Personval = (XPersonBObjExt)partyval;
				Mergeflag = Personval.getXDoNotMergeFlag();
			}
			else if(ExternalRuleConstant.PERSON_ORG_CODE_O.equalsIgnoreCase(Partycheck))
			{
				XOrgBObjExt Orgval = (XOrgBObjExt)partyval;
				Mergeflag = Orgval.getXDoNotMergeFlag();
				
			}
				
						
				if(Mergeflag != null && Mergeflag.equalsIgnoreCase("Y")){	
				
						flagMergePresent = true; //turn flag on to determine Merge flag present																								
				}
						
				// Parties with Null or N mergeflag to filter out
				if (!flagMergePresent) {
					partyIterator.remove();
				}
			}
		}
		
	private void filterPartiesByDataSharing(Vector vecParties, DWLControl dwlControl) throws DWLBaseException {
		
		DSEAAdditionsExtsComponent dseaAdditionsExtsComponent = new DSEAAdditionsExtsComponent();
		String partyId = null;
		Vector<XDataSharingBObj> vecXWholesaleDataSharing = new Vector<XDataSharingBObj> ();
		Iterator partyIterator = vecParties.iterator();
		DWLResponse dwlResponse = new DWLResponse();
		XDataSharingBObj dataSharingBObj = null;
		String dataSharingFlag = null;
		String dataSharingWholeSaleFlag = null;
		
		while (partyIterator.hasNext()) 
		{
			TCRMPartyBObj party = (TCRMPartyBObj) partyIterator.next();

			partyId = party.getPartyId();
			dwlResponse = dseaAdditionsExtsComponent.getDataSharingByPartyId(partyId ,dwlControl);
			Vector<XDataSharingBObj> vecXDataSharing = (Vector<XDataSharingBObj>) dwlResponse.getData();
			
			dataSharingBObj = vecXDataSharing.get(0);
			dataSharingFlag = dataSharingBObj.getDataSharingFlag();
			dataSharingWholeSaleFlag = dataSharingBObj.getDataSharingWholesale();
			
			if(dataSharingFlag != null && dataSharingWholeSaleFlag != null 
					&& ("N".equals(dataSharingFlag)
					|| "N".equals(dataSharingWholeSaleFlag))){
				partyIterator.remove();
			}else if (dataSharingFlag == null || dataSharingWholeSaleFlag == null){
				partyIterator.remove();
			}
			
		}
		
		
	}

}
