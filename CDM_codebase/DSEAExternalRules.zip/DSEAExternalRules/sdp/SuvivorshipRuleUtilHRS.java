package com.ibm.daimler.dsea.extrules.sdp;

import java.sql.Timestamp;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.Vector;

import com.dwl.base.DWLCommon;
import com.dwl.base.DWLControl;
import com.dwl.base.exception.DWLBaseException;
import com.dwl.base.util.DWLExceptionUtils;
import com.dwl.base.util.StringUtils;
import com.dwl.tcrm.coreParty.component.TCRMAdminContEquivBObj;
import com.dwl.tcrm.coreParty.component.TCRMPartyBObj;
import com.dwl.tcrm.coreParty.component.TCRMPersonBObj;
import com.dwl.tcrm.utilities.DateFormatter;
import com.ibm.daimler.dsea.component.XAddressGroupBObjExt;
import com.ibm.daimler.dsea.component.XContEquivBObjExt;
import com.ibm.daimler.dsea.component.XContactMethodGroupBObjExt;
import com.ibm.daimler.dsea.component.XIdentifierBObjExt;
import com.ibm.daimler.dsea.component.XOrgBObjExt;
import com.ibm.daimler.dsea.component.XOrgNameBObjExt;
import com.ibm.daimler.dsea.component.XPersonBObjExt;
import com.ibm.daimler.dsea.component.XPersonNameBObjExt;
import com.ibm.daimler.dsea.extrules.constant.ExternalRuleConstant;

public class SuvivorshipRuleUtilHRS {
	@SuppressWarnings("unchecked")
	public static Vector collapseObjectsSurvivingRules(Vector vecDWLCommons, boolean bReturnTheMostRecentRootBObjOnly) throws DWLBaseException {

		Vector vecSurviveDWLCommons = new Vector();
		
		try
		{
			DWLCommon source = (DWLCommon) vecDWLCommons.get(0);
			TCRMPartyBObj newParty = null;
			String personOrgCode = null;

			if(source instanceof TCRMPartyBObj)
			{
				DWLControl control = source.getControl();
				@SuppressWarnings("rawtypes")

				Vector<TCRMPartyBObj> vecAllParty = new Vector<TCRMPartyBObj>();
				TCRMPartyBObj firstparty = (TCRMPartyBObj) vecDWLCommons.get(0);
				personOrgCode = firstparty.getPartyType();
				newParty = (TCRMPartyBObj) Class.forName(firstparty.getClass().getName()).newInstance();

				if(ExternalRuleConstant.PERSON_ORG_CODE_P.equalsIgnoreCase(personOrgCode))
				{
					Collections.sort(vecDWLCommons, new Comparator<XPersonBObjExt>()
							{	
						//Ascending sort - for delta load
						public int compare(XPersonBObjExt party1, XPersonBObjExt party2)
						{
							if (party1.getXLastModifiedSystemDate() == null || party2.getXLastModifiedSystemDate() == null)
								return 0;

							return party1.getXLastModifiedSystemDate().compareTo(party2.getXLastModifiedSystemDate());
						}
							});

					//Descending sort
					Collections.reverse(vecDWLCommons);
					Iterator itParty = vecDWLCommons.iterator();

					while (itParty.hasNext())
					{
						TCRMPartyBObj newParty1 = new TCRMPartyBObj();
						newParty1 = (TCRMPartyBObj) itParty.next();
						vecAllParty.add(newParty1);
					}

					XPersonBObjExt newPartyBObj = (XPersonBObjExt) newParty;
					XPersonBObjExt survivedBOBj = sortParties(vecAllParty,newPartyBObj, control);
					
					//Survive Gender & Occupation Details
					surviveGenderOccupation(control,survivedBOBj, vecAllParty);

					HashMap<String, HashMap> finalPersonDetlsMap = survivedPersonDetails(vecAllParty, control);

					HashMap<String, XPersonNameBObjExt> personNameMap = new HashMap<String, XPersonNameBObjExt>();
					HashMap<String, XAddressGroupBObjExt> partyAddressMap = new HashMap<String, XAddressGroupBObjExt>();
					HashMap<String, XIdentifierBObjExt> partyIdentMap = new HashMap<String, XIdentifierBObjExt>();
					HashMap<String, XContactMethodGroupBObjExt> partyContMethMap = new HashMap<String, XContactMethodGroupBObjExt>();
					HashMap<String, TCRMAdminContEquivBObj> partyAdminConteqMap = new HashMap<String, TCRMAdminContEquivBObj>();

					Vector<XPersonNameBObjExt> vecSurvivedPersonNameBOBj = new Vector<XPersonNameBObjExt>();
					Vector<XAddressGroupBObjExt> vecSurvivedPartyAddrBOBj = new Vector<XAddressGroupBObjExt>();
					Vector<XIdentifierBObjExt> vecSurvivedPartyIdenBOBj = new Vector<XIdentifierBObjExt>();
					Vector<XContactMethodGroupBObjExt> vecSurvivedPartyContMethBOBj = new Vector<XContactMethodGroupBObjExt>();
					Vector<TCRMAdminContEquivBObj> vecSurvivedPartyAdminContBOBj = new Vector<TCRMAdminContEquivBObj>();


					personNameMap = finalPersonDetlsMap.get(ExternalRuleConstant.SURVIVED_MAP_NAME);
					partyAddressMap = finalPersonDetlsMap.get(ExternalRuleConstant.SURVIVED_MAP_ADDRESS);
					partyIdentMap = finalPersonDetlsMap.get(ExternalRuleConstant.SURVIVED_MAP_IDENTIFIER);
					partyContMethMap = finalPersonDetlsMap.get(ExternalRuleConstant.SURVIVED_MAP_CONTACTMETHOD);
					partyAdminConteqMap = finalPersonDetlsMap.get(ExternalRuleConstant.SURVIVED_MAP_CONTEQUIV);

					for (Map.Entry<String, XPersonNameBObjExt> entry : personNameMap.entrySet())
						vecSurvivedPersonNameBOBj.add(entry.getValue());

					for (Map.Entry<String, XAddressGroupBObjExt> entry : partyAddressMap.entrySet())
						vecSurvivedPartyAddrBOBj.add(entry.getValue());

					for (Map.Entry<String, XIdentifierBObjExt> entry : partyIdentMap.entrySet())
						vecSurvivedPartyIdenBOBj.add(entry.getValue());

					for (Map.Entry<String, XContactMethodGroupBObjExt> entry : partyContMethMap.entrySet())
						vecSurvivedPartyContMethBOBj.add(entry.getValue());

					for (Map.Entry<String, TCRMAdminContEquivBObj> entry : partyAdminConteqMap.entrySet())
						vecSurvivedPartyAdminContBOBj.add(entry.getValue());
					
					// Pravin : To handle Preferred Address
					handlePrefAddress(vecSurvivedPartyAddrBOBj);

					// Pravin : To handle Preferred Address
					handlePrefContactMethod(vecSurvivedPartyContMethBOBj);

					if (vecSurvivedPersonNameBOBj.size() > 0 || vecSurvivedPersonNameBOBj != null)
					{
						((TCRMPersonBObj) survivedBOBj).getItemsTCRMPersonNameBObj().clear();
						((TCRMPersonBObj) survivedBOBj).getItemsTCRMPersonNameBObj().addAll(vecSurvivedPersonNameBOBj);
					}

					if (vecSurvivedPartyAddrBOBj.size() > 0 || vecSurvivedPartyAddrBOBj != null)
					{
						((TCRMPersonBObj) survivedBOBj).getItemsTCRMPartyAddressBObj().clear();
						((TCRMPersonBObj) survivedBOBj).getItemsTCRMPartyAddressBObj().addAll(vecSurvivedPartyAddrBOBj);
					}

					if (vecSurvivedPartyIdenBOBj.size() > 0 || vecSurvivedPartyIdenBOBj != null)
					{
						((TCRMPersonBObj) survivedBOBj).getItemsTCRMPartyIdentificationBObj().clear();
						((TCRMPersonBObj) survivedBOBj).getItemsTCRMPartyIdentificationBObj().addAll(vecSurvivedPartyIdenBOBj);
					}

					if (vecSurvivedPartyContMethBOBj.size() > 0 || vecSurvivedPartyContMethBOBj != null) 
					{
						((TCRMPersonBObj) survivedBOBj).getItemsTCRMPartyContactMethodBObj().clear();
						((TCRMPersonBObj) survivedBOBj).getItemsTCRMPartyContactMethodBObj().addAll(vecSurvivedPartyContMethBOBj);
					}

					if (vecSurvivedPartyAdminContBOBj.size() > 0 || vecSurvivedPartyAdminContBOBj != null) 
					{
						((TCRMPersonBObj) survivedBOBj).getItemsTCRMAdminContEquivBObj().clear();
						((TCRMPersonBObj) survivedBOBj).getItemsTCRMAdminContEquivBObj().addAll(vecSurvivedPartyAdminContBOBj);
					}

					vecSurviveDWLCommons.add(survivedBOBj);

				}
				else if(ExternalRuleConstant.PERSON_ORG_CODE_O.equalsIgnoreCase(personOrgCode))
				{

					Collections.sort(vecDWLCommons, new Comparator<XOrgBObjExt>() {//Ascending sort - for delta load
						public int compare(XOrgBObjExt party1, XOrgBObjExt party2) {
							if (party1.getXLastModifiedSystemDate() == null || party2.getXLastModifiedSystemDate() == null)
								return 0;
							return party1.getXLastModifiedSystemDate().compareTo(party2.getXLastModifiedSystemDate());
						}
					});
					Collections.reverse(vecDWLCommons);//Descending sort
					Iterator itParty = vecDWLCommons.iterator();
					while (itParty.hasNext()) {

						TCRMPartyBObj newParty1 = new TCRMPartyBObj();
						newParty1 = (TCRMPartyBObj) itParty.next();
						vecAllParty.add(newParty1);
					}

					TCRMPartyBObj survivedBOBj = sortOrgParties(vecAllParty,newParty, control);

					HashMap<String, HashMap> finalOrgDetlsMap = survivedOrgDetails(
							vecAllParty, control);
					HashMap<String, XOrgNameBObjExt> orgNameMap = new HashMap<String, XOrgNameBObjExt>();
					HashMap<String, XAddressGroupBObjExt> partyAddressMap = new HashMap<String, XAddressGroupBObjExt>();
					HashMap<String, XIdentifierBObjExt> partyIdentMap = new HashMap<String, XIdentifierBObjExt>();
					HashMap<String, XContactMethodGroupBObjExt> partyContMethMap = new HashMap<String, XContactMethodGroupBObjExt>();
					HashMap<String, TCRMAdminContEquivBObj> partyAdminConteqMap = new HashMap<String, TCRMAdminContEquivBObj>();
					
					Vector<XOrgNameBObjExt> vecSurvivedOrgNameBOBj = new Vector<XOrgNameBObjExt>();
					Vector<XAddressGroupBObjExt> vecSurvivedPartyAddrBOBj = new Vector<XAddressGroupBObjExt>();
					Vector<XIdentifierBObjExt> vecSurvivedPartyIdenBOBj = new Vector<XIdentifierBObjExt>();
					Vector<XContactMethodGroupBObjExt> vecSurvivedPartyContMethBOBj = new Vector<XContactMethodGroupBObjExt>();
					Vector<TCRMAdminContEquivBObj> vecSurvivedPartyAdminContBOBj = new Vector<TCRMAdminContEquivBObj>();
				
					orgNameMap = finalOrgDetlsMap.get(ExternalRuleConstant.SURVIVED_MAP_NAME);
					partyAddressMap = finalOrgDetlsMap.get(ExternalRuleConstant.SURVIVED_MAP_ADDRESS);
					partyIdentMap = finalOrgDetlsMap.get(ExternalRuleConstant.SURVIVED_MAP_IDENTIFIER);
					partyContMethMap = finalOrgDetlsMap.get(ExternalRuleConstant.SURVIVED_MAP_CONTACTMETHOD);
					partyAdminConteqMap = finalOrgDetlsMap.get(ExternalRuleConstant.SURVIVED_MAP_CONTEQUIV);

					for (Map.Entry<String, XOrgNameBObjExt> entry : orgNameMap
							.entrySet()) {
						vecSurvivedOrgNameBOBj.add(entry.getValue());
					}
					for (Map.Entry<String, XAddressGroupBObjExt> entry : partyAddressMap
							.entrySet()) {
						vecSurvivedPartyAddrBOBj.add(entry.getValue());
					}

					for (Map.Entry<String, XIdentifierBObjExt> entry : partyIdentMap
							.entrySet()) {
						vecSurvivedPartyIdenBOBj.add(entry.getValue());
					}
					for (Map.Entry<String, XContactMethodGroupBObjExt> entry : partyContMethMap
							.entrySet()) {
						vecSurvivedPartyContMethBOBj.add(entry.getValue());
					}
					for (Map.Entry<String, TCRMAdminContEquivBObj> entry : partyAdminConteqMap
							.entrySet()) {
						vecSurvivedPartyAdminContBOBj.add(entry.getValue());
					}

					// Pravin : To handle Preferred Address
					handlePrefAddress(vecSurvivedPartyAddrBOBj);

					// Pravin : To handle Preferred Address
					handlePrefContactMethod(vecSurvivedPartyContMethBOBj);
					
					if (vecSurvivedOrgNameBOBj.size() > 0 || vecSurvivedOrgNameBOBj != null)
					{
						((XOrgBObjExt) survivedBOBj).getItemsTCRMOrganizationNameBObj().clear();
						((XOrgBObjExt) survivedBOBj).getItemsTCRMOrganizationNameBObj().addAll(vecSurvivedOrgNameBOBj);
					}

					if (vecSurvivedPartyAddrBOBj.size() > 0 || vecSurvivedPartyAddrBOBj != null)
					{
						((XOrgBObjExt) survivedBOBj).getItemsTCRMPartyAddressBObj().clear();
						((XOrgBObjExt) survivedBOBj).getItemsTCRMPartyAddressBObj().addAll(vecSurvivedPartyAddrBOBj);
					}

					if (vecSurvivedPartyIdenBOBj.size() > 0 || vecSurvivedPartyIdenBOBj != null)
					{
						((XOrgBObjExt) survivedBOBj).getItemsTCRMPartyIdentificationBObj().clear();
						((XOrgBObjExt) survivedBOBj).getItemsTCRMPartyIdentificationBObj().addAll(vecSurvivedPartyIdenBOBj);
					}

					if (vecSurvivedPartyContMethBOBj.size() > 0 || vecSurvivedPartyContMethBOBj != null) 
					{
						((XOrgBObjExt) survivedBOBj).getItemsTCRMPartyContactMethodBObj().clear();
						((XOrgBObjExt) survivedBOBj).getItemsTCRMPartyContactMethodBObj().addAll(vecSurvivedPartyContMethBOBj);
					}

					if (vecSurvivedPartyAdminContBOBj.size() > 0 || vecSurvivedPartyAdminContBOBj != null) 
					{
						((XOrgBObjExt) survivedBOBj).getItemsTCRMAdminContEquivBObj().clear();
						((XOrgBObjExt) survivedBOBj).getItemsTCRMAdminContEquivBObj().addAll(vecSurvivedPartyAdminContBOBj);
					}

					vecSurviveDWLCommons.add(survivedBOBj);

				}
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			DWLExceptionUtils.log(e);
		}

		return vecSurviveDWLCommons;
	}

	// Survived Sorterd Parties method
	@SuppressWarnings("unchecked")
	public static XPersonBObjExt sortParties(Vector<TCRMPartyBObj> vecAllParty, XPersonBObjExt newParty, DWLControl control) throws Exception {

		Timestamp tempCreatedDt = null;
		Timestamp incomingCreatedDt = null;
		XPersonBObjExt tempPartyBObj = null;
		int index =0;
		String incomingPartySourceSystem = null;
		String tempPartySourceSystem = null;

		for (TCRMPartyBObj incomingParty : vecAllParty )
		{
			XPersonBObjExt incomingPersonBObj = (XPersonBObjExt) incomingParty;
			if(index == 0) {
				tempPartyBObj = incomingPersonBObj;
				index++;
				continue;
			}        	

			incomingCreatedDt = DateFormatter.getTimestamp(incomingPersonBObj.getXLastModifiedSystemDate());
			tempCreatedDt = DateFormatter.getTimestamp(tempPartyBObj.getXLastModifiedSystemDate());

			incomingPartySourceSystem = incomingPersonBObj.getSourceIdentifierType();
			tempPartySourceSystem = tempPartyBObj.getSourceIdentifierType();

			if(incomingPartySourceSystem.equalsIgnoreCase(tempPartySourceSystem))
			{
				//If the suspect parties are from the same source system, survive the latest party
				if (incomingCreatedDt.after(tempCreatedDt)) {

					entityCRUDPerson(incomingParty, tempPartyBObj, control);
					tempPartyBObj = incomingPersonBObj;
				}
				else {

					entityCRUDPerson(tempPartyBObj, incomingParty, control);
				}
			}
			else
			{
				//Get source priority of the suspect parties
				String incomingSourcePriority = getSOurcePriorityForPersonAttributes(incomingPartySourceSystem);
				String tempSourcePriority = getSOurcePriorityForPersonAttributes(tempPartySourceSystem);

				//If source priority is same for the suspect parties, survive the latest party
				if(incomingSourcePriority.equalsIgnoreCase(tempSourcePriority))
				{
					if (incomingCreatedDt.after(tempCreatedDt)) {

						entityCRUDPerson(incomingParty, tempPartyBObj, control);
						tempPartyBObj = incomingPersonBObj;
					}
					else {

						entityCRUDPerson(tempPartyBObj, incomingParty, control);
					}
				}
				else
				{
					//Survived the person details for the party with higher source priority
					if(Integer.parseInt(incomingSourcePriority)>Integer.parseInt(tempSourcePriority))
					{
						entityCRUDPerson(incomingParty, tempPartyBObj, control);
						tempPartyBObj = incomingPersonBObj;
					}
					else
					{
						entityCRUDPerson(tempPartyBObj, incomingParty, control);
					}
				}
			}


		}

		newParty.shallowClone(tempPartyBObj);

		return newParty;		
	}

	/**
	 * Method to get the source system priority for person attributes 
	 * @param sourceSystemType
	 * @return
	 * @throws Exception
	 */
	public static String getSOurcePriorityForPersonAttributes (String sourceSystemType) throws Exception {

		String sourcePriority = null;

		if(StringUtils.isNonBlank(sourceSystemType))
		{
			if(ExternalRuleConstant.SOURCE_SYSTEM_TYPE_SFDC_HRS.equalsIgnoreCase(sourceSystemType)||
					ExternalRuleConstant.SOURCE_SYSTEM_TYPE_AUTOLINE_HRS.equalsIgnoreCase(sourceSystemType) )
			{
				sourcePriority = ExternalRuleConstant.SOURCE_PRIORITY_HRS_2;
			}
			else if(ExternalRuleConstant.SOURCE_SYSTEM_TYPE_TDS_HRS.equalsIgnoreCase(sourceSystemType))
			{
				sourcePriority = ExternalRuleConstant.SOURCE_PRIORITY_HRS_1;				
			}
			else
			{
				//Hard Coded for the time being, need to be corrected
				sourcePriority = ExternalRuleConstant.SOURCE_PRIORITY_HRS_1;
			}
		}
		return sourcePriority;		
	}

	/**
	 * 
	 * @param incomingParty
	 * @param tempPartyBObj
	 * @param control
	 * @throws Exception
	 */
	public static void entityCRUDPerson(TCRMPartyBObj incomingParty,TCRMPartyBObj tempPartyBObj, DWLControl control) throws Exception {


		String prefLangType = null;
		String sourceIdentifierType = null;
		String sourceIdentifierValue = null;

		String prefLangValue = ((TCRMPersonBObj)tempPartyBObj).getPreferredLanguageValue();

		if(tempPartyBObj.getSourceIdentifierValue()!= null)
			sourceIdentifierValue = ((TCRMPersonBObj)tempPartyBObj).getSourceIdentifierValue();	

		prefLangType = ((TCRMPersonBObj)tempPartyBObj).getPreferredLanguageType();

		if(((TCRMPersonBObj)tempPartyBObj).getSourceIdentifierValue()!= null)
			sourceIdentifierType = ((TCRMPersonBObj)tempPartyBObj).getSourceIdentifierValue();

		//Preferred Language type
		if (((TCRMPersonBObj)incomingParty).getPreferredLanguageType() == null || ((TCRMPersonBObj)incomingParty).getPreferredLanguageType().isEmpty())
			((TCRMPersonBObj)incomingParty).setPreferredLanguageType(prefLangType);

		//Preferred Language Value
		if (((TCRMPersonBObj)incomingParty).getPreferredLanguageValue() == null || ((TCRMPersonBObj)incomingParty).getPreferredLanguageValue().isEmpty())
			((TCRMPersonBObj)incomingParty).setPreferredLanguageValue(((TCRMPersonBObj)tempPartyBObj).getPreferredLanguageValue());

		//Party Type
		if (((TCRMPersonBObj)incomingParty).getPartyType() == null || ((TCRMPersonBObj)incomingParty).getPartyType().isEmpty())
			((TCRMPersonBObj)incomingParty).setPartyType(((TCRMPersonBObj)tempPartyBObj).getPartyType());

		//CreatedDate
		if (((TCRMPersonBObj)incomingParty).getCreatedDate() == null || ((TCRMPersonBObj)incomingParty).getCreatedDate().isEmpty())
			((TCRMPersonBObj)incomingParty).setCreatedDate(((TCRMPersonBObj)tempPartyBObj).getCreatedDate());

		//Client Status Type
		if (((TCRMPersonBObj)incomingParty).getClientStatusType() == null || ((TCRMPersonBObj)incomingParty).getClientStatusType().isEmpty())
			((TCRMPersonBObj)incomingParty).setClientStatusType(((TCRMPersonBObj)tempPartyBObj).getClientStatusType());

		//Solicitation Indicator
		if (((TCRMPersonBObj)incomingParty).getSolicitationIndicator() == null || ((TCRMPersonBObj)incomingParty).getSolicitationIndicator().isEmpty())
			((TCRMPersonBObj)incomingParty).setSolicitationIndicator(((TCRMPersonBObj)tempPartyBObj).getSolicitationIndicator());

		//ConfidentialIndicator
		if (((TCRMPersonBObj)incomingParty).getConfidentialIndicator() == null || ((TCRMPersonBObj)incomingParty).getConfidentialIndicator().isEmpty())
			((TCRMPersonBObj)incomingParty).setConfidentialIndicator(((TCRMPersonBObj)tempPartyBObj).getConfidentialIndicator());

		//ClientImportanceType
		if (((TCRMPersonBObj)incomingParty).getConfidentialIndicator() == null || ((TCRMPersonBObj)incomingParty).getConfidentialIndicator().isEmpty())
			((TCRMPersonBObj)incomingParty).setConfidentialIndicator(((TCRMPersonBObj)tempPartyBObj).getConfidentialIndicator());

		//ClientImportanceValue
		if (((TCRMPersonBObj)incomingParty).getClientImportanceType() == null || ((TCRMPersonBObj)incomingParty).getClientImportanceType().isEmpty())
			((TCRMPersonBObj)incomingParty).setClientImportanceType(((TCRMPersonBObj)tempPartyBObj).getClientImportanceType());

		//Birth Date
		if (((TCRMPersonBObj)incomingParty).getBirthDate() == null || ((TCRMPersonBObj)incomingParty).getBirthDate().isEmpty())
			((TCRMPersonBObj)incomingParty).setBirthDate(((TCRMPersonBObj)tempPartyBObj).getBirthDate());

		//Gender
		if (((TCRMPersonBObj)incomingParty).getGenderType() == null || ((TCRMPersonBObj)incomingParty).getGenderType().isEmpty())
			((TCRMPersonBObj)incomingParty).setGenderType(((TCRMPersonBObj)tempPartyBObj).getGenderType());

		//Source Identifier Type
		if (((TCRMPersonBObj)incomingParty).getSourceIdentifierType() == null || ((TCRMPersonBObj)incomingParty).getSourceIdentifierType().isEmpty())
			((TCRMPersonBObj)incomingParty).setSourceIdentifierType(sourceIdentifierType);

		//Source Identifier Value
		if (((TCRMPersonBObj)incomingParty).getSourceIdentifierValue() == null || ((TCRMPersonBObj)incomingParty).getSourceIdentifierValue().isEmpty())
			((TCRMPersonBObj)incomingParty).setSourceIdentifierValue(((TCRMPersonBObj)tempPartyBObj).getSourceIdentifierValue());

		//Last Verified Date
		if (((TCRMPersonBObj)incomingParty).getLastVerifiedDate() == null || ((TCRMPersonBObj)incomingParty).getLastVerifiedDate().isEmpty())
			((TCRMPersonBObj)incomingParty).setLastVerifiedDate(((TCRMPersonBObj)tempPartyBObj).getLastVerifiedDate());

		XPersonBObjExt xincomingObj = (XPersonBObjExt)incomingParty;
		XPersonBObjExt xtempBobj = (XPersonBObjExt) tempPartyBObj;

		// Maintain XPerson attributes
		if(xincomingObj != null && xtempBobj != null)
			setXPersonAttr(xincomingObj, xtempBobj, control);

	}
	/**
	 * Method to set XPerson attributes
	 * @param xMainInputBOBj
	 * @param xDBinputBObj
	 * @param control
	 * @throws Exception
	 */
	public static void setXPersonAttr(XPersonBObjExt xMainInputBOBj, XPersonBObjExt xDBinputBObj, DWLControl control) throws Exception
	{
		//XDefunctInd
		if (xMainInputBOBj.getXDefunctInd() == null || xMainInputBOBj.getXDefunctInd().isEmpty())
			xMainInputBOBj.setXDefunctInd(xDBinputBObj.getXDefunctInd());

		//XEmployerName
		if (xMainInputBOBj.getXEmployerName() == null || xMainInputBOBj.getXEmployerName().isEmpty())
			xMainInputBOBj.setXEmployerName(xDBinputBObj.getXEmployerName());

		//XMarketName
		if (xMainInputBOBj.getXMarketName() == null || xMainInputBOBj.getXMarketName().isEmpty())
			xMainInputBOBj.setXMarketName(xDBinputBObj.getXMarketName());

		//XBatchInd
		if (xMainInputBOBj.getXBatchInd() == null || xMainInputBOBj.getXBatchInd().isEmpty())
			xMainInputBOBj.setXBatchInd(xDBinputBObj.getXBatchInd());

		//XOccupationType
		if (xMainInputBOBj.getXOccupationType() == null || xMainInputBOBj.getXOccupationType().isEmpty())
			xMainInputBOBj.setXOccupationType(xDBinputBObj.getXOccupationType());

		//XOccupationValue
		if (xMainInputBOBj.getXOccupationValue() == null || xMainInputBOBj.getXOccupationValue().isEmpty())
			xMainInputBOBj.setXOccupationValue(xDBinputBObj.getXOccupationValue());

		//XLastModifiedSystemDate
		if (xMainInputBOBj.getXLastModifiedSystemDate() == null || xMainInputBOBj.getXLastModifiedSystemDate().isEmpty())
			xMainInputBOBj.setXLastModifiedSystemDate(xDBinputBObj.getXLastModifiedSystemDate());

		//XGeneratedBy
		if (xMainInputBOBj.getXGeneratedBy() == null || xMainInputBOBj.getXGeneratedBy().isEmpty())
			xMainInputBOBj.setXGeneratedBy(xDBinputBObj.getXGeneratedBy());

		//XHobby
		if (xMainInputBOBj.getXHobby() == null || xMainInputBOBj.getXHobby().isEmpty())
			xMainInputBOBj.setXHobby(xDBinputBObj.getXHobby());

		//XPersonalAgreement
		if(xMainInputBOBj.getXPersonalAgreement() == null || xMainInputBOBj.getXPersonalAgreement().isEmpty())
			xMainInputBOBj.setXPersonalAgreement(xDBinputBObj.getXPersonalAgreement());

	}

	/**
	 * Method to survive person components
	 * @param vecAllParty
	 * @param control
	 * @return
	 * @throws Exception
	 */
	private static HashMap<String, HashMap> survivedPersonDetails(Vector vecAllParty,DWLControl control) throws Exception {

		HashMap<String, XPersonNameBObjExt> personNameMap = new HashMap<String, XPersonNameBObjExt>();
		HashMap<String, XAddressGroupBObjExt> partyAddressMap = new HashMap<String, XAddressGroupBObjExt>();
		HashMap<String, XIdentifierBObjExt> partyIdentMap = new HashMap<String, XIdentifierBObjExt>();
		HashMap<String, XContactMethodGroupBObjExt> partyContMethMap = new HashMap<String, XContactMethodGroupBObjExt>();
		HashMap<String, TCRMAdminContEquivBObj> partyAdminConteqMap = new HashMap<String, TCRMAdminContEquivBObj>();
		String mapKey = null;
		boolean isBatch = true;

		XPersonBObjExt incomingPersonBObj = (XPersonBObjExt) vecAllParty.get(0);

		if((ExternalRuleConstant.HUNGARY_MARKET_NAME.equalsIgnoreCase(incomingPersonBObj.getXMarketName()))
				||(ExternalRuleConstant.ROMANIA_MARKET_NAME.equalsIgnoreCase(incomingPersonBObj.getXMarketName()))
				||(ExternalRuleConstant.SLOVAKIA_MARKET_NAME.equalsIgnoreCase(incomingPersonBObj.getXMarketName())))

		{	
			//Added by Sameeha for separate Address survivorship for Initialization data : 18th July,19: Start
			for(int i=0; i < vecAllParty.size(); i++){
			
				TCRMPartyBObj party = (TCRMPartyBObj) vecAllParty.get(i);
				if(ExternalRuleConstant.BATCH_IND_N.equalsIgnoreCase(((XPersonBObjExt) party).getXBatchInd()))
					{
						isBatch = false;
						break;
					}
			}
			//Survive Address Details 
			if(isBatch)
				surviveAddressDetailsInit(control, partyAddressMap, vecAllParty);
			else
				surviveAddressDetailsRT(control, partyAddressMap, vecAllParty);

			//Added by Sameeha for separate Address survivorship for Initialization data : 18th July,19: End
			
			for(int i=0; i < vecAllParty.size(); i++)
			{
				TCRMPartyBObj party = (TCRMPartyBObj) vecAllParty.get(i);


				Vector<XPersonNameBObjExt> vecTempPersonNameBOBj = new Vector<XPersonNameBObjExt>();
				vecTempPersonNameBOBj = ((XPersonBObjExt) party).getItemsTCRMPersonNameBObj();

				//Survive Person Name Details
				survivePersonNameDetails(control, personNameMap, vecTempPersonNameBOBj);


				Vector<XIdentifierBObjExt> vecTempPartyIdentificationBObj = new Vector<XIdentifierBObjExt>();
				vecTempPartyIdentificationBObj = party.getItemsTCRMPartyIdentificationBObj();

				//Survive Identifier Details 
				surviveIdentifierDetails(control, partyIdentMap, vecTempPartyIdentificationBObj);
				Vector<XContactMethodGroupBObjExt> vecTempPartyContactMethodBObj = new Vector<XContactMethodGroupBObjExt>();
				vecTempPartyContactMethodBObj = party.getItemsTCRMPartyContactMethodBObj();	

				//Survive Party Contact Method Details
				surviveContactMethodDetails(control, partyContMethMap, vecTempPartyContactMethodBObj);

				Vector<XContEquivBObjExt> vecTempAdminContequivBObj =  new Vector<XContEquivBObjExt>();
				vecTempAdminContequivBObj = party.getItemsTCRMAdminContEquivBObj();

				//Admin Contequiv  
				surviveContEquivDetails(control, partyAdminConteqMap, vecTempAdminContequivBObj);
				
				

			}
		}

		HashMap<String, HashMap> partyMap = new HashMap<String, HashMap>();
		partyMap.put(ExternalRuleConstant.SURVIVED_MAP_NAME, personNameMap);
		partyMap.put(ExternalRuleConstant.SURVIVED_MAP_ADDRESS, partyAddressMap);
		partyMap.put(ExternalRuleConstant.SURVIVED_MAP_IDENTIFIER, partyIdentMap);
		partyMap.put(ExternalRuleConstant.SURVIVED_MAP_CONTACTMETHOD, partyContMethMap);
		partyMap.put(ExternalRuleConstant.SURVIVED_MAP_CONTEQUIV, partyAdminConteqMap);

		return partyMap;

	}

	//Added by Sameeha for RT/Delta Address Survivorship , 18thJuly,19: Start
	private static void surviveAddressDetailsRT(DWLControl control,	HashMap<String, XAddressGroupBObjExt> partyAddressMap,
			Vector vecAllParty) throws Exception {


		String firstPartyAddressUsageType = null;
		String secondPartyAddressUsageType = null;
		String firstPartyAddressSourceType = null;
		String secondPartyAddressSourceType = null;
		String firstPartyAddressRetailerID = null;
		String secondPartyAddressRetailerID = null;
		String addressRetailerFlag = null;
		String mapKey = null;
		Vector<XAddressGroupBObjExt> vecTempPartyAddressBObj = new Vector<XAddressGroupBObjExt>();

		
		for (int i = 0; i < vecAllParty.size(); i++) {
				
				TCRMPartyBObj party = (TCRMPartyBObj) vecAllParty.get(i);
				
				if(ExternalRuleConstant.PERSON_ORG_CODE_P.equalsIgnoreCase(party.getPartyType())){
					
					XPersonBObjExt tempPersonBObj = (XPersonBObjExt) vecAllParty.get(i);
		
					vecTempPartyAddressBObj = tempPersonBObj.getItemsTCRMPartyAddressBObj();
		
				}
				else if(ExternalRuleConstant.PERSON_ORG_CODE_O.equalsIgnoreCase(party.getPartyType())){
					
					XOrgBObjExt tempOrgBObj = (XOrgBObjExt) vecAllParty.get(i);
		
					vecTempPartyAddressBObj = tempOrgBObj.getItemsTCRMPartyAddressBObj();
		
				}
				
			if(null!= vecTempPartyAddressBObj && vecTempPartyAddressBObj.size()>0)
			{
				for(int j = 0; j<vecTempPartyAddressBObj.size(); j++)
				{
					XAddressGroupBObjExt partyAddressBObj = vecTempPartyAddressBObj.get(j);
					addressRetailerFlag = partyAddressBObj.getXAddressRetailerFlag();
	
					if(ExternalRuleConstant.ADDRESS_RETAILER_FLAG_HRS_Y.equalsIgnoreCase(addressRetailerFlag))
					{
						firstPartyAddressUsageType = partyAddressBObj.getAddressUsageType();
						firstPartyAddressSourceType = partyAddressBObj.getSourceIdentifierType();
						firstPartyAddressRetailerID = partyAddressBObj.getXRetailerId();
						//May 24, 2019 : Added by Sameeha for single retail Address: Start
					
						mapKey = partyAddressBObj.getXAddressRetailerFlag()  + firstPartyAddressRetailerID;
						
						//May 24, 2019 : Added by Sameeha for single retail Address: End
	
						if(!partyAddressMap.containsKey(mapKey))
						{
							partyAddressMap.put(mapKey, partyAddressBObj);
						}
						else
						{
							XAddressGroupBObjExt partyAddressBObjInMap = partyAddressMap.get(mapKey);
							secondPartyAddressUsageType = partyAddressBObjInMap.getAddressUsageType();
							secondPartyAddressSourceType = partyAddressBObjInMap.getSourceIdentifierType();
							secondPartyAddressRetailerID = partyAddressBObjInMap.getXRetailerId();
							Timestamp party1AddrLastModifiedDt = DateFormatter.getTimestamp(partyAddressBObjInMap.getXLastModifiedSystemDate());
							Timestamp party2AddrLastModifiedDt = DateFormatter.getTimestamp(partyAddressBObj.getXLastModifiedSystemDate());
	
							if(firstPartyAddressSourceType.equalsIgnoreCase(secondPartyAddressSourceType))
							{
								if(party1AddrLastModifiedDt.after(party2AddrLastModifiedDt))
								{
									partyAddressMap.put(mapKey, partyAddressBObjInMap);
								}							
								else
								{
									partyAddressMap.put(mapKey, partyAddressBObj);
								}
								
							}
							else
							{
								String firstPartySourcePriority = getSourcePriorityForAddress(firstPartyAddressSourceType);
								String secondPartySourcePriority = getSourcePriorityForAddress(secondPartyAddressSourceType);
	
								if(firstPartySourcePriority.equalsIgnoreCase(secondPartySourcePriority))
								{
									if(party1AddrLastModifiedDt.after(party2AddrLastModifiedDt))
									{
										partyAddressMap.put(mapKey, partyAddressBObjInMap);
									}							
									else
									{
										partyAddressMap.put(mapKey, partyAddressBObj);
									}
								}
								else
								{
									if(Integer.parseInt(firstPartySourcePriority)>Integer.parseInt(secondPartySourcePriority))
									{
										partyAddressMap.put(mapKey, partyAddressBObjInMap);
									}
									else
									{
										partyAddressMap.put(mapKey, partyAddressBObj);
									}
								}
								
							}
						}
					}
					else if(StringUtils.isBlank(addressRetailerFlag) || ExternalRuleConstant.ADDRESS_RETAILER_FLAG_HRS_N.equalsIgnoreCase(addressRetailerFlag))
					{
	
						firstPartyAddressUsageType = partyAddressBObj.getAddressUsageType();
						firstPartyAddressSourceType = partyAddressBObj.getSourceIdentifierType();
						//July 01,2019 : Added by Sameeha for  normalized and unnormalized address survivorship: Start
						
						String addressUsageType = null;
						
						if(ExternalRuleConstant.HOME_MVP.equalsIgnoreCase(firstPartyAddressUsageType) ||
								ExternalRuleConstant.HOME_UNNORMALIZED_MVP.equalsIgnoreCase(firstPartyAddressUsageType))
							
							addressUsageType = ExternalRuleConstant.HOME_ADDRESS;
						
						else if(ExternalRuleConstant.BUSINESS_MVP.equalsIgnoreCase(firstPartyAddressUsageType) ||
								ExternalRuleConstant.BUSINESS_UNNORMALIZED_MVP.equalsIgnoreCase(firstPartyAddressUsageType))
							
							addressUsageType = ExternalRuleConstant.BUSINESS_ADDRESS;
						
						else if(ExternalRuleConstant.OTHERS1_MVP.equalsIgnoreCase(firstPartyAddressUsageType) ||
								ExternalRuleConstant.OTHERS1_UNNORMALIZED_MVP.equalsIgnoreCase(firstPartyAddressUsageType))
							
							addressUsageType = ExternalRuleConstant.OTHERS1_ADDRESS;
						
						else if(ExternalRuleConstant.OTHERS2_MVP.equalsIgnoreCase(firstPartyAddressUsageType) ||
								ExternalRuleConstant.OTHERS2_UNNORMALIZED_MVP.equalsIgnoreCase(firstPartyAddressUsageType))
							
							addressUsageType = ExternalRuleConstant.OTHERS2_ADDRESS;
						
						else if(ExternalRuleConstant.OTHERS3_MVP.equalsIgnoreCase(firstPartyAddressUsageType) ||
								ExternalRuleConstant.OTHERS3_UNNORMALIZED_MVP.equalsIgnoreCase(firstPartyAddressUsageType))
							
							addressUsageType = ExternalRuleConstant.OTHERS3_ADDRESS;
	
						mapKey = addressUsageType + partyAddressBObj.getXAddressRetailerFlag();
						
						//July 01,2019 : Added by Sameeha for  normalized and unnormalized address survivorship: End
	
						if(!partyAddressMap.containsKey(mapKey))
						{
							partyAddressMap.put(mapKey, partyAddressBObj);
						}
						else
						{
							XAddressGroupBObjExt partyAddressBObjInMap = partyAddressMap.get(mapKey);
							secondPartyAddressUsageType = partyAddressBObjInMap.getAddressUsageType();
							secondPartyAddressSourceType = partyAddressBObjInMap.getSourceIdentifierType();
							Timestamp party1AddrLastModifiedDt = DateFormatter.getTimestamp(partyAddressBObjInMap.getXLastModifiedSystemDate());
							Timestamp party2AddrLastModifiedDt = DateFormatter.getTimestamp(partyAddressBObj.getXLastModifiedSystemDate());
	
							if(firstPartyAddressSourceType.equalsIgnoreCase(secondPartyAddressSourceType))
							{
								if(party1AddrLastModifiedDt.after(party2AddrLastModifiedDt))
								{
									partyAddressMap.put(mapKey, partyAddressBObjInMap);
								}							
								else
								{
									partyAddressMap.put(mapKey, partyAddressBObj);
								}
	
							}
							else
							{
								String firstPartySourcePriority = getSourcePriorityForAddress(firstPartyAddressSourceType);
								String secondPartySourcePriority = getSourcePriorityForAddress(secondPartyAddressSourceType);
	
								if(firstPartySourcePriority.equalsIgnoreCase(secondPartySourcePriority))
								{
									if(party1AddrLastModifiedDt.after(party2AddrLastModifiedDt))
									{
										partyAddressMap.put(mapKey, partyAddressBObjInMap);
									}							
									else
									{
										partyAddressMap.put(mapKey, partyAddressBObj);
									}
								}
								else
								{
									if(Integer.parseInt(firstPartySourcePriority)>Integer.parseInt(secondPartySourcePriority))
									{
										partyAddressMap.put(mapKey, partyAddressBObj);
									}
									else
									{
										partyAddressMap.put(mapKey, partyAddressBObjInMap);
										}
									}
								}
							}
						}
					
					}
				}
			}
	}
	//Added by Sameeha for RT/Delta Address Survivorship , 18thJuly,19: End

	/**
	 * Method to survive Person Name Details
	 * @param control
	 * @param personNameMap
	 * @param vecTempPersonNameBOBj
	 * @throws Exception
	 */
	private static void survivePersonNameDetails(DWLControl control, HashMap<String, XPersonNameBObjExt> personNameMap, Vector<XPersonNameBObjExt> vecTempPersonNameBOBj) throws Exception {

		String firstPartyNameUsageType = null;
		String secondPartyNameUsageType = null;
		String firstSourceTypePersonName = null;
		String secondSourceTypePersonName = null;
		String firstPersonSourcePriorityNM = null;
		String secondPersonSourcePriorityNM = null;


		if(null!= vecTempPersonNameBOBj && vecTempPersonNameBOBj.size()>0)
		{
			for(int i=0; i<vecTempPersonNameBOBj.size(); i++)
			{
				XPersonNameBObjExt personnameBObj = (XPersonNameBObjExt) vecTempPersonNameBOBj.get(i);
				firstPartyNameUsageType = personnameBObj.getNameUsageType();
				firstSourceTypePersonName = personnameBObj.getSourceIdentifierType();
				firstPersonSourcePriorityNM = getSOurcePriorityForPersonName(firstSourceTypePersonName);

				if(!personNameMap.containsKey(firstPartyNameUsageType))
				{
					personNameMap.put(firstPartyNameUsageType, personnameBObj);
				}
				else
				{
					XPersonNameBObjExt nameBObjInMap = personNameMap.get(firstPartyNameUsageType);

					secondPartyNameUsageType = personnameBObj.getNameUsageType();
					secondSourceTypePersonName = nameBObjInMap.getSourceIdentifierType();
					secondPersonSourcePriorityNM = getSOurcePriorityForPersonName(secondSourceTypePersonName);

					Timestamp person1NameLastModifiedDate = DateFormatter.getTimestamp(nameBObjInMap.getXLastModifiedSystemDate());
					Timestamp person2NameLastModifiedDate = DateFormatter.getTimestamp(personnameBObj.getXLastModifiedSystemDate());

					if(firstSourceTypePersonName.equalsIgnoreCase(secondSourceTypePersonName))
					{
						if (person1NameLastModifiedDate.after(person2NameLastModifiedDate))
						{
							personNameMap.put(secondPartyNameUsageType,nameBObjInMap);
						}

						else
						{
							personNameMap.put(firstPartyNameUsageType,personnameBObj);
						}

					}
					else
					{
						if(firstPersonSourcePriorityNM.equalsIgnoreCase(secondPersonSourcePriorityNM))
						{
							if (person1NameLastModifiedDate.after(person2NameLastModifiedDate))
							{
								personNameMap.put(secondPartyNameUsageType,nameBObjInMap);
							}

							else
							{
								personNameMap.put(firstPartyNameUsageType,personnameBObj);
							}
						}
						else
						{
							if(Integer.parseInt(firstPersonSourcePriorityNM)>Integer.parseInt(secondPersonSourcePriorityNM))
							{
								personNameMap.put(firstPartyNameUsageType, personnameBObj);
							}
							else
							{
								personNameMap.put(secondPartyNameUsageType, nameBObjInMap);
							}
						}

					}
				}
			}
		}		
	}

	/**
	 * Method to get Source Priority for Person Name 
	 * @param sourceSystemType
	 * @return
	 * @throws Exception
	 */
	public static String getSOurcePriorityForPersonName (String sourceSystemType) throws Exception {

		String sourcePriority = null;

		if(StringUtils.isNonBlank(sourceSystemType))
		{
			if(ExternalRuleConstant.SOURCE_SYSTEM_TYPE_SFDC_HRS.equalsIgnoreCase(sourceSystemType) || 
			   ExternalRuleConstant.SOURCE_SYSTEM_TYPE_AUTOLINE_HRS.equalsIgnoreCase(sourceSystemType))
			{
				sourcePriority = ExternalRuleConstant.SOURCE_PRIORITY_HRS_2;
			}
			else if(ExternalRuleConstant.SOURCE_SYSTEM_TYPE_TDS_HRS.equalsIgnoreCase(sourceSystemType))
			{
				sourcePriority = ExternalRuleConstant.SOURCE_PRIORITY_HRS_1;				
			}
			else
			{
				//Hard Coded 
				sourcePriority = ExternalRuleConstant.SOURCE_PRIORITY_HRS_1;
			}
		}
		return sourcePriority;		
	}
	
	public static String getSourcePriority (String componentType, String sourceSystemType) throws Exception {

		String sourcePriority = null;

		if(StringUtils.isNonBlank(sourceSystemType))
		{
			if(ExternalRuleConstant.SOURCE_SYSTEM_TYPE_SFDC_HRS.equalsIgnoreCase(sourceSystemType) || 
			   ExternalRuleConstant.SOURCE_SYSTEM_TYPE_AUTOLINE_HRS.equalsIgnoreCase(sourceSystemType))
			{
				sourcePriority = ExternalRuleConstant.SOURCE_PRIORITY_HRS_2;
			}
			else if(ExternalRuleConstant.SOURCE_SYSTEM_TYPE_TDS_HRS.equalsIgnoreCase(sourceSystemType))
			{
				sourcePriority = ExternalRuleConstant.SOURCE_PRIORITY_HRS_1;				
			}
			else
			{
				//Hard Coded 
				sourcePriority = ExternalRuleConstant.SOURCE_PRIORITY_HRS_1;
			}
		}
		return sourcePriority;		
	}
	
	private static void surviveGenderOccupation(DWLControl control,XPersonBObjExt survivedBOBj, Vector<TCRMPartyBObj> vecAllParty) {
		try{
			String firstSourceType = null;
			String firstPartyPriority = null;
			String secondSourceType = null;
			String secondPartyPriority = null;
			Timestamp latestCreatedDt = DateFormatter.getTimestamp(survivedBOBj.getXLastModifiedSystemDate());
			firstSourceType = survivedBOBj.getSourceIdentifierType();
			firstPartyPriority = getSourcePriorityForGenderOccupation(ExternalRuleConstant.GENDER_HRS, firstSourceType);
			Timestamp tempCreatedDt = null;
			
			for(TCRMPartyBObj partyBObj : vecAllParty){
				XPersonBObjExt personBObj = (XPersonBObjExt) partyBObj;
				if(!personBObj.getPartyId().equals(survivedBOBj.getPartyId())){
					
					///Gender
					if(survivedBOBj.getGenderType() == null ){
						if(personBObj.getGenderType() != null){
							survivedBOBj.setGenderType(personBObj.getGenderType());
						}
					}else{
						if(personBObj.getGenderType()!=null){
							secondSourceType = personBObj.getSourceIdentifierType();
							secondPartyPriority = getSourcePriorityForGenderOccupation(ExternalRuleConstant.GENDER_HRS, secondSourceType);
							if(Integer.parseInt(firstPartyPriority) > Integer.parseInt(secondPartyPriority)){
								survivedBOBj.setGenderType(personBObj.getGenderType());
							}
							else if (Integer.parseInt(firstPartyPriority) < Integer.parseInt(secondPartyPriority)){
								survivedBOBj.setGenderType(personBObj.getGenderType());
							}
						}
					}
					//Occupation
					if(survivedBOBj.getXOccupationType() == null ){
						if(personBObj.getXOccupationType() != null){
							survivedBOBj.setXOccupationType(personBObj.getXOccupationType());
						}
					}else{
						if(personBObj.getXOccupationType()!=null){
							secondSourceType = personBObj.getSourceIdentifierType();
							secondPartyPriority = getSourcePriorityForGenderOccupation(ExternalRuleConstant.OCCUPATION_HRS, secondSourceType);
							if(Integer.parseInt(firstPartyPriority) > Integer.parseInt(secondPartyPriority)){
								survivedBOBj.setXOccupationType(personBObj.getXOccupationType());
							}
							else if (Integer.parseInt(firstPartyPriority) < Integer.parseInt(secondPartyPriority)){
								survivedBOBj.setXOccupationType(personBObj.getXOccupationType());
							}
						}
					}
				}
			}
		}catch(Exception e){
			
		}
	}
	public static String getSourcePriorityForGenderOccupation (String componentType, String sourceSystemType) throws Exception {

		String sourcePriority = null;
		

		if(StringUtils.isNonBlank(sourceSystemType))
		{
			if(ExternalRuleConstant.SOURCE_SYSTEM_TYPE_SFDC_HRS.equalsIgnoreCase(sourceSystemType))
			{
				sourcePriority = ExternalRuleConstant.SOURCE_PRIORITY_HRS_2;
			}
			else if(ExternalRuleConstant.SOURCE_SYSTEM_TYPE_AUTOLINE_HRS.equalsIgnoreCase(sourceSystemType))
			{
				sourcePriority = ExternalRuleConstant.SOURCE_PRIORITY_HRS_1;				
			}
			/*else
			{
				return sourcePriority;
			}*/
		}
			return sourcePriority;		
	}


	/**
	 * Method to survive Identifier details
	 * @param control
	 * @param partyIdentMap
	 * @param vecTempPartyIdentificationBObj
	 * @throws Exception
	 */
	private static void surviveIdentifierDetails(DWLControl control, HashMap<String, XIdentifierBObjExt> partyIdentMap, Vector<XIdentifierBObjExt> vecPartyIdentificationBObj) throws Exception {

		String firstPartyIdentificationType = null;
		String firstIDSourcePriority = null;
		String secondIDSourcePriority = null;
		String mapKey = null;

		XIdentifierBObjExt xIdenBObj = null;

		if(null!= vecPartyIdentificationBObj && vecPartyIdentificationBObj.size()>0){
			for(XIdentifierBObjExt identifierBObj : vecPartyIdentificationBObj){
				//Vat No and Commercial Reg ID
				firstPartyIdentificationType = identifierBObj.getIdentificationType();
				mapKey = firstPartyIdentificationType;
				if(!partyIdentMap.containsKey(firstPartyIdentificationType)){
					partyIdentMap.put(firstPartyIdentificationType,identifierBObj);
				}else{
					XIdentifierBObjExt identifierBObjInMap = partyIdentMap.get(firstPartyIdentificationType);
					firstIDSourcePriority = getSourcePriority(ExternalRuleConstant.COMPONENT_TYPE_IDENTIFIER_HRS,identifierBObj.getSourceIdentifierType());
					secondIDSourcePriority = getSourcePriority(ExternalRuleConstant.COMPONENT_TYPE_IDENTIFIER_HRS,identifierBObjInMap.getSourceIdentifierType());

					Timestamp person1IDLastModifiedDate = DateFormatter.getTimestamp(identifierBObj.getXLastModifiedSystemDate());
					Timestamp person2IDLastModifiedDate = DateFormatter.getTimestamp(identifierBObjInMap.getXLastModifiedSystemDate());
					
					if(firstIDSourcePriority.equals(secondIDSourcePriority) ){
						//Same source priority
						if(firstIDSourcePriority.equalsIgnoreCase(secondIDSourcePriority)){
							if(person1IDLastModifiedDate.after(person2IDLastModifiedDate)){
								partyIdentMap.put(mapKey, identifierBObj);
							}else{
								partyIdentMap.put(mapKey, identifierBObjInMap);
							}
						}
						//Different source priority
						else if(Integer.parseInt(firstIDSourcePriority) < Integer.parseInt(secondIDSourcePriority)){
							partyIdentMap.put(mapKey, identifierBObj);
						}else if(Integer.parseInt(firstIDSourcePriority) > Integer.parseInt(secondIDSourcePriority)){
							partyIdentMap.put(mapKey, identifierBObjInMap);
						}		
					}
				}				
			}
		}
	}
	/**
	 * Method to get source priority for Social Id
	 * @param sourceSystemType
	 * @return
	 * @throws Exception
	 */
	public static String getSourcePriorityForSocialId (String sourceSystemType) throws Exception {

		String sourcePriority = null;

		if(StringUtils.isNonBlank(sourceSystemType))
		{
			if(ExternalRuleConstant.SOURCE_SYSTEM_TYPE_SFDC_HRS.equalsIgnoreCase(sourceSystemType))
			{
				sourcePriority = ExternalRuleConstant.SOURCE_PRIORITY_HRS_2;
			}
			else if(ExternalRuleConstant.SOURCE_SYSTEM_TYPE_AUTOLINE_HRS.equalsIgnoreCase(sourceSystemType))
			{
				sourcePriority = ExternalRuleConstant.SOURCE_PRIORITY_HRS_2;				
			}
			/*else
			{
				//Hard Coded 
				sourcePriority = ExternalRuleConstant.SOURCE_PRIORITY_HRS_2;
			}*/
		}
		return sourcePriority;		
	}
	
	public static String getSourcePriorityForVatNo (String sourceSystemType) throws Exception {

		String sourcePriority = null;

		if(StringUtils.isNonBlank(sourceSystemType))
		{
			if(ExternalRuleConstant.SOURCE_SYSTEM_TYPE_SFDC_HRS.equalsIgnoreCase(sourceSystemType))
			{
				sourcePriority = ExternalRuleConstant.SOURCE_PRIORITY_HRS_2;
			}
			else if(ExternalRuleConstant.SOURCE_SYSTEM_TYPE_AUTOLINE_HRS.equalsIgnoreCase(sourceSystemType))
			{
				sourcePriority = ExternalRuleConstant.SOURCE_PRIORITY_HRS_1;				
			}
			/*else
			{
				//Hard Coded 
				sourcePriority = ExternalRuleConstant.SOURCE_PRIORITY_HRS_2;
			}*/
		}
		return sourcePriority;		
	}

	/**
	 * Method to survive party address details
	 * @param control
	 * @param partyAddressMap
	 * @param vecTempPartyAddressBObj
	 * @throws Exception
	 */
	private static void surviveAddressDetailsInit(DWLControl control, HashMap<String, XAddressGroupBObjExt> partyAddressMap, Vector vecAllParty) throws Exception {
		

		HashMap<String, Vector<XAddressGroupBObjExt>> retailerAddressMap = new HashMap<String, Vector<XAddressGroupBObjExt>>();

		Vector<XAddressGroupBObjExt> vecRetailerPartyAddressBObj = new Vector<XAddressGroupBObjExt>();
		
		Vector<XAddressGroupBObjExt> vecWSPartyAddressBObj = new Vector<XAddressGroupBObjExt>();
		
		Vector<XAddressGroupBObjExt> vecFinalWSPartyAddressBObj = new Vector<XAddressGroupBObjExt>();

		Vector<XAddressGroupBObjExt> vecHomePartyAddressBObj = new Vector<XAddressGroupBObjExt>();

		Vector<XAddressGroupBObjExt> vecOth1PartyAddressBObj = new Vector<XAddressGroupBObjExt>();

		Vector<XAddressGroupBObjExt> vecOth2PartyAddressBObj = new Vector<XAddressGroupBObjExt>();

		Vector<XAddressGroupBObjExt> vecOth3PartyAddressBObj = new Vector<XAddressGroupBObjExt>();
		
		Vector<XAddressGroupBObjExt> vecBusinessPartyAddressBObj = new Vector<XAddressGroupBObjExt>();
		
		Vector<XAddressGroupBObjExt> vecTempPartyAddressBObj = new Vector<XAddressGroupBObjExt>();
	
		Set<String> wsAddressUsageTpSet = new HashSet<String>();
		
		String mapKey = null;
		
		// Get all Party Addresses of suspects
		for (int i = 0; i < vecAllParty.size(); i++) {
			
			TCRMPartyBObj party = (TCRMPartyBObj) vecAllParty.get(i);
			
			if(ExternalRuleConstant.PERSON_ORG_CODE_P.equalsIgnoreCase(party.getPartyType())){
				
				XPersonBObjExt tempPersonBObj = (XPersonBObjExt) vecAllParty.get(i);
	
				vecTempPartyAddressBObj = tempPersonBObj.getItemsTCRMPartyAddressBObj();
	
			}
			else if(ExternalRuleConstant.PERSON_ORG_CODE_O.equalsIgnoreCase(party.getPartyType())){
				
				XOrgBObjExt tempOrgBObj = (XOrgBObjExt) vecAllParty.get(i);
	
				vecTempPartyAddressBObj = tempOrgBObj.getItemsTCRMPartyAddressBObj();
	
			}
	
	
				for (XAddressGroupBObjExt tempAddrBObj : vecTempPartyAddressBObj) {
					
						if (tempAddrBObj.getAddressUsageType().equals(ExternalRuleConstant.HOME_MVP)
								&& tempAddrBObj.getXAddressRetailerFlag().equalsIgnoreCase(ExternalRuleConstant.ADDRESS_RETAILER_FLAG_N)) {
							
							vecFinalWSPartyAddressBObj.add(tempAddrBObj);
							wsAddressUsageTpSet.add(ExternalRuleConstant.HOME_MVP);
							
							vecHomePartyAddressBObj.add(tempAddrBObj);
							
						} else if (tempAddrBObj.getAddressUsageType().equals(ExternalRuleConstant.BUSINESS_MVP)
								&& tempAddrBObj.getXAddressRetailerFlag().equalsIgnoreCase(ExternalRuleConstant.ADDRESS_RETAILER_FLAG_N)) {
							
							vecFinalWSPartyAddressBObj.add(tempAddrBObj);
							wsAddressUsageTpSet.add(ExternalRuleConstant.BUSINESS_MVP);
							vecBusinessPartyAddressBObj.add(tempAddrBObj);
		
						} 
						else if (tempAddrBObj.getAddressUsageType().equals(ExternalRuleConstant.OTHERS1_MVP)
								&& tempAddrBObj.getXAddressRetailerFlag().equalsIgnoreCase(ExternalRuleConstant.ADDRESS_RETAILER_FLAG_N)) {
							
							vecFinalWSPartyAddressBObj.add(tempAddrBObj);
							wsAddressUsageTpSet.add(ExternalRuleConstant.OTHERS1_MVP);
							vecOth1PartyAddressBObj.add(tempAddrBObj);
		
						}else if (tempAddrBObj.getAddressUsageType().equals(ExternalRuleConstant.OTHERS2_MVP)
								&& tempAddrBObj.getXAddressRetailerFlag().equalsIgnoreCase(ExternalRuleConstant.ADDRESS_RETAILER_FLAG_N)) {
							
							vecFinalWSPartyAddressBObj.add(tempAddrBObj);
							wsAddressUsageTpSet.add(ExternalRuleConstant.OTHERS2_MVP);
							vecOth2PartyAddressBObj.add(tempAddrBObj);
		
						} else if (tempAddrBObj.getAddressUsageType().equals(ExternalRuleConstant.OTHERS3_MVP)
								&& tempAddrBObj.getXAddressRetailerFlag().equalsIgnoreCase(ExternalRuleConstant.ADDRESS_RETAILER_FLAG_N)) {
							
							vecFinalWSPartyAddressBObj.add(tempAddrBObj);
							wsAddressUsageTpSet.add(ExternalRuleConstant.OTHERS3_MVP);
							vecOth3PartyAddressBObj.add(tempAddrBObj);
		
						} else if (tempAddrBObj.getXAddressRetailerFlag().equalsIgnoreCase(ExternalRuleConstant.ADDRESS_RETAILER_FLAG_Y)) {
		
							retailerAddressMap.put(tempAddrBObj.getXRetailerId(), null);
		
							vecRetailerPartyAddressBObj.add(tempAddrBObj);
		
						} 
						
					}
				}
		
		// For Each Retailer

		Set<String> keySet = new HashSet<String>();

		keySet.addAll(retailerAddressMap.keySet());

		Vector<XAddressGroupBObjExt> tempRetAddrBObj;

		for (int i = 0; i < vecRetailerPartyAddressBObj.size(); i++) {

			tempRetAddrBObj = new Vector<XAddressGroupBObjExt>();

			XAddressGroupBObjExt tempAddrGroupBObj = vecRetailerPartyAddressBObj.elementAt(i);

			String retailerId = tempAddrGroupBObj.getXRetailerId();

			if (retailerAddressMap.get(retailerId) != null) {

				tempRetAddrBObj.addAll(retailerAddressMap.get(retailerId));

			}

			tempRetAddrBObj.add(tempAddrGroupBObj);

			retailerAddressMap.put(retailerId, tempRetAddrBObj);
			// tempRetAddrBObj.removeAllElements();

		}

		vecRetailerPartyAddressBObj.removeAllElements();

		for (String key : keySet) {

			vecRetailerPartyAddressBObj.addAll(retailerAddressMap.get(key));

			for (int i = 0; i < vecRetailerPartyAddressBObj.size(); i++) {

				XAddressGroupBObjExt tempAddrGroupBObj = vecRetailerPartyAddressBObj.elementAt(i);

				mapKey =  tempAddrGroupBObj.getXRetailerId() + tempAddrGroupBObj.getXAddressRetailerFlag();

				if (!(partyAddressMap.containsKey(mapKey))) {

					partyAddressMap.put(mapKey, tempAddrGroupBObj);

				}else{
					
					XAddressGroupBObjExt retailerAddressBObjInMap = partyAddressMap.get(mapKey);
					
					Timestamp party1CreatedDt = DateFormatter.getTimestamp(tempAddrGroupBObj.getXLastModifiedSystemDate());

					Timestamp party2CreatedDt = DateFormatter.getTimestamp(retailerAddressBObjInMap.getXLastModifiedSystemDate());
					
					if(party1CreatedDt.after(party2CreatedDt)){
						
						partyAddressMap.put(mapKey, tempAddrGroupBObj);
						
					}else{
						
						partyAddressMap.put(mapKey, retailerAddressBObjInMap);
						
					}
				}
			}
			
			vecRetailerPartyAddressBObj.removeAllElements();
			

		}
		
		
			// for wholesale
			// Sort Vectors by LastModifiedDate
	
			sortPartyAddresses(vecHomePartyAddressBObj, null, control);
			
			sortPartyAddresses(vecBusinessPartyAddressBObj, null, control);
	
			sortPartyAddresses(vecOth1PartyAddressBObj, null, control);
	
			sortPartyAddresses(vecOth2PartyAddressBObj, null, control);
	
			sortPartyAddresses(vecOth3PartyAddressBObj, null, control);
	
			//for Person Data
			if (vecBusinessPartyAddressBObj.size() == 0){
				// If only one party has address
				if(wsAddressUsageTpSet.contains(ExternalRuleConstant.HOME_MVP)
						&& vecHomePartyAddressBObj.size() == 1) {
					
					XAddressGroupBObjExt tempAddressGroupBObj = null;
					//survive home address
					tempAddressGroupBObj = vecHomePartyAddressBObj.elementAt(0);					
					surviveAddress(partyAddressMap, tempAddressGroupBObj);
					
					if(vecOth1PartyAddressBObj.size() != 0 ){
						tempAddressGroupBObj = vecOth1PartyAddressBObj.elementAt(0);					
						surviveAddress(partyAddressMap, tempAddressGroupBObj);
					}
					if(vecOth2PartyAddressBObj.size() != 0 ){
						tempAddressGroupBObj = vecOth2PartyAddressBObj.elementAt(0);					
						surviveAddress(partyAddressMap, tempAddressGroupBObj);
					}
					if(vecOth3PartyAddressBObj.size() != 0 ){
						tempAddressGroupBObj = vecOth3PartyAddressBObj.elementAt(0);					
						surviveAddress(partyAddressMap, tempAddressGroupBObj);
					}
				}
			
			
				//If Any of the suspects has Other 3 Address, Keep the latest address in each Address Usage Type
				 else if(wsAddressUsageTpSet.contains(ExternalRuleConstant.OTHERS3_MVP)){
					 
					XAddressGroupBObjExt tempAddressGroupBObj = null;
					//Survive Latest Home Address
					tempAddressGroupBObj = vecHomePartyAddressBObj.elementAt(0);					
					surviveAddress(partyAddressMap, tempAddressGroupBObj);
										
					//Survive Latest Other 1 Address
					tempAddressGroupBObj = vecOth1PartyAddressBObj.elementAt(0);
					surviveAddress(partyAddressMap, tempAddressGroupBObj);
					
					//Survive Latest Other 2 Address
					tempAddressGroupBObj = vecOth2PartyAddressBObj.elementAt(0);
					surviveAddress(partyAddressMap, tempAddressGroupBObj);
					
					//Survive Latest Other 3 Address
					tempAddressGroupBObj = vecOth3PartyAddressBObj.elementAt(0);
					surviveAddress(partyAddressMap, tempAddressGroupBObj);
			
					
				}
			
			//If Any of the suspects has Other 2 Address,Add latest Home address To Home
			//Survive latest for Oth 1 and second latest for Oth2
			
			else if(!wsAddressUsageTpSet.contains(ExternalRuleConstant.OTHERS3_MVP) &&
					wsAddressUsageTpSet.contains(ExternalRuleConstant.OTHERS2_MVP)){
				XAddressGroupBObjExt tempAddressGroupBObj = null;
				
				//Survive latest Home address for Home					
				tempAddressGroupBObj = vecHomePartyAddressBObj.elementAt(0);
				surviveAddress(partyAddressMap, tempAddressGroupBObj);
				
				//Survive Latest Other 1 Address
				tempAddressGroupBObj = vecOth1PartyAddressBObj.elementAt(0);
				surviveAddress(partyAddressMap, tempAddressGroupBObj);
				
				//Survive Latest Other 2 Address
				tempAddressGroupBObj = vecOth2PartyAddressBObj.elementAt(0);
				surviveAddress(partyAddressMap, tempAddressGroupBObj);
				
				//Survive second Latest Home as Other 3 Address
				tempAddressGroupBObj = vecHomePartyAddressBObj.elementAt(1);
				tempAddressGroupBObj.setAddressUsageType(ExternalRuleConstant.OTHERS3_MVP);
				tempAddressGroupBObj.setAddressUsageValue(ExternalRuleConstant.OTHERS3_MVP_VALUE);
				surviveAddress(partyAddressMap, tempAddressGroupBObj);					
				}
				
			else  if(!wsAddressUsageTpSet.contains(ExternalRuleConstant.OTHERS3_MVP) &&
					!wsAddressUsageTpSet.contains(ExternalRuleConstant.OTHERS2_MVP) &&
					wsAddressUsageTpSet.contains(ExternalRuleConstant.OTHERS1_MVP)){
				XAddressGroupBObjExt oth1AddressGroupBObj = null;
				XAddressGroupBObjExt oth2AddressGroupBObj = null;
				XAddressGroupBObjExt oth3AddressGroupBObj = null;
				XAddressGroupBObjExt homeAddressGroupBObj = null;
				
				//Survive Latest Other 1 Address
				oth1AddressGroupBObj = vecOth1PartyAddressBObj.elementAt(0);
				surviveAddress(partyAddressMap, oth1AddressGroupBObj);
				
				//If count of home adress is only 2
				if(vecHomePartyAddressBObj.size() == 2){
					//Second Latest Home in Other 2
					oth2AddressGroupBObj = vecHomePartyAddressBObj.elementAt(1);
					oth2AddressGroupBObj.setAddressUsageType(ExternalRuleConstant.OTHERS2_MVP);
					oth2AddressGroupBObj.setAddressUsageValue(ExternalRuleConstant.OTHERS2_MVP_VALUE);						
					surviveAddress(partyAddressMap,oth2AddressGroupBObj);
					
					// Latest home in home
					homeAddressGroupBObj = vecHomePartyAddressBObj.elementAt(0);
					surviveAddress(partyAddressMap,homeAddressGroupBObj);
					
				}
				//If count of home adress is more than 2
				else if(vecHomePartyAddressBObj.size() >2){
					//Third Latest Home in Other 3
					oth3AddressGroupBObj = vecHomePartyAddressBObj.elementAt(2);
					oth3AddressGroupBObj.setAddressUsageType(ExternalRuleConstant.OTHERS3_MVP);
					oth3AddressGroupBObj.setAddressUsageValue(ExternalRuleConstant.OTHERS3_MVP_VALUE);
					surviveAddress(partyAddressMap,oth3AddressGroupBObj);
					
					//Second latest in Other 2
					oth2AddressGroupBObj = vecHomePartyAddressBObj.elementAt(1);
					oth2AddressGroupBObj.setAddressUsageType(ExternalRuleConstant.OTHERS2_MVP);
					oth2AddressGroupBObj.setAddressUsageValue(ExternalRuleConstant.OTHERS2_MVP_VALUE);						
					surviveAddress(partyAddressMap,oth2AddressGroupBObj);
					
					//latest in Home
					homeAddressGroupBObj = vecHomePartyAddressBObj.elementAt(0);
					surviveAddress(partyAddressMap,homeAddressGroupBObj);						
				}				
				
			}else  if(!wsAddressUsageTpSet.contains(ExternalRuleConstant.OTHERS3_MVP) &&
					!wsAddressUsageTpSet.contains(ExternalRuleConstant.OTHERS2_MVP) &&
					!wsAddressUsageTpSet.contains(ExternalRuleConstant.OTHERS1_MVP) &&
					wsAddressUsageTpSet.contains(ExternalRuleConstant.HOME_MVP)){
				
				//If only home addresses are present
				
				XAddressGroupBObjExt oth1AddressGroupBObj = null;
				XAddressGroupBObjExt oth2AddressGroupBObj = null;
				XAddressGroupBObjExt oth3AddressGroupBObj = null;
				XAddressGroupBObjExt homeAddressGroupBObj = null;
				
				if(vecHomePartyAddressBObj.size() ==2){
					//If Home Address count is 2
					
					//Second Latest Home in Other 1
					oth1AddressGroupBObj = vecHomePartyAddressBObj.elementAt(1);
					oth1AddressGroupBObj.setAddressUsageType(ExternalRuleConstant.OTHERS1_MVP);
					oth1AddressGroupBObj.setAddressUsageValue(ExternalRuleConstant.OTHERS1_MVP_VALUE);						
					surviveAddress(partyAddressMap,oth1AddressGroupBObj);
					
					//Latest in home
					homeAddressGroupBObj = vecHomePartyAddressBObj.elementAt(0);
					surviveAddress(partyAddressMap,homeAddressGroupBObj);
					
				}else if(vecHomePartyAddressBObj.size() ==3){						
					//If Home Address count is 3
					
					//Third Latest Home in Other 2
					oth2AddressGroupBObj = vecHomePartyAddressBObj.elementAt(2);
					oth2AddressGroupBObj.setAddressUsageType(ExternalRuleConstant.OTHERS2_MVP);
					oth2AddressGroupBObj.setAddressUsageValue(ExternalRuleConstant.OTHERS2_MVP_VALUE);						
					surviveAddress(partyAddressMap,oth2AddressGroupBObj);
					
					//Second Latest in Other 1
					oth1AddressGroupBObj = vecHomePartyAddressBObj.elementAt(1);
					oth1AddressGroupBObj.setAddressUsageType(ExternalRuleConstant.OTHERS1_MVP);
					oth1AddressGroupBObj.setAddressUsageValue(ExternalRuleConstant.OTHERS1_MVP_VALUE);						
					surviveAddress(partyAddressMap,oth1AddressGroupBObj);
					
					
					// Latest in Home
					homeAddressGroupBObj = vecHomePartyAddressBObj.elementAt(0);
					surviveAddress(partyAddressMap,homeAddressGroupBObj);
					
				
					
				}else if (vecHomePartyAddressBObj.size() > 3){
					//If Home Address count > 3
					
					//Fourth Latest Home in Other 3
					oth3AddressGroupBObj = vecHomePartyAddressBObj.elementAt(3);
					oth3AddressGroupBObj.setAddressUsageType(ExternalRuleConstant.OTHERS3_MVP);
					oth3AddressGroupBObj.setAddressUsageValue(ExternalRuleConstant.OTHERS3_MVP_VALUE);						
					surviveAddress(partyAddressMap,oth3AddressGroupBObj);
					
					// Third Latest in Other 2
					oth2AddressGroupBObj = vecHomePartyAddressBObj.elementAt(2);
					oth2AddressGroupBObj.setAddressUsageType(ExternalRuleConstant.OTHERS2_MVP);
					oth2AddressGroupBObj.setAddressUsageValue(ExternalRuleConstant.OTHERS2_MVP_VALUE);						
					surviveAddress(partyAddressMap,oth2AddressGroupBObj);
					
					// Second Latest in Other 1
					oth1AddressGroupBObj = vecHomePartyAddressBObj.elementAt(1);
					oth1AddressGroupBObj.setAddressUsageType(ExternalRuleConstant.OTHERS1_MVP);
					oth1AddressGroupBObj.setAddressUsageValue(ExternalRuleConstant.OTHERS1_MVP_VALUE);						
					surviveAddress(partyAddressMap,oth1AddressGroupBObj);
					
					
					// Latest in Home
					homeAddressGroupBObj = vecHomePartyAddressBObj.elementAt(0);
					surviveAddress(partyAddressMap,homeAddressGroupBObj);
					}
				}
			}
			//For Organization
			else{
				// If only one party has address
				if(wsAddressUsageTpSet.contains(ExternalRuleConstant.BUSINESS_MVP)
						&& vecBusinessPartyAddressBObj.size() == 1) {
					
					XAddressGroupBObjExt tempAddressGroupBObj = null;
					//survive business address
					tempAddressGroupBObj = vecBusinessPartyAddressBObj.elementAt(0);					
					surviveAddress(partyAddressMap, tempAddressGroupBObj);
					
					if(vecOth1PartyAddressBObj.size() != 0 ){
						tempAddressGroupBObj = vecOth1PartyAddressBObj.elementAt(0);					
						surviveAddress(partyAddressMap, tempAddressGroupBObj);
					}
					if(vecOth2PartyAddressBObj.size() != 0 ){
						tempAddressGroupBObj = vecOth2PartyAddressBObj.elementAt(0);					
						surviveAddress(partyAddressMap, tempAddressGroupBObj);
					}
					if(vecOth3PartyAddressBObj.size() != 0 ){
						tempAddressGroupBObj = vecOth3PartyAddressBObj.elementAt(0);					
						surviveAddress(partyAddressMap, tempAddressGroupBObj);
					}
				}
			
			
				//If Any of the suspects has Other 3 Address, Keep the latest address in each Address Usage Type
				 else if(wsAddressUsageTpSet.contains(ExternalRuleConstant.OTHERS3_MVP)){
					 
					XAddressGroupBObjExt tempAddressGroupBObj = null;
					//Survive Latest business Address
					tempAddressGroupBObj = vecBusinessPartyAddressBObj.elementAt(0);					
					surviveAddress(partyAddressMap, tempAddressGroupBObj);
										
					//Survive Latest Other 1 Address
					tempAddressGroupBObj = vecOth1PartyAddressBObj.elementAt(0);
					surviveAddress(partyAddressMap, tempAddressGroupBObj);
					
					//Survive Latest Other 2 Address
					tempAddressGroupBObj = vecOth2PartyAddressBObj.elementAt(0);
					surviveAddress(partyAddressMap, tempAddressGroupBObj);
					
					//Survive Latest Other 3 Address
					tempAddressGroupBObj = vecOth3PartyAddressBObj.elementAt(0);
					surviveAddress(partyAddressMap, tempAddressGroupBObj);
			
					
				}
			
			//If Any of the suspects has Other 2 Address,Add latest business address To business
			//Survive latest for Oth 1 and second latest for Oth2
			
			else if(!wsAddressUsageTpSet.contains(ExternalRuleConstant.OTHERS3_MVP) &&
					wsAddressUsageTpSet.contains(ExternalRuleConstant.OTHERS2_MVP)){
				XAddressGroupBObjExt tempAddressGroupBObj = null;
				
				//Survive latest business address for business					
				tempAddressGroupBObj = vecBusinessPartyAddressBObj.elementAt(0);
				surviveAddress(partyAddressMap, tempAddressGroupBObj);
				
				//Survive Latest Other 1 Address
				tempAddressGroupBObj = vecOth1PartyAddressBObj.elementAt(0);
				surviveAddress(partyAddressMap, tempAddressGroupBObj);
				
				//Survive Latest Other 2 Address
				tempAddressGroupBObj = vecOth2PartyAddressBObj.elementAt(0);
				surviveAddress(partyAddressMap, tempAddressGroupBObj);
				
				//Survive second Latest business as Other 3 Address
				tempAddressGroupBObj = vecBusinessPartyAddressBObj.elementAt(1);
				tempAddressGroupBObj.setAddressUsageType(ExternalRuleConstant.OTHERS3_MVP);
				tempAddressGroupBObj.setAddressUsageValue(ExternalRuleConstant.OTHERS3_MVP_VALUE);
				surviveAddress(partyAddressMap, tempAddressGroupBObj);					
				}
				
			else  if(!wsAddressUsageTpSet.contains(ExternalRuleConstant.OTHERS3_MVP) &&
					!wsAddressUsageTpSet.contains(ExternalRuleConstant.OTHERS2_MVP) &&
					wsAddressUsageTpSet.contains(ExternalRuleConstant.OTHERS1_MVP)){
				XAddressGroupBObjExt oth1AddressGroupBObj = null;
				XAddressGroupBObjExt oth2AddressGroupBObj = null;
				XAddressGroupBObjExt oth3AddressGroupBObj = null;
				XAddressGroupBObjExt businessAddressGroupBObj = null;
				
				//Survive Latest Other 1 Address
				oth1AddressGroupBObj = vecOth1PartyAddressBObj.elementAt(0);
				surviveAddress(partyAddressMap, oth1AddressGroupBObj);
				
				//If count of business address is only 2
				if(vecBusinessPartyAddressBObj.size() == 2){
					//Second Latest business in Other 2
					oth2AddressGroupBObj = vecBusinessPartyAddressBObj.elementAt(1);
					oth2AddressGroupBObj.setAddressUsageType(ExternalRuleConstant.OTHERS2_MVP);
					oth2AddressGroupBObj.setAddressUsageValue(ExternalRuleConstant.OTHERS2_MVP_VALUE);						
					surviveAddress(partyAddressMap,oth2AddressGroupBObj);
					
					// Latest business in business
					businessAddressGroupBObj = vecBusinessPartyAddressBObj.elementAt(0);
					surviveAddress(partyAddressMap,businessAddressGroupBObj);
					
				}
				//If count of business address is more than 2
				else if(vecBusinessPartyAddressBObj.size() >2){
					//Third Latest business in Other 3
					oth3AddressGroupBObj = vecBusinessPartyAddressBObj.elementAt(2);
					oth3AddressGroupBObj.setAddressUsageType(ExternalRuleConstant.OTHERS3_MVP);
					oth3AddressGroupBObj.setAddressUsageValue(ExternalRuleConstant.OTHERS3_MVP_VALUE);
					surviveAddress(partyAddressMap,oth3AddressGroupBObj);
					
					//Second latest in Other 2
					oth2AddressGroupBObj = vecBusinessPartyAddressBObj.elementAt(1);
					oth2AddressGroupBObj.setAddressUsageType(ExternalRuleConstant.OTHERS2_MVP);
					oth2AddressGroupBObj.setAddressUsageValue(ExternalRuleConstant.OTHERS2_MVP_VALUE);						
					surviveAddress(partyAddressMap,oth2AddressGroupBObj);
					
					//latest in business
					businessAddressGroupBObj = vecBusinessPartyAddressBObj.elementAt(0);
					surviveAddress(partyAddressMap,businessAddressGroupBObj);						
				}				
				
			}else  if(!wsAddressUsageTpSet.contains(ExternalRuleConstant.OTHERS3_MVP) &&
					!wsAddressUsageTpSet.contains(ExternalRuleConstant.OTHERS2_MVP) &&
					!wsAddressUsageTpSet.contains(ExternalRuleConstant.OTHERS1_MVP) &&
					wsAddressUsageTpSet.contains(ExternalRuleConstant.BUSINESS_MVP)){
				
				//If only business addresses are present
				
				XAddressGroupBObjExt oth1AddressGroupBObj = null;
				XAddressGroupBObjExt oth2AddressGroupBObj = null;
				XAddressGroupBObjExt oth3AddressGroupBObj = null;
				XAddressGroupBObjExt businessAddressGroupBObj = null;
				
				if(vecBusinessPartyAddressBObj.size() ==2){
					//If business Address count is 2
					
					//Second Latest business in Other 1
					oth1AddressGroupBObj = vecBusinessPartyAddressBObj.elementAt(1);
					oth1AddressGroupBObj.setAddressUsageType(ExternalRuleConstant.OTHERS1_MVP);
					oth1AddressGroupBObj.setAddressUsageValue(ExternalRuleConstant.OTHERS1_MVP_VALUE);						
					surviveAddress(partyAddressMap,oth1AddressGroupBObj);
					
					//Latest in business
					businessAddressGroupBObj = vecBusinessPartyAddressBObj.elementAt(0);
					surviveAddress(partyAddressMap,businessAddressGroupBObj);
					
				}else if(vecBusinessPartyAddressBObj.size() ==3){						
					//If business Address count is 3
					
					//Third Latest business in Other 2
					oth2AddressGroupBObj = vecBusinessPartyAddressBObj.elementAt(2);
					oth2AddressGroupBObj.setAddressUsageType(ExternalRuleConstant.OTHERS2_MVP);
					oth2AddressGroupBObj.setAddressUsageValue(ExternalRuleConstant.OTHERS2_MVP_VALUE);						
					surviveAddress(partyAddressMap,oth2AddressGroupBObj);
					
					//Second Latest in Other 1
					oth1AddressGroupBObj = vecBusinessPartyAddressBObj.elementAt(1);
					oth1AddressGroupBObj.setAddressUsageType(ExternalRuleConstant.OTHERS1_MVP);
					oth1AddressGroupBObj.setAddressUsageValue(ExternalRuleConstant.OTHERS1_MVP_VALUE);						
					surviveAddress(partyAddressMap,oth1AddressGroupBObj);
					
					
					// Latest in business
					businessAddressGroupBObj = vecBusinessPartyAddressBObj.elementAt(0);
					surviveAddress(partyAddressMap,businessAddressGroupBObj);
					
				
					
				}else if (vecBusinessPartyAddressBObj.size() > 3){
					//If business Address count > 3
					
					//Fourth Latest business in Other 3
					oth3AddressGroupBObj = vecBusinessPartyAddressBObj.elementAt(3);
					oth3AddressGroupBObj.setAddressUsageType(ExternalRuleConstant.OTHERS3_MVP);
					oth3AddressGroupBObj.setAddressUsageValue(ExternalRuleConstant.OTHERS3_MVP_VALUE);						
					surviveAddress(partyAddressMap,oth3AddressGroupBObj);
					
					// Third Latest in Other 2
					oth2AddressGroupBObj = vecBusinessPartyAddressBObj.elementAt(2);
					oth2AddressGroupBObj.setAddressUsageType(ExternalRuleConstant.OTHERS2_MVP);
					oth2AddressGroupBObj.setAddressUsageValue(ExternalRuleConstant.OTHERS2_MVP_VALUE);						
					surviveAddress(partyAddressMap,oth2AddressGroupBObj);
					
					// Second Latest in Other 1
					oth1AddressGroupBObj = vecBusinessPartyAddressBObj.elementAt(1);
					oth1AddressGroupBObj.setAddressUsageType(ExternalRuleConstant.OTHERS1_MVP);
					oth1AddressGroupBObj.setAddressUsageValue(ExternalRuleConstant.OTHERS1_MVP_VALUE);						
					surviveAddress(partyAddressMap,oth1AddressGroupBObj);
					
					
					// Latest in business
					businessAddressGroupBObj = vecBusinessPartyAddressBObj.elementAt(0);
					surviveAddress(partyAddressMap,businessAddressGroupBObj);
					}
				}
			}
			// Change Retail Address Usage Type on the basis of Wholesale Address Usage Type
			keySet = partyAddressMap.keySet();
	
			vecWSPartyAddressBObj.removeAllElements();
			vecRetailerPartyAddressBObj.removeAllElements();
			// Set<String> retailerIdSet = new HashSet<String>();
	
			for (String key : keySet) {
				if (!(key.endsWith(ExternalRuleConstant.CHARACTER_Y))) {
	
					vecWSPartyAddressBObj.add(partyAddressMap.get(key));
	
				} else {
	
					vecRetailerPartyAddressBObj.add(partyAddressMap.get(key));
				}
			}
	
			for (XAddressGroupBObjExt retailerPartyAddressBObj : vecRetailerPartyAddressBObj) {
				
				//address usage type P is not used for MVP
				/*retailerPartyAddressBObj.setAddressUsageValue(ExternalRuleConstant.ADDRESS_USAGE_VALUE_P);
	
				retailerPartyAddressBObj.setAddressUsageType(ExternalRuleConstant.ADDRESS_USAGE_TYPE_P);*/
	
				for (XAddressGroupBObjExt wsPartyAddressBObj : vecWSPartyAddressBObj) {
	
					String rtmapKey = retailerPartyAddressBObj.getTCRMAddressBObj().getAddressLineOne() + 
							retailerPartyAddressBObj.getTCRMAddressBObj().getAddressLineTwo() +
							retailerPartyAddressBObj.getTCRMAddressBObj().getAddressLineThree()
							+ retailerPartyAddressBObj.getPartyId();
	
					String wsmapKey = wsPartyAddressBObj.getTCRMAddressBObj().getAddressLineOne() + 
							wsPartyAddressBObj.getTCRMAddressBObj().getAddressLineTwo() +
							wsPartyAddressBObj.getTCRMAddressBObj().getAddressLineThree() + 
							wsPartyAddressBObj.getPartyId() ;
					
					
					if (wsmapKey.equalsIgnoreCase(rtmapKey)) {
	
						// retailerIdSet.add(retailerPartyAddressBObj.getPartyId());
	
						String wsAddressUsageType = wsPartyAddressBObj.getAddressUsageType();
	
						String wsAddressUsageValue = wsPartyAddressBObj.getAddressUsageValue();
	
						if (retailerPartyAddressBObj != null) {
	
							retailerPartyAddressBObj.setAddressUsageValue(wsAddressUsageValue);
	
							retailerPartyAddressBObj.setAddressUsageType(wsAddressUsageType);
	
						}
						continue;
	
					}
				}
	
			
		}
	}
	
	//16 July,19: Added by Sameeha for DMS Address logic: Start
	public static void sortPartyAddresses(Vector<XAddressGroupBObjExt> vecRetailPartyAddressBObj, XAddressGroupBObjExt newPartyAddressBObj, DWLControl control) throws Exception {
		if(vecRetailPartyAddressBObj.size() != 0){
			//Descending order
			Collections.sort(vecRetailPartyAddressBObj, new Comparator<XAddressGroupBObjExt>() {
				public int compare(XAddressGroupBObjExt party1, XAddressGroupBObjExt party2) {
					if (party1.getXLastModifiedSystemDate() == null || party2.getXLastModifiedSystemDate() == null)
					return 0;
					return party1.getXLastModifiedSystemDate().compareTo(party2.getXLastModifiedSystemDate());
				}
			});
			Collections.reverse(vecRetailPartyAddressBObj);
			//Descending sort
		}
	}
	
	private static void surviveAddress(HashMap<String, XAddressGroupBObjExt> partyAddressMap,XAddressGroupBObjExt addressGroupBObj) {
		
		if(addressGroupBObj != null){
			String mapKey = addressGroupBObj.getXAddressRetailerFlag()
					+ addressGroupBObj.getAddressUsageType()
					+ addressGroupBObj.getTCRMAddressBObj().getAddressLineOne()
					+ addressGroupBObj.getTCRMAddressBObj().getAddressLineTwo()
					+ addressGroupBObj.getTCRMAddressBObj().getAddressLineThree()
					+ addressGroupBObj.getTCRMAddressBObj().getCity()
					+ addressGroupBObj.getTCRMAddressBObj().getZipPostalCode()
					+ addressGroupBObj.getTCRMAddressBObj().getResidenceNumber()
					+ addressGroupBObj.getTCRMAddressBObj().getCountryType() ;
					
			partyAddressMap.put(mapKey, addressGroupBObj);
		
		}

	}

	/**
	 * Method to get Source Priority for Address
	 * @param sourceSystemType
	 * @return
	 * @throws Exception
	 */
	public static String getSourcePriorityForAddress(String sourceSystemType) throws Exception {

		String sourcePriority = null;

		if(StringUtils.isNonBlank(sourceSystemType))
		{
			if(ExternalRuleConstant.SOURCE_SYSTEM_TYPE_SFDC_HRS.equalsIgnoreCase(sourceSystemType) || 
			   ExternalRuleConstant.SOURCE_SYSTEM_TYPE_AUTOLINE_HRS.equalsIgnoreCase(sourceSystemType))
			{
				sourcePriority = ExternalRuleConstant.SOURCE_PRIORITY_HRS_2;
			}
			else if(ExternalRuleConstant.SOURCE_SYSTEM_TYPE_TDS_HRS.equalsIgnoreCase(sourceSystemType))
			{
				sourcePriority = ExternalRuleConstant.SOURCE_PRIORITY_HRS_1;				
			}
			else
			{
				//Hard Coded for the time being, need to be corrected
				sourcePriority = ExternalRuleConstant.SOURCE_PRIORITY_HRS_1;
			}
		}
		return sourcePriority;	

	}

	/**
	 * Method to survice Contact Method Details
	 * @param control
	 * @param partyContMethMap
	 * @param vecTempPartyContactMethodBObj
	 * @throws Exception
	 */
	private static void surviveContactMethodDetails(DWLControl control, HashMap<String, XContactMethodGroupBObjExt> partyContMethMap, Vector<XContactMethodGroupBObjExt> vecTempPartyContactMethodBObj) throws Exception {

		String firstPartyContMethodUsageType = null;
		String secondPartyContMethodUsageType = null;
		String firstSourceTypePartyContMethod = null;
		String secondSourceTypePartyContMethod = null;
		String mapKey = null;

		if(null!= vecTempPartyContactMethodBObj && vecTempPartyContactMethodBObj.size()>0)
		{
			for(int i=0; i<vecTempPartyContactMethodBObj.size() ; i++)
			{
				XContactMethodGroupBObjExt partyContMethBObj = (XContactMethodGroupBObjExt) vecTempPartyContactMethodBObj.get(i);
				firstPartyContMethodUsageType = partyContMethBObj.getContactMethodUsageType();
				firstSourceTypePartyContMethod = partyContMethBObj.getSourceIdentifierType();

				if(!partyContMethMap.containsKey(firstPartyContMethodUsageType))
				{
					partyContMethMap.put(firstPartyContMethodUsageType, partyContMethBObj);
				}
				else
				{
					XContactMethodGroupBObjExt contMethodBObjInMap = partyContMethMap.get(firstPartyContMethodUsageType);
					secondPartyContMethodUsageType = contMethodBObjInMap.getContactMethodUsageType();
					secondSourceTypePartyContMethod = contMethodBObjInMap.getSourceIdentifierType();

					Timestamp party1ContMethModifiedDt = DateFormatter.getTimestamp(contMethodBObjInMap.getXLastModifiedSystemDate());
					Timestamp party2ContMethModifiedDt = DateFormatter.getTimestamp(partyContMethBObj.getXLastModifiedSystemDate());

					//If the source system is same , then survive the latest contact methods
					if(firstSourceTypePartyContMethod.equalsIgnoreCase(secondSourceTypePartyContMethod))
					{
						if(party1ContMethModifiedDt.after(party2ContMethModifiedDt))
						{
							partyContMethMap.put(secondPartyContMethodUsageType, contMethodBObjInMap);
						}
						else
						{
							partyContMethMap.put(firstPartyContMethodUsageType, partyContMethBObj);
						}
						
						
					}
					else
					{
						String contactMethodCategory = partyContMethBObj.getTCRMContactMethodBObj().getContactMethodType();

						if(ExternalRuleConstant.CONT_METH_CAT_PHONE_HRS.equalsIgnoreCase(contactMethodCategory))
						{
							if(party1ContMethModifiedDt.after(party2ContMethModifiedDt))
							{
								partyContMethMap.put(secondPartyContMethodUsageType, contMethodBObjInMap);
							}
							else
							{
								partyContMethMap.put(firstPartyContMethodUsageType, partyContMethBObj);
							}
						}
						else if(ExternalRuleConstant.CONT_METH_CAT_EMAIL_HRS.equalsIgnoreCase(contactMethodCategory))
						{
							String firstPartySourcePriority = getSourcePriorityForEmail(firstSourceTypePartyContMethod);
							String secondPartySourcePriority = getSourcePriorityForEmail(secondSourceTypePartyContMethod);

							if(firstPartySourcePriority.equalsIgnoreCase(secondPartySourcePriority))
							{
								if(party1ContMethModifiedDt.after(party2ContMethModifiedDt))
								{
									partyContMethMap.put(secondPartyContMethodUsageType, contMethodBObjInMap);
								}
								else
								{
									partyContMethMap.put(firstPartyContMethodUsageType, partyContMethBObj);
								}
							}
							else
							{
								if(Integer.parseInt(firstPartySourcePriority)>Integer.parseInt(secondPartySourcePriority))
								{
									partyContMethMap.put(firstPartyContMethodUsageType, partyContMethBObj);
								}
								else
								{
									partyContMethMap.put(secondPartyContMethodUsageType, contMethodBObjInMap);
								}
							}
						}
						
					}
				}
			}
		}

	}

	/**
	 * Method to get Source Priority for Email Address
	 * @param sourceSystemType
	 * @return
	 * @throws Exception
	 */
	public static String getSourcePriorityForEmail(String sourceSystemType) throws Exception {

		String sourcePriority = null;

		if(StringUtils.isNonBlank(sourceSystemType))
		{
			if(ExternalRuleConstant.SOURCE_SYSTEM_TYPE_SFDC_HRS.equalsIgnoreCase(sourceSystemType) || 
					   ExternalRuleConstant.SOURCE_SYSTEM_TYPE_AUTOLINE_HRS.equalsIgnoreCase(sourceSystemType))
			{
				sourcePriority = ExternalRuleConstant.SOURCE_PRIORITY_HRS_2;
			}
			else if(ExternalRuleConstant.SOURCE_SYSTEM_TYPE_TDS_HRS.equalsIgnoreCase(sourceSystemType))
			{
				sourcePriority = ExternalRuleConstant.SOURCE_PRIORITY_HRS_1;				
			}
			else
			{
				//Hard Coded for the time being, need to be corrected
				sourcePriority = ExternalRuleConstant.SOURCE_PRIORITY_HRS_1;
			}
		}
		return sourcePriority;	
	}

	/**
	 * Method to survive SFDC ID
	 * @param control
	 * @param partyAdminConteqMap
	 * @param vecTempAdminContequivBObj
	 * @throws Exception
	 */
	private static void surviveContEquivDetails(DWLControl control, HashMap<String, TCRMAdminContEquivBObj> partyAdminConteqMap, Vector<XContEquivBObjExt> vecTempAdminContequivBObj) throws Exception {

		String firstPartyAdminSysType = null;
		String secondPartyAdminSysType = null;
		XContEquivBObjExt newadminContEquivBObj = null;
		String firstRetailerId = null;
		String secondRetailerId = null;
		String firstRetailerFlag = null;
		String secondRetailerFlag = null;
		String mapKey = null;
		XContEquivBObjExt xContEquivBObj = null;

		if(null!= vecTempAdminContequivBObj && vecTempAdminContequivBObj.size()>0)
		{
			for(int i=0; i<vecTempAdminContequivBObj.size() ; i++ )
			{
				XContEquivBObjExt partyAdminContequivBObj= (XContEquivBObjExt) vecTempAdminContequivBObj.get(i);
				firstPartyAdminSysType = partyAdminContequivBObj.getAdminSystemType();
				firstRetailerId = partyAdminContequivBObj.getXRetailerId();
				firstRetailerFlag = partyAdminContequivBObj.getXSourceRetailerFlag();
				
				if (ExternalRuleConstant.SOURCE_SYSTEM_TYPE_UCID_HRS
						.equalsIgnoreCase(firstPartyAdminSysType)) {
					mapKey = firstPartyAdminSysType;
				} else {
					if (ExternalRuleConstant.CHARACTER_N
							.equalsIgnoreCase(firstRetailerFlag)) {
						mapKey = firstRetailerFlag + firstPartyAdminSysType;
					} else {
						mapKey = firstRetailerFlag + firstPartyAdminSysType
								+ firstRetailerId;
					}
				}

				if(!partyAdminConteqMap.containsKey(mapKey))
				{
					partyAdminConteqMap.put(mapKey,partyAdminContequivBObj);
				}
				else
				{
					XContEquivBObjExt partyAdminContequivBObjInMap = (XContEquivBObjExt) partyAdminConteqMap.get(mapKey);
					secondPartyAdminSysType = partyAdminContequivBObjInMap.getAdminSystemType();
					secondRetailerId = partyAdminContequivBObjInMap.getXRetailerId();
					secondRetailerFlag = partyAdminContequivBObjInMap.getXSourceRetailerFlag();
					Timestamp party1SFDCIdModifiedDt = DateFormatter.getTimestamp(partyAdminContequivBObjInMap.getContEquivLastUpdateDate());
					Timestamp party2SFDCIdModifiedDt = DateFormatter.getTimestamp( partyAdminContequivBObj.getContEquivLastUpdateDate());

					if(firstPartyAdminSysType.equalsIgnoreCase(secondPartyAdminSysType))
					{
					  if(ExternalRuleConstant.SOURCE_SYSTEM_TYPE_UCID_HRS.equalsIgnoreCase(firstPartyAdminSysType))
						{
							if(xContEquivBObj == null)
							{
								if (party1SFDCIdModifiedDt.after(party2SFDCIdModifiedDt))
								{
									mapKey = firstPartyAdminSysType;
									partyAdminConteqMap.put(mapKey,partyAdminContequivBObj);
									xContEquivBObj = partyAdminContequivBObj;
								}
								else
								{
									mapKey = secondPartyAdminSysType;
									partyAdminConteqMap.put(mapKey,partyAdminContequivBObjInMap);
								}
							}

							else
							{
								String newCont = xContEquivBObj.getPartyId();
								if(newCont.equalsIgnoreCase(partyAdminContequivBObj.getPartyId()))
								{
									//Both belongs to same party
							  		mapKey = firstPartyAdminSysType;
									partyAdminConteqMap.put(mapKey,partyAdminContequivBObj);
								}
							}
						}
						
						
					  	else if(firstPartyAdminSysType.equalsIgnoreCase(ExternalRuleConstant.SOURCE_SYSTEM_TYPE_SFDC_HRS))
						{
							if(xContEquivBObj == null)
							{
								if (party1SFDCIdModifiedDt.after(party2SFDCIdModifiedDt))
								{
									if(firstRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_Y))
										mapKey = firstRetailerFlag + firstPartyAdminSysType + firstRetailerId;

									else
										mapKey = firstRetailerFlag + firstPartyAdminSysType;

									partyAdminConteqMap.put(mapKey,partyAdminContequivBObj);
									xContEquivBObj = partyAdminContequivBObj;
								}

								else
								{
									if(secondRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_Y))
										mapKey = secondRetailerFlag + secondPartyAdminSysType + secondRetailerId;

									else
										mapKey = secondRetailerFlag + secondPartyAdminSysType;

									partyAdminConteqMap.put(mapKey,partyAdminContequivBObjInMap);
								}
							}

							else
							{
								String newCont = xContEquivBObj.getPartyId();
								if(newCont.equalsIgnoreCase(partyAdminContequivBObj.getPartyId()))
								{
									//Both belongs to same party
									if(firstRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_Y))
										mapKey = firstRetailerFlag + firstPartyAdminSysType + firstRetailerId;

									else
										mapKey = firstRetailerFlag + firstPartyAdminSysType;

									partyAdminConteqMap.put(mapKey,partyAdminContequivBObj);
								}
							}
						}

						else
						{
							if (party1SFDCIdModifiedDt.after(party2SFDCIdModifiedDt))
							{
								if(firstRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_Y))
									mapKey = firstRetailerFlag + firstPartyAdminSysType + firstRetailerId;

								else
									mapKey = firstRetailerFlag + firstPartyAdminSysType;

								partyAdminConteqMap.put(mapKey,partyAdminContequivBObj);
							}

							else
							{
								if(secondRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_Y))
									mapKey = secondRetailerFlag + secondPartyAdminSysType + secondRetailerId;

								else
									mapKey = secondRetailerFlag + secondPartyAdminSysType;

								partyAdminConteqMap.put(mapKey,partyAdminContequivBObjInMap);
						}
					}
				}
			}
		}	
	}
}


/**
	 * Method to sort Organization details
	 * @param vecAllParty
	 * @param newParty
	 * @param control
	 * @return
	 * @throws Exception
	 */
	public static TCRMPartyBObj sortOrgParties(Vector<TCRMPartyBObj> vecAllParty, TCRMPartyBObj newParty, DWLControl control) throws Exception {


		Timestamp tempOrgLastModifiedDt = null;
		Timestamp incomingOrgLastModifiedDt = null;
		TCRMPartyBObj tempPartyBObj = null;
		int index =0;

		for (TCRMPartyBObj incomingParty : vecAllParty ) {
			XOrgBObjExt incomingOrgBObj = (XOrgBObjExt) incomingParty;
			if(index == 0) {
				tempPartyBObj = incomingParty;
				index++;
				continue;
			}

			//System.out.println("ORG LMSD" + incomingOrgBObj.getXLastModifiedSystemDate());
			incomingOrgLastModifiedDt = DateFormatter.getTimestamp(incomingOrgBObj.getXLastModifiedSystemDate());
			tempOrgLastModifiedDt = DateFormatter.getTimestamp(incomingOrgBObj.getXLastModifiedSystemDate());

			if (incomingOrgLastModifiedDt.after(tempOrgLastModifiedDt)) {

				entityCRUDOrg(incomingParty, tempPartyBObj, control);
				tempPartyBObj = incomingParty;
			}
			else {

				entityCRUDOrg(tempPartyBObj, incomingParty, control);
			}

		}

		newParty.shallowClone(tempPartyBObj);

		return newParty;		
	}

	/**
	 * Method to Survive the Organization attributes
	 * @param incomingParty
	 * @param tempPartyBObj
	 * @param control
	 * @throws Exception
	 */
	@SuppressWarnings("static-access")
	public static void entityCRUDOrg(TCRMPartyBObj incomingParty,
			TCRMPartyBObj tempPartyBObj, DWLControl control) throws Exception {
		// TODO Auto-generated method stub

		String prefLangType = null;
		String clientPotentialType = null;
		String sourceIdentifierType = null;
		String orgType = null;
		String industryType = null;

		String prefLangValue = ((XOrgBObjExt)tempPartyBObj).getPreferredLanguageValue();
		String sourceIdentifierValue = ((XOrgBObjExt)tempPartyBObj).getSourceIdentifierValue();
		String orgTypeValue = ((XOrgBObjExt)tempPartyBObj).getOrganizationValue();
		String industryTypeValue = ((XOrgBObjExt)tempPartyBObj).getIndustryValue();


		prefLangType = ((XOrgBObjExt)tempPartyBObj).getPreferredLanguageType();
		sourceIdentifierType =((XOrgBObjExt)tempPartyBObj).getSourceIdentifierType();
		orgType = orgTypeValue = ((XOrgBObjExt)tempPartyBObj).getOrganizationType();
		industryType = ((XOrgBObjExt)tempPartyBObj).getIndustryType();

		if (((XOrgBObjExt)incomingParty).getPreferredLanguageType() == null || ((XOrgBObjExt)incomingParty).getPreferredLanguageType().isEmpty()){
			((XOrgBObjExt)incomingParty).setPreferredLanguageType(prefLangType);
		}
		if (((XOrgBObjExt)incomingParty).getPreferredLanguageValue() == null || ((XOrgBObjExt)incomingParty).getPreferredLanguageValue().isEmpty()){
			((XOrgBObjExt)incomingParty).setPreferredLanguageValue(((XOrgBObjExt)tempPartyBObj).getPreferredLanguageValue());
		}
		if (((XOrgBObjExt)incomingParty).getClientPotentialType() == null || ((XOrgBObjExt)incomingParty).getClientPotentialType().isEmpty()){
			((XOrgBObjExt)incomingParty).setClientPotentialType(clientPotentialType);
		}
		if (((XOrgBObjExt)incomingParty).getClientPotentialValue() == null || ((XOrgBObjExt)incomingParty).getClientPotentialValue().isEmpty()){
			((XOrgBObjExt)incomingParty).setClientPotentialValue(((XOrgBObjExt)tempPartyBObj).getClientPotentialValue());
		}
		if (((XOrgBObjExt)incomingParty).getPartyType() == null || ((XOrgBObjExt)incomingParty).getPartyType().isEmpty()){
			((XOrgBObjExt)incomingParty).setPartyType(((XOrgBObjExt)tempPartyBObj).getPartyType());
		}
		if (((XOrgBObjExt)incomingParty).getSourceIdentifierType() == null || ((XOrgBObjExt)incomingParty).getSourceIdentifierType().isEmpty()){
			((XOrgBObjExt)incomingParty).setSourceIdentifierType(sourceIdentifierType);
		}
		if (((XOrgBObjExt)incomingParty).getSourceIdentifierValue() == null || ((XOrgBObjExt)incomingParty).getSourceIdentifierValue().isEmpty()){
			((XOrgBObjExt)incomingParty).setSourceIdentifierValue(((XOrgBObjExt)tempPartyBObj).getSourceIdentifierValue());
		}
		if (((XOrgBObjExt)incomingParty).getLastVerifiedDate() == null || ((XOrgBObjExt)incomingParty).getLastVerifiedDate().isEmpty()){
			((XOrgBObjExt)incomingParty).setLastVerifiedDate(((XOrgBObjExt)tempPartyBObj).getLastVerifiedDate());
		}
		if (((XOrgBObjExt)incomingParty).getOrganizationType() == null || ((XOrgBObjExt)incomingParty).getOrganizationType().isEmpty()){
			((XOrgBObjExt)incomingParty).setOrganizationType(orgType);
		}
		if (((XOrgBObjExt)incomingParty).getOrganizationValue() == null || ((XOrgBObjExt)incomingParty).getOrganizationValue().isEmpty()){
			((XOrgBObjExt)incomingParty).setOrganizationValue(((XOrgBObjExt)tempPartyBObj).getOrganizationValue());
		}
		if (((XOrgBObjExt)incomingParty).getIndustryType() == null || ((XOrgBObjExt)incomingParty).getIndustryType().isEmpty()){
			((XOrgBObjExt)incomingParty).setIndustryType(industryType);
		}
		if (((XOrgBObjExt)incomingParty).getIndustryValue() == null || ((XOrgBObjExt)incomingParty).getIndustryValue().isEmpty()){
			((XOrgBObjExt)incomingParty).setIndustryValue(((XOrgBObjExt)tempPartyBObj).getIndustryValue());
		}

		XOrgBObjExt xincomingObj = (XOrgBObjExt)incomingParty;
		XOrgBObjExt xtempBobj = (XOrgBObjExt) tempPartyBObj;

		// maintain xorg attributes

		if(xincomingObj != null && xtempBobj != null){

			setXOrgAttr(xincomingObj, xtempBobj, control);

		}

	}
	public static void setXOrgAttr(XOrgBObjExt xMainInputBOBj,XOrgBObjExt xDBinputBObj, DWLControl control) throws Exception
	{
		//XDefunctInd
		if (xMainInputBOBj.getXDefunctInd() == null || xMainInputBOBj.getXDefunctInd().isEmpty())
			xMainInputBOBj.setXDefunctInd(xDBinputBObj.getXDefunctInd());
		
		//XWebsite
		if (xMainInputBOBj.getXWebsite() == null || xMainInputBOBj.getXWebsite().isEmpty())
			xMainInputBOBj.setXWebsite(xDBinputBObj.getXWebsite());
		
		//XMarketName
		if (xMainInputBOBj.getXMarketName() == null || xMainInputBOBj.getXMarketName().isEmpty())
			xMainInputBOBj.setXMarketName(xDBinputBObj.getXMarketName());
		
		//XBatchInd
		if (xMainInputBOBj.getXBatchInd() == null || xMainInputBOBj.getXBatchInd().isEmpty())
			xMainInputBOBj.setXBatchInd(xDBinputBObj.getXBatchInd());
		
		//XNumberOfEmployeesType
		if (xMainInputBOBj.getXNumberOfEmployeesType() == null || xMainInputBOBj.getXNumberOfEmployeesType().isEmpty())
			xMainInputBOBj.setXNumberOfEmployeesType(xDBinputBObj.getXNumberOfEmployeesType());
		
		//XNumberOfEmployeesValue
		if (xMainInputBOBj.getXNumberOfEmployeesValue() == null || xMainInputBOBj.getXNumberOfEmployeesValue().isEmpty())
			xMainInputBOBj.setXNumberOfEmployeesValue(xDBinputBObj.getXNumberOfEmployeesValue());
		
		//XLastModifiedSystemDate
		if (xMainInputBOBj.getXLastModifiedSystemDate() == null || xMainInputBOBj.getXLastModifiedSystemDate().isEmpty())
			xMainInputBOBj.setXLastModifiedSystemDate(xDBinputBObj.getXLastModifiedSystemDate());
		
		//XGenerated_by
		if (xMainInputBOBj.getXGenerated_by() == null || xMainInputBOBj.getXGenerated_by().isEmpty())
			xMainInputBOBj.setXGenerated_by(xDBinputBObj.getXGenerated_by());
		
		//XCorporateCategoryType
		if (xMainInputBOBj.getXCorporateCategoryType() == null || xMainInputBOBj.getXCorporateCategoryType().isEmpty())
			xMainInputBOBj.setXCorporateCategoryType(xDBinputBObj.getXCorporateCategoryType());
		
		//XCorporateCategoryValue
		if (xMainInputBOBj.getXCorporateCategoryValue() == null || xMainInputBOBj.getXCorporateCategoryValue().isEmpty())
			xMainInputBOBj.setXCorporateCategoryValue(xDBinputBObj.getXCorporateCategoryValue());
		
		//XCorporateGroupType
		if (xMainInputBOBj.getXCorporateGroupType() == null || xMainInputBOBj.getXCorporateGroupType().isEmpty())
			xMainInputBOBj.setXCorporateGroupType(xDBinputBObj.getXCorporateGroupType());
		
		//XCorporateGroupValue
		if (xMainInputBOBj.getXCorporateGroupValue() == null || xMainInputBOBj.getXCorporateGroupValue().isEmpty())
			xMainInputBOBj.setXCorporateGroupValue(xDBinputBObj.getXCorporateGroupValue());
		//XPersonalAgreement
		if(xMainInputBOBj.getXPersonalAgreement() == null || xMainInputBOBj.getXPersonalAgreement().isEmpty())
			xMainInputBOBj.setXPersonalAgreement(xDBinputBObj.getXPersonalAgreement());
		
	}
	
	private static HashMap<String, HashMap> survivedOrgDetails(Vector vecAllParty,DWLControl control) throws Exception {
		HashMap<String, XOrgNameBObjExt> orgNameMap = new HashMap<String, XOrgNameBObjExt>();
		HashMap<String, XAddressGroupBObjExt> partyAddressMap = new HashMap<String, XAddressGroupBObjExt>();
		HashMap<String, XIdentifierBObjExt> partyIdentMap = new HashMap<String, XIdentifierBObjExt>();
		HashMap<String, XContactMethodGroupBObjExt> partyContMethMap = new HashMap<String, XContactMethodGroupBObjExt>();
		HashMap<String, TCRMAdminContEquivBObj> partyAdminConteqMap = new HashMap<String, TCRMAdminContEquivBObj>();
		String mapKey = null;
		boolean isBatch = true;

		XOrgBObjExt incomingOrgBObj = (XOrgBObjExt) vecAllParty.get(0);

		if((ExternalRuleConstant.HUNGARY_MARKET_NAME.equalsIgnoreCase(incomingOrgBObj.getXMarketName()))
				||(ExternalRuleConstant.ROMANIA_MARKET_NAME.equalsIgnoreCase(incomingOrgBObj.getXMarketName()))
				||(ExternalRuleConstant.SLOVAKIA_MARKET_NAME.equalsIgnoreCase(incomingOrgBObj.getXMarketName())))

		{	
			//Added by Sameeha for separate Address survivorship for Initialization data : 18th July,19: Start
			for(int i=0; i < vecAllParty.size(); i++){
			
				TCRMPartyBObj party = (TCRMPartyBObj) vecAllParty.get(i);
				if(ExternalRuleConstant.BATCH_IND_N.equalsIgnoreCase(((XOrgBObjExt) party).getXBatchInd())){
					isBatch = false;
					break;
				}
					
			}
			// For Party Address
			//Survive Address Details 
			if(isBatch)
				surviveAddressDetailsInit(control, partyAddressMap, vecAllParty);
			else
				surviveAddressDetailsRT(control, partyAddressMap, vecAllParty);
			
			//Added by Sameeha for separate Address survivorship for Initialization data : 18th July,19: End
			
			for(int i=0; i < vecAllParty.size(); i++)
			{
				TCRMPartyBObj party = (TCRMPartyBObj) vecAllParty.get(i);


				Vector<XOrgNameBObjExt> vecTempOrgNameBOBj = new Vector<XOrgNameBObjExt>();
				vecTempOrgNameBOBj = ((XOrgBObjExt) party).getItemsTCRMOrganizationNameBObj();

				//Survive Organization Name Details
				surviveOrgNameDetails(control, orgNameMap, vecTempOrgNameBOBj);


				Vector<XIdentifierBObjExt> vecTempPartyIdentificationBObj = new Vector<XIdentifierBObjExt>();
				vecTempPartyIdentificationBObj = party.getItemsTCRMPartyIdentificationBObj();

				//Survive Identifier Details 
				surviveIdentifierDetails(control, partyIdentMap, vecTempPartyIdentificationBObj);

				
				Vector<XContactMethodGroupBObjExt> vecTempPartyContactMethodBObj = new Vector<XContactMethodGroupBObjExt>();
				vecTempPartyContactMethodBObj = party.getItemsTCRMPartyContactMethodBObj();	

				//Survive Party Contact Method Details
				surviveContactMethodDetails(control, partyContMethMap, vecTempPartyContactMethodBObj);

				Vector<XContEquivBObjExt> vecTempAdminContequivBObj =  new Vector<XContEquivBObjExt>();
				vecTempAdminContequivBObj = party.getItemsTCRMAdminContEquivBObj();

				//Survive SFDC ID 
				//Admin Contequiv
				surviveContEquivDetails(control, partyAdminConteqMap, vecTempAdminContequivBObj);
				
				
			}
		}

		HashMap<String, HashMap> partyMap = new HashMap<String, HashMap>();
		partyMap.put(ExternalRuleConstant.SURVIVED_MAP_NAME, orgNameMap);
		partyMap.put(ExternalRuleConstant.SURVIVED_MAP_ADDRESS, partyAddressMap);
		partyMap.put(ExternalRuleConstant.SURVIVED_MAP_IDENTIFIER, partyIdentMap);
		partyMap.put(ExternalRuleConstant.SURVIVED_MAP_CONTACTMETHOD, partyContMethMap);
		partyMap.put(ExternalRuleConstant.SURVIVED_MAP_CONTEQUIV, partyAdminConteqMap);

		return partyMap;

	}
	
	/**
	 * Method to survive Person Name Details
	 * @param control
	 * @param personNameMap
	 * @param vecTempPersonNameBOBj
	 * @throws Exception
	 */
	private static void surviveOrgNameDetails(DWLControl control, HashMap<String, XOrgNameBObjExt> orgNameMap, Vector<XOrgNameBObjExt> vecTempOrgNameBOBj) throws Exception {

		String firstPartyNameUsageType = null;
		String secondPartyNameUsageType = null;
		String firstSourceTypeOrgName = null;
		String secondSourceTypeOrgName = null;
		String firstOrgSourcePriorityNM = null;
		String secondOrgSourcePriorityNM = null;


		if(null!= vecTempOrgNameBOBj && vecTempOrgNameBOBj.size()>0)
		{
			for(int i=0; i<vecTempOrgNameBOBj.size(); i++)
			{
				XOrgNameBObjExt orgnameBObj = (XOrgNameBObjExt) vecTempOrgNameBOBj.get(i);
				firstPartyNameUsageType = orgnameBObj.getNameUsageType();
				firstSourceTypeOrgName = orgnameBObj.getSourceIdentifierType();
				firstOrgSourcePriorityNM = getSourcePriorityForOrgName(firstSourceTypeOrgName);

				if(!orgNameMap.containsKey(firstPartyNameUsageType))
				{
					orgNameMap.put(firstPartyNameUsageType, orgnameBObj);
				}
				else
				{
					XOrgNameBObjExt nameBObjInMap = orgNameMap.get(firstPartyNameUsageType);

					secondPartyNameUsageType = orgnameBObj.getNameUsageType();
					secondSourceTypeOrgName = nameBObjInMap.getSourceIdentifierType();
					secondOrgSourcePriorityNM = getSourcePriorityForOrgName(secondSourceTypeOrgName);

					Timestamp org1NameLastModifiedDate = DateFormatter.getTimestamp(nameBObjInMap.getXLastModifiedSystemDate());
					Timestamp org2NameLastModifiedDate = DateFormatter.getTimestamp(orgnameBObj.getXLastModifiedSystemDate());

					if(firstSourceTypeOrgName.equalsIgnoreCase(secondSourceTypeOrgName))
					{
						if (org1NameLastModifiedDate.after(org2NameLastModifiedDate))
						{
							orgNameMap.put(secondPartyNameUsageType,nameBObjInMap);
						}

						else
						{
							orgNameMap.put(firstPartyNameUsageType,orgnameBObj);
						}

					}
					else
					{
						if(firstOrgSourcePriorityNM.equalsIgnoreCase(secondOrgSourcePriorityNM))
						{
							if (org1NameLastModifiedDate.after(org2NameLastModifiedDate))
							{
								orgNameMap.put(secondPartyNameUsageType,nameBObjInMap);
							}

							else
							{
								orgNameMap.put(firstPartyNameUsageType,orgnameBObj);
							}
						}
						else
						{
							if(Integer.parseInt(firstOrgSourcePriorityNM)>Integer.parseInt(secondOrgSourcePriorityNM))
							{
								orgNameMap.put(firstPartyNameUsageType, orgnameBObj);
							}
							else
							{
								orgNameMap.put(secondPartyNameUsageType, nameBObjInMap);
							}
						}

					}
				}
			}
		}		
	}
	
	/**
	 * Method to get Source Priority for Org Name 
	 * @param sourceSystemType
	 * @return
	 * @throws Exception
	 */
	public static String getSourcePriorityForOrgName (String sourceSystemType) throws Exception {

		String sourcePriority = null;

		if(StringUtils.isNonBlank(sourceSystemType))
		{
			if(ExternalRuleConstant.SOURCE_SYSTEM_TYPE_SFDC_HRS.equalsIgnoreCase(sourceSystemType) || 
			     ExternalRuleConstant.SOURCE_SYSTEM_TYPE_AUTOLINE_HRS.equalsIgnoreCase(sourceSystemType))
			{
				sourcePriority = ExternalRuleConstant.SOURCE_PRIORITY_HRS_2;
			}
			else if(ExternalRuleConstant.SOURCE_SYSTEM_TYPE_TDS_HRS.equalsIgnoreCase(sourceSystemType))
			{
				sourcePriority = ExternalRuleConstant.SOURCE_PRIORITY_HRS_1;				
			}
			else
			{
				//Hard Coded 
				sourcePriority = ExternalRuleConstant.SOURCE_PRIORITY_1;
			}
		}
		return sourcePriority;		
	}
	private static void surviveIndustry(DWLControl control,XOrgBObjExt survivedBOBj, Vector<TCRMPartyBObj> vecAllParty) {
		try{
			String firstSourceType = null;
			String firstPartyPriority = null;
			String secondSourceType = null;
			String secondPartyPriority = null;
			Timestamp latestCreatedDt = DateFormatter.getTimestamp(survivedBOBj.getXLastModifiedSystemDate());
			firstSourceType = survivedBOBj.getSourceIdentifierType();
			firstPartyPriority = getSourcePriorityForIndustry(ExternalRuleConstant.INDUSTRY_HRS, firstSourceType);
			Timestamp tempCreatedDt = null;
			
			for(TCRMPartyBObj partyBObj : vecAllParty){
				XOrgBObjExt orgBObj = (XOrgBObjExt) partyBObj;
				if(!orgBObj.getPartyId().equals(survivedBOBj.getPartyId())){
					/*String firstPartySourcePriority = getSourcePriorityForIndustry(firstSourceType);
					String secondPartySourcePriority = getSourcePriorityForIndustry(secondSourceType);*/
					
					//I
					if(survivedBOBj.getIndustryType() == null ){
						if(orgBObj.getIndustryType() != null){
							survivedBOBj.setIndustryType(orgBObj.getIndustryType());
						}
					}else{
						if(orgBObj.getIndustryType()!=null){
							secondSourceType = orgBObj.getSourceIdentifierType();
							secondPartyPriority = getSourcePriorityForIndustry(ExternalRuleConstant.INDUSTRY_HRS, secondSourceType);
							if(Integer.parseInt(firstPartyPriority) > Integer.parseInt(secondPartyPriority)){
								survivedBOBj.setIndustryType(orgBObj.getIndustryType());
							}
							else if (Integer.parseInt(firstPartyPriority) < Integer.parseInt(secondPartyPriority)){
								survivedBOBj.setIndustryType(orgBObj.getIndustryType());
							}
						}
					}
				}
			}	
		}catch(Exception e){
					
	}		
}
	


	/**
	 * Method to get Source Priority for Org Name 
	 * @param sourceSystemType
	 * @param secondSourceType 
	 * @param secondSourceType 
	 * @return
	 * @throws Exception
	 */
	public static String getSourcePriorityForIndustry (String componentType, String sourceSystemType) throws Exception {

		String sourcePriority = null;

		if(StringUtils.isNonBlank(sourceSystemType))
		{
			if(ExternalRuleConstant.SOURCE_SYSTEM_TYPE_SFDC_HRS.equalsIgnoreCase(sourceSystemType))
			{
				sourcePriority = ExternalRuleConstant.SOURCE_PRIORITY_HRS_2;
			}
			else if(ExternalRuleConstant.SOURCE_SYSTEM_TYPE_AUTOLINE_HRS.equalsIgnoreCase(sourceSystemType))
			{
				sourcePriority = ExternalRuleConstant.SOURCE_PRIORITY_HRS_1;				
			}
			
		}
		return sourcePriority;		
	}
	
	private static void handlePrefAddress(
			Vector<XAddressGroupBObjExt> vecSurvivedPersonAddrBOBj)
			throws Exception {

		XAddressGroupBObjExt tempAddrBObj = null;

		for (XAddressGroupBObjExt partyAddress : vecSurvivedPersonAddrBOBj) {

			Timestamp lastUpdatedt = DateFormatter.getTimestamp(partyAddress
					.getXLastModifiedSystemDate());
			String prefInd = partyAddress.getPreferredAddressIndicator();

			if (StringUtils.isNonBlank(prefInd)
					&& prefInd
							.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_Y)) {
				if (tempAddrBObj == null) {
					tempAddrBObj = partyAddress;
					continue;
				}

				if (DateFormatter.getTimestamp(
						tempAddrBObj.getXLastModifiedSystemDate()).before(
						lastUpdatedt)) {
					tempAddrBObj
							.setPreferredAddressIndicator(ExternalRuleConstant.CHARACTER_N);
					tempAddrBObj = partyAddress;
				} else {
					partyAddress
							.setPreferredAddressIndicator(ExternalRuleConstant.CHARACTER_N);
				}

			}
		}
	}

	private static void handlePrefContactMethod(
			Vector<XContactMethodGroupBObjExt> vecSurvivedPersonContMethBOBj)
			throws Exception {

		XContactMethodGroupBObjExt tempContMethodBObj = null;

		for (XContactMethodGroupBObjExt partyContMethodBObj : vecSurvivedPersonContMethBOBj) {

			Timestamp lastUpdatedt = DateFormatter
					.getTimestamp(partyContMethodBObj
							.getXLastModifiedSystemDate());
			String prefInd = partyContMethodBObj
					.getPreferredContactMethodIndicator();

			if (StringUtils.isNonBlank(prefInd)
					&& prefInd
							.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_Y)) {
				if (tempContMethodBObj == null) {
					tempContMethodBObj = partyContMethodBObj;
					continue;
				}

				if (DateFormatter.getTimestamp(
						tempContMethodBObj.getXLastModifiedSystemDate())
						.before(lastUpdatedt)) {
					tempContMethodBObj
							.setPreferredContactMethodIndicator(ExternalRuleConstant.CHARACTER_N);
					tempContMethodBObj = partyContMethodBObj;
				} else {
					partyContMethodBObj
							.setPreferredContactMethodIndicator(ExternalRuleConstant.CHARACTER_N);
				}

			}
		}
	}

}
