package com.ibm.daimler.dsea.extrules.sdp;

import java.sql.Timestamp;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Vector;

import com.dwl.base.DWLCommon;
import com.dwl.base.DWLControl;
import com.dwl.base.exception.DWLBaseException;
import com.dwl.base.util.DWLExceptionUtils;
import com.dwl.base.util.StringUtils;
import com.dwl.tcrm.coreParty.component.TCRMAdminContEquivBObj;
import com.dwl.tcrm.coreParty.component.TCRMPartyBObj;
import com.dwl.tcrm.coreParty.component.TCRMPartyPrivPrefBObj;
import com.dwl.tcrm.coreParty.component.TCRMPersonBObj;
import com.dwl.tcrm.utilities.DateFormatter;
import com.ibm.daimler.dsea.component.XPersonBObjExt;
import com.ibm.daimler.dsea.extrules.constant.ExternalRuleConstant;
import com.ibm.daimler.dsea.component.DSEAAdditionsExtsComponent;
import com.ibm.daimler.dsea.component.XAddressBObjExt;
import com.ibm.daimler.dsea.component.XAddressGroupBObjExt;
import com.ibm.daimler.dsea.component.XContEquivBObjExt;
import com.ibm.daimler.dsea.component.XContactMethodGroupBObjExt;
import com.ibm.daimler.dsea.component.XIdentifierBObjExt;
import com.ibm.daimler.dsea.component.XOrgBObjExt;
import com.ibm.daimler.dsea.component.XOrgNameBObjExt;
import com.ibm.daimler.dsea.component.XPersonNameBObjExt;
import com.ibm.daimler.dsea.component.XPreferenceBObj;
import com.ibm.daimler.dsea.component.XPrivacyAgreementBObj;

public class SurvivorshipRuleUtilTUR {

	@SuppressWarnings("unchecked")
	public static Vector collapseObjectsSurvivingRules(Vector vecDWLCommons, boolean bReturnTheMostRecentRootBObjOnly) throws DWLBaseException {

		Vector vecSurviveDWLCommons = new Vector();

		try
		{
			DWLCommon source = (DWLCommon) vecDWLCommons.get(0);
			TCRMPartyBObj newParty = null;
			String personOrgCode = null;

			if(source instanceof TCRMPartyBObj)
			{
				DWLControl control = source.getControl();
				@SuppressWarnings("rawtypes")

				Vector<TCRMPartyBObj> vecAllParty = new Vector<TCRMPartyBObj>();
				TCRMPartyBObj firstparty = (TCRMPartyBObj) vecDWLCommons.get(0);
				personOrgCode = firstparty.getPartyType();
				newParty = (TCRMPartyBObj) Class.forName(firstparty.getClass().getName()).newInstance();

				if(ExternalRuleConstant.PERSON_ORG_CODE_P.equalsIgnoreCase(personOrgCode)){
					Collections.sort(vecDWLCommons, new Comparator<XPersonBObjExt>(){	
						//Ascending sort - for delta load
						public int compare(XPersonBObjExt party1, XPersonBObjExt party2)
						{
							if (party1.getXLastModifiedSystemDate() == null || party2.getXLastModifiedSystemDate() == null)
								return 0;

							return party1.getXLastModifiedSystemDate().compareTo(party2.getXLastModifiedSystemDate());
						}
				});

					//Descending sort
					Collections.reverse(vecDWLCommons);
					Iterator itParty = vecDWLCommons.iterator();

					while (itParty.hasNext())
					{
						TCRMPartyBObj newParty1 = new TCRMPartyBObj();
						newParty1 = (TCRMPartyBObj) itParty.next();
						vecAllParty.add(newParty1);
					}

					XPersonBObjExt newPartyBObj = (XPersonBObjExt) newParty;
					XPersonBObjExt survivedBOBj = sortParties(vecAllParty,newPartyBObj, control);
					
					//DOB, Gender and Occupation
					surviveGenderDOBOccupation(control,survivedBOBj, vecAllParty);
					
					HashMap<String, HashMap> finalPersonDetlsMap = survivedPersonDetails(vecAllParty, control);

					HashMap<String, XPersonNameBObjExt> personNameMap = new HashMap<String, XPersonNameBObjExt>();
					HashMap<String, XAddressGroupBObjExt> partyAddressMap = new HashMap<String, XAddressGroupBObjExt>();
					HashMap<String, XIdentifierBObjExt> partyIdentMap = new HashMap<String, XIdentifierBObjExt>();
					HashMap<String, XContactMethodGroupBObjExt> partyContMethMap = new HashMap<String, XContactMethodGroupBObjExt>();
					HashMap<String, XContEquivBObjExt> partyAdminConteqMap = new HashMap<String, XContEquivBObjExt>();

					Vector<XPersonNameBObjExt> vecSurvivedPersonNameBOBj = new Vector<XPersonNameBObjExt>();
					Vector<XAddressGroupBObjExt> vecSurvivedPartyAddrBOBj = new Vector<XAddressGroupBObjExt>();
					Vector<XIdentifierBObjExt> vecSurvivedPartyIdenBOBj = new Vector<XIdentifierBObjExt>();
					Vector<XContactMethodGroupBObjExt> vecSurvivedPartyContMethBOBj = new Vector<XContactMethodGroupBObjExt>();
					Vector<XContEquivBObjExt> vecSurvivedPartyAdminContBOBj = new Vector<XContEquivBObjExt>();


					personNameMap = finalPersonDetlsMap.get(ExternalRuleConstant.SURVIVED_MAP_NAME);
					partyAddressMap = finalPersonDetlsMap.get(ExternalRuleConstant.SURVIVED_MAP_ADDRESS);
					partyIdentMap = finalPersonDetlsMap.get(ExternalRuleConstant.SURVIVED_MAP_IDENTIFIER);
					partyContMethMap = finalPersonDetlsMap.get(ExternalRuleConstant.SURVIVED_MAP_CONTACTMETHOD);
					partyAdminConteqMap = finalPersonDetlsMap.get(ExternalRuleConstant.SURVIVED_MAP_CONTEQUIV);

					for (Map.Entry<String, XPersonNameBObjExt> entry : personNameMap.entrySet())
						vecSurvivedPersonNameBOBj.add(entry.getValue());

					for (Map.Entry<String, XAddressGroupBObjExt> entry : partyAddressMap.entrySet())
						vecSurvivedPartyAddrBOBj.add(entry.getValue());

					for (Map.Entry<String, XIdentifierBObjExt> entry : partyIdentMap.entrySet())
						vecSurvivedPartyIdenBOBj.add(entry.getValue());

					for (Map.Entry<String, XContactMethodGroupBObjExt> entry : partyContMethMap.entrySet())
						vecSurvivedPartyContMethBOBj.add(entry.getValue());

					for (Map.Entry<String, XContEquivBObjExt> entry : partyAdminConteqMap.entrySet())
						vecSurvivedPartyAdminContBOBj.add(entry.getValue());
					
				
					handlePrefAddress(vecSurvivedPartyAddrBOBj);

					handlePrefContactMethod(vecSurvivedPartyContMethBOBj);

					

					if (vecSurvivedPersonNameBOBj.size() > 0 || vecSurvivedPersonNameBOBj != null)
					{
						((TCRMPersonBObj) survivedBOBj).getItemsTCRMPersonNameBObj().clear();
						((TCRMPersonBObj) survivedBOBj).getItemsTCRMPersonNameBObj().addAll(vecSurvivedPersonNameBOBj);
					}

					if (vecSurvivedPartyAddrBOBj.size() > 0 || vecSurvivedPartyAddrBOBj != null)
					{
						((TCRMPersonBObj) survivedBOBj).getItemsTCRMPartyAddressBObj().clear();
						((TCRMPersonBObj) survivedBOBj).getItemsTCRMPartyAddressBObj().addAll(vecSurvivedPartyAddrBOBj);
					}

					if (vecSurvivedPartyIdenBOBj.size() > 0 || vecSurvivedPartyIdenBOBj != null)
					{
						((TCRMPersonBObj) survivedBOBj).getItemsTCRMPartyIdentificationBObj().clear();
						((TCRMPersonBObj) survivedBOBj).getItemsTCRMPartyIdentificationBObj().addAll(vecSurvivedPartyIdenBOBj);
					}

					if (vecSurvivedPartyContMethBOBj.size() > 0 || vecSurvivedPartyContMethBOBj != null) 
					{
						((TCRMPersonBObj) survivedBOBj).getItemsTCRMPartyContactMethodBObj().clear();
						((TCRMPersonBObj) survivedBOBj).getItemsTCRMPartyContactMethodBObj().addAll(vecSurvivedPartyContMethBOBj);
					}

					if (vecSurvivedPartyAdminContBOBj.size() > 0 || vecSurvivedPartyAdminContBOBj != null) 
					{
						((TCRMPersonBObj) survivedBOBj).getItemsTCRMAdminContEquivBObj().clear();
						((TCRMPersonBObj) survivedBOBj).getItemsTCRMAdminContEquivBObj().addAll(vecSurvivedPartyAdminContBOBj);
					}

					vecSurviveDWLCommons.add(survivedBOBj);

				}
				else if(ExternalRuleConstant.PERSON_ORG_CODE_O.equalsIgnoreCase(personOrgCode))
				{
					
					Collections.sort(vecDWLCommons, new Comparator<XOrgBObjExt>() {//Ascending sort - for delta load
						public int compare(XOrgBObjExt party1, XOrgBObjExt party2) {
							if (party1.getXLastModifiedSystemDate() == null || party2.getXLastModifiedSystemDate() == null)
								return 0;
							return party1.getXLastModifiedSystemDate().compareTo(party2.getXLastModifiedSystemDate());
						}
					});
					Collections.reverse(vecDWLCommons);//Descending sort
					
					Iterator itParty = vecDWLCommons.iterator();
					while (itParty.hasNext()) {

						TCRMPartyBObj newParty1 = new TCRMPartyBObj();
						newParty1 = (TCRMPartyBObj) itParty.next();
						vecAllParty.add(newParty1);
					}

					TCRMPartyBObj survivedBOBj = sortOrgParties(vecAllParty,newParty, control);
					
					
					//Change for Established date Survivorship : 28th April
					surviveEstablishedDate(control,(XOrgBObjExt) survivedBOBj, vecAllParty);
					

					HashMap<String, HashMap> finalOrgDetlsMap = survivedOrgDetails(vecAllParty, control);
					HashMap<String, XOrgNameBObjExt> orgNameMap = new HashMap<String, XOrgNameBObjExt>();
					HashMap<String, XAddressGroupBObjExt> partyAddressMap = new HashMap<String, XAddressGroupBObjExt>();
					HashMap<String, XIdentifierBObjExt> partyIdentMap = new HashMap<String, XIdentifierBObjExt>();
					HashMap<String, XContactMethodGroupBObjExt> partyContMethMap = new HashMap<String, XContactMethodGroupBObjExt>();
					HashMap<String, XContEquivBObjExt> partyAdminConteqMap = new HashMap<String, XContEquivBObjExt>();
					
					Vector<XOrgNameBObjExt> vecSurvivedOrgNameBOBj = new Vector<XOrgNameBObjExt>();
					Vector<XAddressGroupBObjExt> vecSurvivedPartyAddrBOBj = new Vector<XAddressGroupBObjExt>();
					Vector<XIdentifierBObjExt> vecSurvivedPartyIdenBOBj = new Vector<XIdentifierBObjExt>();
					Vector<XContactMethodGroupBObjExt> vecSurvivedPartyContMethBOBj = new Vector<XContactMethodGroupBObjExt>();
					Vector<XContEquivBObjExt> vecSurvivedPartyAdminContBOBj = new Vector<XContEquivBObjExt>();
				
					orgNameMap = finalOrgDetlsMap.get(ExternalRuleConstant.SURVIVED_MAP_NAME);
					partyAddressMap = finalOrgDetlsMap.get(ExternalRuleConstant.SURVIVED_MAP_ADDRESS);
					partyIdentMap = finalOrgDetlsMap.get(ExternalRuleConstant.SURVIVED_MAP_IDENTIFIER);
					partyContMethMap = finalOrgDetlsMap.get(ExternalRuleConstant.SURVIVED_MAP_CONTACTMETHOD);
					partyAdminConteqMap = finalOrgDetlsMap.get(ExternalRuleConstant.SURVIVED_MAP_CONTEQUIV);

					for (Map.Entry<String, XOrgNameBObjExt> entry : orgNameMap
							.entrySet()) {
						vecSurvivedOrgNameBOBj.add(entry.getValue());
					}
					for (Map.Entry<String, XAddressGroupBObjExt> entry : partyAddressMap
							.entrySet()) {
						vecSurvivedPartyAddrBOBj.add(entry.getValue());
					}

					for (Map.Entry<String, XIdentifierBObjExt> entry : partyIdentMap
							.entrySet()) {
						vecSurvivedPartyIdenBOBj.add(entry.getValue());
					}
					for (Map.Entry<String, XContactMethodGroupBObjExt> entry : partyContMethMap
							.entrySet()) {
						vecSurvivedPartyContMethBOBj.add(entry.getValue());
					}
					for (Map.Entry<String, XContEquivBObjExt> entry : partyAdminConteqMap
							.entrySet()) {
						vecSurvivedPartyAdminContBOBj.add(entry.getValue());
					}
					
					handlePrefAddress(vecSurvivedPartyAddrBOBj);

					handlePrefContactMethod(vecSurvivedPartyContMethBOBj);


					if (vecSurvivedOrgNameBOBj.size() > 0 || vecSurvivedOrgNameBOBj != null)
					{
						((XOrgBObjExt) survivedBOBj).getItemsTCRMOrganizationNameBObj().clear();
						((XOrgBObjExt) survivedBOBj).getItemsTCRMOrganizationNameBObj().addAll(vecSurvivedOrgNameBOBj);
					}

					if (vecSurvivedPartyAddrBOBj.size() > 0 || vecSurvivedPartyAddrBOBj != null)
					{
						((XOrgBObjExt) survivedBOBj).getItemsTCRMPartyAddressBObj().clear();
						((XOrgBObjExt) survivedBOBj).getItemsTCRMPartyAddressBObj().addAll(vecSurvivedPartyAddrBOBj);
					}

					if (vecSurvivedPartyIdenBOBj.size() > 0 || vecSurvivedPartyIdenBOBj != null)
					{
						((XOrgBObjExt) survivedBOBj).getItemsTCRMPartyIdentificationBObj().clear();
						((XOrgBObjExt) survivedBOBj).getItemsTCRMPartyIdentificationBObj().addAll(vecSurvivedPartyIdenBOBj);
					}

					if (vecSurvivedPartyContMethBOBj.size() > 0 || vecSurvivedPartyContMethBOBj != null) 
					{
						((XOrgBObjExt) survivedBOBj).getItemsTCRMPartyContactMethodBObj().clear();
						((XOrgBObjExt) survivedBOBj).getItemsTCRMPartyContactMethodBObj().addAll(vecSurvivedPartyContMethBOBj);
					}

					if (vecSurvivedPartyAdminContBOBj.size() > 0 || vecSurvivedPartyAdminContBOBj != null) 
					{
						((XOrgBObjExt) survivedBOBj).getItemsTCRMAdminContEquivBObj().clear();
						((XOrgBObjExt) survivedBOBj).getItemsTCRMAdminContEquivBObj().addAll(vecSurvivedPartyAdminContBOBj);
					}

					vecSurviveDWLCommons.add(survivedBOBj);

				}
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			DWLExceptionUtils.log(e);
		}

		return vecSurviveDWLCommons;
	}

	

	private static void handlePrefAddress(
			Vector<XAddressGroupBObjExt> vecSurvivedPersonAddrBOBj)
			throws Exception {

		XAddressGroupBObjExt tempAddrBObj = null;

		for (XAddressGroupBObjExt partyAddress : vecSurvivedPersonAddrBOBj) {

			Timestamp lastUpdatedt = DateFormatter.getTimestamp(partyAddress
					.getXLastModifiedSystemDate());
			String prefInd = partyAddress.getPreferredAddressIndicator();

			if (StringUtils.isNonBlank(prefInd)
					&& prefInd
							.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_Y)) {
				if (tempAddrBObj == null) {
					tempAddrBObj = partyAddress;
					continue;
				}

				if (DateFormatter.getTimestamp(
						tempAddrBObj.getXLastModifiedSystemDate()).before(
						lastUpdatedt)) {
					tempAddrBObj
							.setPreferredAddressIndicator(ExternalRuleConstant.CHARACTER_N);
					tempAddrBObj = partyAddress;
				} else {
					partyAddress
							.setPreferredAddressIndicator(ExternalRuleConstant.CHARACTER_N);
				}

			}
		}
	}

	private static void handlePrefContactMethod(
			Vector<XContactMethodGroupBObjExt> vecSurvivedPersonContMethBOBj)
			throws Exception {

		XContactMethodGroupBObjExt tempContMethodBObj = null;

		for (XContactMethodGroupBObjExt partyContMethodBObj : vecSurvivedPersonContMethBOBj) {

			Timestamp lastUpdatedt = DateFormatter
					.getTimestamp(partyContMethodBObj
							.getXLastModifiedSystemDate());
			String prefInd = partyContMethodBObj
					.getPreferredContactMethodIndicator();

			if (StringUtils.isNonBlank(prefInd)
					&& prefInd
							.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_Y)) {
				if (tempContMethodBObj == null) {
					tempContMethodBObj = partyContMethodBObj;
					continue;
				}

				if (DateFormatter.getTimestamp(
						tempContMethodBObj.getXLastModifiedSystemDate())
						.before(lastUpdatedt)) {
					tempContMethodBObj
							.setPreferredContactMethodIndicator(ExternalRuleConstant.CHARACTER_N);
					tempContMethodBObj = partyContMethodBObj;
				} else {
					partyContMethodBObj
							.setPreferredContactMethodIndicator(ExternalRuleConstant.CHARACTER_N);
				}

			}
		}
	}


	private static void surviveGenderDOBOccupation(DWLControl control,XPersonBObjExt survivedBOBj, Vector<TCRMPartyBObj> vecAllParty) {
		try{
			String firstSourceType = null;
			String secondSourceType = null;
			Timestamp latestCreatedDt = DateFormatter.getTimestamp(survivedBOBj.getXLastModifiedSystemDate());
			firstSourceType = survivedBOBj.getSourceIdentifierType();
			Timestamp tempCreatedDt = null;
			
			for(TCRMPartyBObj partyBObj : vecAllParty){
				XPersonBObjExt personBObj = (XPersonBObjExt) partyBObj;
				if(!personBObj.getPartyId().equals(survivedBOBj.getPartyId())){
					//DOB
					if(survivedBOBj.getBirthDate() == null ){
						if(personBObj.getBirthDate() != null){
							survivedBOBj.setBirthDate(personBObj.getBirthDate());
						}
					}
					
					//Occupation
					if(survivedBOBj.getXOccupationType() == null ){
						if(personBObj.getXOccupationType() != null){
							survivedBOBj.setXOccupationType(personBObj.getXOccupationType());
						}
					}
					
					///Gender
					if(survivedBOBj.getGenderType() == null ){
						if(personBObj.getGenderType() != null){
							survivedBOBj.setGenderType(personBObj.getGenderType());
						}
					}
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	//Change for Established date  Survivorship : 28th April
	
	private static void surviveEstablishedDate(DWLControl control,XOrgBObjExt survivedBOBj, Vector<TCRMPartyBObj> vecAllParty) {
		try{
			for(TCRMPartyBObj partyBObj : vecAllParty){
				XOrgBObjExt orgBObj = (XOrgBObjExt) partyBObj;
				if(!orgBObj.getPartyId().equals(survivedBOBj.getPartyId())){
					if(survivedBOBj.getEstablishedDate() == null ){
						if(orgBObj.getEstablishedDate() != null){
							survivedBOBj.setEstablishedDate(orgBObj.getEstablishedDate());
						}
					}
						
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}


	// Survived Sorted Parties method
	@SuppressWarnings("unchecked")
	public static XPersonBObjExt sortParties(Vector<TCRMPartyBObj> vecAllParty, XPersonBObjExt newParty, DWLControl control) throws Exception {
				
		Timestamp tempCreatedDt = null;
		Timestamp incomingCreatedDt = null;
		XPersonBObjExt tempPartyBObj = null;
		int index =0;
		String incomingPartySourceSystem = null;
		String tempPartySourceSystem = null;

		for (TCRMPartyBObj incomingParty : vecAllParty )
		{
			XPersonBObjExt incomingPersonBObj = (XPersonBObjExt) incomingParty;
			if(index == 0) {
				tempPartyBObj = incomingPersonBObj;
				index++;
				continue;
			}        	

			incomingCreatedDt = DateFormatter.getTimestamp(incomingPersonBObj.getXLastModifiedSystemDate());
			tempCreatedDt = DateFormatter.getTimestamp(tempPartyBObj.getXLastModifiedSystemDate());

			incomingPartySourceSystem = incomingPersonBObj.getSourceIdentifierType();
			tempPartySourceSystem = tempPartyBObj.getSourceIdentifierType();

			
			//If the suspect parties are from the same source system, survive the latest party
			if (incomingCreatedDt.after(tempCreatedDt)) {
				entityCRUDPerson(incomingParty, tempPartyBObj, control);
				tempPartyBObj = incomingPersonBObj;
			}else {
				entityCRUDPerson(tempPartyBObj, incomingParty, control);
			}
		
		}

		newParty.shallowClone(tempPartyBObj);

		return newParty;		
	}

	/**
	 * 
	 * @param incomingParty
	 * @param tempPartyBObj
	 * @param control
	 * @throws Exception
	 */
	public static void entityCRUDPerson(TCRMPartyBObj incomingParty,TCRMPartyBObj tempPartyBObj, DWLControl control) throws Exception {


		String prefLangType = null;
		String sourceIdentifierType = null;
		String sourceIdentifierValue = null;

		String prefLangValue = ((TCRMPersonBObj)tempPartyBObj).getPreferredLanguageValue();

		if(tempPartyBObj.getSourceIdentifierValue()!= null)
			sourceIdentifierValue = ((TCRMPersonBObj)tempPartyBObj).getSourceIdentifierValue();	

		prefLangType = ((TCRMPersonBObj)tempPartyBObj).getPreferredLanguageType();

		if(((TCRMPersonBObj)tempPartyBObj).getSourceIdentifierValue()!= null)
			sourceIdentifierType = ((TCRMPersonBObj)tempPartyBObj).getSourceIdentifierValue();

		//Preferred Language type
		if (((TCRMPersonBObj)incomingParty).getPreferredLanguageType() == null || ((TCRMPersonBObj)incomingParty).getPreferredLanguageType().isEmpty())
			((TCRMPersonBObj)incomingParty).setPreferredLanguageType(prefLangType);

		//Preferred Language Value
		if (((TCRMPersonBObj)incomingParty).getPreferredLanguageValue() == null || ((TCRMPersonBObj)incomingParty).getPreferredLanguageValue().isEmpty())
			((TCRMPersonBObj)incomingParty).setPreferredLanguageValue(((TCRMPersonBObj)tempPartyBObj).getPreferredLanguageValue());

		//Party Type
		if (((TCRMPersonBObj)incomingParty).getPartyType() == null || ((TCRMPersonBObj)incomingParty).getPartyType().isEmpty())
			((TCRMPersonBObj)incomingParty).setPartyType(((TCRMPersonBObj)tempPartyBObj).getPartyType());

		//CreatedDate
		if (((TCRMPersonBObj)incomingParty).getCreatedDate() == null || ((TCRMPersonBObj)incomingParty).getCreatedDate().isEmpty())
			((TCRMPersonBObj)incomingParty).setCreatedDate(((TCRMPersonBObj)tempPartyBObj).getCreatedDate());

		//Client Status Type
		if (((TCRMPersonBObj)incomingParty).getClientStatusType() == null || ((TCRMPersonBObj)incomingParty).getClientStatusType().isEmpty())
			((TCRMPersonBObj)incomingParty).setClientStatusType(((TCRMPersonBObj)tempPartyBObj).getClientStatusType());

		//Solicitation Indicator
		if (((TCRMPersonBObj)incomingParty).getSolicitationIndicator() == null || ((TCRMPersonBObj)incomingParty).getSolicitationIndicator().isEmpty())
			((TCRMPersonBObj)incomingParty).setSolicitationIndicator(((TCRMPersonBObj)tempPartyBObj).getSolicitationIndicator());

		//ConfidentialIndicator
		if (((TCRMPersonBObj)incomingParty).getConfidentialIndicator() == null || ((TCRMPersonBObj)incomingParty).getConfidentialIndicator().isEmpty())
			((TCRMPersonBObj)incomingParty).setConfidentialIndicator(((TCRMPersonBObj)tempPartyBObj).getConfidentialIndicator());

		//ClientImportanceType
		if (((TCRMPersonBObj)incomingParty).getConfidentialIndicator() == null || ((TCRMPersonBObj)incomingParty).getConfidentialIndicator().isEmpty())
			((TCRMPersonBObj)incomingParty).setConfidentialIndicator(((TCRMPersonBObj)tempPartyBObj).getConfidentialIndicator());

		//ClientImportanceValue
		if (((TCRMPersonBObj)incomingParty).getClientImportanceType() == null || ((TCRMPersonBObj)incomingParty).getClientImportanceType().isEmpty())
			((TCRMPersonBObj)incomingParty).setClientImportanceType(((TCRMPersonBObj)tempPartyBObj).getClientImportanceType());

		//Birth Date
		if (((TCRMPersonBObj)incomingParty).getBirthDate() == null || ((TCRMPersonBObj)incomingParty).getBirthDate().isEmpty())
			((TCRMPersonBObj)incomingParty).setBirthDate(((TCRMPersonBObj)tempPartyBObj).getBirthDate());

		//Gender
		if (((TCRMPersonBObj)incomingParty).getGenderType() == null || ((TCRMPersonBObj)incomingParty).getGenderType().isEmpty())
			((TCRMPersonBObj)incomingParty).setGenderType(((TCRMPersonBObj)tempPartyBObj).getGenderType());

		//Source Identifier Type
		if (((TCRMPersonBObj)incomingParty).getSourceIdentifierType() == null || ((TCRMPersonBObj)incomingParty).getSourceIdentifierType().isEmpty())
			((TCRMPersonBObj)incomingParty).setSourceIdentifierType(sourceIdentifierType);

		//Source Identifier Value
		if (((TCRMPersonBObj)incomingParty).getSourceIdentifierValue() == null || ((TCRMPersonBObj)incomingParty).getSourceIdentifierValue().isEmpty())
			((TCRMPersonBObj)incomingParty).setSourceIdentifierValue(((TCRMPersonBObj)tempPartyBObj).getSourceIdentifierValue());

		//Last Verified Date
		if (((TCRMPersonBObj)incomingParty).getLastVerifiedDate() == null || ((TCRMPersonBObj)incomingParty).getLastVerifiedDate().isEmpty())
			((TCRMPersonBObj)incomingParty).setLastVerifiedDate(((TCRMPersonBObj)tempPartyBObj).getLastVerifiedDate());

		XPersonBObjExt xincomingObj = (XPersonBObjExt)incomingParty;
		XPersonBObjExt xtempBobj = (XPersonBObjExt) tempPartyBObj;

		// Maintain XPerson attributes
		if(xincomingObj != null && xtempBobj != null)
			setXPersonAttr(xincomingObj, xtempBobj, control);

	}
	/**
	 * Method to set XPerson attributes
	 * @param xMainInputBOBj
	 * @param xDBinputBObj
	 * @param control
	 * @throws Exception
	 */
	public static void setXPersonAttr(XPersonBObjExt xMainInputBOBj, XPersonBObjExt xDBinputBObj, DWLControl control) throws Exception
	{
		//XDefunctInd
		if (xMainInputBOBj.getXDefunctInd() == null || xMainInputBOBj.getXDefunctInd().isEmpty())
			xMainInputBOBj.setXDefunctInd(xDBinputBObj.getXDefunctInd());

		//XEmployerName
		if (xMainInputBOBj.getXEmployerName() == null || xMainInputBOBj.getXEmployerName().isEmpty())
			xMainInputBOBj.setXEmployerName(xDBinputBObj.getXEmployerName());

		//XMarketName
		if (xMainInputBOBj.getXMarketName() == null || xMainInputBOBj.getXMarketName().isEmpty())
			xMainInputBOBj.setXMarketName(xDBinputBObj.getXMarketName());

		//XBatchInd
		if (xMainInputBOBj.getXBatchInd() == null || xMainInputBOBj.getXBatchInd().isEmpty())
			xMainInputBOBj.setXBatchInd(xDBinputBObj.getXBatchInd());

		//XOccupationType
		if (xMainInputBOBj.getXOccupationType() == null || xMainInputBOBj.getXOccupationType().isEmpty())
			xMainInputBOBj.setXOccupationType(xDBinputBObj.getXOccupationType());

		//XOccupationValue
		if (xMainInputBOBj.getXOccupationValue() == null || xMainInputBOBj.getXOccupationValue().isEmpty())
			xMainInputBOBj.setXOccupationValue(xDBinputBObj.getXOccupationValue());

		//XLastModifiedSystemDate
		if (xMainInputBOBj.getXLastModifiedSystemDate() == null || xMainInputBOBj.getXLastModifiedSystemDate().isEmpty())
			xMainInputBOBj.setXLastModifiedSystemDate(xDBinputBObj.getXLastModifiedSystemDate());

		//XGeneratedBy
		if (xMainInputBOBj.getXGeneratedBy() == null || xMainInputBOBj.getXGeneratedBy().isEmpty())
			xMainInputBOBj.setXGeneratedBy(xDBinputBObj.getXGeneratedBy());

		//XHobby
		if (xMainInputBOBj.getXHobby() == null || xMainInputBOBj.getXHobby().isEmpty())
			xMainInputBOBj.setXHobby(xDBinputBObj.getXHobby());

		//XPersonalAgreement
		if(xMainInputBOBj.getXPersonalAgreement() == null || xMainInputBOBj.getXPersonalAgreement().isEmpty())
			xMainInputBOBj.setXPersonalAgreement(xDBinputBObj.getXPersonalAgreement());
		
		//LastActivityDate
		if(xMainInputBOBj.getLastActivityDate() == null || xMainInputBOBj.getLastActivityDate().isEmpty())
			xMainInputBOBj.setLastActivityDate(xDBinputBObj.getLastActivityDate());


	}

	/**
	 * Method to survive person components
	 * @param vecAllParty
	 * @param control
	 * @return
	 * @throws Exception
	 */
	private static HashMap<String, HashMap> survivedPersonDetails(Vector vecAllParty,DWLControl control) throws Exception {

		HashMap<String, XPersonNameBObjExt> personNameMap = new HashMap<String, XPersonNameBObjExt>();
		HashMap<String, XAddressGroupBObjExt> partyAddressMap = new HashMap<String, XAddressGroupBObjExt>();
		HashMap<String, XIdentifierBObjExt> partyIdentMap = new HashMap<String, XIdentifierBObjExt>();
		HashMap<String, XContactMethodGroupBObjExt> partyContMethMap = new HashMap<String, XContactMethodGroupBObjExt>();
		HashMap<String, XContEquivBObjExt> partyAdminConteqMap = new HashMap<String, XContEquivBObjExt>();
		String mapKey = null;
		XContEquivBObjExt xcontEquivBobj = null;

		XPersonBObjExt incomingPersonBObj = (XPersonBObjExt) vecAllParty.get(0);

		if(ExternalRuleConstant.MARKET_NAME_TURKEY.equalsIgnoreCase(incomingPersonBObj.getXMarketName()))
		{
			for(int i=0; i < vecAllParty.size(); i++)
			{
				TCRMPartyBObj party = (TCRMPartyBObj) vecAllParty.get(i);
				
				//Person Name
				Vector<XPersonNameBObjExt> vecTempPersonNameBOBj = new Vector<XPersonNameBObjExt>();
				vecTempPersonNameBOBj = ((XPersonBObjExt) party).getItemsTCRMPersonNameBObj();
				survivePersonNameDetails(control, personNameMap, vecTempPersonNameBOBj);

				//Party Address
				Vector<XAddressGroupBObjExt> vecTempPartyAddressBObj = new Vector<XAddressGroupBObjExt>();
				vecTempPartyAddressBObj = party.getItemsTCRMPartyAddressBObj();
				surviveAddressDetails(control, partyAddressMap, vecTempPartyAddressBObj);

				//Contact Method
				Vector<XContactMethodGroupBObjExt> vecTempPartyContactMethodBObj = new Vector<XContactMethodGroupBObjExt>();
				vecTempPartyContactMethodBObj = party.getItemsTCRMPartyContactMethodBObj();	
				surviveContactMethodDetails(control, partyContMethMap, vecTempPartyContactMethodBObj);

				//ContEquiv
				Vector<XContEquivBObjExt> vecTempAdminContequivBObj =  new Vector<XContEquivBObjExt>();
				vecTempAdminContequivBObj = party.getItemsTCRMAdminContEquivBObj(); 
				surviveContEquivDetails(control, partyAdminConteqMap, vecTempAdminContequivBObj);
				
				if(partyAdminConteqMap.containsKey(ExternalRuleConstant.ADMIN_SYS_TYPE_SFDC))
				{
					xcontEquivBobj = partyAdminConteqMap.get(ExternalRuleConstant.ADMIN_SYS_TYPE_SFDC);
				}
				
				//Identification
				Vector<XIdentifierBObjExt> vecTempPartyIdentificationBObj = new Vector<XIdentifierBObjExt>();
				vecTempPartyIdentificationBObj = party.getItemsTCRMPartyIdentificationBObj();
				surviveIdentifierDetails(control, partyIdentMap, vecTempPartyIdentificationBObj,xcontEquivBobj);
				

			}
		}

		HashMap<String, HashMap> partyMap = new HashMap<String, HashMap>();
		partyMap.put(ExternalRuleConstant.SURVIVED_MAP_NAME, personNameMap);
		partyMap.put(ExternalRuleConstant.SURVIVED_MAP_ADDRESS, partyAddressMap);
		partyMap.put(ExternalRuleConstant.SURVIVED_MAP_IDENTIFIER, partyIdentMap);
		partyMap.put(ExternalRuleConstant.SURVIVED_MAP_CONTACTMETHOD, partyContMethMap);
		partyMap.put(ExternalRuleConstant.SURVIVED_MAP_CONTEQUIV, partyAdminConteqMap);

		return partyMap;

	}

	
	/**
	 * Method to survive Person Name Details
	 * @param control
	 * @param personNameMap
	 * @param vecTempPersonNameBOBj
	 * @throws Exception
	 */
	private static void survivePersonNameDetails(DWLControl control, HashMap<String, XPersonNameBObjExt> personNameMap, Vector<XPersonNameBObjExt> vecTempPersonNameBOBj) throws Exception {

		String firstPartyNameUsageType = null;
		String secondPartyNameUsageType = null;


		if(null!= vecTempPersonNameBOBj && vecTempPersonNameBOBj.size()>0)
		{
			for(int i=0; i<vecTempPersonNameBOBj.size(); i++)
			{
				XPersonNameBObjExt personnameBObj = (XPersonNameBObjExt) vecTempPersonNameBOBj.get(i);
				firstPartyNameUsageType = personnameBObj.getNameUsageType();

				if(!personNameMap.containsKey(firstPartyNameUsageType))
				{
					personNameMap.put(firstPartyNameUsageType, personnameBObj);
				}
				else
				{
					XPersonNameBObjExt nameBObjInMap = personNameMap.get(firstPartyNameUsageType);

					secondPartyNameUsageType = personnameBObj.getNameUsageType();

					Timestamp person1NameLastModifiedDate = DateFormatter.getTimestamp(nameBObjInMap.getXLastModifiedSystemDate());
					Timestamp person2NameLastModifiedDate = DateFormatter.getTimestamp(personnameBObj.getXLastModifiedSystemDate());
					
					//In case of clash survive the Latest
						if (null != person1NameLastModifiedDate && null != person2NameLastModifiedDate
								&& person1NameLastModifiedDate.after(person2NameLastModifiedDate)){
							personNameMap.put(secondPartyNameUsageType,nameBObjInMap);
						}else{
							personNameMap.put(firstPartyNameUsageType,personnameBObj);
						}
										
				}
			}
		}		
	}

	/**
	 * Method to survive Identifier details
	 * @param control
	 * @param partyIdentMap
	 * @param vecTempPartyIdentificationBObj
	 * @throws Exception
	 */
	private static void surviveIdentifierDetails(DWLControl control, HashMap<String, XIdentifierBObjExt> partyIdentMap, Vector<XIdentifierBObjExt> vecPartyIdentificationBObj, XContEquivBObjExt xcontEquivBobj) throws Exception {

		String firstPartyIdentificationType = null;
		String mapKey = null;


		if(null!= vecPartyIdentificationBObj && vecPartyIdentificationBObj.size()>0){
			for(XIdentifierBObjExt identifierBObj : vecPartyIdentificationBObj){
				
				firstPartyIdentificationType = identifierBObj.getIdentificationType();
				mapKey = firstPartyIdentificationType;
				if(!partyIdentMap.containsKey(firstPartyIdentificationType)){
					partyIdentMap.put(firstPartyIdentificationType,identifierBObj);
				}
				
				else{
					//In case of Type clash survive the Latest
					XIdentifierBObjExt identifierBObjInMap = partyIdentMap.get(firstPartyIdentificationType);
					String secondPartyIdentificationType = identifierBObjInMap.getIdentificationType();
					Timestamp person1IDLastModifiedDate = DateFormatter.getTimestamp(identifierBObj.getXLastModifiedSystemDate());
					Timestamp person2IDLastModifiedDate = DateFormatter.getTimestamp(identifierBObjInMap.getXLastModifiedSystemDate());
					
					if (firstPartyIdentificationType.equals(ExternalRuleConstant.ID_TYPE_UCID)) {
						// UCID survives on the basis of SFID(in pairs)
						if(null != xcontEquivBobj)
						{

							String survivedContID = xcontEquivBobj.getPartyId();

							if (survivedContID.equalsIgnoreCase(identifierBObj.getPartyId())) {
								// both belongs to same party
								mapKey = firstPartyIdentificationType;
								partyIdentMap.put(mapKey,identifierBObj);
							}
			
						}
						
						else
						{
							if (person2IDLastModifiedDate.before(person1IDLastModifiedDate)) {

								mapKey = secondPartyIdentificationType;

								partyIdentMap.put(mapKey, identifierBObjInMap);

							}

							else {
								mapKey = firstPartyIdentificationType;

								partyIdentMap.put(mapKey, identifierBObj);

							}
						}
					} 
					else
					{
						//Other then UCID latest Survives
							if(person1IDLastModifiedDate.after(person2IDLastModifiedDate)){
								partyIdentMap.put(mapKey, identifierBObj);
							}else{
								partyIdentMap.put(mapKey, identifierBObjInMap);
							}
				}
					
				}				
			}
		}
	}
	
	/**
	 * Method to survive party address details
	 * @param control
	 * @param partyAddressMap
	 * @param vecTempPartyAddressBObj
	 * @throws Exception
	 */
	private static  void surviveAddressDetails(DWLControl control, HashMap<String, XAddressGroupBObjExt> partyAddressMap, Vector<XAddressGroupBObjExt> vecTempPartyAddressBObj) throws Exception {


		
		String mapKey = null;
		
		if(null!= vecTempPartyAddressBObj && vecTempPartyAddressBObj.size()>0)
		{				
			for(XAddressGroupBObjExt wholesalePartyAddressBObj: vecTempPartyAddressBObj){
				mapKey = wholesalePartyAddressBObj.getAddressUsageType();				
				compareAndSurviveAddress(wholesalePartyAddressBObj,mapKey,partyAddressMap);				
			}
		}
	}

	private static void compareAndSurviveAddress(XAddressGroupBObjExt partyAddressBObj, String mapKey,HashMap<String, XAddressGroupBObjExt> partyAddressMap) throws Exception {
		try{
			
		if(!partyAddressMap.containsKey(mapKey)){
			partyAddressMap.put(mapKey,partyAddressBObj);
		}else{
			XAddressGroupBObjExt partyAddressBObjInMap = partyAddressMap.get(mapKey);		
			Timestamp party1AddrLastModifiedDt = DateFormatter.getTimestamp( partyAddressBObj.getXLastModifiedSystemDate());
			Timestamp party2AddrLastModifiedDt = DateFormatter.getTimestamp(partyAddressBObjInMap.getXLastModifiedSystemDate());		
			
				if(party1AddrLastModifiedDt.after(party2AddrLastModifiedDt)){
					partyAddressMap.put(mapKey, partyAddressBObj);
				}else{
					partyAddressMap.put(mapKey, partyAddressBObjInMap);
				}
						
		}
	}catch(Exception e){
		e.printStackTrace();
	}
	}

	/**
	 * Method to survive Contact Method Details
	 * @param control
	 * @param partyContMethMap
	 * @param vecTempPartyContactMethodBObj
	 * @throws Exception
	 */
	private static void surviveContactMethodDetails(DWLControl control, HashMap<String, XContactMethodGroupBObjExt> partyContMethMap, Vector<XContactMethodGroupBObjExt> vecTempPartyContactMethodBObj) throws Exception {

		String firstPartyContMethodUsageType = null;
		String secondPartyContMethodUsageType = null;

		if(null!= vecTempPartyContactMethodBObj && vecTempPartyContactMethodBObj.size()>0)
		{
			for(int i=0; i<vecTempPartyContactMethodBObj.size() ; i++)
			{
				XContactMethodGroupBObjExt partyContMethBObj = (XContactMethodGroupBObjExt) vecTempPartyContactMethodBObj.get(i);
				firstPartyContMethodUsageType = partyContMethBObj.getContactMethodUsageType();

				if(!partyContMethMap.containsKey(firstPartyContMethodUsageType))
				{
					partyContMethMap.put(firstPartyContMethodUsageType, partyContMethBObj);
				}
				else
				{
					XContactMethodGroupBObjExt contMethodBObjInMap = partyContMethMap.get(firstPartyContMethodUsageType);
					secondPartyContMethodUsageType = contMethodBObjInMap.getContactMethodUsageType();

					Timestamp party2ContMethModifiedDt = DateFormatter.getTimestamp(contMethodBObjInMap.getXLastModifiedSystemDate());
					Timestamp party1ContMethModifiedDt = DateFormatter.getTimestamp(partyContMethBObj.getXLastModifiedSystemDate());
									
					//LATEST SURVIVES
						if(party1ContMethModifiedDt.after(party2ContMethModifiedDt)){
							partyContMethMap.put(firstPartyContMethodUsageType ,partyContMethBObj );
						}else{
							partyContMethMap.put(secondPartyContMethodUsageType, contMethodBObjInMap);
						}
										
				}
			}
		}

	}

		/**
	 * Method to survive SFDC ID
	 * @param control
	 * @param partyAdminConteqMap
	 * @param vecTempAdminContequivBObj
	 * @throws Exception
	 */
	private static void surviveContEquivDetails(DWLControl control, HashMap<String, XContEquivBObjExt> partyAdminConteqMap, Vector<XContEquivBObjExt> vecTempAdminContequivBObj) throws Exception {

		String firstPartyAdminSysType = null;
		String mapKey = null;
		
		
		if(null!= vecTempAdminContequivBObj && vecTempAdminContequivBObj.size()>0)
		{
			for(XContEquivBObjExt tempAdminContequivBObj : vecTempAdminContequivBObj)
			{
				
				firstPartyAdminSysType = tempAdminContequivBObj.getAdminSystemType();
				mapKey = firstPartyAdminSysType;
				if(!partyAdminConteqMap.containsKey(firstPartyAdminSysType)){
					partyAdminConteqMap.put(firstPartyAdminSysType,tempAdminContequivBObj);
				}
				
				else{
					//In case of Type clash survive the Oldest SFID
					XContEquivBObjExt contEquivBObjInMap = partyAdminConteqMap.get(firstPartyAdminSysType);

					Timestamp person1IDLastModifiedDate = DateFormatter.getTimestamp(tempAdminContequivBObj.getXLastModifiedSystemDate());
					Timestamp person2IDLastModifiedDate = DateFormatter.getTimestamp(contEquivBObjInMap.getXLastModifiedSystemDate());
					
				
							if(null != person1IDLastModifiedDate && null !=person2IDLastModifiedDate
									&& person1IDLastModifiedDate.after(person2IDLastModifiedDate)){
								partyAdminConteqMap.put(mapKey, contEquivBObjInMap);
							}else{
								partyAdminConteqMap.put(mapKey, tempAdminContequivBObj);
							}
					
				}				
			}
			
		}		
	}

	/**
	 * Method to sort Organization details
	 * @param vecAllParty
	 * @param newParty
	 * @param control
	 * @return
	 * @throws Exception
	 */
	public static TCRMPartyBObj sortOrgParties(Vector<TCRMPartyBObj> vecAllParty, TCRMPartyBObj newParty, DWLControl control) throws Exception {
		

		Timestamp tempOrgLastModifiedDt = null;
		Timestamp incomingOrgLastModifiedDt = null;
		TCRMPartyBObj tempPartyBObj = null;
		int index =0;

		for (TCRMPartyBObj incomingParty : vecAllParty ) {
			XOrgBObjExt incomingOrgBObj = (XOrgBObjExt) incomingParty;
			if(index == 0) {
				tempPartyBObj = incomingParty;
				index++;
				continue;
			}

//			System.out.println("ORG LMSD" + incomingOrgBObj.getXLastModifiedSystemDate());
			incomingOrgLastModifiedDt = DateFormatter.getTimestamp(incomingOrgBObj.getXLastModifiedSystemDate());
			tempOrgLastModifiedDt = DateFormatter.getTimestamp(incomingOrgBObj.getXLastModifiedSystemDate());

			if (incomingOrgLastModifiedDt.after(tempOrgLastModifiedDt)) {

				entityCRUDOrg(incomingParty, tempPartyBObj, control);
				tempPartyBObj = incomingParty;
			}
			else {

				entityCRUDOrg(tempPartyBObj, incomingParty, control);
			}

		}

		newParty.shallowClone(tempPartyBObj);

		return newParty;		
	}

	/**
	 * Method to Survive the Organization attributes
	 * @param incomingParty
	 * @param tempPartyBObj
	 * @param control
	 * @throws Exception
	 */
	@SuppressWarnings("static-access")
	public static void entityCRUDOrg(TCRMPartyBObj incomingParty,
			TCRMPartyBObj tempPartyBObj, DWLControl control) throws Exception {
		// TODO Auto-generated method stub

		String prefLangType = null;
		String clientPotentialType = null;
		String sourceIdentifierType = null;
		String orgType = null;
		String industryType = null;

		String prefLangValue = ((XOrgBObjExt)tempPartyBObj).getPreferredLanguageValue();
		String sourceIdentifierValue = ((XOrgBObjExt)tempPartyBObj).getSourceIdentifierValue();
		String orgTypeValue = ((XOrgBObjExt)tempPartyBObj).getOrganizationValue();
		String industryTypeValue = ((XOrgBObjExt)tempPartyBObj).getIndustryValue();


		prefLangType = ((XOrgBObjExt)tempPartyBObj).getPreferredLanguageType();
		sourceIdentifierType =((XOrgBObjExt)tempPartyBObj).getSourceIdentifierType();
		orgType = orgTypeValue = ((XOrgBObjExt)tempPartyBObj).getOrganizationType();
		industryType = ((XOrgBObjExt)tempPartyBObj).getIndustryType();

		if (((XOrgBObjExt)incomingParty).getPreferredLanguageType() == null || ((XOrgBObjExt)incomingParty).getPreferredLanguageType().isEmpty()){
			((XOrgBObjExt)incomingParty).setPreferredLanguageType(prefLangType);
		}
		if (((XOrgBObjExt)incomingParty).getPreferredLanguageValue() == null || ((XOrgBObjExt)incomingParty).getPreferredLanguageValue().isEmpty()){
			((XOrgBObjExt)incomingParty).setPreferredLanguageValue(((XOrgBObjExt)tempPartyBObj).getPreferredLanguageValue());
		}
		if (((XOrgBObjExt)incomingParty).getClientPotentialType() == null || ((XOrgBObjExt)incomingParty).getClientPotentialType().isEmpty()){
			((XOrgBObjExt)incomingParty).setClientPotentialType(clientPotentialType);
		}
		if (((XOrgBObjExt)incomingParty).getClientPotentialValue() == null || ((XOrgBObjExt)incomingParty).getClientPotentialValue().isEmpty()){
			((XOrgBObjExt)incomingParty).setClientPotentialValue(((XOrgBObjExt)tempPartyBObj).getClientPotentialValue());
		}
		if (((XOrgBObjExt)incomingParty).getPartyType() == null || ((XOrgBObjExt)incomingParty).getPartyType().isEmpty()){
			((XOrgBObjExt)incomingParty).setPartyType(((XOrgBObjExt)tempPartyBObj).getPartyType());
		}
		if (((XOrgBObjExt)incomingParty).getSourceIdentifierType() == null || ((XOrgBObjExt)incomingParty).getSourceIdentifierType().isEmpty()){
			((XOrgBObjExt)incomingParty).setSourceIdentifierType(sourceIdentifierType);
		}
		if (((XOrgBObjExt)incomingParty).getSourceIdentifierValue() == null || ((XOrgBObjExt)incomingParty).getSourceIdentifierValue().isEmpty()){
			((XOrgBObjExt)incomingParty).setSourceIdentifierValue(((XOrgBObjExt)tempPartyBObj).getSourceIdentifierValue());
		}
		if (((XOrgBObjExt)incomingParty).getLastVerifiedDate() == null || ((XOrgBObjExt)incomingParty).getLastVerifiedDate().isEmpty()){
			((XOrgBObjExt)incomingParty).setLastVerifiedDate(((XOrgBObjExt)tempPartyBObj).getLastVerifiedDate());
		}
		if (((XOrgBObjExt)incomingParty).getOrganizationType() == null || ((XOrgBObjExt)incomingParty).getOrganizationType().isEmpty()){
			((XOrgBObjExt)incomingParty).setOrganizationType(orgType);
		}
		if (((XOrgBObjExt)incomingParty).getOrganizationValue() == null || ((XOrgBObjExt)incomingParty).getOrganizationValue().isEmpty()){
			((XOrgBObjExt)incomingParty).setOrganizationValue(((XOrgBObjExt)tempPartyBObj).getOrganizationValue());
		}
		if (((XOrgBObjExt)incomingParty).getIndustryType() == null || ((XOrgBObjExt)incomingParty).getIndustryType().isEmpty()){
			((XOrgBObjExt)incomingParty).setIndustryType(industryType);
		}
		if (((XOrgBObjExt)incomingParty).getIndustryValue() == null || ((XOrgBObjExt)incomingParty).getIndustryValue().isEmpty()){
			((XOrgBObjExt)incomingParty).setIndustryValue(((XOrgBObjExt)tempPartyBObj).getIndustryValue());
		}

		XOrgBObjExt xincomingObj = (XOrgBObjExt)incomingParty;
		XOrgBObjExt xtempBobj = (XOrgBObjExt) tempPartyBObj;

		// maintain xorg attributes

		if(xincomingObj != null && xtempBobj != null){

			setXOrgAttr(xincomingObj, xtempBobj, control);

		}

	}
	public static void setXOrgAttr(XOrgBObjExt xMainInputBOBj,XOrgBObjExt xDBinputBObj, DWLControl control) throws Exception
	{
		//XDefunctInd
		if (xMainInputBOBj.getXDefunctInd() == null || xMainInputBOBj.getXDefunctInd().isEmpty())
			xMainInputBOBj.setXDefunctInd(xDBinputBObj.getXDefunctInd());
		
		//XWebsite
		if (xMainInputBOBj.getXWebsite() == null || xMainInputBOBj.getXWebsite().isEmpty())
			xMainInputBOBj.setXWebsite(xDBinputBObj.getXWebsite());
		
		//XMarketName
		if (xMainInputBOBj.getXMarketName() == null || xMainInputBOBj.getXMarketName().isEmpty())
			xMainInputBOBj.setXMarketName(xDBinputBObj.getXMarketName());
		
		//XBatchInd
		if (xMainInputBOBj.getXBatchInd() == null || xMainInputBOBj.getXBatchInd().isEmpty())
			xMainInputBOBj.setXBatchInd(xDBinputBObj.getXBatchInd());
		
		//XNumberOfEmployeesType
		if (xMainInputBOBj.getXNumberOfEmployeesType() == null || xMainInputBOBj.getXNumberOfEmployeesType().isEmpty())
			xMainInputBOBj.setXNumberOfEmployeesType(xDBinputBObj.getXNumberOfEmployeesType());
		
		//XNumberOfEmployeesValue
		if (xMainInputBOBj.getXNumberOfEmployeesValue() == null || xMainInputBOBj.getXNumberOfEmployeesValue().isEmpty())
			xMainInputBOBj.setXNumberOfEmployeesValue(xDBinputBObj.getXNumberOfEmployeesValue());
		
		//XLastModifiedSystemDate
		if (xMainInputBOBj.getXLastModifiedSystemDate() == null || xMainInputBOBj.getXLastModifiedSystemDate().isEmpty())
			xMainInputBOBj.setXLastModifiedSystemDate(xDBinputBObj.getXLastModifiedSystemDate());
		
		//XGenerated_by
		if (xMainInputBOBj.getXGenerated_by() == null || xMainInputBOBj.getXGenerated_by().isEmpty())
			xMainInputBOBj.setXGenerated_by(xDBinputBObj.getXGenerated_by());
		
		//XCorporateCategoryType
		if (xMainInputBOBj.getXCorporateCategoryType() == null || xMainInputBOBj.getXCorporateCategoryType().isEmpty())
			xMainInputBOBj.setXCorporateCategoryType(xDBinputBObj.getXCorporateCategoryType());
		
		//XCorporateCategoryValue
		if (xMainInputBOBj.getXCorporateCategoryValue() == null || xMainInputBOBj.getXCorporateCategoryValue().isEmpty())
			xMainInputBOBj.setXCorporateCategoryValue(xDBinputBObj.getXCorporateCategoryValue());
		
		//XCorporateGroupType
		if (xMainInputBOBj.getXCorporateGroupType() == null || xMainInputBOBj.getXCorporateGroupType().isEmpty())
			xMainInputBOBj.setXCorporateGroupType(xDBinputBObj.getXCorporateGroupType());
		
		//XCorporateGroupValue
		if (xMainInputBOBj.getXCorporateGroupValue() == null || xMainInputBOBj.getXCorporateGroupValue().isEmpty())
			xMainInputBOBj.setXCorporateGroupValue(xDBinputBObj.getXCorporateGroupValue());
		
		//XPersonalAgreement
		if(xMainInputBOBj.getXPersonalAgreement() == null || xMainInputBOBj.getXPersonalAgreement().isEmpty())
			xMainInputBOBj.setXPersonalAgreement(xDBinputBObj.getXPersonalAgreement());
		
		//LastActivityDate
		if(xMainInputBOBj.getLastActivityDate() == null || xMainInputBOBj.getLastActivityDate().isEmpty())
			xMainInputBOBj.setLastActivityDate(xDBinputBObj.getLastActivityDate());

		
	}
	
	private static HashMap<String, HashMap> survivedOrgDetails(Vector vecAllParty,DWLControl control) throws Exception {
		HashMap<String, XOrgNameBObjExt> orgNameMap = new HashMap<String, XOrgNameBObjExt>();
		HashMap<String, XAddressGroupBObjExt> partyAddressMap = new HashMap<String, XAddressGroupBObjExt>();
		HashMap<String, XIdentifierBObjExt> partyIdentMap = new HashMap<String, XIdentifierBObjExt>();
		HashMap<String, XContactMethodGroupBObjExt> partyContMethMap = new HashMap<String, XContactMethodGroupBObjExt>();
		HashMap<String, XContEquivBObjExt> partyAdminConteqMap = new HashMap<String, XContEquivBObjExt>();
		String mapKey = null;
		XContEquivBObjExt xcontEquivBobj = null;

		XOrgBObjExt incomingOrgBObj = (XOrgBObjExt) vecAllParty.get(0);

		if(ExternalRuleConstant.MARKET_NAME_TURKEY.equalsIgnoreCase(incomingOrgBObj.getXMarketName()))
		{
			for(int i=0; i < vecAllParty.size(); i++)
			{
				TCRMPartyBObj party = (TCRMPartyBObj) vecAllParty.get(i);

				//Org Name
				Vector<XOrgNameBObjExt> vecTempOrgNameBOBj = new Vector<XOrgNameBObjExt>();
				vecTempOrgNameBOBj = ((XOrgBObjExt) party).getItemsTCRMOrganizationNameBObj();
				surviveOrgNameDetails(control, orgNameMap, vecTempOrgNameBOBj);

				//Address
				Vector<XAddressGroupBObjExt> vecTempPartyAddressBObj = new Vector<XAddressGroupBObjExt>();
				vecTempPartyAddressBObj = party.getItemsTCRMPartyAddressBObj();
				surviveAddressDetails(control, partyAddressMap, vecTempPartyAddressBObj);
				
				//Contact Method
				Vector<XContactMethodGroupBObjExt> vecTempPartyContactMethodBObj = new Vector<XContactMethodGroupBObjExt>();
				vecTempPartyContactMethodBObj = party.getItemsTCRMPartyContactMethodBObj();	
				surviveContactMethodDetails(control, partyContMethMap, vecTempPartyContactMethodBObj);

				//Admin Contequiv
				Vector<XContEquivBObjExt> vecTempAdminContequivBObj =  new Vector<XContEquivBObjExt>();
				vecTempAdminContequivBObj = party.getItemsTCRMAdminContEquivBObj();
				surviveContEquivDetails(control, partyAdminConteqMap, vecTempAdminContequivBObj);
				
				if(partyAdminConteqMap.containsKey(ExternalRuleConstant.ADMIN_SYS_TYPE_SFDC))
				{
					xcontEquivBobj = partyAdminConteqMap.get(ExternalRuleConstant.ADMIN_SYS_TYPE_SFDC);
				}
				
				//Identifier
				Vector<XIdentifierBObjExt> vecTempPartyIdentificationBObj = new Vector<XIdentifierBObjExt>();
				vecTempPartyIdentificationBObj = party.getItemsTCRMPartyIdentificationBObj();
				surviveIdentifierDetails(control, partyIdentMap, vecTempPartyIdentificationBObj, xcontEquivBobj);

			}
		}

		HashMap<String, HashMap> partyMap = new HashMap<String, HashMap>();
		partyMap.put(ExternalRuleConstant.SURVIVED_MAP_NAME, orgNameMap);
		partyMap.put(ExternalRuleConstant.SURVIVED_MAP_ADDRESS, partyAddressMap);
		partyMap.put(ExternalRuleConstant.SURVIVED_MAP_IDENTIFIER, partyIdentMap);
		partyMap.put(ExternalRuleConstant.SURVIVED_MAP_CONTACTMETHOD, partyContMethMap);
		partyMap.put(ExternalRuleConstant.SURVIVED_MAP_CONTEQUIV, partyAdminConteqMap);

		return partyMap;

	}
	
	/**
	 * Method to survive Person Name Details
	 * @param control
	 * @param personNameMap
	 * @param vecTempPersonNameBOBj
	 * @throws Exception
	 */
	private static void surviveOrgNameDetails(DWLControl control, HashMap<String, XOrgNameBObjExt> orgNameMap, Vector<XOrgNameBObjExt> vecTempOrgNameBOBj) throws Exception {

		String firstPartyNameUsageType = null;
		String secondPartyNameUsageType = null;


		if(null!= vecTempOrgNameBOBj && vecTempOrgNameBOBj.size()>0)
		{
			for(int i=0; i<vecTempOrgNameBOBj.size(); i++)
			{
				XOrgNameBObjExt orgnameBObj = (XOrgNameBObjExt) vecTempOrgNameBOBj.get(i);
				firstPartyNameUsageType = orgnameBObj.getNameUsageType();

				if(!orgNameMap.containsKey(firstPartyNameUsageType))
				{
					orgNameMap.put(firstPartyNameUsageType, orgnameBObj);
				}
				else
				{
					//If Key Present in map go for survivorship on the basis of last modified date
					XOrgNameBObjExt nameBObjInMap = orgNameMap.get(firstPartyNameUsageType);
					secondPartyNameUsageType = nameBObjInMap.getNameUsageType();

					Timestamp org1NameLastModifiedDate = DateFormatter.getTimestamp(nameBObjInMap.getXLastModifiedSystemDate());
					Timestamp org2NameLastModifiedDate = DateFormatter.getTimestamp(orgnameBObj.getXLastModifiedSystemDate());
					
						//ReArchTHAMYS: Changed from Source Priority to modified date
						if (org1NameLastModifiedDate.after(org2NameLastModifiedDate)){
							orgNameMap.put(secondPartyNameUsageType,nameBObjInMap);
						}else{
							orgNameMap.put(firstPartyNameUsageType,orgnameBObj);
						}
										
				}
			}
		}		
	}


}
