package com.ibm.daimler.dsea.extrules.sdp;

import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.Vector;

import com.dwl.base.DWLCommon;
import com.dwl.base.DWLControl;
import com.dwl.base.constant.DWLControlKeys;
import com.dwl.base.db.SQLQuery;
import com.dwl.base.exception.DWLBaseException;
import com.dwl.base.util.DWLClassFactory;
import com.dwl.base.util.DWLExceptionUtils;
import com.dwl.management.ManagementException;
import com.dwl.management.config.client.Configuration;
import com.dwl.management.config.repository.ConfigurationRepositoryException;
import com.dwl.tcrm.coreParty.component.TCRMAdminContEquivBObj;
import com.dwl.tcrm.coreParty.component.TCRMPartyBObj;
import com.dwl.tcrm.coreParty.component.TCRMPartyPrivPrefBObj;
import com.dwl.tcrm.coreParty.component.TCRMPersonBObj;
import com.dwl.tcrm.coreParty.component.TCRMPersonNameBObj;
import com.dwl.tcrm.utilities.DateFormatter;
import com.dwl.tcrm.utilities.StringUtils;
import com.dwl.unifi.tx.exception.BusinessProxyException;
import com.ibm.daimler.dsea.component.XAddressBObjExt;
import com.ibm.daimler.dsea.component.XAddressGroupBObjExt;
import com.ibm.daimler.dsea.component.XContEquivBObjExt;
import com.ibm.daimler.dsea.component.XContactMethodGroupBObjExt;
import com.ibm.daimler.dsea.component.XIdentifierBObjExt;
import com.ibm.daimler.dsea.component.XOrgBObjExt;
import com.ibm.daimler.dsea.component.XOrgNameBObjExt;
import com.ibm.daimler.dsea.component.XPersonBObjExt;
import com.ibm.daimler.dsea.component.XPersonNameBObjExt;
import com.ibm.daimler.dsea.component.XPreferenceBObj;
import com.ibm.daimler.dsea.component.XPrivacyAgreementBObj;


import com.ibm.daimler.dsea.extrules.constant.ExternalRuleConstant;
import com.ibm.mdm.common.codetype.interfaces.CodeTypeComponentHelper;
import com.ibm.mdm.common.codetype.obj.CodeTypeBObj;

public class SurvivorshipRuleUtil {

	@SuppressWarnings("unchecked")
	public Vector collapseObjectsSurvivingRules(Vector vecDWLCommons, boolean bReturnTheMostRecentRootBObjOnly) throws DWLBaseException {
		Vector vecSurviveDWLCommons = new Vector();
		try {
			DWLCommon source = (DWLCommon) vecDWLCommons.get(0);

			TCRMPartyBObj newParty = null;
			
			String personOrgCode = null;

			if (source instanceof TCRMPartyBObj) {

				DWLControl control = source.getControl();

				@SuppressWarnings("rawtypes")
				Vector<TCRMPartyBObj> vecAllParty = new Vector<TCRMPartyBObj>();

				TCRMPartyBObj firstparty = (TCRMPartyBObj) vecDWLCommons.get(0);
				
				personOrgCode = firstparty.getPartyType();

				newParty = (TCRMPartyBObj) Class.forName(firstparty.getClass().getName()).newInstance();
				
				// For Person Entity
				if(personOrgCode.equalsIgnoreCase(ExternalRuleConstant.PERSON_ORG_CODE_P)){
					
				Collections.sort(vecDWLCommons, new Comparator<XPersonBObjExt>() {//Ascending sort - for delta load
					public int compare(XPersonBObjExt party1, XPersonBObjExt party2) {
						if (party1.getXLastModifiedSystemDate() == null || party2.getXLastModifiedSystemDate() == null)
						return 0;
						return party1.getXLastModifiedSystemDate().compareTo(party2.getXLastModifiedSystemDate());
					}
				});
				Collections.reverse(vecDWLCommons);//Descending sort
				Iterator itParty = vecDWLCommons.iterator();
				while (itParty.hasNext()) {

					TCRMPartyBObj newParty1 = new TCRMPartyBObj();
					newParty1 = (TCRMPartyBObj) itParty.next();
					vecAllParty.add(newParty1);
				}

				XPersonBObjExt newPartyBObj = (XPersonBObjExt) newParty;

				XPersonBObjExt survivedBOBj = sortParties(vecAllParty,newPartyBObj, control);
				// -------------------Start FS Changes

				// Set FS Gender and DOB FS, if any FS object is present as
				// suspect
				setFSGenderAndDOB(survivedBOBj, vecAllParty, control);

				// -------------------End FS Changes

				HashMap<String, HashMap> finalPersonDetlsMap = survivedPersonDetails(vecAllParty, control);
				
				HashMap<String, XPersonNameBObjExt> personNameMap = new HashMap<String, XPersonNameBObjExt>();
				HashMap<String, XAddressGroupBObjExt> partyAddressMap = new HashMap<String, XAddressGroupBObjExt>();
				HashMap<String, XIdentifierBObjExt> partyIdentMap = new HashMap<String, XIdentifierBObjExt>();
				HashMap<String, XContactMethodGroupBObjExt> partyContMethMap = new HashMap<String, XContactMethodGroupBObjExt>();
				HashMap<String, TCRMAdminContEquivBObj> partyAdminConteqMap = new HashMap<String, TCRMAdminContEquivBObj>();
				HashMap<String, TCRMPartyPrivPrefBObj> partyPrivacyPrefMap = new HashMap<String, TCRMPartyPrivPrefBObj>();
				Vector<XPersonNameBObjExt> vecSurvivedPersonNameBOBj = new Vector<XPersonNameBObjExt>();
				Vector<XAddressGroupBObjExt> vecSurvivedPartyAddrBOBj = new Vector<XAddressGroupBObjExt>();
				Vector<XIdentifierBObjExt> vecSurvivedPartyIdenBOBj = new Vector<XIdentifierBObjExt>();
				Vector<XContactMethodGroupBObjExt> vecSurvivedPartyContMethBOBj = new Vector<XContactMethodGroupBObjExt>();
				Vector<TCRMAdminContEquivBObj> vecSurvivedPartyAdminContBOBj = new Vector<TCRMAdminContEquivBObj>();
				Vector<TCRMPartyPrivPrefBObj> vecSurvivedPartyPrivacyPrefBOBj = new Vector<TCRMPartyPrivPrefBObj>();

				personNameMap = finalPersonDetlsMap.get(ExternalRuleConstant.SURVIVED_MAP_NAME);
				partyAddressMap = finalPersonDetlsMap.get(ExternalRuleConstant.SURVIVED_MAP_ADDRESS);
				partyIdentMap = finalPersonDetlsMap.get(ExternalRuleConstant.SURVIVED_MAP_IDENTIFIER);
				partyContMethMap = finalPersonDetlsMap.get(ExternalRuleConstant.SURVIVED_MAP_CONTACTMETHOD);
				partyAdminConteqMap = finalPersonDetlsMap.get(ExternalRuleConstant.SURVIVED_MAP_CONTEQUIV);
				

				for (Map.Entry<String, XPersonNameBObjExt> entry : personNameMap.entrySet()) {
					vecSurvivedPersonNameBOBj.add(entry.getValue());
				}
				for (Map.Entry<String, XAddressGroupBObjExt> entry : partyAddressMap.entrySet()) {
					vecSurvivedPartyAddrBOBj.add(entry.getValue());
				}

				for (Map.Entry<String, XIdentifierBObjExt> entry : partyIdentMap.entrySet()) {
					vecSurvivedPartyIdenBOBj.add(entry.getValue());
				}
				for (Map.Entry<String, XContactMethodGroupBObjExt> entry : partyContMethMap.entrySet()) {
					vecSurvivedPartyContMethBOBj.add(entry.getValue());
				}
				// prod issue fix dupplicate record exists: changes done by ankit
				//FSChange: THA Delta modification for the above fix | 19/11/2020
				for(XContactMethodGroupBObjExt contactMethodGroupBObjExt : vecSurvivedPartyContMethBOBj){
					String contMethodBPID = contactMethodGroupBObjExt.getX_BPID();
					if(ExternalRuleConstant.FS_VALUE.equalsIgnoreCase(contactMethodGroupBObjExt.getXContactRetailerFlag())
							&& null != contMethodBPID){
						contactMethodGroupBObjExt.setContactMethodComments(contMethodBPID+ExternalRuleConstant.FS_VALUE);
					}
				}
				//end
				
				for (Map.Entry<String, TCRMAdminContEquivBObj> entry : partyAdminConteqMap.entrySet()) {
					vecSurvivedPartyAdminContBOBj.add(entry.getValue());
				}
				
				for (Map.Entry<String, TCRMPartyPrivPrefBObj> entry : partyPrivacyPrefMap.entrySet()) {
					vecSurvivedPartyPrivacyPrefBOBj.add(entry.getValue());
				}
				 
				//Change for Preferred Address Indicator 05-12-2017
				handlePrefAddress(vecSurvivedPartyAddrBOBj);
				
				//Change for Preferred Contact Method Indicator 05-12-2017
				handlePrefContactMethod(vecSurvivedPartyContMethBOBj);
				
				if (vecSurvivedPersonNameBOBj.size() > 0 || vecSurvivedPersonNameBOBj != null) {

					((TCRMPersonBObj) survivedBOBj).getItemsTCRMPersonNameBObj().clear();
					((TCRMPersonBObj) survivedBOBj).getItemsTCRMPersonNameBObj().addAll(vecSurvivedPersonNameBOBj);
				}
				if (vecSurvivedPartyAddrBOBj.size() > 0 || vecSurvivedPartyAddrBOBj != null) {
					((TCRMPersonBObj) survivedBOBj).getItemsTCRMPartyAddressBObj().clear();
					((TCRMPersonBObj) survivedBOBj).getItemsTCRMPartyAddressBObj().addAll(vecSurvivedPartyAddrBOBj);
				}
				if (vecSurvivedPartyIdenBOBj.size() > 0 || vecSurvivedPartyIdenBOBj != null) {

					((TCRMPersonBObj) survivedBOBj).getItemsTCRMPartyIdentificationBObj().clear();
					((TCRMPersonBObj) survivedBOBj).getItemsTCRMPartyIdentificationBObj().addAll(vecSurvivedPartyIdenBOBj);
				}
				if (vecSurvivedPartyContMethBOBj.size() > 0 || vecSurvivedPartyContMethBOBj != null) {
					((TCRMPersonBObj) survivedBOBj).getItemsTCRMPartyContactMethodBObj().clear();
					((TCRMPersonBObj) survivedBOBj).getItemsTCRMPartyContactMethodBObj().addAll(vecSurvivedPartyContMethBOBj);
				}
				if (vecSurvivedPartyAdminContBOBj.size() > 0 || vecSurvivedPartyAdminContBOBj != null) {
					((TCRMPersonBObj) survivedBOBj).getItemsTCRMAdminContEquivBObj().clear();
					((TCRMPersonBObj) survivedBOBj).getItemsTCRMAdminContEquivBObj().addAll(vecSurvivedPartyAdminContBOBj);
				}
				if (vecSurvivedPartyPrivacyPrefBOBj.size() > 0 || vecSurvivedPartyPrivacyPrefBOBj != null) {
					((TCRMPersonBObj) survivedBOBj).getItemsTCRMPartyPrivPrefBObj().clear();
					((TCRMPersonBObj) survivedBOBj).getItemsTCRMPartyPrivPrefBObj().addAll(vecSurvivedPartyPrivacyPrefBOBj);
				}

				vecSurviveDWLCommons.add(survivedBOBj);
				
				}
				
				//For Org Entity
				
				if(personOrgCode.equalsIgnoreCase(ExternalRuleConstant.PERSON_ORG_CODE_O)){

					Collections.sort(vecDWLCommons, new Comparator<XOrgBObjExt>() {//Ascending sort - for delta load
						public int compare(XOrgBObjExt party1, XOrgBObjExt party2) {
							if (party1.getXLastModifiedSystemDate() == null || party2.getXLastModifiedSystemDate() == null)
							return 0;
							return party1.getXLastModifiedSystemDate().compareTo(party2.getXLastModifiedSystemDate());
						}
					});
					Collections.reverse(vecDWLCommons);//Descending sort
					Iterator itParty = vecDWLCommons.iterator();
					while (itParty.hasNext()) {

						TCRMPartyBObj newParty1 = new TCRMPartyBObj();
						newParty1 = (TCRMPartyBObj) itParty.next();
						vecAllParty.add(newParty1);
					}
					
					TCRMPartyBObj survivedBOBj = sortOrgParties(vecAllParty,newParty, control);

					HashMap<String, HashMap> finalOrgDetlsMap = survivedOrgDetails(
							vecAllParty, control);
					HashMap<String, XOrgNameBObjExt> orgNameMap = new HashMap<String, XOrgNameBObjExt>();
					HashMap<String, XAddressGroupBObjExt> partyAddressMap = new HashMap<String, XAddressGroupBObjExt>();
					HashMap<String, XIdentifierBObjExt> partyIdentMap = new HashMap<String, XIdentifierBObjExt>();
					HashMap<String, XContactMethodGroupBObjExt> partyContMethMap = new HashMap<String, XContactMethodGroupBObjExt>();
					HashMap<String, TCRMAdminContEquivBObj> partyAdminConteqMap = new HashMap<String, TCRMAdminContEquivBObj>();
					HashMap<String, TCRMAdminContEquivBObj> partyAdminConteqMap1 = new HashMap<String, TCRMAdminContEquivBObj>();
					HashMap<String, TCRMPartyPrivPrefBObj> partyPrivacyPrefMap = new HashMap<String, TCRMPartyPrivPrefBObj>();
					Vector<XOrgNameBObjExt> vecSurvivedOrgNameBOBj = new Vector<XOrgNameBObjExt>();
					Vector<XAddressGroupBObjExt> vecSurvivedPartyAddrBOBj = new Vector<XAddressGroupBObjExt>();
					Vector<XIdentifierBObjExt> vecSurvivedPartyIdenBOBj = new Vector<XIdentifierBObjExt>();
					Vector<XContactMethodGroupBObjExt> vecSurvivedPartyContMethBOBj = new Vector<XContactMethodGroupBObjExt>();
					Vector<TCRMAdminContEquivBObj> vecSurvivedPartyAdminContBOBj = new Vector<TCRMAdminContEquivBObj>();
					Vector<TCRMAdminContEquivBObj> vecSurvivedPartyAdminContBOBj1 = new Vector<TCRMAdminContEquivBObj>();
					Vector<TCRMPartyPrivPrefBObj> vecSurvivedPartyPrivacyPrefBOBj = new Vector<TCRMPartyPrivPrefBObj>();

					orgNameMap = finalOrgDetlsMap.get(ExternalRuleConstant.SURVIVED_MAP_NAME);
					partyAddressMap = finalOrgDetlsMap.get(ExternalRuleConstant.SURVIVED_MAP_ADDRESS);
					partyIdentMap = finalOrgDetlsMap.get(ExternalRuleConstant.SURVIVED_MAP_IDENTIFIER);
					partyContMethMap = finalOrgDetlsMap.get(ExternalRuleConstant.SURVIVED_MAP_CONTACTMETHOD);
					partyAdminConteqMap = finalOrgDetlsMap.get(ExternalRuleConstant.SURVIVED_MAP_CONTEQUIV);

					for (Map.Entry<String, XOrgNameBObjExt> entry : orgNameMap
							.entrySet()) {
						vecSurvivedOrgNameBOBj.add(entry.getValue());
					}
					for (Map.Entry<String, XAddressGroupBObjExt> entry : partyAddressMap
							.entrySet()) {
						vecSurvivedPartyAddrBOBj.add(entry.getValue());
					}

					for (Map.Entry<String, XIdentifierBObjExt> entry : partyIdentMap
							.entrySet()) {
						vecSurvivedPartyIdenBOBj.add(entry.getValue());
					}
					for (Map.Entry<String, XContactMethodGroupBObjExt> entry : partyContMethMap
							.entrySet()) {
						vecSurvivedPartyContMethBOBj.add(entry.getValue());
					}
					// prod issue fix dupplicate record exists: changes done by ankit
					//FSChange: THA Delta modification for the above fix | 19/11/2020
					for(XContactMethodGroupBObjExt contactMethodGroupBObjExt : vecSurvivedPartyContMethBOBj){
						String contMethodBPID = contactMethodGroupBObjExt.getX_BPID();
						if(ExternalRuleConstant.FS_VALUE.equalsIgnoreCase(contactMethodGroupBObjExt.getXContactRetailerFlag())
								&& null != contMethodBPID){
							contactMethodGroupBObjExt.setContactMethodComments(contMethodBPID+ExternalRuleConstant.FS_VALUE);
						}
					}
					//end
					for (Map.Entry<String, TCRMAdminContEquivBObj> entry : partyAdminConteqMap
							.entrySet()) {
						vecSurvivedPartyAdminContBOBj.add(entry.getValue());
					}
					for (Map.Entry<String, TCRMAdminContEquivBObj> entry : partyAdminConteqMap1
							.entrySet()) {
						vecSurvivedPartyAdminContBOBj1.add(entry.getValue());
					}
					for (Map.Entry<String, TCRMPartyPrivPrefBObj> entry : partyPrivacyPrefMap
							.entrySet()) {
						vecSurvivedPartyPrivacyPrefBOBj.add(entry.getValue());
					}
					
					//Change for Preferred Address Indicator 05-12-2017
					handlePrefAddress(vecSurvivedPartyAddrBOBj);
					
					//Change for Preferred Contact Method Indicator 05-12-2017
					handlePrefContactMethod(vecSurvivedPartyContMethBOBj);

					if (vecSurvivedOrgNameBOBj.size() > 0
							|| vecSurvivedOrgNameBOBj != null) {

						((XOrgBObjExt) survivedBOBj)
								.getItemsTCRMOrganizationNameBObj().clear();
						((XOrgBObjExt) survivedBOBj)
								.getItemsTCRMOrganizationNameBObj().addAll(
										vecSurvivedOrgNameBOBj);
					}
					if (vecSurvivedPartyAddrBOBj.size() > 0
							|| vecSurvivedPartyAddrBOBj != null) {
						((XOrgBObjExt) survivedBOBj)
								.getItemsTCRMPartyAddressBObj().clear();
						((XOrgBObjExt) survivedBOBj)
								.getItemsTCRMPartyAddressBObj().addAll(
										vecSurvivedPartyAddrBOBj);
					}
					if (vecSurvivedPartyIdenBOBj.size() > 0
							|| vecSurvivedPartyIdenBOBj != null) {

						((XOrgBObjExt) survivedBOBj)
								.getItemsTCRMPartyIdentificationBObj().clear();
						((XOrgBObjExt) survivedBOBj)
								.getItemsTCRMPartyIdentificationBObj().addAll(
										vecSurvivedPartyIdenBOBj);
					}
					if (vecSurvivedPartyContMethBOBj.size() > 0
							|| vecSurvivedPartyContMethBOBj != null) {
						((XOrgBObjExt) survivedBOBj)
								.getItemsTCRMPartyContactMethodBObj().clear();
						((XOrgBObjExt) survivedBOBj)
								.getItemsTCRMPartyContactMethodBObj().addAll(
										vecSurvivedPartyContMethBOBj);
					}
					if (vecSurvivedPartyAdminContBOBj.size() > 0
							|| vecSurvivedPartyAdminContBOBj != null) {
						((XOrgBObjExt) survivedBOBj)
								.getItemsTCRMAdminContEquivBObj().clear();
						((XOrgBObjExt) survivedBOBj)
								.getItemsTCRMAdminContEquivBObj().addAll(
										vecSurvivedPartyAdminContBOBj);
					}
					if (vecSurvivedPartyAdminContBOBj1.size() > 0
							|| vecSurvivedPartyAdminContBOBj1 != null) {
						((XOrgBObjExt) survivedBOBj)
								.getItemsTCRMAdminContEquivBObj().addAll(
										vecSurvivedPartyAdminContBOBj1);
					}
					if (vecSurvivedPartyPrivacyPrefBOBj.size() > 0
							|| vecSurvivedPartyPrivacyPrefBOBj != null) {
						((XOrgBObjExt) survivedBOBj)
								.getItemsTCRMPartyPrivPrefBObj().clear();
						((XOrgBObjExt) survivedBOBj)
								.getItemsTCRMPartyPrivPrefBObj().addAll(
										vecSurvivedPartyPrivacyPrefBOBj);
					}

					vecSurviveDWLCommons.add(survivedBOBj);
					
					}
			}
		} catch (Exception e) {
			DWLExceptionUtils.log(e);

		}
		return vecSurviveDWLCommons;

	}

	// -------------------Start FS Changes Loveleen-------------------------//
	private void setFSGenderAndDOB(XPersonBObjExt survivedBOBj,
			Vector<TCRMPartyBObj> vecAllParty, DWLControl control)
			throws Exception {
		// Parties are sorted in Descending order of Last Modified date

		// Vector<XPersonBObjExt> vecFSPersonBobj = new
		// Vector<XPersonBObjExt>();
		Boolean isDOBAndGenderSet = false;

		Boolean isDOBSet = false;

		Boolean isGenderSet = false;

		survivedBOBj.setControl(control);

		for (TCRMPartyBObj suspectPartyBObj : vecAllParty) {

			XPersonBObjExt suspectPersonBobj = (XPersonBObjExt) suspectPartyBObj;

			if (!isDOBAndGenderSet) {

				if (!isDOBSet && suspectPersonBobj.getXBirthDateFS() != null) {

					survivedBOBj.setXBirthDateFS(suspectPersonBobj
							.getXBirthDateFS());
					survivedBOBj.setBirthDate(suspectPersonBobj.getXBirthDateFS());

					isDOBSet = true;

				}

				if (!isGenderSet && suspectPersonBobj.getXGenderFS() != null) {

					survivedBOBj.setXGenderFS(suspectPersonBobj.getXGenderFS());
					survivedBOBj.setGenderType(suspectPersonBobj.getXGenderFS());
					isGenderSet = true;

				}
			}

		}

	}

	// -------------------End FS Changes Loveleen-------------------------//

	// Survived Sorterd Parties method
	@SuppressWarnings("unchecked")
	public XPersonBObjExt sortParties(Vector<TCRMPartyBObj> vecAllParty, XPersonBObjExt newParty, DWLControl control) throws Exception {

		 Timestamp tempCreatedDt = null;
		 Timestamp incomingCreatedDt = null;
		 XPersonBObjExt tempPartyBObj = null;
		 int index =0;

        for (TCRMPartyBObj incomingParty : vecAllParty ) {
        	XPersonBObjExt incomingPersonBObj = (XPersonBObjExt) incomingParty;
        	if(index == 0) {
        		tempPartyBObj = incomingPersonBObj;
        		index++;
        		continue;
        	}        	
        		
    		incomingCreatedDt = DateFormatter.getTimestamp(incomingPersonBObj.getXLastModifiedSystemDate());
    		tempCreatedDt = DateFormatter.getTimestamp(tempPartyBObj.getXLastModifiedSystemDate());

			if (incomingCreatedDt.after(tempCreatedDt)) {
				
				entityCRUDPerson(incomingParty, tempPartyBObj, control);
				tempPartyBObj = incomingPersonBObj;
			}
			else {
				
				entityCRUDPerson(tempPartyBObj, incomingParty, control);
			}
        	
        }

		newParty.shallowClone(tempPartyBObj);
		
		return newParty;
	}
	
	// For Org Sort Parties
	
		@SuppressWarnings("unchecked")
	public TCRMPartyBObj sortOrgParties(Vector<TCRMPartyBObj> vecAllParty, TCRMPartyBObj newParty, DWLControl control) throws Exception {

		 Timestamp tempCreatedDt = null;
		 Timestamp incomingCreatedDt = null;
		 TCRMPartyBObj tempPartyBObj = null;
		 int index =0;

        for (TCRMPartyBObj incomingParty : vecAllParty ) {
        	XOrgBObjExt incomingOrgBObj = (XOrgBObjExt) incomingParty;
        	if(index == 0) {
        		tempPartyBObj = incomingParty;
        		index++;
        		continue;
        	}
        	
        		
    		incomingCreatedDt = DateFormatter.getTimestamp(incomingOrgBObj.getXLastModifiedSystemDate());
    		tempCreatedDt = DateFormatter.getTimestamp(incomingOrgBObj.getXLastModifiedSystemDate());

			if (incomingCreatedDt.after(tempCreatedDt)) {
				
				entityCRUDOrg(incomingParty, tempPartyBObj, control);
				tempPartyBObj = incomingParty;
			}
			else {
				
				entityCRUDOrg(tempPartyBObj, incomingParty, control);
			}
        	
        }

		newParty.shallowClone(tempPartyBObj);
		
		return newParty;
	}
	
		public void sortPartyAddresses(Vector<XAddressGroupBObjExt> vecRetailPartyAddressBObj, XAddressGroupBObjExt newPartyAddressBObj, DWLControl control) throws Exception {
			if(vecRetailPartyAddressBObj.size() != 0){
				//Descending order
				Collections.sort(vecRetailPartyAddressBObj, new Comparator<XAddressGroupBObjExt>() {
					public int compare(XAddressGroupBObjExt party1, XAddressGroupBObjExt party2) {
						if (party1.getXLastModifiedSystemDate() == null || party2.getXLastModifiedSystemDate() == null)
						return 0;
						return party1.getXLastModifiedSystemDate().compareTo(party2.getXLastModifiedSystemDate());
					}
				});
				Collections.reverse(vecRetailPartyAddressBObj);//Descending sort
			}
		}
		
		public void sortPartyAddressesAsc(Vector<XAddressGroupBObjExt> vecRetailPartyAddressBObj, XAddressGroupBObjExt newPartyAddressBObj, DWLControl control) throws Exception {

			//ascending order
			Collections.sort(vecRetailPartyAddressBObj, new Comparator<XAddressGroupBObjExt>() {
				public int compare(XAddressGroupBObjExt party1, XAddressGroupBObjExt party2) {
					if (party1.getXLastModifiedSystemDate() == null || party2.getXLastModifiedSystemDate() == null)
					return 0;
					return party1.getXLastModifiedSystemDate().compareTo(party2.getXLastModifiedSystemDate());
				}
			});
		}


		
		public void entityCRUDAddress(XAddressGroupBObjExt incomingPartyAddressBObj, XAddressGroupBObjExt tempPartyAddressBObj, DWLControl control) throws Exception{
			//AddressUsageType
			if (incomingPartyAddressBObj.getAddressUsageType() == null || incomingPartyAddressBObj.getAddressUsageType().isEmpty()){
				incomingPartyAddressBObj.setAddressUsageType(tempPartyAddressBObj.getAddressUsageType());
			}
			//AddressUsageValue
			if (incomingPartyAddressBObj.getAddressUsageValue() == null || incomingPartyAddressBObj.getAddressUsageValue().isEmpty()){
				incomingPartyAddressBObj.setAddressUsageValue(tempPartyAddressBObj.getAddressUsageValue());
			}
			//StartDate
			if (incomingPartyAddressBObj.getStartDate() == null || incomingPartyAddressBObj.getStartDate().isEmpty()){
				incomingPartyAddressBObj.setStartDate(tempPartyAddressBObj.getStartDate());
			}
			//PreferredAddressIndicator
			if (incomingPartyAddressBObj.getPreferredAddressIndicator() == null || incomingPartyAddressBObj.getPreferredAddressIndicator().isEmpty()){
				incomingPartyAddressBObj.setPreferredAddressIndicator(tempPartyAddressBObj.getPreferredAddressIndicator());
			}
			//SourceIdentifierType
			if (incomingPartyAddressBObj.getSourceIdentifierType() == null || incomingPartyAddressBObj.getSourceIdentifierType().isEmpty()){
				incomingPartyAddressBObj.setSourceIdentifierType(tempPartyAddressBObj.getSourceIdentifierType());
			}
			//SourceIdentifierValue
			if (incomingPartyAddressBObj.getSourceIdentifierValue() == null || incomingPartyAddressBObj.getSourceIdentifierValue().isEmpty()){
				incomingPartyAddressBObj.setSourceIdentifierValue(tempPartyAddressBObj.getSourceIdentifierValue());
			}
			
			//--XAddressGroupBObj Attributes
			//XVerifiedType
			if (incomingPartyAddressBObj.getXVerifiedType() == null || incomingPartyAddressBObj.getXVerifiedType().isEmpty()){
				incomingPartyAddressBObj.setXVerifiedType(tempPartyAddressBObj.getXVerifiedType());
			}
			//XVerifiedValue
			if (incomingPartyAddressBObj.getXVerifiedValue() == null || incomingPartyAddressBObj.getXVerifiedValue().isEmpty()){
				incomingPartyAddressBObj.setXVerifiedValue(tempPartyAddressBObj.getXVerifiedValue());
			}
			//XLastModifiedSystemDate
			if (incomingPartyAddressBObj.getXLastModifiedSystemDate() == null || incomingPartyAddressBObj.getXLastModifiedSystemDate().isEmpty()){
				incomingPartyAddressBObj.setXLastModifiedSystemDate(tempPartyAddressBObj.getXLastModifiedSystemDate());
			}
			//XAddressRetailerFlag
			if (incomingPartyAddressBObj.getXAddressRetailerFlag() == null || incomingPartyAddressBObj.getXAddressRetailerFlag().isEmpty()){
				incomingPartyAddressBObj.setXAddressRetailerFlag(tempPartyAddressBObj.getXAddressRetailerFlag());
			}
			
			//--XPrivacyAgreementBObj
			//ActionType
			if (incomingPartyAddressBObj.getXPrivacyAgreementBObj().getActionType() == null || incomingPartyAddressBObj.getXPrivacyAgreementBObj().getActionType().isEmpty()){
				incomingPartyAddressBObj.getXPrivacyAgreementBObj().setActionType(tempPartyAddressBObj.getXPrivacyAgreementBObj().getActionType());
			}
			//ActionValue
			if (incomingPartyAddressBObj.getXPrivacyAgreementBObj().getActionValue() == null || incomingPartyAddressBObj.getXPrivacyAgreementBObj().getActionValue().isEmpty()){
				incomingPartyAddressBObj.getXPrivacyAgreementBObj().setActionValue(tempPartyAddressBObj.getXPrivacyAgreementBObj().getActionValue());
			}
			//SourceIdentifierType
			if (incomingPartyAddressBObj.getXPrivacyAgreementBObj().getSourceIdentifierType() == null || incomingPartyAddressBObj.getXPrivacyAgreementBObj().getSourceIdentifierType().isEmpty()){
				incomingPartyAddressBObj.getXPrivacyAgreementBObj().setSourceIdentifierType(tempPartyAddressBObj.getXPrivacyAgreementBObj().getSourceIdentifierType());
			}
			//SourceIdentifierValue
			if (incomingPartyAddressBObj.getXPrivacyAgreementBObj().getSourceIdentifierValue() == null || incomingPartyAddressBObj.getXPrivacyAgreementBObj().getSourceIdentifierValue().isEmpty()){
				incomingPartyAddressBObj.getXPrivacyAgreementBObj().setSourceIdentifierValue(tempPartyAddressBObj.getXPrivacyAgreementBObj().getSourceIdentifierValue());
			}
			//StartDate
			if (incomingPartyAddressBObj.getXPrivacyAgreementBObj().getStartDate() == null || incomingPartyAddressBObj.getXPrivacyAgreementBObj().getStartDate().isEmpty()){
				incomingPartyAddressBObj.getXPrivacyAgreementBObj().setStartDate(tempPartyAddressBObj.getXPrivacyAgreementBObj().getStartDate());
			}
			//EndDate
			if (incomingPartyAddressBObj.getXPrivacyAgreementBObj().getEndDate() == null || incomingPartyAddressBObj.getXPrivacyAgreementBObj().getEndDate().isEmpty()){
				incomingPartyAddressBObj.getXPrivacyAgreementBObj().setEndDate(tempPartyAddressBObj.getXPrivacyAgreementBObj().getEndDate());
			}
			//LastModifiedSystemDate
			if (incomingPartyAddressBObj.getXPrivacyAgreementBObj().getLastModifiedSystemDate() == null || incomingPartyAddressBObj.getXPrivacyAgreementBObj().getLastModifiedSystemDate().isEmpty()){
				incomingPartyAddressBObj.getXPrivacyAgreementBObj().setLastModifiedSystemDate(tempPartyAddressBObj.getXPrivacyAgreementBObj().getLastModifiedSystemDate());
			}
			
		}
	
	@SuppressWarnings("static-access")
	public void entityCRUDPerson(TCRMPartyBObj incomingParty,TCRMPartyBObj tempPartyBObj, DWLControl control) throws Exception {
		// TODO Auto-generated method stub
		
		String prefLangType = null;
		String sourceIdentifierType = null;
		String sourceIdentifierValue = null;
		
		String prefLangValue = ((TCRMPersonBObj)tempPartyBObj).getPreferredLanguageValue();
		if(tempPartyBObj.getSourceIdentifierValue()!= null)
			sourceIdentifierValue = ((TCRMPersonBObj)tempPartyBObj).getSourceIdentifierValue();	
		
		prefLangType = ((TCRMPersonBObj)tempPartyBObj).getPreferredLanguageType();
		if(((TCRMPersonBObj)tempPartyBObj).getSourceIdentifierValue()!= null)
			sourceIdentifierType = ((TCRMPersonBObj)tempPartyBObj).getSourceIdentifierValue();
		
		//Preferred Language type
		if (((TCRMPersonBObj)incomingParty).getPreferredLanguageType() == null || ((TCRMPersonBObj)incomingParty).getPreferredLanguageType().isEmpty()){
			((TCRMPersonBObj)incomingParty).setPreferredLanguageType(prefLangType);
		}
		//Preferred Language Value
		if (((TCRMPersonBObj)incomingParty).getPreferredLanguageValue() == null || ((TCRMPersonBObj)incomingParty).getPreferredLanguageValue().isEmpty()){
			((TCRMPersonBObj)incomingParty).setPreferredLanguageValue(((TCRMPersonBObj)tempPartyBObj).getPreferredLanguageValue());
		}
		//Party Type
		if (((TCRMPersonBObj)incomingParty).getPartyType() == null || ((TCRMPersonBObj)incomingParty).getPartyType().isEmpty()){
			((TCRMPersonBObj)incomingParty).setPartyType(((TCRMPersonBObj)tempPartyBObj).getPartyType());
		}
		//CreatedDate
		if (((TCRMPersonBObj)incomingParty).getCreatedDate() == null || ((TCRMPersonBObj)incomingParty).getCreatedDate().isEmpty()){
			((TCRMPersonBObj)incomingParty).setCreatedDate(((TCRMPersonBObj)tempPartyBObj).getCreatedDate());
		}
		//Client Status Type
		if (((TCRMPersonBObj)incomingParty).getClientStatusType() == null || ((TCRMPersonBObj)incomingParty).getClientStatusType().isEmpty()){
			((TCRMPersonBObj)incomingParty).setClientStatusType(((TCRMPersonBObj)tempPartyBObj).getClientStatusType());
		}
		//Solicitation Indicator
		if (((TCRMPersonBObj)incomingParty).getSolicitationIndicator() == null || ((TCRMPersonBObj)incomingParty).getSolicitationIndicator().isEmpty()){
			((TCRMPersonBObj)incomingParty).setSolicitationIndicator(((TCRMPersonBObj)tempPartyBObj).getSolicitationIndicator());
		}
		//ConfidentialIndicator
		if (((TCRMPersonBObj)incomingParty).getConfidentialIndicator() == null || ((TCRMPersonBObj)incomingParty).getConfidentialIndicator().isEmpty()){
			((TCRMPersonBObj)incomingParty).setConfidentialIndicator(((TCRMPersonBObj)tempPartyBObj).getConfidentialIndicator());
		}
		//ClientImportanceType
		if (((TCRMPersonBObj)incomingParty).getConfidentialIndicator() == null || ((TCRMPersonBObj)incomingParty).getConfidentialIndicator().isEmpty()){
			((TCRMPersonBObj)incomingParty).setConfidentialIndicator(((TCRMPersonBObj)tempPartyBObj).getConfidentialIndicator());
		}
		//ClientImportanceValue
		if (((TCRMPersonBObj)incomingParty).getClientImportanceType() == null || ((TCRMPersonBObj)incomingParty).getClientImportanceType().isEmpty()){
			((TCRMPersonBObj)incomingParty).setClientImportanceType(((TCRMPersonBObj)tempPartyBObj).getClientImportanceType());
		}	
		//Birth Date
		if (((TCRMPersonBObj)incomingParty).getBirthDate() == null || ((TCRMPersonBObj)incomingParty).getBirthDate().isEmpty()){
			((TCRMPersonBObj)incomingParty).setBirthDate(((TCRMPersonBObj)tempPartyBObj).getBirthDate());
		}
		//Gender
		if (((TCRMPersonBObj)incomingParty).getGenderType() == null || ((TCRMPersonBObj)incomingParty).getGenderType().isEmpty()){
			((TCRMPersonBObj)incomingParty).setGenderType(((TCRMPersonBObj)tempPartyBObj).getGenderType());
		}
		//Source Identifier Type
		if (((TCRMPersonBObj)incomingParty).getSourceIdentifierType() == null || ((TCRMPersonBObj)incomingParty).getSourceIdentifierType().isEmpty()){
			((TCRMPersonBObj)incomingParty).setSourceIdentifierType(sourceIdentifierType);
		}
		//Source Identifier Value
		if (((TCRMPersonBObj)incomingParty).getSourceIdentifierValue() == null || ((TCRMPersonBObj)incomingParty).getSourceIdentifierValue().isEmpty()){
			((TCRMPersonBObj)incomingParty).setSourceIdentifierValue(((TCRMPersonBObj)tempPartyBObj).getSourceIdentifierValue());
		}
		//Last Verified Date
		if (((TCRMPersonBObj)incomingParty).getLastVerifiedDate() == null || ((TCRMPersonBObj)incomingParty).getLastVerifiedDate().isEmpty()){
			((TCRMPersonBObj)incomingParty).setLastVerifiedDate(((TCRMPersonBObj)tempPartyBObj).getLastVerifiedDate());
		}
		
		XPersonBObjExt xincomingObj = (XPersonBObjExt)incomingParty;
		XPersonBObjExt xtempBobj = (XPersonBObjExt) tempPartyBObj;

		// maintain xperson attributes
		
		if(xincomingObj != null && xtempBobj != null){
			
		setXPersonAttr(xincomingObj, xtempBobj, control);
		
		}
	    
	}
	//For Org Entity and Extesnion Survivorship
	
	
	@SuppressWarnings("static-access")
	public void entityCRUDOrg(TCRMPartyBObj incomingParty,
			TCRMPartyBObj tempPartyBObj, DWLControl control) throws Exception {
		// TODO Auto-generated method stub
		
		String prefLangType = null;
		String clientPotentialType = null;
		String sourceIdentifierType = null;
		String orgType = null;
		String industryType = null;
		
		String prefLangValue = ((XOrgBObjExt)tempPartyBObj).getPreferredLanguageValue();
		String sourceIdentifierValue = ((XOrgBObjExt)tempPartyBObj).getSourceIdentifierValue();
		String orgTypeValue = ((XOrgBObjExt)tempPartyBObj).getOrganizationValue();
		String industryTypeValue = ((XOrgBObjExt)tempPartyBObj).getIndustryValue();
		
		
		prefLangType = ((XOrgBObjExt)tempPartyBObj).getPreferredLanguageType();
		sourceIdentifierType =((XOrgBObjExt)tempPartyBObj).getSourceIdentifierType();
		orgType = orgTypeValue = ((XOrgBObjExt)tempPartyBObj).getOrganizationType();
		industryType = ((XOrgBObjExt)tempPartyBObj).getIndustryType();
		
		if (((XOrgBObjExt)incomingParty).getPreferredLanguageType() == null || ((XOrgBObjExt)incomingParty).getPreferredLanguageType().isEmpty()){
			((XOrgBObjExt)incomingParty).setPreferredLanguageType(prefLangType);
		}
		if (((XOrgBObjExt)incomingParty).getPreferredLanguageValue() == null || ((XOrgBObjExt)incomingParty).getPreferredLanguageValue().isEmpty()){
			((XOrgBObjExt)incomingParty).setPreferredLanguageValue(((XOrgBObjExt)tempPartyBObj).getPreferredLanguageValue());
		}
		if (((XOrgBObjExt)incomingParty).getClientPotentialType() == null || ((XOrgBObjExt)incomingParty).getClientPotentialType().isEmpty()){
			((XOrgBObjExt)incomingParty).setClientPotentialType(clientPotentialType);
		}
		if (((XOrgBObjExt)incomingParty).getClientPotentialValue() == null || ((XOrgBObjExt)incomingParty).getClientPotentialValue().isEmpty()){
			((XOrgBObjExt)incomingParty).setClientPotentialValue(((XOrgBObjExt)tempPartyBObj).getClientPotentialValue());
		}
		if (((XOrgBObjExt)incomingParty).getPartyType() == null || ((XOrgBObjExt)incomingParty).getPartyType().isEmpty()){
			((XOrgBObjExt)incomingParty).setPartyType(((XOrgBObjExt)tempPartyBObj).getPartyType());
		}
		if (((XOrgBObjExt)incomingParty).getSourceIdentifierType() == null || ((XOrgBObjExt)incomingParty).getSourceIdentifierType().isEmpty()){
			((XOrgBObjExt)incomingParty).setSourceIdentifierType(sourceIdentifierType);
		}
		if (((XOrgBObjExt)incomingParty).getSourceIdentifierValue() == null || ((XOrgBObjExt)incomingParty).getSourceIdentifierValue().isEmpty()){
			((XOrgBObjExt)incomingParty).setSourceIdentifierValue(((XOrgBObjExt)tempPartyBObj).getSourceIdentifierValue());
		}
		if (((XOrgBObjExt)incomingParty).getLastVerifiedDate() == null || ((XOrgBObjExt)incomingParty).getLastVerifiedDate().isEmpty()){
			((XOrgBObjExt)incomingParty).setLastVerifiedDate(((XOrgBObjExt)tempPartyBObj).getLastVerifiedDate());
		}
		if (((XOrgBObjExt)incomingParty).getOrganizationType() == null || ((XOrgBObjExt)incomingParty).getOrganizationType().isEmpty()){
			((XOrgBObjExt)incomingParty).setOrganizationType(orgType);
		}
		if (((XOrgBObjExt)incomingParty).getOrganizationValue() == null || ((XOrgBObjExt)incomingParty).getOrganizationValue().isEmpty()){
			((XOrgBObjExt)incomingParty).setOrganizationValue(((XOrgBObjExt)tempPartyBObj).getOrganizationValue());
		}
		if (((XOrgBObjExt)incomingParty).getIndustryType() == null || ((XOrgBObjExt)incomingParty).getIndustryType().isEmpty()){
			((XOrgBObjExt)incomingParty).setIndustryType(industryType);
		}
		if (((XOrgBObjExt)incomingParty).getIndustryValue() == null || ((XOrgBObjExt)incomingParty).getIndustryValue().isEmpty()){
			((XOrgBObjExt)incomingParty).setIndustryValue(((XOrgBObjExt)tempPartyBObj).getIndustryValue());
		}
		
		XOrgBObjExt xincomingObj = (XOrgBObjExt)incomingParty;
		XOrgBObjExt xtempBobj = (XOrgBObjExt) tempPartyBObj;

		// maintain xorg attributes
		
		if(xincomingObj != null && xtempBobj != null){
			
		setXOrgAttr(xincomingObj, xtempBobj, control);
		
		}
	    
	}
	
	// Survived PersonDetails method
	@SuppressWarnings("unchecked")
	private HashMap<String, HashMap> survivedPersonDetails(Vector vecAllParty,DWLControl control) throws Exception {
		// TODO Auto-generated method stub

		HashMap<String, XPersonNameBObjExt> personNameMap = new HashMap<String, XPersonNameBObjExt>();
		HashMap<String, XAddressGroupBObjExt> partyAddressMap = new HashMap<String, XAddressGroupBObjExt>();
		HashMap<String, XIdentifierBObjExt> partyIdentMap = new HashMap<String, XIdentifierBObjExt>();
		HashMap<String, XContactMethodGroupBObjExt> partyContMethMap = new HashMap<String, XContactMethodGroupBObjExt>();
		HashMap<String, TCRMAdminContEquivBObj> partyAdminConteqMap = new HashMap<String, TCRMAdminContEquivBObj>();
		String mapKey = null;
		int counter = 1;
		XPersonBObjExt incomingPersonBObj = (XPersonBObjExt) vecAllParty.get(0);
		
		

		if (incomingPersonBObj.getXBatchInd().equalsIgnoreCase(ExternalRuleConstant.BATCH_IND_Y)
				&& incomingPersonBObj.getXMarketName().equalsIgnoreCase(ExternalRuleConstant.MARKET_NAME_MALAYSIA)
				&& incomingPersonBObj.getSourceIdentifierType().equalsIgnoreCase(ExternalRuleConstant.SOURCE_IDENTIFIER_TYPE_AUTOLINE)) {
			// Latest record will survive

			// INI - MYS - AL

			for (int i = 0; i < vecAllParty.size(); i++) {
				
				TCRMPartyBObj party = (TCRMPartyBObj) vecAllParty.get(i);
				Vector<XPersonNameBObjExt> vecTempPersonNameBOBj = new Vector<XPersonNameBObjExt>();
				vecTempPersonNameBOBj = ((XPersonBObjExt) party).getItemsTCRMPersonNameBObj();
				String firstPartyNameUsageType = null;
				String secondPartyNameUsageType = null;
				// For Person Names
				for (int j = 0; j < vecTempPersonNameBOBj.size(); j++) {
	
					XPersonNameBObjExt personnameBObj = (XPersonNameBObjExt) vecTempPersonNameBOBj.get(j);
					firstPartyNameUsageType = personnameBObj.getNameUsageType();
					if (!personNameMap.containsKey(firstPartyNameUsageType)) {
						personNameMap.put(firstPartyNameUsageType, personnameBObj);
					} else {
						XPersonNameBObjExt nameBObjInMap = personNameMap.get(firstPartyNameUsageType);
						secondPartyNameUsageType = personnameBObj.getNameUsageType();
						Timestamp person1CreatedDt = DateFormatter.getTimestamp(nameBObjInMap.getXLastModifiedSystemDate());
						Timestamp person2CreatedDt = DateFormatter.getTimestamp(personnameBObj.getXLastModifiedSystemDate());
						
						if(firstPartyNameUsageType.equalsIgnoreCase(secondPartyNameUsageType)){
							if (person1CreatedDt.after(person2CreatedDt)) {
								personNameMap.put(secondPartyNameUsageType,nameBObjInMap);
							}
							else {     
								personNameMap.put(firstPartyNameUsageType,personnameBObj);
							}
							
						}
						
						
					}
				}
				//For Party Identification
			
				Vector<XIdentifierBObjExt> vecTempPartyIdentificationBObj = new Vector<XIdentifierBObjExt>();
	
				vecTempPartyIdentificationBObj = party.getItemsTCRMPartyIdentificationBObj();
				
				String firstPartyIdentificationType = null;
				
				String secondPartyIdentificationType = null;
				
				String firstRetailerId = null;
				
				String secondRetailerId = null;
				
				XIdentifierBObjExt xIdenBObj = null;
						
				for (int j = 0; j < vecTempPartyIdentificationBObj.size(); j++) {
	
					XIdentifierBObjExt partyIdenBObj = (XIdentifierBObjExt) vecTempPartyIdentificationBObj.get(j);
					
					firstPartyIdentificationType = partyIdenBObj.getIdentificationType();
					
					firstRetailerId = partyIdenBObj.getXRetailerId();
					
					if(firstPartyIdentificationType.equalsIgnoreCase(ExternalRuleConstant.ID_TYPE_MAGIC)){
						mapKey = firstPartyIdentificationType + firstRetailerId;
					} else {
						mapKey = firstPartyIdentificationType;
					}

					if (!partyIdentMap.containsKey(mapKey)) {

						partyIdentMap.put(mapKey, partyIdenBObj);

					} else {

						XIdentifierBObjExt idenBObjInMap = partyIdentMap.get(mapKey);

						// secondPartyIdentificationValue =
						// idenBObjInMap.getIdentificationValue();

						secondPartyIdentificationType = idenBObjInMap.getIdentificationType();

						secondRetailerId = idenBObjInMap.getXRetailerId();

						if (firstPartyIdentificationType.equalsIgnoreCase(secondPartyIdentificationType)) {

							if (firstPartyIdentificationType.equals(ExternalRuleConstant.ID_TYPE_UCID)) {
								// UCID
								Timestamp party1CreatedDt = DateFormatter.getTimestamp(idenBObjInMap.getXLastModifiedSystemDate());

								Timestamp party2CreatedDt = DateFormatter.getTimestamp(partyIdenBObj.getXLastModifiedSystemDate());
								// Oldest record survives
								if (xIdenBObj == null) {
									if (party1CreatedDt.before(party2CreatedDt)) {

										mapKey = secondPartyIdentificationType;

										partyIdentMap.put(mapKey, idenBObjInMap);

										xIdenBObj = idenBObjInMap;
									}

									else {
										mapKey = firstPartyIdentificationType;

										partyIdentMap.put(mapKey, partyIdenBObj);

										xIdenBObj = partyIdenBObj;
									}
								} else {

									String newCont = xIdenBObj.getPartyId();

									if (newCont.equalsIgnoreCase(partyIdenBObj.getPartyId())) {

										// both belongs to same party
										mapKey = firstPartyIdentificationType;

										partyIdentMap.put(mapKey, partyIdenBObj);
									}
								}
							} else if (firstPartyIdentificationType.equals(ExternalRuleConstant.ID_TYPE_MAGIC)) {
								// MAGIC
								Timestamp party1CreatedDt = DateFormatter.getTimestamp(idenBObjInMap.getXLastModifiedSystemDate());

								Timestamp party2CreatedDt = DateFormatter.getTimestamp(partyIdenBObj.getXLastModifiedSystemDate());

								// Oldest record survives
								if (xIdenBObj == null) {
									if (party1CreatedDt.before(party2CreatedDt)) {

										mapKey = secondPartyIdentificationType + secondRetailerId;

										partyIdentMap.put(mapKey, idenBObjInMap);

										xIdenBObj = idenBObjInMap;
									}

									else {
										mapKey = firstPartyIdentificationType + firstRetailerId;

										partyIdentMap.put(mapKey, partyIdenBObj);

										xIdenBObj = partyIdenBObj;
									}
								} else {
									String newCont = xIdenBObj.getPartyId();

									if (newCont.equalsIgnoreCase(partyIdenBObj.getPartyId())) {
										// both belong to same party

										mapKey = firstPartyIdentificationType + firstRetailerId;

										partyIdentMap.put(mapKey, partyIdenBObj);
									}
								}

							} else {

								// All Id types except UCID and MAGIC
								Timestamp party1CreatedDt = DateFormatter.getTimestamp(idenBObjInMap.getXLastModifiedSystemDate());

								Timestamp party2CreatedDt = DateFormatter.getTimestamp(partyIdenBObj.getXLastModifiedSystemDate());

								if (party1CreatedDt.after(party2CreatedDt)) {

									partyIdentMap.put(secondPartyIdentificationType,idenBObjInMap);
								}

								else {

									partyIdentMap.put(firstPartyIdentificationType,partyIdenBObj);
								}
							}
						}
					}
				}

				// For Party Contact Method

				Vector<XContactMethodGroupBObjExt> vecTempPartyContactMethodBObj = new Vector<XContactMethodGroupBObjExt>();
	
				vecTempPartyContactMethodBObj = party.getItemsTCRMPartyContactMethodBObj();	
				
				String firstPartyContMethodUsageType = null;

				String secondPartyContMethodUsageType = null;

				for (int j = 0; j < vecTempPartyContactMethodBObj.size(); j++) {


					XContactMethodGroupBObjExt partyContMethBObj = (XContactMethodGroupBObjExt) vecTempPartyContactMethodBObj.get(j);

					//Added DELETED check for ignore Delete merge TF
					if(!ExternalRuleConstant.VALUE_DELETED.equals
							(partyContMethBObj.getTCRMContactMethodBObj().getReferenceNumber()))
					{

					firstPartyContMethodUsageType = partyContMethBObj.getContactMethodUsageType();

					if (!partyContMethMap.containsKey(firstPartyContMethodUsageType)) {

						partyContMethMap.put(firstPartyContMethodUsageType,partyContMethBObj);

					} else {

						XContactMethodGroupBObjExt contMethodBObjInMap = partyContMethMap.get(firstPartyContMethodUsageType);


						secondPartyContMethodUsageType = contMethodBObjInMap.getContactMethodUsageType();

						if (firstPartyContMethodUsageType.equalsIgnoreCase(secondPartyContMethodUsageType)) {

							Timestamp party1CreatedDt = DateFormatter.getTimestamp(contMethodBObjInMap.getXLastModifiedSystemDate());

							Timestamp party2CreatedDt = DateFormatter.getTimestamp(partyContMethBObj.getXLastModifiedSystemDate());

							if (party1CreatedDt.after(party2CreatedDt)) {

								partyContMethMap.put(secondPartyContMethodUsageType,contMethodBObjInMap);
							}

							else if (party1CreatedDt.before(party2CreatedDt)) {

								partyContMethMap.put(firstPartyContMethodUsageType,partyContMethBObj);

							} else if (party1CreatedDt.equals(party2CreatedDt)) {

								partyContMethMap.put(firstPartyContMethodUsageType,partyContMethBObj);

							}

						}

					}

					}
				}

				// For Party Admin Contequiv

				Vector<XContEquivBObjExt> vecTempAdminContequivBObj = null;

				vecTempAdminContequivBObj = party.getItemsTCRMAdminContEquivBObj();

				String firstPartyAdminSysType = null;

				String secondPartyAdminSysType = null;


				firstRetailerId = null;

				secondRetailerId = null;

				for (int j = 0; j < vecTempAdminContequivBObj.size(); j++) {

					XContEquivBObjExt partyAdminContequivBObj = (XContEquivBObjExt) vecTempAdminContequivBObj.get(j);

					firstPartyAdminSysType = partyAdminContequivBObj.getAdminSystemType();

					String firstRetailerFlag = partyAdminContequivBObj.getXSourceRetailerFlag();

					if (firstRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_Y)) {

						firstRetailerId = partyAdminContequivBObj.getXRetailerId();

						mapKey = firstRetailerFlag + firstPartyAdminSysType + firstRetailerId;

					} else {

						mapKey = firstRetailerFlag + firstPartyAdminSysType;

					}

					if (!partyAdminConteqMap.containsKey(mapKey)) {

						partyAdminConteqMap.put(mapKey, partyAdminContequivBObj);

					} else {

						XContEquivBObjExt partyAdminContequivBObjInMap = (XContEquivBObjExt) partyAdminConteqMap.get(mapKey);

						secondPartyAdminSysType = partyAdminContequivBObjInMap.getAdminSystemType();

						String secondRetailerFlag = partyAdminContequivBObj.getXSourceRetailerFlag();

						if (secondRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_Y)) {

							secondRetailerId = partyAdminContequivBObj.getXRetailerId();

						}

						Timestamp party1CreatedDt = DateFormatter.getTimestamp(partyAdminContequivBObj.getContEquivLastUpdateDate());

						Timestamp party2CreatedDt = DateFormatter.getTimestamp(partyAdminContequivBObjInMap.getContEquivLastUpdateDate());

						if (firstPartyAdminSysType.equalsIgnoreCase(secondPartyAdminSysType)) {

							if (firstPartyAdminSysType.equalsIgnoreCase(ExternalRuleConstant.SOURCE_IDENTIFIER_TYPE_SFDC)) {

								if (xIdenBObj == null) {

									if (party1CreatedDt.before(party2CreatedDt)) {

										if (firstRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_Y)) {

											mapKey = firstRetailerFlag + firstPartyAdminSysType + firstRetailerId;

										} else {

											mapKey = firstRetailerFlag + firstPartyAdminSysType;

										}

										partyAdminConteqMap.put(mapKey, partyAdminContequivBObj);

									} else {
										if (secondRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_Y)) {

											mapKey = secondRetailerFlag + secondPartyAdminSysType + secondRetailerId;

										} else {

											mapKey = secondRetailerFlag + secondPartyAdminSysType;

										}

										partyAdminConteqMap.put(mapKey, partyAdminContequivBObjInMap);

									}
								} else {

									String newCont = xIdenBObj.getPartyId();

									if (newCont.equalsIgnoreCase(partyAdminContequivBObj.getPartyId())) {
										// both belongs to same party
										if (firstRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_Y)) {

											mapKey = firstRetailerFlag + firstPartyAdminSysType + firstRetailerId;

										} else {

											mapKey = firstRetailerFlag + firstPartyAdminSysType;

										}
										partyAdminConteqMap.put(mapKey,partyAdminContequivBObj);
									}
								}
							} else {
								if (party1CreatedDt.after(party2CreatedDt)) {

									if (firstRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_Y)) {

										mapKey = firstRetailerFlag + firstPartyAdminSysType + firstRetailerId;

									} else {

										mapKey = firstRetailerFlag + firstPartyAdminSysType;

									}

									partyAdminConteqMap.put(mapKey, partyAdminContequivBObj);

								} else {

									if (secondRetailerFlag
											.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_Y)) {

										mapKey = secondRetailerFlag + secondPartyAdminSysType + secondRetailerId;

									} else {

										mapKey = secondRetailerFlag + secondPartyAdminSysType;

									}

									partyAdminConteqMap.put(mapKey, partyAdminContequivBObjInMap);
								}
							}
						}
					}
				}
			}
		} else if (incomingPersonBObj.getXMarketName().equals( ExternalRuleConstant.MARKET_NAME_MALAYSIA)
				&& (incomingPersonBObj.getXBatchInd().equalsIgnoreCase( ExternalRuleConstant.BATCH_IND_N)
						&& (!incomingPersonBObj.getSourceIdentifierType().equalsIgnoreCase(ExternalRuleConstant.SOURCE_IDENTIFIER_TYPE_CMS))))
		{
			

			//MYS Real Time and Delta
			// Priority source

			for (int i = 0; i < vecAllParty.size(); i++) {
				
				TCRMPartyBObj party = (TCRMPartyBObj) vecAllParty.get(i);
				

				String firstFS = null;

				String secondFS = null;
				//FS changes-Sameeha//
				
				Vector<TCRMPersonNameBObj> vecTempPersonNameBOBj = new Vector<TCRMPersonNameBObj>();
				vecTempPersonNameBOBj = ((TCRMPersonBObj) party).getItemsTCRMPersonNameBObj();
				
				String firstPartyNameUsageType = null;
				
				String secondPartyNameUsageType = null;
				
				String firstPartySource = null;
				
				String secondPartySource = null;

				String firstRetailerId = null;

				String secondRetailerId = null;

				String firstRetailerFlag = null;

				String secondRetailerFlag = null;

				// For Person Names
				for (int j = 0; j < vecTempPersonNameBOBj.size(); j++) {

					XPersonNameBObjExt personnameBObj = (XPersonNameBObjExt) vecTempPersonNameBOBj.get(j);
					firstPartyNameUsageType = personnameBObj.getNameUsageType();
					firstPartySource = personnameBObj.getSourceIdentifierType();
					
				
					firstFS = personnameBObj.getXPersonNameRetailerFlag();
					
					// If FS, Key = Name usage type + FS
					if (personnameBObj.getXPersonNameRetailerFlag() != null
							&& personnameBObj.getXPersonNameRetailerFlag().equals(ExternalRuleConstant.FS_VALUE)) {

						mapKey = firstPartyNameUsageType+ ExternalRuleConstant.FS_VALUE;

					} else if (personnameBObj.getXPersonNameRetailerFlag() == null
							|| !personnameBObj.getXPersonNameRetailerFlag().equals(ExternalRuleConstant.FS_WHOLESALE)) {

						// Otherwise Key = Name Usage type
						mapKey = firstPartyNameUsageType;

					}
					
					// FS Wholesale Objects do not participate in Merge

					if ((firstFS == null) || (firstFS != null && !firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE))) {
						if (!personNameMap.containsKey(mapKey)) {
							// If key doesn't exist in map
							personNameMap.put(mapKey, personnameBObj);

						} else {
							// If key exists in map

							XPersonNameBObjExt nameBObjInMap = personNameMap.get(mapKey);

							secondPartyNameUsageType = personnameBObj.getNameUsageType();

							secondPartySource = nameBObjInMap.getSourceIdentifierType();

							secondFS = nameBObjInMap.getXPersonNameRetailerFlag();

							Timestamp person1CreatedDt = DateFormatter.getTimestamp(nameBObjInMap.getXLastModifiedSystemDate());

							Timestamp person2CreatedDt = DateFormatter.getTimestamp(personnameBObj.getXLastModifiedSystemDate());

							if (firstPartyNameUsageType.equalsIgnoreCase(secondPartyNameUsageType)) {
								// Same Name Usage type

								if (firstPartySource.equalsIgnoreCase(secondPartySource)) {
									// Same source
									// Latest survives
									if (person1CreatedDt.after(person2CreatedDt)) {

									
										if (secondFS != null) {
											// If FS, Key = Name usage type + FS
											mapKey = secondPartyNameUsageType + secondFS;

										} else {
											// Otherwise Key = Name Usage type
											mapKey = secondPartyNameUsageType;

										}

									
										personNameMap.put(mapKey, nameBObjInMap);

									} else {

									
										if (firstFS != null && firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {
											// If FS, Key = Name usage type + FS
											mapKey = firstPartyNameUsageType + firstFS;

										} else {
											// Otherwise Key = Name Usage type
											mapKey = firstPartyNameUsageType;

										}

									
										personNameMap.put(mapKey, personnameBObj);

									}
								} else {
									// Different source
									// Priority source will survive

									if (firstPartySource.equalsIgnoreCase(ExternalRuleConstant.SOURCE_IDENTIFIER_TYPE_SFDC)) {
										// SFDC is priority source

										
										if (firstFS != null && firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {
											// If FS, Key = Name usage type + FS
											mapKey = firstPartyNameUsageType + firstFS;

										} else {
											// Otherwise Key = Name Usage type
											mapKey = firstPartyNameUsageType;

										}

										personNameMap.put(mapKey, personnameBObj);

									} else {

									
										if (secondFS != null &&  secondFS.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {
											// If FS, Key = Name usage type + FS
											mapKey = secondPartyNameUsageType + secondFS;

										} else {
											// Otherwise Key = Name Usage type
											mapKey = secondPartyNameUsageType;

										}

									
										personNameMap.put(mapKey, nameBObjInMap);
									}
								}
							}

						}
					}
				}
				// For Party Identification

				Vector<XIdentifierBObjExt> vecTempPartyIdentificationBObj = new Vector<XIdentifierBObjExt>();

				vecTempPartyIdentificationBObj = party.getItemsTCRMPartyIdentificationBObj();

				String firstPartyIdentificationType = null;

				String secondPartyIdentificationType = null;

				String firstPartyIdentificationValue = null;

				String secondPartyIdentificationValue = null;

				XIdentifierBObjExt xIdenBObj = null;
				
				firstFS = null;

				secondFS = null;

				for (int j = 0; j < vecTempPartyIdentificationBObj.size(); j++) {

					XIdentifierBObjExt partyIdenBObj = (XIdentifierBObjExt) vecTempPartyIdentificationBObj.get(j);

					firstPartyIdentificationValue = partyIdenBObj.getIdentificationValue();

					firstPartyIdentificationType = partyIdenBObj.getIdentificationType();

					firstPartySource = party.getSourceIdentifierType();

					firstRetailerId = partyIdenBObj.getXRetailerId();
					
					firstFS = partyIdenBObj.getXIdentifierRetailerFlag();

					// Retailer Id null and ID type not EPUCID
					if (!firstPartyIdentificationType.equalsIgnoreCase(ExternalRuleConstant.ID_TYPE_MAGIC)
							&& !firstPartyIdentificationType.equalsIgnoreCase(ExternalRuleConstant.ID_TYPE_PERSON_EPUCID)) {

					
						// If FS, Key = Identification type + FS

						if (firstFS != null && firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {

							mapKey = firstPartyIdentificationType + firstFS;
						}

						else if(firstFS == null || (firstFS!=null && !ExternalRuleConstant.FS_WHOLESALE.equalsIgnoreCase(firstFS))){		
						
							if(firstRetailerId == null && !firstPartyIdentificationType.equalsIgnoreCase(ExternalRuleConstant.ID_TYPE_PERSON_EPUCID)){
								mapKey = firstPartyIdentificationType;
							}else if(firstRetailerId != null && !firstPartyIdentificationType.equalsIgnoreCase(ExternalRuleConstant.ID_TYPE_PERSON_EPUCID)){
								mapKey = firstPartyIdentificationType + firstRetailerId;
							}
						}
						
					 
					
					if(((firstFS == null)  || (firstFS != null && !firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE))) ){
						
						if (!partyIdentMap.containsKey(mapKey)) {
												
							partyIdentMap.put(mapKey, partyIdenBObj);
	
						} else {
	
							XIdentifierBObjExt idenBObjInMap = partyIdentMap.get(mapKey);
	
							secondPartyIdentificationValue = idenBObjInMap.getIdentificationValue();
	
							secondPartyIdentificationType = idenBObjInMap.getIdentificationType();
	
							secondPartySource = idenBObjInMap.getSourceIdentifierType();
	
							secondRetailerId = idenBObjInMap.getXRetailerId();
							
							secondFS = idenBObjInMap.getXIdentifierRetailerFlag();

							Timestamp party1CreatedDt = DateFormatter.getTimestamp(idenBObjInMap.getXLastModifiedSystemDate());
	
							Timestamp party2CreatedDt = DateFormatter.getTimestamp(partyIdenBObj.getXLastModifiedSystemDate());
	
							if (firstPartyIdentificationType.equalsIgnoreCase(secondPartyIdentificationType)) {
	
								if (firstPartyIdentificationType.equals(ExternalRuleConstant.ID_TYPE_UCID)) {
									// UCID
									// Oldest record survives
									if (xIdenBObj == null) {
										if (party1CreatedDt.before(party2CreatedDt)) {
											partyIdentMap.put(secondPartyIdentificationType,idenBObjInMap);
											xIdenBObj = idenBObjInMap;
										} else {
											partyIdentMap.put(firstPartyIdentificationType,partyIdenBObj);
											xIdenBObj = partyIdenBObj;
										}
									} else {
										String newCont = xIdenBObj.getPartyId();
										if (newCont.equalsIgnoreCase(partyIdenBObj.getPartyId())) {
											// both belongs to same party
											partyIdentMap.put(firstPartyIdentificationType,partyIdenBObj);
										}
									}
								} 
								else if (firstPartyIdentificationType.equals(ExternalRuleConstant.ID_TYPE_BPID)
										&& firstFS != null && firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)
										&& secondFS != null && secondFS.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {

									// BPID

									// Oldest BPID survives

									if (party1CreatedDt.before(party2CreatedDt)) {

										mapKey = secondPartyIdentificationType + secondFS;

										partyIdentMap.put(mapKey, idenBObjInMap);

										// xIdenBObj = idenBObjInMap;

									} else {

										mapKey = firstPartyIdentificationType + firstFS;

										partyIdentMap.put(mapKey, partyIdenBObj);

										// xIdenBObj = partyIdenBObj;

									}

								} else if (firstPartyIdentificationType.equals(ExternalRuleConstant.ID_TYPE_PERSON_EPUCID)) {
									
									// Do nothing
								}
								 else {
	
									if (firstPartySource != null && secondPartySource != null) {
									
										if (firstPartySource.equalsIgnoreCase(secondPartySource)) {
											
											// Same Source
											if (party1CreatedDt.after(party2CreatedDt)) {

												if (secondRetailerId == null) {

													// If FS, Key = Identification type + FS
													if (secondFS != null && secondFS.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {

														mapKey = secondPartyIdentificationType + secondFS;

													} else {
														// Otherwise, Key =Identification type
														mapKey = secondPartyIdentificationType;
													}

												}else{
													
													mapKey = secondPartyIdentificationType + secondRetailerId;
												}

												partyIdentMap.put(mapKey, idenBObjInMap);
											}

											else {

												if (firstRetailerId == null) {

													// If FS, Key = Identification type + FS
													if (firstFS != null && firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {

														mapKey = firstPartyIdentificationType + firstFS;

													} else {
														// Otherwise, Key =Identification type
														mapKey = firstPartyIdentificationType;

													}
												} else{
													mapKey = firstPartyIdentificationType + firstRetailerId;
												}
												partyIdentMap.put(mapKey, partyIdenBObj);
											}

										} else {
											// Different sourcePriority source will survive
											if (firstPartySource.equalsIgnoreCase(ExternalRuleConstant.SOURCE_IDENTIFIER_TYPE_AUTOLINE)) {
												if (firstRetailerId == null) {

													// If FS, Key =Identification type + FS
													if (firstFS != null && firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {

														mapKey = firstPartyIdentificationType + firstFS;
													} else {
														// Otherwise, Key =Identification type
														mapKey = firstPartyIdentificationType;
													}

												}  else{
													mapKey = firstPartyIdentificationType + firstRetailerId;
												}
												partyIdentMap.put(mapKey,partyIdenBObj);
												
											} else {
												if (secondRetailerId == null) {
													// If FS, Key =Identification type + FS
													if (secondFS != null && secondFS.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {

														mapKey = secondPartyIdentificationType + secondFS;
													} else {
														// Otherwise, Key =Identification type
														mapKey = secondPartyIdentificationType;
													}
												} else{
													
													mapKey = secondPartyIdentificationType + secondRetailerId;
												}

												partyIdentMap.put(mapKey, idenBObjInMap);
											}
											
										}
									}
								}
							}
						}
					}
				}
			}

				// For Party Contact Method

				Vector<XContactMethodGroupBObjExt> vecTempPartyContactMethodBObj = new Vector<XContactMethodGroupBObjExt>();

				vecTempPartyContactMethodBObj = party.getItemsTCRMPartyContactMethodBObj();

				String firstPartyValidityContType = null;

				String secondPartyValidityContType = null;

				String firstPartyContMethodUsageType = null;

				String secondPartyContMethodUsageType = null;

				String firstPrefInd = null;

				String secondPrefInd = null;

				firstFS = null;

				secondFS = null;

				for (int j = 0; j < vecTempPartyContactMethodBObj.size(); j++) {

					XContactMethodGroupBObjExt partyContMethBObj = (XContactMethodGroupBObjExt) vecTempPartyContactMethodBObj.get(j);

					//Added DELETED check for ignore Delete merge TF
					if(!ExternalRuleConstant.VALUE_DELETED.equals
							(partyContMethBObj.getTCRMContactMethodBObj().getReferenceNumber()))
					{
						firstPartySource = partyContMethBObj.getSourceIdentifierType();

					firstPartyContMethodUsageType = partyContMethBObj.getContactMethodUsageType();

					firstFS = partyContMethBObj.getXContactRetailerFlag();

					// If FS, Key = Contact Method Usage Type + FS
					if (firstFS != null && firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {

						mapKey = firstPartyContMethodUsageType + firstFS;
					}
					// Otherwise, Key = Contact Method Usage Type
					else {

						mapKey = firstPartyContMethodUsageType;
					}

					// FSWS objects do not participate in Merge
					if (firstFS == null || !firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE)) {
						if (!partyContMethMap.containsKey(mapKey)) {
	
							partyContMethMap.put(mapKey,partyContMethBObj);
	
						} else {
	
							XContactMethodGroupBObjExt contMethodBObjInMap = partyContMethMap.get(mapKey);
	
							secondPartySource = contMethodBObjInMap.getSourceIdentifierType();
	
							secondPartyContMethodUsageType = contMethodBObjInMap.getContactMethodUsageType();
							
							secondFS = contMethodBObjInMap.getXContactRetailerFlag();

							if (firstPartyContMethodUsageType.equalsIgnoreCase(secondPartyContMethodUsageType)) {
	
								Timestamp party1CreatedDt = DateFormatter.getTimestamp(contMethodBObjInMap.getXLastModifiedSystemDate());
	
								Timestamp party2CreatedDt = DateFormatter.getTimestamp(partyContMethBObj.getXLastModifiedSystemDate());
	
								if (firstPartySource.equalsIgnoreCase(secondPartySource)) {
									// Same source
	
									if (party1CreatedDt.after(party2CreatedDt)) {

										// If FS, Key = Contact Method Usage Type + FS
										if (secondFS != null && secondFS.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {

											mapKey = secondPartyContMethodUsageType + secondFS;
										}
										// Otherwise, Key = Contact Method Usage Type
										else {

											mapKey = secondPartyContMethodUsageType;
										}
										partyContMethMap.put(mapKey,contMethodBObjInMap);
	
									}
	
									else if (party1CreatedDt.before(party2CreatedDt)) {
										// If FS, Key = Contact Method Usage Type + FS
										if (firstFS != null && firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {

											mapKey = firstPartyContMethodUsageType + firstFS;
										}
										// Otherwise, Key = Contact Method Usage Type
										else {

											mapKey = firstPartyContMethodUsageType;
										}

										partyContMethMap.put(mapKey, partyContMethBObj);
										
									} else if (party1CreatedDt.equals(party2CreatedDt)) {
											// If FS, Key = Contact Method Usage Type + FS
											if (firstFS != null && firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {

												mapKey = firstPartyContMethodUsageType + firstFS;
											}
											// Otherwise, Key = Contact Method Usage Type
											else {

												mapKey = firstPartyContMethodUsageType;
											}

										partyContMethMap.put(mapKey,partyContMethBObj);

									}

								} else {
									// Different source
									if (firstPartySource.equalsIgnoreCase(ExternalRuleConstant.SOURCE_IDENTIFIER_TYPE_AUTOLINE)) {

										// If FS, Key = Contact Method Usage Type + FS
										if (firstFS != null && firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {

											mapKey = firstPartyContMethodUsageType + firstFS;
										}
										// Otherwise, Key = Contact Method Usage Type
										else {

											mapKey = firstPartyContMethodUsageType;
										}

										partyContMethMap.put(mapKey, partyContMethBObj);
									} else {

										// If FS, Key = Contact Method Usage Type + FS
										if (secondFS != null && secondFS.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {

											mapKey = secondPartyContMethodUsageType + secondFS;
										}
										// Otherwise, Key = Contact Method Usage Type
										else {

											mapKey = secondPartyContMethodUsageType;
										}
										partyContMethMap.put(mapKey,partyContMethBObj);
									}
								}
	
							}
						}
					}
				}
			}

		// For Party Admin Contequiv

				Vector<XContEquivBObjExt> vecTempAdminContequivBObj = null;

				vecTempAdminContequivBObj = party.getItemsTCRMAdminContEquivBObj();

				String firstPartyAdminSysType = null;

				String secondPartyAdminSysType = null;

				String firstPartyAdminSysValue = null;

				String secondPartyAdminSysValue = null;

				XContEquivBObjExt newadminContEquivBObj = null;

				firstRetailerId = null;

				secondRetailerId = null;
				
				firstFS = null;
				
				secondFS = null;
				
						
				for (int j = 0; j < vecTempAdminContequivBObj.size(); j++) {

					XContEquivBObjExt partyAdminContequivBObj = (XContEquivBObjExt) vecTempAdminContequivBObj.get(j);

					firstPartyAdminSysValue = partyAdminContequivBObj.getAdminSystemValue();

					firstPartyAdminSysType = partyAdminContequivBObj.getAdminSystemType();

					firstRetailerId = partyAdminContequivBObj.getXRetailerId();

					firstRetailerFlag = partyAdminContequivBObj.getXSourceRetailerFlag();
					
					firstFS = partyAdminContequivBObj.getXSourceRetailerFlag();
					
					if(ExternalRuleConstant.CHARACTER_N.equalsIgnoreCase(firstRetailerFlag)){
						
						// MapKey = Retailer Flag + Admin System System type 
						
						mapKey = firstRetailerFlag + firstPartyAdminSysType ;
							
						
					}else if(firstFS!= null && firstFS.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_Y)){
						//Retailer
						// MapKey = Retailer Flag + Admin System System type
						mapKey = firstRetailerFlag + firstPartyAdminSysType + firstRetailerId;
						
					}else if(firstFS!= null && firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)){
						//Retailer
						// MapKey = Retailer Flag + Admin System System type
						mapKey = firstFS + firstPartyAdminSysType ;
																
					}
					
					//FSWS objects do not participate in Merge
					
					if ( (firstFS == null) || (firstFS != null && !firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE) )){
						
						if (!partyAdminConteqMap.containsKey(mapKey)) {
							
							partyAdminConteqMap.put(mapKey,partyAdminContequivBObj);
					   			
						} else {
			
							XContEquivBObjExt partyAdminContequivBObjInMap = (XContEquivBObjExt) partyAdminConteqMap.get(mapKey);
							
							secondPartyAdminSysValue = partyAdminContequivBObjInMap.getAdminSystemValue();
							
							secondPartyAdminSysType = partyAdminContequivBObjInMap.getAdminSystemType();
							
							secondRetailerId = partyAdminContequivBObjInMap.getXRetailerId();
							
							secondRetailerFlag = partyAdminContequivBObjInMap.getXSourceRetailerFlag();
							
							secondFS = partyAdminContequivBObjInMap.getXSourceRetailerFlag();
			
							Timestamp party1CreatedDt = DateFormatter.getTimestamp(partyAdminContequivBObj.getContEquivLastUpdateDate());
			
							Timestamp party2CreatedDt = DateFormatter.getTimestamp( partyAdminContequivBObjInMap.getContEquivLastUpdateDate());
							
						if(firstPartyAdminSysType.equalsIgnoreCase(secondPartyAdminSysType)){
															
							if(xIdenBObj == null){
							
								if (party1CreatedDt.before(party2CreatedDt)) {
									
									if(firstRetailerFlag!= null && firstRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_Y)){
										//Retailer Copy
										//MapKey = Retailer Flag + Admin System System type + Retailer ID
										
										mapKey = firstRetailerFlag + firstPartyAdminSysType + firstRetailerId;
										
										
									}else if(firstRetailerFlag!= null && firstRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_N)){
										//Wholesale Copy											
										// MapKey = Retailer Flag + Admin System System type
										mapKey = firstRetailerFlag + firstPartyAdminSysType;
										
									
									}else if(firstRetailerFlag!= null && firstRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)){
										//If FS, MapKey = FS + Admin System System type
										
										mapKey = firstFS + firstPartyAdminSysType ;
									}
									
										partyAdminConteqMap.put(mapKey,partyAdminContequivBObj);
							
								}else{
									
									if(secondRetailerFlag!= null && secondRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_Y)){
										//Retailer Copy
										//MapKey = Retailer Flag + Admin System System type + Retailer ID
										
										mapKey = secondRetailerFlag + secondPartyAdminSysType + secondRetailerId;
										
										
									}else if(secondRetailerFlag!= null && secondRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_N)){
										//Wholesale Copy											
										// MapKey = Retailer Flag + Admin System System type
										mapKey = secondRetailerFlag + secondPartyAdminSysType;
										
									
									}else if(secondRetailerFlag != null && secondRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)){
										//If FS, MapKey = FS + Admin System System type
										
										mapKey = secondFS + secondPartyAdminSysType ;
									}
								
									partyAdminConteqMap.put(mapKey,partyAdminContequivBObjInMap);
								}
							
							} else{
								String newCont = xIdenBObj.getPartyId();
								
								if(newCont.equalsIgnoreCase(partyAdminContequivBObj.getPartyId())){
									//both belongs to same party
									
									if(firstRetailerFlag != null && firstRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_Y)){
										//Retailer Copy
										
										// MapKey = Retailer Flag + Admin System System type + RetailerId 
										
										mapKey = firstRetailerFlag + firstPartyAdminSysType + firstRetailerId;
										
									}else if(firstRetailerFlag != null && firstRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_N)){
										//Wholesale Copy
										
										//MapKey = Retailer Flag + Admin System System type 
										
										mapKey = firstRetailerFlag + firstPartyAdminSysType ;
										
										
										
									}else if(firstRetailerFlag != null && firstRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)){
										
										mapKey = firstFS + firstPartyAdminSysType;
									}
									
									partyAdminConteqMap.put(mapKey,partyAdminContequivBObj);
								
								}
							}
						}
					}
				}
			}
		}
			//dealer level magic number survivorship
			//sortedMagicNumber(dealerRetailerMap, vecAllParty, partyIdentMap, control);
			sortedMagicNumber(vecAllParty, partyIdentMap, control);
	
			
		} else if (incomingPersonBObj.getXMarketName().equals( ExternalRuleConstant.MARKET_NAME_THAILAND) &&
				!incomingPersonBObj.getSourceIdentifierType().equalsIgnoreCase(ExternalRuleConstant.SOURCE_IDENTIFIER_TYPE_CMS)) {
			
		//Thailand AL|SFDC|TDS|STOUCH
		// Priority source

		for (int i = 0; i < vecAllParty.size(); i++) {

			TCRMPartyBObj party = (TCRMPartyBObj) vecAllParty.get(i);
			

			String firstFS = null;

			String secondFS = null;
			//FS changes-Sameeha//
			
			Vector<TCRMPersonNameBObj> vecTempPersonNameBOBj = new Vector<TCRMPersonNameBObj>();
			vecTempPersonNameBOBj = ((TCRMPersonBObj) party).getItemsTCRMPersonNameBObj();
			
			String firstPartyNameUsageType = null;

			String secondPartyNameUsageType = null;

			String firstPartySource = null;

			String secondPartySource = null;

			String firstRetailerId = null;

			String secondRetailerId = null;

			String firstRetailerFlag = null;

			String secondRetailerFlag = null;

			// For Person Names
			for (int j = 0; j < vecTempPersonNameBOBj.size(); j++) {

				XPersonNameBObjExt personnameBObj = (XPersonNameBObjExt) vecTempPersonNameBOBj.get(j);

				firstPartyNameUsageType = personnameBObj.getNameUsageType();

				firstPartySource = personnameBObj.getSourceIdentifierType();
				
				
				firstFS = personnameBObj.getXPersonNameRetailerFlag();
				
				//BPID survive
				if(personnameBObj.getX_BPID()!=null){
					personNameMap.put(firstPartyNameUsageType+personnameBObj.getX_BPID(), personnameBObj);
					continue;
				}

				// If FS, Key = Name usage type + FS
				if (personnameBObj.getXPersonNameRetailerFlag() != null
						&& personnameBObj.getXPersonNameRetailerFlag().equals(ExternalRuleConstant.FS_VALUE)) {

					mapKey = firstPartyNameUsageType+ ExternalRuleConstant.FS_VALUE;

				} else if (personnameBObj.getXPersonNameRetailerFlag() == null
						|| !personnameBObj.getXPersonNameRetailerFlag().equals(ExternalRuleConstant.FS_WHOLESALE)) {

					// Otherwise Key = Name Usage type
					mapKey = firstPartyNameUsageType;

				}
				// Added  :THA FS Delta Changes : 11/13/2020
				else if (personnameBObj.getXPersonNameRetailerFlag() != null
						&& personnameBObj.getXPersonNameRetailerFlag().equals(ExternalRuleConstant.FS_WHOLESALE)) {

					mapKey = firstPartyNameUsageType+ExternalRuleConstant.FS_WHOLESALE;

				}
				
				// FS Wholesale Objects do not participate in Merge

				// Added  :THA FS Delta Changes : 11/13/2020
				if ((firstFS == null) || (firstFS != null && !firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE))
						|| firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE)) {
					if (!personNameMap.containsKey(mapKey)) {
						// If key doesn't exist in map
						personNameMap.put(mapKey, personnameBObj);

					} else {
						// If key exists in map

						XPersonNameBObjExt nameBObjInMap = personNameMap.get(mapKey);

						secondPartyNameUsageType = personnameBObj.getNameUsageType();

						secondPartySource = nameBObjInMap.getSourceIdentifierType();

						secondFS = nameBObjInMap.getXPersonNameRetailerFlag();

						Timestamp person1CreatedDt = DateFormatter.getTimestamp(nameBObjInMap.getXLastModifiedSystemDate());

						Timestamp person2CreatedDt = DateFormatter.getTimestamp(personnameBObj.getXLastModifiedSystemDate());

						if (firstPartyNameUsageType.equalsIgnoreCase(secondPartyNameUsageType)) {
							// Same Name Usage type

							if (firstPartySource.equalsIgnoreCase(secondPartySource)) {
								// Same source
								// Latest survives
								if (person1CreatedDt.after(person2CreatedDt)) {

								
									if (secondFS != null) {
										// If FS, Key = Name usage type + FS
										mapKey = secondPartyNameUsageType + secondFS;

									} else {
										// Otherwise Key = Name Usage type
										mapKey = secondPartyNameUsageType;

									}

								
									personNameMap.put(mapKey, nameBObjInMap);

								} else {

									// Added  :THA FS Delta Changes : 11/13/2020
									if (firstFS != null && firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE)) {
										// If FS, Key = Name usage type + FS
										mapKey = firstPartyNameUsageType + firstFS;

									} else {
										// Otherwise Key = Name Usage type
										mapKey = firstPartyNameUsageType;

									}

								
									personNameMap.put(mapKey, personnameBObj);

								}
							} else {
								// Different source
								// Priority source will survive

								if (firstPartySource.equalsIgnoreCase(ExternalRuleConstant.SOURCE_IDENTIFIER_TYPE_SFDC)) {
									// SFDC is priority source

									// Added  :THA FS Delta Changes : 11/13/2020
									if (firstFS != null && firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE)) {
										// If FS, Key = Name usage type + FS
										mapKey = firstPartyNameUsageType + firstFS;

									} else {
										// Otherwise Key = Name Usage type
										mapKey = firstPartyNameUsageType;

									}

									personNameMap.put(mapKey, personnameBObj);

								} else {

									// Added  :THA FS Delta Changes : 11/13/2020
									if (secondFS != null &&  secondFS.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE)) {
										// If FS, Key = Name usage type + FS
										mapKey = secondPartyNameUsageType + secondFS;

									} else {
										// Otherwise Key = Name Usage type
										mapKey = secondPartyNameUsageType;

									}

								
									personNameMap.put(mapKey, nameBObjInMap);
								}
							}
						}

					}
				}
			}
				// Added  :THA FS Delta Changes : 11/13/2020
				//Find MPC WS record.
			if(!personNameMap.isEmpty())
			{
				boolean isMPCAvailable = false;
				for (Entry<String, XPersonNameBObjExt> e : personNameMap.entrySet()) {
				    if (!e.getKey().contains(ExternalRuleConstant.FS_WHOLESALE) && !e.getKey().contains(ExternalRuleConstant.FS_VALUE)
				    		&& (e.getValue()).getX_BPID()==null) {
				    	isMPCAvailable = true;
				    	break;
				    }
				}
				
				HashMap<String, XPersonNameBObjExt> tempPersonNameMap = new HashMap<String, XPersonNameBObjExt>();
				
					tempPersonNameMap.putAll(personNameMap);
				//If MPC record is available then remove FSWS record.
				if(isMPCAvailable){
				for (Entry<String, XPersonNameBObjExt> e : tempPersonNameMap.entrySet()) {
					if (e.getKey().contains(ExternalRuleConstant.FS_WHOLESALE)){
						personNameMap.remove(e.getKey());
					}
					
				}
				}
				
			}

			// For Party Identification

			Vector<XIdentifierBObjExt> vecTempPartyIdentificationBObj = new Vector<XIdentifierBObjExt>();

			vecTempPartyIdentificationBObj = party.getItemsTCRMPartyIdentificationBObj();

			String firstPartyIdentificationType = null;

			String secondPartyIdentificationType = null;

			String firstPartyIdentificationValue = null;

			String secondPartyIdentificationValue = null;

			XIdentifierBObjExt xIdenBObj = null;
			
			firstFS = null;

			secondFS = null;

			for (int j = 0; j < vecTempPartyIdentificationBObj.size(); j++) {
				


				XIdentifierBObjExt partyIdenBObj = (XIdentifierBObjExt) vecTempPartyIdentificationBObj.get(j);

				firstPartyIdentificationValue = partyIdenBObj.getIdentificationValue();

				firstPartyIdentificationType = partyIdenBObj.getIdentificationType();

				firstPartySource = party.getSourceIdentifierType();

				firstRetailerId = partyIdenBObj.getXRetailerId();

				firstFS = partyIdenBObj.getXIdentifierRetailerFlag();
				
				//BPID survive
				if(partyIdenBObj.getX_BPID()!=null ){
					partyIdentMap.put(partyIdenBObj.getX_BPID()+counter, partyIdenBObj);
					counter++;
					continue;
				}
				//FSChange: THA Delta Changes | 17-11-2020
				if(firstPartyIdentificationType.equals(ExternalRuleConstant.ID_TYPE_BPID) ){
					partyIdentMap.put(ExternalRuleConstant.ID_TYPE_BPID+counter+j, partyIdenBObj);
					counter++;
					continue;
				}

				// ID type not EPUCID
				if (!firstPartyIdentificationType.equalsIgnoreCase(ExternalRuleConstant.ID_TYPE_PERSON_EPUCID)) {
				
					// If FS, Key = Identification type + FS

					if (firstFS != null && firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {

						mapKey = firstPartyIdentificationType + firstFS;
					}

					else if(firstFS == null && firstRetailerId == null 
					&& !firstPartyIdentificationType.equalsIgnoreCase(ExternalRuleConstant.ID_TYPE_PERSON_EPUCID)){
					
						mapKey = firstPartyIdentificationType;
						
					}
					//FSChange: THA Delta Changes | 17-11-2020
					else if (firstFS != null
							&& firstFS.equals(ExternalRuleConstant.FS_WHOLESALE)) {

						mapKey = firstPartyIdentificationType+ExternalRuleConstant.FS_WHOLESALE;

					}
					else{
						//Retailer ID present
						mapKey = firstPartyIdentificationType + firstRetailerId;
					}
					
				 
					//FSChange: THA Delta Changes | 17-11-2020
				if((firstFS == null)  || (firstFS != null && !firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE))
						|| (firstFS != null && firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE))){
					
					if (!partyIdentMap.containsKey(mapKey)) {

						partyIdentMap.put(mapKey, partyIdenBObj);

					} else {

						XIdentifierBObjExt idenBObjInMap = partyIdentMap.get(mapKey);

						secondPartyIdentificationValue = idenBObjInMap.getIdentificationValue();

						secondPartyIdentificationType = idenBObjInMap.getIdentificationType();

						secondPartySource = idenBObjInMap.getSourceIdentifierType();

						secondRetailerId = idenBObjInMap.getXRetailerId();

						secondFS = idenBObjInMap.getXIdentifierRetailerFlag();

						Timestamp party1CreatedDt = DateFormatter.getTimestamp(idenBObjInMap.getXLastModifiedSystemDate());

						Timestamp party2CreatedDt = DateFormatter.getTimestamp(partyIdenBObj.getXLastModifiedSystemDate());

						if (firstPartyIdentificationType.equalsIgnoreCase(secondPartyIdentificationType)) {

							if (firstPartyIdentificationType.equals(ExternalRuleConstant.ID_TYPE_UCID)) {

								// UCID
								// Oldest record survives

								if (xIdenBObj == null) {

									if (party1CreatedDt.before(party2CreatedDt)) {

										partyIdentMap.put(secondPartyIdentificationType,idenBObjInMap);

										xIdenBObj = idenBObjInMap;

									} else {

										partyIdentMap.put(firstPartyIdentificationType,partyIdenBObj);

										xIdenBObj = partyIdenBObj;

									}

								} else {

									String newCont = xIdenBObj.getPartyId();

									if (newCont.equalsIgnoreCase(partyIdenBObj.getPartyId())) {

										// both belongs to same party

										partyIdentMap.put(firstPartyIdentificationType,partyIdenBObj);

									}
								}

							} else if (firstPartyIdentificationType.equals(ExternalRuleConstant.ID_TYPE_LINE)) {

								// UCID
								// Oldest record survives

								if (xIdenBObj == null) {

									if (party1CreatedDt.before(party2CreatedDt)) {

										partyIdentMap.put(secondPartyIdentificationType,idenBObjInMap);

										xIdenBObj = idenBObjInMap;

									} else {

										partyIdentMap.put(firstPartyIdentificationType,partyIdenBObj);

										xIdenBObj = partyIdenBObj;

									}

								} else {

									String newCont = xIdenBObj.getPartyId();

									if (newCont.equalsIgnoreCase(partyIdenBObj.getPartyId())) {

										// both belongs to same party

										partyIdentMap.put(firstPartyIdentificationType,partyIdenBObj);

									}
								}

							}else if (firstPartyIdentificationType.equals(ExternalRuleConstant.ID_TYPE_MAGIC)) {
								// MAGIC

								// Oldest record survives
								if (xIdenBObj == null) {

									if (party1CreatedDt.before(party2CreatedDt)) {

										if (secondRetailerId == null) {

											mapKey = secondPartyIdentificationType;

										} else {

											mapKey = secondPartyIdentificationType + secondRetailerId;

										}

										partyIdentMap.put(mapKey, idenBObjInMap);

										xIdenBObj = idenBObjInMap;

									} else {

										if (firstRetailerId == null) {

											mapKey = firstPartyIdentificationType;

										} else {

											mapKey = firstPartyIdentificationType + firstRetailerId;

										}

										partyIdentMap.put(mapKey,partyIdenBObj);

										xIdenBObj = partyIdenBObj;
									}
								} else {

									String newCont = xIdenBObj.getPartyId();

									if (newCont.equalsIgnoreCase(partyIdenBObj.getPartyId())) {

										// both belong to same party
										if (firstRetailerId == null) {

											mapKey = firstPartyIdentificationType;

										} else {

											mapKey = firstPartyIdentificationType + firstRetailerId;

										}

										partyIdentMap.put(mapKey, partyIdenBObj);

									}
								}

							} else if (firstPartyIdentificationType.equals(ExternalRuleConstant.ID_TYPE_BPID)
									&& firstFS != null && firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)
									&& secondFS != null && secondFS.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {

								// BPID

								// Oldest BPID survives

								if (party1CreatedDt.before(party2CreatedDt)) {

									mapKey = secondPartyIdentificationType + secondFS;

									partyIdentMap.put(mapKey, idenBObjInMap);

									// xIdenBObj = idenBObjInMap;

								} else {

									mapKey = firstPartyIdentificationType + firstFS;

									partyIdentMap.put(mapKey, partyIdenBObj);

									// xIdenBObj = partyIdenBObj;

								}

							}else if (firstPartyIdentificationType.equals(ExternalRuleConstant.ID_TYPE_COMPASS_CUSTOMER_ID)) {

								// Compass Customer Id
								// Oldest record survives

								if (xIdenBObj == null) {

									if (party1CreatedDt.before(party2CreatedDt)) {

										partyIdentMap.put(secondPartyIdentificationType,idenBObjInMap);

										xIdenBObj = idenBObjInMap;

									} else {

										partyIdentMap.put(firstPartyIdentificationType,partyIdenBObj);

										xIdenBObj = partyIdenBObj;

									}

								} else {

									String newCont = xIdenBObj.getPartyId();

									if (newCont.equalsIgnoreCase(partyIdenBObj.getPartyId())) {

										// both belongs to same party

										partyIdentMap.put(firstPartyIdentificationType,partyIdenBObj);

									}
								}

							}  else if (firstPartyIdentificationType.equals(ExternalRuleConstant.ID_TYPE_PERSON_EPUCID)) {

								// Do nothing

							}else {

								if (firstPartySource != null && secondPartySource != null) {

									if (firstPartySource.equalsIgnoreCase(secondPartySource)) {
										// Same Source

										if (party1CreatedDt.after(party2CreatedDt)) {
											
											if (secondRetailerId == null) {
												//FSChange: THA Delta Changes | 17-11-2020
												// If FS, Key = Identification type + FS
												if (secondFS != null && secondFS.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE)) {

													mapKey = secondPartyIdentificationType + secondFS;

												} else {
													// Otherwise, Key =Identification type
													mapKey = secondPartyIdentificationType;

												}

											}else if(firstPartyIdentificationType.equals(ExternalRuleConstant.ID_TYPE_STOUCHID) || 
												firstPartyIdentificationType.equals(ExternalRuleConstant.ID_TYPE_TDSID)){
													//STOUCH ID | TDS ID
													mapKey = secondPartyIdentificationType + secondRetailerId;
										
											}

											partyIdentMap.put(mapKey, idenBObjInMap);
										}else {

											if (firstRetailerId == null) {
												//FSChange: THA Delta Changes | 17-11-2020
												// If FS, Key = Identification type + FS
												if (firstFS != null && firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE)) {

													mapKey = firstPartyIdentificationType + firstFS;

												} else {
													// Otherwise, Key =Identification type
													mapKey = firstPartyIdentificationType;

												}
											}else if(firstPartyIdentificationType.equals(ExternalRuleConstant.ID_TYPE_STOUCHID) || 
												firstPartyIdentificationType.equals(ExternalRuleConstant.ID_TYPE_TDSID)){
													//STOUCH ID | TDS ID
													mapKey = firstPartyIdentificationType + firstRetailerId;
										
											} 
											partyIdentMap.put(mapKey, partyIdenBObj);
										}

									} else {
										// Different source
										//Priority source will survive
										if (firstPartySource.equalsIgnoreCase(ExternalRuleConstant.SOURCE_IDENTIFIER_TYPE_AUTOLINE)) {
											if (firstRetailerId == null) {
												//FSChange: THA Delta Changes | 17-11-2020
												// If FS, Key =Identification type + FS
												if (firstFS != null && firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE)) {

													mapKey = firstPartyIdentificationType + firstFS;

												} else {
													// Otherwise, Key =Identification type
													mapKey = firstPartyIdentificationType;

												}

											} else if(firstPartyIdentificationType.equals(ExternalRuleConstant.ID_TYPE_STOUCHID) || 
												firstPartyIdentificationType.equals(ExternalRuleConstant.ID_TYPE_TDSID)){
													//STOUCH ID | TDS ID
													mapKey = firstPartyIdentificationType + firstRetailerId;
										
											}
											partyIdentMap.put(mapKey,partyIdenBObj);

										} else if(secondPartySource.equalsIgnoreCase(ExternalRuleConstant.SOURCE_IDENTIFIER_TYPE_AUTOLINE)){

											if (secondRetailerId == null) {
												//FSChange: THA Delta Changes | 17-11-2020
												// If FS, Key =Identification type + FS
												if (secondFS != null && secondFS.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE)) {

													mapKey = secondPartyIdentificationType + secondFS;

												} else {
													// Otherwise, Key =Identification type
													mapKey = secondPartyIdentificationType;

												}
											} else if(secondPartyIdentificationType.equals(ExternalRuleConstant.ID_TYPE_STOUCHID) || 
												secondPartyIdentificationType.equals(ExternalRuleConstant.ID_TYPE_TDSID)){
													//STOUCH ID | TDS ID
													mapKey = secondPartyIdentificationType + secondRetailerId;
										
												}

												partyIdentMap.put(mapKey, idenBObjInMap);
											}
										}
									}
								}
							}
						}
					}
				}		
					
			}
			//FSChange: THA Delta Changes | 17-11-2020
			//Find MPC WS record.
			if(!partyIdentMap.isEmpty())
			{
				
			boolean isMPCIdenAvailable = false;
			for (Entry<String, XIdentifierBObjExt> e : partyIdentMap.entrySet()) {
			    if (!e.getKey().contains(ExternalRuleConstant.FS_WHOLESALE) && !e.getKey().contains(ExternalRuleConstant.FS_VALUE)
			    		&& (e.getValue()).getX_BPID()==null
			    		&& !e.getKey().contains(ExternalRuleConstant.ID_TYPE_UCID)  &&
			    		!e.getKey().contains(ExternalRuleConstant.ID_TYPE_LINE)  &&
			    		!e.getKey().contains(ExternalRuleConstant.ID_TYPE_MAGIC)  &&
			    		!e.getKey().contains(ExternalRuleConstant.ID_TYPE_COMPASS_CUSTOMER_ID)  &&
			    		!e.getKey().contains(ExternalRuleConstant.ID_TYPE_PERSON_EPUCID)  &&
			    		!e.getKey().contains(ExternalRuleConstant.ID_TYPE_STOUCHID)  &&
			    		!e.getKey().contains(ExternalRuleConstant.ID_TYPE_TDSID)
			    		&& !e.getKey().contains(ExternalRuleConstant.ID_TYPE_BPID)) {
			    	isMPCIdenAvailable = true;
			    	break;
			    }
			}
			//If MPC record is available then remove FSWS record.
			HashMap<String, XIdentifierBObjExt> tempPartyIdentMap = new HashMap<String, XIdentifierBObjExt>();
			
			tempPartyIdentMap.putAll(partyIdentMap);
			if(isMPCIdenAvailable){
			for (Entry<String, XIdentifierBObjExt> e : tempPartyIdentMap.entrySet()) {
				if (e.getKey().contains(ExternalRuleConstant.FS_WHOLESALE)){
					partyIdentMap.remove(e.getKey());
				}
				
			}
			}
			
			}
			
			// For Party Contact Method

			Vector<XContactMethodGroupBObjExt> vecTempPartyContactMethodBObj = new Vector<XContactMethodGroupBObjExt>();

			vecTempPartyContactMethodBObj = party.getItemsTCRMPartyContactMethodBObj();

			String firstPartyContMethodUsageType = null;

			String secondPartyContMethodUsageType = null;

			String firstPrefInd = null;

			String secondPrefInd = null;

			firstFS = null;

			secondFS = null;

			for (int j = 0; j < vecTempPartyContactMethodBObj.size(); j++) {

				XContactMethodGroupBObjExt partyContMethBObj = (XContactMethodGroupBObjExt) vecTempPartyContactMethodBObj.get(j);

				firstPartySource = partyContMethBObj.getSourceIdentifierType();

				firstPartyContMethodUsageType = partyContMethBObj.getContactMethodUsageType();

				firstFS = partyContMethBObj.getXContactRetailerFlag();
				
				//BPID survive
				if(partyContMethBObj.getX_BPID()!=null){
					partyContMethMap.put(firstPartyContMethodUsageType+partyContMethBObj.getX_BPID(), partyContMethBObj);
					continue;
				}
				
				String party2RefNum=(partyContMethBObj.getTCRMContactMethodBObj()).getReferenceNumber();

				// If FS, Key = Contact Method Usage Type + FS
				if (firstFS != null && firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {

					mapKey = firstPartyContMethodUsageType + firstFS;

				}
				// Otherwise, Key = Contact Method Usage Type
				
				// Added  :THA FS Delta Changes : 11/13/2020
				else if (partyContMethBObj.getXContactRetailerFlag() != null
						&& partyContMethBObj.getXContactRetailerFlag().equals(ExternalRuleConstant.FS_WHOLESALE)) {

					mapKey = firstPartyContMethodUsageType+ExternalRuleConstant.FS_WHOLESALE;

				}
				else {

					mapKey = firstPartyContMethodUsageType;
				}

				// FSWS objects do not participate in Merge
				// Added  :THA FS Delta Changes : 11/13/2020
				if ((firstFS == null) || (firstFS != null && !firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE))
						|| firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE)) {
					if (!partyContMethMap.containsKey(mapKey)) {

						if( !party2RefNum.equalsIgnoreCase(ExternalRuleConstant.VALUE_DELETED)){
								partyContMethMap.put(mapKey, partyContMethBObj);
						}

					} else {

						XContactMethodGroupBObjExt contMethodBObjInMap = partyContMethMap.get(mapKey);

						secondPartySource = contMethodBObjInMap.getSourceIdentifierType();

						secondPartyContMethodUsageType = contMethodBObjInMap.getContactMethodUsageType();

						secondFS = contMethodBObjInMap.getXContactRetailerFlag();
						
						String party1RefNum=(contMethodBObjInMap.getTCRMContactMethodBObj()).getReferenceNumber();
						//System.err.println("Party 1 type = "+firstPartyContMethodUsageType+ "-- Value-"+ party1RefNum);

						if (firstPartyContMethodUsageType.equalsIgnoreCase(secondPartyContMethodUsageType)) {

							Timestamp party1CreatedDt = DateFormatter.getTimestamp(contMethodBObjInMap.getXLastModifiedSystemDate());

							Timestamp party2CreatedDt = DateFormatter.getTimestamp(partyContMethBObj.getXLastModifiedSystemDate());
							
							
							if(!party1RefNum.equalsIgnoreCase(ExternalRuleConstant.VALUE_DELETED) && 
									!party2RefNum.equalsIgnoreCase(ExternalRuleConstant.VALUE_DELETED)){
							if (firstPartySource.equalsIgnoreCase(secondPartySource)) {
								// Same source
								
								if (party1CreatedDt.after(party2CreatedDt)) {
																	
									// If FS, Key = Contact Method Usage Type + FS
									if (secondFS != null && secondFS.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE)) {

										mapKey = secondPartyContMethodUsageType + secondFS;

									}
									// Otherwise, Key = Contact Method Usage Type
									else {
										
										mapKey = secondPartyContMethodUsageType;

									}

									partyContMethMap.put(mapKey,contMethodBObjInMap);
								}

								else if (party1CreatedDt.before(party2CreatedDt)) {
									// If FS, Key = Contact Method Usage Type + FS
									if (firstFS != null && firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE)) {

										mapKey = firstPartyContMethodUsageType + firstFS;

									}
									// Otherwise, Key = Contact Method Usage Type
									else {

										mapKey = firstPartyContMethodUsageType;

									}

									partyContMethMap.put(mapKey, partyContMethBObj);
									
									} else if (party1CreatedDt.equals(party2CreatedDt)) {
										// If FS, Key = Contact Method Usage Type + FS
										if (firstFS != null && firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE)) {

											mapKey = firstPartyContMethodUsageType + firstFS;
										}
										// Otherwise, Key = Contact Method Usage Type
										else {

										mapKey = firstPartyContMethodUsageType;

									}

									partyContMethMap.put(mapKey,partyContMethBObj);

								}
							
							} else {
								// Different source
								if (firstPartySource.equalsIgnoreCase(ExternalRuleConstant.SOURCE_IDENTIFIER_TYPE_AUTOLINE)) {

									// If FS, Key = Contact Method Usage Type + FS
									if (firstFS != null && firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {

										mapKey = firstPartyContMethodUsageType + firstFS;

									}
									// Otherwise, Key = Contact Method Usage Type
									else {

										mapKey = firstPartyContMethodUsageType;

									}

									partyContMethMap.put(mapKey, partyContMethBObj);

								} else {

									// If FS, Key = Contact Method Usage Type + FS
									if (secondFS != null && secondFS.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {

										mapKey = secondPartyContMethodUsageType + secondFS;

									}
									// Otherwise, Key = Contact Method Usage Type
									else {

										mapKey = secondPartyContMethodUsageType;

									}

									partyContMethMap.put(mapKey,partyContMethBObj);

								}
							}
							// if
							}
							else if(!party1RefNum.equalsIgnoreCase(ExternalRuleConstant.VALUE_DELETED) && party2RefNum.equalsIgnoreCase(ExternalRuleConstant.VALUE_DELETED)){

								// If FS, Key = Contact Method Usage Type + FS
								if (firstFS != null && firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {

									mapKey = firstPartyContMethodUsageType + firstFS;
								}
								// Otherwise, Key = Contact Method Usage Type
								else {

								mapKey = firstPartyContMethodUsageType;

							}

							partyContMethMap.put(mapKey,contMethodBObjInMap);
								
							}
							else if(party1RefNum.equalsIgnoreCase(ExternalRuleConstant.VALUE_DELETED) && !party2RefNum.equalsIgnoreCase(ExternalRuleConstant.VALUE_DELETED)){
								
								if (secondFS != null && secondFS.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {

									mapKey = secondPartyContMethodUsageType + secondFS;

								}
								// Otherwise, Key = Contact Method Usage Type
								else {

									mapKey = secondPartyContMethodUsageType;

								}

								partyContMethMap.put(mapKey,partyContMethBObj);
							}
							
						}
					}
				}
			}
			// Added  :THA FS Delta Changes : 11/13/2020
			//Find MPC WS record.
			boolean isContactMPCAvailable = false;
			for (Entry<String, XContactMethodGroupBObjExt> e : partyContMethMap.entrySet()) {
			    if (!e.getKey().contains(ExternalRuleConstant.FS_WHOLESALE) && !e.getKey().contains(ExternalRuleConstant.FS_VALUE)
			    		&& (e.getValue()).getX_BPID()==null) {
			    	isContactMPCAvailable = true;
			    	break;
			    }
			}
			//If MPC record is available then remove FSWS record.
			HashMap<String, XContactMethodGroupBObjExt> tempContactMap = new HashMap<String, XContactMethodGroupBObjExt>();
			
			tempContactMap.putAll(partyContMethMap);
			if(isContactMPCAvailable){
				for (Entry<String, XContactMethodGroupBObjExt> e : tempContactMap.entrySet()) {
					if (e.getKey().contains(ExternalRuleConstant.FS_WHOLESALE)){
						partyContMethMap.remove(e.getKey());
					}
					
				}
			}
			
			
			//For Party Admin Contequiv
			
			Vector<XContEquivBObjExt> vecTempAdminContequivBObj = null;
	
			vecTempAdminContequivBObj = party.getItemsTCRMAdminContEquivBObj();
			
			String firstPartyAdminSysType = null;
			
			String secondPartyAdminSysType = null;
			
			String firstPartyAdminSysValue = null;
			
			String secondPartyAdminSysValue = null;
			
			XContEquivBObjExt newadminContEquivBObj = null;
			
			firstRetailerId = null;
			
			secondRetailerId = null;
			
			firstFS = null;
			
			secondFS = null;
			
					
			for (int j = 0; j < vecTempAdminContequivBObj.size(); j++) {
	
				XContEquivBObjExt partyAdminContequivBObj= (XContEquivBObjExt) vecTempAdminContequivBObj.get(j);			
				
				firstPartyAdminSysValue = partyAdminContequivBObj.getAdminSystemValue();
				
				firstPartyAdminSysType = partyAdminContequivBObj.getAdminSystemType();
				
				firstRetailerId = partyAdminContequivBObj.getXRetailerId();
				
				firstRetailerFlag = partyAdminContequivBObj.getXSourceRetailerFlag();
				
				firstFS = partyAdminContequivBObj.getXSourceRetailerFlag();
				
				if(firstRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_N)){
					
					// MapKey = Retailer Flag + Admin System System type 
					
					mapKey = firstRetailerFlag + firstPartyAdminSysType ;
						
					
				}else if(firstFS!= null && firstFS.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_Y)){
					//Retailer
					
					// MapKey = Retailer Flag + Admin System System type
					
					mapKey = firstRetailerFlag + firstPartyAdminSysType + firstRetailerId;
					
					
											
				}else if(firstFS!= null && firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)){
					//Retailer
					
					// MapKey = Retailer Flag + Admin System System type
					
					mapKey = firstFS + firstPartyAdminSysType ;
					
											
				}
				//FSChange: THA Delta Changes | 17-11-2020
				else if(firstFS!= null && firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE)){
					//Retailer
					
					// MapKey = Retailer Flag + Admin System System type
					
					mapKey = firstFS + firstPartyAdminSysType ;
					
											
				}
				
				//FSWS objects do not participate in Merge
				//FSChange: THA Delta Changes | 17-11-2020
				if ( (firstFS == null) || (firstFS != null && !firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE) )
						|| (firstFS != null && firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE) )){
					
					if (!partyAdminConteqMap.containsKey(mapKey)) {
						
						partyAdminConteqMap.put(mapKey,partyAdminContequivBObj);
				   			
					} else {
		
						XContEquivBObjExt partyAdminContequivBObjInMap = (XContEquivBObjExt) partyAdminConteqMap.get(mapKey);
						
						secondPartyAdminSysValue = partyAdminContequivBObjInMap.getAdminSystemValue();
						
						secondPartyAdminSysType = partyAdminContequivBObjInMap.getAdminSystemType();
						
						secondRetailerId = partyAdminContequivBObjInMap.getXRetailerId();
						
						secondRetailerFlag = partyAdminContequivBObjInMap.getXSourceRetailerFlag();
						
						secondFS = partyAdminContequivBObjInMap.getXSourceRetailerFlag();
		
						Timestamp party1CreatedDt = DateFormatter.getTimestamp(partyAdminContequivBObj.getContEquivLastUpdateDate());
		
						Timestamp party2CreatedDt = DateFormatter.getTimestamp( partyAdminContequivBObjInMap.getContEquivLastUpdateDate());
						
						if(firstPartyAdminSysType.equalsIgnoreCase(secondPartyAdminSysType)){
															
							if(xIdenBObj == null){
							
								if (party1CreatedDt.before(party2CreatedDt)) {
									
									if(firstRetailerFlag!= null && firstRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_Y)){
										//Retailer Copy
										//MapKey = Retailer Flag + Admin System System type + Retailer ID
										
										mapKey = firstRetailerFlag + firstPartyAdminSysType + firstRetailerId;
										
										
									}else if(firstRetailerFlag!= null && firstRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_N)){
										//Wholesale Copy											
										// MapKey = Retailer Flag + Admin System System type
										mapKey = firstRetailerFlag + firstPartyAdminSysType;
										
									
									}else if(firstRetailerFlag!= null && firstRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)){
										//If FS, MapKey = FS + Admin System System type
										
										mapKey = firstFS + firstPartyAdminSysType ;
									}
									//FSChange: THA Delta Changes | 17-11-2020
									else if(firstRetailerFlag!= null && firstRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE)){
										//If FS, MapKey = FS + Admin System System type
										
										mapKey = firstFS + firstPartyAdminSysType ;
									}
									
										partyAdminConteqMap.put(mapKey,partyAdminContequivBObj);
							
								}else{
									
									if(secondRetailerFlag!= null && secondRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_Y)){
										//Retailer Copy
										//MapKey = Retailer Flag + Admin System System type + Retailer ID
										
										mapKey = secondRetailerFlag + secondPartyAdminSysType + secondRetailerId;
										
										
									}else if(secondRetailerFlag!= null && secondRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_N)){
										//Wholesale Copy											
										// MapKey = Retailer Flag + Admin System System type
										mapKey = secondRetailerFlag + secondPartyAdminSysType;
										
									
									}else if(secondRetailerFlag != null && secondRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)){
										//If FS, MapKey = FS + Admin System System type
										
										mapKey = secondFS + secondPartyAdminSysType ;
									}
									//FSChange: THA Delta Changes | 17-11-2020
									else if(secondRetailerFlag != null && secondRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE)){
										//If FS, MapKey = FS + Admin System System type
										
										mapKey = secondFS + secondPartyAdminSysType ;
									}
									partyAdminConteqMap.put(mapKey,partyAdminContequivBObjInMap);
								}
							
							} else{
								String newCont = xIdenBObj.getPartyId();
								
								if(newCont.equalsIgnoreCase(partyAdminContequivBObj.getPartyId())){
									//both belongs to same party
									
									if(firstRetailerFlag != null && firstRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_Y)){
										//Retailer Copy
										
										// MapKey = Retailer Flag + Admin System System type + RetailerId 
										
										mapKey = firstRetailerFlag + firstPartyAdminSysType + firstRetailerId;
										
									}else if(firstRetailerFlag != null && firstRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_N)){
										//Wholesale Copy
										
										//MapKey = Retailer Flag + Admin System System type 
										
										mapKey = firstRetailerFlag + firstPartyAdminSysType ;
										
										
										
									}else if(firstRetailerFlag != null && firstRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)){
										
										mapKey = firstFS + firstPartyAdminSysType;
									}
									//FSChange: THA Delta Changes | 17-11-2020
									else if(firstRetailerFlag != null && firstRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE)){
										
										mapKey = firstFS + firstPartyAdminSysType;
									}
									
									partyAdminConteqMap.put(mapKey,partyAdminContequivBObj);
								
								}
							}
						}
					}
				}
			}
			
			// Added  :THA FS Delta Changes : 11/13/2020
			//Find MPC WS record.
			if(!partyAdminConteqMap.isEmpty())
			{
			boolean isMPCContEquivAvailable = false;
			for (Entry<String, TCRMAdminContEquivBObj> e : partyAdminConteqMap.entrySet()) {
			    if (!e.getKey().contains(ExternalRuleConstant.FS_WHOLESALE) && !e.getKey().contains(ExternalRuleConstant.FS_VALUE)
			    		&& !e.getKey().contains(ExternalRuleConstant.CHARACTER_Y)) {
			    	isMPCContEquivAvailable = true;
			    	break;
			    }
			}
			HashMap<String, TCRMAdminContEquivBObj> tempPartyAdminConteqMap = new HashMap<String, TCRMAdminContEquivBObj>();
			tempPartyAdminConteqMap.putAll(partyAdminConteqMap);
			//If MPC record is available then remove FSWS record.
			if(isMPCContEquivAvailable){
			for (Entry<String, TCRMAdminContEquivBObj> e : tempPartyAdminConteqMap.entrySet()) {
				if (e.getKey().contains(ExternalRuleConstant.FS_WHOLESALE)){
					partyAdminConteqMap.remove(e.getKey());
				}
				
			}
			}
			}
		}

	}else if(incomingPersonBObj.getSourceIdentifierType().equalsIgnoreCase(ExternalRuleConstant.SOURCE_IDENTIFIER_TYPE_CMS)){
			
		//Thailand | Malaysia | CMS
		// Priority source
	
		for (int i = 0; i < vecAllParty.size(); i++) {
	
			TCRMPartyBObj party = (TCRMPartyBObj) vecAllParty.get(i);
			
	
			String firstFS = null;
	
			String secondFS = null;
			//FS changes-Sameeha//
			
			Vector<TCRMPersonNameBObj> vecTempPersonNameBOBj = new Vector<TCRMPersonNameBObj>();
			vecTempPersonNameBOBj = ((TCRMPersonBObj) party).getItemsTCRMPersonNameBObj();
			
			String firstPartyNameUsageType = null;
	
			String secondPartyNameUsageType = null;
	
			String firstPartySource = null;
	
			String secondPartySource = null;
	
			String firstRetailerId = null;
	
			String secondRetailerId = null;
	
			String firstRetailerFlag = null;
	
			String secondRetailerFlag = null;
	
			// For Person Names
			for (int j = 0; j < vecTempPersonNameBOBj.size(); j++) {
	
				XPersonNameBObjExt personnameBObj = (XPersonNameBObjExt) vecTempPersonNameBOBj.get(j);
	
				firstPartyNameUsageType = personnameBObj.getNameUsageType();
	
				firstPartySource = personnameBObj.getSourceIdentifierType();
				
			
				firstFS = personnameBObj.getXPersonNameRetailerFlag();
				
				//BPID survive
				if(personnameBObj.getX_BPID()!=null){
					personNameMap.put(firstPartyNameUsageType+personnameBObj.getX_BPID()+j, personnameBObj);
					continue;
				}
	
				// If FS, Key = Name usage type + FS
				if (personnameBObj.getXPersonNameRetailerFlag() != null
						&& personnameBObj.getXPersonNameRetailerFlag().equals(ExternalRuleConstant.FS_VALUE)) {
	
					mapKey = firstPartyNameUsageType+ ExternalRuleConstant.FS_VALUE;
	
				} else if (personnameBObj.getXPersonNameRetailerFlag() == null
						|| !personnameBObj.getXPersonNameRetailerFlag().equals(ExternalRuleConstant.FS_WHOLESALE)) {
	
					// Otherwise Key = Name Usage type
					mapKey = firstPartyNameUsageType;
	
				}// Added  :THA FS Delta Changes : 11/13/2020
				else if (personnameBObj.getXPersonNameRetailerFlag() != null
						&& personnameBObj.getXPersonNameRetailerFlag().equals(ExternalRuleConstant.FS_WHOLESALE)) {
	
					// Otherwise Key = Name Usage type
					mapKey = firstPartyNameUsageType+ExternalRuleConstant.FS_WHOLESALE;
	
				}
				
				
				// FS Wholesale Objects do not participate in Merge
				// Added  :THA FS Delta Changes : 11/13/2020
				if ((firstFS == null) || (firstFS != null && !firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE))
						||firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE)) {
					if (!personNameMap.containsKey(mapKey)) {
						// If key doesn't exist in map
						personNameMap.put(mapKey, personnameBObj);
	
					} else {
						// If key exists in map
	
						XPersonNameBObjExt nameBObjInMap = personNameMap.get(mapKey);
	
						secondPartyNameUsageType = personnameBObj.getNameUsageType();
	
						secondPartySource = nameBObjInMap.getSourceIdentifierType();
	
						secondFS = nameBObjInMap.getXPersonNameRetailerFlag();
	
						Timestamp person1CreatedDt = DateFormatter.getTimestamp(nameBObjInMap.getXLastModifiedSystemDate());
	
						Timestamp person2CreatedDt = DateFormatter.getTimestamp(personnameBObj.getXLastModifiedSystemDate());
	
						if (firstPartyNameUsageType.equalsIgnoreCase(secondPartyNameUsageType)) {
							// Same Name Usage type
	
							if (firstPartySource.equalsIgnoreCase(secondPartySource)) {
								// Same source
								// Latest survives
								if (person1CreatedDt.after(person2CreatedDt)) {
	
								
									if (secondFS != null) {
										// If FS, Key = Name usage type + FS
										mapKey = secondPartyNameUsageType + secondFS;
	
									} else {
										// Otherwise Key = Name Usage type
										mapKey = secondPartyNameUsageType;
	
									}
	
								
									personNameMap.put(mapKey, nameBObjInMap);
	
								} else {
	
									// Added  :THA FS Delta Changes : 11/13/2020
									if (firstFS != null && firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE)) {
										// If FS, Key = Name usage type + FS
										mapKey = firstPartyNameUsageType + firstFS;
	
									} else {
										// Otherwise Key = Name Usage type
										mapKey = firstPartyNameUsageType;
	
									}
	
								
									personNameMap.put(mapKey, personnameBObj);
	
								}
							} else {
								// Different source
								// Priority source will survive
	
								if (firstPartySource.equalsIgnoreCase(ExternalRuleConstant.SOURCE_IDENTIFIER_TYPE_SFDC)) {
									// SFDC is priority source
	
									// Added  :THA FS Delta Changes : 11/13/2020
									if (firstFS != null && firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE)) {
										// If FS, Key = Name usage type + FS
										mapKey = firstPartyNameUsageType + firstFS;
	
									} else {
										// Otherwise Key = Name Usage type
										mapKey = firstPartyNameUsageType;
	
									}
	
									personNameMap.put(mapKey, personnameBObj);
	
								} else {
	
									// Added  :THA FS Delta Changes : 11/13/2020
									if (secondFS != null &&  secondFS.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE)) {
										// If FS, Key = Name usage type + FS
										mapKey = secondPartyNameUsageType + secondFS;
	
									} else {
										// Otherwise Key = Name Usage type
										mapKey = secondPartyNameUsageType;
	
									}
	
								
									personNameMap.put(mapKey, nameBObjInMap);
								}
							}
						}
	
					}
				}
			}
			
			// Added  :THA FS Delta Changes : 11/13/2020
			//Find MPC WS record.
			if(!personNameMap.isEmpty())
			{
				boolean isMPCAvailable = false;
				for (Entry<String, XPersonNameBObjExt> e : personNameMap.entrySet()) {
				    if (!e.getKey().contains(ExternalRuleConstant.FS_WHOLESALE) && !e.getKey().contains(ExternalRuleConstant.FS_VALUE)
				    		&& (e.getValue()).getX_BPID()==null) {
				    	isMPCAvailable = true;
				    	break;
				    }
				}
				
				HashMap<String, XPersonNameBObjExt> tempPersonNameMap = new HashMap<String, XPersonNameBObjExt>();
				
					tempPersonNameMap.putAll(personNameMap);
				//If MPC record is available then remove FSWS record.
				if(isMPCAvailable){
				for (Entry<String, XPersonNameBObjExt> e : tempPersonNameMap.entrySet()) {
					if (e.getKey().contains(ExternalRuleConstant.FS_WHOLESALE)){
						personNameMap.remove(e.getKey());
					}
					
				}
				}
				
			}
			// For Party Identification
	
			Vector<XIdentifierBObjExt> vecTempPartyIdentificationBObj = new Vector<XIdentifierBObjExt>();
	
			vecTempPartyIdentificationBObj = party.getItemsTCRMPartyIdentificationBObj();
	
			String firstPartyIdentificationType = null;
	
			String secondPartyIdentificationType = null;
	
			XIdentifierBObjExt xIdenBObj = null;
			
			firstFS = null;
	
			secondFS = null;
	
			for (int j = 0; j < vecTempPartyIdentificationBObj.size(); j++) {
				
	
	
				XIdentifierBObjExt partyIdenBObj = (XIdentifierBObjExt) vecTempPartyIdentificationBObj.get(j);
	
				firstPartyIdentificationType = partyIdenBObj.getIdentificationType();
	
				firstPartySource = party.getSourceIdentifierType();
	
				firstRetailerId = partyIdenBObj.getXRetailerId();
	
				firstFS = partyIdenBObj.getXIdentifierRetailerFlag();
	
				
	
				//FSChange: THA FS Delta changes | 17/11/2020
				//BPID survive
				if(partyIdenBObj.getX_BPID()!=null ){
					partyIdentMap.put(partyIdenBObj.getX_BPID()+counter, partyIdenBObj);
					counter++;
					continue;
				}
				
				//FSChange: THA Delta Changes | 17-11-2020
				if(firstPartyIdentificationType.equals(ExternalRuleConstant.ID_TYPE_BPID) ){
					partyIdentMap.put(ExternalRuleConstant.ID_TYPE_BPID+counter+j, partyIdenBObj);
					counter++;
					continue;
				}
				// ID type not EPUCID
				if (!firstPartyIdentificationType.equalsIgnoreCase(ExternalRuleConstant.ID_TYPE_PERSON_EPUCID)) {
				
					// If FS, Key = Identification type + FS
	
					if (firstFS != null && firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {
	
						mapKey = firstPartyIdentificationType + firstFS;
					}
	
					else if(firstFS == null && firstRetailerId == null 
					&& !firstPartyIdentificationType.equalsIgnoreCase(ExternalRuleConstant.ID_TYPE_PERSON_EPUCID)){
					
						mapKey = firstPartyIdentificationType;
					}
					//FSChange: THA Delta Changes | 17-11-2020
					else if (firstFS != null
							&& firstFS.equals(ExternalRuleConstant.FS_WHOLESALE)) {

						mapKey = firstPartyIdentificationType+ExternalRuleConstant.FS_WHOLESALE;

					}
					else{
						//Retailer ID present
						mapKey = firstPartyIdentificationType + firstRetailerId;
					}
					
				 
					//FSChange: THA Delta Changes | 17-11-2020
				if((firstFS == null)  || (firstFS != null && !firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE)) 
						|| (firstFS != null && firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE))){
					
					if (!partyIdentMap.containsKey(mapKey)) {
	
						partyIdentMap.put(mapKey, partyIdenBObj);
	
					} else {
	
						XIdentifierBObjExt idenBObjInMap = partyIdentMap.get(mapKey);
	
						secondPartyIdentificationType = idenBObjInMap.getIdentificationType();
	
						secondPartySource = idenBObjInMap.getSourceIdentifierType();
	
						secondRetailerId = idenBObjInMap.getXRetailerId();
	
						secondFS = idenBObjInMap.getXIdentifierRetailerFlag();
	
						Timestamp party1CreatedDt = DateFormatter.getTimestamp(idenBObjInMap.getXLastModifiedSystemDate());
	
						Timestamp party2CreatedDt = DateFormatter.getTimestamp(partyIdenBObj.getXLastModifiedSystemDate());
	
						if (firstPartyIdentificationType.equalsIgnoreCase(secondPartyIdentificationType)) {
	
							if (firstPartyIdentificationType.equals(ExternalRuleConstant.ID_TYPE_UCID)) {
	
								// UCID
								// Oldest record survives
	
								if (xIdenBObj == null) {
	
									if (party1CreatedDt.before(party2CreatedDt)) {
	
										partyIdentMap.put(secondPartyIdentificationType,idenBObjInMap);
	
										xIdenBObj = idenBObjInMap;
	
									} else {
	
										partyIdentMap.put(firstPartyIdentificationType,partyIdenBObj);
	
										xIdenBObj = partyIdenBObj;
	
									}
	
								} else {
	
									String newCont = xIdenBObj.getPartyId();
	
									if (newCont.equalsIgnoreCase(partyIdenBObj.getPartyId())) {
	
										// both belongs to same party
	
										partyIdentMap.put(firstPartyIdentificationType,partyIdenBObj);
	
									}
								}
	
							}else if (firstPartyIdentificationType.equals(ExternalRuleConstant.ID_TYPE_LINE)) {
	
								// UCID
								// Oldest record survives
	
								if (xIdenBObj == null) {
	
									if (party1CreatedDt.before(party2CreatedDt)) {
	
										partyIdentMap.put(secondPartyIdentificationType,idenBObjInMap);
	
										xIdenBObj = idenBObjInMap;
	
									} else {
	
										partyIdentMap.put(firstPartyIdentificationType,partyIdenBObj);
	
										xIdenBObj = partyIdenBObj;
	
									}
	
								} else {
	
									String newCont = xIdenBObj.getPartyId();
	
									if (newCont.equalsIgnoreCase(partyIdenBObj.getPartyId())) {
	
										// both belongs to same party
	
										partyIdentMap.put(firstPartyIdentificationType,partyIdenBObj);
	
									}
								}
	
							} else if (firstPartyIdentificationType.equals(ExternalRuleConstant.ID_TYPE_MAGIC)) {
								// MAGIC
	
								// Oldest record survives
								if (xIdenBObj == null) {
	
									if (party1CreatedDt.before(party2CreatedDt)) {
	
										if (secondRetailerId == null) {
	
											mapKey = secondPartyIdentificationType;
	
										} else {
	
											mapKey = secondPartyIdentificationType + secondRetailerId;
	
										}
	
										partyIdentMap.put(mapKey, idenBObjInMap);
	
										xIdenBObj = idenBObjInMap;
	
									} else {
	
										if (firstRetailerId == null) {
	
											mapKey = firstPartyIdentificationType;
	
										} else {
	
											mapKey = firstPartyIdentificationType + firstRetailerId;
	
										}
	
										partyIdentMap.put(mapKey,partyIdenBObj);
	
										xIdenBObj = partyIdenBObj;
									}
								} else {
	
									String newCont = xIdenBObj.getPartyId();
	
									if (newCont.equalsIgnoreCase(partyIdenBObj.getPartyId())) {
	
										// both belong to same party
										if (firstRetailerId == null) {
	
											mapKey = firstPartyIdentificationType;
	
										} else {
	
											mapKey = firstPartyIdentificationType + firstRetailerId;
	
										}
	
										partyIdentMap.put(mapKey, partyIdenBObj);
	
									}
								}
	
							} else if (firstPartyIdentificationType.equals(ExternalRuleConstant.ID_TYPE_BPID)
									&& firstFS != null && firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)
									&& secondFS != null && secondFS.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {
	
								// BPID
	
								// Oldest BPID survives
	
								if (party1CreatedDt.before(party2CreatedDt)) {
	
									mapKey = secondPartyIdentificationType + secondFS;
	
									partyIdentMap.put(mapKey, idenBObjInMap);
	
									// xIdenBObj = idenBObjInMap;
	
								} else {
	
									mapKey = firstPartyIdentificationType + firstFS;
	
									partyIdentMap.put(mapKey, partyIdenBObj);
	
									// xIdenBObj = partyIdenBObj;
	
								}
	
							} else if (firstPartyIdentificationType.equals(ExternalRuleConstant.ID_TYPE_PERSON_EPUCID)) {
	
								// Do nothing
	
							}else {
	
								if (firstPartySource != null && secondPartySource != null) {
	
									if (firstPartySource.equalsIgnoreCase(secondPartySource)) {
										// Same Source
	
										if (party1CreatedDt.after(party2CreatedDt)) {
											
											if (secondRetailerId == null) {
												//FSChange: THA Delta Changes | 17-11-2020
												// If FS, Key = Identification type + FS
												if (secondFS != null && secondFS.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE)) {
	
													mapKey = secondPartyIdentificationType + secondFS;
	
												} else {
													// Otherwise, Key =Identification type
													mapKey = secondPartyIdentificationType;
	
												}
	
											}else if(firstPartyIdentificationType.equals(ExternalRuleConstant.ID_TYPE_STOUCHID) || 
												firstPartyIdentificationType.equals(ExternalRuleConstant.ID_TYPE_TDSID)){
													//STOUCH ID | TDS ID
													mapKey = secondPartyIdentificationType + secondRetailerId;
										
											}
	
											partyIdentMap.put(mapKey, idenBObjInMap);
										}else {
	
											if (firstRetailerId == null) {
												//FSChange: THA Delta Changes | 17-11-2020
												// If FS, Key = Identification type + FS
												if (firstFS != null && firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE)) {
	
													mapKey = firstPartyIdentificationType + firstFS;
	
												} else {
													// Otherwise, Key =Identification type
													mapKey = firstPartyIdentificationType;
	
												}
											}else if(firstPartyIdentificationType.equals(ExternalRuleConstant.ID_TYPE_STOUCHID) || 
												firstPartyIdentificationType.equals(ExternalRuleConstant.ID_TYPE_TDSID)){
													//STOUCH ID | TDS ID
													mapKey = firstPartyIdentificationType + firstRetailerId;
										
											} 
											partyIdentMap.put(mapKey, partyIdenBObj);
										}
	
									} else {
										// Different source
										//Priority source will survive
										if (firstPartySource.equalsIgnoreCase(ExternalRuleConstant.SOURCE_IDENTIFIER_TYPE_AUTOLINE)) {
											if (firstRetailerId == null) {
												//FSChange: THA Delta Changes | 17-11-2020
												// If FS, Key =Identification type + FS
												if (firstFS != null && firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE)) {
	
													mapKey = firstPartyIdentificationType + firstFS;
	
												} else {
													// Otherwise, Key =Identification type
													mapKey = firstPartyIdentificationType;
	
												}
	
											} else if(firstPartyIdentificationType.equals(ExternalRuleConstant.ID_TYPE_STOUCHID) || 
												firstPartyIdentificationType.equals(ExternalRuleConstant.ID_TYPE_TDSID)){
													//STOUCH ID | TDS ID
													mapKey = firstPartyIdentificationType + firstRetailerId;
										
											}
											partyIdentMap.put(mapKey,partyIdenBObj);
	
										} else if(secondPartySource.equalsIgnoreCase(ExternalRuleConstant.SOURCE_IDENTIFIER_TYPE_AUTOLINE)){
	
											if (secondRetailerId == null) {
												//FSChange: THA Delta Changes | 17-11-2020
												// If FS, Key =Identification type + FS
												if (secondFS != null && secondFS.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE)) {
	
													mapKey = secondPartyIdentificationType + secondFS;
	
												} else {
													// Otherwise, Key =Identification type
													mapKey = secondPartyIdentificationType;
	
												}
											} else if(secondPartyIdentificationType.equals(ExternalRuleConstant.ID_TYPE_STOUCHID) || 
												secondPartyIdentificationType.equals(ExternalRuleConstant.ID_TYPE_TDSID)){
													//STOUCH ID | TDS ID
													mapKey = secondPartyIdentificationType + secondRetailerId;
										
												}
	
												partyIdentMap.put(mapKey, idenBObjInMap);
											}
										}
									}
								}
							}
						}
					}
				
				
				}		
					
			}
			
			//FSChange: THA Delta Changes | 17-11-2020
			//Find MPC WS record.
			if(!partyIdentMap.isEmpty())
			{
				
			boolean isMPCIdenAvailable = false;
			for (Entry<String, XIdentifierBObjExt> e : partyIdentMap.entrySet()) {
			    if (!e.getKey().contains(ExternalRuleConstant.FS_WHOLESALE) && !e.getKey().contains(ExternalRuleConstant.FS_VALUE)
			    		&& (e.getValue()).getX_BPID()==null
			    		&& !e.getKey().contains(ExternalRuleConstant.ID_TYPE_UCID)  &&
			    		!e.getKey().contains(ExternalRuleConstant.ID_TYPE_LINE)  &&
			    		!e.getKey().contains(ExternalRuleConstant.ID_TYPE_MAGIC)  &&
			    		!e.getKey().contains(ExternalRuleConstant.ID_TYPE_COMPASS_CUSTOMER_ID)  &&
			    		!e.getKey().contains(ExternalRuleConstant.ID_TYPE_PERSON_EPUCID)  &&
			    		!e.getKey().contains(ExternalRuleConstant.ID_TYPE_STOUCHID)  &&
			    		!e.getKey().contains(ExternalRuleConstant.ID_TYPE_TDSID)
			    		&& !e.getKey().contains(ExternalRuleConstant.ID_TYPE_BPID)) {
			    	isMPCIdenAvailable = true;
			    	break;
			    }
			}
			//If MPC record is available then remove FSWS record.
			HashMap<String, XIdentifierBObjExt> tempPartyIdentMap = new HashMap<String, XIdentifierBObjExt>();
			
			tempPartyIdentMap.putAll(partyIdentMap);
			if(isMPCIdenAvailable){
			for (Entry<String, XIdentifierBObjExt> e : tempPartyIdentMap.entrySet()) {
				if (e.getKey().contains(ExternalRuleConstant.FS_WHOLESALE)){
					partyIdentMap.remove(e.getKey());
				}
				
			}
			}
			
			}
	
			// For Party Contact Method
	
			Vector<XContactMethodGroupBObjExt> vecTempPartyContactMethodBObj = new Vector<XContactMethodGroupBObjExt>();
	
			vecTempPartyContactMethodBObj = party.getItemsTCRMPartyContactMethodBObj();
	
			String firstPartyContMethodUsageType = null;
	
			String secondPartyContMethodUsageType = null;
	
	
			firstFS = null;
	
			secondFS = null;
	
			for (int j = 0; j < vecTempPartyContactMethodBObj.size(); j++) {
	
				XContactMethodGroupBObjExt partyContMethBObj = (XContactMethodGroupBObjExt) vecTempPartyContactMethodBObj.get(j);

				//Added DELETED check for ignore Delete merge TF
				if(!ExternalRuleConstant.VALUE_DELETED.equals
						(partyContMethBObj.getTCRMContactMethodBObj().getReferenceNumber()))
				{
				firstPartySource = partyContMethBObj.getSourceIdentifierType();
	
				firstPartyContMethodUsageType = partyContMethBObj.getContactMethodUsageType();
	
				firstFS = partyContMethBObj.getXContactRetailerFlag();
				
				//BPID survive
				if(partyContMethBObj.getX_BPID()!=null){
					partyContMethMap.put(partyContMethBObj.getX_BPID()+firstPartyContMethodUsageType, partyContMethBObj);
					continue;
				}
	
				// If FS, Key = Contact Method Usage Type + FS
				if (firstFS != null && firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {
	
					mapKey = firstPartyContMethodUsageType + firstFS;
	
				}
				// Otherwise, Key = Contact Method Usage Type
				// Added  :THA FS Delta Changes : 11/13/2020
				else if (partyContMethBObj.getXContactRetailerFlag() != null
						&& partyContMethBObj.getXContactRetailerFlag().equals(ExternalRuleConstant.FS_WHOLESALE)) {
	
					// Otherwise Key = Name Usage type
					mapKey = firstPartyContMethodUsageType+ExternalRuleConstant.FS_WHOLESALE;
	
				}
				else {
	
					mapKey = firstPartyContMethodUsageType;
				}
	
				// FSWS objects do not participate in Merge
				// Added  :THA FS Delta Changes : 11/13/2020
				if ((firstFS == null) || (firstFS != null && !firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE))
						||firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE)) {
					if (!partyContMethMap.containsKey(mapKey)) {
	
						partyContMethMap.put(mapKey, partyContMethBObj);
	
					} else {
	
						XContactMethodGroupBObjExt contMethodBObjInMap = partyContMethMap.get(mapKey);
	
						secondPartySource = contMethodBObjInMap.getSourceIdentifierType();
	
						secondPartyContMethodUsageType = contMethodBObjInMap.getContactMethodUsageType();
	
						secondFS = contMethodBObjInMap.getXContactRetailerFlag();
	
						if (firstPartyContMethodUsageType.equalsIgnoreCase(secondPartyContMethodUsageType)) {
	
							Timestamp party1CreatedDt = DateFormatter.getTimestamp(contMethodBObjInMap.getXLastModifiedSystemDate());
	
							Timestamp party2CreatedDt = DateFormatter.getTimestamp(partyContMethBObj.getXLastModifiedSystemDate());
	
							if (firstPartySource.equalsIgnoreCase(secondPartySource)) {
								// Same source
	
								if (party1CreatedDt.after(party2CreatedDt)) {
	
									// If FS, Key = Contact Method Usage Type + FS
									if (secondFS != null && secondFS.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {
	
										mapKey = secondPartyContMethodUsageType + secondFS;
	
									}
									// Otherwise, Key = Contact Method Usage Type
									else {
	
										mapKey = secondPartyContMethodUsageType;
	
									}
	
									partyContMethMap.put(mapKey,contMethodBObjInMap);
								}
	
								else if (party1CreatedDt.before(party2CreatedDt)) {
									// If FS, Key = Contact Method Usage Type + FS
									// Added  :THA FS Delta Changes : 11/13/2020
									if (firstFS != null && firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE)) {
	
										mapKey = firstPartyContMethodUsageType + firstFS;
	
									}
									// Otherwise, Key = Contact Method Usage Type
									else {
	
										mapKey = firstPartyContMethodUsageType;
	
									}
	
									partyContMethMap.put(mapKey, partyContMethBObj);
									
								} else if (party1CreatedDt.equals(party2CreatedDt)) {
									// If FS, Key = Contact Method Usage Type + FS
									// Added  :THA FS Delta Changes : 11/13/2020
									if (firstFS != null && firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE)) {

										mapKey = firstPartyContMethodUsageType + firstFS;
									}
									// Otherwise, Key = Contact Method Usage Type
									else {

										mapKey = firstPartyContMethodUsageType;

									}

									partyContMethMap.put(mapKey,partyContMethBObj);

								}
	
							} else {
								// Different source
								if (firstPartySource.equalsIgnoreCase(ExternalRuleConstant.SOURCE_IDENTIFIER_TYPE_AUTOLINE)) {
	
									// If FS, Key = Contact Method Usage Type + FS
									// Added  :THA FS Delta Changes : 11/13/2020
									if (firstFS != null && firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE)) {
	
										mapKey = firstPartyContMethodUsageType + firstFS;
	
									}
									// Otherwise, Key = Contact Method Usage Type
									else {
	
										mapKey = firstPartyContMethodUsageType;
	
									}
	
									partyContMethMap.put(mapKey, partyContMethBObj);
	
								} else {
	
									// If FS, Key = Contact Method Usage Type + FS
									if (secondFS != null && secondFS.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {
	
										mapKey = secondPartyContMethodUsageType + secondFS;
	
									}
									// Otherwise, Key = Contact Method Usage Type
									else {
	
										mapKey = secondPartyContMethodUsageType;
	
									}
	
									partyContMethMap.put(mapKey,partyContMethBObj);

									}
								}
							}
						}
					}
				}
			}
			// Added  :THA FS Delta Changes : 11/13/2020
			//Find MPC WS record.
			
			boolean isContactMPCAvailable = false;
			for (Entry<String, XContactMethodGroupBObjExt> e : partyContMethMap.entrySet()) {
			    if (!e.getKey().contains(ExternalRuleConstant.FS_WHOLESALE) && !e.getKey().contains(ExternalRuleConstant.FS_VALUE)
			    		&& (e.getValue()).getX_BPID()==null) {
			    	isContactMPCAvailable = true;
			    	break;
			    }
			}
			//If MPC record is available then remove FSWS record.
			HashMap<String, XContactMethodGroupBObjExt> tempContactMap = new HashMap<String, XContactMethodGroupBObjExt>();
			
			tempContactMap.putAll(partyContMethMap);
			if(isContactMPCAvailable){
				for (Entry<String, XContactMethodGroupBObjExt> e : tempContactMap.entrySet()) {
					if (e.getKey().contains(ExternalRuleConstant.FS_WHOLESALE)){
						partyContMethMap.remove(e.getKey());
					}
				}
			}
			
			//For Party Admin Contequiv
			
			Vector<XContEquivBObjExt> vecTempAdminContequivBObj = null;
	
			vecTempAdminContequivBObj = party.getItemsTCRMAdminContEquivBObj();
			
			String firstPartyAdminSysType = null;
			
			String secondPartyAdminSysType = null;
			
			String firstPartyAdminSysValue = null;
			
			String secondPartyAdminSysValue = null;
			
			XContEquivBObjExt newadminContEquivBObj = null;
			
			firstRetailerId = null;
			
			secondRetailerId = null;
			
			firstFS = null;
			
			secondFS = null;
			
					
			for (int j = 0; j < vecTempAdminContequivBObj.size(); j++) {
	
				XContEquivBObjExt partyAdminContequivBObj= (XContEquivBObjExt) vecTempAdminContequivBObj.get(j);			
				
				firstPartyAdminSysValue = partyAdminContequivBObj.getAdminSystemValue();
				
				firstPartyAdminSysType = partyAdminContequivBObj.getAdminSystemType();
				
				firstRetailerId = partyAdminContequivBObj.getXRetailerId();
				
				firstRetailerFlag = partyAdminContequivBObj.getXSourceRetailerFlag();
				
				firstFS = partyAdminContequivBObj.getXSourceRetailerFlag();
				
				if(firstRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_N)){
					
					// MapKey = Retailer Flag + Admin System System type 
					
					mapKey = firstRetailerFlag + firstPartyAdminSysType ;
						
					
				}else if(firstFS!= null && firstFS.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_Y)){
					//Retailer
					
					// MapKey = Retailer Flag + Admin System System type
					
					mapKey = firstRetailerFlag + firstPartyAdminSysType + firstRetailerId;
					
					
											
				}else if(firstFS!= null && firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)){
					//Retailer
					
					// MapKey = Retailer Flag + Admin System System type
					
					mapKey = firstFS + firstPartyAdminSysType ;
					
											
				}
				
				//FSChange: THA Delta Changes | 17-11-2020
				else if(firstFS!= null && firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE)){
					//Retailer
					
					// MapKey = Retailer Flag + Admin System System type
					
					mapKey = firstFS + firstPartyAdminSysType ;
					
											
				}
				
				//FSWS objects do not participate in Merge
				//FSChange: THA Delta Changes | 17-11-2020
				if ( (firstFS == null) || (firstFS != null && !firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE) )
						|| (firstFS != null && firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE) )){
					
					if (!partyAdminConteqMap.containsKey(mapKey)) {
						
						partyAdminConteqMap.put(mapKey,partyAdminContequivBObj);
				   			
					} else {
		
						XContEquivBObjExt partyAdminContequivBObjInMap = (XContEquivBObjExt) partyAdminConteqMap.get(mapKey);
						
						secondPartyAdminSysValue = partyAdminContequivBObjInMap.getAdminSystemValue();
						
						secondPartyAdminSysType = partyAdminContequivBObjInMap.getAdminSystemType();
						
						secondRetailerId = partyAdminContequivBObjInMap.getXRetailerId();
						
						secondRetailerFlag = partyAdminContequivBObjInMap.getXSourceRetailerFlag();
						
						secondFS = partyAdminContequivBObjInMap.getXSourceRetailerFlag();
		
						Timestamp party1CreatedDt = DateFormatter.getTimestamp(partyAdminContequivBObj.getContEquivLastUpdateDate());
		
						Timestamp party2CreatedDt = DateFormatter.getTimestamp( partyAdminContequivBObjInMap.getContEquivLastUpdateDate());
						
						if(firstPartyAdminSysType.equalsIgnoreCase(secondPartyAdminSysType)){
															
							if(xIdenBObj == null){
							
								if (party1CreatedDt.before(party2CreatedDt)) {
									
									if(firstRetailerFlag!= null && firstRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_Y)){
										//Retailer Copy
										//MapKey = Retailer Flag + Admin System System type + Retailer ID
										
										mapKey = firstRetailerFlag + firstPartyAdminSysType + firstRetailerId;
										
										
									}else if(firstRetailerFlag!= null && firstRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_N)){
										//Wholesale Copy											
										// MapKey = Retailer Flag + Admin System System type
										mapKey = firstRetailerFlag + firstPartyAdminSysType;
										
									
									}else if(firstRetailerFlag!= null && firstRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)){
										//If FS, MapKey = FS + Admin System System type
										
										mapKey = firstFS + firstPartyAdminSysType ;
									}
									//FSChange: THA Delta Changes | 17-11-2020
									else if(firstRetailerFlag!= null && firstRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE)){
										//If FS, MapKey = FS + Admin System System type
										
										mapKey = firstFS + firstPartyAdminSysType ;
									}
									
										partyAdminConteqMap.put(mapKey,partyAdminContequivBObj);
							
								}else{
									
									if(secondRetailerFlag!= null && secondRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_Y)){
										//Retailer Copy
										//MapKey = Retailer Flag + Admin System System type + Retailer ID
										
										mapKey = secondRetailerFlag + secondPartyAdminSysType + secondRetailerId;
										
										
									}else if(secondRetailerFlag!= null && secondRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_N)){
										//Wholesale Copy											
										// MapKey = Retailer Flag + Admin System System type
										mapKey = secondRetailerFlag + secondPartyAdminSysType;
										
									
									}else if(secondRetailerFlag != null && secondRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)){
										//If FS, MapKey = FS + Admin System System type
										
										mapKey = secondFS + secondPartyAdminSysType ;
									}
									
									//FSChange: THA Delta Changes | 17-11-2020
									else if(secondRetailerFlag != null && secondRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE)){
										//If FS, MapKey = FS + Admin System System type
										
										mapKey = secondFS + secondPartyAdminSysType ;
									}
								
									partyAdminConteqMap.put(mapKey,partyAdminContequivBObjInMap);
								}
							
							} else{
								String newCont = xIdenBObj.getPartyId();
								
								if(newCont.equalsIgnoreCase(partyAdminContequivBObj.getPartyId())){
									//both belongs to same party
									
									if(firstRetailerFlag != null && firstRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_Y)){
										//Retailer Copy
										
										// MapKey = Retailer Flag + Admin System System type + RetailerId 
										
										mapKey = firstRetailerFlag + firstPartyAdminSysType + firstRetailerId;
										
									}else if(firstRetailerFlag != null && firstRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_N)){
										//Wholesale Copy
										
										//MapKey = Retailer Flag + Admin System System type 
										
										mapKey = firstRetailerFlag + firstPartyAdminSysType ;
										
										
										
									}else if(firstRetailerFlag != null && firstRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)){
										
										mapKey = firstFS + firstPartyAdminSysType;
									}
									//FSChange: THA Delta Changes | 17-11-2020
									else if(firstRetailerFlag != null && firstRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE)){
										
										mapKey = firstFS + firstPartyAdminSysType;
									}
									
									partyAdminConteqMap.put(mapKey,partyAdminContequivBObj);
								
								}
							}
						}
					}
				}
			}
			
			// Added  :THA FS Delta Changes : 11/13/2020
						//Find MPC WS record.
			if(!partyAdminConteqMap.isEmpty())
			{
			boolean isMPCContEquivAvailable = false;
			for (Entry<String, TCRMAdminContEquivBObj> e : partyAdminConteqMap.entrySet()) {
			    if (!e.getKey().contains(ExternalRuleConstant.FS_WHOLESALE) && !e.getKey().contains(ExternalRuleConstant.FS_VALUE)
			    		&& !e.getKey().contains(ExternalRuleConstant.CHARACTER_Y)) {
			    	isMPCContEquivAvailable = true;
			    	break;
			    }
			}
			HashMap<String, TCRMAdminContEquivBObj> tempPartyAdminConteqMap = new HashMap<String, TCRMAdminContEquivBObj>();
			tempPartyAdminConteqMap.putAll(partyAdminConteqMap);
			//If MPC record is available then remove FSWS record.
			if(isMPCContEquivAvailable){
			for (Entry<String, TCRMAdminContEquivBObj> e : tempPartyAdminConteqMap.entrySet()) {
				if (e.getKey().contains(ExternalRuleConstant.FS_WHOLESALE)){
					partyAdminConteqMap.remove(e.getKey());
				}
				
			}
			}
			}
		}
	
	}
			
			

		// PartyAddress
		partyAddressMap = survivedPartyAddressDetails(vecAllParty,partyAddressMap, control);

		HashMap<String, HashMap> partyMap = new HashMap<String, HashMap>();
		partyMap.put(ExternalRuleConstant.SURVIVED_MAP_NAME, personNameMap);
		partyMap.put(ExternalRuleConstant.SURVIVED_MAP_ADDRESS, partyAddressMap);
		partyMap.put(ExternalRuleConstant.SURVIVED_MAP_IDENTIFIER,
				partyIdentMap);
		partyMap.put(ExternalRuleConstant.SURVIVED_MAP_CONTACTMETHOD,
				partyContMethMap);
		partyMap.put(ExternalRuleConstant.SURVIVED_MAP_CONTEQUIV,
				partyAdminConteqMap);

		return partyMap;
	}

	private HashMap<String, XAddressGroupBObjExt> survivedPartyAddressDetails( Vector<XPersonBObjExt> vecAllParty, HashMap<String, XAddressGroupBObjExt> partyAddressMap, DWLControl control) throws Exception {
		Vector<XAddressGroupBObjExt> vecAllAddressBObj = new Vector<XAddressGroupBObjExt>();
		
		for (XPersonBObjExt personBObj : vecAllParty) {
			//start of change for DELETED check MYS
			Vector<XAddressGroupBObjExt> tempVecAddressBObj = personBObj.getItemsTCRMPartyAddressBObj();
			
			if(personBObj.getXMarketName().equalsIgnoreCase(ExternalRuleConstant.MARKET_NAME_MALAYSIA))
			{
				for (Iterator<XAddressGroupBObjExt> addressIterator = tempVecAddressBObj.iterator(); addressIterator.hasNext();) {
					XAddressGroupBObjExt tempXAddressGroupBObjExt = (XAddressGroupBObjExt) addressIterator.next();

					//ignore Delete merge TF MYS
					if(!ExternalRuleConstant.VALUE_DELETED.equals(tempXAddressGroupBObjExt.getTCRMAddressBObj().getAddressLineOne())){
						vecAllAddressBObj.add(tempXAddressGroupBObjExt);
					}else{
						//remove DELETED address from original vector
						addressIterator.remove();
					}
				}
				
			}else{
				vecAllAddressBObj.addAll(personBObj.getItemsTCRMPartyAddressBObj());
			}
		}
		if (vecAllAddressBObj.size() == 0) {

		} else {

			// For Party Address
			XPersonBObjExt incomingPersonBObj = (XPersonBObjExt) vecAllParty
					.get(0);

			// For MYS INI
			if (incomingPersonBObj.getXMarketName().equalsIgnoreCase(ExternalRuleConstant.MARKET_NAME_MALAYSIA) &&
					incomingPersonBObj.getXBatchInd().equalsIgnoreCase(ExternalRuleConstant.BATCH_IND_Y) &&
					incomingPersonBObj.getSourceIdentifierType().equalsIgnoreCase(ExternalRuleConstant.SOURCE_IDENTIFIER_TYPE_AUTOLINE)) {
				
				String mapKey = null;

				String wsAddrTypeSet = null;

				HashMap<String, Vector<XAddressGroupBObjExt>> retailerAddressMap = new HashMap<String, Vector<XAddressGroupBObjExt>>();

				Vector<XAddressGroupBObjExt> vecIncomingPartyAddressBObj = new Vector<XAddressGroupBObjExt>();

				Vector<XAddressGroupBObjExt> vecWSPartyAddressBObj = new Vector<XAddressGroupBObjExt>();

				Vector<XAddressGroupBObjExt> vecRetailerPartyAddressBObj = new Vector<XAddressGroupBObjExt>();

			

				XAddressGroupBObjExt incomingHomeAddrBObj = null;

				// Incoming Party addresses
				vecIncomingPartyAddressBObj = incomingPersonBObj.getItemsTCRMPartyAddressBObj();

				for (XAddressGroupBObjExt incomingAddrBObj : vecIncomingPartyAddressBObj) {

					if (incomingAddrBObj.getXAddressRetailerFlag().equalsIgnoreCase(ExternalRuleConstant.CHARACTER_Y)) {

						// partyAddressMap.put(ExternalRuleConstant.ADDRESS_USAGE_TYPE_P,incomingAddrBObj);

						vecRetailerPartyAddressBObj.add(incomingAddrBObj);

						retailerAddressMap.put(incomingAddrBObj.getXRetailerId(), null);

					} else {

						incomingHomeAddrBObj = incomingAddrBObj;

						vecWSPartyAddressBObj.add(incomingHomeAddrBObj);

					}
				}

				// Get all Party Addresses of suspects
				for (int i = 1; i < vecAllParty.size(); i++) {

					XPersonBObjExt tempPersonBObj = (XPersonBObjExt) vecAllParty.get(i);

					Vector<XAddressGroupBObjExt> vecTempAddressBObj = tempPersonBObj.getItemsTCRMPartyAddressBObj();

					if (vecTempAddressBObj.size() != 0) {

						for (XAddressGroupBObjExt tempAddrBObj : vecTempAddressBObj) {

							if (tempAddrBObj.getXAddressRetailerFlag().equalsIgnoreCase(ExternalRuleConstant.CHARACTER_Y)) {

								vecRetailerPartyAddressBObj.add(tempAddrBObj);

								retailerAddressMap.put(tempAddrBObj.getXRetailerId(), null);

							} else {

								vecWSPartyAddressBObj.add(tempAddrBObj);
							}
						}
					}
				}

				// For Each Retailer

				Set<String> keySet = new HashSet<String>();

				keySet.addAll(retailerAddressMap.keySet());

				Vector<XAddressGroupBObjExt> tempRetAddrBObj;

				for (int i = 0; i < vecRetailerPartyAddressBObj.size(); i++) {

					tempRetAddrBObj = new Vector<XAddressGroupBObjExt>();

					XAddressGroupBObjExt tempAddrGroupBObj = vecRetailerPartyAddressBObj.elementAt(i);

					String retailerId = tempAddrGroupBObj.getXRetailerId();

					if (retailerAddressMap.get(retailerId) != null) {

						tempRetAddrBObj.addAll(retailerAddressMap.get(retailerId));

					}

					tempRetAddrBObj.add(tempAddrGroupBObj);

					retailerAddressMap.put(retailerId, tempRetAddrBObj);
					// tempRetAddrBObj.removeAllElements();

				}

				vecRetailerPartyAddressBObj.removeAllElements();

				for (String key : keySet) {

					vecRetailerPartyAddressBObj.addAll(retailerAddressMap.get(key));

					for (int i = 0; i < vecRetailerPartyAddressBObj.size(); i++) {

						XAddressGroupBObjExt tempAddrGroupBObj = vecRetailerPartyAddressBObj.elementAt(i);

						mapKey =  tempAddrGroupBObj.getXRetailerId() + tempAddrGroupBObj.getXAddressRetailerFlag();

						if (!(partyAddressMap.containsKey(mapKey))) {

							partyAddressMap.put(mapKey, tempAddrGroupBObj);

						}else{
							
							XAddressGroupBObjExt retailerAddressBObjInMap = partyAddressMap.get(mapKey);
							
							Timestamp party1CreatedDt = DateFormatter.getTimestamp(tempAddrGroupBObj.getAddressGroupLastUpdateDate());

							Timestamp party2CreatedDt = DateFormatter.getTimestamp(retailerAddressBObjInMap.getAddressGroupLastUpdateDate());
							
							if(party1CreatedDt.after(party2CreatedDt)){
								
								partyAddressMap.put(mapKey, tempAddrGroupBObj);
								
							}else{
								
								partyAddressMap.put(mapKey, retailerAddressBObjInMap);
								
							}
						}
					}
					
					vecRetailerPartyAddressBObj.removeAllElements();
					

				}

				// Sort listWSPartyAddressBObj by LastModifiedDate
 
				if (vecWSPartyAddressBObj.size() != 0) {
					for (int i = 0; i < vecWSPartyAddressBObj.size(); i++) {

						XAddressGroupBObjExt wsPartyAddressGroupBObj = vecWSPartyAddressBObj
								.elementAt(i);

						if (i == 0) {

							wsPartyAddressGroupBObj
									.setAddressUsageType(ExternalRuleConstant.ADDRESS_USAGE_TYPE_HOME_ADDRESS);

							wsPartyAddressGroupBObj
									.setAddressUsageValue(ExternalRuleConstant.ADDRESS_USAGE_VALUE_HOME_ADDRESS);

							mapKey = wsPartyAddressGroupBObj
									.getXAddressRetailerFlag()
									+ wsPartyAddressGroupBObj
											.getTCRMAddressBObj()
											.getAddressLineOne()
									+ wsPartyAddressGroupBObj
											.getTCRMAddressBObj()
											.getAddressLineTwo()
									+ wsPartyAddressGroupBObj
											.getTCRMAddressBObj()
											.getAddressLineThree()
									+ wsPartyAddressGroupBObj
											.getTCRMAddressBObj().getCity()
									+ wsPartyAddressGroupBObj
											.getTCRMAddressBObj()
											.getZipPostalCode()
									+ wsPartyAddressGroupBObj
											.getTCRMAddressBObj()
											.getResidenceNumber()
									+ wsPartyAddressGroupBObj
											.getTCRMAddressBObj()
											.getCountryType();

							partyAddressMap
									.put(mapKey, wsPartyAddressGroupBObj);

							wsAddrTypeSet = ExternalRuleConstant.ADDRESS_USAGE_TYPE_HOME_ADDRESS;

						} else if (wsAddrTypeSet
								.equalsIgnoreCase(ExternalRuleConstant.ADDRESS_USAGE_TYPE_HOME_ADDRESS)) {

							mapKey = wsPartyAddressGroupBObj
									.getXAddressRetailerFlag()
									+ wsPartyAddressGroupBObj
											.getTCRMAddressBObj()
											.getAddressLineOne()
									+ wsPartyAddressGroupBObj
											.getTCRMAddressBObj()
											.getAddressLineTwo()
									+ wsPartyAddressGroupBObj
											.getTCRMAddressBObj()
											.getAddressLineThree()
									+ wsPartyAddressGroupBObj
											.getTCRMAddressBObj().getCity()
									+ wsPartyAddressGroupBObj
											.getTCRMAddressBObj()
											.getZipPostalCode()
									+ wsPartyAddressGroupBObj
											.getTCRMAddressBObj()
											.getResidenceNumber()
									+ wsPartyAddressGroupBObj
											.getTCRMAddressBObj()
											.getCountryType();

							if (!(partyAddressMap.containsKey(mapKey))) {

								wsPartyAddressGroupBObj
										.setAddressUsageType(ExternalRuleConstant.ADDRESS_USAGE_TYPE_OTHER_ADDRESS_1);

								wsPartyAddressGroupBObj
										.setAddressUsageValue(ExternalRuleConstant.ADDRESS_USAGE_VALUE_OTHER_ADDRESS_1);

								partyAddressMap.put(mapKey,
										wsPartyAddressGroupBObj);

								wsAddrTypeSet = ExternalRuleConstant.ADDRESS_USAGE_TYPE_OTHER_ADDRESS_1;

							}

						} else if (wsAddrTypeSet
								.equalsIgnoreCase(ExternalRuleConstant.ADDRESS_USAGE_TYPE_OTHER_ADDRESS_1)) {

							mapKey = wsPartyAddressGroupBObj
									.getXAddressRetailerFlag()
									+ wsPartyAddressGroupBObj
											.getTCRMAddressBObj()
											.getAddressLineOne()
									+ wsPartyAddressGroupBObj
											.getTCRMAddressBObj()
											.getAddressLineTwo()
									+ wsPartyAddressGroupBObj
											.getTCRMAddressBObj()
											.getAddressLineThree()
									+ wsPartyAddressGroupBObj
											.getTCRMAddressBObj().getCity()
									+ wsPartyAddressGroupBObj
											.getTCRMAddressBObj()
											.getZipPostalCode()
									+ wsPartyAddressGroupBObj
											.getTCRMAddressBObj()
											.getResidenceNumber()
									+ wsPartyAddressGroupBObj
											.getTCRMAddressBObj()
											.getCountryType();

							if (!(partyAddressMap.containsKey(mapKey))) {

								wsPartyAddressGroupBObj
										.setAddressUsageType(ExternalRuleConstant.ADDRESS_USAGE_TYPE_OTHER_ADDRESS_2);

								wsPartyAddressGroupBObj
										.setAddressUsageValue(ExternalRuleConstant.ADDRESS_USAGE_VALUE_OTHER_ADDRESS_2);

								partyAddressMap.put(mapKey,
										wsPartyAddressGroupBObj);

								wsAddrTypeSet = ExternalRuleConstant.ADDRESS_USAGE_TYPE_OTHER_ADDRESS_2;

							}

						} else if (wsAddrTypeSet
								.equalsIgnoreCase(ExternalRuleConstant.ADDRESS_USAGE_TYPE_OTHER_ADDRESS_2)) {

							mapKey = wsPartyAddressGroupBObj
									.getXAddressRetailerFlag()
									+ wsPartyAddressGroupBObj
											.getTCRMAddressBObj()
											.getAddressLineOne()
									+ wsPartyAddressGroupBObj
											.getTCRMAddressBObj()
											.getAddressLineTwo()
									+ wsPartyAddressGroupBObj
											.getTCRMAddressBObj()
											.getAddressLineThree()
									+ wsPartyAddressGroupBObj
											.getTCRMAddressBObj().getCity()
									+ wsPartyAddressGroupBObj
											.getTCRMAddressBObj()
											.getZipPostalCode()
									+ wsPartyAddressGroupBObj
											.getTCRMAddressBObj()
											.getResidenceNumber()
									+ wsPartyAddressGroupBObj
											.getTCRMAddressBObj()
											.getCountryType();

							if (!(partyAddressMap.containsKey(mapKey))) {

								wsPartyAddressGroupBObj
										.setAddressUsageType(ExternalRuleConstant.ADDRESS_USAGE_TYPE_OTHER_ADDRESS_3);

								wsPartyAddressGroupBObj
										.setAddressUsageValue(ExternalRuleConstant.ADDRESS_USAGE_VALUE_OTHER_ADDRESS_3);

								partyAddressMap.put(mapKey,
										wsPartyAddressGroupBObj);

								wsAddrTypeSet = ExternalRuleConstant.ADDRESS_USAGE_TYPE_OTHER_ADDRESS_3;

							}

						}
					}
				}

				// Change Retail Address Usage Type on the basis of Wholesale
				// Address Usage Type
				keySet = partyAddressMap.keySet();

				vecWSPartyAddressBObj.removeAllElements();
				vecRetailerPartyAddressBObj.removeAllElements();
				// Set<String> retailerIdSet = new HashSet<String>();

				for (String key : keySet) {
					if (!(key.endsWith(ExternalRuleConstant.CHARACTER_Y))) {

						vecWSPartyAddressBObj.add(partyAddressMap.get(key));

					} else {

						vecRetailerPartyAddressBObj.add(partyAddressMap
								.get(key));
					}
				}

				for (XAddressGroupBObjExt retailerPartyAddressBObj : vecRetailerPartyAddressBObj) {

					retailerPartyAddressBObj.setAddressUsageValue(ExternalRuleConstant.ADDRESS_USAGE_VALUE_P);

					retailerPartyAddressBObj.setAddressUsageType(ExternalRuleConstant.ADDRESS_USAGE_TYPE_P);

					for (XAddressGroupBObjExt wsPartyAddressBObj : vecWSPartyAddressBObj) {

						String retailContId = retailerPartyAddressBObj.getPartyId();

						String wsContId = wsPartyAddressBObj.getPartyId();

						if (wsContId.equalsIgnoreCase(retailContId)) {

							// retailerIdSet.add(retailerPartyAddressBObj.getPartyId());

							String wsAddressUsageType = wsPartyAddressBObj
									.getAddressUsageType();

							String wsAddressUsageValue = wsPartyAddressBObj
									.getAddressUsageValue();

							if (retailerPartyAddressBObj != null) {

								retailerPartyAddressBObj.setAddressUsageValue(wsAddressUsageValue);

								retailerPartyAddressBObj.setAddressUsageType(wsAddressUsageType);

							}
							continue;

						}
					}

				}

			} else if (incomingPersonBObj.getXBatchInd().equalsIgnoreCase(ExternalRuleConstant.BATCH_IND_N)
					&& incomingPersonBObj.getSourceIdentifierType().equalsIgnoreCase(ExternalRuleConstant.SOURCE_IDENTIFIER_TYPE_AUTOLINE)
					&& incomingPersonBObj.getXMarketName().equalsIgnoreCase(ExternalRuleConstant.MARKET_NAME_THAILAND)) {
				
				// Delta  load for  Thailand
				HashMap<String, Vector<XAddressGroupBObjExt>> retailerAddressMap = new HashMap<String, Vector<XAddressGroupBObjExt>>();


				String mapKey = null;


				Vector<XAddressGroupBObjExt> vecRetailerPartyAddressBObj = new Vector<XAddressGroupBObjExt>();
				
				Vector<XAddressGroupBObjExt> vecWSPartyAddressBObj = new Vector<XAddressGroupBObjExt>();
				
				Vector<XAddressGroupBObjExt> vecFinalWSPartyAddressBObj = new Vector<XAddressGroupBObjExt>();


				Vector<XAddressGroupBObjExt> vecHomePartyAddressBObj = new Vector<XAddressGroupBObjExt>();

				Vector<XAddressGroupBObjExt> vecOth1PartyAddressBObj = new Vector<XAddressGroupBObjExt>();

				Vector<XAddressGroupBObjExt> vecOth2PartyAddressBObj = new Vector<XAddressGroupBObjExt>();

				Vector<XAddressGroupBObjExt> vecOth3PartyAddressBObj = new Vector<XAddressGroupBObjExt>();
				
				Vector<XAddressGroupBObjExt> vecFSPartyAddressBObj = new Vector<XAddressGroupBObjExt>();


				
				Set<String> wsAddressUsageTpSet = new HashSet<String>();
				

				// Get all Party Addresses of suspects
				for (int i = 0; i < vecAllParty.size(); i++) {

					XPersonBObjExt tempPersonBObj = (XPersonBObjExt) vecAllParty.get(i);

					Vector<XAddressGroupBObjExt> vecTempAddressBObj = tempPersonBObj.getItemsTCRMPartyAddressBObj();

					for (XAddressGroupBObjExt tempAddrBObj : vecTempAddressBObj) {

						if (tempAddrBObj.getAddressUsageType().equals(ExternalRuleConstant.ADDRESS_USAGE_TYPE_HOME_ADDRESS)
								&& tempAddrBObj.getXAddressRetailerFlag().equalsIgnoreCase(ExternalRuleConstant.ADDRESS_RETAILER_FLAG_N)) {
							
							vecFinalWSPartyAddressBObj.add(tempAddrBObj);
							wsAddressUsageTpSet.add(ExternalRuleConstant.ADDRESS_USAGE_TYPE_HOME_ADDRESS);
							
							vecHomePartyAddressBObj.add(tempAddrBObj);
							
							

						} else if (tempAddrBObj.getAddressUsageType().equals(ExternalRuleConstant.ADDRESS_USAGE_TYPE_OTHER_ADDRESS_1)
								&& tempAddrBObj.getXAddressRetailerFlag().equalsIgnoreCase(ExternalRuleConstant.ADDRESS_RETAILER_FLAG_N)) {
							
							vecFinalWSPartyAddressBObj.add(tempAddrBObj);
							wsAddressUsageTpSet.add(ExternalRuleConstant.ADDRESS_USAGE_TYPE_OTHER_ADDRESS_1);
							vecOth1PartyAddressBObj.add(tempAddrBObj);

						} else if (tempAddrBObj.getAddressUsageType().equals(ExternalRuleConstant.ADDRESS_USAGE_TYPE_OTHER_ADDRESS_2)
								&& tempAddrBObj.getXAddressRetailerFlag().equalsIgnoreCase(ExternalRuleConstant.ADDRESS_RETAILER_FLAG_N)) {
							
							vecFinalWSPartyAddressBObj.add(tempAddrBObj);
							wsAddressUsageTpSet.add(ExternalRuleConstant.ADDRESS_USAGE_TYPE_OTHER_ADDRESS_2);
							vecOth2PartyAddressBObj.add(tempAddrBObj);

						} else if (tempAddrBObj.getAddressUsageType().equals(ExternalRuleConstant.ADDRESS_USAGE_TYPE_OTHER_ADDRESS_3)
								&& tempAddrBObj.getXAddressRetailerFlag().equalsIgnoreCase(ExternalRuleConstant.ADDRESS_RETAILER_FLAG_N)) {
							
							vecFinalWSPartyAddressBObj.add(tempAddrBObj);
							wsAddressUsageTpSet.add(ExternalRuleConstant.ADDRESS_USAGE_TYPE_OTHER_ADDRESS_3);
							vecOth3PartyAddressBObj.add(tempAddrBObj);

						} else if (tempAddrBObj.getXAddressRetailerFlag().equalsIgnoreCase(ExternalRuleConstant.ADDRESS_RETAILER_FLAG_Y)) {

							retailerAddressMap.put(tempAddrBObj.getXRetailerId(), null);

							vecRetailerPartyAddressBObj.add(tempAddrBObj);

						}else if (tempAddrBObj.getXAddressRetailerFlag().equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {
							
							vecFSPartyAddressBObj.add(tempAddrBObj);
						
						}
					}
				}
				
				// For Each Retailer

				Set<String> keySet = new HashSet<String>();

				keySet.addAll(retailerAddressMap.keySet());

				Vector<XAddressGroupBObjExt> tempRetAddrBObj;

				for (int i = 0; i < vecRetailerPartyAddressBObj.size(); i++) {

					tempRetAddrBObj = new Vector<XAddressGroupBObjExt>();

					XAddressGroupBObjExt tempAddrGroupBObj = vecRetailerPartyAddressBObj.elementAt(i);

					String retailerId = tempAddrGroupBObj.getXRetailerId();

					if (retailerAddressMap.get(retailerId) != null) {

						tempRetAddrBObj.addAll(retailerAddressMap.get(retailerId));

					}

					tempRetAddrBObj.add(tempAddrGroupBObj);

					retailerAddressMap.put(retailerId, tempRetAddrBObj);
					// tempRetAddrBObj.removeAllElements();

				}

				vecRetailerPartyAddressBObj.removeAllElements();

				for (String key : keySet) {

					vecRetailerPartyAddressBObj.addAll(retailerAddressMap.get(key));

					for (int i = 0; i < vecRetailerPartyAddressBObj.size(); i++) {

						XAddressGroupBObjExt tempAddrGroupBObj = vecRetailerPartyAddressBObj.elementAt(i);

						mapKey =  tempAddrGroupBObj.getXRetailerId() + tempAddrGroupBObj.getXAddressRetailerFlag();

						if (!(partyAddressMap.containsKey(mapKey))) {

							partyAddressMap.put(mapKey, tempAddrGroupBObj);

						}else{
							
							XAddressGroupBObjExt retailerAddressBObjInMap = partyAddressMap.get(mapKey);
							
							Timestamp party1CreatedDt = DateFormatter.getTimestamp(tempAddrGroupBObj.getXLastModifiedSystemDate());

							Timestamp party2CreatedDt = DateFormatter.getTimestamp(retailerAddressBObjInMap.getXLastModifiedSystemDate());
							
							if(party1CreatedDt.after(party2CreatedDt)){
								
								partyAddressMap.put(mapKey, tempAddrGroupBObj);
								
							}else{
								
								partyAddressMap.put(mapKey, retailerAddressBObjInMap);
								
							}
						}
					}
					
					vecRetailerPartyAddressBObj.removeAllElements();
					

				}
				
				//Wholesale

				// Sort Vectors by LastModifiedDate

				sortPartyAddresses(vecHomePartyAddressBObj, null, control);

				sortPartyAddresses(vecOth1PartyAddressBObj, null, control);

				sortPartyAddresses(vecOth2PartyAddressBObj, null, control);

				sortPartyAddresses(vecOth3PartyAddressBObj, null, control);
				
				
					// If only one party has address
					if(wsAddressUsageTpSet.contains(ExternalRuleConstant.ADDRESS_USAGE_TYPE_HOME_ADDRESS)
							&& vecHomePartyAddressBObj.size() == 1) {
						
						XAddressGroupBObjExt tempAddressGroupBObj = null;
						//survive home address
						tempAddressGroupBObj = vecHomePartyAddressBObj.elementAt(0);					
						surviveAddress(partyAddressMap, tempAddressGroupBObj);
						
						if(vecOth1PartyAddressBObj.size() != 0 ){
							tempAddressGroupBObj = vecOth1PartyAddressBObj.elementAt(0);					
							surviveAddress(partyAddressMap, tempAddressGroupBObj);
						}
						if(vecOth2PartyAddressBObj.size() != 0 ){
							tempAddressGroupBObj = vecOth2PartyAddressBObj.elementAt(0);					
							surviveAddress(partyAddressMap, tempAddressGroupBObj);
						}
						if(vecOth3PartyAddressBObj.size() != 0 ){
							tempAddressGroupBObj = vecOth3PartyAddressBObj.elementAt(0);					
							surviveAddress(partyAddressMap, tempAddressGroupBObj);
						}
					}
				
				
					//If Any of the suspects has Other 3 Address, Keep the latest address in each Address Usage Type
				 	else if(wsAddressUsageTpSet.contains(ExternalRuleConstant.ADDRESS_USAGE_TYPE_OTHER_ADDRESS_3)){
					XAddressGroupBObjExt tempAddressGroupBObj = null;
					//Survive Latest Home Address
					if(vecHomePartyAddressBObj.size() != 0){
						tempAddressGroupBObj = vecHomePartyAddressBObj.elementAt(0);					
						surviveAddress(partyAddressMap, tempAddressGroupBObj);
					}
															
					//Survive Latest Other 1 Address
					if(vecOth1PartyAddressBObj.size() != 0){
						tempAddressGroupBObj = vecOth1PartyAddressBObj.elementAt(0);
						surviveAddress(partyAddressMap, tempAddressGroupBObj);
					}
					
					//Survive Latest Other 2 Address
					if(vecOth2PartyAddressBObj.size() != 0){
						tempAddressGroupBObj = vecOth2PartyAddressBObj.elementAt(0);
						surviveAddress(partyAddressMap, tempAddressGroupBObj);
					}
					
					//Survive Latest Other 3 Address
					if(vecOth3PartyAddressBObj.size() != 0){
						tempAddressGroupBObj = vecOth3PartyAddressBObj.elementAt(0);
						surviveAddress(partyAddressMap, tempAddressGroupBObj);
					}
					
				}
				
				
				
				//If Any of the suspects has Other 2 Address,Add latest Home address To Oth3
				//Survive latest for Oth 1 and second latest for Home
				
				else if(!wsAddressUsageTpSet.contains(ExternalRuleConstant.ADDRESS_USAGE_TYPE_OTHER_ADDRESS_3) &&
						wsAddressUsageTpSet.contains(ExternalRuleConstant.ADDRESS_USAGE_TYPE_OTHER_ADDRESS_2)){
					XAddressGroupBObjExt tempAddressGroupBObj = null;
					
					//Survive second latest Home address for Home
					if(vecHomePartyAddressBObj.size() > 1){
						tempAddressGroupBObj = vecHomePartyAddressBObj.elementAt(1);
						surviveAddress(partyAddressMap, tempAddressGroupBObj);
					}
				
					//Survive Latest Other 1 Address
					if(vecOth1PartyAddressBObj.size() != 0){
						tempAddressGroupBObj = vecOth1PartyAddressBObj.elementAt(0);
						surviveAddress(partyAddressMap, tempAddressGroupBObj);
					}
					
					//Survive Latest Other 2 Address
					if(vecOth2PartyAddressBObj.size() != 0){
						tempAddressGroupBObj = vecOth2PartyAddressBObj.elementAt(0);
						surviveAddress(partyAddressMap, tempAddressGroupBObj);
					}
					
					//Survive Latest Home Other 3 Address
					if(vecHomePartyAddressBObj.size() != 0){
						tempAddressGroupBObj = vecHomePartyAddressBObj.elementAt(0);
						tempAddressGroupBObj.setAddressUsageType(ExternalRuleConstant.ADDRESS_USAGE_TYPE_OTHER_ADDRESS_3);
						tempAddressGroupBObj.setAddressUsageValue(ExternalRuleConstant.ADDRESS_USAGE_VALUE_OTHER_ADDRESS_3);
						surviveAddress(partyAddressMap, tempAddressGroupBObj);	
					}
				}
				else  if(!wsAddressUsageTpSet.contains(ExternalRuleConstant.ADDRESS_USAGE_TYPE_OTHER_ADDRESS_3) &&
						!wsAddressUsageTpSet.contains(ExternalRuleConstant.ADDRESS_USAGE_TYPE_OTHER_ADDRESS_2) &&
						wsAddressUsageTpSet.contains(ExternalRuleConstant.ADDRESS_USAGE_TYPE_OTHER_ADDRESS_1)){
					XAddressGroupBObjExt oth1AddressGroupBObj = new XAddressGroupBObjExt();
					XAddressGroupBObjExt oth2AddressGroupBObj = new XAddressGroupBObjExt();
					XAddressGroupBObjExt oth3AddressGroupBObj = new XAddressGroupBObjExt();
					XAddressGroupBObjExt homeAddressGroupBObj = new XAddressGroupBObjExt();
					
					//Survive Latest Other 1 Address
					if(vecOth1PartyAddressBObj.size() != 0){
						oth1AddressGroupBObj = vecOth1PartyAddressBObj.elementAt(0);
						surviveAddress(partyAddressMap, oth1AddressGroupBObj);
					}
					
					
					//If count of home adress is only 2
					if(vecHomePartyAddressBObj.size() == 2){
						//Latest Home in Other 2
						oth2AddressGroupBObj = vecHomePartyAddressBObj.elementAt(0);
						oth2AddressGroupBObj.setAddressUsageType(ExternalRuleConstant.ADDRESS_USAGE_TYPE_OTHER_ADDRESS_2);
						oth2AddressGroupBObj.setAddressUsageValue(ExternalRuleConstant.ADDRESS_USAGE_VALUE_OTHER_ADDRESS_2);						
						surviveAddress(partyAddressMap,oth2AddressGroupBObj);
						
						//Second Latest in home
						homeAddressGroupBObj = vecHomePartyAddressBObj.elementAt(1);
						surviveAddress(partyAddressMap,homeAddressGroupBObj);
						
					}
					//If count of home address is more than 2
					else if(vecHomePartyAddressBObj.size() >2){
						//Latest Home in Other 3
						oth3AddressGroupBObj = vecHomePartyAddressBObj.elementAt(0);
						oth3AddressGroupBObj.setAddressUsageType(ExternalRuleConstant.ADDRESS_USAGE_TYPE_OTHER_ADDRESS_3);
						oth3AddressGroupBObj.setAddressUsageValue(ExternalRuleConstant.ADDRESS_USAGE_VALUE_OTHER_ADDRESS_3);
						surviveAddress(partyAddressMap,oth3AddressGroupBObj);
						
						//Second latest in Other 2
						oth2AddressGroupBObj = vecHomePartyAddressBObj.elementAt(1);
						oth2AddressGroupBObj.setAddressUsageType(ExternalRuleConstant.ADDRESS_USAGE_TYPE_OTHER_ADDRESS_2);
						oth2AddressGroupBObj.setAddressUsageValue(ExternalRuleConstant.ADDRESS_USAGE_VALUE_OTHER_ADDRESS_2);						
						surviveAddress(partyAddressMap,oth2AddressGroupBObj);
						
						//Third latest in Home
						homeAddressGroupBObj = vecHomePartyAddressBObj.elementAt(2);
						surviveAddress(partyAddressMap,homeAddressGroupBObj);						
					}				
					
				}else  if(!wsAddressUsageTpSet.contains(ExternalRuleConstant.ADDRESS_USAGE_TYPE_OTHER_ADDRESS_3) &&
						!wsAddressUsageTpSet.contains(ExternalRuleConstant.ADDRESS_USAGE_TYPE_OTHER_ADDRESS_2) &&
						!wsAddressUsageTpSet.contains(ExternalRuleConstant.ADDRESS_USAGE_TYPE_OTHER_ADDRESS_1) &&
						wsAddressUsageTpSet.contains(ExternalRuleConstant.ADDRESS_USAGE_TYPE_HOME_ADDRESS)){
					
					//If only home addresses are present
					
					XAddressGroupBObjExt oth1AddressGroupBObj = null;
					XAddressGroupBObjExt oth2AddressGroupBObj = null;
					XAddressGroupBObjExt oth3AddressGroupBObj = null;
					XAddressGroupBObjExt homeAddressGroupBObj = null;
					
					if(vecHomePartyAddressBObj.size() ==2){
						//If Home Address count is 2
						
						//Latest Home in Other 1
						oth2AddressGroupBObj = vecHomePartyAddressBObj.elementAt(0);
						oth2AddressGroupBObj.setAddressUsageType(ExternalRuleConstant.ADDRESS_USAGE_TYPE_OTHER_ADDRESS_1);
						oth2AddressGroupBObj.setAddressUsageValue(ExternalRuleConstant.ADDRESS_USAGE_VALUE_OTHER_ADDRESS_1);						
						surviveAddress(partyAddressMap,oth2AddressGroupBObj);
						
						//Second Latest in home
						homeAddressGroupBObj = vecHomePartyAddressBObj.elementAt(1);
						surviveAddress(partyAddressMap,homeAddressGroupBObj);
						
					}else if(vecHomePartyAddressBObj.size() ==3){						
						//If Home Address count is 3
						
						//Latest Home in Other 2
						oth2AddressGroupBObj = vecHomePartyAddressBObj.elementAt(0);
						oth2AddressGroupBObj.setAddressUsageType(ExternalRuleConstant.ADDRESS_USAGE_TYPE_OTHER_ADDRESS_2);
						oth2AddressGroupBObj.setAddressUsageValue(ExternalRuleConstant.ADDRESS_USAGE_VALUE_OTHER_ADDRESS_2);						
						surviveAddress(partyAddressMap,oth2AddressGroupBObj);
						
						//Second Latest in Other 1
						oth1AddressGroupBObj = vecHomePartyAddressBObj.elementAt(1);
						oth1AddressGroupBObj.setAddressUsageType(ExternalRuleConstant.ADDRESS_USAGE_TYPE_OTHER_ADDRESS_1);
						oth1AddressGroupBObj.setAddressUsageValue(ExternalRuleConstant.ADDRESS_USAGE_VALUE_OTHER_ADDRESS_1);						
						surviveAddress(partyAddressMap,oth1AddressGroupBObj);
						
						
						//Third Latest in Home
						homeAddressGroupBObj = vecHomePartyAddressBObj.elementAt(2);
						surviveAddress(partyAddressMap,homeAddressGroupBObj);
						
					
						
					}else if (vecHomePartyAddressBObj.size() > 3){
						//If Home Address count > 3
						
						//Latest Home in Other 3
						oth3AddressGroupBObj = vecHomePartyAddressBObj.elementAt(0);
						oth3AddressGroupBObj.setAddressUsageType(ExternalRuleConstant.ADDRESS_USAGE_TYPE_OTHER_ADDRESS_3);
						oth3AddressGroupBObj.setAddressUsageValue(ExternalRuleConstant.ADDRESS_USAGE_VALUE_OTHER_ADDRESS_3);						
						surviveAddress(partyAddressMap,oth3AddressGroupBObj);
						
						//Second Latest in Other 2
						oth2AddressGroupBObj = vecHomePartyAddressBObj.elementAt(1);
						oth2AddressGroupBObj.setAddressUsageType(ExternalRuleConstant.ADDRESS_USAGE_TYPE_OTHER_ADDRESS_2);
						oth2AddressGroupBObj.setAddressUsageValue(ExternalRuleConstant.ADDRESS_USAGE_VALUE_OTHER_ADDRESS_2);						
						surviveAddress(partyAddressMap,oth2AddressGroupBObj);
						
						//Third Latest in Other 1
						oth1AddressGroupBObj = vecHomePartyAddressBObj.elementAt(2);
						oth1AddressGroupBObj.setAddressUsageType(ExternalRuleConstant.ADDRESS_USAGE_TYPE_OTHER_ADDRESS_1);
						oth1AddressGroupBObj.setAddressUsageValue(ExternalRuleConstant.ADDRESS_USAGE_VALUE_OTHER_ADDRESS_1);						
						surviveAddress(partyAddressMap,oth1AddressGroupBObj);
						
						
						//Fourth Latest in Home
						homeAddressGroupBObj = vecHomePartyAddressBObj.elementAt(3);
						surviveAddress(partyAddressMap,homeAddressGroupBObj);
					}
				}
					
				// Change Retail Address Usage Type on the basis of Wholesale
				// Address Usage Type
				keySet = partyAddressMap.keySet();

				vecWSPartyAddressBObj.removeAllElements();
				vecRetailerPartyAddressBObj.removeAllElements();
				// Set<String> retailerIdSet = new HashSet<String>();

				for (String key : keySet) {
					if (!(key.endsWith(ExternalRuleConstant.CHARACTER_Y))) {

						vecWSPartyAddressBObj.add(partyAddressMap.get(key));

					} else {

						vecRetailerPartyAddressBObj.add(partyAddressMap
								.get(key));
					}
				}

				for (XAddressGroupBObjExt retailerPartyAddressBObj : vecRetailerPartyAddressBObj) {

					retailerPartyAddressBObj.setAddressUsageValue(ExternalRuleConstant.ADDRESS_USAGE_VALUE_P);

					retailerPartyAddressBObj.setAddressUsageType(ExternalRuleConstant.ADDRESS_USAGE_TYPE_P);

					for (XAddressGroupBObjExt wsPartyAddressBObj : vecWSPartyAddressBObj) {

						String rtmapKey = retailerPartyAddressBObj.getTCRMAddressBObj().getAddressLineOne() + 
								retailerPartyAddressBObj.getTCRMAddressBObj().getAddressLineTwo() +
								retailerPartyAddressBObj.getTCRMAddressBObj().getAddressLineThree()
								+ retailerPartyAddressBObj.getPartyId();

						String wsmapKey = wsPartyAddressBObj.getTCRMAddressBObj().getAddressLineOne() + 
								wsPartyAddressBObj.getTCRMAddressBObj().getAddressLineTwo() +
								wsPartyAddressBObj.getTCRMAddressBObj().getAddressLineThree() + 
								wsPartyAddressBObj.getPartyId() ;
						
						
						if (wsmapKey.equalsIgnoreCase(rtmapKey)) {

							// retailerIdSet.add(retailerPartyAddressBObj.getPartyId());

							String wsAddressUsageType = wsPartyAddressBObj
									.getAddressUsageType();

							String wsAddressUsageValue = wsPartyAddressBObj
									.getAddressUsageValue();

							if (retailerPartyAddressBObj != null) {

								retailerPartyAddressBObj.setAddressUsageValue(wsAddressUsageValue);

								retailerPartyAddressBObj.setAddressUsageType(wsAddressUsageType);

							}
							continue;

						}
					}

				}
				
				//FS 
				for(XAddressGroupBObjExt FSPartyAddressBObj : vecFSPartyAddressBObj){


					XAddressGroupBObjExt partyAddrBObj = FSPartyAddressBObj;

					String firstPartyAddrUsageType = partyAddrBObj.getAddressUsageType();

					String firstPartyAddrSourceIdTp = partyAddrBObj.getSourceIdentifierType();

					String firstFS = partyAddrBObj.getXAddressRetailerFlag();

					if (firstFS !=null && firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {

						mapKey =  firstPartyAddrUsageType + firstFS;

					} 

					if((firstFS != null  && !firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE) )){
					
					if (!partyAddressMap.containsKey(mapKey)) {

						partyAddressMap.put(mapKey, partyAddrBObj);

					} else {

						XAddressGroupBObjExt addrBObjInMap = partyAddressMap.get(mapKey);

						String secondPartyAddrUsageType = addrBObjInMap.getAddressUsageType();

						String secondPartyAddrSourceIdTp = addrBObjInMap.getSourceIdentifierType();

						String secondFS = addrBObjInMap.getXAddressRetailerFlag();

						if (firstPartyAddrUsageType.equalsIgnoreCase(secondPartyAddrUsageType)) {

							if (secondPartyAddrSourceIdTp.equalsIgnoreCase(firstPartyAddrSourceIdTp)) {

								// Same Source IdentTp

								Timestamp party1CreatedDt = DateFormatter.getTimestamp(partyAddrBObj.getXLastModifiedSystemDate());

								Timestamp party2CreatedDt = DateFormatter.getTimestamp(addrBObjInMap.getXLastModifiedSystemDate());

								if (party1CreatedDt.after(party2CreatedDt)) {

									if (firstFS !=null && firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {

										mapKey =  firstPartyAddrUsageType + firstFS;

									} 

									partyAddressMap.put(mapKey,partyAddrBObj);

								} else if (party1CreatedDt.before(party2CreatedDt)) {

									if (secondFS !=null && secondFS.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {

										mapKey =  secondPartyAddrUsageType + secondFS;

									} 
																	
									partyAddressMap.put(mapKey, addrBObjInMap);

								} else {
									
									if (firstFS !=null && firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {

										mapKey =  firstPartyAddrUsageType + firstFS;

									} 

									partyAddressMap.put(mapKey,partyAddrBObj);
								}
							} else {
								// Diff Source | Priority Source in Golden Record

								if (firstPartyAddrSourceIdTp.equalsIgnoreCase(ExternalRuleConstant.SOURCE_IDENTIFIER_TYPE_AUTOLINE)) {

									if (firstFS !=null && firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {

										mapKey =  firstPartyAddrUsageType + firstFS;

									} 

								
									partyAddressMap.put(mapKey,partyAddrBObj);

								} else if (secondPartyAddrSourceIdTp.equalsIgnoreCase(ExternalRuleConstant.SOURCE_IDENTIFIER_TYPE_AUTOLINE)) {
										
									 if (secondFS !=null && secondFS.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {

										mapKey =  secondPartyAddrUsageType +  secondFS;

									} 
										

									partyAddressMap.put(mapKey,addrBObjInMap);

									}
								}
							}
						}
					}
				}
				
				
			} else if (incomingPersonBObj.getXBatchInd().equalsIgnoreCase(ExternalRuleConstant.BATCH_IND_N) && 
					incomingPersonBObj.getSourceIdentifierType().equalsIgnoreCase(ExternalRuleConstant.SOURCE_IDENTIFIER_TYPE_AUTOLINE)
					&& incomingPersonBObj.getXMarketName().equalsIgnoreCase(ExternalRuleConstant.MARKET_NAME_MALAYSIA)) {
				
				// Delta  load for  Malaysia
				HashMap<String, Vector<XAddressGroupBObjExt>> retailerAddressMap = new HashMap<String, Vector<XAddressGroupBObjExt>>();

				String suspectAddrUsageAbsent = null;

				String mapKey = null;

				String goldenAddrUsage = null;

				Vector<XAddressGroupBObjExt> vecRetailerPartyAddressBObj = new Vector<XAddressGroupBObjExt>();
				
				Vector<XAddressGroupBObjExt> vecWSPartyAddressBObj = new Vector<XAddressGroupBObjExt>();
				
				Vector<XAddressGroupBObjExt> vecFinalWSPartyAddressBObj = new Vector<XAddressGroupBObjExt>();

				Vector<XAddressGroupBObjExt> vecIncomingPartyAddressBObj = new Vector<XAddressGroupBObjExt>();				

				Vector<XAddressGroupBObjExt> vecHomePartyAddressBObj = new Vector<XAddressGroupBObjExt>();

				Vector<XAddressGroupBObjExt> vecOth1PartyAddressBObj = new Vector<XAddressGroupBObjExt>();

				Vector<XAddressGroupBObjExt> vecOth2PartyAddressBObj = new Vector<XAddressGroupBObjExt>();

				Vector<XAddressGroupBObjExt> vecOth3PartyAddressBObj = new Vector<XAddressGroupBObjExt>();
				
				Vector<XAddressGroupBObjExt> vecFSPartyAddressBObj = new Vector<XAddressGroupBObjExt>();


				XAddressGroupBObjExt incomingHomeAddrBObj = new XAddressGroupBObjExt();

				XAddressGroupBObjExt incomingPAddrBObj = new XAddressGroupBObjExt();
				
				Set<String> wsAddressUsageTpSet = new HashSet<String>();
				

				// Get all Party Addresses of suspects
				for (int i = 0; i < vecAllParty.size(); i++) {

					XPersonBObjExt tempPersonBObj = (XPersonBObjExt) vecAllParty.get(i);

					Vector<XAddressGroupBObjExt> vecTempAddressBObj = tempPersonBObj.getItemsTCRMPartyAddressBObj();

					for (XAddressGroupBObjExt tempAddrBObj : vecTempAddressBObj) {

						if (tempAddrBObj.getAddressUsageType().equals(ExternalRuleConstant.ADDRESS_USAGE_TYPE_HOME_ADDRESS)
								&& tempAddrBObj.getXAddressRetailerFlag().equalsIgnoreCase(ExternalRuleConstant.ADDRESS_RETAILER_FLAG_N)) {
							
							vecFinalWSPartyAddressBObj.add(tempAddrBObj);
							wsAddressUsageTpSet.add(ExternalRuleConstant.ADDRESS_USAGE_TYPE_HOME_ADDRESS);
							
							vecHomePartyAddressBObj.add(tempAddrBObj);
							
							

						} else if (tempAddrBObj.getAddressUsageType().equals(ExternalRuleConstant.ADDRESS_USAGE_TYPE_OTHER_ADDRESS_1)
								&& tempAddrBObj.getXAddressRetailerFlag().equalsIgnoreCase(ExternalRuleConstant.ADDRESS_RETAILER_FLAG_N)) {
							
							vecFinalWSPartyAddressBObj.add(tempAddrBObj);
							wsAddressUsageTpSet.add(ExternalRuleConstant.ADDRESS_USAGE_TYPE_OTHER_ADDRESS_1);
							vecOth1PartyAddressBObj.add(tempAddrBObj);

						} else if (tempAddrBObj.getAddressUsageType().equals(ExternalRuleConstant.ADDRESS_USAGE_TYPE_OTHER_ADDRESS_2)
								&& tempAddrBObj.getXAddressRetailerFlag().equalsIgnoreCase(ExternalRuleConstant.ADDRESS_RETAILER_FLAG_N)) {
							
							vecFinalWSPartyAddressBObj.add(tempAddrBObj);
							wsAddressUsageTpSet.add(ExternalRuleConstant.ADDRESS_USAGE_TYPE_OTHER_ADDRESS_2);
							vecOth2PartyAddressBObj.add(tempAddrBObj);

						} else if (tempAddrBObj.getAddressUsageType().equals(ExternalRuleConstant.ADDRESS_USAGE_TYPE_OTHER_ADDRESS_3)
								&& tempAddrBObj.getXAddressRetailerFlag().equalsIgnoreCase(ExternalRuleConstant.ADDRESS_RETAILER_FLAG_N)) {
							
							vecFinalWSPartyAddressBObj.add(tempAddrBObj);
							wsAddressUsageTpSet.add(ExternalRuleConstant.ADDRESS_USAGE_TYPE_OTHER_ADDRESS_3);
							vecOth3PartyAddressBObj.add(tempAddrBObj);

						} else if (tempAddrBObj.getXAddressRetailerFlag().equalsIgnoreCase(ExternalRuleConstant.ADDRESS_RETAILER_FLAG_Y)) {

							retailerAddressMap.put(tempAddrBObj.getXRetailerId(), null);

							vecRetailerPartyAddressBObj.add(tempAddrBObj);

						}else if (tempAddrBObj.getXAddressRetailerFlag().equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {
							
							vecFSPartyAddressBObj.add(tempAddrBObj);
						
						}
					}
				}
				
				//Retailer Address Survivorship -Dealer wise 
				//survivedDealerRetailerAddress(dealerRetailerMap, vecAllParty, partyAddressMap, control);
				survivedDealerRetailerAddress(vecAllParty, partyAddressMap, control);
				
				//Wholesale

				// Sort Vectors by LastModifiedDate

				sortPartyAddresses(vecHomePartyAddressBObj, null, control);

				sortPartyAddresses(vecOth1PartyAddressBObj, null, control);

				sortPartyAddresses(vecOth2PartyAddressBObj, null, control);

				sortPartyAddresses(vecOth3PartyAddressBObj, null, control);
				
				
					// If only one party has address
					if(wsAddressUsageTpSet.contains(ExternalRuleConstant.ADDRESS_USAGE_TYPE_HOME_ADDRESS)
							&& vecHomePartyAddressBObj.size() == 1) {
						
						XAddressGroupBObjExt tempAddressGroupBObj = null;
						//survive home address
						if(vecHomePartyAddressBObj.size() != 0){
							tempAddressGroupBObj = vecHomePartyAddressBObj.elementAt(0);					
							surviveAddress(partyAddressMap, tempAddressGroupBObj);
						}					
						
						if(vecOth1PartyAddressBObj.size() != 0 ){
							tempAddressGroupBObj = vecOth1PartyAddressBObj.elementAt(0);					
							surviveAddress(partyAddressMap, tempAddressGroupBObj);
						}
						if(vecOth2PartyAddressBObj.size() != 0 ){
							tempAddressGroupBObj = vecOth2PartyAddressBObj.elementAt(0);					
							surviveAddress(partyAddressMap, tempAddressGroupBObj);
						}
						if(vecOth3PartyAddressBObj.size() != 0 ){
							tempAddressGroupBObj = vecOth3PartyAddressBObj.elementAt(0);					
							surviveAddress(partyAddressMap, tempAddressGroupBObj);
						}
					}
				
				
					//If Any of the suspects has Other 3 Address, Keep the latest address in each Address Usage Type
				 	else if(wsAddressUsageTpSet.contains(ExternalRuleConstant.ADDRESS_USAGE_TYPE_OTHER_ADDRESS_3)){
					XAddressGroupBObjExt tempAddressGroupBObj = null;
					//Survive Latest Home Address
					if(vecHomePartyAddressBObj.size() != 0){
						tempAddressGroupBObj = vecHomePartyAddressBObj.elementAt(0);					
						surviveAddress(partyAddressMap, tempAddressGroupBObj);
					}
										
					//Survive Latest Other 1 Address
					if(vecOth1PartyAddressBObj.size() != 0){
						tempAddressGroupBObj = vecOth1PartyAddressBObj.elementAt(0);
						surviveAddress(partyAddressMap, tempAddressGroupBObj);
					}
					
					//Survive Latest Other 2 Address
					if(vecOth2PartyAddressBObj.size() != 0){
						tempAddressGroupBObj = vecOth2PartyAddressBObj.elementAt(0);
						surviveAddress(partyAddressMap, tempAddressGroupBObj);
					}
					
					//Survive Latest Other 3 Address
					if(vecOth3PartyAddressBObj.size() != 0){
						tempAddressGroupBObj = vecOth3PartyAddressBObj.elementAt(0);
						surviveAddress(partyAddressMap, tempAddressGroupBObj);
					}
					
				}
				
				
				
				//If Any of the suspects has Other 2 Address,Add latest Home address To Oth3
				//Survive latest for Oth 1 and second latest for Home
				
				else if(!wsAddressUsageTpSet.contains(ExternalRuleConstant.ADDRESS_USAGE_TYPE_OTHER_ADDRESS_3) &&
						wsAddressUsageTpSet.contains(ExternalRuleConstant.ADDRESS_USAGE_TYPE_OTHER_ADDRESS_2)){
					XAddressGroupBObjExt tempAddressGroupBObj = null;
					
					//Survive second latest Home address for Home	
					if(vecHomePartyAddressBObj.size() > 1){
						tempAddressGroupBObj = vecHomePartyAddressBObj.elementAt(1);
						surviveAddress(partyAddressMap, tempAddressGroupBObj);
					}
					
					//Survive Latest Other 1 Address
					if(vecOth1PartyAddressBObj.size() > 1){
						tempAddressGroupBObj = vecOth1PartyAddressBObj.elementAt(0);
						surviveAddress(partyAddressMap, tempAddressGroupBObj);
					}
					
					//Survive Latest Other 2 Address
					if(vecOth2PartyAddressBObj.size() > 1){
						tempAddressGroupBObj = vecOth2PartyAddressBObj.elementAt(0);
						surviveAddress(partyAddressMap, tempAddressGroupBObj);
					}
					
					//Survive Latest Home Other 3 Address
					if(vecHomePartyAddressBObj.size() > 0){
						tempAddressGroupBObj = vecHomePartyAddressBObj.elementAt(0);
						tempAddressGroupBObj.setAddressUsageType(ExternalRuleConstant.ADDRESS_USAGE_TYPE_OTHER_ADDRESS_3);
						tempAddressGroupBObj.setAddressUsageValue(ExternalRuleConstant.ADDRESS_USAGE_VALUE_OTHER_ADDRESS_3);
						surviveAddress(partyAddressMap, tempAddressGroupBObj);					
					}
				}
				else  if(!wsAddressUsageTpSet.contains(ExternalRuleConstant.ADDRESS_USAGE_TYPE_OTHER_ADDRESS_3) &&
						!wsAddressUsageTpSet.contains(ExternalRuleConstant.ADDRESS_USAGE_TYPE_OTHER_ADDRESS_2) &&
						wsAddressUsageTpSet.contains(ExternalRuleConstant.ADDRESS_USAGE_TYPE_OTHER_ADDRESS_1)){
					XAddressGroupBObjExt oth1AddressGroupBObj = null;
					XAddressGroupBObjExt oth2AddressGroupBObj = null;
					XAddressGroupBObjExt oth3AddressGroupBObj = null;
					XAddressGroupBObjExt homeAddressGroupBObj = null;
					
					//Survive Latest Other 1 Address
					oth1AddressGroupBObj = vecOth1PartyAddressBObj.elementAt(0);
					surviveAddress(partyAddressMap, oth1AddressGroupBObj);
					
					//If count of home adress is only 2
					if(vecHomePartyAddressBObj.size() == 2){
						//Latest Home in Other 2
						oth2AddressGroupBObj = vecHomePartyAddressBObj.elementAt(0);
						oth2AddressGroupBObj.setAddressUsageType(ExternalRuleConstant.ADDRESS_USAGE_TYPE_OTHER_ADDRESS_2);
						oth2AddressGroupBObj.setAddressUsageValue(ExternalRuleConstant.ADDRESS_USAGE_VALUE_OTHER_ADDRESS_2);						
						surviveAddress(partyAddressMap,oth2AddressGroupBObj);
						
						//Second Latest in home
						homeAddressGroupBObj = vecHomePartyAddressBObj.elementAt(1);
						surviveAddress(partyAddressMap,homeAddressGroupBObj);
						
					}
					//If count of home adress is more than 2
					else if(vecHomePartyAddressBObj.size() >2){
						//Latest Home in Other 3
						oth3AddressGroupBObj = vecHomePartyAddressBObj.elementAt(0);
						oth3AddressGroupBObj.setAddressUsageType(ExternalRuleConstant.ADDRESS_USAGE_TYPE_OTHER_ADDRESS_2);
						oth3AddressGroupBObj.setAddressUsageValue(ExternalRuleConstant.ADDRESS_USAGE_VALUE_OTHER_ADDRESS_2);
						surviveAddress(partyAddressMap,oth3AddressGroupBObj);
						
						//Second latest in Other 2
						oth2AddressGroupBObj = vecHomePartyAddressBObj.elementAt(1);
						oth2AddressGroupBObj.setAddressUsageType(ExternalRuleConstant.ADDRESS_USAGE_TYPE_OTHER_ADDRESS_2);
						oth2AddressGroupBObj.setAddressUsageValue(ExternalRuleConstant.ADDRESS_USAGE_VALUE_OTHER_ADDRESS_2);						
						surviveAddress(partyAddressMap,oth2AddressGroupBObj);
						
						//Third latest in Home
						homeAddressGroupBObj = vecHomePartyAddressBObj.elementAt(2);
						surviveAddress(partyAddressMap,homeAddressGroupBObj);						
					}				
					
				}else  if(!wsAddressUsageTpSet.contains(ExternalRuleConstant.ADDRESS_USAGE_TYPE_OTHER_ADDRESS_3) &&
						!wsAddressUsageTpSet.contains(ExternalRuleConstant.ADDRESS_USAGE_TYPE_OTHER_ADDRESS_2) &&
						!wsAddressUsageTpSet.contains(ExternalRuleConstant.ADDRESS_USAGE_TYPE_OTHER_ADDRESS_1) &&
						wsAddressUsageTpSet.contains(ExternalRuleConstant.ADDRESS_USAGE_TYPE_HOME_ADDRESS)){
					
					//If only home addresses are present
					
					XAddressGroupBObjExt oth1AddressGroupBObj = null;
					XAddressGroupBObjExt oth2AddressGroupBObj = null;
					XAddressGroupBObjExt oth3AddressGroupBObj = null;
					XAddressGroupBObjExt homeAddressGroupBObj = null;
					
					if(vecHomePartyAddressBObj.size() ==2){
						//If Home Address count is 2
						
						//Latest Home in Other 1
						oth2AddressGroupBObj = vecHomePartyAddressBObj.elementAt(0);
						oth2AddressGroupBObj.setAddressUsageType(ExternalRuleConstant.ADDRESS_USAGE_TYPE_OTHER_ADDRESS_1);
						oth2AddressGroupBObj.setAddressUsageValue(ExternalRuleConstant.ADDRESS_USAGE_VALUE_OTHER_ADDRESS_1);						
						surviveAddress(partyAddressMap,oth2AddressGroupBObj);
						
						//Second Latest in home
						homeAddressGroupBObj = vecHomePartyAddressBObj.elementAt(1);
						surviveAddress(partyAddressMap,homeAddressGroupBObj);
						
					}else if(vecHomePartyAddressBObj.size() ==3){						
						//If Home Address count is 3
						
						//Latest Home in Other 2
						oth2AddressGroupBObj = vecHomePartyAddressBObj.elementAt(0);
						oth2AddressGroupBObj.setAddressUsageType(ExternalRuleConstant.ADDRESS_USAGE_TYPE_OTHER_ADDRESS_2);
						oth2AddressGroupBObj.setAddressUsageValue(ExternalRuleConstant.ADDRESS_USAGE_VALUE_OTHER_ADDRESS_2);						
						surviveAddress(partyAddressMap,oth2AddressGroupBObj);
						
						//Second Latest in Other 1
						oth1AddressGroupBObj = vecHomePartyAddressBObj.elementAt(1);
						oth1AddressGroupBObj.setAddressUsageType(ExternalRuleConstant.ADDRESS_USAGE_TYPE_OTHER_ADDRESS_1);
						oth1AddressGroupBObj.setAddressUsageValue(ExternalRuleConstant.ADDRESS_USAGE_VALUE_OTHER_ADDRESS_1);						
						surviveAddress(partyAddressMap,oth1AddressGroupBObj);
						
						
						//Third Latest in Home
						homeAddressGroupBObj = vecHomePartyAddressBObj.elementAt(2);
						surviveAddress(partyAddressMap,homeAddressGroupBObj);
						
					
						
					}else if (vecHomePartyAddressBObj.size() > 3){
						//If Home Address count > 3
						
						//Latest Home in Other 3
						oth3AddressGroupBObj = vecHomePartyAddressBObj.elementAt(0);
						oth3AddressGroupBObj.setAddressUsageType(ExternalRuleConstant.ADDRESS_USAGE_TYPE_OTHER_ADDRESS_3);
						oth3AddressGroupBObj.setAddressUsageValue(ExternalRuleConstant.ADDRESS_USAGE_VALUE_OTHER_ADDRESS_3);						
						surviveAddress(partyAddressMap,oth3AddressGroupBObj);
						
						//Second Latest in Other 2
						oth2AddressGroupBObj = vecHomePartyAddressBObj.elementAt(1);
						oth2AddressGroupBObj.setAddressUsageType(ExternalRuleConstant.ADDRESS_USAGE_TYPE_OTHER_ADDRESS_2);
						oth2AddressGroupBObj.setAddressUsageValue(ExternalRuleConstant.ADDRESS_USAGE_VALUE_OTHER_ADDRESS_2);						
						surviveAddress(partyAddressMap,oth2AddressGroupBObj);
						
						//Third Latest in Other 1
						oth1AddressGroupBObj = vecHomePartyAddressBObj.elementAt(2);
						oth1AddressGroupBObj.setAddressUsageType(ExternalRuleConstant.ADDRESS_USAGE_TYPE_OTHER_ADDRESS_1);
						oth1AddressGroupBObj.setAddressUsageValue(ExternalRuleConstant.ADDRESS_USAGE_VALUE_OTHER_ADDRESS_1);						
						surviveAddress(partyAddressMap,oth1AddressGroupBObj);
						
						
						//Fourth Latest in Home
						homeAddressGroupBObj = vecHomePartyAddressBObj.elementAt(3);
						surviveAddress(partyAddressMap,homeAddressGroupBObj);
					}
				}
					
				// Change Retail Address Usage Type on the basis of Wholesale
				// Address Usage Type
				Set<String> keySet = partyAddressMap.keySet();

				vecWSPartyAddressBObj.removeAllElements();
				vecRetailerPartyAddressBObj.removeAllElements();
				// Set<String> retailerIdSet = new HashSet<String>();

				for (String key : keySet) {
					if (!(key.endsWith(ExternalRuleConstant.CHARACTER_Y))) {

						vecWSPartyAddressBObj.add(partyAddressMap.get(key));

					} else {

						vecRetailerPartyAddressBObj.add(partyAddressMap.get(key));
					}
				}

				for (XAddressGroupBObjExt retailerPartyAddressBObj : vecRetailerPartyAddressBObj) {

					retailerPartyAddressBObj.setAddressUsageValue(ExternalRuleConstant.ADDRESS_USAGE_VALUE_P);

					retailerPartyAddressBObj.setAddressUsageType(ExternalRuleConstant.ADDRESS_USAGE_TYPE_P);

					for (XAddressGroupBObjExt wsPartyAddressBObj : vecWSPartyAddressBObj) {

						String rtmapKey = retailerPartyAddressBObj.getTCRMAddressBObj().getAddressLineOne() + 
								retailerPartyAddressBObj.getTCRMAddressBObj().getAddressLineTwo() +
								retailerPartyAddressBObj.getTCRMAddressBObj().getAddressLineThree()
								+ retailerPartyAddressBObj.getPartyId();

						String wsmapKey = wsPartyAddressBObj.getTCRMAddressBObj().getAddressLineOne() + 
								wsPartyAddressBObj.getTCRMAddressBObj().getAddressLineTwo() +
								wsPartyAddressBObj.getTCRMAddressBObj().getAddressLineThree() + 
								wsPartyAddressBObj.getPartyId() ;
						
						
						if (wsmapKey.equalsIgnoreCase(rtmapKey)) {

							// retailerIdSet.add(retailerPartyAddressBObj.getPartyId());

							String wsAddressUsageType = wsPartyAddressBObj.getAddressUsageType();

							String wsAddressUsageValue = wsPartyAddressBObj.getAddressUsageValue();

							if (retailerPartyAddressBObj != null) {

								retailerPartyAddressBObj.setAddressUsageValue(wsAddressUsageValue);

								retailerPartyAddressBObj.setAddressUsageType(wsAddressUsageType);

							}
							continue;

						}
					}

				}
				
				//FS 
				for(XAddressGroupBObjExt FSPartyAddressBObj : vecFSPartyAddressBObj){


					XAddressGroupBObjExt partyAddrBObj = FSPartyAddressBObj;

					String firstPartyAddrUsageType = partyAddrBObj.getAddressUsageType();

					String firstPartyAddrSourceIdTp = partyAddrBObj.getSourceIdentifierType();

					String firstFS = partyAddrBObj.getXAddressRetailerFlag();

					if (firstFS !=null && firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {

						mapKey =  firstPartyAddrUsageType + firstFS;

					} 

					if((firstFS != null  && !firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE) )){
					
					if (!partyAddressMap.containsKey(mapKey)) {

						partyAddressMap.put(mapKey, partyAddrBObj);

					} else {

						XAddressGroupBObjExt addrBObjInMap = partyAddressMap.get(mapKey);

						String secondPartyAddrUsageType = addrBObjInMap.getAddressUsageType();

						String secondPartyAddrSourceIdTp = addrBObjInMap.getSourceIdentifierType();

						String secondFS = addrBObjInMap.getXAddressRetailerFlag();

						if (firstPartyAddrUsageType.equalsIgnoreCase(secondPartyAddrUsageType)) {

							if (secondPartyAddrSourceIdTp.equalsIgnoreCase(firstPartyAddrSourceIdTp)) {

								// Same Source IdentTp

								Timestamp party1CreatedDt = DateFormatter.getTimestamp(partyAddrBObj.getXLastModifiedSystemDate());

								Timestamp party2CreatedDt = DateFormatter.getTimestamp(addrBObjInMap.getXLastModifiedSystemDate());

								if (party1CreatedDt.after(party2CreatedDt)) {

									if (firstFS !=null && firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {

										mapKey =  firstPartyAddrUsageType + firstFS;

									} 

									partyAddressMap.put(mapKey,partyAddrBObj);

								} else if (party1CreatedDt.before(party2CreatedDt)) {

									if (secondFS !=null && secondFS.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {

										mapKey =  secondPartyAddrUsageType + secondFS;

									} 
																	
									partyAddressMap.put(mapKey, addrBObjInMap);

								} else {
									
									if (firstFS !=null && firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {

										mapKey =  firstPartyAddrUsageType + firstFS;

									} 

									partyAddressMap.put(mapKey,partyAddrBObj);
								}
							} else {
								// Diff Source | Priority Source in Golden Record

								if (firstPartyAddrSourceIdTp.equalsIgnoreCase(ExternalRuleConstant.SOURCE_IDENTIFIER_TYPE_AUTOLINE)) {

									if (firstFS !=null && firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {

										mapKey =  firstPartyAddrUsageType + firstFS;

									} 

								
									partyAddressMap.put(mapKey,partyAddrBObj);

								} else if (secondPartyAddrSourceIdTp.equalsIgnoreCase(ExternalRuleConstant.SOURCE_IDENTIFIER_TYPE_AUTOLINE)) {
										
									 if (secondFS !=null && secondFS.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {

										mapKey =  secondPartyAddrUsageType +  secondFS;

									} 
										

									partyAddressMap.put(mapKey,addrBObjInMap);

									}
								}
							}
						}
					}
				}
				
				
			} else if ((incomingPersonBObj.getXBatchInd().equalsIgnoreCase(ExternalRuleConstant.BATCH_IND_N)
					&& incomingPersonBObj.getSourceIdentifierType().equalsIgnoreCase(ExternalRuleConstant.SOURCE_IDENTIFIER_TYPE_SFDC) 
					&& (incomingPersonBObj.getXMarketName().equalsIgnoreCase(ExternalRuleConstant.MARKET_NAME_MALAYSIA)))) {
				// Malaysia SFDC
				String mapKey = null;
				
				//survivedDealerRetailerAddress(dealerRetailerMap, vecAllParty, partyAddressMap, control);
				survivedDealerRetailerAddress(vecAllParty, partyAddressMap, control);
				
				// Check for priority SourceIdentTp as well
				for (int i = 0; i < vecAllParty.size(); i++) {

					XPersonBObjExt currPersonBObj = (XPersonBObjExt) vecAllParty.get(i);
					Vector<XAddressGroupBObjExt> vecTempPartyAddressBObj = currPersonBObj.getItemsTCRMPartyAddressBObj();

					String firstPartyAddrUsageType = null;

					String secondPartyAddrUsageType = null;

					String firstPartyAddrSourceIdTp = null;

					String secondPartyAddrSourceIdTp = null;

					String firstPartyAddrRetailerFlag = null;

					String secondPartyAddrRetailerFlag = null;

					String firstRetailer = null;

					String secondRetailer = null;

					String firstFS = null;

					String secondFS = null;

					for (int j = 0; j < vecTempPartyAddressBObj.size(); j++) {

						XAddressGroupBObjExt partyAddrBObj = (XAddressGroupBObjExt) vecTempPartyAddressBObj.get(j);

						firstPartyAddrUsageType = partyAddrBObj.getAddressUsageType();

						firstPartyAddrSourceIdTp = partyAddrBObj.getSourceIdentifierType();

						firstPartyAddrRetailerFlag = partyAddrBObj.getXAddressRetailerFlag();

						firstRetailer = partyAddrBObj.getXRetailerId();

						firstFS = partyAddrBObj.getXAddressRetailerFlag();

						if (firstPartyAddrRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_N)) {

							// Wholesale  Key = Retailer Flag + Address Usage Type
							mapKey = firstPartyAddrRetailerFlag + firstPartyAddrUsageType;

						}else if (firstFS !=null && firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {

							mapKey = firstPartyAddrRetailerFlag	+ firstPartyAddrUsageType + firstFS;

						} 
					//separate the retailer addresses from below logic	
					if((firstFS == null  || !firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE) ) && firstRetailer == null){
						
						if (!partyAddressMap.containsKey(mapKey)) {

							partyAddressMap.put(mapKey, partyAddrBObj);

						} else {

							XAddressGroupBObjExt addrBObjInMap = null;

							if (partyAddressMap.containsKey(mapKey)&& !firstPartyAddrRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_Y)) {

								// Key = Retailer Flag + Address Usage Type
								if (firstPartyAddrRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_N)) {

									// Wholesale  Key = Retailer Flag + Address Usage Type
									mapKey = firstPartyAddrRetailerFlag + firstPartyAddrUsageType;

								}else if (firstFS !=null && firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {

									mapKey = firstPartyAddrRetailerFlag	+ firstPartyAddrUsageType + firstFS;

								} 
							}

							addrBObjInMap = partyAddressMap.get(mapKey);

							secondPartyAddrUsageType = addrBObjInMap.getAddressUsageType();

							secondPartyAddrSourceIdTp = addrBObjInMap.getSourceIdentifierType();

							secondPartyAddrRetailerFlag = addrBObjInMap.getXAddressRetailerFlag();

							secondRetailer = addrBObjInMap.getXRetailerId();

							//secondDealer = dealerRetailerMap.get(secondRetailer);

							secondFS = addrBObjInMap.getXAddressRetailerFlag();

							//Wholesale address
							if (firstPartyAddrUsageType.equalsIgnoreCase(secondPartyAddrUsageType)
									&& firstPartyAddrRetailerFlag.equalsIgnoreCase(secondPartyAddrRetailerFlag)
									&& !firstPartyAddrRetailerFlag.equals(ExternalRuleConstant.CHARACTER_Y)) {

								if (secondPartyAddrSourceIdTp.equalsIgnoreCase(firstPartyAddrSourceIdTp)) {

									// Same Source IdentTp

									Timestamp party1CreatedDt = DateFormatter.getTimestamp(partyAddrBObj.getXLastModifiedSystemDate());

									Timestamp party2CreatedDt = DateFormatter.getTimestamp(addrBObjInMap.getXLastModifiedSystemDate());

									if (party1CreatedDt.after(party2CreatedDt)) {

										// Key = Retailer Flag + Address Usage Type
										if (firstPartyAddrRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_N)) {

											// Wholesale  Key = Retailer Flag + Address Usage Type
											mapKey = firstPartyAddrRetailerFlag + firstPartyAddrUsageType;

										}else if (firstFS !=null && firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {

											mapKey = firstPartyAddrRetailerFlag	+ firstPartyAddrUsageType + firstFS;

										} 

										partyAddressMap.put(mapKey,partyAddrBObj);

									} else if (party1CreatedDt.before(party2CreatedDt)) {

										// Key = Retailer Flag +Address Usage Type + Retailer ID
										if (secondPartyAddrRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_N)) {

											// Wholesale  Key = Retailer Flag + Address Usage Type
											mapKey = secondPartyAddrRetailerFlag + secondPartyAddrUsageType;

										}else if (secondFS !=null && secondFS.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {

											mapKey = secondPartyAddrRetailerFlag + secondPartyAddrUsageType + secondFS;

										} 
										

										
										partyAddressMap.put(mapKey, addrBObjInMap);

									} else {

										//  Key = Retailer Flag +Address Usage Type
										if (firstPartyAddrRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_N)) {

											// Wholesale  Key = Retailer Flag + Address Usage Type
											mapKey = firstPartyAddrRetailerFlag + firstPartyAddrUsageType;

										}else if (firstFS !=null && firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {

											mapKey = firstPartyAddrRetailerFlag	+ firstPartyAddrUsageType + firstFS;

										} 

										
										partyAddressMap.put(mapKey,partyAddrBObj);
									}
								} else {
									// Diff Source | Priority Source in Golden
									// Record

									if (firstPartyAddrSourceIdTp.equalsIgnoreCase(ExternalRuleConstant.SOURCE_IDENTIFIER_TYPE_AUTOLINE)) {

										// Key = Retailer Flag +  Address Usage Type
										if (firstPartyAddrRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_N)) {

											// Wholesale  Key = Retailer Flag + Address Usage Type
											mapKey = firstPartyAddrRetailerFlag + firstPartyAddrUsageType;

										}else if (firstFS !=null && firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {

											mapKey = firstPartyAddrRetailerFlag	+ firstPartyAddrUsageType + firstFS;

										} 

									
										partyAddressMap.put(mapKey,partyAddrBObj);

									} else if (secondPartyAddrSourceIdTp.equalsIgnoreCase(ExternalRuleConstant.SOURCE_IDENTIFIER_TYPE_AUTOLINE)) {
											
										if (secondPartyAddrRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_N)) {

											// Wholesale  Key = Retailer Flag + Address Usage Type
											mapKey = secondPartyAddrRetailerFlag	+ secondPartyAddrUsageType;
											
										}else if (secondFS !=null && secondFS.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {

											mapKey = secondPartyAddrRetailerFlag	+ secondPartyAddrUsageType +  secondFS;

										} 
											

										partyAddressMap.put(mapKey,addrBObjInMap);

									}

								}
							}

						}
						
					}
				}

			}
		}

			else if ((incomingPersonBObj.getXBatchInd().equalsIgnoreCase(ExternalRuleConstant.BATCH_IND_N)
					&& (incomingPersonBObj.getSourceIdentifierType().equalsIgnoreCase(ExternalRuleConstant.SOURCE_IDENTIFIER_TYPE_SFDC)
							|| incomingPersonBObj.getSourceIdentifierType().equalsIgnoreCase(ExternalRuleConstant.SOURCE_IDENTIFIER_TYPE_STOUCH)
							|| incomingPersonBObj.getSourceIdentifierType().equalsIgnoreCase(ExternalRuleConstant.SOURCE_IDENTIFIER_TYPE_TDS))
					&& (incomingPersonBObj.getXMarketName().equalsIgnoreCase(ExternalRuleConstant.MARKET_NAME_THAILAND)))
					|| (incomingPersonBObj.getXBatchInd().equalsIgnoreCase(ExternalRuleConstant.BATCH_IND_Y) 
							&& incomingPersonBObj.getXMarketName().equalsIgnoreCase(ExternalRuleConstant.MARKET_NAME_THAILAND) &&
							!incomingPersonBObj.getSourceIdentifierType().equalsIgnoreCase(ExternalRuleConstant.SOURCE_IDENTIFIER_TYPE_CMS))) {

				// Thailand Real time SFDC| STOUCH | TDS
				//THAILAND INITIAL LOAD 
				String mapKey = null;

				// Check for priority SourceIdentTp as well
				for (int i = 0; i < vecAllParty.size(); i++) {

					XPersonBObjExt currPersonBObj = (XPersonBObjExt) vecAllParty.get(i);
					Vector<XAddressGroupBObjExt> vecTempPartyAddressBObj = currPersonBObj.getItemsTCRMPartyAddressBObj();

					String firstPartyAddrUsageType = null;

					String secondPartyAddrUsageType = null;

					String firstPartyAddrSourceIdTp = null;

					String secondPartyAddrSourceIdTp = null;

					String firstPartyAddrRetailerFlag = null;

					String secondPartyAddrRetailerFlag = null;

					String firstRetailer = null;

					String secondRetailer = null;

					String firstFS = null;

					String secondFS = null;
					
					XAddressBObjExt xaddressBObjExtParty1 = new XAddressBObjExt();
					
					XAddressBObjExt xaddressBObjExtParty2 = new XAddressBObjExt();

					for (int j = 0; j < vecTempPartyAddressBObj.size(); j++) {

						XAddressGroupBObjExt partyAddrBObj = (XAddressGroupBObjExt) vecTempPartyAddressBObj.get(j);

						firstPartyAddrUsageType = partyAddrBObj.getAddressUsageType();

						firstPartyAddrSourceIdTp = partyAddrBObj.getSourceIdentifierType();

						firstPartyAddrRetailerFlag = partyAddrBObj.getXAddressRetailerFlag();

						firstRetailer = partyAddrBObj.getXRetailerId();

						firstFS = partyAddrBObj.getXAddressRetailerFlag();
						
						if(partyAddrBObj.getX_BPID()!=null){
							partyAddressMap.put(firstPartyAddrUsageType+partyAddrBObj.getX_BPID(), partyAddrBObj);
							continue;
						}
						
						
						 if (firstPartyAddrRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_Y)) {
							// Retailer
								
							mapKey = firstPartyAddrRetailerFlag + firstRetailer;
								
						}else if (!firstPartyAddrRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_Y)
									&& !firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE)) {

							// Wholesale
								
							mapKey = firstPartyAddrRetailerFlag + firstPartyAddrUsageType;
							
						} 
						// Added  :THA FS Delta Changes : 11/13/2020
						else if (partyAddrBObj.getXAddressRetailerFlag() != null
								&& partyAddrBObj.getXAddressRetailerFlag().equals(ExternalRuleConstant.FS_WHOLESALE)) {
			
							// Otherwise Key = Name Usage type
							mapKey = firstPartyAddrRetailerFlag+ExternalRuleConstant.FS_WHOLESALE;
			
						}
						
						xaddressBObjExtParty1=(XAddressBObjExt) partyAddrBObj.getTCRMAddressBObj();

						// Added  :THA FS Delta Changes : 11/13/2020
						if ((firstFS == null) || (firstFS != null && !firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE))
								|| firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE)) {
							

							if (!partyAddressMap.containsKey(mapKey)) {
								
								if (!xaddressBObjExtParty1.getAddressLineOne().equalsIgnoreCase(ExternalRuleConstant.VALUE_DELETED)) {
									partyAddressMap.put(mapKey, partyAddrBObj);
								}
							} else {

								XAddressGroupBObjExt addrBObjInMap = null;
								
								addrBObjInMap = partyAddressMap.get(mapKey);

								secondPartyAddrUsageType = addrBObjInMap.getAddressUsageType();

								secondPartyAddrSourceIdTp = addrBObjInMap.getSourceIdentifierType();

								secondPartyAddrRetailerFlag = addrBObjInMap.getXAddressRetailerFlag();

								secondRetailer = addrBObjInMap.getXRetailerId();

								secondFS = addrBObjInMap.getXAddressRetailerFlag();

								// Retail
								//Latest Retailer Address Survives within a Retailer Irrespective of Address Usage type

								if(firstPartyAddrRetailerFlag.equalsIgnoreCase(secondPartyAddrRetailerFlag)
										&& firstPartyAddrRetailerFlag.equals(ExternalRuleConstant.CHARACTER_Y)
										&& firstRetailer.equalsIgnoreCase(secondRetailer)){
									
									Timestamp party1CreatedDt = DateFormatter.getTimestamp(partyAddrBObj.getXLastModifiedSystemDate());

									Timestamp party2CreatedDt = DateFormatter.getTimestamp(addrBObjInMap.getXLastModifiedSystemDate());
									xaddressBObjExtParty1=(XAddressBObjExt) partyAddrBObj.getTCRMAddressBObj();
									xaddressBObjExtParty2=(XAddressBObjExt) addrBObjInMap.getTCRMAddressBObj();
									if(!xaddressBObjExtParty1.getAddressLineOne().equalsIgnoreCase(ExternalRuleConstant.VALUE_DELETED) &&
											!xaddressBObjExtParty2.getAddressLineOne().equalsIgnoreCase(ExternalRuleConstant.VALUE_DELETED) )
										{
										if (party1CreatedDt.after(party2CreatedDt)) {

											partyAddressMap.put(mapKey,partyAddrBObj);

										} else {

											partyAddressMap.put(mapKey,addrBObjInMap);
										}
									}else if(xaddressBObjExtParty1.getAddressLineOne().equalsIgnoreCase(ExternalRuleConstant.VALUE_DELETED) &&
											!xaddressBObjExtParty2.getAddressLineOne().equalsIgnoreCase(ExternalRuleConstant.VALUE_DELETED)){
										
										partyAddressMap.put(mapKey,addrBObjInMap);
									}else if(!xaddressBObjExtParty1.getAddressLineOne().equalsIgnoreCase(ExternalRuleConstant.VALUE_DELETED) &&
											xaddressBObjExtParty2.getAddressLineOne().equalsIgnoreCase(ExternalRuleConstant.VALUE_DELETED)){
										
										partyAddressMap.put(mapKey,partyAddrBObj);
									}if(xaddressBObjExtParty1.getAddressLineOne().equalsIgnoreCase(ExternalRuleConstant.VALUE_DELETED) &&
											xaddressBObjExtParty2.getAddressLineOne().equalsIgnoreCase(ExternalRuleConstant.VALUE_DELETED) ){
										//do nothing, no address will survive if both the address are DELETED.
									}
									
								}

								// Both Wholesale or FS
								else if (firstPartyAddrUsageType.equalsIgnoreCase(secondPartyAddrUsageType)
										&& firstPartyAddrRetailerFlag.equalsIgnoreCase(secondPartyAddrRetailerFlag)
										&& !firstPartyAddrRetailerFlag.equals(ExternalRuleConstant.CHARACTER_Y)) {

									if (secondPartyAddrSourceIdTp.equalsIgnoreCase(firstPartyAddrSourceIdTp)) {

										// Same Source

										Timestamp party1CreatedDt = DateFormatter.getTimestamp(partyAddrBObj.getXLastModifiedSystemDate());

										Timestamp party2CreatedDt = DateFormatter.getTimestamp(addrBObjInMap.getXLastModifiedSystemDate());
										
									
										
										xaddressBObjExtParty1=(XAddressBObjExt) partyAddrBObj.getTCRMAddressBObj();
										//System.err.println("xaddressBObjExtParty1.getAddressLineOne()--  "+xaddressBObjExtParty1.getAddressLineOne()+"---" +party1CreatedDt);
										
										
										
										xaddressBObjExtParty2=(XAddressBObjExt) addrBObjInMap.getTCRMAddressBObj();
										//System.err.println("xaddressBObjExtParty2.getAddressLineOne() --> "+xaddressBObjExtParty2.getAddressLineOne()+"---" +party2CreatedDt );
										
										if(!xaddressBObjExtParty1.getAddressLineOne().equalsIgnoreCase(ExternalRuleConstant.VALUE_DELETED) &&
												!xaddressBObjExtParty2.getAddressLineOne().equalsIgnoreCase(ExternalRuleConstant.VALUE_DELETED) )
										{
										if (party1CreatedDt.after(party2CreatedDt)) {

											// Key = Retailer Flag + Address Usage Type
											mapKey = firstPartyAddrRetailerFlag + firstPartyAddrUsageType;

											
											partyAddressMap.put(mapKey,partyAddrBObj);

										} else if (party1CreatedDt.before(party2CreatedDt)) {

											//  Key = Retailer Flag + Address Usage Type + Retailer ID
												mapKey = secondPartyAddrRetailerFlag + secondPartyAddrUsageType;


												partyAddressMap.put(mapKey, addrBObjInMap);

										} else {

												// Key = Retailer Flag + Address Usage Type
											mapKey = firstPartyAddrRetailerFlag + firstPartyAddrUsageType;


											partyAddressMap.put(mapKey, partyAddrBObj);
										}
									}else if(xaddressBObjExtParty1.getAddressLineOne().equalsIgnoreCase(ExternalRuleConstant.VALUE_DELETED) &&
												!xaddressBObjExtParty2.getAddressLineOne().equalsIgnoreCase(ExternalRuleConstant.VALUE_DELETED)){
										
										mapKey = secondPartyAddrRetailerFlag + secondPartyAddrUsageType;
										partyAddressMap.put(mapKey, addrBObjInMap);
									}
									else if(!xaddressBObjExtParty1.getAddressLineOne().equalsIgnoreCase(ExternalRuleConstant.VALUE_DELETED) &&
											xaddressBObjExtParty2.getAddressLineOne().equalsIgnoreCase(ExternalRuleConstant.VALUE_DELETED)){
										
										
										// Key = Retailer Flag + Address Usage Type
										mapKey = firstPartyAddrRetailerFlag + firstPartyAddrUsageType;
										partyAddressMap.put(mapKey,partyAddrBObj);
									}else if(xaddressBObjExtParty1.getAddressLineOne().equalsIgnoreCase(ExternalRuleConstant.VALUE_DELETED) &&
											xaddressBObjExtParty2.getAddressLineOne().equalsIgnoreCase(ExternalRuleConstant.VALUE_DELETED)){
										// do nothing, no address will survive if both are DELETED
									}
										} else {
											// Diff Source | Priority Source in Golden Record

											if (firstPartyAddrSourceIdTp.equalsIgnoreCase(ExternalRuleConstant.SOURCE_IDENTIFIER_TYPE_AUTOLINE)) {

												// Key = Retailer Flag + Address Usage Type
												mapKey = firstPartyAddrRetailerFlag + firstPartyAddrUsageType;


												partyAddressMap.put(mapKey, partyAddrBObj);

											} else if (secondPartyAddrSourceIdTp.equalsIgnoreCase(ExternalRuleConstant.SOURCE_IDENTIFIER_TYPE_AUTOLINE)) {

												//  Key = Retailer Flag + Address Usage Type + Retailer ID
													mapKey = secondPartyAddrRetailerFlag + secondPartyAddrUsageType;


												partyAddressMap.put(mapKey, addrBObjInMap);

											
										}
									}

								}
							}

						}
					}
				}
			} else if(incomingPersonBObj.getSourceIdentifierType().equalsIgnoreCase(ExternalRuleConstant.SOURCE_IDENTIFIER_TYPE_CMS)){

				// THA | MYS | FS
				String mapKey = null;

				// Check for priority SourceIdentTp as well
				for (int i = 0; i < vecAllParty.size(); i++) {

					XPersonBObjExt currPersonBObj = (XPersonBObjExt) vecAllParty.get(i);
					Vector<XAddressGroupBObjExt> vecTempPartyAddressBObj = currPersonBObj.getItemsTCRMPartyAddressBObj();

					String firstPartyAddrUsageType = null;

					String secondPartyAddrUsageType = null;

					String firstPartyAddrSourceIdTp = null;

					String secondPartyAddrSourceIdTp = null;

					String firstPartyAddrRetailerFlag = null;

					String secondPartyAddrRetailerFlag = null;

					String firstRetailer = null;

					String secondRetailer = null;

					String firstFS = null;


					for (int j = 0; j < vecTempPartyAddressBObj.size(); j++) {

						XAddressGroupBObjExt partyAddrBObj = (XAddressGroupBObjExt) vecTempPartyAddressBObj.get(j);

						firstPartyAddrUsageType = partyAddrBObj.getAddressUsageType();

						firstPartyAddrSourceIdTp = partyAddrBObj.getSourceIdentifierType();

						firstPartyAddrRetailerFlag = partyAddrBObj.getXAddressRetailerFlag();

						firstRetailer = partyAddrBObj.getXRetailerId();

						firstFS = partyAddrBObj.getXAddressRetailerFlag();
						
						//BPID survive
						if(partyAddrBObj.getX_BPID()!=null){
							partyAddressMap.put(firstPartyAddrUsageType+partyAddrBObj.getX_BPID(), partyAddrBObj);
							continue;
						}
						
						 if (firstPartyAddrRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_Y)) {
							// Retailer
								
							mapKey = firstPartyAddrRetailerFlag + firstRetailer;
								
						}else if (!firstPartyAddrRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_Y)
									&& !firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE)) {

							// Wholesale  Key = Retailer Flag + Address  Usage Type
								
							mapKey = firstPartyAddrRetailerFlag + firstPartyAddrUsageType;

							
						} 
						
						// Added  :THA FS Delta Changes : 11/13/2020
						else if (partyAddrBObj.getXAddressRetailerFlag() != null
								&& partyAddrBObj.getXAddressRetailerFlag().equals(ExternalRuleConstant.FS_WHOLESALE)) {
			
							// Otherwise Key = Name Usage type
							mapKey = firstPartyAddrRetailerFlag+ExternalRuleConstant.FS_WHOLESALE;
			
						}
						 
						// Added  :THA FS Delta Changes : 11/13/2020
						if ((firstFS == null) || (firstFS != null && !firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE))
									|| firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE)) {

							if (!partyAddressMap.containsKey(mapKey)) {

								partyAddressMap.put(mapKey, partyAddrBObj);

							} else {

								XAddressGroupBObjExt addrBObjInMap = null;
								
								addrBObjInMap = partyAddressMap.get(mapKey);

								secondPartyAddrUsageType = addrBObjInMap.getAddressUsageType();

								secondPartyAddrSourceIdTp = addrBObjInMap.getSourceIdentifierType();

								secondPartyAddrRetailerFlag = addrBObjInMap.getXAddressRetailerFlag();

								secondRetailer = addrBObjInMap.getXRetailerId();


								// Retail
								//Latest Retailer Address Survives within a Retailer Irrespective of Address Usage type

								if(firstPartyAddrRetailerFlag.equalsIgnoreCase(secondPartyAddrRetailerFlag)
										&& firstPartyAddrRetailerFlag.equals(ExternalRuleConstant.CHARACTER_Y)
										&& firstRetailer.equalsIgnoreCase(secondRetailer)){
									
									Timestamp party1CreatedDt = DateFormatter.getTimestamp(partyAddrBObj.getXLastModifiedSystemDate());

									Timestamp party2CreatedDt = DateFormatter.getTimestamp(addrBObjInMap.getXLastModifiedSystemDate());
									
									if(party1CreatedDt.after(party2CreatedDt)){
										
										partyAddressMap.put(mapKey,partyAddrBObj);
										
									}else{
										
										partyAddressMap.put(mapKey,addrBObjInMap);
										
									}
									
								}

								// Both Wholesale or FS
								else if (firstPartyAddrUsageType.equalsIgnoreCase(secondPartyAddrUsageType)
										&& firstPartyAddrRetailerFlag.equalsIgnoreCase(secondPartyAddrRetailerFlag)
										&& !firstPartyAddrRetailerFlag.equals(ExternalRuleConstant.CHARACTER_Y)) {

									if (secondPartyAddrSourceIdTp.equalsIgnoreCase(firstPartyAddrSourceIdTp)) {

										// Same Source

										Timestamp party1CreatedDt = DateFormatter.getTimestamp(partyAddrBObj.getXLastModifiedSystemDate());

										Timestamp party2CreatedDt = DateFormatter.getTimestamp(addrBObjInMap.getXLastModifiedSystemDate());

										if (party1CreatedDt.after(party2CreatedDt)) {

											// Key = Retailer Flag + Address Usage Type
											mapKey = firstPartyAddrRetailerFlag + firstPartyAddrUsageType;

											
											partyAddressMap.put(mapKey,partyAddrBObj);

										} else if (party1CreatedDt.before(party2CreatedDt)) {

											//  Key = Retailer Flag + Address Usage Type + Retailer ID
												mapKey = secondPartyAddrRetailerFlag + secondPartyAddrUsageType;


												partyAddressMap.put(mapKey, addrBObjInMap);

										} else {

												// Key = Retailer Flag + Address Usage Type
											mapKey = firstPartyAddrRetailerFlag + firstPartyAddrUsageType;


											partyAddressMap.put(mapKey, partyAddrBObj);
											}
										
										} else {
											// Diff Source | Priority Source in Golden Record

											if (firstPartyAddrSourceIdTp.equalsIgnoreCase(ExternalRuleConstant.SOURCE_IDENTIFIER_TYPE_AUTOLINE)) {

												// Key = Retailer Flag + Address Usage Type
												mapKey = firstPartyAddrRetailerFlag + firstPartyAddrUsageType;


												partyAddressMap.put(mapKey, partyAddrBObj);

											} else if (secondPartyAddrSourceIdTp.equalsIgnoreCase(ExternalRuleConstant.SOURCE_IDENTIFIER_TYPE_AUTOLINE)) {

												//  Key = Retailer Flag + Address Usage Type + Retailer ID
													mapKey = secondPartyAddrRetailerFlag + secondPartyAddrUsageType;


												partyAddressMap.put(mapKey, addrBObjInMap);

											
										}
									}

								}
							}

						}
						
					}
				}
			}
		}
		// Added  :THA FS Delta Changes : 11/13/2020
		//Find MPC WS record.
		boolean isMPCAvailable = false;
		for (Entry<String, XAddressGroupBObjExt> e : partyAddressMap.entrySet()) {
		    if (!e.getKey().contains(ExternalRuleConstant.FS_WHOLESALE) && !e.getKey().contains(ExternalRuleConstant.FS_VALUE)
		    		&& (e.getValue()).getX_BPID()==null) {
		    	isMPCAvailable = true;
		    	break;
		    }
		}
		//If MPC record is available then remove FSWS record.
		HashMap<String, XAddressGroupBObjExt> tempAddressMap = new HashMap<String, XAddressGroupBObjExt>();
		tempAddressMap.putAll(partyAddressMap);
		
		if(isMPCAvailable){
			for (Entry<String, XAddressGroupBObjExt> e : tempAddressMap.entrySet()) {
				if (e.getKey().contains(ExternalRuleConstant.FS_WHOLESALE)){
					partyAddressMap.remove(e.getKey());
				}
			
			}
		}
		return partyAddressMap;
	}
	
	private void surviveAddress(HashMap<String, XAddressGroupBObjExt> partyAddressMap,XAddressGroupBObjExt addressGroupBObj) {
		
		if(addressGroupBObj != null){
			String mapKey = addressGroupBObj.getXAddressRetailerFlag()
					+ addressGroupBObj.getAddressUsageType()
					+ addressGroupBObj.getTCRMAddressBObj().getAddressLineOne()
					+ addressGroupBObj.getTCRMAddressBObj().getAddressLineTwo()
					+ addressGroupBObj.getTCRMAddressBObj().getAddressLineThree()
					+ addressGroupBObj.getTCRMAddressBObj().getCity()
					+ addressGroupBObj.getTCRMAddressBObj().getZipPostalCode()
					+ addressGroupBObj.getTCRMAddressBObj().getResidenceNumber()
					+ addressGroupBObj.getTCRMAddressBObj().getCountryType() ;
					
			partyAddressMap.put(mapKey, addressGroupBObj);
		
		}
		
		
		
	}

	public HashMap<String, XAddressGroupBObjExt> survivedDealerRetailerAddress(Vector vecAllParty,HashMap<String, XAddressGroupBObjExt> partyAddressMap, DWLControl control) throws Exception{

		//HashMap<String, Vector<XAddressGroupBObjExt>> dealerAddressMap = new HashMap<String, Vector<XAddressGroupBObjExt>>();
			
		HashMap<String, Vector<XAddressGroupBObjExt>> retailerAddressMap = new HashMap<String, Vector<XAddressGroupBObjExt>>();

		XAddressGroupBObjExt latestAddressGrpBobj = null;
		
		for (int i = 0; i < vecAllParty.size(); i++) {
				
				TCRMPartyBObj party = (TCRMPartyBObj) vecAllParty.get(i);
				
				Vector<XAddressGroupBObjExt> vecTempPartyAddressBObj = new Vector<XAddressGroupBObjExt>();
	
				vecTempPartyAddressBObj = party.getItemsTCRMPartyAddressBObj();
				
				if(vecTempPartyAddressBObj.size() != 0){
					
					for(XAddressGroupBObjExt addressGroupBobj : vecTempPartyAddressBObj){
						
						if(addressGroupBobj.getXAddressRetailerFlag().equalsIgnoreCase(ExternalRuleConstant.ADDRESS_RETAILER_FLAG_Y)){
							
							String retailerId = addressGroupBobj.getXRetailerId();
							
							/*String dealerCode = null;
							
							dealerCode = dealerRetailerMap.get(retailerId);
							
							if(dealerCode!=null){
								
								if(dealerAddressMap.containsKey(dealerCode)){
									
									//If key is present in Map, get the vector and add this bobj in it
									Vector<XAddressGroupBObjExt> vecAddressBObjForKey = dealerAddressMap.get(dealerCode);
									
									vecAddressBObjForKey.add(addressGroupBobj);
									
															
								}else{
									
									//Add the Key Value Pair in Map
									Vector<XAddressGroupBObjExt> vecAddressBObjForKey = new Vector<XAddressGroupBObjExt>();
									
									vecAddressBObjForKey.add(addressGroupBobj);
									
									dealerAddressMap.put(dealerCode, vecAddressBObjForKey);								
									
								}
							}*/
							//----Added by Sameeha for Prod deployment-02Aug2018----//
							//Reverting Dealer Level(only retailer level magic number survives)
							//else{
								
								if(retailerAddressMap.containsKey(retailerId)){
									
									//If key is present in Map, get the vector and add this bobj in it
									Vector<XAddressGroupBObjExt> vecAddressBObjForKey = retailerAddressMap.get(retailerId);
									
									vecAddressBObjForKey.add(addressGroupBobj);
									
															
								}else{
									
									//Add the Key Value Pair in Map
									Vector<XAddressGroupBObjExt> vecAddressBObjForKey = new Vector<XAddressGroupBObjExt>();
									
									vecAddressBObjForKey.add(addressGroupBobj);
									
									retailerAddressMap.put(retailerId, vecAddressBObjForKey);									
									
								}
							
							//}
							//----Added by Sameeha for Prod deployment-02Aug2018----//
						
						}
						
					}
				
				}
				
			
			}
			
	/*		if(!dealerAddressMap.isEmpty()){
				for(Map.Entry<String, Vector<XAddressGroupBObjExt>> dealerAddres: dealerAddressMap.entrySet()){
						
						//Get dealercode 
						String dealerFromMap = dealerAddres.getKey();
						
						//Get all the addresses for this dealer
						Vector<XAddressGroupBObjExt> vecAddressrDealer = dealerAddres.getValue();
						
						//Sort all address by last modified system date
						Collections.sort(vecAddressrDealer, new Comparator<XAddressGroupBObjExt>() {
							public int compare(XAddressGroupBObjExt address1, XAddressGroupBObjExt address2) {
								if (address1.getXLastModifiedSystemDate() == null || address2.getXLastModifiedSystemDate() == null)
								return 0;
								return address1.getXLastModifiedSystemDate().compareTo(address2.getXLastModifiedSystemDate());
							}
						});
						Collections.reverse(vecAddressrDealer);//Descending sort for latest address
																	
						//Latest Address survives
						if(vecAddressrDealer.size() != 0)
							latestAddressGrpBobj = vecAddressrDealer.get(0);
						
						//Iterate vector of address to set values
						for(XAddressGroupBObjExt addressRetail: vecAddressrDealer){
							
							String mapKey = addressRetail.getXRetailerId() + addressRetail.getXAddressRetailerFlag() ;
						
							addressRetail.setControl(control);
	            			addressRetail.setTCRMAddressBObj(latestAddressGrpBobj.getTCRMAddressBObj());
	            			addressRetail.setAddressUsageType(latestAddressGrpBobj.getAddressUsageType());
	            			addressRetail.setAddressUsageValue(latestAddressGrpBobj.getAddressUsageValue());
	    									
							if(!partyAddressMap.containsKey(mapKey))
							
								partyAddressMap.put(mapKey, addressRetail);
							
							else{
								
								XAddressGroupBObjExt AddrInMap = partyAddressMap.get(mapKey);
								
								Timestamp party1CreatedDt = DateFormatter.getTimestamp(AddrInMap.getXLastModifiedSystemDate());
								
								Timestamp party2CreatedDt = DateFormatter.getTimestamp(addressRetail.getXLastModifiedSystemDate());
								
								if(party2CreatedDt.after(party1CreatedDt)){
									
									partyAddressMap.put(mapKey, addressRetail);
	
								}
									
								
							}
								
							
						}
						
					}
				}	*/						//----Added by Sameeha for Prod deployment-02Aug2018----//
			
				//else{
					//retailer level address
	
					for(Map.Entry<String, Vector<XAddressGroupBObjExt>> retailerAddres: retailerAddressMap.entrySet()){
							
							//Get retailerID 
							String retailerFromMap = retailerAddres.getKey();
							
							//Get all the addresses for this retailer
							Vector<XAddressGroupBObjExt> vecAddressrRetaier = retailerAddres.getValue();
							
							//Sort all address by last modified system date
							Collections.sort(vecAddressrRetaier, new Comparator<XAddressGroupBObjExt>() {
								public int compare(XAddressGroupBObjExt address1, XAddressGroupBObjExt address2) {
									if (address1.getXLastModifiedSystemDate() == null || address2.getXLastModifiedSystemDate() == null)
									return 0;
									return address1.getXLastModifiedSystemDate().compareTo(address2.getXLastModifiedSystemDate());
								}
							});
							Collections.reverse(vecAddressrRetaier);//Descending sort for latest address
																		
							//Latest Address survives
							if(vecAddressrRetaier.size() != 0){
								
								latestAddressGrpBobj = vecAddressrRetaier.get(0);
								
								String mapKey = null;
								
								mapKey = latestAddressGrpBobj.getXRetailerId() + latestAddressGrpBobj.getXAddressRetailerFlag();
								
								partyAddressMap.put(mapKey, latestAddressGrpBobj);
							
							}
							
						}
					
			//	}
											//----Added by Sameeha for Prod deployment-02Aug2018----//

		
			return partyAddressMap;
			
	}
	
	public static void setPartyAddressGroup(XAddressGroupBObjExt addressRetail,XAddressGroupBObjExt latestAddressGrpBobj, DWLControl control) throws BusinessProxyException {
		try{
			
			
			//AddressBObj
			XAddressBObjExt finalAddressBObjExt = (XAddressBObjExt) addressRetail.getTCRMAddressBObj();
			//addressRetail.setTCRMAddressBObj(null);
			finalAddressBObjExt.setControl(control);
			XAddressBObjExt reqAddressBObjExt = (XAddressBObjExt) latestAddressGrpBobj.getTCRMAddressBObj();
	
			//AddressLineOne
			if(reqAddressBObjExt.getAddressLineOne() != null)
				finalAddressBObjExt.setAddressLineOne(reqAddressBObjExt.getAddressLineOne());
			//AddressLineTwo
			if(reqAddressBObjExt.getAddressLineTwo() != null)
				finalAddressBObjExt.setAddressLineTwo(reqAddressBObjExt.getAddressLineTwo());
			//AddressLineThree
			if(reqAddressBObjExt.getAddressLineThree() != null)
				finalAddressBObjExt.setAddressLineThree(reqAddressBObjExt.getAddressLineThree());
			//City
			if(reqAddressBObjExt.getCity() != null)
				finalAddressBObjExt.setCity(reqAddressBObjExt.getCity());
			//ProvinceStateType / Residence
			if(reqAddressBObjExt.getResidenceNumber() != null)
				finalAddressBObjExt.setResidenceNumber(reqAddressBObjExt.getResidenceNumber());
			//ZipPostalCode
			if(reqAddressBObjExt.getZipPostalCode() != null)
				finalAddressBObjExt.setZipPostalCode(reqAddressBObjExt.getZipPostalCode());
			//CountryType
			if(reqAddressBObjExt.getCountryType() != null)
				finalAddressBObjExt.setCountryType(reqAddressBObjExt.getCountryType());
			
			//XAddressVerification Date
			if(reqAddressBObjExt.getXAddressVerificationDate() != null)
				finalAddressBObjExt.setXAddressVerificationDate(reqAddressBObjExt.getXAddressVerificationDate());
				//XDistrictType
			if(reqAddressBObjExt.getXDistrictType() != null)
				finalAddressBObjExt.setXDistrictType(reqAddressBObjExt.getXDistrictType());
				//XSubcity
			if(reqAddressBObjExt.getXSubcityType() != null)
				finalAddressBObjExt.setXSubcityType(reqAddressBObjExt.getXSubcityType());
			
			//StartDate
			if(latestAddressGrpBobj.getStartDate() != null){
				addressRetail.setStartDate(latestAddressGrpBobj.getStartDate());
			}
			//EndDate
			if(latestAddressGrpBobj.getEndDate() != null){
				addressRetail.setEndDate(latestAddressGrpBobj.getEndDate());
			}
			
			//Preferred Address Indicator 05-12-2017
			//finalAddressGroupBObjExt.setPreferredAddressIndicator("N");
			
			
			
			addressRetail.setTCRMAddressBObj(finalAddressBObjExt);
					
			}catch(Exception e){
				
				e.printStackTrace();
                //  logger.finest(e);
			/*DWLError error = errHandler
					.getErrorMessage(TCRMCoreComponentID.PARTY_ADDRESS_OBJECT,
							"UPDERR",TCRMCoreErrorReasonCode.UPDATE_PARTY_ADDRESS_FAILED,control, new String[0]);
			throw new BusinessProxyException(error.getErrorMessage());*/			
	}
	
}
	
	//public HashMap<String, XIdentifierBObjExt> sortedMagicNumber(HashMap<String, String> dealerRetailerMap,Vector vecAllParty,HashMap<String, XIdentifierBObjExt> partyIdenMap, DWLControl control) throws Exception{
	public HashMap<String, XIdentifierBObjExt> sortedMagicNumber(Vector vecAllParty,HashMap<String, XIdentifierBObjExt> partyIdenMap, DWLControl control) throws Exception{
			
			
			//HashMap<String, Vector<XIdentifierBObjExt>> dealerMagicMap = new HashMap<String, Vector<XIdentifierBObjExt>>();
			
			HashMap<String, Vector<XIdentifierBObjExt>> retailerMagicMap = new HashMap<String, Vector<XIdentifierBObjExt>>();
			
			String goldenMagicNumber = null;
			
			for (int i = 0; i < vecAllParty.size(); i++) {
					
					TCRMPartyBObj party = (TCRMPartyBObj) vecAllParty.get(i);
					
					Vector<XIdentifierBObjExt> vecTempPartyIdentificationBObj = new Vector<XIdentifierBObjExt>();
		
					vecTempPartyIdentificationBObj = party.getItemsTCRMPartyIdentificationBObj();
					
					if(vecTempPartyIdentificationBObj.size() != 0){
						
						for(XIdentifierBObjExt identificationBObj : vecTempPartyIdentificationBObj){
							
							if(identificationBObj.getIdentificationType().equals(ExternalRuleConstant.ID_TYPE_MAGIC)){
								
								String retailerId = identificationBObj.getXRetailerId();
								
								/*String dealerCode = null;
								dealerCode = dealerRetailerMap.get(retailerId);
								
								if(dealerCode!=null){
									if(dealerMagicMap.containsKey(dealerCode)){
										
										//If key is present in Map, get the vector and add this bobj in it
										Vector<XIdentifierBObjExt> vecIdentificationBObjForKey = dealerMagicMap.get(dealerCode);
										
										vecIdentificationBObjForKey.add(identificationBObj);
										
																
									}else{
										
										//Add the Key Value Pair in Map
										Vector<XIdentifierBObjExt> vecIdentificationBObjForKey = new Vector<XIdentifierBObjExt>();
										
										vecIdentificationBObjForKey.add(identificationBObj);
										
										dealerMagicMap.put(dealerCode, vecIdentificationBObjForKey);								
										
									}
								}*/
								//----Added by Sameeha for Prod deployment-02Aug2018----//
								//Reverting Dealer Level(only retailer level magic number survives)
								//else{
									
									if(retailerMagicMap.containsKey(retailerId)){
										
										//If key is present in Map, get the vector and add this bobj in it
										Vector<XIdentifierBObjExt> vecIdentificationBObjForKey = retailerMagicMap.get(retailerId);
										
										vecIdentificationBObjForKey.add(identificationBObj);
										
																
									}else{
										
										//Add the Key Value Pair in Map
										Vector<XIdentifierBObjExt> vecIdentificationBObjForKey = new Vector<XIdentifierBObjExt>();
										
										vecIdentificationBObjForKey.add(identificationBObj);
										
										retailerMagicMap.put(retailerId, vecIdentificationBObjForKey);								
										
									}
								
								//}
								//----Added by Sameeha for Prod deployment-02Aug2018----//
							
							}
							
						}
					
					}
					
				
				}
/*				if(!dealerMagicMap.isEmpty()){
					for(Map.Entry<String, Vector<XIdentifierBObjExt>> dealerMagic: dealerMagicMap.entrySet()){
						
						//Get dealercode 
						String dealerFromMap = dealerMagic.getKey();
						
						//Get all the magicnumber for this dealer
						Vector<XIdentifierBObjExt> vecMagicNumberForDealer = dealerMagic.getValue();
						
						//Sort all magic numbers by last modified system date
						Collections.sort(vecMagicNumberForDealer, new Comparator<XIdentifierBObjExt>() {
							public int compare(XIdentifierBObjExt magic1, XIdentifierBObjExt magic2) {
								if (magic1.getXLastModifiedSystemDate() == null || magic2.getXLastModifiedSystemDate() == null)
								return 0;
								return magic1.getXLastModifiedSystemDate().compareTo(magic2.getXLastModifiedSystemDate());
							}
						});			
						
						XIdentifierBObjExt oldestMagicNumberBObj = null;
												
						//Oldest Magic number survives
						if(vecMagicNumberForDealer.size() != 0)
							oldestMagicNumberBObj = vecMagicNumberForDealer.get(0);
						
						goldenMagicNumber = oldestMagicNumberBObj.getIdentificationNumber();
						
						for(XIdentifierBObjExt magicRetailer: vecMagicNumberForDealer){
							
							String mapKey = magicRetailer.getXRetailerId();
							
							magicRetailer.setControl(control);
							
							magicRetailer.setIdentificationNumber(goldenMagicNumber);
							if(!partyIdenMap.containsKey(mapKey))
							
								partyIdenMap.put(mapKey, magicRetailer);
							
							else{
								
								XIdentifierBObjExt IdenInMap = partyIdenMap.get(mapKey);
								
								Timestamp party1CreatedDt = DateFormatter.getTimestamp(IdenInMap.getXLastModifiedSystemDate());
								
								Timestamp party2CreatedDt = DateFormatter.getTimestamp(magicRetailer.getXLastModifiedSystemDate());
								
								if(party2CreatedDt.before(party1CreatedDt)){
									
									partyIdenMap.put(mapKey, magicRetailer);

								}
									
								
							}
								
							
						}
						
						
					}
				}	*/							
				//----Added by Sameeha for Prod deployment-02Aug2018----//

				//else{
					for(Map.Entry<String, Vector<XIdentifierBObjExt>> retailerMagic: retailerMagicMap.entrySet()){
						
						//Get retailerID 
						String retailerFromMap = retailerMagic.getKey();
						
						//Get all the magicnumber for this dealer
						Vector<XIdentifierBObjExt> vecMagicNumberForRetailer = retailerMagic.getValue();
						
						//Sort all magic numbers by last modified system date
						Collections.sort(vecMagicNumberForRetailer, new Comparator<XIdentifierBObjExt>() {
							public int compare(XIdentifierBObjExt magic1, XIdentifierBObjExt magic2) {
								if (magic1.getXLastModifiedSystemDate() == null || magic2.getXLastModifiedSystemDate() == null)
								return 0;
								return magic1.getXLastModifiedSystemDate().compareTo(magic2.getXLastModifiedSystemDate());
							}
						});			
						
						XIdentifierBObjExt oldestMagicNumberBObj = null;
												
						//Oldest Magic number survives
						if(vecMagicNumberForRetailer.size() != 0){
							
						oldestMagicNumberBObj = vecMagicNumberForRetailer.get(0);
									
						String mapKey = null;
						
						mapKey = oldestMagicNumberBObj.getXRetailerId();
						
						partyIdenMap.put(mapKey, oldestMagicNumberBObj);
						
					}
				}		
			//}	
				//----Added by Sameeha for Prod deployment-02Aug2018----//

			return partyIdenMap;
				
		}
	
	public HashMap<String, Vector<XIdentifierBObjExt>> getAllMagicNumbersForParties(HashMap<String, Vector<XIdentifierBObjExt>> contIdMagicMap,Vector vecAllParty, DWLControl control) throws Exception {
		
			
			//Get MAGIC numbers for each ContID
		for (int i = 0; i < vecAllParty.size(); i++) {
			
			TCRMPartyBObj party = (TCRMPartyBObj) vecAllParty.get(i);
			
			Vector<XIdentifierBObjExt> vecTempPartyIdentificationBObj = new Vector<XIdentifierBObjExt>();

			vecTempPartyIdentificationBObj = party.getItemsTCRMPartyIdentificationBObj();
			
			String contId = party.getPartyId();
			
				/*Vector<XIdentifierBObjExt> identificationBObjs = party.get
						
						partyComponent.getAllPartyIdentifications(contId, "ALL", control);*/
				
				if(vecTempPartyIdentificationBObj.size() != 0){
					
					for(XIdentifierBObjExt identificationBObj : vecTempPartyIdentificationBObj){
						
						if(identificationBObj.getIdentificationType().equals(ExternalRuleConstant.ID_TYPE_MAGIC)){
							
							if(contIdMagicMap.containsKey(contId)){
								
								//If key is present in Map, get the vector and add this bobj in it
								Vector<XIdentifierBObjExt> vecIdentificationBObjForKey = contIdMagicMap.get(contId);
								
								vecIdentificationBObjForKey.add(identificationBObj);
								
														
							}else{
								
								//Add the Key Value Pair in Map
								Vector<XIdentifierBObjExt> vecIdentificationBObjForKey = new Vector<XIdentifierBObjExt>();
								
								vecIdentificationBObjForKey.add(identificationBObj);
								
								contIdMagicMap.put(contId, vecIdentificationBObjForKey);								
								
							}
							
						}
						
					}
				
				}
				
				
			}
			
	
			return contIdMagicMap;
		}
	
	private HashMap<String, HashMap> survivedOrgDetails(Vector vecAllParty,
			DWLControl control) throws Exception {
		// TODO Auto-generated method stub

		HashMap<String, XOrgNameBObjExt> orgNameMap = new HashMap<String, XOrgNameBObjExt>();
		HashMap<String, XAddressGroupBObjExt> partyAddressMap = new HashMap<String, XAddressGroupBObjExt>();
		HashMap<String, XIdentifierBObjExt> partyIdentMap = new HashMap<String, XIdentifierBObjExt>();
		HashMap<String, XContactMethodGroupBObjExt> partyContMethMap = new HashMap<String, XContactMethodGroupBObjExt>();
		HashMap<String, TCRMAdminContEquivBObj> partyAdminConteqMap = new HashMap<String, TCRMAdminContEquivBObj>();

		HashMap<String, TCRMAdminContEquivBObj> partyAdminConteqMap1 = new HashMap<String, TCRMAdminContEquivBObj>();
		HashMap<String, String> dealerRetailerMap = new HashMap<String, String>();
		dealerRetailerMap = getAllRetailersByDealerForMagic(dealerRetailerMap);

		XOrgBObjExt orgBObjExtIncomingParty = (XOrgBObjExt) vecAllParty.get(0);
		String sourceIdentifierTypeIncomingParty = orgBObjExtIncomingParty
				.getSourceIdentifierType();
		//System.out.println(orgBObjExtIncomingParty.toXML());
		
		//start of change for DELETED check MYS
		//remove DELETED ph, email and address from original parties
		removeDeletedCommChannels(vecAllParty);
		//end of change for DELETED check MYS
		if (orgBObjExtIncomingParty != null
				&& orgBObjExtIncomingParty.getXBatchInd() != null
				&& orgBObjExtIncomingParty.getXMarketName() != null
				&& ((orgBObjExtIncomingParty.getXBatchInd().equalsIgnoreCase(ExternalRuleConstant.BATCH_IND_Y) 
						&& orgBObjExtIncomingParty.getXMarketName().equals(ExternalRuleConstant.MARKET_NAME_MALAYSIA)) 
						|| (orgBObjExtIncomingParty.getXBatchInd().equalsIgnoreCase(ExternalRuleConstant.BATCH_IND_N)
						&& orgBObjExtIncomingParty.getXMarketName().equals(ExternalRuleConstant.MARKET_NAME_MALAYSIA) 
						&& orgBObjExtIncomingParty.getSourceIdentifierType().equalsIgnoreCase(ExternalRuleConstant.SOURCE_IDENTIFIER_TYPE_AUTOLINE)))) {
			
			// FOr MALAYSIA INITIALIZATION
			survivalOfIndividualOrg(vecAllParty, control, orgNameMap,
					partyAddressMap, partyIdentMap, partyContMethMap,
					partyAdminConteqMap, partyAdminConteqMap1,
					dealerRetailerMap);

		} else if (orgBObjExtIncomingParty != null
				&& orgBObjExtIncomingParty.getXBatchInd() != null
				&& orgBObjExtIncomingParty.getXMarketName() != null
				&& ((orgBObjExtIncomingParty.getXMarketName().equals(ExternalRuleConstant.MARKET_NAME_THAILAND)) 
						|| (orgBObjExtIncomingParty.getXBatchInd().equalsIgnoreCase(ExternalRuleConstant.BATCH_IND_N) &&
								orgBObjExtIncomingParty.getSourceIdentifierType().equalsIgnoreCase(ExternalRuleConstant.SOURCE_IDENTIFIER_TYPE_SFDC)))) {

			survivalOfIndividualOrgWithPriority(vecAllParty, control,
					orgNameMap, partyAddressMap, partyIdentMap,
					partyContMethMap, partyAdminConteqMap, partyAdminConteqMap1,dealerRetailerMap);
		}

		HashMap<String, HashMap> orgMap = new HashMap<String, HashMap>();
		orgMap.put(ExternalRuleConstant.SURVIVED_MAP_NAME, orgNameMap);
		orgMap.put(ExternalRuleConstant.SURVIVED_MAP_ADDRESS, partyAddressMap);
		orgMap.put(ExternalRuleConstant.SURVIVED_MAP_IDENTIFIER, partyIdentMap);
		orgMap.put(ExternalRuleConstant.SURVIVED_MAP_CONTACTMETHOD,
				partyContMethMap);
		orgMap.put(ExternalRuleConstant.SURVIVED_MAP_CONTEQUIV,
				partyAdminConteqMap);

		return orgMap;
	}

	/**
	 * @param vecAllParty
	 * @param control
	 * @param orgNameMap
	 * @param partyAddressMap
	 * @param partyIdentMap
	 * @param partyContMethMap
	 * @param partyAdminConteqMap
	 * @param partyAdminConteqMap1
	 * @param priority
	 * @throws Exception
	 */
	private void survivalOfIndividualOrg(Vector vecAllParty,
			DWLControl control, HashMap<String, XOrgNameBObjExt> orgNameMap,
			HashMap<String, XAddressGroupBObjExt> partyAddressMap,
			HashMap<String, XIdentifierBObjExt> partyIdentMap,
			HashMap<String, XContactMethodGroupBObjExt> partyContMethMap,
			HashMap<String, TCRMAdminContEquivBObj> partyAdminConteqMap,
			HashMap<String, TCRMAdminContEquivBObj> partyAdminConteqMap1,
			HashMap<String, String> dealerRetailerMap) throws Exception {

		XOrgBObjExt orgBObjExtIncomingParty = (XOrgBObjExt) vecAllParty.get(0);
		String batchIndicator = orgBObjExtIncomingParty.getXBatchInd();

		if (batchIndicator.equals(ExternalRuleConstant.BATCH_IND_N)) {
			
			//survivedDealerRetailerAddress(dealerRetailerMap, vecAllParty, partyAddressMap, control);
			survivedDealerRetailerAddress(vecAllParty, partyAddressMap, control);
			
			String mapKey = null;
			
			for (int i = 0; i < vecAllParty.size(); i++) {
				TCRMPartyBObj party = (TCRMPartyBObj) vecAllParty.get(i);
				//FS changes//
				String firstFS = null;

				String secondFS = null;
				//FS CHanges//
				
			Vector<XOrgNameBObjExt> vecTempOrgNameBOBj = new Vector<XOrgNameBObjExt>();
			vecTempOrgNameBOBj = ((XOrgBObjExt) party).getItemsTCRMOrganizationNameBObj();

			String firstPartyNameUsageType = null;

			String secondPartyNameUsageType = null;

			String firstPartyNameUsageValue = null;

			String secondPartyNameUsageValue = null;

			// For Org Names
			for (int j = 0; j < vecTempOrgNameBOBj.size(); j++) {

				XOrgNameBObjExt orgnameBObj = (XOrgNameBObjExt) vecTempOrgNameBOBj.get(j);

				firstPartyNameUsageValue = orgnameBObj.getNameUsageValue();

				firstPartyNameUsageType = orgnameBObj.getNameUsageType();
				
				firstFS = orgnameBObj.getXOrgNameRetailerFlag();
				
				if (orgnameBObj.getXOrgNameRetailerFlag() != null
						&& orgnameBObj.getXOrgNameRetailerFlag().equals(ExternalRuleConstant.FS_VALUE)) {

					mapKey = firstPartyNameUsageType+ ExternalRuleConstant.FS_VALUE;

				} else if (orgnameBObj.getXOrgNameRetailerFlag() == null
						|| !orgnameBObj.getXOrgNameRetailerFlag().equals(ExternalRuleConstant.FS_WHOLESALE)) {

					// Otherwise Key = Name Usage type
					mapKey = firstPartyNameUsageType;

				}
				
			if ((firstFS == null) || (firstFS != null && !firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE))) {
				if (!orgNameMap.containsKey(firstPartyNameUsageType)) {
					
					orgNameMap.put(mapKey, orgnameBObj);
				} else {

					XOrgNameBObjExt nameBObjInMap = orgNameMap.get(firstPartyNameUsageType);

					secondPartyNameUsageValue = nameBObjInMap.getNameUsageValue();

					secondPartyNameUsageType = nameBObjInMap.getNameUsageType();
					
					secondFS = nameBObjInMap.getXOrgNameRetailerFlag();

					Timestamp person1CreatedDt = DateFormatter.getTimestamp(nameBObjInMap.getXLastModifiedSystemDate());

					Timestamp person2CreatedDt = DateFormatter.getTimestamp(orgnameBObj.getXLastModifiedSystemDate());

					if (person1CreatedDt.after(person2CreatedDt)) {
						// -- Start FS Changes
						
						if (secondFS != null) {
							// If FS, Key = Name usage type + FS
							mapKey = secondPartyNameUsageType + secondFS;

						} else {
							// Otherwise Key = Name Usage type
							mapKey = secondPartyNameUsageType;

						}

						orgNameMap.put(mapKey, nameBObjInMap);
						}

					else {
						// -- Start FS Changes
						
						if (firstFS != null && firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {
							// If FS, Key = Name usage type + FS
							mapKey = firstPartyNameUsageType + firstFS;

						} else {
							// Otherwise Key = Name Usage type
							mapKey = firstPartyNameUsageType;

						}

						// -- End FS Changes
						// Loveleen-----------//

						orgNameMap.put(mapKey, orgnameBObj);
						
					}

				}
			}
		}
			// For Party Address

			Vector<XAddressGroupBObjExt> vecTempPartyAddressBObj = new Vector<XAddressGroupBObjExt>();
			Vector<XAddressGroupBObjExt> vecRetailPartyAddressBObj = new Vector<XAddressGroupBObjExt>();

			vecTempPartyAddressBObj = party.getItemsTCRMPartyAddressBObj();

			String firstPartyValidityType = null;

			String secondPartyValidityType = null;

			String firstPartyAddrUsageType = null;

			String secondPartyAddrUsageType = null;

			String firstPartyAddrUsageValue = null;

			String secondPartyAddrUsageValue = null;
			boolean isCSet = false;

			boolean isBusinessSet = false;

			XOrgBObjExt orgBObjExt = (XOrgBObjExt) party;

				String sourceIdentifierType = orgBObjExt
						.getSourceIdentifierType();
				addressSurvivourshipLogicImplementation(control,
						partyAddressMap, vecTempPartyAddressBObj,
						vecRetailPartyAddressBObj, isCSet, isBusinessSet,
						orgBObjExt.getXBatchInd(), dealerRetailerMap);

			/*
			 * if(orgBObjExt!=null && orgBObjExt.getXBatchInd()!=null &&
			 * orgBObjExt
			 * .getXMarketName().equalsIgnoreCase(ExternalRuleConstant.
			 * MARKET_NAME_MALAYSIA) &&
			 * orgBObjExt.getXBatchInd().equalsIgnoreCase
			 * (ExternalRuleConstant.BATCH_IND_Y)){ //FOr MALAYSIA
			 * INITIALIZATION addressSurvivourshipLogicImplementation(control,
			 * partyAddressMap, vecTempPartyAddressBObj,
			 * vecRetailPartyAddressBObj, isCSet,
			 * isBusinessSet,orgBObjExt.getXBatchInd());
			 * 
			 * }else if(orgBObjExt!=null && orgBObjExt.getXBatchInd()!=null &&
			 * orgBObjExt
			 * .getXBatchInd().equalsIgnoreCase(ExternalRuleConstant.BATCH_IND_N
			 * ) && sourceIdentifierType!=null &&
			 * sourceIdentifierType.equalsIgnoreCase
			 * (ExternalRuleConstant.SOURCE_IDENTIFIER_TYPE_AUTOLINE)){
			 * addressSurvivourshipLogicImplementation(control, partyAddressMap,
			 * vecTempPartyAddressBObj, vecRetailPartyAddressBObj, isCSet,
			 * isBusinessSet,orgBObjExt.getXBatchInd()); }else
			 * if(sourceIdentifierType
			 * .equalsIgnoreCase(ExternalRuleConstant.SOURCE_IDENTIFIER_TYPE_SFDC
			 * )){ addressSurvivourshipLogicImplementationRealtime(control,
			 * partyAddressMap, vecTempPartyAddressBObj,
			 * vecRetailPartyAddressBObj, isCSet, isBusinessSet,orgBObjExt); }
			 */

			// For Party Identification

			Vector<XIdentifierBObjExt> vecTempPartyIdentificationBObj = new Vector<XIdentifierBObjExt>();

			vecTempPartyIdentificationBObj = party.getItemsTCRMPartyIdentificationBObj();

			String firstPartyIdentificationType = null;

			String secondPartyIdentificationType = null;

			String firstPartyIdentificationValue = null;

			String secondPartyIdentificationValue = null;

			String firstRetailerId = null;

			String secondRetailerId = null;
			
			// -- Start FS Changes Loveleen-----------//

			firstFS = null;

			secondFS = null;
			
			//String mapKey = null;

			XIdentifierBObjExt xIdenBObj = null;

			for (int j = 0; j < vecTempPartyIdentificationBObj.size(); j++) {

				XIdentifierBObjExt partyIdenBObj = (XIdentifierBObjExt) vecTempPartyIdentificationBObj.get(j);

				firstPartyIdentificationValue = partyIdenBObj.getIdentificationValue();

				firstPartyIdentificationType = partyIdenBObj.getIdentificationType();

				firstRetailerId = partyIdenBObj.getXRetailerId();
				//Fs change//
				
				firstFS = partyIdenBObj.getXIdentifierRetailerFlag();
				
				if (!firstPartyIdentificationType.equalsIgnoreCase(ExternalRuleConstant.ID_TYPE_MAGIC)) {
					//  FS Changes 
					// If FS, Key = Identification type + FS

					if (firstFS != null && firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {

						mapKey = firstPartyIdentificationType + firstFS;
					} else {

						// Otherwise, Key = Identification type
						mapKey = firstPartyIdentificationType;
					}
				}
				
				if(((firstFS == null)  || (firstFS != null && !firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE)&& !firstFS.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_Y))) ){
					
					if (!partyIdentMap.containsKey(mapKey)) {
	
						partyIdentMap.put(mapKey, partyIdenBObj);
	
					} else {
	
						XIdentifierBObjExt idenBObjInMap = partyIdentMap.get(mapKey);
	
						secondPartyIdentificationValue = idenBObjInMap.getIdentificationValue();
	
						secondPartyIdentificationType = idenBObjInMap.getIdentificationType();
	
						secondRetailerId = idenBObjInMap.getXRetailerId();
						//FS change
						secondFS = idenBObjInMap.getXIdentifierRetailerFlag();
						
						Timestamp party1CreatedDt = DateFormatter.getTimestamp(idenBObjInMap.getXLastModifiedSystemDate());
						
						Timestamp party2CreatedDt = DateFormatter.getTimestamp(partyIdenBObj.getXLastModifiedSystemDate());
						
						if (firstPartyIdentificationType.equalsIgnoreCase(secondPartyIdentificationType)) {
	
							if (firstPartyIdentificationType.equals(ExternalRuleConstant.ID_TYPE_UCID)) {
								// UCID
								
								// Oldest record survives
								if (xIdenBObj == null) {
									if (party1CreatedDt.before(party2CreatedDt)) {
	
										mapKey = secondPartyIdentificationType;
	
										partyIdentMap.put(mapKey, idenBObjInMap);
	
										xIdenBObj = idenBObjInMap;
									}
	
									else {
										mapKey = firstPartyIdentificationType;
	
										partyIdentMap.put(mapKey, partyIdenBObj);
	
										xIdenBObj = partyIdenBObj;
									}
								} else {
	
									String newCont = xIdenBObj.getPartyId();
	
									if (newCont.equalsIgnoreCase(partyIdenBObj.getPartyId())) {
	
										// both belongs to same party
										mapKey = firstPartyIdentificationType;
	
										partyIdentMap.put(mapKey, partyIdenBObj);
									}
								}
							} else if(firstPartyIdentificationType.equals(ExternalRuleConstant.ID_TYPE_BPID)
									&& firstFS != null && firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)
									&& secondFS != null && secondFS.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)){
								// BPID
								// Oldest BPID survives
								if (party1CreatedDt.before(party2CreatedDt)) {

									mapKey = secondPartyIdentificationType + secondFS;

									partyIdentMap.put(mapKey, idenBObjInMap);

									// xIdenBObj = idenBObjInMap;
								} else {

									mapKey = firstPartyIdentificationType + firstFS;

									partyIdentMap.put(mapKey, partyIdenBObj);
									// xIdenBObj = partyIdenBObj;
								}
							}
													
							else {
								// All Id types except UCID and MAGIC
								//Timestamp party1CreatedDt = DateFormatter.getTimestamp(idenBObjInMap.getXLastModifiedSystemDate());
								//Timestamp party2CreatedDt = DateFormatter.getTimestamp(partyIdenBObj.getXLastModifiedSystemDate());
								if (party1CreatedDt.after(party2CreatedDt)) {
									// If FS, Key =
									// Identification type + FS
									if (secondFS != null && secondFS.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {

										mapKey = secondPartyIdentificationType + secondFS;
									} else {
										// Otherwise, Key = Identification type

										mapKey = secondPartyIdentificationType;
									}
									
									partyIdentMap.put(mapKey,idenBObjInMap);
								}
								else {

									// If FS, Key = Identification type + FS
									if (firstFS != null && firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {

										mapKey = firstPartyIdentificationType + firstFS;
									} else {
										// Otherwise, Key =  Identification type

										mapKey = firstPartyIdentificationType;
									}
									
									partyIdentMap.put(mapKey,partyIdenBObj);
								}
	
							}
						}
	
					}
				}

		}

			// For Party Contact Method

			Vector<XContactMethodGroupBObjExt> vecTempPartyContactMethodBObj = new Vector<XContactMethodGroupBObjExt>();

			vecTempPartyContactMethodBObj = party
					.getItemsTCRMPartyContactMethodBObj();

			String firstPartyValidityContType = null;

			String secondPartyValidityContType = null;

			String firstPartyContMethodUsageType = null;

			String secondPartyContMethodUsageType = null;

			String firstPartyContMethodUsageValue = null;

			String secondPartyContMethodUsageValue = null;

			String firstPrefInd = null;

			String secondPrefInd = null;
			//FS Change
			
			firstFS = null;

			secondFS = null;

			for (int j = 0; j < vecTempPartyContactMethodBObj.size(); j++) {

				XContactMethodGroupBObjExt partyContMethBObj = (XContactMethodGroupBObjExt) vecTempPartyContactMethodBObj.get(j);

				firstPartyContMethodUsageValue = partyContMethBObj.getContactMethodUsageValue();

				firstPartyContMethodUsageType = partyContMethBObj.getContactMethodUsageType();

				firstPrefInd = partyContMethBObj.getPreferredContactMethodIndicator();
				
				//FS change
				firstFS = partyContMethBObj.getXContactRetailerFlag();
				// If FS, Key = Contact Method Usage Type + FS
				if (firstFS != null && firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {

					mapKey = firstPartyContMethodUsageType + firstFS;
				}
				// Otherwise, Key = Contact Method Usage Type
				else {

					mapKey = firstPartyContMethodUsageType;
				}
			
			if (firstFS == null || !firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE)) {
				if (!partyContMethMap.containsKey(firstPartyContMethodUsageType)) { 
					
					partyContMethMap.put(mapKey,partyContMethBObj);
				} else {

					XContactMethodGroupBObjExt contMethodBObjInMap = partyContMethMap.get(firstPartyContMethodUsageType);

					secondPartyContMethodUsageValue = contMethodBObjInMap.getContactMethodUsageValue();

					secondPartyContMethodUsageType = contMethodBObjInMap.getContactMethodUsageType();

					secondPrefInd = contMethodBObjInMap.getPreferredContactMethodIndicator();

					if (firstPartyContMethodUsageType.equalsIgnoreCase(secondPartyContMethodUsageType)) {

						Timestamp party1CreatedDt = DateFormatter.getTimestamp(contMethodBObjInMap.getXLastModifiedSystemDate());

						Timestamp party2CreatedDt = DateFormatter.getTimestamp(partyContMethBObj.getXLastModifiedSystemDate());

						if (firstPrefInd != null && firstPrefInd.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_Y)
								&& (secondPrefInd == null || !(secondPrefInd.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_Y)))) {

							partyContMethMap.put(firstPartyContMethodUsageType,partyContMethBObj);

						} else if (secondPrefInd != null
								&& secondPrefInd.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_Y)
								&& (firstPrefInd == null || !(firstPrefInd.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_Y)))) {

							partyContMethMap.put(secondPartyContMethodUsageType,contMethodBObjInMap);

						} else {if (party1CreatedDt.after(party2CreatedDt)) {

							// If FS, Key = Contact Method Usage Type + FS
							if (secondFS != null && secondFS.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {

								mapKey = secondPartyContMethodUsageType + secondFS;
							}
							// Otherwise, Key = Contact Method Usage  Type
							else {

								mapKey = secondPartyContMethodUsageType;
							}

							partyContMethMap.put(mapKey,contMethodBObjInMap);
						}

						else if (party1CreatedDt.before(party2CreatedDt)) {

							// If FS, Key = Contact Method Usage Type + FS
							if (firstFS != null && firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {

								mapKey = firstPartyContMethodUsageType + firstFS;
							}
							// Otherwise, Key = Contact Method Usage  Type
							else {

								mapKey = firstPartyContMethodUsageType;
							}

							partyContMethMap.put(mapKey, partyContMethBObj);

						} else if (party1CreatedDt.equals(party2CreatedDt)) {

							// If FS, Key = Contact Method Usage  Type + FS
							if (firstFS != null && firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {

								mapKey = firstPartyContMethodUsageType + firstFS;
							}
							// Otherwise, Key = Contact Method Usage Type
							else {

								mapKey = firstPartyContMethodUsageType;
							}

							partyContMethMap.put(mapKey,partyContMethBObj);

							}
						}

					}

				}
			}
		}

			// For Party Admin Contequiv

			Vector<XContEquivBObjExt> vecTempAdminContequivBObj = null;

			vecTempAdminContequivBObj = party.getItemsTCRMAdminContEquivBObj();

			String firstPartyAdminSysType = null;

			String secondPartyAdminSysType = null;

			String firstPartyAdminSysValue = null;

			String secondPartyAdminSysValue = null;

			XContEquivBObjExt newadminContEquivBObj = null;

			firstRetailerId = null;

			secondRetailerId = null;
			
			firstFS = null;
			
			secondFS = null;

			for (int j = 0; j < vecTempAdminContequivBObj.size(); j++) {

				XContEquivBObjExt partyAdminContequivBObj = (XContEquivBObjExt) vecTempAdminContequivBObj.get(j);

				firstPartyAdminSysValue = partyAdminContequivBObj.getAdminSystemValue();

				firstPartyAdminSysType = partyAdminContequivBObj.getAdminSystemType();

				String firstRetailerFlag = partyAdminContequivBObj.getXSourceRetailerFlag();
				
				firstFS = partyAdminContequivBObj.getXSourceRetailerFlag();

				if(firstRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_N)){
					
					// MapKey = Retailer Flag + Admin System System type 
					mapKey = firstRetailerFlag + firstPartyAdminSysType ;
											
				}else if(firstFS!= null && firstFS.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_Y)){
					//Retailer
					// MapKey = Retailer Flag + Admin System System type
					mapKey = firstRetailerFlag + firstPartyAdminSysType + firstRetailerId;
																		
				}else if(firstFS!= null && firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)){
					//Retailer
					// MapKey = Retailer Flag + Admin System System type
					mapKey = firstFS + firstPartyAdminSysType ;
									
				}
			
			if ( (firstFS == null) || (firstFS != null && !firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE) )){
				if (!partyAdminConteqMap.containsKey(mapKey)) {

					partyAdminConteqMap.put(mapKey, partyAdminContequivBObj);

				} else {

					XContEquivBObjExt partyAdminContequivBObjInMap = (XContEquivBObjExt) partyAdminConteqMap.get(mapKey);

					secondPartyAdminSysValue = partyAdminContequivBObjInMap.getAdminSystemValue();

					secondPartyAdminSysType = partyAdminContequivBObjInMap.getAdminSystemType();

					String secondRetailerFlag = partyAdminContequivBObj.getXSourceRetailerFlag();
					
					secondFS = partyAdminContequivBObjInMap.getXSourceRetailerFlag();


					if (secondRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_Y)) {

						secondRetailerId = partyAdminContequivBObj.getXRetailerId();

					}

					Timestamp party1CreatedDt = DateFormatter.getTimestamp(partyAdminContequivBObj.getContEquivLastUpdateDate());

					Timestamp party2CreatedDt = DateFormatter.getTimestamp(partyAdminContequivBObjInMap.getContEquivLastUpdateDate());

					if (firstPartyAdminSysType.equalsIgnoreCase(secondPartyAdminSysType)) {

						if (firstPartyAdminSysType.equalsIgnoreCase(ExternalRuleConstant.SOURCE_IDENTIFIER_TYPE_SFDC)) {

							if (xIdenBObj == null) {
								if (party1CreatedDt.before(party2CreatedDt)) {
									
									if(firstRetailerFlag!= null && firstRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_Y)){
										//Retailer Copy
										//MapKey = Retailer Flag + Admin System System type + Retailer ID
										mapKey = firstRetailerFlag + firstPartyAdminSysType + firstRetailerId;
																				
									}else if(firstRetailerFlag!= null && firstRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_N)){
										//Wholesale Copy											
										// MapKey = Retailer Flag + Admin System System type
										mapKey = firstRetailerFlag + firstPartyAdminSysType;
										
									}else if(firstRetailerFlag!= null && firstRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)){
										//If FS, MapKey = FS + Admin System System type
										
										mapKey = firstFS + firstPartyAdminSysType ;
									}
									
										partyAdminConteqMap.put(mapKey,partyAdminContequivBObj);
							
								}else{
								
								if(secondRetailerFlag!= null && secondRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_Y)){
									//Retailer Copy
									//MapKey = Retailer Flag + Admin System System type + Retailer ID
									
									mapKey = secondRetailerFlag + secondPartyAdminSysType + secondRetailerId;
									
									
								}else if(secondRetailerFlag!= null && secondRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_N)){
									//Wholesale Copy											
									// MapKey = Retailer Flag + Admin System System type
									mapKey = secondRetailerFlag + secondPartyAdminSysType;
									
								
								}else if(secondRetailerFlag != null && secondRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)){
									//If FS, MapKey = FS + Admin System System type
									
									mapKey = secondFS + secondPartyAdminSysType ;
								}
							
								partyAdminConteqMap.put(mapKey,partyAdminContequivBObjInMap);
							}
						} else {

								String newCont = xIdenBObj.getPartyId();

									if (newCont.equalsIgnoreCase(partyAdminContequivBObj.getPartyId())) {
										//both belongs to same party
										if(firstRetailerFlag != null && firstRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_Y)){
											//Retailer Copy
											// MapKey = Retailer Flag + Admin System System type + RetailerId 
											mapKey = firstRetailerFlag + firstPartyAdminSysType + firstRetailerId;
											
										}else if(firstRetailerFlag != null && firstRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_N)){
											//Wholesale Copy
											//MapKey = Retailer Flag + Admin System System type 
											mapKey = firstRetailerFlag + firstPartyAdminSysType ;
											
										}else if(firstRetailerFlag != null && firstRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)){
											
											mapKey = firstFS + firstPartyAdminSysType;
										}
										
										partyAdminConteqMap.put(mapKey,partyAdminContequivBObj);}
								}
							
							} else {
								if (party1CreatedDt.before(party2CreatedDt)) {
									
									if(firstRetailerFlag!= null && firstRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_Y)){
										//Retailer Copy
										//MapKey = Retailer Flag + Admin System System type + Retailer ID
										mapKey = firstRetailerFlag + firstPartyAdminSysType + firstRetailerId;
																				
									}else if(firstRetailerFlag!= null && firstRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_N)){
										//Wholesale Copy											
										// MapKey = Retailer Flag + Admin System System type
										mapKey = firstRetailerFlag + firstPartyAdminSysType;
										
									}else if(firstRetailerFlag!= null && firstRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)){
										//If FS, MapKey = FS + Admin System System type
										
										mapKey = firstFS + firstPartyAdminSysType ;
									}
									
										partyAdminConteqMap.put(mapKey,partyAdminContequivBObj);
							
								}else{
								
								if(secondRetailerFlag!= null && secondRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_Y)){
									//Retailer Copy
									//MapKey = Retailer Flag + Admin System System type + Retailer ID
									
									mapKey = secondRetailerFlag + secondPartyAdminSysType + secondRetailerId;
									
									
								}else if(secondRetailerFlag!= null && secondRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_N)){
									//Wholesale Copy											
									// MapKey = Retailer Flag + Admin System System type
									mapKey = secondRetailerFlag + secondPartyAdminSysType;
									
								
								}else if(secondRetailerFlag != null && secondRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)){
									//If FS, MapKey = FS + Admin System System type
									
									mapKey = secondFS + secondPartyAdminSysType ;
								}
							
								partyAdminConteqMap.put(mapKey,partyAdminContequivBObjInMap);
								}
							}
						}
					}
				}
			}
		}
			
			//sortedMagicNumber(dealerRetailerMap, vecAllParty, partyIdentMap, control);
			sortedMagicNumber(vecAllParty, partyIdentMap, control);
			
	} else if (batchIndicator.equals(ExternalRuleConstant.BATCH_IND_Y)) {
			for (int i = 0; i < vecAllParty.size(); i++) {
				TCRMPartyBObj party = (TCRMPartyBObj) vecAllParty.get(i);

				Vector<XOrgNameBObjExt> vecTempOrgNameBOBj = new Vector<XOrgNameBObjExt>();
				vecTempOrgNameBOBj = ((XOrgBObjExt) party)
						.getItemsTCRMOrganizationNameBObj();

				String firstPartyNameUsageType = null;

				String secondPartyNameUsageType = null;

				String firstPartyNameUsageValue = null;

				String secondPartyNameUsageValue = null;

				// For Org Names
				for (int j = 0; j < vecTempOrgNameBOBj.size(); j++) {

					XOrgNameBObjExt orgnameBObj = (XOrgNameBObjExt) vecTempOrgNameBOBj
							.get(j);

					firstPartyNameUsageValue = orgnameBObj.getNameUsageValue();

					firstPartyNameUsageType = orgnameBObj.getNameUsageType();

					if (!orgNameMap.containsKey(firstPartyNameUsageType)) {
						orgNameMap.put(firstPartyNameUsageType, orgnameBObj);
					} else {

						XOrgNameBObjExt nameBObjInMap = orgNameMap
								.get(firstPartyNameUsageType);

						secondPartyNameUsageValue = nameBObjInMap
								.getNameUsageValue();

						secondPartyNameUsageType = nameBObjInMap
								.getNameUsageType();

						Timestamp person1CreatedDt = DateFormatter
								.getTimestamp(nameBObjInMap
										.getXLastModifiedSystemDate());

						Timestamp person2CreatedDt = DateFormatter
								.getTimestamp(orgnameBObj
										.getXLastModifiedSystemDate());

						if (person1CreatedDt.after(person2CreatedDt)) {

							orgNameMap.put(secondPartyNameUsageType,
									nameBObjInMap);
						}

						else {

							orgNameMap
									.put(firstPartyNameUsageType, orgnameBObj);
						}

					}

				}
				// For Party Address

				Vector<XAddressGroupBObjExt> vecTempPartyAddressBObj = new Vector<XAddressGroupBObjExt>();
				Vector<XAddressGroupBObjExt> vecRetailPartyAddressBObj = new Vector<XAddressGroupBObjExt>();

				vecTempPartyAddressBObj = party.getItemsTCRMPartyAddressBObj();

				String firstPartyValidityType = null;

				String secondPartyValidityType = null;

				String firstPartyAddrUsageType = null;

				String secondPartyAddrUsageType = null;

				String firstPartyAddrUsageValue = null;

				String secondPartyAddrUsageValue = null;
				boolean isCSet = false;

				boolean isBusinessSet = false;

				XOrgBObjExt orgBObjExt = (XOrgBObjExt) party;

				String sourceIdentifierType = orgBObjExt
						.getSourceIdentifierType();
				addressSurvivourshipLogicImplementation(control,
						partyAddressMap, vecTempPartyAddressBObj,
						vecRetailPartyAddressBObj, isCSet, isBusinessSet,
						orgBObjExt.getXBatchInd(), dealerRetailerMap);

				/*
				 * if(orgBObjExt!=null && orgBObjExt.getXBatchInd()!=null &&
				 * orgBObjExt
				 * .getXMarketName().equalsIgnoreCase(ExternalRuleConstant
				 * .MARKET_NAME_MALAYSIA) &&
				 * orgBObjExt.getXBatchInd().equalsIgnoreCase
				 * (ExternalRuleConstant.BATCH_IND_Y)){ //FOr MALAYSIA
				 * INITIALIZATION
				 * addressSurvivourshipLogicImplementation(control,
				 * partyAddressMap, vecTempPartyAddressBObj,
				 * vecRetailPartyAddressBObj, isCSet,
				 * isBusinessSet,orgBObjExt.getXBatchInd());
				 * 
				 * }else if(orgBObjExt!=null && orgBObjExt.getXBatchInd()!=null
				 * &&
				 * orgBObjExt.getXBatchInd().equalsIgnoreCase(ExternalRuleConstant
				 * .BATCH_IND_N) && sourceIdentifierType!=null &&
				 * sourceIdentifierType.equalsIgnoreCase(ExternalRuleConstant.
				 * SOURCE_IDENTIFIER_TYPE_AUTOLINE)){
				 * addressSurvivourshipLogicImplementation(control,
				 * partyAddressMap, vecTempPartyAddressBObj,
				 * vecRetailPartyAddressBObj, isCSet,
				 * isBusinessSet,orgBObjExt.getXBatchInd()); }else
				 * if(sourceIdentifierType
				 * .equalsIgnoreCase(ExternalRuleConstant.
				 * SOURCE_IDENTIFIER_TYPE_SFDC)){
				 * addressSurvivourshipLogicImplementationRealtime(control,
				 * partyAddressMap, vecTempPartyAddressBObj,
				 * vecRetailPartyAddressBObj, isCSet, isBusinessSet,orgBObjExt);
				 * }
				 */

				// For Party Identification

				Vector<XIdentifierBObjExt> vecTempPartyIdentificationBObj = new Vector<XIdentifierBObjExt>();

				vecTempPartyIdentificationBObj = party
						.getItemsTCRMPartyIdentificationBObj();

				String firstPartyIdentificationType = null;

				String secondPartyIdentificationType = null;

				String firstPartyIdentificationValue = null;

				String secondPartyIdentificationValue = null;

				String firstRetailerId = null;

				String secondRetailerId = null;

				String mapKey = null;

				XIdentifierBObjExt xIdenBObj = null;

				for (int j = 0; j < vecTempPartyIdentificationBObj.size(); j++) {

					XIdentifierBObjExt partyIdenBObj = (XIdentifierBObjExt) vecTempPartyIdentificationBObj
							.get(j);

					firstPartyIdentificationValue = partyIdenBObj
							.getIdentificationValue();

					firstPartyIdentificationType = partyIdenBObj
							.getIdentificationType();

					firstRetailerId = partyIdenBObj.getXRetailerId();

					if (firstPartyIdentificationType
							.equalsIgnoreCase(ExternalRuleConstant.ID_TYPE_MAGIC)) {

						mapKey = firstPartyIdentificationType + firstRetailerId;

					} else {
						mapKey = firstPartyIdentificationType;
					}

					if (!partyIdentMap.containsKey(mapKey)) {

						partyIdentMap.put(mapKey, partyIdenBObj);

					} else {

						XIdentifierBObjExt idenBObjInMap = partyIdentMap
								.get(mapKey);

						secondPartyIdentificationValue = idenBObjInMap
								.getIdentificationValue();

						secondPartyIdentificationType = idenBObjInMap
								.getIdentificationType();

						secondRetailerId = idenBObjInMap.getXRetailerId();

						if (firstPartyIdentificationType
								.equalsIgnoreCase(secondPartyIdentificationType)) {

							if (firstPartyIdentificationType
									.equals(ExternalRuleConstant.ID_TYPE_UCID)) {
								// UCID
								Timestamp party1CreatedDt = DateFormatter
										.getTimestamp(idenBObjInMap
												.getXLastModifiedSystemDate());

								Timestamp party2CreatedDt = DateFormatter
										.getTimestamp(partyIdenBObj
												.getXLastModifiedSystemDate());
								// Oldest record survives
								if (xIdenBObj == null) {
									if (party1CreatedDt.before(party2CreatedDt)) {

										mapKey = secondPartyIdentificationType;

										partyIdentMap
												.put(mapKey, idenBObjInMap);

										xIdenBObj = idenBObjInMap;
									}

									else {
										mapKey = firstPartyIdentificationType;

										partyIdentMap
												.put(mapKey, partyIdenBObj);

										xIdenBObj = partyIdenBObj;
									}
								} else {

									String newCont = xIdenBObj.getPartyId();

									if (newCont.equalsIgnoreCase(partyIdenBObj
											.getPartyId())) {

										// both belongs to same party
										mapKey = firstPartyIdentificationType;

										partyIdentMap
												.put(mapKey, partyIdenBObj);
									}
								}
							} else if (firstPartyIdentificationType
									.equals(ExternalRuleConstant.ID_TYPE_MAGIC)) {
								// MAGIC
								Timestamp party1CreatedDt = DateFormatter
										.getTimestamp(idenBObjInMap
												.getXLastModifiedSystemDate());

								Timestamp party2CreatedDt = DateFormatter
										.getTimestamp(partyIdenBObj
												.getXLastModifiedSystemDate());

								// Oldest record survives
								if (xIdenBObj == null) {
									if (party1CreatedDt.before(party2CreatedDt)) {

										mapKey = secondPartyIdentificationType
												+ secondRetailerId;

										partyIdentMap
												.put(mapKey, idenBObjInMap);

										xIdenBObj = idenBObjInMap;
									}

									else {

										mapKey = firstPartyIdentificationType
												+ firstRetailerId;

										partyIdentMap
												.put(mapKey, partyIdenBObj);

										xIdenBObj = partyIdenBObj;
									}
								} else {
									String newCont = xIdenBObj.getPartyId();

									if (newCont.equalsIgnoreCase(partyIdenBObj
											.getPartyId())) {
										// both belong to same party

										mapKey = firstPartyIdentificationType
												+ firstRetailerId;

										partyIdentMap
												.put(mapKey, partyIdenBObj);
									}
								}

							} else {

								// All Id types except UCID and MAGIC
								Timestamp party1CreatedDt = DateFormatter
										.getTimestamp(idenBObjInMap
												.getXLastModifiedSystemDate());

								Timestamp party2CreatedDt = DateFormatter
										.getTimestamp(partyIdenBObj
												.getXLastModifiedSystemDate());

								if (party1CreatedDt.after(party2CreatedDt)) {

									partyIdentMap.put(
											secondPartyIdentificationType,
											idenBObjInMap);
								}

								else {

									partyIdentMap.put(
											firstPartyIdentificationType,
											partyIdenBObj);
								}

							}
						}

					}

				}

				// For Party Contact Method

				Vector<XContactMethodGroupBObjExt> vecTempPartyContactMethodBObj = new Vector<XContactMethodGroupBObjExt>();

				vecTempPartyContactMethodBObj = party
						.getItemsTCRMPartyContactMethodBObj();

				String firstPartyValidityContType = null;

				String secondPartyValidityContType = null;

				String firstPartyContMethodUsageType = null;

				String secondPartyContMethodUsageType = null;

				String firstPartyContMethodUsageValue = null;

				String secondPartyContMethodUsageValue = null;

				String firstPrefInd = null;

				String secondPrefInd = null;

				for (int j = 0; j < vecTempPartyContactMethodBObj.size(); j++) {

					XContactMethodGroupBObjExt partyContMethBObj = (XContactMethodGroupBObjExt) vecTempPartyContactMethodBObj
							.get(j);

					firstPartyContMethodUsageValue = partyContMethBObj
							.getContactMethodUsageValue();

					firstPartyContMethodUsageType = partyContMethBObj
							.getContactMethodUsageType();

					firstPrefInd = partyContMethBObj
							.getPreferredContactMethodIndicator();

					if (!partyContMethMap
							.containsKey(firstPartyContMethodUsageType)) {
						partyContMethMap.put(firstPartyContMethodUsageType,
								partyContMethBObj);
					} else {

						XContactMethodGroupBObjExt contMethodBObjInMap = partyContMethMap
								.get(firstPartyContMethodUsageType);

						secondPartyContMethodUsageValue = contMethodBObjInMap
								.getContactMethodUsageValue();

						secondPartyContMethodUsageType = contMethodBObjInMap
								.getContactMethodUsageType();

						secondPrefInd = contMethodBObjInMap
								.getPreferredContactMethodIndicator();

						if (firstPartyContMethodUsageType
								.equalsIgnoreCase(secondPartyContMethodUsageType)) {

							Timestamp party1CreatedDt = DateFormatter
									.getTimestamp(contMethodBObjInMap
											.getXLastModifiedSystemDate());

							Timestamp party2CreatedDt = DateFormatter
									.getTimestamp(partyContMethBObj
											.getXLastModifiedSystemDate());

							if (firstPrefInd != null
									&& firstPrefInd
											.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_Y)
									&& (secondPrefInd == null || !(secondPrefInd
											.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_Y)))) {

								partyContMethMap.put(
										firstPartyContMethodUsageType,
										partyContMethBObj);

							} else if (secondPrefInd != null
									&& secondPrefInd
											.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_Y)
									&& (firstPrefInd == null || !(firstPrefInd
											.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_Y)))) {

								partyContMethMap.put(
										secondPartyContMethodUsageType,
										contMethodBObjInMap);

							} else {

								if (party1CreatedDt.after(party2CreatedDt)) {

									partyContMethMap.put(
											secondPartyContMethodUsageType,
											contMethodBObjInMap);
								}

								else if (party1CreatedDt
										.before(party2CreatedDt)) {

									partyContMethMap.put(
											firstPartyContMethodUsageType,
											partyContMethBObj);

								} else if (party1CreatedDt
										.equals(party2CreatedDt)) {

									partyContMethMap.put(
											firstPartyContMethodUsageType,
											partyContMethBObj);

								}
							}

						}

					}

				}

				// For Party Admin Contequiv

				Vector<XContEquivBObjExt> vecTempAdminContequivBObj = null;

				vecTempAdminContequivBObj = party
						.getItemsTCRMAdminContEquivBObj();

				String firstPartyAdminSysType = null;

				String secondPartyAdminSysType = null;

				String firstPartyAdminSysValue = null;

				String secondPartyAdminSysValue = null;

				XContEquivBObjExt newadminContEquivBObj = null;

				firstRetailerId = null;

				secondRetailerId = null;

				for (int j = 0; j < vecTempAdminContequivBObj.size(); j++) {

					XContEquivBObjExt partyAdminContequivBObj = (XContEquivBObjExt) vecTempAdminContequivBObj
							.get(j);

					firstPartyAdminSysValue = partyAdminContequivBObj
							.getAdminSystemValue();

					firstPartyAdminSysType = partyAdminContequivBObj
							.getAdminSystemType();

					String firstRetailerFlag = partyAdminContequivBObj
							.getXSourceRetailerFlag();

					if (firstRetailerFlag
							.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_Y)) {

						firstRetailerId = partyAdminContequivBObj
								.getXRetailerId();

						mapKey = firstRetailerFlag + firstPartyAdminSysType
								+ firstRetailerId;

					} else {

						mapKey = firstRetailerFlag + firstPartyAdminSysType;

					}

					if (!partyAdminConteqMap.containsKey(mapKey)) {

						partyAdminConteqMap
								.put(mapKey, partyAdminContequivBObj);

					} else {

						XContEquivBObjExt partyAdminContequivBObjInMap = (XContEquivBObjExt) partyAdminConteqMap
								.get(mapKey);

						secondPartyAdminSysValue = partyAdminContequivBObjInMap
								.getAdminSystemValue();

						secondPartyAdminSysType = partyAdminContequivBObjInMap
								.getAdminSystemType();

						String secondRetailerFlag = partyAdminContequivBObj
								.getXSourceRetailerFlag();

						if (secondRetailerFlag
								.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_Y)) {

							secondRetailerId = partyAdminContequivBObj
									.getXRetailerId();

						}

						Timestamp party1CreatedDt = DateFormatter
								.getTimestamp(partyAdminContequivBObj
										.getContEquivLastUpdateDate());

						Timestamp party2CreatedDt = DateFormatter
								.getTimestamp(partyAdminContequivBObjInMap
										.getContEquivLastUpdateDate());

						if (firstPartyAdminSysType
								.equalsIgnoreCase(secondPartyAdminSysType)) {

							if (firstPartyAdminSysType
									.equalsIgnoreCase(ExternalRuleConstant.SOURCE_IDENTIFIER_TYPE_SFDC)) {

								if (xIdenBObj == null) {

									if (party1CreatedDt.before(party2CreatedDt)) {

										if (firstRetailerFlag
												.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_Y)) {

											mapKey = firstRetailerFlag
													+ firstPartyAdminSysType
													+ firstRetailerId;

										} else {

											mapKey = firstRetailerFlag
													+ firstPartyAdminSysType;

										}

										partyAdminConteqMap.put(mapKey,
												partyAdminContequivBObj);

									} else {
										if (secondRetailerFlag
												.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_Y)) {

											mapKey = secondRetailerFlag
													+ secondPartyAdminSysType
													+ secondRetailerId;

										} else {

											mapKey = secondRetailerFlag
													+ secondPartyAdminSysType;

										}

										partyAdminConteqMap.put(mapKey,
												partyAdminContequivBObjInMap);

									}
								} else {

									String newCont = xIdenBObj.getPartyId();

									if (newCont
											.equalsIgnoreCase(partyAdminContequivBObj
													.getPartyId())) {
										// both belongs to same party
										if (firstRetailerFlag
												.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_Y)) {

										mapKey = firstRetailerFlag
												+ firstPartyAdminSysType
												+ firstRetailerId;

									} else {

										mapKey = firstRetailerFlag
												+ firstPartyAdminSysType;

									}
									partyAdminConteqMap.put(mapKey,
											partyAdminContequivBObj);
								}
							}
						} else {
							if (party1CreatedDt.after(party2CreatedDt)) {

								if (firstRetailerFlag
										.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_Y)) {

									mapKey = firstRetailerFlag
											+ firstPartyAdminSysType
											+ firstRetailerId;

								} else {

									mapKey = firstRetailerFlag
											+ firstPartyAdminSysType;

								}

								partyAdminConteqMap.put(mapKey,
										partyAdminContequivBObj);

							} else {

								if (secondRetailerFlag
										.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_Y)) {

									mapKey = secondRetailerFlag
											+ secondPartyAdminSysType
											+ secondRetailerId;

								} else {

									mapKey = secondRetailerFlag
											+ secondPartyAdminSysType;

								}

								partyAdminConteqMap.put(mapKey,
										partyAdminContequivBObjInMap);

							}
						}
					}
				}

			}
			}
		}
	}

	// For Org Name,Address,ContactMethod,Privacy
	// Preference,AdminContequiv,Identifier survivorship
	private void survivalOfIndividualOrgWithPriority(Vector vecAllParty,
			DWLControl control, HashMap<String, XOrgNameBObjExt> orgNameMap,
			HashMap<String, XAddressGroupBObjExt> partyAddressMap,
			HashMap<String, XIdentifierBObjExt> partyIdentMap,
			HashMap<String, XContactMethodGroupBObjExt> partyContMethMap,
			HashMap<String, TCRMAdminContEquivBObj> partyAdminConteqMap,
			HashMap<String, TCRMAdminContEquivBObj> partyAdminConteqMap1,
			HashMap<String, String> dealerRetailerMap)
			throws Exception {
		
		//HashMap<String, String> dealerRetailerMap = new HashMap<String, String>();
		dealerRetailerMap = getAllRetailersByDealerForMagic(dealerRetailerMap);
		XOrgBObjExt orgBObjExtIncomingParty = (XOrgBObjExt) vecAllParty.get(0);
		String batchIndicator = orgBObjExtIncomingParty.getXBatchInd();
		String market_name = orgBObjExtIncomingParty.getXMarketName();
		if ((batchIndicator.equalsIgnoreCase(ExternalRuleConstant.BATCH_IND_N) && (market_name.equals(ExternalRuleConstant.MARKET_NAME_MALAYSIA)))) {
			//MALAYSIA | SFDC
			//dealer retailer changes
				
			//changes for Dealer-Retailer Address 23May2018
			//survivedDealerRetailerAddress(dealerRetailerMap, vecAllParty, partyAddressMap, control);
			survivedDealerRetailerAddress(vecAllParty, partyAddressMap, control);
			
			//changes for Dealer-Retailer Address 23May2018
			for (int i = 0; i < vecAllParty.size(); i++) {
					
				TCRMPartyBObj party = (TCRMPartyBObj) vecAllParty.get(i);
	
				Vector<XOrgNameBObjExt> vecTempOrgNameBOBj = new Vector<XOrgNameBObjExt>();
	
				vecTempOrgNameBOBj = ((XOrgBObjExt) party).getItemsTCRMOrganizationNameBObj();
	
				String mapKey = null;
	
				String firstPartyNameUsageType = null;
	
				String secondPartyNameUsageType = null;
	
				// String firstPartyNameUsageValue = null;
	
				// String secondPartyNameUsageValue = null;
	
				String firstPartySource = null;
	
				String secondPartySource = null;
	
				// --Start FS changes Loveleen------//
	
				String firstFS = null;
	
				String secondFS = null;
	
				// --End FS changes Loveleen -------//
	
				// For Org Names
				for (int j = 0; j < vecTempOrgNameBOBj.size(); j++) {
	
					XOrgNameBObjExt orgnameBObj = (XOrgNameBObjExt) vecTempOrgNameBOBj.get(j);
	
					// firstPartyNameUsageValue = orgnameBObj.getNameUsageValue();
	
					firstPartyNameUsageType = orgnameBObj.getNameUsageType();
	
					firstPartySource = orgnameBObj.getSourceIdentifierType();
	
					// If FS, Key = Name usage type + FS
					if (orgnameBObj.getXOrgNameRetailerFlag() != null
							&& orgnameBObj.getXOrgNameRetailerFlag().equals(ExternalRuleConstant.FS_VALUE)) {
	
						mapKey = firstPartyNameUsageType + ExternalRuleConstant.FS_VALUE;
	
					} else {
	
						// Otherwise Key = Name Usage type
						mapKey = firstPartyNameUsageType;
	
					}
	
					// -- End FS Changes Loveleen-----------//
	
					// FSWS objects do not participate in Merge
					if (firstFS == null || !firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE)) {
						if (!orgNameMap.containsKey(mapKey)) {
							// If key doesn't exist in map
							orgNameMap.put(mapKey, orgnameBObj);
	
						} else {
	
							// If key exists in map
	
							XOrgNameBObjExt nameBObjInMap = orgNameMap.get(mapKey);
	
							// secondPartyNameUsageValue =
							// nameBObjInMap.getNameUsageValue();
	
							secondPartyNameUsageType = nameBObjInMap.getNameUsageType();
	
							secondPartySource = nameBObjInMap.getSourceIdentifierType();
	
							Timestamp person1CreatedDt = DateFormatter.getTimestamp(nameBObjInMap.getXLastModifiedSystemDate());
	
							Timestamp person2CreatedDt = DateFormatter.getTimestamp(orgnameBObj.getXLastModifiedSystemDate());
	
							if (firstPartyNameUsageType.equalsIgnoreCase(secondPartyNameUsageType)) {
	
								if (firstPartySource.equalsIgnoreCase(secondPartySource)) {
	
									if (person1CreatedDt.after(person2CreatedDt)) {
	
										// -- Start FS Changes Loveleen-----------//
	
										if (secondFS != null) {
											// If FS, Key = Name usage type + FS
											mapKey = secondPartyNameUsageType + secondFS;
	
										} else {
											// Otherwise Key = Name Usage type
											mapKey = secondPartyNameUsageType;
	
										}
										// -- End FS Changes Loveleen-----------//
	
										orgNameMap.put(mapKey, nameBObjInMap);
	
									}
	
									else {
	
										// -- Start FS Changes Loveleen-----------//
	
										if (firstFS != null
												&& firstFS
														.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {
											// If FS, Key = Name usage type + FS
											mapKey = firstPartyNameUsageType
													+ firstFS;
	
										} else {
											// Otherwise Key = Name Usage type
											mapKey = firstPartyNameUsageType;
	
										}
	
										// -- End FS Changes Loveleen-----------//
	
										orgNameMap.put(firstPartyNameUsageType,
												orgnameBObj);
	
									}
								} else {
									if (firstPartySource.equalsIgnoreCase(ExternalRuleConstant.SOURCE_IDENTIFIER_TYPE_SFDC)) {
	
										// SFDC is priority source
	
										// -- Start FS Changes Loveleen-----------//
	
										if (firstFS != null && firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {
											// If FS, Key = Name usage type + FS
											mapKey = firstPartyNameUsageType
													+ firstFS;
	
										} else {
											// Otherwise Key = Name Usage type
											mapKey = firstPartyNameUsageType;
	
										}
	
										// -- End FS Changes Loveleen-----------//
	
										orgNameMap.put(mapKey, orgnameBObj);
	
									} else {
	
										// -- Start FS Changes Loveleen-----------//
	
										if (secondFS != null) {
											// If FS, Key = Name usage type + FS
											mapKey = secondPartyNameUsageType + secondFS;
	
										} else {
											// Otherwise Key = Name Usage type
											mapKey = secondPartyNameUsageType;
	
										}
										// -- End FS Changes Loveleen-----------//
	
										orgNameMap.put(secondPartyNameUsageType,
												nameBObjInMap);
	
									}
								}
							}
						}
					}
	
				}
				// For Party Address
	
				Vector<XAddressGroupBObjExt> vecTempPartyAddressBObj = new Vector<XAddressGroupBObjExt>();
				Vector<XAddressGroupBObjExt> vecRetailPartyAddressBObj = new Vector<XAddressGroupBObjExt>();
	
				vecTempPartyAddressBObj = party.getItemsTCRMPartyAddressBObj();
	
				String firstPartyValidityType = null;
	
				String secondPartyValidityType = null;
	
				String firstPartyAddrUsageType = null;
	
				String secondPartyAddrUsageType = null;
	
				String firstPartyAddrUsageValue = null;
	
				String secondPartyAddrUsageValue = null;
	
				boolean isCSet = false;
	
				boolean isBusinessSet = false;
	
				XOrgBObjExt orgBObjExt = (XOrgBObjExt) party;
	
				String sourceIdentifierType = orgBObjExt.getSourceIdentifierType();
					addressSurvivourshipLogicImplementationwithPriority(control,
							partyAddressMap, vecTempPartyAddressBObj,
							vecRetailPartyAddressBObj, isCSet, isBusinessSet,
							orgBObjExt.getXBatchInd(),dealerRetailerMap, orgBObjExt.getXMarketName());
					
	
					// For Party Identification
	
					Vector<XIdentifierBObjExt> vecTempPartyIdentificationBObj = new Vector<XIdentifierBObjExt>();
	
					vecTempPartyIdentificationBObj = party.getItemsTCRMPartyIdentificationBObj();
	
					String firstPartyIdentificationType = null;
	
					String secondPartyIdentificationType = null;
	
					String firstPartyIdentificationValue = null;
	
					String secondPartyIdentificationValue = null;
	
					String firstRetailerId = null;
					
					String firstDealer = null;
	
					String secondRetailerId = null;
					
					String secondDealer = null;
					
					mapKey = null;
	
					// -- Start FS Changes Loveleen-----------//
	
					firstFS = null;
	
					secondFS = null;
	
					// -- End FS Changes Loveleen-----------//
	
					XIdentifierBObjExt xIdenBObj = null;
	
					for (int j = 0; j < vecTempPartyIdentificationBObj.size(); j++) {
	
						XIdentifierBObjExt partyIdenBObj = (XIdentifierBObjExt) vecTempPartyIdentificationBObj.get(j);
	
						firstPartyIdentificationValue = partyIdenBObj.getIdentificationValue();
	
						firstPartyIdentificationType = partyIdenBObj.getIdentificationType();	
						
						firstPartySource = party.getSourceIdentifierType();
	
						firstRetailerId = partyIdenBObj.getXRetailerId();
						
						// --  FS Changes 
	
						firstFS = partyIdenBObj.getXIdentifierRetailerFlag();
	
						// -- FS Changes 
	
						if (firstFS != null && firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE) && 
								firstRetailerId == null && !firstPartyIdentificationType.equalsIgnoreCase(ExternalRuleConstant.ID_TYPE_PERSON_EPUCID)) {
							
								mapKey = firstPartyIdentificationType + firstFS;
						}
	
						else if(firstFS == null &&
								firstRetailerId == null && !firstPartyIdentificationType.equalsIgnoreCase(ExternalRuleConstant.ID_TYPE_PERSON_EPUCID)){
							
								mapKey = firstPartyIdentificationType;
						}
						
						
						if(((firstFS == null)  || (firstFS != null && !firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE)&& !firstFS.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_Y))) ){
							
							if (!partyIdentMap.containsKey(mapKey)) {
		
								partyIdentMap.put(mapKey, partyIdenBObj);
		
							} else {
		
								XIdentifierBObjExt idenBObjInMap = partyIdentMap.get(mapKey);
		
								secondPartyIdentificationValue = idenBObjInMap.getIdentificationValue();
		
								secondPartyIdentificationType = idenBObjInMap.getIdentificationType();
		
								secondPartySource = idenBObjInMap.getSourceIdentifierType();
		
								secondRetailerId = idenBObjInMap.getXRetailerId();
								
								secondFS = idenBObjInMap.getXIdentifierRetailerFlag();
	
								Timestamp party1CreatedDt = DateFormatter.getTimestamp(idenBObjInMap.getXLastModifiedSystemDate());
		
								Timestamp party2CreatedDt = DateFormatter.getTimestamp(partyIdenBObj.getXLastModifiedSystemDate());
		
								if (firstPartyIdentificationType.equalsIgnoreCase(secondPartyIdentificationType)) {
		
									if (firstPartyIdentificationType.equals(ExternalRuleConstant.ID_TYPE_UCID)) {
		
										// UCID
										// Oldest record survives
		
										if (xIdenBObj == null) {
		
											if (party1CreatedDt.before(party2CreatedDt)) {
		
												partyIdentMap.put(secondPartyIdentificationType,idenBObjInMap);
		
												xIdenBObj = idenBObjInMap;
		
											} else {
		
												partyIdentMap.put(firstPartyIdentificationType,partyIdenBObj);
		
												xIdenBObj = partyIdenBObj;
		
											}
		
										} else {
		
											String newCont = xIdenBObj.getPartyId();
		
											if (newCont.equalsIgnoreCase(partyIdenBObj.getPartyId())) {
		
												// both belongs to same party
		
												partyIdentMap.put(firstPartyIdentificationType,partyIdenBObj);
		
											}
										}
									}  
									else if (firstPartyIdentificationType.equals(ExternalRuleConstant.ID_TYPE_BPID) && firstFS != null && firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {
										// BPID
	
										// Oldest BPID survives
	
										if (party1CreatedDt.before(party2CreatedDt)) {
	
											mapKey = secondPartyIdentificationType + secondFS;
	
											partyIdentMap.put(mapKey, idenBObjInMap);
	
											// xIdenBObj = idenBObjInMap;
	
										} else {
	
											mapKey = firstPartyIdentificationType + firstFS;
	
											partyIdentMap.put(mapKey, partyIdenBObj);
	
											// xIdenBObj = partyIdenBObj;
										}
									
										
									}
		
									} else if (firstPartyIdentificationType.equals(ExternalRuleConstant.ID_TYPE_ORG_EPUCID)) {
		
									// Should not survive
								} else {
		
									if (firstPartySource != null && secondPartySource != null) {
		
										if (firstPartySource.equalsIgnoreCase(secondPartySource)) {
											// Same Source
		
											if (party1CreatedDt.after(party2CreatedDt)) {
		
												if (secondRetailerId == null) {
		
													// If FS, Key = Identification type + FS
													if (secondFS !=null && secondFS.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {
		
														mapKey = secondPartyIdentificationType	+ secondFS;
													} else {
														// Otherwise, Key = Identification type
		
														mapKey = secondPartyIdentificationType;
													}
		
												} 
													partyIdentMap.put(mapKey, idenBObjInMap);
											}
		
											else {
		
												if (firstRetailerId == null) {
		
													// If FS, Key = Identification type
													// + FS
													if (firstFS !=null && firstFS
															.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {
		
														mapKey = firstPartyIdentificationType
																+ firstFS;
		
													} else {
														// Otherwise, Key =
														// Identification type
		
														mapKey = firstPartyIdentificationType;
													}
		
												} 
		
												partyIdentMap.put(mapKey, partyIdenBObj);
											}
		
										} else {
											// Different source
											// Priority source will survive
											if (firstPartySource
													.equalsIgnoreCase(ExternalRuleConstant.SOURCE_IDENTIFIER_TYPE_AUTOLINE)) {
												if (firstRetailerId == null) {
		
													// If FS, Key = Identification type
													// + FS
													if (firstFS !=null && firstFS
															.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {
		
														mapKey = firstPartyIdentificationType
																+ firstFS;
		
													} else {
														// Otherwise, Key =
														// Identification type
		
														mapKey = firstPartyIdentificationType;
		
													}
		
												} 
		
												partyIdentMap.put(mapKey, partyIdenBObj);
		
											} else {
		
												if (secondRetailerId == null) {
													// If FS, Key = Identification type
													// + FS
													if (secondFS !=null && secondFS
															.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {
		
														mapKey = secondPartyIdentificationType
																+ secondFS;
		
													} else {
														// Otherwise, Key =
														// Identification type
		
														mapKey = secondPartyIdentificationType;
		
													}
												} 
		
												partyIdentMap.put(mapKey, idenBObjInMap);
											}
										}
									}
								}
							}
						}
				}
	
					// For Party Contact Method
	
					Vector<XContactMethodGroupBObjExt> vecTempPartyContactMethodBObj = new Vector<XContactMethodGroupBObjExt>();
	
					vecTempPartyContactMethodBObj = party
							.getItemsTCRMPartyContactMethodBObj();
	
					String firstPartyValidityContType = null;
	
					String secondPartyValidityContType = null;
	
					String firstPartyContMethodUsageType = null;
	
					String secondPartyContMethodUsageType = null;
	
					String firstPartyContMethodUsageValue = null;
	
					String secondPartyContMethodUsageValue = null;
	
					String firstPrefInd = null;
	
					String secondPrefInd = null;
	
					// --Start FS changes Loveleen------//
					firstFS = null;
	
					secondFS = null;
	
					// --End FS changes Loveleen------//
	
					for (int j = 0; j < vecTempPartyContactMethodBObj.size(); j++) {
	
						XContactMethodGroupBObjExt partyContMethBObj = (XContactMethodGroupBObjExt) vecTempPartyContactMethodBObj
								.get(j);
	
						firstPartySource = partyContMethBObj
								.getSourceIdentifierType();
	
						firstPartyContMethodUsageType = partyContMethBObj
								.getContactMethodUsageType();
	
						firstFS = partyContMethBObj.getXContactRetailerFlag();
	
						if (partyContMethBObj.getPreferredContactMethodIndicator() != null)
	
							firstPrefInd = partyContMethBObj
									.getPreferredContactMethodIndicator();
	
						// If FS, Key = Contact Method Usage Type + FS
						if (firstFS !=null && firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {
	
							mapKey = firstPartyContMethodUsageType + firstFS;
	
						}
						// Otherwise, Key = Contact Method Usage Type
						else {
	
							mapKey = firstPartyContMethodUsageType;
						}
						
						if (firstFS == null || !firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE)) {
	
						if (!partyContMethMap.containsKey(mapKey)) {
	
							partyContMethMap.put(mapKey, partyContMethBObj);
	
						} else {
	
							XContactMethodGroupBObjExt contMethodBObjInMap = partyContMethMap
									.get(mapKey);
	
							secondPartySource = contMethodBObjInMap
									.getSourceIdentifierType();
	
							secondPartyContMethodUsageType = contMethodBObjInMap
									.getContactMethodUsageType();
	
							secondFS = contMethodBObjInMap
									.getXContactRetailerFlag();
	
							if (contMethodBObjInMap
									.getPreferredContactMethodIndicator() != null)
	
								secondPrefInd = contMethodBObjInMap
										.getPreferredContactMethodIndicator();
	
							if (firstPartyContMethodUsageType
									.equalsIgnoreCase(secondPartyContMethodUsageType)) {
	
								Timestamp party1CreatedDt = DateFormatter
										.getTimestamp(contMethodBObjInMap
												.getXLastModifiedSystemDate());
	
								Timestamp party2CreatedDt = DateFormatter
										.getTimestamp(partyContMethBObj
												.getXLastModifiedSystemDate());
	
								if (firstPartySource
										.equalsIgnoreCase(secondPartySource)) {
									// Same source
									if (firstPrefInd != null
											&& firstPrefInd
													.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_Y)
											&& (secondPrefInd == null || !(secondPrefInd
													.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_Y)))) {
	
										// If FS, Key = Contact Method Usage Type +
										// FS
										if (firstFS !=null && firstFS
												.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {
	
											mapKey = firstPartyContMethodUsageType
													+ firstFS;
	
										}
										// Otherwise, Key = Contact Method Usage
										// Type
										else {
	
											mapKey = firstPartyContMethodUsageType;
	
										}
	
										partyContMethMap.put(mapKey,
												partyContMethBObj);
	
									} else if (secondPrefInd != null
											&& secondPrefInd
													.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_Y)
											&& (firstPrefInd == null || !(firstPrefInd
													.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_Y)))) {
	
										// If FS, Key = Contact Method Usage Type +
										// FS
										if (secondFS !=null && secondFS
												.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {
	
											mapKey = secondPartyContMethodUsageType
													+ secondFS;
	
										}
										// Otherwise, Key = Contact Method Usage
										// Type
										else {
	
											mapKey = secondPartyContMethodUsageType;
	
										}
	
										partyContMethMap.put(mapKey,
												contMethodBObjInMap);
									} else {
	
										if (party1CreatedDt.after(party2CreatedDt)) {
	
											// If FS, Key = Contact Method Usage
											// Type + FS
											if (secondFS !=null && secondFS
													.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {
	
												mapKey = secondPartyContMethodUsageType
														+ secondFS;
	
											}
											// Otherwise, Key = Contact Method Usage
											// Type
											else {
	
												mapKey = secondPartyContMethodUsageType;
	
											}
	
											partyContMethMap.put(mapKey,
													contMethodBObjInMap);
										}
	
										else if (party1CreatedDt
												.before(party2CreatedDt)) {
	
											// If FS, Key = Contact Method Usage
											// Type + FS
											if (firstFS !=null && firstFS
													.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {
	
												mapKey = firstPartyContMethodUsageType
														+ firstFS;
	
											}
											// Otherwise, Key = Contact Method Usage
											// Type
											else {
	
												mapKey = firstPartyContMethodUsageType;
	
											}
	
											partyContMethMap.put(mapKey,
													partyContMethBObj);
	
										} else if (party1CreatedDt
												.equals(party2CreatedDt)) {
	
											// If FS, Key = Contact Method Usage
											// Type + FS
											if (firstFS !=null && firstFS
													.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {
	
												mapKey = firstPartyContMethodUsageType
														+ firstFS;
	
											}
											// Otherwise, Key = Contact Method Usage
											// Type
											else {
	
												mapKey = firstPartyContMethodUsageType;
	
											}
	
											partyContMethMap.put(mapKey,
													partyContMethBObj);
	
										}
									}
								} else {
									// Different source
									if (firstPartySource
											.equalsIgnoreCase(ExternalRuleConstant.SOURCE_IDENTIFIER_TYPE_AUTOLINE)) {
										// If FS, Key = Contact Method Usage Type +
										// FS
										if (firstFS !=null && firstFS
												.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {
	
											mapKey = firstPartyContMethodUsageType
													+ firstFS;
	
										}
										// Otherwise, Key = Contact Method Usage
										// Type
										else {
	
											mapKey = firstPartyContMethodUsageType;
	
										}
	
										partyContMethMap.put(mapKey,
												partyContMethBObj);
									} else {
										// If FS, Key = Contact Method Usage Type +
										// FS
										if (secondFS !=null && secondFS
												.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {
	
											mapKey = secondPartyContMethodUsageType
													+ secondFS;
	
										}
										// Otherwise, Key = Contact Method Usage
										// Type
										else {
	
											mapKey = secondPartyContMethodUsageType;
	
										}
	
										partyContMethMap.put(mapKey,
												partyContMethBObj);
	
										}
									}
								}
							}
						}
					}
	
	
					Vector<XContEquivBObjExt> vecTempAdminContequivBObj = null;
	
					vecTempAdminContequivBObj = party
							.getItemsTCRMAdminContEquivBObj();
	
					String firstPartyAdminSysType = null;
	
					String secondPartyAdminSysType = null;
	
					String firstPartyAdminSysValue = null;
	
					String secondPartyAdminSysValue = null;
	
					String firstRetailerFlag = null;
	
					String secondRetailerFlag = null;
	
					XContEquivBObjExt newadminContEquivBObj = null;
	
					firstRetailerId = null;
	
					secondRetailerId = null;
	
					firstFS = null;
	
					secondFS = null;
	
					for (int j = 0; j < vecTempAdminContequivBObj.size(); j++) {
	
						XContEquivBObjExt partyAdminContequivBObj = (XContEquivBObjExt) vecTempAdminContequivBObj
								.get(j);
	
						firstPartyAdminSysValue = partyAdminContequivBObj
								.getAdminSystemValue();
	
						firstPartyAdminSysType = partyAdminContequivBObj
								.getAdminSystemType();
	
						firstRetailerId = partyAdminContequivBObj.getXRetailerId();
	
						firstRetailerFlag = partyAdminContequivBObj
								.getXSourceRetailerFlag();
	
						firstFS = partyAdminContequivBObj.getXSourceRetailerFlag();
						
						//
						if(firstRetailerFlag!= null && firstRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_Y)){
							//Retailer Copy
							//MapKey = Retailer Flag + Admin System System type + Retailer ID
							mapKey = firstRetailerFlag + firstPartyAdminSysType + firstRetailerId;
																	
						}else if(firstRetailerFlag!= null && firstRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_N)){
							//Wholesale Copy											
							// MapKey = Retailer Flag + Admin System System type
							mapKey = firstRetailerFlag + firstPartyAdminSysType;
							
						}else if(firstRetailerFlag!= null && firstRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)){
							//If FS, MapKey = FS + Admin System System type
							
							mapKey = firstFS + firstPartyAdminSysType ;
						}
						
						if (firstFS == null || !firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE)) {
							
						if (!partyAdminConteqMap.containsKey(mapKey)) {
	
							partyAdminConteqMap
									.put(mapKey, partyAdminContequivBObj);
	
						} else {
	
							XContEquivBObjExt partyAdminContequivBObjInMap = (XContEquivBObjExt) partyAdminConteqMap
									.get(mapKey);
	
							secondPartyAdminSysValue = partyAdminContequivBObjInMap
									.getAdminSystemValue();
	
							secondPartyAdminSysType = partyAdminContequivBObjInMap
									.getAdminSystemType();
	
							secondRetailerId = partyAdminContequivBObjInMap
									.getXRetailerId();
	
							secondRetailerFlag = partyAdminContequivBObjInMap
									.getXSourceRetailerFlag();
							secondFS = partyAdminContequivBObjInMap
									.getXSourceRetailerFlag();
	
							Timestamp party1CreatedDt = DateFormatter
									.getTimestamp(partyAdminContequivBObj
											.getContEquivLastUpdateDate());
	
							Timestamp party2CreatedDt = DateFormatter
									.getTimestamp(partyAdminContequivBObjInMap
											.getContEquivLastUpdateDate());
	
							if (firstPartyAdminSysType
									.equalsIgnoreCase(secondPartyAdminSysType)) {
	
								if (firstPartyAdminSysType
										.equalsIgnoreCase(ExternalRuleConstant.SOURCE_IDENTIFIER_TYPE_SFDC)) {
	
									if (xIdenBObj == null) {
	
										if (party1CreatedDt.before(party2CreatedDt)) {
	
											if(firstRetailerFlag!= null && firstRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_Y)){
												//Retailer Copy
												//MapKey = Retailer Flag + Admin System System type + Retailer ID
												mapKey = firstRetailerFlag + firstPartyAdminSysType + firstRetailerId;
																						
											}else if(firstRetailerFlag!= null && firstRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_N)){
												//Wholesale Copy											
												// MapKey = Retailer Flag + Admin System System type
												mapKey = firstRetailerFlag + firstPartyAdminSysType;
												
											}else if(firstRetailerFlag!= null && firstRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)){
												//If FS, MapKey = FS + Admin System System type
												
												mapKey = firstFS + firstPartyAdminSysType ;
											}
	
											partyAdminConteqMap.put(mapKey,
													partyAdminContequivBObj);
	
										} else {
											if(secondRetailerFlag!= null && secondRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_Y)){
												//Retailer Copy
												//MapKey = Retailer Flag + Admin System System type + Retailer ID
												mapKey = secondRetailerFlag + secondPartyAdminSysType + firstRetailerId;
																						
											}else if(secondRetailerFlag!= null && secondRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_N)){
												//Wholesale Copy											
												// MapKey = Retailer Flag + Admin System System type
												mapKey = secondRetailerFlag + secondPartyAdminSysType;
												
											}else if(secondRetailerFlag!= null && secondRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)){
												//If FS, MapKey = FS + Admin System System type
												
												mapKey = secondFS + secondPartyAdminSysType ;
											}
											
											//
											partyAdminConteqMap.put(mapKey, partyAdminContequivBObjInMap);
										}
	
									} else {
										String newCont = xIdenBObj.getPartyId();
	
										if (newCont.equalsIgnoreCase(partyAdminContequivBObj.getPartyId())) {
											// both belongs to same party
											
											if(firstRetailerFlag!= null && firstRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_Y)){
												//Retailer Copy
												//MapKey = Retailer Flag + Admin System System type + Retailer ID
												mapKey = firstRetailerFlag + firstPartyAdminSysType + firstRetailerId;
																						
											}else if(firstRetailerFlag!= null && firstRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_N)){
												//Wholesale Copy											
												// MapKey = Retailer Flag + Admin System System type
												mapKey = firstRetailerFlag + firstPartyAdminSysType;
												
											}else if(firstRetailerFlag!= null && firstRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)){
												//If FS, MapKey = FS + Admin System System type
												
												mapKey = firstFS + firstPartyAdminSysType ;
											}
	
											partyAdminConteqMap.put(mapKey,
													partyAdminContequivBObj);
	
										}
									}
								} else {
									if (party1CreatedDt.after(party2CreatedDt)) {
										
										if(firstRetailerFlag!= null && firstRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_Y)){
											//Retailer Copy
											//MapKey = Retailer Flag + Admin System System type + Retailer ID
											mapKey = firstRetailerFlag + firstPartyAdminSysType + firstRetailerId;
																					
										}else if(firstRetailerFlag!= null && firstRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_N)){
											//Wholesale Copy											
											// MapKey = Retailer Flag + Admin System System type
											mapKey = firstRetailerFlag + firstPartyAdminSysType;
											
										}else if(firstRetailerFlag!= null && firstRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)){
											//If FS, MapKey = FS + Admin System System type
											
											mapKey = firstFS + firstPartyAdminSysType ;
										}
									
										partyAdminConteqMap.put(mapKey,
												partyAdminContequivBObj);
	
									} else {
										
										if(secondRetailerFlag!= null && secondRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_Y)){
											//Retailer Copy
											//MapKey = Retailer Flag + Admin System System type + Retailer ID
											mapKey = secondRetailerFlag + secondPartyAdminSysType + firstRetailerId;
																					
										}else if(secondRetailerFlag!= null && secondRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_N)){
											//Wholesale Copy											
											// MapKey = Retailer Flag + Admin System System type
											mapKey = secondRetailerFlag + secondPartyAdminSysType;
											
										}else if(secondRetailerFlag!= null && secondRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)){
											//If FS, MapKey = FS + Admin System System type
											
											mapKey = secondFS + secondPartyAdminSysType ;
										}
										
										
										partyAdminConteqMap.put(mapKey,
												partyAdminContequivBObjInMap);
									}
								}
							}
						
						}
						}
					}
				}
			
			//sortedMagicNumber(dealerRetailerMap, vecAllParty, partyIdentMap, control);
			sortedMagicNumber(vecAllParty, partyIdentMap, control);
			
			}else{
			//THAILAND | SFDC|AUTOLINE|STOUCH|TDS 
				int counter = 1;
			for (int i = 0; i < vecAllParty.size(); i++) {
				TCRMPartyBObj party = (TCRMPartyBObj) vecAllParty.get(i);

				Vector<XOrgNameBObjExt> vecTempOrgNameBOBj = new Vector<XOrgNameBObjExt>();
				vecTempOrgNameBOBj = ((XOrgBObjExt) party).getItemsTCRMOrganizationNameBObj();

				String mapKey = null;

				String firstPartyNameUsageType = null;

				String secondPartyNameUsageType = null;

				// String firstPartyNameUsageValue = null;

				// String secondPartyNameUsageValue = null;

				String firstPartySource = null;

				String secondPartySource = null;

				// --Start FS changes Loveleen------//

				String firstFS = null;

				String secondFS = null;

				// --End FS changes Loveleen -------//

				// For Org Names
				for (int j = 0; j < vecTempOrgNameBOBj.size(); j++) {

					XOrgNameBObjExt orgnameBObj = (XOrgNameBObjExt) vecTempOrgNameBOBj.get(j);

					firstPartyNameUsageType = orgnameBObj.getNameUsageType();
					if(orgnameBObj.getX_BPID()!=null){
						orgNameMap.put(firstPartyNameUsageType+orgnameBObj.getX_BPID(), orgnameBObj);
						continue;
					}

					firstPartySource = orgnameBObj.getSourceIdentifierType();
					firstFS = orgnameBObj.getXOrgNameRetailerFlag();
					// If FS, Key = Name usage type + FS
					if (orgnameBObj.getXOrgNameRetailerFlag() != null
							&& orgnameBObj.getXOrgNameRetailerFlag().equals(ExternalRuleConstant.FS_VALUE)) {

						mapKey = firstPartyNameUsageType+ ExternalRuleConstant.FS_VALUE;

					} 
					//FSChange: THA FS Delta change | 18/11/2020
					else if (orgnameBObj.getXOrgNameRetailerFlag() != null
							&& orgnameBObj.getXOrgNameRetailerFlag().equals(ExternalRuleConstant.FS_WHOLESALE)) {

						mapKey = firstPartyNameUsageType+ ExternalRuleConstant.FS_WHOLESALE;

					} 
					else {

						// Otherwise Key = Name Usage type
						mapKey = firstPartyNameUsageType;

					}

					// -- End FS Changes Loveleen-----------//
					//FSChange: THA FS Delta change | 18/11/2020
					if ((firstFS == null) || (firstFS != null && !firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE))
							|| firstFS != null && firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE)) {
						if (!orgNameMap.containsKey(mapKey)) {
							// If key doesn't exist in map
							orgNameMap.put(mapKey, orgnameBObj);
	
						} 
						else {
	
							// If key exists in map
	
							XOrgNameBObjExt nameBObjInMap = orgNameMap.get(mapKey);
	
							// secondPartyNameUsageValue =
							// nameBObjInMap.getNameUsageValue();
	
							secondPartyNameUsageType =
							 nameBObjInMap.getNameUsageType();
	
							secondPartySource = nameBObjInMap
									.getSourceIdentifierType();
	
							Timestamp person1CreatedDt = DateFormatter
									.getTimestamp(nameBObjInMap
											.getXLastModifiedSystemDate());
	
							Timestamp person2CreatedDt = DateFormatter
									.getTimestamp(orgnameBObj
											.getXLastModifiedSystemDate());
							if (firstPartyNameUsageType.equalsIgnoreCase(secondPartyNameUsageType)) {
								
								if (firstPartySource.equalsIgnoreCase(secondPartySource)) {
									//SAME SOURCE
									if (person1CreatedDt.after(person2CreatedDt)) {
	
										// -- Start FS Changes Loveleen-----------//
										//FSChange: THA FS Delta change | 18/11/2020
										if (secondFS != null && secondFS.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE) ){
											// If FS, Key = Name usage type + FS
											mapKey = secondPartyNameUsageType
													+ secondFS;
	
										} else {
											// Otherwise Key = Name Usage type
											mapKey = secondPartyNameUsageType;
	
										}
										// -- End FS Changes Loveleen-----------//
	
										orgNameMap.put(mapKey, nameBObjInMap);
	
									}
	
									else {
	
										// -- Start FS Changes Loveleen-----------//
										//FSChange: THA FS Delta change | 18/11/2020
										if (firstFS !=null && firstFS
												.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE)) {
											// If FS, Key = Name usage type + FS
											mapKey = firstPartyNameUsageType
													+ firstFS;
	
										} else {
											// Otherwise Key = Name Usage type
											mapKey = firstPartyNameUsageType;
	
										}
	
										// -- End FS Changes Loveleen-----------//
	
										orgNameMap.put(firstPartyNameUsageType,
												orgnameBObj);
	
									}
								} else {
									//DIFFERENT SOURCE
									if (firstPartySource.equalsIgnoreCase(ExternalRuleConstant.SOURCE_IDENTIFIER_TYPE_SFDC)) {
	
										// SFDC is priority source
										//FSChange: THA FS Delta change | 18/11/2020
										if (firstFS !=null && firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE)) {
											// If FS, Key = Name usage type + FS
											orgNameMap.put(firstPartyNameUsageType + firstFS, orgnameBObj);
	
										} else {
											mapKey = firstPartyNameUsageType;
											orgNameMap.put(firstPartyNameUsageType, nameBObjInMap);
										}
	
									} else {

										//FSChange: THA FS Delta change | 18/11/2020
										if (secondFS != null && secondFS.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE)) {
											// If FS, Key = Name usage type + FS
											mapKey = secondPartyNameUsageType + secondFS;
											orgNameMap.put(secondPartyNameUsageType, nameBObjInMap);

										} else {
											// Otherwise Key = Name Usage type
										
											mapKey = secondPartyNameUsageType;
											orgNameMap.put(secondPartyNameUsageType, nameBObjInMap);
										}
									} 
								}
							}
						}
					}
				}
				
				// Added  :THA FS Delta Changes : 18/11/2020
				//Find MPC WS record.
			if(!orgNameMap.isEmpty())
			{
				boolean isMPCAvailable = false;
				for (Entry<String,  XOrgNameBObjExt> e : orgNameMap.entrySet()) {
				    if (!e.getKey().contains(ExternalRuleConstant.FS_WHOLESALE) && !e.getKey().contains(ExternalRuleConstant.FS_VALUE)
				    		&& (e.getValue()).getX_BPID()==null) {
				    	isMPCAvailable = true;
				    	break;
				    }
				}
				
				HashMap<String,  XOrgNameBObjExt> tempOrgNameMap = new HashMap<String,  XOrgNameBObjExt>();
				
				tempOrgNameMap.putAll(orgNameMap);
				//If MPC record is available then remove FSWS record.
				if(isMPCAvailable){
				for (Entry<String,  XOrgNameBObjExt> e : tempOrgNameMap.entrySet()) {
					if (e.getKey().contains(ExternalRuleConstant.FS_WHOLESALE)){
						orgNameMap.remove(e.getKey());
					}
					
				}
				}
				
			}
				// For Party Address

				Vector<XAddressGroupBObjExt> vecTempPartyAddressBObj = new Vector<XAddressGroupBObjExt>();
				Vector<XAddressGroupBObjExt> vecRetailPartyAddressBObj = new Vector<XAddressGroupBObjExt>();

				vecTempPartyAddressBObj = party.getItemsTCRMPartyAddressBObj();

				String firstPartyValidityType = null;

				String secondPartyValidityType = null;

				String firstPartyAddrUsageType = null;

				String secondPartyAddrUsageType = null;

				String firstPartyAddrUsageValue = null;

				String secondPartyAddrUsageValue = null;

				boolean isCSet = false;

				boolean isBusinessSet = false;

				XOrgBObjExt orgBObjExt = (XOrgBObjExt) party;

				String sourceIdentifierType = orgBObjExt
						.getSourceIdentifierType();
				addressSurvivourshipLogicImplementationwithPriority(control,
						partyAddressMap, vecTempPartyAddressBObj,
						vecRetailPartyAddressBObj, isCSet, isBusinessSet,
						orgBObjExt.getXBatchInd(),dealerRetailerMap, orgBObjExt.getXMarketName());
				

					// For Party Identification
		
					Vector<XIdentifierBObjExt> vecTempPartyIdentificationBObj = new Vector<XIdentifierBObjExt>();
		
					vecTempPartyIdentificationBObj = party
							.getItemsTCRMPartyIdentificationBObj();
		
					String firstPartyIdentificationType = null;
		
					String secondPartyIdentificationType = null;
		
					String firstPartyIdentificationValue = null;
		
					String secondPartyIdentificationValue = null;
		
					String firstRetailerId = null;
		
					String secondRetailerId = null;
		
					mapKey = null;
		
					// -- Start FS Changes Loveleen-----------//
		
					firstFS = null;
		
					secondFS = null;
		
					// -- End FS Changes Loveleen-----------//
		
					XIdentifierBObjExt xIdenBObj = null;

					for (int j = 0; j < vecTempPartyIdentificationBObj.size(); j++) {
	
					XIdentifierBObjExt partyIdenBObj = (XIdentifierBObjExt) vecTempPartyIdentificationBObj
							.get(j);
	
					firstPartyIdentificationValue = partyIdenBObj
							.getIdentificationValue();
	
					firstPartyIdentificationType = partyIdenBObj
							.getIdentificationType();
	
					firstPartySource = party.getSourceIdentifierType();
	
					firstRetailerId = partyIdenBObj.getXRetailerId();
	
					
	
					firstFS = partyIdenBObj.getXIdentifierRetailerFlag();
	
					if(partyIdenBObj.getX_BPID()!=null){
						partyIdentMap.put(partyIdenBObj.getX_BPID()+counter, partyIdenBObj);
						counter++;
						continue;
					}
					
					//FSChange: THA Delta Changes | 18-11-2020
					if(firstPartyIdentificationType.equals(ExternalRuleConstant.ID_TYPE_BPID) ){
						partyIdentMap.put(ExternalRuleConstant.ID_TYPE_BPID+counter+j, partyIdenBObj);
						counter++;
						continue;
					}
					//  ID type not EPUCID
	
					if (!firstPartyIdentificationType.equals(ExternalRuleConstant.ID_TYPE_ORG_EPUCID)) {
	
						// If FS, Key = Identification type + FS
	
						if (firstFS != null && firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {
	
							mapKey = firstPartyIdentificationType + firstFS;
						}
						
						// Added  :THA FS Delta Changes : 18/11/2020
						else if (firstFS != null && firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE)) {
							
							mapKey = firstPartyIdentificationType + firstFS;
						}
						else if(firstFS == null && firstRetailerId == null 
						&& !firstPartyIdentificationType.equalsIgnoreCase(ExternalRuleConstant.ID_TYPE_PERSON_EPUCID)){
						
							mapKey = firstPartyIdentificationType;
							
						}else{
							//Retailer ID present
							mapKey = firstPartyIdentificationType + firstRetailerId;
						}
						
					 
						// Added  :THA FS Delta Changes : 18/11/2020
					if((firstFS == null)  || (firstFS != null && !firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE)) 
							|| (firstFS != null && firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE))){
						
						if (!partyIdentMap.containsKey(mapKey)) {
	
							partyIdentMap.put(mapKey, partyIdenBObj);
	
						} else {
	
							XIdentifierBObjExt idenBObjInMap = partyIdentMap.get(mapKey);
	
							secondPartyIdentificationValue = idenBObjInMap.getIdentificationValue();
	
							secondPartyIdentificationType = idenBObjInMap.getIdentificationType();
	
							secondPartySource = idenBObjInMap.getSourceIdentifierType();
	
							secondRetailerId = idenBObjInMap.getXRetailerId();
	
							secondFS = idenBObjInMap.getXIdentifierRetailerFlag();
	
							Timestamp party1CreatedDt = DateFormatter.getTimestamp(idenBObjInMap.getXLastModifiedSystemDate());
	
							Timestamp party2CreatedDt = DateFormatter.getTimestamp(partyIdenBObj.getXLastModifiedSystemDate());
	
							if (firstPartyIdentificationType.equalsIgnoreCase(secondPartyIdentificationType)) {
	
								if (firstPartyIdentificationType.equals(ExternalRuleConstant.ID_TYPE_UCID)) {
	
									// UCID
									// Oldest record survives
	
									if (xIdenBObj == null) {
	
										if (party1CreatedDt.before(party2CreatedDt)) {
	
											partyIdentMap.put(secondPartyIdentificationType,idenBObjInMap);
	
											xIdenBObj = idenBObjInMap;
	
										} else {
	
											partyIdentMap.put(firstPartyIdentificationType,partyIdenBObj);
	
											xIdenBObj = partyIdenBObj;
	
										}
	
									} else {
	
										String newCont = xIdenBObj.getPartyId();
	
										if (newCont.equalsIgnoreCase(partyIdenBObj.getPartyId())) {
	
											// both belongs to same party
	
											partyIdentMap.put(firstPartyIdentificationType,partyIdenBObj);
	
										}
									}
	
								} else if (firstPartyIdentificationType.equals(ExternalRuleConstant.ID_TYPE_MAGIC)) {
									// MAGIC
									// Oldest record survives
									if (xIdenBObj == null) {
	
										if (party1CreatedDt.before(party2CreatedDt)) {
	
											if (secondRetailerId == null) {
	
												mapKey = secondPartyIdentificationType;
	
											} else {
	
												mapKey = secondPartyIdentificationType + secondRetailerId;
	
											}
	
											partyIdentMap.put(mapKey, idenBObjInMap);
	
											xIdenBObj = idenBObjInMap;
	
										} else {
	
											if (firstRetailerId == null) {
	
												mapKey = firstPartyIdentificationType;
	
											} else {
	
												mapKey = firstPartyIdentificationType + firstRetailerId;
	
											}
	
											partyIdentMap.put(mapKey,partyIdenBObj);
	
											xIdenBObj = partyIdenBObj;
										}
									} else {
										String newCont = xIdenBObj.getPartyId();
	
										if (newCont.equalsIgnoreCase(partyIdenBObj.getPartyId())) {
	
											// both belong to same party
											if (firstRetailerId == null) {
	
												mapKey = firstPartyIdentificationType;
	
											} else {
	
												mapKey = firstPartyIdentificationType + firstRetailerId;
	
											}
	
											partyIdentMap.put(mapKey, partyIdenBObj);
	
										}
									}
	
								} else if (firstPartyIdentificationType.equals(ExternalRuleConstant.ID_TYPE_BPID)
										&& firstFS != null && firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)
										&& secondFS != null && secondFS.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {
	
									// BPID
	
									// Oldest BPID survives
	
									if (party1CreatedDt.before(party2CreatedDt)) {
	
										mapKey = secondPartyIdentificationType + secondFS;
	
										partyIdentMap.put(mapKey, idenBObjInMap);
	
										// xIdenBObj = idenBObjInMap;
	
									} else {
	
										mapKey = firstPartyIdentificationType + firstFS;
	
										partyIdentMap.put(mapKey, partyIdenBObj);
	
										// xIdenBObj = partyIdenBObj;
	
									}
	
								} else if (firstPartyIdentificationType
										.equals(ExternalRuleConstant.ID_TYPE_COMPASS_CUSTOMER_ID)) {

									// Compass Customer Id
									// Oldest record survives

									if (xIdenBObj == null) {

										if (party1CreatedDt.before(party2CreatedDt)) {

											partyIdentMap.put(
													secondPartyIdentificationType,
													idenBObjInMap);

											xIdenBObj = idenBObjInMap;

										} else {

											partyIdentMap.put(
													firstPartyIdentificationType,
													partyIdenBObj);

											xIdenBObj = partyIdenBObj;

										}

									} else {

										String newCont = xIdenBObj.getPartyId();

										if (newCont.equalsIgnoreCase(partyIdenBObj
												.getPartyId())) {

										// both belongs to same party

										partyIdentMap.put(
												firstPartyIdentificationType,
												partyIdenBObj);

										}
									}
								} else if (firstPartyIdentificationType.equals(ExternalRuleConstant.ID_TYPE_PERSON_EPUCID)) {
	
									// Do nothing
	
								}else {
	
									if (firstPartySource != null && secondPartySource != null) {
	
										if (firstPartySource.equalsIgnoreCase(secondPartySource)) {
											// Same Source
	
											if (party1CreatedDt.after(party2CreatedDt)) {
												
												if (secondRetailerId == null) {
	
													// If FS, Key = Identification type + FS
													// Added  :THA FS Delta Changes : 18/11/2020
													if (secondFS != null && secondFS.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE)) {
	
														mapKey = secondPartyIdentificationType + secondFS;
	
													} else {
														// Otherwise, Key =Identification type
														mapKey = secondPartyIdentificationType;
	
												}
	
												}else if(firstPartyIdentificationType.equals(ExternalRuleConstant.ID_TYPE_STOUCHID) || 
													firstPartyIdentificationType.equals(ExternalRuleConstant.ID_TYPE_TDSID)){
														//STOUCH ID | TDS ID
														mapKey = secondPartyIdentificationType + secondRetailerId;
											
												}
	
												partyIdentMap.put(mapKey, idenBObjInMap);
											}else {
	
											if (firstRetailerId == null) {
	
												// If FS, Key = Identification type + FS
												// Added  :THA FS Delta Changes : 18/11/2020
												if (firstFS != null && firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE)) {
	
													mapKey = firstPartyIdentificationType + firstFS;
	
													} else {
														// Otherwise, Key =Identification type
														mapKey = firstPartyIdentificationType;
	
													}
												}else if(firstPartyIdentificationType.equals(ExternalRuleConstant.ID_TYPE_STOUCHID) || 
													firstPartyIdentificationType.equals(ExternalRuleConstant.ID_TYPE_TDSID)){
														//STOUCH ID | TDS ID
														mapKey = firstPartyIdentificationType + firstRetailerId;
											
												} 
												partyIdentMap.put(mapKey, partyIdenBObj);
											}
	
										} else {
											// Different source
											//Priority source will survive
											if (firstPartySource.equalsIgnoreCase(ExternalRuleConstant.SOURCE_IDENTIFIER_TYPE_AUTOLINE)) {
												if (firstRetailerId == null) {
	
													// If FS, Key =Identification type + FS
													// Added  :THA FS Delta Changes : 18/11/2020
													if (firstFS != null && firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE)) {
	
													mapKey = firstPartyIdentificationType + firstFS;
	
												} else {
													// Otherwise, Key =  Identification type
	
													mapKey = firstPartyIdentificationType;
												}
	
												} else if(firstPartyIdentificationType.equals(ExternalRuleConstant.ID_TYPE_STOUCHID) || 
													firstPartyIdentificationType.equals(ExternalRuleConstant.ID_TYPE_TDSID)){
														//STOUCH ID | TDS ID
														mapKey = firstPartyIdentificationType + firstRetailerId;
											
												}
												partyIdentMap.put(mapKey,partyIdenBObj);
	
										} else if(secondPartySource.equalsIgnoreCase(ExternalRuleConstant.SOURCE_IDENTIFIER_TYPE_AUTOLINE)){
	
											if (secondRetailerId == null) {
												// If FS, Key = Identification type
												// + FS
												// Added  :THA FS Delta Changes : 18/11/2020
												if (secondFS != null && secondFS.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE)) {
	
													mapKey = secondPartyIdentificationType + secondFS;
	
												} else {
													// Otherwise, Key =  Identification type
	
													mapKey = secondPartyIdentificationType;
	
													}
												} else if(secondPartyIdentificationType.equals(ExternalRuleConstant.ID_TYPE_STOUCHID) || 
													secondPartyIdentificationType.equals(ExternalRuleConstant.ID_TYPE_TDSID)){
														//STOUCH ID | TDS ID
														mapKey = secondPartyIdentificationType + secondRetailerId;
											
													}
	
													partyIdentMap.put(mapKey, idenBObjInMap);
												}
											}
										}
									}
								}
							}
						}
					}				
				}
					
					//FSChange: THA Delta Changes | 18-11-2020
					//Find MPC WS record.
					if(!partyIdentMap.isEmpty())
					{
						
					boolean isMPCIdenAvailable = false;
					for (Entry<String, XIdentifierBObjExt> e : partyIdentMap.entrySet()) {
					    if (!e.getKey().contains(ExternalRuleConstant.FS_WHOLESALE) && !e.getKey().contains(ExternalRuleConstant.FS_VALUE)
					    		&& (e.getValue()).getX_BPID()==null
					    		&& !e.getKey().contains(ExternalRuleConstant.ID_TYPE_UCID)  &&
					    		!e.getKey().contains(ExternalRuleConstant.ID_TYPE_LINE)  &&
					    		!e.getKey().contains(ExternalRuleConstant.ID_TYPE_MAGIC)  &&
					    		!e.getKey().contains(ExternalRuleConstant.ID_TYPE_COMPASS_CUSTOMER_ID)  &&
					    		!e.getKey().contains(ExternalRuleConstant.ID_TYPE_PERSON_EPUCID)  &&
					    		!e.getKey().contains(ExternalRuleConstant.ID_TYPE_STOUCHID)  &&
					    		!e.getKey().contains(ExternalRuleConstant.ID_TYPE_TDSID)
					    		&& !e.getKey().contains(ExternalRuleConstant.ID_TYPE_BPID)) {
					    	isMPCIdenAvailable = true;
					    	break;
					    }
					}
					//If MPC record is available then remove FSWS record.
					HashMap<String, XIdentifierBObjExt> tempPartyIdentMap = new HashMap<String, XIdentifierBObjExt>();
					
					tempPartyIdentMap.putAll(partyIdentMap);
					if(isMPCIdenAvailable){
					for (Entry<String, XIdentifierBObjExt> e : tempPartyIdentMap.entrySet()) {
						if (e.getKey().contains(ExternalRuleConstant.FS_WHOLESALE)){
							partyIdentMap.remove(e.getKey());
						}
						
					}
					}
					
				}
				// For Party Contact Method
		
				Vector<XContactMethodGroupBObjExt> vecTempPartyContactMethodBObj = new Vector<XContactMethodGroupBObjExt>();
	
				vecTempPartyContactMethodBObj = party
						.getItemsTCRMPartyContactMethodBObj();
	
				String firstPartyValidityContType = null;
	
				String secondPartyValidityContType = null;
	
				String firstPartyContMethodUsageType = null;
	
				String secondPartyContMethodUsageType = null;
	
				String firstPartyContMethodUsageValue = null;
	
				String secondPartyContMethodUsageValue = null;
	
				String firstPrefInd = null;
	
				String secondPrefInd = null;
	
				// --Start FS changes Loveleen------//
				firstFS = null;
	
				secondFS = null;
				
				String refNum1=null;
				
				String refNum2=null;
				
				// --End FS changes Loveleen------//

			for (int j = 0; j < vecTempPartyContactMethodBObj.size(); j++) {

				XContactMethodGroupBObjExt partyContMethBObj = (XContactMethodGroupBObjExt) vecTempPartyContactMethodBObj.get(j);

				firstPartySource = partyContMethBObj.getSourceIdentifierType();

				firstPartyContMethodUsageType = partyContMethBObj.getContactMethodUsageType();

				firstFS = partyContMethBObj.getXContactRetailerFlag();

				refNum1=(partyContMethBObj.getTCRMContactMethodBObj()).getReferenceNumber();
				
				//BPID survive
				if(partyContMethBObj.getX_BPID()!=null){
					partyContMethMap.put(firstPartyContMethodUsageType+partyContMethBObj.getX_BPID(), partyContMethBObj);
					continue;
				}
				
				// If FS, Key = Contact Method Usage Type + FS
				if (firstFS != null
						&& firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {

					mapKey = firstPartyContMethodUsageType + firstFS;

				}
				
				// Added  :THA FS Delta Changes : 11/13/2020
				else if (partyContMethBObj.getXContactRetailerFlag() != null
						&& partyContMethBObj.getXContactRetailerFlag().equals(ExternalRuleConstant.FS_WHOLESALE)) {

					mapKey = firstPartyContMethodUsageType+ExternalRuleConstant.FS_WHOLESALE;

				}
				// Otherwise, Key = Contact Method Usage Type
				else {

					mapKey = firstPartyContMethodUsageType;
				}

				// FSWS objects do not participate in Merge
				if ((firstFS == null) || (firstFS != null && !firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE))
						|| firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE)) {

					if (!partyContMethMap.containsKey(mapKey)) {
						
						if(!refNum1.equalsIgnoreCase(ExternalRuleConstant.VALUE_DELETED)){
						partyContMethMap.put(mapKey, partyContMethBObj);
						}

					} else {

						XContactMethodGroupBObjExt contMethodBObjInMap = partyContMethMap
								.get(mapKey);

						secondPartySource = contMethodBObjInMap
								.getSourceIdentifierType();

						secondPartyContMethodUsageType = contMethodBObjInMap
								.getContactMethodUsageType();

						secondFS = contMethodBObjInMap
								.getXContactRetailerFlag();
						refNum1=(contMethodBObjInMap.getTCRMContactMethodBObj()).getReferenceNumber();
						refNum2=(partyContMethBObj.getTCRMContactMethodBObj()).getReferenceNumber();

						if (contMethodBObjInMap
								.getPreferredContactMethodIndicator() != null)

							secondPrefInd = contMethodBObjInMap
									.getPreferredContactMethodIndicator();

						if (firstPartyContMethodUsageType
								.equalsIgnoreCase(secondPartyContMethodUsageType)) {

							Timestamp party1CreatedDt = DateFormatter
									.getTimestamp(contMethodBObjInMap
											.getXLastModifiedSystemDate());

							Timestamp party2CreatedDt = DateFormatter
									.getTimestamp(partyContMethBObj
											.getXLastModifiedSystemDate());
							
							if (firstPartySource
									.equalsIgnoreCase(secondPartySource)) {
								// Same source
								if(!refNum1.equalsIgnoreCase(ExternalRuleConstant.VALUE_DELETED) 
										&& !refNum2.equalsIgnoreCase(ExternalRuleConstant.VALUE_DELETED)){
								if (party1CreatedDt.after(party2CreatedDt)) {

									// If FS, Key = Contact Method Usage Type +
									// FS
									if (secondFS != null
											&& secondFS
													.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE)) {

										mapKey = secondPartyContMethodUsageType
												+ secondFS;

									}
									// Otherwise, Key = Contact Method Usage
									// Type
									else {

										mapKey = secondPartyContMethodUsageType;

									}

									partyContMethMap.put(mapKey,
											contMethodBObjInMap);
								}

								else if (party1CreatedDt
										.before(party2CreatedDt)) {

									// If FS, Key = Contact Method Usage Type +
									// FS
									if (firstFS != null
											&& firstFS
													.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE)) {

										mapKey = firstPartyContMethodUsageType
												+ firstFS;

									}
									// Otherwise, Key = Contact Method Usage
									// Type
									else {

										mapKey = firstPartyContMethodUsageType;

									}

									partyContMethMap.put(mapKey,
											partyContMethBObj);

								} else if (party1CreatedDt
										.equals(party2CreatedDt)) {

									// If FS, Key = Contact Method Usage Type +
									// FS
									if (firstFS != null
											&& firstFS
													.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE)) {

										mapKey = firstPartyContMethodUsageType
												+ firstFS;

									}
									// Otherwise, Key = Contact Method Usage
									// Type
									else {

										mapKey = firstPartyContMethodUsageType;

									}

									partyContMethMap.put(mapKey,
											partyContMethBObj);

								}
							}
								else if(!refNum1.equalsIgnoreCase(ExternalRuleConstant.VALUE_DELETED) 
										&& refNum2.equalsIgnoreCase(ExternalRuleConstant.VALUE_DELETED)){
									// If FS, Key = Contact Method Usage Type +
									// FS
									if (secondFS != null
											&& secondFS
													.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {

										mapKey = secondPartyContMethodUsageType
												+ secondFS;

									}
									// Otherwise, Key = Contact Method Usage
									// Type
									else {

										mapKey = secondPartyContMethodUsageType;

									}

									partyContMethMap.put(mapKey,
											contMethodBObjInMap);
								}else if(refNum1.equalsIgnoreCase(ExternalRuleConstant.VALUE_DELETED) 
										&& !refNum2.equalsIgnoreCase(ExternalRuleConstant.VALUE_DELETED)){
									// If FS, Key = Contact Method Usage Type +
									// FS
									if (firstFS != null
											&& firstFS
													.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {

										mapKey = firstPartyContMethodUsageType
												+ firstFS;

									}
									// Otherwise, Key = Contact Method Usage
									// Type
									else {

										mapKey = firstPartyContMethodUsageType;

									}

									partyContMethMap.put(mapKey,
											partyContMethBObj);
								}
							} else {
								// Different source
								if (firstPartySource
										.equalsIgnoreCase(ExternalRuleConstant.SOURCE_IDENTIFIER_TYPE_AUTOLINE)) {
									// If FS, Key = Contact Method Usage Type +
									// FS
									if (firstFS != null
											&& firstFS
													.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {

										mapKey = firstPartyContMethodUsageType
												+ firstFS;

									}
									// Otherwise, Key = Contact Method Usage
									// Type
									else {

										mapKey = firstPartyContMethodUsageType;

									}

									partyContMethMap.put(mapKey,
											partyContMethBObj);
								} else {
									// If FS, Key = Contact Method Usage Type +
									// FS
									if (secondFS != null
											&& secondFS
													.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {

										mapKey = secondPartyContMethodUsageType
												+ secondFS;

									}
									// Otherwise, Key = Contact Method Usage
									// Type
									else {

										mapKey = secondPartyContMethodUsageType;

									}
									if(!(partyContMethBObj.getTCRMContactMethodBObj()).getReferenceNumber().equalsIgnoreCase(ExternalRuleConstant.VALUE_DELETED))
									{
									partyContMethMap.put(mapKey,
											partyContMethBObj);
									}
								}
							}
						}
					}
				}
				
			
			}
			
			// Added  :THA FS Delta Changes : 11/13/2020
			//Find MPC WS record.
			boolean isContactMPCAvailable = false;
			for (Entry<String, XContactMethodGroupBObjExt> e : partyContMethMap.entrySet()) {
			    if (!e.getKey().contains(ExternalRuleConstant.FS_WHOLESALE) && !e.getKey().contains(ExternalRuleConstant.FS_VALUE)
			    		&& (e.getValue()).getX_BPID()==null) {
			    	isContactMPCAvailable = true;
			    	break;
			    }
			}
			//If MPC record is available then remove FSWS record.
			HashMap<String, XContactMethodGroupBObjExt> tempContactMap = new HashMap<String, XContactMethodGroupBObjExt>();
			
			tempContactMap.putAll(partyContMethMap);
			if(isContactMPCAvailable){
				for (Entry<String, XContactMethodGroupBObjExt> e : tempContactMap.entrySet()) {
					if (e.getKey().contains(ExternalRuleConstant.FS_WHOLESALE)){
						partyContMethMap.remove(e.getKey());
					}
					
				}
			}

			

			Vector<XContEquivBObjExt> vecTempAdminContequivBObj = null;

			vecTempAdminContequivBObj = party.getItemsTCRMAdminContEquivBObj();

			String firstPartyAdminSysType = null;

			String secondPartyAdminSysType = null;

			String firstPartyAdminSysValue = null;

			String secondPartyAdminSysValue = null;

			String firstRetailerFlag = null;

			String secondRetailerFlag = null;

			XContEquivBObjExt newadminContEquivBObj = null;

			firstRetailerId = null;

			secondRetailerId = null;

			firstFS = null;

			secondFS = null;

			for (int j = 0; j < vecTempAdminContequivBObj.size(); j++) {

				XContEquivBObjExt partyAdminContequivBObj = (XContEquivBObjExt) vecTempAdminContequivBObj
						.get(j);

				firstPartyAdminSysValue = partyAdminContequivBObj
						.getAdminSystemValue();

				firstPartyAdminSysType = partyAdminContequivBObj
						.getAdminSystemType();

				firstRetailerId = partyAdminContequivBObj.getXRetailerId();

				firstRetailerFlag = partyAdminContequivBObj
						.getXSourceRetailerFlag();

				firstFS = partyAdminContequivBObj.getXSourceRetailerFlag();

				if (ExternalRuleConstant.CHARACTER_N
						.equalsIgnoreCase(firstRetailerFlag)) {

					// If FS, MapKey = Retailer Flag + Admin System System type
					// + FS

					if (firstFS != null
							&& firstFS
									.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {

						mapKey = firstRetailerFlag + firstPartyAdminSysType
								+ firstFS;

					}
					//FSChange: THA Delta Changes | 18/11/2020
					else if (firstFS != null
							&& firstFS
									.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE)) {

						mapKey = firstRetailerFlag + firstPartyAdminSysType
								+ firstFS;

					}
					// Otherwise, MapKey = Retailer Flag + Admin System System
					// type
					else {

						mapKey = firstRetailerFlag + firstPartyAdminSysType;

					}
				} else {

					// If FS, MapKey = Retailer Flag + Admin System System type
					// + RetailerId + FS

					if (firstFS != null
							&& firstFS
									.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {

						mapKey = firstRetailerFlag + firstPartyAdminSysType
								+ firstRetailerId + firstFS;

					}
					//FSChange: THA Delta Changes | 18/11/2020
					else if (firstFS != null
							&& firstFS
									.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE)) {

						mapKey = firstRetailerFlag + firstPartyAdminSysType
								+  firstFS;

					}
					
					// Otherwise, MapKey = Retailer Flag + Admin System System
					// type
					else {

						mapKey = firstRetailerFlag + firstPartyAdminSysType
								+ firstRetailerId;

					}

				}

				// FSWS objects do not participate in Merge
				//FSChange: THA Delta Changes | 18/11/2020
				if ((firstFS == null
						|| !firstFS
								.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE))
								|| (firstFS == null
										|| firstFS
										.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE))) {
					if (!partyAdminConteqMap.containsKey(mapKey)) {

						partyAdminConteqMap
								.put(mapKey, partyAdminContequivBObj);

					} else {

						XContEquivBObjExt partyAdminContequivBObjInMap = (XContEquivBObjExt) partyAdminConteqMap
								.get(mapKey);

						secondPartyAdminSysValue = partyAdminContequivBObjInMap
								.getAdminSystemValue();

						secondPartyAdminSysType = partyAdminContequivBObjInMap
								.getAdminSystemType();

						secondRetailerId = partyAdminContequivBObjInMap
								.getXRetailerId();

						secondRetailerFlag = partyAdminContequivBObjInMap
								.getXSourceRetailerFlag();
						secondFS = partyAdminContequivBObjInMap
								.getXSourceRetailerFlag();

						Timestamp party1CreatedDt = DateFormatter
								.getTimestamp(partyAdminContequivBObj
										.getContEquivLastUpdateDate());

						Timestamp party2CreatedDt = DateFormatter
								.getTimestamp(partyAdminContequivBObjInMap
										.getContEquivLastUpdateDate());

						if (firstPartyAdminSysType
								.equalsIgnoreCase(secondPartyAdminSysType)) {

							if (firstPartyAdminSysType
									.equalsIgnoreCase(ExternalRuleConstant.SOURCE_IDENTIFIER_TYPE_SFDC)) {

								if (xIdenBObj == null) {

									if (party1CreatedDt.before(party2CreatedDt)) {

										if (firstRetailerFlag
												.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_Y)) {
											// Retailer Copy
											// If FS, MapKey = Retailer Flag +
											// Admin System System type +
											// Retailer ID + FS

											if (firstFS != null
													&& firstFS
															.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {

												mapKey = firstRetailerFlag
														+ firstPartyAdminSysType
														+ firstRetailerId
														+ firstFS;

											}
											//FSChange: THA Delta Changes | 18/11/2020
											else if (firstFS != null
													&& firstFS
													.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE)) {

										mapKey = firstRetailerFlag
												+ firstPartyAdminSysType
												+ firstFS;

											}
											// Otherwise, MapKey = Retailer Flag
											// + Admin System System type +
											// Retailer ID
											else {

												mapKey = firstRetailerFlag
														+ firstPartyAdminSysType
														+ firstRetailerId;

											}
										} else {
											// Wholesale Copy
											// If FS, MapKey = Retailer Flag +
											// Admin System System type + FS

											if (firstFS != null
													&& firstFS
															.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {

												mapKey = firstRetailerFlag
														+ firstPartyAdminSysType
														+ firstFS;

											}
											//FSChange: THA Delta Changes | 18/11/2020
											else if (firstFS != null
													&& firstFS
															.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE)) {

												mapKey = firstRetailerFlag
														+ firstPartyAdminSysType
														+ firstFS;

											}
											// Otherwise, MapKey = Retailer Flag
											// + Admin System System type
											else {

												mapKey = firstRetailerFlag
														+ firstPartyAdminSysType;

											}
										}

										partyAdminConteqMap.put(mapKey,
												partyAdminContequivBObj);

									} else {

										if (secondRetailerFlag
												.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_Y)) {
											// Retailer Copy

											// If FS, MapKey = Retailer Flag +
											// Admin System System type +
											// RetailerId + FS

											if (secondFS != null
													&& secondFS
															.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {

												mapKey = secondRetailerFlag
														+ secondPartyAdminSysType
														+ secondRetailerId
														+ secondFS;

											}
											//FSChange: THA Delta Changes | 18/11/2020
											else if (secondFS != null
													&& secondFS
															.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE)) {

												mapKey = secondRetailerFlag
														+ secondPartyAdminSysType
														+ secondFS;

											}
											// Otherwise, MapKey = Retailer Flag
											// + Admin System System type
											else {

												mapKey = secondRetailerFlag
														+ secondPartyAdminSysType
														+ secondRetailerId;

											}

										} else {
											// Wholesale Copy

											// If FS, MapKey = Retailer Flag +
											// Admin System System type + FS

											if (secondFS != null
													&& secondFS
															.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {

												mapKey = secondRetailerFlag
														+ secondPartyAdminSysType
														+ secondFS;

											}
											//FSChange: THA Delta Changes | 18/11/2020
											else if (secondFS != null
													&& secondFS
															.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE)) {

												mapKey = secondRetailerFlag
														+ secondPartyAdminSysType
														+ secondFS;

											}
											// Otherwise, MapKey = Retailer Flag
											// + Admin System System type
											else {

												mapKey = secondRetailerFlag
														+ secondPartyAdminSysType;

											}

										}

										partyAdminConteqMap.put(mapKey,
												partyAdminContequivBObjInMap);
									}

								} else {
									String newCont = xIdenBObj.getPartyId();

									if (newCont
											.equalsIgnoreCase(partyAdminContequivBObj
													.getPartyId())) {
										// both belongs to same party

										if (firstRetailerFlag
												.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_Y)) {
											// Retailer Copy

											// If FS, MapKey = Retailer Flag +
											// Admin System System type +
											// RetailerId + FS

											if (firstFS != null
													&& firstFS
															.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {

												mapKey = firstRetailerFlag
														+ firstPartyAdminSysType
														+ firstRetailerId
														+ firstFS;

											}
											//FSChange: THA Delta Changes | 18/11/2020
											else if (firstFS != null
													&& firstFS
													.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE)) {

										mapKey = firstRetailerFlag
												+ firstPartyAdminSysType
												+ firstFS;

									}
											// Otherwise, MapKey = Retailer Flag
											// + Admin System System type
											else {

												mapKey = firstRetailerFlag
														+ firstPartyAdminSysType
														+ firstRetailerId;

											}
										} else {
											// Wholesale Copy

											// If FS, MapKey = Retailer Flag +
											// Admin System System type + FS

											if (firstFS != null
													&& firstFS
															.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {

												mapKey = firstRetailerFlag
														+ firstPartyAdminSysType
														+ firstFS;

											}
											//FSChange: THA Delta Changes | 18/11/2020
											else if (firstFS != null
													&& firstFS
													.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE)) {

												mapKey = firstRetailerFlag
														+ firstPartyAdminSysType
														+ firstFS;

											}
											// Otherwise, MapKey = Retailer Flag
											// + Admin System System type
											else {

												mapKey = firstRetailerFlag
														+ firstPartyAdminSysType;

											}

										}

										partyAdminConteqMap.put(mapKey,
												partyAdminContequivBObj);

									}
								}
							} else {
								if (party1CreatedDt.after(party2CreatedDt)) {

									if (firstRetailerFlag
											.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_Y)) {
										// Retailer copy

										// If FS, MapKey = Retailer Flag + Admin
										// System System type + RetailerId + FS

										if (firstFS != null
												&& firstFS
														.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {

											mapKey = firstRetailerFlag
													+ firstPartyAdminSysType
													+ firstRetailerId + firstFS;

										}
										//FSChange: THA Delta Changes | 18/11/2020
										else if (firstFS != null
												&& firstFS
												.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE)) {

											mapKey = firstRetailerFlag
													+ firstPartyAdminSysType
													+  firstFS;

										}
										// Otherwise, MapKey = Retailer Flag +
										// Admin System System type
										else {

											mapKey = firstRetailerFlag
													+ firstPartyAdminSysType
													+ firstRetailerId;

										}
									} else {
										// Wholesale

										// If FS, MapKey = Retailer Flag + Admin
										// System System type + FS

										if (firstFS != null
												&& firstFS
														.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {

											mapKey = firstRetailerFlag
													+ firstPartyAdminSysType
													+ firstFS;

										}
										//FSChange: THA Delta Changes | 18/11/2020
										else if (firstFS != null
												&& firstFS
												.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE)) {

											mapKey = firstRetailerFlag
													+ firstPartyAdminSysType
													+ firstFS;

										}
										// Otherwise, MapKey = Retailer Flag +
										// Admin System System type
										else {

											mapKey = firstRetailerFlag
													+ firstPartyAdminSysType;

										}

									}

									partyAdminConteqMap.put(mapKey,
											partyAdminContequivBObj);

								} else {

									if (secondRetailerFlag
											.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_Y)) {
										// Retailer
										// If FS, MapKey = Retailer Flag + Admin
										// System System type + RetailerId + FS

										if (secondFS != null
												&& secondFS
														.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {

											mapKey = secondRetailerFlag
													+ secondPartyAdminSysType
													+ secondRetailerId
													+ secondFS;

										}
										//FSChange: THA Delta Changes | 18/11/2020
										if (secondFS != null
												&& secondFS
														.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE)) {

											mapKey = secondRetailerFlag
													+ secondPartyAdminSysType
													+ secondFS;

										}
										// Otherwise, MapKey = Retailer Flag +
										// Admin System System type
										else {

											mapKey = secondRetailerFlag
													+ secondPartyAdminSysType
													+ secondRetailerId;

										}
									} else {
										// Wholesale

										// If FS, MapKey = Retailer Flag + Admin
										// System System type + FS

										if (secondFS != null
												&& secondFS
														.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {

											mapKey = secondRetailerFlag
													+ secondPartyAdminSysType
													+ secondFS;

										}
										//FSChange: THA Delta Changes | 18/11/2020
										if (secondFS != null
												&& secondFS
														.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE)) {

											mapKey = secondRetailerFlag
													+ secondPartyAdminSysType
													+ secondFS;

										}
										// Otherwise, MapKey = Retailer Flag +
										// Admin System System type
										else {

											mapKey = secondRetailerFlag
													+ secondPartyAdminSysType;

										}

									}

									partyAdminConteqMap.put(mapKey,
											partyAdminContequivBObjInMap);
								}
							}
						}
					}
				}
			}
			
			// Added  :THA FS Delta Changes : 11/13/2020
			//Find MPC WS record.
			if(!partyAdminConteqMap.isEmpty())
			{
			boolean isMPCContEquivAvailable = false;
			for (Entry<String, TCRMAdminContEquivBObj> e : partyAdminConteqMap.entrySet()) {
			    if (!e.getKey().contains(ExternalRuleConstant.FS_WHOLESALE) && !e.getKey().contains(ExternalRuleConstant.FS_VALUE)
			    		&& !e.getKey().contains(ExternalRuleConstant.CHARACTER_Y)) {
			    	isMPCContEquivAvailable = true;
			    	break;
			    }
			}
			HashMap<String, TCRMAdminContEquivBObj> tempPartyAdminConteqMap = new HashMap<String, TCRMAdminContEquivBObj>();
			tempPartyAdminConteqMap.putAll(partyAdminConteqMap);
			//If MPC record is available then remove FSWS record.
			if(isMPCContEquivAvailable){
			for (Entry<String, TCRMAdminContEquivBObj> e : tempPartyAdminConteqMap.entrySet()) {
				if (e.getKey().contains(ExternalRuleConstant.FS_WHOLESALE)){
					partyAdminConteqMap.remove(e.getKey());
				}
				
			}
			}
}
		}
		}
	}

	// @SuppressWarnings("unchecked")
	
	/**
	 * @param control
	 * @param partyAddressMap
	 * @param vecTempPartyAddressBObj
	 * @param vecRetailPartyAddressBObj
	 * @param isCSet
	 * @param isBusinessSet
	 * @param string
	 * @throws Exception
	 */
	private void addressSurvivourshipLogicImplementation(DWLControl control,
			HashMap<String, XAddressGroupBObjExt> partyAddressMap,
			Vector<XAddressGroupBObjExt> vecTempPartyAddressBObj,
			Vector<XAddressGroupBObjExt> vecRetailPartyAddressBObj,
			boolean isCSet, boolean isBusinessSet, String string,
			HashMap<String, String> dealerRetailerMap) throws Exception {
		if (string.equalsIgnoreCase(ExternalRuleConstant.BATCH_IND_N)) {

			String firstPartyAddrUsageType;
			String firstPartyAddrUsageValue;
			String secondPartyAddrUsageType;
			String secondPartyAddrUsageValue;
			
			for (int j = 0; j < vecTempPartyAddressBObj.size(); j++) {
				// Extract Retail Addresses
				XAddressGroupBObjExt partyAddrBObj = (XAddressGroupBObjExt) vecTempPartyAddressBObj.get(j);
				vecRetailPartyAddressBObj.add(partyAddrBObj);
			}

			String mapKey = null;

			String firstRetailerId = null;
			
			String addrRetailerFlag = null;
			
			String firstFS = null;
			
			String secondFS = null;

			Vector<XAddressGroupBObjExt> rtPartyAddressBObjs = new Vector<XAddressGroupBObjExt>();

			Vector<XAddressGroupBObjExt> wsPartyAddressBObjs = new Vector<XAddressGroupBObjExt>();

			// Sort Party Addresses by Last Modified Date
			// sortPartyAddresses(vecRetailPartyAddressBObj, null, control);
			for (int j = 0; j < vecRetailPartyAddressBObj.size(); j++) {
				
				XAddressGroupBObjExt partyAddrBObj = (XAddressGroupBObjExt) vecTempPartyAddressBObj.get(j);

				firstPartyAddrUsageValue = partyAddrBObj.getAddressUsageValue();

				firstPartyAddrUsageType = partyAddrBObj.getAddressUsageType();

				firstRetailerId = partyAddrBObj.getXRetailerId();

				addrRetailerFlag = partyAddrBObj.getXAddressRetailerFlag();
				
				firstFS = partyAddrBObj.getXAddressRetailerFlag();

				if (addrRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_N)) {

					mapKey = firstPartyAddrUsageValue;

				}else if (firstFS != null && firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {

					mapKey = firstPartyAddrUsageValue + firstFS;

				}

				XAddressGroupBObjExt wsPartyAddressBObj = new XAddressGroupBObjExt();
				
				if(((firstFS == null)  || (firstFS != null && !firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE) && !firstFS.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_Y))) ){
					
					if (!partyAddressMap.containsKey(mapKey)) {
						
						partyAddressMap.put(mapKey, partyAddrBObj);
						
					} 
					else if(!firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE)){

						XAddressGroupBObjExt partyAddrBObjInMap = partyAddressMap.get(mapKey);

						secondPartyAddrUsageType = partyAddrBObjInMap.getAddressUsageType();

						secondPartyAddrUsageValue = partyAddrBObjInMap.getAddressUsageValue();

						String secondAddressRetailerFlag = partyAddrBObjInMap.getXAddressRetailerFlag();

						Timestamp party1CreatedDt = DateFormatter.getTimestamp(partyAddrBObjInMap.getXLastModifiedSystemDate());

						Timestamp party2CreatedDt = DateFormatter.getTimestamp(partyAddrBObj.getXLastModifiedSystemDate());
			
						//Wholesale
						if (firstPartyAddrUsageType.equalsIgnoreCase(secondPartyAddrUsageType)) {

								if (party1CreatedDt.after(party2CreatedDt)) {
									
									if (addrRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_N)) {

										mapKey = secondPartyAddrUsageValue;

									}else if (secondFS != null && secondFS.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {

										mapKey = secondPartyAddrUsageValue + secondFS;

									}

									partyAddressMap.put(mapKey, partyAddrBObjInMap);
								}

								else {
									
									if (addrRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_N)) {

										mapKey = firstPartyAddrUsageValue;

									}else if (firstFS != null && firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {

										mapKey = firstPartyAddrUsageValue + firstFS;

									}

									partyAddressMap.put(mapKey, partyAddrBObj);
								}
							
						}
					}
				}
			}

				vecTempPartyAddressBObj.removeAllElements();

				Set<String> keys = partyAddressMap.keySet();

				for (String key : keys) {

					XAddressGroupBObjExt partyAddrBObjs = partyAddressMap.get(key);

					addrRetailerFlag = partyAddrBObjs.getXAddressRetailerFlag();

					if (addrRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_Y)) {

						rtPartyAddressBObjs.add(partyAddrBObjs);

					} else if (addrRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_N)) {

						wsPartyAddressBObjs.add(partyAddrBObjs);

					}

				}

				for (XAddressGroupBObjExt rtAddressGroupBObj : rtPartyAddressBObjs) {

					for (XAddressGroupBObjExt wsAddressGroupBObj : wsPartyAddressBObjs) {

						String rtContId = rtAddressGroupBObj.getPartyId();

						String wsContId = wsAddressGroupBObj.getPartyId();

						if (wsContId.equalsIgnoreCase(rtContId)) {

							rtAddressGroupBObj.setAddressUsageType(ExternalRuleConstant.ADDRESS_USAGE_TYPE_BUSINESS_ADDRESS);

							rtAddressGroupBObj.setAddressUsageValue(ExternalRuleConstant.ADDRESS_USAGE_VALUE_BUSINESS_ADDRESS);

						} else {

							rtAddressGroupBObj.setAddressUsageType(ExternalRuleConstant.ADDRESS_USAGE_TYPE_C);

							rtAddressGroupBObj.setAddressUsageValue(ExternalRuleConstant.ADDRESS_USAGE_VALUE_C);

						}

					}
				
			}

		} else if (string.equalsIgnoreCase(ExternalRuleConstant.BATCH_IND_Y)) {

			String firstPartyAddrUsageType;
			String firstPartyAddrUsageValue;
			for (int j = 0; j < vecTempPartyAddressBObj.size(); j++) {
				// Extract Retail Addresses
				XAddressGroupBObjExt partyAddrBObj = (XAddressGroupBObjExt) vecTempPartyAddressBObj
						.get(j);
				vecRetailPartyAddressBObj.add(partyAddrBObj);
			}

			String mapKey = null;
	
			String retailerId = null;
	
			String addrRetailerFlag = null;
	
			Vector<XAddressGroupBObjExt> rtPartyAddressBObjs = new Vector<XAddressGroupBObjExt>();
	
			Vector<XAddressGroupBObjExt> wsPartyAddressBObjs = new Vector<XAddressGroupBObjExt>();
	
			// Sort Party Addresses by Last Modified Date
			// sortPartyAddresses(vecRetailPartyAddressBObj, null, control);
			for (int j = 0; j < vecRetailPartyAddressBObj.size(); j++) {
				XAddressGroupBObjExt partyAddrBObj = (XAddressGroupBObjExt) vecTempPartyAddressBObj
						.get(j);
	
				firstPartyAddrUsageValue = partyAddrBObj.getAddressUsageValue();
	
				firstPartyAddrUsageType = partyAddrBObj.getAddressUsageType();
	
				retailerId = partyAddrBObj.getXRetailerId();
	
				addrRetailerFlag = partyAddrBObj.getXAddressRetailerFlag();
	
				if (addrRetailerFlag
						.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_Y)) {
	
					mapKey = firstPartyAddrUsageValue + retailerId;
	
				} else if (addrRetailerFlag
						.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_N)) {
	
					mapKey = firstPartyAddrUsageValue;
	
				}
	
				XAddressGroupBObjExt wsPartyAddressBObj = new XAddressGroupBObjExt();
	
				if (!partyAddressMap.containsKey(mapKey)) {
					partyAddressMap.put(mapKey, partyAddrBObj);
				}
			}

		vecTempPartyAddressBObj.removeAllElements();

		Set<String> keys = partyAddressMap.keySet();

		for (String key : keys) {

			XAddressGroupBObjExt partyAddrBObj = partyAddressMap.get(key);

			addrRetailerFlag = partyAddrBObj.getXAddressRetailerFlag();

			if (addrRetailerFlag
					.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_Y)) {

				rtPartyAddressBObjs.add(partyAddrBObj);

			} else if (addrRetailerFlag
					.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_N)) {

				wsPartyAddressBObjs.add(partyAddrBObj);

			}

		}

		for (XAddressGroupBObjExt rtAddressGroupBObj : rtPartyAddressBObjs) {

			for (XAddressGroupBObjExt wsAddressGroupBObj : wsPartyAddressBObjs) {

				String rtContId = rtAddressGroupBObj.getPartyId();

				String wsContId = wsAddressGroupBObj.getPartyId();

				if (wsContId.equalsIgnoreCase(rtContId)) {

					rtAddressGroupBObj
							.setAddressUsageType(ExternalRuleConstant.ADDRESS_USAGE_TYPE_BUSINESS_ADDRESS);

					rtAddressGroupBObj
							.setAddressUsageValue(ExternalRuleConstant.ADDRESS_USAGE_VALUE_BUSINESS_ADDRESS);

				} else {

					rtAddressGroupBObj
							.setAddressUsageType(ExternalRuleConstant.ADDRESS_USAGE_TYPE_C);

					rtAddressGroupBObj
							.setAddressUsageValue(ExternalRuleConstant.ADDRESS_USAGE_VALUE_C);

				}

			}
			}
		}
	}

	/**
	 * @param control
	 * @param partyAddressMap
	 * @param vecTempPartyAddressBObj
	 * @param vecRetailPartyAddressBObj
	 * @param isCSet
	 * @param isBusinessSet
	 * @param string
	 * @throws Exception
	 */
	private void addressSurvivourshipLogicImplementationwithPriority(
			DWLControl control,
			HashMap<String, XAddressGroupBObjExt> partyAddressMap,
			Vector<XAddressGroupBObjExt> vecTempPartyAddressBObj,
			Vector<XAddressGroupBObjExt> vecRetailPartyAddressBObj,
			boolean isCSet, boolean isBusinessSet, String batch,HashMap<String, String> dealerRetailerMap, String marketName)
			throws Exception {
	//change for dealer-retailer address
	if((marketName.equals(ExternalRuleConstant.MARKET_NAME_MALAYSIA)) &&(batch.equals(ExternalRuleConstant.BATCH_IND_N))){
		
		String firstPartyAddrUsageType;
		
		dealerRetailerMap = getAllRetailersByDealerForMagic(dealerRetailerMap);

		String firstPartyAddrUsageValue;

		String firstPartySource = null;

		String secondPartyAddrUsageType;

		String secondPartyAddrUsageValue;

		String secondPartySource = null;

		String secondRetailerId = null;

		String firstPartyAddrRetailerFlag = null;

		String secondAddressRetailerFlag = null;

		String mapKey = null;

		String firstRetailer = null;
		
		//String firstDealer = null;

		String firstFS = null;

		String secondFS = null;
		
		//String secondDealer = null;
		
		for (int j = 0; j < vecTempPartyAddressBObj.size(); j++) {

			// Extract Retail Addresses

			XAddressGroupBObjExt partyAddrBObj = (XAddressGroupBObjExt) vecTempPartyAddressBObj.get(j);

			vecRetailPartyAddressBObj.add(partyAddrBObj);

		}

		// Sort Party Addresses by Last Modified Date
		// sortPartyAddresses(vecRetailPartyAddressBObj, null, control);
		for (int j = 0; j < vecRetailPartyAddressBObj.size(); j++) {

			XAddressGroupBObjExt partyAddrBObj = (XAddressGroupBObjExt) vecRetailPartyAddressBObj.get(j);

			firstPartyAddrUsageValue = partyAddrBObj.getAddressUsageValue();

			firstPartySource = partyAddrBObj.getSourceIdentifierType();

			firstPartyAddrUsageType = partyAddrBObj.getAddressUsageType();

			firstRetailer = partyAddrBObj.getXRetailerId();
			
			//firstDealer = dealerRetailerMap.get(firstRetailer);

			firstPartyAddrRetailerFlag = partyAddrBObj.getXAddressRetailerFlag();

			firstFS = partyAddrBObj.getXAddressRetailerFlag();

			if (firstPartyAddrRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_N)) {

					// Otherwise, Key = Retailer Flag + Address Usage Type
				mapKey = firstPartyAddrRetailerFlag	+ firstPartyAddrUsageType;
								
			} else if (firstFS != null && firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {

				mapKey = firstPartyAddrUsageType + firstFS;

			}

			if(((firstFS == null)  || (firstFS != null && !firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE) && !firstFS.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_Y))) ){
				
				if (!partyAddressMap.containsKey(mapKey)) {
	
					partyAddressMap.put(mapKey, partyAddrBObj);
	
				} else {
	
					XAddressGroupBObjExt partyAddrBObjInMap = partyAddressMap.get(mapKey);
	
					secondPartyAddrUsageType = partyAddrBObjInMap.getAddressUsageType();
	
					secondPartySource = partyAddrBObjInMap.getSourceIdentifierType();
	
					secondRetailerId = partyAddrBObjInMap.getXRetailerId();
					
					//secondDealer = dealerRetailerMap.get(secondRetailerId);
	
					secondPartyAddrUsageValue = partyAddrBObjInMap.getAddressUsageValue();
	
					secondAddressRetailerFlag = partyAddrBObjInMap.getXAddressRetailerFlag();
	
					Timestamp party1CreatedDt = DateFormatter.getTimestamp(partyAddrBObjInMap.getXLastModifiedSystemDate());
	
					Timestamp party2CreatedDt = DateFormatter.getTimestamp(partyAddrBObj.getXLastModifiedSystemDate());
	
					if (firstPartyAddrUsageType.equalsIgnoreCase(secondPartyAddrUsageType)) {
						
						if (firstPartySource.equalsIgnoreCase(secondPartySource)) {

							if (party1CreatedDt.after(party2CreatedDt)) {

								 if (secondAddressRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_N)) {
									// Wholesale  Key = Retailer Flag + Address Usage Type + Retailer ID
									mapKey = secondAddressRetailerFlag + secondPartyAddrUsageType;

								} else if (secondFS != null && secondFS.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {

									mapKey = secondPartyAddrUsageType + secondFS;

								}
								partyAddressMap.put(mapKey, partyAddrBObjInMap);
							}

							else {
								if (firstPartyAddrRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_N)) {

									// Key = Retailer Flag + Address Usage Type
									mapKey = firstPartyAddrRetailerFlag + firstPartyAddrUsageType;

								} else if (firstFS != null && firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {

									mapKey = firstPartyAddrUsageType + firstFS;
								}

								partyAddressMap.put(mapKey, partyAddrBObj);
							}
						} else {
							// Different source Priority source will survive
							if (firstPartySource.equalsIgnoreCase(ExternalRuleConstant.SOURCE_IDENTIFIER_TYPE_AUTOLINE)) {

								 if (firstPartyAddrRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_N)) {

									mapKey = firstPartyAddrUsageValue;

								} else if (firstFS != null && firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {

									mapKey = firstPartyAddrRetailerFlag + firstFS;

								}
								partyAddressMap.put(mapKey, partyAddrBObj);
							} else {

								 if (firstPartyAddrUsageType.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_N)) {

									mapKey = firstPartyAddrUsageType;

								} else if (firstFS != null && firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {

									mapKey = firstPartyAddrUsageType + firstFS;

								}
								partyAddressMap.put(mapKey, partyAddrBObjInMap);
							}
						}
					}
				}
			}
		}
	}
	else{

		String firstPartyAddrUsageType;
		
		String firstPartyAddrUsageValue;

		String firstPartySource = null;

		String secondPartyAddrUsageType;

		String secondPartyAddrUsageValue;

		String secondPartySource = null;

		String secondRetailerId = null;

		String firstPartyAddrRetailerFlag = null;

		String secondAddressRetailerFlag = null;

		String mapKey = null;

		String firstRetailer = null;

		String firstFS = null;

		String secondFS = null;
		
		XAddressBObjExt xaddressBObjExtParty = new XAddressBObjExt();
		
		XAddressBObjExt xaddressBObjExtParty1 = new XAddressBObjExt();
		
		XAddressBObjExt xaddressBObjExtParty2 = new XAddressBObjExt();
		
		

		for (int j = 0; j < vecTempPartyAddressBObj.size(); j++) {

			// Extract Retail Addresses

			XAddressGroupBObjExt partyAddrBObj = (XAddressGroupBObjExt) vecTempPartyAddressBObj.get(j);

			vecRetailPartyAddressBObj.add(partyAddrBObj);

		}

		// Sort Party Addresses by Last Modified Date
		// sortPartyAddresses(vecRetailPartyAddressBObj, null, control);
		for (int j = 0; j < vecRetailPartyAddressBObj.size(); j++) {

			XAddressGroupBObjExt partyAddrBObj = (XAddressGroupBObjExt) vecTempPartyAddressBObj.get(j);

			firstPartyAddrUsageValue = partyAddrBObj.getAddressUsageValue();

			firstPartySource = partyAddrBObj.getSourceIdentifierType();

			firstPartyAddrUsageType = partyAddrBObj.getAddressUsageType();

			firstRetailer = partyAddrBObj.getXRetailerId();

			firstPartyAddrRetailerFlag = partyAddrBObj.getXAddressRetailerFlag();

			firstFS = partyAddrBObj.getXAddressRetailerFlag();
			
			if(partyAddrBObj.getX_BPID()!=null){
				partyAddressMap.put(firstPartyAddrUsageType+partyAddrBObj.getX_BPID(), partyAddrBObj);
				continue;
			}

			if (firstPartyAddrRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_N)) {

				// Wholesale
				// ---Start FS Changes Loveleen------//

				// Otherwise, Key = Retailer Flag + Address Usage Type
				mapKey = firstPartyAddrRetailerFlag + firstPartyAddrUsageType;

				// ---End FS Changes Loveleen------//
			} else if (firstPartyAddrRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_Y)) {
				// Retailer
				// ---Start FS Changes Loveleen------//

				// Key = Retailer Flag + Retailer ID
				mapKey = firstPartyAddrRetailerFlag +  firstRetailer;

			} else if (firstFS != null && firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {

				mapKey = firstPartyAddrUsageType + firstFS;

			}
			// Added  :THA FS Delta Changes : 11/13/2020
			else if (partyAddrBObj.getXAddressRetailerFlag() != null
					&& partyAddrBObj.getXAddressRetailerFlag().equals(ExternalRuleConstant.FS_WHOLESALE)) {

				// Otherwise Key = Name Usage type
				mapKey = firstPartyAddrUsageType+ExternalRuleConstant.FS_WHOLESALE;

			}
			// ---End FS Changes Loveleen------//
			
			xaddressBObjExtParty=(XAddressBObjExt) partyAddrBObj.getTCRMAddressBObj();
			// FSWS objects do not participate in Merge
			if ((firstFS == null) || (firstFS != null && !firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE))
					|| firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE)) {

				if (!partyAddressMap.containsKey(mapKey)) {
					if (!xaddressBObjExtParty.getAddressLineOne().equalsIgnoreCase(ExternalRuleConstant.VALUE_DELETED)) {
						partyAddressMap.put(mapKey, partyAddrBObj);
					}

				} else {

					XAddressGroupBObjExt partyAddrBObjInMap = partyAddressMap.get(mapKey);

					secondPartyAddrUsageType = partyAddrBObjInMap.getAddressUsageType();

					secondPartySource = partyAddrBObjInMap.getSourceIdentifierType();

					secondRetailerId = partyAddrBObjInMap.getXRetailerId();

					secondPartyAddrUsageValue = partyAddrBObjInMap.getAddressUsageValue();

					secondAddressRetailerFlag = partyAddrBObjInMap.getXAddressRetailerFlag();

					Timestamp party1CreatedDt = DateFormatter.getTimestamp(partyAddrBObjInMap.getXLastModifiedSystemDate());

					Timestamp party2CreatedDt = DateFormatter.getTimestamp(partyAddrBObj.getXLastModifiedSystemDate());
					
					xaddressBObjExtParty1=(XAddressBObjExt) partyAddrBObjInMap.getTCRMAddressBObj();
					xaddressBObjExtParty2=(XAddressBObjExt) partyAddrBObj.getTCRMAddressBObj();
					
					//Retailer 
					if(firstPartyAddrRetailerFlag.equalsIgnoreCase(secondAddressRetailerFlag) &&
							firstPartyAddrRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_Y)){
						
						if(!xaddressBObjExtParty1.getAddressLineOne().equalsIgnoreCase(ExternalRuleConstant.VALUE_DELETED) &&
								!xaddressBObjExtParty2.getAddressLineOne().equalsIgnoreCase(ExternalRuleConstant.VALUE_DELETED) )
						{	
					
							if (party1CreatedDt.after(party2CreatedDt)) {
						
									mapKey = secondAddressRetailerFlag  + secondRetailerId;
						
									partyAddressMap.put(mapKey, partyAddrBObjInMap);
						
							}else{
						
									mapKey = firstPartyAddrRetailerFlag  + firstRetailer;
						
									partyAddressMap.put(mapKey, partyAddrBObj);
						
								}
					
						}
						
						else if (!xaddressBObjExtParty1.getAddressLineOne().equalsIgnoreCase(ExternalRuleConstant.VALUE_DELETED) &&
								xaddressBObjExtParty2.getAddressLineOne().equalsIgnoreCase(ExternalRuleConstant.VALUE_DELETED)){
							
							mapKey = secondAddressRetailerFlag  + secondRetailerId;
							partyAddressMap.put(mapKey, partyAddrBObjInMap);
						}
						else if(xaddressBObjExtParty1.getAddressLineOne().equalsIgnoreCase(ExternalRuleConstant.VALUE_DELETED) &&
								!xaddressBObjExtParty2.getAddressLineOne().equalsIgnoreCase(ExternalRuleConstant.VALUE_DELETED)){
							
							mapKey = firstPartyAddrRetailerFlag  + firstRetailer;
							partyAddressMap.put(mapKey, partyAddrBObj);
						}
						if(xaddressBObjExtParty1.getAddressLineOne().equalsIgnoreCase(ExternalRuleConstant.VALUE_DELETED) &&
								xaddressBObjExtParty2.getAddressLineOne().equalsIgnoreCase(ExternalRuleConstant.VALUE_DELETED) )
							{	
								// Do nothing, if both the address are deleted then survive nothing.
							}
						
					}
					
					//Wholesale
					else if (firstPartyAddrUsageType.equalsIgnoreCase(secondPartyAddrUsageType)) {

						if (firstPartySource.equalsIgnoreCase(secondPartySource)) {
							
							if(!xaddressBObjExtParty1.getAddressLineOne().equalsIgnoreCase(ExternalRuleConstant.VALUE_DELETED) &&
								!xaddressBObjExtParty2.getAddressLineOne().equalsIgnoreCase(ExternalRuleConstant.VALUE_DELETED) )
								{
								if (party1CreatedDt.after(party2CreatedDt)) {
							
								 if (secondAddressRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_N)) {
									// Wholesale
									// Key = Retailer Flag + Address Usage Type
									// + Retailer ID
									mapKey = secondAddressRetailerFlag
											+ secondPartyAddrUsageType;

								} else if (secondFS != null && secondFS.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE)) {

									mapKey = secondPartyAddrUsageType
											+ secondFS;

								}

								partyAddressMap.put(mapKey, partyAddrBObjInMap);
							}

							else {
								if (firstPartyAddrRetailerFlag
										.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_N)) {

									// Key = Retailer Flag + Address Usage Type
									mapKey = firstPartyAddrRetailerFlag + firstPartyAddrUsageType;

								} else if (firstFS != null
										&& firstFS
												.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE)) {

									mapKey = firstPartyAddrUsageType + firstFS;

								}

								partyAddressMap.put(mapKey, partyAddrBObj);
							}
						}
							else if(xaddressBObjExtParty1.getAddressLineOne().equalsIgnoreCase(ExternalRuleConstant.VALUE_DELETED) &&
									!xaddressBObjExtParty2.getAddressLineOne().equalsIgnoreCase(ExternalRuleConstant.VALUE_DELETED)){
								if (firstPartyAddrRetailerFlag
										.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_N)) {

									// Key = Retailer Flag + Address Usage Type
									mapKey = firstPartyAddrRetailerFlag + firstPartyAddrUsageType;

								} else if (firstFS != null && firstFS.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE)) {

									mapKey = firstPartyAddrUsageType + firstFS;

								}

								partyAddressMap.put(mapKey, partyAddrBObj);
							}
							else if (!xaddressBObjExtParty1.getAddressLineOne().equalsIgnoreCase(ExternalRuleConstant.VALUE_DELETED) &&
									xaddressBObjExtParty2.getAddressLineOne().equalsIgnoreCase(ExternalRuleConstant.VALUE_DELETED)){
								
								if (secondAddressRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_N)) {
									// Wholesale
									// Key = Retailer Flag + Address Usage Type
									// + Retailer ID
									mapKey = secondAddressRetailerFlag + secondPartyAddrUsageType;
								}else if (secondFS != null && secondFS.equalsIgnoreCase(ExternalRuleConstant.FS_WHOLESALE)) {

									mapKey = secondPartyAddrUsageType
											+ secondFS;

								} 
								partyAddressMap.put(mapKey, partyAddrBObjInMap);
							}
						} else {
							// Different source
							// Priority source will survive
							if (firstPartySource
									.equalsIgnoreCase(ExternalRuleConstant.SOURCE_IDENTIFIER_TYPE_AUTOLINE)) {

								 if (firstPartyAddrRetailerFlag
										.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_N)) {

									mapKey = firstPartyAddrRetailerFlag + firstPartyAddrUsageType;;

								} else if (secondFS != null
										&& secondFS
												.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {

									mapKey = secondPartyAddrUsageType + secondFS;
									

								}
								partyAddressMap.put(mapKey, partyAddrBObj);
							} else {

								 if (secondAddressRetailerFlag
										.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_N)) {

									mapKey = secondAddressRetailerFlag + secondPartyAddrUsageType;

								} else if (firstFS != null
										&& firstFS
												.equalsIgnoreCase(ExternalRuleConstant.FS_VALUE)) {

									mapKey = firstPartyAddrUsageType + firstFS;

								}
								 if(!xaddressBObjExtParty1.getAddressLineOne().equalsIgnoreCase(ExternalRuleConstant.VALUE_DELETED)){
									 partyAddressMap.put(mapKey, partyAddrBObjInMap);
								 }
								
							}
						}
					}
				}
			}
			
			
		}
		
		boolean isAddressMPCAvailable = false;
		for (Entry<String, XAddressGroupBObjExt> e : partyAddressMap.entrySet()) {
		    if (!e.getKey().contains(ExternalRuleConstant.FS_WHOLESALE) && !e.getKey().contains(ExternalRuleConstant.FS_VALUE)
		    		&& (e.getValue()).getX_BPID()==null) {
		    	isAddressMPCAvailable = true;
		    	break;
		    }
		}
		//If MPC record is available then remove FSWS record.
		HashMap<String, XAddressGroupBObjExt> tempAddressMap = new HashMap<String, XAddressGroupBObjExt>();
		
		tempAddressMap.putAll(partyAddressMap);
		if(isAddressMPCAvailable){
			for (Entry<String, XAddressGroupBObjExt> e : tempAddressMap.entrySet()) {
				if (e.getKey().contains(ExternalRuleConstant.FS_WHOLESALE)){
					partyAddressMap.remove(e.getKey());
				}
				
			}
		}
		}
	}

	/**
	 * @param control
	 * @param partyAddressMap
	 * @param vecTempPartyAddressBObj
	 * @param vecRetailPartyAddressBObj
	 * @param isCSet
	 * @param isBusinessSet
	 * @param orgBObjExt
	 * @throws Exception
	 */
	private void addressSurvivourshipLogicImplementationRealtime(
			DWLControl control,
			HashMap<String, XAddressGroupBObjExt> partyAddressMap,
			Vector<XAddressGroupBObjExt> vecTempPartyAddressBObj,
			Vector<XAddressGroupBObjExt> vecRetailPartyAddressBObj,
			boolean isCSet, boolean isBusinessSet, XOrgBObjExt orgBObjExt)
			throws Exception {
		String firstPartyAddrUsageType;
		String firstPartyAddrUsageValue;
		for (int j = 0; j < vecTempPartyAddressBObj.size(); j++) {

			if (orgBObjExt.getSourceIdentifierType() != null
					&& orgBObjExt.getSourceIdentifierType().equalsIgnoreCase(
							ExternalRuleConstant.SOURCE_IDENTIFIER_TYPE_SFDC)) {
				// Extract Retail Addresses
				XAddressGroupBObjExt partyAddrBObj = (XAddressGroupBObjExt) vecTempPartyAddressBObj
						.get(j);
				vecRetailPartyAddressBObj.add(partyAddrBObj);
			}
		}

		// Sort Party Addresses by Last Modified Date
		sortPartyAddresses(vecRetailPartyAddressBObj, null, control);
		for (int j = 0; j < vecRetailPartyAddressBObj.size(); j++) {
			XAddressGroupBObjExt partyAddrBObj = (XAddressGroupBObjExt) vecTempPartyAddressBObj
					.get(j);

			firstPartyAddrUsageValue = partyAddrBObj.getAddressUsageValue();

			firstPartyAddrUsageType = partyAddrBObj.getAddressUsageType();

			if (!partyAddressMap.containsKey(firstPartyAddrUsageType)) {
				// First Retail Address
				if (firstPartyAddrUsageType != null
						&& ((firstPartyAddrUsageType
								.equalsIgnoreCase(ExternalRuleConstant.ADDRESS_USAGE_TYPE_C) && !isCSet) || (firstPartyAddrUsageType
								.equalsIgnoreCase(ExternalRuleConstant.ADDRESS_USAGE_TYPE_BUSINESS_ADDRESS) && !isBusinessSet))) {

					if (firstPartyAddrUsageType
							.equalsIgnoreCase(ExternalRuleConstant.ADDRESS_USAGE_TYPE_C)) {
						isCSet = true;
					} else if (firstPartyAddrUsageType
							.equalsIgnoreCase(ExternalRuleConstant.ADDRESS_USAGE_TYPE_BUSINESS_ADDRESS)) {
						isBusinessSet = true;
					}
					partyAddressMap.put(firstPartyAddrUsageType, partyAddrBObj);
				}
			}
		}
	}

	public void setXPersonAttr(XPersonBObjExt xMainInputBOBj,
			XPersonBObjExt xDBinputBObj, DWLControl control) throws Exception {

		// XDefunctInd
		if (xMainInputBOBj.getXDefunctInd() == null
				|| xMainInputBOBj.getXDefunctInd().isEmpty()) {
			xMainInputBOBj.setXDefunctInd(xDBinputBObj.getXDefunctInd());
		}
		// XEmployerName
		if (xMainInputBOBj.getXEmployerName() == null
				|| xMainInputBOBj.getXEmployerName().isEmpty()) {
			xMainInputBOBj.setXEmployerName(xDBinputBObj.getXEmployerName());
		}
		// XMarketName
		if (xMainInputBOBj.getXMarketName() == null
				|| xMainInputBOBj.getXMarketName().isEmpty()) {
			xMainInputBOBj.setXMarketName(xDBinputBObj.getXMarketName());
		}
		// XBatchInd
		if (xMainInputBOBj.getXBatchInd() == null
				|| xMainInputBOBj.getXBatchInd().isEmpty()) {
			xMainInputBOBj.setXBatchInd(xDBinputBObj.getXBatchInd());
		}
		// XOccupationType
		if (xMainInputBOBj.getXOccupationType() == null
				|| xMainInputBOBj.getXOccupationType().isEmpty()) {
			xMainInputBOBj
					.setXOccupationType(xDBinputBObj.getXOccupationType());
		}
		// XOccupationValue
		if (xMainInputBOBj.getXOccupationValue() == null
				|| xMainInputBOBj.getXOccupationValue().isEmpty()) {
			xMainInputBOBj.setXOccupationValue(xDBinputBObj
					.getXOccupationValue());
		}
		// XLastModifiedSystemDate
		if (xMainInputBOBj.getXLastModifiedSystemDate() == null
				|| xMainInputBOBj.getXLastModifiedSystemDate().isEmpty()) {
			xMainInputBOBj.setXLastModifiedSystemDate(xDBinputBObj
					.getXLastModifiedSystemDate());
		}
		
		//XPersonalAgreement
		if(xMainInputBOBj.getXPersonalAgreement() == null 
				|| xMainInputBOBj.getXPersonalAgreement().isEmpty()){
					xMainInputBOBj.setXPersonalAgreement(xDBinputBObj.getXPersonalAgreement());
		}
		
		//FSChange X_CUST_TYPE Start
		if(null != xMainInputBOBj.getX_CUST_TYPE() && StringUtils.isNonBlank(xMainInputBOBj.getX_CUST_TYPE())
				&& null != xDBinputBObj.getX_CUST_TYPE() && StringUtils.isNonBlank(xDBinputBObj.getX_CUST_TYPE()) )
		{
			if(ExternalRuleConstant.XCUST_TYPE_PC.equalsIgnoreCase(xMainInputBOBj.getX_CUST_TYPE()) 
					&& ExternalRuleConstant.XCUST_TYPE_PC.equalsIgnoreCase(xDBinputBObj.getX_CUST_TYPE()) )
			{
				//PC + PC -> PC
				xMainInputBOBj.setX_CUST_TYPE(ExternalRuleConstant.XCUST_TYPE_PC);
			}
			
			else if(ExternalRuleConstant.XCUST_TYPE_FS.equalsIgnoreCase(xMainInputBOBj.getX_CUST_TYPE()) 
					&& ExternalRuleConstant.XCUST_TYPE_FS.equalsIgnoreCase(xDBinputBObj.getX_CUST_TYPE()) )
			{
				//FS + FS -> FS
				xMainInputBOBj.setX_CUST_TYPE(ExternalRuleConstant.XCUST_TYPE_FS);
			}
			
			else if( (ExternalRuleConstant.XCUST_TYPE_FS.equalsIgnoreCase(xMainInputBOBj.getX_CUST_TYPE()) 
					&& ExternalRuleConstant.XCUST_TYPE_PC.equalsIgnoreCase(xDBinputBObj.getX_CUST_TYPE()))
					|| (ExternalRuleConstant.XCUST_TYPE_PC.equalsIgnoreCase(xMainInputBOBj.getX_CUST_TYPE()) 
							&& ExternalRuleConstant.XCUST_TYPE_FS.equalsIgnoreCase(xDBinputBObj.getX_CUST_TYPE())))
			{
				//FS + PC -> FS;PC
				xMainInputBOBj.setX_CUST_TYPE(ExternalRuleConstant.XCUST_TYPE_FSPC);
			}
			
			else if( ExternalRuleConstant.XCUST_TYPE_FSPC.equalsIgnoreCase(xMainInputBOBj.getX_CUST_TYPE()) 
					|| ExternalRuleConstant.XCUST_TYPE_FSPC.equalsIgnoreCase(xDBinputBObj.getX_CUST_TYPE())) 
			{
				//FS;PC + anything -> FS;PC
				xMainInputBOBj.setX_CUST_TYPE(ExternalRuleConstant.XCUST_TYPE_FSPC);
			}
		}
				
				//FSChange X_CUST_TYPE End

	}

	// For Org Extension Survivorship

	public void setXOrgAttr(XOrgBObjExt xMainInputBOBj,
			XOrgBObjExt xDBinputBObj, DWLControl control) throws Exception {

		if (xMainInputBOBj.getXDefunctInd() == null
				|| xMainInputBOBj.getXDefunctInd().isEmpty()) {
			xMainInputBOBj.setXDefunctInd(xDBinputBObj.getXDefunctInd());
		}
		if (xMainInputBOBj.getXWebsite() == null
				|| xMainInputBOBj.getXWebsite().isEmpty()) {
			xMainInputBOBj.setXWebsite(xDBinputBObj.getXWebsite());
		//XPersonalAgreement
		if(xMainInputBOBj.getXPersonalAgreement() == null 
				|| xMainInputBOBj.getXPersonalAgreement().isEmpty())
				xMainInputBOBj.setXPersonalAgreement(xDBinputBObj.getXPersonalAgreement());
		}
		
		//FSChange X_CUST_TYPE Start
		if(null != xMainInputBOBj.getX_CUST_TYPE() && StringUtils.isNonBlank(xMainInputBOBj.getX_CUST_TYPE())
				&& null != xDBinputBObj.getX_CUST_TYPE() && StringUtils.isNonBlank(xDBinputBObj.getX_CUST_TYPE()) )
		{
			if(ExternalRuleConstant.XCUST_TYPE_PC.equalsIgnoreCase(xMainInputBOBj.getX_CUST_TYPE()) 
					&& ExternalRuleConstant.XCUST_TYPE_PC.equalsIgnoreCase(xDBinputBObj.getX_CUST_TYPE()) )
			{
				//PC + PC -> PC
				xMainInputBOBj.setX_CUST_TYPE(ExternalRuleConstant.XCUST_TYPE_PC);
			}
			
			else if(ExternalRuleConstant.XCUST_TYPE_FS.equalsIgnoreCase(xMainInputBOBj.getX_CUST_TYPE()) 
					&& ExternalRuleConstant.XCUST_TYPE_FS.equalsIgnoreCase(xDBinputBObj.getX_CUST_TYPE()) )
			{
				//FS + FS -> FS
				xMainInputBOBj.setX_CUST_TYPE(ExternalRuleConstant.XCUST_TYPE_FS);
			}
			
			else if( (ExternalRuleConstant.XCUST_TYPE_FS.equalsIgnoreCase(xMainInputBOBj.getX_CUST_TYPE()) 
					&& ExternalRuleConstant.XCUST_TYPE_PC.equalsIgnoreCase(xDBinputBObj.getX_CUST_TYPE()))
					|| (ExternalRuleConstant.XCUST_TYPE_PC.equalsIgnoreCase(xMainInputBOBj.getX_CUST_TYPE()) 
							&& ExternalRuleConstant.XCUST_TYPE_FS.equalsIgnoreCase(xDBinputBObj.getX_CUST_TYPE())))
			{
				//FS + PC -> FS;PC
				xMainInputBOBj.setX_CUST_TYPE(ExternalRuleConstant.XCUST_TYPE_FSPC);
			}
			
			else if( ExternalRuleConstant.XCUST_TYPE_FSPC.equalsIgnoreCase(xMainInputBOBj.getX_CUST_TYPE()) 
					|| ExternalRuleConstant.XCUST_TYPE_FSPC.equalsIgnoreCase(xDBinputBObj.getX_CUST_TYPE())) 
			{
				//FS;PC + anything -> FS;PC
				xMainInputBOBj.setX_CUST_TYPE(ExternalRuleConstant.XCUST_TYPE_FSPC);
			}
		}
		
		//FSChange X_CUST_TYPE End
	}

	/*
	 * public static boolean isUpdateAllowed(String reqValidityStatustp,String
	 * respValidityStatusTp,String entityName,DWLControl control) throws
	 * ConfigurationRepositoryException, ManagementException{
	 * 
	 * if (StringUtils.isBlank(reqValidityStatustp) &&
	 * StringUtils.isBlank(respValidityStatusTp)){ return true; } else if
	 * (StringUtils.isNonBlank(reqValidityStatustp) &&
	 * StringUtils.isBlank(respValidityStatusTp)){ return true; } else if
	 * (StringUtils.isBlank(reqValidityStatustp) &&
	 * StringUtils.isNonBlank(respValidityStatusTp)){ return false; } else if
	 * (StringUtils.isNonBlank(reqValidityStatustp) &&
	 * StringUtils.isNonBlank(respValidityStatusTp)){
	 * 
	 * String
	 * strOOP=getConfigItemValue(ExternalRuleConstant.DAIMLERSOURCESYSTEM+
	 * entityName, control); if (StringUtils.isNonBlank(strOOP)) {
	 * StringTokenizer strTokns= new StringTokenizer(strOOP,",");
	 * HashMap<String, Integer> mapOOP=new HashMap<String, Integer>(); int i=0;
	 * while (strTokns.hasMoreTokens()){
	 * 
	 * mapOOP.put(strTokns.nextToken(),i); i++; }
	 * 
	 * if (mapOOP.get(reqValidityStatustp) <= mapOOP.get(respValidityStatusTp)){
	 * return true; } else{ return false; } }
	 * 
	 * }
	 * 
	 * return true; }
	 */
	/**
	 * @param configItem
	 * @param control
	 * @return
	 * @throws ConfigurationRepositoryException
	 * @throws ManagementException
	 * 
	 * <br>
	 *             generic method to retrieve value from CONFIGELEMENT </br>
	 *
	 */
	public static String getConfigItemValue(String configItem,
			DWLControl control) throws ConfigurationRepositoryException,
			ManagementException {
		String configValue = Configuration.getConfiguration()
				.getConfigItem(configItem, control.retrieveConfigContext())
				.getValue();
		return configValue;
	}

	/*
	 * public static String validOrgCode(String sourcePartyId) throws Exception
	 * { HashMap <String,String> validUCIDType = new HashMap <String,String>();
	 * 
	 * DaimlerCompositeUtils daimlerCompositeUtils = new
	 * DaimlerCompositeUtils();
	 * 
	 * List<SQLParam> params = new ArrayList<SQLParam>();
	 * 
	 * params.add(0, new SQLParam(ADMIN_CLIENT_ID));
	 * 
	 * validUCIDType =
	 * daimlerCompositeUtils.executeQueryUCID(ExternalRuleConstant
	 * .UCID_CUSTOMER_BY_CONTEQUIV, params);
	 * 
	 * return validUCIDType; }
	 */

	public static String getCodeTypeFromValue(String codeTableName,
			String codeValue, DWLControl control) throws Exception {

		String langId = (String) control.get(DWLControlKeys.LANG_ID);
		CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory
				.getCodeTypeComponentHelper();
		String codeType = null;
		if (codeValue != null) {
			CodeTypeBObj ctBObj = codeTypeCompHelper.getCodeTypeByValue(
					codeTableName, langId, codeValue, control);
			if (ctBObj != null) {
				codeType = ctBObj.gettp_cd();
			}
		}
		return codeType;
	}

	public static void setPartyAddressGroupFromRequest(
			XAddressGroupBObjExt finalAddressGroupBObjExt,
			XAddressGroupBObjExt reqAddressGroupBObjExt, DWLControl control)
			throws BusinessProxyException {
		try {

			finalAddressGroupBObjExt.setControl(control);
			// XRetailerId
			finalAddressGroupBObjExt.setXRetailerId(reqAddressGroupBObjExt
					.getXRetailerId());
			// Address Usage Type
			finalAddressGroupBObjExt.setAddressUsageType(reqAddressGroupBObjExt
					.getAddressUsageType());
			// Address Usage Value
			if (reqAddressGroupBObjExt.getAddressUsageValue() != null)
				finalAddressGroupBObjExt
						.setAddressUsageValue(reqAddressGroupBObjExt
								.getAddressUsageValue());
			// LastModifiedSystemDate
			if (reqAddressGroupBObjExt.getXLastModifiedSystemDate() != null)
				finalAddressGroupBObjExt
						.setXLastModifiedSystemDate(reqAddressGroupBObjExt
								.getXLastModifiedSystemDate());
			// XPreference BObj
			XPreferenceBObj requestPreferenceBObj = reqAddressGroupBObjExt
					.getXPreferenceBObj();
			XPreferenceBObj finalPreferenceBObj = new XPreferenceBObj();

			finalPreferenceBObj.setControl(control);
			// Preferred Type
			if (requestPreferenceBObj.getPreferredType() != null)
				finalPreferenceBObj.setPreferredType(requestPreferenceBObj
						.getPreferredType());
			// Source Identifier type
			if (requestPreferenceBObj.getSourceIdentifierType() != null)
				finalPreferenceBObj
						.setSourceIdentifierType(requestPreferenceBObj
								.getSourceIdentifierType());
			// Start Date
			if (requestPreferenceBObj.getStartDate() != null)
				finalPreferenceBObj.setStartDate(requestPreferenceBObj
						.getStartDate());
			// End Date
			if (requestPreferenceBObj.getEndDate() != null)
				finalPreferenceBObj.setEndDate(requestPreferenceBObj
						.getEndDate());

			finalAddressGroupBObjExt.setXPreferenceBObj(finalPreferenceBObj);

			// XPrivacyAgreement BObj
			XPrivacyAgreementBObj requestPrivacyAgreementBObj = reqAddressGroupBObjExt
					.getXPrivacyAgreementBObj();
			XPrivacyAgreementBObj finalPrivacyAgreementBObj = new XPrivacyAgreementBObj();

			finalPrivacyAgreementBObj.setControl(control);
			// Action
			if (requestPrivacyAgreementBObj.getActionType() != null)
				finalPrivacyAgreementBObj
						.setActionType(requestPrivacyAgreementBObj
								.getActionType());
			// Source Identifier type
			if (requestPrivacyAgreementBObj.getSourceIdentifierType() != null)
				finalPrivacyAgreementBObj
						.setSourceIdentifierType(requestPrivacyAgreementBObj
								.getSourceIdentifierType());
			// Start Date
			if (requestPrivacyAgreementBObj.getStartDate() != null)
				finalPrivacyAgreementBObj
						.setStartDate(requestPrivacyAgreementBObj
								.getStartDate());
			// End Date
			if (requestPrivacyAgreementBObj.getEndDate() != null)
				finalPrivacyAgreementBObj
						.setEndDate(requestPrivacyAgreementBObj.getEndDate());

			finalAddressGroupBObjExt
					.setXPrivacyAgreementBObj(finalPrivacyAgreementBObj);

			// XVerified
			if (reqAddressGroupBObjExt.getXVerifiedType() != null) {
				finalAddressGroupBObjExt
						.setXVerifiedType(reqAddressGroupBObjExt
								.getXVerifiedType());
			}
			// XAddressFlag
			if (reqAddressGroupBObjExt.getXAddressRetailerFlag() != null) {
				finalAddressGroupBObjExt
						.setXAddressRetailerFlag(reqAddressGroupBObjExt
								.getXAddressRetailerFlag());
			}
			// AddressBObj
			XAddressBObjExt finalAddressBObjExt = new XAddressBObjExt();
			finalAddressBObjExt.setControl(control);
			XAddressBObjExt reqAddressBObjExt = (XAddressBObjExt) reqAddressGroupBObjExt
					.getTCRMAddressBObj();

			// AddressLineOne
			if (reqAddressBObjExt.getAddressLineOne() != null)
				finalAddressBObjExt.setAddressLineOne(reqAddressBObjExt
						.getAddressLineOne());
			// AddressLineTwo
			if (reqAddressBObjExt.getAddressLineTwo() != null)
				finalAddressBObjExt.setAddressLineTwo(reqAddressBObjExt
						.getAddressLineTwo());
			// AddressLineThree
			if (reqAddressBObjExt.getAddressLineThree() != null)
				finalAddressBObjExt.setAddressLineThree(reqAddressBObjExt
						.getAddressLineThree());
			// City
			if (reqAddressBObjExt.getCity() != null)
				finalAddressBObjExt.setCity(reqAddressBObjExt.getCity());
			// ProvinceStateType
			if (reqAddressBObjExt.getProvinceStateType() != null)
				finalAddressBObjExt.setProvinceStateType(reqAddressBObjExt
						.getProvinceStateType());
			// ZipPostalCode
			if (reqAddressBObjExt.getZipPostalCode() != null)
				finalAddressBObjExt.setZipPostalCode(reqAddressBObjExt
						.getZipPostalCode());
			// CountryType
			if (reqAddressBObjExt.getCountryType() != null)
				finalAddressBObjExt.setCountryType(reqAddressBObjExt
						.getCountryType());

			// XAddressVerification Date
			if (reqAddressBObjExt.getXAddressVerificationDate() != null)
				finalAddressBObjExt
						.setXAddressVerificationDate(reqAddressBObjExt
								.getXAddressVerificationDate());
			// XDistrictType
			if (reqAddressBObjExt.getXDistrictType() != null)
				finalAddressBObjExt.setXDistrictType(reqAddressBObjExt
						.getXDistrictType());
			// XSubcity
			if (reqAddressBObjExt.getXSubcityType() != null)
				finalAddressBObjExt.setXSubcityType(reqAddressBObjExt
						.getXSubcityType());

			// StartDate
			if (reqAddressGroupBObjExt.getStartDate() != null) {
				finalAddressGroupBObjExt.setStartDate(reqAddressGroupBObjExt
						.getStartDate());
			}
			// EndDate
			if (reqAddressGroupBObjExt.getEndDate() != null) {
				finalAddressGroupBObjExt.setEndDate(reqAddressGroupBObjExt
						.getEndDate());
			}

			finalAddressGroupBObjExt.setTCRMAddressBObj(finalAddressBObjExt);

		} catch (Exception e) {

			e.printStackTrace();
			/*
			 * DWLError error = errHandler
			 * .getErrorMessage(TCRMCoreComponentID.PARTY_ADDRESS_OBJECT,
			 * "UPDERR"
			 * ,TCRMCoreErrorReasonCode.UPDATE_PARTY_ADDRESS_FAILED,control, new
			 * String[0]); throw new
			 * BusinessProxyException(error.getErrorMessage());
			 */
		}

	}

	private void handlePrefAddress(
			Vector<XAddressGroupBObjExt> vecSurvivedPersonAddrBOBj)
			throws Exception {

		XAddressGroupBObjExt tempAddrBObj = null;

		for (XAddressGroupBObjExt partyAddress : vecSurvivedPersonAddrBOBj) {

			Timestamp lastUpdatedt = DateFormatter.getTimestamp(partyAddress
					.getXLastModifiedSystemDate());
			String prefInd = partyAddress.getPreferredAddressIndicator();

			if (StringUtils.isNonBlank(prefInd)
					&& prefInd
							.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_Y)) {
				if (tempAddrBObj == null) {
					tempAddrBObj = partyAddress;
					continue;
				}

				if (DateFormatter.getTimestamp(
						tempAddrBObj.getXLastModifiedSystemDate()).before(
						lastUpdatedt)) {
					tempAddrBObj
							.setPreferredAddressIndicator(ExternalRuleConstant.CHARACTER_N);
					tempAddrBObj = partyAddress;
				} else {
					partyAddress
							.setPreferredAddressIndicator(ExternalRuleConstant.CHARACTER_N);
				}

			}
		}
	}

	private void handlePrefContactMethod(
			Vector<XContactMethodGroupBObjExt> vecSurvivedPersonContMethBOBj)
			throws Exception {

		XContactMethodGroupBObjExt tempContMethodBObj = null;

		for (XContactMethodGroupBObjExt partyContMethodBObj : vecSurvivedPersonContMethBOBj) {

			Timestamp lastUpdatedt = DateFormatter
					.getTimestamp(partyContMethodBObj
							.getXLastModifiedSystemDate());
			String prefInd = partyContMethodBObj
					.getPreferredContactMethodIndicator();

			if (StringUtils.isNonBlank(prefInd)
					&& prefInd
							.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_Y)) {
				if (tempContMethodBObj == null) {
					tempContMethodBObj = partyContMethodBObj;
					continue;
				}

				if (DateFormatter.getTimestamp(
						tempContMethodBObj.getXLastModifiedSystemDate())
						.before(lastUpdatedt)) {
					tempContMethodBObj
							.setPreferredContactMethodIndicator(ExternalRuleConstant.CHARACTER_N);
					tempContMethodBObj = partyContMethodBObj;
				} else {
					partyContMethodBObj
							.setPreferredContactMethodIndicator(ExternalRuleConstant.CHARACTER_N);
				}

			}
		}
	}

	public HashMap<String, String> getAllRetailersByDealerForMagic(
			HashMap<String, String> dealerRetailerMap) throws Exception {
		// TODO Auto-generated method stub

		SQLQuery sqlQuery = new SQLQuery();
		ResultSet objResultSet = null;
		String dealerCode = null;
		String retailerCode = null;

		String partyIdSql = ExternalRuleConstant.GET_ALL_DEALER_RETAILER_RELS;

		try {
			objResultSet = sqlQuery.executeQuery(partyIdSql);

			while (objResultSet.next()) {
				dealerCode = objResultSet
						.getString(ExternalRuleConstant.DEALER_CODE);
				retailerCode = objResultSet
						.getString(ExternalRuleConstant.RETAILER_CODE);

				dealerRetailerMap.put(retailerCode, dealerCode);

			}

		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			if(objResultSet != null)
				objResultSet.close();
			sqlQuery.close();
		}

		return dealerRetailerMap;
	}
	
	public String checkRecordTypeForPerson(XPersonBObjExt tcrmPersonBObj) {
		
		String recordType = null;
		
		Vector<XPersonNameBObjExt> vecNameBObjs = tcrmPersonBObj.getItemsTCRMPersonNameBObj();
		
		if(vecNameBObjs.size() == 1){
			if(StringUtils.isBlank(vecNameBObjs.get(0).getXPersonNameRetailerFlag())
					|| vecNameBObjs.get(0).getXPersonNameRetailerFlag() == null){
			recordType = "MPC";
			}else{
				recordType = "FS";
			}
		}else{
			
			for(XPersonNameBObjExt personNameBObj : vecNameBObjs){
				
				if(personNameBObj.getXPersonNameRetailerFlag() == null || 
						StringUtils.isBlank(personNameBObj.getXPersonNameRetailerFlag())){
					recordType = "MPCFS";
				}else if(personNameBObj.getXPersonNameRetailerFlag().equals("FSWS")){
					recordType = "FS";
				}
			}
		}
				
		return recordType;
		
	}
	
	public String checkRecordTypeForOrg(XOrgBObjExt tcrmOrgBObj) {
		
		String recordType = null;
		
		Vector<XOrgNameBObjExt> vecNameBObjs = tcrmOrgBObj.getItemsTCRMOrganizationNameBObj();
		
		if(vecNameBObjs.size() == 1){
			if(StringUtils.isBlank(vecNameBObjs.get(0).getXOrgNameRetailerFlag())
					|| vecNameBObjs.get(0).getXOrgNameRetailerFlag() == null){
			recordType = "MPC";
			}else{
				recordType = "FS";
			}
		}else{
			
			for(XOrgNameBObjExt orgNameBObj : vecNameBObjs){
				
				if(orgNameBObj.getXOrgNameRetailerFlag() == null || 
						StringUtils.isBlank(orgNameBObj.getXOrgNameRetailerFlag())){
					recordType = "MPCFS";
				}else if(orgNameBObj.getXOrgNameRetailerFlag().equals("FSWS")){
					recordType = "FS";
				}
			}
		}
				
		return recordType;
		
	}
	/**
	 * removes DELETED ph, email and address from original parties
	 * @param vecAllParty
	 */
	void removeDeletedCommChannels(Vector vecAllParty){
		
		for (int i=0; i<vecAllParty.size();i++) {
			XOrgBObjExt xOrgBObj = (XOrgBObjExt) vecAllParty.get(i);

			if(xOrgBObj.getXMarketName().equalsIgnoreCase(ExternalRuleConstant.MARKET_NAME_MALAYSIA))
			{
				Vector<XAddressGroupBObjExt> tempVecAddressBObj = xOrgBObj.getItemsTCRMPartyAddressBObj();

				for (Iterator<XAddressGroupBObjExt> addressIterator = tempVecAddressBObj.iterator(); addressIterator.hasNext();) {
					XAddressGroupBObjExt tempXAddressGroupBObjExt = (XAddressGroupBObjExt) addressIterator.next();

					//ignore Delete merge TF MYS
					if(ExternalRuleConstant.VALUE_DELETED.equals(tempXAddressGroupBObjExt.getTCRMAddressBObj().getAddressLineOne())){

						//remove DELETED address from original vector
						addressIterator.remove();
					}
				}

				Vector<XContactMethodGroupBObjExt> tempContMethBObj = xOrgBObj.getItemsTCRMPartyContactMethodBObj();

				for (Iterator<XContactMethodGroupBObjExt> contMethIterator = tempContMethBObj.iterator(); contMethIterator.hasNext();) {
					XContactMethodGroupBObjExt tempXContMethExt = (XContactMethodGroupBObjExt) contMethIterator.next();

					//ignore Delete merge TF MYS
					if(ExternalRuleConstant.VALUE_DELETED.equals
							(tempXContMethExt.getTCRMContactMethodBObj().getReferenceNumber())){

						//remove DELETED contact meth from original vector
						contMethIterator.remove();
					}
				}
			}
		}
	}
}
