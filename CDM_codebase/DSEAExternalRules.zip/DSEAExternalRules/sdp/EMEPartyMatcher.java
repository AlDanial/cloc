package com.ibm.daimler.dsea.extrules.sdp;

import com.dwl.base.DWLControl;
import com.dwl.base.IDWLErrorMessage;
import com.dwl.base.error.DWLError;
import com.dwl.base.error.DWLStatus;
import com.dwl.base.exception.DWLBaseException;
import com.dwl.base.externalrule.ExternalRuleComponent;
import com.dwl.base.externalrule.ExternalRuleException;
import com.dwl.base.externalrule.ExternalRuleFact;
import com.dwl.base.performance.PerformanceMonitor;
import com.dwl.base.performance.PerformanceMonitorConfig;
import com.dwl.base.performance.PerformanceMonitorFactory;
import com.dwl.base.util.DWLExceptionUtils;
import com.dwl.tcrm.coreParty.component.TCRMOrganizationBObj;
import com.dwl.tcrm.coreParty.component.TCRMOrganizationSearchBObj;
import com.dwl.tcrm.coreParty.component.TCRMOrganizationSearchResultBObj;
import com.dwl.tcrm.coreParty.component.TCRMPartyBObj;
import com.dwl.tcrm.coreParty.component.TCRMPartyComponent;
import com.dwl.tcrm.coreParty.component.TCRMPartySearchBObj;
import com.dwl.tcrm.coreParty.component.TCRMPersonBObj;
import com.dwl.tcrm.coreParty.component.TCRMPersonSearchBObj;
import com.dwl.tcrm.coreParty.component.TCRMPersonSearchResultBObj;
import com.dwl.tcrm.coreParty.component.TCRMSuspectBObj;
import com.dwl.tcrm.coreParty.interfaces.IPartyMatcher;
import com.dwl.tcrm.coreParty.interfaces.IPartySearcher;
import com.dwl.tcrm.exception.TCRMDataInvalidException;
import com.dwl.tcrm.exception.TCRMException;
import com.dwl.tcrm.exception.TCRMReadException;
import com.dwl.tcrm.utilities.TCRMClassFactory;
import com.dwl.tcrm.utilities.TCRMExceptionUtils;
import com.dwl.tcrm.utilities.TCRMExtRuleHelper;
import com.ibm.daimler.dsea.component.XOrgBObjExt;
import com.ibm.daimler.dsea.component.XPersonBObjExt;
import com.ibm.daimler.dsea.extrules.constant.ExternalRuleConstant;
import com.ibm.mdm.common.converter.Converter;
import com.ibm.mdm.common.converter.ConverterFactory;
import com.ibm.mdm.eme.suspect.component.TransientSuspectBObj;
import com.ibm.mdm.matching.adapter.MatchingAdapter;
import com.ibm.mdm.matching.adapter.MatchingAdapterManager;
import com.ibm.mdm.matching.adapter.SuspectSearchAdapter;
import com.ibm.mdm.matching.engine.IMatcher2ndGen;
import com.ibm.mdm.suspect.interfaces.EntitySuspect;

import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

public class EMEPartyMatcher
  implements IPartyMatcher, IPartySearcher, IMatcher2ndGen
{
  public static final String copyright = "Licensed Materials -- Property of IBM\n(c) Copyright IBM Corp. 2011, 2014\nUS Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.";
  protected IDWLErrorMessage errHandler = TCRMClassFactory.getErrorHandler();
  private static final String MONITOR_TRANS_MATCH_PARTIES = "matchParties(TCRMPartyBObj,Vector)";

  public Vector matchParties(TCRMPartyBObj theTCRMPartyBObj, Vector vecTCRMPartyBObj)
    throws TCRMException, ExternalRuleException
  {
    PerformanceMonitorFactory performanceMonitorFactory = 
      PerformanceMonitorConfig.getInstance().getPerformanceMonitorFactory();
    PerformanceMonitor performanceMonitor = performanceMonitorFactory
      .newPartyMatcherMonitor(theTCRMPartyBObj.getControl());
    boolean success = false;

    Vector vecSuspectBObj = null;
    DWLStatus status = new DWLStatus();
    DWLControl control = theTCRMPartyBObj.getControl();
    
    String marketName = null;
    String partyType = null;
    Vector vecSourcePartyMYSBObj = new Vector();
    Vector vecSourcePartyTHAIBObj = new Vector();

    performanceMonitor.start(control, "matchParties(TCRMPartyBObj,Vector)", getClass());
    try
    {
      if ((!(theTCRMPartyBObj instanceof TCRMPersonBObj)) && (!(theTCRMPartyBObj instanceof TCRMOrganizationBObj))) {
        TCRMExceptionUtils.throwTCRMException(null, new TCRMReadException(), status, 
          9L, 
          "1", "READERR", 
          "1601", 
          control, this.errHandler);
      }

      MatchingAdapter adapter = MatchingAdapterManager.getMatchingAdapter(theTCRMPartyBObj);
      
      //Changes start for DSEA
      
      partyType = theTCRMPartyBObj.getPartyType();
      if(partyType!=null && partyType.equalsIgnoreCase("P")){
      XPersonBObjExt xPersonBObjExt = (XPersonBObjExt)theTCRMPartyBObj;      
      marketName = xPersonBObjExt.getXMarketName();
      
      if(marketName!=null && marketName.equalsIgnoreCase("MYS")){
    	  for(int i=0;i<vecTCRMPartyBObj.size();i++){
    		  
    		  XPersonBObjExt xPersonBObj =  (XPersonBObjExt) vecTCRMPartyBObj.get(i);
    		  if(xPersonBObj.getXMarketName()!=null && !xPersonBObj.getXMarketName().equalsIgnoreCase("MYS")){  
    			  vecTCRMPartyBObj.remove(i);
    		  }
    	  }
    	  
      }
      if(marketName!=null && marketName.equalsIgnoreCase("THA")){
    	  for(int i=0;i<vecTCRMPartyBObj.size();i++){
    		  
    		  XPersonBObjExt xPersonBObj =  (XPersonBObjExt) vecTCRMPartyBObj.get(i);
    		  if(xPersonBObj.getXMarketName()!=null && !xPersonBObj.getXMarketName().equalsIgnoreCase("THA")){
    			  vecTCRMPartyBObj.remove(i);   			  
    		  }
    	  }
    	  
      }
      }
      
      if(partyType!=null && partyType.equalsIgnoreCase("O")){
          XOrgBObjExt xOrgBObjExt = (XOrgBObjExt)theTCRMPartyBObj;      
          marketName = xOrgBObjExt.getXMarketName();
          
          if(marketName!=null && marketName.equalsIgnoreCase("MYS")){
        	  for(int i=0;i<vecTCRMPartyBObj.size();i++){
        		  
        		  XOrgBObjExt xOrgBObj =  (XOrgBObjExt) vecTCRMPartyBObj.get(i);
        		  if(xOrgBObj.getXMarketName()!=null && !xOrgBObj.getXMarketName().equalsIgnoreCase("MYS")){
        			  vecTCRMPartyBObj.remove(i);   			  
        		  }
        	  }
        	  
          }
          if(marketName!=null && marketName.equalsIgnoreCase("THA")){
        	  for(int i=0;i<vecTCRMPartyBObj.size();i++){
        		  
        		  XOrgBObjExt xOrgBObj =  (XOrgBObjExt) vecTCRMPartyBObj.get(i);
        		  if(xOrgBObj.getXMarketName()!=null && !xOrgBObj.getXMarketName().equalsIgnoreCase("THA")){
        			  vecTCRMPartyBObj.remove(i);   			  
        		  }
        	  }
        	  
          }
          }
            
      //Changes end for DSEA

      vecSuspectBObj = adapter.compareEntities(theTCRMPartyBObj, vecTCRMPartyBObj);
      success = true;
    } catch (TCRMException ex) {
      DWLExceptionUtils.log(ex);
      throw ex;
    } catch (Exception ex) {
      TCRMExceptionUtils.throwTCRMException(ex, new TCRMReadException(), status, 9L, "1", "READERR", 
        "2312", 
        theTCRMPartyBObj.getControl(), this.errHandler);
    } finally {
      performanceMonitor.stop(success);
    }

    return vecSuspectBObj;
  }

  public Vector rankSearchResults(TCRMPartySearchBObj theTCRMPartySearchBObj, Vector vecPartySearchResultBObj)
    throws TCRMException, ExternalRuleException
  {
    Vector output = new Vector();
    Vector input = new Vector();

    DWLStatus status = new DWLStatus();
    try
    {
      if ((theTCRMPartySearchBObj instanceof TCRMPersonSearchBObj))
      {
        ExternalRuleComponent aExternalRuleComponent = 
          TCRMExtRuleHelper.getExternalRuleComponent();

        ExternalRuleFact aExternalRuleFact = new ExternalRuleFact();

        input.addElement((TCRMPersonSearchBObj)theTCRMPartySearchBObj);

        for (int i = 0; i < vecPartySearchResultBObj.size(); i++) {
          input
            .addElement(
            (TCRMPersonSearchResultBObj)vecPartySearchResultBObj
            .elementAt(i));
        }

        aExternalRuleFact.setInput(input);

        aExternalRuleFact.setRuleId("4");

        aExternalRuleComponent.executeRule(aExternalRuleFact);

        Vector vecOutput = (Vector)aExternalRuleFact.getOutput();

        if ((vecOutput != null) && (vecOutput.size() > 0))
        {
          for (int i = 0; i < vecOutput.size(); i++)
            output
              .addElement(
              (TCRMPersonSearchResultBObj)vecOutput
              .elementAt(i));
        }
      }
      else if ((theTCRMPartySearchBObj instanceof TCRMOrganizationSearchBObj))
      {
        ExternalRuleComponent aExternalRuleComponent = 
          TCRMExtRuleHelper.getExternalRuleComponent();

        ExternalRuleFact aExternalRuleFact = new ExternalRuleFact();

        input
          .addElement((TCRMOrganizationSearchBObj)theTCRMPartySearchBObj);

        for (int i = 0; i < vecPartySearchResultBObj.size(); i++) {
          input
            .addElement(
            (TCRMOrganizationSearchResultBObj)vecPartySearchResultBObj
            .elementAt(i));
        }

        aExternalRuleFact.setInput(input);

        aExternalRuleFact.setRuleId("5");

        aExternalRuleComponent.executeRule(aExternalRuleFact);

        Vector vecOutput = (Vector)aExternalRuleFact.getOutput();

        if ((vecOutput != null) && (vecOutput.size() > 0))
        {
          for (int i = 0; i < vecOutput.size(); i++)
            output
              .addElement(
              (TCRMOrganizationSearchResultBObj)vecOutput
              .elementAt(i));
        }
      }
      else
      {
        DWLError error = this.errHandler.getErrorMessage(
          "1", 
          "INSERR", 
          "1601", 
          theTCRMPartySearchBObj.getControl(), new String[0]);

        status.addError(error);
        status.setStatus(9L);

        TCRMDataInvalidException dataEx = new TCRMDataInvalidException();
        dataEx.setStatus(status);

        throw dataEx;
      }
    }
    catch (TCRMException ex) {
      DWLExceptionUtils.log(ex);
      throw ex;
    }
    catch (ExternalRuleException ex) {
      DWLExceptionUtils.log(ex);
      throw ex;
    }
    catch (Exception ex) {
      DWLExceptionUtils.log(ex);
      status = new DWLStatus();

      TCRMReadException readEx = new TCRMReadException();

      DWLError error = this.errHandler.getErrorMessage(
        "1", 
        "READERR", 
        "778", 
        theTCRMPartySearchBObj.getControl(), new String[0]);
      error.setDetail(ex.toString());
      error.setThrowable(ex);
      status.addError(error);
      status.setStatus(9L);
      readEx.setStatus(status);

      throw readEx;
    }

    return output;
  }

  public Vector searchSuspects(TCRMPartyBObj partyBObj)
    throws TCRMException, ExternalRuleException
  {
    Vector suspectSearchResult = new Vector();
    
    String marketName = null;
    String partyType = null;
    Vector vecSourcePartyMYSBObj = new Vector();
    Vector vecSourcePartyTHAIBObj = new Vector();
    TCRMPartyComponent tcrmPartyComponent = new TCRMPartyComponent();
    String partyId = null;
    XPersonBObjExt tcrmPersonBObj = null;
    XOrgBObjExt tcrmOrgBObj = null;
    List transientPartySuspectBObj = new ArrayList();
    
    try
    {
      SuspectSearchAdapter suspectSearchAdapter = MatchingAdapterManager.getSuspectSearchAdapter(partyBObj);

      List entitySuspectList = suspectSearchAdapter.searchSuspects(partyBObj);
      
      //Changes start for DSEA
      
      partyType = partyBObj.getPartyType();
      if(partyType!=null && partyType.equalsIgnoreCase(ExternalRuleConstant.PERSON_TYPE)){
      XPersonBObjExt xPersonBObjExt = (XPersonBObjExt)partyBObj;      
      marketName = xPersonBObjExt.getXMarketName();
      
      if(marketName!=null && marketName.equalsIgnoreCase(ExternalRuleConstant.MARKET_NAME_MALAYSIA)){
    	  for(int i=0;i<entitySuspectList.size();i++){
    		  
    		  TransientSuspectBObj transientSuspectBObj =  (TransientSuspectBObj) entitySuspectList.get(i);
    		  
    		  partyId = transientSuspectBObj.getSuspectEntityId();
    		  
    		  tcrmPersonBObj = (XPersonBObjExt) tcrmPartyComponent.getPerson(partyId,
    				  ExternalRuleConstant.INQUIRY_LVL_0, transientSuspectBObj.getControl());
    		  if(tcrmPersonBObj.getXMarketName()!=null && tcrmPersonBObj.getXMarketName().equalsIgnoreCase(ExternalRuleConstant.MARKET_NAME_MALAYSIA)){ 
    			  transientPartySuspectBObj.add(transientSuspectBObj);
    		  }
    	  }
    	  
      }
      if(marketName!=null && marketName.equalsIgnoreCase(ExternalRuleConstant.MARKET_NAME_THAILAND)){
    	  for(int i=0;i<entitySuspectList.size();i++){
    		  
    		  TransientSuspectBObj transientSuspectBObj =  (TransientSuspectBObj) entitySuspectList.get(i);
    		  
    		  partyId = transientSuspectBObj.getSuspectEntityId();
    		  
    		  tcrmPersonBObj = (XPersonBObjExt) tcrmPartyComponent.getPerson(partyId,
    				  ExternalRuleConstant.INQUIRY_LVL_0, transientSuspectBObj.getControl());
    		  if(tcrmPersonBObj.getXMarketName()!=null && tcrmPersonBObj.getXMarketName().equalsIgnoreCase(ExternalRuleConstant.MARKET_NAME_THAILAND)){ 
    			  transientPartySuspectBObj.add(transientSuspectBObj);
    		  }
    	  }
    	  
      }
      }
      
      if(partyType!=null && partyType.equalsIgnoreCase(ExternalRuleConstant.ORG_TYPE)){
          XOrgBObjExt xOrgBObjExt = (XOrgBObjExt)partyBObj;      
          marketName = xOrgBObjExt.getXMarketName();          
          if(marketName!=null && marketName.equalsIgnoreCase(ExternalRuleConstant.MARKET_NAME_MALAYSIA)){
        	  for(int i=0;i<entitySuspectList.size();i++){
        		  
        		  TransientSuspectBObj transientSuspectBObj =  (TransientSuspectBObj) entitySuspectList.get(i);
        		  
        		  partyId = transientSuspectBObj.getSuspectEntityId();
        		  
        		  tcrmOrgBObj = (XOrgBObjExt) tcrmPartyComponent.getOrganization(partyId,
        				  ExternalRuleConstant.INQUIRY_LVL_0, transientSuspectBObj.getControl());
        		  if(tcrmOrgBObj.getXMarketName()!=null && tcrmOrgBObj.getXMarketName().equalsIgnoreCase(ExternalRuleConstant.MARKET_NAME_MALAYSIA)){ 
        			  transientPartySuspectBObj.add(transientSuspectBObj);
        		  }
        	  }
        	  
          }
          if(marketName!=null && marketName.equalsIgnoreCase(ExternalRuleConstant.MARKET_NAME_THAILAND)){
        	  for(int i=0;i<entitySuspectList.size();i++){
        		  
        		  TransientSuspectBObj transientSuspectBObj =  (TransientSuspectBObj) entitySuspectList.get(i);
        		  
        		  partyId = transientSuspectBObj.getSuspectEntityId();
        		  
        		  tcrmOrgBObj = (XOrgBObjExt) tcrmPartyComponent.getOrganization(partyId,
        				  ExternalRuleConstant.INQUIRY_LVL_0, transientSuspectBObj.getControl());
        		  if(tcrmOrgBObj.getXMarketName()!=null && tcrmOrgBObj.getXMarketName().equalsIgnoreCase(ExternalRuleConstant.MARKET_NAME_THAILAND)){ 
        			  transientPartySuspectBObj.add(transientSuspectBObj);
        		  }
        	  }
          }
          
      }
      
      if ((transientPartySuspectBObj != null) && (transientPartySuspectBObj.size() > 0))
          suspectSearchResult = convertToTCRMSuspects(transientPartySuspectBObj);
            
      //Changes end for DSEA

      //if ((entitySuspectList != null) && (entitySuspectList.size() > 0))
      //  suspectSearchResult = convertToTCRMSuspects(entitySuspectList);
    }
    catch (DWLBaseException e)
    {
      TCRMException ex = new TCRMException(e);
      ex.setStatus(e.getStatus());
      throw ex;
    }

    return suspectSearchResult;
  }

  private Vector convertToTCRMSuspects(List<EntitySuspect> entitySuspectList)
    throws DWLBaseException
  {
    Vector resultVecTCRMSuspect = new Vector();

    ConverterFactory cFactory = ConverterFactory.getInstance("eme.searchSuspects.converter");
    Converter transientSuspectToTCRMSuspectConverter = cFactory.getConverter(TransientSuspectBObj.class);

    for (EntitySuspect entitySuspect : entitySuspectList)
    {
      TCRMSuspectBObj tcrmSuspectBObj = null;
      try {
        tcrmSuspectBObj = (TCRMSuspectBObj)transientSuspectToTCRMSuspectConverter.convert(entitySuspect);
      } catch (Exception e) {
        DWLExceptionUtils.log(e);
        throw new DWLBaseException(e);
      }

      resultVecTCRMSuspect.add(tcrmSuspectBObj);
    }

    return resultVecTCRMSuspect;
  }
}