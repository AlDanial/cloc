package com.ibm.daimler.dsea.extrules.sdp;

/* _______________________________________________________ {COPYRIGHT-TOP} _____
* Licensed Materials - Property of IBM
* Restricted Materials of IBM
*
* 5725-E59
*
* (C) Copyright IBM Corp. 2013, 2014  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
* ________________________________________________________ {COPYRIGHT-END} _____*/
/**
 * 
 */

import java.util.List;
import java.util.Vector;

import com.dwl.base.DWLControl;
import com.dwl.base.DWLResponse;
import com.dwl.base.error.DWLStatus;
import com.dwl.base.externalrule.ExternalRuleComponent;
import com.dwl.base.externalrule.ExternalRuleFact;
import com.dwl.base.externalrule.Rule;
import com.dwl.base.requestHandler.DWLTransactionPersistent;
import com.dwl.base.requestHandler.DWLTxnBP;
import com.dwl.base.util.StringUtils;
import com.dwl.tcrm.common.TCRMCommon;
import com.dwl.tcrm.coreParty.component.TCRMPartyBObj;
import com.dwl.tcrm.coreParty.component.TCRMPartyComponent;
import com.dwl.tcrm.coreParty.component.TCRMPartyListBObj;
import com.dwl.tcrm.coreParty.component.TCRMPersonBObj;
import com.dwl.tcrm.coreParty.component.TCRMPersonNameBObj;
import com.dwl.tcrm.coreParty.component.TCRMSuspectBObj;
import com.dwl.tcrm.externalrule.PartyMatchCategoryExtRule;
import com.dwl.tcrm.utilities.TCRMExtRuleHelper;
import com.ibm.daimler.dsea.component.XDataSharingBObj;
import com.ibm.daimler.dsea.component.XIdentifierBObjExt;
import com.ibm.daimler.dsea.component.XOrgBObjExt;
import com.ibm.daimler.dsea.component.XPersonBObjExt;
import com.ibm.daimler.dsea.extrules.constant.ExternalRuleConstant;
import com.ibm.daimler.dsea.extrules.util.ExternalRuleUtil;
import com.ibm.mdm.eme.bobj.ComparisonFunctionDetailsBObj;
import com.ibm.mdm.eme.bobj.MatchComparisonDetailsBObj;
import com.ibm.mdm.eme.util.EMEUtil;

/**
 * This rule will delegate execution to PartyMatchCategoryExtRule when eME is not the configured matching engine for the input business object,
 * otherwise it doesn't do anything.
 *
 */
public class DSEAPartySuspectAdjustmentRule extends Rule {
	public static final String copyright =  "Licensed Materials -- Property of IBM\n(c) Copyright IBM Corp. 2013, 2014\nUS Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.";




	/* 
	 * If eME is matching engine, do nothing; otherwise call PartyMatchCategoryExtRule.
	 * @param input
	 *            A <code>Vector</code> containing an instance of 
	 *            <code>TCRMPartyBObj</code> as the first element and instances of
	 *            <code> TCRMSuspectBObj</code> as subsequent elements 
	 *  @return
	 *            if eME is matching engine,return a <code>Vector</code> containing same instances of <code> TCRMSuspectBObj</code> as in <code> input </code>
	 *            if eME is not matching engine, return a <code>Vector</code> containing adjusted <code> TCRMSuspectBObj</code> 
	 */
	@Override
	public Object execute(Object input, Object componentObject)
			throws Exception {

		Vector vecInput=(Vector)input;
		
		

		TCRMSuspectBObj suspect=(TCRMSuspectBObj)(vecInput.elementAt(1));
		String matchEngineType=suspect.getCurrentMatchEngineType();

		//if use eME, return suspect instances in input
		if (EMEUtil.useEME(matchEngineType))
		{

			TCRMPartyBObj sourceparty=(TCRMPartyBObj) vecInput.elementAt(0);
			
			XPersonBObjExt personObj=new XPersonBObjExt();
			XOrgBObjExt orgObj=new XOrgBObjExt();
			String xmarketName=null;
			
			if(sourceparty instanceof XPersonBObjExt)
			{
				
				personObj=(XPersonBObjExt)sourceparty;
				xmarketName=personObj.getXMarketName();
			}
			else if(sourceparty instanceof XOrgBObjExt)
			{
				orgObj=(XOrgBObjExt)sourceparty;
				xmarketName=orgObj.getXMarketName();
			}
			
			// For JAPAN market Suspect Adjustment : Start
			if(xmarketName!=null && xmarketName.equalsIgnoreCase(ExternalRuleConstant.JAPAN_MARKET_NAME))
			{
				for(int i=1;i<vecInput.size();i++)
				{
					sourceparty.getItemsTCRMSuspectBObj().add((TCRMSuspectBObj)(vecInput.elementAt(i)));
				}
				
				ExternalRuleUtil extrUtil=new ExternalRuleUtil();
				//extrUtil.matchRulesAdjustForJapan(sourceparty, sourceparty.getControl());
				// Start of Changes for Match suspect by  Shashi 18-06-2021 Start:
				extrUtil.matchRulesAdjustForJPN(sourceparty, sourceparty.getControl(), xmarketName);
				// End
				extrUtil.matchRulesAdjustForSpecialVR(sourceparty, sourceparty.getControl(), xmarketName);
				return categorizeSuspects(vecInput);
			}
			// For JAPAN market Suspect Adjustment : End
			
			// For AU&NZ market Suspect Adjustment : Start by Shashi (20-08-2021)
			if(xmarketName!=null && (xmarketName.equalsIgnoreCase(ExternalRuleConstant.MARKET_NAME_AUSTRALIA)
					|| xmarketName.equalsIgnoreCase(ExternalRuleConstant.MARKET_NAME_NEWZEALAND)))
			{
				for(int i=1;i<vecInput.size();i++)
					{
					    sourceparty.getItemsTCRMSuspectBObj().add((TCRMSuspectBObj)(vecInput.elementAt(i)));
					}
							
					ExternalRuleUtil extrUtil=new ExternalRuleUtil();
							
					extrUtil.matchRulesAdjustForAUNZ(sourceparty, sourceparty.getControl(), xmarketName);
					extrUtil.matchRulesAdjustForSpecialVR(sourceparty, sourceparty.getControl(), xmarketName);
					//For AUNZ down grade A1 to B for specific data scenarios
					downgradeA1Suspects(vecInput);
					return categorizeSuspects(vecInput);
			}
		    // For AU&NZ market Suspect Adjustment : End
			
			// For KOREA market Suspect Adjustment : Start
			if(xmarketName!=null && xmarketName.equalsIgnoreCase(ExternalRuleConstant.KOREA_MARKET_NAME))
			{
				for(int i=1;i<vecInput.size();i++)
				{
					sourceparty.getItemsTCRMSuspectBObj().add((TCRMSuspectBObj)(vecInput.elementAt(i)));
				}
				
				ExternalRuleUtil extrUtil=new ExternalRuleUtil();
				extrUtil.matchRulesAdjustForKorea(sourceparty, sourceparty.getControl());
				
				//extrUtil.matchRulesAdjustForSpecialVR(sourceparty, sourceparty.getControl(), xmarketName); Commented for REARCH
				
				//Start of change for removing impact of enabling auto collapse 
				downgradeA1suspectsForRealTime(vecInput,((TCRMPartyBObj)vecInput.get(0)).getControl());
				
				changeDOBScoreKOR(vecInput);
				
				
				return categorizeSuspects(vecInput);
			}
			//THA-FS Changes
			if(xmarketName!=null && xmarketName.equalsIgnoreCase(ExternalRuleConstant.MARKET_NAME_THAILAND))
			{
				for(int i=1;i<vecInput.size();i++)
				{
					sourceparty.getItemsTCRMSuspectBObj().add((TCRMSuspectBObj)(vecInput.elementAt(i)));
				}
				
				ExternalRuleUtil extrUtil=new ExternalRuleUtil();
				// added for upgrade of suspect by  Shashi 15-10-2020 Start:
				extrUtil.matchRulesAdjustForTHA(sourceparty, sourceparty.getControl(), xmarketName);
				//end
//				extrUtil.matchRulesAdjustForTHAFS(sourceparty, sourceparty.getControl());
				extrUtil.matchRulesAdjustForSpecialVR(sourceparty, sourceparty.getControl(), xmarketName);
				return categorizeSuspects(vecInput);
			}
			
			if(xmarketName!=null && xmarketName.equalsIgnoreCase(ExternalRuleConstant.MARKET_NAME_BRAZIL))
			{
				for(int i=1;i<vecInput.size();i++)
				{
					sourceparty.getItemsTCRMSuspectBObj().add((TCRMSuspectBObj)(vecInput.elementAt(i)));
				}
				
				ExternalRuleUtil extrUtil=new ExternalRuleUtil();
				extrUtil.matchRulesAdjustForBrasil(sourceparty, sourceparty.getControl());
				extrUtil.matchRulesAdjustForSpecialVR(sourceparty, sourceparty.getControl(), xmarketName);
				return categorizeSuspects(vecInput);
			}
			else
			{
			
				if(xmarketName!=null && xmarketName.equalsIgnoreCase(ExternalRuleConstant.MARKET_NAME_TURKEY)
						||xmarketName!=null && xmarketName.equalsIgnoreCase(ExternalRuleConstant.MARKET_NAME_SINGAPORE)
						||xmarketName!=null && xmarketName.equalsIgnoreCase(ExternalRuleConstant.MARKET_NAME_INDONESIA)
						||xmarketName!=null && xmarketName.equalsIgnoreCase(ExternalRuleConstant.MARKET_NAME_VIETNAM)
						||xmarketName!=null && xmarketName.equalsIgnoreCase(ExternalRuleConstant.MARKET_NAME_MALAYSIA)
						||xmarketName!=null && xmarketName.equalsIgnoreCase(ExternalRuleConstant.MARKET_NAME_INDIA)
						//Added for special VR merge Cl2 TF
						||xmarketName!=null && xmarketName.equalsIgnoreCase(ExternalRuleConstant.HUNGARY_MARKET_NAME)||
						xmarketName!=null && xmarketName.equalsIgnoreCase(ExternalRuleConstant.ROMANIA_MARKET_NAME)||
						xmarketName!=null && xmarketName.equalsIgnoreCase(ExternalRuleConstant.SLOVAKIA_MARKET_NAME)||
						xmarketName!=null && ExternalRuleConstant.AEM_MARKETS.contains(xmarketName)||
						xmarketName!=null && xmarketName.equalsIgnoreCase(ExternalRuleConstant.SOUTH_AFRICA_MARKET_NAME))
				{
					for(int i=1;i<vecInput.size();i++)
					{
						sourceparty.getItemsTCRMSuspectBObj().add((TCRMSuspectBObj)(vecInput.elementAt(i)));
					}
					
					ExternalRuleUtil extrUtil=new ExternalRuleUtil();
					extrUtil.matchRulesAdjustForSpecialVR(sourceparty, sourceparty.getControl(), xmarketName);
					return categorizeSuspects(vecInput);
				}
				
				
				//Start of change for removing impact of enabling auto collapse 
				downgradeA1suspectsForRealTime(vecInput,((TCRMPartyBObj)vecInput.get(0)).getControl());
				
				//End of change for removing impact of enabling auto collapse
				
				//Changes for ZA to upgrade when fname & lname matching
				if(xmarketName!=null && xmarketName.equalsIgnoreCase(ExternalRuleConstant.SOUTH_AFRICA_MARKET_NAME)){
					upgradeBSuspectsZA(vecInput);
				}
				return categorizeSuspects(vecInput);
			}
		} 
		//if not use eME, call rule PartyMatchCategoryExtRule
		else {

			Rule oldRule=new PartyMatchCategoryExtRule();
			return oldRule.execute(input,componentObject);

		}
	}

	/**
	 * The same logic from PartyMatchCategoryExtRule is used to categorize 
	 * the suspects according to the following rules:<P>
	 * <UL>
	 * <LI>ReturnAllSuspects == N (AddParty Case):</LI>
	 * <OL>
	 *   <LI>Return all A1, A2 and B if they are found</LI>
	 *   <LI>Return empty vector if no A1, A2 or B is found</LI>
	 * </OL>
	 * <LI>ReturnAllSuspects != N (Create Suspect Case):</LI>
	 * <OL>
	 *   <LI>Return all A1, A2 and B if they are found</LI>
	 *   <LI>Return empty vector if no A1, A2 or B is found</LI>
	 * </OL>
	 * </UL>
	 */
	private Vector<TCRMSuspectBObj> categorizeSuspects(Vector suspectVec){
		Vector<TCRMSuspectBObj> returnSuspects = new Vector<TCRMSuspectBObj>();;

		TCRMPartyBObj partyBObj = (TCRMPartyBObj) suspectVec.elementAt(0);
		String returnAllSuspects = partyBObj.retrieveReturnAllSuspectsIndicator();

		if ("N".equalsIgnoreCase(returnAllSuspects)) {			
			//Returns ALL the suspects except for "C":
			//  1. A1 + A2 + B
			for (int i = 1; i < suspectVec.size(); i++) {
				TCRMSuspectBObj suspect = (TCRMSuspectBObj) suspectVec.elementAt(i);

				String strProcessingAction = suspect.getMatchCategoryCode();
				if (StringUtils.isNonBlank(suspect.getCurrentSuspectCategoryValue())){
					strProcessingAction = suspect.getCurrentSuspectCategoryValue();
				}  

				if ("A1".equalsIgnoreCase(strProcessingAction) 
						|| "A2".equalsIgnoreCase(strProcessingAction)
						|| "B".equalsIgnoreCase(strProcessingAction)) {
					returnSuspects.add(suspect);
				}
			}
		} else { //for  if ("N".equalsIgnoreCase(returnAllSuspects))

			//Returns the following combinations:
			//  1. A1 + A2 + B
			//  2. <Empty>
			Vector<TCRMSuspectBObj> vecAllSuspectsNoC = new Vector<TCRMSuspectBObj>();
			for (int i = 1; i < suspectVec.size(); i++) {
				TCRMSuspectBObj suspect = (TCRMSuspectBObj) suspectVec.elementAt(i);

				String strProcessingAction = suspect.getMatchCategoryCode();
				if (StringUtils.isNonBlank(suspect.getCurrentSuspectCategoryValue())){
					strProcessingAction = suspect.getCurrentSuspectCategoryValue();
				}  

				if ("A1".equalsIgnoreCase(strProcessingAction) || 
						"A2".equalsIgnoreCase(strProcessingAction) ||
						"B".equalsIgnoreCase(strProcessingAction)) {
					vecAllSuspectsNoC.add(suspect);
				}
			}

			returnSuspects = vecAllSuspectsNoC;
		}

		return returnSuspects;
	}


	/**
	 * filters out AUNZ suspects
	 * diff Fname/gender downgraded to B
	 * @param suspectVec
	 * @throws Exception 
	 */
	private void downgradeA1Suspects(Vector suspectVec) throws Exception{

		TCRMPartyBObj partyBObj = (TCRMPartyBObj) suspectVec.elementAt(0);

		String fNamePerson = null;
		String genderPerson = null;
		String fNameSuspect = null;
		String genderSuspect = null;

		//downgrade applicable only for person
		if(partyBObj instanceof XPersonBObjExt)
		{
			XPersonBObjExt xPersonBObj = (XPersonBObjExt)partyBObj;
			TCRMPersonBObj suspectPersonBObj = null;
			fNamePerson = ((TCRMPersonNameBObj)xPersonBObj.getItemsTCRMPersonNameBObj().get(0)).getGivenNameOne();
			genderPerson = xPersonBObj.getGenderType();

			//downgrade applicable only for AUNZ
			if(ExternalRuleConstant.MARKET_NAME_AUSTRALIA.equalsIgnoreCase(xPersonBObj.getXMarketName())
					||ExternalRuleConstant.MARKET_NAME_NEWZEALAND.equalsIgnoreCase(xPersonBObj.getXMarketName())){

				for (int i = 1; i < suspectVec.size(); i++) {
					TCRMSuspectBObj suspect = (TCRMSuspectBObj) suspectVec.elementAt(i);

					//downgrade for A1 only
					if(ExternalRuleConstant.MATCH_CAT_CODE_A1.equalsIgnoreCase(suspect.getMatchCategoryCode()))
					{
						//	System.out.println(suspect.toXML());
						TCRMPartyComponent partyComponent = new TCRMPartyComponent();
						suspectPersonBObj = partyComponent.getPerson(suspect.getSuspectPartyId(), "0", suspect.getControl());

						fNameSuspect = ((TCRMPersonNameBObj)suspectPersonBObj.getItemsTCRMPersonNameBObj().get(0)).getGivenNameOne();
						genderSuspect = suspectPersonBObj.getGenderType();

						//if suspects do not have first name matching down grade to B
						if(StringUtils.isNonBlank(fNamePerson) && !fNamePerson.equalsIgnoreCase(fNameSuspect)){

							suspect.setAdjustedMatchCategoryCode(ExternalRuleConstant.MATCH_CAT_CODE_B);
							suspect.setMatchCategoryAdjustmentType(ExternalRuleConstant.MATCH_CAT_ADJUSTMENT_TYPE_FNAME);
							suspect.setMatchCategoryAdjustmentValue(ExternalRuleConstant.MATCH_CAT_ADJUSTMENT_VALUE_FNAME);

						}
						//if suspects both have gender and do not have gender matching down grade to B
						else if (StringUtils.isNonBlank(genderPerson) && StringUtils.isNonBlank(genderSuspect) && !genderPerson.equalsIgnoreCase(genderSuspect)){

							suspect.setAdjustedMatchCategoryCode(ExternalRuleConstant.MATCH_CAT_CODE_B);
							suspect.setMatchCategoryAdjustmentType(ExternalRuleConstant.MATCH_CAT_ADJUSTMENT_TYPE_GENDER);
							suspect.setMatchCategoryAdjustmentValue(ExternalRuleConstant.MATCH_CAT_ADJUSTMENT_VALUE_GENDER);
						}
					}
				}
			}	
		}
	}
	
	/**
	 * downgrade A1suspects For RealTime for MYS, THA, IND, TUR, AUNZ, KOR
	 * @param suspectVec
	 * @param control
	 */
	private void downgradeA1suspectsForRealTime (Vector suspectVec, DWLControl control){
		
		Boolean isAutoCollapseAllowed = true;
		if(control != null)
			{
			String autocollapse = (String)control.get("AutoCollapse");
			if(autocollapse != null && StringUtils.isNonBlank(autocollapse)){
				if("false".equalsIgnoreCase(autocollapse))
				{
					isAutoCollapseAllowed = false;
				}
			}
			}
		TCRMPersonBObj suspectPersonBObj = null;
		for (int i = 1; i < suspectVec.size(); i++) {
			TCRMSuspectBObj suspect = (TCRMSuspectBObj) suspectVec.elementAt(i);

			//downgrade for A1 only
			if(ExternalRuleConstant.MATCH_CAT_CODE_A1.equalsIgnoreCase(suspect.getMatchCategoryCode()))
			{
				
				//if suspects do not have first name matching down grade to B
				if(!isAutoCollapseAllowed){

					/*suspect.setAdjustedMatchCategoryCode("C");
					suspect.setMatchCategoryAdjustmentType(ExternalRuleConstant.MATCH_CAT_ADJUSTMENT_TYPE_FNAME);
					suspect.setMatchCategoryAdjustmentValue(ExternalRuleConstant.MATCH_CAT_ADJUSTMENT_VALUE_FNAME);
*/
					suspectVec.remove(i);
					i--;
					
				}
				
			}
		}
	}
	
	/**
	 * upgrade ZA person match B to A
	 * fname & lname exact match
	 * @param suspectVec
	 * @throws Exception
	 */
	private void upgradeBSuspectsZA(Vector suspectVec) throws Exception{

		TCRMPartyBObj partyBObj = (TCRMPartyBObj) suspectVec.elementAt(0);

		String fNamePerson = null;
		String lNamePerson = null;
		String fNameSuspect = null;
		String lNameSuspect = null;

		//upgrade applicable only for person
		if(partyBObj instanceof XPersonBObjExt)
		{
			XPersonBObjExt xPersonBObj = (XPersonBObjExt)partyBObj;
			TCRMPersonBObj suspectPersonBObj = null;
			fNamePerson = ((TCRMPersonNameBObj)xPersonBObj.getItemsTCRMPersonNameBObj().get(0)).getGivenNameOne();
			lNamePerson = ((TCRMPersonNameBObj)xPersonBObj.getItemsTCRMPersonNameBObj().get(0)).getLastName();

			//upgrade applicable only for ZA
			if(ExternalRuleConstant.SOUTH_AFRICA_MARKET_NAME.equalsIgnoreCase(xPersonBObj.getXMarketName())){

				for (int i = 1; i < suspectVec.size(); i++) {
					TCRMSuspectBObj suspect = (TCRMSuspectBObj) suspectVec.elementAt(i);

					//upgrade for B only
					if(ExternalRuleConstant.MATCH_CAT_CODE_B.equalsIgnoreCase(suspect.getMatchCategoryCode()))
					{
						
						TCRMPartyComponent partyComponent = new TCRMPartyComponent();
						suspectPersonBObj = partyComponent.getPerson(suspect.getSuspectPartyId(), "0", suspect.getControl());

						fNameSuspect = ((TCRMPersonNameBObj)suspectPersonBObj.getItemsTCRMPersonNameBObj().get(0)).getGivenNameOne();
						lNameSuspect = ((TCRMPersonNameBObj)suspectPersonBObj.getItemsTCRMPersonNameBObj().get(0)).getLastName();

						//if suspects have first name & last name matching up grade to A1
						if(StringUtils.isNonBlank(fNamePerson) && StringUtils.isNonBlank(lNamePerson) 
								&& fNamePerson.equalsIgnoreCase(fNameSuspect) && lNamePerson.equalsIgnoreCase(lNameSuspect)){

							suspect.setAdjustedMatchCategoryCode(ExternalRuleConstant.MATCH_CAT_CODE_A1);
							suspect.setMatchCategoryAdjustmentType(ExternalRuleConstant.MATCH_CAT_ADJUSTMENT_TYPE_FNAME_LNAME_ZA);
							suspect.setMatchCategoryAdjustmentValue(ExternalRuleConstant.MATCH_CAT_ADJUSTMENT_VALUE_FNAME_LNAME_ZA);

						}
						
					}
				}
			}	
		}
	}
	
	
	
	
	/* For KOR Simplification,
	 * If Suspect catagoty is B and DOB score is negative 
	 * then add the same (-)score into main score (+) and 
	 * if score is > A1 category score (11) then upgrade the category.
	 */
	
	private void changeDOBScoreKOR(Vector suspectVec) throws Exception{
		
		//Vector<TCRMPersonBObj>�v = new Vector<TCRMPersonBObj>();
		
		DWLControl control = ((TCRMPartyBObj)suspectVec.get(0)).getControl();
		DWLResponse matchPartiesResponse = null;
		DWLTransactionPersistent matchPartiesRequest = new DWLTransactionPersistent();
		
		
		DWLTxnBP dwlTxnBP = new DWLTxnBP();
		DWLResponse txnResponse = null;
		DWLTransactionPersistent transactionRequest = new DWLTransactionPersistent();
		
		if(null!=suspectVec && suspectVec.size()>1){
			TCRMPartyBObj partyBObj = (TCRMPartyBObj) suspectVec.elementAt(0);
			if(partyBObj instanceof XPersonBObjExt){
			
			for (int i=1;i<suspectVec.size();i++){
				TCRMPartyListBObj matchPartiesInput = new TCRMPartyListBObj();
		
				TCRMSuspectBObj suspect = (TCRMSuspectBObj) suspectVec.get(i);
				
				if(!ExternalRuleConstant.MATCH_CAT_CODE_B.equalsIgnoreCase(suspect.getMatchCategoryCode())){
					continue;
				}
				
				
				TCRMPersonBObj Party = new TCRMPersonBObj();
				Party.setPartyId(suspect.getPartyId());
				Party.setPartyActiveIndicator(null);
				Party.setControl(control);
				matchPartiesInput.setControl(control);
				//System.out.println(suspectInput.getPartyId());
				(matchPartiesInput.getItemsTCRMPartyBObj()).add(Party);
								
				TCRMPersonBObj suspectParty = new TCRMPersonBObj();
				suspectParty.setPartyId(suspect.getSuspectPartyId());
				suspectParty.setPartyActiveIndicator(null);
				suspectParty.setControl(control);
				//System.out.println(suspect.getPartyId());
				(matchPartiesInput.getItemsTCRMPartyBObj()).add(suspectParty);

				transactionRequest.setTxnControl(control);
				transactionRequest.setTxnType("matchParties");
				transactionRequest.setTxnTopLevelObject(matchPartiesInput);
			
				txnResponse = (DWLResponse) dwlTxnBP.execute(transactionRequest);
				if(txnResponse != null && txnResponse.getStatus().getStatus() != DWLStatus.FATAL){
				Vector<TCRMSuspectBObj> suspectresponsebobj = (Vector<TCRMSuspectBObj>) txnResponse.getData();
				
				
				if(suspectresponsebobj.size()>0){
				TCRMSuspectBObj tempsuspect = suspectresponsebobj.get(0);
				
				if(tempsuspect.getItemsMatchComparisonDetailsBObj().size()>0){
				MatchComparisonDetailsBObj tempmatchcomp = tempsuspect.getItemsMatchComparisonDetailsBObj().get(0);
				Vector<ComparisonFunctionDetailsBObj> tempcompfun = tempmatchcomp.getItemsComparisonFunctionDetailsBObj();
				
				
				for(int j =0; j<tempcompfun.size();j++){
					if(tempcompfun.get(j).getComparisonFunctionCode().equalsIgnoreCase("DOB")){
						
						String overall_score = tempsuspect.getWeight();
						double double_overall_score = Double.parseDouble(overall_score);
						
						String dobscore_string = tempcompfun.get(j).getWeight();
						double dobscore_double=Double.parseDouble(dobscore_string);
						
						
						if(dobscore_double < 0 && ExternalRuleConstant.MATCH_CAT_CODE_B.equalsIgnoreCase(suspect.getMatchCategoryCode())){
							
							
							double new_overall_score_double = double_overall_score - dobscore_double;
							String new_overall_score_string = Double.toString(new_overall_score_double);
							tempcompfun.get(j).setWeight("0");
							
							suspect.setWeight(new_overall_score_string);
							
							if(new_overall_score_double >= 11){
							suspect.setAdjustedMatchCategoryCode(ExternalRuleConstant.MATCH_CAT_CODE_A1);
							break;

							
							}
							
						}
					}
				}}
				}
				}
				
				
				
				

			}
		}
	}

}
	
	
	
	
	
	
}
