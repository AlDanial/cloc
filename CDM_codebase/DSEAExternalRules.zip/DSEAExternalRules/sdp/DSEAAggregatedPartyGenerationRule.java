/* _______________________________________________________ {COPYRIGHT-TOP} _____
* Licensed Materials - Property of IBM
* Restricted Materials of IBM
*
* 5725-E59
*
* (C) Copyright IBM Corp. 2006, 2014  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
* ________________________________________________________ {COPYRIGHT-END} _____*/
package com.ibm.daimler.dsea.extrules.sdp;

import java.util.Vector;

import com.dwl.base.DWLControl;
import com.dwl.base.IDWLErrorMessage;
import com.dwl.base.error.DWLError;
import com.dwl.base.error.DWLStatus;
import com.dwl.base.exception.DWLBaseException;
import com.dwl.base.externalrule.Rule;
import com.dwl.base.logging.DWLLoggerManager;
import com.dwl.base.logging.IDWLLogger;
import com.dwl.tcrm.common.TCRMErrorCode;
import com.dwl.tcrm.common.TCRMRecordFilter;
import com.dwl.tcrm.coreParty.component.TCRMPartyBObj;
import com.dwl.tcrm.coreParty.constant.TCRMCoreComponentID;
import com.dwl.tcrm.coreParty.constant.TCRMCoreErrorReasonCode;
import com.dwl.tcrm.coreParty.constant.TCRMCorePropertyKeys;
import com.dwl.tcrm.coreParty.interfaces.IParty;
import com.dwl.tcrm.utilities.TCRMClassFactory;
import com.ibm.daimler.dsea.component.XOrgBObjExt;
import com.ibm.daimler.dsea.component.XPersonBObjExt;
import com.ibm.daimler.dsea.extrules.constant.ExternalRuleConstant;
/**
 * Rule 113 for aggregating parties into a single view using surviving rules:
 * Using the business key elements and Last Update Date Field, this method
 * combines the information on the first and second parties and then create a
 * party object which holds the most recent information of those input parties.
 */
public class DSEAAggregatedPartyGenerationRule extends Rule {
    public static final String copyright =  "Licensed Materials -- Property of IBM\n(c) Copyright IBM Corp. 2006, 2014\nUS Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.";


	protected final static IDWLLogger logger = DWLLoggerManager.getLogger(DSEAAggregatedPartyGenerationRule.class);

	protected String ruleName = "AggregatePartyGenerationRules";

	protected String debugStr = "External Java Rule 113 " + ruleName + ": ";

	private boolean bAggregateAdminContEquiv;

	private boolean bAggregateAlerts = true;

	private boolean bAggregatePartyRelationships = true;

	IParty partyComp = null;

	/**
	 * @param input
	 *            A <code>Vector</code> of <code>TCRMPartyBOBj</code>s (with
	 *            relationships, if any)
	 * @return TCRMPartyListBObj (party objects with input party ids, last party
	 *         aggregated view)
	 */
	public Object execute(Object input, Object componentObject)
			throws Exception {
		debugOut(debugStr + "Entering Rule");

		Vector vecParties = (Vector) input;
		Vector vecPartiesWithRelationships = new Vector();

		partyComp = (IParty) TCRMClassFactory
				.getTCRMComponent(TCRMCorePropertyKeys.PARTY_COMPONENT);

		DWLStatus status = new DWLStatus();
		status.setStatus(DWLStatus.SUCCESS);

		TCRMPartyBObj aggregatedPartyView = null;

		Vector vecRet = new Vector();
		DWLControl dwlControl = null;

		boolean aggregatePartyRelationships = false;

		try {
			dwlControl = ((TCRMPartyBObj) vecParties.elementAt(0)).getControl();
			TCRMPartyBObj aggPartyCandidate = null;

			for (int idx1 = 0; idx1 < vecParties.size(); idx1++) {
				aggPartyCandidate = (TCRMPartyBObj) vecParties.elementAt(idx1);

				if (isAggregateAlerts()) {
					debugOut(debugStr + "Retrieving Alerts");
					Vector vec = ((IParty) partyComp).getAllPartyAlerts(
							aggPartyCandidate.getPartyId(),
							TCRMRecordFilter.ACTIVE, dwlControl);

					if (vec != null) {
						(aggPartyCandidate.getItemsTCRMAlertBObj()).addAll(vec);
					}
				}

				if (isAggregateAdminContEquiv()) {
					debugOut(debugStr + "Retrieving AdminContEquiv");

					Vector vec = ((IParty) partyComp).getAllPartyAdminSysKeys(
							aggPartyCandidate.getPartyId(), dwlControl);
					(aggPartyCandidate.getItemsTCRMAdminContEquivBObj())
							.addAll(vec);
				}

				aggregatePartyRelationships = isAggregatePartyRelationships();

				if (aggregatePartyRelationships) {
					// First get all the relationships for the party
					// Put the partyBObj which has partyRelationship to a
					// separate vector
					if (aggPartyCandidate.getItemsTCRMPartyRelationshipBObj() != null
							&& aggPartyCandidate
									.getItemsTCRMPartyRelationshipBObj().size() > 0) {
						vecPartiesWithRelationships.add(aggPartyCandidate);
					}
				}
			}

			// If inquiry level does not include party relationship, so we don't
			// need to run collapsePartyRelationshipsSurvivingRules
			// boolean isInquiryLevelIncludePartyRelationship =
			// checkInquiryLevelIncludePartyRelationship(inquiryLevel,
			// dwlControl);
			Vector rel = null;

			if (aggregatePartyRelationships) {
				if (vecPartiesWithRelationships.size() > 0) {
					//add source party in the end of vecPartiesWithRelationships
					TCRMPartyBObj sourceParty=(TCRMPartyBObj)vecParties.get(0);
					vecPartiesWithRelationships.add(sourceParty);
					rel = partyComp.collapsePartyRelationshipsSurvivingRules(vecPartiesWithRelationships);
				}
			}
			
			// For Market Check
			TCRMPartyBObj vecParty = (TCRMPartyBObj) vecParties.get(0);
			String partyType = vecParty.getPartyType();
			String xMarketName = null;
			if(ExternalRuleConstant.PERSON_ORG_CODE_P.equalsIgnoreCase(partyType))
			{
				XPersonBObjExt vecPerson = (XPersonBObjExt)vecParty;
				xMarketName = vecPerson.getXMarketName();
			}
			else if(ExternalRuleConstant.PERSON_ORG_CODE_O.equalsIgnoreCase(partyType))
			{
				XOrgBObjExt vecOrg = (XOrgBObjExt)vecParty;
				xMarketName = vecOrg.getXMarketName();
			}
			
			if(ExternalRuleConstant.MARKET_NAME_AUSTRALIA.equalsIgnoreCase(xMarketName))
			{
				//for Australia
				SurvivorshipRuleUtilAus survivorshipRuleUtilAus = new SurvivorshipRuleUtilAus();
				Vector v = survivorshipRuleUtilAus.collapseObjectsSurvivingRules(vecParties, true);;
				aggregatedPartyView = (TCRMPartyBObj) v.elementAt(0);
			}
			else if(ExternalRuleConstant.MARKET_NAME_NEWZEALAND.equalsIgnoreCase(xMarketName))
					{
				//for New Zaealand
				SurvivorshipRuleUtilAus survivorshipRuleUtilAus = new SurvivorshipRuleUtilAus();
				Vector v = survivorshipRuleUtilAus.collapseObjectsSurvivingRules(vecParties, true);;
				aggregatedPartyView = (TCRMPartyBObj) v.elementAt(0);
					}
			else if(ExternalRuleConstant.MARKET_NAME_INDIA.equalsIgnoreCase(xMarketName))
			{
				//for India 
				SurvivorshipRuleUtilIND survivorshipRuleUtilIND = new SurvivorshipRuleUtilIND();
				Vector v = survivorshipRuleUtilIND.collapseObjectsSurvivingRulesIND(vecParties, true);;
				aggregatedPartyView = (TCRMPartyBObj) v.elementAt(0);
			}
			//May 28, 2018 : Added by Diparnab for Turkey : Start
			else if (ExternalRuleConstant.MARKET_NAME_TURKEY.equalsIgnoreCase(xMarketName))
			{
				SurvivorshipRuleUtilTUR survivorshipRuleUtilTUR = new SurvivorshipRuleUtilTUR();
				Vector v = survivorshipRuleUtilTUR.collapseObjectsSurvivingRules(vecParties, true);
				aggregatedPartyView = (TCRMPartyBObj) v.elementAt(0);
				
			}
			
			//May 28, 2018 : Added by Diparnab for Turkey : End
			
			//Aug 28, 2018 : Added by Pushpraj for JPN : Start
			else if (ExternalRuleConstant.JAPAN_MARKET_NAME.equalsIgnoreCase(xMarketName))
			{
				SurvivorshipRuleUtilJPN survivorshipRuleUtilJPN=new SurvivorshipRuleUtilJPN();
				Vector v=survivorshipRuleUtilJPN.collapseObjectsSurvivingRules(vecParties, true);
				aggregatedPartyView=(TCRMPartyBObj) v.elementAt(0);
			}
			//Aug 28, 2018 : Added by Pushpraj for JPN : End
			else if(ExternalRuleConstant.AEM_MARKETS.contains(xMarketName) 
					&& !ExternalRuleConstant.MARKET_NAME_MIDDLEEAST.equalsIgnoreCase(xMarketName)
					)
			{
				SuvivorshipRuleUtilAEM survivorshipRuleUtilAEM=new SuvivorshipRuleUtilAEM();
				Vector v=survivorshipRuleUtilAEM.collapseObjectsSurvivingRules(vecParties, true);
				aggregatedPartyView=(TCRMPartyBObj) v.elementAt(0);
				
			}
			
			else if(ExternalRuleConstant.MARKET_NAME_MIDDLEEAST.equalsIgnoreCase(xMarketName))
			{
				SurvivorshipRuleUtilME survivorshipRuleUtilME=new SurvivorshipRuleUtilME();
				Vector v=survivorshipRuleUtilME.collapseObjectsSurvivingRules(vecParties, true);
				aggregatedPartyView=(TCRMPartyBObj) v.elementAt(0);
				
			} 
			else if(ExternalRuleConstant.SOUTH_AFRICA_MARKET_NAME.contains(xMarketName))
			{
				SuvivorshipRuleUtilZA suvivorshipRuleUtilZA =new SuvivorshipRuleUtilZA();
				Vector v=suvivorshipRuleUtilZA.collapseObjectsSurvivingRules(vecParties, true);
				aggregatedPartyView=(TCRMPartyBObj) v.elementAt(0);
				
			} 
			else
			{	// for MYS & THA
				if(ExternalRuleConstant.MARKET_NAME_THAILAND.contains(xMarketName))
				{
					SurvivorshipRuleUtilTHA survivorshipRuleUtilTHA = new SurvivorshipRuleUtilTHA();
					Vector v = survivorshipRuleUtilTHA.collapseObjectsSurvivingRules(vecParties, true);;
					aggregatedPartyView = (TCRMPartyBObj) v.elementAt(0);
				}
				
				else if(ExternalRuleConstant.MARKET_NAME_MALAYSIA.contains(xMarketName))
				{
					SurvivorshipRuleUtilMYS survivorshipRuleUtilMYS = new SurvivorshipRuleUtilMYS();
					Vector v = survivorshipRuleUtilMYS.collapseObjectsSurvivingRules(vecParties, true);;
					aggregatedPartyView = (TCRMPartyBObj) v.elementAt(0);	
				}
			}
			
			
			/*SurvivorshipRuleUtil survivorshipRuleUtil = new SurvivorshipRuleUtil();
			Vector v = survivorshipRuleUtil.collapseObjectsSurvivingRules(vecParties, true);;

			aggregatedPartyView = (TCRMPartyBObj) v.elementAt(0);*/

			// Create list of party ids.. then the last party being the
			// aggregated party view.
			aggregatedPartyView.setMandatorySearchDone("Y");
			aggregatedPartyView.setControl(dwlControl);

			// If there only one party having partyRel, add the partyRel to the
			// view bobj
			if (rel != null && rel.size() > 0) {
				aggregatedPartyView.getItemsTCRMPartyRelationshipBObj()
						.removeAllElements();
				aggregatedPartyView.getItemsTCRMPartyRelationshipBObj().addAll(
						rel);
			} else { // If there are no relationships returned, the view bobj
				// should not have any party relationships
				aggregatedPartyView.getItemsTCRMPartyRelationshipBObj()
						.removeAllElements();
			}

			// Construct the returned vector - including all the passed in
			// partyBObj (only partyId needed for returning) and
			// aggregatedPartyView
			TCRMPartyBObj partyBObj = null;
			TCRMPartyBObj tmpPartyBObj = null;

			for (int i = 0; i < vecParties.size(); i++) {
				partyBObj = (TCRMPartyBObj) vecParties.elementAt(i);

				tmpPartyBObj = new TCRMPartyBObj();
				tmpPartyBObj.setPartyId(partyBObj.getPartyId());
				//PMR36896,7TD,000
				tmpPartyBObj.setPartyType(partyBObj.getPartyType());				
				vecRet.add(tmpPartyBObj);
			}

			// Add the aggregated partyBObj to the list returned
			vecRet.add(aggregatedPartyView);
		} catch (DWLBaseException ex) {
            // Added by AutomatedFix
            com.dwl.base.util.DWLExceptionUtils.log(ex);
			status = ex.getStatus();
		} catch (Exception ex) {
            // Added by AutomatedFix
            com.dwl.base.util.DWLExceptionUtils.log(ex);
			status = addError(dwlControl, TCRMErrorCode.READ_RECORD_ERROR,
					TCRMCoreErrorReasonCode.GET_AGGREGATED_PARTY_VIEW_FAILED,
					ex.getMessage());
		}

		aggregatedPartyView.setStatus(status);

		return vecRet;
	}

	/**
	 * @return Holding the error messages if there are any
	 */
	protected DWLStatus addError(DWLControl theControl, String sErrorCode,
			String sReasonCode, String sDetail) {
		IDWLErrorMessage errHandler = TCRMClassFactory.getErrorHandler();

		DWLError error = errHandler.getErrorMessage(
				TCRMCoreComponentID.PARTY_COMPONENT, sErrorCode, sReasonCode,
				theControl, new String[0]);

		error.setDetail(sDetail);
		DWLStatus status = new DWLStatus();
		status.addError(error);
		status.setStatus(DWLStatus.FATAL);
		return status;
	}

	/**
	 * @param tmpCollapseAlerts
	 *            Set bCollapseAlerts to "true" if collapse partyAlerts is
	 *            desired otherwsie "false"
	 */
	public void setCollapseAlerts(boolean tmpCollapseAlerts) {
		bAggregateAlerts = tmpCollapseAlerts;
	}

	public boolean isAggregateAlerts() {
		return bAggregateAlerts;
	}

	/**
	 * Set bCollapseAdminContEquiv to "true" if collapse AdminContEquiv is
	 * desired otherwsie "false"
	 */
	public void setAggregateAdminContEquiv(boolean tmpAggregateAdminContEquiv) {
		bAggregateAdminContEquiv = tmpAggregateAdminContEquiv;
	}

	protected boolean isAggregateAdminContEquiv() {
		return bAggregateAdminContEquiv;
	}

	protected boolean isAggregatePartyRelationships() {
		return bAggregatePartyRelationships;
	}

	protected void debugOut(String str) {
//		System.out.println(str);
	}

}
