package com.ibm.daimler.dsea.extrules.sdp;

import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.Vector;





import com.dwl.base.DWLCommon;
import com.dwl.base.DWLControl;
import com.dwl.base.DWLResponse;
import com.dwl.base.constant.DWLControlKeys;
import com.dwl.base.db.SQLQuery;
import com.dwl.base.error.DWLStatus;
import com.dwl.base.exception.DWLBaseException;
import com.dwl.base.util.DWLClassFactory;
import com.dwl.base.util.DWLExceptionUtils;
import com.dwl.base.util.DWLFunctionUtils;
import com.dwl.management.ManagementException;
import com.dwl.management.config.client.Configuration;
import com.dwl.management.config.repository.ConfigurationRepositoryException;
import com.dwl.tcrm.common.TCRMControlKeys;
import com.dwl.tcrm.coreParty.component.TCRMAdminContEquivBObj;
import com.dwl.tcrm.coreParty.component.TCRMPartyBObj;
import com.dwl.tcrm.coreParty.component.TCRMPartyPrivPrefBObj;
import com.dwl.tcrm.coreParty.component.TCRMPersonBObj;
import com.dwl.tcrm.utilities.DateFormatter;
import com.dwl.tcrm.utilities.StringUtils;
import com.dwl.unifi.tx.exception.BusinessProxyException;
import com.ibm.daimler.dsea.component.DSEAAdditionsExtsComponent;
import com.ibm.daimler.dsea.component.XAddressBObjExt;
import com.ibm.daimler.dsea.component.XAddressGroupBObjExt;
import com.ibm.daimler.dsea.component.XContEquivBObjExt;
import com.ibm.daimler.dsea.component.XContactMethodBObjExt;
import com.ibm.daimler.dsea.component.XContactMethodGroupBObjExt;
import com.ibm.daimler.dsea.component.XIdentifierBObjExt;
import com.ibm.daimler.dsea.component.XOrgBObjExt;
import com.ibm.daimler.dsea.component.XOrgNameBObjExt;
import com.ibm.daimler.dsea.component.XPersonBObjExt;
import com.ibm.daimler.dsea.component.XPersonNameBObjExt;
import com.ibm.daimler.dsea.component.XPreferenceBObj;
import com.ibm.daimler.dsea.component.XPrivacyAgreementBObj;


import com.ibm.daimler.dsea.component.XRetailerBObj;
import com.ibm.daimler.dsea.extrules.constant.ExternalRuleConstant;
import com.ibm.daimler.dsea.extrules.util.ExternalRuleUtil;
import com.ibm.mdm.common.codetype.interfaces.CodeTypeComponentHelper;
import com.ibm.mdm.common.codetype.obj.CodeTypeBObj;



/**
 * @author pushkuma
 *
 */

public class SurvivorshipRuleUtilJPN {

	private final static com.dwl.base.logging.IDWLLogger logger = com.dwl.base.logging.DWLLoggerManager.getLogger(SurvivorshipRuleUtilJPN.class);
	@SuppressWarnings("unchecked")
	public Vector collapseObjectsSurvivingRules(Vector vecDWLCommons,
			boolean bReturnTheMostRecentRootBObjOnly) throws DWLBaseException, Exception {
		Vector vecSurviveDWLCommons = new Vector();
		//logger.info("Inside Survivorship Rule Util JPN");
		try {
			DWLCommon source = (DWLCommon) vecDWLCommons.get(0);

			TCRMPartyBObj newParty = null;
			
			

			String personOrgCode = null;

			if (source instanceof TCRMPartyBObj) {

				DWLControl control = source.getControl();
				
				boolean allDSCParty=false;
				
				boolean isRealTime=false;

				@SuppressWarnings("rawtypes")
				Vector<TCRMPartyBObj> vecAllParty = new Vector<TCRMPartyBObj>();

				TCRMPartyBObj firstparty = (TCRMPartyBObj) vecDWLCommons.get(0);
				TCRMPartyBObj secondParty = (TCRMPartyBObj) vecDWLCommons.get(1);
				/*System.out.println("FirstParty Xml" + firstparty.toXML("TCRM", "MDMDomains.xsd", 0, null, false));
				System.out.println("SecondParty Xml" + secondParty.toXML("TCRM", "MDMDomains.xsd", 0, null, false));*/
				personOrgCode = firstparty.getPartyType();

				newParty = (TCRMPartyBObj) Class.forName(
						firstparty.getClass().getName()).newInstance();

				// For Person Entity
				if (personOrgCode
						.equalsIgnoreCase(ExternalRuleConstant.PERSON_ORG_CODE_P)) {
					//logger.info("Inside Survivorship Rule Util JPN : Person");
					
					//isRealTime=

					Collections.sort(vecDWLCommons,
							new Comparator<XPersonBObjExt>() {// Ascending sort
																// - for delta
																// load
								public int compare(XPersonBObjExt party1,
										XPersonBObjExt party2) {
									if (party1.getXLastModifiedSystemDate() == null
											|| party2
													.getXLastModifiedSystemDate() == null)
										return 0;
									return party1
											.getXLastModifiedSystemDate()
											.compareTo(
													party2.getXLastModifiedSystemDate());
								}
							});
					Collections.reverse(vecDWLCommons);// Descending sort
					Iterator itParty = vecDWLCommons.iterator();
					while (itParty.hasNext()) {

						TCRMPartyBObj newParty1 = new TCRMPartyBObj();
						newParty1 = (TCRMPartyBObj) itParty.next();
						vecAllParty.add(newParty1);
					}
					
					
					//setting UCID from Identifier to Contequiv
					setUCIDObj(vecAllParty,control);
					
					if(((XPersonBObjExt)vecAllParty.firstElement()).getXBatchInd().equalsIgnoreCase(ExternalRuleConstant.BATCH_IND_N))
					{
						isRealTime=true;
					}
					
					allDSCParty=checkForDSCPartyData(vecAllParty,control);

					XPersonBObjExt newPartyBObj = (XPersonBObjExt) newParty;

					XPersonBObjExt survivedBOBj = sortParties(vecAllParty,newPartyBObj, allDSCParty, control);
					
					/*if(survivedBOBj.getXBatchInd().equalsIgnoreCase(ExternalRuleConstant.BATCH_IND_N))
					{
					isRealTime=true;
					}*/
					Vector<XContEquivBObjExt> allSlaveKeys=processSlaveSourceKeys(vecAllParty,control);
					
				
					HashMap<String, HashMap> finalPersonDetlsMap = survivedPersonDetails(vecAllParty, allDSCParty, isRealTime, control);

					HashMap<String, XPersonNameBObjExt> personNameMap = new HashMap<String, XPersonNameBObjExt>();
					HashMap<String, XAddressGroupBObjExt> partyAddressMap = new HashMap<String, XAddressGroupBObjExt>();
					HashMap<String, XIdentifierBObjExt> partyIdentMap = new HashMap<String, XIdentifierBObjExt>();
					HashMap<String, XContactMethodGroupBObjExt> partyContMethMap = new HashMap<String, XContactMethodGroupBObjExt>();
					HashMap<String, TCRMAdminContEquivBObj> partyAdminConteqMap = new HashMap<String, TCRMAdminContEquivBObj>();
					HashMap<String, TCRMPartyPrivPrefBObj> partyPrivacyPrefMap = new HashMap<String, TCRMPartyPrivPrefBObj>();
					HashMap<String, XPreferenceBObj> contactMethodPrefMap=new HashMap<String, XPreferenceBObj>();
					HashMap<String, XPreferenceBObj> addressPrefMap=new HashMap<String, XPreferenceBObj>();
					Vector<XPersonNameBObjExt> vecSurvivedPersonNameBOBj = new Vector<XPersonNameBObjExt>();
					Vector<XAddressGroupBObjExt> vecSurvivedPartyAddrBOBj = new Vector<XAddressGroupBObjExt>();
					Vector<XIdentifierBObjExt> vecSurvivedPartyIdenBOBj = new Vector<XIdentifierBObjExt>();
					Vector<XContactMethodGroupBObjExt> vecSurvivedPartyContMethBOBj = new Vector<XContactMethodGroupBObjExt>();
					Vector<TCRMAdminContEquivBObj> vecSurvivedPartyAdminContBOBj = new Vector<TCRMAdminContEquivBObj>();
					Vector<TCRMPartyPrivPrefBObj> vecSurvivedPartyPrivacyPrefBOBj = new Vector<TCRMPartyPrivPrefBObj>();

					personNameMap = finalPersonDetlsMap
							.get(ExternalRuleConstant.SURVIVED_MAP_NAME);
					partyAddressMap = finalPersonDetlsMap
							.get(ExternalRuleConstant.SURVIVED_MAP_ADDRESS);
					partyIdentMap = finalPersonDetlsMap
							.get(ExternalRuleConstant.SURVIVED_MAP_IDENTIFIER);
					partyContMethMap = finalPersonDetlsMap
							.get(ExternalRuleConstant.SURVIVED_MAP_CONTACTMETHOD);
					partyAdminConteqMap = finalPersonDetlsMap
							.get(ExternalRuleConstant.SURVIVED_MAP_CONTEQUIV);

					for (Map.Entry<String, XPersonNameBObjExt> entry : personNameMap
							.entrySet()) {
						vecSurvivedPersonNameBOBj.add(entry.getValue());
					}
					for (Map.Entry<String, XAddressGroupBObjExt> entry : partyAddressMap
							.entrySet()) {
						vecSurvivedPartyAddrBOBj.add(entry.getValue());
					}

					for (Map.Entry<String, XIdentifierBObjExt> entry : partyIdentMap
							.entrySet()) {
						vecSurvivedPartyIdenBOBj.add(entry.getValue());
					}
					for (Map.Entry<String, XContactMethodGroupBObjExt> entry : partyContMethMap
							.entrySet()) {
						vecSurvivedPartyContMethBOBj.add(entry.getValue());
					}
					for (Map.Entry<String, TCRMAdminContEquivBObj> entry : partyAdminConteqMap
							.entrySet()) {
						vecSurvivedPartyAdminContBOBj.add(entry.getValue());
					}
					//Add all Slave Keys to the survived Party Vector
					vecSurvivedPartyAdminContBOBj.addAll(allSlaveKeys);

					for (Map.Entry<String, TCRMPartyPrivPrefBObj> entry : partyPrivacyPrefMap
							.entrySet()) {
						vecSurvivedPartyPrivacyPrefBOBj.add(entry.getValue());
					}

					// Change for Preferred Address Indicator
					handlePrefAddress(vecSurvivedPartyAddrBOBj, addressPrefMap);

					// Change for Preferred Contact Method Indicator 05-12-2017
					handlePrefContactMethod(vecSurvivedPartyContMethBOBj,contactMethodPrefMap);

					if (vecSurvivedPersonNameBOBj.size() > 0
							|| vecSurvivedPersonNameBOBj != null) {

						((TCRMPersonBObj) survivedBOBj)
								.getItemsTCRMPersonNameBObj().clear();
						((TCRMPersonBObj) survivedBOBj)
								.getItemsTCRMPersonNameBObj().addAll(
										vecSurvivedPersonNameBOBj);
					}
					if (vecSurvivedPartyAddrBOBj.size() > 0
							|| vecSurvivedPartyAddrBOBj != null) {
						((TCRMPersonBObj) survivedBOBj)
								.getItemsTCRMPartyAddressBObj().clear();
						((TCRMPersonBObj) survivedBOBj)
								.getItemsTCRMPartyAddressBObj().addAll(
										vecSurvivedPartyAddrBOBj);
					}
					if (vecSurvivedPartyIdenBOBj.size() > 0
							|| vecSurvivedPartyIdenBOBj != null) {

						((TCRMPersonBObj) survivedBOBj)
								.getItemsTCRMPartyIdentificationBObj().clear();
						((TCRMPersonBObj) survivedBOBj)
								.getItemsTCRMPartyIdentificationBObj().addAll(
										vecSurvivedPartyIdenBOBj);
					}
					if (vecSurvivedPartyContMethBOBj.size() > 0
							|| vecSurvivedPartyContMethBOBj != null) {
						((TCRMPersonBObj) survivedBOBj)
								.getItemsTCRMPartyContactMethodBObj().clear();
						((TCRMPersonBObj) survivedBOBj)
								.getItemsTCRMPartyContactMethodBObj().addAll(
										vecSurvivedPartyContMethBOBj);
					}
					if (vecSurvivedPartyAdminContBOBj.size() > 0
							|| vecSurvivedPartyAdminContBOBj != null) {
						((TCRMPersonBObj) survivedBOBj)
								.getItemsTCRMAdminContEquivBObj().clear();
						((TCRMPersonBObj) survivedBOBj)
								.getItemsTCRMAdminContEquivBObj().addAll(
										vecSurvivedPartyAdminContBOBj);
					}
					/*if (vecSurvivedPartyPrivacyPrefBOBj.size() > 0
							|| vecSurvivedPartyPrivacyPrefBOBj != null) {
						((TCRMPersonBObj) survivedBOBj)
								.getItemsTCRMPartyPrivPrefBObj().clear();
						((TCRMPersonBObj) survivedBOBj)
								.getItemsTCRMPartyPrivPrefBObj().addAll(
										vecSurvivedPartyPrivacyPrefBOBj);
					}*/

					vecSurviveDWLCommons.add(survivedBOBj);

				}

				// For Org Entity

				else if (personOrgCode
						.equalsIgnoreCase(ExternalRuleConstant.PERSON_ORG_CODE_O)) {

					Collections.sort(vecDWLCommons,
							new Comparator<XOrgBObjExt>() {// Ascending sort -
															// for delta load
								public int compare(XOrgBObjExt party1,
										XOrgBObjExt party2) {
									if (party1.getXLastModifiedSystemDate() == null
											|| party2
													.getXLastModifiedSystemDate() == null)
										return 0;
									return party1
											.getXLastModifiedSystemDate()
											.compareTo(
													party2.getXLastModifiedSystemDate());
								}
							});
					Collections.reverse(vecDWLCommons);// Descending sort
					Iterator itParty = vecDWLCommons.iterator();
					while (itParty.hasNext()) {

						TCRMPartyBObj newParty1 = new TCRMPartyBObj();
						newParty1 = (TCRMPartyBObj) itParty.next();
						vecAllParty.add(newParty1);
					}
					
					
					setUCIDObj(vecAllParty,control);
					
					if(((XOrgBObjExt)vecAllParty.firstElement()).getXBatchInd().equalsIgnoreCase(ExternalRuleConstant.BATCH_IND_N))
					{
						isRealTime=true;
					}
					
					allDSCParty=checkForDSCPartyData(vecAllParty,control);
					
					TCRMPartyBObj survivedBOBj = sortOrgParties(vecAllParty,
							newParty,allDSCParty, control);

					HashMap<String, HashMap> finalOrgDetlsMap = survivedOrgDetails(
							vecAllParty, allDSCParty,isRealTime, control);
					HashMap<String, XOrgNameBObjExt> orgNameMap = new HashMap<String, XOrgNameBObjExt>();
					HashMap<String, XAddressGroupBObjExt> partyAddressMap = new HashMap<String, XAddressGroupBObjExt>();
					HashMap<String, XIdentifierBObjExt> partyIdentMap = new HashMap<String, XIdentifierBObjExt>();
					HashMap<String, XContactMethodGroupBObjExt> partyContMethMap = new HashMap<String, XContactMethodGroupBObjExt>();
					HashMap<String, TCRMAdminContEquivBObj> partyAdminConteqMap = new HashMap<String, TCRMAdminContEquivBObj>();
					HashMap<String, TCRMAdminContEquivBObj> partyAdminConteqMap1 = new HashMap<String, TCRMAdminContEquivBObj>();
					HashMap<String, TCRMPartyPrivPrefBObj> partyPrivacyPrefMap = new HashMap<String, TCRMPartyPrivPrefBObj>();
					HashMap<String, XPreferenceBObj> contactMethodPrefMap=new HashMap<String, XPreferenceBObj>();
					HashMap<String, XPreferenceBObj> addressPrefMap=new HashMap<String, XPreferenceBObj>();
					Vector<XOrgNameBObjExt> vecSurvivedOrgNameBOBj = new Vector<XOrgNameBObjExt>();
					Vector<XAddressGroupBObjExt> vecSurvivedPartyAddrBOBj = new Vector<XAddressGroupBObjExt>();
					Vector<XIdentifierBObjExt> vecSurvivedPartyIdenBOBj = new Vector<XIdentifierBObjExt>();
					Vector<XContactMethodGroupBObjExt> vecSurvivedPartyContMethBOBj = new Vector<XContactMethodGroupBObjExt>();
					Vector<TCRMAdminContEquivBObj> vecSurvivedPartyAdminContBOBj = new Vector<TCRMAdminContEquivBObj>();
					Vector<TCRMAdminContEquivBObj> vecSurvivedPartyAdminContBOBj1 = new Vector<TCRMAdminContEquivBObj>();
					Vector<TCRMPartyPrivPrefBObj> vecSurvivedPartyPrivacyPrefBOBj = new Vector<TCRMPartyPrivPrefBObj>();

					orgNameMap = finalOrgDetlsMap
							.get(ExternalRuleConstant.SURVIVED_MAP_NAME);
					partyAddressMap = finalOrgDetlsMap
							.get(ExternalRuleConstant.SURVIVED_MAP_ADDRESS);
					partyIdentMap = finalOrgDetlsMap
							.get(ExternalRuleConstant.SURVIVED_MAP_IDENTIFIER);
					partyContMethMap = finalOrgDetlsMap
							.get(ExternalRuleConstant.SURVIVED_MAP_CONTACTMETHOD);
					partyAdminConteqMap = finalOrgDetlsMap
							.get(ExternalRuleConstant.SURVIVED_MAP_CONTEQUIV);

					for (Map.Entry<String, XOrgNameBObjExt> entry : orgNameMap
							.entrySet()) {
						vecSurvivedOrgNameBOBj.add(entry.getValue());
					}
					for (Map.Entry<String, XAddressGroupBObjExt> entry : partyAddressMap
							.entrySet()) {
						vecSurvivedPartyAddrBOBj.add(entry.getValue());
					}

					for (Map.Entry<String, XIdentifierBObjExt> entry : partyIdentMap
							.entrySet()) {
						vecSurvivedPartyIdenBOBj.add(entry.getValue());
					}
					for (Map.Entry<String, XContactMethodGroupBObjExt> entry : partyContMethMap
							.entrySet()) {
						vecSurvivedPartyContMethBOBj.add(entry.getValue());
					}
					for (Map.Entry<String, TCRMAdminContEquivBObj> entry : partyAdminConteqMap
							.entrySet()) {
						vecSurvivedPartyAdminContBOBj.add(entry.getValue());
					}
					for (Map.Entry<String, TCRMAdminContEquivBObj> entry : partyAdminConteqMap1
							.entrySet()) {
						vecSurvivedPartyAdminContBOBj1.add(entry.getValue());
					}
					for (Map.Entry<String, TCRMPartyPrivPrefBObj> entry : partyPrivacyPrefMap
							.entrySet()) {
						vecSurvivedPartyPrivacyPrefBOBj.add(entry.getValue());
					}					
	
					// Change for Preferred Address Indicator JPN-31/08/2018
					handlePrefAddress(vecSurvivedPartyAddrBOBj, addressPrefMap);

					// Change for Preferred Contact Method Indicator JPN-31/08/2018
					handlePrefContactMethod(vecSurvivedPartyContMethBOBj,contactMethodPrefMap);

					if (vecSurvivedOrgNameBOBj.size() > 0
							|| vecSurvivedOrgNameBOBj != null) {

						((XOrgBObjExt) survivedBOBj)
								.getItemsTCRMOrganizationNameBObj().clear();
						((XOrgBObjExt) survivedBOBj)
								.getItemsTCRMOrganizationNameBObj().addAll(
										vecSurvivedOrgNameBOBj);
					}
					if (vecSurvivedPartyAddrBOBj.size() > 0
							|| vecSurvivedPartyAddrBOBj != null) {
						((XOrgBObjExt) survivedBOBj)
								.getItemsTCRMPartyAddressBObj().clear();
						((XOrgBObjExt) survivedBOBj)
								.getItemsTCRMPartyAddressBObj().addAll(
										vecSurvivedPartyAddrBOBj);
					}
					if (vecSurvivedPartyIdenBOBj.size() > 0
							|| vecSurvivedPartyIdenBOBj != null) {

						((XOrgBObjExt) survivedBOBj)
								.getItemsTCRMPartyIdentificationBObj().clear();
						((XOrgBObjExt) survivedBOBj)
								.getItemsTCRMPartyIdentificationBObj().addAll(
										vecSurvivedPartyIdenBOBj);
					}
					if (vecSurvivedPartyContMethBOBj.size() > 0
							|| vecSurvivedPartyContMethBOBj != null) {
						((XOrgBObjExt) survivedBOBj)
								.getItemsTCRMPartyContactMethodBObj().clear();
						((XOrgBObjExt) survivedBOBj)
								.getItemsTCRMPartyContactMethodBObj().addAll(
										vecSurvivedPartyContMethBOBj);
					}
					if (vecSurvivedPartyAdminContBOBj.size() > 0
							|| vecSurvivedPartyAdminContBOBj != null) {
						((XOrgBObjExt) survivedBOBj)
								.getItemsTCRMAdminContEquivBObj().clear();
						((XOrgBObjExt) survivedBOBj)
								.getItemsTCRMAdminContEquivBObj().addAll(
										vecSurvivedPartyAdminContBOBj);
					}
					if (vecSurvivedPartyAdminContBOBj1.size() > 0
							|| vecSurvivedPartyAdminContBOBj1 != null) {
						((XOrgBObjExt) survivedBOBj)
								.getItemsTCRMAdminContEquivBObj().addAll(
										vecSurvivedPartyAdminContBOBj1);
					}
					if (vecSurvivedPartyPrivacyPrefBOBj.size() > 0
							|| vecSurvivedPartyPrivacyPrefBOBj != null) {
						((XOrgBObjExt) survivedBOBj)
								.getItemsTCRMPartyPrivPrefBObj().clear();
						((XOrgBObjExt) survivedBOBj)
								.getItemsTCRMPartyPrivPrefBObj().addAll(
										vecSurvivedPartyPrivacyPrefBOBj);
					}

					vecSurviveDWLCommons.add(survivedBOBj);

				}
			}
		}
		catch (DWLBaseException e1)
		{
			DWLExceptionUtils.log(e1);
			throw new DWLBaseException(e1.getMessage());
		}
		catch (Exception e2) {
			DWLExceptionUtils.log(e2);
			throw new Exception(e2.getMessage());

		}
		return vecSurviveDWLCommons;
	}
		
	
	public boolean checkForDSCPartyData(Vector<TCRMPartyBObj> vecAllParty,DWLControl control)
	{
		boolean allDSCParty=true;
		for(TCRMPartyBObj currParty: vecAllParty)
		{
			if(!currParty.getSourceIdentifierType().equalsIgnoreCase(ExternalRuleConstant.DSC_SOURCE_TYPE))
			{
				allDSCParty=false;
				break;
			}
		}
		return allDSCParty;

	}
	
	
	public void setUCIDObj(Vector<TCRMPartyBObj> vecAllParty,
			 DWLControl control) throws Exception {
		for(TCRMPartyBObj currPartyObj : vecAllParty)
		{
			Vector<XIdentifierBObjExt> vecUcidObj=new Vector<XIdentifierBObjExt>();
			Vector<XIdentifierBObjExt> vecIdentParty=currPartyObj.getItemsTCRMPartyIdentificationBObj();
			for(XIdentifierBObjExt currXIdent : vecIdentParty)
			{
				if(currXIdent.getIdentificationType().equalsIgnoreCase(ExternalRuleConstant.UCID_TYPE))
				{
					vecUcidObj.add(currXIdent);
					//break;
				}
			}
		if(vecUcidObj!=null)
		{
			for(XIdentifierBObjExt ucidObj : vecUcidObj)
			{
			XContEquivBObjExt newContequiv=new XContEquivBObjExt();
			newContequiv.setAdminPartyId(ucidObj.getIdentificationNumber());
			newContequiv.setAdminSystemType(ExternalRuleConstant.UCID_SOURCE_TYPE);
			newContequiv.setAdminSystemValue(ExternalRuleConstant.UCID_SOURCE_VALUE);
			newContequiv.setDescription(ucidObj.getIdentificationDescription());
			newContequiv.setXLastModifiedSystemDate(ucidObj.getXLastModifiedSystemDate());
			newContequiv.setControl(control);
			newContequiv.setXSourceRetailerFlag(ucidObj.getXIdentifierRetailerFlag());
			newContequiv.setXRetailerId(ucidObj.getXRetailerId());
			newContequiv.setPartyId(ucidObj.getPartyId());
			currPartyObj.getItemsTCRMPartyIdentificationBObj().remove(ucidObj);
			currPartyObj
			.setTCRMAdminContEquivBObj(newContequiv);
			}
		}
		}
	}

	/// Survived Sorterd Parties method
	@SuppressWarnings("unchecked")
	public XPersonBObjExt sortParties(Vector<TCRMPartyBObj> vecAllParty,
			XPersonBObjExt newParty,  boolean allDSCParty, DWLControl control) throws Exception {
		
		boolean myMExists=true;
		Vector<String> myMPartyId=new Vector<String>();
		myMExists=checkPartiesforActiveMyMId(vecAllParty,myMPartyId, control);

		Timestamp tempCreatedDt = null;
		Timestamp incomingCreatedDt = null;
		XPersonBObjExt tempPartyBObj = null;
		int index = 0;

		for (TCRMPartyBObj incomingParty : vecAllParty) {
			XPersonBObjExt incomingPersonBObj = (XPersonBObjExt) incomingParty;
			boolean sourceTypeDSC=false;
			if(!allDSCParty)
			{
				if(incomingPersonBObj.getSourceIdentifierType().equalsIgnoreCase(ExternalRuleConstant.DSC_SOURCE_TYPE))
				{
					continue;
					
				}
			}
			if (index == 0) {
				tempPartyBObj = incomingPersonBObj;
				index++;
				continue;
			}

			incomingCreatedDt = DateFormatter.getTimestamp(incomingPersonBObj
					.getXLastModifiedSystemDate());
			tempCreatedDt = DateFormatter.getTimestamp(tempPartyBObj
					.getXLastModifiedSystemDate());
			if(myMPartyId.contains(incomingPersonBObj.getPartyId()))
			{
				if(myMPartyId.contains(tempPartyBObj.getPartyId()))
				{
					if (incomingCreatedDt.after(tempCreatedDt)) {

						entityCRUDPerson(incomingParty, tempPartyBObj, control);
						tempPartyBObj = incomingPersonBObj;
					} else {

						entityCRUDPerson(tempPartyBObj, incomingParty, control);
					}
				}
				else
				{
					entityCRUDPerson(incomingParty, tempPartyBObj, control);
					tempPartyBObj = incomingPersonBObj;
				}
			}
			
			else if (incomingCreatedDt.after(tempCreatedDt)) {

				entityCRUDPerson(incomingParty, tempPartyBObj, control);
				tempPartyBObj = incomingPersonBObj;
			} else {

				entityCRUDPerson(tempPartyBObj, incomingParty, control);
			}

		}

		newParty.shallowClone(tempPartyBObj);

		return newParty;
	}


	// For Org Sort Parties

	@SuppressWarnings("unchecked")
	public TCRMPartyBObj sortOrgParties(Vector<TCRMPartyBObj> vecAllParty,
			TCRMPartyBObj newParty, boolean  allDSCParty, DWLControl control) throws Exception {

		
		boolean myMExists=true;
		Vector<String> myMPartyId=new Vector<String>();
		myMExists=checkPartiesforActiveMyMId(vecAllParty,myMPartyId, control);

		Timestamp tempCreatedDt = null;
		Timestamp incomingCreatedDt = null;
		TCRMPartyBObj tempPartyBObj = null;
		int index = 0;

		for (TCRMPartyBObj incomingParty : vecAllParty) {
			XOrgBObjExt incomingOrgBObj = (XOrgBObjExt) incomingParty;
			if(!allDSCParty)
			{
				if(incomingOrgBObj.getSourceIdentifierType().equalsIgnoreCase(ExternalRuleConstant.DSC_SOURCE_TYPE))
				{
					continue;
					
				}
			}
			if (index == 0) {
				tempPartyBObj = incomingParty;
				index++;
				continue;
			}

			incomingCreatedDt = DateFormatter.getTimestamp(incomingOrgBObj
					.getXLastModifiedSystemDate());
			tempCreatedDt = DateFormatter.getTimestamp(incomingOrgBObj
					.getXLastModifiedSystemDate());
			
			
			if(myMPartyId.contains(incomingOrgBObj.getPartyId()))
			{
				if(myMPartyId.contains(tempPartyBObj.getPartyId()))
				{
					if (incomingCreatedDt.after(tempCreatedDt)) {

						entityCRUDOrg(incomingParty, tempPartyBObj, control);
						tempPartyBObj = incomingOrgBObj;
					} else {

						entityCRUDOrg(tempPartyBObj, incomingParty, control);
					}
				}
				else
				{
					entityCRUDOrg(incomingParty, tempPartyBObj, control);
					tempPartyBObj = incomingOrgBObj;
				}
			}
			
			else if (incomingCreatedDt.after(tempCreatedDt)) {

				entityCRUDOrg(incomingParty, tempPartyBObj, control);
				tempPartyBObj = incomingOrgBObj;
			} else {

				entityCRUDOrg(tempPartyBObj, incomingParty, control);
			}

		}

		//newParty.shallowClone(tempPartyBObj);

			/*if (incomingCreatedDt.after(tempCreatedDt)) {

				entityCRUDOrg(incomingParty, tempPartyBObj, control);
				tempPartyBObj = incomingParty;
			} else {

				entityCRUDOrg(tempPartyBObj, incomingParty, control);
			}*/

		

		newParty.shallowClone(tempPartyBObj);

		return newParty;
	}

	public void sortPartyAddresses(
			Vector<XAddressGroupBObjExt> vecRetailPartyAddressBObj,
			XAddressGroupBObjExt newPartyAddressBObj, DWLControl control)
			throws Exception {
		if (vecRetailPartyAddressBObj.size() != 0) {
			// Descending order
			Collections.sort(vecRetailPartyAddressBObj,
					new Comparator<XAddressGroupBObjExt>() {
						public int compare(XAddressGroupBObjExt party1,
								XAddressGroupBObjExt party2) {
							if (party1.getXLastModifiedSystemDate() == null
									|| party2.getXLastModifiedSystemDate() == null)
								return 0;
							return party1
									.getXLastModifiedSystemDate()
									.compareTo(
											party2.getXLastModifiedSystemDate());
						}
					});
			Collections.reverse(vecRetailPartyAddressBObj);// Descending sort
		}
	}

	public void sortPartyAddressesAsc(
			Vector<XAddressGroupBObjExt> vecRetailPartyAddressBObj,
			XAddressGroupBObjExt newPartyAddressBObj, DWLControl control)
			throws Exception {

		// ascending order
		Collections.sort(vecRetailPartyAddressBObj,
				new Comparator<XAddressGroupBObjExt>() {
					public int compare(XAddressGroupBObjExt party1,
							XAddressGroupBObjExt party2) {
						if (party1.getXLastModifiedSystemDate() == null
								|| party2.getXLastModifiedSystemDate() == null)
							return 0;
						return party1.getXLastModifiedSystemDate().compareTo(
								party2.getXLastModifiedSystemDate());
					}
				});
	}

	public void entityCRUDAddress(
			XAddressGroupBObjExt incomingPartyAddressBObj,
			XAddressGroupBObjExt tempPartyAddressBObj, DWLControl control)
			throws Exception {
		// AddressUsageType
		if (incomingPartyAddressBObj.getAddressUsageType() == null
				|| incomingPartyAddressBObj.getAddressUsageType().isEmpty()) {
			incomingPartyAddressBObj.setAddressUsageType(tempPartyAddressBObj
					.getAddressUsageType());
		}
		// AddressUsageValue
		if (incomingPartyAddressBObj.getAddressUsageValue() == null
				|| incomingPartyAddressBObj.getAddressUsageValue().isEmpty()) {
			incomingPartyAddressBObj.setAddressUsageValue(tempPartyAddressBObj
					.getAddressUsageValue());
		}
		// StartDate
		if (incomingPartyAddressBObj.getStartDate() == null
				|| incomingPartyAddressBObj.getStartDate().isEmpty()) {
			incomingPartyAddressBObj.setStartDate(tempPartyAddressBObj
					.getStartDate());
		}
		// PreferredAddressIndicator
		if (incomingPartyAddressBObj.getPreferredAddressIndicator() == null
				|| incomingPartyAddressBObj.getPreferredAddressIndicator()
						.isEmpty()) {
			incomingPartyAddressBObj
					.setPreferredAddressIndicator(tempPartyAddressBObj
							.getPreferredAddressIndicator());
		}
		// SourceIdentifierType
		if (incomingPartyAddressBObj.getSourceIdentifierType() == null
				|| incomingPartyAddressBObj.getSourceIdentifierType().isEmpty()) {
			incomingPartyAddressBObj
					.setSourceIdentifierType(tempPartyAddressBObj
							.getSourceIdentifierType());
		}
		// SourceIdentifierValue
		if (incomingPartyAddressBObj.getSourceIdentifierValue() == null
				|| incomingPartyAddressBObj.getSourceIdentifierValue()
						.isEmpty()) {
			incomingPartyAddressBObj
					.setSourceIdentifierValue(tempPartyAddressBObj
							.getSourceIdentifierValue());
		}

		// --XAddressGroupBObj Attributes
		// XVerifiedType
		if (incomingPartyAddressBObj.getXVerifiedType() == null
				|| incomingPartyAddressBObj.getXVerifiedType().isEmpty()) {
			incomingPartyAddressBObj.setXVerifiedType(tempPartyAddressBObj
					.getXVerifiedType());
		}
		// XVerifiedValue
		if (incomingPartyAddressBObj.getXVerifiedValue() == null
				|| incomingPartyAddressBObj.getXVerifiedValue().isEmpty()) {
			incomingPartyAddressBObj.setXVerifiedValue(tempPartyAddressBObj
					.getXVerifiedValue());
		}
		// XLastModifiedSystemDate
		if (incomingPartyAddressBObj.getXLastModifiedSystemDate() == null
				|| incomingPartyAddressBObj.getXLastModifiedSystemDate()
						.isEmpty()) {
			incomingPartyAddressBObj
					.setXLastModifiedSystemDate(tempPartyAddressBObj
							.getXLastModifiedSystemDate());
		}
		// XAddressRetailerFlag
		if (incomingPartyAddressBObj.getXAddressRetailerFlag() == null
				|| incomingPartyAddressBObj.getXAddressRetailerFlag().isEmpty()) {
			incomingPartyAddressBObj
					.setXAddressRetailerFlag(tempPartyAddressBObj
							.getXAddressRetailerFlag());
		}

		// --XPrivacyAgreementBObj
		// ActionType
		if (incomingPartyAddressBObj.getXPrivacyAgreementBObj().getActionType() == null
				|| incomingPartyAddressBObj.getXPrivacyAgreementBObj()
						.getActionType().isEmpty()) {
			incomingPartyAddressBObj.getXPrivacyAgreementBObj().setActionType(
					tempPartyAddressBObj.getXPrivacyAgreementBObj()
							.getActionType());
		}
		// ActionValue
		if (incomingPartyAddressBObj.getXPrivacyAgreementBObj()
				.getActionValue() == null
				|| incomingPartyAddressBObj.getXPrivacyAgreementBObj()
						.getActionValue().isEmpty()) {
			incomingPartyAddressBObj.getXPrivacyAgreementBObj().setActionValue(
					tempPartyAddressBObj.getXPrivacyAgreementBObj()
							.getActionValue());
		}
		// SourceIdentifierType
		if (incomingPartyAddressBObj.getXPrivacyAgreementBObj()
				.getSourceIdentifierType() == null
				|| incomingPartyAddressBObj.getXPrivacyAgreementBObj()
						.getSourceIdentifierType().isEmpty()) {
			incomingPartyAddressBObj.getXPrivacyAgreementBObj()
					.setSourceIdentifierType(
							tempPartyAddressBObj.getXPrivacyAgreementBObj()
									.getSourceIdentifierType());
		}
		// SourceIdentifierValue
		if (incomingPartyAddressBObj.getXPrivacyAgreementBObj()
				.getSourceIdentifierValue() == null
				|| incomingPartyAddressBObj.getXPrivacyAgreementBObj()
						.getSourceIdentifierValue().isEmpty()) {
			incomingPartyAddressBObj.getXPrivacyAgreementBObj()
					.setSourceIdentifierValue(
							tempPartyAddressBObj.getXPrivacyAgreementBObj()
									.getSourceIdentifierValue());
		}
		// StartDate
		if (incomingPartyAddressBObj.getXPrivacyAgreementBObj().getStartDate() == null
				|| incomingPartyAddressBObj.getXPrivacyAgreementBObj()
						.getStartDate().isEmpty()) {
			incomingPartyAddressBObj.getXPrivacyAgreementBObj().setStartDate(
					tempPartyAddressBObj.getXPrivacyAgreementBObj()
							.getStartDate());
		}
		// EndDate
		if (incomingPartyAddressBObj.getXPrivacyAgreementBObj().getEndDate() == null
				|| incomingPartyAddressBObj.getXPrivacyAgreementBObj()
						.getEndDate().isEmpty()) {
			incomingPartyAddressBObj.getXPrivacyAgreementBObj().setEndDate(
					tempPartyAddressBObj.getXPrivacyAgreementBObj()
							.getEndDate());
		}
		// LastModifiedSystemDate
		if (incomingPartyAddressBObj.getXPrivacyAgreementBObj()
				.getLastModifiedSystemDate() == null
				|| incomingPartyAddressBObj.getXPrivacyAgreementBObj()
						.getLastModifiedSystemDate().isEmpty()) {
			incomingPartyAddressBObj.getXPrivacyAgreementBObj()
					.setLastModifiedSystemDate(
							tempPartyAddressBObj.getXPrivacyAgreementBObj()
									.getLastModifiedSystemDate());
		}

	}

	@SuppressWarnings("static-access")
	public void entityCRUDPerson(TCRMPartyBObj incomingParty,
			TCRMPartyBObj tempPartyBObj, DWLControl control) throws Exception {
		

		String prefLangType = null;
		String sourceIdentifierType = null;
		String sourceIdentifierValue = null;

		String prefLangValue = ((TCRMPersonBObj) tempPartyBObj)
				.getPreferredLanguageValue();
		if (tempPartyBObj.getSourceIdentifierValue() != null)
			sourceIdentifierValue = ((TCRMPersonBObj) tempPartyBObj)
					.getSourceIdentifierValue();

		prefLangType = ((TCRMPersonBObj) tempPartyBObj)
				.getPreferredLanguageType();
		if (((TCRMPersonBObj) tempPartyBObj).getSourceIdentifierValue() != null)
			sourceIdentifierType = ((TCRMPersonBObj) tempPartyBObj)
					.getSourceIdentifierValue();

		// Preferred Language type
		if (((TCRMPersonBObj) incomingParty).getPreferredLanguageType() == null
				|| ((TCRMPersonBObj) incomingParty).getPreferredLanguageType()
						.isEmpty()) {
			((TCRMPersonBObj) incomingParty)
					.setPreferredLanguageType(prefLangType);
		}
		// Preferred Language Value
		if (((TCRMPersonBObj) incomingParty).getPreferredLanguageValue() == null
				|| ((TCRMPersonBObj) incomingParty).getPreferredLanguageValue()
						.isEmpty()) {
			((TCRMPersonBObj) incomingParty)
					.setPreferredLanguageValue(((TCRMPersonBObj) tempPartyBObj)
							.getPreferredLanguageValue());
		}
		// Party Type
		if (((TCRMPersonBObj) incomingParty).getPartyType() == null
				|| ((TCRMPersonBObj) incomingParty).getPartyType().isEmpty()) {
			((TCRMPersonBObj) incomingParty)
					.setPartyType(((TCRMPersonBObj) tempPartyBObj)
							.getPartyType());
		}
		// CreatedDate
		if (((TCRMPersonBObj) incomingParty).getCreatedDate() == null
				|| ((TCRMPersonBObj) incomingParty).getCreatedDate().isEmpty()) {
			((TCRMPersonBObj) incomingParty)
					.setCreatedDate(((TCRMPersonBObj) tempPartyBObj)
							.getCreatedDate());
		}
		// Client Status Type
		if (((TCRMPersonBObj) incomingParty).getClientStatusType() == null
				|| ((TCRMPersonBObj) incomingParty).getClientStatusType()
						.isEmpty()) {
			((TCRMPersonBObj) incomingParty)
					.setClientStatusType(((TCRMPersonBObj) tempPartyBObj)
							.getClientStatusType());
		}
		// Solicitation Indicator
		if (((TCRMPersonBObj) incomingParty).getSolicitationIndicator() == null
				|| ((TCRMPersonBObj) incomingParty).getSolicitationIndicator()
						.isEmpty()) {
			((TCRMPersonBObj) incomingParty)
					.setSolicitationIndicator(((TCRMPersonBObj) tempPartyBObj)
							.getSolicitationIndicator());
		}
		// ConfidentialIndicator
		if (((TCRMPersonBObj) incomingParty).getConfidentialIndicator() == null
				|| ((TCRMPersonBObj) incomingParty).getConfidentialIndicator()
						.isEmpty()) {
			((TCRMPersonBObj) incomingParty)
					.setConfidentialIndicator(((TCRMPersonBObj) tempPartyBObj)
							.getConfidentialIndicator());
		}
		// ClientImportanceType
		if (((TCRMPersonBObj) incomingParty).getConfidentialIndicator() == null
				|| ((TCRMPersonBObj) incomingParty).getConfidentialIndicator()
						.isEmpty()) {
			((TCRMPersonBObj) incomingParty)
					.setConfidentialIndicator(((TCRMPersonBObj) tempPartyBObj)
							.getConfidentialIndicator());
		}
		// ClientImportanceValue
		if (((TCRMPersonBObj) incomingParty).getClientImportanceType() == null
				|| ((TCRMPersonBObj) incomingParty).getClientImportanceType()
						.isEmpty()) {
			((TCRMPersonBObj) incomingParty)
					.setClientImportanceType(((TCRMPersonBObj) tempPartyBObj)
							.getClientImportanceType());
		}
		// Birth Date
		if (((TCRMPersonBObj) incomingParty).getBirthDate() == null
				|| ((TCRMPersonBObj) incomingParty).getBirthDate().isEmpty()) {
			((TCRMPersonBObj) incomingParty)
					.setBirthDate(((TCRMPersonBObj) tempPartyBObj)
							.getBirthDate());
		}
		// Gender
		if (((TCRMPersonBObj) incomingParty).getGenderType() == null
				|| ((TCRMPersonBObj) incomingParty).getGenderType().isEmpty()) {
			((TCRMPersonBObj) incomingParty)
					.setGenderType(((TCRMPersonBObj) tempPartyBObj)
							.getGenderType());
		}
		// Source Identifier Type
		if (((TCRMPersonBObj) incomingParty).getSourceIdentifierType() == null
				|| ((TCRMPersonBObj) incomingParty).getSourceIdentifierType()
						.isEmpty()) {
			((TCRMPersonBObj) incomingParty)
					.setSourceIdentifierType(sourceIdentifierType);
		}
		// Source Identifier Value
		if (((TCRMPersonBObj) incomingParty).getSourceIdentifierValue() == null
				|| ((TCRMPersonBObj) incomingParty).getSourceIdentifierValue()
						.isEmpty()) {
			((TCRMPersonBObj) incomingParty)
					.setSourceIdentifierValue(((TCRMPersonBObj) tempPartyBObj)
							.getSourceIdentifierValue());
		}
		// Last Verified Date
		if (((TCRMPersonBObj) incomingParty).getLastVerifiedDate() == null
				|| ((TCRMPersonBObj) incomingParty).getLastVerifiedDate()
						.isEmpty()) {
			((TCRMPersonBObj) incomingParty)
					.setLastVerifiedDate(((TCRMPersonBObj) tempPartyBObj)
							.getLastVerifiedDate());
		}
		
		// Marital Status Type
		if (((TCRMPersonBObj) incomingParty).getMaritalStatusType() == null
				|| ((TCRMPersonBObj) incomingParty).getMaritalStatusType()
						.isEmpty()) {
			((TCRMPersonBObj) incomingParty)
					.setMaritalStatusType(((TCRMPersonBObj) tempPartyBObj)
							.getMaritalStatusType());
		}
		
		// Marital Status Value
		if (((TCRMPersonBObj) incomingParty).getMaritalStatusValue() == null
				|| ((TCRMPersonBObj) incomingParty).getMaritalStatusValue()
						.isEmpty()) {
			((TCRMPersonBObj) incomingParty)
					.setMaritalStatusValue(((TCRMPersonBObj) tempPartyBObj)
							.getMaritalStatusValue());
		}

		
		XPersonBObjExt xincomingObj = (XPersonBObjExt) incomingParty;
		XPersonBObjExt xtempBobj = (XPersonBObjExt) tempPartyBObj;

		// maintain xperson attributes

		if (xincomingObj != null && xtempBobj != null) {

			setXPersonAttr(xincomingObj, xtempBobj, control);

		}

	}

	// For Org Entity and Extesnion Survivorship

	@SuppressWarnings("static-access")
	public void entityCRUDOrg(TCRMPartyBObj incomingParty,
			TCRMPartyBObj tempPartyBObj, DWLControl control) throws Exception {

		String prefLangType = null;
		String clientPotentialType = null;
		String sourceIdentifierType = null;
		String orgType = null;
		String industryType = null;

		String prefLangValue = ((XOrgBObjExt) tempPartyBObj)
				.getPreferredLanguageValue();
		String sourceIdentifierValue = ((XOrgBObjExt) tempPartyBObj)
				.getSourceIdentifierValue();
		String orgTypeValue = ((XOrgBObjExt) tempPartyBObj)
				.getOrganizationValue();
		String industryTypeValue = ((XOrgBObjExt) tempPartyBObj)
				.getIndustryValue();

		prefLangType = ((XOrgBObjExt) tempPartyBObj).getPreferredLanguageType();
		sourceIdentifierType = ((XOrgBObjExt) tempPartyBObj)
				.getSourceIdentifierType();
		orgType = orgTypeValue = ((XOrgBObjExt) tempPartyBObj)
				.getOrganizationType();
		industryType = ((XOrgBObjExt) tempPartyBObj).getIndustryType();

		if (((XOrgBObjExt) incomingParty).getPreferredLanguageType() == null
				|| ((XOrgBObjExt) incomingParty).getPreferredLanguageType()
						.isEmpty()) {
			((XOrgBObjExt) incomingParty)
					.setPreferredLanguageType(prefLangType);
		}
		if (((XOrgBObjExt) incomingParty).getPreferredLanguageValue() == null
				|| ((XOrgBObjExt) incomingParty).getPreferredLanguageValue()
						.isEmpty()) {
			((XOrgBObjExt) incomingParty)
					.setPreferredLanguageValue(((XOrgBObjExt) tempPartyBObj)
							.getPreferredLanguageValue());
		}
		if (((XOrgBObjExt) incomingParty).getClientPotentialType() == null
				|| ((XOrgBObjExt) incomingParty).getClientPotentialType()
						.isEmpty()) {
			((XOrgBObjExt) incomingParty)
					.setClientPotentialType(clientPotentialType);
		}
		if (((XOrgBObjExt) incomingParty).getClientPotentialValue() == null
				|| ((XOrgBObjExt) incomingParty).getClientPotentialValue()
						.isEmpty()) {
			((XOrgBObjExt) incomingParty)
					.setClientPotentialValue(((XOrgBObjExt) tempPartyBObj)
							.getClientPotentialValue());
		}
		if (((XOrgBObjExt) incomingParty).getPartyType() == null
				|| ((XOrgBObjExt) incomingParty).getPartyType().isEmpty()) {
			((XOrgBObjExt) incomingParty)
					.setPartyType(((XOrgBObjExt) tempPartyBObj).getPartyType());
		}
		if (((XOrgBObjExt) incomingParty).getSourceIdentifierType() == null
				|| ((XOrgBObjExt) incomingParty).getSourceIdentifierType()
						.isEmpty()) {
			((XOrgBObjExt) incomingParty)
					.setSourceIdentifierType(sourceIdentifierType);
		}
		if (((XOrgBObjExt) incomingParty).getSourceIdentifierValue() == null
				|| ((XOrgBObjExt) incomingParty).getSourceIdentifierValue()
						.isEmpty()) {
			((XOrgBObjExt) incomingParty)
					.setSourceIdentifierValue(((XOrgBObjExt) tempPartyBObj)
							.getSourceIdentifierValue());
		}
		if (((XOrgBObjExt) incomingParty).getLastVerifiedDate() == null
				|| ((XOrgBObjExt) incomingParty).getLastVerifiedDate()
						.isEmpty()) {
			((XOrgBObjExt) incomingParty)
					.setLastVerifiedDate(((XOrgBObjExt) tempPartyBObj)
							.getLastVerifiedDate());
		}
		if (((XOrgBObjExt) incomingParty).getOrganizationType() == null
				|| ((XOrgBObjExt) incomingParty).getOrganizationType()
						.isEmpty()) {
			((XOrgBObjExt) incomingParty).setOrganizationType(orgType);
		}
		if (((XOrgBObjExt) incomingParty).getOrganizationValue() == null
				|| ((XOrgBObjExt) incomingParty).getOrganizationValue()
						.isEmpty()) {
			((XOrgBObjExt) incomingParty)
					.setOrganizationValue(((XOrgBObjExt) tempPartyBObj)
							.getOrganizationValue());
		}
		if (((XOrgBObjExt) incomingParty).getIndustryType() == null
				|| ((XOrgBObjExt) incomingParty).getIndustryType().isEmpty()) {
			((XOrgBObjExt) incomingParty).setIndustryType(industryType);
		}
		if (((XOrgBObjExt) incomingParty).getIndustryValue() == null
				|| ((XOrgBObjExt) incomingParty).getIndustryValue().isEmpty()) {
			((XOrgBObjExt) incomingParty)
					.setIndustryValue(((XOrgBObjExt) tempPartyBObj)
							.getIndustryValue());
		}

		XOrgBObjExt xincomingObj = (XOrgBObjExt) incomingParty;
		XOrgBObjExt xtempBobj = (XOrgBObjExt) tempPartyBObj;

		// maintain xorg attributes

		if (xincomingObj != null && xtempBobj != null) {

			setXOrgAttr(xincomingObj, xtempBobj, control);

		}

	}

	// Survived PersonDetails method
	@SuppressWarnings("unchecked")
	private HashMap<String, HashMap> survivedPersonDetails(Vector vecAllParty, boolean allDSCParty, boolean isRealTime, DWLControl control) throws Exception {
		
		logger.info("Inside survivedPersonDetails JPN");
		HashMap<String, XPersonNameBObjExt> personNameMap = new HashMap<String, XPersonNameBObjExt>();
		HashMap<String, XAddressGroupBObjExt> partyAddressMap = new HashMap<String, XAddressGroupBObjExt>();
		HashMap<String, XIdentifierBObjExt> partyIdentMap = new HashMap<String, XIdentifierBObjExt>();
		HashMap<String, XContactMethodGroupBObjExt> partyContMethMap = new HashMap<String, XContactMethodGroupBObjExt>();
		HashMap<String, XContEquivBObjExt> partyAdminConteqMap = new HashMap<String, XContEquivBObjExt>();
		//HashMap<String, TCRMAdminContEquivBObj> partyAdminConteqMapMaster = new HashMap<String, TCRMAdminContEquivBObj>();
		//HashMap<String, TCRMAdminContEquivBObj> partyDealerAdminConteqMap = new HashMap<String, TCRMAdminContEquivBObj>();
		String mapKey = null;
		Vector<String> myMIdPartyId=new Vector<String>();
		boolean myMIdExists=false;
		myMIdExists = checkPartiesforActiveMyMId(vecAllParty,myMIdPartyId, control);
		XContEquivBObjExt myMIdObj=null;
		Vector<TCRMPartyBObj> vecDSCParty=new Vector<TCRMPartyBObj>();
		
		/* Change Request for SFDC Survivorship - 12/2018 start */
		Vector<XPersonBObjExt> vecSortedPartyForSFDC=new Vector<XPersonBObjExt>();					
		vecSortedPartyForSFDC.addAll(vecAllParty);
		
		Collections.sort(vecSortedPartyForSFDC,
				new Comparator<XPersonBObjExt>() {// Ascending sort
													// - for delta
													// load
					public int compare(XPersonBObjExt party1,
							XPersonBObjExt party2) {
						if (party1.getCreatedDate() == null
								|| party2
										.getCreatedDate() == null)
							return 0;
						return party1
								.getCreatedDate()
								.compareTo(
										party2.getCreatedDate());
					}
				});
		
		XPersonBObjExt retailSfdcMasterParty=null;
		XPersonBObjExt wsSFDCMasterParty=null;
		//Vector<XContEquivBObjExt> vecRetailMasterKey=new Vector<XContEquivBObjExt>();
		Vector<String> vecMasterPartyRetailerIds=new Vector<String>();
		XContEquivBObjExt wsMasterKey=null;
		for(XPersonBObjExt currXpersonObj : vecSortedPartyForSFDC)
		{			
			Vector<XContEquivBObjExt> vecPartyEquivs=currXpersonObj.getItemsTCRMAdminContEquivBObj();
			for(XContEquivBObjExt currXCont : vecPartyEquivs)
			{
				if(currXCont.getAdminSystemType().equalsIgnoreCase(ExternalRuleConstant.SOURCE_IDENTIFIER_TYPE_SFDC))
				{
					if(retailSfdcMasterParty==null || (retailSfdcMasterParty!=null && retailSfdcMasterParty.getPartyId().equalsIgnoreCase(currXpersonObj.getPartyId())))
					{
						if(currXCont.getDescription().equalsIgnoreCase(ExternalRuleConstant.MASTER_KEY) && currXCont.getXSourceRetailerFlag()!=null && currXCont.getXSourceRetailerFlag().equalsIgnoreCase(ExternalRuleConstant.ACTIVE_FLAG_Y))
						{
						retailSfdcMasterParty=currXpersonObj;
						//vecRetailMasterKey.add(currXCont);
						vecMasterPartyRetailerIds.add(currXCont.getXRetailerId());
						
						}
					}
					
					if(wsSFDCMasterParty==null)
					{
						
						if(currXCont.getDescription().equalsIgnoreCase(ExternalRuleConstant.MASTER_KEY) && currXCont.getXSourceRetailerFlag()!=null && currXCont.getXSourceRetailerFlag().equalsIgnoreCase(ExternalRuleConstant.ACTIVE_FLAG_N))
						{
							wsSFDCMasterParty=currXpersonObj;
							wsMasterKey=currXCont;
							
						}
						
					}
				}
				
			}
			/*if(retailSfdcMasterParty!=null && wsSFDCMasterParty!=null)
			{
				break;
			}*/
		}
		
		//XPersonBObjExt sfdcMasterParty=vecSortedPartyForSFDC.firstElement();
		
		/* Change Request for SFDC Survivorship - 12/2018 End */

		XPersonBObjExt incomingPersonBObj = (XPersonBObjExt) vecAllParty.get(0);
			//  JPN Person Survivorship
			
			
			for (int i = 0; i < vecAllParty.size(); i++) {

				boolean sourceTypeDSC=false;
				
				TCRMPartyBObj party = (TCRMPartyBObj) vecAllParty.get(i);
				
				if(!allDSCParty)
				{
					if(party.getSourceIdentifierType().equalsIgnoreCase(ExternalRuleConstant.DSC_SOURCE_TYPE))
					{
						vecDSCParty.add(party);
						sourceTypeDSC=true;
						continue;
						
					}
				}
				
				//Person Name Survivorship
				Vector<XPersonNameBObjExt> vecTempPersonNameBOBj = new Vector<XPersonNameBObjExt>();
				vecTempPersonNameBOBj = ((XPersonBObjExt) party)
						.getItemsTCRMPersonNameBObj();
				String firstPartyNameUsageType = null;
				String secondPartyNameUsageType = null;
				
				// For Person Names
				for (int j = 0; j < vecTempPersonNameBOBj.size(); j++) {

					XPersonNameBObjExt personnameBObj = (XPersonNameBObjExt) vecTempPersonNameBOBj
							.get(j);
					firstPartyNameUsageType = personnameBObj.getNameUsageType();
					if (!personNameMap.containsKey(firstPartyNameUsageType)) {
						personNameMap.put(firstPartyNameUsageType,
								personnameBObj);
					} else{
						XPersonNameBObjExt nameBObjInMap = personNameMap.get(firstPartyNameUsageType);
						secondPartyNameUsageType = personnameBObj.getNameUsageType();
						Timestamp person1CreatedDt = DateFormatter.getTimestamp(nameBObjInMap.getXLastModifiedSystemDate());
						Timestamp person2CreatedDt = DateFormatter.getTimestamp(personnameBObj.getXLastModifiedSystemDate());

						if (firstPartyNameUsageType.equalsIgnoreCase(secondPartyNameUsageType)) {
							if (person1CreatedDt.after(person2CreatedDt)) {
								personNameMap.put(secondPartyNameUsageType,nameBObjInMap);
							} else {
								personNameMap.put(firstPartyNameUsageType,personnameBObj);
							}

						}

					}
				}
				// For Party Identification

				Vector<XIdentifierBObjExt> vecTempPartyIdentificationBObj = new Vector<XIdentifierBObjExt>();
				

				vecTempPartyIdentificationBObj = party.getItemsTCRMPartyIdentificationBObj();


				String firstPartyIdentificationType = null;

				String secondPartyIdentificationType = null;

				String firstPartyIdentificationValue = null;

				String secondPartyIdentificationValue = null;

				String firstRetailerId = null;

				String secondRetailerId = null;

				//XIdentifierBObjExt xIdenBObj = null;
				

				for (int j = 0; j < vecTempPartyIdentificationBObj.size(); j++) {

					XIdentifierBObjExt partyIdenBObj = (XIdentifierBObjExt) vecTempPartyIdentificationBObj.get(j);

					firstPartyIdentificationValue = partyIdenBObj.getIdentificationValue();

					firstPartyIdentificationType = partyIdenBObj.getIdentificationType();

					//firstRetailerId = partyIdenBObj.getXRetailerId();

					/*if (firstPartyIdentificationType.equalsIgnoreCase(ExternalRuleConstant.ID_TYPE_MAGIC)) {
						mapKey = firstPartyIdentificationType + firstRetailerId;
					} else {*/
						mapKey = firstPartyIdentificationType;
					//}

					if (!partyIdentMap.containsKey(mapKey) ) {

						partyIdentMap.put(mapKey, partyIdenBObj);

					} else {

						XIdentifierBObjExt idenBObjInMap = partyIdentMap.get(mapKey);

						// secondPartyIdentificationValue =
						// idenBObjInMap.getIdentificationValue();

						secondPartyIdentificationType = idenBObjInMap.getIdentificationType();

						//secondRetailerId = idenBObjInMap.getXRetailerId();

						if (firstPartyIdentificationType.equalsIgnoreCase(secondPartyIdentificationType)) {
							 

								// All Id types except UCID
								Timestamp party1CreatedDt = DateFormatter.getTimestamp(idenBObjInMap.getXLastModifiedSystemDate());

								Timestamp party2CreatedDt = DateFormatter.getTimestamp(partyIdenBObj.getXLastModifiedSystemDate());

								if (party1CreatedDt.after(party2CreatedDt)) {

									partyIdentMap.put(secondPartyIdentificationType,idenBObjInMap);
								}

								else {

									partyIdentMap.put(firstPartyIdentificationType,partyIdenBObj);
								}
							
						}
					}
				}

				// For Party Admin Contequiv
				Vector<XContEquivBObjExt> vecTempAdminContequivBObj = null;
				vecTempAdminContequivBObj = party.getItemsTCRMAdminContEquivBObj();

				String firstPartyAdminSysType = null;

				String secondPartyAdminSysType = null;

				String firstPartyAdminSysValue = null;

				String secondPartyAdminSysValue = null;

				XContEquivBObjExt newadminContEquivBObj = null;

				firstRetailerId = null;

				secondRetailerId = null;
				
				XContEquivBObjExt xConteq=null;
				
				boolean myMercedeseType=false;
				
				for (int j = 0; j < vecTempAdminContequivBObj.size(); j++) {
					
					//boolean sameDealer=false;

					XContEquivBObjExt partyAdminContequivBObj = (XContEquivBObjExt) vecTempAdminContequivBObj.get(j);

					firstPartyAdminSysValue = partyAdminContequivBObj.getAdminSystemValue();

					firstPartyAdminSysType = partyAdminContequivBObj.getAdminSystemType();

					String firstRetailerFlag = partyAdminContequivBObj.getXSourceRetailerFlag();
					if(firstRetailerFlag!=null)
					{
					if (firstRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_Y)) {

						firstRetailerId = partyAdminContequivBObj.getXRetailerId();
						
						

						mapKey = firstRetailerFlag + firstPartyAdminSysType + firstRetailerId;

					} else {

						mapKey = firstRetailerFlag + firstPartyAdminSysType;

					}
					}

					if(!(partyAdminContequivBObj.getAdminSystemType().equalsIgnoreCase(ExternalRuleConstant.MAGIC_NUMBER_SYS_TYPE)||partyAdminContequivBObj.getAdminSystemType().equalsIgnoreCase(ExternalRuleConstant.UCID_SOURCE_TYPE)|| partyAdminContequivBObj.getAdminSystemType().equalsIgnoreCase(ExternalRuleConstant.SOURCE_IDENTIFIER_TYPE_SFDC)))
					{
					if (!partyAdminConteqMap.containsKey(mapKey)){
						
						partyAdminContequivBObj.setDescription(ExternalRuleConstant.MASTER_KEY);
						partyAdminConteqMap.put(mapKey, partyAdminContequivBObj);
						if(firstPartyAdminSysType.equalsIgnoreCase(ExternalRuleConstant.MYMERC_SOURCETYPE) && firstRetailerId==null)
						{
							myMIdObj=partyAdminContequivBObj;
						}
						
					} 
					else
					{
						XContEquivBObjExt partyAdminContequivBObjInMap = (XContEquivBObjExt) partyAdminConteqMap.get(mapKey);

						secondPartyAdminSysValue = partyAdminContequivBObjInMap.getAdminSystemValue();

						secondPartyAdminSysType = partyAdminContequivBObjInMap.getAdminSystemType();

						String secondRetailerFlag = partyAdminContequivBObj.getXSourceRetailerFlag();

						if(secondRetailerFlag!=null)
						if (secondRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_Y)) {

							secondRetailerId = partyAdminContequivBObj.getXRetailerId();

						}

						/*if(firstRetailerId!=null && secondRetailerId!=null && !firstRetailerId.equals(secondRetailerId))
						{
							sameDealer=checkIfSameDealerRetailCopy(firstRetailerId,secondRetailerId, control);
						}*/
						Timestamp party1CreatedDt = DateFormatter.getTimestamp(partyAdminContequivBObj.getXLastModifiedSystemDate());

						Timestamp party2CreatedDt = DateFormatter.getTimestamp(partyAdminContequivBObjInMap.getXLastModifiedSystemDate());
						
						
						
						
							if(party1CreatedDt.before(party2CreatedDt))
							{
								if(firstPartyAdminSysType.equalsIgnoreCase(ExternalRuleConstant.MYMERC_SOURCETYPE))
								{
								partyAdminConteqMap.put(mapKey, partyAdminContequivBObj);
								if(firstRetailerId==null)
								{
								myMIdObj=partyAdminContequivBObj;
								}
								}
								else
								{
								partyAdminContequivBObj.setDescription(ExternalRuleConstant.MASTER_KEY);
								partyAdminConteqMap.put(mapKey, partyAdminContequivBObj);
								
								
								
								int slaveKey=1;
								String newMapKey=mapKey+ExternalRuleConstant.SLAVE_KEY+Integer.toString(slaveKey);
								
								while(partyAdminConteqMap.containsKey(newMapKey))
								{
									slaveKey++;
									String count=Integer.toString(slaveKey); 
									newMapKey=mapKey+ExternalRuleConstant.SLAVE_KEY+count;
								}
								mapKey=newMapKey;
								partyAdminContequivBObjInMap.setDescription(ExternalRuleConstant.SLAVE_KEY);
								partyAdminConteqMap.put(mapKey, partyAdminContequivBObjInMap);
								}
							}
							else
							{
								if(firstPartyAdminSysType.equalsIgnoreCase(ExternalRuleConstant.MYMERC_SOURCETYPE))
								{
								partyAdminConteqMap.put(mapKey, partyAdminContequivBObjInMap);
								if(firstRetailerId==null)
								{
								myMIdObj=partyAdminContequivBObjInMap;
								}
								}
								else
								{
								partyAdminContequivBObjInMap.setDescription(ExternalRuleConstant.MASTER_KEY);
								partyAdminConteqMap.put(mapKey, partyAdminContequivBObjInMap);
								
								int slaveKey=1;
								String newMapKey=mapKey+ExternalRuleConstant.SLAVE_KEY+Integer.toString(slaveKey);
								
								while(partyAdminConteqMap.containsKey(newMapKey))
								{
									slaveKey++;
									String count=Integer.toString(slaveKey); 
									newMapKey=mapKey+ExternalRuleConstant.SLAVE_KEY+count;
								}
								mapKey=newMapKey;
								partyAdminContequivBObj.setDescription(ExternalRuleConstant.SLAVE_KEY);
								partyAdminConteqMap.put(mapKey, partyAdminContequivBObj);
								}
							}
						
						
						}
				}
					
				}
				//surviveUCIDObj(partyAdminConteqMap,vecTempAdminContequivBObj,xConteq,control);

				
				
				// For Party Contact Method

				Vector<XContactMethodGroupBObjExt> vecTempPartyContactMethodBObj = new Vector<XContactMethodGroupBObjExt>();

				vecTempPartyContactMethodBObj = party
						.getItemsTCRMPartyContactMethodBObj();

				String firstPartyValidityContType = null;

				String secondPartyValidityContType = null;

				String firstPartyContMethodUsageType = null;

				String secondPartyContMethodUsageType = null;

				String firstPartyContMethodUsageValue = null;

				String secondPartyContMethodUsageValue = null;

				XPreferenceBObj incomingPrefObj = null;

				XPreferenceBObj PrefObjInMap = null;

				for (int j = 0; j < vecTempPartyContactMethodBObj.size(); j++) {

				 	
					XContactMethodGroupBObjExt partyContMethBObj = (XContactMethodGroupBObjExt) vecTempPartyContactMethodBObj.get(j);
					
					//Added by Sameeha for Removal of Deleted ContatMethods | 08thMay,2020 | Start
					
					XContactMethodBObjExt existingContMethBObj = (XContactMethodBObjExt) partyContMethBObj.getTCRMContactMethodBObj();
					
					if(!existingContMethBObj.getReferenceNumber().equalsIgnoreCase(ExternalRuleConstant.DELETED_VALUE)){
							
					//Added by Sameeha for Removal of Deleted ContatMethods | 08thMay,2020 | End

						firstPartyContMethodUsageValue = partyContMethBObj.getContactMethodUsageValue();
	
						firstPartyContMethodUsageType = partyContMethBObj.getContactMethodUsageType();
						
						incomingPrefObj=partyContMethBObj.getXPreferenceBObj();
	
						if (!partyContMethMap.containsKey(firstPartyContMethodUsageType)) {
	
							partyContMethMap.put(firstPartyContMethodUsageType,partyContMethBObj);
	
						} else {
	
							XContactMethodGroupBObjExt contMethodBObjInMap = partyContMethMap.get(firstPartyContMethodUsageType);
	
							secondPartyContMethodUsageValue = contMethodBObjInMap.getContactMethodUsageValue();
	
							secondPartyContMethodUsageType = contMethodBObjInMap.getContactMethodUsageType();
							
							PrefObjInMap=contMethodBObjInMap.getXPreferenceBObj();
	
							if (firstPartyContMethodUsageType.equalsIgnoreCase(secondPartyContMethodUsageType)) {
								
								Timestamp pref1CreatedDt=null;
								Timestamp pref2CreatedDt=null;
								if(incomingPrefObj!=null && PrefObjInMap!=null)
								if(!incomingPrefObj.getPreferredType().equalsIgnoreCase(PrefObjInMap.getPreferredType()))
								{
									 pref1CreatedDt = DateFormatter.getTimestamp(PrefObjInMap.getLastModifiedSystemDate());
	
									 pref2CreatedDt = DateFormatter.getTimestamp(incomingPrefObj.getLastModifiedSystemDate());
									
								}
	
								Timestamp party1CreatedDt = DateFormatter.getTimestamp(contMethodBObjInMap.getXLastModifiedSystemDate());
	
								Timestamp party2CreatedDt = DateFormatter.getTimestamp(partyContMethBObj.getXLastModifiedSystemDate());
								
								if (party1CreatedDt.after(party2CreatedDt)) {
									if(pref1CreatedDt!=null && pref2CreatedDt !=null)
									{
									if(pref1CreatedDt.after(pref2CreatedDt))
									{
									partyContMethMap.put(secondPartyContMethodUsageType,contMethodBObjInMap);
									}
									else
									{
										contMethodBObjInMap.getXPreferenceBObj().setPreferredType(incomingPrefObj.getPreferredType());
										contMethodBObjInMap.getXPreferenceBObj().setPreferredValue(incomingPrefObj.getPreferredValue());
										partyContMethMap.put(secondPartyContMethodUsageType, contMethodBObjInMap);
									}
									}
									else
									{
									partyContMethMap.put(secondPartyContMethodUsageType,contMethodBObjInMap);
									}
								}
	
								else {
									if(pref1CreatedDt!=null && pref2CreatedDt !=null)
									{
									if(pref2CreatedDt.after(pref1CreatedDt))
									{
									partyContMethMap.put(firstPartyContMethodUsageType,partyContMethBObj);
									}
									else
									{
										partyContMethBObj.getXPreferenceBObj().setPreferredType(PrefObjInMap.getPreferredType());
										partyContMethBObj.getXPreferenceBObj().setPreferredValue(PrefObjInMap.getPreferredValue());
										partyContMethMap.put(firstPartyContMethodUsageType,partyContMethBObj);
									}
									}
									else
									{
									partyContMethMap.put(firstPartyContMethodUsageType,partyContMethBObj);
									}
									//partyContMethMap.put(firstPartyContMethodUsageType,partyContMethBObj);
	
									}
	
								}
	
							}
						}
				}
			}
			
			

			//Remove DSC SourceParty from  Merge
			vecAllParty.removeAll(vecDSCParty);
			
			
			if(vecAllParty!=null && vecAllParty.size()>0)
			{
				    SurviveContequivKeys(vecAllParty,partyAdminConteqMap,wsMasterKey,control);
					// Survive UCID Objects Org
					//surviveUCIDObj(vecAllParty,partyAdminConteqMap,wsSFDCMasterParty, control);
					//Process Magic Number sorting for same Dealer but different Retailer JPN
					sortedMagicNumber( vecAllParty, partyAdminConteqMap, control);
					//PartyAddress Survivorship JPN
			
					partyAddressMap = survivedPartyAddressDetails(vecAllParty,partyAddressMap, control);
			}
		//processDSCSurvivorship(vecDSCParty, personNameMap,null, partyAddressMap, partyIdentMap, partyContMethMap, partyAdminConteqMap,control);

		HashMap<String, HashMap> partyMap = new HashMap<String, HashMap>();
		partyMap.put(ExternalRuleConstant.SURVIVED_MAP_NAME, personNameMap);
		partyMap.put(ExternalRuleConstant.SURVIVED_MAP_ADDRESS, partyAddressMap);
		partyMap.put(ExternalRuleConstant.SURVIVED_MAP_IDENTIFIER,
				partyIdentMap);
		partyMap.put(ExternalRuleConstant.SURVIVED_MAP_CONTACTMETHOD,
				partyContMethMap);
		partyMap.put(ExternalRuleConstant.SURVIVED_MAP_CONTEQUIV,
				partyAdminConteqMap);

		return partyMap;
	}
	
	private void processDSCSurvivorship(Vector<TCRMPartyBObj> vecDSCParty,HashMap<String, XPersonNameBObjExt> personNameMap,HashMap<String, XOrgNameBObjExt> orgNameMap,HashMap<String, XAddressGroupBObjExt> partyAddressMap, HashMap<String, XIdentifierBObjExt> partyIdentMap,HashMap<String, XContactMethodGroupBObjExt> partyContMethMap,HashMap<String, XContEquivBObjExt> partyAdminConteqMap, DWLControl control) throws Exception
	{
		
		for(TCRMPartyBObj dscParty : vecDSCParty)
		{
			Vector<XPersonNameBObjExt> vecDSCPersonName=new Vector<XPersonNameBObjExt>();
			Vector<XOrgNameBObjExt> vecDSCOrgName=new Vector<XOrgNameBObjExt>();
			if(dscParty instanceof XPersonBObjExt)
			{
				XPersonBObjExt dscPerson=(XPersonBObjExt) dscParty;
				vecDSCPersonName=dscPerson.getItemsTCRMPersonNameBObj();
			}
			else if(dscParty instanceof XOrgBObjExt)
			{
				XOrgBObjExt dscOrg=(XOrgBObjExt) dscParty;
				vecDSCOrgName=dscOrg.getItemsTCRMOrganizationNameBObj();
			}
			Vector<XContEquivBObjExt> vecDSCContequiv=dscParty.getItemsTCRMAdminContEquivBObj();
			Vector<XIdentifierBObjExt> vecDSCIdentifier=dscParty.getItemsTCRMPartyIdentificationBObj();
			Vector<XAddressGroupBObjExt> vecDSCAddress=dscParty.getItemsTCRMPartyAddressBObj();
			Vector<XContactMethodGroupBObjExt> vecDSCContact=dscParty.getItemsTCRMPartyContactMethodBObj();
			
			if(vecDSCPersonName!=null && vecDSCPersonName.size()>0)
			for(XPersonNameBObjExt dscPersonName : vecDSCPersonName)
			{
				String dscPersonNameUsageType=dscPersonName.getNameUsageType();
				if(!personNameMap.containsKey(dscPersonNameUsageType))
				{
					personNameMap.put(dscPersonNameUsageType, dscPersonName);
				}
				else
				{
					XPersonNameBObjExt personNameInMap=personNameMap.get(dscPersonNameUsageType);
					if(personNameInMap.getSourceIdentifierType().equalsIgnoreCase(ExternalRuleConstant.DSC_SOURCE_TYPE))
					{
						
						Timestamp person1CreatedDt = DateFormatter.getTimestamp(personNameInMap.getXLastModifiedSystemDate());
						Timestamp person2CreatedDt = DateFormatter.getTimestamp(dscPersonName.getXLastModifiedSystemDate());

						
							if (person1CreatedDt.after(person2CreatedDt)) {
								personNameMap.put(dscPersonNameUsageType,personNameInMap);
							} else {
								personNameMap.put(dscPersonNameUsageType,dscPersonName);
							}

						
					}
				}
				
				
			}
			
			if(vecDSCOrgName!=null && vecDSCOrgName.size()>0)
				for(XOrgNameBObjExt dscOrgName : vecDSCOrgName)
				{
					String dscOrgNameUsageType=dscOrgName.getNameUsageType();
					if(!orgNameMap.containsKey(dscOrgNameUsageType))
					{
						orgNameMap.put(dscOrgNameUsageType, dscOrgName);
					}
					else
					{
						XOrgNameBObjExt orgNameInMap=orgNameMap.get(dscOrgNameUsageType);
						if(orgNameInMap.getSourceIdentifierType().equalsIgnoreCase(ExternalRuleConstant.DSC_SOURCE_TYPE))
						{
							
							Timestamp org1CreatedDt = DateFormatter.getTimestamp(orgNameInMap.getXLastModifiedSystemDate());
							Timestamp org2CreatedDt = DateFormatter.getTimestamp(dscOrgName.getXLastModifiedSystemDate());

							
								if (org1CreatedDt.after(org2CreatedDt)) {
									orgNameMap.put(dscOrgNameUsageType,orgNameInMap);
								} else {
									orgNameMap.put(dscOrgNameUsageType,dscOrgName);
								}

							
						}
					}
					
					
				}
			
			for(XIdentifierBObjExt dscIdenObj : vecDSCIdentifier)
			{
				String dscIdentifierType=dscIdenObj.getIdentificationType();
			if(!partyIdentMap.containsKey(dscIdentifierType))
			{
				partyIdentMap.put(dscIdentifierType, dscIdenObj);
			}
			else
			{
			XIdentifierBObjExt idenBObjInMap=partyIdentMap.get(dscIdentifierType);
			if(idenBObjInMap.getSourceIdentifierType().equalsIgnoreCase(ExternalRuleConstant.DSC_SOURCE_TYPE))
			{
			Timestamp party1CreatedDt = DateFormatter.getTimestamp(idenBObjInMap.getXLastModifiedSystemDate());

			Timestamp party2CreatedDt = DateFormatter.getTimestamp(dscIdenObj.getXLastModifiedSystemDate());

			if (party1CreatedDt.after(party2CreatedDt)) {

				partyIdentMap.put(dscIdentifierType,idenBObjInMap);
			}

			else {

				partyIdentMap.put(dscIdentifierType,dscIdenObj);
			}
			}
			}
			
			}
			
			

			String firstPartyContMethodUsageType = null;

			String secondPartyContMethodUsageType = null;

			String firstPartyContMethodUsageValue = null;

			String secondPartyContMethodUsageValue = null;

			XPreferenceBObj incomingPrefObj = null;

			XPreferenceBObj PrefObjInMap = null;
			
			//Party Contact Method DSC Survivorship
			for(XContactMethodGroupBObjExt partyContMethBObj : vecDSCContact)
			{
				//String dscContactType=contMethGrp.getContactMethodUsageType();


				//XContactMethodGroupBObjExt partyContMethBObj = (XContactMethodGroupBObjExt) vecTempPartyContactMethodBObj.get(j);

				firstPartyContMethodUsageValue = partyContMethBObj.getContactMethodUsageValue();

				firstPartyContMethodUsageType = partyContMethBObj.getContactMethodUsageType();
				
				incomingPrefObj=partyContMethBObj.getXPreferenceBObj();

				if (!partyContMethMap.containsKey(firstPartyContMethodUsageType)) {

					partyContMethMap.put(firstPartyContMethodUsageType,partyContMethBObj);

				} else {
					

					XContactMethodGroupBObjExt contMethodBObjInMap = partyContMethMap.get(firstPartyContMethodUsageType);
					
					if(contMethodBObjInMap.getSourceIdentifierType().equalsIgnoreCase(ExternalRuleConstant.DSC_SOURCE_TYPE))
					{

					secondPartyContMethodUsageValue = contMethodBObjInMap.getContactMethodUsageValue();

					secondPartyContMethodUsageType = contMethodBObjInMap.getContactMethodUsageType();
					
					PrefObjInMap=contMethodBObjInMap.getXPreferenceBObj();

					if (firstPartyContMethodUsageType.equalsIgnoreCase(secondPartyContMethodUsageType)) {
						
						Timestamp pref1CreatedDt=null;
						Timestamp pref2CreatedDt=null;
						if(incomingPrefObj!=null && PrefObjInMap!=null)
						if(!incomingPrefObj.getPreferredType().equalsIgnoreCase(PrefObjInMap.getPreferredType()))
						{
							 pref1CreatedDt = DateFormatter.getTimestamp(PrefObjInMap.getLastModifiedSystemDate());

							 pref2CreatedDt = DateFormatter.getTimestamp(incomingPrefObj.getLastModifiedSystemDate());
							
						}

						Timestamp party1CreatedDt = DateFormatter.getTimestamp(contMethodBObjInMap.getXLastModifiedSystemDate());

						Timestamp party2CreatedDt = DateFormatter.getTimestamp(partyContMethBObj.getXLastModifiedSystemDate());
						
						if (party1CreatedDt.after(party2CreatedDt)) {
							if(pref1CreatedDt!=null && pref2CreatedDt !=null)
							{
							if(pref1CreatedDt.after(pref2CreatedDt))
							{
							partyContMethMap.put(secondPartyContMethodUsageType,contMethodBObjInMap);
							}
							else
							{
								contMethodBObjInMap.getXPreferenceBObj().setPreferredType(incomingPrefObj.getPreferredType());
								contMethodBObjInMap.getXPreferenceBObj().setPreferredValue(incomingPrefObj.getPreferredValue());
								partyContMethMap.put(secondPartyContMethodUsageType, contMethodBObjInMap);
							}
							}
							else
							{
							partyContMethMap.put(secondPartyContMethodUsageType,contMethodBObjInMap);
							}
						}

						else {
							if(pref1CreatedDt!=null && pref2CreatedDt !=null)
							{
							if(pref2CreatedDt.after(pref1CreatedDt))
							{
							partyContMethMap.put(firstPartyContMethodUsageType,partyContMethBObj);
							}
							else
							{
								partyContMethBObj.getXPreferenceBObj().setPreferredType(PrefObjInMap.getPreferredType());
								partyContMethBObj.getXPreferenceBObj().setPreferredValue(PrefObjInMap.getPreferredValue());
								partyContMethMap.put(firstPartyContMethodUsageType,partyContMethBObj);
							}
							}
							else
							{
							partyContMethMap.put(firstPartyContMethodUsageType,partyContMethBObj);
							}
							//partyContMethMap.put(firstPartyContMethodUsageType,partyContMethBObj);

						}

					}
				}
				}

			
				
			}
			
			//Address DSC
			
			
		}
		
		
	}
	
	
		
	
	
	
	private boolean checkPartiesforActiveMyMId(Vector vecAllParty, Vector<String> vecMymPartyId, DWLControl control) throws Exception
	{
		boolean MyMExists=false;
		int mymCount=0;
		//Vector<String> vecMymPartyId=new Vector<String>();
		Vector<XContEquivBObjExt> vecTempAdminContequivBObj=new Vector<XContEquivBObjExt>();
		for (int i = 0; i < vecAllParty.size(); i++) {

			TCRMPartyBObj party = (TCRMPartyBObj) vecAllParty.get(i);
			vecTempAdminContequivBObj = party.getItemsTCRMAdminContEquivBObj();
			for(XContEquivBObjExt currXCont : vecTempAdminContequivBObj)
			{
				if(ExternalRuleConstant.MYMERC_SOURCETYPE.equalsIgnoreCase(currXCont.getAdminSystemType()))
				{
					mymCount++;
					vecMymPartyId.add(party.getPartyId());
					break;
				}
			}
		}
		
		if(mymCount>1)
		{
			MyMExists=true;
		}
		return MyMExists;
		
	}
	
	
	
	
	
	
	private Vector<XContEquivBObjExt > processSlaveSourceKeys(Vector vecAllParty,DWLControl control) throws Exception
	{
		logger.info("In Process Slave Source Keys .");
		
		try {
			
			Vector<XContEquivBObjExt> allSlaveKeys=new Vector<XContEquivBObjExt>();
			Vector<XContEquivBObjExt> vecSlaveKeys=new Vector<XContEquivBObjExt>();
			Vector<XContEquivBObjExt> currPartyEquiv=new Vector<XContEquivBObjExt>();
			for (TCRMPartyBObj currParty : (Vector<TCRMPartyBObj>)vecAllParty)
			{
				currPartyEquiv=currParty.getItemsTCRMAdminContEquivBObj();
				for(XContEquivBObjExt currEquiv : currPartyEquiv)
				{
					if(currEquiv.getDescription()!=null && currEquiv.getDescription().equalsIgnoreCase(ExternalRuleConstant.SLAVE_KEY))
					{
						vecSlaveKeys.add(currEquiv);
					}
				}
				currParty.getItemsTCRMAdminContEquivBObj().removeAll(vecSlaveKeys);
				allSlaveKeys.addAll(vecSlaveKeys);
				vecSlaveKeys.clear();
			}
					
			return allSlaveKeys;
			
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception(e.getMessage());
		}
		
		
	}
	
	private void SurviveContequivKeys(Vector vecAllParty, HashMap<String, XContEquivBObjExt> adminContMap, XContEquivBObjExt wsMasterKey, DWLControl control) throws Exception {
		
		
		try{
		DSEAAdditionsExtsComponent dseac =new DSEAAdditionsExtsComponent();
		//String masterRetailerId=null;
		DWLResponse getRetailerResp=null;
		XRetailerBObj retailerObjMaster=new XRetailerBObj();
		Vector<XContEquivBObjExt> vecContequivObjs=new Vector<XContEquivBObjExt>();
		Vector<String> vecMasterGCCode=new Vector<String>();
		TCRMPartyBObj survivedsfdcparty = null;
		
		
		for(TCRMPartyBObj currParty : (Vector<TCRMPartyBObj>)vecAllParty)
		{
			
			for(XContEquivBObjExt currEquiv : (Vector<XContEquivBObjExt>)currParty.getItemsTCRMAdminContEquivBObj())
			{
				if(currEquiv.getXSourceRetailerFlag()!=null && currEquiv.getAdminSystemType().equalsIgnoreCase(ExternalRuleConstant.SOURCE_IDENTIFIER_TYPE_SFDC))
				if(currEquiv.getXSourceRetailerFlag().equalsIgnoreCase(ExternalRuleConstant.PREFERRED_VALUE_N))
				{
					//Wholesale SFDC Id from All Parties
					vecContequivObjs.add(currEquiv);
				}
				
			}
	
			
		}
		
		
		
		if(null!= vecContequivObjs && vecContequivObjs.size()>0)
		{
			String firstPartyAdminSysType = null;
			String mapKey = null;
			HashMap<String, XContEquivBObjExt> partyAdminConteqMap = new HashMap<String, XContEquivBObjExt>();
			
			for(XContEquivBObjExt tempAdminContequivBObj : vecContequivObjs)
			{
				
				firstPartyAdminSysType = tempAdminContequivBObj.getAdminSystemType();
				if(null != firstPartyAdminSysType && firstPartyAdminSysType.equalsIgnoreCase(ExternalRuleConstant.SOURCE_IDENTIFIER_TYPE_SFDC))
				{
				mapKey = firstPartyAdminSysType;
				if(!partyAdminConteqMap.containsKey(firstPartyAdminSysType)){
					partyAdminConteqMap.put(firstPartyAdminSysType,tempAdminContequivBObj);
				}
				
				else{
					XContEquivBObjExt contEquivBObjInMap = partyAdminConteqMap.get(firstPartyAdminSysType);

					Timestamp person1IDLastModifiedDate = DateFormatter.getTimestamp(tempAdminContequivBObj.getXLastModifiedSystemDate());
					Timestamp person2IDLastModifiedDate = DateFormatter.getTimestamp(contEquivBObjInMap.getXLastModifiedSystemDate());
					
						

							//In case of SFID Type clash survive the Oldest SFID
							if(null != person1IDLastModifiedDate && null !=person2IDLastModifiedDate
									&& person1IDLastModifiedDate.after(person2IDLastModifiedDate)){
								partyAdminConteqMap.put(mapKey, contEquivBObjInMap);
							}else{
								partyAdminConteqMap.put(mapKey, tempAdminContequivBObj);
							}
						
					
				}
				} 
			}
			wsMasterKey = partyAdminConteqMap.get(mapKey);
		}
		
		
		
		for(TCRMPartyBObj currParty : (Vector<TCRMPartyBObj>)vecAllParty)
		{
			
			for(XContEquivBObjExt currEquiv : (Vector<XContEquivBObjExt>)currParty.getItemsTCRMAdminContEquivBObj())
			{
				if(currEquiv.getXSourceRetailerFlag()!=null && currEquiv.getAdminSystemType().equalsIgnoreCase(ExternalRuleConstant.SOURCE_IDENTIFIER_TYPE_SFDC))
				if(currEquiv.getAdminPartyId().equalsIgnoreCase(wsMasterKey.getAdminPartyId()))
				{
					survivedsfdcparty = currParty;
				}
				
			}
	
			
		}
		
		
		
		
		
		vecContequivObjs.remove(wsMasterKey);
		//vecContequivObjs.remove(rtMasterKey);
		String mapKey=null;
		
		
		
		if(wsMasterKey!=null)
		{
		wsMasterKey.setDescription(ExternalRuleConstant.MASTER_KEY);
		mapKey=wsMasterKey.getAdminSystemType()+survivedsfdcparty.getPartyId();
		adminContMap.put(mapKey, wsMasterKey);
		}
		
			
			
			int slaveIndex=1;
			
			for(XContEquivBObjExt currContEquiv : vecContequivObjs)
			{
				if(currContEquiv.getAdminSystemType().equalsIgnoreCase(ExternalRuleConstant.SOURCE_IDENTIFIER_TYPE_SFDC))
				{
					if(currContEquiv.getXSourceRetailerFlag().equalsIgnoreCase(ExternalRuleConstant.ACTIVE_FLAG_N))
					
					{
						currContEquiv.setDescription(ExternalRuleConstant.SLAVE_KEY);
						mapKey=currContEquiv.getAdminSystemType()+ExternalRuleConstant.SLAVE_KEY+Integer.toString(slaveIndex);
						adminContMap.put(mapKey, currContEquiv);
						slaveIndex++;
						
					}
					
				}
			}
			
			surviveUCIDObj(vecAllParty,adminContMap,survivedsfdcparty, control);
			
			
		}
		catch(Exception e)
		{
		 e.printStackTrace();
		 throw new BusinessProxyException(e.getMessage()); 
		 
		}

	}
	
	
	
	
	
	private void surviveUCIDObj(Vector vecAllParty, HashMap<String, XContEquivBObjExt> adminContMap, TCRMPartyBObj wsMasterParty, DWLControl control) throws Exception
	{
		Vector<XContEquivBObjExt> vecTempAdminContequivBObj=new Vector<XContEquivBObjExt>();
		Vector<XContEquivBObjExt> vecUCIDObj=new Vector<XContEquivBObjExt>();
		XContEquivBObjExt survivingUcidObj=null;
		String survivedSFIDContID = null;
		//System.out.println("++++ UCID Survivorship +++++");
		for (int i = 0; i < vecAllParty.size(); i++) {

			TCRMPartyBObj party = (TCRMPartyBObj) vecAllParty.get(i);
			vecTempAdminContequivBObj = party.getItemsTCRMAdminContEquivBObj();
			for(XContEquivBObjExt currXCont : vecTempAdminContequivBObj)
			{
				if(ExternalRuleConstant.UCID_SOURCE_TYPE.equalsIgnoreCase(currXCont.getAdminSystemType()))
				{
					vecUCIDObj.add(currXCont);
					
					
			}
			
		
		}
		}
		
		if(wsMasterParty.getPartyId()!=null){
			survivedSFIDContID = wsMasterParty.getPartyId();
		}
		
		for (int i = 0; i < vecAllParty.size(); i++) {

			TCRMPartyBObj party = (TCRMPartyBObj) vecAllParty.get(i);
			vecTempAdminContequivBObj = party.getItemsTCRMAdminContEquivBObj();
			for(XContEquivBObjExt currXCont : vecTempAdminContequivBObj)
			{
				if(ExternalRuleConstant.UCID_SOURCE_TYPE.equalsIgnoreCase(currXCont.getAdminSystemType()))
				{
					if(survivedSFIDContID.equalsIgnoreCase(currXCont.getPartyId()))
					{
						survivingUcidObj = currXCont;
						break;
					}
					
					
					
			}
			
		
		}
		}
		
			
		
		
		String mapKey=survivingUcidObj.getAdminSystemType();
		survivingUcidObj.setDescription(ExternalRuleConstant.MASTER_KEY);
		adminContMap.put(mapKey, survivingUcidObj);
		
		vecUCIDObj.remove(survivingUcidObj);
		int slaveKey=1;
		
		for(XContEquivBObjExt ucidObj : vecUCIDObj)
		{
			String newMapKey=mapKey+ExternalRuleConstant.SLAVE_KEY+Integer.toString(slaveKey);
			mapKey=newMapKey;
			ucidObj.setDescription(ExternalRuleConstant.SLAVE_KEY);
			adminContMap.put(mapKey, ucidObj);
			slaveKey++;
		}

	}
	
	
	private HashMap<String, XAddressGroupBObjExt> survivedPartyAddressDetails( Vector<TCRMPartyBObj> vecAllParty, HashMap<String, XAddressGroupBObjExt> partyAddressMap, DWLControl control) throws Exception {
		Vector<XAddressGroupBObjExt> vecAllAddressBObj = new Vector<XAddressGroupBObjExt>();
		/*if(vecAllParty.firstElement() instanceof XPersonBObjExt)
		{
		//Vector<XPersonBObjExt> vecXpersonObj=((Vector<XPersonBObjExt>)vecAllParty);
		for (TCRMPartyBObj personBObj : vecAllParty) {
			XPersonBObjExt XpersonObj=(XPersonBObjExt) personBObj;
			vecAllAddressBObj.addAll(XpersonObj.getItemsTCRMPartyAddressBObj());
		}
		}
		else if(vecAllParty.firstElement() instanceof XOrgBObjExt)
		{
			for (TCRMPartyBObj orgBobj : vecAllParty) {
				XOrgBObjExt xOrgObj=(XOrgBObjExt)orgBobj
				vecAllAddressBObj.addAll(xOrgObj.getItemsTCRMPartyAddressBObj());
			}
		}*/
		/*if (vecAllAddressBObj.size() != 0) {*/

			// For Party Address
		
		XPersonBObjExt incomingPersonBObj=null;
		XOrgBObjExt incomingOrgBobj=null;
		
		if(vecAllParty.firstElement() instanceof XPersonBObjExt)
		{
			//XPersonBObjExt XpersonObj=(XPersonBObjExt) personBObj;
			 incomingPersonBObj = ((XPersonBObjExt) ((TCRMPartyBObj)vecAllParty
					.get(0)));
		}
		else if(vecAllParty.firstElement() instanceof XOrgBObjExt)
		{
			 incomingOrgBobj= ((XOrgBObjExt) ((TCRMPartyBObj)vecAllParty
					.get(0)));
		}

			// For Japan Initialization
			if ((incomingPersonBObj!=null && incomingPersonBObj.getXMarketName().equalsIgnoreCase(ExternalRuleConstant.JAPAN_MARKET_NAME))
					 || (incomingOrgBobj!=null && incomingOrgBobj.getXMarketName().equalsIgnoreCase(ExternalRuleConstant.JAPAN_MARKET_NAME))) 
			{

				String mapKey = null;

				String wsAddrTypeSet = null;

				HashMap<String, Vector<XAddressGroupBObjExt>> retailerAddressMap = new HashMap<String, Vector<XAddressGroupBObjExt>>();

				Vector<XAddressGroupBObjExt> vecIncomingPartyAddressBObj = new Vector<XAddressGroupBObjExt>();

				Vector<XAddressGroupBObjExt> vecWSPartyAddressBObj = new Vector<XAddressGroupBObjExt>();

				Vector<XAddressGroupBObjExt> vecRetailerPartyAddressBObj = new Vector<XAddressGroupBObjExt>();

			

/*				XAddressGroupBObjExt incomingHomeAddrBObj = null;

				// Incoming Party addresses
				vecIncomingPartyAddressBObj = incomingPersonBObj.getItemsTCRMPartyAddressBObj();

				for (XAddressGroupBObjExt incomingAddrBObj : vecIncomingPartyAddressBObj) {

					if (incomingAddrBObj.getXAddressRetailerFlag().equalsIgnoreCase(ExternalRuleConstant.CHARACTER_Y)) {

						// partyAddressMap.put(ExternalRuleConstant.ADDRESS_USAGE_TYPE_P,incomingAddrBObj);

						vecRetailerPartyAddressBObj.add(incomingAddrBObj);

						retailerAddressMap.put(incomingAddrBObj.getXRetailerId(), null);

					} else {

						incomingHomeAddrBObj = incomingAddrBObj;

						vecWSPartyAddressBObj.add(incomingHomeAddrBObj);

					}
				}*/

				// Get all Party Addresses of suspects
				for (int i = 0; i < vecAllParty.size(); i++) {

					//XPersonBObjExt tempPersonBObj = (XPersonBObjExt) vecAllParty.get(i);

					Vector<XAddressGroupBObjExt> vecTempAddressBObj = vecAllParty.get(i).getItemsTCRMPartyAddressBObj();

					if (vecTempAddressBObj.size() != 0) {

						for (XAddressGroupBObjExt tempAddrBObj : vecTempAddressBObj) {
							//6thMay,2020 Added by Sameeha to exclude Deleted address from Merge | Start
							XAddressBObjExt xAddressBObjExt = (XAddressBObjExt) tempAddrBObj.getTCRMAddressBObj();

							if(!xAddressBObjExt.getAddressLineOne().equalsIgnoreCase(ExternalRuleConstant.DELETED_VALUE))
							{ 							
							//6thMay,2020 Added by Sameeha to exclude Deleted address from Merge | End

								if (tempAddrBObj.getXAddressRetailerFlag().equalsIgnoreCase(ExternalRuleConstant.CHARACTER_Y)) {
		
									vecRetailerPartyAddressBObj.add(tempAddrBObj);
		
									retailerAddressMap.put(tempAddrBObj.getXRetailerId(), null);
		
								} else {
		
									vecWSPartyAddressBObj.add(tempAddrBObj);
								}
							}
						}
					}
				}

				// For Each Retailer

				Set<String> keySet = new HashSet<String>();

				keySet.addAll(retailerAddressMap.keySet());

				Vector<XAddressGroupBObjExt> tempRetAddrBObj;

				for (int i = 0; i < vecRetailerPartyAddressBObj.size(); i++) {

					tempRetAddrBObj = new Vector<XAddressGroupBObjExt>();

					XAddressGroupBObjExt tempAddrGroupBObj = vecRetailerPartyAddressBObj.elementAt(i);

					String retailerId = tempAddrGroupBObj.getXRetailerId();

					if (retailerAddressMap.get(retailerId) != null) {

						tempRetAddrBObj.addAll(retailerAddressMap.get(retailerId));

					}

					tempRetAddrBObj.add(tempAddrGroupBObj);

					retailerAddressMap.put(retailerId, tempRetAddrBObj);
					// tempRetAddrBObj.removeAllElements();

				}

				vecRetailerPartyAddressBObj.removeAllElements();

				for (String key : keySet) {

					vecRetailerPartyAddressBObj.addAll(retailerAddressMap.get(key));

					for (int i = 0; i < vecRetailerPartyAddressBObj.size(); i++) {

						XAddressGroupBObjExt tempAddrGroupBObj = vecRetailerPartyAddressBObj.elementAt(i);

						mapKey =  tempAddrGroupBObj.getXRetailerId() + tempAddrGroupBObj.getXAddressRetailerFlag();

						if (!(partyAddressMap.containsKey(mapKey))) {

							partyAddressMap.put(mapKey, tempAddrGroupBObj);

						}else{
							
							XAddressGroupBObjExt retailerAddressBObjInMap = partyAddressMap.get(mapKey);
							
							boolean sourceDSCInMap=false;
							boolean sourceDSCIncoming=false;
							if(retailerAddressBObjInMap.getSourceIdentifierType().equalsIgnoreCase(ExternalRuleConstant.DSC_SOURCE_TYPE))
							{
								sourceDSCInMap=true;
							}
							if(tempAddrGroupBObj.getSourceIdentifierType().equalsIgnoreCase(ExternalRuleConstant.DSC_SOURCE_TYPE))
							{
								sourceDSCIncoming=true;
							}
							
							Timestamp party1CreatedDt = DateFormatter.getTimestamp(tempAddrGroupBObj.getXLastModifiedSystemDate());

							Timestamp party2CreatedDt = DateFormatter.getTimestamp(retailerAddressBObjInMap.getXLastModifiedSystemDate());
							if(sourceDSCIncoming==sourceDSCInMap)
							{
							if(party1CreatedDt.after(party2CreatedDt))
							{
								partyAddressMap.put(mapKey, tempAddrGroupBObj);	
							}
							else
							{
								partyAddressMap.put(mapKey, retailerAddressBObjInMap);
							}
							}
							else if(sourceDSCIncoming)
							{
								partyAddressMap.put(mapKey, retailerAddressBObjInMap);
								
							}
							else if(sourceDSCInMap)
							{
								partyAddressMap.put(mapKey, tempAddrGroupBObj);	
							}
								
							
						}
					}
					
					vecRetailerPartyAddressBObj.removeAllElements();
					

				}
				
				// Survive Golden WS Addresses
 
				if (vecWSPartyAddressBObj.size() != 0) {
					
					//HashMap<String, XAddressGroupBObjExt> duplicateAddressMap=new HashMap<String, XAddressGroupBObjExt>();
					Vector<XAddressGroupBObjExt> vecduplicateAddress=new Vector<XAddressGroupBObjExt>();
					Vector<XAddressGroupBObjExt> vecAllduplicateAddresses=new Vector<XAddressGroupBObjExt>();
					Vector<XAddressGroupBObjExt> vecSurvivingAddress=new Vector<XAddressGroupBObjExt>();
					
					//Vector<String> vecToRemoveAddr=new Vector<String>();
					for (int i = 0; i < vecWSPartyAddressBObj.size(); i++) {

						
						XAddressGroupBObjExt firstPartyAddrBobj = vecWSPartyAddressBObj
								.elementAt(i);
						if(!vecAllduplicateAddresses.contains(firstPartyAddrBobj))
						{
							vecduplicateAddress.add(firstPartyAddrBobj);
						
						for(int j=i+1; j<vecWSPartyAddressBObj.size(); j++)
						{
							XAddressGroupBObjExt secondPartyAddrBobj = vecWSPartyAddressBObj
									.elementAt(j);
							
							if(isAddressMatched(firstPartyAddrBobj, secondPartyAddrBobj, control))
							{
								
								vecduplicateAddress.add(secondPartyAddrBobj);
								
							}
						}
						surviveGoldenAddressFromDuplicates(vecSurvivingAddress,vecduplicateAddress,control);
						vecAllduplicateAddresses.addAll(vecduplicateAddress);
						vecduplicateAddress.clear();
						
						}
						
					}
					
					vecWSPartyAddressBObj.removeAll(vecAllduplicateAddresses);
					vecWSPartyAddressBObj.addAll(vecSurvivingAddress);
					/*for(XAddressGroupBObjExt cuurX : vecWSPartyAddressBObj)
					{
					System.out.println("Surviving Non Duplicate Addresses"+ cuurX.toXML("TCRM", "MDMDomains.xsd", 0, null, false));
					}*/
					
					
					TreeSet<String> kanjiAddressSet=new  TreeSet<String>();
					TreeSet<String> kanaAddressSet=new  TreeSet<String>();
					Vector<String> vecPrimeAddressType=new Vector<String>();
					//Vector<String> vecHomeAddressType=new Vector<String>();
					//Vector<String> vecWorkAddressType=new Vector<String>();
					vecPrimeAddressType.add(ExternalRuleConstant.ADDRESS_USAGE_TYPE_HOME_KANA_ADDRESS);
					vecPrimeAddressType.add(ExternalRuleConstant.ADDRESS_USAGE_TYPE_HOME_KANJI_ADDRESS);
					vecPrimeAddressType.add(ExternalRuleConstant.ADDRESS_USAGE_TYPE_BUSINESS_KANJI_ADDRESS);
					vecPrimeAddressType.add(ExternalRuleConstant.ADDRESS_USAGE_TYPE_BUSINESS_KANA_ADDRESS);
					
					kanaAddressSet.add(ExternalRuleConstant.ADDRESS_USAGE_TYPE_OTHER_KANA_ADDRESS_1);
					kanaAddressSet.add(ExternalRuleConstant.ADDRESS_USAGE_TYPE_OTHER_KANA_ADDRESS_2);
					kanaAddressSet.add(ExternalRuleConstant.ADDRESS_USAGE_TYPE_OTHER_KANA_ADDRESS_3);
					kanjiAddressSet.add(ExternalRuleConstant.ADDRESS_USAGE_TYPE_OTHER_KANJI_ADDRESS_1);
					kanjiAddressSet.add(ExternalRuleConstant.ADDRESS_USAGE_TYPE_OTHER_KANJI_ADDRESS_2);
					kanjiAddressSet.add(ExternalRuleConstant.ADDRESS_USAGE_TYPE_OTHER_KANJI_ADDRESS_3);
					
					
					Vector<XAddressGroupBObjExt> vecSortedOtherAddress=new Vector<XAddressGroupBObjExt>();
					//Vector<XAddressGroupBObjExt> vecSortedPrimeAddress=new Vector<XAddressGroupBObjExt>();
					sortOtherPartyAddress(vecWSPartyAddressBObj, vecSortedOtherAddress, vecPrimeAddressType, control);
					
					vecWSPartyAddressBObj.removeAll(vecSortedOtherAddress);
					
					sortPrimeAddress(vecWSPartyAddressBObj, control);
/*					Vector<String> vecOtherAddressType=new Vector<String>();*/
					//HashMap<String, XAddressGroupBObjExt> otherAddressMap=new HashMap<String, XAddressGroupBObjExt>();
					
					
					
					
					
					for (int i = 0; i < vecWSPartyAddressBObj.size(); i++) {
					

						XAddressGroupBObjExt wsPartyAddressGroupBObj = vecWSPartyAddressBObj
								.elementAt(i);
						String currMapKey=wsPartyAddressGroupBObj.getAddressUsageType();
						if(!partyAddressMap.containsKey(currMapKey))
						{
						partyAddressMap.put(currMapKey, wsPartyAddressGroupBObj);
						//System.out.println("Surviving Non Duplicate Addresses : "+currMapKey+ wsPartyAddressGroupBObj.toXML("TCRM", "MDMDomains.xsd", 0, null, false));
						}
						
						else
						{
							XAddressGroupBObjExt addrBObjInMap = partyAddressMap.get(currMapKey);
							
							boolean sourceDSCInMap=false;
							boolean sourceDSCIncoming=false;
							
							String currPreference=null;
							String preferenceInMap=null;
							
							if(addrBObjInMap.getSourceIdentifierType().equalsIgnoreCase(ExternalRuleConstant.DSC_SOURCE_TYPE))
							{
								sourceDSCInMap=true;
							}
							if(wsPartyAddressGroupBObj.getSourceIdentifierType().equalsIgnoreCase(ExternalRuleConstant.DSC_SOURCE_TYPE))
							{
								sourceDSCIncoming=true;
							}
							
							//secondPartyNameUsageType = personnameBObj.getNameUsageType();
							Timestamp addr1CreatedDt = DateFormatter.getTimestamp(addrBObjInMap.getXLastModifiedSystemDate());
							Timestamp addr2CreatedDt = DateFormatter.getTimestamp(wsPartyAddressGroupBObj.getXLastModifiedSystemDate());
							if(addrBObjInMap.getXPreferenceBObj()!=null && addrBObjInMap.getXPreferenceBObj().getPreferredType()!=null)
							{
							 preferenceInMap=addrBObjInMap.getXPreferenceBObj().getPreferredType();
							}
							if(wsPartyAddressGroupBObj.getXPreferenceBObj()!=null && wsPartyAddressGroupBObj.getXPreferenceBObj().getPreferredType()!=null)
							{
							 currPreference=wsPartyAddressGroupBObj.getXPreferenceBObj().getPreferredType();
							}
							//boolean keepMapObjectOnly=false;
							//XPreferenceBObj survivingPref=surviveAddressPreference(addrBObjInMap,wsPartyAddressGroupBObj, control)
							//if(addrBObjInMap.getXPreferenceBObj().getPreferredType().equalsIgnoreCase(ExternalRuleConstant.PREFERRED_TYPE_Y))
							/*if(preferenceInMap.equalsIgnoreCase(ExternalRuleConstant.PREFERRED_TYPE_Y) && currPreference.equalsIgnoreCase(ExternalRuleConstant.PREFERRED_TYPE_N))
							{
								keepMapObjectOnly=true;
							}*/
							/*else if((preferenceInMap.equalsIgnoreCase(ExternalRuleConstant.PREFERRED_TYPE_N) && currPreference.equalsIgnoreCase(ExternalRuleConstant.PREFERRED_TYPE_Y)))
							{
								
							}*/
								if(preferenceInMap==null || currPreference==null || (preferenceInMap!=null && currPreference!=null && preferenceInMap.equalsIgnoreCase(currPreference)))
								{
									if(sourceDSCIncoming==sourceDSCInMap)
									{
										if (addr1CreatedDt.after(addr2CreatedDt)) {
											partyAddressMap.put(currMapKey,addrBObjInMap);
									
											setOtherAddressObjInMap(partyAddressMap, currMapKey, wsPartyAddressGroupBObj, kanjiAddressSet,kanaAddressSet, control);
									
									
										} else{
											partyAddressMap.put(currMapKey,wsPartyAddressGroupBObj);
											setOtherAddressObjInMap(partyAddressMap, currMapKey, addrBObjInMap, kanjiAddressSet,kanaAddressSet, control);
										}
									}
									else if(sourceDSCIncoming)
									{
										partyAddressMap.put(currMapKey,addrBObjInMap);
										
										setOtherAddressObjInMap(partyAddressMap, currMapKey, wsPartyAddressGroupBObj, kanjiAddressSet,kanaAddressSet, control);
									}
									else if(sourceDSCInMap)
									{
										partyAddressMap.put(currMapKey,wsPartyAddressGroupBObj);
										setOtherAddressObjInMap(partyAddressMap, currMapKey, addrBObjInMap, kanjiAddressSet,kanaAddressSet, control);
									}
								}
								else
								{
									if(sourceDSCIncoming==sourceDSCInMap)
									{
									if(preferenceInMap.equalsIgnoreCase(ExternalRuleConstant.PREFERRED_TYPE_Y))
									{
										partyAddressMap.put(currMapKey,addrBObjInMap);
										
										setOtherAddressObjInMap(partyAddressMap, currMapKey, wsPartyAddressGroupBObj, kanjiAddressSet,kanaAddressSet, control);
										
										//System.out.println("Surviving Non Duplicate Addresses : "+currMapKey+ addrBObjInMap.toXML("TCRM", "MDMDomains.xsd", 0, null, false));
									}
									else if(currPreference.equalsIgnoreCase(ExternalRuleConstant.PREFERRED_TYPE_Y))
									{
										partyAddressMap.put(currMapKey,wsPartyAddressGroupBObj);
										setOtherAddressObjInMap(partyAddressMap, currMapKey, addrBObjInMap, kanjiAddressSet,kanaAddressSet, control);
										//System.out.println("Surviving Non Duplicate Addresses : "+currMapKey+ addrBObjInMap.toXML("TCRM", "MDMDomains.xsd", 0, null, false));
									}
									}
									else if(sourceDSCIncoming)
									{
										partyAddressMap.put(currMapKey,addrBObjInMap);
										
										setOtherAddressObjInMap(partyAddressMap, currMapKey, wsPartyAddressGroupBObj, kanjiAddressSet,kanaAddressSet, control);
									}
									else if(sourceDSCInMap)
									{
										partyAddressMap.put(currMapKey,wsPartyAddressGroupBObj);
										setOtherAddressObjInMap(partyAddressMap, currMapKey, addrBObjInMap, kanjiAddressSet,kanaAddressSet, control);
									}
								}
								
							

						}

						
					}
					for(int i = 0; i < vecSortedOtherAddress.size(); i++)
					{
						XAddressGroupBObjExt wsOtherPartyAddressGroupBObj = vecSortedOtherAddress
								.elementAt(i);
						String currMapKey=wsOtherPartyAddressGroupBObj.getAddressUsageType();
						
							if(!partyAddressMap.containsKey(currMapKey))
							{
								partyAddressMap.put(currMapKey, wsOtherPartyAddressGroupBObj);
								if(kanjiAddressSet.contains(currMapKey))
								{
								kanjiAddressSet.remove(currMapKey);
								}
								else if(kanaAddressSet.contains(currMapKey))
								{
								kanaAddressSet.remove(currMapKey);
								}
							}
							else
							{
								if(currMapKey.equalsIgnoreCase(ExternalRuleConstant.ADDRESS_USAGE_TYPE_OTHER_KANA_ADDRESS_1) && !kanaAddressSet.isEmpty())
								{
									String currKey=kanaAddressSet.first();
									wsOtherPartyAddressGroupBObj.setAddressUsageType(currKey);
									partyAddressMap.put(currKey, wsOtherPartyAddressGroupBObj);
									kanaAddressSet.remove(currKey);
								}
								else if(currMapKey.equalsIgnoreCase(ExternalRuleConstant.ADDRESS_USAGE_TYPE_OTHER_KANA_ADDRESS_2) && !kanaAddressSet.isEmpty())
								{
									String currKey=kanaAddressSet.first();
									wsOtherPartyAddressGroupBObj.setAddressUsageType(currKey);
									partyAddressMap.put(currKey, wsOtherPartyAddressGroupBObj);
									kanaAddressSet.remove(currKey);
								}
								else if(currMapKey.equalsIgnoreCase(ExternalRuleConstant.ADDRESS_USAGE_TYPE_OTHER_KANA_ADDRESS_3) && !kanaAddressSet.isEmpty())
								{
									String currKey=kanaAddressSet.first();
									wsOtherPartyAddressGroupBObj.setAddressUsageType(currKey);
									partyAddressMap.put(currKey, wsOtherPartyAddressGroupBObj);
									kanaAddressSet.remove(currKey);
								}
								else if(currMapKey.equalsIgnoreCase(ExternalRuleConstant.ADDRESS_USAGE_TYPE_OTHER_KANJI_ADDRESS_1) && !kanjiAddressSet.isEmpty())
								{
									String currKey=kanjiAddressSet.first();
									wsOtherPartyAddressGroupBObj.setAddressUsageType(currKey);
									partyAddressMap.put(currKey, wsOtherPartyAddressGroupBObj);
									kanjiAddressSet.remove(currKey);
								}
								else if(currMapKey.equalsIgnoreCase(ExternalRuleConstant.ADDRESS_USAGE_TYPE_OTHER_KANJI_ADDRESS_2) && !kanjiAddressSet.isEmpty())
								{
									String currKey=kanjiAddressSet.first();
									wsOtherPartyAddressGroupBObj.setAddressUsageType(currKey);
									partyAddressMap.put(currKey, wsOtherPartyAddressGroupBObj);
									kanjiAddressSet.remove(currKey);
								}
								else if(currMapKey.equalsIgnoreCase(ExternalRuleConstant.ADDRESS_USAGE_TYPE_OTHER_KANJI_ADDRESS_3) && !kanjiAddressSet.isEmpty())
								{
									String currKey=kanjiAddressSet.first();
									wsOtherPartyAddressGroupBObj.setAddressUsageType(currKey);
									partyAddressMap.put(currKey, wsOtherPartyAddressGroupBObj);
									kanjiAddressSet.remove(currKey);
								}
							}
						
					}
				}	
						
						
						/*else
						{
							for(String exisMapKey : partyAddressMap.keySet())
							{
								boolean isAddressMatched=false;
								Vector<String> vecOtherAddressType=new Vector<String>();
								Vector<String> vecPrimeAddressType=new Vector<String>();
								vecOtherAddressType.add(ExternalRuleConstant.ADDRESS_USAGE_TYPE_OTHER_KANA_ADDRESS_1);
								vecOtherAddressType.add(ExternalRuleConstant.ADDRESS_USAGE_TYPE_OTHER_KANA_ADDRESS_2);
								vecOtherAddressType.add(ExternalRuleConstant.ADDRESS_USAGE_TYPE_OTHER_KANA_ADDRESS_3);
								vecOtherAddressType.add(ExternalRuleConstant.ADDRESS_USAGE_TYPE_OTHER_KANJI_ADDRESS_1);
								vecOtherAddressType.add(ExternalRuleConstant.ADDRESS_USAGE_TYPE_OTHER_KANJI_ADDRESS_2);
								vecOtherAddressType.add(ExternalRuleConstant.ADDRESS_USAGE_TYPE_OTHER_KANJI_ADDRESS_3);
								
								vecPrimeAddressType.add(ExternalRuleConstant.ADDRESS_USAGE_TYPE_HOME_KANA_ADDRESS);
								vecPrimeAddressType.add(ExternalRuleConstant.ADDRESS_USAGE_TYPE_HOME_KANJI_ADDRESS);
								vecPrimeAddressType.add(ExternalRuleConstant.ADDRESS_USAGE_TYPE_BUSINESS_KANJI_ADDRESS);
								vecPrimeAddressType.add(ExternalRuleConstant.ADDRESS_USAGE_TYPE_BUSINESS_KANA_ADDRESS);
								
								if(currMapKey.equals(exisMapKey)&& (currMapKey.equals(ExternalRuleConstant.ADDRESS_USAGE_TYPE_HOME_KANA_ADDRESS)||currMapKey.equals(ExternalRuleConstant.ADDRESS_USAGE_TYPE_HOME_KANJI_ADDRESS)||currMapKey.equals(ExternalRuleConstant.ADDRESS_USAGE_TYPE_BUSINESS_KANA_ADDRESS)|| currMapKey.equals(ExternalRuleConstant.ADDRESS_USAGE_TYPE_BUSINESS_KANJI_ADDRESS)))
								{
								
									if(isAddressMatched(partyAddressMap.get(exisMapKey), wsPartyAddressGroupBObj, control))
									{
										if(!exisMapKey.equals(currMapKey) && ((vecPrimeAddressType.contains(exisMapKey) && vecOtherAddressType.contains(currMapKey)) || (vecPrimeAddressType.contains(currMapKey) && vecOtherAddressType.contains(exisMapKey))))
										{
											if(vecPrimeAddressType.contains(currMapKey))
											{
												partyAddressMap.put(currMapKey, wsPartyAddressGroupBObj);
												//partyAddressMap.remove(exisMapKey);
												
												vecToRemoveAddrType.add(exisMapKey);
											}
											
										}
										else
										{
										
										Timestamp party1CreatedDt = DateFormatter.getTimestamp(partyAddressMap.get(exisMapKey).getAddressGroupLastUpdateDate());

										Timestamp party2CreatedDt = DateFormatter.getTimestamp(wsPartyAddressGroupBObj.getAddressGroupLastUpdateDate());
										
										if(party2CreatedDt.after(party1CreatedDt)){
											
											partyAddressMap.put(currMapKey, wsPartyAddressGroupBObj);
											if(!exisMapKey.equals(currMapKey))
											{
											//partyAddressMap.remove(exisMapKey);
											vecToRemoveAddrType.add(exisMapKey);	
											}
											
										}
										
									}
									}
									else
									{
										if(exisMapKey.equals(currMapKey))
										{
										Timestamp party1CreatedDt = DateFormatter.getTimestamp(partyAddressMap.get(exisMapKey).getAddressGroupLastUpdateDate());

										Timestamp party2CreatedDt = DateFormatter.getTimestamp(wsPartyAddressGroupBObj.getAddressGroupLastUpdateDate());
										
										if(party2CreatedDt.after(party1CreatedDt)){
											
											partyAddressMap.put(currMapKey, wsPartyAddressGroupBObj);
											
											Need to Consider the other address too
											 * String otherMapKey=ExternalRuleConstant.Ad
											partyAddressMap.put(currMapKey, )
											
											
										}
										}
										
									}
							
								
								else if(!currMapKey.equals(exisMapKey) && ((currMapKey.equals(ExternalRuleConstant.ADDRESS_USAGE_TYPE_HOME_KANA_ADDRESS)||currMapKey.equals(ExternalRuleConstant.ADDRESS_USAGE_TYPE_HOME_KANJI_ADDRESS)||currMapKey.equals(ExternalRuleConstant.ADDRESS_USAGE_TYPE_BUSINESS_KANA_ADDRESS)|| currMapKey.equals(ExternalRuleConstant.ADDRESS_USAGE_TYPE_BUSINESS_KANJI_ADDRESS))) && ((exisMapKey.equals(ExternalRuleConstant.ADDRESS_USAGE_TYPE_HOME_KANA_ADDRESS)||exisMapKey.equals(ExternalRuleConstant.ADDRESS_USAGE_TYPE_HOME_KANJI_ADDRESS)||exisMapKey.equals(ExternalRuleConstant.ADDRESS_USAGE_TYPE_BUSINESS_KANA_ADDRESS)|| exisMapKey.equals(ExternalRuleConstant.ADDRESS_USAGE_TYPE_BUSINESS_KANJI_ADDRESS))) )
								{
									
								}
								}
							
							
							
						}*/
											
					
					
					
					
					
					
					
					
					
					
					
					}

				
		/*for(String key : partyAddressMap.keySet())
		{
			//System.out.println("Final Surviving Addresses : "+key+ partyAddressMap.get(key).toXML("TCRM", "MDMDomains.xsd", 0, null, false));
		}*/
	return partyAddressMap;
	}
	
	public static void sortOtherPartyAddress(Vector<XAddressGroupBObjExt> vecWSpartyAddress,Vector<XAddressGroupBObjExt> vecSortedOtherAddress, Vector<String> vecPrimeAddressTypes, DWLControl control) throws Exception
	{
		//Vector<XAddressGroupBObjExt> vecOtherAddressObjs=new Vector<XAddressGroupBObjExt>();
		for(XAddressGroupBObjExt currXAddrGrp : vecWSpartyAddress)
		{
			if(!vecPrimeAddressTypes.contains(currXAddrGrp.getAddressUsageType()))
			{
				vecSortedOtherAddress.add(currXAddrGrp);
			}
		}
		
		Collections.sort(vecSortedOtherAddress,
				new Comparator<XAddressGroupBObjExt>() {// Ascending sort
													
					public int compare(XAddressGroupBObjExt addr1,
							XAddressGroupBObjExt addr2) {
						if (addr1.getXLastModifiedSystemDate() == null
								|| addr2
										.getXLastModifiedSystemDate() == null)
							return 0;
						return addr1
								.getXLastModifiedSystemDate()
								.compareTo(addr2.getXLastModifiedSystemDate());
					}
				});
		
		Collections.reverse(vecSortedOtherAddress);
	}
	
	public static void sortPrimeAddress(Vector<XAddressGroupBObjExt> vecWSpartyAddress, DWLControl control) throws Exception
	{
		Collections.sort(vecWSpartyAddress,
				new Comparator<XAddressGroupBObjExt>() {// Ascending sort
													
					public int compare(XAddressGroupBObjExt addr1,
							XAddressGroupBObjExt addr2) {
						if (addr1.getAddressUsageType() == null
								|| addr2
										.getAddressUsageType() == null)
							return 0;
						return addr1
								.getAddressUsageType()
								.compareTo(addr2.getAddressUsageType());
					}
				});
	}
	
	
	public static void setOtherAddressObjInMap (HashMap<String,XAddressGroupBObjExt> partyAddressMap,
			String mapKey, XAddressGroupBObjExt currXAddrGrpObj, TreeSet kanjiAddressSet,TreeSet kanaAddressSet ,DWLControl control) throws Exception {
		
		if(currXAddrGrpObj.getAddressUsageType().equalsIgnoreCase(ExternalRuleConstant.ADDRESS_USAGE_TYPE_HOME_KANA_ADDRESS) || currXAddrGrpObj.getAddressUsageType().equalsIgnoreCase(ExternalRuleConstant.ADDRESS_USAGE_TYPE_BUSINESS_KANA_ADDRESS))
		{
			if(!kanaAddressSet.isEmpty())
			{
			String currKey=kanaAddressSet.first().toString();
			currXAddrGrpObj.setAddressUsageType(currKey);
			currXAddrGrpObj.setAddressUsageValue(StringUtils.EMPTY_STRING);
			partyAddressMap.put(currKey, currXAddrGrpObj);
			kanaAddressSet.remove(currKey);
			}
		}
		else if(currXAddrGrpObj.getAddressUsageType().equalsIgnoreCase(ExternalRuleConstant.ADDRESS_USAGE_TYPE_HOME_KANJI_ADDRESS) || currXAddrGrpObj.getAddressUsageType().equalsIgnoreCase(ExternalRuleConstant.ADDRESS_USAGE_TYPE_BUSINESS_KANJI_ADDRESS))
		{
			if(!kanjiAddressSet.isEmpty())
			{
			String currKey=kanjiAddressSet.first().toString();
			currXAddrGrpObj.setAddressUsageType(currKey);
			currXAddrGrpObj.setAddressUsageValue(StringUtils.EMPTY_STRING);
			partyAddressMap.put(currKey, currXAddrGrpObj);
			kanjiAddressSet.remove(currKey);
			}
		}
		
		
		
		
	}
	
	
	
	public static void surviveGoldenAddressFromDuplicates(Vector<XAddressGroupBObjExt> vecSurvivingAddr,
			Vector<XAddressGroupBObjExt> vecDuplicateAddrs, DWLControl control) throws Exception {
		
		//Vector<String> vecOtherAddressType=new Vector<String>();
		Vector<String> vecPrimeAddressType=new Vector<String>();
		
/*		vecOtherAddressType.add(ExternalRuleConstant.ADDRESS_USAGE_TYPE_OTHER_KANA_ADDRESS_1);
		vecOtherAddressType.add(ExternalRuleConstant.ADDRESS_USAGE_TYPE_OTHER_KANA_ADDRESS_2);
		vecOtherAddressType.add(ExternalRuleConstant.ADDRESS_USAGE_TYPE_OTHER_KANA_ADDRESS_3);
		vecOtherAddressType.add(ExternalRuleConstant.ADDRESS_USAGE_TYPE_OTHER_KANJI_ADDRESS_1);
		vecOtherAddressType.add(ExternalRuleConstant.ADDRESS_USAGE_TYPE_OTHER_KANJI_ADDRESS_2);
		vecOtherAddressType.add(ExternalRuleConstant.ADDRESS_USAGE_TYPE_OTHER_KANJI_ADDRESS_3);*/
		
		vecPrimeAddressType.add(ExternalRuleConstant.ADDRESS_USAGE_TYPE_HOME_KANA_ADDRESS);
		vecPrimeAddressType.add(ExternalRuleConstant.ADDRESS_USAGE_TYPE_HOME_KANJI_ADDRESS);
		vecPrimeAddressType.add(ExternalRuleConstant.ADDRESS_USAGE_TYPE_BUSINESS_KANJI_ADDRESS);
		vecPrimeAddressType.add(ExternalRuleConstant.ADDRESS_USAGE_TYPE_BUSINESS_KANA_ADDRESS);
		
		Vector<XAddressGroupBObjExt> vecPrimeAddressObjs=new Vector<XAddressGroupBObjExt>();
		Vector<XAddressGroupBObjExt> vecNonPrimeAddressObj=new Vector<XAddressGroupBObjExt>();
		
		for(XAddressGroupBObjExt currXAddr : vecDuplicateAddrs)
		{
			if(vecPrimeAddressType.contains(currXAddr.getAddressUsageType()))
			{
				
				vecPrimeAddressObjs.add(currXAddr);
				
			}
			else
			{
				
				vecNonPrimeAddressObj.add(currXAddr);
				
			}
			
		}
		
		if(vecPrimeAddressObjs!=null && vecPrimeAddressObjs.size()>0)
		{
			XAddressGroupBObjExt survivingAddress=null;
			XPreferenceBObj survivingPref=null;
			for(XAddressGroupBObjExt currXAddr : vecPrimeAddressObjs)
			{
				if(survivingAddress==null)
				{
					survivingAddress=currXAddr;
					/*if(currXAddr.getXPreferenceBObj()!=null)
					{
					survivingPref=currXAddr.getXPreferenceBObj();
					}*/
				}
				else
				{
					Timestamp existingAddrCreated=DateFormatter.getTimestamp(survivingAddress.getXLastModifiedSystemDate());
					Timestamp newAddrCreated=DateFormatter.getTimestamp(currXAddr.getXLastModifiedSystemDate());
					/*if(currXAddr.getXPreferenceBObj()!=null && currXAddr.getXPreferenceBObj().getLastModifiedSystemDate()!=null)
					{
						Timestamp existingPrefCreated=null;
						if(survivingAddress.getXPreferenceBObj()!=null && survivingAddress.getXPreferenceBObj().getLastModifiedSystemDate()!=null)
							{
								existingPrefCreated=DateFormatter.getTimestamp(survivingAddress.getXPreferenceBObj().getLastModifiedSystemDate());
							}
						Timestamp newPrefCreated=DateFormatter.getTimestamp(currXAddr.getXPreferenceBObj().getLastModifiedSystemDate());
						
						if(existingPrefCreated==null)
						{
							survivingPref=currXAddr.getXPreferenceBObj();
						}
						else if(newPrefCreated.after(existingPrefCreated))
						{
							survivingPref=currXAddr.getXPreferenceBObj();
						}
						else
						{
							survivingPref=survivingAddress.getXPreferenceBObj();
						}
						}*/
						
						if(newAddrCreated.after(existingAddrCreated))
						{
							survivingAddress=currXAddr;
							//survivingAddress.setXPreferenceBObj(survivingPref);
						}
					
					
				}
				
				
				
			}
			
			vecSurvivingAddr.add(survivingAddress);
		
		}
		else
		{
			XAddressGroupBObjExt survivingAddress=null;
			XPreferenceBObj survivingPref=null;
			for(XAddressGroupBObjExt currXAddr : vecNonPrimeAddressObj)
			{
				if(survivingAddress==null)
				{
					survivingAddress=currXAddr;
					/*if(currXAddr.getXPreferenceBObj()!=null)
					{
					survivingPref=currXAddr.getXPreferenceBObj();
					}*/
				}
				else
				{
					Timestamp existingAddrCreated=DateFormatter.getTimestamp(survivingAddress.getXLastModifiedSystemDate());
					Timestamp newAddrCreated=DateFormatter.getTimestamp(currXAddr.getXLastModifiedSystemDate());
					/*if(currXAddr.getXPreferenceBObj()!=null && currXAddr.getXPreferenceBObj().getLastModifiedSystemDate()!=null)
					{
						Timestamp existingPrefCreated=null;
						if(survivingAddress.getXPreferenceBObj()!=null && survivingAddress.getXPreferenceBObj().getLastModifiedSystemDate()!=null)
							{
								existingPrefCreated=DateFormatter.getTimestamp(survivingAddress.getXPreferenceBObj().getLastModifiedSystemDate());
							}
						Timestamp newPrefCreated=DateFormatter.getTimestamp(currXAddr.getXPreferenceBObj().getLastModifiedSystemDate());
						
						if(existingPrefCreated==null)
						{
							survivingPref=currXAddr.getXPreferenceBObj();
						}
						else if(newPrefCreated.after(existingPrefCreated))
						{
							survivingPref=currXAddr.getXPreferenceBObj();
						}
						else
						{
							survivingPref=survivingAddress.getXPreferenceBObj();
						}
						}*/
						
						if(newAddrCreated.after(existingAddrCreated))
						{
							survivingAddress=currXAddr;
							//survivingAddress.setXPreferenceBObj(survivingPref);
						}
					
					
				}
				
				
				
			}
			
			vecSurvivingAddr.add(survivingAddress);
			
		}
		
		
		
	}
	
	
	
	/**
	 * @param firstPartyAddrBobj
	 * @param secondPartyAddrBobj
	 * @param control
	 * @return
	 * @throws Exception
	 */
	public static boolean isAddressMatched(XAddressGroupBObjExt firstPartyAddrBobj,
			XAddressGroupBObjExt secondPartyAddrBobj, DWLControl control) throws Exception {
		// validate  addressMatchCriteria for Province, City,
		//Address Line 3, Residence Number, Address Line 1, Address Line 2, and Company Name
		boolean isAddressLineOneMatched = false;
		boolean isAddressLineTwoMatched = false;
		boolean isAddressLineThreeMatched = false;
		boolean isCityMatched = false;
		boolean isProvinceStateValueMatched = false;
		boolean isResidenceNumberMatched=false;
		boolean isCompanyNameMatched=false;
		boolean isAddressMatched = false;
		
		XAddressBObjExt firstAddrObj=(XAddressBObjExt) firstPartyAddrBobj.getTCRMAddressBObj();
		XAddressBObjExt secondAddrObj=(XAddressBObjExt) secondPartyAddrBobj.getTCRMAddressBObj();
		
		if (firstAddrObj.getAddressLineOne().trim()
				.equals(secondAddrObj.getAddressLineOne().trim())) {
			isAddressLineOneMatched = true;
		}
	
	//  : if both are not null then check if both same then set
	// flag =true otherwise false
	if (StringUtils.isNonBlank(secondAddrObj.getAddressLineTwo())
			&& StringUtils.isNonBlank(firstAddrObj.getAddressLineTwo())) {
		if (firstAddrObj.getAddressLineTwo().trim()
				.equals(secondAddrObj.getAddressLineTwo().trim())) {
			isAddressLineTwoMatched = true;
		}
	}
	// : if either of two is null set flag =true 
	else if (!StringUtils.isNonBlank(secondAddrObj.getAddressLineTwo())
			|| !StringUtils.isNonBlank(firstAddrObj.getAddressLineTwo())) {
		isAddressLineTwoMatched = true;
	}
	
	//  : if both are not null then check if both same then set
	// flag =true otherwise false
	if (StringUtils.isNonBlank(secondAddrObj.getAddressLineThree())
			&& StringUtils.isNonBlank(firstAddrObj.getAddressLineThree())) {
		if (firstAddrObj.getAddressLineThree().trim()
				.equals(secondAddrObj.getAddressLineThree().trim())) {
			isAddressLineThreeMatched = true;
		}
	}
	
	// : if either of two is null set flag =true 
	else if (!StringUtils.isNonBlank(secondAddrObj.getAddressLineThree())
			|| !StringUtils.isNonBlank(firstAddrObj.getAddressLineThree())) {
		isAddressLineThreeMatched = true;
	}
	
	if (firstAddrObj.getCity().trim().equals(secondAddrObj.getCity().trim())) {
		isCityMatched = true;
	}

	
	CodeTypeComponentHelper ctHelper = DWLClassFactory
			.getCodeTypeComponentHelper();
	String langId = (String) control.get(TCRMControlKeys.LANG_ID);
	
	
	String reqProvStatevalue = null;
	if (StringUtils.isNonBlank(secondAddrObj.getProvinceStateType())) {

		CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory
				.getCodeTypeComponentHelper();
		CodeTypeBObj psctBObj = codeTypeCompHelper.getCodeTypeByCode(
				"CdProvStateTp", langId,
				secondAddrObj.getProvinceStateType(), control);
		if (psctBObj != null) {
			reqProvStatevalue = psctBObj.getvalue();
		}
	}
	String resProvStatevalue = null;
	if (StringUtils.isNonBlank(firstAddrObj.getProvinceStateType())) {
		
		CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory
				.getCodeTypeComponentHelper();
		CodeTypeBObj rpsctBObj = codeTypeCompHelper.getCodeTypeByCode(
				"CdProvStateTp", langId,
				firstAddrObj.getProvinceStateType(), control);
		if (rpsctBObj != null) {
			resProvStatevalue = rpsctBObj.getvalue();
		}
	}
	if (!StringUtils.isNonBlank(reqProvStatevalue)
			|| !StringUtils.isNonBlank(resProvStatevalue)) {

		isProvinceStateValueMatched = true;
	} else if (StringUtils.isNonBlank(reqProvStatevalue)
			&& StringUtils.isNonBlank(resProvStatevalue)) {
		if (resProvStatevalue.trim().equals(reqProvStatevalue.trim())) {
			isProvinceStateValueMatched = true;
		}
	}
	
	
//  : if both are not null then check if both same then set
	// flag =true otherwise false
	if (StringUtils.isNonBlank(secondAddrObj.getResidenceNumber())
			&& StringUtils.isNonBlank(firstAddrObj.getResidenceNumber())) {
		if (firstAddrObj.getResidenceNumber().trim()
				.equals(secondAddrObj.getResidenceNumber().trim())) {
			isResidenceNumberMatched = true;
		}
	}
	
	// : if either of two is null set flag =true 
	else if (!StringUtils.isNonBlank(secondAddrObj.getResidenceNumber())
			|| !StringUtils.isNonBlank(firstAddrObj.getResidenceNumber())) {
		isResidenceNumberMatched = true;
	}

//  : if both are not null then check if both same then set
	// flag =true otherwise false
	if (StringUtils.isNonBlank(secondPartyAddrBobj.getCompanyName())
			&& StringUtils.isNonBlank(firstPartyAddrBobj.getCompanyName())) {
		if (firstPartyAddrBobj.getCompanyName().trim()
				.equals(secondPartyAddrBobj.getCompanyName().trim())) {
			isCompanyNameMatched = true;
		}
	}
	
	// : if either of two is null set flag =true 
	else if (!StringUtils.isNonBlank(secondPartyAddrBobj.getCompanyName())
			|| !StringUtils.isNonBlank(firstPartyAddrBobj.getCompanyName())) {
		isCompanyNameMatched = true;
	}

	if (isAddressLineOneMatched && isAddressLineTwoMatched
			&& isAddressLineThreeMatched && isCityMatched && isResidenceNumberMatched
			&& isProvinceStateValueMatched && isCompanyNameMatched) {
		isAddressMatched = true;

	}
	return isAddressMatched;
		
	}

	public HashMap<String, XAddressGroupBObjExt> survivedDealerRetailerAddress(Vector vecAllParty,HashMap<String, XAddressGroupBObjExt> partyAddressMap, DWLControl control) throws Exception{

		HashMap<String, Vector<XAddressGroupBObjExt>> dealerAddressMap = new HashMap<String, Vector<XAddressGroupBObjExt>>();
			
		XAddressGroupBObjExt latestAddressGrpBobj = null;
		
		for (int i = 0; i < vecAllParty.size(); i++) {
				
				TCRMPartyBObj party = (TCRMPartyBObj) vecAllParty.get(i);
				
				Vector<XAddressGroupBObjExt> vecTempPartyAddressBObj = new Vector<XAddressGroupBObjExt>();
	
				vecTempPartyAddressBObj = party.getItemsTCRMPartyAddressBObj();
				
				if(vecTempPartyAddressBObj.size() != 0){
					
					for(XAddressGroupBObjExt addressGroupBobj : vecTempPartyAddressBObj){
						
						if(addressGroupBobj.getXAddressRetailerFlag().equalsIgnoreCase(ExternalRuleConstant.ADDRESS_RETAILER_FLAG_Y)){
							
							String retailerId = addressGroupBobj.getXRetailerId();
							
							//String dealerCode = dealerRetailerMap.get(retailerId);
							
/*							if(dealerAddressMap.containsKey(dealerCode)){
								
								//If key is present in Map, get the vector and add this bobj in it
								Vector<XAddressGroupBObjExt> vecAddressBObjForKey = dealerAddressMap.get(dealerCode);
								
								vecAddressBObjForKey.add(addressGroupBobj);
								
														
							}else{
								
								//Add the Key Value Pair in Map
								Vector<XAddressGroupBObjExt> vecAddressBObjForKey = new Vector<XAddressGroupBObjExt>();
								
								vecAddressBObjForKey.add(addressGroupBobj);
								
								dealerAddressMap.put(dealerCode, vecAddressBObjForKey);								
								
							}*/
							
						}
						
					}
				
				}
				
			
			}
			if(!dealerAddressMap.isEmpty()){
			for(Map.Entry<String, Vector<XAddressGroupBObjExt>> dealerAddres: dealerAddressMap.entrySet()){
					
					//Get dealercode 
					String dealerFromMap = dealerAddres.getKey();
					
					//Get all the addresses for this dealer
					Vector<XAddressGroupBObjExt> vecAddressrDealer = dealerAddres.getValue();
					
					//Sort all address by last modified system date
					Collections.sort(vecAddressrDealer, new Comparator<XAddressGroupBObjExt>() {
						public int compare(XAddressGroupBObjExt address1, XAddressGroupBObjExt address2) {
							if (address1.getXLastModifiedSystemDate() == null || address2.getXLastModifiedSystemDate() == null)
							return 0;
							return address1.getXLastModifiedSystemDate().compareTo(address2.getXLastModifiedSystemDate());
						}
					});
					Collections.reverse(vecAddressrDealer);//Descending sort for latest address
																
					//Latest Address survives
					if(vecAddressrDealer.size() != 0)
						latestAddressGrpBobj = vecAddressrDealer.get(0);
					
					//Iterate vector of address to set values
					for(XAddressGroupBObjExt addressRetail: vecAddressrDealer){
						
						String mapKey = addressRetail.getXRetailerId();
					
						//addressRetail.setControl(control);
            			addressRetail.setTCRMAddressBObj(latestAddressGrpBobj.getTCRMAddressBObj());
    					//addressGroupBobjToUpdate.setTCRMAddressBObj(latestAddressGroup.getTCRMAddressBObj());
    					//setPartyAddressGroup(addressRetail,latestAddressGrpBobj,control);
    					
											
						if(!partyAddressMap.containsKey(mapKey))
						
							partyAddressMap.put(mapKey, addressRetail);
						
						else{
							
							XAddressGroupBObjExt AddrInMap = partyAddressMap.get(mapKey);
							
							Timestamp party1CreatedDt = DateFormatter.getTimestamp(AddrInMap.getXLastModifiedSystemDate());
							
							Timestamp party2CreatedDt = DateFormatter.getTimestamp(addressRetail.getXLastModifiedSystemDate());
							
							if(party2CreatedDt.after(party1CreatedDt)){
								
								partyAddressMap.put(mapKey, addressRetail);

							}
								
							
						}
							
						
					}
					
				}
			}
		
		
			return partyAddressMap;
			
	}
	
	public static void setPartyAddressGroup(XAddressGroupBObjExt addressRetail,XAddressGroupBObjExt latestAddressGrpBobj, DWLControl control) throws BusinessProxyException {
		try{
			
			
			//AddressBObj
			XAddressBObjExt finalAddressBObjExt = (XAddressBObjExt) addressRetail.getTCRMAddressBObj();
			//addressRetail.setTCRMAddressBObj(null);
			finalAddressBObjExt.setControl(control);
			XAddressBObjExt reqAddressBObjExt = (XAddressBObjExt) latestAddressGrpBobj.getTCRMAddressBObj();
	
			//AddressLineOne
			if(reqAddressBObjExt.getAddressLineOne() != null)
				finalAddressBObjExt.setAddressLineOne(reqAddressBObjExt.getAddressLineOne());
			//AddressLineTwo
			if(reqAddressBObjExt.getAddressLineTwo() != null)
				finalAddressBObjExt.setAddressLineTwo(reqAddressBObjExt.getAddressLineTwo());
			//AddressLineThree
			if(reqAddressBObjExt.getAddressLineThree() != null)
				finalAddressBObjExt.setAddressLineThree(reqAddressBObjExt.getAddressLineThree());
			//City
			if(reqAddressBObjExt.getCity() != null)
				finalAddressBObjExt.setCity(reqAddressBObjExt.getCity());
			//ProvinceStateType / Residence
			if(reqAddressBObjExt.getResidenceNumber() != null)
				finalAddressBObjExt.setResidenceNumber(reqAddressBObjExt.getResidenceNumber());
			//ZipPostalCode
			if(reqAddressBObjExt.getZipPostalCode() != null)
				finalAddressBObjExt.setZipPostalCode(reqAddressBObjExt.getZipPostalCode());
			//CountryType
			if(reqAddressBObjExt.getCountryType() != null)
				finalAddressBObjExt.setCountryType(reqAddressBObjExt.getCountryType());
			
			//XAddressVerification Date
			if(reqAddressBObjExt.getXAddressVerificationDate() != null)
				finalAddressBObjExt.setXAddressVerificationDate(reqAddressBObjExt.getXAddressVerificationDate());
				//XDistrictType
			if(reqAddressBObjExt.getXDistrictType() != null)
				finalAddressBObjExt.setXDistrictType(reqAddressBObjExt.getXDistrictType());
				//XSubcity
			if(reqAddressBObjExt.getXSubcityType() != null)
				finalAddressBObjExt.setXSubcityType(reqAddressBObjExt.getXSubcityType());
			
			//StartDate
			if(latestAddressGrpBobj.getStartDate() != null){
				addressRetail.setStartDate(latestAddressGrpBobj.getStartDate());
			}
			//EndDate
			if(latestAddressGrpBobj.getEndDate() != null){
				addressRetail.setEndDate(latestAddressGrpBobj.getEndDate());
			}
			
			//Preferred Address Indicator 05-12-2017
			//finalAddressGroupBObjExt.setPreferredAddressIndicator("N");
			
			
			
			addressRetail.setTCRMAddressBObj(finalAddressBObjExt);
					
			}catch(Exception e){
				
				e.printStackTrace();
                //  logger.finest(e);
			/*DWLError error = errHandler
					.getErrorMessage(TCRMCoreComponentID.PARTY_ADDRESS_OBJECT,
							"UPDERR",TCRMCoreErrorReasonCode.UPDATE_PARTY_ADDRESS_FAILED,control, new String[0]);
			throw new BusinessProxyException(error.getErrorMessage());*/			
	}
	
}
	/**
	 * @param vecAllParty
	 * @param partyContEquivMap
	 * @param control
	 * @return
	 * @throws Exception
	 */
	public HashMap<String, XContEquivBObjExt> sortedMagicNumber(Vector vecAllParty,HashMap<String, XContEquivBObjExt> partyContEquivMap, DWLControl control) throws Exception{
			
			DSEAAdditionsExtsComponent dseac=new DSEAAdditionsExtsComponent();
			HashMap<String, Vector<XContEquivBObjExt>> dealerMagicMap = new HashMap<String, Vector<XContEquivBObjExt>>();
			
			HashMap<String, XContEquivBObjExt> retailerMagicMap = new HashMap<String, XContEquivBObjExt>();
			
			String goldenMagicNumber = null;
			
			for (int i = 0; i < vecAllParty.size(); i++) {
					
					TCRMPartyBObj party = (TCRMPartyBObj) vecAllParty.get(i);
					
					Vector<XContEquivBObjExt> vecTempContEquivBObj = new Vector<XContEquivBObjExt>();
		
					vecTempContEquivBObj = party.getItemsTCRMAdminContEquivBObj();
					
					if(vecTempContEquivBObj.size() != 0){
						
						for(XContEquivBObjExt currXContEquiv : vecTempContEquivBObj){
							
							if(currXContEquiv.getAdminSystemType().equals(ExternalRuleConstant.MAGIC_NUMBER_SYS_TYPE) && currXContEquiv.getXRetailerId()!=null){
								
								String retailerId = currXContEquiv.getXRetailerId();
								retailerMagicMap.put(retailerId, currXContEquiv);
								DWLResponse getRetailerResponse =dseac.getXRetailer(retailerId, control);
								String dealerCode=null;
								if(getRetailerResponse!=null && getRetailerResponse.getStatus().getStatus()!=DWLStatus.FATAL)
								{
									dealerCode = ((XRetailerBObj)getRetailerResponse.getData()).getGCCode();
								}
								if(dealerCode!=null)
								{
								if(dealerMagicMap.containsKey(dealerCode)){
									
									//If key is present in Map, get the vector and add this bobj in it
									Vector<XContEquivBObjExt> vecContEquivForKey = dealerMagicMap.get(dealerCode);
									
									vecContEquivForKey.add(currXContEquiv);
									
															
								}
								else{
									
									//Add the Key Value Pair in Map
									Vector<XContEquivBObjExt> vecContEquivForKey = new Vector<XContEquivBObjExt>();
									
									vecContEquivForKey.add(currXContEquiv);
									
									dealerMagicMap.put(dealerCode, vecContEquivForKey);								
									
								}
								}
								
							}
							
						}
					
					}
					
				
				}
					
					for(Map.Entry<String, Vector<XContEquivBObjExt>> dealerMagic: dealerMagicMap.entrySet()){
						
						//Get dealercode 
						String dealerFromMap = dealerMagic.getKey();
						
						//Get all the magicnumber for this dealer
						Vector<XContEquivBObjExt> vecMagicNumberForDealer = dealerMagic.getValue();
						
						Vector<String> vecDealerMagicNumbers=new Vector<String>();
						
						//Sort all magic numbers by last modified system date
						Collections.sort(vecMagicNumberForDealer, new Comparator<XContEquivBObjExt>() {
							public int compare(XContEquivBObjExt magic1, XContEquivBObjExt magic2) {
								if (magic1.getXLastModifiedSystemDate() == null || magic2.getXLastModifiedSystemDate() == null)
								return 0;
								return magic1.getXLastModifiedSystemDate().compareTo(magic2.getXLastModifiedSystemDate());
							}
						});
						//Collections.reverse(vecMagicNumberForDealer);//Descending sort
						
						
						XContEquivBObjExt oldestMagicNumberBObj = null;
												
						//Oldest Magic number survives
						if(vecMagicNumberForDealer.size() != 0)
						{
							
							oldestMagicNumberBObj = vecMagicNumberForDealer.get(0);
							
							for(XContEquivBObjExt dealerCeq : vecMagicNumberForDealer)
							{
								vecDealerMagicNumbers.add(dealerCeq.getAdminPartyId());
							}
						}
						
						goldenMagicNumber = oldestMagicNumberBObj.getAdminPartyId();
						
						for(XContEquivBObjExt magicRetailer: vecMagicNumberForDealer){
							
							//String mapKey = magicRetailer.getXRetailerId();
							String mapKey= dealerFromMap;
							magicRetailer.setControl(control);
							
							//magicRetailer.setAdminPartyId(goldenMagicNumber);
							
							
							if(!partyContEquivMap.containsKey(mapKey)){
								
								magicRetailer.setDescription(ExternalRuleConstant.MASTER_KEY);
								partyContEquivMap.put(mapKey, magicRetailer);
							}
							
							else{
								
								XContEquivBObjExt ContEquivInMap = partyContEquivMap.get(mapKey);
								
								Timestamp party1CreatedDt = DateFormatter.getTimestamp(ContEquivInMap.getXLastModifiedSystemDate());
								
								Timestamp party2CreatedDt = DateFormatter.getTimestamp(magicRetailer.getXLastModifiedSystemDate());
								
								if(party2CreatedDt.before(party1CreatedDt)){
									
									magicRetailer.setDescription(ExternalRuleConstant.MASTER_KEY);
									partyContEquivMap.put(mapKey, magicRetailer);
									
									int slaveKey=1;
									String newMapKey=mapKey+ExternalRuleConstant.SLAVE_KEY+Integer.toString(slaveKey);
									
									while(partyContEquivMap.containsKey(newMapKey))
									{
										slaveKey++;
										String count=Integer.toString(slaveKey); 
										newMapKey=mapKey+ExternalRuleConstant.SLAVE_KEY+count;
									}
									mapKey=newMapKey;
									ContEquivInMap.setDescription(ExternalRuleConstant.SLAVE_KEY);
									partyContEquivMap.put(mapKey, ContEquivInMap);
									

								}
								else
								{
									ContEquivInMap.setDescription(ExternalRuleConstant.MASTER_KEY);
									partyContEquivMap.put(mapKey, ContEquivInMap);
									
									int slaveKey=1;
									String newMapKey=mapKey+ExternalRuleConstant.SLAVE_KEY+Integer.toString(slaveKey);
									
									while(partyContEquivMap.containsKey(newMapKey))
									{
										slaveKey++;
										String count=Integer.toString(slaveKey); 
										newMapKey=mapKey+ExternalRuleConstant.SLAVE_KEY+count;
									}
									mapKey=newMapKey;
									magicRetailer.setDescription(ExternalRuleConstant.SLAVE_KEY);
									partyContEquivMap.put(mapKey, magicRetailer);
								}
									
								
							}
								
							
						}
						
						for(String mapKeys : partyContEquivMap.keySet())
						{
							
							
							XContEquivBObjExt currXCont=partyContEquivMap.get(mapKeys);
							
							
							
							if(vecDealerMagicNumbers.contains(currXCont.getAdminPartyId())  && currXCont.getDescription().equalsIgnoreCase(ExternalRuleConstant.MASTER_KEY))
							{
								currXCont.setAdminPartyId(goldenMagicNumber);
							}
							
						}
						
						
				}
			
			
				return partyContEquivMap;
				
		}
	
	
	/** Org Survivorship JPN
	 * @param vecAllParty
	 * @param control
	 * @return
	 * @throws Exception
	 */
	private HashMap<String, HashMap> survivedOrgDetails(Vector vecAllParty, boolean allDSCParty, boolean isRealTime,
			DWLControl control) throws Exception {
		//logger.info("In survivedOrgDetails JPN");

		HashMap<String, XOrgNameBObjExt> orgNameMap = new HashMap<String, XOrgNameBObjExt>();
		HashMap<String, XAddressGroupBObjExt> partyAddressMap = new HashMap<String, XAddressGroupBObjExt>();
		HashMap<String, XIdentifierBObjExt> partyIdentMap = new HashMap<String, XIdentifierBObjExt>();
		HashMap<String, XContactMethodGroupBObjExt> partyContMethMap = new HashMap<String, XContactMethodGroupBObjExt>();
		HashMap<String, XContEquivBObjExt> partyAdminConteqMap = new HashMap<String, XContEquivBObjExt>();
		HashMap<String, XPreferenceBObj> contactMethodPrefMap=new HashMap<String, XPreferenceBObj>();
		//HashMap<String, XPreferenceBObj> partyAddressPrefMap=new HashMap<String, XPreferenceBObj>();
		//HashMap<String, TCRMPartyPrivPrefBObj> partyPrivacyPrefMap = new HashMap<String, TCRMPartyPrivPrefBObj>();

		//HashMap<String, XContEquivBObjExt> partyAdminConteqMap1 = new HashMap<String, XContEquivBObjExt>();
		/*HashMap<String, String> dealerRetailerMap = new HashMap<String, String>();
		dealerRetailerMap = getAllRetailersByDealerForMagic(dealerRetailerMap);*/

		XOrgBObjExt orgBObjExtIncomingParty = (XOrgBObjExt) vecAllParty.get(0);
		//String sourceIdentifierTypeIncomingParty = orgBObjExtIncomingParty.getSourceIdentifierType();
		if (orgBObjExtIncomingParty != null
				&& orgBObjExtIncomingParty.getXMarketName() != null
				&& orgBObjExtIncomingParty.getXMarketName().equals(ExternalRuleConstant.JAPAN_MARKET_NAME)) {
			
			// FOr Japan Org Survivorship
			survivalOfIndividualOrg(vecAllParty, allDSCParty,isRealTime,control, orgNameMap,
					partyAddressMap, partyIdentMap, partyContMethMap,
					partyAdminConteqMap,contactMethodPrefMap);

		} 
		HashMap<String, HashMap> orgMap = new HashMap<String, HashMap>();
		orgMap.put(ExternalRuleConstant.SURVIVED_MAP_NAME, orgNameMap);
		orgMap.put(ExternalRuleConstant.SURVIVED_MAP_ADDRESS, partyAddressMap);
		orgMap.put(ExternalRuleConstant.SURVIVED_MAP_IDENTIFIER, partyIdentMap);
		orgMap.put(ExternalRuleConstant.SURVIVED_MAP_CONTACTMETHOD,
				partyContMethMap);
		orgMap.put(ExternalRuleConstant.SURVIVED_MAP_CONTEQUIV,
				partyAdminConteqMap);

		return orgMap;
	}

	/**
	 * @param vecAllParty
	 * @param control
	 * @param orgNameMap
	 * @param partyAddressMap
	 * @param partyIdentMap
	 * @param partyContMethMap
	 * @param partyAdminConteqMap
	 * @param partyAdminConteqMap1
	 * @param priority
	 * @throws Exception
	 */
	private void survivalOfIndividualOrg(Vector vecAllParty, boolean allDSCParty, boolean isRealTime,
			DWLControl control, HashMap<String, XOrgNameBObjExt> orgNameMap,
			HashMap<String, XAddressGroupBObjExt> partyAddressMap,
			HashMap<String, XIdentifierBObjExt> partyIdentMap,
			HashMap<String, XContactMethodGroupBObjExt> partyContMethMap,
			HashMap<String, XContEquivBObjExt> partyAdminConteqMap,
			 HashMap<String, XPreferenceBObj> contactMethodMap
			) throws Exception {

		XOrgBObjExt orgBObjExtIncomingParty = (XOrgBObjExt) vecAllParty.get(0);
		String batchIndicator = orgBObjExtIncomingParty.getXBatchInd();
		
		Vector<String> myMIdPartyId=new Vector<String>();
		boolean myMIdExists=false;
		myMIdExists = checkPartiesforActiveMyMId(vecAllParty,myMIdPartyId, control);
		
		
		/* Change Request for SFDC Survivorship - 12/2018 start */
		Vector<XOrgBObjExt> vecSortedPartyForSFDC=new Vector<XOrgBObjExt>();					
		vecSortedPartyForSFDC.addAll(vecAllParty);
		
		Collections.sort(vecSortedPartyForSFDC,
				new Comparator<XOrgBObjExt>() {// Ascending sort
													// - for delta
													// load
					public int compare(XOrgBObjExt party1,
							XOrgBObjExt party2) {
						if (party1.getCreatedDate() == null
								|| party2
										.getCreatedDate() == null)
							return 0;
						return party1
								.getCreatedDate()
								.compareTo(
										party2.getCreatedDate());
					}
				});
		
		XOrgBObjExt retailSfdcMasterParty=null;
		XOrgBObjExt wsSFDCMasterParty=null;
		//Vector<XContEquivBObjExt> vecRetailMasterKey=new Vector<XContEquivBObjExt>();
		Vector<String> vecMasterPartyRetailerIds=new Vector<String>();
		XContEquivBObjExt wsMasterKey=null;
		for(XOrgBObjExt currOrgObj : vecSortedPartyForSFDC)
		{
			Vector<XContEquivBObjExt> vecPartyEquivs=currOrgObj.getItemsTCRMAdminContEquivBObj();
			for(XContEquivBObjExt currXCont : vecPartyEquivs)
			{
				if(currXCont.getAdminSystemType().equalsIgnoreCase(ExternalRuleConstant.SOURCE_IDENTIFIER_TYPE_SFDC))
				{
					if(retailSfdcMasterParty==null || (retailSfdcMasterParty!=null && retailSfdcMasterParty.getPartyId().equalsIgnoreCase(currOrgObj.getPartyId())))
					{
						if(currXCont.getDescription().equalsIgnoreCase(ExternalRuleConstant.MASTER_KEY) && currXCont.getXSourceRetailerFlag()!=null && currXCont.getXSourceRetailerFlag().equalsIgnoreCase(ExternalRuleConstant.ACTIVE_FLAG_Y))
						{
						retailSfdcMasterParty=currOrgObj;
						//vecRetailMasterKey.add(currXCont);
						vecMasterPartyRetailerIds.add(currXCont.getXRetailerId());
						
						}
					}
					
					if(wsSFDCMasterParty==null)
					{
						
						if(currXCont.getDescription().equalsIgnoreCase(ExternalRuleConstant.MASTER_KEY) && currXCont.getXSourceRetailerFlag()!=null && currXCont.getXSourceRetailerFlag().equalsIgnoreCase(ExternalRuleConstant.ACTIVE_FLAG_N))
						{
							wsSFDCMasterParty=currOrgObj;
							wsMasterKey=currXCont;
							
						}
						
					}
				}
				
			}
			/*if(retailSfdcMasterParty!=null && wsSFDCMasterParty!=null)
			{
				break;
			}*/
		}
		
		//XPersonBObjExt sfdcMasterParty=vecSortedPartyForSFDC.firstElement();
		
		/* Change Request for SFDC Survivorship - 12/2018 End */

		

			XContEquivBObjExt myMIdObj=null;
			Vector<TCRMPartyBObj> vecDSCParty=new Vector<TCRMPartyBObj>();
			
			String mapKey = null;
			
			for (int i = 0; i < vecAllParty.size(); i++) {
				TCRMPartyBObj party = (TCRMPartyBObj) vecAllParty.get(i);
				boolean sourceTypeDSC=false;
				if(!allDSCParty)
				{
					if(party.getSourceIdentifierType().equalsIgnoreCase(ExternalRuleConstant.DSC_SOURCE_TYPE))
					{
						vecDSCParty.add(party);
						sourceTypeDSC=true;
						continue;
						
					}
				}
				
				
			Vector<XOrgNameBObjExt> vecTempOrgNameBOBj = new Vector<XOrgNameBObjExt>();
			vecTempOrgNameBOBj = ((XOrgBObjExt) party).getItemsTCRMOrganizationNameBObj();

			String firstPartyNameUsageType = null;

			String secondPartyNameUsageType = null;

			String firstPartyNameUsageValue = null;

			String secondPartyNameUsageValue = null;

			// For Org Names
			for (int j = 0; j < vecTempOrgNameBOBj.size(); j++) {

				XOrgNameBObjExt orgnameBObj = (XOrgNameBObjExt) vecTempOrgNameBOBj.get(j);

				firstPartyNameUsageValue = orgnameBObj.getNameUsageValue();

				firstPartyNameUsageType = orgnameBObj.getNameUsageType();
				 
				mapKey=firstPartyNameUsageType;
			
				if (!orgNameMap.containsKey(firstPartyNameUsageType)) {
					
					orgNameMap.put(mapKey, orgnameBObj);
				}
				else 
				{

					XOrgNameBObjExt nameBObjInMap = orgNameMap.get(firstPartyNameUsageType);

					secondPartyNameUsageValue = nameBObjInMap.getNameUsageValue();

					secondPartyNameUsageType = nameBObjInMap.getNameUsageType();
					
					//secondFS = nameBObjInMap.getXOrgNameRetailerFlag();

					Timestamp Org1CreatedDt = DateFormatter.getTimestamp(nameBObjInMap.getXLastModifiedSystemDate());

					Timestamp Org2CreatedDt = DateFormatter.getTimestamp(orgnameBObj.getXLastModifiedSystemDate());

					if (Org1CreatedDt.after(Org2CreatedDt)) {
						
						
							//Key = Name Usage type
							mapKey = secondPartyNameUsageType;

							orgNameMap.put(mapKey, nameBObjInMap);
						}

					else {
						 
							// Key = Name Usage type
						mapKey = firstPartyNameUsageType;
						orgNameMap.put(mapKey, orgnameBObj);
						
					}

				}
		}
			
			
			// For Party Identification

			Vector<XIdentifierBObjExt> vecTempPartyIdentificationBObj = new Vector<XIdentifierBObjExt>();
			

			vecTempPartyIdentificationBObj = party.getItemsTCRMPartyIdentificationBObj();


			String firstPartyIdentificationType = null;

			String secondPartyIdentificationType = null;

			String firstPartyIdentificationValue = null;

			String secondPartyIdentificationValue = null;

			String firstRetailerId = null;

			String secondRetailerId = null;

			//XIdentifierBObjExt xIdenBObj = null;
			

			for (int j = 0; j < vecTempPartyIdentificationBObj.size(); j++) {

				XIdentifierBObjExt partyIdenBObj = (XIdentifierBObjExt) vecTempPartyIdentificationBObj.get(j);

				firstPartyIdentificationValue = partyIdenBObj.getIdentificationValue();

				firstPartyIdentificationType = partyIdenBObj.getIdentificationType();

				//firstRetailerId = partyIdenBObj.getXRetailerId();

				/*if (firstPartyIdentificationType.equalsIgnoreCase(ExternalRuleConstant.ID_TYPE_MAGIC)) {
					mapKey = firstPartyIdentificationType + firstRetailerId;
				} else {*/
					mapKey = firstPartyIdentificationType;
				//}

				if (!partyIdentMap.containsKey(mapKey) ) {

					partyIdentMap.put(mapKey, partyIdenBObj);

				} else {

					XIdentifierBObjExt idenBObjInMap = partyIdentMap.get(mapKey);

					// secondPartyIdentificationValue =
					// idenBObjInMap.getIdentificationValue();

					secondPartyIdentificationType = idenBObjInMap.getIdentificationType();

					//secondRetailerId = idenBObjInMap.getXRetailerId();

					if (firstPartyIdentificationType.equalsIgnoreCase(secondPartyIdentificationType)) {
						 

							Timestamp party1CreatedDt = DateFormatter.getTimestamp(idenBObjInMap.getXLastModifiedSystemDate());

							Timestamp party2CreatedDt = DateFormatter.getTimestamp(partyIdenBObj.getXLastModifiedSystemDate());

							if (party1CreatedDt.after(party2CreatedDt)) {

								partyIdentMap.put(secondPartyIdentificationType,idenBObjInMap);
							}

							else {

								partyIdentMap.put(firstPartyIdentificationType,partyIdenBObj);
							}
						
					}
				}
			}

			// For Party Admin Contequiv
			Vector<XContEquivBObjExt> vecTempAdminContequivBObj = null;
			vecTempAdminContequivBObj = party.getItemsTCRMAdminContEquivBObj();

			String firstPartyAdminSysType = null;

			String secondPartyAdminSysType = null;

			String firstPartyAdminSysValue = null;

			String secondPartyAdminSysValue = null;

			XContEquivBObjExt newadminContEquivBObj = null;

			firstRetailerId = null;

			secondRetailerId = null;
			
			XContEquivBObjExt xConteq=null;
			
			boolean myMercedeseType=false;
			
			for (int j = 0; j < vecTempAdminContequivBObj.size(); j++) {
				
				//boolean sameDealer=false;

				XContEquivBObjExt partyAdminContequivBObj = (XContEquivBObjExt) vecTempAdminContequivBObj.get(j);

				firstPartyAdminSysValue = partyAdminContequivBObj.getAdminSystemValue();

				firstPartyAdminSysType = partyAdminContequivBObj.getAdminSystemType();

				String firstRetailerFlag = partyAdminContequivBObj.getXSourceRetailerFlag();
				if(firstRetailerFlag!=null)
				{
				if (firstRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_Y)) {

					firstRetailerId = partyAdminContequivBObj.getXRetailerId();
					
					

					mapKey = firstRetailerFlag + firstPartyAdminSysType + firstRetailerId;

				} else {

					mapKey = firstRetailerFlag + firstPartyAdminSysType;

				}
				}

				if(!(partyAdminContequivBObj.getAdminSystemType().equalsIgnoreCase(ExternalRuleConstant.MAGIC_NUMBER_SYS_TYPE)||partyAdminContequivBObj.getAdminSystemType().equalsIgnoreCase(ExternalRuleConstant.UCID_SOURCE_TYPE)|| partyAdminContequivBObj.getAdminSystemType().equalsIgnoreCase(ExternalRuleConstant.SOURCE_IDENTIFIER_TYPE_SFDC)))
				{
				if (!partyAdminConteqMap.containsKey(mapKey)){
					
					partyAdminContequivBObj.setDescription(ExternalRuleConstant.MASTER_KEY);
					partyAdminConteqMap.put(mapKey, partyAdminContequivBObj);
					
				} 
				else
				{
					XContEquivBObjExt partyAdminContequivBObjInMap = (XContEquivBObjExt) partyAdminConteqMap.get(mapKey);

					secondPartyAdminSysValue = partyAdminContequivBObjInMap.getAdminSystemValue();

					secondPartyAdminSysType = partyAdminContequivBObjInMap.getAdminSystemType();

					String secondRetailerFlag = partyAdminContequivBObj.getXSourceRetailerFlag();

					if(secondRetailerFlag!=null)
					if (secondRetailerFlag.equalsIgnoreCase(ExternalRuleConstant.CHARACTER_Y)) {

						secondRetailerId = partyAdminContequivBObj.getXRetailerId();

					}

					/*if(firstRetailerId!=null && secondRetailerId!=null && !firstRetailerId.equals(secondRetailerId))
					{
						sameDealer=checkIfSameDealerRetailCopy(firstRetailerId,secondRetailerId, control);
					}*/
					Timestamp party1CreatedDt = DateFormatter.getTimestamp(partyAdminContequivBObj.getXLastModifiedSystemDate());

					Timestamp party2CreatedDt = DateFormatter.getTimestamp(partyAdminContequivBObjInMap.getXLastModifiedSystemDate());
					
					
					
					
						if(party1CreatedDt.before(party2CreatedDt))
						{
							if(firstPartyAdminSysType.equalsIgnoreCase(ExternalRuleConstant.MYMERC_SOURCETYPE))
							{
							partyAdminConteqMap.put(mapKey, partyAdminContequivBObj);
							if(firstRetailerId==null)
							{
							myMIdObj=partyAdminContequivBObj;
							}
							}
							else
							{
							partyAdminContequivBObj.setDescription(ExternalRuleConstant.MASTER_KEY);
							partyAdminConteqMap.put(mapKey, partyAdminContequivBObj);
							
							
							
							int slaveKey=1;
							String newMapKey=mapKey+ExternalRuleConstant.SLAVE_KEY+Integer.toString(slaveKey);
							
							while(partyAdminConteqMap.containsKey(newMapKey))
							{
								slaveKey++;
								String count=Integer.toString(slaveKey); 
								newMapKey=mapKey+ExternalRuleConstant.SLAVE_KEY+count;
							}
							mapKey=newMapKey;
							partyAdminContequivBObjInMap.setDescription(ExternalRuleConstant.SLAVE_KEY);
							partyAdminConteqMap.put(mapKey, partyAdminContequivBObjInMap);
							}
						}
						else
						{
							if(firstPartyAdminSysType.equalsIgnoreCase(ExternalRuleConstant.MYMERC_SOURCETYPE))
							{
							partyAdminConteqMap.put(mapKey, partyAdminContequivBObjInMap);
							if(firstRetailerId==null)
							{
							myMIdObj=partyAdminContequivBObjInMap;
							}
							}
							else
							{
							partyAdminContequivBObjInMap.setDescription(ExternalRuleConstant.MASTER_KEY);
							partyAdminConteqMap.put(mapKey, partyAdminContequivBObjInMap);
							
							int slaveKey=1;
							String newMapKey=mapKey+ExternalRuleConstant.SLAVE_KEY+Integer.toString(slaveKey);
							
							while(partyAdminConteqMap.containsKey(newMapKey))
							{
								slaveKey++;
								String count=Integer.toString(slaveKey); 
								newMapKey=mapKey+ExternalRuleConstant.SLAVE_KEY+count;
							}
							mapKey=newMapKey;
							partyAdminContequivBObj.setDescription(ExternalRuleConstant.SLAVE_KEY);
							partyAdminConteqMap.put(mapKey, partyAdminContequivBObj);
							}
						}
					
					
					}
			}
				
			}
			//surviveUCIDObj(partyAdminConteqMap,vecTempAdminContequivBObj,xConteq,control);

			
			
			// For Party Contact Method

			Vector<XContactMethodGroupBObjExt> vecTempPartyContactMethodBObj = new Vector<XContactMethodGroupBObjExt>();

			vecTempPartyContactMethodBObj = party
					.getItemsTCRMPartyContactMethodBObj();

			String firstPartyValidityContType = null;

			String secondPartyValidityContType = null;

			String firstPartyContMethodUsageType = null;

			String secondPartyContMethodUsageType = null;

			String firstPartyContMethodUsageValue = null;

			String secondPartyContMethodUsageValue = null;

			XPreferenceBObj incomingPrefObj = null;

			XPreferenceBObj PrefObjInMap = null;

			for (int j = 0; j < vecTempPartyContactMethodBObj.size(); j++) {

				XContactMethodGroupBObjExt partyContMethBObj = (XContactMethodGroupBObjExt) vecTempPartyContactMethodBObj.get(j);

				//Added by Sameeha for Removal of Deleted ContatMethods | 08thMay,2020 | Start
				
				XContactMethodBObjExt existingContMethBObj = (XContactMethodBObjExt) partyContMethBObj.getTCRMContactMethodBObj();
				
				if(!existingContMethBObj.getReferenceNumber().equalsIgnoreCase(ExternalRuleConstant.DELETED_VALUE)){
						
				//Added by Sameeha for Removal of Deleted ContatMethods | 08thMay,2020 | End

				firstPartyContMethodUsageValue = partyContMethBObj.getContactMethodUsageValue();

				firstPartyContMethodUsageType = partyContMethBObj.getContactMethodUsageType();
				
				incomingPrefObj=partyContMethBObj.getXPreferenceBObj();

				if (!partyContMethMap.containsKey(firstPartyContMethodUsageType)) {

					partyContMethMap.put(firstPartyContMethodUsageType,partyContMethBObj);

				} else {

					XContactMethodGroupBObjExt contMethodBObjInMap = partyContMethMap.get(firstPartyContMethodUsageType);

					secondPartyContMethodUsageValue = contMethodBObjInMap.getContactMethodUsageValue();

					secondPartyContMethodUsageType = contMethodBObjInMap.getContactMethodUsageType();
					
					PrefObjInMap=contMethodBObjInMap.getXPreferenceBObj();

					if (firstPartyContMethodUsageType.equalsIgnoreCase(secondPartyContMethodUsageType)) {
						
						Timestamp pref1CreatedDt=null;
						Timestamp pref2CreatedDt=null;
						if(incomingPrefObj!=null && incomingPrefObj.getPreferredType()!=null && PrefObjInMap!=null && PrefObjInMap.getPreferredType()!=null)
						if(!incomingPrefObj.getPreferredType().equalsIgnoreCase(PrefObjInMap.getPreferredType()))
						{
							 pref1CreatedDt = DateFormatter.getTimestamp(PrefObjInMap.getLastModifiedSystemDate());

							 pref2CreatedDt = DateFormatter.getTimestamp(incomingPrefObj.getLastModifiedSystemDate());
							
						}

						Timestamp party1CreatedDt = DateFormatter.getTimestamp(contMethodBObjInMap.getXLastModifiedSystemDate());

						Timestamp party2CreatedDt = DateFormatter.getTimestamp(partyContMethBObj.getXLastModifiedSystemDate());
						
						if (party1CreatedDt.after(party2CreatedDt)) {
							if(pref1CreatedDt!=null && pref2CreatedDt !=null)
							{
							if(pref1CreatedDt.after(pref2CreatedDt))
							{
							partyContMethMap.put(secondPartyContMethodUsageType,contMethodBObjInMap);
							}
							else
							{
								contMethodBObjInMap.getXPreferenceBObj().setPreferredType(incomingPrefObj.getPreferredType());
								contMethodBObjInMap.getXPreferenceBObj().setPreferredValue(incomingPrefObj.getPreferredValue());
								partyContMethMap.put(secondPartyContMethodUsageType, contMethodBObjInMap);
							}
							}
							else
							{
							partyContMethMap.put(secondPartyContMethodUsageType,contMethodBObjInMap);
							}
						}

						else {
							if(pref1CreatedDt!=null && pref2CreatedDt !=null)
							{
							if(pref2CreatedDt.after(pref1CreatedDt))
							{
							partyContMethMap.put(firstPartyContMethodUsageType,partyContMethBObj);
							}
							else
							{
								partyContMethBObj.getXPreferenceBObj().setPreferredType(PrefObjInMap.getPreferredType());
								partyContMethBObj.getXPreferenceBObj().setPreferredValue(PrefObjInMap.getPreferredValue());
								partyContMethMap.put(firstPartyContMethodUsageType,partyContMethBObj);
							}
							}
							else
							{
							partyContMethMap.put(firstPartyContMethodUsageType,partyContMethBObj);
							}
							//partyContMethMap.put(firstPartyContMethodUsageType,partyContMethBObj);

						}

					}

				}
			}
			}

		}


		
		//Remove DSC SourceParty from  Merge
		vecAllParty.removeAll(vecDSCParty);
		
		
		if(vecAllParty!=null && vecAllParty.size()>0)
		{
			    SurviveContequivKeys(vecAllParty,partyAdminConteqMap,wsMasterKey,control);
				// Survive UCID Objects Org
				//surviveUCIDObj(vecAllParty,partyAdminConteqMap,wsSFDCMasterParty, control);
				//Process Magic Number sorting for same Dealer but different Retailer JPN
				sortedMagicNumber( vecAllParty, partyAdminConteqMap, control);
				//PartyAddress Survivorship JPN
		
				partyAddressMap = survivedPartyAddressDetails(vecAllParty,partyAddressMap, control);
		}
		//processDSCSurvivorship(vecDSCParty, null, orgNameMap, partyAddressMap, partyIdentMap, partyContMethMap, partyAdminConteqMap, control);
	}

	
	


	/** For Extended person Attributes Survivorship
	 * @param xMainInputBOBj
	 * @param xDBinputBObj
	 * @param control
	 * @throws Exception
	 */
	public void setXPersonAttr(XPersonBObjExt xMainInputBOBj,
			XPersonBObjExt xDBinputBObj, DWLControl control) throws Exception {

		// XDefunctInd
		if (xMainInputBOBj.getXDefunctInd() == null
				|| xMainInputBOBj.getXDefunctInd().isEmpty()) {
			xMainInputBOBj.setXDefunctInd(xDBinputBObj.getXDefunctInd());
		}
		// XEmployerName
		if (xMainInputBOBj.getXEmployerName() == null
				|| xMainInputBOBj.getXEmployerName().isEmpty()) {
			xMainInputBOBj.setXEmployerName(xDBinputBObj.getXEmployerName());
		}
		// XMarketName
		if (xMainInputBOBj.getXMarketName() == null
				|| xMainInputBOBj.getXMarketName().isEmpty()) {
			xMainInputBOBj.setXMarketName(xDBinputBObj.getXMarketName());
		}
		// XBatchInd
		if (xMainInputBOBj.getXBatchInd() == null
				|| xMainInputBOBj.getXBatchInd().isEmpty()) {
			xMainInputBOBj.setXBatchInd(xDBinputBObj.getXBatchInd());
		}
		// XOccupationType
		if (xMainInputBOBj.getXOccupationType() == null
				|| xMainInputBOBj.getXOccupationType().isEmpty()) {
			xMainInputBOBj
					.setXOccupationType(xDBinputBObj.getXOccupationType());
		}
		// XOccupationValue
		if (xMainInputBOBj.getXOccupationValue() == null
				|| xMainInputBOBj.getXOccupationValue().isEmpty()) {
			xMainInputBOBj.setXOccupationValue(xDBinputBObj
					.getXOccupationValue());
		}
		// XLastModifiedSystemDate
		if (xMainInputBOBj.getXLastModifiedSystemDate() == null
				|| xMainInputBOBj.getXLastModifiedSystemDate().isEmpty()) {
			xMainInputBOBj.setXLastModifiedSystemDate(xDBinputBObj
					.getXLastModifiedSystemDate());
		}
		
		//XGeneratedBy
		if (xMainInputBOBj.getXGeneratedBy() == null || xMainInputBOBj.getXGeneratedBy().isEmpty())
			xMainInputBOBj.setXGeneratedBy(xDBinputBObj.getXGeneratedBy());

		//XHobby
		if (xMainInputBOBj.getXHobby() == null || xMainInputBOBj.getXHobby().isEmpty())
			xMainInputBOBj.setXHobby(xDBinputBObj.getXHobby());

		//XPersonalAgreement
		if(xMainInputBOBj.getXPersonalAgreement() == null || xMainInputBOBj.getXPersonalAgreement().isEmpty())
			xMainInputBOBj.setXPersonalAgreement(xDBinputBObj.getXPersonalAgreement());
		
		// Delete Flag
				if (xMainInputBOBj.getDeleteFlag() == null
						|| xMainInputBOBj.getDeleteFlag().isEmpty()) {
					xMainInputBOBj.setDeleteFlag(xDBinputBObj.getDeleteFlag());
				}
				
		// InfoRemoveFlag
				if (xMainInputBOBj.getInfoRemoveFlag() == null
						|| xMainInputBOBj.getInfoRemoveFlag().isEmpty()) {
					xMainInputBOBj.setInfoRemoveFlag(xDBinputBObj.getInfoRemoveFlag());
				}
		// Dedup Hidden Flag
				if (xMainInputBOBj.getDedupHiddenFlag() == null
						|| xMainInputBOBj.getDedupHiddenFlag().isEmpty()) {
					xMainInputBOBj.setDedupHiddenFlag(xDBinputBObj.getDedupHiddenFlag());
				}
		// PrefCommunicationChannel
				if (xMainInputBOBj.getPrefCommunicationChannel() == null
						|| xMainInputBOBj.getPrefCommunicationChannel().isEmpty()) {
					xMainInputBOBj.setPrefCommunicationChannel(xDBinputBObj.getPrefCommunicationChannel());
				}

	}

	

	/* For Org Extension Survivorship
	 * @param xMainInputBOBj
	 * @param xDBinputBObj
	 * @param control
	 * @throws Exception
	 */
	public void setXOrgAttr(XOrgBObjExt xMainInputBOBj,
			XOrgBObjExt xDBinputBObj, DWLControl control) throws Exception {

		
				//Defunct Ind
				if (xMainInputBOBj.getXDefunctInd() == null
						|| xMainInputBOBj.getXDefunctInd().isEmpty()) {
					xMainInputBOBj.setXDefunctInd(xDBinputBObj.getXDefunctInd());
				}
				
				//Website
				if (xMainInputBOBj.getXWebsite() == null
						|| xMainInputBOBj.getXWebsite().isEmpty()) {
					xMainInputBOBj.setXWebsite(xDBinputBObj.getXWebsite());
				}
		
				//XNumberOfEmployeesType
				if (xMainInputBOBj.getXNumberOfEmployeesType() == null || xMainInputBOBj.getXNumberOfEmployeesType().isEmpty())
					xMainInputBOBj.setXNumberOfEmployeesType(xDBinputBObj.getXNumberOfEmployeesType());
				
				//XNumberOfEmployeesValue
				if (xMainInputBOBj.getXNumberOfEmployeesValue() == null || xMainInputBOBj.getXNumberOfEmployeesValue().isEmpty())
					xMainInputBOBj.setXNumberOfEmployeesValue(xDBinputBObj.getXNumberOfEmployeesValue());
				
				//XLastModifiedSystemDate
				if (xMainInputBOBj.getXLastModifiedSystemDate() == null || xMainInputBOBj.getXLastModifiedSystemDate().isEmpty())
					xMainInputBOBj.setXLastModifiedSystemDate(xDBinputBObj.getXLastModifiedSystemDate());
				
				//XGenerated_by
				if (xMainInputBOBj.getXGenerated_by() == null || xMainInputBOBj.getXGenerated_by().isEmpty())
					xMainInputBOBj.setXGenerated_by(xDBinputBObj.getXGenerated_by());
				
				//XCorporateCategoryType
				if (xMainInputBOBj.getXCorporateCategoryType() == null || xMainInputBOBj.getXCorporateCategoryType().isEmpty())
					xMainInputBOBj.setXCorporateCategoryType(xDBinputBObj.getXCorporateCategoryType());
				
				//XCorporateCategoryValue
				if (xMainInputBOBj.getXCorporateCategoryValue() == null || xMainInputBOBj.getXCorporateCategoryValue().isEmpty())
					xMainInputBOBj.setXCorporateCategoryValue(xDBinputBObj.getXCorporateCategoryValue());
				
				//XCorporateGroupType
				if (xMainInputBOBj.getXCorporateGroupType() == null || xMainInputBOBj.getXCorporateGroupType().isEmpty())
					xMainInputBOBj.setXCorporateGroupType(xDBinputBObj.getXCorporateGroupType());
				
				//XCorporateGroupValue
				if (xMainInputBOBj.getXCorporateGroupValue() == null || xMainInputBOBj.getXCorporateGroupValue().isEmpty())
					xMainInputBOBj.setXCorporateGroupValue(xDBinputBObj.getXCorporateGroupValue());
				
				//XPersonalAgreement
				if(xMainInputBOBj.getXPersonalAgreement() == null || xMainInputBOBj.getXPersonalAgreement().isEmpty())
					xMainInputBOBj.setXPersonalAgreement(xDBinputBObj.getXPersonalAgreement());
		
				// Delete Flag
				if (xMainInputBOBj.getDeleteFlag() == null
						|| xMainInputBOBj.getDeleteFlag().isEmpty()) {
					xMainInputBOBj.setDeleteFlag(xDBinputBObj.getDeleteFlag());
				}
				
				// InfoRemoveFlag
				if (xMainInputBOBj.getInfoRemoveFlag() == null
						|| xMainInputBOBj.getInfoRemoveFlag().isEmpty()) {
					xMainInputBOBj.setInfoRemoveFlag(xDBinputBObj.getInfoRemoveFlag());
				}
				// Dedup Hidden Flag
				if (xMainInputBOBj.getDedupHiddenFlag() == null
						|| xMainInputBOBj.getDedupHiddenFlag().isEmpty()) {
					xMainInputBOBj.setDedupHiddenFlag(xDBinputBObj.getDedupHiddenFlag());
				}
				// PrefCommunicationChannel
				if (xMainInputBOBj.getPrefCommunicationChannel() == null
						|| xMainInputBOBj.getPrefCommunicationChannel().isEmpty()) {
					xMainInputBOBj.setPrefCommunicationChannel(xDBinputBObj.getPrefCommunicationChannel());
				}
	}

	
	/**
	 * @param configItem
	 * @param control
	 * @return
	 * @throws ConfigurationRepositoryException
	 * @throws ManagementException
	 * 
	 * <br>
	 *             generic method to retrieve value from CONFIGELEMENT </br>
	 *
	 */
	public static String getConfigItemValue(String configItem,
			DWLControl control) throws ConfigurationRepositoryException,
			ManagementException {
		String configValue = Configuration.getConfiguration()
				.getConfigItem(configItem, control.retrieveConfigContext())
				.getValue();
		return configValue;
	}

	

	public static String getCodeTypeFromValue(String codeTableName,
			String codeValue, DWLControl control) throws Exception {

		String langId = (String) control.get(DWLControlKeys.LANG_ID);
		CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory
				.getCodeTypeComponentHelper();
		String codeType = null;
		if (codeValue != null) {
			CodeTypeBObj ctBObj = codeTypeCompHelper.getCodeTypeByValue(
					codeTableName, langId, codeValue, control);
			if (ctBObj != null) {
				codeType = ctBObj.gettp_cd();
			}
		}
		return codeType;
	}

	public static void setPartyAddressGroupFromRequest(
			XAddressGroupBObjExt finalAddressGroupBObjExt,
			XAddressGroupBObjExt reqAddressGroupBObjExt, DWLControl control)
			throws BusinessProxyException {
		try {

			finalAddressGroupBObjExt.setControl(control);
			// XRetailerId
			finalAddressGroupBObjExt.setXRetailerId(reqAddressGroupBObjExt
					.getXRetailerId());
			// Address Usage Type
			finalAddressGroupBObjExt.setAddressUsageType(reqAddressGroupBObjExt
					.getAddressUsageType());
			// Address Usage Value
			if (reqAddressGroupBObjExt.getAddressUsageValue() != null)
				finalAddressGroupBObjExt
						.setAddressUsageValue(reqAddressGroupBObjExt
								.getAddressUsageValue());
			// LastModifiedSystemDate
			if (reqAddressGroupBObjExt.getXLastModifiedSystemDate() != null)
				finalAddressGroupBObjExt
						.setXLastModifiedSystemDate(reqAddressGroupBObjExt
								.getXLastModifiedSystemDate());
			// XPreference BObj
			XPreferenceBObj requestPreferenceBObj = reqAddressGroupBObjExt
					.getXPreferenceBObj();
			XPreferenceBObj finalPreferenceBObj = new XPreferenceBObj();

			finalPreferenceBObj.setControl(control);
			// Preferred Type
			if (requestPreferenceBObj.getPreferredType() != null)
				finalPreferenceBObj.setPreferredType(requestPreferenceBObj
						.getPreferredType());
			// Source Identifier type
			if (requestPreferenceBObj.getSourceIdentifierType() != null)
				finalPreferenceBObj
						.setSourceIdentifierType(requestPreferenceBObj
								.getSourceIdentifierType());
			// Start Date
			if (requestPreferenceBObj.getStartDate() != null)
				finalPreferenceBObj.setStartDate(requestPreferenceBObj
						.getStartDate());
			// End Date
			if (requestPreferenceBObj.getEndDate() != null)
				finalPreferenceBObj.setEndDate(requestPreferenceBObj
						.getEndDate());

			finalAddressGroupBObjExt.setXPreferenceBObj(finalPreferenceBObj);

			// XPrivacyAgreement BObj
			XPrivacyAgreementBObj requestPrivacyAgreementBObj = reqAddressGroupBObjExt
					.getXPrivacyAgreementBObj();
			XPrivacyAgreementBObj finalPrivacyAgreementBObj = new XPrivacyAgreementBObj();

			finalPrivacyAgreementBObj.setControl(control);
			// Action
			if (requestPrivacyAgreementBObj.getActionType() != null)
				finalPrivacyAgreementBObj
						.setActionType(requestPrivacyAgreementBObj
								.getActionType());
			// Source Identifier type
			if (requestPrivacyAgreementBObj.getSourceIdentifierType() != null)
				finalPrivacyAgreementBObj
						.setSourceIdentifierType(requestPrivacyAgreementBObj
								.getSourceIdentifierType());
			// Start Date
			if (requestPrivacyAgreementBObj.getStartDate() != null)
				finalPrivacyAgreementBObj
						.setStartDate(requestPrivacyAgreementBObj
								.getStartDate());
			// End Date
			if (requestPrivacyAgreementBObj.getEndDate() != null)
				finalPrivacyAgreementBObj
						.setEndDate(requestPrivacyAgreementBObj.getEndDate());

			finalAddressGroupBObjExt
					.setXPrivacyAgreementBObj(finalPrivacyAgreementBObj);

			// XVerified
			if (reqAddressGroupBObjExt.getXVerifiedType() != null) {
				finalAddressGroupBObjExt
						.setXVerifiedType(reqAddressGroupBObjExt
								.getXVerifiedType());
			}
			// XAddressFlag
			if (reqAddressGroupBObjExt.getXAddressRetailerFlag() != null) {
				finalAddressGroupBObjExt
						.setXAddressRetailerFlag(reqAddressGroupBObjExt
								.getXAddressRetailerFlag());
			}
			// AddressBObj
			XAddressBObjExt finalAddressBObjExt = new XAddressBObjExt();
			finalAddressBObjExt.setControl(control);
			XAddressBObjExt reqAddressBObjExt = (XAddressBObjExt) reqAddressGroupBObjExt
					.getTCRMAddressBObj();

			// AddressLineOne
			if (reqAddressBObjExt.getAddressLineOne() != null)
				finalAddressBObjExt.setAddressLineOne(reqAddressBObjExt
						.getAddressLineOne());
			// AddressLineTwo
			if (reqAddressBObjExt.getAddressLineTwo() != null)
				finalAddressBObjExt.setAddressLineTwo(reqAddressBObjExt
						.getAddressLineTwo());
			// AddressLineThree
			if (reqAddressBObjExt.getAddressLineThree() != null)
				finalAddressBObjExt.setAddressLineThree(reqAddressBObjExt
						.getAddressLineThree());
			// City
			if (reqAddressBObjExt.getCity() != null)
				finalAddressBObjExt.setCity(reqAddressBObjExt.getCity());
			// ProvinceStateType
			if (reqAddressBObjExt.getProvinceStateType() != null)
				finalAddressBObjExt.setProvinceStateType(reqAddressBObjExt
						.getProvinceStateType());
			// ZipPostalCode
			if (reqAddressBObjExt.getZipPostalCode() != null)
				finalAddressBObjExt.setZipPostalCode(reqAddressBObjExt
						.getZipPostalCode());
			// CountryType
			if (reqAddressBObjExt.getCountryType() != null)
				finalAddressBObjExt.setCountryType(reqAddressBObjExt
						.getCountryType());

			// XAddressVerification Date
			if (reqAddressBObjExt.getXAddressVerificationDate() != null)
				finalAddressBObjExt
						.setXAddressVerificationDate(reqAddressBObjExt
								.getXAddressVerificationDate());
			// XDistrictType
			if (reqAddressBObjExt.getXDistrictType() != null)
				finalAddressBObjExt.setXDistrictType(reqAddressBObjExt
						.getXDistrictType());
			// XSubcity
			if (reqAddressBObjExt.getXSubcityType() != null)
				finalAddressBObjExt.setXSubcityType(reqAddressBObjExt
						.getXSubcityType());

			// StartDate
			if (reqAddressGroupBObjExt.getStartDate() != null) {
				finalAddressGroupBObjExt.setStartDate(reqAddressGroupBObjExt
						.getStartDate());
			}
			// EndDate
			if (reqAddressGroupBObjExt.getEndDate() != null) {
				finalAddressGroupBObjExt.setEndDate(reqAddressGroupBObjExt
						.getEndDate());
			}

			finalAddressGroupBObjExt.setTCRMAddressBObj(finalAddressBObjExt);

		} catch (Exception e) {

			e.printStackTrace();
			/*
			 * DWLError error = errHandler
			 * .getErrorMessage(TCRMCoreComponentID.PARTY_ADDRESS_OBJECT,
			 * "UPDERR"
			 * ,TCRMCoreErrorReasonCode.UPDATE_PARTY_ADDRESS_FAILED,control, new
			 * String[0]); throw new
			 * BusinessProxyException(error.getErrorMessage());
			 */
		}

	}

	private void handlePrefAddress(
			Vector<XAddressGroupBObjExt> vecSurvivedAddrBOBj, HashMap<String, XPreferenceBObj> addressPrefMap)
			throws Exception {

		XAddressGroupBObjExt tempAddrBObj = null;
		String preferredAddressType=null;
		List<String> preferedAddrList = new ArrayList<String>();
		
		XPreferenceBObj tempXPref=null;
		
		for(XAddressGroupBObjExt currXAddr : vecSurvivedAddrBOBj)
		{
			if(currXAddr.getXPreferenceBObj()!=null && currXAddr.getXPreferenceBObj().getPreferredType()!=null && currXAddr.getXAddressRetailerFlag().equalsIgnoreCase(ExternalRuleConstant.CHARACTER_N))
			if(currXAddr.getXPreferenceBObj().getPreferredType().equalsIgnoreCase(ExternalRuleConstant.PREFERRED_TYPE_Y))
			{
				if(preferredAddressType==null && tempXPref==null)
				{
				preferredAddressType=currXAddr.getAddressUsageType();
				tempXPref=currXAddr.getXPreferenceBObj();
				}
				else if(tempXPref!=null && currXAddr.getXPreferenceBObj().getLastModifiedSystemDate()!=null)
				{
					Timestamp existingPrefTimestamp=null;
					if(tempXPref.getLastModifiedSystemDate()!=null)
						{
						existingPrefTimestamp=DateFormatter.getTimestamp(tempXPref.getLastModifiedSystemDate());
						}
					//Timestamp existingPrefTimestamp=DWLFunctionUtils.getTimestampFromTimestampString(tempXPref.getLastModifiedSystemDate());
					Timestamp currPrefTimestamp=DWLFunctionUtils.getTimestampFromTimestampString(currXAddr.getXPreferenceBObj().getLastModifiedSystemDate());
					if(existingPrefTimestamp==null)
					{
						tempXPref=currXAddr.getXPreferenceBObj();
						preferredAddressType=currXAddr.getAddressUsageType();
					}
					else if(currPrefTimestamp.after(existingPrefTimestamp))
					{
						tempXPref=currXAddr.getXPreferenceBObj();
						preferredAddressType=currXAddr.getAddressUsageType();
					}
					
				}
				
			}
		}
		
		if(preferredAddressType != null){
			if(ExternalRuleConstant.HOME_ADDRESSES.contains(preferredAddressType)){
				preferedAddrList = ExternalRuleConstant.HOME_ADDRESSES;
			}
			else if(ExternalRuleConstant.WORK_ADDRESSES.contains(preferredAddressType)){
				preferedAddrList = ExternalRuleConstant.WORK_ADDRESSES;
			}
			else if(ExternalRuleConstant.OTHER1_ADDRESSES.contains(preferredAddressType)){
				preferedAddrList = ExternalRuleConstant.OTHER1_ADDRESSES;
			}
			else if(ExternalRuleConstant.OTHER2_ADDRESSES.contains(preferredAddressType)){
				preferedAddrList = ExternalRuleConstant.OTHER2_ADDRESSES;
			}
			else if(ExternalRuleConstant.OTHER3_ADDRESSES.contains(preferredAddressType)){
				preferedAddrList = ExternalRuleConstant.OTHER3_ADDRESSES;
			}
		}
		
		
		for(XAddressGroupBObjExt currXAddr : vecSurvivedAddrBOBj)
		{
			if(preferedAddrList.contains(currXAddr.getAddressUsageType()) && currXAddr.getXAddressRetailerFlag().equalsIgnoreCase(ExternalRuleConstant.ADDRESS_RETAILER_FLAG_N))
			{
				currXAddr.setXPreferenceBObj(tempXPref);
			}
			else
			{
				if(currXAddr.getXPreferenceBObj()!=null)
				{
					currXAddr.getXPreferenceBObj().setPreferredType(ExternalRuleConstant.PREFERRED_TYPE_N);
					currXAddr.getXPreferenceBObj().setPreferredValue(ExternalRuleConstant.PREFERRED_VALUE_N);
				}
			}
		}
		
		
		/*Collections.sort(vecSurvivedAddrBOBj,
				new Comparator<XAddressGroupBObjExt>() {// Ascending sort
													
					public int compare(XAddressGroupBObjExt addr1,
							XAddressGroupBObjExt addr2) {
						if (addr1.getXLastModifiedSystemDate() == null
								|| addr2
										.getXLastModifiedSystemDate() == null)
							return 0;
						return addr1
								.getXLastModifiedSystemDate()
								.compareTo(addr2.getXLastModifiedSystemDate());
					}
				});
		Collections.reverse(vecSurvivedAddrBOBj);
*/
/*		for (XAddressGroupBObjExt partyAddress : vecSurvivedAddrBOBj) {

			String addrType=partyAddress.getAddressUsageType();
			XPreferenceBObj tempXPref=partyAddress.getXPreferenceBObj();
			String preferredAddressType=null;
			
			if(tempXPref!=null && partyAddress.getXAddressRetailerFlag().equalsIgnoreCase(ExternalRuleConstant.CHARACTER_Y))
			{
				if(!addressPrefMap.containsKey(addrType))
				{
					preferredAddressType=addrType;
					addressPrefMap.put(addrType, tempXPref);
				}
				else
				{
				XPreferenceBObj prefObjInMap=addressPrefMap.get(addrType);
				if(prefObjInMap.getLastModifiedSystemDate()!=null && tempXPref!=null && tempXPref.getLastModifiedSystemDate()!=null)
				{
				Timestamp existingPrefTimestamp=DWLFunctionUtils.getTimestampFromTimestampString(prefObjInMap.getLastModifiedSystemDate());
				Timestamp currPrefTimestamp=DWLFunctionUtils.getTimestampFromTimestampString(tempXPref.getLastModifiedSystemDate());
				if(currPrefTimestamp.after(existingPrefTimestamp))
				{
					addressPrefMap.put(addrType, tempXPref);
				}
				else
				{
					addressPrefMap.put(addrType, prefObjInMap);
				}
				
				}
				else
				{
					if( tempXPref!=null  && tempXPref.getLastModifiedSystemDate()!=null)
					{
						addressPrefMap.put(addrType, tempXPref);
					}
				}
			}
			}
	}*/
		/*
		for(XAddressGroupBObjExt currXAddressGrp : vecSurvivedAddrBOBj)
		{
			String addrType=currXAddressGrp.getAddressUsageType();
			if(addressPrefMap.containsKey(addrType))
			{
				if(addressPrefMap.get(addrType).getLocationGroupId().equalsIgnoreCase(currXAddressGrp.getPartyAddressIdPK()))
				{
					currXAddressGrp.setXPreferenceBObj(addressPrefMap.get(addrType));
				}
			}
		}*/
		
		
/*		for(XAddressGroupBObjExt currXAddressGrp : vecSurvivedAddrBOBj)
		{
			if(currXAddressGrp.getXAddressRetailerFlag().equalsIgnoreCase(ExternalRuleConstant.CHARACTER_N))
			{
			if(preferredAddressType==null)
			{
				preferredAddressType=currXAddressGrp.getAddressUsageType();
				if(currXAddressGrp.getXPreferenceBObj()!=null)
				{
				currXAddressGrp.getXPreferenceBObj().setPreferredType(ExternalRuleConstant.PREFERRED_TYPE_Y);
				currXAddressGrp.getXPreferenceBObj().setPreferredValue(ExternalRuleConstant.PREFERRED_VALUE_Y);
				}
				else
				{
					XPreferenceBObj newXprefObj=new XPreferenceBObj();
					newXprefObj.setPreferredType(ExternalRuleConstant.PREFERRED_TYPE_Y);
					newXprefObj.setPreferredValue(ExternalRuleConstant.PREFERRED_VALUE_Y);
					newXprefObj.setLocationGroupId(currXAddressGrp.getPartyAddressIdPK());
					currXAddressGrp.setXPreferenceBObj(newXprefObj);
				}
			}
			else
			{
				if(currXAddressGrp.getXPreferenceBObj()!=null)
				{
				currXAddressGrp.getXPreferenceBObj().setPreferredType(ExternalRuleConstant.PREFERRED_TYPE_N);
				currXAddressGrp.getXPreferenceBObj().setPreferredValue(ExternalRuleConstant.PREFERRED_VALUE_N);
				}
			}
			
			
		}
		}*/
		
	}

	private void handlePrefContactMethod(
			Vector<XContactMethodGroupBObjExt> vecSurvivedPersonContMethBOBj,HashMap<String, XPreferenceBObj> contactMethodPrefMap)
			throws Exception {

		//XContactMethodGroupBObjExt tempContMethodBObj = null;
		/*XPreferenceBObj tempXPref=null;
		String contMethCat=null;
*/
		for (XContactMethodGroupBObjExt partyContMethodBObj : vecSurvivedPersonContMethBOBj) {
		
		String contMethType=partyContMethodBObj.getTCRMContactMethodBObj().getContactMethodType();
		XPreferenceBObj tempXPref=partyContMethodBObj.getXPreferenceBObj();
		//StringTokenizer st =new StringTokenizer(contMethType, "|");
		if(tempXPref!=null && tempXPref.getPreferredType()!=null)
		{
		if(!contactMethodPrefMap.containsKey(contMethType) )
		{
			contactMethodPrefMap.put(contMethType, tempXPref);
			
		}
		else
		{
			XPreferenceBObj prefObjInMap=contactMethodPrefMap.get(contMethType);
			Timestamp existingPrefTimestamp=DWLFunctionUtils.getTimestampFromTimestampString(prefObjInMap.getLastModifiedSystemDate());
			Timestamp currPrefTimestamp=DWLFunctionUtils.getTimestampFromTimestampString(tempXPref.getLastModifiedSystemDate());
			if(currPrefTimestamp.after(existingPrefTimestamp))
			{
				contactMethodPrefMap.put(contMethType, tempXPref);
			}
			else
			{
				contactMethodPrefMap.put(contMethType, prefObjInMap);
			}
			
		}
		}
	
		}
		
		for(XContactMethodGroupBObjExt currXContactMethodgrp : vecSurvivedPersonContMethBOBj)
		{
			/*String contMethTp=currXContactMethodgrp.getTCRMContactMethodBObj().getContactMethodType()+currXContactMethodgrp.getContactMethodUsageType();
			if(contactMethodPrefMap.containsKey(contMethTp))
			{
				currXContactMethodgrp.setXPreferenceBObj(contactMethodPrefMap.get(contMethTp));
			}*/
			String contMethTp=currXContactMethodgrp.getTCRMContactMethodBObj().getContactMethodType();
			if(contactMethodPrefMap.containsKey(contMethTp))
			{
				if(contactMethodPrefMap.get(contMethTp).getLocationGroupId().equalsIgnoreCase(currXContactMethodgrp.getPartyContactMethodIdPK()))
				{
					currXContactMethodgrp.setXPreferenceBObj(contactMethodPrefMap.get(contMethTp));
				}
				else if(contactMethodPrefMap.get(contMethTp).getPreferredType().equalsIgnoreCase(ExternalRuleConstant.PREFERRED_TYPE_Y))
				{
					currXContactMethodgrp.getXPreferenceBObj().setPreferredType(ExternalRuleConstant.PREFERRED_TYPE_N);
					currXContactMethodgrp.getXPreferenceBObj().setPreferredValue(ExternalRuleConstant.PREFERRED_VALUE_N);
				}
			}
		}
	}

	}
		
