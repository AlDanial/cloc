package com.ibm.daimler.dsea.extrules.sdp;

import java.util.Vector;

import com.dwl.base.externalrule.Rule;
import com.dwl.base.logging.DWLLoggerManager;
import com.dwl.base.logging.IDWLLogger;
import com.dwl.base.util.StringUtils;
import com.dwl.management.config.client.Configuration;
import com.dwl.tcrm.common.IExtension;
import com.dwl.tcrm.coreParty.component.TCRMAddressBObj;
import com.dwl.tcrm.utilities.ThirdPartyStandardizerUtil;

import com.ibm.daimler.dsea.component.*;
public class DSEACheckAddrForUpdateRule extends Rule {



	protected final static IDWLLogger logger = DWLLoggerManager
			.getLogger(DSEACheckAddrForUpdateRule.class);

	protected String ruleName = "CheckAddrForUpdateRule";

	protected String debugStr = "External Java Rule 132 " + ruleName + ": ";
	
	private final static String LOCATION_NORMALIZATION_ENABLED = "/IBM/Party/LocationNormalization/enabled";
	private static final String ADDRESS_FORMATTER_MAPPINGS = "/IBM/ThirdPartyAdapters/Address/Formatter";    // AddressLineOne=StreetNumber+PreDirectional+StreetName+PostDirectional+StreetSuffix;AddressLineTwo=StreetNumber+PreDirectional+StreetName
	static String[] normalizedItemsArray = null;

	static {
		try{
			normalizedItemsArray = ThirdPartyStandardizerUtil.getNormalizedItems(ADDRESS_FORMATTER_MAPPINGS);
		} catch (Exception ex) {
			//TODO: Replace Exception Control Flow - getConfigItem
		}
	}

	/**
	 * 	@Override
	 * @param input
	 *        A vector of two instances of TCRMAddressBObj, which are going
	 *        to be compared.
	 * @param componentObject
	 *        Not used currently
	 * @return True if there is no difference between two instances.
	 */
	public Object execute(Object input, Object componentObject)
			throws Exception {
		debugOut(debugStr + "Entering Rule");
		
		Vector inputVector = (Vector) input;
		//Incoming Address
		TCRMAddressBObj addBObjA = ((TCRMAddressBObj) inputVector
				.elementAt(0));
		//Existing Address
		TCRMAddressBObj addBObjB = ((TCRMAddressBObj) inputVector
				.elementAt(1));
		boolean isSame = false;
 
		// if the following fields are same, we do not need to update address
		if (StringUtils.compareWithTrim(addBObjA.getCountryType(), 
				addBObjB.getCountryType())
				&& StringUtils.compareWithTrim(addBObjA.getResidenceType(),
						addBObjB.getResidenceType())
				&& StringUtils.compareWithTrim(addBObjA.getAddressLineOne(),
						addBObjB.getAddressLineOne())
				&& StringUtils.compareWithTrim(addBObjA.getAddressLineTwo(),
						addBObjB.getAddressLineTwo())
				&& StringUtils.compareWithTrim(addBObjA.getAddressLineThree(),
						addBObjB.getAddressLineThree())
				&& StringUtils.compareWithTrim(addBObjA.getProvinceStateType(),
						addBObjB.getProvinceStateType())
				&& StringUtils.compareWithTrim(addBObjA.getCity(), 
						addBObjB.getCity())
				&& StringUtils.compareWithTrim(addBObjA.getZipPostalCode(),
						addBObjB.getZipPostalCode())
				&& StringUtils.compareWithTrim(addBObjA.getResidenceNumber(),
						addBObjB.getResidenceNumber())
				&& StringUtils.compareWithTrim(addBObjA.getCountyCode(),
						addBObjB.getCountyCode())
				&& StringUtils.compareWithTrim(addBObjA.getLongitudeDegrees(),
						addBObjB.getLongitudeDegrees())
				&& StringUtils.compareWithTrim(addBObjA.getLatitudeDegrees(),
						addBObjB.getLatitudeDegrees())
				&& StringUtils.compareWithTrim(addBObjA.getZipPostalBarCode(),
						addBObjB.getZipPostalBarCode())) {

			//logic to compare extended attributes
		if(addBObjA instanceof XAddressBObjExt && addBObjB instanceof XAddressBObjExt){

				XAddressBObjExt addressBObjExt1 = (XAddressBObjExt)addBObjA;
				XAddressBObjExt addressBObjExt2 = (XAddressBObjExt)addBObjB;

				if(StringUtils
						.compareWithTrim(addressBObjExt1.getXSuburb(),
								addressBObjExt2.getXSuburb())
								&& StringUtils
								.compareWithTrim(addressBObjExt1.getXBuildingName(),
										addressBObjExt2.getXBuildingName())
										&& StringUtils
										.compareWithTrim(addressBObjExt1.getXDistrictType(),
												addressBObjExt2.getXDistrictType())
												&& StringUtils
												.compareWithTrim(addressBObjExt1.getXStreetName(),
														addressBObjExt2.getXStreetName())
														&& StringUtils
														.compareWithTrim(addressBObjExt1.getXStreetNumber(),
																addressBObjExt2.getXStreetNumber())
																&& StringUtils
																.compareWithTrim(addressBObjExt1.getXSubcityType(),
																		addressBObjExt2.getXSubcityType())
																		&& StringUtils.compareWithTrim(addressBObjExt1.getXAddressVerificationDate(), 
																				addressBObjExt2.getXAddressVerificationDate())){
					//compareResultBln = new java.lang.Boolean(true);
					isSame = true;
				}
			}
			
			else{
			//compareResultBln = new java.lang.Boolean(true);
				isSame = true;
			}
		} 
		
		boolean isLocationNormalizationEnabled = Configuration.getConfiguration().getConfigItem(
				LOCATION_NORMALIZATION_ENABLED, addBObjA.getControl().retrieveConfigContext()).getBooleanValue();
		
		debugOut("isLocationNormalizationEnabled:" + isLocationNormalizationEnabled);
		
		boolean isNormalizedFieldsSame = false;
		// No matter LocationNormalization is enabled or not, always check if all address items changed or not (bug fix for 284)

			//Check normalized field , those defined in the ADDRESS_FORMATTER
			isNormalizedFieldsSame = !isNormalizedAddressItemsChanged(addBObjA, addBObjB, normalizedItemsArray, true);
			//if both un-normalized and normalized fields are the same, then the two addresses are the same;
			//otherwise the two addresses are not the same
			isSame = isSame && isNormalizedFieldsSame;


		return Boolean.valueOf(isSame);
	}
	
	/**
	 * To compare all normalized address items in request with the corresponding data in database; 
	 * if any item is changed, set the flag to true; if there is no item changed, return false.
	 * 
	 * @param addressBObj
	 * @param oldAddressBObj
	 * @return boolean 
	 * @throws Exception
	 */
	protected boolean isNormalizedAddressItemsChanged(TCRMAddressBObj addressBObj, TCRMAddressBObj oldAddressBObj, String[] normalizedAddressFields, boolean isLocationNormalizationEnabled) throws Exception {
		boolean bChanged = false;
		String field = null;
		String fieldValue = null;
		String oldFieldValue = null;
		
		if (isLocationNormalizationEnabled && normalizedAddressFields != null) {
			for (int i = 0; i < normalizedAddressFields.length; i++) {
				field = normalizedAddressFields[i];
				fieldValue = ThirdPartyStandardizerUtil.getSpecifiedValueFromBObj(addressBObj, field);
				oldFieldValue = ThirdPartyStandardizerUtil.getSpecifiedValueFromBObj(oldAddressBObj, field);
				
				if (!StringUtils.compareWithTrim(fieldValue, oldFieldValue)) {
					bChanged = true;
					break;
				}
			}
		}
		
		return bChanged;
	}

	
	/**
	 * @param s
	 *            Output the debug information to log file if the log level is
	 *            set to fine.
	 */
	protected void debugOut(String s) {
		if (logger.isFineEnabled()) {
			logger.fine(s);
		}
	}

}
