package com.ibm.daimler.dsea.extrules.sdp;

import java.util.Vector;

import com.dwl.base.DWLCommon;
import com.dwl.base.DWLControl;
import com.dwl.base.error.DWLStatus;
import com.dwl.base.util.StringUtils;
import com.dwl.tcrm.coreParty.component.ProbabilisticOrganizationSearchBObj;
import com.dwl.tcrm.coreParty.component.TCRMAddressBObj;
import com.dwl.tcrm.coreParty.component.TCRMContactMethodBObj;
import com.dwl.tcrm.coreParty.component.TCRMOrganizationBObj;
import com.dwl.tcrm.coreParty.component.TCRMOrganizationNameBObj;
import com.dwl.tcrm.coreParty.component.TCRMPartyAddressBObj;
import com.dwl.tcrm.coreParty.component.TCRMPartyComponent;
import com.dwl.tcrm.coreParty.component.TCRMPartyContactMethodBObj;
import com.dwl.tcrm.coreParty.component.TCRMPartyIdentificationBObj;
import com.dwl.tcrm.coreParty.entityObject.EObjIdentifier;
import com.dwl.tcrm.coreParty.entityObject.EObjLocationGroup;
import com.dwl.tcrm.coreParty.entityObject.EObjOrgName;
import com.dwl.tcrm.exception.TCRMDataInvalidException;
import com.dwl.tcrm.utilities.DateFormatter;
import com.dwl.tcrm.utilities.TCRMClassFactory;
import com.dwl.tcrm.utilities.TCRMExceptionUtils;
import com.ibm.daimler.dsea.component.XOrgBObjExt;
import com.ibm.daimler.dsea.component.XOrgNameBObjExt;
import com.ibm.daimler.dsea.extrules.constant.ExternalRuleConstant;
import com.ibm.mdm.common.util.PropertyManager;
import com.ibm.mdm.eme.metadata.CriticalData;
import com.ibm.mdm.mds.pme.api.bean.Attribute;
import com.ibm.mdm.mds.pme.api.bean.Record;
import com.ibm.mdm.mds.pme.api.bean.RecordId;
import com.ibm.daimler.dsea.extrules.constant.ExternalRuleConstant;
import com.ibm.daimler.dsea.extrules.util.ExternalRuleUtil;

import java.util.Collection;
import java.util.Iterator;
import java.util.Set;
import java.util.Vector;

public class OrganizationDerivedDataConverter extends PartyDerivedDataConverter
{
  public static final String copyright = "Licensed Materials -- Property of IBM\n(c) Copyright IBM Corp. 2011, 2014\nUS Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.";
  private Record organizationRecord = null;
  private static final String ORG_NAME_MDM_ATTRIBUTE_NAME = "OrganizationName";
  private static final String ORG_ORGNAME_NAMEUSAGETYPE_PREFIX = "Organization.OrganizationName.NameUsageType.";
  private static final String ORG_PARTYADDRESS_ADDRESSUSAGETYPE_PREFIX = "Organization.PartyAddress.AddressUsageType.";
  private static final String ORG_PARTYIDENTIFICATION_IDENTIFICATIONTYPE_PREFIX = "Organization.PartyIdentification.IdentificationType.";
  private static final String ORG_PARTYCONTACTMETHOD_CONTACTMETHODUSAGETYPE_PREFIX = "Organization.PartyContactMethod.ContactMethodUsageType.";
  private static final String ESTABLISHED_DATE_MDM_ATTRIBUTE_NAME = "EstablishedDate";
  private static final Object ORG_GROUP_NAME = "Organization";
  private static final String MARKET_MDM_ATTRIBUTE_NAME = "XMarketName";
  private boolean isCommIdPresent = false;
  boolean probabilisticSearch = false;

  private void buildOrgNameAttributes(Vector<TCRMOrganizationNameBObj> vecOrgName, String xmarketName)
    throws Exception
  {
    if ((vecOrgName != null) && (vecOrgName.size() > 0)) {
      Vector<CriticalData> vecCricDataForOrgName = getCriticalDataElementsOfChildObjectOfOrganization(
        (DWLCommon)vecOrgName
        .firstElement());
      for (TCRMOrganizationNameBObj orgNameBObj : vecOrgName) {
        String nameUsageTp = orgNameBObj.getNameUsageType();

        if ((this.probabilisticSearch) && (nameUsageTp == null))
        {
          nameUsageTp = "1";
        }

        String attrCode = PropertyManager.getOptionalProperty("Organization.OrganizationName.NameUsageType." + nameUsageTp, null);

        if (attrCode != null)
          for (CriticalData criticalData : vecCricDataForOrgName) {
            String instancePK = criticalData.getInstancePK();
            if ((instancePK == null) || (instancePK.equals(nameUsageTp))) {
              String fieldName = criticalData.getElementName();

              if (StringUtils.isNonBlank(orgNameBObj
                .getOrganizationName()))
              {
                if (fieldName
                  .equalsIgnoreCase("OrganizationName")) {
                  Attribute orgNameAttr = new Attribute(attrCode);
                  String orgName = orgNameBObj.getOrganizationName();
                  if(orgName.contains("บจก")){
                	  orgName = orgName.replace("บจก", "");
                  } else if(orgName.contains("お客様個人名を入力してください")){
                	  
                	  orgName = orgName.replace("お客様個人名を入力してください", "");
                	  
                  } else if(orgName.contains("【お客様個人名を入力してください】")){
                	  
                	  orgName = orgName.replace("【お客様個人名を入力してください】", "");
                	  
                  } else if(orgName.contains("削除顧客")){
                	  
                	  orgName = orgName.replace("削除顧客", "");
                	  
                  } else if(orgName.contains("不明")){
                	  
                	  orgName = orgName.replace("不明", "");
                	  
                  } else if(orgName.contains("フメイ")){
                	  
                	  orgName = orgName.replace("フメイ", "");
                	  
                  } else if(orgName.contains("名乗らず")){
                	  
                	  orgName = orgName.replace("名乗らず", ""); 
                  }
                  
                  
                  if(xmarketName!=null && xmarketName.equalsIgnoreCase(ExternalRuleConstant.JAPAN_MARKET_NAME))
                  {
                	  if(orgName.contains("　")){
                		  orgName = orgName.replaceAll("　", " ");
	                  }if(orgName.contains("－")){
	                	  orgName = orgName.replaceAll("－", "-");	  
	                  }if(orgName.contains("・")){
                	  orgName = orgName.replaceAll("・", "・");
                  	  }
                 	 if(orgName.contains("�")){
                	  orgName = orgName.replaceAll("�", "");
	                  }
                  }
                  if(xmarketName.equalsIgnoreCase(ExternalRuleConstant.KOREA_MARKET_NAME))
					{
						if(orgName.contains("~")){							                	  
							orgName = orgName.replaceAll("~", " ");
						}if(orgName.contains("�")){							                	  
							orgName = orgName.replaceAll("�", " ");
						}if(orgName.contains("|")){							                	  
							orgName = orgName.replaceAll("|", " ");
						}if(orgName.contains("^")){							                	  
							orgName = orgName.replaceAll("^", " ");
						}if(orgName.contains(":")){							                	  
							orgName = orgName.replaceAll(":", " ");
						}if(orgName.contains(" ")){
							orgName = orgName.replaceAll(" ", " ");
						}
					}
				  
				  if(xmarketName!=null && xmarketName.equalsIgnoreCase(ExternalRuleConstant.MARKET_NAME_INDIA))
					{
										// char a='?';
										// int ascii = (int) a;
										// System.err.println(ascii);
										String orgName1 = orgName;
										for (int i = 0; i < orgName.length(); i++) {
											char positionI;
											int asciiValue;
											positionI = orgName.charAt(i);
											asciiValue = (int) positionI;
											
											if (asciiValue == 63)// ASCII value
																	// of ? is
																	// 63
											{
												orgName = orgName.replace(
														(char) 63, (char) 32);
											}
											if (asciiValue == 42)// ASCII value
																	// of * is
																	// 42
											{
												orgName = orgName.replace(
														(char) 42, (char) 32);
											}
											if (asciiValue == 61)// ASCII value
																	// of = is
																	// 61
											{
												orgName = orgName.replace(
														(char) 61, (char) 32);
											}
											if (asciiValue == 96)// ASCII value
																	// of "`" is
																	// 96
											{
												orgName = orgName.replace(
														(char) 96, (char) 32);
											}
											if (asciiValue == 64)// ASCII value
																	// of "@" is
																	// 64
											{
												orgName = orgName.replace(
														(char) 64, (char) 32);
											}
											

										}
										if (orgName.contains("�")) {

											orgName = orgName.replaceAll("�","");
										} else if (orgName.contains("✔")) {

											orgName = orgName.replaceAll("✔","");
										}
		                  						 			
					}
				  if(xmarketName!=null && xmarketName.equalsIgnoreCase(ExternalRuleConstant.MARKET_NAME_AUSTRALIA)
							||xmarketName!=null && xmarketName.equalsIgnoreCase(ExternalRuleConstant.MARKET_NAME_NEWZEALAND))
					{
					  if(orgName.contains("�")){
	                	  
	                	  orgName = orgName.replaceAll("�", "");
	                  }
					}
						/* AEM Market changes - Pushpraj */
						if(xmarketName!=null && ExternalRuleConstant.AEM_MARKETS.contains(xmarketName))
						{
							ExternalRuleUtil extUtil=new ExternalRuleUtil();
							orgName=extUtil.processNameDataAEM(orgName,xmarketName,ORG_GROUP_NAME.toString());
						}
                  //FS change
                  if(isCommIdPresent && ((XOrgNameBObjExt)orgNameBObj).getXOrgNameRetailerFlag() != null && 
                		  ((XOrgNameBObjExt)orgNameBObj).getXOrgNameRetailerFlag().equals("FS")){
                	  String orgNameLocal = ((XOrgNameBObjExt)orgNameBObj).getXOrganizationNameLocal();
                	  if(orgNameLocal!= null && orgNameLocal.contains("บจก"))
                    	  orgNameLocal = orgNameLocal.replace("บจก", "");
                	  orgNameAttr.setField("orgname", ((XOrgNameBObjExt)orgNameBObj).getXOrganizationNameLocal());
                  }else{
						orgNameAttr.setField("orgname", orgName);
				  }
                  
                  boolean isOrgNameActive = checkIfActiveObject(orgNameBObj.getEObjOrganizationName().getEndDt(), orgNameBObj.getControl());
                  orgNameAttr.setActive(isOrgNameActive);

                  this.organizationRecord.addAttribute(orgNameAttr);
                }
              }
            }
          }
      }
    }
  }

  private void buildOrgAddressAttributes(Vector<TCRMPartyAddressBObj> vecOrgAddress, String xmarketName)
    throws Exception
  {
    if ((vecOrgAddress != null) && (vecOrgAddress.size() > 0)) {
      Vector<CriticalData> vecPartyAddressCriticalData = getCriticalDataElementsOfChildObjectOfOrganization(vecOrgAddress.firstElement());
      Vector<CriticalData> vecCricDataForAddr = getCriticalDataElementsOfChildObjectOfOrganization(vecOrgAddress.firstElement().getTCRMAddressBObj());
      
      for (TCRMPartyAddressBObj prtyAddressBobj : vecOrgAddress)
    	      {
        TCRMAddressBObj tcrmAddBObj = prtyAddressBobj
          .getTCRMAddressBObj();

        String addressUsageType = prtyAddressBobj.getAddressUsageType();

        if ((this.probabilisticSearch) && (addressUsageType == null))
        {
          addressUsageType = "3";
        }

        String attrCode = null;
        for (CriticalData partyAddressCriticalData : vecPartyAddressCriticalData) {
        if (StringUtils.isBlank(attrCode)) {
          String instancePK = partyAddressCriticalData.getInstancePK();
          if ((instancePK == null) || (instancePK.equals(addressUsageType)))
          {
            attrCode = PropertyManager.getOptionalProperty("Organization.PartyAddress.AddressUsageType." + addressUsageType, null);

            if (attrCode != null) {
              Attribute orgAddrAttr = new Attribute(attrCode);

              for (CriticalData criticalData : vecCricDataForAddr) {
                String fieldName = criticalData.getElementName();
                if (StringUtils.isNonBlank(tcrmAddBObj.getCity()))
                {
                  if (fieldName
                    .equalsIgnoreCase("City")) {
                	  
                	  String cityName=tcrmAddBObj.getCity();
						
						if(xmarketName.equalsIgnoreCase(ExternalRuleConstant.JAPAN_MARKET_NAME))
						{
							if(cityName.contains("　")){
			                	  
								cityName = cityName.replaceAll("　", " ");
							}if(cityName.contains("－")){
			                	  
								cityName = cityName.replaceAll("－", "-");
			                    
		                  } if(cityName.contains("・")){
		                	  
		                	  cityName = cityName.replaceAll("・", "・");
		                  }
		                  	if(cityName.contains("�")){
		                	  
		                	  cityName = cityName.replaceAll("�", "");
							
						}
						} 
						 if(xmarketName!=null && xmarketName.equalsIgnoreCase(ExternalRuleConstant.MARKET_NAME_AUSTRALIA)
									||xmarketName!=null && xmarketName.equalsIgnoreCase(ExternalRuleConstant.MARKET_NAME_NEWZEALAND))
							{
							  if(cityName.contains("�")){
			                	  
								  cityName = cityName.replaceAll("�", "");
			                  }
							}
                    orgAddrAttr.setField("city", cityName);
                    continue; } 
                }if (StringUtils.isNonBlank(tcrmAddBObj
                  .getResidenceNumber()))
                {
                  if (fieldName
                    .equalsIgnoreCase("ResidenceNumber")) {
                	  
                	  String residenceNum=tcrmAddBObj.getResidenceNumber();
						if(xmarketName.equalsIgnoreCase(ExternalRuleConstant.JAPAN_MARKET_NAME))
						{
							if(residenceNum.contains("　")){
			                	  
								residenceNum = residenceNum.replaceAll("　", " ");
							}if(residenceNum.contains("－")){
			                	  
								residenceNum = residenceNum.replaceAll("－", "-");
			                    
		                  } if(residenceNum.contains("・")){
		                	  
		                	  residenceNum = residenceNum.replaceAll("・", "・");
		                  }
							if(residenceNum.contains("�")){
		                	  
		                	  residenceNum = residenceNum.replaceAll("�", "");
		                  }
						}
						 if(xmarketName!=null && xmarketName.equalsIgnoreCase(ExternalRuleConstant.MARKET_NAME_AUSTRALIA)
									||xmarketName!=null && xmarketName.equalsIgnoreCase(ExternalRuleConstant.MARKET_NAME_NEWZEALAND))
							{
							  if(residenceNum.contains("�")){
			                	  
								  residenceNum = residenceNum.replaceAll("�", "");
			                  }
							}
                	  
                    orgAddrAttr.setField("residencenum", residenceNum);
                    continue; } 
                }if (StringUtils.isNonBlank(tcrmAddBObj
                  .getProvinceStateType()))
                {
                  if (fieldName
                    .equalsIgnoreCase("ProvinceStateType")) {
                    orgAddrAttr.setField("provstate", tcrmAddBObj
                      .getProvinceStateType());
                    continue; } 
                }if (StringUtils.isNonBlank(tcrmAddBObj
                  .getAddressLineOne()))
                {
                  if (fieldName
                    .equalsIgnoreCase("AddressLineOne")) {
                	  String addressLineOne = tcrmAddBObj.getAddressLineOne();
						
						if(xmarketName.equalsIgnoreCase(ExternalRuleConstant.JAPAN_MARKET_NAME))
						{
						if(addressLineOne.contains("　")){
		                	  
							addressLineOne = addressLineOne.replaceAll("　", " ");
						}if(addressLineOne.contains("－")){
		                	  
		                	  addressLineOne = addressLineOne.replaceAll("－", "-");
		                    
	                  } if(addressLineOne.contains("・")){
	                	  
	                	  addressLineOne = addressLineOne.replaceAll("・", "・");
	                  } if(addressLineOne.contains("�")){
	                	  
	                	  addressLineOne = addressLineOne.replaceAll("�", "");
	                  }
						}
						if(xmarketName!=null && xmarketName.equalsIgnoreCase(ExternalRuleConstant.MARKET_NAME_AUSTRALIA)
								||xmarketName!=null && xmarketName.equalsIgnoreCase(ExternalRuleConstant.MARKET_NAME_NEWZEALAND))
						{
						  if(addressLineOne.contains("�")){
		                	  
							  addressLineOne = addressLineOne.replaceAll("�", "");
		                  }
						}
                	  
					//tcrmAddBObj.setAddressLineOne(addressLineOne);
                    orgAddrAttr.setField("addrline1", addressLineOne);
                    continue; } 
                }if (StringUtils.isNonBlank(tcrmAddBObj
                  .getAddressLineTwo()))
                {
                  if (fieldName
                    .equalsIgnoreCase("AddressLineTwo")) {
                	  String addressLineTwo = tcrmAddBObj.getAddressLineTwo();
						
					if(xmarketName.equalsIgnoreCase(ExternalRuleConstant.JAPAN_MARKET_NAME))
					{
						if(addressLineTwo.contains("　")){
		                	  
							addressLineTwo = addressLineTwo.replaceAll("　", " ");
						}if(addressLineTwo.contains("－")){
		                	  
							addressLineTwo = addressLineTwo.replaceAll("－", "-");
		                    
	                  } if(addressLineTwo.contains("・")){
	                	  
	                	  addressLineTwo = addressLineTwo.replaceAll("・", "・");
	                  } if(addressLineTwo.contains("�")){
	                	  
	                	  addressLineTwo = addressLineTwo.replaceAll("�", "");
	                  }
					}
					if(xmarketName!=null && xmarketName.equalsIgnoreCase(ExternalRuleConstant.MARKET_NAME_AUSTRALIA)
							||xmarketName!=null && xmarketName.equalsIgnoreCase(ExternalRuleConstant.MARKET_NAME_NEWZEALAND))
					{
					  if(addressLineTwo.contains("�")){
	                	  
	                	  addressLineTwo = addressLineTwo.replaceAll("�", "");
	                  }
					}
              	  
					//tcrmAddBObj.setAddressLineTwo(addressLineTwo);
                	  
                    orgAddrAttr.setField("addrline2", addressLineTwo);
                    continue; } 
                }if (StringUtils.isNonBlank(tcrmAddBObj
                  .getAddressLineThree()))
                {
                  if (fieldName
                    .equalsIgnoreCase("AddressLineThree")) {
                	  
                	  String addressLineThree = tcrmAddBObj.getAddressLineThree();
						
  					if(xmarketName.equalsIgnoreCase(ExternalRuleConstant.JAPAN_MARKET_NAME))
  					{
  						if(addressLineThree.contains("　")){
  		                	  
  							addressLineThree = addressLineThree.replaceAll("　", " ");
  						}if(addressLineThree.contains("－")){
  		                	  
  							addressLineThree = addressLineThree.replaceAll("－", "-");
  		                    
  	                  } if(addressLineThree.contains("・")){
  	                	  
  	                	addressLineThree = addressLineThree.replaceAll("・", "・");
  	                  }
  	                   if(addressLineThree.contains("�")){
	                	  
  	                	addressLineThree = addressLineThree.replaceAll("�", "");
	                  }
  						
  					}
  					if(xmarketName!=null && xmarketName.equalsIgnoreCase(ExternalRuleConstant.MARKET_NAME_AUSTRALIA)
							||xmarketName!=null && xmarketName.equalsIgnoreCase(ExternalRuleConstant.MARKET_NAME_NEWZEALAND))
					{
					  if(addressLineThree.contains("�")){
	                	  
  	                	addressLineThree = addressLineThree.replaceAll("�", "");
	                  }
  						
  					}
  					//tcrmAddBObj.setAddressLineThree(addressLineThree);
                	  
                	  
                    orgAddrAttr.setField("addrline3", addressLineThree);
                    continue; } 
                }if (StringUtils.isNonBlank(tcrmAddBObj
                  .getZipPostalCode()))
                {
                  if (fieldName
                    .equalsIgnoreCase("ZipPostalCode")) {
                	  String zipPostalCode = tcrmAddBObj.getZipPostalCode();
                	  if(xmarketName.equalsIgnoreCase(ExternalRuleConstant.JAPAN_MARKET_NAME))
					  {
	                  	if(!zipPostalCode.matches("[0-9]*"))
                  		{
                  			zipPostalCode=null;
                  		}
	                  	
					  }
                    orgAddrAttr.setField("postalcode", zipPostalCode);
                  }
                }
              }
              if (orgAddrAttr.getFieldNames().size() > 0) {
                boolean isOrgAddrActive = checkIfActiveObject(prtyAddressBobj.getEObjLocationGroup().getEndDt(), prtyAddressBobj.getControl());
                orgAddrAttr.setActive(isOrgAddrActive);
                
             // Start change to exclude all Address from EME_RECCMPD for Japan by Shashi (17-06-2021)
				if(xmarketName != null && !(xmarketName.equalsIgnoreCase(ExternalRuleConstant.JAPAN_MARKET_NAME)))
				{	

                this.organizationRecord.addAttribute(orgAddrAttr);
                }
				// End Changes
              }
            }
          }
        }
        
        }	
      }
    }
  }

  private void buildOrgIdentificationAttributes(Vector<TCRMPartyIdentificationBObj> vecPersonIdentification)
    throws Exception
  {
    if ((vecPersonIdentification != null) && 
      (vecPersonIdentification.size() > 0)) {
      Vector<CriticalData> vecCritVectorForPersonIdentification = getCriticalDataElementsOfChildObjectOfOrganization(
        (DWLCommon)vecPersonIdentification
        .firstElement());

      for (TCRMPartyIdentificationBObj prtyIdentBobj : vecPersonIdentification)
      {
        String identUsageType = prtyIdentBobj.getIdentificationType();
        String attrCode = PropertyManager.getOptionalProperty("Organization.PartyIdentification.IdentificationType." + identUsageType, null);

        if (attrCode != null)
          for (CriticalData criticalData : vecCritVectorForPersonIdentification) {
            String instancePK = criticalData.getInstancePK();
            if ((instancePK == null) || (instancePK.equals(identUsageType))) {
              String fieldName = criticalData.getElementName();

              if (StringUtils.isNonBlank(prtyIdentBobj
                .getIdentificationNumber()))
              {
                if (fieldName
                  .equalsIgnoreCase("IdentificationNumber")) {
                  Attribute orgIdentAttr = new Attribute(attrCode);
                  orgIdentAttr.setField("idnum", prtyIdentBobj
                    .getIdentificationNumber());
	              //changed for FS
                  if(prtyIdentBobj.getIdentificationType() != null && prtyIdentBobj.getIdentificationType().equals("1006"))
                	  isCommIdPresent = true;
                  //changed for FS
                  boolean isOrgIdentificationActive = checkIfActiveObject(prtyIdentBobj.getEObjIdentifier().getEndDt(), prtyIdentBobj.getControl());
                  orgIdentAttr.setActive(isOrgIdentificationActive);

                  this.organizationRecord.addAttribute(orgIdentAttr);
                }
              }
            }
          }
      }
    }
  }

  private void buildOrgContactMethodAttributes(Vector<TCRMPartyContactMethodBObj> vecPersonContMethod)
    throws Exception
  {
	  if ((vecPersonContMethod != null) && (vecPersonContMethod.size() > 0)) {
		  Vector<CriticalData> vecCritVectorForContMethod = getCriticalDataElementsOfChildObjectOfOrganization(
				  ((TCRMPartyContactMethodBObj)vecPersonContMethod
						  .firstElement()).getTCRMContactMethodBObj());

		  for (TCRMPartyContactMethodBObj prtyContBobj : vecPersonContMethod) {
			  TCRMContactMethodBObj contMethodBobj = prtyContBobj
					  .getTCRMContactMethodBObj();

			  String contMethodUsageType = prtyContBobj
					  .getContactMethodUsageType();

			  if ((this.probabilisticSearch) && (contMethodUsageType == null))
			  {
				  contMethodUsageType = "2";
			  }

			  //start of change for AU NZ 8 Aug 2018 to exclude smart phone numbers

			  //For AUNZ phones exclude smart numbers from matching
			  if(!isAUNZPhone(contMethodUsageType) || !isSmartNumber(contMethodBobj.getReferenceNumber()) || !isJPNEmail(contMethodUsageType)){

				  //End of change for AU NZ 8 Aug 2018 to exclude smart phone numbers

				  String attrCode = PropertyManager.getOptionalProperty("Organization.PartyContactMethod.ContactMethodUsageType." + contMethodUsageType, null);

				  if (attrCode != null)
					  for (CriticalData criticalData : vecCritVectorForContMethod) {
						  String instancePK = criticalData.getInstancePK();
						  if ((instancePK == null) || (instancePK.equals(contMethodUsageType))) {
							  String fieldName = criticalData.getElementName();

							  if (StringUtils.isNonBlank(contMethodBobj
									  .getReferenceNumber()))
							  {
								  if (fieldName
										  .equalsIgnoreCase("ReferenceNumber")) {
									  Attribute orgContMethodAttr = new Attribute(
											  attrCode);
                 /* if(prtyContBobj.getContactMethodUsageType().equalsIgnoreCase("1030")
							|| prtyContBobj.getContactMethodUsageType().equalsIgnoreCase("1031") || prtyContBobj.getContactMethodUsageType().equalsIgnoreCase("1032"))
                	  		orgContMethodAttr.setField("email", contMethodBobj
									.getReferenceNumber());
                  
                  
                  
						else*/
								
							
							orgContMethodAttr.setField("refnum", contMethodBobj
				                    .getReferenceNumber());
						
									  boolean isOrgContMethActive = checkIfActiveObject(prtyContBobj.getEObjLocationGroup().getEndDt(), prtyContBobj.getControl());
									  orgContMethodAttr.setActive(isOrgContMethActive);

									  this.organizationRecord.addAttribute(orgContMethodAttr);
								  }
							  }
						  }
					  }
			  }
		  }
	  }
  }

  private Attribute buildAttribute(String attrCode, String elementName, Object elementValue)
  {
    Attribute personAttrs = new Attribute(attrCode);
    personAttrs.setField(elementName, elementValue);
    return personAttrs;
  }

  public Record convert(DWLCommon rootBObj)
    throws Exception
  {
	  
	XOrgBObjExt xOrgBOBjExt = new XOrgBObjExt();
	TCRMPartyComponent partyComponent = new TCRMPartyComponent();
	  
    if ((rootBObj instanceof ProbabilisticOrganizationSearchBObj)) {
      this.probabilisticSearch = true;
      RecordId newRecordId = new RecordId("MDMSO", "");
      this.organizationRecord = new Record("ORG", newRecordId);

      String xmarketNameForSearch=rootBObj.getControl().getGeographicalRegion();
      //FS change order for identification
      buildOrgIdentificationAttributes(((ProbabilisticOrganizationSearchBObj)rootBObj)
    	        .getItemsTCRMPartyIdentificationBObj());
      
      buildOrgNameAttributes(((ProbabilisticOrganizationSearchBObj)rootBObj)
        .getItemsTCRMOrganizationNameBObj(),xmarketNameForSearch);

      /*buildOrgIdentificationAttributes(((ProbabilisticOrganizationSearchBObj)rootBObj)
        .getItemsTCRMPartyIdentificationBObj());*/

      buildOrgAddressAttributes(((ProbabilisticOrganizationSearchBObj)rootBObj)
        .getItemsTCRMPartyAddressBObj(),xmarketNameForSearch);

      buildOrgContactMethodAttributes(((ProbabilisticOrganizationSearchBObj)rootBObj)
        .getItemsTCRMPartyContactMethodBObj());
    }
    else
    {
      TCRMOrganizationBObj orgObj = (TCRMOrganizationBObj)rootBObj;

    //Changes for PME
	    DWLControl control = orgObj.getControl();
		String partyId = null;
		String marketName = null;
		String marketNameSync = null;
		partyId = orgObj.getPartyId();
		String txnType = (control.get("txnCategory")).toString();
		String requestName = (control.get("request_name")).toString();				
		xOrgBOBjExt = (XOrgBObjExt)partyComponent.getOrganization(partyId, "0", control);
								
		if(txnType!=null && txnType.equalsIgnoreCase("update")){
		marketName = (control.get("marketName")).toString();
		}
		
		if (txnType != null && (txnType.equalsIgnoreCase("delete"))) {
			RecordId newRecordId = new RecordId("MDMSO", orgObj.getPartyId());
			organizationRecord = new Record(ORG_REC_TYPE, newRecordId);
			return organizationRecord;
		} 
		
		//if(requestName!=null && requestName.equalsIgnoreCase("synchronizeeME")){
			marketNameSync = xOrgBOBjExt.getXMarketName();
		//}

      RecordId newRecordId = new RecordId("MDMSO", orgObj.getPartyId());

      this.organizationRecord = new Record("ORG", newRecordId);
      
      //August 09, 2018 : Added by Diparnab for removal of magic number from Comparison String for Turkey Market : Start
      
      //Restrict Magic Number from being populated in the comparison string for Turkey market
      if(isMarketTurkey(txnType, requestName, marketName, marketNameSync, xOrgBOBjExt))
      {
    	  Vector<TCRMPartyIdentificationBObj> magicNumberVec = new Vector<TCRMPartyIdentificationBObj>();
    	  
    	  if(null!= orgObj.getItemsTCRMPartyIdentificationBObj() && orgObj.getItemsTCRMPartyIdentificationBObj().size()>0)
    	  {
    		  Vector<TCRMPartyIdentificationBObj> identificationBObjVec = orgObj.getItemsTCRMPartyIdentificationBObj();
    		  
    		  for(TCRMPartyIdentificationBObj identificationBObj : identificationBObjVec)
    		  {
    			  if(ExternalRuleConstant.ID_TYPE_MAGIC.equalsIgnoreCase(identificationBObj.getIdentificationType()))
					{
    				  magicNumberVec.add(identificationBObj);
					}
    		  }
    		  
				//November 16, 2018 : Added by Diparnab for fixing Magic Number removal from comparison string : Start
				/**
				 * Restrict all magic numbers from being populated in the comparison string
				 */
				if(null!= magicNumberVec && magicNumberVec.size()>0)
				{
					for(TCRMPartyIdentificationBObj dbMagicNumberBobj : magicNumberVec)
					{
						if(null!= dbMagicNumberBobj)
						{
							identificationBObjVec.remove(dbMagicNumberBobj);
						}							
					}
				}	
				
			  //November 16, 2018 : Added by Diparnab for fixing Magic Number removal from comparison string : End
    	  }
      }
      
      //August 09, 2018 : Added by Diparnab for removal of magic number from Comparison String for Turkey Market : End
      

      buildOrgIdentificationAttributes(orgObj.getItemsTCRMPartyIdentificationBObj());
      
      buildOrgNameAttributes(orgObj.getItemsTCRMOrganizationNameBObj(),marketNameSync);
      
      //July 22, 2018 : Modified by Diparnab for restricting address from being populated in Comparison string for Organization Update : Start
      
      //For Data Synchronization job
      if(StringUtils.isNonBlank(requestName) && "synchronizeeME".equalsIgnoreCase(requestName))
      {
    	  if(!"IND".equalsIgnoreCase(marketNameSync) && !"TUR".equalsIgnoreCase(marketNameSync)){
    	      buildOrgAddressAttributes(orgObj.getItemsTCRMPartyAddressBObj(),marketNameSync);
    	      }
      }
      //For Update Flow
      else if(StringUtils.isNonBlank(txnType) && "update".equalsIgnoreCase(txnType))
      {
    	  if(!"IND".equalsIgnoreCase(marketName) && !"TUR".equalsIgnoreCase(marketName)){
    	      buildOrgAddressAttributes(orgObj.getItemsTCRMPartyAddressBObj(),marketNameSync);
    	      }
      }
      //For Create Flow
      else
      {
    	  if(!"IND".equalsIgnoreCase(xOrgBOBjExt.getXMarketName()) && !"TUR".equalsIgnoreCase(xOrgBOBjExt.getXMarketName())){
    	      buildOrgAddressAttributes(orgObj.getItemsTCRMPartyAddressBObj(),marketNameSync);
    	      }
      }    
      
      //July 22, 2018 : Modified by Diparnab for restricting address from being populated in Comparison string for Organization Update : End
      
      /*buildOrgIdentificationAttributes(orgObj
        .getItemsTCRMPartyIdentificationBObj());*/

      buildOrgContactMethodAttributes(orgObj
        .getItemsTCRMPartyContactMethodBObj());

      Vector<CriticalData> vecCritVectorForOrg = getCriticalDataElementsForGroup(orgObj);

      for (CriticalData criticalData : vecCritVectorForOrg) {
        String fieldName = criticalData.getElementName();

        /*if (StringUtils.isNonBlank(orgObj.getEstablishedDate()))
        {
          if (fieldName
            .equalsIgnoreCase("EstablishedDate")) {
        	String marketNameEstablishedDate = ((XOrgBObjExt)rootBObj).getXMarketName();
        	if(marketNameEstablishedDate!=null && marketNameEstablishedDate.equalsIgnoreCase("JPN")){
        		
            this.organizationRecord.addAttribute(buildAttribute("ORGESTABDATE", "val", 
              DateFormatter.getDate(orgObj.getEstablishedDate()))); 
            
            
        	}
          }

        }*/ if (StringUtils.isNonBlank(xOrgBOBjExt.getXMarketName()))
        {
            if (fieldName
              .equalsIgnoreCase(MARKET_MDM_ATTRIBUTE_NAME)) {
              this.organizationRecord.addAttribute(buildAttribute("ORGMARKET", "market", 
            		  xOrgBOBjExt.getXMarketName()));
            }
		//Changed for marketName CMPVAL (25 May 2018)
          }
        else if (txnType!=null && txnType.equalsIgnoreCase("update")
				&& fieldName
				.equalsIgnoreCase(MARKET_MDM_ATTRIBUTE_NAME)) {
        	this.organizationRecord 
			.addAttribute(buildAttribute("ORGMARKET", "market",
					marketName));
		//Changed for marketName CMPVAL (25 May 2018)
		}
		else if (requestName!=null && requestName.equalsIgnoreCase("synchronizeeME")
				&& fieldName
				.equalsIgnoreCase(MARKET_MDM_ATTRIBUTE_NAME)) {
			this.organizationRecord.addAttribute(buildAttribute("ORGMARKET", "market",
					marketNameSync));

		}
		
		//Changes end for PME

      }

    }

    if ((this.probabilisticSearch) && (this.organizationRecord.getAttributes().isEmpty()))
    {
      DWLStatus status = new DWLStatus();
      this.errHandler = TCRMClassFactory.getErrorHandler();

      TCRMExceptionUtils.throwTCRMException(null, 
        new TCRMDataInvalidException(), status, 
        9L, 
        "4433", 
        "DIERR", 
        "792", 
        rootBObj.getControl(), this.errHandler);
    }

    return this.organizationRecord;
  }

  private Vector<CriticalData> getCriticalDataElementsOfChildObjectOfOrganization(DWLCommon bObj) throws Exception
  {
    Vector<CriticalData> vecCritDataElemOfIncomingBObj = getCriticalDataElementsForGroup(bObj);
    Vector vecCritDataElemOfIncomingBObjForOrg = new Vector();
    for (CriticalData criticalData : vecCritDataElemOfIncomingBObj) {
      if (criticalData.getUltimateParentGroupName().equals(ORG_GROUP_NAME)) {
        vecCritDataElemOfIncomingBObjForOrg.add(criticalData);
      }
    }
    return vecCritDataElemOfIncomingBObjForOrg;
  }
  
  
  
  // Start Changes to exclude All Email for Japan by Shashi (17-06-2021)
  
private Boolean isJPNEmail(String contactMethodUsageType){
	  
	  Boolean result = false;
	  
	  if(ExternalRuleConstant.CONTACT_METHOD_USAGE_TYPE_PRIVATE_EMAIL_JPN.equalsIgnoreCase(contactMethodUsageType)
		  ||ExternalRuleConstant.CONTACT_METHOD_USAGE_TYPE_WORK_EMAIL_JPN.equalsIgnoreCase(contactMethodUsageType)
		  ||ExternalRuleConstant.CONTACT_METHOD_USAGE_TYPE_OTHER_EMAIL_JAPAN.equalsIgnoreCase(contactMethodUsageType)
		  ||ExternalRuleConstant.CONTACT_METHOD_USAGE_TYPE_EMAIL3_JPN.equalsIgnoreCase(contactMethodUsageType)){
		  result = true;
	  }
	  return result;
  }
  
  
  //End
  
  
  
  
  
  
  /**
   * returns true if usage type is for AU NZ
   * @author shrdatta
   * @param contactMethodUsageType
   * @return
   */
  private Boolean isAUNZPhone(String contactMethodUsageType){
	  
	  Boolean result = false;
	  
	  if(ExternalRuleConstant.CONTACT_METHOD_USAGE_TYPE_HOME_PHONE_AUS.equalsIgnoreCase(contactMethodUsageType)
		  ||ExternalRuleConstant.CONTACT_METHOD_USAGE_TYPE_WORK_PHONE_AUS.equalsIgnoreCase(contactMethodUsageType)
		  ||ExternalRuleConstant.CONTACT_METHOD_USAGE_TYPE_MOBILE_AUS.equalsIgnoreCase(contactMethodUsageType)
		  ||ExternalRuleConstant.CONTACT_METHOD_USAGE_TYPE_FAX_AUS.equalsIgnoreCase(contactMethodUsageType)
		  ||ExternalRuleConstant.CONTACT_METHOD_USAGE_TYPE_SMS_AUS.equalsIgnoreCase(contactMethodUsageType)){
		  result = true;
	  }
	  return result;
  }
  
  /**
   * Returns true for Australian Smart Numbers
   * @author shrdatta
   * @param referenceNumber
   * @return
   */
  private Boolean isSmartNumber(String referenceNumber){
	  
	  Boolean result = false;
	  
	  //numbers starting with 1800 or 1300 with total number of digits 10 and starting with 13 with total number of digits 6 are smart numbers
	  
	  if(StringUtils.isNonBlank(referenceNumber)){
		  
		  //starts with 1800 and 10 digit
		  if(referenceNumber.startsWith(ExternalRuleConstant.SMART_NUMBER_AUS_PREFIX_1800) && referenceNumber.length() == 10){
			  result = true;
		  }
		  //starts with 1300 and 10 digit
		  else if(referenceNumber.startsWith(ExternalRuleConstant.SMART_NUMBER_AUS_PREFIX_1300) && referenceNumber.length() == 10){
			  result = true;
		  }
		  //starts with 13 and 6 digit
		  else if(referenceNumber.startsWith(ExternalRuleConstant.SMART_NUMBER_AUS_PREFIX_13) && referenceNumber.length() == 6){
			  result = true;
		  }  
	  }
	  
	  return result;
  }
  
	//August 09, 2018 : Added by Diparnab for Magic Number removal as a Match Attribute for Turkey Market : Start
	/**
	 * Method to check whether the request record is for Turkey Market
	 * @param txnType
	 * @param requestName
	 * @param marketName
	 * @param marketNameSync
	 * @param personObj
	 * @return
	 */
	private boolean isMarketTurkey(String txnType, String requestName, String marketName, String marketNameSync, XOrgBObjExt xOrgBobj) 
	{
		boolean isMarketTurkey = false;
		//For Derived data synchronization job
		if(StringUtils.isNonBlank(requestName) && "synchronizeeME".equalsIgnoreCase(requestName) && "TUR".equalsIgnoreCase(marketNameSync))
		{
			isMarketTurkey =  true;
		}
		//For Customer Update Flow
		else if (StringUtils.isNonBlank(txnType) && "update".equalsIgnoreCase(txnType) && "TUR".equalsIgnoreCase(marketName))
		{
			isMarketTurkey =  true;
		}
		//For Customer Add Flow
		else if ("TUR".equalsIgnoreCase(xOrgBobj.getXMarketName()))
		{
			isMarketTurkey = true;
		}
		return isMarketTurkey;		
	}
	//August 09, 2018 : Added by Diparnab for Magic Number removal as a Match Attribute for Turkey Market : End
}