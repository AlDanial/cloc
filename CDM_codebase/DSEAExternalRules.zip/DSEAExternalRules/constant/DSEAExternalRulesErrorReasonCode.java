/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[505df2d71136231ed9da97c0b170395e]
 */
package com.ibm.daimler.dsea.extrules.constant;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * Defines the error message codes used in this module.
 *
 * @generated
 */
public class DSEAExternalRulesErrorReasonCode {

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * 
     *
     * @generated
     */
    public final static String ADD_PARTY_UCID_INSERT_FAILED = "3300031";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * 
     *
     * @generated
     */
    public final static String GET_PARTY_RETRIEVE_FAILED = "3300103";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * 
     *
     * @generated
     */
    public final static String COLLAPSE_MULTIPLE_PARTIES_FAILED = "3300107";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * 
     *
     * @generated
     */
    public final static String CREATE_SUSPECTS_FAILED = "3300123";

    
    public final static String MAINTAINCONTRACTFSJPN_CONTRACTOR_GUARANTOR_SAME = "3300124";
}


