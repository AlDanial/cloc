package com.ibm.daimler.dsea.extrules.constant;


import java.util.Arrays;
import java.util.List;

public interface ExternalRuleConstant {
	
	//UCID Identifier related
	//public final static String UCID_SEQUENCE = "SELECT NEXTVAL FOR MDM_UCID_SEQ AS UCID_SEQ FROM SYSIBM.SYSDUMMY1";
	//public final static String UCID_DSEAMSA_PREFIX = "MAS";
	//public static Random randomNo = new Random(); 
	
	public static final String UCID_TYPE = "1001";
	public static final String UCID_TEXT = "UCID";
	
	
	public static final String COLLAPSEMULTIPLEPARTIES = "collapseMultipleParties";
	public static final String COLLAPSEPARTIESWITHRULES = "collapsePartiesWithRules";
	public static final String COLLAPSEMULTIPLEACTIVEPARTIES = "collapseMultipleActiveParties";
	public static final String ASYNCREIDENTIFYSUSPECTS = "asyncReidentifySuspects";
	public static final String UNDOCOLLAPSEMULTIPLEPARTIES = "undoCollapseMultipleParties";
	public static final String CREATESUSPECTS = "createSuspects";
	
	public static final String INQUIRY_LVL_4 = "4";
	public static final String INQUIRY_LVL_2 = "2";
	
	public static final String INQUIRY_LVL_0 = "0";
	public static final String INQUIRY_LVL_1 = "1";
	
	public static final String LOG_ENTRY_OF_METHOD = "ENTER ";
	public static final String LOG_EXIT_OF_METHOD = "RETURN ";
	
	public final static String QUERY_SELECT_VALUE = "SELECT NVL(VALUE,VALUE_DEFAULT) FROM CONFIGELEMENT WHERE NAME = ?  WITH UR";
	public final static String QUERY_SELECT_SEQUENCE = "SELECT NEXT VALUE FOR MDM_UCID_SEQ AS UCID_SEQNO FROM SYSIBM.SYSDUMMY1 WITH UR";
	final static String UCID_DEPLOYMENT_PREFIX_KEY = "/DSEA/Composites/UCID/DeploymentPrefix";
	final static String UCID_SECRET_STRING_PREFIX_KEY = "/DSEA/Composites/UCID/SecretString";

	public final static String HASH_ALGORITHM = "SHA-256";
	public final static String ENCODING = "UTF-8";
	
	//--------------Start Survivorship rule-----------------//
	
	public static final String GET_RETAILER_IDPK = "SELECT RETAILERPK_ID FROM XRETAILER WHERE RETAILER_CODE = ? WITH UR";
	public static final String RETAILER_ID = "RETAILERPK_ID";
	
	public static final String GET_CUSTOMERVEHICLE_IDPK = "SELECT CUSTOMERVEHICLEPK_ID FROM XCUSTOMERVEHICLE WHERE CONT_ID = ? WITH UR";
	public static final String CUSTOMERVEHICLE_ID = "CUSTOMERVEHICLEPK_ID";
	public static final String GET_CUSTOMERVEHICLEKOR_IDPK = "SELECT XCUSTOMER_VEHICLE_KORPK_ID FROM XCUSTOMERVEHICLEKOR WHERE CONT_ID = ? WITH UR";
	public static final String CUSTOMERVEHICLEKOR_ID = "XCUSTOMER_VEHICLE_KORPK_ID";
	public static final String GET_VEHICLE_IDPK = "SELECT VEHICLEPK_ID FROM XVEHICLE WHERE GLOBAL_VIN = ? WITH UR";
	public static final String VEHICLE_ID = "VEHICLEPK_ID";
	public static final String GET_VEHICLE_IDPK_KOR = "SELECT XVEHICLE_KORPK_ID FROM XVEHICLEKOR WHERE GLOBAL_VIN = ? WITH UR";
	public static final String VEHICLE_ID_KOR = "XVEHICLE_KORPK_ID";
	
	public static final String SALES_ROLE_TYPE = "1001";
	public static final String AFTERSALES_ROLE_TYPE = "1002";
	public static final String DRIVER_ROLE_TYPE = "1003";
	public static final String PERSON_TYPE = "P";
	public static final String ORG_TYPE = "O";
	
	public static final String SURVIVED_MAP_NAME = "SurvivedName";
	public static final String SURVIVED_MAP_ADDRESS = "SurvivedAddress";
	public static final String SURVIVED_MAP_IDENTIFIER = "SurvivedIdentifier";
	public static final String SURVIVED_MAP_CONTACTMETHOD = "SurvivedContactMethod";
	public static final String SURVIVED_MAP_CONTEQUIV = "SurvivedContequiv";
	public static final String ID_TYPE_UCID = "1001";
	public static final String ID_TYPE_LINE = "1042";
	public static final String ID_TYPE_MAGIC = "1002";
	public static final String ID_TYPE_EDEALER = "1018";
	public static final String ID_TYPE_TDSID = "1026";
	public static final String ID_TYPE_STOUCHID = "1028";
	public static final String ADDRESS_RETAILER_FLAG_Y = "Y";
	public static final String ADDRESS_RETAILER_FLAG_N = "N";
	public static final String MARKET_NAME_MALAYSIA = "MYS";
	public static final String MARKET_NAME_THAILAND = "THA";
	public static final String MARKET_NAME_INDIA = "IND";
	public static final String BATCH_IND_Y = "Y";
	public static final String BATCH_IND_N = "N";
	public static final String SOURCE_IDENTIFIER_TYPE_SFDC = "1001";
	public static final String SOURCE_IDENTIFIER_TYPE_AUTOLINE = "1002";
	public static final String SOURCE_IDENTIFIER_TYPE_EDEALER = "1004";
	public static final String SOURCE_IDENTIFIER_TYPE_MSALES = "1005";
	public static final String SOURCE_IDENTIFIER_TYPE_STOUCH = "1006";
	public static final String ADDRESS_USAGE_TYPE_P = "1005";
	public static final String ADDRESS_USAGE_VALUE_P = "P";
	public static final String ADDRESS_USAGE_TYPE_C = "1006";
	public static final String ADDRESS_USAGE_VALUE_C = "C";
	public static final String ADDRESS_USAGE_TYPE_HOME_ADDRESS = "1001";
	public static final String ADDRESS_USAGE_VALUE_HOME_ADDRESS = "Home";
	public static final String ADDRESS_USAGE_TYPE_BUSINESS_ADDRESS = "3";
	public static final String ADDRESS_USAGE_VALUE_BUSINESS_ADDRESS = "Business";
	public static final String ADDRESS_USAGE_TYPE_OTHER_ADDRESS_1 = "1002";
	public static final String ADDRESS_USAGE_VALUE_OTHER_ADDRESS_1 = "Others1";
	public static final String ADDRESS_USAGE_TYPE_OTHER_ADDRESS_2 = "1003";
	public static final String ADDRESS_USAGE_VALUE_OTHER_ADDRESS_2 = "Others2";
	public static final String ADDRESS_USAGE_TYPE_OTHER_ADDRESS_3 = "1004";
	public static final String ADDRESS_USAGE_VALUE_OTHER_ADDRESS_3 = "Others3";
	public static final String PERSON_ORG_CODE_P = "P";
	public static final String PERSON_ORG_CODE_O = "O";
	public static final String SOURCE_IDENTIFIER_TYPE_CMS = "1003";
	
	//Pref Ind Change 05-12-2017
	public final static String CHARACTER_Y = "Y";
	public final static String CHARACTER_N = "N";
		
	//--------------End Survivorship rule-------------------//
	

	public static final String SEARCHSUSPECT_WITHTASKMANAGEMENT = "searchSuspectDSEAPartiesWithTaskManagement";
	public static final String SEARCHSUSPECT_WITHOUTTASKMANAGEMENT = "searchSuspectDSEAPartiesWithoutTaskManagement";
	
	
	//C2C survivorship	
	public static final String ID_TYPE_PERSON_EPUCID = "1012";
	public static final String ID_TYPE_ORG_EPUCID = "1013";
	
	public static final String RELATIONSHIP_ASSIGN_TYPE_PRIMARY = "1000";
	public static final String RELATIONSHIP_ASSIGN_TYPE_ACTIVE = "1001";
	public static final String RELATIONSHIP_ASSIGN_TYPE_INACTIVE = "1002";
	
	public static final String RELATIONSHIP_ASSIGN_VALUE_PRIMARY = "PRIMARY";
	public static final String RELATIONSHIP_ASSIGN_VALUE_ACTIVE = "ACTIVE";
	public static final String RELATIONSHIP_ASSIGN_VALUE_INACTIVE = "INACTIVE";
	
	//----------------------Start Loveleen FS changes------------------------------------//
	
	public static final String FS_WHOLESALE = "FSWS";
	public static final String FS_VALUE = "FS";
	public static final String ID_TYPE_BPID = "1009";
	public static final String GET_CONTRACT_REL = "SELECT * FROM XCONTRACTREL WHERE CONTRACT_ID = ? AND CONT_ID = ? WITH UR";
	public static final String GET_CONTRACT_REL_BY_PARTYID = "SELECT * FROM XCONTRACTREL WHERE CONT_ID = ? WITH UR";
	public static final String CONTRACT_REL_ID = "XCONTRACT_RELPK_ID";
	
	public static final String LAST_UPDATE_DT = "LAST_UPDATE_DT";
		
	//----------------------End Loveleen FS changes------------------------------------//
//----------------------Start Sameeha Dealer Level Changes------------------------//
	
  	public static final String GET_ALL_DEALER_RETAILER_RELS = "SELECT * FROM XDEALERRETAILER WITH UR";

  	public static final String DEALER_CODE = "DEALER_CODE";
  	
  	public static final String RETAILER_CODE = "RETAILER_CODE";


	
	//----------------------End Sameeha Dealer Level Changes------------------------//

	//----------------------Start Arup Australia changes------------------------------------//
	
	public static final String MARKET_NAME_AUSTRALIA = "AU";
	public static final String MARKET_NAME_NEWZEALAND="NZ";
	public static final String ID_TYPE_CUSTID = "1019";
	public static final String ID_TYPE_SALESCARDID = "1041";
	public static final String CONTACT_METHOD_USAGE_TYPE_HOME_PHONE_AUS = "1014";
	public static final String CONTACT_METHOD_USAGE_TYPE_WORK_PHONE_AUS = "1015";
	public static final String CONTACT_METHOD_USAGE_TYPE_MOBILE_AUS = "1016";
	public static final String CONTACT_METHOD_USAGE_TYPE_FAX_AUS = "1017";
	public static final String CONTACT_METHOD_USAGE_TYPE_EMAIL_AUS = "1018";
	public static final String CONTACT_METHOD_USAGE_TYPE_SMS_AUS = "1019";
	
	public static final String CLIENT_STATUS_CUSTOMER = "1001";
	public static final String CLIENT_STATUS_VALUE_CUSTOMER = "Customer";
	public static final String CLIENT_STATUS_PROSPECT = "1002";
	public static final String CLIENT_STATUS_VALUE_PROSPECT = "Prospect";
	public static final String GET_VEHICLE_AUS_ID_PK = "SELECT XVEHICLE_AUSPK_ID FROM XVEHICLEAUS WHERE GLOBAL_VIN = ? WITH UR";
	public static final String GET_CUSTOMERVEHICLEAUS_ID_PK = "SELECT XCUSTOMER_VEHICLE_AUSPK_ID FROM XCUSTOMERVEHICLEAUS WHERE CONT_ID = ? WITH UR";
	public static final String XCUSTOMER_VEHICLE_AUSPK_ID = "XCUSTOMER_VEHICLE_AUSPK_ID";
	public static final String VEHICLE_AUS_ID = "XVEHICLE_AUSPK_ID";
	
	public static final String CUSTOMER_DEFUNCTIND_Y = "Y";
	
	public static final String SEARCH_PERSON_DIG_APPS = "SEARCH_PERSON_DIG_APPS";
	
	
	public static final String MASTER_COPY = "M";
	public static final String SLAVE_COPY = "S";
	
	//----------------------End Arup Australia changes------------------------------------//
	
	//May 28, 2018 : Added by Diparnab for Turkey survivorship Rule Changes : Start 
	
	public static final String MARKET_NAME_TURKEY = "TUR";
	public static final String SOURCE_PRIORITY_1 = "1";
	public static final String SOURCE_PRIORITY_2 = "2";
	public static final String SOURCE_IDENTIFIER_TYPE_CUSTOMER_PORTAL = "1011";
	public static final String SOURCE_IDENTIFIER_TYPE_COMPASS = "1013";
	public static final String SOURCE_IDENTIFIER_TYPE_TDS = "1007";
	public static final String SOURCE_IDENTIFIER_TYPE_AKASYA = "1010";
	public static final String SOURCE_IDENTIFIER_TYPE_CPD = "1014";
	public static final String SOURCE_IDENTIFIER_TYPE_ONEWEB = "1015";
	public static final String ID_TYPE_SOCAIL_ID = "1006";
	public static final String ID_TYPE_VAT_NO = "1022";
	public static final String CONT_METH_CAT_EMAIL = "2";
	public static final String CONT_METH_CAT_PHONE = "1";
	public static final String CONSENT_RETAILER_FLAG_N = "N";
	public static final String CONSENT_RETAILER_FLAG_Y = "Y";
		
	//May 28, 2018 : Added by Diparnab for Turkey survivorship Rule Changes : End
	
	//------------- Changes start for Japan ----------------//
	
	public static final String JAPAN_MARKET_NAME = "JPN";
	public static final String MYMERC_SOURCETYPE="1021";
	public static final String DSC_SOURCE_TYPE="1020";
	public static final String MAGIC_NUMBER_SYS_TYPE="1002";
	public static final String MASTER_KEY="M";
	public static final String SLAVE_KEY="S";
	public static final String PREFERRED_TYPE_N="1002";
	public static final String PREFERRED_VALUE_N="N";
	public static final String PREFERRED_TYPE_Y="1001";
	public static final String PREFERRED_VALUE_Y="Y";
	public static final String DATASHARING_FLAG_Y="Y";
	public static final String DATASHARING_RETAILER_FLAG_Y="Y";
	public static final String DATASHARING_RETAILER_FLAG_N="N";
	public static final String UCID_SOURCE_TYPE="1026";
	public static final String UCID_SOURCE_VALUE="UCID";
	
	public static final List<String> HOME_ADDRESSES = Arrays
			.asList(new String[] { "1014", "1015", "1025"});
	
	public static final List<String> WORK_ADDRESSES = Arrays
			.asList(new String[] { "1016", "1017", "1027"});
	
	public static final List<String> OTHER1_ADDRESSES = Arrays
			.asList(new String[] { "1018", "1019", "1029"});
	
	public static final List<String> OTHER2_ADDRESSES = Arrays
			.asList(new String[] { "1020", "1021", "1031"});
	
	public static final List<String> OTHER3_ADDRESSES = Arrays
			.asList(new String[] { "1022", "1023", "1033"});
	
	public static final String ADDRESS_USAGE_TYPE_HOME_KANA_ADDRESS = "1014";
	public static final String ADDRESS_USAGE_TYPE_BUSINESS_KANA_ADDRESS = "1016";
	public static final String ADDRESS_USAGE_TYPE_OTHER_KANA_ADDRESS_1 = "1018";
	public static final String ADDRESS_USAGE_TYPE_OTHER_KANA_ADDRESS_2 = "1020";
	public static final String ADDRESS_USAGE_TYPE_OTHER_KANA_ADDRESS_3 = "1022";
	public static final String ADDRESS_USAGE_TYPE_HOME_KANJI_ADDRESS = "1015";
	public static final String ADDRESS_USAGE_TYPE_BUSINESS_KANJI_ADDRESS = "1017";
	public static final String ADDRESS_USAGE_TYPE_OTHER_KANJI_ADDRESS_1 = "1019";
	public static final String ADDRESS_USAGE_TYPE_OTHER_KANJI_ADDRESS_2 = "1021";
	public static final String ADDRESS_USAGE_TYPE_OTHER_KANJI_ADDRESS_3 = "1023";
	
	// Added for Create Suspect
	public static final String SUSPECT_CATEGORY_TYPEA1 = "1";
	public static final String SUSPECT_CATEGORY_VALUEA1 = "A1";
	public static final String SUSPECT_CATEGORY_TYPEB = "3";
	public static final String SUSPECT_CATEGORY_VALUEB = "B";
	public static final String SUSPECT_CATEGORY_VALUEC = "C";
	
	public static final String SUSP_REASON_CODE_GLOBALVIN_TYPE = "100001";	
	public static final String SUSP_REASON_CODE_WORKADDRESS_TYPE = "100002";
	public static final String SUSP_REASON_CODE_WORKPHONE_TYPE = "100003";
	public static final String SUSP_REASON_CODE_VEHICLEADDRESS_TYPE = "100004";
	public static final String SUSP_REASON_CODE_MYMID_TYPE = "100005";
	public static final String SUSP_REASON_CODE_DATASHARINGFLAG_TYPE = "100006";
	public static final String SUSP_REASON_CODE_PREFADDRINDICATOR_TYPE = "100007";
	public static final String SUSP_REASON_CODE_ANONNAME_VALUES = "100008";
	//Added by Sameeha for Multiple MMID merge issue | 12-Feb- 2020: Start
	public static final String SUSP_REASON_CODE_MULTIPLE_MYMID_TYPE = "100009";
	//Added by Sameeha for Multiple MMID merge issue | 12-Feb- 2020: End
	
	public static final String WORK_PHONE_TYPE_JPN = "1025";
	
	public static final String SOURCE_NAME_MYMERCEDES = "1021";
	public static final String DATASHARING_FLAG_N = "N";
	
	public static final String CONTACTMETHOD_CATEGORY_PHONE = "1";
	
	public static final String CONTRACT_RELJPN_ID = "XCONTRACT_RELJPNPK_ID";
	
	public static final String GET_CONTRACT_RELJPN_BY_PARTYID = "SELECT * FROM XCONTRACTRELJPN WHERE CONT_ID = ? AND (END_DT IS NULL OR END_DT > CURRENT_TIMESTAMP) WITH UR";
	public static final String GET_CONTRACT_RELJPN = "SELECT * FROM XCONTRACTRELJPN WHERE CONTRACT_ID = ? AND CONT_ID = ? AND (END_DT IS NULL OR END_DT > CURRENT_TIMESTAMP) WITH UR";
	public static final String GET_RETAILER_IDPK_BY_NDCODE = "SELECT RETAILERPK_ID FROM XRETAILER WHERE ND_CODE = ? WITH UR";
	
	
	public static final String GUARANTOR_ROLE = "GUARANTOR";
	public static final String CONTRACTOR_ROLE = "CONTRACTOR";
	
	public static final String VEHICLE_SALES_TYPE_NEW ="1011";
	public static final String VEHICLE_SALES_TYPE_USED ="1012";
	public static final String VEHICLE_SALES_TYPE_UNKNOWN ="1013";
			
	//------------- Changes end for Japan ----------------//
	
	//July 5, 2018 : Added by Shandeep for Turkey survivorship Rule Changes : Start
	public static final String ID_TYPE_AKASYA = "1025";
	
	public static final String ID_TYPE_TDS = "1026";
	
	public static final String ID_TYPE_ONEWEB = "1027";
	
	//July 5, 2018 : Added by Shandeep for Turkey survivorship Rule Changes : End
	
	//July 27, 2018 : Added by Shandeep for Turkey survivorship Rule Changes : Start
	
	public static final String SOURCE_IDENTIFIER_TYPE_LEADMANAGEMENT_SOCIAL_MEDIA = "1018";
	
	public static final String SOURCE_IDENTIFIER_TYPE_LEADMANAGEMENT_INSURANCE = "1024";
	
	//July 27, 2018 : Added by Shandeep for Turkey survivorship Rule Changes : End
	
	//start of change for AU NZ 8 Aug 2018 to exclude smart phone numbers
	public static final String SMART_NUMBER_AUS_PREFIX_1800 = "1800";
	public static final String SMART_NUMBER_AUS_PREFIX_1300 = "1300";
	public static final String SMART_NUMBER_AUS_PREFIX_13 = "13";
	//end of change for AU NZ 8 Aug 2018 to exclude smart phone numbers
	
	//July 28, 2018 : Added by Abhijit for India survivorship Rule Changes : Start
	
	public static final String PERSON_LAST_NAME = "Customer";
		
	//July 28, 2018 : Added by Abhijit for India survivorship Rule Changes : End
		

	
	//Added for household merge CR 25 Sep 2018
	
	public static final String MATCH_CAT_CODE_A1 = "A1";
	public static final String MATCH_CAT_CODE_B = "B";
	public static final String MATCH_CAT_ADJUSTMENT_TYPE_FNAME = "8";
	public static final String MATCH_CAT_ADJUSTMENT_VALUE_FNAME = "Down - Different firstname";
	public static final String MATCH_CAT_ADJUSTMENT_TYPE_GENDER = "7";
	public static final String MATCH_CAT_ADJUSTMENT_VALUE_GENDER = "Down - Different gender";
	//Added for household merge CR 25 Sep 2018
		
	// added for THA Compass - 12 Oct 2018
	public static final String ID_TYPE_COMPASS_CUSTOMER_ID = "1023";
	// added for THA Compass - 12 Oct 2018
	
			//-------------Changes Start for Korea-------------------//

	public static final String KOREA_MARKET_NAME = "KOR";
	public static final String ADMIN_SYS_TP_UCID = "1026";
	public static final String ADMIN_SYS_VALUE_UCID = "UCID";
	public static final String ADMIN_SYS_TP_STOUCH = "1006";
	public static final String ADMIN_SYS_VALUE_STOUCH = "SalesTouch";
	public static final String ADMIN_SYS_VALUE_SFDC = "SFDC";
	public static final String ADMIN_SYS_TYPE_SFDC = "1001";
	public static final String SOURCE_IDENTIFIER_TYPE_LOYALTYAPPS = "1028";
	public static final String SOURCE_PRIORITY_3 = "3";
	public static final String SOURCE_PRIORITY_4 = "4";
	public static final String COMPONENT_TYPE_NAME = "NAME";
	public static final String COMPONENT_TYPE_ADDRESS = "ADDRESS";
	public static final String COMPONENT_TYPE_CONTACT_METHOD = "CONTACTMETHOD";
	public static final String COMPONENT_TYPE_IDENTIFIER = "IDENTIFIER";
	public static final String COMPONENT_TYPE_GENDER = "GENDER";
	public static final String COMPONENT_TYPE_OCCUPATION = "OCCUPATION";
	public static final String COMPONENT_TYPE_DOB = "DOB";
	public static final String COMPONENT_TYPE_ESTABLISHED_DT_KOR = "ESTABLISHED_DT";
	public static final String ID_TYPE_VAT_NO_KOR = "1033";
	public static final String ID_TYPE_COM_REG_ID_KOR = "1032" ;
	public static final String ACTIVE_FLAG_Y = "Y" ;
	public static final String ACTIVE_FLAG_N = "N" ;
	
	
	public static final String SUSP_REASON_CODE_PHONE_VIN_TYPE = "20001";
	public static final String SUSP_REASON_CODE_NAME_VAT_CRN_TYPE = "20002";
	public static final String SUSP_REASON_CODE_NAME_CRN_PHONE_TYPE = "20005";
	public static final String SUSP_REASON_CODE_NAME_VAT_TYPE = "20004";
	public static final String SUSP_REASON_CODE_NAME_VAT_PHONE_TYPE = "20003";
	public static final String SUSP_REASON_CODE_NAME_VAT_CRN_PHONE_TYPE = "20007";
	public static final String SUSP_REASON_CODE_NAME_2 = "20006";
	public static final String SEARCH_PERSON_DIGITAL_APP = "SEARCH_PERSON_DIGITAL_APP";
	
	
	public static final String ANON_VALUE_1 = "お客様個人名を入力してください";	
	public static final String ANON_VALUE_2 = "【お客様個人名を入力してください】";
	public static final String ANON_VALUE_3 = "削除顧客";
	public static final String ANON_VALUE_4 = "不明";
	public static final String ANON_VALUE_5 = "フメイ";
	public static final String ANON_VALUE_6 = "名乗らず";
	
	public static final String SEARCH_XCONSENT_DETAILS_PARTYID = "SELECT * FROM XCONSENT WHERE CONT_ID IN (";
	public static final String SEARCH_COMMON = ") WITH UR";
	public static final String SEARCH_XDATASHARING_DETAILS_PARTYID = "SELECT * FROM XDATASHARING WHERE CONT_ID IN (";
	public static final String SEARCH_XCONTRACTREL_DETAILS_PARTYID1 = "SELECT * FROM XCONTRACTRELJPN WHERE CONT_ID IN (";
	public static final String SEARCH_XCONTRACTREL_DETAILS_PARTYID2 = ") AND (END_DT IS NULL OR END_DT > CURRENT_TIMESTAMP) WITH UR";	
	public static final String SEARCH_XCUSTOMERRETAILER_DETAILS_PARTYID = "SELECT * FROM XCUSTOMERRETAILERJPN WHERE CONT_ID IN (";
	public static final String SEARCH_RETAILER_DETAILS_RETAILERID = "SELECT * FROM XRETAILER WHERE RETAILERPK_ID = ? WITH UR";
	
	public static final String SEARCH_XCONTACTREL_DETAILS_PARTYID1 = "SELECT * FROM CONTACTREL WHERE TO_CONT_ID IN (";
	public static final String SEARCH_XCONTACTREL_DETAILS_PARTYID2 = ") OR FROM_CONT_ID IN (";
	
	public static final String SEARCH_XCUSTVEHICLEREL_DETAILS_PARTYID1 = "SELECT * FROM XCUSTOMERVEHICLEJPN WHERE CONT_ID IN (";
	public static final String SEARCH_XVEHICLE_DETAILS_VEHICLEID = "SELECT * FROM XVEHICLEJPN WHERE XVEHICLE_JPNPK_ID = ? WITH UR";
	public static final String SEARCH_XCUSTVEHICLEROLE_DETAILS_VEHRELID = "SELECT * FROM XCUSTOMERVEHICLEROLEJPN WHERE CUSTOMER_VEHICLE_ID = ? WITH UR";
	
	public static final String COUNT_XCUSTVEHICLEROLE_DETAILS_CONTID_ALL = "SELECT COUNT(XCVR.CUSTOMERVEHICLEROLEPK_ID) TOTAL_ROLES FROM XCUSTOMERVEHICLEROLE XCVR, XCUSTOMERVEHICLE XCV, CONTACT C WHERE XCVR.CUSTOMER_VEHICLE_ID=XCV.CUSTOMERVEHICLEPK_ID AND XCV.CONT_ID=C.CONT_ID AND XCVR.END_DT IS NULL AND XCV.END_DT IS NULL AND C.INACTIVATED_DT IS NULL AND C.CONT_ID=? WITH UR";
	public static final String COUNT_XCUSTVEHICLEROLE_DETAILS_CONTID_AUNZ = "SELECT COUNT(XCVR.XCUSTOMER_ROLE_AUSPK_ID) TOTAL_ROLES FROM XCUSTOMERVEHICLEROLEAUS XCVR, XCUSTOMERVEHICLEAUS XCV, CONTACT C WHERE XCVR.CUSTOMER_VEHICLE_ID=XCV.XCUSTOMER_VEHICLE_AUSPK_ID AND XCV.CONT_ID=C.CONT_ID AND XCVR.END_DT IS NULL AND XCV.END_DT IS NULL AND C.INACTIVATED_DT IS NULL AND C.CONT_ID=? WITH UR";
	public static final String COUNT_XCUSTVEHICLEROLE_DETAILS_CONTID_JPN = "SELECT COUNT(XCVR.XCUSTOMERVEHICLEROLEJPNPK_ID) TOTAL_ROLES FROM XCUSTOMERVEHICLEROLEJPN XCVR, XCUSTOMERVEHICLEJPN XCV, CONTACT C WHERE XCVR.CUSTOMER_VEHICLE_ID=XCV.XCUSTOMER_VEHICLE_JPNPK_ID AND XCV.CONT_ID=C.CONT_ID AND XCVR.END_DT IS NULL AND XCV.END_DT IS NULL AND C.INACTIVATED_DT IS NULL AND C.CONT_ID=? WITH UR";
	public static final String COUNT_XCUSTVEHICLEROLE_DETAILS_CONTID_KOR = "SELECT COUNT(XCVR.XCUSTOMERVEHICLEROLEKORPK_ID) TOTAL_ROLES FROM XCUSTOMERVEHICLEROLEKOR XCVR, XCUSTOMERVEHICLEKOR XCV, CONTACT C WHERE XCVR.CUSTOMER_VEHICLE_ID=XCV.XCUSTOMER_VEHICLE_KORPK_ID AND XCV.CONT_ID=C.CONT_ID AND XCVR.END_DT IS NULL AND XCV.END_DT IS NULL AND C.INACTIVATED_DT IS NULL AND C.CONT_ID=? WITH UR";
	
	public static final String SEARCH_ORG_DIGITAL_APP_KOR = "SEARCH_ORG_DIGITAL_APP_KOR";
	public static final String NAME_USAGE_TYPE_KOREA = "1004";
	public static final String CONTACT_METHOD_MOBILE_KOR = "1038";
	public static final String CONTACT_METHOD_HOMEPHONE_KOR = "1044";
	public static final String CONTACT_METHOD_WORKPHONE_KOR = "1045";
	public static final String CONTACT_METHOD_WORKMOBILE_KOR = "1046";

	//January 11, 2019 : Added by Shandeep for Turkey survivorship Rule Changes : Start
	
    public static final String SOURCE_IDENTIFIER_TYPE_PCS = "1035";
		
	//January 11, 2019 : Added by Shandeep for Turkey survivorship Rule Changes : End
    
	// -------------Changes Start for MVP -------------------//
	public static final String INDONESIA_MARKET_NAME = "ID";
	public static final String VIETNAM_MARKET_NAME = "VN";
	public static final String SINGAPORE_MARKET_NAME = "SG";
	public static final String ADMIN_SYS_TP_UCID_MVP = "1026";
	public static final String ADMIN_SYS_VALUE_UCID_MVP = "UCID";
	public static final String COMPONENT_TYPE_NAME_MVP = "NAME";
	public static final String COMPONENT_TYPE_ADDRESS_MVP = "ADDRESS";
	public static final String COMPONENT_TYPE_CONTACT_METHOD_MVP = "CONTACTMETHOD";
	public static final String COMPONENT_TYPE_IDENTIFIER_MVP = "IDENTIFIER";
	public static final String COMPONENT_TYPE_GENDER_MVP = "GENDER";
	public static final String COMPONENT_TYPE_OCCUPATION_MVP = "OCCUPATION";
	public static final String COMPONENT_TYPE_DOB_MVP = "DOB";
	public static final String ACTIVE_FLAG_Y_MVP = "Y";
	public static final String ACTIVE_FLAG_N_MVP = "N";
	
	//Survivorship MVP
	public static final String MARKET_NAME_INDONESIA = "ID";
	public static final String MARKET_NAME_VIETNAM = "VN";
	public static final String MARKET_NAME_SINGAPORE = "SG";
	public static final String MARKET_NAME_BRAZIL = "BR";
	public static final String SOURCE_PRIORITY_MVP_1 = "1";
	public static final String SOURCE_PRIORITY_MVP_2 = "2";
	public static final String ID_TYPE_SOCAIL_ID_MVP = "";
	public static final String ID_TYPE_VAT_NO_MVP = "";
	public static final String SOURCE_SYSTEM_TYPE_UCID_MVP = "1026";
	public static final String CONT_METH_CAT_EMAIL_MVP = "2";
	public static final String CONT_METH_CAT_PHONE_MVP = "1";
	public static final String CONSENT_RETAILER_FLAG_MVP_N = "N";
	public static final String CONSENT_RETAILER_FLAG_MVP_Y = "Y";
	public static final String SOURCE_SYSTEM_TYPE_SFDC_MVP = "1001";
	public static final String SOURCE_SYSTEM_TYPE_AUTOLINE_MVP = "1002";
	public static final String SOURCE_SYSTEM_TYPE_NBS_BR = "1037";
	public static final String ADDRESS_RETAILER_FLAG_MVP_Y = "Y";
	public static final String ADDRESS_RETAILER_FLAG_MVP_N = "N";
	public final static String CHARACTER_MVP_Y = "Y";
	public final static String CHARACTER_MVP_N = "N";
	public static final String ID_TYPE_MAGIC_MVP = "1002";
	public static final String SOURCE_SYSTEM_TYPE_TDS_MVP = "1007";
	
	public static final String GENDER_MVP = "GENDER";
	public static final String OCCUPATION_MVP = "OCCUPATION";
	public static final String INDUSTRY_MVP = "INDUSTRY"; 
	
	public static final String SUSP_REASON_CODE_NAME_CPF3_PH_1_2_EMAIL_TYPE = "20010";
	public static final String SUSP_REASON_CODE_NAME_CPF_PHONE_EMAIL_TYPE = "20011";
	public static final String SUSP_REASON_CODE_NAME_CVR_MORE_THAN_500 = "20012";
	
	public static final String SEARCH_PERSON_DIGITAL_APP_Brasil = "SEARCH_PERSON_DIGITAL_APP_BR";
	public static final String NAME_USAGE_TYPE_LEGAL = "1";
	public static final String CLIENT_SYS_NAME_STS_AUS = "STS"; 
	//April 17, 2019 : Added by Dhaval for MVP2 : Start
	
	public static final String HUNGARY_MARKET_NAME = "HU";
	public static final String ROMANIA_MARKET_NAME = "RO";
	public static final String SLOVAKIA_MARKET_NAME = "SK";
	
	//April 17, 2019 : Added by Dhaval for MVP2 : End
	
	//April 29, 2019 : Added by Sameeha for MVP2 : Start

	//Survivorship HRS
	public static final String SOURCE_PRIORITY_HRS_1 = "1";
	public static final String SOURCE_PRIORITY_HRS_2 = "2";
	public static final String ID_TYPE_SOCAIL_ID_HRS = "";
	public static final String ID_TYPE_VAT_NO_HRS = "";
	public static final String SOURCE_SYSTEM_TYPE_UCID_HRS = "1026";
	public static final String CONT_METH_CAT_EMAIL_HRS = "2";
	public static final String CONT_METH_CAT_PHONE_HRS = "1";
	public static final String CONSENT_RETAILER_FLAG_HRS_N = "N";
	public static final String CONSENT_RETAILER_FLAG_HRS_Y = "Y";
	public static final String SOURCE_SYSTEM_TYPE_SFDC_HRS = "1001";
	public static final String SOURCE_SYSTEM_TYPE_AUTOLINE_HRS = "1002";
	public static final String ADDRESS_RETAILER_FLAG_HRS_Y = "Y";
	public static final String ADDRESS_RETAILER_FLAG_HRS_N = "N";
	public final static String CHARACTER_HRS_Y = "Y";
	public final static String CHARACTER_HRS_N = "N";
	public static final String ID_TYPE_MAGIC_HRS = "1002";
	public static final String SOURCE_SYSTEM_TYPE_TDS_HRS = "1007";
	
	public static final String GENDER_HRS = "GENDER";
	public static final String OCCUPATION_HRS = "OCCUPATION";
	public static final String INDUSTRY_HRS = "INDUSTRY"; 
	public static final String COMPONENT_TYPE_IDENTIFIER_HRS = "IDENTIFIER";

	
	//April 29, 2019 : Added by Sameeha for MVP2 : End
	
	//July 18, 2019 : Added by Pushpraj for CL3 : Start

	public static final List<String> AEM_MARKETS = (List) Arrays.asList(new String[] {
			"AR", "EG","ME"}); 
	//Derived Data Converter
	public static final String MIDDLE_EAST_MARKET="ME";
	public static final String REGEX_ME_MARKET="^[a-zA-Z0-9 .,&'()-_]*$";
	
	
	//Survivorship AEM
	public static final String SOURCE_PRIORITY_AEM_1 = "1";
	public static final String SOURCE_PRIORITY_AEM_2 = "2";
	public static final String ID_TYPE_SOCAIL_ID_AEM = "";
	public static final String ID_TYPE_VAT_NO_AEM = "";
	public static final String SOURCE_SYSTEM_TYPE_UCID_AEM = "1026";
	public static final String CONT_METH_CAT_EMAIL_AEM = "2";
	public static final String CONT_METH_CAT_PHONE_AEM = "1";
	public static final String CONSENT_RETAILER_FLAG_AEM_N = "N";
	public static final String CONSENT_RETAILER_FLAG_AEM_Y = "Y";
	public static final String SOURCE_SYSTEM_TYPE_SFDC_AEM = "1001";
	public static final String SOURCE_SYSTEM_TYPE_AUTOLINE_AEM = "1002";
	public static final String ADDRESS_RETAILER_FLAG_AEM_Y = "Y";
	public static final String ADDRESS_RETAILER_FLAG_AEM_N = "N";
	public final static String CHARACTER_AEM_Y = "Y";
	public final static String CHARACTER_AEM_N = "N";
	public static final String ID_TYPE_MAGIC_AEM = "1002";
	public static final String SOURCE_SYSTEM_TYPE_TDS_AEM = "1007";
	
	public static final String GENDER_AEM = "GENDER";
	public static final String OCCUPATION_AEM = "OCCUPATION";
	public static final String INDUSTRY_AEM = "INDUSTRY"; 
	public static final String COMPONENT_TYPE_IDENTIFIER_AEM = "IDENTIFIER";

	
	//July 18, 2019 : Added by Pushpraj for CL3 : End
	
	//July 01, 2019 : Added by Sameeha for Unnormalized Address Changes: Start
	
	public static final String HOME_ADDRESS = "HOME"; 
	public static final String BUSINESS_ADDRESS = "BUSINESS"; 
	public static final String OTHERS1_ADDRESS = "OTHERS1"; 
	public static final String OTHERS2_ADDRESS = "OTHERS2"; 
	public static final String OTHERS3_ADDRESS = "OTHERS3";	
	public static final String HOME_MVP="1039";
	public static final String HOME_MVP_VALUE="Home MVP";
	public static final String HOME_UNNORMALIZED_MVP="1043";
	public static final String BUSINESS_MVP="1038";
	public static final String BUSINESS_MVP_VALUE="Business MVP";
	public static final String BUSINESS_UNNORMALIZED_MVP="1044";
	public static final String OTHERS1_MVP="1040";
	public static final String OTHERS1_MVP_VALUE="Others1 MVP";
	public static final String OTHERS1_UNNORMALIZED_MVP="1045";
	public static final String OTHERS2_MVP="1041";
	public static final String OTHERS2_MVP_VALUE="Others2 MVP";
	public static final String OTHERS2_UNNORMALIZED_MVP="1046";
	public static final String OTHERS3_MVP="1042";
	public static final String OTHERS3_MVP_VALUE="Others3 MVP";
	public static final String OTHERS3_UNNORMALIZED_MVP="1047";

	//July 01, 2019 : Added by Sameeha for Unnormalized Address Changes: End

	// ZA
	public static final String SOUTH_AFRICA_MARKET_NAME = "ZA";
	
	public static final String SOURCE_PRIORITY_ZA_1 = "1";
	public static final String SOURCE_PRIORITY_ZA_2 = "2";
	public static final String ID_TYPE_SOCAIL_ID_ZA = "";
	public static final String ID_TYPE_VAT_NO_ZA = "";
	public static final String SOURCE_SYSTEM_TYPE_UCID_ZA = "1026";
	public static final String CONT_METH_CAT_EMAIL_ZA = "2";
	public static final String CONT_METH_CAT_PHONE_ZA = "1";
	public static final String CONSENT_RETAILER_FLAG_ZA_N = "N";
	public static final String CONSENT_RETAILER_FLAG_ZA_Y = "Y";
	public static final String SOURCE_SYSTEM_TYPE_SFDC_ZA = "1001";
	public static final String SOURCE_SYSTEM_TYPE_AUTOLINE_ZA = "1002";
	public static final String ADDRESS_RETAILER_FLAG_ZA_Y = "Y";
	public static final String ADDRESS_RETAILER_FLAG_ZA_N = "N";
	public final static String CHARACTER_ZA_Y = "Y";
	public final static String CHARACTER_ZA_N = "N";
	public static final String ID_TYPE_MAGIC_ZA = "1002";
	public static final String SOURCE_SYSTEM_TYPE_TDS_ZA = "1007";
	public static final String ADMIN_SYS_TP_UCID_ZA = "1026";
	public static final String ADMIN_SYS_VALUE_UCID_ZA = "UCID";
	public static final String COMPONENT_TYPE_NAME_ZA = "NAME";
	public static final String COMPONENT_TYPE_ADDRESS_ZA = "ADDRESS";
	public static final String COMPONENT_TYPE_CONTACT_METHOD_ZA = "CONTACTMETHOD";
	public static final String COMPONENT_TYPE_IDENTIFIER_ZA = "IDENTIFIER";
	public static final String COMPONENT_TYPE_GENDER_ZA = "GENDER";
	public static final String COMPONENT_TYPE_OCCUPATION_ZA = "OCCUPATION";
	public static final String COMPONENT_TYPE_DOB_ZA = "DOB";
	public static final String ACTIVE_FLAG_Y_ZA = "Y";
	public static final String ACTIVE_FLAG_N_ZA = "N";
	
	public static final String GENDER_ZA = "GENDER";
	public static final String OCCUPATION_ZA = "OCCUPATION";
	public static final String INDUSTRY_ZA = "INDUSTRY"; 
	public static final String SOURCE_IDENTIFIER_TYPE_CBU = "1040";
	public static final String SUSP_REASON_CODE_DO_NOT_MERGE_FS_CUSTOMERS = "300010";
	
	//End of change for ZA
	
	
	public static final String STOUCH_UCID = "STOUCH_UCID_REMOVE";
	public static final String TXN_NAME_ADDXVRCOLLAPSE = "addXVRCollapse";
	public static final String XSUBURBDEFAULT = "NA";
	public static final String YES = "Y";
	public static final String NO = "N";
	
	public static final String MARKET_NAME_ARGENTINA="AR";
	
	public static final String MARKET_NAME_MIDDLEEAST="ME";
	
	public static final String MATCH_CAT_ADJUSTMENT_TYPE_FNAME_LNAME_ZA = "9";
	public static final String MATCH_CAT_ADJUSTMENT_VALUE_FNAME_LNAME_ZA = "Up - Same First Name and Last Name ZA";
	
	public static final String VALUE_DELETED = "DELETED";
	//Added by Sameeha for Delete Merge | 8th May 2020: Start
	public static final String DELETED_VALUE="DELETED";
	//Added by Sameeha for Delete Merge | 8th May 2020: End
	//For FS : Start
	public static final String XCUST_TYPE_PC = "PC";
	public static final String XCUST_TYPE_FS = "FS";
	public static final String XCUST_TYPE_FSPC = "FS;PC";
	// For Turkey Consent Change : Start
	public static final String SEARCH_PARTYTYPE_BY_CONT = "SELECT PERSON_ORG_CODE FROM CONTACT WHERE CONT_ID = ? ";
	public static final String PARTY_TYPE = "PERSON_ORG_CODE";
	
	public static final String SEARCH_MOBILE_BY_CONT = "SELECT REF_NUM FROM CONTACTMETHOD WHERE CONTACT_METHOD_ID IN "
			+ "(SELECT contact_method_id FROM CONTACTMETHODGROUP WHERE LOCATION_GROUP_ID IN "
			+ "(SELECT LOCATION_GROUP_ID FROM LOCATIONGROUP WHERE cont_id= ? AND LOC_GROUP_TP_CODE='C') AND CONT_METH_TP_CD = '1023')";
	public static final String SEARCH_EMAIL_BY_CONT = "SELECT REF_NUM FROM CONTACTMETHOD WHERE CONTACT_METHOD_ID IN "
			+ "(SELECT contact_method_id FROM CONTACTMETHODGROUP WHERE LOCATION_GROUP_ID IN "
			+ "(SELECT LOCATION_GROUP_ID FROM LOCATIONGROUP WHERE cont_id= ? AND LOC_GROUP_TP_CODE='C') AND CONT_METH_TP_CD = '1035')";
	
	public static final String SEARCH_MOBILE_XMODIFY_DT_BY_CONT = "SELECT XMODIFY_SYS_DT FROM CONTACTMETHODGROUP WHERE LOCATION_GROUP_ID "
			+ "IN (SELECT LOCATION_GROUP_ID FROM LOCATIONGROUP WHERE cont_id= ? AND LOC_GROUP_TP_CODE='C') AND CONT_METH_TP_CD ='1023'";

	public static final String SEARCH_EMAIL_XMODIFY_DT_BY_CONT = "SELECT XMODIFY_SYS_DT FROM CONTACTMETHODGROUP WHERE LOCATION_GROUP_ID "
			+ "IN (SELECT LOCATION_GROUP_ID FROM LOCATIONGROUP WHERE cont_id= ? AND LOC_GROUP_TP_CODE='C') AND CONT_METH_TP_CD ='1035'";

	public static final String SEARCH_HOMEADDR_BY_CONT_WS = "SELECT REPLACE(ADDR_LINE_ONE ||COALESCE(ADDR_LINE_TWO, '')|| COALESCE(ADDR_LINE_THREE, '')|| CITY_NAME || COALESCE(POSTAL_CODE, ''),' ','') AS FULL_ADDR FROM ADDRESS WHERE ADDRESS_ID IN "
			+ "(SELECT ADDRESS_ID FROM ADDRESSGROUP WHERE LOCATION_GROUP_ID IN (SELECT LOCATION_GROUP_ID FROM LOCATIONGROUP WHERE cont_id= ? AND LOC_GROUP_TP_CODE='A' AND END_DT IS NULL) AND ADDR_USAGE_TP_CD='1001' AND XADDR_RETAILER_FLAG = 'N' AND XRETAILER_ID IS NULL )";

	public static final String SEARCH_BUSINESSADDR_BY_CONT_WS = "SELECT REPLACE(ADDR_LINE_ONE ||COALESCE(ADDR_LINE_TWO, '')|| COALESCE(ADDR_LINE_THREE, '')|| CITY_NAME || COALESCE(POSTAL_CODE, ''),' ','') AS FULL_ADDR FROM ADDRESS WHERE ADDRESS_ID IN "
			+ "(SELECT ADDRESS_ID FROM ADDRESSGROUP WHERE LOCATION_GROUP_ID IN (SELECT LOCATION_GROUP_ID FROM LOCATIONGROUP WHERE cont_id= ? AND LOC_GROUP_TP_CODE='A' AND END_DT IS NULL) AND ADDR_USAGE_TP_CD='3' AND XADDR_RETAILER_FLAG = 'N' AND XRETAILER_ID IS NULL)";

	
	public static final String SEARCH_HOMEADDR_BY_CONT_RT = "SELECT REPLACE(ADDR_LINE_ONE ||COALESCE(ADDR_LINE_TWO, '')|| COALESCE(ADDR_LINE_THREE, '')|| CITY_NAME || COALESCE(POSTAL_CODE, ''),' ','') AS FULL_ADDR FROM ADDRESS WHERE ADDRESS_ID IN "
			+ "(SELECT ADDRESS_ID FROM ADDRESSGROUP WHERE LOCATION_GROUP_ID IN (SELECT LOCATION_GROUP_ID FROM LOCATIONGROUP WHERE cont_id= ? AND LOC_GROUP_TP_CODE='A' AND END_DT IS NULL) AND ADDR_USAGE_TP_CD='1001' AND XADDR_RETAILER_FLAG = 'Y' AND XRETAILER_ID IS NOT NULL)";

	public static final String SEARCH_BUSINESSADDR_BY_CONT_RT = "SELECT REPLACE(ADDR_LINE_ONE ||COALESCE(ADDR_LINE_TWO, '')|| COALESCE(ADDR_LINE_THREE, '')|| CITY_NAME || COALESCE(POSTAL_CODE, ''),' ','') AS FULL_ADDR FROM ADDRESS WHERE ADDRESS_ID IN "
			+ "(SELECT ADDRESS_ID FROM ADDRESSGROUP WHERE LOCATION_GROUP_ID IN (SELECT LOCATION_GROUP_ID FROM LOCATIONGROUP WHERE cont_id= ? AND LOC_GROUP_TP_CODE='A' AND END_DT IS NULL) AND ADDR_USAGE_TP_CD='3' AND XADDR_RETAILER_FLAG = 'Y' AND XRETAILER_ID IS NOT NULL)";

	
	public static final String SEARCH_HOMEADDR_XMODIFYDT_BY_CONT_WS = "SELECT XMODIFY_SYS_DT FROM ADDRESSGROUP WHERE LOCATION_GROUP_ID IN "
			+ "(SELECT LOCATION_GROUP_ID FROM LOCATIONGROUP WHERE cont_id= ? AND LOC_GROUP_TP_CODE='A' AND END_DT IS NULL)AND ADDR_USAGE_TP_CD='1001' AND XADDR_RETAILER_FLAG = 'N' AND XRETAILER_ID IS NULL";

	public static final String SEARCH_BUSINESSADDR_XMODIFYDT_BY_CONT_WS = "SELECT XMODIFY_SYS_DT FROM ADDRESSGROUP WHERE LOCATION_GROUP_ID IN "
			+ "(SELECT LOCATION_GROUP_ID FROM LOCATIONGROUP WHERE cont_id= ? AND LOC_GROUP_TP_CODE='A' AND END_DT IS NULL)AND ADDR_USAGE_TP_CD='3' AND XADDR_RETAILER_FLAG = 'N' AND XRETAILER_ID IS NULL";

	
	public static final String SEARCH_HOMEADDR_XMODIFYDT_BY_CONT_RT = "SELECT XMODIFY_SYS_DT FROM ADDRESSGROUP WHERE LOCATION_GROUP_ID IN "
			+ "(SELECT LOCATION_GROUP_ID FROM LOCATIONGROUP WHERE cont_id= ? AND LOC_GROUP_TP_CODE='A' AND END_DT IS NULL)AND ADDR_USAGE_TP_CD='1001' AND XADDR_RETAILER_FLAG = 'Y' AND XRETAILER_ID IS NOT NULL";

	public static final String SEARCH_BUSINESSADDR_XMODIFYDT_BY_CONT_RT = "SELECT XMODIFY_SYS_DT FROM ADDRESSGROUP WHERE LOCATION_GROUP_ID IN "
			+ "(SELECT LOCATION_GROUP_ID FROM LOCATIONGROUP WHERE cont_id= ? AND LOC_GROUP_TP_CODE='A' AND END_DT IS NULL)AND ADDR_USAGE_TP_CD='3' AND XADDR_RETAILER_FLAG = 'Y' AND XRETAILER_ID IS NOT NULL";

	
	
	
	
	public static final String REF_NUM = "REF_NUM";
	public static final String XMODIFY_SYS_DT = "XMODIFY_SYS_DT";
	public static final String FULL_ADDR = "FULL_ADDR";
	
	public static final String CONTACT_METHOD_USAGE_TYPE_MOBILE_PHONE = "1023";
	
	public static final String CONTACT_METHOD_USAGE_TYPE_EMAIL = "1035";
	
	// For Turkey Consent Change : End
	
	public static final String MATCH_CAT_ADJUSTMENT_TYPE_FN_LN_PHONE_EMAIL_NATIONALID_EXACT_THA = "10";
	public static final String MATCH_CAT_ADJUSTMENT_VALUE_FN_LN_PHONE_EMAIL_NATIONALID_EXACT_THA = "Up - Exact Fname+Lname + Email or Phone or NationalID THA";
	
	//For FS : End
	
	
// For Japan Match Rule Changes by Shashi: Start 
	
	public static final String CONTACT_METHOD_USAGE_TYPE_PRIVATE_EMAIL_JPN = "1030";
	public static final String CONTACT_METHOD_USAGE_TYPE_WORK_EMAIL_JPN = "1031";
	public static final String CONTACT_METHOD_USAGE_TYPE_OTHER_EMAIL_JAPAN = "1032";
	public static final String CONTACT_METHOD_USAGE_TYPE_EMAIL3_JPN = "1036";
	
	
	public static final String MATCH_CAT_ADJUSTMENT_TYPE_UPGRADE_B_TO_A1_PERSON_JPN = "11";
	public static final String MATCH_CAT_ADJUSTMENT_VALUE_UPGRADE_B_TO_A1_PERSON_JPN = "Up - Exact Person Name + Email or Phone & All DataSharing Yes Japan";

	public static final String MATCH_CAT_ADJUSTMENT_TYPE_DOWNGRADE_A1_TO_B_PERSON_JPN = "12";
	public static final String MATCH_CAT_ADJUSTMENT_VALUE_DOWNGRADE_A1_TO_B_PERSON_JPN = "Downgrade - A1 to B Japan";

	public static final String MATCH_CAT_ADJUSTMENT_TYPE_UPGRADE_B_TO_A1_ORG_JPN = "13";
	public static final String MATCH_CAT_ADJUSTMENT_VALUE_UPGRADE_B_TO_A1_ORG_JPN  = "Up - Exact Org Name + Phone & All DataSharing Yes Japan";


	
// End of Changes

        //AU_NZ Match Rule Changes : Start
	
	public static final String MATCH_CAT_ADJUSTMENT_TYPE_UPGRADE_B_TO_A1_PERSON_AU_NZ = "14";
	public static final String MATCH_CAT_ADJUSTMENT_VALUE_UPGRADE_B_TO_A1_PERSON_AU_NZ = "Up - Exact Person Name + Email AU-NZ";

	
	//End
		//For FS : Start
	public static final String CONTACT_METHOD_USAGE_TYPE_FS_MOBILE = "1055";
	public static final String CONTACT_METHOD_USAGE_TYPE_FS_EMAIL_2 = "1056";
	public static final String CONTACT_METHOD_USAGE_TYPE_FS_EMAIL_1 = "1054";
	//For FS : End
	public static final String MATCH_CAT_CODE_C = "C";
	
	
	public static final String ANONYMIZED_VAL_BY_PARTYID = "SELECT X_ANONYMIZED FROM PERSON WHERE CONT_ID = ? ";
	public static final String X_ANONYMIZED = "X_ANONYMIZED";
	
	//For FS ZA: Start
	public static final String CONTACT_METHOD_USAGE_TYPE_Retail_Phone = "1057";
	public static final String IDENTIFICATION_TYPE_ABN_Number = "1010";
	public static final String IDENTIFICATION_TYPE_PASSPORT_NUMBER = "8";
	public static final String IDENTIFICATION_TYPE_Customer_Number = "1045";
	//For FS : End
}
