package com.ibm.daimler.dsea.extrules.notification;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Vector;

import com.dwl.base.DWLControl;
import com.dwl.base.notification.CommonNotification;
import com.dwl.tcrm.common.TCRMCommon;
import com.dwl.tcrm.coreParty.component.TCRMAdminContEquivBObj;
import com.dwl.tcrm.coreParty.component.TCRMConsolidatedPartyBObj;
import com.dwl.tcrm.coreParty.component.TCRMPartyBObj;
import com.dwl.tcrm.coreParty.component.TCRMPartyListBObj;
import com.dwl.tcrm.utilities.DateFormatter;
import com.ibm.daimler.dsea.component.XIdentifierBObjExt;
import com.ibm.daimler.dsea.extrules.constant.ExternalRuleConstant;

public class CustomNotificationCollapseAUS extends CommonNotification {
	private TCRMCommon commonObject;
	private String externalCorrelationId;
	private Object collapseresponse;
	private final static com.dwl.base.logging.IDWLLogger logger = com.dwl.base.logging.DWLLoggerManager
			.getLogger(CommonNotification.class);
	String header = "<MergedResult> <GoldenParty>";
	String header1 = " </SourcePartyList> </MergedResult>";
	private String stat;

	public CustomNotificationCollapseAUS(){
		super();
		//this.notificationType="nt12";
		//this.notificationTypeValue="MDM Entity Change Broadcast";

		this.notificationType="nt17";
		this.notificationTypeValue="Collapse Response for Australia";
	}

	public void setExternalCorrelationId(String externalCorrelationId) {
		this.externalCorrelationId = externalCorrelationId;
	}

	public TCRMCommon getCommonObject() {
		return this.commonObject;
	}

	public void setCommonObject(TCRMCommon commonObject) {
		this.commonObject = commonObject;
	}

	/*
	 * Generate notification xml
	 */
	public String getXml() throws Exception {

		/*TCRMConsolidatedPartyBObj consolidatedParty = (TCRMConsolidatedPartyBObj) this.commonObject;
		TCRMPartyBObj partyObject = consolidatedParty.getTCRMPartyBObj();
		DWLControl control =  partyObject.getControl();
		String goldenPartyId = partyObject.getPartyId();
		String goldenUCID = null;
		String goldenSystemName = null;
		TCRMPartyListBObj partySourceListBobj = new TCRMPartyListBObj();
		Vector<TCRMPartyBObj> vecSourcePartyBobj = new Vector<TCRMPartyBObj>();
		String sourceIdSystemName = new String();
		partySourceListBobj = consolidatedParty.getTCRMPartyListBObj();
		vecSourcePartyBobj = partySourceListBobj.getItemsTCRMPartyBObj();

		//Get Golden Party System Name
		goldenSystemName = getGoldenSystemName(partyObject);

		Vector<XIdentifierBObjExt> goldenIdentifiers = partyObject.getItemsTCRMPartyIdentificationBObj();
		for(XIdentifierBObjExt identificationBObj : goldenIdentifiers) {
			if(ExternalRuleConstant.ID_TYPE_UCID.equals(identificationBObj.getIdentificationType())){
				goldenUCID = identificationBObj.getIdentificationNumber();
				break;
			}
		}

		//Get Source Party List and Source Party System Name
		if (vecSourcePartyBobj != null && vecSourcePartyBobj.size() > 0) {
			for (TCRMPartyBObj sourcePartyBObj : vecSourcePartyBobj) {
				// sourceFinalPartyId = sourceFinalPartyId + sourcePartyId;
				String sourcePartyId = new String();
				String sourceSystemName = new String();
				String partyIdSystemName = new String();
				String sourceUCID = null;
				sourcePartyId = "<SourceParty><PartyID>" + sourcePartyBObj.getPartyId() + "</PartyID>";
				Vector<XIdentifierBObjExt> vectorIdentifiers = sourcePartyBObj.getItemsTCRMPartyIdentificationBObj();
				for(XIdentifierBObjExt identificationBObj : vectorIdentifiers) {
					if(ExternalRuleConstant.ID_TYPE_UCID.equals(identificationBObj.getIdentificationType())){
						sourceUCID = identificationBObj.getIdentificationNumber();
						break;
					}
				}
				sourceUCID = "<UCID>"+sourceUCID+"</UCID>";
				String systemNames = "<SystemName>" + getSourceSystemName(sourcePartyBObj) + "</SystemName>";
				sourceSystemName = sourceSystemName + sourceUCID+systemNames;
				partyIdSystemName = sourcePartyId + sourceSystemName
						+ "</SourceParty> ";
				sourceIdSystemName = sourceIdSystemName + partyIdSystemName;
			}
		}


		logger.finest("Coming to getMessage method");*/
		StringBuffer strXml = new StringBuffer();
		/*strXml.append(header);
		strXml.append("<PartyID>" + goldenPartyId + "</PartyID>");
		strXml.append("<UCID>" + goldenUCID + "</UCID>");
		strXml.append("<SystemName>" + goldenSystemName + "</SystemName>" );
		strXml.append("</GoldenParty> <SourcePartyList> ");
		strXml.append(sourceIdSystemName);
		strXml.append(header1);*/
		return strXml.toString();
	}

	@Override
	public String getMessage() {
		try {
			return getXml();
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}

	}

	/*
	 * This method is used for setting the status of the transaction
	 */

	public void setTransactionStat(String stat) {
		this.stat = stat;

	}

	/*protected String getGoldenSystemName(TCRMPartyBObj tcrmPartyBObj) {

		String goldenSystem = null;
		try {

			List<List<String>> xModifyList = new ArrayList<List<String>>();
			xModifyList.addAll(getXModifyDateFromIdentifier(tcrmPartyBObj));
			xModifyList.addAll(getXModifyDateFromContequiv(tcrmPartyBObj));
			List<Date> xModifiedDates = new ArrayList<Date>();
			for(int j=0;j<xModifyList.size();j++){
				xModifiedDates.add(DateFormatter.getTimestamp(xModifyList.get(j).get(0)));
			}
			Collections.sort(xModifiedDates);
			for(int j=0;j<xModifyList.size();j++){
				if(xModifiedDates.get(0).toString().equals(xModifyList.get(j).get(0))){
					goldenSystem = xModifyList.get(j).get(1);
				}
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return goldenSystem;
	}

	protected String getSourceSystemName(TCRMPartyBObj tcrmPartyBObj){

		String sourceSystem = null;
		try {

			List<List<String>> xModifyList = new ArrayList<List<String>>();
			xModifyList.addAll(getXModifyDateFromIdentifier(tcrmPartyBObj));
			for(int i=0;i<xModifyList.size();i++){
				if(ExternalRuleConstant.ADMIN_SYS_VALUE_STOUCH.equals(xModifyList.get(i).get(1))){
					return ExternalRuleConstant.ADMIN_SYS_VALUE_STOUCH;
				}
			}

			xModifyList.addAll(getXModifyDateFromContequiv(tcrmPartyBObj));
			List<Date> xModifiedDates = new ArrayList<Date>();
			for(int j=0;j<xModifyList.size();j++){
				xModifiedDates.add(DateFormatter.getTimestamp(xModifyList.get(j).get(0)));
			}
			Collections.sort(xModifiedDates);
			for(int j=0;j<xModifyList.size();j++){
				if(xModifiedDates.get(0).toString().equals(xModifyList.get(j).get(0))){
					sourceSystem = xModifyList.get(j).get(1);
				}
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return sourceSystem;
	}

	protected List<List<String>> getXModifyDateFromIdentifier(TCRMPartyBObj tcrmPartyBObj) {
		String xModifyDate = null;
		String identTp = null;
		String sourceIdentVal = null;
		List<List<String>> xModifyList = new ArrayList<List<String>>();
		List<String> xModifyDetails = new ArrayList<String>();

		Vector<XIdentifierBObjExt> vectorIdentifiers = tcrmPartyBObj.getItemsTCRMPartyIdentificationBObj();
		try {
			for(XIdentifierBObjExt identificationBObj : vectorIdentifiers) {

				xModifyDetails = new ArrayList<String>();
				xModifyDate = identificationBObj.getXLastModifiedSystemDate();
				identTp = identificationBObj.getIdentificationType();
				sourceIdentVal = identificationBObj.getSourceIdentifierValue();
				if(ExternalRuleConstant.ID_TYPE_STOUCHID.equals(identTp)){
					xModifyDetails.add(xModifyDate);
					xModifyDetails.add(sourceIdentVal);
					xModifyList.add(xModifyDetails);
					break;
				}
				else if(ExternalRuleConstant.ID_TYPE_CUSTID.equals(identTp)){
					xModifyDetails.add(xModifyDate);
					xModifyDetails.add(sourceIdentVal);
					xModifyList.add(xModifyDetails);
				}
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return xModifyList;

	}

	protected List<List<String>> getXModifyDateFromContequiv(TCRMPartyBObj tcrmPartyBObj) {
		String xModifyDate = null;
		String sourceIdentVal = null;
		List<List<String>> xModifyList = new ArrayList<List<String>>();
		List<String> xModifyDetails = new ArrayList<String>();

		Vector<TCRMAdminContEquivBObj> vectorContequiv = tcrmPartyBObj.getItemsTCRMAdminContEquivBObj();
		try {
			for(TCRMAdminContEquivBObj contequiv : vectorContequiv) {

				xModifyDetails = new ArrayList<String>();
				xModifyDate = contequiv.getContEquivLastUpdateDate();
				sourceIdentVal = contequiv.getAdminSystemValue();
				xModifyDetails.add(xModifyDate);
				xModifyDetails.add(sourceIdentVal);
				xModifyList.add(xModifyDetails);
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return xModifyList;
	}*/
}
