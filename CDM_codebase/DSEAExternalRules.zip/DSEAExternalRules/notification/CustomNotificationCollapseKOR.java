package com.ibm.daimler.dsea.extrules.notification;


import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Vector;

import com.dwl.base.notification.CommonNotification;
import com.dwl.tcrm.common.TCRMCommon;
import com.dwl.tcrm.coreParty.component.TCRMAdminContEquivBObj;
import com.dwl.tcrm.coreParty.component.TCRMConsolidatedPartyBObj;
import com.dwl.tcrm.coreParty.component.TCRMPartyBObj;
import com.dwl.tcrm.coreParty.component.TCRMPartyListBObj;
import com.dwl.tcrm.utilities.DateFormatter;
import com.ibm.daimler.dsea.component.XContEquivBObjExt;
import com.ibm.daimler.dsea.extrules.constant.ExternalRuleConstant;

public class CustomNotificationCollapseKOR extends CommonNotification{
	private TCRMCommon commonObject;
	private String externalCorrelationId;
	private Object collapseresponse;
	private final static com.dwl.base.logging.IDWLLogger logger = com.dwl.base.logging.DWLLoggerManager.getLogger(CustomNotificationCollapseKOR.class);
	String header="<MergedResult> <GoldenParty>";
	String header1=" </SourcePartyList> </MergedResult>";
	private String stat;
	
	public CustomNotificationCollapseKOR(){
		super();
		//this.notificationType="nt12";
		//this.notificationTypeValue="MDM Entity Change Broadcast";
		
		this.notificationType="nt14";
		this.notificationTypeValue="Collapse Response for Korea";
	}
	
	public void setExternalCorrelationId(String externalCorrelationId) {
		this.externalCorrelationId = externalCorrelationId;
	}
	public TCRMCommon getCommonObject()
	{
		return this.commonObject;
	}
	 
	public void setCommonObject(TCRMCommon commonObject)
	{
		this.commonObject = commonObject;
	}

	public String getXml() throws Exception{

		TCRMConsolidatedPartyBObj consolidatedParty = (TCRMConsolidatedPartyBObj) this.commonObject;
		TCRMPartyBObj partyObject = consolidatedParty.getTCRMPartyBObj();
		String goldenPartyId = partyObject.getPartyId();
		String goldenUCID = null;
		String goldenSystemName = null;
		TCRMPartyListBObj partySourceListBobj = new TCRMPartyListBObj();
		Vector<TCRMPartyBObj> vecSourcePartyBobj = new Vector<TCRMPartyBObj>();
		String sourceIdSystemName = new String();
		partySourceListBobj = consolidatedParty.getTCRMPartyListBObj();
		vecSourcePartyBobj = partySourceListBobj.getItemsTCRMPartyBObj();
		
		//Get Golden Party System Name
		goldenSystemName = getGoldenSystemName(partyObject);
		
		Vector<XContEquivBObjExt> goldenContequiv = partyObject.getItemsTCRMAdminContEquivBObj();
		for(XContEquivBObjExt contequivBObj : goldenContequiv) {
			if("Y".equals(contequivBObj.getDescription()) && ExternalRuleConstant.UCID_SOURCE_TYPE.equals(contequivBObj.getAdminSystemType())){
				goldenUCID = contequivBObj.getAdminPartyId();
				break;
			}
		}
		
		//Get Source Party List and Source Party System Name
		if (vecSourcePartyBobj != null && vecSourcePartyBobj.size() > 0) {
			for (TCRMPartyBObj sourcePartyBObj : vecSourcePartyBobj) {
				// sourceFinalPartyId = sourceFinalPartyId + sourcePartyId;
				String sourcePartyId = new String();
				String sourceSystemName = new String();
				String partyIdSystemName = new String();
				String sourceUCID = null;
				sourcePartyId = "<SourceParty><PartyID>" + sourcePartyBObj.getPartyId() + "</PartyID>";
				Vector<XContEquivBObjExt> vectorContequiv = sourcePartyBObj.getItemsTCRMAdminContEquivBObj();
				for(XContEquivBObjExt contequivBObj : vectorContequiv) {
					if(ExternalRuleConstant.UCID_SOURCE_TYPE.equals(contequivBObj.getAdminSystemType())){
						sourceUCID = contequivBObj.getAdminPartyId();
						break;
					}
				}
				if(!goldenUCID.equalsIgnoreCase(sourceUCID)){
					sourceUCID = "<UCID>"+sourceUCID+"</UCID>";
					
					String systemNames = "<SystemName>" + getSourceSystemName(sourcePartyBObj) + "</SystemName>";
					sourceSystemName = sourceSystemName + sourceUCID+systemNames;
					partyIdSystemName = sourcePartyId + sourceSystemName
							+ "</SourceParty> ";
					sourceIdSystemName = sourceIdSystemName + partyIdSystemName;
				}
			}
		}
		

		logger.finest("Coming to getMessage method");
		StringBuffer strXml = new StringBuffer();
		strXml.append(header);
		strXml.append("<PartyID>" + goldenPartyId + "</PartyID>");
		strXml.append("<UCID>" + goldenUCID + "</UCID>");
		strXml.append("<SystemName>" + goldenSystemName + "</SystemName>" );
		strXml.append("</GoldenParty> <SourcePartyList> ");
		strXml.append(sourceIdSystemName);
		strXml.append(header1);
		return strXml.toString();
	}

	@Override
	public String getMessage() {
		try {
			return getXml();
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}

	}

	/*
	 * This method is used for setting the status of the transaction
	 */

	public void setTransactionStat(String stat) {
		this.stat = stat;

	}

	protected String getGoldenSystemName(TCRMPartyBObj tcrmPartyBObj) {
		
		String goldenSystem = null;
		try {
			
			List<List<String>> xModifyList = new ArrayList<List<String>>();
			xModifyList.addAll(getXModifyDateFromContequiv(tcrmPartyBObj));
			List<Date> xModifiedDates = new ArrayList<Date>();
			for(int j=0;j<xModifyList.size();j++){
				xModifiedDates.add(DateFormatter.getTimestamp(xModifyList.get(j).get(0)));
			}
			Collections.sort(xModifiedDates);
			for(int j=0;j<xModifyList.size();j++){
				if(xModifiedDates.get(0).toString().equals(xModifyList.get(j).get(0))){
					goldenSystem = xModifyList.get(j).get(1);
				}
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return goldenSystem;
	}
	
	protected String getSourceSystemName(TCRMPartyBObj tcrmPartyBObj){
		
		String sourceSystem = null;
		try {
			
			List<List<String>> xModifyList = new ArrayList<List<String>>();
			
			
			xModifyList.addAll(getXModifyDateFromContequiv(tcrmPartyBObj));
			for(int i=0;i<xModifyList.size();i++){
				if(ExternalRuleConstant.ADMIN_SYS_VALUE_STOUCH.equals(xModifyList.get(i).get(1))){
					return ExternalRuleConstant.ADMIN_SYS_VALUE_STOUCH;
				}
			}
			List<Date> xModifiedDates = new ArrayList<Date>();
			for(int j=0;j<xModifyList.size();j++){
				xModifiedDates.add(DateFormatter.getTimestamp(xModifyList.get(j).get(0)));
			}
			Collections.sort(xModifiedDates);
			for(int j=0;j<xModifyList.size();j++){
				if(xModifiedDates.get(0).toString().equals(xModifyList.get(j).get(0))){
					sourceSystem = xModifyList.get(j).get(1);
				}
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return sourceSystem;
	}
	
	

	protected List<List<String>> getXModifyDateFromContequiv(TCRMPartyBObj tcrmPartyBObj) {
		String xModifyDate = null;
		String sourceIdentVal = null;
		List<List<String>> xModifyList = new ArrayList<List<String>>();
		List<String> xModifyDetails = new ArrayList<String>();
		
		Vector<TCRMAdminContEquivBObj> vectorContequiv = tcrmPartyBObj.getItemsTCRMAdminContEquivBObj();
		try {
			for(TCRMAdminContEquivBObj contequiv : vectorContequiv) {
				if(!ExternalRuleConstant.ADMIN_SYS_TP_UCID.equals(contequiv.getAdminSystemType())){
					xModifyDetails = new ArrayList<String>();
					xModifyDate = contequiv.getContEquivLastUpdateDate();
					sourceIdentVal = contequiv.getAdminSystemValue();
					xModifyDetails.add(xModifyDate);
					xModifyDetails.add(sourceIdentVal);
					xModifyList.add(xModifyDetails);
				}
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return xModifyList;
	}

}
