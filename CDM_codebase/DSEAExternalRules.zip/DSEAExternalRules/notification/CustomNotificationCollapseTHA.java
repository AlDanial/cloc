package com.ibm.daimler.dsea.extrules.notification;


import java.util.ArrayList;
import java.util.Vector;

import com.dwl.base.notification.CommonNotification;
import com.dwl.tcrm.common.TCRMCommon;
import com.dwl.tcrm.coreParty.component.TCRMAdminContEquivBObj;
import com.dwl.tcrm.coreParty.component.TCRMConsolidatedPartyBObj;
import com.dwl.tcrm.coreParty.component.TCRMPartyBObj;
import com.dwl.tcrm.coreParty.component.TCRMPartyListBObj;
import com.ibm.daimler.dsea.component.XPersonNameBObjExt;

public class CustomNotificationCollapseTHA extends CommonNotification{
	private TCRMCommon commonObject;
	private String externalCorrelationId;
	private Object collapseresponse;
	private final static com.dwl.base.logging.IDWLLogger logger = com.dwl.base.logging.DWLLoggerManager.getLogger(CustomNotificationCollapseTHA.class);
	String header="<MergedResult> <GoldenParty>";
	String header1=" </SourcePartyList> </MergedResult>";
	private String stat;
	
	public CustomNotificationCollapseTHA(){
		super();
		//this.notificationType="nt12";
		//this.notificationTypeValue="MDM Entity Change Broadcast";
		
		this.notificationType="nt16";
		this.notificationTypeValue="Collapse Response for Thailand";
	}
	
	public void setExternalCorrelationId(String externalCorrelationId) {
		this.externalCorrelationId = externalCorrelationId;
	}
	public TCRMCommon getCommonObject()
	   {
	      return this.commonObject;
	    }
	 
	 public void setCommonObject(TCRMCommon commonObject)
	    {
	      this.commonObject = commonObject;
	    }

	 public String getXml()
		     throws Exception
		   {
		 
		 /*TCRMConsolidatedPartyBObj consolidatedParty = (TCRMConsolidatedPartyBObj)this.commonObject;
		 TCRMPartyBObj partyObject = consolidatedParty.getTCRMPartyBObj();
		 Vector<TCRMAdminContEquivBObj> vecContequivBOBj = new Vector<TCRMAdminContEquivBObj>();
		 vecContequivBOBj = partyObject.getItemsTCRMAdminContEquivBObj();
		 String goldenPartyId = partyObject.getPartyId();
		 ArrayList<String> goldenSystemList = new ArrayList<String>();
		 String goldenSystemName = new String();
		 TCRMPartyListBObj partySourceListBobj = new TCRMPartyListBObj();
		 Vector<TCRMPartyBObj> vecSourcePartyBobj = new Vector<TCRMPartyBObj>();
		 String sourceFinalPartyId = new String();
		 String sourceIdSystemName = new String();	 
		 partySourceListBobj = consolidatedParty.getTCRMPartyListBObj();
		 vecSourcePartyBobj = partySourceListBobj.getItemsTCRMPartyBObj();
		 
		 if(vecSourcePartyBobj!=null && vecSourcePartyBobj.size()>0){
		 for(TCRMPartyBObj sourcePartyBObj : vecSourcePartyBobj){			 
			// sourceFinalPartyId = sourceFinalPartyId + sourcePartyId;
			 String sourcePartyId = new String();
			 String sourceSystemName = new String();
			 String partyIdSystemName = new String();
			 sourcePartyId = "<SourceParty><PartyID>" + sourcePartyBObj.getPartyId() + "</PartyID>";
			 Vector<TCRMAdminContEquivBObj> vecSourceContequivBOBj = new Vector<TCRMAdminContEquivBObj>();
			 vecSourceContequivBOBj = sourcePartyBObj.getItemsTCRMAdminContEquivBObj();
			 ArrayList<String> sourceSystemList = new ArrayList<String>();			 
			 if(vecSourceContequivBOBj!=null && vecSourceContequivBOBj.size()>0){
				 for(TCRMAdminContEquivBObj tcrmAdminContequivBObj : vecSourceContequivBOBj){				 
					 String adminSystemValue = tcrmAdminContequivBObj.getAdminSystemValue();
					 sourceSystemList.add(adminSystemValue);			 				 
				 }
			 }			 		 
			 if(sourceSystemList!=null && sourceSystemList.size()>0){
				 for(int i=0;i<sourceSystemList.size();i++){
					 String systemNames = "<SystemName>" + sourceSystemList.get(i) + "</SystemName>";	 
					 sourceSystemName = sourceSystemName + systemNames;			 				 
				 }			 
			 }			 
			 partyIdSystemName = sourcePartyId + sourceSystemName + "</SourceParty> ";
			 sourceIdSystemName = sourceIdSystemName + partyIdSystemName;			 
		 	}
		 }		 
		 if(vecContequivBOBj!=null && vecContequivBOBj.size()>0){
			 for(TCRMAdminContEquivBObj tcrmAdminContequivBObj : vecContequivBOBj){				 
				 String adminSystemValue = tcrmAdminContequivBObj.getAdminSystemValue();
				 goldenSystemList.add(adminSystemValue);			 				 
			 }
		 }		 		 
		 if(goldenSystemList!=null && goldenSystemList.size()>0){
			 for(int i=0;i<goldenSystemList.size();i++){
				 String systemNames = "<SystemName>" + goldenSystemList.get(i) + "</SystemName>";	 
				 goldenSystemName = goldenSystemName + systemNames;			 				 
			 }			 
		 }		 
		 logger.finest("Coming to getMessage method");*/
	     StringBuffer strXml = new StringBuffer();
	     /*strXml.append(header);
	     strXml.append("<PartyID>" + goldenPartyId + "</PartyID>");		     
	     strXml.append(goldenSystemName);
	     strXml.append("</GoldenParty> <SourcePartyList> ");
	     strXml.append(sourceIdSystemName);
	     strXml.append(header1);*/
	     
	     strXml.append("Thailand Message :::++++++222222222");
	     return strXml.toString();
	   }	 
	 @Override
	public String getMessage() {
		try
	    {
	      return getXml();
	     }
	     catch (Exception e) {
	       e.printStackTrace();
	       return null;
	     }
		
	}

/*
 * This method is used for setting the status of the transaction
 */

	public void setTransactionStat(String stat) {
		this.stat=stat;
		
	}
	
	

}
