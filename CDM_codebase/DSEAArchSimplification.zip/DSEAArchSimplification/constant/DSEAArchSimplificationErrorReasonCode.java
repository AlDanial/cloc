/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[5dfe51360b5e80bc75c9598215298ff4]
 */
package com.ibm.mdm.dsea.arch.constant;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * Defines the error message codes used in this module.
 *
 * @generated
 */
public class DSEAArchSimplificationErrorReasonCode {

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * In a one-to-many containment, the reference in the child object has a value which does not match the parent object during an update transaction.
     *
     * @generated
     */
    public final static String MAINTAININDIVIDUALOBJECT_TCRMPERSONBOBJ_REFERENCE_INVALID = "9961023";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * In a one-to-many containment, the reference in the child object has a value which does not match the parent object during an update transaction.
     *
     * @generated
     */
    public final static String MAINTAININDIVIDUALOBJECT_XDATASHARINGBOBJ_REFERENCE_INVALID = "9961029";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * In a one-to-many containment, the reference in the child object has a value which does not match the parent object during an update transaction.
     *
     * @generated
     */
    public final static String MAINTAINCOMPANYOBJECT_TCRMORGANIZATIONBOBJ_REFERENCE_INVALID = "9961047";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * In a one-to-many containment, the reference in the child object has a value which does not match the parent object during an update transaction.
     *
     * @generated
     */
    public final static String MAINTAINCOMPANYOBJECT_XDATASHARINGBOBJ_REFERENCE_INVALID = "9961053";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The transaction maintainIndividual failed.
     *
     * @generated
     */
    public final static String MAINTAININDIVIDUAL_FAILED = "9961067";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The transaction maintainCompany failed.
     *
     * @generated
     */
    public final static String MAINTAINCOMPANY_FAILED = "9961081";

	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The transaction deleteCustomer failed.
     *
     * @generated
     */
    public final static String DELETECUSTOMER_FAILED = "9961111";

    public static final String MARKET_NAME_INVALID = "9971001";

	public static final String UCID_INVALID = "9971002";
	
	public static final String SFDCID_INVALID = "9971003";

	public static final String MAINTAIN_INDIVIDUAL_GETPARTY_FAILED = "9971004";

	public static final String MAINTAIN_INDIVIDUAL_UPDATE_FAILED = "9971005";
	
	public static final String MAINTAIN_COMPANY_GETPARTY_FAILED = "9971006";

	public static final String MAINTAIN_COMPANY_UPDATE_FAILED = "9971007";
	
	public static final String MANDATORY_UCID_SFDCID = "9971008";

	public static final String NO_RECORD_FOUND = "10201";

}


