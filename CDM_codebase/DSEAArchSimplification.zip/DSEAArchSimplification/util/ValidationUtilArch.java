package com.ibm.mdm.dsea.arch.util;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Vector;

import com.dwl.base.DWLCommon;
import com.dwl.base.DWLControl;
import com.dwl.base.DWLResponse;
import com.dwl.base.IDWLErrorMessage;
import com.dwl.base.db.SQLParam;
import com.dwl.base.db.SQLQuery;
import com.dwl.base.error.DWLError;
import com.dwl.base.error.DWLErrorCode;
import com.dwl.base.error.DWLStatus;
import com.dwl.base.requestHandler.DWLTransactionPersistent;
import com.dwl.base.requestHandler.DWLTxnBP;
import com.dwl.base.util.DWLClassFactory;
import com.dwl.base.util.StringUtils;
import com.dwl.tcrm.common.TCRMControlKeys;
import com.dwl.tcrm.common.TCRMResponse;
import com.dwl.tcrm.coreParty.component.TCRMAdminContEquivBObj;
import com.dwl.tcrm.coreParty.component.TCRMPartyBObj;
import com.dwl.tcrm.coreParty.component.TCRMPartyComponent;
import com.dwl.tcrm.coreParty.component.TCRMPartyIdentificationBObj;
import com.dwl.tcrm.coreParty.component.TCRMPersonBObj;
import com.dwl.tcrm.coreParty.constant.TCRMCoreComponentID;
import com.dwl.tcrm.coreParty.constant.TCRMCoreErrorReasonCode;
import com.dwl.tcrm.exception.TCRMException;
import com.dwl.tcrm.utilities.TCRMClassFactory;
import com.dwl.unifi.tx.exception.BusinessProxyException;
import com.ibm.mdm.common.codetype.interfaces.CodeTypeComponentHelper;
import com.ibm.mdm.common.codetype.obj.CodeTypeBObj;
import com.ibm.mdm.dsea.arch.component.DeletePartyBObj;
import com.ibm.mdm.dsea.arch.component.MaintainCompanyObjectBObj;
import com.ibm.mdm.dsea.arch.component.MaintainIndividualObjectBObj;
import com.ibm.mdm.dsea.arch.constant.DSEAArchSimplificationComponentID;
import com.ibm.mdm.dsea.arch.constant.DSEAArchSimplificationErrorReasonCode;
import com.ibm.mdm.dsea.arch.constant.DSEACompositeArchConstant;
import com.ibm.daimler.dsea.component.DSEAAdditionsExtsComponent;
import com.ibm.daimler.dsea.component.XAddressBObjExt;
import com.ibm.daimler.dsea.component.XAddressGroupBObjExt;
import com.ibm.daimler.dsea.component.XContEquivBObjExt;
import com.ibm.daimler.dsea.component.XContactMethodGroupBObjExt;
import com.ibm.daimler.dsea.component.XDataSharingBObj;
import com.ibm.daimler.dsea.component.XIdentifierBObjExt;
import com.ibm.daimler.dsea.component.XOrgBObjExt;
import com.ibm.daimler.dsea.component.XOrgNameBObjExt;
import com.ibm.daimler.dsea.component.XPersonBObjExt;
import com.ibm.daimler.dsea.component.XPersonNameBObjExt;
import com.ibm.daimler.dsea.component.XPreferenceBObj;
import com.ibm.daimler.dsea.component.XPrivacyAgreementBObj;


public class ValidationUtilArch extends DWLTxnBP {

	private final static com.dwl.base.logging.IDWLLogger logger = com.dwl.base.logging.DWLLoggerManager
			.getLogger(ValidationUtilArch.class);
	private static IDWLErrorMessage errHandler;
	private TCRMPartyIdentificationBObj tCRMPartyIdentificationBObj;
	protected StringBuffer sb = new StringBuffer();

	public ValidationUtilArch() {
		// TODO Auto-generated constructor stub
		super();
		errHandler = TCRMClassFactory.getErrorHandler();
	}

	public DWLError validateMaintainIndividual(DWLCommon topLevelObject,
			DWLControl control) throws BusinessProxyException {
		DWLError error = null;
		// TODO Auto-generated method stub
		if (!(topLevelObject instanceof MaintainIndividualObjectBObj)) {
			// MDM_TODO0: CDKWB0014I optionally use a more appropriate error
			// code than
			// "MAINTAININDIVIDUAL_FAILED".
			error = errHandler
					.getErrorMessage(
							DSEAArchSimplificationComponentID.MAINTAIN_INDIVIDUAL_BUSINESS_PROXY,
							"INSERR",
							DSEAArchSimplificationErrorReasonCode.MAINTAININDIVIDUAL_FAILED,
							control, new String[0]);
			// throw new BusinessProxyException(error.getErrorMessage());
			return error;
		}

		// Market Name Null | Throw Error
		boolean isUCIDPresent = false;
		boolean isSFDCIdPresent = false;
		MaintainIndividualObjectBObj mainInput = (MaintainIndividualObjectBObj) topLevelObject;
		XPersonBObjExt inputPersonBObj = (XPersonBObjExt) mainInput
				.getTCRMPersonBObj();

		String marketName = inputPersonBObj.getXMarketName();

		if (marketName == null
				|| (!marketName
						.equalsIgnoreCase(DSEACompositeArchConstant.MARKET_NAME_KOREA)
						&& (!marketName
								.equalsIgnoreCase(DSEACompositeArchConstant.MARKET_NAME_THAILAND) && (!marketName
								.equalsIgnoreCase(DSEACompositeArchConstant.MARKET_NAME_MALAYSIA)))
						&& !marketName
								.equalsIgnoreCase(DSEACompositeArchConstant.MARKET_NAME_EGYPT)
						&& !marketName
								.equalsIgnoreCase(DSEACompositeArchConstant.MARKET_NAME_AUSTRALIA)
						&& !marketName
								.equalsIgnoreCase(DSEACompositeArchConstant.MARKET_NAME_NEWZEALAND)
						&& !marketName
								.equalsIgnoreCase(DSEACompositeArchConstant.MARKET_NAME_INDIA)
						&& !marketName
								.equalsIgnoreCase(DSEACompositeArchConstant.MARKET_NAME_JAPAN)
						&& !marketName
								.equalsIgnoreCase(DSEACompositeArchConstant.MARKET_NAME_INDONESIA)
						&& !marketName
								.equalsIgnoreCase(DSEACompositeArchConstant.MARKET_NAME_VIETNAM) 
						&& !marketName
								.equalsIgnoreCase(DSEACompositeArchConstant.MARKET_NAME_SINGAPORE)
						&& !marketName
								.equalsIgnoreCase(DSEACompositeArchConstant.MARKET_NAME_TURKEY)
						&& !marketName
								.equalsIgnoreCase(DSEACompositeArchConstant.MARKET_NAME_MIDDLEEAST))) {

			error = errHandler
					.getErrorMessage(
							DSEAArchSimplificationComponentID.MAINTAIN_INDIVIDUAL_BUSINESS_PROXY,
							DWLErrorCode.FIELD_VALIDATION_ERROR,
							DSEAArchSimplificationErrorReasonCode.MARKET_NAME_INVALID,
							control, new String[0]);
			// throw new BusinessProxyException(error.getErrorMessage());
			return error;
		}

		Vector<XContEquivBObjExt> vecContEquivBObj = inputPersonBObj
				.getItemsTCRMAdminContEquivBObj();
		Vector<XIdentifierBObjExt> vecIdentBobjs = inputPersonBObj
				.getItemsTCRMPartyIdentificationBObj();

		if (null != marketName
				&& StringUtils.isNonBlank(marketName)
				&& (marketName
						.equalsIgnoreCase(DSEACompositeArchConstant.MARKET_NAME_AUSTRALIA)
						|| marketName
								.equalsIgnoreCase(DSEACompositeArchConstant.MARKET_NAME_NEWZEALAND)
						|| marketName
								.equalsIgnoreCase(DSEACompositeArchConstant.MARKET_NAME_THAILAND)
						|| marketName
								.equalsIgnoreCase(DSEACompositeArchConstant.MARKET_NAME_MALAYSIA) 
						|| marketName
							.equalsIgnoreCase(DSEACompositeArchConstant.MARKET_NAME_INDIA)
						|| marketName
							.equalsIgnoreCase(DSEACompositeArchConstant.MARKET_NAME_TURKEY))) {

			// if market is AU, NZ, MYS, THA, IND, TUR then look for UCID in
			// identifier  
			// ucid should have 19 digits and start with "34" or "35" or "30"
			

			for (XIdentifierBObjExt vecIdentBobj : vecIdentBobjs) {
				if(null != vecIdentBobj.getIdentificationType() 
						&& vecIdentBobj.getIdentificationType().equalsIgnoreCase(
						DSEACompositeArchConstant.IDENTIFIER_UCID_TYPE)){
			
				if (null != vecIdentBobj.getIdentificationNumber()
						&& vecIdentBobj.getIdentificationNumber().length() == 19
						&& (vecIdentBobj.getIdentificationNumber().startsWith(
								"34") || vecIdentBobj.getIdentificationNumber().startsWith(
										"35") || vecIdentBobj.getIdentificationNumber().startsWith(
												"30"))) {

							isUCIDPresent = true;
						
					}
				
				}
				
			}
			

			for (XContEquivBObjExt XContEquivObject : vecContEquivBObj) {
				// If SFDC Id present
				if (null != XContEquivObject.getAdminSystemType() 
						&& XContEquivObject.getAdminSystemType().equalsIgnoreCase(
						DSEACompositeArchConstant.SFDC_TYPE)) {
					if (null != XContEquivObject.getAdminPartyId()
							&& StringUtils.isNonBlank(XContEquivObject
							.getAdminPartyId())) {
						isSFDCIdPresent = true;
					}
				}
			}
		}
		
		else if(null != marketName
				&& StringUtils.isNonBlank(marketName)
				&& (marketName
						.equalsIgnoreCase(DSEACompositeArchConstant.MARKET_NAME_VIETNAM)
						|| marketName
								.equalsIgnoreCase(DSEACompositeArchConstant.MARKET_NAME_SINGAPORE)
						|| marketName
								.equalsIgnoreCase(DSEACompositeArchConstant.MARKET_NAME_INDONESIA)
						|| marketName
								.equalsIgnoreCase(DSEACompositeArchConstant.MARKET_NAME_JAPAN)
						|| marketName
								.equalsIgnoreCase(DSEACompositeArchConstant.MARKET_NAME_MIDDLEEAST)))
		{

			// If market name is ID,VN,SG,Jpn, ME then check for UCID in ContEquiv
			
			

			for (XContEquivBObjExt XContEquivObject : vecContEquivBObj) {
				// If SFDC Id present
				if (null != XContEquivObject.getAdminSystemType() 
						&& XContEquivObject.getAdminSystemType().equalsIgnoreCase(
						DSEACompositeArchConstant.SFDC_TYPE)) {
					if (null != XContEquivObject.getAdminPartyId() 
							&&StringUtils.isNonBlank(XContEquivObject
							.getAdminPartyId())) {
						isSFDCIdPresent = true;
						if ( marketName
								.equalsIgnoreCase(DSEACompositeArchConstant.MARKET_NAME_JAPAN) && (XContEquivObject.getDescription()== null || XContEquivObject.getDescription().isEmpty())){
						XContEquivObject.setDescription(DSEACompositeArchConstant.MASTER_KEY);
						}
					}
				}
				
				//Ucid should have 19 digits and starts with "34" or "35" or "30"
				if(null !=  XContEquivObject.getAdminSystemType()  
						&& XContEquivObject.getAdminSystemType().equalsIgnoreCase(DSEACompositeArchConstant.UCID_TYPE)){
					if (null != XContEquivObject.getAdminPartyId() && StringUtils.isNonBlank(XContEquivObject.getAdminPartyId())
							&& XContEquivObject.getAdminPartyId().length() == 19
							&& (XContEquivObject.getAdminPartyId().startsWith(
									"34") || XContEquivObject.getAdminPartyId().startsWith(
											"35") || XContEquivObject.getAdminPartyId().startsWith(
													"30"))) {
	
								isUCIDPresent = true;
								if ( marketName
										.equalsIgnoreCase(DSEACompositeArchConstant.MARKET_NAME_JAPAN) && (XContEquivObject.getDescription()== null || XContEquivObject.getDescription().isEmpty())){
								XContEquivObject.setDescription(DSEACompositeArchConstant.MASTER_KEY);
								}
							
					} 
				}
				
			}
		
		}
		
		else {
			for (XContEquivBObjExt XContEquivObject : vecContEquivBObj) {
				// If UCID Present |
				if (XContEquivObject.getAdminSystemType().equalsIgnoreCase(
						DSEACompositeArchConstant.UCID_TYPE)) {
					if (StringUtils.isNonBlank(XContEquivObject
							.getAdminPartyId())) {
						isUCIDPresent = true;
					}
				}
				
				//If SFDC Id present
				if (XContEquivObject.getAdminSystemType().equalsIgnoreCase(
						DSEACompositeArchConstant.SFDC_TYPE)) {
					if (StringUtils.isNonBlank(XContEquivObject
							.getAdminPartyId())) {
						isSFDCIdPresent = true;
					}
				}
			}
		}

		if (!isUCIDPresent) {
			error = errHandler
					.getErrorMessage(
							DSEAArchSimplificationComponentID.MAINTAIN_INDIVIDUAL_BUSINESS_PROXY,
							DWLErrorCode.FIELD_VALIDATION_ERROR,
							DSEAArchSimplificationErrorReasonCode.UCID_INVALID,
							control, new String[0]);
			// throw new BusinessProxyException(error.getErrorMessage());
			return error;
		}

		if (!isSFDCIdPresent) {
			error = errHandler
					.getErrorMessage(
							DSEAArchSimplificationComponentID.MAINTAIN_INDIVIDUAL_BUSINESS_PROXY,
							DWLErrorCode.FIELD_VALIDATION_ERROR,
							DSEAArchSimplificationErrorReasonCode.SFDCID_INVALID,
							control, new String[0]);
			// throw new BusinessProxyException(error.getErrorMessage());
			return error;
		}
		return error;
	}
    /**
     * 
     * @param inputPersonBObj
     * @return
     */
	public String getSFDCIdFromInputPerson(XPersonBObjExt inputPersonBObj) {
		String sfdcId = null;
		Vector<XContEquivBObjExt> vecContEquivBObj = inputPersonBObj
				.getItemsTCRMAdminContEquivBObj();

		for (XContEquivBObjExt XContEquivObject : vecContEquivBObj) {

			if (XContEquivObject.getAdminSystemType().equalsIgnoreCase(
					DSEACompositeArchConstant.SFDC_TYPE)) {

				sfdcId = XContEquivObject.getAdminPartyId();
			}
		}

		return sfdcId;
	}
	/**
	 * 
	 * @param inputPersonBObj
	 * @return
	 */
	public String getUCIDFromInputPerson(XPersonBObjExt inputPersonBObj) {
		String uCID = null;
		Vector<XContEquivBObjExt> vecContEquivBObj = inputPersonBObj
				.getItemsTCRMAdminContEquivBObj();

		for (XContEquivBObjExt XContEquivObject : vecContEquivBObj) {

			if (XContEquivObject.getAdminSystemType().equalsIgnoreCase(
					DSEACompositeArchConstant.UCID_TYPE)) {

				uCID = XContEquivObject.getAdminPartyId();
			}
		}

		return uCID;
	}
	/**
	 * 
	 * @param inputOrgBObj
	 * @return
	 */
	public String getSFDCIdFromInputCompany(XOrgBObjExt inputOrgBObj) {
		String sfdcId = null;
		Vector<XContEquivBObjExt> vecContEquivBObj = inputOrgBObj
				.getItemsTCRMAdminContEquivBObj();

		for (XContEquivBObjExt XContEquivObject : vecContEquivBObj) {

			if (XContEquivObject.getAdminSystemType().equalsIgnoreCase(
					DSEACompositeArchConstant.SFDC_TYPE)) {

				sfdcId = XContEquivObject.getAdminPartyId();
			}
		}

		return sfdcId;
	}
	/**
	 * 
	 * @param inputOrgBObj
	 * @return
	 */
	public String getUCIDFromInputCompany(XOrgBObjExt inputOrgBObj) {
		String uCID = null;
		Vector<XContEquivBObjExt> vecContEquivBObj = inputOrgBObj
				.getItemsTCRMAdminContEquivBObj();

		for (XContEquivBObjExt XContEquivObject : vecContEquivBObj) {

			if (XContEquivObject.getAdminSystemType().equalsIgnoreCase(
					DSEACompositeArchConstant.UCID_TYPE)) {

				uCID = XContEquivObject.getAdminPartyId();
			}
		}

		return uCID;
	}
	/**
	 * 
	 * @param sfdcId
	 * @param control
	 * @return
	 * @throws BusinessProxyException
	 * @throws SQLException
	 */
	public String getPartyIdBySFDCId(String sfdcId, DWLControl control)
			throws BusinessProxyException, SQLException {

		SQLQuery sqlQuery = new SQLQuery();
		ResultSet objResultSet = null;
		String partyIdSql = null;
		String contId = null;
		List<SQLParam> params = new ArrayList<SQLParam>();

		try {

			partyIdSql = DSEACompositeArchConstant.GET_PARTY_ID_BY_SFDCID;

			params = new ArrayList<SQLParam>();
			params.add(0, new SQLParam(sfdcId));

			objResultSet = sqlQuery.executeQuery(partyIdSql, params);
			if (objResultSet.next()) {
				contId = objResultSet
						.getString(DSEACompositeArchConstant.PARTY_ID);
			}

		} catch (Exception ex) {
			ex.printStackTrace();
			DWLError error = errHandler
					.getErrorMessage(
							DSEAArchSimplificationComponentID.MAINTAIN_INDIVIDUAL_BUSINESS_PROXY,
							"READERR",
							DSEAArchSimplificationErrorReasonCode.MAINTAIN_INDIVIDUAL_GETPARTY_FAILED,
							control, new String[0]);
			throw new BusinessProxyException(error.getErrorMessage());

		} finally {
			if (objResultSet != null)
				objResultSet.close();
			sqlQuery.close();
		}

		return contId;
	}
	
	/**
	 * 
	 * @param uCID
	 * @param control
	 * @return
	 * @throws BusinessProxyException
	 * @throws SQLException
	 */
	public String getPartyIdByUCID(String uCID, DWLControl control)
			throws BusinessProxyException, SQLException {

		SQLQuery sqlQuery = new SQLQuery();
		ResultSet objResultSet = null;
		String partyIdSql = null;
		String contId = null;
		List<SQLParam> params = new ArrayList<SQLParam>();

		try {

			partyIdSql = DSEACompositeArchConstant.GET_PARTY_ID_BY_UCID;

			params = new ArrayList<SQLParam>();
			params.add(0, new SQLParam(uCID));

			objResultSet = sqlQuery.executeQuery(partyIdSql, params);
			if (objResultSet.next()) {
				contId = objResultSet
						.getString(DSEACompositeArchConstant.PARTY_ID);
			}

		} catch (Exception ex) {
			ex.printStackTrace();
			DWLError error = errHandler
					.getErrorMessage(
							DSEAArchSimplificationComponentID.MAINTAIN_INDIVIDUAL_BUSINESS_PROXY,
							"READERR",
							DSEAArchSimplificationErrorReasonCode.MAINTAIN_INDIVIDUAL_GETPARTY_FAILED,
							control, new String[0]);
			throw new BusinessProxyException(error.getErrorMessage());

		} finally {
			if (objResultSet != null)
				objResultSet.close();
			sqlQuery.close();
		}

		return contId;
	}
	/**
	 * 
	 * @param personResponseBObj
	 * @param additionsExtsComponent
	 * @param inputPersonBObj
	 * @param control
	 * @return
	 * @throws BusinessProxyException
	 */
	public XPersonBObjExt createPersonWholesale(
			XPersonBObjExt personResponseBObj,
			DSEAAdditionsExtsComponent additionsExtsComponent,
			XPersonBObjExt inputPersonBObj, DWLControl control)
			throws BusinessProxyException {
		// TODO Auto-generated method stub

		DWLResponse addUpdatePartyResponse = null;

		// Add Person transaction
		addUpdatePartyResponse = mdmTransaction(
				inputPersonBObj,
				control,
				DSEACompositeArchConstant.ADD_PERSON_TXN,
				DSEAArchSimplificationComponentID.MAINTAIN_INDIVIDUAL_BUSINESS_PROXY);
		throwExceptionifTXNFail(addUpdatePartyResponse, sb);

		if (addUpdatePartyResponse != null) {
			personResponseBObj = (XPersonBObjExt) addUpdatePartyResponse
					.getData();

			if (personResponseBObj == null) {

				throwExceptionifTXNFail(addUpdatePartyResponse, sb);

			} else if (personResponseBObj.getStatus().getStatus() == DWLStatus.FATAL) {

				throwExceptionifTXNFail(addUpdatePartyResponse, sb);

			}

		} else {

			throwExceptionifTXNFail(addUpdatePartyResponse, sb);
		}

		return personResponseBObj;
	}

	public XPersonBObjExt updatePersonWholesale(
			XPersonBObjExt personResponseBObj,
			DSEAAdditionsExtsComponent additionsExtsComponent,
			XPersonBObjExt inputPersonBObj, XPersonBObjExt outputPersonBObj,
			DWLControl control, String partyId) throws Exception {
		// TODO Auto-generated method stub

		DWLResponse addUpdatePartyResponse = null;
		XPersonBObjExt existingPersonBObj = new XPersonBObjExt();
		TCRMPartyComponent partyComponent = new TCRMPartyComponent();
		XPersonBObjExt requestBObj = new XPersonBObjExt();
		String marketName;
		XContEquivBObjExt existingUCIDBObj = new XContEquivBObjExt();
		XContEquivBObjExt existingSFDCBObj = new XContEquivBObjExt();

		try {
			existingPersonBObj = (XPersonBObjExt) partyComponent.getPerson(
					partyId, "2", control);
		}
		// throw error if Get Person Failed
		catch (TCRMException e) {
			e.printStackTrace();

			DWLError error = errHandler
					.getErrorMessage(
							DSEAArchSimplificationComponentID.MAINTAIN_INDIVIDUAL_BUSINESS_PROXY,
							"UPDERR",
							DSEAArchSimplificationErrorReasonCode.MAINTAIN_INDIVIDUAL_UPDATE_FAILED,
							control, new String[0]);
			// vectReqDWLError.add(error);
			throw new BusinessProxyException(error.getErrorMessage());

		}
		// throw error if no person data is fetched
		if (existingPersonBObj == null) {

			DWLError error = errHandler
					.getErrorMessage(
							DSEAArchSimplificationComponentID.MAINTAIN_INDIVIDUAL_BUSINESS_PROXY,
							"UPDERR",
							DSEAArchSimplificationErrorReasonCode.MAINTAIN_INDIVIDUAL_UPDATE_FAILED,
							control, new String[0]);
			// vectReqDWLError.add(error);
			throw new BusinessProxyException(error.getErrorMessage());
		}

		// Update the mainInputBObj for the updatePerson transaction

		setUpdatePersonBObj(inputPersonBObj, requestBObj, existingPersonBObj,
				control);

		// Changed for marketName CMPVAL
		marketName = inputPersonBObj.getXMarketName();
		// Changed for marketName CMPVAL

		// Compare the request BObjs with existing BObjs
		comparePersonNameBObjsForUpdate(existingPersonBObj, inputPersonBObj,
				control);
		comparePartyIdentificationBObjsForUpdate(existingPersonBObj,
				inputPersonBObj, control);
		comparePartyAddressBObjsForUpdate(existingPersonBObj, inputPersonBObj,
				control);
		comparePartyContactMethodBObjsForUpdate(existingPersonBObj,
				inputPersonBObj, control);
		compareAdminContEquivBObjsForUpdate(existingPersonBObj,
				inputPersonBObj, control);

		// Changed for marketName CMPVAL (25 May 2018)
		control.put("marketName", marketName);
		// Changed for marketName CMPVAL (25 May 2018)

		// Run the updateOrg Transaction
		// System.out.println(inputPersonBObj.toXML());
		inputPersonBObj.setControl(control);
		addUpdatePartyResponse = mdmTransaction(
				inputPersonBObj,
				control,
				DSEACompositeArchConstant.UPDATE_PERSON_TXN,
				DSEAArchSimplificationComponentID.MAINTAIN_INDIVIDUAL_BUSINESS_PROXY);
		throwExceptionifTXNFail(addUpdatePartyResponse, sb);

		if (addUpdatePartyResponse != null) {

			personResponseBObj = (XPersonBObjExt) addUpdatePartyResponse
					.getData();

			if (personResponseBObj == null) {

				throwExceptionifTXNFail(addUpdatePartyResponse, sb);

			} else if (personResponseBObj.getStatus().getStatus() == DWLStatus.FATAL) {

				throwExceptionifTXNFail(addUpdatePartyResponse, sb);
			}
		} else {

			throwExceptionifTXNFail(addUpdatePartyResponse, sb);
		}
		// Set Response Objects
		// Set UCID in response
		/*
		 * Vector<XContEquivBObjExt> existingContEquivBObjs =
		 * existingPersonBObj.getItemsTCRMAdminContEquivBObj();
		 * 
		 * for(XContEquivBObjExt contEquivBObj : existingContEquivBObjs){
		 * if(DSEACompositeArchConstant
		 * .UCID_TYPE.equalsIgnoreCase(contEquivBObj.getAdminSystemType())){ if
		 * ("Y".equalsIgnoreCase(contEquivBObj.getDescription())) {
		 * existingUCIDBObj = contEquivBObj; } } else if
		 * (DSEACompositeArchConstant
		 * .SFDC_TYPE.equalsIgnoreCase(contEquivBObj.getAdminSystemType()) &&
		 * contEquivBObj.getXRetailerId() == null) if
		 * ("Y".equalsIgnoreCase(contEquivBObj.getDescription())) {
		 * existingSFDCBObj = contEquivBObj; } }
		 */
		personResponseBObj.setTCRMAdminContEquivBObj(existingUCIDBObj);

		return personResponseBObj;

	}
	
	public XPersonBObjExt updatePersonWholesaleTHAMYS(
			XPersonBObjExt personResponseBObj,
			DSEAAdditionsExtsComponent additionsExtsComponent,
			XPersonBObjExt inputPersonBObj, XPersonBObjExt outputPersonBObj,
			DWLControl control, String partyId) throws Exception {
		// TODO Auto-generated method stub

		DWLResponse addUpdatePartyResponse = null;
		XPersonBObjExt existingPersonBObj = new XPersonBObjExt();
		TCRMPartyComponent partyComponent = new TCRMPartyComponent();
		XPersonBObjExt requestBObj = new XPersonBObjExt();
		String marketName;
		XContEquivBObjExt existingUCIDBObj = new XContEquivBObjExt();
		XContEquivBObjExt existingSFDCBObj = new XContEquivBObjExt();

		try {
			existingPersonBObj = (XPersonBObjExt) partyComponent.getPerson(
					partyId, "2", control);
		}
		// throw error if Get Person Failed
		catch (TCRMException e) {
			e.printStackTrace();

			DWLError error = errHandler
					.getErrorMessage(
							DSEAArchSimplificationComponentID.MAINTAIN_INDIVIDUAL_BUSINESS_PROXY,
							"UPDERR",
							DSEAArchSimplificationErrorReasonCode.MAINTAIN_INDIVIDUAL_UPDATE_FAILED,
							control, new String[0]);
			// vectReqDWLError.add(error);
			throw new BusinessProxyException(error.getErrorMessage());

		}
		// throw error if no person data is fetched
		if (existingPersonBObj == null) {

			DWLError error = errHandler
					.getErrorMessage(
							DSEAArchSimplificationComponentID.MAINTAIN_INDIVIDUAL_BUSINESS_PROXY,
							"UPDERR",
							DSEAArchSimplificationErrorReasonCode.MAINTAIN_INDIVIDUAL_UPDATE_FAILED,
							control, new String[0]);
			// vectReqDWLError.add(error);
			throw new BusinessProxyException(error.getErrorMessage());
		}

		// Update the mainInputBObj for the updatePerson transaction

		setUpdatePersonBObj(inputPersonBObj, requestBObj, existingPersonBObj,
				control);

		// Changed for marketName CMPVAL
		marketName = inputPersonBObj.getXMarketName();
		// Changed for marketName CMPVAL

		// Compare the request BObjs with existing BObjs
		comparePersonNameBObjsForUpdate(existingPersonBObj, inputPersonBObj,
				control);
		comparePartyIdentificationBObjsForUpdate(existingPersonBObj,
				inputPersonBObj, control);
		comparePartyAddressBObjsForUpdate(existingPersonBObj, inputPersonBObj,
				control);
		comparePartyContactMethodBObjsForUpdate(existingPersonBObj,
				inputPersonBObj, control);
		compareAdminContEquivBObjsForUpdateNoDescription(existingPersonBObj,
				inputPersonBObj, control);

		// Changed for marketName CMPVAL (25 May 2018)
		control.put("marketName", marketName);
		// Changed for marketName CMPVAL (25 May 2018)

		// Run the updateOrg Transaction
		// System.out.println(inputPersonBObj.toXML());
		inputPersonBObj.setControl(control);
		addUpdatePartyResponse = mdmTransaction(
				inputPersonBObj,
				control,
				DSEACompositeArchConstant.UPDATE_PERSON_TXN,
				DSEAArchSimplificationComponentID.MAINTAIN_INDIVIDUAL_BUSINESS_PROXY);
		throwExceptionifTXNFail(addUpdatePartyResponse, sb);

		if (addUpdatePartyResponse != null) {

			personResponseBObj = (XPersonBObjExt) addUpdatePartyResponse
					.getData();

			if (personResponseBObj == null) {

				throwExceptionifTXNFail(addUpdatePartyResponse, sb);

			} else if (personResponseBObj.getStatus().getStatus() == DWLStatus.FATAL) {

				throwExceptionifTXNFail(addUpdatePartyResponse, sb);
			}
		} else {

			throwExceptionifTXNFail(addUpdatePartyResponse, sb);
		}
		// Set Response Objects
		// Set UCID in response
		/*
		 * Vector<XContEquivBObjExt> existingContEquivBObjs =
		 * existingPersonBObj.getItemsTCRMAdminContEquivBObj();
		 * 
		 * for(XContEquivBObjExt contEquivBObj : existingContEquivBObjs){
		 * if(DSEACompositeArchConstant
		 * .UCID_TYPE.equalsIgnoreCase(contEquivBObj.getAdminSystemType())){ if
		 * ("Y".equalsIgnoreCase(contEquivBObj.getDescription())) {
		 * existingUCIDBObj = contEquivBObj; } } else if
		 * (DSEACompositeArchConstant
		 * .SFDC_TYPE.equalsIgnoreCase(contEquivBObj.getAdminSystemType()) &&
		 * contEquivBObj.getXRetailerId() == null) if
		 * ("Y".equalsIgnoreCase(contEquivBObj.getDescription())) {
		 * existingSFDCBObj = contEquivBObj; } }
		 */
		personResponseBObj.setTCRMAdminContEquivBObj(existingUCIDBObj);

		return personResponseBObj;

	}
	
	public XPersonBObjExt updatePersonWholesaleTUR(
			XPersonBObjExt personResponseBObj,
			DSEAAdditionsExtsComponent additionsExtsComponent,
			XPersonBObjExt inputPersonBObj, XPersonBObjExt outputPersonBObj,
			DWLControl control, String partyId) throws Exception {
		// TODO Auto-generated method stub

		DWLResponse addUpdatePartyResponse = null;
		XPersonBObjExt existingPersonBObj = new XPersonBObjExt();
		TCRMPartyComponent partyComponent = new TCRMPartyComponent();
		XPersonBObjExt requestBObj = new XPersonBObjExt();
		String marketName;
		XContEquivBObjExt existingUCIDBObj = new XContEquivBObjExt();
		XContEquivBObjExt existingSFDCBObj = new XContEquivBObjExt();

		try {
			existingPersonBObj = (XPersonBObjExt) partyComponent.getPerson(
					partyId, "2", control);
		}
		// throw error if Get Person Failed
		catch (TCRMException e) {
			e.printStackTrace();

			DWLError error = errHandler
					.getErrorMessage(
							DSEAArchSimplificationComponentID.MAINTAIN_INDIVIDUAL_BUSINESS_PROXY,
							"UPDERR",
							DSEAArchSimplificationErrorReasonCode.MAINTAIN_INDIVIDUAL_UPDATE_FAILED,
							control, new String[0]);
			// vectReqDWLError.add(error);
			throw new BusinessProxyException(error.getErrorMessage());

		}
		// throw error if no person data is fetched
		if (existingPersonBObj == null) {

			DWLError error = errHandler
					.getErrorMessage(
							DSEAArchSimplificationComponentID.MAINTAIN_INDIVIDUAL_BUSINESS_PROXY,
							"UPDERR",
							DSEAArchSimplificationErrorReasonCode.MAINTAIN_INDIVIDUAL_UPDATE_FAILED,
							control, new String[0]);
			// vectReqDWLError.add(error);
			throw new BusinessProxyException(error.getErrorMessage());
		}

		// Update the mainInputBObj for the updatePerson transaction

		setUpdatePersonBObj(inputPersonBObj, requestBObj, existingPersonBObj,
				control);

		// Changed for marketName CMPVAL
		marketName = inputPersonBObj.getXMarketName();
		// Changed for marketName CMPVAL

		// Compare the request BObjs with existing BObjs
		comparePersonNameBObjsForUpdate(existingPersonBObj, inputPersonBObj,
				control);
		comparePartyIdentificationBObjsForUpdate(existingPersonBObj,
				inputPersonBObj, control);
		comparePartyAddressBObjsForUpdateME(existingPersonBObj, inputPersonBObj,
				control);
		comparePartyContactMethodBObjsForUpdate(existingPersonBObj,
				inputPersonBObj, control);
		compareAdminContEquivBObjsForUpdateNoDescription(existingPersonBObj,
				inputPersonBObj, control);

		// Changed for marketName CMPVAL (25 May 2018)
		control.put("marketName", marketName);
		// Changed for marketName CMPVAL (25 May 2018)

		// Run the updateOrg Transaction
		// System.out.println(inputPersonBObj.toXML());
		inputPersonBObj.setControl(control);
		addUpdatePartyResponse = mdmTransaction(
				inputPersonBObj,
				control,
				DSEACompositeArchConstant.UPDATE_PERSON_TXN,
				DSEAArchSimplificationComponentID.MAINTAIN_INDIVIDUAL_BUSINESS_PROXY);
		throwExceptionifTXNFail(addUpdatePartyResponse, sb);

		if (addUpdatePartyResponse != null) {

			personResponseBObj = (XPersonBObjExt) addUpdatePartyResponse
					.getData();

			if (personResponseBObj == null) {

				throwExceptionifTXNFail(addUpdatePartyResponse, sb);

			} else if (personResponseBObj.getStatus().getStatus() == DWLStatus.FATAL) {

				throwExceptionifTXNFail(addUpdatePartyResponse, sb);
			}
		} else {

			throwExceptionifTXNFail(addUpdatePartyResponse, sb);
		}
		personResponseBObj.setTCRMAdminContEquivBObj(existingUCIDBObj);

		return personResponseBObj;

	}

	public XPersonBObjExt updatePersonWholesaleCL1(
			XPersonBObjExt personResponseBObj,
			DSEAAdditionsExtsComponent additionsExtsComponent,
			XPersonBObjExt inputPersonBObj, XPersonBObjExt outputPersonBObj,
			DWLControl control, String partyId) throws Exception {
		// TODO Auto-generated method stub

		DWLResponse addUpdatePartyResponse = null;
		XPersonBObjExt existingPersonBObj = new XPersonBObjExt();
		TCRMPartyComponent partyComponent = new TCRMPartyComponent();
		XPersonBObjExt requestBObj = new XPersonBObjExt();
		String marketName;
		XContEquivBObjExt existingUCIDBObj = new XContEquivBObjExt();
		XContEquivBObjExt existingSFDCBObj = new XContEquivBObjExt();

		try {
			existingPersonBObj = (XPersonBObjExt) partyComponent.getPerson(
					partyId, "2", control);
		}
		// throw error if Get Person Failed
		catch (TCRMException e) {
			e.printStackTrace();

			DWLError error = errHandler
					.getErrorMessage(
							DSEAArchSimplificationComponentID.MAINTAIN_INDIVIDUAL_BUSINESS_PROXY,
							"UPDERR",
							DSEAArchSimplificationErrorReasonCode.MAINTAIN_INDIVIDUAL_UPDATE_FAILED,
							control, new String[0]);
			// vectReqDWLError.add(error);
			throw new BusinessProxyException(error.getErrorMessage());

		}
		// throw error if no person data is fetched
		if (existingPersonBObj == null) {

			DWLError error = errHandler
					.getErrorMessage(
							DSEAArchSimplificationComponentID.MAINTAIN_INDIVIDUAL_BUSINESS_PROXY,
							"UPDERR",
							DSEAArchSimplificationErrorReasonCode.MAINTAIN_INDIVIDUAL_UPDATE_FAILED,
							control, new String[0]);
			// vectReqDWLError.add(error);
			throw new BusinessProxyException(error.getErrorMessage());
		}

		// Update the mainInputBObj for the updatePerson transaction

		setUpdatePersonBObj(inputPersonBObj, requestBObj, existingPersonBObj,
				control);

		// Changed for marketName CMPVAL
		marketName = inputPersonBObj.getXMarketName();
		// Changed for marketName CMPVAL

		// Compare the request BObjs with existing BObjs
		comparePersonNameBObjsForUpdate(existingPersonBObj, inputPersonBObj,
				control);
		comparePartyIdentificationBObjsForUpdate(existingPersonBObj,
				inputPersonBObj, control);
		comparePartyAddressBObjsForUpdate(existingPersonBObj, inputPersonBObj,
				control);
		comparePartyContactMethodBObjsForUpdate(existingPersonBObj,
				inputPersonBObj, control);
		compareAdminContEquivBObjsForUpdateNoDescription(existingPersonBObj,
				inputPersonBObj, control);

		// Changed for marketName CMPVAL (25 May 2018)
		control.put("marketName", marketName);
		// Changed for marketName CMPVAL (25 May 2018)

		// Run the updateOrg Transaction
		// System.out.println(inputPersonBObj.toXML());
		inputPersonBObj.setControl(control);
		addUpdatePartyResponse = mdmTransaction(
				inputPersonBObj,
				control,
				DSEACompositeArchConstant.UPDATE_PERSON_TXN,
				DSEAArchSimplificationComponentID.MAINTAIN_INDIVIDUAL_BUSINESS_PROXY);
		throwExceptionifTXNFail(addUpdatePartyResponse, sb);

		if (addUpdatePartyResponse != null) {

			personResponseBObj = (XPersonBObjExt) addUpdatePartyResponse
					.getData();

			if (personResponseBObj == null) {

				throwExceptionifTXNFail(addUpdatePartyResponse, sb);

			} else if (personResponseBObj.getStatus().getStatus() == DWLStatus.FATAL) {

				throwExceptionifTXNFail(addUpdatePartyResponse, sb);
			}
		} else {

			throwExceptionifTXNFail(addUpdatePartyResponse, sb);
		}
		// Set Response Objects
		// Set UCID in response
		/*
		 * Vector<XContEquivBObjExt> existingContEquivBObjs =
		 * existingPersonBObj.getItemsTCRMAdminContEquivBObj();
		 * 
		 * for(XContEquivBObjExt contEquivBObj : existingContEquivBObjs){
		 * if(DSEACompositeArchConstant
		 * .UCID_TYPE.equalsIgnoreCase(contEquivBObj.getAdminSystemType())){ if
		 * ("Y".equalsIgnoreCase(contEquivBObj.getDescription())) {
		 * existingUCIDBObj = contEquivBObj; } } else if
		 * (DSEACompositeArchConstant
		 * .SFDC_TYPE.equalsIgnoreCase(contEquivBObj.getAdminSystemType()) &&
		 * contEquivBObj.getXRetailerId() == null) if
		 * ("Y".equalsIgnoreCase(contEquivBObj.getDescription())) {
		 * existingSFDCBObj = contEquivBObj; } }
		 */
		personResponseBObj.setTCRMAdminContEquivBObj(existingUCIDBObj);

		return personResponseBObj;

	}
	
	public XPersonBObjExt updatePersonWholesaleME(
			XPersonBObjExt personResponseBObj,
			DSEAAdditionsExtsComponent additionsExtsComponent,
			XPersonBObjExt inputPersonBObj, XPersonBObjExt outputPersonBObj,
			DWLControl control, String partyId) throws Exception {
		// TODO Auto-generated method stub

		DWLResponse addUpdatePartyResponse = null;
		XPersonBObjExt existingPersonBObj = new XPersonBObjExt();
		TCRMPartyComponent partyComponent = new TCRMPartyComponent();
		XPersonBObjExt requestBObj = new XPersonBObjExt();
		String marketName;
		XContEquivBObjExt existingUCIDBObj = new XContEquivBObjExt();
		XContEquivBObjExt existingSFDCBObj = new XContEquivBObjExt();

		try {
			existingPersonBObj = (XPersonBObjExt) partyComponent.getPerson(
					partyId, "2", control);
		}
		// throw error if Get Person Failed
		catch (TCRMException e) {
			e.printStackTrace();

			DWLError error = errHandler
					.getErrorMessage(
							DSEAArchSimplificationComponentID.MAINTAIN_INDIVIDUAL_BUSINESS_PROXY,
							"UPDERR",
							DSEAArchSimplificationErrorReasonCode.MAINTAIN_INDIVIDUAL_UPDATE_FAILED,
							control, new String[0]);
			// vectReqDWLError.add(error);
			throw new BusinessProxyException(error.getErrorMessage());

		}
		// throw error if no person data is fetched
		if (existingPersonBObj == null) {

			DWLError error = errHandler
					.getErrorMessage(
							DSEAArchSimplificationComponentID.MAINTAIN_INDIVIDUAL_BUSINESS_PROXY,
							"UPDERR",
							DSEAArchSimplificationErrorReasonCode.MAINTAIN_INDIVIDUAL_UPDATE_FAILED,
							control, new String[0]);
			// vectReqDWLError.add(error);
			throw new BusinessProxyException(error.getErrorMessage());
		}

		// Update the mainInputBObj for the updatePerson transaction

		setUpdatePersonBObj(inputPersonBObj, requestBObj, existingPersonBObj,
				control);

		// Changed for marketName CMPVAL
		marketName = inputPersonBObj.getXMarketName();
		// Changed for marketName CMPVAL

		// Compare the request BObjs with existing BObjs
		comparePersonNameBObjsForUpdate(existingPersonBObj, inputPersonBObj,
				control);
		comparePartyIdentificationBObjsForUpdate(existingPersonBObj,
				inputPersonBObj, control);
		comparePartyAddressBObjsForUpdateME(existingPersonBObj, inputPersonBObj,
				control);
		comparePartyContactMethodBObjsForUpdate(existingPersonBObj,
				inputPersonBObj, control);
		compareAdminContEquivBObjsForUpdateNoDescription(existingPersonBObj,
				inputPersonBObj, control);

		// Changed for marketName CMPVAL (25 May 2018)
		control.put("marketName", marketName);
		// Changed for marketName CMPVAL (25 May 2018)

		// Run the updateOrg Transaction
		// System.out.println(inputPersonBObj.toXML());
		inputPersonBObj.setControl(control);
		addUpdatePartyResponse = mdmTransaction(
				inputPersonBObj,
				control,
				DSEACompositeArchConstant.UPDATE_PERSON_TXN,
				DSEAArchSimplificationComponentID.MAINTAIN_INDIVIDUAL_BUSINESS_PROXY);
		throwExceptionifTXNFail(addUpdatePartyResponse, sb);

		if (addUpdatePartyResponse != null) {

			personResponseBObj = (XPersonBObjExt) addUpdatePartyResponse
					.getData();

			if (personResponseBObj == null) {

				throwExceptionifTXNFail(addUpdatePartyResponse, sb);

			} else if (personResponseBObj.getStatus().getStatus() == DWLStatus.FATAL) {

				throwExceptionifTXNFail(addUpdatePartyResponse, sb);
			}
		} else {

			throwExceptionifTXNFail(addUpdatePartyResponse, sb);
		}
		
		personResponseBObj.setTCRMAdminContEquivBObj(existingUCIDBObj);

		return personResponseBObj;

	}


	public XPersonBObjExt updatePersonWholesaleANZ(
			XPersonBObjExt personResponseBObj,
			DSEAAdditionsExtsComponent additionsExtsComponent,
			XPersonBObjExt inputPersonBObj, XPersonBObjExt outputPersonBObj,
			DWLControl control, String partyId) throws Exception {
		// TODO Auto-generated method stub

		DWLResponse addUpdatePartyResponse = null;
		XPersonBObjExt existingPersonBObj = new XPersonBObjExt();
		TCRMPartyComponent partyComponent = new TCRMPartyComponent();
		XPersonBObjExt requestBObj = new XPersonBObjExt();
		String marketName;
		XContEquivBObjExt existingUCIDBObj = new XContEquivBObjExt();
		XContEquivBObjExt existingSFDCBObj = new XContEquivBObjExt();

		try {
			existingPersonBObj = (XPersonBObjExt) partyComponent.getPerson(
					partyId, "2", control);
		}
		// throw error if Get Person Failed
		catch (TCRMException e) {
			e.printStackTrace();

			DWLError error = errHandler
					.getErrorMessage(
							DSEAArchSimplificationComponentID.MAINTAIN_INDIVIDUAL_BUSINESS_PROXY,
							"UPDERR",
							DSEAArchSimplificationErrorReasonCode.MAINTAIN_INDIVIDUAL_UPDATE_FAILED,
							control, new String[0]);
			// vectReqDWLError.add(error);
			throw new BusinessProxyException(error.getErrorMessage());

		}
		// throw error if no person data is fetched
		if (existingPersonBObj == null) {

			DWLError error = errHandler
					.getErrorMessage(
							DSEAArchSimplificationComponentID.MAINTAIN_INDIVIDUAL_BUSINESS_PROXY,
							"UPDERR",
							DSEAArchSimplificationErrorReasonCode.MAINTAIN_INDIVIDUAL_UPDATE_FAILED,
							control, new String[0]);
			// vectReqDWLError.add(error);
			throw new BusinessProxyException(error.getErrorMessage());
		}

		// Update the mainInputBObj for the updatePerson transaction

		setUpdatePersonBObj(inputPersonBObj, requestBObj, existingPersonBObj,
				control);

		// Changed for marketName CMPVAL
		marketName = inputPersonBObj.getXMarketName();
		// Changed for marketName CMPVAL

		// Compare the request BObjs with existing BObjs
		comparePersonNameBObjsForUpdate(existingPersonBObj, inputPersonBObj,
				control);
		comparePartyIdentificationBObjsForUpdate(existingPersonBObj,
				inputPersonBObj, control);
		comparePartyAddressBObjsForUpdateME(existingPersonBObj, inputPersonBObj,
				control);
		comparePartyContactMethodBObjsForUpdate(existingPersonBObj,
				inputPersonBObj, control);
		compareAdminContEquivBObjsForUpdateNoDescription(existingPersonBObj,
				inputPersonBObj, control);

		// Changed for marketName CMPVAL (25 May 2018)
		control.put("marketName", marketName);
		// Changed for marketName CMPVAL (25 May 2018)

		// Run the updateOrg Transaction
		// System.out.println(inputPersonBObj.toXML());
		inputPersonBObj.setControl(control);
		addUpdatePartyResponse = mdmTransaction(
				inputPersonBObj,
				control,
				DSEACompositeArchConstant.UPDATE_PERSON_TXN,
				DSEAArchSimplificationComponentID.MAINTAIN_INDIVIDUAL_BUSINESS_PROXY);
		throwExceptionifTXNFail(addUpdatePartyResponse, sb);

		if (addUpdatePartyResponse != null) {

			personResponseBObj = (XPersonBObjExt) addUpdatePartyResponse
					.getData();

			if (personResponseBObj == null) {

				throwExceptionifTXNFail(addUpdatePartyResponse, sb);

			} else if (personResponseBObj.getStatus().getStatus() == DWLStatus.FATAL) {

				throwExceptionifTXNFail(addUpdatePartyResponse, sb);
			}
		} else {

			throwExceptionifTXNFail(addUpdatePartyResponse, sb);
		}
		// Set Response Objects
		// Set UCID in response
		/*
		 * Vector<XContEquivBObjExt> existingContEquivBObjs =
		 * existingPersonBObj.getItemsTCRMAdminContEquivBObj();
		 * 
		 * for(XContEquivBObjExt contEquivBObj : existingContEquivBObjs){
		 * if(DSEACompositeArchConstant
		 * .UCID_TYPE.equalsIgnoreCase(contEquivBObj.getAdminSystemType())){ if
		 * ("Y".equalsIgnoreCase(contEquivBObj.getDescription())) {
		 * existingUCIDBObj = contEquivBObj; } } else if
		 * (DSEACompositeArchConstant
		 * .SFDC_TYPE.equalsIgnoreCase(contEquivBObj.getAdminSystemType()) &&
		 * contEquivBObj.getXRetailerId() == null) if
		 * ("Y".equalsIgnoreCase(contEquivBObj.getDescription())) {
		 * existingSFDCBObj = contEquivBObj; } }
		 */
		personResponseBObj.setTCRMAdminContEquivBObj(existingUCIDBObj);

		return personResponseBObj;

	}

	public XPersonBObjExt updatePersonWholesaleEG(
			XPersonBObjExt personResponseBObj,
			DSEAAdditionsExtsComponent additionsExtsComponent,
			XPersonBObjExt inputPersonBObj, XPersonBObjExt outputPersonBObj,
			DWLControl control, String partyId) throws Exception {
		// TODO Auto-generated method stub

		DWLResponse addUpdatePartyResponse = null;
		XPersonBObjExt existingPersonBObj = new XPersonBObjExt();
		TCRMPartyComponent partyComponent = new TCRMPartyComponent();
		XPersonBObjExt requestBObj = new XPersonBObjExt();
		String marketName;
		XContEquivBObjExt existingUCIDBObj = new XContEquivBObjExt();
		XContEquivBObjExt existingSFDCBObj = new XContEquivBObjExt();

		try {
			existingPersonBObj = (XPersonBObjExt) partyComponent.getPerson(
					partyId, "2", control);
		}
		// throw error if Get Person Failed
		catch (TCRMException e) {
			e.printStackTrace();

			DWLError error = errHandler
					.getErrorMessage(
							DSEAArchSimplificationComponentID.MAINTAIN_INDIVIDUAL_BUSINESS_PROXY,
							"UPDERR",
							DSEAArchSimplificationErrorReasonCode.MAINTAIN_INDIVIDUAL_UPDATE_FAILED,
							control, new String[0]);
			// vectReqDWLError.add(error);
			throw new BusinessProxyException(error.getErrorMessage());

		}
		// throw error if no person data is fetched
		if (existingPersonBObj == null) {

			DWLError error = errHandler
					.getErrorMessage(
							DSEAArchSimplificationComponentID.MAINTAIN_INDIVIDUAL_BUSINESS_PROXY,
							"UPDERR",
							DSEAArchSimplificationErrorReasonCode.MAINTAIN_INDIVIDUAL_UPDATE_FAILED,
							control, new String[0]);
			// vectReqDWLError.add(error);
			throw new BusinessProxyException(error.getErrorMessage());
		}

		// Update the mainInputBObj for the updatePerson transaction

		setUpdatePersonBObj(inputPersonBObj, requestBObj, existingPersonBObj,
				control);

		// Changed for marketName CMPVAL
		marketName = inputPersonBObj.getXMarketName();
		// Changed for marketName CMPVAL

		// Compare the request BObjs with existing BObjs
		comparePersonNameBObjsForUpdate(existingPersonBObj, inputPersonBObj,
				control);
		comparePartyIdentificationBObjsForUpdate(existingPersonBObj,
				inputPersonBObj, control);
		comparePartyAddressBObjsForUpdate(existingPersonBObj, inputPersonBObj,
				control);
		comparePartyContactMethodBObjsForUpdate(existingPersonBObj,
				inputPersonBObj, control);
		compareAdminContEquivBObjsForUpdateNoDescription(existingPersonBObj,
				inputPersonBObj, control);

		// Changed for marketName CMPVAL (25 May 2018)
		control.put("marketName", marketName);
		// Changed for marketName CMPVAL (25 May 2018)

		// Run the updateOrg Transaction
		// System.out.println(inputPersonBObj.toXML());
		inputPersonBObj.setControl(control);
		addUpdatePartyResponse = mdmTransaction(
				inputPersonBObj,
				control,
				DSEACompositeArchConstant.UPDATE_PERSON_TXN,
				DSEAArchSimplificationComponentID.MAINTAIN_INDIVIDUAL_BUSINESS_PROXY);
		throwExceptionifTXNFail(addUpdatePartyResponse, sb);

		if (addUpdatePartyResponse != null) {

			personResponseBObj = (XPersonBObjExt) addUpdatePartyResponse
					.getData();

			if (personResponseBObj == null) {

				throwExceptionifTXNFail(addUpdatePartyResponse, sb);

			} else if (personResponseBObj.getStatus().getStatus() == DWLStatus.FATAL) {

				throwExceptionifTXNFail(addUpdatePartyResponse, sb);
			}
		} else {

			throwExceptionifTXNFail(addUpdatePartyResponse, sb);
		}
		// Set Response Objects
		// Set UCID in response
		/*
		 * Vector<XContEquivBObjExt> existingContEquivBObjs =
		 * existingPersonBObj.getItemsTCRMAdminContEquivBObj();
		 * 
		 * for(XContEquivBObjExt contEquivBObj : existingContEquivBObjs){
		 * if(DSEACompositeArchConstant
		 * .UCID_TYPE.equalsIgnoreCase(contEquivBObj.getAdminSystemType())){ if
		 * ("Y".equalsIgnoreCase(contEquivBObj.getDescription())) {
		 * existingUCIDBObj = contEquivBObj; } } else if
		 * (DSEACompositeArchConstant
		 * .SFDC_TYPE.equalsIgnoreCase(contEquivBObj.getAdminSystemType()) &&
		 * contEquivBObj.getXRetailerId() == null) if
		 * ("Y".equalsIgnoreCase(contEquivBObj.getDescription())) {
		 * existingSFDCBObj = contEquivBObj; } }
		 */
		personResponseBObj.setTCRMAdminContEquivBObj(existingUCIDBObj);

		return personResponseBObj;

	}

	public XPersonBObjExt updatePersonWholesaleIND(
			XPersonBObjExt personResponseBObj,
			DSEAAdditionsExtsComponent additionsExtsComponent,
			XPersonBObjExt inputPersonBObj, XPersonBObjExt outputPersonBObj,
			DWLControl control, String partyId) throws Exception {
		// TODO Auto-generated method stub

		DWLResponse addUpdatePartyResponse = null;
		XPersonBObjExt existingPersonBObj = new XPersonBObjExt();
		TCRMPartyComponent partyComponent = new TCRMPartyComponent();
		XPersonBObjExt requestBObj = new XPersonBObjExt();
		String marketName;
		XContEquivBObjExt existingUCIDBObj = new XContEquivBObjExt();
		XContEquivBObjExt existingSFDCBObj = new XContEquivBObjExt();

		try {
			existingPersonBObj = (XPersonBObjExt) partyComponent.getPerson(
					partyId, "2", control);
		}
		// throw error if Get Person Failed
		catch (TCRMException e) {
			e.printStackTrace();

			DWLError error = errHandler
					.getErrorMessage(
							DSEAArchSimplificationComponentID.MAINTAIN_INDIVIDUAL_BUSINESS_PROXY,
							"UPDERR",
							DSEAArchSimplificationErrorReasonCode.MAINTAIN_INDIVIDUAL_UPDATE_FAILED,
							control, new String[0]);
			// vectReqDWLError.add(error);
			throw new BusinessProxyException(error.getErrorMessage());

		}
		// throw error if no person data is fetched
		if (existingPersonBObj == null) {

			DWLError error = errHandler
					.getErrorMessage(
							DSEAArchSimplificationComponentID.MAINTAIN_INDIVIDUAL_BUSINESS_PROXY,
							"UPDERR",
							DSEAArchSimplificationErrorReasonCode.MAINTAIN_INDIVIDUAL_UPDATE_FAILED,
							control, new String[0]);
			// vectReqDWLError.add(error);
			throw new BusinessProxyException(error.getErrorMessage());
		}

		// Update the mainInputBObj for the updatePerson transaction

		setUpdatePersonBObj(inputPersonBObj, requestBObj, existingPersonBObj,
				control);

		// Changed for marketName CMPVAL
		marketName = inputPersonBObj.getXMarketName();
		// Changed for marketName CMPVAL

		// Compare the request BObjs with existing BObjs
		comparePersonNameBObjsForUpdate(existingPersonBObj, inputPersonBObj,
				control);
		comparePartyIdentificationBObjsForUpdate(existingPersonBObj,
				inputPersonBObj, control);
		comparePartyAddressBObjsForUpdateME(existingPersonBObj, inputPersonBObj,
				control);
		comparePartyContactMethodBObjsForUpdate(existingPersonBObj,
				inputPersonBObj, control);
		compareAdminContEquivBObjsForUpdateNoDescription(existingPersonBObj,
				inputPersonBObj, control);

		// Changed for marketName CMPVAL (25 May 2018)
		control.put("marketName", marketName);
		// Changed for marketName CMPVAL (25 May 2018)

		// Run the updateOrg Transaction
		// System.out.println(inputPersonBObj.toXML());
		inputPersonBObj.setControl(control);
		addUpdatePartyResponse = mdmTransaction(
				inputPersonBObj,
				control,
				DSEACompositeArchConstant.UPDATE_PERSON_TXN,
				DSEAArchSimplificationComponentID.MAINTAIN_INDIVIDUAL_BUSINESS_PROXY);
		throwExceptionifTXNFail(addUpdatePartyResponse, sb);

		if (addUpdatePartyResponse != null) {

			personResponseBObj = (XPersonBObjExt) addUpdatePartyResponse
					.getData();

			if (personResponseBObj == null) {

				throwExceptionifTXNFail(addUpdatePartyResponse, sb);

			} else if (personResponseBObj.getStatus().getStatus() == DWLStatus.FATAL) {

				throwExceptionifTXNFail(addUpdatePartyResponse, sb);
			}
		} else {

			throwExceptionifTXNFail(addUpdatePartyResponse, sb);
		}
		// Set Response Objects
		// Set UCID in response
		/*
		 * Vector<XContEquivBObjExt> existingContEquivBObjs =
		 * existingPersonBObj.getItemsTCRMAdminContEquivBObj();
		 * 
		 * for(XContEquivBObjExt contEquivBObj : existingContEquivBObjs){
		 * if(DSEACompositeArchConstant
		 * .UCID_TYPE.equalsIgnoreCase(contEquivBObj.getAdminSystemType())){ if
		 * ("Y".equalsIgnoreCase(contEquivBObj.getDescription())) {
		 * existingUCIDBObj = contEquivBObj; } } else if
		 * (DSEACompositeArchConstant
		 * .SFDC_TYPE.equalsIgnoreCase(contEquivBObj.getAdminSystemType()) &&
		 * contEquivBObj.getXRetailerId() == null) if
		 * ("Y".equalsIgnoreCase(contEquivBObj.getDescription())) {
		 * existingSFDCBObj = contEquivBObj; } }
		 */
		personResponseBObj.setTCRMAdminContEquivBObj(existingUCIDBObj);

		return personResponseBObj;

	}

	protected TCRMPartyBObj swapSuburb(TCRMPartyBObj partyBobj,
			DWLControl control) {
		// Markets Handled: AU, NZ suburb swap with res num to participate in
		// match, populate in response
		Vector<XAddressGroupBObjExt> partyAddressBObjs = (Vector<XAddressGroupBObjExt>) partyBobj
				.getItemsTCRMPartyAddressBObj();

		for (XAddressGroupBObjExt partyAddressBObj : partyAddressBObjs) {

			XAddressBObjExt xAddress = (XAddressBObjExt) partyAddressBObj
					.getTCRMAddressBObj();
			String residenceNumber = xAddress.getResidenceNumber();
			String xsuburb = xAddress.getXSuburb();
			try {
				xAddress.setXSuburb(residenceNumber);
				xAddress.setResidenceNumber(xsuburb);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		partyBobj.setControl(control);
		return partyBobj;
	}
	
	
	
	public String AddrLineOnecheck(TCRMPartyBObj partyBobj,
			DWLControl control)  {
		
		Vector<XAddressGroupBObjExt> partyAddressBObjs = (Vector<XAddressGroupBObjExt>) partyBobj
				.getItemsTCRMPartyAddressBObj();
		String isAddrline1Null = DSEACompositeArchConstant.FLAG_N;

		for (XAddressGroupBObjExt partyAddressBObj : partyAddressBObjs) {

			XAddressBObjExt xAddress = (XAddressBObjExt) partyAddressBObj
					.getTCRMAddressBObj();
	
				if(StringUtils.isBlank(xAddress.getAddressLineOne())){
					isAddrline1Null = DSEACompositeArchConstant.FLAG_Y;
					break;
				}
			

		}
		
		return isAddrline1Null;
		
	}
	
	
	
	
	/**
	 * 
	 * @param existingPersonBObj
	 * @param mainInput
	 * @param control
	 * @throws Exception
	 */
	public void comparePersonNameBObjsForUpdate(
			TCRMPersonBObj existingPersonBObj, XPersonBObjExt mainInput,
			DWLControl control) throws Exception {
		// TODO Auto-generated method stub

		Vector<XPersonNameBObjExt> existingPersonNameBObjs = existingPersonBObj
				.getItemsTCRMPersonNameBObj();
		Vector<XPersonNameBObjExt> requestPersonNameBObjs = mainInput
				.getItemsTCRMPersonNameBObj();
		String requestFirstName = null;
		String requestLastName = null;
		String dbFirstName = null;
		String dbLastName = null;

		if (requestPersonNameBObjs.size() > 0) {

			for (XPersonNameBObjExt requestPersonNameBObj : requestPersonNameBObjs) {

				String requestNameUsageTp = requestPersonNameBObj
						.getNameUsageType();
				requestFirstName = requestPersonNameBObj.getGivenNameOne();
				requestLastName = requestPersonNameBObj.getLastName();

				for (XPersonNameBObjExt existingPersonNameBObj : existingPersonNameBObjs) {
					// Check with Name Usage Type

					dbFirstName = existingPersonNameBObj.getGivenNameOne();
					dbLastName = existingPersonNameBObj.getLastName();

					if (existingPersonNameBObj.getNameUsageType().equals(
							requestNameUsageTp)) {

						try {
							requestPersonNameBObj.setControl(control);
							requestPersonNameBObj
									.setPersonNameIdPK(existingPersonNameBObj
											.getPersonNameIdPK());
							requestPersonNameBObj
									.setPersonPartyId(existingPersonNameBObj
											.getPersonPartyId());
							requestPersonNameBObj
									.setContId(existingPersonNameBObj
											.getPersonPartyId());
							requestPersonNameBObj
									.setPersonNameLastUpdateDate(existingPersonNameBObj
											.getPersonNameLastUpdateDate());
							requestPersonNameBObj
									.setLastUpdatedDate(existingPersonNameBObj
											.getLastUpdatedDate());

							if (requestFirstName != null
									&& requestLastName != null
									&& dbFirstName != null
									&& dbLastName != null
									&& requestFirstName.equals(dbFirstName)
									&& requestLastName.equals(dbLastName)) {

								requestPersonNameBObj
										.setXLastModifiedSystemDate(existingPersonNameBObj
												.getXLastModifiedSystemDate());
							}

							break;
						} catch (Exception e) {
							// e.printStackTrace();
							DWLError error = errHandler
									.getErrorMessage(
											TCRMCoreComponentID.PERSON_NAME_OBJECT,
											"UPDERR",
											TCRMCoreErrorReasonCode.UPDATE_PERSON_NAME_FAILED,
											control, new String[0]);
							// vectReqDWLError.add(error);
							throw new BusinessProxyException(
									error.getErrorMessage());
						}
					}
				}
			}
		}

	}
	/**
	 * 
	 * @param mainInput
	 * @param control
	 * @param requestName
	 * @param BusinessProxy
	 * @return
	 * @throws BusinessProxyException
	 */
	protected DWLResponse mdmTransaction(TCRMPartyBObj mainInput,
			DWLControl control, String requestName, String BusinessProxy)
			throws BusinessProxyException {
		DWLTxnBP dwlTxnBP = new DWLTxnBP();
		DWLResponse txnResponse = null;
		DWLTransactionPersistent transactionRequest = new DWLTransactionPersistent();
		// XPersonBObjExt reqPersonBObj = (XPersonBObjExt)mainInput;
		transactionRequest.setTxnControl(control);
		transactionRequest.setTxnType(requestName);
		transactionRequest.setTxnTopLevelObject(mainInput);

		try {
			txnResponse = (DWLResponse) dwlTxnBP.execute(transactionRequest);
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessProxyException(e.getMessage());

		}
		return txnResponse;

	}
	
	public DWLResponse runPersistentTransaction(String strTxnName, DWLControl theDWLControl, DWLCommon theDWLCommon)
			throws BusinessProxyException {

		DWLTransactionPersistent transationObj = new DWLTransactionPersistent();
		DWLControl newDwlControl = (DWLControl) theDWLControl.clone();
		newDwlControl.setRequestName(strTxnName);
		transationObj.setTxnControl(newDwlControl);
		theDWLCommon.setControl(newDwlControl);
		transationObj.setTxnType(strTxnName);
		transationObj.setTxnTopLevelObject(theDWLCommon);
		DWLResponse theDWLResponse = (DWLResponse) super.processPersistentObject(transationObj);   
		return theDWLResponse;
	}
	
	
	
	/**
	 * 
	 * @param response
	 * @param sBuffer
	 * @throws BusinessProxyException
	 */
	protected void throwExceptionifTXNFail(DWLResponse response,
			StringBuffer sBuffer) throws BusinessProxyException {
		DWLStatus status;
		Vector<DWLError> error;
		String serr;
		if (response != null) {
			status = response.getStatus();

			error = status.getDwlErrorGroup();

			if (error != null && error.size() > 0 && status != null
					&& status.getStatus() == DWLStatus.FATAL) {

				status.setStatus(DWLStatus.FATAL);

				for (DWLError dw : error) {

					serr = dw.getErrorMessage();

					sBuffer.append("::" + serr);
					// vectReqDWLError.add(dw);

				}

				throw new BusinessProxyException(sBuffer.toString());

			}
		}

	}
	/**
	 * 
	 * @param mainInput
	 * @param requestBObj
	 * @param existingPerBObj
	 * @param control
	 * @throws BusinessProxyException
	 */
	protected void setUpdatePersonBObj(XPersonBObjExt mainInput,
			TCRMPersonBObj requestBObj, XPersonBObjExt existingPerBObj,
			DWLControl control) throws BusinessProxyException {
		try {

			mainInput.setPartyId(existingPerBObj.getPartyId());
			mainInput.setPersonPartyId(existingPerBObj.getPersonPartyId());
			mainInput.setPartyLastUpdateDate(existingPerBObj
					.getPartyLastUpdateDate());

			mainInput.setPersonLastUpdateDate(existingPerBObj
					.getPersonLastUpdateDate());

		} catch (Exception e) {
			logger.finest(e);
			e.printStackTrace();
			DWLError error = errHandler
					.getErrorMessage(
							DSEAArchSimplificationComponentID.MAINTAIN_INDIVIDUAL_BUSINESS_PROXY,
							"UPDERR",
							DSEAArchSimplificationErrorReasonCode.MAINTAIN_INDIVIDUAL_UPDATE_FAILED,
							control, new String[0]);
			// vectReqDWLError.add(error);
			throw new BusinessProxyException(error.getErrorMessage());
		}
	}
	/**
	 * 
	 * @param existingPartyBObj
	 * @param mainInput
	 * @param control
	 * @throws BusinessProxyException
	 */
	protected void comparePartyIdentificationBObjsForUpdate(
			TCRMPartyBObj existingPartyBObj, TCRMPartyBObj mainInput,
			DWLControl control) throws BusinessProxyException {

		Vector<XIdentifierBObjExt> existingIdentificationBObjs = existingPartyBObj
				.getItemsTCRMPartyIdentificationBObj();
		Vector<XIdentifierBObjExt> requestIdentificationBObjs = mainInput
				.getItemsTCRMPartyIdentificationBObj();
		String requestIdentifier = null;
		String dbIdentifier = null;

		if (requestIdentificationBObjs.size() > 0) {

			for (XIdentifierBObjExt requestidBObj : requestIdentificationBObjs) {

				requestIdentifier = requestidBObj.getIdentificationNumber();

				for (XIdentifierBObjExt existingidBObj : existingIdentificationBObjs) {

					dbIdentifier = existingidBObj.getIdentificationNumber();

					try {
						if (requestidBObj.getIdentificationType().equals(
								existingidBObj.getIdentificationType())) {

							requestidBObj.setControl(control);
							requestidBObj.setIdentificationIdPK(existingidBObj
									.getIdentificationIdPK());
							requestidBObj.setPartyId(existingidBObj
									.getPartyId());
							requestidBObj
									.setPartyIdentificationLastUpdateDate(existingidBObj
											.getPartyIdentificationLastUpdateDate());

							if (requestIdentifier.equals(dbIdentifier)) {
								requestidBObj
										.setXLastModifiedSystemDate(existingidBObj
												.getXLastModifiedSystemDate());
							}

							break;
						}

					} catch (Exception e) {
						DWLError error = errHandler
								.getErrorMessage(
										TCRMCoreComponentID.PARTY_IDENTIFICATION_OBJECT,
										"UPDERR",
										TCRMCoreErrorReasonCode.UPDATE_PARTY_IDENTIFICATION_FAILED,
										control, new String[0]);
						// vectReqDWLError.add(error);
						throw new BusinessProxyException(
								error.getErrorMessage());
					}
				}
			}
		}
	}
	/**
	 * 
	 * @param existingPartyBObj
	 * @param mainInput
	 * @param control
	 * @throws BusinessProxyException
	 * @throws Exception
	 */
	protected void comparePartyAddressBObjsForUpdate(
			TCRMPartyBObj existingPartyBObj, TCRMPartyBObj mainInput,
			DWLControl control) throws BusinessProxyException, Exception {

		Vector<XAddressGroupBObjExt> existingPartyAddressBObjs = existingPartyBObj
				.getItemsTCRMPartyAddressBObj();
		Vector<XAddressGroupBObjExt> requestPartyAddressBObjs = mainInput
				.getItemsTCRMPartyAddressBObj();

		ArrayList<String> arrDNDAddressTypes = new ArrayList<String>();

		// --Start changes for Preferred Adress

		XAddressGroupBObjExt dbPreferredAddressBObj = null;

		DWLTxnBP dwlTxnBP = new DWLTxnBP();

		DWLResponse txnResponse = null;

		DWLTransactionPersistent transactionRequest = new DWLTransactionPersistent();

		String timeStamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
				.format(new Date());

		Vector<XAddressGroupBObjExt> existingAddressBObjsToUpdate = new Vector<XAddressGroupBObjExt>();

		if (requestPartyAddressBObjs.size() > 0) {

			// If Preferred address is present in request,
			// check for Preferred address in db and set db Pref Ind as N

			String preferredAddressInRequest = null;
			String requestRetailerId = null;

			for (XAddressGroupBObjExt requestPartyAddressBObj : requestPartyAddressBObjs) {

				if (requestPartyAddressBObj.getPreferredAddressIndicator() != null) {

					if (requestPartyAddressBObj
							.getPreferredAddressIndicator()
							.equalsIgnoreCase(
									DSEACompositeArchConstant.ADDRESS_PREF_IND_Y)) {

						preferredAddressInRequest = requestPartyAddressBObj
								.getAddressUsageType();

						break;
					}
				}

			}

			if (preferredAddressInRequest != null) {

				for (XAddressGroupBObjExt existingPartyAddressBObj : existingPartyAddressBObjs) {

					// If there's a preferred Address in Database
					if (existingPartyAddressBObj.getPreferredAddressIndicator() != null) {

						if (existingPartyAddressBObj
								.getPreferredAddressIndicator()
								.equalsIgnoreCase(
										DSEACompositeArchConstant.ADDRESS_PREF_IND_Y)) {

							dbPreferredAddressBObj = existingPartyAddressBObj;

						}

						if (dbPreferredAddressBObj != null) {

							existingPartyAddressBObjs
									.remove(dbPreferredAddressBObj);

							dbPreferredAddressBObj
									.setPreferredAddressIndicator(DSEACompositeArchConstant.ADDRESS_PREF_IND_N);

							transactionRequest.setTxnControl(control);

							transactionRequest.setTxnType("updatePartyAddress");

							transactionRequest
									.setTxnTopLevelObject(dbPreferredAddressBObj);

							try {

								txnResponse = (DWLResponse) dwlTxnBP
										.execute(transactionRequest);

							} catch (Exception e) {

								throw new BusinessProxyException(e.getMessage());

							}

							if (txnResponse.getData() != null) {

								existingPartyAddressBObjs
										.add((XAddressGroupBObjExt) txnResponse
												.getData());

							} else {
								throwExceptionifTXNFail(txnResponse, sb);
							}

							break;
						}
					}
				}
			}

			// --End changes for Preferred Address

			for (XAddressGroupBObjExt requestPartyAddressBObj : requestPartyAddressBObjs) {

				for (XAddressGroupBObjExt existingPartyAddressBObj : existingPartyAddressBObjs) {

					try {

						String reqAddressUsageType = requestPartyAddressBObj
								.getAddressUsageType();

						if (requestPartyAddressBObj.getAddressUsageType()
								.equalsIgnoreCase(
										existingPartyAddressBObj
												.getAddressUsageType())) {
							if (!arrDNDAddressTypes
									.contains(reqAddressUsageType)) {
								arrDNDAddressTypes.add(reqAddressUsageType);
							}

							requestPartyAddressBObj.setControl(control);
							requestPartyAddressBObj
									.setPartyId(existingPartyAddressBObj
											.getPartyId());
							requestPartyAddressBObj
									.setPartyAddressIdPK(existingPartyAddressBObj
											.getPartyAddressIdPK());
							requestPartyAddressBObj
									.setAddressId(existingPartyAddressBObj
											.getAddressId());
							requestPartyAddressBObj
									.setLocationGroupLastUpdateDate(existingPartyAddressBObj
											.getLocationGroupLastUpdateDate());
							requestPartyAddressBObj
									.setAddressGroupLastUpdateDate(existingPartyAddressBObj
											.getAddressGroupLastUpdateDate());
							requestPartyAddressBObj
									.getTCRMAddressBObj()
									.setAddressLastUpdateDate(
											existingPartyAddressBObj
													.getTCRMAddressBObj()
													.getAddressLastUpdateDate());

							requestPartyAddressBObj.getTCRMAddressBObj()
									.setAddressIdPK(
											existingPartyAddressBObj
													.getAddressId());
							// change for null start date
							if (requestPartyAddressBObj.getStartDate() == null) {
								requestPartyAddressBObj
										.setStartDate(existingPartyAddressBObj
												.getStartDate());
							}

							if (isAddressMatched(requestPartyAddressBObj,
									existingPartyAddressBObj, control)) {
								requestPartyAddressBObj
										.setXLastModifiedSystemDate(existingPartyAddressBObj
												.getXLastModifiedSystemDate());
							}
							break;

						}

					} catch (Exception e) {
						e.printStackTrace();
						DWLError error = errHandler
								.getErrorMessage(
										TCRMCoreComponentID.PARTY_ADDRESS_OBJECT,
										"UPDERR",
										TCRMCoreErrorReasonCode.UPDATE_PARTY_ADDRESS_FAILED,
										control, new String[0]);
						// vectReqDWLError.add(error);
						throw new BusinessProxyException(
								error.getErrorMessage());
					}
				}
			}

		}
		deleteCustomerAddress(existingPartyAddressBObjs, arrDNDAddressTypes,
				control);
	}
	
	
	
	
		protected void comparePartyAddressBObjsForUpdateME(
			TCRMPartyBObj existingPartyBObj, TCRMPartyBObj mainInput,
			DWLControl control) throws BusinessProxyException, Exception {

		Vector<XAddressGroupBObjExt> existingPartyAddressBObjs = existingPartyBObj
				.getItemsTCRMPartyAddressBObj();
		Vector<XAddressGroupBObjExt> requestPartyAddressBObjs = mainInput
				.getItemsTCRMPartyAddressBObj();

		ArrayList<String> arrDNDAddressTypes = new ArrayList<String>();
		
		

		// --Start changes for Preferred Adress

		XAddressGroupBObjExt dbPreferredAddressBObj = null;

		DWLTxnBP dwlTxnBP = new DWLTxnBP();

		DWLResponse txnResponse = null;

		DWLTransactionPersistent transactionRequest = new DWLTransactionPersistent();

		String timeStamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
				.format(new Date());

		Vector<XAddressGroupBObjExt> existingAddressBObjsToUpdate = new Vector<XAddressGroupBObjExt>();

		if (requestPartyAddressBObjs.size() > 0) {

			// If Preferred address is present in request,
			// check for Preferred address in db and set db Pref Ind as N

			String preferredAddressInRequest = null;
			String requestRetailerId = null;

			for (XAddressGroupBObjExt requestPartyAddressBObj : requestPartyAddressBObjs) {

				if (requestPartyAddressBObj.getPreferredAddressIndicator() != null) {

					if (requestPartyAddressBObj
							.getPreferredAddressIndicator()
							.equalsIgnoreCase(
									DSEACompositeArchConstant.ADDRESS_PREF_IND_Y)) {

						preferredAddressInRequest = requestPartyAddressBObj
								.getAddressUsageType();

						break;
					}
				}

			}

			if (preferredAddressInRequest != null) {

				for (XAddressGroupBObjExt existingPartyAddressBObj : existingPartyAddressBObjs) {

					// If there's a preferred Address in Database
					if (existingPartyAddressBObj.getPreferredAddressIndicator() != null) {

						if (existingPartyAddressBObj
								.getPreferredAddressIndicator()
								.equalsIgnoreCase(
										DSEACompositeArchConstant.ADDRESS_PREF_IND_Y)) {

							dbPreferredAddressBObj = existingPartyAddressBObj;

						}

						if (dbPreferredAddressBObj != null) {

							existingPartyAddressBObjs
									.remove(dbPreferredAddressBObj);

							dbPreferredAddressBObj
									.setPreferredAddressIndicator(DSEACompositeArchConstant.ADDRESS_PREF_IND_N);

							transactionRequest.setTxnControl(control);

							transactionRequest.setTxnType("updatePartyAddress");

							transactionRequest
									.setTxnTopLevelObject(dbPreferredAddressBObj);

							try {

								txnResponse = (DWLResponse) dwlTxnBP
										.execute(transactionRequest);

							} catch (Exception e) {

								throw new BusinessProxyException(e.getMessage());

							}

							if (txnResponse.getData() != null) {

								existingPartyAddressBObjs
										.add((XAddressGroupBObjExt) txnResponse
												.getData());

							} else {
								throwExceptionifTXNFail(txnResponse, sb);
							}

							break;
						}
					}
				}
			}

			// --End changes for Preferred Address

			for (XAddressGroupBObjExt requestPartyAddressBObj : requestPartyAddressBObjs) {

				for (XAddressGroupBObjExt existingPartyAddressBObj : existingPartyAddressBObjs) {

					try {

						String reqAddressUsageType = requestPartyAddressBObj
								.getAddressUsageType();

						if (requestPartyAddressBObj.getAddressUsageType()
								.equalsIgnoreCase(
										existingPartyAddressBObj
												.getAddressUsageType())) {
							if (!arrDNDAddressTypes
									.contains(reqAddressUsageType)) {
								arrDNDAddressTypes.add(reqAddressUsageType);
							}

							requestPartyAddressBObj.setControl(control);
							requestPartyAddressBObj
									.setPartyId(existingPartyAddressBObj
											.getPartyId());
							requestPartyAddressBObj
									.setPartyAddressIdPK(existingPartyAddressBObj
											.getPartyAddressIdPK());
							requestPartyAddressBObj
									.setAddressId(existingPartyAddressBObj
											.getAddressId());
							requestPartyAddressBObj
									.setLocationGroupLastUpdateDate(existingPartyAddressBObj
											.getLocationGroupLastUpdateDate());
							requestPartyAddressBObj
									.setAddressGroupLastUpdateDate(existingPartyAddressBObj
											.getAddressGroupLastUpdateDate());
							requestPartyAddressBObj
									.getTCRMAddressBObj()
									.setAddressLastUpdateDate(
											existingPartyAddressBObj
													.getTCRMAddressBObj()
													.getAddressLastUpdateDate());

							requestPartyAddressBObj.getTCRMAddressBObj()
									.setAddressIdPK(
											existingPartyAddressBObj
													.getAddressId());
							
						
							
							// change for null start date
							if (requestPartyAddressBObj.getStartDate() == null) {
								requestPartyAddressBObj
										.setStartDate(existingPartyAddressBObj
												.getStartDate());
							}

							if (isAddressMatchedME(requestPartyAddressBObj,
									existingPartyAddressBObj, control)) {
								requestPartyAddressBObj
										.setXLastModifiedSystemDate(existingPartyAddressBObj
												.getXLastModifiedSystemDate());
							}
							break;

						}

					} catch (Exception e) {
						e.printStackTrace();
						DWLError error = errHandler
								.getErrorMessage(
										TCRMCoreComponentID.PARTY_ADDRESS_OBJECT,
										"UPDERR",
										TCRMCoreErrorReasonCode.UPDATE_PARTY_ADDRESS_FAILED,
										control, new String[0]);
						// vectReqDWLError.add(error);
						throw new BusinessProxyException(
								error.getErrorMessage());
					}
				}
			}

		}
		deleteCustomerAddress(existingPartyAddressBObjs, arrDNDAddressTypes,
				control);
	}
	
	
	
	
	
	
	
	
	
	/**
	 * 
	 * @param existingPartyBObj
	 * @param mainInput
	 * @param control
	 * @throws BusinessProxyException
	 * @throws Exception
	 */
	protected void comparePartyAddressBObjsForUpdateJPN(
			TCRMPartyBObj existingPartyBObj, TCRMPartyBObj mainInput,
			DWLControl control) throws BusinessProxyException, Exception {

		Vector<XAddressGroupBObjExt> existingPartyAddressBObjs = existingPartyBObj
				.getItemsTCRMPartyAddressBObj();
		Vector<XAddressGroupBObjExt> requestPartyAddressBObjs = mainInput
				.getItemsTCRMPartyAddressBObj();

		ArrayList<String> arrDNDAddressTypes = new ArrayList<String>();

		// --Start changes for Preferred Adress

		XAddressGroupBObjExt dbPreferredAddressBObj = null;

		DWLTxnBP dwlTxnBP = new DWLTxnBP();

		DWLResponse txnResponse = null;

		DWLTransactionPersistent transactionRequest = new DWLTransactionPersistent();

		String timeStamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
				.format(new Date());

		Vector<XAddressGroupBObjExt> existingAddressBObjsToUpdate = new Vector<XAddressGroupBObjExt>();

		if (requestPartyAddressBObjs.size() > 0) {

			// If Preferred address is present in request,
			// check for Preferred address in db and set db Pref Ind as N

			String preferredAddressInRequest = null;
			String requestRetailerId = null;

			for (XAddressGroupBObjExt requestPartyAddressBObj : requestPartyAddressBObjs) {

				if (requestPartyAddressBObj.getPreferredAddressIndicator() != null) {

					if (requestPartyAddressBObj
							.getPreferredAddressIndicator()
							.equalsIgnoreCase(
									DSEACompositeArchConstant.ADDRESS_PREF_IND_Y)) {

						preferredAddressInRequest = requestPartyAddressBObj
								.getAddressUsageType();

						break;
					}
				}

			}

			if (preferredAddressInRequest != null) {

				for (XAddressGroupBObjExt existingPartyAddressBObj : existingPartyAddressBObjs) {

					// If there's a preferred Address in Database
					if (existingPartyAddressBObj.getPreferredAddressIndicator() != null) {

						if (existingPartyAddressBObj
								.getPreferredAddressIndicator()
								.equalsIgnoreCase(
										DSEACompositeArchConstant.ADDRESS_PREF_IND_Y)) {

							dbPreferredAddressBObj = existingPartyAddressBObj;

						}

						if (dbPreferredAddressBObj != null) {

							existingPartyAddressBObjs
									.remove(dbPreferredAddressBObj);

							dbPreferredAddressBObj
									.setPreferredAddressIndicator(DSEACompositeArchConstant.ADDRESS_PREF_IND_N);

							transactionRequest.setTxnControl(control);

							transactionRequest.setTxnType("updatePartyAddress");

							transactionRequest
									.setTxnTopLevelObject(dbPreferredAddressBObj);

							try {

								txnResponse = (DWLResponse) dwlTxnBP
										.execute(transactionRequest);

							} catch (Exception e) {

								throw new BusinessProxyException(e.getMessage());

							}

							if (txnResponse.getData() != null) {

								existingPartyAddressBObjs
										.add((XAddressGroupBObjExt) txnResponse
												.getData());

							} else {
								throwExceptionifTXNFail(txnResponse, sb);
							}

							break;
						}
					}
				}
			}

			// --End changes for Preferred Address

			for (XAddressGroupBObjExt requestPartyAddressBObj : requestPartyAddressBObjs) {

				for (XAddressGroupBObjExt existingPartyAddressBObj : existingPartyAddressBObjs) {

					try {

						String reqAddressUsageType = requestPartyAddressBObj
								.getAddressUsageType();

						if (requestPartyAddressBObj.getAddressUsageType()
								.equalsIgnoreCase(
										existingPartyAddressBObj
												.getAddressUsageType())) {
							if (!arrDNDAddressTypes
									.contains(reqAddressUsageType)) {
								arrDNDAddressTypes.add(reqAddressUsageType);
							}

							requestPartyAddressBObj.setControl(control);
							requestPartyAddressBObj
									.setPartyId(existingPartyAddressBObj
											.getPartyId());
							requestPartyAddressBObj
									.setPartyAddressIdPK(existingPartyAddressBObj
											.getPartyAddressIdPK());
							requestPartyAddressBObj
									.setAddressId(existingPartyAddressBObj
											.getAddressId());
							requestPartyAddressBObj
									.setLocationGroupLastUpdateDate(existingPartyAddressBObj
											.getLocationGroupLastUpdateDate());
							requestPartyAddressBObj
									.setAddressGroupLastUpdateDate(existingPartyAddressBObj
											.getAddressGroupLastUpdateDate());
							requestPartyAddressBObj
									.getTCRMAddressBObj()
									.setAddressLastUpdateDate(
											existingPartyAddressBObj
													.getTCRMAddressBObj()
													.getAddressLastUpdateDate());

							requestPartyAddressBObj.getTCRMAddressBObj()
									.setAddressIdPK(
											existingPartyAddressBObj
													.getAddressId());
							
							if (requestPartyAddressBObj != null
									&& existingPartyAddressBObj != null) {
								updateXPreferenceJpn(
										requestPartyAddressBObj
										.getXPreferenceBObj(),
										existingPartyAddressBObj
										.getXPreferenceBObj());
							}
							// change for null start date
							if (requestPartyAddressBObj.getStartDate() == null) {
								requestPartyAddressBObj
										.setStartDate(existingPartyAddressBObj
												.getStartDate());
							}

							if (isAddressMatched(requestPartyAddressBObj,
									existingPartyAddressBObj, control)) {
								requestPartyAddressBObj
										.setXLastModifiedSystemDate(existingPartyAddressBObj
												.getXLastModifiedSystemDate());
							}
							break;

						}

					} catch (Exception e) {
						e.printStackTrace();
						DWLError error = errHandler
								.getErrorMessage(
										TCRMCoreComponentID.PARTY_ADDRESS_OBJECT,
										"UPDERR",
										TCRMCoreErrorReasonCode.UPDATE_PARTY_ADDRESS_FAILED,
										control, new String[0]);
						// vectReqDWLError.add(error);
						throw new BusinessProxyException(
								error.getErrorMessage());
					}
				}
			}

		}
		deleteCustomerAddress(existingPartyAddressBObjs, arrDNDAddressTypes,
				control);
	}

	protected void deleteCustomerAddress(
			Vector<XAddressGroupBObjExt> existingPartyAddressBObjs,
			ArrayList<String> arrDNDAddressTypes, DWLControl control)
			throws BusinessProxyException, Exception {
		try {

			DSEAAdditionsExtsComponent dseac = new DSEAAdditionsExtsComponent();
			TCRMPartyComponent tcrmParty = new TCRMPartyComponent();
			for (XAddressGroupBObjExt currXAddr : existingPartyAddressBObjs) {
				if (!arrDNDAddressTypes.contains(currXAddr
						.getAddressUsageType())) {
					if (currXAddr.getXPreferenceBObj() != null) {
						XPreferenceBObj currXPref = currXAddr
								.getXPreferenceBObj();
						currXPref.setControl(control);
						dseac.deleteXPreference(currXPref);
					}
					
					if(null != currXAddr.getXPrivacyAgreementBObj())
					{
						XPrivacyAgreementBObj currXPrivAgr = currXAddr.getXPrivacyAgreementBObj();
						deleteXPrivacyAgreement(currXPrivAgr.getLocationGroupId());
					}
					
					currXAddr.setControl(control);
					tcrmParty.deletePartyAddress(currXAddr);

				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			DWLError error = errHandler.getErrorMessage(
					TCRMCoreComponentID.PARTY_ADDRESS_OBJECT, "UPDERR",
					TCRMCoreErrorReasonCode.UPDATE_PARTY_ADDRESS_FAILED,
					control, new String[0]);
			// vectReqDWLError.add(error);
			throw new BusinessProxyException(error.getErrorMessage());
		}
	}
	protected void deleteXPrivacyAgreement(String locationGroupID)
	{
		SQLQuery query = new SQLQuery();
		List<SQLParam> params = new ArrayList<SQLParam>();
		if(null != locationGroupID)
		{	
			params.add(0,new SQLParam(locationGroupID));
			try {
				query.executeUpdate(DSEACompositeArchConstant.DELETE_XPRIVACYGREEMENT, params);
				} 
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
	
	}
	/**
	 * 
	 * @param existingPartyBObj
	 * @param mainInput
	 * @param control
	 * @throws BusinessProxyException
	 * @throws Exception
	 */
	protected void comparePartyContactMethodBObjsForUpdate(
			TCRMPartyBObj existingPartyBObj, TCRMPartyBObj mainInput,
			DWLControl control) throws BusinessProxyException, Exception {

		Vector<XContactMethodGroupBObjExt> existingPartyContactMethodBObjs = existingPartyBObj
				.getItemsTCRMPartyContactMethodBObj();

		Vector<XContactMethodGroupBObjExt> requestPartyContactMethodBObjs = mainInput
				.getItemsTCRMPartyContactMethodBObj();

		XContactMethodGroupBObjExt dbPreferredContactMethodBObj = null;
		ArrayList<String> arrDNDContacts = new ArrayList<String>();

		DWLTxnBP dwlTxnBP = new DWLTxnBP();

		DWLResponse txnResponse = null;

		DWLTransactionPersistent transactionRequest = new DWLTransactionPersistent();

		try {

			if (requestPartyContactMethodBObjs.size() > 0) {

				// If Preferred contact method is present in request, check for
				// Preferred contact method in db and set db Pref Ind as N
				String preferredContactMethodInRequest = null;
				for (XContactMethodGroupBObjExt requestPartyContactMethodBObj : requestPartyContactMethodBObjs) {
					if (requestPartyContactMethodBObj
							.getPreferredContactMethodIndicator() != null) {
						if (requestPartyContactMethodBObj
								.getPreferredContactMethodIndicator()
								.equalsIgnoreCase(
										DSEACompositeArchConstant.CONTACT_PREF_IND_Y)) {
							preferredContactMethodInRequest = requestPartyContactMethodBObj
									.getContactMethodUsageType();
							break;
						}
					}
				}
				if (preferredContactMethodInRequest != null) {
					for (XContactMethodGroupBObjExt existingPartyContactMethodBObj : existingPartyContactMethodBObjs) {
						if (existingPartyContactMethodBObj
								.getPreferredContactMethodIndicator() != null) {
							if (existingPartyContactMethodBObj
									.getPreferredContactMethodIndicator()
									.equalsIgnoreCase(
											DSEACompositeArchConstant.CONTACT_PREF_IND_Y)
									&& !existingPartyContactMethodBObj
											.getContactMethodUsageType()
											.equals(preferredContactMethodInRequest)) {
								dbPreferredContactMethodBObj = existingPartyContactMethodBObj;
							}
							if (dbPreferredContactMethodBObj != null) {
								existingPartyContactMethodBObjs
										.remove(dbPreferredContactMethodBObj);
								dbPreferredContactMethodBObj
										.setPreferredContactMethodIndicator(DSEACompositeArchConstant.CONTACT_PREF_IND_N);
								transactionRequest.setTxnControl(control);
								transactionRequest
										.setTxnType("updatePartyContactMethod");
								transactionRequest
										.setTxnTopLevelObject(dbPreferredContactMethodBObj);
								try {
									txnResponse = (DWLResponse) dwlTxnBP
											.execute(transactionRequest);
								} catch (Exception e) {
									throw new BusinessProxyException(
											e.getMessage());
								}
								if (txnResponse.getData() != null) {
									existingPartyContactMethodBObjs
											.add((XContactMethodGroupBObjExt) txnResponse
													.getData());
								} else {
									throwExceptionifTXNFail(txnResponse, sb);
								}
								break;

							}
						}
					}
				}

				String requestContactMethod = null;
				String dbContactMethod = null;

				for (XContactMethodGroupBObjExt existingPartyContactMethodBObj : existingPartyContactMethodBObjs) {

					dbContactMethod = existingPartyContactMethodBObj
							.getTCRMContactMethodBObj().getReferenceNumber();

					for (XContactMethodGroupBObjExt requestPartyContactMethodBObj : requestPartyContactMethodBObjs) {
						// try {
						requestContactMethod = requestPartyContactMethodBObj
								.getTCRMContactMethodBObj()
								.getReferenceNumber();

						if (requestPartyContactMethodBObj
								.getContactMethodUsageType().equals(
										existingPartyContactMethodBObj
												.getContactMethodUsageType())) {
							arrDNDContacts.add(requestPartyContactMethodBObj
									.getContactMethodUsageType());
							requestPartyContactMethodBObj.setControl(control);
							requestPartyContactMethodBObj
									.setPartyId(existingPartyContactMethodBObj
											.getPartyId());
							requestPartyContactMethodBObj
									.setPartyContactMethodIdPK(existingPartyContactMethodBObj
											.getPartyContactMethodIdPK());
							requestPartyContactMethodBObj
									.setContactMethodId(existingPartyContactMethodBObj
											.getContactMethodId());
							requestPartyContactMethodBObj
									.setLocationGroupLastUpdateDate(existingPartyContactMethodBObj
											.getLocationGroupLastUpdateDate());
							requestPartyContactMethodBObj
									.setContactMethodGroupLastUpdateDate(existingPartyContactMethodBObj
											.getContactMethodGroupLastUpdateDate());

							requestPartyContactMethodBObj
									.getTCRMContactMethodBObj()
									.setContactMethodLastUpdateDate(
											existingPartyContactMethodBObj
													.getTCRMContactMethodBObj()
													.getContactMethodLastUpdateDate());

							requestPartyContactMethodBObj
									.getTCRMContactMethodBObj()
									.setContactMethodIdPK(
											existingPartyContactMethodBObj
													.getContactMethodId());
							// change for null Start date
							if (requestPartyContactMethodBObj.getStartDate() == null) {
								requestPartyContactMethodBObj
										.setStartDate(existingPartyContactMethodBObj
												.getStartDate());
							}

							if (requestContactMethod.equals(dbContactMethod)) {
								requestPartyContactMethodBObj
										.setXLastModifiedSystemDate(existingPartyContactMethodBObj
												.getXLastModifiedSystemDate());
							}

							break;
						}

					}
				}

			}
		} catch (Exception e) {
			DWLError error = errHandler.getErrorMessage(
					TCRMCoreComponentID.PARTY_CONTACTMETHOD_OBJECT, "UPDERR",
					TCRMCoreErrorReasonCode.UPDATE_PARTY_CONTACT_METHOD_FAILED,
					control, new String[0]);
			// vectReqDWLError.add(error);
			throw new BusinessProxyException(error.getErrorMessage());

		}
		deleteCustomerContacts(existingPartyContactMethodBObjs, arrDNDContacts,
				control);
	}
	
	/**
	 * 
	 * @param existingPartyBObj
	 * @param mainInput
	 * @param control
	 * @throws BusinessProxyException
	 * @throws Exception
	 */
	protected void comparePartyContactMethodBObjsForUpdateJPN(
			TCRMPartyBObj existingPartyBObj, TCRMPartyBObj mainInput,
			DWLControl control) throws BusinessProxyException, Exception {

		Vector<XContactMethodGroupBObjExt> existingPartyContactMethodBObjs = existingPartyBObj
				.getItemsTCRMPartyContactMethodBObj();

		Vector<XContactMethodGroupBObjExt> requestPartyContactMethodBObjs = mainInput
				.getItemsTCRMPartyContactMethodBObj();

		XContactMethodGroupBObjExt dbPreferredContactMethodBObj = null;
		ArrayList<String> arrDNDContacts = new ArrayList<String>();

		DWLTxnBP dwlTxnBP = new DWLTxnBP();

		DWLResponse txnResponse = null;

		DWLTransactionPersistent transactionRequest = new DWLTransactionPersistent();

		try {

			if (requestPartyContactMethodBObjs.size() > 0) {

				// If Preferred contact method is present in request, check for
				// Preferred contact method in db and set db Pref Ind as N
				String preferredContactMethodInRequest = null;
				for (XContactMethodGroupBObjExt requestPartyContactMethodBObj : requestPartyContactMethodBObjs) {
					if (requestPartyContactMethodBObj
							.getPreferredContactMethodIndicator() != null) {
						if (requestPartyContactMethodBObj
								.getPreferredContactMethodIndicator()
								.equalsIgnoreCase(
										DSEACompositeArchConstant.CONTACT_PREF_IND_Y)) {
							preferredContactMethodInRequest = requestPartyContactMethodBObj
									.getContactMethodUsageType();
							break;
						}
					}
				}
				if (preferredContactMethodInRequest != null) {
					for (XContactMethodGroupBObjExt existingPartyContactMethodBObj : existingPartyContactMethodBObjs) {
						if (existingPartyContactMethodBObj
								.getPreferredContactMethodIndicator() != null) {
							if (existingPartyContactMethodBObj
									.getPreferredContactMethodIndicator()
									.equalsIgnoreCase(
											DSEACompositeArchConstant.CONTACT_PREF_IND_Y)
									&& !existingPartyContactMethodBObj
											.getContactMethodUsageType()
											.equals(preferredContactMethodInRequest)) {
								dbPreferredContactMethodBObj = existingPartyContactMethodBObj;
							}
							if (dbPreferredContactMethodBObj != null) {
								existingPartyContactMethodBObjs
										.remove(dbPreferredContactMethodBObj);
								dbPreferredContactMethodBObj
										.setPreferredContactMethodIndicator(DSEACompositeArchConstant.CONTACT_PREF_IND_N);
								transactionRequest.setTxnControl(control);
								transactionRequest
										.setTxnType("updatePartyContactMethod");
								transactionRequest
										.setTxnTopLevelObject(dbPreferredContactMethodBObj);
								try {
									txnResponse = (DWLResponse) dwlTxnBP
											.execute(transactionRequest);
								} catch (Exception e) {
									throw new BusinessProxyException(
											e.getMessage());
								}
								if (txnResponse.getData() != null) {
									existingPartyContactMethodBObjs
											.add((XContactMethodGroupBObjExt) txnResponse
													.getData());
								} else {
									throwExceptionifTXNFail(txnResponse, sb);
								}
								break;

							}
						}
					}
				}

				String requestContactMethod = null;
				String dbContactMethod = null;

				for (XContactMethodGroupBObjExt existingPartyContactMethodBObj : existingPartyContactMethodBObjs) {

					dbContactMethod = existingPartyContactMethodBObj
							.getTCRMContactMethodBObj().getReferenceNumber();

					for (XContactMethodGroupBObjExt requestPartyContactMethodBObj : requestPartyContactMethodBObjs) {
						// try {
						requestContactMethod = requestPartyContactMethodBObj
								.getTCRMContactMethodBObj()
								.getReferenceNumber();

						if (requestPartyContactMethodBObj
								.getContactMethodUsageType().equals(
										existingPartyContactMethodBObj
												.getContactMethodUsageType())) {
							arrDNDContacts.add(requestPartyContactMethodBObj
									.getContactMethodUsageType());
							requestPartyContactMethodBObj.setControl(control);
							requestPartyContactMethodBObj
									.setPartyId(existingPartyContactMethodBObj
											.getPartyId());
							requestPartyContactMethodBObj
									.setPartyContactMethodIdPK(existingPartyContactMethodBObj
											.getPartyContactMethodIdPK());
							requestPartyContactMethodBObj
									.setContactMethodId(existingPartyContactMethodBObj
											.getContactMethodId());
							requestPartyContactMethodBObj
									.setLocationGroupLastUpdateDate(existingPartyContactMethodBObj
											.getLocationGroupLastUpdateDate());
							requestPartyContactMethodBObj
									.setContactMethodGroupLastUpdateDate(existingPartyContactMethodBObj
											.getContactMethodGroupLastUpdateDate());

							requestPartyContactMethodBObj
									.getTCRMContactMethodBObj()
									.setContactMethodLastUpdateDate(
											existingPartyContactMethodBObj
													.getTCRMContactMethodBObj()
													.getContactMethodLastUpdateDate());

							requestPartyContactMethodBObj
									.getTCRMContactMethodBObj()
									.setContactMethodIdPK(
											existingPartyContactMethodBObj
													.getContactMethodId());
							// change for null Start date
							if (requestPartyContactMethodBObj.getStartDate() == null) {
								requestPartyContactMethodBObj
										.setStartDate(existingPartyContactMethodBObj
												.getStartDate());
							}
							if(requestPartyContactMethodBObj!=null && existingPartyContactMethodBObj!=null){
								updateXPreferenceJpn(requestPartyContactMethodBObj.getXPreferenceBObj(),existingPartyContactMethodBObj
										.getXPreferenceBObj());
							}
							
							
							if (requestContactMethod.equals(dbContactMethod)) {
								requestPartyContactMethodBObj
										.setXLastModifiedSystemDate(existingPartyContactMethodBObj
												.getXLastModifiedSystemDate());
							}

							break;
						}

					}
				}

			}
		} catch (Exception e) {
			DWLError error = errHandler.getErrorMessage(
					TCRMCoreComponentID.PARTY_CONTACTMETHOD_OBJECT, "UPDERR",
					TCRMCoreErrorReasonCode.UPDATE_PARTY_CONTACT_METHOD_FAILED,
					control, new String[0]);
			// vectReqDWLError.add(error);
			throw new BusinessProxyException(error.getErrorMessage());

		}
		deleteCustomerContacts(existingPartyContactMethodBObjs, arrDNDContacts,
				control);
	}

/**
	 * 
	 * @param xPreferenceBObj_req
	 * @param xPreferenceBObj_existing
	 * @throws Exception
	 */
	private void updateXPreferenceJpn(XPreferenceBObj xPreferenceBObj_req,
			XPreferenceBObj xPreferenceBObj_existing) throws Exception {
		if (xPreferenceBObj_req != null && xPreferenceBObj_existing != null) {
			xPreferenceBObj_req.setPreferencepkId(xPreferenceBObj_existing
					.getPreferencepkId());
			xPreferenceBObj_req.setLocationGroupId(xPreferenceBObj_existing
					.getLocationGroupId());
			xPreferenceBObj_req
			.setXPreferenceLastUpdateDate(xPreferenceBObj_existing
					.getXPreferenceLastUpdateDate());
			DSEAAdditionsExtsComponent dseac = new DSEAAdditionsExtsComponent();
			dseac.updateXPreference(xPreferenceBObj_req);
		}

	}
	protected void deleteCustomerContacts(
			Vector<XContactMethodGroupBObjExt> existingPartyContactMethodBObjs,
			ArrayList<String> arrDNDContacts, DWLControl control)
			throws BusinessProxyException, Exception {
		try {

			DSEAAdditionsExtsComponent dseac = new DSEAAdditionsExtsComponent();
			TCRMPartyComponent tcrmParty = new TCRMPartyComponent();
			for (XContactMethodGroupBObjExt currXContact : existingPartyContactMethodBObjs) {
				if (!arrDNDContacts.contains(currXContact
						.getContactMethodUsageType())) {
					if (currXContact.getXPreferenceBObj() != null) {
						XPreferenceBObj currXPref = currXContact
								.getXPreferenceBObj();
						currXPref.setControl(control);
						dseac.deleteXPreference(currXPref);
					}
					if(null != currXContact.getXPrivacyAgreementBObj())
					{
						XPrivacyAgreementBObj currXPrivAgr = currXContact.getXPrivacyAgreementBObj();
						deleteXPrivacyAgreement(currXPrivAgr.getLocationGroupId());
					}
					currXContact.setControl(control);
					tcrmParty.deletePartyContactMethod(currXContact);

				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			DWLError error = errHandler.getErrorMessage(
					TCRMCoreComponentID.PARTY_CONTACTMETHOD_OBJECT, "UPDERR",
					TCRMCoreErrorReasonCode.UPDATE_PARTY_CONTACT_METHOD_FAILED,
					control, new String[0]);
			// vectReqDWLError.add(error);
			throw new BusinessProxyException(error.getErrorMessage());
		}
	}

	protected void compareAdminContEquivBObjsForUpdate(
			TCRMPartyBObj existingPartyBObj, TCRMPartyBObj mainInput,
			DWLControl control) throws BusinessProxyException {

		Vector<XContEquivBObjExt> existingContEquivBObjBObjs = existingPartyBObj
				.getItemsTCRMAdminContEquivBObj();
		Vector<XContEquivBObjExt> requestContEquivBObjBObjs = mainInput
				.getItemsTCRMAdminContEquivBObj();
		String requestAdminClientId = null;
		String requestDescription = null;
		String dbAdminClientId = null;
		String dbDescription = null;

		if (requestContEquivBObjBObjs.size() > 0) {

			for (XContEquivBObjExt requestBObj : requestContEquivBObjBObjs) {

				requestAdminClientId = requestBObj.getAdminPartyId();
				requestDescription = requestBObj.getDescription();

				for (XContEquivBObjExt existingBObj : existingContEquivBObjBObjs) {

					dbAdminClientId = existingBObj.getAdminPartyId();
					dbDescription = existingBObj.getDescription();

					try {
						requestBObj.setControl(control);

						if (requestBObj.getAdminSystemType().equals(
								existingBObj.getAdminSystemType())
								&& requestDescription != null
								&& dbDescription != null
								&& requestDescription.equals(dbDescription)) {

							requestBObj.setPartyId(existingBObj.getPartyId());
							requestBObj.setAdminContEquivIdPK(existingBObj
									.getAdminContEquivIdPK());
							requestBObj.setContEquivLastUpdateDate(existingBObj
									.getContEquivLastUpdateDate());

							if (requestAdminClientId.equals(dbAdminClientId)) {
								requestBObj
										.setXLastModifiedSystemDate(existingBObj
												.getXLastModifiedSystemDate());
							}
						}

					} catch (Exception e) {
						e.printStackTrace();
						DWLError error = errHandler
								.getErrorMessage(
										TCRMCoreComponentID.ADMINSYSKEY_COMPONENT,
										"UPDERR",
										TCRMCoreErrorReasonCode.UPDATE_PARTY_ADMIN_SYSTEM_KEY_FALIED,
										control, new String[0]); // error change
						// vectReqDWLError.add(error); // needed
						throw new BusinessProxyException(
								error.getErrorMessage());
					}

				}
			}
		}
	}

	protected void compareAdminContEquivBObjsForUpdateNoDescription(
			TCRMPartyBObj existingPartyBObj, TCRMPartyBObj mainInput,
			DWLControl control) throws BusinessProxyException {
		// Markets Handled: EG, AU, NZ ,IND ,CL1
		Vector<XContEquivBObjExt> existingContEquivBObjBObjs = existingPartyBObj
				.getItemsTCRMAdminContEquivBObj();
		Vector<XContEquivBObjExt> requestContEquivBObjBObjs = mainInput
				.getItemsTCRMAdminContEquivBObj();
		String requestAdminClientId = null;
		String dbAdminClientId = null;

		if (requestContEquivBObjBObjs.size() > 0) {

			for (XContEquivBObjExt requestBObj : requestContEquivBObjBObjs) {

				requestAdminClientId = requestBObj.getAdminPartyId();

				for (XContEquivBObjExt existingBObj : existingContEquivBObjBObjs) {

					dbAdminClientId = existingBObj.getAdminPartyId();

					try {
						requestBObj.setControl(control);

						if (requestBObj.getAdminSystemType().equals(
								existingBObj.getAdminSystemType())) {

							requestBObj.setPartyId(existingBObj.getPartyId());
							requestBObj.setAdminContEquivIdPK(existingBObj
									.getAdminContEquivIdPK());
							requestBObj.setContEquivLastUpdateDate(existingBObj
									.getContEquivLastUpdateDate());

							if (requestAdminClientId.equals(dbAdminClientId)) {
								requestBObj
										.setXLastModifiedSystemDate(existingBObj
												.getXLastModifiedSystemDate());
							}
						}

					} catch (Exception e) {
						e.printStackTrace();
						DWLError error = errHandler
								.getErrorMessage(
										TCRMCoreComponentID.ADMINSYSKEY_COMPONENT,
										"UPDERR",
										TCRMCoreErrorReasonCode.UPDATE_PARTY_ADMIN_SYSTEM_KEY_FALIED,
										control, new String[0]); // error change
						// vectReqDWLError.add(error); // needed
						throw new BusinessProxyException(
								error.getErrorMessage());
					}

				}
			}
		}
	}
	/**
	 * 
	 * @param existingPartyBObj
	 * @param mainInput
	 * @param control
	 * @param partyComponent
	 * @param partyId 
	 * @throws BusinessProxyException
	 */
	protected void compareAdminContEquivBObjsForUpdateNoDescriptionJPN(
			TCRMPartyBObj existingPartyBObj, TCRMPartyBObj mainInput,
			DWLControl control, TCRMPartyComponent partyComponent,
			String partyId) throws BusinessProxyException {
		// Markets Handled: JPN
		@SuppressWarnings("unchecked")
		Vector<XContEquivBObjExt> requestContEquivBObjBObjs = mainInput
				.getItemsTCRMAdminContEquivBObj();
		Vector<XContEquivBObjExt> existingtCRMAdminContEquivBObjInDbvect = null;
		String requestAdminClientId = null;
		String requestAdminsystype = null;
		String description = null;
		if (requestContEquivBObjBObjs != null
				&& requestContEquivBObjBObjs.size() > 0) {
			try {
				existingtCRMAdminContEquivBObjInDbvect = getAdminConteqivByPartyIDJPN(
						control, partyId);

				for (XContEquivBObjExt requestBObj : requestContEquivBObjBObjs) {
					requestAdminClientId = requestBObj.getAdminPartyId();
					requestAdminsystype = requestBObj.getAdminSystemType();
					description = requestBObj.getDescription();
					requestBObj.setControl(control);
					findExistingXContEquivBObjExtbyIDandUpdate(
							requestAdminClientId, requestAdminsystype,
							description,
							existingtCRMAdminContEquivBObjInDbvect,
							requestBObj, requestContEquivBObjBObjs);
				}
			} catch (Exception e) {
				e.printStackTrace();
				DWLError error = errHandler
						.getErrorMessage(
								TCRMCoreComponentID.ADMINSYSKEY_COMPONENT,
								"UPDERR",
								TCRMCoreErrorReasonCode.UPDATE_PARTY_ADMIN_SYSTEM_KEY_FALIED,
								control, new String[0]);
				throw new BusinessProxyException(error.getErrorMessage());
			}
		}
	}
	

	/**
	 * 
	 * @param requestAdminClientId
	 * @param requestAdminsystype
	 * @param description
	 * @param existingtCRMAdminContEquivBObjInDbvect
	 * @param requestBObj
	 * @param requestContEquivBObjBObjs
	 * @return
	 * @throws Exception
	 */
	private void findExistingXContEquivBObjExtbyIDandUpdate(
			String requestAdminClientId, String requestAdminsystype,
			String description,
			Vector<XContEquivBObjExt> existingtCRMAdminContEquivBObjInDbvect,
			XContEquivBObjExt requestBObj,
			Vector<XContEquivBObjExt> requestContEquivBObjBObjs)
			throws Exception {
		//int i = 0;
		for (XContEquivBObjExt XContEquivBObjExtdb : existingtCRMAdminContEquivBObjInDbvect) {
			//System.out.println("entry-->" + i);
			//i++;
			if (XContEquivBObjExtdb != null
					&& XContEquivBObjExtdb.getAdminPartyId() != null
					&& XContEquivBObjExtdb.getDescription() != null
					&& XContEquivBObjExtdb.getAdminSystemType() != null
					&& XContEquivBObjExtdb.getAdminPartyId().equalsIgnoreCase(
							requestAdminClientId)
					&& XContEquivBObjExtdb.getDescription().equalsIgnoreCase(
							description)
					&& XContEquivBObjExtdb.getAdminSystemType()
							.equalsIgnoreCase(requestAdminsystype)) {
				/*System.out.println("loop1 db id-->"
						+ XContEquivBObjExtdb.getAdminPartyId()
						+ "--request id-->" + requestBObj.getAdminPartyId()
						+ "--db desc-->" + XContEquivBObjExtdb.getDescription()
						+ "--request desc-->" + requestBObj.getDescription()
						+ "--db AdminSystemType-->"
						+ XContEquivBObjExtdb.getAdminSystemType()
						+ "--request AdminSystemType-->"
						+ requestBObj.getAdminSystemType());*/
				requestBObj.setPartyId(XContEquivBObjExtdb.getPartyId());
				requestBObj.setAdminContEquivIdPK(XContEquivBObjExtdb
						.getAdminContEquivIdPK());
				requestBObj.setContEquivLastUpdateDate(XContEquivBObjExtdb
						.getContEquivLastUpdateDate());
				requestBObj
						.setXLastModifiedSystemDate(((XContEquivBObjExt) XContEquivBObjExtdb)
								.getXLastModifiedSystemDate());
				break;
			} else if (XContEquivBObjExtdb != null
					&& XContEquivBObjExtdb.getAdminSystemType() != null
					&& XContEquivBObjExtdb.getAdminSystemType()
							.equalsIgnoreCase(requestAdminsystype)) {
				/*System.out.println("loop2 db id-->"
						+ XContEquivBObjExtdb.getAdminPartyId()
						+ "--request id-->" + requestBObj.getAdminPartyId()
						+ "--db desc-->" + XContEquivBObjExtdb.getDescription()
						+ "--request desc-->" + requestBObj.getDescription()
						+ "--db AdminSystemType-->"
						+ XContEquivBObjExtdb.getAdminSystemType()
						+ "--request AdminSystemType-->"
						+ requestBObj.getAdminSystemType());*/
				requestBObj.setPartyId(XContEquivBObjExtdb.getPartyId());
				if (XContEquivBObjExtdb.getAdminPartyId() != null
						&& XContEquivBObjExtdb.getDescription() != null
						&& XContEquivBObjExtdb.getAdminPartyId()
								.equalsIgnoreCase(requestAdminClientId)
						&& XContEquivBObjExtdb.getDescription() != description
						&& XContEquivBObjExtdb.getDescription()
								.equalsIgnoreCase(
										DSEACompositeArchConstant.SLAVE_KEY)) {
					/*System.out.println("loop2.1 db id-->"
							+ XContEquivBObjExtdb.getAdminPartyId()
							+ "--request id-->" + requestBObj.getAdminPartyId()
							+ "--db desc-->"
							+ XContEquivBObjExtdb.getDescription()
							+ "--request desc-->"
							+ requestBObj.getDescription()
							+ "--db AdminSystemType-->"
							+ XContEquivBObjExtdb.getAdminSystemType()
							+ "--request AdminSystemType-->"
							+ requestBObj.getAdminSystemType());*/
					requestBObj.setPartyId(XContEquivBObjExtdb.getPartyId());
					requestBObj.setAdminContEquivIdPK(XContEquivBObjExtdb
							.getAdminContEquivIdPK());
					requestBObj.setContEquivLastUpdateDate(XContEquivBObjExtdb
							.getContEquivLastUpdateDate());
					requestBObj.setDescription(XContEquivBObjExtdb
							.getDescription());
					requestBObj
							.setXLastModifiedSystemDate(((XContEquivBObjExt) XContEquivBObjExtdb)
									.getXLastModifiedSystemDate());
					break;
				} else if (XContEquivBObjExtdb.getAdminPartyId() != null
						&& XContEquivBObjExtdb.getDescription() != null
						&& XContEquivBObjExtdb.getAdminPartyId() != requestAdminClientId
						&& XContEquivBObjExtdb.getDescription()
								.equalsIgnoreCase(description)
						&& XContEquivBObjExtdb.getDescription()
								.equalsIgnoreCase(
										DSEACompositeArchConstant.MASTER_KEY)) {
					/*System.out.println("loop2.2 db id-->"
							+ XContEquivBObjExtdb.getAdminPartyId()
							+ "--request id-->" + requestBObj.getAdminPartyId()
							+ "--db desc-->"
							+ XContEquivBObjExtdb.getAdminPartyId()
							+ "--request desc-->"
							+ requestBObj.getAdminPartyId()
							+ "--db AdminSystemType-->"
							+ XContEquivBObjExtdb.getAdminSystemType()
							+ "--request AdminSystemType-->"
							+ requestBObj.getAdminSystemType());*/

					requestBObj.setPartyId(XContEquivBObjExtdb.getPartyId());
					requestBObj.setAdminContEquivIdPK(XContEquivBObjExtdb
							.getAdminContEquivIdPK());
					requestBObj.setContEquivLastUpdateDate(XContEquivBObjExtdb
							.getContEquivLastUpdateDate());
					requestBObj.setDescription(XContEquivBObjExtdb
							.getDescription());
					if (requestBObj.getAdminSystemType().equalsIgnoreCase(
							DSEACompositeArchConstant.SFDC_TYPE)) {
						requestBObj.setAdminPartyId(XContEquivBObjExtdb
								.getAdminPartyId());
					}
					requestBObj
							.setXLastModifiedSystemDate(((XContEquivBObjExt) XContEquivBObjExtdb)
									.getXLastModifiedSystemDate());
					break;

				}

			}
		}
		
	}

	/**
	 * 
	 * @param control
	 * @param partyId
	 * @return
	 * @throws Exception
	 */
	protected Vector<XContEquivBObjExt> getAdminConteqivByPartyIDJPN(
			DWLControl control, String partyId) throws Exception {
		SQLQuery sqlQuery = new SQLQuery();
		ResultSet objResultSet = null;
		String getSFDCContEquivSql = DSEACompositeArchConstant.GET_ADMINCONTEQUIV_OBJECT_BY_CONT_ID;

		List<SQLParam> params = new ArrayList<SQLParam>();
		XContEquivBObjExt xContBObjExt = null;
		Vector<XContEquivBObjExt> contequivvect = new Vector<>();
		try {
			params = new ArrayList<SQLParam>();
			params.add(0, new SQLParam(partyId));

			objResultSet = sqlQuery.executeQuery(getSFDCContEquivSql, params);
			while (objResultSet.next()) {
				xContBObjExt = new XContEquivBObjExt();
				xContBObjExt.setAdminContEquivIdPK(objResultSet
						.getString(DSEACompositeArchConstant.CONT_EQUIV_ID_PK));
				xContBObjExt.setPartyId(objResultSet
						.getString(DSEACompositeArchConstant.PARTY_ID));
				xContBObjExt
						.setAdminSystemType(objResultSet
								.getString(DSEACompositeArchConstant.GET_ADMIN_SYS_TP_CD));
				xContBObjExt
						.setAdminPartyId(objResultSet
								.getString(DSEACompositeArchConstant.GET_ADMIN_CLIENT_ID));
				xContBObjExt.setDescription(objResultSet
						.getString(DSEACompositeArchConstant.DESCRIPTION));
				xContBObjExt
						.setContEquivLastUpdateDate(objResultSet
								.getString(DSEACompositeArchConstant.GET_LAST_UPDATE_DT));
				xContBObjExt
						.setXLastModifiedSystemDate(objResultSet
								.getString(DSEACompositeArchConstant.GET_XMODIFY_SYS_DT));
				contequivvect.add(xContBObjExt);
			}
		} catch (Exception ex) {
			ex.printStackTrace();

		} finally {
			if (objResultSet != null)
				objResultSet.close();
			sqlQuery.close();
		}
	
		
		return contequivvect;
		
	}

	public DWLError validateMaintainCompany(DWLCommon topLevelObject,
			DWLControl control) throws BusinessProxyException {
		DWLError error = null;
		// TODO Auto-generated method stub
		if (!(topLevelObject instanceof MaintainCompanyObjectBObj)) {
			// MDM_TODO0: CDKWB0014I optionally use a more appropriate error
			// code than
			// "MAINTAININDIVIDUAL_FAILED".
			error = errHandler
					.getErrorMessage(
							DSEAArchSimplificationComponentID.MAINTAIN_COMPANY_BUSINESS_PROXY,
							"INSERR",
							DSEAArchSimplificationErrorReasonCode.MAINTAININDIVIDUAL_FAILED,
							control, new String[0]);
			// throw new BusinessProxyException(error.getErrorMessage());
			return error;
		}

		// Market Name Null | Throw Error
		boolean isUCIDPresent = false;
		boolean isSFDCIdPresent = false;
		MaintainCompanyObjectBObj mainInput = (MaintainCompanyObjectBObj) topLevelObject;
		XOrgBObjExt inputCompanyBObj = (XOrgBObjExt) mainInput
				.getTCRMOrganizationBObj();

		String marketName = inputCompanyBObj.getXMarketName();

		if (marketName == null
				|| (!marketName
						.equalsIgnoreCase(DSEACompositeArchConstant.MARKET_NAME_KOREA)
						&& (!marketName
								.equalsIgnoreCase(DSEACompositeArchConstant.MARKET_NAME_THAILAND) && (!marketName
								.equalsIgnoreCase(DSEACompositeArchConstant.MARKET_NAME_MALAYSIA)))
						&& !marketName
								.equalsIgnoreCase(DSEACompositeArchConstant.MARKET_NAME_EGYPT)
						&& !marketName
								.equalsIgnoreCase(DSEACompositeArchConstant.MARKET_NAME_AUSTRALIA)
						&& !marketName
								.equalsIgnoreCase(DSEACompositeArchConstant.MARKET_NAME_NEWZEALAND)
						&& !marketName
								.equalsIgnoreCase(DSEACompositeArchConstant.MARKET_NAME_INDIA)
						&& !marketName
								.equalsIgnoreCase(DSEACompositeArchConstant.MARKET_NAME_JAPAN)
						&& !marketName
								.equalsIgnoreCase(DSEACompositeArchConstant.MARKET_NAME_INDONESIA)
						&& !marketName
								.equalsIgnoreCase(DSEACompositeArchConstant.MARKET_NAME_VIETNAM) 
						&& !marketName
								.equalsIgnoreCase(DSEACompositeArchConstant.MARKET_NAME_SINGAPORE)
						&& !marketName
								.equalsIgnoreCase(DSEACompositeArchConstant.MARKET_NAME_TURKEY)
						&& !marketName
								.equalsIgnoreCase(DSEACompositeArchConstant.MARKET_NAME_MIDDLEEAST))) {
			error = errHandler
					.getErrorMessage(
							DSEAArchSimplificationComponentID.MAINTAIN_COMPANY_BUSINESS_PROXY,
							DWLErrorCode.FIELD_VALIDATION_ERROR,
							DSEAArchSimplificationErrorReasonCode.MARKET_NAME_INVALID,
							control, new String[0]);
			// throw new BusinessProxyException(error.getErrorMessage());
			return error;
		}

		Vector<XContEquivBObjExt> vecContEquivBObj = inputCompanyBObj
				.getItemsTCRMAdminContEquivBObj();
		Vector<XIdentifierBObjExt> vecIdentBobjs = inputCompanyBObj
				.getItemsTCRMPartyIdentificationBObj();

		if (null != marketName
				&& StringUtils.isNonBlank(marketName)
				&& (marketName
						.equalsIgnoreCase(DSEACompositeArchConstant.MARKET_NAME_AUSTRALIA)
						|| marketName
								.equalsIgnoreCase(DSEACompositeArchConstant.MARKET_NAME_NEWZEALAND)
						|| marketName
								.equalsIgnoreCase(DSEACompositeArchConstant.MARKET_NAME_THAILAND)
						|| marketName
								.equalsIgnoreCase(DSEACompositeArchConstant.MARKET_NAME_MALAYSIA)
						|| marketName
								.equalsIgnoreCase(DSEACompositeArchConstant.MARKET_NAME_INDIA)
						|| marketName
								.equalsIgnoreCase(DSEACompositeArchConstant.MARKET_NAME_TURKEY))) {
			// If market name is AU, THA, MYS, NZ, IND, Turkey then check for UCID in Identifier
			
			//Ucid should have 19 digits and starts with "34" or "35" or "30"
			for (XIdentifierBObjExt vecIdentBobj : vecIdentBobjs) {
				if(null !=  vecIdentBobj.getIdentificationType() 
						&& vecIdentBobj.getIdentificationType().equalsIgnoreCase(DSEACompositeArchConstant.IDENTIFIER_UCID_TYPE)){
					if (null != vecIdentBobj.getIdentificationNumber() && StringUtils.isNonBlank(vecIdentBobj.getIdentificationNumber())
							&& vecIdentBobj.getIdentificationNumber().length() == 19
							&& (vecIdentBobj.getIdentificationNumber().startsWith(
									"34") || vecIdentBobj.getIdentificationNumber().startsWith(
											"35") || vecIdentBobj.getIdentificationNumber().startsWith(
													"30"))) {
	
								isUCIDPresent = true;
							
					} 
				}
				
			}

			for (XContEquivBObjExt XContEquivObject : vecContEquivBObj) {
				// If SFDC Id present
				if (null != XContEquivObject.getAdminSystemType() 
						&& XContEquivObject.getAdminSystemType().equalsIgnoreCase(
						DSEACompositeArchConstant.SFDC_TYPE)) {
					if (null != XContEquivObject.getAdminPartyId() 
							&&StringUtils.isNonBlank(XContEquivObject
							.getAdminPartyId())) {
						isSFDCIdPresent = true;
					}
				}
			}
		} 
		
		else if(null != marketName
				&& StringUtils.isNonBlank(marketName)
				&& (marketName
						.equalsIgnoreCase(DSEACompositeArchConstant.MARKET_NAME_VIETNAM)
						|| marketName
								.equalsIgnoreCase(DSEACompositeArchConstant.MARKET_NAME_SINGAPORE)
						|| marketName
								.equalsIgnoreCase(DSEACompositeArchConstant.MARKET_NAME_INDONESIA)
						|| marketName
								.equalsIgnoreCase(DSEACompositeArchConstant.MARKET_NAME_JAPAN)
						|| marketName
								.equalsIgnoreCase(DSEACompositeArchConstant.MARKET_NAME_MIDDLEEAST)))
		{

			// If market name is ID,VN,SG then check for UCID in ContEquiv
			
			

			for (XContEquivBObjExt XContEquivObject : vecContEquivBObj) {
				// If SFDC Id present
				if (null != XContEquivObject.getAdminSystemType() 
						&& XContEquivObject.getAdminSystemType().equalsIgnoreCase(
						DSEACompositeArchConstant.SFDC_TYPE)) {
					if (null != XContEquivObject.getAdminPartyId() 
							&&StringUtils.isNonBlank(XContEquivObject
							.getAdminPartyId())) {
						isSFDCIdPresent = true;
						if ( marketName
								.equalsIgnoreCase(DSEACompositeArchConstant.MARKET_NAME_JAPAN) && (XContEquivObject.getDescription()== null || XContEquivObject.getDescription().isEmpty())){
						XContEquivObject.setDescription(DSEACompositeArchConstant.MASTER_KEY);
						}
					}
				}
				
				//Ucid should have 19 digits and starts with "34" or "35" or "30"
				if(null !=  XContEquivObject.getAdminSystemType()  
						&& XContEquivObject.getAdminSystemType().equalsIgnoreCase(DSEACompositeArchConstant.UCID_TYPE)){
					if (null != XContEquivObject.getAdminPartyId() && StringUtils.isNonBlank(XContEquivObject.getAdminPartyId())
							&& XContEquivObject.getAdminPartyId().length() == 19
							&& (XContEquivObject.getAdminPartyId().startsWith(
									"34") || XContEquivObject.getAdminPartyId().startsWith(
											"35") || XContEquivObject.getAdminPartyId().startsWith(
													"30"))) {
	
								isUCIDPresent = true;
								if ( marketName
										.equalsIgnoreCase(DSEACompositeArchConstant.MARKET_NAME_JAPAN) && (XContEquivObject.getDescription()== null || XContEquivObject.getDescription().isEmpty())){
								XContEquivObject.setDescription(DSEACompositeArchConstant.MASTER_KEY);
								}
							
					} 
				}
				
			}
		
		}
		else {
			for (XContEquivBObjExt XContEquivObject : vecContEquivBObj) {
				// If UCID Present |
				if (XContEquivObject.getAdminSystemType().equalsIgnoreCase(
						DSEACompositeArchConstant.UCID_TYPE)) {
					if (StringUtils.isNonBlank(XContEquivObject
							.getAdminPartyId())) {
						isUCIDPresent = true;
					}
				}
				
				if (XContEquivObject.getAdminSystemType().equalsIgnoreCase(
						DSEACompositeArchConstant.SFDC_TYPE)) {
					if (StringUtils.isNonBlank(XContEquivObject
							.getAdminPartyId())) {
						isSFDCIdPresent = true;
					}
				}
			}
		}
		if (!isUCIDPresent) {
			error = errHandler
					.getErrorMessage(
							DSEAArchSimplificationComponentID.MAINTAIN_COMPANY_BUSINESS_PROXY,
							DWLErrorCode.FIELD_VALIDATION_ERROR,
							DSEAArchSimplificationErrorReasonCode.UCID_INVALID,
							control, new String[0]);
			// throw new BusinessProxyException(error.getErrorMessage());
			return error;
		}

		if (!isSFDCIdPresent) {
			error = errHandler
					.getErrorMessage(
							DSEAArchSimplificationComponentID.MAINTAIN_COMPANY_BUSINESS_PROXY,
							DWLErrorCode.FIELD_VALIDATION_ERROR,
							DSEAArchSimplificationErrorReasonCode.SFDCID_INVALID,
							control, new String[0]);
			// throw new BusinessProxyException(error.getErrorMessage());
			return error;
		}
		return error;
	}
	/**
	 * 
	 * @param companyResponseBObj
	 * @param additionsExtsComponent
	 * @param inputCompanyBObj
	 * @param control
	 * @return
	 * @throws BusinessProxyException
	 */
	public XOrgBObjExt createCompanyWholesale(XOrgBObjExt companyResponseBObj,
			DSEAAdditionsExtsComponent additionsExtsComponent,
			XOrgBObjExt inputCompanyBObj, DWLControl control)
			throws BusinessProxyException {

		DWLResponse addUpdatePartyResponse = null;

		// Add Person transaction
		addUpdatePartyResponse = mdmTransaction(
				inputCompanyBObj,
				control,
				DSEACompositeArchConstant.ADD_ORG_TXN,
				DSEAArchSimplificationComponentID.MAINTAIN_COMPANY_BUSINESS_PROXY);

		throwExceptionifTXNFail(addUpdatePartyResponse, sb);

		if (addUpdatePartyResponse != null) {
			companyResponseBObj = (XOrgBObjExt) addUpdatePartyResponse
					.getData();

			if (companyResponseBObj == null) {

				throwExceptionifTXNFail(addUpdatePartyResponse, sb);

			} else if (companyResponseBObj.getStatus().getStatus() == DWLStatus.FATAL) {

				throwExceptionifTXNFail(addUpdatePartyResponse, sb);

			}

		} else {

			throwExceptionifTXNFail(addUpdatePartyResponse, sb);
		}

		return companyResponseBObj;
	}

	public XOrgBObjExt updateCompanyWholesale(XOrgBObjExt companyResponseBObj,
			DSEAAdditionsExtsComponent additionsExtsComponent,
			XOrgBObjExt inputCompanyBObj, XOrgBObjExt outputCompanyBObj,
			DWLControl control, String partyId) throws BusinessProxyException,
			Exception {
		// TODO Auto-generated method stub

		DWLResponse addUpdatePartyResponse = null;
		XOrgBObjExt existingCompanyBObj = new XOrgBObjExt();
		TCRMPartyComponent partyComponent = new TCRMPartyComponent();
		XOrgBObjExt requestBObj = new XOrgBObjExt();
		String marketName;
		XContEquivBObjExt existingUCIDBObj = new XContEquivBObjExt();
		XContEquivBObjExt existingSFDCBObj = new XContEquivBObjExt();

		try {
			existingCompanyBObj = (XOrgBObjExt) partyComponent.getOrganization(
					partyId, "2", control);
		}
		// throw error if Get Person Failed
		catch (TCRMException e) {
			e.printStackTrace();

			DWLError error = errHandler
					.getErrorMessage(
							DSEAArchSimplificationComponentID.MAINTAIN_COMPANY_BUSINESS_PROXY,
							"UPDERR",
							DSEAArchSimplificationErrorReasonCode.MAINTAIN_COMPANY_UPDATE_FAILED,
							control, new String[0]);
			// vectReqDWLError.add(error);
			throw new BusinessProxyException(error.getErrorMessage());

		}
		// throw error if no person data is fetched
		if (existingCompanyBObj == null) {

			DWLError error = errHandler
					.getErrorMessage(
							DSEAArchSimplificationComponentID.MAINTAIN_COMPANY_BUSINESS_PROXY,
							"UPDERR",
							DSEAArchSimplificationErrorReasonCode.MAINTAIN_COMPANY_UPDATE_FAILED,
							control, new String[0]);
			// vectReqDWLError.add(error);
			throw new BusinessProxyException(error.getErrorMessage());
		}

		// Update the mainInputBObj for the updatePerson transaction

		setUpdateCompanyBObj(inputCompanyBObj, requestBObj,
				existingCompanyBObj, control);

		// Changed for marketName CMPVAL
		marketName = inputCompanyBObj.getXMarketName();
		// Changed for marketName CMPVAL

		// Compare the request BObjs with existing BObjs
		compareCompanyNameBObjsForUpdate(existingCompanyBObj, inputCompanyBObj,
				control);
		comparePartyIdentificationBObjsForUpdate(existingCompanyBObj,
				inputCompanyBObj, control);
		comparePartyAddressBObjsForUpdate(existingCompanyBObj,
				inputCompanyBObj, control);
		comparePartyContactMethodBObjsForUpdate(existingCompanyBObj,
				inputCompanyBObj, control);
		compareAdminContEquivBObjsForUpdate(existingCompanyBObj,
				inputCompanyBObj, control);

		// Changed for marketName CMPVAL (25 May 2018)
		control.put("marketName", marketName);
		// Changed for marketName CMPVAL (25 May 2018)

		// Run the updateOrg Transaction
		inputCompanyBObj.setControl(control);
		System.out.println(inputCompanyBObj.toXML());
		addUpdatePartyResponse = mdmTransaction(
				inputCompanyBObj,
				control,
				DSEACompositeArchConstant.UPDATE_ORG_TXN,
				DSEAArchSimplificationComponentID.MAINTAIN_COMPANY_BUSINESS_PROXY);
		throwExceptionifTXNFail(addUpdatePartyResponse, sb);

		if (addUpdatePartyResponse != null) {

			companyResponseBObj = (XOrgBObjExt) addUpdatePartyResponse
					.getData();

			if (companyResponseBObj == null) {

				throwExceptionifTXNFail(addUpdatePartyResponse, sb);

			} else if (companyResponseBObj.getStatus().getStatus() == DWLStatus.FATAL) {

				throwExceptionifTXNFail(addUpdatePartyResponse, sb);
			}
		} else {

			throwExceptionifTXNFail(addUpdatePartyResponse, sb);
		}
		// Set Response Objects
		// Set UCID in response
		Vector<XContEquivBObjExt> existingContEquivBObjs = existingCompanyBObj
				.getItemsTCRMAdminContEquivBObj();

		for (XContEquivBObjExt contEquivBObj : existingContEquivBObjs) {
			if (DSEACompositeArchConstant.UCID_TYPE
					.equalsIgnoreCase(contEquivBObj.getAdminSystemType())) {
				if ("Y".equalsIgnoreCase(contEquivBObj.getDescription())) {
					existingUCIDBObj = contEquivBObj;
				}
			} else if (DSEACompositeArchConstant.SFDC_TYPE
					.equalsIgnoreCase(contEquivBObj.getAdminSystemType())
					&& contEquivBObj.getXRetailerId() == null)
				if ("Y".equalsIgnoreCase(contEquivBObj.getDescription())) {
					existingSFDCBObj = contEquivBObj;
				}
		}

		companyResponseBObj.setTCRMAdminContEquivBObj(existingUCIDBObj);

		return companyResponseBObj;

	}
	
	public XOrgBObjExt updateCompanyWholesaleTHAMYS(XOrgBObjExt companyResponseBObj,
			DSEAAdditionsExtsComponent additionsExtsComponent,
			XOrgBObjExt inputCompanyBObj, XOrgBObjExt outputCompanyBObj,
			DWLControl control, String partyId) throws BusinessProxyException,
			Exception {
		// TODO Auto-generated method stub

		DWLResponse addUpdatePartyResponse = null;
		XOrgBObjExt existingCompanyBObj = new XOrgBObjExt();
		TCRMPartyComponent partyComponent = new TCRMPartyComponent();
		XOrgBObjExt requestBObj = new XOrgBObjExt();
		String marketName;
		XContEquivBObjExt existingUCIDBObj = new XContEquivBObjExt();
		XContEquivBObjExt existingSFDCBObj = new XContEquivBObjExt();

		try {
			existingCompanyBObj = (XOrgBObjExt) partyComponent.getOrganization(
					partyId, "2", control);
		}
		// throw error if Get Person Failed
		catch (TCRMException e) {
			e.printStackTrace();

			DWLError error = errHandler
					.getErrorMessage(
							DSEAArchSimplificationComponentID.MAINTAIN_COMPANY_BUSINESS_PROXY,
							"UPDERR",
							DSEAArchSimplificationErrorReasonCode.MAINTAIN_COMPANY_UPDATE_FAILED,
							control, new String[0]);
			// vectReqDWLError.add(error);
			throw new BusinessProxyException(error.getErrorMessage());

		}
		// throw error if no person data is fetched
		if (existingCompanyBObj == null) {

			DWLError error = errHandler
					.getErrorMessage(
							DSEAArchSimplificationComponentID.MAINTAIN_COMPANY_BUSINESS_PROXY,
							"UPDERR",
							DSEAArchSimplificationErrorReasonCode.MAINTAIN_COMPANY_UPDATE_FAILED,
							control, new String[0]);
			// vectReqDWLError.add(error);
			throw new BusinessProxyException(error.getErrorMessage());
		}

		// Update the mainInputBObj for the updatePerson transaction

		setUpdateCompanyBObj(inputCompanyBObj, requestBObj,
				existingCompanyBObj, control);

		// Changed for marketName CMPVAL
		marketName = inputCompanyBObj.getXMarketName();
		// Changed for marketName CMPVAL

		// Compare the request BObjs with existing BObjs
		compareCompanyNameBObjsForUpdate(existingCompanyBObj, inputCompanyBObj,
				control);
		comparePartyIdentificationBObjsForUpdate(existingCompanyBObj,
				inputCompanyBObj, control);
		comparePartyAddressBObjsForUpdate(existingCompanyBObj,
				inputCompanyBObj, control);
		comparePartyContactMethodBObjsForUpdate(existingCompanyBObj,
				inputCompanyBObj, control);
		compareAdminContEquivBObjsForUpdateNoDescription(existingCompanyBObj,
				inputCompanyBObj, control);

		// Changed for marketName CMPVAL (25 May 2018)
		control.put("marketName", marketName);
		// Changed for marketName CMPVAL (25 May 2018)

		// Run the updateOrg Transaction
		inputCompanyBObj.setControl(control);
		System.out.println(inputCompanyBObj.toXML());
		addUpdatePartyResponse = mdmTransaction(
				inputCompanyBObj,
				control,
				DSEACompositeArchConstant.UPDATE_ORG_TXN,
				DSEAArchSimplificationComponentID.MAINTAIN_COMPANY_BUSINESS_PROXY);
		throwExceptionifTXNFail(addUpdatePartyResponse, sb);

		if (addUpdatePartyResponse != null) {

			companyResponseBObj = (XOrgBObjExt) addUpdatePartyResponse
					.getData();

			if (companyResponseBObj == null) {

				throwExceptionifTXNFail(addUpdatePartyResponse, sb);

			} else if (companyResponseBObj.getStatus().getStatus() == DWLStatus.FATAL) {

				throwExceptionifTXNFail(addUpdatePartyResponse, sb);
			}
		} else {

			throwExceptionifTXNFail(addUpdatePartyResponse, sb);
		}
	
		return companyResponseBObj;

	}
	
	public XOrgBObjExt updateCompanyWholesaleTUR(XOrgBObjExt companyResponseBObj,
			DSEAAdditionsExtsComponent additionsExtsComponent,
			XOrgBObjExt inputCompanyBObj, XOrgBObjExt outputCompanyBObj,
			DWLControl control, String partyId) throws BusinessProxyException,
			Exception {
		// TODO Auto-generated method stub

		DWLResponse addUpdatePartyResponse = null;
		XOrgBObjExt existingCompanyBObj = new XOrgBObjExt();
		TCRMPartyComponent partyComponent = new TCRMPartyComponent();
		XOrgBObjExt requestBObj = new XOrgBObjExt();
		String marketName;
		XContEquivBObjExt existingUCIDBObj = new XContEquivBObjExt();
		XContEquivBObjExt existingSFDCBObj = new XContEquivBObjExt();

		try {
			existingCompanyBObj = (XOrgBObjExt) partyComponent.getOrganization(
					partyId, "2", control);
		}
		// throw error if Get Person Failed
		catch (TCRMException e) {
			e.printStackTrace();

			DWLError error = errHandler
					.getErrorMessage(
							DSEAArchSimplificationComponentID.MAINTAIN_COMPANY_BUSINESS_PROXY,
							"UPDERR",
							DSEAArchSimplificationErrorReasonCode.MAINTAIN_COMPANY_UPDATE_FAILED,
							control, new String[0]);
			// vectReqDWLError.add(error);
			throw new BusinessProxyException(error.getErrorMessage());

		}
		// throw error if no person data is fetched
		if (existingCompanyBObj == null) {

			DWLError error = errHandler
					.getErrorMessage(
							DSEAArchSimplificationComponentID.MAINTAIN_COMPANY_BUSINESS_PROXY,
							"UPDERR",
							DSEAArchSimplificationErrorReasonCode.MAINTAIN_COMPANY_UPDATE_FAILED,
							control, new String[0]);
			// vectReqDWLError.add(error);
			throw new BusinessProxyException(error.getErrorMessage());
		}

		// Update the mainInputBObj for the updatePerson transaction

		setUpdateCompanyBObj(inputCompanyBObj, requestBObj,
				existingCompanyBObj, control);

		// Changed for marketName CMPVAL
		marketName = inputCompanyBObj.getXMarketName();
		// Changed for marketName CMPVAL

		// Compare the request BObjs with existing BObjs
		compareCompanyNameBObjsForUpdate(existingCompanyBObj, inputCompanyBObj,
				control);
		comparePartyIdentificationBObjsForUpdate(existingCompanyBObj,
				inputCompanyBObj, control);
		comparePartyAddressBObjsForUpdateME(existingCompanyBObj,
				inputCompanyBObj, control);
		comparePartyContactMethodBObjsForUpdate(existingCompanyBObj,
				inputCompanyBObj, control);
		compareAdminContEquivBObjsForUpdateNoDescription(existingCompanyBObj,
				inputCompanyBObj, control);

		// Changed for marketName CMPVAL (25 May 2018)
		control.put("marketName", marketName);
		// Changed for marketName CMPVAL (25 May 2018)

		// Run the updateOrg Transaction
		inputCompanyBObj.setControl(control);
		System.out.println(inputCompanyBObj.toXML());
		addUpdatePartyResponse = mdmTransaction(
				inputCompanyBObj,
				control,
				DSEACompositeArchConstant.UPDATE_ORG_TXN,
				DSEAArchSimplificationComponentID.MAINTAIN_COMPANY_BUSINESS_PROXY);
		throwExceptionifTXNFail(addUpdatePartyResponse, sb);

		if (addUpdatePartyResponse != null) {

			companyResponseBObj = (XOrgBObjExt) addUpdatePartyResponse
					.getData();

			if (companyResponseBObj == null) {

				throwExceptionifTXNFail(addUpdatePartyResponse, sb);

			} else if (companyResponseBObj.getStatus().getStatus() == DWLStatus.FATAL) {

				throwExceptionifTXNFail(addUpdatePartyResponse, sb);
			}
		} else {

			throwExceptionifTXNFail(addUpdatePartyResponse, sb);
		}
	
		return companyResponseBObj;

	}

	public XOrgBObjExt updateCompanyWholesaleEG(
			XOrgBObjExt companyResponseBObj,
			DSEAAdditionsExtsComponent additionsExtsComponent,
			XOrgBObjExt inputCompanyBObj, XOrgBObjExt outputCompanyBObj,
			DWLControl control, String partyId) throws BusinessProxyException,
			Exception {
		// TODO Auto-generated method stub

		DWLResponse addUpdatePartyResponse = null;
		XOrgBObjExt existingCompanyBObj = new XOrgBObjExt();
		TCRMPartyComponent partyComponent = new TCRMPartyComponent();
		XOrgBObjExt requestBObj = new XOrgBObjExt();
		String marketName;
		XContEquivBObjExt existingUCIDBObj = new XContEquivBObjExt();
		XContEquivBObjExt existingSFDCBObj = new XContEquivBObjExt();

		try {
			existingCompanyBObj = (XOrgBObjExt) partyComponent.getOrganization(
					partyId, "2", control);
		}
		// throw error if Get Person Failed
		catch (TCRMException e) {
			e.printStackTrace();

			DWLError error = errHandler
					.getErrorMessage(
							DSEAArchSimplificationComponentID.MAINTAIN_COMPANY_BUSINESS_PROXY,
							"UPDERR",
							DSEAArchSimplificationErrorReasonCode.MAINTAIN_COMPANY_UPDATE_FAILED,
							control, new String[0]);
			// vectReqDWLError.add(error);
			throw new BusinessProxyException(error.getErrorMessage());

		}
		// throw error if no person data is fetched
		if (existingCompanyBObj == null) {

			DWLError error = errHandler
					.getErrorMessage(
							DSEAArchSimplificationComponentID.MAINTAIN_COMPANY_BUSINESS_PROXY,
							"UPDERR",
							DSEAArchSimplificationErrorReasonCode.MAINTAIN_COMPANY_UPDATE_FAILED,
							control, new String[0]);
			// vectReqDWLError.add(error);
			throw new BusinessProxyException(error.getErrorMessage());
		}

		// Update the mainInputBObj for the updatePerson transaction

		setUpdateCompanyBObj(inputCompanyBObj, requestBObj,
				existingCompanyBObj, control);

		// Changed for marketName CMPVAL
		marketName = inputCompanyBObj.getXMarketName();
		// Changed for marketName CMPVAL

		// Compare the request BObjs with existing BObjs
		compareCompanyNameBObjsForUpdate(existingCompanyBObj, inputCompanyBObj,
				control);
		comparePartyIdentificationBObjsForUpdate(existingCompanyBObj,
				inputCompanyBObj, control);
		comparePartyAddressBObjsForUpdate(existingCompanyBObj,
				inputCompanyBObj, control);
		comparePartyContactMethodBObjsForUpdate(existingCompanyBObj,
				inputCompanyBObj, control);
		compareAdminContEquivBObjsForUpdateNoDescription(existingCompanyBObj,
				inputCompanyBObj, control);

		// Changed for marketName CMPVAL (25 May 2018)
		control.put("marketName", marketName);
		// Changed for marketName CMPVAL (25 May 2018)

		// Run the updateOrg Transaction
		inputCompanyBObj.setControl(control);
		System.out.println(inputCompanyBObj.toXML());
		addUpdatePartyResponse = mdmTransaction(
				inputCompanyBObj,
				control,
				DSEACompositeArchConstant.UPDATE_ORG_TXN,
				DSEAArchSimplificationComponentID.MAINTAIN_COMPANY_BUSINESS_PROXY);
		throwExceptionifTXNFail(addUpdatePartyResponse, sb);

		if (addUpdatePartyResponse != null) {

			companyResponseBObj = (XOrgBObjExt) addUpdatePartyResponse
					.getData();

			if (companyResponseBObj == null) {

				throwExceptionifTXNFail(addUpdatePartyResponse, sb);

			} else if (companyResponseBObj.getStatus().getStatus() == DWLStatus.FATAL) {

				throwExceptionifTXNFail(addUpdatePartyResponse, sb);
			}
		} else {

			throwExceptionifTXNFail(addUpdatePartyResponse, sb);
		}

		return companyResponseBObj;

	}

	public XOrgBObjExt updateCompanyWholesaleANZ(
			XOrgBObjExt companyResponseBObj,
			DSEAAdditionsExtsComponent additionsExtsComponent,
			XOrgBObjExt inputCompanyBObj, XOrgBObjExt outputCompanyBObj,
			DWLControl control, String partyId) throws BusinessProxyException,
			Exception {
		// TODO Auto-generated method stub

		DWLResponse addUpdatePartyResponse = null;
		XOrgBObjExt existingCompanyBObj = new XOrgBObjExt();
		TCRMPartyComponent partyComponent = new TCRMPartyComponent();
		XOrgBObjExt requestBObj = new XOrgBObjExt();
		String marketName;
		XContEquivBObjExt existingUCIDBObj = new XContEquivBObjExt();
		XContEquivBObjExt existingSFDCBObj = new XContEquivBObjExt();

		try {
			existingCompanyBObj = (XOrgBObjExt) partyComponent.getOrganization(
					partyId, "2", control);
		}
		// throw error if Get Person Failed
		catch (TCRMException e) {
			e.printStackTrace();

			DWLError error = errHandler
					.getErrorMessage(
							DSEAArchSimplificationComponentID.MAINTAIN_COMPANY_BUSINESS_PROXY,
							"UPDERR",
							DSEAArchSimplificationErrorReasonCode.MAINTAIN_COMPANY_UPDATE_FAILED,
							control, new String[0]);
			// vectReqDWLError.add(error);
			throw new BusinessProxyException(error.getErrorMessage());

		}
		// throw error if no person data is fetched
		if (existingCompanyBObj == null) {

			DWLError error = errHandler
					.getErrorMessage(
							DSEAArchSimplificationComponentID.MAINTAIN_COMPANY_BUSINESS_PROXY,
							"UPDERR",
							DSEAArchSimplificationErrorReasonCode.MAINTAIN_COMPANY_UPDATE_FAILED,
							control, new String[0]);
			// vectReqDWLError.add(error);
			throw new BusinessProxyException(error.getErrorMessage());
		}

		// Update the mainInputBObj for the updatePerson transaction

		setUpdateCompanyBObj(inputCompanyBObj, requestBObj,
				existingCompanyBObj, control);

		// Changed for marketName CMPVAL
		marketName = inputCompanyBObj.getXMarketName();
		// Changed for marketName CMPVAL

		// Compare the request BObjs with existing BObjs
		compareCompanyNameBObjsForUpdate(existingCompanyBObj, inputCompanyBObj,
				control);
		comparePartyIdentificationBObjsForUpdate(existingCompanyBObj,
				inputCompanyBObj, control);
		comparePartyAddressBObjsForUpdateME(existingCompanyBObj,
				inputCompanyBObj, control);
		comparePartyContactMethodBObjsForUpdate(existingCompanyBObj,
				inputCompanyBObj, control);
		compareAdminContEquivBObjsForUpdateNoDescription(existingCompanyBObj,
				inputCompanyBObj, control);

		// Changed for marketName CMPVAL (25 May 2018)
		control.put("marketName", marketName);
		// Changed for marketName CMPVAL (25 May 2018)

		// Run the updateOrg Transaction
		inputCompanyBObj.setControl(control);
		System.out.println(inputCompanyBObj.toXML());
		addUpdatePartyResponse = mdmTransaction(
				inputCompanyBObj,
				control,
				DSEACompositeArchConstant.UPDATE_ORG_TXN,
				DSEAArchSimplificationComponentID.MAINTAIN_COMPANY_BUSINESS_PROXY);
		throwExceptionifTXNFail(addUpdatePartyResponse, sb);

		if (addUpdatePartyResponse != null) {

			companyResponseBObj = (XOrgBObjExt) addUpdatePartyResponse
					.getData();

			if (companyResponseBObj == null) {

				throwExceptionifTXNFail(addUpdatePartyResponse, sb);

			} else if (companyResponseBObj.getStatus().getStatus() == DWLStatus.FATAL) {

				throwExceptionifTXNFail(addUpdatePartyResponse, sb);
			}
		} else {

			throwExceptionifTXNFail(addUpdatePartyResponse, sb);
		}

		return companyResponseBObj;

	}

	public XOrgBObjExt updateCompanyWholesaleCL1(
			XOrgBObjExt companyResponseBObj,
			DSEAAdditionsExtsComponent additionsExtsComponent,
			XOrgBObjExt inputCompanyBObj, XOrgBObjExt outputCompanyBObj,
			DWLControl control, String partyId) throws BusinessProxyException,
			Exception {
		// TODO Auto-generated method stub

		DWLResponse addUpdatePartyResponse = null;
		XOrgBObjExt existingCompanyBObj = new XOrgBObjExt();
		TCRMPartyComponent partyComponent = new TCRMPartyComponent();
		XOrgBObjExt requestBObj = new XOrgBObjExt();
		String marketName;
		XContEquivBObjExt existingUCIDBObj = new XContEquivBObjExt();
		XContEquivBObjExt existingSFDCBObj = new XContEquivBObjExt();

		try {
			existingCompanyBObj = (XOrgBObjExt) partyComponent.getOrganization(
					partyId, "2", control);
		}
		// throw error if Get Person Failed
		catch (TCRMException e) {
			e.printStackTrace();

			DWLError error = errHandler
					.getErrorMessage(
							DSEAArchSimplificationComponentID.MAINTAIN_COMPANY_BUSINESS_PROXY,
							"UPDERR",
							DSEAArchSimplificationErrorReasonCode.MAINTAIN_COMPANY_UPDATE_FAILED,
							control, new String[0]);
			// vectReqDWLError.add(error);
			throw new BusinessProxyException(error.getErrorMessage());

		}
		// throw error if no person data is fetched
		if (existingCompanyBObj == null) {

			DWLError error = errHandler
					.getErrorMessage(
							DSEAArchSimplificationComponentID.MAINTAIN_COMPANY_BUSINESS_PROXY,
							"UPDERR",
							DSEAArchSimplificationErrorReasonCode.MAINTAIN_COMPANY_UPDATE_FAILED,
							control, new String[0]);
			// vectReqDWLError.add(error);
			throw new BusinessProxyException(error.getErrorMessage());
		}

		// Update the mainInputBObj for the updatePerson transaction

		setUpdateCompanyBObj(inputCompanyBObj, requestBObj,
				existingCompanyBObj, control);

		// Changed for marketName CMPVAL
		marketName = inputCompanyBObj.getXMarketName();
		// Changed for marketName CMPVAL

		// Compare the request BObjs with existing BObjs
		compareCompanyNameBObjsForUpdate(existingCompanyBObj, inputCompanyBObj,
				control);
		comparePartyIdentificationBObjsForUpdate(existingCompanyBObj,
				inputCompanyBObj, control);
		comparePartyAddressBObjsForUpdate(existingCompanyBObj,
				inputCompanyBObj, control);
		comparePartyContactMethodBObjsForUpdate(existingCompanyBObj,
				inputCompanyBObj, control);
		compareAdminContEquivBObjsForUpdateNoDescription(existingCompanyBObj,
				inputCompanyBObj, control);

		// Changed for marketName CMPVAL (25 May 2018)
		control.put("marketName", marketName);
		// Changed for marketName CMPVAL (25 May 2018)

		// Run the updateOrg Transaction
		inputCompanyBObj.setControl(control);
		System.out.println(inputCompanyBObj.toXML());
		addUpdatePartyResponse = mdmTransaction(
				inputCompanyBObj,
				control,
				DSEACompositeArchConstant.UPDATE_ORG_TXN,
				DSEAArchSimplificationComponentID.MAINTAIN_COMPANY_BUSINESS_PROXY);
		throwExceptionifTXNFail(addUpdatePartyResponse, sb);

		if (addUpdatePartyResponse != null) {

			companyResponseBObj = (XOrgBObjExt) addUpdatePartyResponse
					.getData();

			if (companyResponseBObj == null) {

				throwExceptionifTXNFail(addUpdatePartyResponse, sb);

			} else if (companyResponseBObj.getStatus().getStatus() == DWLStatus.FATAL) {

				throwExceptionifTXNFail(addUpdatePartyResponse, sb);
			}
		} else {

			throwExceptionifTXNFail(addUpdatePartyResponse, sb);
		}

		return companyResponseBObj;

	}
	
	public XOrgBObjExt updateCompanyWholesaleME(
			XOrgBObjExt companyResponseBObj,
			DSEAAdditionsExtsComponent additionsExtsComponent,
			XOrgBObjExt inputCompanyBObj, XOrgBObjExt outputCompanyBObj,
			DWLControl control, String partyId) throws BusinessProxyException,
			Exception {
		// TODO Auto-generated method stub

		DWLResponse addUpdatePartyResponse = null;
		XOrgBObjExt existingCompanyBObj = new XOrgBObjExt();
		TCRMPartyComponent partyComponent = new TCRMPartyComponent();
		XOrgBObjExt requestBObj = new XOrgBObjExt();
		String marketName;
		XContEquivBObjExt existingUCIDBObj = new XContEquivBObjExt();
		XContEquivBObjExt existingSFDCBObj = new XContEquivBObjExt();

		try {
			existingCompanyBObj = (XOrgBObjExt) partyComponent.getOrganization(
					partyId, "2", control);
		}
		// throw error if Get Person Failed
		catch (TCRMException e) {
			e.printStackTrace();

			DWLError error = errHandler
					.getErrorMessage(
							DSEAArchSimplificationComponentID.MAINTAIN_COMPANY_BUSINESS_PROXY,
							"UPDERR",
							DSEAArchSimplificationErrorReasonCode.MAINTAIN_COMPANY_UPDATE_FAILED,
							control, new String[0]);
			// vectReqDWLError.add(error);
			throw new BusinessProxyException(error.getErrorMessage());

		}
		// throw error if no person data is fetched
		if (existingCompanyBObj == null) {

			DWLError error = errHandler
					.getErrorMessage(
							DSEAArchSimplificationComponentID.MAINTAIN_COMPANY_BUSINESS_PROXY,
							"UPDERR",
							DSEAArchSimplificationErrorReasonCode.MAINTAIN_COMPANY_UPDATE_FAILED,
							control, new String[0]);
			// vectReqDWLError.add(error);
			throw new BusinessProxyException(error.getErrorMessage());
		}

		// Update the mainInputBObj for the updatePerson transaction

		setUpdateCompanyBObj(inputCompanyBObj, requestBObj,
				existingCompanyBObj, control);

		// Changed for marketName CMPVAL
		marketName = inputCompanyBObj.getXMarketName();
		// Changed for marketName CMPVAL

		// Compare the request BObjs with existing BObjs
		compareCompanyNameBObjsForUpdate(existingCompanyBObj, inputCompanyBObj,
				control);
		comparePartyIdentificationBObjsForUpdate(existingCompanyBObj,
				inputCompanyBObj, control);
		comparePartyAddressBObjsForUpdateME(existingCompanyBObj,
				inputCompanyBObj, control);
		comparePartyContactMethodBObjsForUpdate(existingCompanyBObj,
				inputCompanyBObj, control);
		compareAdminContEquivBObjsForUpdateNoDescription(existingCompanyBObj,
				inputCompanyBObj, control);

		// Changed for marketName CMPVAL (25 May 2018)
		control.put("marketName", marketName);
		// Changed for marketName CMPVAL (25 May 2018)

		// Run the updateOrg Transaction
		inputCompanyBObj.setControl(control);
		System.out.println(inputCompanyBObj.toXML());
		addUpdatePartyResponse = mdmTransaction(
				inputCompanyBObj,
				control,
				DSEACompositeArchConstant.UPDATE_ORG_TXN,
				DSEAArchSimplificationComponentID.MAINTAIN_COMPANY_BUSINESS_PROXY);
		throwExceptionifTXNFail(addUpdatePartyResponse, sb);

		if (addUpdatePartyResponse != null) {

			companyResponseBObj = (XOrgBObjExt) addUpdatePartyResponse
					.getData();

			if (companyResponseBObj == null) {

				throwExceptionifTXNFail(addUpdatePartyResponse, sb);

			} else if (companyResponseBObj.getStatus().getStatus() == DWLStatus.FATAL) {

				throwExceptionifTXNFail(addUpdatePartyResponse, sb);
			}
		} else {

			throwExceptionifTXNFail(addUpdatePartyResponse, sb);
		}

		return companyResponseBObj;

	}
	/**
	 * 
	 * @param companyResponseBObj
	 * @param additionsExtsComponent
	 * @param inputCompanyBObj
	 * @param outputCompanyBObj
	 * @param control
	 * @param partyId
	 * @return
	 * @throws BusinessProxyException
	 * @throws Exception
	 */
	public XOrgBObjExt updateCompanyWholesaleJPN(
			XOrgBObjExt companyResponseBObj,
			DSEAAdditionsExtsComponent additionsExtsComponent,
			XOrgBObjExt inputCompanyBObj, XOrgBObjExt outputCompanyBObj,
			DWLControl control, String partyId) throws BusinessProxyException,
			Exception {
		

		DWLResponse addUpdatePartyResponse = null;
		XOrgBObjExt existingCompanyBObj = new XOrgBObjExt();
		TCRMPartyComponent partyComponent = new TCRMPartyComponent();
		XOrgBObjExt requestBObj = new XOrgBObjExt();
		String marketName;
	
		try {
			existingCompanyBObj = (XOrgBObjExt) partyComponent.getOrganization(
					partyId, "4", control);
			
			}
		// throw error if Get Person Failed
		catch (TCRMException e) {
			e.printStackTrace();

			DWLError error = errHandler
					.getErrorMessage(
							DSEAArchSimplificationComponentID.MAINTAIN_COMPANY_BUSINESS_PROXY,
							"UPDERR",
							DSEAArchSimplificationErrorReasonCode.MAINTAIN_COMPANY_UPDATE_FAILED,
							control, new String[0]);
			// vectReqDWLError.add(error);
			throw new BusinessProxyException(error.getErrorMessage());

		}
		// throw error if no person data is fetched
		if (existingCompanyBObj == null) {

			DWLError error = errHandler
					.getErrorMessage(
							DSEAArchSimplificationComponentID.MAINTAIN_COMPANY_BUSINESS_PROXY,
							"UPDERR",
							DSEAArchSimplificationErrorReasonCode.MAINTAIN_COMPANY_UPDATE_FAILED,
							control, new String[0]);
			// vectReqDWLError.add(error);
			throw new BusinessProxyException(error.getErrorMessage());
		}

		// Update the mainInputBObj for the updatePerson transaction

		setUpdateCompanyBObj(inputCompanyBObj, requestBObj,
				existingCompanyBObj, control);

		// Changed for marketName CMPVAL
		marketName = inputCompanyBObj.getXMarketName();
		// Changed for marketName CMPVAL

		// Compare the request BObjs with existing BObjs
		compareCompanyNameBObjsForUpdate(existingCompanyBObj, inputCompanyBObj,
				control);
		comparePartyIdentificationBObjsForUpdate(existingCompanyBObj,
				inputCompanyBObj, control);
		comparePartyAddressBObjsForUpdateJPN(existingCompanyBObj,
				inputCompanyBObj, control);
		comparePartyContactMethodBObjsForUpdateJPN(existingCompanyBObj,
				inputCompanyBObj, control);
		compareAdminContEquivBObjsForUpdateNoDescriptionJPN(existingCompanyBObj,
				inputCompanyBObj, control,partyComponent,partyId);
		/*comparePartyAddressBObjsForUpdate(existingCompanyBObj,
				inputCompanyBObj, control);*/
		//System.out.println("comparePartyContactMethodBObjsForUpdateJPN_3_inputCompanyBObj"+inputCompanyBObj.toXML());
		/*comparePartyContactMethodBObjsForUpdate(existingCompanyBObj,
				inputCompanyBObj, control);*/
		/*compareAdminContEquivBObjsForUpdateNoDescription(existingCompanyBObj,
				inputCompanyBObj, control);*/
		

		// Changed for marketName CMPVAL (25 May 2018)
		control.put("marketName", marketName);
		// Changed for marketName CMPVAL (25 May 2018)

		// Run the updateOrg Transaction
		inputCompanyBObj.setControl(control);
		//System.out.println(inputCompanyBObj.toXML());
		addUpdatePartyResponse = mdmTransaction(
				inputCompanyBObj,
				control,
				DSEACompositeArchConstant.UPDATE_ORG_TXN,
				DSEAArchSimplificationComponentID.MAINTAIN_COMPANY_BUSINESS_PROXY);
		throwExceptionifTXNFail(addUpdatePartyResponse, sb);

		if (addUpdatePartyResponse != null) {

			companyResponseBObj = (XOrgBObjExt) addUpdatePartyResponse
					.getData();

			if (companyResponseBObj == null) {

				throwExceptionifTXNFail(addUpdatePartyResponse, sb);

			} else if (companyResponseBObj.getStatus().getStatus() == DWLStatus.FATAL) {

				throwExceptionifTXNFail(addUpdatePartyResponse, sb);
			}
		} else {

			throwExceptionifTXNFail(addUpdatePartyResponse, sb);
		}

		return companyResponseBObj;

	}

	public XOrgBObjExt updateCompanyWholesaleIND(
			XOrgBObjExt companyResponseBObj,
			DSEAAdditionsExtsComponent additionsExtsComponent,
			XOrgBObjExt inputCompanyBObj, XOrgBObjExt outputCompanyBObj,
			DWLControl control, String partyId) throws BusinessProxyException,
			Exception {
		// TODO Auto-generated method stub

		DWLResponse addUpdatePartyResponse = null;
		XOrgBObjExt existingCompanyBObj = new XOrgBObjExt();
		TCRMPartyComponent partyComponent = new TCRMPartyComponent();
		XOrgBObjExt requestBObj = new XOrgBObjExt();
		String marketName;
		XContEquivBObjExt existingUCIDBObj = new XContEquivBObjExt();
		XContEquivBObjExt existingSFDCBObj = new XContEquivBObjExt();

		try {
			existingCompanyBObj = (XOrgBObjExt) partyComponent.getOrganization(
					partyId, "2", control);
		}
		// throw error if Get Person Failed
		catch (TCRMException e) {
			e.printStackTrace();

			DWLError error = errHandler
					.getErrorMessage(
							DSEAArchSimplificationComponentID.MAINTAIN_COMPANY_BUSINESS_PROXY,
							"UPDERR",
							DSEAArchSimplificationErrorReasonCode.MAINTAIN_COMPANY_UPDATE_FAILED,
							control, new String[0]);
			// vectReqDWLError.add(error);
			throw new BusinessProxyException(error.getErrorMessage());

		}
		// throw error if no person data is fetched
		if (existingCompanyBObj == null) {

			DWLError error = errHandler
					.getErrorMessage(
							DSEAArchSimplificationComponentID.MAINTAIN_COMPANY_BUSINESS_PROXY,
							"UPDERR",
							DSEAArchSimplificationErrorReasonCode.MAINTAIN_COMPANY_UPDATE_FAILED,
							control, new String[0]);
			// vectReqDWLError.add(error);
			throw new BusinessProxyException(error.getErrorMessage());
		}

		// Update the mainInputBObj for the updatePerson transaction

		setUpdateCompanyBObj(inputCompanyBObj, requestBObj,
				existingCompanyBObj, control);

		// Changed for marketName CMPVAL
		marketName = inputCompanyBObj.getXMarketName();
		// Changed for marketName CMPVAL

		// Compare the request BObjs with existing BObjs
		compareCompanyNameBObjsForUpdate(existingCompanyBObj, inputCompanyBObj,
				control);
		comparePartyIdentificationBObjsForUpdate(existingCompanyBObj,
				inputCompanyBObj, control);
		comparePartyAddressBObjsForUpdateME(existingCompanyBObj,
				inputCompanyBObj, control);
		comparePartyContactMethodBObjsForUpdate(existingCompanyBObj,
				inputCompanyBObj, control);
		compareAdminContEquivBObjsForUpdateNoDescription(existingCompanyBObj,
				inputCompanyBObj, control);

		// Changed for marketName CMPVAL (25 May 2018)
		control.put("marketName", marketName);
		// Changed for marketName CMPVAL (25 May 2018)

		// Run the updateOrg Transaction
		inputCompanyBObj.setControl(control);
		System.out.println(inputCompanyBObj.toXML());
		addUpdatePartyResponse = mdmTransaction(
				inputCompanyBObj,
				control,
				DSEACompositeArchConstant.UPDATE_ORG_TXN,
				DSEAArchSimplificationComponentID.MAINTAIN_COMPANY_BUSINESS_PROXY);
		throwExceptionifTXNFail(addUpdatePartyResponse, sb);

		if (addUpdatePartyResponse != null) {

			companyResponseBObj = (XOrgBObjExt) addUpdatePartyResponse
					.getData();

			if (companyResponseBObj == null) {

				throwExceptionifTXNFail(addUpdatePartyResponse, sb);

			} else if (companyResponseBObj.getStatus().getStatus() == DWLStatus.FATAL) {

				throwExceptionifTXNFail(addUpdatePartyResponse, sb);
			}
		} else {

			throwExceptionifTXNFail(addUpdatePartyResponse, sb);
		}

		return companyResponseBObj;

	}

	private void compareCompanyNameBObjsForUpdate(
			XOrgBObjExt existingCompanyBObj, XOrgBObjExt inputCompanyBObj,
			DWLControl control) throws BusinessProxyException {
		// TODO Auto-generated method stub

		Vector<XOrgNameBObjExt> existingCompanyNameBObjs = existingCompanyBObj
				.getItemsTCRMOrganizationNameBObj();
		Vector<XOrgNameBObjExt> requestCompanyNameBObjs = inputCompanyBObj
				.getItemsTCRMOrganizationNameBObj();
		String requestOrgName = null;
		String dbOrgName = null;

		if (requestCompanyNameBObjs.size() > 0) {

			for (XOrgNameBObjExt requestCompanyNameBObj : requestCompanyNameBObjs) {

				requestOrgName = requestCompanyNameBObj.getOrganizationName();
				String requestNameUsageTp = requestCompanyNameBObj
						.getNameUsageType();

				for (XOrgNameBObjExt existingCompanyNameBObj : existingCompanyNameBObjs) {
					// Check with Name Usage Type
					dbOrgName = existingCompanyNameBObj.getOrganizationName();

					if (existingCompanyNameBObj.getNameUsageType().equals(
							requestNameUsageTp)) {

						try {
							requestCompanyNameBObj.setControl(control);
							requestCompanyNameBObj
									.setOrganizationNameIdPK(existingCompanyNameBObj
											.getOrganizationNameIdPK());
							requestCompanyNameBObj
									.setOrganizationPartyId(existingCompanyNameBObj
											.getOrganizationPartyId());
							requestCompanyNameBObj
									.setOrganizationNameLastUpdateDate(existingCompanyNameBObj
											.getOrganizationNameLastUpdateDate());

							if (requestOrgName.equals(dbOrgName)) {
								requestCompanyNameBObj
										.setXLastModifiedSystemDate(existingCompanyBObj
												.getXLastModifiedSystemDate());
							}

							break;
						} catch (Exception e) {
							// e.printStackTrace();
							DWLError error = errHandler
									.getErrorMessage(
											TCRMCoreComponentID.PERSON_NAME_OBJECT,
											"UPDERR",
											TCRMCoreErrorReasonCode.UPDATE_ORG_NAME_FAILED,
											control, new String[0]);
							// vectReqDWLError.add(error);
							throw new BusinessProxyException(
									error.getErrorMessage());
						}
					}
				}
			}
		}

	}

	public void setUpdateCompanyBObj(XOrgBObjExt inputCompanyBObj,
			XOrgBObjExt requestBObj, XOrgBObjExt existingCompanyBObj,
			DWLControl control) throws BusinessProxyException {
		try {

			inputCompanyBObj.setPartyId(existingCompanyBObj.getPartyId());
			inputCompanyBObj.setOrganizationPartyId(existingCompanyBObj
					.getOrganizationPartyId());
			inputCompanyBObj.setPartyLastUpdateDate(existingCompanyBObj
					.getPartyLastUpdateDate());

			inputCompanyBObj.setOrganizationLastUpdateDate(existingCompanyBObj
					.getOrganizationLastUpdateDate());

		} catch (Exception e) {
			logger.finest(e);
			e.printStackTrace();
			DWLError error = errHandler
					.getErrorMessage(
							DSEAArchSimplificationComponentID.MAINTAIN_INDIVIDUAL_BUSINESS_PROXY,
							"UPDERR",
							DSEAArchSimplificationErrorReasonCode.MAINTAIN_COMPANY_UPDATE_FAILED,
							control, new String[0]);
			// vectReqDWLError.add(error);
			throw new BusinessProxyException(error.getErrorMessage());
		}
	}
	/**
	 * 
	 * @param xdataSharingInputReqBObj
	 * @param transaction
	 * @param control
	 * @throws BusinessProxyException
	 */
	public void handleInputXDataSharing(
			XDataSharingBObj xdataSharingInputReqBObj, String transaction,
			DWLControl control) throws BusinessProxyException {

		try {
			xdataSharingInputReqBObj
					.setRetailerFlag(DSEACompositeArchConstant.FLAG_N);
			xdataSharingInputReqBObj.setRetailerId(null);
			// vecXDataSharingFinalReqObj.add(xdataSharingInputReqBObj);
			// }
		} catch (Exception e) {
			throw new BusinessProxyException(e.getMessage());
		}
	}
	/**
	 * 
	 * @param partyOutObj
	 * @param vecExistingDataSharingObj
	 * @param xdataSharingInputReqBObj
	 * @param sb
	 * @param control
	 * @return
	 * @throws BusinessProxyException
	 */
	public XDataSharingBObj maintainXDataSharingJPN(TCRMPartyBObj partyOutObj,
			Vector<XDataSharingBObj> vecExistingDataSharingObj,
			XDataSharingBObj xdataSharingInputReqBObj, StringBuffer sb,
			DWLControl control) throws BusinessProxyException {
		try {
			Vector<XDataSharingBObj> vecXDataSharingOutput = new Vector<XDataSharingBObj>();
			XDataSharingBObj finalXDataSharingResp = null;
			DWLResponse updateXDataSharingResponse = null;

			if (null != xdataSharingInputReqBObj) {

				if (vecExistingDataSharingObj != null)

					for (XDataSharingBObj existingXDataSharingObj : vecExistingDataSharingObj) {
						if (existingXDataSharingObj!=null && existingXDataSharingObj.getDataSharingFlag()!= null &&
								(!existingXDataSharingObj.getDataSharingFlag().equalsIgnoreCase((DSEACompositeArchConstant.FLAG_Y)))){
						xdataSharingInputReqBObj
								.setXDataSharingLastUpdateDate(existingXDataSharingObj
										.getXDataSharingLastUpdateDate());
						xdataSharingInputReqBObj
								.setDataSharingpkId(existingXDataSharingObj
										.getDataSharingpkId());
						xdataSharingInputReqBObj
								.setContId(existingXDataSharingObj.getContId());
					
						// XDataSharingReqObj.setRetailerFlag(DSEACompositeArchConstant.FLAG_N);
						xdataSharingInputReqBObj.setRetailerId(null);
						xdataSharingInputReqBObj.setControl(control);
						updateXDataSharingResponse = addUpdateXDataSharing(
								xdataSharingInputReqBObj,
								control,
								DSEACompositeArchConstant.TXN_NAME_UPDATEXDATASHARING,
								updateXDataSharingResponse);

						throwExceptionifTXNFail(updateXDataSharingResponse, sb);
						if (updateXDataSharingResponse != null) {
							vecXDataSharingOutput
									.add((XDataSharingBObj) updateXDataSharingResponse
											.getData());
						}
					}else{
						finalXDataSharingResp=existingXDataSharingObj;
					}

				if (updateXDataSharingResponse != null) {
					finalXDataSharingResp = (XDataSharingBObj) updateXDataSharingResponse
							.getData();
				}
			}

			else {
				finalXDataSharingResp = null;
			}
			}

			return finalXDataSharingResp;
		} catch (Exception e) {
			throw new BusinessProxyException(e.getMessage());
		}

	}

	public XDataSharingBObj maintainXDataSharing(TCRMPartyBObj partyOutObj,
			Vector<XDataSharingBObj> vecExistingDataSharingObj,
			XDataSharingBObj xdataSharingInputReqBObj, StringBuffer sb,
			DWLControl control) throws BusinessProxyException {
		try {
			Vector<XDataSharingBObj> vecXDataSharingOutput = new Vector<XDataSharingBObj>();
			XDataSharingBObj finalXDataSharingResp = null;
			DWLResponse updateXDataSharingResponse = null;

			if (null != xdataSharingInputReqBObj) {

				if (vecExistingDataSharingObj != null)

					for (XDataSharingBObj existingXDataSharingObj : vecExistingDataSharingObj) {

						xdataSharingInputReqBObj
								.setXDataSharingLastUpdateDate(existingXDataSharingObj
										.getXDataSharingLastUpdateDate());
						xdataSharingInputReqBObj
								.setDataSharingpkId(existingXDataSharingObj
										.getDataSharingpkId());
						xdataSharingInputReqBObj
								.setContId(existingXDataSharingObj.getContId());
						// XDataSharingReqObj.setRetailerFlag(DSEACompositeArchConstant.FLAG_N);
						xdataSharingInputReqBObj.setRetailerId(null);
						xdataSharingInputReqBObj.setControl(control);
						updateXDataSharingResponse = addUpdateXDataSharing(
								xdataSharingInputReqBObj,
								control,
								DSEACompositeArchConstant.TXN_NAME_UPDATEXDATASHARING,
								updateXDataSharingResponse);

						throwExceptionifTXNFail(updateXDataSharingResponse, sb);
						if (updateXDataSharingResponse != null) {
							vecXDataSharingOutput
									.add((XDataSharingBObj) updateXDataSharingResponse
											.getData());
						}
					}

				if (updateXDataSharingResponse != null) {
					finalXDataSharingResp = (XDataSharingBObj) updateXDataSharingResponse
							.getData();
				}
			}

			else {
				finalXDataSharingResp = null;
			}

			return finalXDataSharingResp;
		} catch (Exception e) {
			throw new BusinessProxyException(e.getMessage());
		}

	}
	/**
	 * 
	 * @param partyOutObj
	 * @param xdataSharingInputReqBObj
	 * @param sb
	 * @param control
	 * @return
	 * @throws BusinessProxyException
	 */
	public XDataSharingBObj handleXDataSharingAdd(TCRMPartyBObj partyOutObj,
			XDataSharingBObj xdataSharingInputReqBObj, StringBuffer sb,
			DWLControl control) throws BusinessProxyException {

		try {

			Vector<XDataSharingBObj> vecXDataSharingOutput = new Vector<XDataSharingBObj>();
			XDataSharingBObj finalXDataSharingResp = null;
			DWLResponse addXDataSharingResponse = null;

			if (xdataSharingInputReqBObj != null) {

				xdataSharingInputReqBObj.setContId(partyOutObj.getPartyId());
				xdataSharingInputReqBObj.setControl(control);

				if (StringUtils.isNonBlank(xdataSharingInputReqBObj
						.getDataSharingpkId())) {
					addXDataSharingResponse = addUpdateXDataSharing(
							xdataSharingInputReqBObj,
							control,
							DSEACompositeArchConstant.TXN_NAME_UPDATEXDATASHARING,
							addXDataSharingResponse);
				} else {
					addXDataSharingResponse = addUpdateXDataSharing(
							xdataSharingInputReqBObj, control,
							DSEACompositeArchConstant.TXN_NAME_ADDXDATASHARING,
							addXDataSharingResponse);
				}

				throwExceptionifTXNFail(addXDataSharingResponse, sb);

				if (addXDataSharingResponse != null) {
					vecXDataSharingOutput
							.add((XDataSharingBObj) addXDataSharingResponse
									.getData());
				}
				finalXDataSharingResp = (XDataSharingBObj) addXDataSharingResponse
						.getData();
			} else {
				finalXDataSharingResp = null;
			}

			return finalXDataSharingResp;
		} catch (Exception e) {
			throw new BusinessProxyException(e.getMessage());
		}
	}

	public DWLResponse addUpdateXDataSharing(XDataSharingBObj xdataSharingBObj,
			DWLControl control, String txnName, DWLResponse txnResponse)
			throws Exception {

		DWLTxnBP dwlTxnBP = new DWLTxnBP();
		DWLTransactionPersistent transactionRequest = new DWLTransactionPersistent();
		// XPersonBObjExt reqPersonBObj = (XPersonBObjExt)mainInput;
		transactionRequest.setTxnControl(control);
		transactionRequest.setTxnType(txnName);
		transactionRequest.setTxnTopLevelObject(xdataSharingBObj);

		try {
			txnResponse = (DWLResponse) dwlTxnBP.execute(transactionRequest);
		} catch (Exception e) {
			throw new BusinessProxyException(e.getMessage());

		}
		return txnResponse;

	}

	public static boolean isAddressMatched(
			XAddressGroupBObjExt firstPartyAddrBobj,
			XAddressGroupBObjExt secondPartyAddrBobj, DWLControl control)
			throws Exception {
		// validate addressMatchCriteria for Province, City,
		// Address Line 3, Residence Number, Address Line 1, Address Line 2, and
		// Company Name
		boolean isAddressLineOneMatched = false;
		boolean isAddressLineTwoMatched = false;
		boolean isAddressLineThreeMatched = false;
		boolean isCityMatched = false;
		boolean isProvinceStateValueMatched = false;
		boolean isResidenceNumberMatched = false;
		boolean isAddressMatched = false;

		XAddressBObjExt firstAddrObj = (XAddressBObjExt) firstPartyAddrBobj
				.getTCRMAddressBObj();
		XAddressBObjExt secondAddrObj = (XAddressBObjExt) secondPartyAddrBobj
				.getTCRMAddressBObj();

		if (firstAddrObj.getAddressLineOne().trim()
				.equals(secondAddrObj.getAddressLineOne().trim())) {
			isAddressLineOneMatched = true;
		}
		

		// : if both are not null then check if both same then set
		// flag =true otherwise false
		if (StringUtils.isNonBlank(secondAddrObj.getAddressLineTwo())
				&& StringUtils.isNonBlank(firstAddrObj.getAddressLineTwo())) {
			if (firstAddrObj.getAddressLineTwo().trim()
					.equals(secondAddrObj.getAddressLineTwo().trim())) {
				isAddressLineTwoMatched = true;
			}
		}
		// : if either of two is null set flag =true
		else if (!StringUtils.isNonBlank(secondAddrObj.getAddressLineTwo())
				|| !StringUtils.isNonBlank(firstAddrObj.getAddressLineTwo())) {
			isAddressLineTwoMatched = true;
		}

		// : if both are not null then check if both same then set
		// flag =true otherwise false
		if (StringUtils.isNonBlank(secondAddrObj.getAddressLineThree())
				&& StringUtils.isNonBlank(firstAddrObj.getAddressLineThree())) {
			if (firstAddrObj.getAddressLineThree().trim()
					.equals(secondAddrObj.getAddressLineThree().trim())) {
				isAddressLineThreeMatched = true;
			}
		}

		// : if either of two is null set flag =true
		else if (!StringUtils.isNonBlank(secondAddrObj.getAddressLineThree())
				|| !StringUtils.isNonBlank(firstAddrObj.getAddressLineThree())) {
			isAddressLineThreeMatched = true;
		}

		if (firstAddrObj.getCity().trim()
				.equals(secondAddrObj.getCity().trim())) {
			isCityMatched = true;
		}

		CodeTypeComponentHelper ctHelper = DWLClassFactory
				.getCodeTypeComponentHelper();
		String langId = (String) control.get(TCRMControlKeys.LANG_ID);

		String reqProvStatevalue = null;
		if (StringUtils.isNonBlank(secondAddrObj.getProvinceStateType())) {

			CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory
					.getCodeTypeComponentHelper();
			CodeTypeBObj psctBObj = codeTypeCompHelper.getCodeTypeByCode(
					"CdProvStateTp", langId,
					secondAddrObj.getProvinceStateType(), control);
			if (psctBObj != null) {
				reqProvStatevalue = psctBObj.getvalue();
			}
		}
		String resProvStatevalue = null;
		if (StringUtils.isNonBlank(firstAddrObj.getProvinceStateType())) {

			CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory
					.getCodeTypeComponentHelper();
			CodeTypeBObj rpsctBObj = codeTypeCompHelper.getCodeTypeByCode(
					"CdProvStateTp", langId,
					firstAddrObj.getProvinceStateType(), control);
			if (rpsctBObj != null) {
				resProvStatevalue = rpsctBObj.getvalue();
			}
		}
		if (!StringUtils.isNonBlank(reqProvStatevalue)
				|| !StringUtils.isNonBlank(resProvStatevalue)) {

			isProvinceStateValueMatched = true;
		} else if (StringUtils.isNonBlank(reqProvStatevalue)
				&& StringUtils.isNonBlank(resProvStatevalue)) {
			if (resProvStatevalue.trim().equals(reqProvStatevalue.trim())) {
				isProvinceStateValueMatched = true;
			}
		}

		// : if both are not null then check if both same then set
		// flag =true otherwise false
		if (StringUtils.isNonBlank(secondAddrObj.getResidenceNumber())
				&& StringUtils.isNonBlank(firstAddrObj.getResidenceNumber())) {
			if (firstAddrObj.getResidenceNumber().trim()
					.equals(secondAddrObj.getResidenceNumber().trim())) {
				isResidenceNumberMatched = true;
			}
		}

		// : if either of two is null set flag =true
		else if (!StringUtils.isNonBlank(secondAddrObj.getResidenceNumber())
				|| !StringUtils.isNonBlank(firstAddrObj.getResidenceNumber())) {
			isResidenceNumberMatched = true;
		}

		if (isAddressLineOneMatched && isAddressLineTwoMatched
				&& isAddressLineThreeMatched && isCityMatched
				&& isResidenceNumberMatched && isProvinceStateValueMatched) {
			isAddressMatched = true;

		}
		return isAddressMatched;

	}
	
	
	public static boolean isAddressMatchedME(
			XAddressGroupBObjExt firstPartyAddrBobj,
			XAddressGroupBObjExt secondPartyAddrBobj, DWLControl control)
			throws Exception {
		// validate addressMatchCriteria for Province, City,
		// Address Line 3, Residence Number, Address Line 1, Address Line 2, and
		// Company Name
		boolean isAddressLineOneMatched = false;
		boolean isAddressLineTwoMatched = false;
		boolean isAddressLineThreeMatched = false;
		boolean isCityMatched = false;
		boolean isProvinceStateValueMatched = false;
		boolean isResidenceNumberMatched = false;
		boolean isAddressMatched = false;

		XAddressBObjExt firstAddrObj = (XAddressBObjExt) firstPartyAddrBobj
				.getTCRMAddressBObj();
		XAddressBObjExt secondAddrObj = (XAddressBObjExt) secondPartyAddrBobj
				.getTCRMAddressBObj();

		if (firstAddrObj.getAddressLineOne().trim()
				.equals(secondAddrObj.getAddressLineOne().trim())) {
			isAddressLineOneMatched = true;
		}
		
		firstAddrObj.setXAddressVerificationDate(secondAddrObj.getXAddressVerificationDate());

		// : if both are not null then check if both same then set
		// flag =true otherwise false
		if (StringUtils.isNonBlank(secondAddrObj.getAddressLineTwo())
				&& StringUtils.isNonBlank(firstAddrObj.getAddressLineTwo())) {
			if (firstAddrObj.getAddressLineTwo().trim()
					.equals(secondAddrObj.getAddressLineTwo().trim())) {
				isAddressLineTwoMatched = true;
			}
		}
		// : if either of two is null set flag =true
		else if (!StringUtils.isNonBlank(secondAddrObj.getAddressLineTwo())
				|| !StringUtils.isNonBlank(firstAddrObj.getAddressLineTwo())) {
			isAddressLineTwoMatched = true;
		}

		// : if both are not null then check if both same then set
		// flag =true otherwise false
		if (StringUtils.isNonBlank(secondAddrObj.getAddressLineThree())
				&& StringUtils.isNonBlank(firstAddrObj.getAddressLineThree())) {
			if (firstAddrObj.getAddressLineThree().trim()
					.equals(secondAddrObj.getAddressLineThree().trim())) {
				isAddressLineThreeMatched = true;
			}
		}

		// : if either of two is null set flag =true
		else if (!StringUtils.isNonBlank(secondAddrObj.getAddressLineThree())
				|| !StringUtils.isNonBlank(firstAddrObj.getAddressLineThree())) {
			isAddressLineThreeMatched = true;
		}

		if (firstAddrObj.getCity().trim()
				.equals(secondAddrObj.getCity().trim())) {
			isCityMatched = true;
		}

		CodeTypeComponentHelper ctHelper = DWLClassFactory
				.getCodeTypeComponentHelper();
		String langId = (String) control.get(TCRMControlKeys.LANG_ID);

		String reqProvStatevalue = null;
		if (StringUtils.isNonBlank(secondAddrObj.getProvinceStateType())) {

			CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory
					.getCodeTypeComponentHelper();
			CodeTypeBObj psctBObj = codeTypeCompHelper.getCodeTypeByCode(
					"CdProvStateTp", langId,
					secondAddrObj.getProvinceStateType(), control);
			if (psctBObj != null) {
				reqProvStatevalue = psctBObj.getvalue();
			}
		}
		String resProvStatevalue = null;
		if (StringUtils.isNonBlank(firstAddrObj.getProvinceStateType())) {

			CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory
					.getCodeTypeComponentHelper();
			CodeTypeBObj rpsctBObj = codeTypeCompHelper.getCodeTypeByCode(
					"CdProvStateTp", langId,
					firstAddrObj.getProvinceStateType(), control);
			if (rpsctBObj != null) {
				resProvStatevalue = rpsctBObj.getvalue();
			}
		}
		if (!StringUtils.isNonBlank(reqProvStatevalue)
				|| !StringUtils.isNonBlank(resProvStatevalue)) {

			isProvinceStateValueMatched = true;
		} else if (StringUtils.isNonBlank(reqProvStatevalue)
				&& StringUtils.isNonBlank(resProvStatevalue)) {
			if (resProvStatevalue.trim().equals(reqProvStatevalue.trim())) {
				isProvinceStateValueMatched = true;
			}
		}

		// : if both are not null then check if both same then set
		// flag =true otherwise false
		if (StringUtils.isNonBlank(secondAddrObj.getResidenceNumber())
				&& StringUtils.isNonBlank(firstAddrObj.getResidenceNumber())) {
			if (firstAddrObj.getResidenceNumber().trim()
					.equals(secondAddrObj.getResidenceNumber().trim())) {
				isResidenceNumberMatched = true;
			}
		}

		// : if either of two is null set flag =true
		else if (!StringUtils.isNonBlank(secondAddrObj.getResidenceNumber())
				|| !StringUtils.isNonBlank(firstAddrObj.getResidenceNumber())) {
			isResidenceNumberMatched = true;
		}

		if (isAddressLineOneMatched && isAddressLineTwoMatched
				&& isAddressLineThreeMatched && isCityMatched
				&& isResidenceNumberMatched && isProvinceStateValueMatched) {
			isAddressMatched = true;

		}
		return isAddressMatched;

	}

	public void setIndicatorsIndividual(XPersonBObjExt inputPersonBObj)
			throws Exception {

		// Set address retailer flag
		Vector<XAddressGroupBObjExt> requestPartyAddressBObjs = inputPersonBObj
				.getItemsTCRMPartyAddressBObj();

		for (XAddressGroupBObjExt requestPartyAddressBObj : requestPartyAddressBObjs) {
			requestPartyAddressBObj
					.setXAddressRetailerFlag(DSEACompositeArchConstant.FLAG_N);
		}

		Vector<XContEquivBObjExt> requestPartyContequivBObjs = inputPersonBObj
				.getItemsTCRMAdminContEquivBObj();

		for (XContEquivBObjExt requestPartyContequivBObj : requestPartyContequivBObjs) {
			requestPartyContequivBObj
					.setDescription(DSEACompositeArchConstant.FLAG_Y);
		}

		inputPersonBObj.setXSourceTypeFlag("REARCH");

	}
	
	public void setIndicatorsIndividualTHAMYS(XPersonBObjExt inputPersonBObj)
			throws Exception {

		// Set address retailer flag
		Vector<XAddressGroupBObjExt> requestPartyAddressBObjs = inputPersonBObj
				.getItemsTCRMPartyAddressBObj();

		for (XAddressGroupBObjExt requestPartyAddressBObj : requestPartyAddressBObjs) {
			requestPartyAddressBObj
					.setXAddressRetailerFlag(DSEACompositeArchConstant.FLAG_N);
		}

		Vector<XContEquivBObjExt> requestPartyContequivBObjs = inputPersonBObj
				.getItemsTCRMAdminContEquivBObj();

		for (XContEquivBObjExt requestPartyContequivBObj : requestPartyContequivBObjs) {
			requestPartyContequivBObj
					.setXSourceRetailerFlag(DSEACompositeArchConstant.FLAG_N);
		}

		inputPersonBObj.setXSourceTypeFlag("REARCH");

	}
	
	public void setIndicatorsIndividualTUR(XPersonBObjExt inputPersonBObj)
			throws Exception {

		// Set address retailer flag
		Vector<XAddressGroupBObjExt> requestPartyAddressBObjs = inputPersonBObj
				.getItemsTCRMPartyAddressBObj();

		for (XAddressGroupBObjExt requestPartyAddressBObj : requestPartyAddressBObjs) {
			requestPartyAddressBObj
					.setXAddressRetailerFlag(DSEACompositeArchConstant.FLAG_N);
		}

		Vector<XContEquivBObjExt> requestPartyContequivBObjs = inputPersonBObj
				.getItemsTCRMAdminContEquivBObj();

		for (XContEquivBObjExt requestPartyContequivBObj : requestPartyContequivBObjs) {
			requestPartyContequivBObj
					.setXSourceRetailerFlag(DSEACompositeArchConstant.FLAG_N);
		}

		inputPersonBObj.setXSourceTypeFlag("REARCH");

	}

	public void setIndicatorsIndividualEG(XPersonBObjExt inputPersonBObj)
			throws Exception {

		// Set address retailer flag
		Vector<XAddressGroupBObjExt> requestPartyAddressBObjs = inputPersonBObj
				.getItemsTCRMPartyAddressBObj();

		for (XAddressGroupBObjExt requestPartyAddressBObj : requestPartyAddressBObjs) {
			requestPartyAddressBObj
					.setXAddressRetailerFlag(DSEACompositeArchConstant.FLAG_N);
		}

		// Set ContactMethodGroup flag
		Vector<XContactMethodGroupBObjExt> requestPartyContactMethodBObjs = inputPersonBObj
				.getItemsTCRMPartyContactMethodBObj();
		for (XContactMethodGroupBObjExt requestPartyContactMethodBObj : requestPartyContactMethodBObjs) {
			requestPartyContactMethodBObj
					.setXContactRetailerFlag(DSEACompositeArchConstant.FLAG_N);
		}

		// Set ContEquiv flag
		Vector<XContEquivBObjExt> requestPartyContEquivBObjs = inputPersonBObj
				.getItemsTCRMAdminContEquivBObj();
		for (XContEquivBObjExt requestPartyContEquivBObj : requestPartyContEquivBObjs) {
			String reqAdminSysType = requestPartyContEquivBObj
					.getAdminSystemType();
			if (null != reqAdminSysType
					&& !reqAdminSysType
							.equalsIgnoreCase(DSEACompositeArchConstant.UCID_TYPE)) {
				requestPartyContEquivBObj
						.setXSourceRetailerFlag(DSEACompositeArchConstant.FLAG_N);
			}
		}

		inputPersonBObj.setXSourceTypeFlag("REARCH");

	}

	public void setIndicatorsIndividualANZ(XPersonBObjExt inputPersonBObj)
			throws Exception {

		// Set address retailer flag
		Vector<XAddressGroupBObjExt> requestPartyAddressBObjs = inputPersonBObj
				.getItemsTCRMPartyAddressBObj();

		for (XAddressGroupBObjExt requestPartyAddressBObj : requestPartyAddressBObjs) {
			requestPartyAddressBObj
					.setXAddressRetailerFlag(DSEACompositeArchConstant.FLAG_N);
		}

		// Set ContactMethodGroup flag
		Vector<XContactMethodGroupBObjExt> requestPartyContactMethodBObjs = inputPersonBObj
				.getItemsTCRMPartyContactMethodBObj();
		for (XContactMethodGroupBObjExt requestPartyContactMethodBObj : requestPartyContactMethodBObjs) {
			requestPartyContactMethodBObj
					.setXContactRetailerFlag(DSEACompositeArchConstant.FLAG_N);
		}

		// Set ContEquiv flag
		Vector<XContEquivBObjExt> requestPartyContEquivBObjs = inputPersonBObj
				.getItemsTCRMAdminContEquivBObj();
		for (XContEquivBObjExt requestPartyContEquivBObj : requestPartyContEquivBObjs) {
			String reqAdminSysType = requestPartyContEquivBObj
					.getAdminSystemType();
			if (null != reqAdminSysType
					&& StringUtils.isNonBlank(reqAdminSysType)
					&& reqAdminSysType
							.equalsIgnoreCase(DSEACompositeArchConstant.SFDC_TYPE)) {
				requestPartyContEquivBObj
						.setXSourceRetailerFlag(DSEACompositeArchConstant.FLAG_N);
			}
		}

		inputPersonBObj.setXSourceTypeFlag("REARCH");

	}

	public void setIndicatorsIndividualCL1(XPersonBObjExt inputPersonBObj)
			throws Exception {

		// Set address retailer flag
		Vector<XAddressGroupBObjExt> requestPartyAddressBObjs = inputPersonBObj
				.getItemsTCRMPartyAddressBObj();

		for (XAddressGroupBObjExt requestPartyAddressBObj : requestPartyAddressBObjs) {
			requestPartyAddressBObj
					.setXAddressRetailerFlag(DSEACompositeArchConstant.FLAG_N);
		}

		// Set ContactMethodGroup flag
		Vector<XContactMethodGroupBObjExt> requestPartyContactMethodBObjs = inputPersonBObj
				.getItemsTCRMPartyContactMethodBObj();
		for (XContactMethodGroupBObjExt requestPartyContactMethodBObj : requestPartyContactMethodBObjs) {
			requestPartyContactMethodBObj
					.setXContactRetailerFlag(DSEACompositeArchConstant.FLAG_N);
		}

		// Set ContEquiv flag
		Vector<XContEquivBObjExt> requestPartyContEquivBObjs = inputPersonBObj
				.getItemsTCRMAdminContEquivBObj();
		for (XContEquivBObjExt requestPartyContEquivBObj : requestPartyContEquivBObjs) {
			String reqAdminSysType = requestPartyContEquivBObj
					.getAdminSystemType();
			if (null != reqAdminSysType
					&& StringUtils.isNonBlank(reqAdminSysType)
					&& reqAdminSysType
							.equalsIgnoreCase(DSEACompositeArchConstant.SFDC_TYPE)) {
				requestPartyContEquivBObj
						.setXSourceRetailerFlag(DSEACompositeArchConstant.FLAG_N);
			}
		}

		// Set Identifier Flag
		Vector<XIdentifierBObjExt> requestIdentifierBobjs = inputPersonBObj
				.getItemsTCRMPartyIdentificationBObj();
		for (XIdentifierBObjExt requestIdentifierBobj : requestIdentifierBobjs) {
			String requestIDType = requestIdentifierBobj
					.getIdentificationType();
			if (null != requestIDType
					&& StringUtils.isNonBlank(requestIDType)
					&& !requestIDType
							.equalsIgnoreCase(DSEACompositeArchConstant.IDENTIFIER_UCID_TYPE)) {
				requestIdentifierBobj
						.setXIdentifierRetailerFlag(DSEACompositeArchConstant.FLAG_N);
			}

		}

		inputPersonBObj.setXSourceTypeFlag("REARCH");

	}
	
	public void setIndicatorsIndividualME(XPersonBObjExt inputPersonBObj)
			throws Exception {

		// Set address retailer flag
		Vector<XAddressGroupBObjExt> requestPartyAddressBObjs = inputPersonBObj
				.getItemsTCRMPartyAddressBObj();

		for (XAddressGroupBObjExt requestPartyAddressBObj : requestPartyAddressBObjs) {
			requestPartyAddressBObj
					.setXAddressRetailerFlag(DSEACompositeArchConstant.FLAG_N);
		}

		// Set ContactMethodGroup flag
		Vector<XContactMethodGroupBObjExt> requestPartyContactMethodBObjs = inputPersonBObj
				.getItemsTCRMPartyContactMethodBObj();
		for (XContactMethodGroupBObjExt requestPartyContactMethodBObj : requestPartyContactMethodBObjs) {
			requestPartyContactMethodBObj
					.setXContactRetailerFlag(DSEACompositeArchConstant.FLAG_N);
		}

		// Set ContEquiv flag
		Vector<XContEquivBObjExt> requestPartyContEquivBObjs = inputPersonBObj
				.getItemsTCRMAdminContEquivBObj();
		for (XContEquivBObjExt requestPartyContEquivBObj : requestPartyContEquivBObjs) {
			String reqAdminSysType = requestPartyContEquivBObj
					.getAdminSystemType();
			if (null != reqAdminSysType
					&& StringUtils.isNonBlank(reqAdminSysType)
					&& reqAdminSysType
							.equalsIgnoreCase(DSEACompositeArchConstant.SFDC_TYPE)) {
				requestPartyContEquivBObj
						.setXSourceRetailerFlag(DSEACompositeArchConstant.FLAG_N);
			}
		}

		// Set Identifier Flag
		Vector<XIdentifierBObjExt> requestIdentifierBobjs = inputPersonBObj
				.getItemsTCRMPartyIdentificationBObj();
		for (XIdentifierBObjExt requestIdentifierBobj : requestIdentifierBobjs) {
			String requestIDType = requestIdentifierBobj
					.getIdentificationType();
			if (null != requestIDType
					&& StringUtils.isNonBlank(requestIDType)
					&& !requestIDType
							.equalsIgnoreCase(DSEACompositeArchConstant.IDENTIFIER_UCID_TYPE)) {
				requestIdentifierBobj
						.setXIdentifierRetailerFlag(DSEACompositeArchConstant.FLAG_N);
			}

		}

		inputPersonBObj.setXSourceTypeFlag("REARCH");

	}
	/**
	 * 
	 * @param inputPersonBObj
	 * @throws Exception
	 */
	public void setIndicatorsIndividualJPN(XPersonBObjExt inputPersonBObj)
			throws Exception {

		// Set address retailer flag
		Vector<XAddressGroupBObjExt> requestPartyAddressBObjs = inputPersonBObj
				.getItemsTCRMPartyAddressBObj();

		for (XAddressGroupBObjExt requestPartyAddressBObj : requestPartyAddressBObjs) {
			requestPartyAddressBObj
					.setXAddressRetailerFlag(DSEACompositeArchConstant.FLAG_N);
		}

		// Set ContactMethodGroup flag
		Vector<XContactMethodGroupBObjExt> requestPartyContactMethodBObjs = inputPersonBObj
				.getItemsTCRMPartyContactMethodBObj();
		for (XContactMethodGroupBObjExt requestPartyContactMethodBObj : requestPartyContactMethodBObjs) {
			requestPartyContactMethodBObj
					.setXContactRetailerFlag(DSEACompositeArchConstant.FLAG_N);
		}

		// Set ContEquiv flag
		Vector<XContEquivBObjExt> requestPartyContEquivBObjs = inputPersonBObj
				.getItemsTCRMAdminContEquivBObj();
		for (XContEquivBObjExt requestPartyContEquivBObj : requestPartyContEquivBObjs) {
			String reqAdminSysType = requestPartyContEquivBObj
					.getAdminSystemType();
			if (null != reqAdminSysType
					&& StringUtils.isNonBlank(reqAdminSysType)
					&& reqAdminSysType
							.equalsIgnoreCase(DSEACompositeArchConstant.SFDC_TYPE)) {
				requestPartyContEquivBObj
						.setXSourceRetailerFlag(DSEACompositeArchConstant.FLAG_N);
			}
		}

		// Set Identifier Flag
		Vector<XIdentifierBObjExt> requestIdentifierBobjs = inputPersonBObj
				.getItemsTCRMPartyIdentificationBObj();
		for (XIdentifierBObjExt requestIdentifierBobj : requestIdentifierBobjs) {
			String requestIDType = requestIdentifierBobj
					.getIdentificationType();
			if (null != requestIDType
					&& StringUtils.isNonBlank(requestIDType)
					&& !requestIDType
							.equalsIgnoreCase(DSEACompositeArchConstant.IDENTIFIER_UCID_TYPE)) {
				requestIdentifierBobj
						.setXIdentifierRetailerFlag(DSEACompositeArchConstant.FLAG_N);
			}

		}

		inputPersonBObj.setXSourceTypeFlag("REARCH");

	}

	

	public void setIndicatorsIndividualIND(XPersonBObjExt inputPersonBObj)
			throws Exception {

		// Set address retailer flag
		Vector<XAddressGroupBObjExt> requestPartyAddressBObjs = inputPersonBObj
				.getItemsTCRMPartyAddressBObj();

		for (XAddressGroupBObjExt requestPartyAddressBObj : requestPartyAddressBObjs) {
			requestPartyAddressBObj
					.setXAddressRetailerFlag(DSEACompositeArchConstant.FLAG_N);
		}

		// Set ContactMethodGroup flag
		Vector<XContactMethodGroupBObjExt> requestPartyContactMethodBObjs = inputPersonBObj
				.getItemsTCRMPartyContactMethodBObj();
		for (XContactMethodGroupBObjExt requestPartyContactMethodBObj : requestPartyContactMethodBObjs) {
			requestPartyContactMethodBObj
					.setXContactRetailerFlag(DSEACompositeArchConstant.FLAG_N);
		}

		// Set ContEquiv flag
		Vector<XContEquivBObjExt> requestPartyContEquivBObjs = inputPersonBObj
				.getItemsTCRMAdminContEquivBObj();
		for (XContEquivBObjExt requestPartyContEquivBObj : requestPartyContEquivBObjs) {
			String reqAdminSysType = requestPartyContEquivBObj
					.getAdminSystemType();
			if (null != reqAdminSysType
					&& StringUtils.isNonBlank(reqAdminSysType)
					&& reqAdminSysType
							.equalsIgnoreCase(DSEACompositeArchConstant.SFDC_TYPE)) {
				requestPartyContEquivBObj
						.setXSourceRetailerFlag(DSEACompositeArchConstant.FLAG_N);
			}
		}

		inputPersonBObj.setXSourceTypeFlag("REARCH");

	}

	public void setIndicatorsCompany(XOrgBObjExt inputCompanyBObj)
			throws Exception {

		// Set address retailer flag
		Vector<XAddressGroupBObjExt> requestPartyAddressBObjs = inputCompanyBObj
				.getItemsTCRMPartyAddressBObj();

		for (XAddressGroupBObjExt requestPartyAddressBObj : requestPartyAddressBObjs) {
			requestPartyAddressBObj
					.setXAddressRetailerFlag(DSEACompositeArchConstant.FLAG_N);
		}

		Vector<XContEquivBObjExt> requestPartyContequivBObjs = inputCompanyBObj
				.getItemsTCRMAdminContEquivBObj();

		for (XContEquivBObjExt requestPartyContequivBObj : requestPartyContequivBObjs) {
			requestPartyContequivBObj
					.setDescription(DSEACompositeArchConstant.FLAG_Y);
		}

		inputCompanyBObj.setXSourceTypeFlag("REARCH");

	}
	
	public void setIndicatorsCompanyTHAMYS(XOrgBObjExt inputCompanyBObj) throws Exception
	{


		// Set address retailer flag
		Vector<XAddressGroupBObjExt> requestPartyAddressBObjs = inputCompanyBObj.getItemsTCRMPartyAddressBObj();

		for (XAddressGroupBObjExt requestPartyAddressBObj : requestPartyAddressBObjs) {
			requestPartyAddressBObj
					.setXAddressRetailerFlag(DSEACompositeArchConstant.FLAG_N);
		}

		// Set ContEquiv flag
				Vector<XContEquivBObjExt> requestPartyContEquivBObjs = inputCompanyBObj.getItemsTCRMAdminContEquivBObj();
				for (XContEquivBObjExt requestPartyContEquivBObj : requestPartyContEquivBObjs) {
					//Set default value of Flag to N as only WS will come in ReArch
						requestPartyContEquivBObj
								.setXSourceRetailerFlag(DSEACompositeArchConstant.FLAG_N);
					
				}

		inputCompanyBObj.setXSourceTypeFlag("REARCH");

	
	}
	public void setIndicatorsCompanyTUR(XOrgBObjExt inputCompanyBObj) throws Exception
	{


		// Set address retailer flag
		Vector<XAddressGroupBObjExt> requestPartyAddressBObjs = inputCompanyBObj.getItemsTCRMPartyAddressBObj();

		for (XAddressGroupBObjExt requestPartyAddressBObj : requestPartyAddressBObjs) {
			requestPartyAddressBObj
					.setXAddressRetailerFlag(DSEACompositeArchConstant.FLAG_N);
		}

		// Set ContEquiv flag
				Vector<XContEquivBObjExt> requestPartyContEquivBObjs = inputCompanyBObj.getItemsTCRMAdminContEquivBObj();
				for (XContEquivBObjExt requestPartyContEquivBObj : requestPartyContEquivBObjs) {
					//Set default value of Flag to N as only WS will come in ReArch
						requestPartyContEquivBObj
								.setXSourceRetailerFlag(DSEACompositeArchConstant.FLAG_N);
					
				}

		inputCompanyBObj.setXSourceTypeFlag("REARCH");

	
	}

	public void setIndicatorsCompanyEG(XOrgBObjExt inputCompanyBObj)
			throws Exception {

		// Set address retailer flag
		Vector<XAddressGroupBObjExt> requestPartyAddressBObjs = inputCompanyBObj
				.getItemsTCRMPartyAddressBObj();

		for (XAddressGroupBObjExt requestPartyAddressBObj : requestPartyAddressBObjs) {
			requestPartyAddressBObj
					.setXAddressRetailerFlag(DSEACompositeArchConstant.FLAG_N);
		}

		// Set ContactMethodGroup flag
		Vector<XContactMethodGroupBObjExt> requestPartyContactMethodBObjs = inputCompanyBObj
				.getItemsTCRMPartyContactMethodBObj();
		for (XContactMethodGroupBObjExt requestPartyContactMethodBObj : requestPartyContactMethodBObjs) {
			requestPartyContactMethodBObj
					.setXContactRetailerFlag(DSEACompositeArchConstant.FLAG_N);
		}

		// Set ContEquiv flag
		Vector<XContEquivBObjExt> requestPartyContEquivBObjs = inputCompanyBObj
				.getItemsTCRMAdminContEquivBObj();
		for (XContEquivBObjExt requestPartyContEquivBObj : requestPartyContEquivBObjs) {
			String reqAdminSysType = requestPartyContEquivBObj
					.getAdminSystemType();
			if (null != reqAdminSysType
					&& !reqAdminSysType
							.equalsIgnoreCase(DSEACompositeArchConstant.UCID_TYPE)) {
				requestPartyContEquivBObj
						.setXSourceRetailerFlag(DSEACompositeArchConstant.FLAG_N);
			}
		}

		inputCompanyBObj.setXSourceTypeFlag("REARCH");

	}

	public void setIndicatorsCompanyANZ(XOrgBObjExt inputCompanyBObj)
			throws Exception {

		// Set address retailer flag
		Vector<XAddressGroupBObjExt> requestPartyAddressBObjs = inputCompanyBObj
				.getItemsTCRMPartyAddressBObj();

		for (XAddressGroupBObjExt requestPartyAddressBObj : requestPartyAddressBObjs) {
			requestPartyAddressBObj
					.setXAddressRetailerFlag(DSEACompositeArchConstant.FLAG_N);
		}

		// Set ContactMethodGroup flag
		Vector<XContactMethodGroupBObjExt> requestPartyContactMethodBObjs = inputCompanyBObj
				.getItemsTCRMPartyContactMethodBObj();
		for (XContactMethodGroupBObjExt requestPartyContactMethodBObj : requestPartyContactMethodBObjs) {
			requestPartyContactMethodBObj
					.setXContactRetailerFlag(DSEACompositeArchConstant.FLAG_N);
		}

		// Set ContEquiv flag
		Vector<XContEquivBObjExt> requestPartyContEquivBObjs = inputCompanyBObj
				.getItemsTCRMAdminContEquivBObj();
		for (XContEquivBObjExt requestPartyContEquivBObj : requestPartyContEquivBObjs) {
			String reqAdminSysType = requestPartyContEquivBObj
					.getAdminSystemType();
			if (null != reqAdminSysType
					&& StringUtils.isNonBlank(reqAdminSysType)
					&& reqAdminSysType
							.equalsIgnoreCase(DSEACompositeArchConstant.SFDC_TYPE)) {
				requestPartyContEquivBObj
						.setXSourceRetailerFlag(DSEACompositeArchConstant.FLAG_N);
			}
		}

		// Set Identifier Flag
		Vector<XIdentifierBObjExt> requestIdentifierBobjs = inputCompanyBObj
				.getItemsTCRMPartyIdentificationBObj();
		for (XIdentifierBObjExt requestIdentifierBobj : requestIdentifierBobjs) {
			String requestIDType = requestIdentifierBobj
					.getIdentificationType();
			if (null != requestIDType
					&& StringUtils.isNonBlank(requestIDType)
					&& !requestIDType
							.equalsIgnoreCase(DSEACompositeArchConstant.IDENTIFIER_UCID_TYPE)) {
				requestIdentifierBobj
						.setXIdentifierRetailerFlag(DSEACompositeArchConstant.FLAG_N);
			}

		}

		inputCompanyBObj.setXSourceTypeFlag("REARCH");

	}

	public void setIndicatorsCompanyCL(XOrgBObjExt inputCompanyBObj)
			throws Exception {

		// Set address retailer flag
		Vector<XAddressGroupBObjExt> requestPartyAddressBObjs = inputCompanyBObj
				.getItemsTCRMPartyAddressBObj();

		for (XAddressGroupBObjExt requestPartyAddressBObj : requestPartyAddressBObjs) {
			requestPartyAddressBObj
					.setXAddressRetailerFlag(DSEACompositeArchConstant.FLAG_N);
		}

		// Set ContactMethodGroup flag
		Vector<XContactMethodGroupBObjExt> requestPartyContactMethodBObjs = inputCompanyBObj
				.getItemsTCRMPartyContactMethodBObj();
		for (XContactMethodGroupBObjExt requestPartyContactMethodBObj : requestPartyContactMethodBObjs) {
			requestPartyContactMethodBObj
					.setXContactRetailerFlag(DSEACompositeArchConstant.FLAG_N);
		}

		// Set ContEquiv flag
		Vector<XContEquivBObjExt> requestPartyContEquivBObjs = inputCompanyBObj
				.getItemsTCRMAdminContEquivBObj();
		for (XContEquivBObjExt requestPartyContEquivBObj : requestPartyContEquivBObjs) {
			String reqAdminSysType = requestPartyContEquivBObj
					.getAdminSystemType();
			if (null != reqAdminSysType
					&& StringUtils.isNonBlank(reqAdminSysType)
					&& reqAdminSysType
							.equalsIgnoreCase(DSEACompositeArchConstant.SFDC_TYPE)) {
				requestPartyContEquivBObj
						.setXSourceRetailerFlag(DSEACompositeArchConstant.FLAG_N);
			}
		}

		inputCompanyBObj.setXSourceTypeFlag("REARCH");

	}
	
	public void setIndicatorsCompanyME(XOrgBObjExt inputCompanyBObj)
			throws Exception {

		// Set address retailer flag
		Vector<XAddressGroupBObjExt> requestPartyAddressBObjs = inputCompanyBObj
				.getItemsTCRMPartyAddressBObj();

		for (XAddressGroupBObjExt requestPartyAddressBObj : requestPartyAddressBObjs) {
			requestPartyAddressBObj
					.setXAddressRetailerFlag(DSEACompositeArchConstant.FLAG_N);
		}

		// Set ContactMethodGroup flag
		Vector<XContactMethodGroupBObjExt> requestPartyContactMethodBObjs = inputCompanyBObj
				.getItemsTCRMPartyContactMethodBObj();
		for (XContactMethodGroupBObjExt requestPartyContactMethodBObj : requestPartyContactMethodBObjs) {
			requestPartyContactMethodBObj
					.setXContactRetailerFlag(DSEACompositeArchConstant.FLAG_N);
		}

		// Set ContEquiv flag
		Vector<XContEquivBObjExt> requestPartyContEquivBObjs = inputCompanyBObj
				.getItemsTCRMAdminContEquivBObj();
		for (XContEquivBObjExt requestPartyContEquivBObj : requestPartyContEquivBObjs) {
			String reqAdminSysType = requestPartyContEquivBObj
					.getAdminSystemType();
			if (null != reqAdminSysType
					&& StringUtils.isNonBlank(reqAdminSysType)
					&& reqAdminSysType
							.equalsIgnoreCase(DSEACompositeArchConstant.SFDC_TYPE)) {
				requestPartyContEquivBObj
						.setXSourceRetailerFlag(DSEACompositeArchConstant.FLAG_N);
			}
		}

		inputCompanyBObj.setXSourceTypeFlag("REARCH");

	}

	public void setIndicatorsCompanyIND(XOrgBObjExt inputCompanyBObj)
			throws Exception {

		// Set address retailer flag
		Vector<XAddressGroupBObjExt> requestPartyAddressBObjs = inputCompanyBObj
				.getItemsTCRMPartyAddressBObj();

		for (XAddressGroupBObjExt requestPartyAddressBObj : requestPartyAddressBObjs) {
			requestPartyAddressBObj
					.setXAddressRetailerFlag(DSEACompositeArchConstant.FLAG_N);
		}

		// Set ContactMethodGroup flag
		Vector<XContactMethodGroupBObjExt> requestPartyContactMethodBObjs = inputCompanyBObj
				.getItemsTCRMPartyContactMethodBObj();
		for (XContactMethodGroupBObjExt requestPartyContactMethodBObj : requestPartyContactMethodBObjs) {
			requestPartyContactMethodBObj
					.setXContactRetailerFlag(DSEACompositeArchConstant.FLAG_N);
		}

		// Set ContEquiv flag
		Vector<XContEquivBObjExt> requestPartyContEquivBObjs = inputCompanyBObj
				.getItemsTCRMAdminContEquivBObj();
		for (XContEquivBObjExt requestPartyContEquivBObj : requestPartyContEquivBObjs) {
			String reqAdminSysType = requestPartyContEquivBObj
					.getAdminSystemType();
			if (null != reqAdminSysType
					&& StringUtils.isNonBlank(reqAdminSysType)
					&& reqAdminSysType
							.equalsIgnoreCase(DSEACompositeArchConstant.SFDC_TYPE)) {
				requestPartyContEquivBObj
						.setXSourceRetailerFlag(DSEACompositeArchConstant.FLAG_N);
			}
		}

		// Set Identifier Flag
		Vector<XIdentifierBObjExt> requestIdentifierBobjs = inputCompanyBObj
				.getItemsTCRMPartyIdentificationBObj();
		for (XIdentifierBObjExt requestIdentifierBobj : requestIdentifierBobjs) {
			String requestIDType = requestIdentifierBobj
					.getIdentificationType();
			if (null != requestIDType
					&& StringUtils.isNonBlank(requestIDType)
					&& !requestIDType
							.equalsIgnoreCase(DSEACompositeArchConstant.IDENTIFIER_UCID_TYPE)) {
				requestIdentifierBobj
						.setXIdentifierRetailerFlag(DSEACompositeArchConstant.FLAG_N);
			}

		}

		inputCompanyBObj.setXSourceTypeFlag("REARCH");

	}
	
	/**
	 * 
	 * 
	 * @param inputCompanyBObj
	 * @throws Exception
	 */
	public void setIndicatorsCompanyJPN(XOrgBObjExt inputCompanyBObj)
			throws Exception {

		// Set address retailer flag
		Vector<XAddressGroupBObjExt> requestPartyAddressBObjs = inputCompanyBObj
				.getItemsTCRMPartyAddressBObj();

		for (XAddressGroupBObjExt requestPartyAddressBObj : requestPartyAddressBObjs) {
			requestPartyAddressBObj
					.setXAddressRetailerFlag(DSEACompositeArchConstant.FLAG_N);
		}

		// Set ContactMethodGroup flag
		Vector<XContactMethodGroupBObjExt> requestPartyContactMethodBObjs = inputCompanyBObj
				.getItemsTCRMPartyContactMethodBObj();
		for (XContactMethodGroupBObjExt requestPartyContactMethodBObj : requestPartyContactMethodBObjs) {
			requestPartyContactMethodBObj
					.setXContactRetailerFlag(DSEACompositeArchConstant.FLAG_N);
		}

		// Set ContEquiv flag
		Vector<XContEquivBObjExt> requestPartyContEquivBObjs = inputCompanyBObj
				.getItemsTCRMAdminContEquivBObj();
		for (XContEquivBObjExt requestPartyContEquivBObj : requestPartyContEquivBObjs) {
			String reqAdminSysType = requestPartyContEquivBObj
					.getAdminSystemType();
			if (null != reqAdminSysType
					&& StringUtils.isNonBlank(reqAdminSysType)
					&& reqAdminSysType
							.equalsIgnoreCase(DSEACompositeArchConstant.SFDC_TYPE)) {
				requestPartyContEquivBObj
						.setXSourceRetailerFlag(DSEACompositeArchConstant.FLAG_N);
			}
		}

		// Set Identifier Flag
		Vector<XIdentifierBObjExt> requestIdentifierBobjs = inputCompanyBObj
				.getItemsTCRMPartyIdentificationBObj();
		for (XIdentifierBObjExt requestIdentifierBobj : requestIdentifierBobjs) {
			String requestIDType = requestIdentifierBobj
					.getIdentificationType();
			if (null != requestIDType
					&& StringUtils.isNonBlank(requestIDType)
					&& !requestIDType
							.equalsIgnoreCase(DSEACompositeArchConstant.IDENTIFIER_UCID_TYPE)) {
				requestIdentifierBobj
						.setXIdentifierRetailerFlag(DSEACompositeArchConstant.FLAG_N);
			}

		}

		inputCompanyBObj.setXSourceTypeFlag("REARCH");

	}

	public DWLError validateDeleteCustomer(DWLCommon topLevelObject,
			DWLControl control) throws BusinessProxyException {

		DWLError error = null;
		boolean isUCIDPresent = false;
		boolean isSFDCIdPresent = false;

		if (!(topLevelObject instanceof DeletePartyBObj)) {
			error = errHandler
					.getErrorMessage(
							DSEAArchSimplificationComponentID.DELETE_CUSTOMER_BUSINESS_PROXY,
							"UPDERR",
							DSEAArchSimplificationErrorReasonCode.DELETECUSTOMER_FAILED,
							control, new String[0]);
			return error;
		}

		DeletePartyBObj mainInput = (DeletePartyBObj) topLevelObject;

		if (mainInput.getUCID() != null) {
			isUCIDPresent = true;
		}

		if (mainInput.getSFDC_ID() != null) {
			isSFDCIdPresent = true;
		}

		if (!(isUCIDPresent || isSFDCIdPresent)) {
			error = errHandler
					.getErrorMessage(
							DSEAArchSimplificationComponentID.DELETE_CUSTOMER_BUSINESS_PROXY,
							"FVERR",
							DSEAArchSimplificationErrorReasonCode.MANDATORY_UCID_SFDCID,
							control, new String[0]);
			return error;
		}

		return error;
	}

	public Vector<String> getId(String sqlStatement, String inputId,
			DWLControl control) throws BusinessProxyException, SQLException {

		SQLQuery sqlQuery = new SQLQuery();
		ResultSet objResultSet = null;
		String id = null;
		List<SQLParam> params = new ArrayList<SQLParam>();
		Vector<String> vecIds = new Vector<String>();
		try {
			params = new ArrayList<SQLParam>();
			params.add(0, new SQLParam(inputId));

			if (sqlStatement
					.equals(DSEACompositeArchConstant.GET_CONTACTREL_ID_BY_PARTYID)) {
				params.add(1, new SQLParam(inputId));
			} else if (sqlStatement
					.equals(DSEACompositeArchConstant.GET_SUSPECT_ID_BY_PARTYID)) {
				params.add(1, new SQLParam(inputId));
			} else if (sqlStatement
					.equals(DSEACompositeArchConstant.GET_INACTIVECONTLINK_ID_BY_PARTYID)) {
				params.add(1, new SQLParam(inputId));
			}

			objResultSet = sqlQuery.executeQuery(sqlStatement, params);
			while (objResultSet.next()) {
				vecIds.add(objResultSet.getString(1));
			}

		} catch (Exception ex) {
			DWLError error = errHandler
					.getErrorMessage(
							DSEAArchSimplificationComponentID.DELETE_CUSTOMER_BUSINESS_PROXY,
							"READERR",
							DSEAArchSimplificationErrorReasonCode.MAINTAIN_INDIVIDUAL_GETPARTY_FAILED,
							control, new String[0]);
			throw new BusinessProxyException(error.getErrorMessage());
		} finally {
			if (objResultSet != null)
				objResultSet.close();
			sqlQuery.close();
		}

		return vecIds;
	}

	public void deleteData(String sqlStatement, String inputId,
			DWLControl control) throws BusinessProxyException, SQLException {

		SQLQuery sqlQuery = new SQLQuery();
		int objResultSet;
		try {

			sqlStatement = sqlStatement.replace("?", inputId);
			objResultSet = sqlQuery.executeUpdate(sqlStatement);

		} catch (Exception ex) {
			ex.printStackTrace();
			DWLError error = errHandler
					.getErrorMessage(
							DSEAArchSimplificationComponentID.DELETE_CUSTOMER_BUSINESS_PROXY,
							"READERR",
							DSEAArchSimplificationErrorReasonCode.MAINTAIN_INDIVIDUAL_GETPARTY_FAILED,
							control, new String[0]);
			throw new BusinessProxyException(error.getErrorMessage());
		} finally {

			sqlQuery.close();
		}

	}
	
	/**
	 * 
	 * @param personResponseBObj
	 * @param additionsExtsComponent
	 * @param inputPersonBObj
	 * @param outputPersonBObj
	 * @param control
	 * @param partyId
	 * @return
	 * @throws Exception
	 * Added by Kausumbha for Japan ARP
	 */
	
	public XPersonBObjExt updatePersonWholesaleJPN(
			XPersonBObjExt personResponseBObj,
			DSEAAdditionsExtsComponent additionsExtsComponent,
			XPersonBObjExt inputPersonBObj, XPersonBObjExt outputPersonBObj,
			DWLControl control, String partyId) throws Exception {
		// TODO Auto-generated method stub

		DWLResponse addUpdatePartyResponse = null;
		XPersonBObjExt existingPersonBObj = new XPersonBObjExt();
		TCRMPartyComponent partyComponent = new TCRMPartyComponent();
		XPersonBObjExt requestBObj = new XPersonBObjExt();
		String marketName;
		XContEquivBObjExt existingUCIDBObj = new XContEquivBObjExt();
		XContEquivBObjExt existingSFDCBObj = new XContEquivBObjExt();

		try {
			existingPersonBObj = (XPersonBObjExt) partyComponent.getPerson(
					partyId, "2", control);
		}
		// throw error if Get Person Failed
		catch (TCRMException e) {
			e.printStackTrace();

			DWLError error = errHandler
					.getErrorMessage(
							DSEAArchSimplificationComponentID.MAINTAIN_INDIVIDUAL_BUSINESS_PROXY,
							"UPDERR",
							DSEAArchSimplificationErrorReasonCode.MAINTAIN_INDIVIDUAL_UPDATE_FAILED,
							control, new String[0]);
			// vectReqDWLError.add(error);
			throw new BusinessProxyException(error.getErrorMessage());

		}
		// throw error if no person data is fetched
		if (existingPersonBObj == null) {

			DWLError error = errHandler
					.getErrorMessage(
							DSEAArchSimplificationComponentID.MAINTAIN_INDIVIDUAL_BUSINESS_PROXY,
							"UPDERR",
							DSEAArchSimplificationErrorReasonCode.MAINTAIN_INDIVIDUAL_UPDATE_FAILED,
							control, new String[0]);
			// vectReqDWLError.add(error);
			throw new BusinessProxyException(error.getErrorMessage());
		}

		// Update the mainInputBObj for the updatePerson transaction

		setUpdatePersonBObj(inputPersonBObj, requestBObj, existingPersonBObj,
				control);

		// Changed for marketName CMPVAL
		marketName = inputPersonBObj.getXMarketName();
		// Changed for marketName CMPVAL

		// Compare the request BObjs with existing BObjs
		comparePersonNameBObjsForUpdate(existingPersonBObj, inputPersonBObj,
				control);
		comparePartyIdentificationBObjsForUpdate(existingPersonBObj,
				inputPersonBObj, control);
		comparePartyAddressBObjsForUpdateJPN(existingPersonBObj, inputPersonBObj,
				control);
		comparePartyContactMethodBObjsForUpdateJPN(existingPersonBObj,
				inputPersonBObj, control);
		compareAdminContEquivBObjsForUpdateNoDescriptionJPN(existingPersonBObj,
				inputPersonBObj, control,partyComponent,partyId);

		// Changed for marketName CMPVAL (25 May 2018)
		control.put("marketName", marketName);
		// Changed for marketName CMPVAL (25 May 2018)

		// Run the updateOrg Transaction
		// System.out.println(inputPersonBObj.toXML());
		inputPersonBObj.setControl(control);
		addUpdatePartyResponse = mdmTransaction(
				inputPersonBObj,
				control,
				DSEACompositeArchConstant.UPDATE_PERSON_TXN,
				DSEAArchSimplificationComponentID.MAINTAIN_INDIVIDUAL_BUSINESS_PROXY);
		throwExceptionifTXNFail(addUpdatePartyResponse, sb);

		if (addUpdatePartyResponse != null) {

			personResponseBObj = (XPersonBObjExt) addUpdatePartyResponse
					.getData();

			if (personResponseBObj == null) {

				throwExceptionifTXNFail(addUpdatePartyResponse, sb);

			} else if (personResponseBObj.getStatus().getStatus() == DWLStatus.FATAL) {

				throwExceptionifTXNFail(addUpdatePartyResponse, sb);
			}
		} else {

			throwExceptionifTXNFail(addUpdatePartyResponse, sb);
		}
		// Set Response Objects
		// Set UCID in response
		/*
		 * Vector<XContEquivBObjExt> existingContEquivBObjs =
		 * existingPersonBObj.getItemsTCRMAdminContEquivBObj();
		 * 
		 * for(XContEquivBObjExt contEquivBObj : existingContEquivBObjs){
		 * if(DSEACompositeArchConstant
		 * .UCID_TYPE.equalsIgnoreCase(contEquivBObj.getAdminSystemType())){ if
		 * ("Y".equalsIgnoreCase(contEquivBObj.getDescription())) {
		 * existingUCIDBObj = contEquivBObj; } } else if
		 * (DSEACompositeArchConstant
		 * .SFDC_TYPE.equalsIgnoreCase(contEquivBObj.getAdminSystemType()) &&
		 * contEquivBObj.getXRetailerId() == null) if
		 * ("Y".equalsIgnoreCase(contEquivBObj.getDescription())) {
		 * existingSFDCBObj = contEquivBObj; } }
		 */
		personResponseBObj.setTCRMAdminContEquivBObj(existingUCIDBObj);

		return personResponseBObj;

	}

}
