/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[ec1f807301a943e5f8f0413f8484581a]
 */

package com.ibm.mdm.dsea.arch.compositeTxn;

import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Vector;

import com.dwl.base.DWLCommon;
import com.dwl.base.DWLResponse;
import com.dwl.base.IDWLErrorMessage;
import com.dwl.base.error.DWLError;
import com.dwl.base.error.DWLStatus;
import com.dwl.base.requestHandler.DWLTransactionPersistent;
import com.dwl.base.requestHandler.DWLTxnBP;
import com.dwl.base.util.StringUtils;
import com.dwl.tcrm.common.TCRMResponse;
import com.dwl.tcrm.coreParty.component.TCRMInactivatedPartyBObj;
import com.dwl.tcrm.coreParty.component.TCRMPartyBObj;
import com.dwl.tcrm.coreParty.component.TCRMPartyComponent;
import com.dwl.tcrm.utilities.TCRMClassFactory;
import com.dwl.unifi.tx.exception.BusinessProxyException;


import com.dwl.base.DWLControl;
import com.ibm.daimler.dsea.component.DSEAAdditionsExtsComponent;
import com.ibm.daimler.dsea.component.XContEquivBObjExt;
import com.ibm.daimler.dsea.component.XDeleteAuditBObj;
import com.ibm.daimler.dsea.component.XIdentifierBObjExt;
import com.ibm.daimler.dsea.component.XPersonBObjExt;
import com.ibm.daimler.dsea.component.XPersonNameBObjExt;
import com.ibm.mdm.domains.codetype.obj.AdminSystemTypeMetadataBObj;
import com.ibm.mdm.dsea.arch.component.DeletePartyBObj;
import com.ibm.mdm.dsea.arch.constant.DSEAArchSimplificationComponentID;
import com.ibm.mdm.dsea.arch.constant.DSEAArchSimplificationErrorReasonCode;
import com.ibm.mdm.dsea.arch.constant.DSEACompositeArchConstant;
import com.ibm.mdm.dsea.arch.util.ValidationUtilArch;
import com.sun.jmx.snmp.Timestamp;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * 
 * @generated
 */
public class DeleteCustomerCompositeTxnBP  extends ValidationUtilArch {

	/**
	 * @generated
	 **/
	private IDWLErrorMessage errHandler;
	
	/**
    * <!-- begin-user-doc -->
	  * <!-- end-user-doc -->
    * @generated 
    */
	 private final static com.dwl.base.logging.IDWLLogger logger = com.dwl.base.logging.DWLLoggerManager.getLogger(DeleteCustomerCompositeTxnBP.class);
	/**
	 * @generated
	 **/
    public DeleteCustomerCompositeTxnBP() {
        super();
        errHandler = TCRMClassFactory.getErrorHandler();
    }
	/**
	 * @generated
	 **/
    public Object execute(Object inputObj) throws BusinessProxyException {
    logger.finest("ENTER Object execute(Object inputObj)");

        TCRMResponse outputTxnObj = null;
        DWLTransactionPersistent inputTxnObj = (DWLTransactionPersistent) inputObj;
        DWLControl control = inputTxnObj.getTxnControl();
        DWLCommon topLevelObject = (DWLCommon) inputTxnObj.getTxnTopLevelObject();
        DeletePartyBObj deletePartyBObj = new DeletePartyBObj();
        DWLResponse deletePartyResponse = null;
        TCRMPartyBObj tcrmPartyBObj = new TCRMPartyBObj();
        Vector<XContEquivBObjExt> vecContequivBObjs = null;
        Vector<XIdentifierBObjExt> vecIdentBobjs = null;
        XPersonBObjExt existingPersonBobj = new XPersonBObjExt();
        
        //validate delete party
        DWLError error = validateDeleteCustomer(topLevelObject, control);
        		
        if (error != null) {
           
            DWLStatus outputStatus = new DWLStatus();
			outputStatus.setStatus(DWLStatus.FATAL);
			outputStatus.addError(error);

			outputTxnObj = new TCRMResponse();
			outputTxnObj.setStatus(outputStatus);
			outputTxnObj.setData(deletePartyBObj);

			return outputTxnObj;
        }


        DeletePartyBObj mainOutput = new DeletePartyBObj();
        mainOutput.setControl(control);
        DeletePartyBObj mainInput = (DeletePartyBObj) topLevelObject;
        
        String sfdcId = mainInput.getSFDC_ID();
        String ucid = mainInput.getUCID();
        String partyId = null;
        Vector<String> vecIds = null;
        String customerMarketName = null;
        
        DSEAAdditionsExtsComponent additionsExtsComponent = new DSEAAdditionsExtsComponent();

		customerMarketName = mainInput.getObjectReferenceId();
    	try {
	        if(sfdcId != null){
	        	vecIds = getId(DSEACompositeArchConstant.GET_PARTY_ID_BY_SFDCID, sfdcId, control);
	        	
	        	
	        }else if(ucid != null){
	        	//Changes made to pick the IDs from identifier in case of markets where UCID is stored in identifier || 1Dec 2020
	        	if(null != customerMarketName && StringUtils.isNonBlank(customerMarketName)
	        			&& (customerMarketName.equalsIgnoreCase(DSEACompositeArchConstant.MARKET_NAME_AUSTRALIA)
	        					|| customerMarketName.equalsIgnoreCase(DSEACompositeArchConstant.MARKET_NAME_NEWZEALAND)
	        					|| customerMarketName.equalsIgnoreCase(DSEACompositeArchConstant.MARKET_NAME_THAILAND)
	        					|| customerMarketName.equalsIgnoreCase(DSEACompositeArchConstant.MARKET_NAME_MALAYSIA)
	        					|| customerMarketName.equalsIgnoreCase(DSEACompositeArchConstant.MARKET_NAME_INDIA)
	        					|| customerMarketName.equalsIgnoreCase(DSEACompositeArchConstant.MARKET_NAME_TURKEY)))
	        	{
	        		vecIds = getId(DSEACompositeArchConstant.GET_PARTY_ID_BY_UCID_IDENTIFIER, ucid, control);
	        	}
	        	else
	        	{
	        		vecIds = getId(DSEACompositeArchConstant.GET_PARTY_ID_BY_UCID, ucid, control);
	        	}
	        	
	        }	
	        
	       } catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
	       }
       
        
	        if(vecIds != null && vecIds.size() > 0){
	        		        	
	        	try {
	        		partyId = vecIds.get(0);
		        	
	        		/*ucid = (getId(DSEACompositeArchConstant.GET_UCID_BY_SFDCID, sfdcId, control)).get(0);
		        	sfdcId = (getId(DSEACompositeArchConstant.GET_SFDCID_BY_UCID, sfdcId, control)).get(0);
		        */
		        	TCRMPartyComponent partyComponent = new TCRMPartyComponent();
	    			vecContequivBObjs = partyComponent.getAllPartyAdminSysKeys(partyId, control);
	    			if(null != customerMarketName && StringUtils.isNonBlank(customerMarketName)
	    					&& (customerMarketName.equalsIgnoreCase(DSEACompositeArchConstant.MARKET_NAME_TURKEY)
	    							|| customerMarketName.equalsIgnoreCase(DSEACompositeArchConstant.MARKET_NAME_THAILAND)
		        					|| customerMarketName.equalsIgnoreCase(DSEACompositeArchConstant.MARKET_NAME_MALAYSIA)
		        					|| customerMarketName.equalsIgnoreCase(DSEACompositeArchConstant.MARKET_NAME_AUSTRALIA)
		        					|| customerMarketName.equalsIgnoreCase(DSEACompositeArchConstant.MARKET_NAME_INDIA)
		        					|| customerMarketName.equalsIgnoreCase(DSEACompositeArchConstant.MARKET_NAME_NEWZEALAND)))
	    			{
	    				vecIdentBobjs = partyComponent.getAllPartyIdentifications(partyId,"ALL",control);
	    			}
	    			
	    			if(customerMarketName.equalsIgnoreCase(DSEACompositeArchConstant.MARKET_NAME_TURKEY)){
	    				
	    				// Soft Delete for Turkey
	    				
	    				TCRMInactivatedPartyBObj inactivatedPartyBObj = new TCRMInactivatedPartyBObj();
	    				
	    				inactivatedPartyBObj.setInactivatedPartyId(partyId);
	    				inactivatedPartyBObj.setInactivationReasonType(DSEACompositeArchConstant.INACTIVATEREASONTYPE);
	    				inactivatedPartyBObj.setInactivatedByUser(DSEACompositeArchConstant.INACTIVATED_BY_USER);
	    				inactivatedPartyBObj.setControl(control);
	    				
	    				
		    			deletePartyResponse=runPersistentTransaction(DSEACompositeArchConstant.TXN_NAME_INACTIVATEPARTY, control, inactivatedPartyBObj);
	    				
		    			throwExceptionifTXNFail(deletePartyResponse, sb);
	    				
	    			}  
	    			
	    			else{
	    			
	        		//Delete XDATASHARING
	    			Vector<String> vecDataSharingPkIds = getId(DSEACompositeArchConstant.GET_DATASHARINGPKID_BY_PARTYID, partyId, control);
	    			String datasharingPkIds = "";
		        	for(String datasharingPkId : vecDataSharingPkIds){
		        		datasharingPkIds += datasharingPkId +",";
		        	}
		        	
		        	if(datasharingPkIds.length() > 0){
		        		datasharingPkIds = datasharingPkIds.substring(0, datasharingPkIds.length()-1);
			        	
		        		deleteData(DSEACompositeArchConstant.DELETE_XDATASHARING, datasharingPkIds, control);
		        	}
		        	
		        	//Delete XPREFERENCE
		        	Vector<String> vecPreferencePkIds = getId(DSEACompositeArchConstant.GET_PREFERENCEPK_ID_BY_PARTYID, partyId, control);
		        	String preferencePkIds = "";
		        	for(String preferencePkId : vecPreferencePkIds){
		        		preferencePkIds += preferencePkId +",";
		        	}
		        	
		        	if(preferencePkIds.length() > 0){
		        		preferencePkIds = preferencePkIds.substring(0, preferencePkIds.length()-1);
			        	
		        		deleteData(DSEACompositeArchConstant.DELETE_XPREFERENCE, preferencePkIds, control);
		        	}
		        	
		        	//Delete XPRIVAGREEMENT
		        	Vector<String> vecPrivAgreementPkIds = getId(DSEACompositeArchConstant.GET_PRIVAGREEMENTPK_ID_BY_PARTYID, partyId, control);
		        	String privAgreementPkIds = "";
		        	
		        	for(String privAgreementPkId : vecPrivAgreementPkIds){
		        		privAgreementPkIds += privAgreementPkId +",";
		        	}
		        	
		        	if(privAgreementPkIds.length() > 0){
		        		privAgreementPkIds = privAgreementPkIds.substring(0, privAgreementPkIds.length()-1);
			        	
		        		deleteData(DSEACompositeArchConstant.DELETE_XPRIVAGREEMENT, privAgreementPkIds, control);
		        	}
		        	
		        	//Delete Customer retailer roles
		        	Vector<String> vecRetailerRoleIds = getId(DSEACompositeArchConstant.GET_CUSTOMERRETAILERROLE_ID_BY_PARTYID, partyId, control);
		        	String retailerRoleIds = "";
		        	
		        	for(String retailerRoleId : vecRetailerRoleIds){
		        		retailerRoleIds += retailerRoleId +",";
		        	}
		        	
		        	if(retailerRoleIds.length() > 0){
		        		retailerRoleIds = retailerRoleIds.substring(0, retailerRoleIds.length()-1);
			        	
		        		deleteData(DSEACompositeArchConstant.DELETE_XCUSTOMERRETAILERROLE, retailerRoleIds, control);
		        	}
		        	
		        	//Delete Customer retailer RELATIONSHIP
		        	Vector<String> vecCustomerRetailerIds = getId(DSEACompositeArchConstant.GET_CUSTOMERRETAILER_ID_BY_PARTYID, partyId, control);
		        	String customerRetailerIds = "";
		        	
		        	for(String customerRetailerId : vecCustomerRetailerIds){
		        		customerRetailerIds += customerRetailerId +",";
		        	}
		        	
		        	if(customerRetailerIds.length() > 0){
		        		customerRetailerIds = customerRetailerIds.substring(0, customerRetailerIds.length()-1);
			        	
		        		deleteData(DSEACompositeArchConstant.DELETE_XCUSTOMERRETAILER, customerRetailerIds, control);
		        	}
		        	
		        	//Delete Customer vehicle roles
		        	Vector<String> vecVehicleRoleIds = getId(DSEACompositeArchConstant.GET_CUSTOMERVEHICLEROLE_ID_BY_PARTYID, partyId, control);
		        	String vehicleRoleIds = "";
		        	
		        	for(String vehicleRoleId : vecVehicleRoleIds){
		        		vehicleRoleIds += vehicleRoleId +",";
		        	}
		        	
		        	if(vehicleRoleIds.length() > 0){
		        		vehicleRoleIds = vehicleRoleIds.substring(0, vehicleRoleIds.length()-1);
			        	
		        		deleteData(DSEACompositeArchConstant.DELETE_XCUSTOMERVEHICLEROLE, vehicleRoleIds, control);
		        	}
		        	
		        	//Delete Customer vehicle relationship
		        	Vector<String> vecCustomerVehicleIds = getId(DSEACompositeArchConstant.GET_CUSTOMERVEHICLE_ID_BY_PARTYID, partyId, control);
		        	String customerVehicleIds = "";
		        	
		        	for(String customerVehicleId : vecCustomerVehicleIds){
		        		customerVehicleIds += customerVehicleId +",";
		        	}
		        	
		        	if(customerVehicleIds.length() > 0){
		        		customerVehicleIds = customerVehicleIds.substring(0, customerVehicleIds.length()-1);
			        	
		        		deleteData(DSEACompositeArchConstant.DELETE_XCUSTOMERVEHICLE, customerVehicleIds, control);
		        	}
		        	
		        	//Delete Customer Customer relationship
		        	Vector<String> vecC2CIds = getId(DSEACompositeArchConstant.GET_CONTACTREL_ID_BY_PARTYID, partyId, control);
		        	String c2cIds = "";
		        	
		        	for(String c2cId : vecC2CIds){
		        		c2cIds += c2cId +",";
		        	}
		        	
		        	if(c2cIds.length() > 0){
		        		c2cIds = c2cIds.substring(0, c2cIds.length()-1);
			        	
		        		deleteData(DSEACompositeArchConstant.DELETE_CONTACTREL, c2cIds, control);
		        	}
					
		        	// delete suspect table entries
		        	Vector<String> vecSuspectIds = getId(DSEACompositeArchConstant.GET_SUSPECT_ID_BY_PARTYID, partyId, control);
		        	String suspectIds = "";
		        	
		        	for(String suspectId : vecSuspectIds){
		        		suspectIds += suspectId +",";
		        	}
		        	
		        	if(suspectIds.length() > 0){
		        		suspectIds = suspectIds.substring(0, suspectIds.length()-1);
			        	
		        		deleteData(DSEACompositeArchConstant.DELETE_SUSPECT, suspectIds, control);
		        	}
		        	
		        	// delete inactivecontlink entries
		        	Vector<String> vecInactiveContLinkIds = getId(DSEACompositeArchConstant.GET_INACTIVECONTLINK_ID_BY_PARTYID, partyId, control);
		        	String inactiveContLinkIds = "";
		        	
		        	for(String inactiveContLinkId : vecInactiveContLinkIds){
		        		inactiveContLinkIds += inactiveContLinkId +",";
		        	}
		        	
		        	if(inactiveContLinkIds.length() > 0){
		        		inactiveContLinkIds = inactiveContLinkIds.substring(0, inactiveContLinkIds.length()-1);
			        	
		        		deleteData(DSEACompositeArchConstant.DELETE_INACTIVECONTLINK, inactiveContLinkIds, control);
		        	}
		        	
		        	
		        	// delete INACTIVATEDCONT entries
		        	
		        	deleteData(DSEACompositeArchConstant.DELETE_INACTIVATEDCONT, partyId, control);
		        	
		        	
		        	//update DO_NOT_DELETE_IND to 1
		        	deleteData(DSEACompositeArchConstant.UPDATE_CONTACT, partyId, control);
		        	
		        	//DELETE Other party information using deleteParty txn
		        	tcrmPartyBObj.setControl(control);
		        	tcrmPartyBObj.setPartyId(partyId);
		        	
		        	deletePartyResponse=mdmTransaction(tcrmPartyBObj,control,DSEACompositeArchConstant.DELETE_PARTY_TXN,
							DSEAArchSimplificationComponentID.DELETE_CUSTOMER_BUSINESS_PROXY);
		        	
		        	throwExceptionifTXNFail(deletePartyResponse, sb);
		        	
	    			}
					
		        	if(deletePartyResponse != null){
		        				        		
		        		if(vecContequivBObjs != null && vecContequivBObjs.size() > 0){
		        			for(XContEquivBObjExt conteBObj : vecContequivBObjs){
		        				
		        				XDeleteAuditBObj auditBObj = new XDeleteAuditBObj();
				        		auditBObj.setControl(control);
				        		
		        				if(conteBObj.getAdminSystemType().equals("1001")
		        					|| conteBObj.getAdminSystemType().equals("1026")){
		        					
		        					if("Y".equals(conteBObj.getDescription()) && conteBObj.getAdminSystemType().equals("1001")){
		        						sfdcId = conteBObj.getAdminPartyId();
		        					}else if("Y".equals(conteBObj.getDescription()) && conteBObj.getAdminSystemType().equals("1026")){
		        						ucid = conteBObj.getAdminPartyId();
		        					}
		        					String currentTimestamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new java.util.Date());
		        					auditBObj.setCONT_ID(conteBObj.getPartyId());
		        					auditBObj.setADMIN_CLIENT_ID(conteBObj.getAdminPartyId());
		        					auditBObj.setADMIN_SYSTEM_VALUE(conteBObj.getAdminSystemValue());
		        					auditBObj.setDESCRIPTION(conteBObj.getDescription());
		        					auditBObj.setDELETE_DATE(currentTimestamp);
		        					if(null != customerMarketName && StringUtils.isNonBlank(customerMarketName))
		        					{
		        						auditBObj.setMARKET_NAME(customerMarketName);
		        					}
		        					else
		        					{
		        						auditBObj.setMARKET_NAME("KOR");
		        					}
		        					DWLResponse deleteResponse = additionsExtsComponent.addXDeleteAudit(auditBObj);
		        					throwExceptionifTXNFail(deleteResponse, sb);
		        				}
		        			}
		        			 mainOutput.setUCID(ucid);
		        	    	 mainOutput.setSFDC_ID(sfdcId);
		        		}
		        		
		        		if(vecIdentBobjs != null && vecIdentBobjs.size() > 0){
		        			for(XIdentifierBObjExt identBobj : vecIdentBobjs){
		        				
		        				XDeleteAuditBObj auditBObj = new XDeleteAuditBObj();
				        		auditBObj.setControl(control);
				        		
		        				if(identBobj.getIdentificationType().equals("1001")){
		        					
		        					String currentTimestamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new java.util.Date());
		        					auditBObj.setCONT_ID(identBobj.getPartyId());
		        					auditBObj.setADMIN_CLIENT_ID(identBobj.getIdentificationNumber());
		        					auditBObj.setADMIN_SYSTEM_VALUE(identBobj.getIdentificationValue());
		        					auditBObj.setDELETE_DATE(currentTimestamp);
		        					auditBObj.setMARKET_NAME(customerMarketName);
		        					DWLResponse deleteResponse = additionsExtsComponent.addXDeleteAudit(auditBObj);
		        					throwExceptionifTXNFail(deleteResponse, sb);
		        				}
		        			}
		        			 mainOutput.setUCID(ucid);
		        	    	 mainOutput.setSFDC_ID(sfdcId);
		        		}
		        		
		        	}
		        	
				} catch (Exception e) {
					error = errHandler.getErrorMessage(
							DSEAArchSimplificationComponentID.DELETE_CUSTOMER_BUSINESS_PROXY,
							"UPDERR",
							DSEAArchSimplificationErrorReasonCode.DELETECUSTOMER_FAILED,
									control, new String[0]);
		        	
		        	DWLStatus outputStatus = new DWLStatus();
		 			outputStatus.setStatus(DWLStatus.FATAL);
		 			outputStatus.addError(error);
		
		 			outputTxnObj = new TCRMResponse();
		 			outputTxnObj.setStatus(outputStatus);
		 			outputTxnObj.setData(deletePartyBObj);
		
		 			return outputTxnObj;
				}
	      	
	        	
	        }else{
	        	
	        	error = errHandler.getErrorMessage(
								DSEAArchSimplificationComponentID.DELETE_CUSTOMER_BUSINESS_PROXY,
								"FVERR",
								DSEAArchSimplificationErrorReasonCode.NO_RECORD_FOUND,
								control, new String[0]);
	        	
	        	DWLStatus outputStatus = new DWLStatus();
	 			outputStatus.setStatus(DWLStatus.FATAL);
	 			outputStatus.addError(error);
	
	 			outputTxnObj = new TCRMResponse();
	 			outputTxnObj.setStatus(outputStatus);
	 			outputTxnObj.setData(deletePartyBObj);
	
	 			return outputTxnObj;
	        }
        
	       
    		
        // Construct the response object.
        DWLStatus outputStatus = new DWLStatus();
        outputStatus.setStatus(DWLStatus.SUCCESS);
        outputTxnObj = new TCRMResponse();
        outputTxnObj.setStatus(outputStatus);
        outputTxnObj.setData(mainOutput);
        logger.finest("RETURN Object execute(Object inputObj)");
        return outputTxnObj;
    }
	
}


