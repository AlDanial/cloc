/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[04078b22c3e5f1efd7c7869caa091927]
 */

package com.ibm.mdm.dsea.arch.compositeTxn;

import java.sql.SQLException;
import java.util.Vector;

import com.dwl.base.DWLCommon;
import com.dwl.base.DWLResponse;
import com.dwl.base.IDWLErrorMessage;
import com.dwl.base.error.DWLError;
import com.dwl.base.error.DWLErrorCode;
import com.dwl.base.error.DWLStatus;
import com.dwl.base.exception.DWLBaseException;
import com.dwl.base.requestHandler.DWLTransactionPersistent;
import com.dwl.base.requestHandler.DWLTxnBP;
import com.dwl.base.util.StringUtils;
import com.dwl.tcrm.common.TCRMResponse;
import com.dwl.tcrm.coreParty.component.TCRMPartyBObj;
import com.dwl.tcrm.coreParty.component.TCRMPartyComponent;
import com.dwl.tcrm.exception.TCRMException;
import com.dwl.tcrm.utilities.TCRMClassFactory;
import com.dwl.unifi.tx.exception.BusinessProxyException;
import com.dwl.base.DWLControl;
import com.ibm.daimler.dsea.component.DSEAAdditionsExtsComponent;
import com.ibm.daimler.dsea.component.XContEquivBObjExt;
import com.ibm.daimler.dsea.component.XDataSharingBObj;
import com.ibm.daimler.dsea.component.XPersonBObjExt;
import com.ibm.mdm.dsea.arch.component.MaintainIndividualObjectBObj;
import com.ibm.mdm.dsea.arch.constant.DSEAArchSimplificationComponentID;
import com.ibm.mdm.dsea.arch.constant.DSEAArchSimplificationErrorReasonCode;
import com.ibm.mdm.dsea.arch.constant.DSEACompositeArchConstant;
import com.ibm.mdm.dsea.arch.helper.MaintainIndividualANZ;
import com.ibm.mdm.dsea.arch.helper.MaintainIndividualCL1;
import com.ibm.mdm.dsea.arch.helper.MaintainIndividualIND;
import com.ibm.mdm.dsea.arch.helper.MaintainIndividualJPN;
import com.ibm.mdm.dsea.arch.helper.MaintainIndividualKOR;
import com.ibm.mdm.dsea.arch.helper.MaintainIndividualME;
import com.ibm.mdm.dsea.arch.helper.MaintainIndividualMYS;
import com.ibm.mdm.dsea.arch.helper.MaintainIndividualTHA;
import com.ibm.mdm.dsea.arch.helper.MaintainIndividualTUR;
import com.ibm.mdm.dsea.arch.util.ValidationUtilArch;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * 
 * @generated NOT
 */
public class MaintainIndividualCompositeTxnBP  extends ValidationUtilArch {

	/**
	 * @generated
	 **/
	private IDWLErrorMessage errHandler;
	
	/**
    * <!-- begin-user-doc -->
	  * <!-- end-user-doc -->
    * @generated 
    */
	 private final static com.dwl.base.logging.IDWLLogger logger = com.dwl.base.logging.DWLLoggerManager.getLogger(MaintainIndividualCompositeTxnBP.class);
	/**
	 * @generated
	 **/
    public MaintainIndividualCompositeTxnBP() {
        super();
        errHandler = TCRMClassFactory.getErrorHandler();
    }
	/**
	 * @generated
	 **/
    public Object execute(Object inputObj) throws BusinessProxyException {
    logger.finest("ENTER Object execute(Object inputObj)");

        TCRMResponse outputTxnObj = null;
        DWLTransactionPersistent inputTxnObj = (DWLTransactionPersistent) inputObj;
        DWLControl control = inputTxnObj.getTxnControl();
        DWLCommon topLevelObject = (DWLCommon) inputTxnObj.getTxnTopLevelObject();
        XPersonBObjExt inputPersonBObj = null;
        XPersonBObjExt outputPersonBObj = null;
        String marketName = null;
        String sourceType = null;
        String sourceValue = null;
        String partyId = null;
        String sfdcId = null;
        XPersonBObjExt personResponseBObj = null;
        boolean isUCIDPresent;
        DWLStatus outputStatus = new DWLStatus();
        Vector<DWLError> vectReqDWLError = new Vector<DWLError>();    
        MaintainIndividualObjectBObj mainOutput = new MaintainIndividualObjectBObj();
        
        DSEAAdditionsExtsComponent additionsExtsComponent = new DSEAAdditionsExtsComponent();
    	
        //validate input object
        DWLError error = validateMaintainIndividual(topLevelObject, control);
        
        if (error != null) {
            outputStatus = new DWLStatus();
			outputStatus.setStatus(DWLStatus.FATAL);
			outputStatus.addError(error);

			outputTxnObj = new TCRMResponse();
			outputTxnObj.setStatus(outputStatus);
			outputTxnObj.setData(mainOutput);

			return outputTxnObj;
        }
        
        if (!(topLevelObject instanceof MaintainIndividualObjectBObj)) {
            // MDM_TODO0: CDKWB0014I optionally use a more appropriate error code than
            // "MAINTAINCOMPANY_FAILED".
            DWLError error1 = errHandler.getErrorMessage(DSEAArchSimplificationComponentID.MAINTAIN_INDIVIDUAL_BUSINESS_PROXY,
                                                        "INSERR",
                                                        DSEAArchSimplificationErrorReasonCode.MAINTAININDIVIDUAL_FAILED,
                                                        control, new String[0]);
            throw new BusinessProxyException(error1.getErrorMessage());
            
        }
        
        MaintainIndividualObjectBObj mainInput = (MaintainIndividualObjectBObj) topLevelObject;        
        inputPersonBObj = (XPersonBObjExt) mainInput.getTCRMPersonBObj();        
       
        
      //KOR Individual Start : 16th June
        MaintainIndividualKOR maintainIndividualKOR = new MaintainIndividualKOR();
        MaintainIndividualIND maintainIndividualIND = new MaintainIndividualIND();
        MaintainIndividualANZ maintainIndividualANZ = new MaintainIndividualANZ();
        MaintainIndividualCL1 maintainIndividualCL1 = new MaintainIndividualCL1();
        MaintainIndividualTUR maintainIndividualTUR = new MaintainIndividualTUR();
        MaintainIndividualME maintainIndividualME = new MaintainIndividualME();
        
        marketName = inputPersonBObj.getXMarketName();
        if(marketName != null && marketName.equals("KOR")){
        	mainOutput = maintainIndividualKOR.execute(mainInput, control);
        }
      //KOR Individual Ends : 16th June
        
        //IND Individual Start 
        if(marketName != null && marketName.equals("IND")){
        	mainOutput = maintainIndividualIND.execute(mainInput, control);
        }
        //IND Individual Ends
        
        //ANZ Individual Start 
		if(marketName != null && (marketName.equals("AU") || marketName.equals("NZ"))){
        	mainOutput = maintainIndividualANZ.execute(mainInput, control);
        }
		//ANZ Individual Ends
		  //CL1 Individual Start 
		if(marketName != null && (marketName.equals("ID") || marketName.equals("VN") || marketName.equals("SG"))){
        	mainOutput = maintainIndividualCL1.execute(mainInput, control);
		}
		//CL1 Individual Ends 
		
		//MYS Individual Start 
        MaintainIndividualMYS maintainIndividualMYS = new MaintainIndividualMYS();
        
        marketName = inputPersonBObj.getXMarketName();
        if(marketName != null && marketName.equals("MYS")){
        	mainOutput = maintainIndividualMYS.execute(mainInput, control);
        }
      //MYS Individual Ends 
        
      //THA Individual Start 
        MaintainIndividualTHA maintainIndividualTHA = new MaintainIndividualTHA();
        
        marketName = inputPersonBObj.getXMarketName();
        if(marketName != null && marketName.equals("THA")){
        	mainOutput = maintainIndividualTHA.execute(mainInput, control);
        }
      //THA Individual Ends
        //JPN Individual Start 
        MaintainIndividualJPN maintainIndividualJPN = new MaintainIndividualJPN();
        marketName = inputPersonBObj.getXMarketName();
        if(marketName != null && marketName.equals("JPN")){
        	mainOutput = maintainIndividualJPN.execute(mainInput, control);
        }
      //JPN Individual Ends
        
        if(marketName != null && marketName.equals("TUR"))
        {
        	mainOutput = maintainIndividualTUR.execute(mainInput, control);
        }
        
        if(marketName != null && marketName.equals("ME"))
        {
        	mainOutput = maintainIndividualME.execute(mainInput, control);
        }
        // Construct the response object.
        //DWLStatus outputStatus = new DWLStatus();
        outputStatus.setStatus(DWLStatus.SUCCESS);
        outputTxnObj = new TCRMResponse();
        outputTxnObj.setStatus(outputStatus);
        outputTxnObj.setData(mainOutput);
        logger.finest("RETURN Object execute(Object inputObj)");
        return outputTxnObj;
    }
	

}


