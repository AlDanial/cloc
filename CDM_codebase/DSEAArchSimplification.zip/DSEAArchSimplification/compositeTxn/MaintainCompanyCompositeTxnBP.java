package com.ibm.mdm.dsea.arch.compositeTxn;

import java.sql.SQLException;
import java.util.Vector;

import com.dwl.base.DWLCommon;
import com.dwl.base.DWLResponse;
import com.dwl.base.IDWLErrorMessage;
import com.dwl.base.error.DWLError;
import com.dwl.base.error.DWLStatus;
import com.dwl.base.exception.DWLBaseException;
import com.dwl.base.requestHandler.DWLTransactionPersistent;
import com.dwl.base.requestHandler.DWLTxnBP;
import com.dwl.base.util.StringUtils;
import com.dwl.tcrm.common.TCRMResponse;
import com.dwl.tcrm.coreParty.component.TCRMPartyBObj;
import com.dwl.tcrm.utilities.TCRMClassFactory;
import com.dwl.unifi.tx.exception.BusinessProxyException;


import com.dwl.base.DWLControl;
import com.ibm.daimler.dsea.component.DSEAAdditionsExtsComponent;
import com.ibm.daimler.dsea.component.XDataSharingBObj;
import com.ibm.daimler.dsea.component.XOrgBObjExt;
import com.ibm.mdm.dsea.arch.component.MaintainCompanyObjectBObj;
import com.ibm.mdm.dsea.arch.constant.DSEAArchSimplificationComponentID;
import com.ibm.mdm.dsea.arch.constant.DSEAArchSimplificationErrorReasonCode;
import com.ibm.mdm.dsea.arch.constant.DSEACompositeArchConstant;
import com.ibm.mdm.dsea.arch.helper.MaintainCompanyANZ;
import com.ibm.mdm.dsea.arch.helper.MaintainCompanyCL1;
import com.ibm.mdm.dsea.arch.helper.MaintainCompanyIND;
import com.ibm.mdm.dsea.arch.helper.MaintainCompanyJPN;
import com.ibm.mdm.dsea.arch.helper.MaintainCompanyKOR;
import com.ibm.mdm.dsea.arch.helper.MaintainCompanyME;
import com.ibm.mdm.dsea.arch.helper.MaintainCompanyMYS;
import com.ibm.mdm.dsea.arch.helper.MaintainCompanyTHA;
import com.ibm.mdm.dsea.arch.helper.MaintainCompanyTUR;
import com.ibm.mdm.dsea.arch.util.ValidationUtilArch;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * 
 * @generated NOT
 */

public class MaintainCompanyCompositeTxnBP extends ValidationUtilArch{
	
	/**
	 * @generated
	 **/
	private IDWLErrorMessage errHandler;
	
	/**
    * <!-- begin-user-doc -->
	  * <!-- end-user-doc -->
    * @generated 
    */
	 private final static com.dwl.base.logging.IDWLLogger logger = com.dwl.base.logging.DWLLoggerManager.getLogger(MaintainCompanyCompositeTxnBP.class);
	/**
	 * @generated
	 **/
    public MaintainCompanyCompositeTxnBP() {
        super();
        errHandler = TCRMClassFactory.getErrorHandler();
    }
	/**
	 * @generated
	 **/
    public Object execute(Object inputObj) throws BusinessProxyException {
    logger.finest("ENTER Object execute(Object inputObj)");

        TCRMResponse outputTxnObj = null;
        DWLTransactionPersistent inputTxnObj = (DWLTransactionPersistent) inputObj;
        DWLControl control = inputTxnObj.getTxnControl();
        DWLCommon topLevelObject = (DWLCommon) inputTxnObj.getTxnTopLevelObject();
        XOrgBObjExt inputCompanyBObj = null;
        XOrgBObjExt outputCompanyBObj = null;
        String marketName = null;
        String sourceType = null;
        String sourceValue = null;
        String partyId = null;
        String sfdcId = null;
        XOrgBObjExt companyResponseBObj = null;
        boolean isUCIDPresent;
        DWLStatus outputStatus = new DWLStatus();
        Vector<DWLError> vectReqDWLError = new Vector<DWLError>();    
        MaintainCompanyObjectBObj mainOutput = new MaintainCompanyObjectBObj();
        DSEAAdditionsExtsComponent additionsExtsComponent = new DSEAAdditionsExtsComponent();
    	

        DWLError error = validateMaintainCompany(topLevelObject, control);
        	
        if (error != null) {
            outputStatus = new DWLStatus();
			outputStatus.setStatus(DWLStatus.FATAL);
			outputStatus.addError(error);

			outputTxnObj = new TCRMResponse();
			outputTxnObj.setStatus(outputStatus);
			outputTxnObj.setData(mainOutput);

			return outputTxnObj;
        }
        
        
        if (!(topLevelObject instanceof MaintainCompanyObjectBObj)) {
            // MDM_TODO0: CDKWB0014I optionally use a more appropriate error code than
            // "MAINTAINCOMPANY_FAILED".
            DWLError error1 = errHandler.getErrorMessage(DSEAArchSimplificationComponentID.MAINTAIN_COMPANY_BUSINESS_PROXY,
                                                        "INSERR",
                                                        DSEAArchSimplificationErrorReasonCode.MAINTAINCOMPANY_FAILED,
                                                        control, new String[0]);
            throw new BusinessProxyException(error1.getErrorMessage());
            
            /*outputStatus = new DWLStatus();
 			outputStatus.setStatus(DWLStatus.FATAL);
 			outputStatus.addError(error1);

 			outputTxnObj = new TCRMResponse();
 			outputTxnObj.setStatus(outputStatus);
 			outputTxnObj.setData(mainOutput);

 			return outputTxnObj;*/
        }
        
        MaintainCompanyObjectBObj mainInput = (MaintainCompanyObjectBObj) topLevelObject;
       
        inputCompanyBObj = (XOrgBObjExt) mainInput.getTCRMOrganizationBObj();
        
        
        
        
        //KOR Company Start : 16th June
       
        MaintainCompanyKOR maintainCompanyKOR = new MaintainCompanyKOR();
         
        MaintainCompanyIND maintainCompanyIND = new MaintainCompanyIND();
		MaintainCompanyANZ maintainCompanyANZ = new MaintainCompanyANZ();
		MaintainCompanyCL1 maintainCompanyCL1 = new MaintainCompanyCL1(); 
		MaintainCompanyTUR maintainCompanyTUR = new MaintainCompanyTUR();
		MaintainCompanyME maintainCompanyME = new MaintainCompanyME();
        
        marketName = inputCompanyBObj.getXMarketName();
        if(marketName != null && marketName.equals("KOR")){
        	mainOutput = maintainCompanyKOR.execute(mainInput, control);
        }
        

		//IND Company Start
		if(marketName != null && marketName.equals("IND")){
        	mainOutput = maintainCompanyIND.execute(mainInput, control);
        }
		//IND Company Ends
		
		//ANZ Company Start
		if(marketName != null && (marketName.equals("AU") || marketName.equals("NZ"))){
        	mainOutput = maintainCompanyANZ.execute(mainInput, control);
        }
		//ANZ Company Ends
        //CL1 Company Start
		if(marketName != null && (marketName.equals("ID") || marketName.equals("VN") || marketName.equals("SG"))){
        	mainOutput = maintainCompanyCL1.execute(mainInput, control);
		}
		//CL1 Company Ends
		//MYS Company Start      
        MaintainCompanyMYS maintainCompanyMYS = new MaintainCompanyMYS();
         
        
        marketName = inputCompanyBObj.getXMarketName();
        if(marketName != null && marketName.equals("MYS")){
        	mainOutput = maintainCompanyMYS.execute(mainInput, control);
        }
        
      //MYS Company Ends 
        
      //THA Company Start 
        
        MaintainCompanyTHA maintainCompanyTHA = new MaintainCompanyTHA();
         
        
        marketName = inputCompanyBObj.getXMarketName();
        if(marketName != null && marketName.equals("THA")){
        	mainOutput = maintainCompanyTHA.execute(mainInput, control);
        }
        
      //THA Company Ends 
        
        //JPN Company Start        
        MaintainCompanyJPN maintainCompanyJPN = new MaintainCompanyJPN();        
        
        marketName = inputCompanyBObj.getXMarketName();
        if(marketName != null && marketName.equals("JPN")){
        	mainOutput = maintainCompanyJPN.execute(mainInput, control);
        }       
        //JPN Company Ends
        
        if(marketName != null && marketName.equals("TUR"))
        {
        	mainOutput = maintainCompanyTUR.execute(mainInput, control);
        }
        
        if(marketName != null && marketName.equals("ME"))
        {
        	mainOutput = maintainCompanyME.execute(mainInput, control);
        }
        // Construct the response object.
        outputStatus = new DWLStatus();
        outputStatus.setStatus(DWLStatus.SUCCESS);
        outputTxnObj = new TCRMResponse();
        outputTxnObj.setStatus(outputStatus);
        outputTxnObj.setData(mainOutput);
    logger.finest("RETURN Object execute(Object inputObj)");
        return outputTxnObj;
    }

	
}
