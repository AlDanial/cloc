package com.ibm.mdm.dsea.arch.helper;

import java.sql.SQLException;
import java.util.Vector;

import com.dwl.base.DWLControl;
import com.dwl.base.DWLResponse;
import com.dwl.base.IDWLErrorMessage;
import com.dwl.base.error.DWLError;
import com.dwl.base.exception.DWLBaseException;
import com.dwl.base.util.StringUtils;
import com.dwl.tcrm.coreParty.component.TCRMPartyBObj;
import com.dwl.tcrm.utilities.TCRMClassFactory;
import com.dwl.unifi.tx.exception.BusinessProxyException;
import com.ibm.daimler.dsea.component.DSEAAdditionsExtsComponent;
import com.ibm.daimler.dsea.component.XDataSharingBObj;
import com.ibm.daimler.dsea.component.XPersonBObjExt;
import com.ibm.mdm.dsea.arch.component.MaintainIndividualObjectBObj;
import com.ibm.mdm.dsea.arch.constant.DSEACompositeArchConstant;
import com.ibm.mdm.dsea.arch.util.ValidationUtilArch;

public class MaintainIndividualCL1 extends ValidationUtilArch {
	/**
	 * @generated
	 **/
	private IDWLErrorMessage errHandler;

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	private final static com.dwl.base.logging.IDWLLogger logger = com.dwl.base.logging.DWLLoggerManager
			.getLogger(MaintainIndividualKOR.class);

	/**
	 * @generated
	 **/
	public MaintainIndividualCL1() {
		super();
		errHandler = TCRMClassFactory.getErrorHandler();
	}

	/**
	 * @param control
	 * @generated
	 **/
	public MaintainIndividualObjectBObj execute(
			MaintainIndividualObjectBObj mainInput, DWLControl control)
			throws BusinessProxyException {
		logger.finest("ENTER Object execute(Object inputObj)");

		XPersonBObjExt outputPersonBObj = null;
		String marketName = null;
		String sourceType = null;
		String sourceValue = null;
		String partyId = null;
		String sfdcId = null;
		XPersonBObjExt personResponseBObj = null;
		boolean isUCIDPresent;
		Vector<DWLError> vectReqDWLError = new Vector<DWLError>();
		MaintainIndividualObjectBObj mainOutput = new MaintainIndividualObjectBObj();

		DSEAAdditionsExtsComponent additionsExtsComponent = new DSEAAdditionsExtsComponent();

		// validate input object
		/*
		 * DWLError error = validateMaintainIndividual(topLevelObject, control);
		 * if (error != null) {
		 * 
		 * DWLStatus outputStatus = new DWLStatus();
		 * outputStatus.setStatus(DWLStatus.FATAL);
		 * outputStatus.addError(error);
		 * 
		 * outputTxnObj = new TCRMResponse();
		 * outputTxnObj.setStatus(outputStatus);
		 * outputTxnObj.setData(mainOutput);
		 * 
		 * return outputTxnObj; }
		 */

		// MaintainIndividualObjectBObj mainInput =
		// (MaintainIndividualObjectBObj) topLevelObject;
		// inputPersonBObj = (XPersonBObjExt) mainInput.getTCRMPersonBObj();

		control.put("AutoCollapse", "false");

		control.put("REARCH", "true");

		XPersonBObjExt inputPersonBObj = (XPersonBObjExt) mainInput
				.getTCRMPersonBObj();

		sourceType = inputPersonBObj.getSourceIdentifierType();
		sourceValue = inputPersonBObj.getSourceIdentifierValue();

		sfdcId = getSFDCIdFromInputPerson(inputPersonBObj);
		try {
			partyId = getPartyIdBySFDCId(sfdcId, control);
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

			// SFDC is Incoming Source
			if (sourceType != null
					&& StringUtils.isNonBlank(sourceType)
					&& (sourceType
							.equalsIgnoreCase(DSEACompositeArchConstant.SFDC_TYPE))) {

				// set mandatory indicators

				try {
					setIndicatorsIndividualCL1(inputPersonBObj);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				// Create Person
				if (partyId == null && !StringUtils.isNonBlank(partyId)) {

					personResponseBObj = createPersonWholesale(
							personResponseBObj, additionsExtsComponent,
							inputPersonBObj, control);

				}
				// Update Person WS
				else {
					try {
						personResponseBObj = updatePersonWholesaleCL1(
								personResponseBObj, additionsExtsComponent,
								inputPersonBObj, outputPersonBObj, control,
								partyId);
					} 
					catch(BusinessProxyException bpe)
					{
						throw new BusinessProxyException(bpe.getMessage());
					}
					catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

				}

				XDataSharingBObj xdataSharingInputReqBObj = null;
				DWLResponse dwlxDataSharingResp = null;
				XDataSharingBObj xdataSharingResp = null;
				try {
					dwlxDataSharingResp = additionsExtsComponent
							.getDataSharingByPartyId(
									personResponseBObj.getPartyId(), control);
				} catch (DWLBaseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				
				
				if (mainInput.getItemsXDataSharingBObj() != null
						&& mainInput.getItemsXDataSharingBObj().size() > 0) {
					
					xdataSharingInputReqBObj  = (XDataSharingBObj) mainInput.getItemsXDataSharingBObj().get(0);
				}
				
				try {
					dwlxDataSharingResp = additionsExtsComponent.getDataSharingByPartyId(personResponseBObj.getPartyId(), control);
				} catch (DWLBaseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				Vector<XDataSharingBObj> vecExistingDataSharingObj = (Vector<XDataSharingBObj>) dwlxDataSharingResp.getData();
				
				if (null != dwlxDataSharingResp.getData() && xdataSharingInputReqBObj != null) {
					
					//handleInputXDataSharing(xdataSharingInputReqBObj,vecXDataSharingFinalReqObj, DSEACompositeArchConstant.UPDATE_PERSON_TXN, control);
					
					xdataSharingResp = maintainXDataSharing(((TCRMPartyBObj) personResponseBObj),
												vecExistingDataSharingObj,xdataSharingInputReqBObj, sb, control);
				
				} else {
					if (mainInput.getItemsXDataSharingBObj() != null
							&& mainInput.getItemsXDataSharingBObj().size() > 0) {
						
						handleInputXDataSharing(xdataSharingInputReqBObj,DSEACompositeArchConstant.ADD_PERSON_TXN, control);
						
						xdataSharingResp = handleXDataSharingAdd(((TCRMPartyBObj) personResponseBObj),
								xdataSharingInputReqBObj, sb, control);
					}
				}
				
				if (null != xdataSharingResp) {
					mainOutput.setXDataSharingBObj(xdataSharingResp);
				}
			}
			
			else
			{
				//If source is not SFDC then throw error
				throw new BusinessProxyException("Source Type Should be: 1001");
			}
		
		mainOutput.setTCRMPersonBObj(personResponseBObj);
		// MDM_TODO: CDKWB0013I build the response Bobj.
		mainOutput.setControl(control);

		return mainOutput;
	}

}
