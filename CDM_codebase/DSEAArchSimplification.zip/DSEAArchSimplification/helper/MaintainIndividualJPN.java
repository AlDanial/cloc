package com.ibm.mdm.dsea.arch.helper;

import java.sql.SQLException;
import java.util.Vector;

import com.dwl.base.DWLCommon;
import com.dwl.base.DWLResponse;
import com.dwl.base.IDWLErrorMessage;
import com.dwl.base.error.DWLError;
import com.dwl.base.error.DWLErrorCode;
import com.dwl.base.error.DWLStatus;
import com.dwl.base.exception.DWLBaseException;
import com.dwl.base.requestHandler.DWLTransactionPersistent;
import com.dwl.base.requestHandler.DWLTxnBP;
import com.dwl.base.util.StringUtils;
import com.dwl.tcrm.common.TCRMResponse;
import com.dwl.tcrm.coreParty.component.TCRMPartyBObj;
import com.dwl.tcrm.coreParty.component.TCRMPartyComponent;
import com.dwl.tcrm.coreParty.component.TCRMPersonBObj;
import com.dwl.tcrm.exception.TCRMException;
import com.dwl.tcrm.utilities.TCRMClassFactory;
import com.dwl.unifi.tx.exception.BusinessProxyException;
import com.dwl.base.DWLControl;
import com.ibm.daimler.dsea.component.DSEAAdditionsExtsComponent;
import com.ibm.daimler.dsea.component.XContEquivBObjExt;
import com.ibm.daimler.dsea.component.XDataSharingBObj;
import com.ibm.daimler.dsea.component.XPersonBObjExt;
import com.ibm.mdm.dsea.arch.component.MaintainIndividualObjectBObj;
import com.ibm.mdm.dsea.arch.constant.DSEAArchSimplificationComponentID;
import com.ibm.mdm.dsea.arch.constant.DSEAArchSimplificationErrorReasonCode;
import com.ibm.mdm.dsea.arch.constant.DSEACompositeArchConstant;
import com.ibm.mdm.dsea.arch.util.ValidationUtilArch;

/**
 * <!-- begin-user-doc --> <!-- end-user-doc -->
 *
 * 
 * @generated NOT
 */
public class MaintainIndividualJPN extends ValidationUtilArch {

	/**
	 * @generated
	 **/
	private IDWLErrorMessage errHandler;

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	private final static com.dwl.base.logging.IDWLLogger logger = com.dwl.base.logging.DWLLoggerManager
			.getLogger(MaintainIndividualJPN.class);

	/**
	 * @generated
	 **/
	public MaintainIndividualJPN() {
		super();
		errHandler = TCRMClassFactory.getErrorHandler();
	}

	/**
	 * @param control
	 * @generated
	 **/
	@SuppressWarnings("unchecked")
	public MaintainIndividualObjectBObj execute(
			MaintainIndividualObjectBObj mainInput, DWLControl control)
			throws BusinessProxyException {
		logger.finest("ENTER Object execute(Object inputObj)");

		XPersonBObjExt outputPersonBObj = null;
		String sourceType = null;
		String partyId = null;
		String sfdcId = null;
		String uCID = null;
		XPersonBObjExt personResponseBObj = null;
		MaintainIndividualObjectBObj mainOutput = new MaintainIndividualObjectBObj();
		DSEAAdditionsExtsComponent additionsExtsComponent = new DSEAAdditionsExtsComponent();
		control.put("AutoCollapse", "false");
		control.put("REARCH", "true");
		XPersonBObjExt inputPersonBObj = (XPersonBObjExt) mainInput
				.getTCRMPersonBObj();
		sourceType = inputPersonBObj.getSourceIdentifierType();
		sfdcId = getSFDCIdFromInputPerson(inputPersonBObj);
		uCID = getUCIDFromInputPerson(inputPersonBObj);
		XDataSharingBObj xdataSharingInputReqBObj = null;
		DWLResponse dwlxDataSharingResp = null;
		XDataSharingBObj xdataSharingResp = null;
		try {
			partyId = getPartyIdBySFDCId(sfdcId, control); // needs Query twik
			if (partyId == null && !StringUtils.isNonBlank(partyId)
					&& uCID != null) {
				partyId = getPartyIdByUCID(uCID, control);
			}
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		// SFDC is Incoming Source
		if (sourceType != null
				&& StringUtils.isNonBlank(sourceType)
				&& (sourceType
						.equalsIgnoreCase(DSEACompositeArchConstant.SFDC_TYPE))) {
			// set mandatory indicators
			try {
				setIndicatorsIndividualJPN(inputPersonBObj);
			} catch (Exception e) {
				e.printStackTrace();
			}
			// Create Person
			if (partyId == null && !StringUtils.isNonBlank(partyId)) {
				personResponseBObj = createPersonWholesale(personResponseBObj,
						additionsExtsComponent, inputPersonBObj, control);
			}
			// Update Person WS
			else {
				try {
					personResponseBObj = updatePersonWholesaleJPN(
							personResponseBObj, additionsExtsComponent,
							inputPersonBObj, outputPersonBObj, control, partyId);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		
			if (mainInput!=null && mainInput.getItemsXDataSharingBObj() != null
					&& mainInput.getItemsXDataSharingBObj().size() > 0) {
				xdataSharingInputReqBObj = (XDataSharingBObj) mainInput
						.getItemsXDataSharingBObj().get(0);
			}
			try {
				dwlxDataSharingResp = additionsExtsComponent
						.getDataSharingByPartyId(
								personResponseBObj.getPartyId(), control);
			} catch (DWLBaseException e) {
				e.printStackTrace();
			}
			Vector<XDataSharingBObj> vecExistingDataSharingObj = (Vector<XDataSharingBObj>) dwlxDataSharingResp
					.getData();
			if (dwlxDataSharingResp != null
					&& null != dwlxDataSharingResp.getData()
					&& xdataSharingInputReqBObj != null) {
				xdataSharingResp = maintainXDataSharingJPN(
						((TCRMPartyBObj) personResponseBObj),
						vecExistingDataSharingObj, xdataSharingInputReqBObj,
						sb, control);
			} else {
				if (mainInput.getItemsXDataSharingBObj() != null
						&& mainInput.getItemsXDataSharingBObj().size() > 0) {
					handleInputXDataSharing(xdataSharingInputReqBObj,
							DSEACompositeArchConstant.ADD_PERSON_TXN, control);
					xdataSharingResp = handleXDataSharingAdd(
							((TCRMPartyBObj) personResponseBObj),
							xdataSharingInputReqBObj, sb, control);
				}
			}
			if (null != xdataSharingResp) {
				mainOutput.setXDataSharingBObj(xdataSharingResp);
			}
		}
		else
		{
			//If source is not SFDC then throw error
			throw new BusinessProxyException("Source Type Should be: 1001");
		}
		mainOutput.setTCRMPersonBObj(personResponseBObj);
		mainOutput.setControl(control);
		return mainOutput;
	}

}
