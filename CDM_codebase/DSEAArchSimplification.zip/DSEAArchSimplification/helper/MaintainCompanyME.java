package com.ibm.mdm.dsea.arch.helper;

import java.sql.SQLException;
import java.util.Vector;

import com.dwl.base.DWLControl;
import com.dwl.base.DWLResponse;
import com.dwl.base.IDWLErrorMessage;
import com.dwl.base.error.DWLError;
import com.dwl.base.error.DWLStatus;
import com.dwl.base.exception.DWLBaseException;
import com.dwl.base.util.StringUtils;
import com.dwl.tcrm.common.TCRMResponse;
import com.dwl.tcrm.coreParty.component.TCRMPartyBObj;
import com.dwl.tcrm.utilities.TCRMClassFactory;
import com.dwl.unifi.tx.exception.BusinessProxyException;
import com.ibm.daimler.dsea.component.DSEAAdditionsExtsComponent;
import com.ibm.daimler.dsea.component.XDataSharingBObj;
import com.ibm.daimler.dsea.component.XOrgBObjExt;
import com.ibm.mdm.dsea.arch.component.MaintainCompanyObjectBObj;
import com.ibm.mdm.dsea.arch.compositeTxn.MaintainCompanyCompositeTxnBP;
import com.ibm.mdm.dsea.arch.constant.DSEACompositeArchConstant;
import com.ibm.mdm.dsea.arch.util.ValidationUtilArch;

public class MaintainCompanyME extends ValidationUtilArch {
	/**
	 * @generated
	 **/
	private IDWLErrorMessage errHandler;

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	private final static com.dwl.base.logging.IDWLLogger logger = com.dwl.base.logging.DWLLoggerManager
			.getLogger(MaintainCompanyCompositeTxnBP.class);

	/**
	 * @generated
	 **/
	public MaintainCompanyME() {
		super();
		errHandler = TCRMClassFactory.getErrorHandler();
	}

	/**
	 * @generated
	 **/
	public MaintainCompanyObjectBObj execute(
			MaintainCompanyObjectBObj mainInput, DWLControl control)
			throws BusinessProxyException {
		logger.finest("ENTER Object execute(Object inputObj)");

		TCRMResponse outputTxnObj = null;
		XOrgBObjExt outputCompanyBObj = null;
		String marketName = null;
		String sourceType = null;
		String sourceValue = null;
		String partyId = null;
		String sfdcId = null;
		XOrgBObjExt companyResponseBObj = null;
		boolean isUCIDPresent;
		DWLStatus outputStatus = new DWLStatus();
		Vector<DWLError> vectReqDWLError = new Vector<DWLError>();
		MaintainCompanyObjectBObj mainOutput = new MaintainCompanyObjectBObj();
		DSEAAdditionsExtsComponent additionsExtsComponent = new DSEAAdditionsExtsComponent();

		control.put("AutoCollapse", "false");
		control.put("REARCH", "true");

		XOrgBObjExt inputCompanyBObj = (XOrgBObjExt) mainInput
				.getTCRMOrganizationBObj();
		marketName = inputCompanyBObj.getXMarketName();
		sourceType = inputCompanyBObj.getSourceIdentifierType();
		sourceValue = inputCompanyBObj.getSourceIdentifierValue();

		sfdcId = getSFDCIdFromInputCompany(inputCompanyBObj);
		try {
			partyId = getPartyIdBySFDCId(sfdcId, control);
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		
			// SFDC is Incoming Source
			if (sourceType != null
					&& StringUtils.isNonBlank(sourceType)
					&& (sourceType
							.equalsIgnoreCase(DSEACompositeArchConstant.SFDC_TYPE))) {

				// set mandatory indicators

				try {
					setIndicatorsCompanyME(inputCompanyBObj);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				// Create Person
				if (partyId == null && !StringUtils.isNonBlank(partyId)) {

					companyResponseBObj = createCompanyWholesale(
							companyResponseBObj, additionsExtsComponent,
							inputCompanyBObj, control);

				}
				// Update Person WS
				else {
					try {
						companyResponseBObj = updateCompanyWholesaleME(
								companyResponseBObj, additionsExtsComponent,
								inputCompanyBObj, outputCompanyBObj, control,
								partyId);
					} 
					
					catch(BusinessProxyException bpe)
					{
						throw new BusinessProxyException(bpe.getMessage());
					}
					catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

				}

				XDataSharingBObj xdataSharingInputReqBObj = null;
				DWLResponse dwlxDataSharingResp = null;
				XDataSharingBObj xdataSharingResp = null;
				try {
					dwlxDataSharingResp = additionsExtsComponent
							.getDataSharingByPartyId(
									companyResponseBObj.getPartyId(), control);
				} catch (DWLBaseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				
				
				if (mainInput.getItemsXDataSharingBObj() != null
						&& mainInput.getItemsXDataSharingBObj().size() > 0) {
					
					xdataSharingInputReqBObj  = (XDataSharingBObj) mainInput.getItemsXDataSharingBObj().get(0);
				}
				
				try {
					dwlxDataSharingResp = additionsExtsComponent.getDataSharingByPartyId(companyResponseBObj.getPartyId(), control);
				} catch (DWLBaseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				Vector<XDataSharingBObj> vecExistingDataSharingObj = (Vector<XDataSharingBObj>) dwlxDataSharingResp.getData();
				
				if (null != dwlxDataSharingResp.getData() && xdataSharingInputReqBObj != null) {
					
					//handleInputXDataSharing(xdataSharingInputReqBObj,vecXDataSharingFinalReqObj, DSEACompositeArchConstant.UPDATE_PERSON_TXN, control);
					
					xdataSharingResp = maintainXDataSharing(((TCRMPartyBObj) companyResponseBObj),
												vecExistingDataSharingObj,xdataSharingInputReqBObj, sb, control);
				
				} else {
					if (mainInput.getItemsXDataSharingBObj() != null
							&& mainInput.getItemsXDataSharingBObj().size() > 0) {
						
						handleInputXDataSharing(xdataSharingInputReqBObj, DSEACompositeArchConstant.ADD_PERSON_TXN, control);
						
						xdataSharingResp = handleXDataSharingAdd(((TCRMPartyBObj) companyResponseBObj),
											xdataSharingInputReqBObj, sb, control);
					}
				}
				
				if (null != xdataSharingResp) {
					mainOutput.setXDataSharingBObj(xdataSharingResp);
				}
			}
			
			else
			{
				//If source is not SFDC then throw error
				throw new BusinessProxyException("Source Type Should be: 1001");
			}
		

		mainOutput.setTCRMOrganizationBObj(companyResponseBObj);
		// MDM_TODO: CDKWB0013I build the response Bobj.
		mainOutput.setControl(control);

		return mainOutput;
	}

}
