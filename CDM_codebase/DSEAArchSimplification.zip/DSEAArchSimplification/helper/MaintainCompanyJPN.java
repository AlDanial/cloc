package com.ibm.mdm.dsea.arch.helper;

import java.sql.SQLException;
import java.util.Vector;

import com.dwl.base.DWLCommon;
import com.dwl.base.DWLResponse;
import com.dwl.base.IDWLErrorMessage;
import com.dwl.base.error.DWLError;
import com.dwl.base.error.DWLStatus;
import com.dwl.base.exception.DWLBaseException;
import com.dwl.base.requestHandler.DWLTransactionPersistent;
import com.dwl.base.requestHandler.DWLTxnBP;
import com.dwl.base.util.StringUtils;
import com.dwl.tcrm.common.TCRMResponse;
import com.dwl.tcrm.coreParty.component.TCRMOrganizationBObj;
import com.dwl.tcrm.coreParty.component.TCRMPartyBObj;
import com.dwl.tcrm.utilities.TCRMClassFactory;
import com.dwl.unifi.tx.exception.BusinessProxyException;
import com.dwl.base.DWLControl;
import com.ibm.daimler.dsea.component.DSEAAdditionsExtsComponent;
import com.ibm.daimler.dsea.component.XDataSharingBObj;
import com.ibm.daimler.dsea.component.XOrgBObjExt;
import com.ibm.daimler.dsea.component.XPersonBObjExt;
import com.ibm.mdm.dsea.arch.component.MaintainCompanyObjectBObj;
import com.ibm.mdm.dsea.arch.compositeTxn.MaintainCompanyCompositeTxnBP;
import com.ibm.mdm.dsea.arch.constant.DSEAArchSimplificationComponentID;
import com.ibm.mdm.dsea.arch.constant.DSEAArchSimplificationErrorReasonCode;
import com.ibm.mdm.dsea.arch.constant.DSEACompositeArchConstant;
import com.ibm.mdm.dsea.arch.util.ValidationUtilArch;

/**
 * <!-- begin-user-doc --> <!-- end-user-doc -->
 *
 * 
 * @generated NOT
 */
public class MaintainCompanyJPN extends ValidationUtilArch {

	/**
	 * @generated
	 **/
	private IDWLErrorMessage errHandler;

	

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	private final static com.dwl.base.logging.IDWLLogger logger = com.dwl.base.logging.DWLLoggerManager
			.getLogger(MaintainCompanyCompositeTxnBP.class);

	/**
	 * @generated
	 **/
	public MaintainCompanyJPN() {
		super();
		errHandler = TCRMClassFactory.getErrorHandler();
	}

	/**
	 * @generated
	 **/
	public MaintainCompanyObjectBObj execute(
			MaintainCompanyObjectBObj mainInput, DWLControl control)
					throws BusinessProxyException {
		logger.finest("ENTER Object execute(Object inputObj)");

		XOrgBObjExt outputCompanyBObj = null;
		String sourceType = null;
		String partyId = null;
		String sfdcId = null;
		String uCID = null;
		XOrgBObjExt companyResponseBObj = null;
		MaintainCompanyObjectBObj mainOutput = new MaintainCompanyObjectBObj();
		DSEAAdditionsExtsComponent additionsExtsComponent = new DSEAAdditionsExtsComponent();
		control.put("AutoCollapse", "false");
		control.put("REARCH", "true");
		XOrgBObjExt inputCompanyBObj = (XOrgBObjExt) mainInput
				.getTCRMOrganizationBObj();
		sourceType = inputCompanyBObj.getSourceIdentifierType();
		sfdcId = getSFDCIdFromInputCompany(inputCompanyBObj);
		uCID = getUCIDFromInputCompany(inputCompanyBObj);
		XDataSharingBObj xdataSharingInputReqBObj = null;
		DWLResponse dwlxDataSharingResp = null;
		XDataSharingBObj xdataSharingResp = null;
		try {
			partyId = getPartyIdBySFDCId(sfdcId, control);
			if (partyId == null && !StringUtils.isNonBlank(partyId)
					&& uCID != null) {
				partyId = getPartyIdByUCID(uCID, control);
			}
		} catch (SQLException e1) {

			e1.printStackTrace();
		}
		// SFDC is Incoming Source
		if (sourceType != null
				&& StringUtils.isNonBlank(sourceType)
				&& (sourceType
						.equalsIgnoreCase(DSEACompositeArchConstant.SFDC_TYPE))) {
			// set mandatory indicators
			try {
				setIndicatorsCompanyJPN(inputCompanyBObj);
			} catch (Exception e) {
				e.printStackTrace();
			}
			// Create Company
			if (partyId == null && !StringUtils.isNonBlank(partyId)) {
				companyResponseBObj = createCompanyWholesale(
						companyResponseBObj, additionsExtsComponent,
						inputCompanyBObj, control);
			}
			// Update Company WS
			else {
				try {
					companyResponseBObj = updateCompanyWholesaleJPN(
							companyResponseBObj, additionsExtsComponent,
							inputCompanyBObj, outputCompanyBObj, control,
							partyId);
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			
			if (mainInput.getItemsXDataSharingBObj() != null
					&& mainInput.getItemsXDataSharingBObj().size() > 0) {
				xdataSharingInputReqBObj = (XDataSharingBObj) mainInput
						.getItemsXDataSharingBObj().get(0);
			}
			try {
				dwlxDataSharingResp = additionsExtsComponent
						.getDataSharingByPartyId(
								companyResponseBObj.getPartyId(), control);
				
			} catch (DWLBaseException e) {
				e.printStackTrace();
			}
			@SuppressWarnings("unchecked")
			Vector<XDataSharingBObj> vecExistingDataSharingObj = (Vector<XDataSharingBObj>) dwlxDataSharingResp
					.getData();
			if (null != dwlxDataSharingResp.getData()
					&& xdataSharingInputReqBObj != null) {
				xdataSharingResp = maintainXDataSharingJPN(
						((TCRMPartyBObj) companyResponseBObj),
						vecExistingDataSharingObj, xdataSharingInputReqBObj,
						sb, control);

			} else {
				if (mainInput.getItemsXDataSharingBObj() != null
						&& mainInput.getItemsXDataSharingBObj().size() > 0) {

					handleInputXDataSharing(xdataSharingInputReqBObj,
							DSEACompositeArchConstant.ADD_PERSON_TXN, control);
					xdataSharingResp = handleXDataSharingAdd(
							((TCRMPartyBObj) companyResponseBObj),
							xdataSharingInputReqBObj, sb, control);
				}
			}

			if (null != xdataSharingResp) {
				mainOutput.setXDataSharingBObj(xdataSharingResp);
			}
		}
		else
		{
			//If source is not SFDC then throw error
			throw new BusinessProxyException("Source Type Should be: 1001");
		}
		try {
			
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		mainOutput.setTCRMOrganizationBObj(companyResponseBObj);
		mainOutput.setControl(control);
		return mainOutput;
	}
}
