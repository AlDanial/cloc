# cloc_submodule_test
Trivial git repo used to test cloc's git capabilities.
